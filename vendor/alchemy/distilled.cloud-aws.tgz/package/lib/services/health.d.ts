import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}>;
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const InvalidPaginationToken_base: S.TaggedErrorClass<"InvalidPaginationToken", {
    readonly message: any;
}>;
export declare class InvalidPaginationToken extends /*@__PURE__*/ InvalidPaginationToken_base {
}
declare const UnsupportedLocale_base: S.TaggedErrorClass<"UnsupportedLocale", {
    readonly message: any;
}>;
export declare class UnsupportedLocale extends /*@__PURE__*/ UnsupportedLocale_base {
}
export type EventArn = string;
export type NextToken = string;
export type MaxResults = number;
export interface DescribeAffectedAccountsForOrganizationRequest {
    eventArn: string;
    nextToken?: string;
    maxResults?: number;
}
export type AccountId = string;
export type AffectedAccountsList = string[];
export type EventScopeCode = "PUBLIC" | "ACCOUNT_SPECIFIC" | "NONE" | (string & {});
export interface DescribeAffectedAccountsForOrganizationResponse {
    affectedAccounts?: string[];
    eventScopeCode?: EventScopeCode;
    nextToken?: string;
}
export type EventArnList = string[];
export type EntityArn = string;
export type EntityArnList = string[];
export type EntityValue = string;
export type EntityValueList = string[];
export interface DateTimeRange {
    from?: Date;
    to?: Date;
}
export type DateTimeRangeList = DateTimeRange[];
export type TagKey = string;
export type TagValue = string;
export type TagSet = {
    [key: string]: string | undefined;
};
export type TagFilter = {
    [key: string]: string | undefined;
}[];
export type EntityStatusCode = "IMPAIRED" | "UNIMPAIRED" | "UNKNOWN" | "PENDING" | "RESOLVED" | (string & {});
export type EntityStatusCodeList = EntityStatusCode[];
export interface EntityFilter {
    eventArns: string[];
    entityArns?: string[];
    entityValues?: string[];
    lastUpdatedTimes?: DateTimeRange[];
    tags?: {
        [key: string]: string | undefined;
    }[];
    statusCodes?: EntityStatusCode[];
}
export type Locale = string;
export type MaxResultsLowerRange = number;
export interface DescribeAffectedEntitiesRequest {
    filter: EntityFilter;
    locale?: string;
    nextToken?: string;
    maxResults?: number;
}
export type EntityUrl = string;
export type EntityMetadataKey = string;
export type EntityMetadataValue = string;
export type EntityMetadata = {
    [key: string]: string | undefined;
};
export interface AffectedEntity {
    entityArn?: string;
    eventArn?: string;
    entityValue?: string;
    entityUrl?: string;
    awsAccountId?: string;
    lastUpdatedTime?: Date;
    statusCode?: EntityStatusCode;
    tags?: {
        [key: string]: string | undefined;
    };
    entityMetadata?: {
        [key: string]: string | undefined;
    };
}
export type EntityList = AffectedEntity[];
export interface DescribeAffectedEntitiesResponse {
    entities?: AffectedEntity[];
    nextToken?: string;
}
export interface EventAccountFilter {
    eventArn: string;
    awsAccountId?: string;
}
export type OrganizationEntityFiltersList = EventAccountFilter[];
export interface EntityAccountFilter {
    eventArn: string;
    awsAccountId?: string;
    statusCodes?: EntityStatusCode[];
}
export type OrganizationEntityAccountFiltersList = EntityAccountFilter[];
export interface DescribeAffectedEntitiesForOrganizationRequest {
    organizationEntityFilters?: EventAccountFilter[];
    locale?: string;
    nextToken?: string;
    maxResults?: number;
    organizationEntityAccountFilters?: EntityAccountFilter[];
}
export interface OrganizationAffectedEntitiesErrorItem {
    awsAccountId?: string;
    eventArn?: string;
    errorName?: string;
    errorMessage?: string;
}
export type DescribeAffectedEntitiesForOrganizationFailedSet = OrganizationAffectedEntitiesErrorItem[];
export interface DescribeAffectedEntitiesForOrganizationResponse {
    entities?: AffectedEntity[];
    failedSet?: OrganizationAffectedEntitiesErrorItem[];
    nextToken?: string;
}
export type EventArnsList = string[];
export interface DescribeEntityAggregatesRequest {
    eventArns?: string[];
}
export type Count = number;
export type EntityStatuses = {
    [key in EntityStatusCode]?: number;
};
export interface EntityAggregate {
    eventArn?: string;
    count?: number;
    statuses?: {
        [key: string]: number | undefined;
    };
}
export type EntityAggregateList = EntityAggregate[];
export interface DescribeEntityAggregatesResponse {
    entityAggregates?: EntityAggregate[];
}
export type OrganizationEventArnsList = string[];
export type OrganizationAccountIdsList = string[];
export interface DescribeEntityAggregatesForOrganizationRequest {
    eventArns: string[];
    awsAccountIds?: string[];
}
export interface AccountEntityAggregate {
    accountId?: string;
    count?: number;
    statuses?: {
        [key: string]: number | undefined;
    };
}
export type AccountEntityAggregatesList = AccountEntityAggregate[];
export interface OrganizationEntityAggregate {
    eventArn?: string;
    count?: number;
    statuses?: {
        [key: string]: number | undefined;
    };
    accounts?: AccountEntityAggregate[];
}
export type OrganizationEntityAggregatesList = OrganizationEntityAggregate[];
export interface DescribeEntityAggregatesForOrganizationResponse {
    organizationEntityAggregates?: OrganizationEntityAggregate[];
}
export type EventActionability = "ACTION_REQUIRED" | "ACTION_MAY_BE_REQUIRED" | "INFORMATIONAL" | (string & {});
export type EventActionabilityList = EventActionability[];
export type EventType2 = string;
export type EventTypeList2 = string[];
export type Service = string;
export type ServiceList = string[];
export type Region = string;
export type RegionList = string[];
export type AvailabilityZone = string;
export type AvailabilityZones = string[];
export type EventTypeCategory = "issue" | "accountNotification" | "scheduledChange" | "investigation" | (string & {});
export type EventTypeCategoryList2 = EventTypeCategory[];
export type EventStatusCode = "open" | "closed" | "upcoming" | (string & {});
export type EventStatusCodeList = EventStatusCode[];
export type EventPersona = "OPERATIONS" | "SECURITY" | "BILLING" | (string & {});
export type EventPersonaList = EventPersona[];
export interface EventFilter {
    actionabilities?: EventActionability[];
    eventArns?: string[];
    eventTypeCodes?: string[];
    services?: string[];
    regions?: string[];
    availabilityZones?: string[];
    startTimes?: DateTimeRange[];
    endTimes?: DateTimeRange[];
    lastUpdatedTimes?: DateTimeRange[];
    entityArns?: string[];
    entityValues?: string[];
    eventTypeCategories?: EventTypeCategory[];
    tags?: {
        [key: string]: string | undefined;
    }[];
    eventStatusCodes?: EventStatusCode[];
    personas?: EventPersona[];
}
export type EventAggregateField = "eventTypeCategory" | (string & {});
export interface DescribeEventAggregatesRequest {
    filter?: EventFilter;
    aggregateField: EventAggregateField;
    maxResults?: number;
    nextToken?: string;
}
export type AggregateValue = string;
export interface EventAggregate {
    aggregateValue?: string;
    count?: number;
}
export type EventAggregateList = EventAggregate[];
export interface DescribeEventAggregatesResponse {
    eventAggregates?: EventAggregate[];
    nextToken?: string;
}
export interface DescribeEventDetailsRequest {
    eventArns: string[];
    locale?: string;
}
export type EventTypeCode = string;
export interface Event {
    arn?: string;
    service?: string;
    eventTypeCode?: string;
    eventTypeCategory?: EventTypeCategory;
    region?: string;
    availabilityZone?: string;
    startTime?: Date;
    endTime?: Date;
    lastUpdatedTime?: Date;
    statusCode?: EventStatusCode;
    eventScopeCode?: EventScopeCode;
    actionability?: EventActionability;
    personas?: EventPersona[];
}
export type EventDescription2 = string;
export interface EventDescription {
    latestDescription?: string;
}
export type MetadataKey = string;
export type MetadataValue = string;
export type EventMetadata = {
    [key: string]: string | undefined;
};
export interface EventDetails {
    event?: Event;
    eventDescription?: EventDescription;
    eventMetadata?: {
        [key: string]: string | undefined;
    };
}
export type DescribeEventDetailsSuccessfulSet = EventDetails[];
export interface EventDetailsErrorItem {
    eventArn?: string;
    errorName?: string;
    errorMessage?: string;
}
export type DescribeEventDetailsFailedSet = EventDetailsErrorItem[];
export interface DescribeEventDetailsResponse {
    successfulSet?: EventDetails[];
    failedSet?: EventDetailsErrorItem[];
}
export type OrganizationEventDetailFiltersList = EventAccountFilter[];
export interface DescribeEventDetailsForOrganizationRequest {
    organizationEventDetailFilters: EventAccountFilter[];
    locale?: string;
}
export interface OrganizationEventDetails {
    awsAccountId?: string;
    event?: Event;
    eventDescription?: EventDescription;
    eventMetadata?: {
        [key: string]: string | undefined;
    };
}
export type DescribeEventDetailsForOrganizationSuccessfulSet = OrganizationEventDetails[];
export interface OrganizationEventDetailsErrorItem {
    awsAccountId?: string;
    eventArn?: string;
    errorName?: string;
    errorMessage?: string;
}
export type DescribeEventDetailsForOrganizationFailedSet = OrganizationEventDetailsErrorItem[];
export interface DescribeEventDetailsForOrganizationResponse {
    successfulSet?: OrganizationEventDetails[];
    failedSet?: OrganizationEventDetailsErrorItem[];
}
export interface DescribeEventsRequest {
    filter?: EventFilter;
    nextToken?: string;
    maxResults?: number;
    locale?: string;
}
export type EventList = Event[];
export interface DescribeEventsResponse {
    events?: Event[];
    nextToken?: string;
}
export type AwsAccountIdsList = string[];
export interface OrganizationEventFilter {
    actionabilities?: EventActionability[];
    eventTypeCodes?: string[];
    awsAccountIds?: string[];
    services?: string[];
    regions?: string[];
    startTime?: DateTimeRange;
    endTime?: DateTimeRange;
    lastUpdatedTime?: DateTimeRange;
    entityArns?: string[];
    entityValues?: string[];
    eventTypeCategories?: EventTypeCategory[];
    eventStatusCodes?: EventStatusCode[];
    personas?: EventPersona[];
}
export interface DescribeEventsForOrganizationRequest {
    filter?: OrganizationEventFilter;
    nextToken?: string;
    maxResults?: number;
    locale?: string;
}
export interface OrganizationEvent {
    arn?: string;
    service?: string;
    eventTypeCode?: string;
    eventTypeCategory?: EventTypeCategory;
    eventScopeCode?: EventScopeCode;
    region?: string;
    startTime?: Date;
    endTime?: Date;
    lastUpdatedTime?: Date;
    statusCode?: EventStatusCode;
    actionability?: EventActionability;
    personas?: EventPersona[];
}
export type OrganizationEventList = OrganizationEvent[];
export interface DescribeEventsForOrganizationResponse {
    events?: OrganizationEvent[];
    nextToken?: string;
}
export type EventTypeCodeList = string[];
export type EventTypeCategoryList = EventTypeCategory[];
export type EventTypeActionability = "ACTION_REQUIRED" | "ACTION_MAY_BE_REQUIRED" | "INFORMATIONAL" | (string & {});
export type EventTypeActionabilityList = EventTypeActionability[];
export type EventTypePersona = "OPERATIONS" | "SECURITY" | "BILLING" | (string & {});
export type EventTypePersonaList = EventTypePersona[];
export interface EventTypeFilter {
    eventTypeCodes?: string[];
    services?: string[];
    eventTypeCategories?: EventTypeCategory[];
    actionabilities?: EventTypeActionability[];
    personas?: EventTypePersona[];
}
export interface DescribeEventTypesRequest {
    filter?: EventTypeFilter;
    locale?: string;
    nextToken?: string;
    maxResults?: number;
}
export interface EventType {
    service?: string;
    code?: string;
    category?: EventTypeCategory;
    actionability?: EventTypeActionability;
    personas?: EventTypePersona[];
}
export type EventTypeList = EventType[];
export interface DescribeEventTypesResponse {
    eventTypes?: EventType[];
    nextToken?: string;
}
export interface DescribeHealthServiceStatusForOrganizationRequest {
}
export type HealthServiceAccessStatusForOrganization = string;
export interface DescribeHealthServiceStatusForOrganizationResponse {
    healthServiceAccessStatusForOrganization?: string;
}
export interface ServiceLifecycleFilter {
    service?: string;
}
export type LifecycleMaxResults = number;
export interface DescribeServiceLifecycleRequest {
    filter?: ServiceLifecycleFilter;
    nextToken?: string;
    maxResults?: number;
}
export type ImpactRiskList = string[];
export interface LifecycleEvent {
    lifecycleEventType?: string;
    date?: Date;
    regions?: string[];
    impactRisks?: string[];
    description?: string;
}
export type LifecycleEventList = LifecycleEvent[];
export interface ServiceLifecycle {
    service?: string;
    version?: string;
    title?: string;
    recommendedVersion?: string;
    lifecycleEvents?: LifecycleEvent[];
}
export type ServiceLifecycleList = ServiceLifecycle[];
export interface DescribeServiceLifecycleResponse {
    serviceLifecycles?: ServiceLifecycle[];
    nextToken?: string;
}
export interface DisableHealthServiceAccessForOrganizationRequest {
}
export interface DisableHealthServiceAccessForOrganizationResponse {
}
export interface EnableHealthServiceAccessForOrganizationRequest {
}
export interface EnableHealthServiceAccessForOrganizationResponse {
}
export type DescribeAffectedAccountsForOrganizationError = InvalidPaginationToken | CommonErrors;
/**
 * Returns a list of accounts in the organization from Organizations that are affected by the
 * provided event. For more information about the different types of Health events, see
 * Event.
 *
 * Before you can call this operation, you must first enable Health to work with
 * Organizations. To do this, call the EnableHealthServiceAccessForOrganization operation from your organization's
 * management account.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the next request to return more results.
 */
export declare const describeAffectedAccountsForOrganization: API.PaginatedOperationMethod<DescribeAffectedAccountsForOrganizationRequest, DescribeAffectedAccountsForOrganizationResponse, DescribeAffectedAccountsForOrganizationError, Credentials | HttpClient.HttpClient, AccountId>;
export type DescribeAffectedEntitiesError = InvalidPaginationToken | UnsupportedLocale | CommonErrors;
/**
 * Returns a list of entities that have been affected by the specified events, based on the
 * specified filter criteria. Entities can refer to individual customer resources, groups of
 * customer resources, or any other construct, depending on the Amazon Web Services service. Events that
 * have impact beyond that of the affected entities, or where the extent of impact is unknown,
 * include at least one entity indicating this.
 *
 * At least one event ARN is required.
 *
 * - This API operation uses pagination. Specify the `nextToken` parameter in the next request to return more results.
 *
 * - This operation supports resource-level permissions. You can use this operation to allow or deny access to specific Health events. For more
 * information, see Resource- and action-based conditions in the *Health User Guide*.
 */
export declare const describeAffectedEntities: API.PaginatedOperationMethod<DescribeAffectedEntitiesRequest, DescribeAffectedEntitiesResponse, DescribeAffectedEntitiesError, Credentials | HttpClient.HttpClient, AffectedEntity>;
export type DescribeAffectedEntitiesForOrganizationError = InvalidPaginationToken | UnsupportedLocale | CommonErrors;
/**
 * Returns a list of entities that have been affected by one or more events for one or more
 * accounts in your organization in Organizations, based on the filter criteria. Entities can refer
 * to individual customer resources, groups of customer resources, or any other construct,
 * depending on the Amazon Web Services service.
 *
 * At least one event Amazon Resource Name (ARN) and account ID are required.
 *
 * Before you can call this operation, you must first enable Health to work with
 * Organizations. To do this, call the EnableHealthServiceAccessForOrganization operation from your organization's
 * management account.
 *
 * - This API operation uses pagination. Specify the `nextToken` parameter in the next request to return more results.
 *
 * - This operation doesn't support resource-level permissions. You can't use this operation to allow or deny access to specific Health events. For more
 * information, see Resource- and action-based conditions in the *Health User Guide*.
 */
export declare const describeAffectedEntitiesForOrganization: API.PaginatedOperationMethod<DescribeAffectedEntitiesForOrganizationRequest, DescribeAffectedEntitiesForOrganizationResponse, DescribeAffectedEntitiesForOrganizationError, Credentials | HttpClient.HttpClient, AffectedEntity>;
export type DescribeEntityAggregatesError = CommonErrors;
/**
 * Returns the number of entities that are affected by each of the specified events.
 */
export declare const describeEntityAggregates: API.OperationMethod<DescribeEntityAggregatesRequest, DescribeEntityAggregatesResponse, DescribeEntityAggregatesError, Credentials | HttpClient.HttpClient>;
export type DescribeEntityAggregatesForOrganizationError = CommonErrors;
/**
 * Returns a list of entity aggregates for your Organizations that are affected by each of the specified events.
 */
export declare const describeEntityAggregatesForOrganization: API.OperationMethod<DescribeEntityAggregatesForOrganizationRequest, DescribeEntityAggregatesForOrganizationResponse, DescribeEntityAggregatesForOrganizationError, Credentials | HttpClient.HttpClient>;
export type DescribeEventAggregatesError = InvalidPaginationToken | CommonErrors;
/**
 * Returns the number of events of each event type (issue, scheduled change, and account
 * notification). If no filter is specified, the counts of all events in each category are
 * returned.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the next request to return more results.
 */
export declare const describeEventAggregates: API.PaginatedOperationMethod<DescribeEventAggregatesRequest, DescribeEventAggregatesResponse, DescribeEventAggregatesError, Credentials | HttpClient.HttpClient, EventAggregate>;
export type DescribeEventDetailsError = UnsupportedLocale | CommonErrors;
/**
 * Returns detailed information about one or more specified events. Information includes
 * standard event data (Amazon Web Services Region, service, and so on, as returned by DescribeEvents), a detailed event description, and possible additional metadata
 * that depends upon the nature of the event. Affected entities are not included. To retrieve
 * the entities, use the DescribeAffectedEntities operation.
 *
 * If a specified event can't be retrieved, an error message is returned for that
 * event.
 *
 * This operation supports resource-level permissions. You can use this operation to allow or deny access to specific Health events. For more
 * information, see Resource- and action-based conditions in the *Health User Guide*.
 */
export declare const describeEventDetails: API.OperationMethod<DescribeEventDetailsRequest, DescribeEventDetailsResponse, DescribeEventDetailsError, Credentials | HttpClient.HttpClient>;
export type DescribeEventDetailsForOrganizationError = UnsupportedLocale | CommonErrors;
/**
 * Returns detailed information about one or more specified events for one or more
 * Amazon Web Services accounts in your organization. This information includes standard event data (such as
 * the Amazon Web Services Region and service), an event description, and (depending on the event) possible
 * metadata. This operation doesn't return affected entities, such as the resources related to
 * the event. To return affected entities, use the DescribeAffectedEntitiesForOrganization operation.
 *
 * Before you can call this operation, you must first enable Health to work with
 * Organizations. To do this, call the EnableHealthServiceAccessForOrganization operation from your organization's
 * management account.
 *
 * When you call the `DescribeEventDetailsForOrganization` operation, specify
 * the `organizationEventDetailFilters` object in the request. Depending on the
 * Health event type, note the following differences:
 *
 * - To return event details for a public event, you must specify a null value for the
 * `awsAccountId` parameter. If you specify an account ID for a public
 * event, Health returns an error message because public events aren't specific to
 * an account.
 *
 * - To return event details for an event that is specific to an account in your
 * organization, you must specify the `awsAccountId` parameter in the
 * request. If you don't specify an account ID, Health returns an error message
 * because the event is specific to an account in your organization.
 *
 * For more information, see Event.
 *
 * This operation doesn't support resource-level permissions. You can't use this operation to allow or deny access to specific Health events. For more
 * information, see Resource- and action-based conditions in the *Health User Guide*.
 */
export declare const describeEventDetailsForOrganization: API.OperationMethod<DescribeEventDetailsForOrganizationRequest, DescribeEventDetailsForOrganizationResponse, DescribeEventDetailsForOrganizationError, Credentials | HttpClient.HttpClient>;
export type DescribeEventsError = InvalidPaginationToken | UnsupportedLocale | CommonErrors;
/**
 * Returns information about events that meet the specified filter criteria. Events are
 * returned in a summary form and do not include the detailed description, any additional
 * metadata that depends on the event type, or any affected resources. To retrieve that
 * information, use the DescribeEventDetails and DescribeAffectedEntities operations.
 *
 * If no filter criteria are specified, all events are returned. Results are sorted by
 * `lastModifiedTime`, starting with the most recent event.
 *
 * - When you call the `DescribeEvents` operation and specify an entity
 * for the `entityValues` parameter, Health might return public
 * events that aren't specific to that resource. For example, if you call
 * `DescribeEvents` and specify an ID for an Amazon Elastic Compute Cloud (Amazon EC2)
 * instance, Health might return events that aren't specific to that resource or
 * service. To get events that are specific to a service, use the
 * `services` parameter in the `filter` object. For more
 * information, see Event.
 *
 * - This API operation uses pagination. Specify the `nextToken` parameter in the next request to return more results.
 */
export declare const describeEvents: API.PaginatedOperationMethod<DescribeEventsRequest, DescribeEventsResponse, DescribeEventsError, Credentials | HttpClient.HttpClient, Event>;
export type DescribeEventsForOrganizationError = InvalidPaginationToken | UnsupportedLocale | CommonErrors;
/**
 * Returns information about events across your organization in Organizations. You can use
 * the`filters` parameter to specify the events that you want to return. Events
 * are returned in a summary form and don't include the affected accounts, detailed
 * description, any additional metadata that depends on the event type, or any affected
 * resources. To retrieve that information, use the following operations:
 *
 * - DescribeAffectedAccountsForOrganization
 *
 * - DescribeEventDetailsForOrganization
 *
 * - DescribeAffectedEntitiesForOrganization
 *
 * If you don't specify a `filter`, the
 * `DescribeEventsForOrganizations` returns all events across your organization.
 * Results are sorted by `lastModifiedTime`, starting with the most recent event.
 *
 * For more information about the different types of Health events, see Event.
 *
 * Before you can call this operation, you must first enable Health to work with
 * Organizations. To do this, call the EnableHealthServiceAccessForOrganization operation from your organization's
 * management account.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the next request to return more results.
 */
export declare const describeEventsForOrganization: API.PaginatedOperationMethod<DescribeEventsForOrganizationRequest, DescribeEventsForOrganizationResponse, DescribeEventsForOrganizationError, Credentials | HttpClient.HttpClient, OrganizationEvent>;
export type DescribeEventTypesError = InvalidPaginationToken | UnsupportedLocale | CommonErrors;
/**
 * Returns the event types that meet the specified filter criteria. You can use this API
 * operation to find information about the Health event, such as the category, Amazon Web Services service, and event code. The metadata for each event appears in the EventType object.
 *
 * If you don't specify a filter criteria, the API operation returns all event types, in no
 * particular order.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the next request to return more results.
 */
export declare const describeEventTypes: API.PaginatedOperationMethod<DescribeEventTypesRequest, DescribeEventTypesResponse, DescribeEventTypesError, Credentials | HttpClient.HttpClient, EventType>;
export type DescribeHealthServiceStatusForOrganizationError = CommonErrors;
/**
 * This operation provides status information on enabling or disabling Health to work
 * with your organization. To call this operation, you must use the organization's
 * management account.
 */
export declare const describeHealthServiceStatusForOrganization: API.OperationMethod<DescribeHealthServiceStatusForOrganizationRequest, DescribeHealthServiceStatusForOrganizationResponse, DescribeHealthServiceStatusForOrganizationError, Credentials | HttpClient.HttpClient>;
export type DescribeServiceLifecycleError = InvalidPaginationToken | CommonErrors;
/**
 * Returns lifecycle information for Amazon Web Services services, including end-of-life dates, version recommendations, and lifecycle events.
 */
export declare const describeServiceLifecycle: API.PaginatedOperationMethod<DescribeServiceLifecycleRequest, DescribeServiceLifecycleResponse, DescribeServiceLifecycleError, Credentials | HttpClient.HttpClient, ServiceLifecycle>;
export type DisableHealthServiceAccessForOrganizationError = ConcurrentModificationException | CommonErrors;
/**
 * Disables Health from working with Organizations. To call this operation, you must sign
 * in to the organization's management account. For more information, see Aggregating
 * Health events in the *Health User Guide*.
 *
 * This operation doesn't remove the service-linked role from the management account in your
 * organization. You must use the IAM console, API, or Command Line Interface (CLI) to remove the
 * service-linked role. For more information, see Deleting a Service-Linked Role in the
 * *IAM User Guide*.
 *
 * You can also disable the organizational feature by using the Organizations DisableAWSServiceAccess API operation. After you call this operation,
 * Health stops aggregating events for all other Amazon Web Services accounts in your organization.
 * If you call the Health API operations for organizational view, Health returns
 * an error. Health continues to aggregate health events for your
 * Amazon Web Services account.
 */
export declare const disableHealthServiceAccessForOrganization: API.OperationMethod<DisableHealthServiceAccessForOrganizationRequest, DisableHealthServiceAccessForOrganizationResponse, DisableHealthServiceAccessForOrganizationError, Credentials | HttpClient.HttpClient>;
export type EnableHealthServiceAccessForOrganizationError = ConcurrentModificationException | CommonErrors;
/**
 * Enables Health to work with Organizations. You can use the organizational view feature
 * to aggregate events from all Amazon Web Services accounts in your organization in a centralized location.
 *
 * This operation also creates a service-linked role for the management account in the
 * organization.
 *
 * To call this operation, you must meet the following requirements:
 *
 * - You must have a Business, Enterprise On-Ramp, or Enterprise Support plan from Amazon Web Services Support to use the Health API. If you call
 * the Health API from an Amazon Web Services account that doesn't have a
 * Business, Enterprise On-Ramp, or Enterprise Support plan, you receive a `SubscriptionRequiredException`
 * error.
 *
 * - You must have permission to call this operation from the organization's
 * management account. For example IAM policies, see Health
 * identity-based policy examples.
 *
 * If you don't have the required support plan, you can instead use the Health console
 * to enable the organizational view feature. For more information, see Aggregating
 * Health events in the *Health User Guide*.
 */
export declare const enableHealthServiceAccessForOrganization: API.OperationMethod<EnableHealthServiceAccessForOrganizationRequest, EnableHealthServiceAccessForOrganizationResponse, EnableHealthServiceAccessForOrganizationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=health.d.ts.map