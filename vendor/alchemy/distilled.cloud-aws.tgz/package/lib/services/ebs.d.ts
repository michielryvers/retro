import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import * as T from "../traits.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConcurrentLimitExceededException_base: S.TaggedErrorClass<"ConcurrentLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConcurrentLimitExceededException extends /*@__PURE__*/ ConcurrentLimitExceededException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidSignatureException_base: S.TaggedErrorClass<"InvalidSignatureException", {
    readonly message: any;
}>;
export declare class InvalidSignatureException extends /*@__PURE__*/ InvalidSignatureException_base {
}
declare const RequestThrottledException_base: S.TaggedErrorClass<"RequestThrottledException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RequestThrottledException extends /*@__PURE__*/ RequestThrottledException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SnapshotId = string;
export type ChangedBlocksCount = number;
export type Checksum = string;
export type ChecksumAlgorithm = "SHA256" | (string & {});
export type ChecksumAggregationMethod = "LINEAR" | (string & {});
export interface CompleteSnapshotRequest {
    SnapshotId: string;
    ChangedBlocksCount: number;
    Checksum?: string;
    ChecksumAlgorithm?: ChecksumAlgorithm;
    ChecksumAggregationMethod?: ChecksumAggregationMethod;
}
export type Status = "completed" | "pending" | "error" | (string & {});
export interface CompleteSnapshotResponse {
    Status?: Status;
}
export type BlockIndex = number;
export type BlockToken = string;
export interface GetSnapshotBlockRequest {
    SnapshotId: string;
    BlockIndex: number;
    BlockToken: string;
}
export type DataLength = number;
export interface GetSnapshotBlockResponse {
    DataLength?: number;
    BlockData?: T.StreamingOutputBody;
    Checksum?: string;
    ChecksumAlgorithm?: ChecksumAlgorithm;
}
export type PageToken = string;
export type MaxResults = number;
export interface ListChangedBlocksRequest {
    FirstSnapshotId?: string;
    SecondSnapshotId: string;
    NextToken?: string;
    MaxResults?: number;
    StartingBlockIndex?: number;
}
export interface ChangedBlock {
    BlockIndex?: number;
    FirstBlockToken?: string;
    SecondBlockToken?: string;
}
export type ChangedBlocks = ChangedBlock[];
export type VolumeSize = number;
export type BlockSize = number;
export interface ListChangedBlocksResponse {
    ChangedBlocks?: ChangedBlock[];
    ExpiryTime?: Date;
    VolumeSize?: number;
    BlockSize?: number;
    NextToken?: string;
}
export interface ListSnapshotBlocksRequest {
    SnapshotId: string;
    NextToken?: string;
    MaxResults?: number;
    StartingBlockIndex?: number;
}
export interface Block {
    BlockIndex?: number;
    BlockToken?: string;
}
export type Blocks = Block[];
export interface ListSnapshotBlocksResponse {
    Blocks?: Block[];
    ExpiryTime?: Date;
    VolumeSize?: number;
    BlockSize?: number;
    NextToken?: string;
}
export type Progress = number;
export interface PutSnapshotBlockRequest {
    SnapshotId: string;
    BlockIndex: number;
    BlockData: T.StreamingInputBody;
    DataLength: number;
    Progress?: number;
    Checksum: string;
    ChecksumAlgorithm: ChecksumAlgorithm;
}
export interface PutSnapshotBlockResponse {
    Checksum?: string;
    ChecksumAlgorithm?: ChecksumAlgorithm;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string;
    Value?: string;
}
export type Tags = Tag[];
export type Description = string;
export type IdempotencyToken = string;
export type KmsKeyArn = string | redacted.Redacted<string>;
export type Timeout = number;
export interface StartSnapshotRequest {
    VolumeSize: number;
    ParentSnapshotId?: string;
    Tags?: Tag[];
    Description?: string;
    ClientToken?: string;
    Encrypted?: boolean;
    KmsKeyArn?: string | redacted.Redacted<string>;
    Timeout?: number;
}
export type OwnerId = string;
export type SSEType = "sse-ebs" | "sse-kms" | "none" | (string & {});
export interface StartSnapshotResponse {
    Description?: string;
    SnapshotId?: string;
    OwnerId?: string;
    Status?: Status;
    StartTime?: Date;
    VolumeSize?: number;
    BlockSize?: number;
    Tags?: Tag[];
    ParentSnapshotId?: string;
    KmsKeyArn?: string | redacted.Redacted<string>;
    SseType?: SSEType;
}
export type ErrorMessage = string;
export type AccessDeniedExceptionReason = "UNAUTHORIZED_ACCOUNT" | "DEPENDENCY_ACCESS_DENIED" | (string & {});
export type RequestThrottledExceptionReason = "ACCOUNT_THROTTLED" | "DEPENDENCY_REQUEST_THROTTLED" | "RESOURCE_LEVEL_THROTTLE" | (string & {});
export type ResourceNotFoundExceptionReason = "SNAPSHOT_NOT_FOUND" | "GRANT_NOT_FOUND" | "DEPENDENCY_RESOURCE_NOT_FOUND" | "IMAGE_NOT_FOUND" | (string & {});
export type ServiceQuotaExceededExceptionReason = "DEPENDENCY_SERVICE_QUOTA_EXCEEDED" | (string & {});
export type ValidationExceptionReason = "INVALID_CUSTOMER_KEY" | "INVALID_PAGE_TOKEN" | "INVALID_BLOCK_TOKEN" | "INVALID_GRANT_TOKEN" | "INVALID_SNAPSHOT_ID" | "UNRELATED_SNAPSHOTS" | "INVALID_BLOCK" | "INVALID_CONTENT_ENCODING" | "INVALID_TAG" | "INVALID_DEPENDENCY_REQUEST" | "INVALID_PARAMETER_VALUE" | "INVALID_VOLUME_SIZE" | "CONFLICTING_BLOCK_UPDATE" | "INVALID_IMAGE_ID" | "WRITE_REQUEST_TIMEOUT" | (string & {});
export type CompleteSnapshotError = AccessDeniedException | InternalServerException | RequestThrottledException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | InvalidSignatureException | CommonErrors;
/**
 * Seals and completes the snapshot after all of the required blocks of data have been
 * written to it. Completing the snapshot changes the status to `completed`. You
 * cannot write new blocks to a snapshot after it has been completed.
 *
 * You should always retry requests that receive server (`5xx`)
 * error responses, and `ThrottlingException` and `RequestThrottledException`
 * client error responses. For more information see Error retries in the
 * *Amazon Elastic Compute Cloud User Guide*.
 */
export declare const completeSnapshot: API.OperationMethod<CompleteSnapshotRequest, CompleteSnapshotResponse, CompleteSnapshotError, Credentials | HttpClient.HttpClient>;
export type GetSnapshotBlockError = AccessDeniedException | InternalServerException | RequestThrottledException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Returns the data in a block in an Amazon Elastic Block Store snapshot.
 *
 * You should always retry requests that receive server (`5xx`)
 * error responses, and `ThrottlingException` and `RequestThrottledException`
 * client error responses. For more information see Error retries in the
 * *Amazon Elastic Compute Cloud User Guide*.
 */
export declare const getSnapshotBlock: API.OperationMethod<GetSnapshotBlockRequest, GetSnapshotBlockResponse, GetSnapshotBlockError, Credentials | HttpClient.HttpClient>;
export type ListChangedBlocksError = AccessDeniedException | InternalServerException | RequestThrottledException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Returns information about the blocks that are different between two
 * Amazon Elastic Block Store snapshots of the same volume/snapshot lineage.
 *
 * You should always retry requests that receive server (`5xx`)
 * error responses, and `ThrottlingException` and `RequestThrottledException`
 * client error responses. For more information see Error retries in the
 * *Amazon Elastic Compute Cloud User Guide*.
 */
export declare const listChangedBlocks: API.PaginatedOperationMethod<ListChangedBlocksRequest, ListChangedBlocksResponse, ListChangedBlocksError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSnapshotBlocksError = AccessDeniedException | InternalServerException | RequestThrottledException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Returns information about the blocks in an Amazon Elastic Block Store snapshot.
 *
 * You should always retry requests that receive server (`5xx`)
 * error responses, and `ThrottlingException` and `RequestThrottledException`
 * client error responses. For more information see Error retries in the
 * *Amazon Elastic Compute Cloud User Guide*.
 */
export declare const listSnapshotBlocks: API.PaginatedOperationMethod<ListSnapshotBlocksRequest, ListSnapshotBlocksResponse, ListSnapshotBlocksError, Credentials | HttpClient.HttpClient, unknown>;
export type PutSnapshotBlockError = AccessDeniedException | InternalServerException | RequestThrottledException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | InvalidSignatureException | CommonErrors;
/**
 * Writes a block of data to a snapshot. If the specified block contains
 * data, the existing data is overwritten. The target snapshot must be in the
 * `pending` state.
 *
 * Data written to a snapshot must be aligned with 512-KiB sectors.
 *
 * You should always retry requests that receive server (`5xx`)
 * error responses, and `ThrottlingException` and `RequestThrottledException`
 * client error responses. For more information see Error retries in the
 * *Amazon Elastic Compute Cloud User Guide*.
 */
export declare const putSnapshotBlock: API.OperationMethod<PutSnapshotBlockRequest, PutSnapshotBlockResponse, PutSnapshotBlockError, Credentials | HttpClient.HttpClient>;
export type StartSnapshotError = AccessDeniedException | ConcurrentLimitExceededException | ConflictException | InternalServerException | RequestThrottledException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a new Amazon EBS snapshot. The new snapshot enters the `pending` state
 * after the request completes.
 *
 * After creating the snapshot, use PutSnapshotBlock to
 * write blocks of data to the snapshot.
 *
 * You should always retry requests that receive server (`5xx`)
 * error responses, and `ThrottlingException` and `RequestThrottledException`
 * client error responses. For more information see Error retries in the
 * *Amazon Elastic Compute Cloud User Guide*.
 */
export declare const startSnapshot: API.OperationMethod<StartSnapshotRequest, StartSnapshotResponse, StartSnapshotError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ebs.d.ts.map