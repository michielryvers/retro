import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type InvocationArn = string;
export interface GetDataAutomationStatusRequest {
    invocationArn: string;
}
export type AutomationJobStatus = "Created" | "InProgress" | "Success" | "ServiceError" | "ClientError" | (string & {});
export type S3Uri = string;
export interface OutputConfiguration {
    s3Uri: string;
}
export interface GetDataAutomationStatusResponse {
    status?: AutomationJobStatus;
    errorType?: string;
    errorMessage?: string;
    outputConfiguration?: OutputConfiguration;
    jobSubmissionTime?: Date;
    jobCompletionTime?: Date;
    jobDurationInSeconds?: number;
}
export interface SyncInputConfiguration {
    bytes?: Uint8Array;
    s3Uri?: string;
}
export type DataAutomationArn = string;
export type DataAutomationStage = "LIVE" | "DEVELOPMENT" | (string & {});
export interface DataAutomationConfiguration {
    dataAutomationProjectArn: string;
    stage?: DataAutomationStage;
}
export type BlueprintArn = string;
export type BlueprintVersion = string;
export type BlueprintStage = "DEVELOPMENT" | "LIVE" | (string & {});
export interface Blueprint {
    blueprintArn: string;
    version?: string;
    stage?: BlueprintStage;
}
export type BlueprintList = Blueprint[];
export type DataAutomationProfileArn = string;
export type KMSKeyId = string;
export type EncryptionContextKey = string;
export type EncryptionContextValue = string;
export type EncryptionContextMap = {
    [key: string]: string | undefined;
};
export interface EncryptionConfiguration {
    kmsKeyId: string;
    kmsEncryptionContext?: {
        [key: string]: string | undefined;
    };
}
export interface InvokeDataAutomationRequest {
    inputConfiguration: SyncInputConfiguration;
    dataAutomationConfiguration?: DataAutomationConfiguration;
    blueprints?: Blueprint[];
    dataAutomationProfileArn: string;
    encryptionConfiguration?: EncryptionConfiguration;
    outputConfiguration?: OutputConfiguration;
}
export type SemanticModality = "DOCUMENT" | "IMAGE" | "AUDIO" | "VIDEO" | (string & {});
export type CustomOutputStatus = "MATCH" | "NO_MATCH" | (string & {});
export interface OutputSegment {
    customOutputStatus?: CustomOutputStatus;
    customOutput?: string;
    standardOutput?: string;
}
export type OutputSegmentList = OutputSegment[];
export interface InvokeDataAutomationResponse {
    outputConfiguration?: OutputConfiguration;
    semanticModality: SemanticModality;
    outputSegments?: OutputSegment[];
}
export type IdempotencyToken = string;
export interface TimestampSegment {
    startTimeMillis: number;
    endTimeMillis: number;
}
export type VideoSegmentConfiguration = {
    timestampSegment: TimestampSegment;
};
export interface VideoAssetProcessingConfiguration {
    segmentConfiguration?: VideoSegmentConfiguration;
}
export interface AssetProcessingConfiguration {
    video?: VideoAssetProcessingConfiguration;
}
export interface InputConfiguration {
    s3Uri: string;
    assetProcessingConfiguration?: AssetProcessingConfiguration;
}
export interface EventBridgeConfiguration {
    eventBridgeEnabled: boolean;
}
export interface NotificationConfiguration {
    eventBridgeConfiguration: EventBridgeConfiguration;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagList = Tag[];
export interface InvokeDataAutomationAsyncRequest {
    clientToken?: string;
    inputConfiguration: InputConfiguration;
    outputConfiguration: OutputConfiguration;
    dataAutomationConfiguration?: DataAutomationConfiguration;
    encryptionConfiguration?: EncryptionConfiguration;
    notificationConfiguration?: NotificationConfiguration;
    blueprints?: Blueprint[];
    dataAutomationProfileArn: string;
    tags?: Tag[];
}
export interface InvokeDataAutomationAsyncResponse {
    invocationArn: string;
}
export type TaggableResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceARN: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[];
}
export interface TagResourceRequest {
    resourceARN: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceARN: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export type NonBlankString = string;
export type GetDataAutomationStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * API used to get data automation status.
 */
export declare const getDataAutomationStatus: API.OperationMethod<GetDataAutomationStatusRequest, GetDataAutomationStatusResponse, GetDataAutomationStatusError, Credentials | HttpClient.HttpClient>;
export type InvokeDataAutomationError = AccessDeniedException | InternalServerException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sync API: Invoke data automation.
 */
export declare const invokeDataAutomation: API.OperationMethod<InvokeDataAutomationRequest, InvokeDataAutomationResponse, InvokeDataAutomationError, Credentials | HttpClient.HttpClient>;
export type InvokeDataAutomationAsyncError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Async API: Invoke data automation.
 */
export declare const invokeDataAutomationAsync: API.OperationMethod<InvokeDataAutomationAsyncRequest, InvokeDataAutomationAsyncResponse, InvokeDataAutomationAsyncError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List tags for an Amazon Bedrock Data Automation resource
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Tag an Amazon Bedrock Data Automation resource
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Untag an Amazon Bedrock Data Automation resource
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bedrock-data-automation-runtime.d.ts.map