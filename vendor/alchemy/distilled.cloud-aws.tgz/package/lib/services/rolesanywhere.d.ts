import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ResourceName = string;
export type RoleArn = string;
export type RoleArnList = string[];
export type ManagedPolicyList = string[];
export type TagKey = string | redacted.Redacted<string>;
export type TagValue = string | redacted.Redacted<string>;
export interface Tag {
    key: string | redacted.Redacted<string>;
    value: string | redacted.Redacted<string>;
}
export type TagList = Tag[];
export interface CreateProfileRequest {
    name: string;
    requireInstanceProperties?: boolean;
    sessionPolicy?: string;
    roleArns: string[];
    managedPolicyArns?: string[];
    durationSeconds?: number;
    enabled?: boolean;
    tags?: Tag[];
    acceptRoleSessionName?: boolean;
}
export type Uuid = string;
export type ProfileArn = string;
export type CertificateField = string;
export interface MappingRule {
    specifier: string;
}
export type MappingRules = MappingRule[];
export interface AttributeMapping {
    certificateField?: string;
    mappingRules?: MappingRule[];
}
export type AttributeMappings = AttributeMapping[];
export interface ProfileDetail {
    profileId?: string;
    profileArn?: string;
    name?: string;
    requireInstanceProperties?: boolean;
    enabled?: boolean;
    createdBy?: string;
    sessionPolicy?: string;
    roleArns?: string[];
    managedPolicyArns?: string[];
    createdAt?: Date;
    updatedAt?: Date;
    durationSeconds?: number;
    acceptRoleSessionName?: boolean;
    attributeMappings?: AttributeMapping[];
}
export interface ProfileDetailResponse {
    profile?: ProfileDetail;
}
export type TrustAnchorType = string;
export type SourceData = {
    x509CertificateData: string;
    acmPcaArn?: never;
} | {
    x509CertificateData?: never;
    acmPcaArn: string;
};
export interface Source {
    sourceType?: string;
    sourceData?: SourceData;
}
export type NotificationEvent = string;
export type NotificationChannel = string;
export interface NotificationSetting {
    enabled: boolean;
    event: string;
    threshold?: number;
    channel?: string;
}
export type NotificationSettings = NotificationSetting[];
export interface CreateTrustAnchorRequest {
    name: string;
    source: Source;
    enabled?: boolean;
    tags?: Tag[];
    notificationSettings?: NotificationSetting[];
}
export interface NotificationSettingDetail {
    enabled: boolean;
    event: string;
    threshold?: number;
    channel?: string;
    configuredBy?: string;
}
export type NotificationSettingDetails = NotificationSettingDetail[];
export interface TrustAnchorDetail {
    trustAnchorId?: string;
    trustAnchorArn?: string;
    name?: string;
    source?: Source;
    enabled?: boolean;
    createdAt?: Date;
    updatedAt?: Date;
    notificationSettings?: NotificationSettingDetail[];
}
export interface TrustAnchorDetailResponse {
    trustAnchor: TrustAnchorDetail;
}
export type SpecifierList = string[];
export interface DeleteAttributeMappingRequest {
    profileId: string;
    certificateField: string;
    specifiers?: string[];
}
export interface DeleteAttributeMappingResponse {
    profile: ProfileDetail;
}
export interface ScalarCrlRequest {
    crlId: string;
}
export interface CrlDetail {
    crlId?: string;
    crlArn?: string;
    name?: string;
    enabled?: boolean;
    crlData?: Uint8Array;
    trustAnchorArn?: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export interface CrlDetailResponse {
    crl: CrlDetail;
}
export interface ScalarProfileRequest {
    profileId: string;
}
export interface ScalarTrustAnchorRequest {
    trustAnchorId: string;
}
export interface ScalarSubjectRequest {
    subjectId: string;
}
export interface CredentialSummary {
    seenAt?: Date;
    serialNumber?: string;
    issuer?: string;
    enabled?: boolean;
    x509CertificateData?: string;
    failed?: boolean;
}
export type CredentialSummaries = CredentialSummary[];
export type InstancePropertyMap = {
    [key: string]: string | undefined;
};
export interface InstanceProperty {
    seenAt?: Date;
    properties?: {
        [key: string]: string | undefined;
    };
    failed?: boolean;
}
export type InstanceProperties = InstanceProperty[];
export interface SubjectDetail {
    subjectArn?: string;
    subjectId?: string;
    enabled?: boolean;
    x509Subject?: string;
    lastSeenAt?: Date;
    createdAt?: Date;
    updatedAt?: Date;
    credentials?: CredentialSummary[];
    instanceProperties?: InstanceProperty[];
}
export interface SubjectDetailResponse {
    subject?: SubjectDetail;
}
export type TrustAnchorArn = string;
export interface ImportCrlRequest {
    name: string;
    crlData: Uint8Array;
    enabled?: boolean;
    tags?: Tag[];
    trustAnchorArn: string;
}
export interface ListRequest {
    nextToken?: string;
    pageSize?: number;
}
export type CrlDetails = CrlDetail[];
export interface ListCrlsResponse {
    nextToken?: string;
    crls?: CrlDetail[];
}
export type ProfileDetails = ProfileDetail[];
export interface ListProfilesResponse {
    nextToken?: string;
    profiles?: ProfileDetail[];
}
export interface SubjectSummary {
    subjectArn?: string;
    subjectId?: string;
    enabled?: boolean;
    x509Subject?: string;
    lastSeenAt?: Date;
    createdAt?: Date;
    updatedAt?: Date;
}
export type SubjectSummaries = SubjectSummary[];
export interface ListSubjectsResponse {
    subjects?: SubjectSummary[];
    nextToken?: string;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[];
}
export type TrustAnchorDetails = TrustAnchorDetail[];
export interface ListTrustAnchorsResponse {
    nextToken?: string;
    trustAnchors?: TrustAnchorDetail[];
}
export interface PutAttributeMappingRequest {
    profileId: string;
    certificateField: string;
    mappingRules: MappingRule[];
}
export interface PutAttributeMappingResponse {
    profile: ProfileDetail;
}
export interface PutNotificationSettingsRequest {
    trustAnchorId: string;
    notificationSettings: NotificationSetting[];
}
export interface PutNotificationSettingsResponse {
    trustAnchor: TrustAnchorDetail;
}
export interface NotificationSettingKey {
    event: string;
    channel?: string;
}
export type NotificationSettingKeys = NotificationSettingKey[];
export interface ResetNotificationSettingsRequest {
    trustAnchorId: string;
    notificationSettingKeys: NotificationSettingKey[];
}
export interface ResetNotificationSettingsResponse {
    trustAnchor: TrustAnchorDetail;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = (string | redacted.Redacted<string>)[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: (string | redacted.Redacted<string>)[];
}
export interface UntagResourceResponse {
}
export interface UpdateCrlRequest {
    crlId: string;
    name?: string;
    crlData?: Uint8Array;
}
export interface UpdateProfileRequest {
    profileId: string;
    name?: string;
    sessionPolicy?: string;
    roleArns?: string[];
    managedPolicyArns?: string[];
    durationSeconds?: number;
    acceptRoleSessionName?: boolean;
}
export interface UpdateTrustAnchorRequest {
    trustAnchorId: string;
    name?: string;
    source?: Source;
}
export type CreateProfileError = AccessDeniedException | ValidationException | CommonErrors;
/**
 * Creates a *profile*, a list of the roles that Roles Anywhere service is trusted to assume. You use profiles to intersect permissions with IAM managed policies.
 *
 * **Required permissions: ** `rolesanywhere:CreateProfile`.
 */
export declare const createProfile: API.OperationMethod<CreateProfileRequest, ProfileDetailResponse, CreateProfileError, Credentials | HttpClient.HttpClient>;
export type CreateTrustAnchorError = AccessDeniedException | ValidationException | CommonErrors;
/**
 * Creates a trust anchor to establish trust between IAM Roles Anywhere and your certificate authority (CA). You can define a trust anchor as a reference to an Private Certificate Authority (Private CA) or by uploading a CA certificate. Your Amazon Web Services workloads can authenticate with the trust anchor using certificates issued by the CA in exchange for temporary Amazon Web Services credentials.
 *
 * **Required permissions: ** `rolesanywhere:CreateTrustAnchor`.
 */
export declare const createTrustAnchor: API.OperationMethod<CreateTrustAnchorRequest, TrustAnchorDetailResponse, CreateTrustAnchorError, Credentials | HttpClient.HttpClient>;
export type DeleteAttributeMappingError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Delete an entry from the attribute mapping rules enforced by a given profile.
 */
export declare const deleteAttributeMapping: API.OperationMethod<DeleteAttributeMappingRequest, DeleteAttributeMappingResponse, DeleteAttributeMappingError, Credentials | HttpClient.HttpClient>;
export type DeleteCrlError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a certificate revocation list (CRL).
 *
 * **Required permissions: ** `rolesanywhere:DeleteCrl`.
 */
export declare const deleteCrl: API.OperationMethod<ScalarCrlRequest, CrlDetailResponse, DeleteCrlError, Credentials | HttpClient.HttpClient>;
export type DeleteProfileError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a profile.
 *
 * **Required permissions: ** `rolesanywhere:DeleteProfile`.
 */
export declare const deleteProfile: API.OperationMethod<ScalarProfileRequest, ProfileDetailResponse, DeleteProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteTrustAnchorError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a trust anchor.
 *
 * **Required permissions: ** `rolesanywhere:DeleteTrustAnchor`.
 */
export declare const deleteTrustAnchor: API.OperationMethod<ScalarTrustAnchorRequest, TrustAnchorDetailResponse, DeleteTrustAnchorError, Credentials | HttpClient.HttpClient>;
export interface DisableCrlRequest extends ScalarCrlRequest {
}
export type DisableCrlError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Disables a certificate revocation list (CRL).
 *
 * **Required permissions: ** `rolesanywhere:DisableCrl`.
 */
export declare const disableCrl: API.OperationMethod<DisableCrlRequest, CrlDetailResponse, DisableCrlError, Credentials | HttpClient.HttpClient>;
export interface DisableProfileRequest extends ScalarProfileRequest {
}
export type DisableProfileError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Disables a profile. When disabled, temporary credential requests with this profile fail.
 *
 * **Required permissions: ** `rolesanywhere:DisableProfile`.
 */
export declare const disableProfile: API.OperationMethod<DisableProfileRequest, ProfileDetailResponse, DisableProfileError, Credentials | HttpClient.HttpClient>;
export interface DisableTrustAnchorRequest extends ScalarTrustAnchorRequest {
}
export type DisableTrustAnchorError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Disables a trust anchor. When disabled, temporary credential requests specifying this trust anchor are unauthorized.
 *
 * **Required permissions: ** `rolesanywhere:DisableTrustAnchor`.
 */
export declare const disableTrustAnchor: API.OperationMethod<DisableTrustAnchorRequest, TrustAnchorDetailResponse, DisableTrustAnchorError, Credentials | HttpClient.HttpClient>;
export interface EnableCrlRequest extends ScalarCrlRequest {
}
export type EnableCrlError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Enables a certificate revocation list (CRL). When enabled, certificates stored in the CRL are unauthorized to receive session credentials.
 *
 * **Required permissions: ** `rolesanywhere:EnableCrl`.
 */
export declare const enableCrl: API.OperationMethod<EnableCrlRequest, CrlDetailResponse, EnableCrlError, Credentials | HttpClient.HttpClient>;
export interface EnableProfileRequest extends ScalarProfileRequest {
}
export type EnableProfileError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Enables temporary credential requests for a profile.
 *
 * **Required permissions: ** `rolesanywhere:EnableProfile`.
 */
export declare const enableProfile: API.OperationMethod<EnableProfileRequest, ProfileDetailResponse, EnableProfileError, Credentials | HttpClient.HttpClient>;
export interface EnableTrustAnchorRequest extends ScalarTrustAnchorRequest {
}
export type EnableTrustAnchorError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Enables a trust anchor. When enabled, certificates in the trust anchor chain are authorized for trust validation.
 *
 * **Required permissions: ** `rolesanywhere:EnableTrustAnchor`.
 */
export declare const enableTrustAnchor: API.OperationMethod<EnableTrustAnchorRequest, TrustAnchorDetailResponse, EnableTrustAnchorError, Credentials | HttpClient.HttpClient>;
export interface GetCrlRequest extends ScalarCrlRequest {
}
export type GetCrlError = ResourceNotFoundException | CommonErrors;
/**
 * Gets a certificate revocation list (CRL).
 *
 * **Required permissions: ** `rolesanywhere:GetCrl`.
 */
export declare const getCrl: API.OperationMethod<GetCrlRequest, CrlDetailResponse, GetCrlError, Credentials | HttpClient.HttpClient>;
export interface GetProfileRequest extends ScalarProfileRequest {
}
export type GetProfileError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Gets a profile.
 *
 * **Required permissions: ** `rolesanywhere:GetProfile`.
 */
export declare const getProfile: API.OperationMethod<GetProfileRequest, ProfileDetailResponse, GetProfileError, Credentials | HttpClient.HttpClient>;
export type GetSubjectError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Gets a *subject*, which associates a certificate identity with authentication attempts. The subject stores auditing information such as the status of the last authentication attempt, the certificate data used in the attempt, and the last time the associated identity attempted authentication.
 *
 * **Required permissions: ** `rolesanywhere:GetSubject`.
 */
export declare const getSubject: API.OperationMethod<ScalarSubjectRequest, SubjectDetailResponse, GetSubjectError, Credentials | HttpClient.HttpClient>;
export interface GetTrustAnchorRequest extends ScalarTrustAnchorRequest {
}
export type GetTrustAnchorError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets a trust anchor.
 *
 * **Required permissions: ** `rolesanywhere:GetTrustAnchor`.
 */
export declare const getTrustAnchor: API.OperationMethod<GetTrustAnchorRequest, TrustAnchorDetailResponse, GetTrustAnchorError, Credentials | HttpClient.HttpClient>;
export type ImportCrlError = AccessDeniedException | ValidationException | CommonErrors;
/**
 * Imports the certificate revocation list (CRL). A CRL is a list of certificates that have been revoked by the issuing certificate Authority (CA).In order to be properly imported, a CRL must be in PEM format. IAM Roles Anywhere validates against the CRL before issuing credentials.
 *
 * **Required permissions: ** `rolesanywhere:ImportCrl`.
 */
export declare const importCrl: API.OperationMethod<ImportCrlRequest, CrlDetailResponse, ImportCrlError, Credentials | HttpClient.HttpClient>;
export type ListCrlsError = AccessDeniedException | ValidationException | CommonErrors;
/**
 * Lists all certificate revocation lists (CRL) in the authenticated account and Amazon Web Services Region.
 *
 * **Required permissions: ** `rolesanywhere:ListCrls`.
 */
export declare const listCrls: API.PaginatedOperationMethod<ListRequest, ListCrlsResponse, ListCrlsError, Credentials | HttpClient.HttpClient, CrlDetail>;
export interface ListProfilesRequest extends ListRequest {
}
export type ListProfilesError = AccessDeniedException | ValidationException | CommonErrors;
/**
 * Lists all profiles in the authenticated account and Amazon Web Services Region.
 *
 * **Required permissions: ** `rolesanywhere:ListProfiles`.
 */
export declare const listProfiles: API.PaginatedOperationMethod<ListProfilesRequest, ListProfilesResponse, ListProfilesError, Credentials | HttpClient.HttpClient, ProfileDetail>;
export interface ListSubjectsRequest extends ListRequest {
}
export type ListSubjectsError = AccessDeniedException | ValidationException | CommonErrors;
/**
 * Lists the subjects in the authenticated account and Amazon Web Services Region.
 *
 * **Required permissions: ** `rolesanywhere:ListSubjects`.
 */
export declare const listSubjects: API.PaginatedOperationMethod<ListSubjectsRequest, ListSubjectsResponse, ListSubjectsError, Credentials | HttpClient.HttpClient, SubjectSummary>;
export type ListTagsForResourceError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tags attached to the resource.
 *
 * **Required permissions: ** `rolesanywhere:ListTagsForResource`.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export interface ListTrustAnchorsRequest extends ListRequest {
}
export type ListTrustAnchorsError = AccessDeniedException | ValidationException | CommonErrors;
/**
 * Lists the trust anchors in the authenticated account and Amazon Web Services Region.
 *
 * **Required permissions: ** `rolesanywhere:ListTrustAnchors`.
 */
export declare const listTrustAnchors: API.PaginatedOperationMethod<ListTrustAnchorsRequest, ListTrustAnchorsResponse, ListTrustAnchorsError, Credentials | HttpClient.HttpClient, TrustAnchorDetail>;
export type PutAttributeMappingError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Put an entry in the attribute mapping rules that will be enforced by a given profile. A mapping specifies a certificate field and one or more specifiers that have contextual meanings.
 */
export declare const putAttributeMapping: API.OperationMethod<PutAttributeMappingRequest, PutAttributeMappingResponse, PutAttributeMappingError, Credentials | HttpClient.HttpClient>;
export type PutNotificationSettingsError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Attaches a list of *notification settings* to a trust anchor.
 *
 * A notification setting includes information such as event name, threshold, status of the notification setting, and the channel to notify.
 *
 * **Required permissions: ** `rolesanywhere:PutNotificationSettings`.
 */
export declare const putNotificationSettings: API.OperationMethod<PutNotificationSettingsRequest, PutNotificationSettingsResponse, PutNotificationSettingsError, Credentials | HttpClient.HttpClient>;
export type ResetNotificationSettingsError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Resets the *custom notification setting* to IAM Roles Anywhere default setting.
 *
 * **Required permissions: ** `rolesanywhere:ResetNotificationSettings`.
 */
export declare const resetNotificationSettings: API.OperationMethod<ResetNotificationSettingsRequest, ResetNotificationSettingsResponse, ResetNotificationSettingsError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ResourceNotFoundException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Attaches tags to a resource.
 *
 * **Required permissions: ** `rolesanywhere:TagResource`.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes tags from the resource.
 *
 * **Required permissions: ** `rolesanywhere:UntagResource`.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCrlError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the certificate revocation list (CRL). A CRL is a list of certificates that have been revoked by the issuing certificate authority (CA). IAM Roles Anywhere validates against the CRL before issuing credentials.
 *
 * **Required permissions: ** `rolesanywhere:UpdateCrl`.
 */
export declare const updateCrl: API.OperationMethod<UpdateCrlRequest, CrlDetailResponse, UpdateCrlError, Credentials | HttpClient.HttpClient>;
export type UpdateProfileError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a *profile*, a list of the roles that IAM Roles Anywhere service is trusted to assume. You use profiles to intersect permissions with IAM managed policies.
 *
 * **Required permissions: ** `rolesanywhere:UpdateProfile`.
 */
export declare const updateProfile: API.OperationMethod<UpdateProfileRequest, ProfileDetailResponse, UpdateProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateTrustAnchorError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a trust anchor. You establish trust between IAM Roles Anywhere and your certificate authority (CA) by configuring a trust anchor. You can define a trust anchor as a reference to an Private Certificate Authority (Private CA) or by uploading a CA certificate. Your Amazon Web Services workloads can authenticate with the trust anchor using certificates issued by the CA in exchange for temporary Amazon Web Services credentials.
 *
 * **Required permissions: ** `rolesanywhere:UpdateTrustAnchor`.
 */
export declare const updateTrustAnchor: API.OperationMethod<UpdateTrustAnchorRequest, TrustAnchorDetailResponse, UpdateTrustAnchorError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=rolesanywhere.d.ts.map