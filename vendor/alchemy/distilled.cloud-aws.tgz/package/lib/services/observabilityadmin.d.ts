import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly amznErrorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly amznErrorType: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidStateException_base: S.TaggedErrorClass<"InvalidStateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidStateException extends /*@__PURE__*/ InvalidStateException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
    readonly ServiceCode: any;
    readonly QuotaCode: any;
    readonly amznErrorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Errors: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type RuleName = string;
export type Region = string;
export type Regions = string[];
export type SourceFilterString = string;
export type LogsFilterString = string;
export type DataSourceFilterString = string;
export type EncryptedLogGroupStrategy = "ALLOW" | "SKIP" | (string & {});
export interface SourceLogsConfiguration {
    LogGroupSelectionCriteria?: string;
    DataSourceSelectionCriteria?: string;
    EncryptedLogGroupStrategy: EncryptedLogGroupStrategy;
}
export type MetricsFilterString = string;
export interface SourceMetricsConfiguration {
    MetricsSelectionCriteria?: string;
}
export interface SourceContextGraphConfiguration {
}
export interface CentralizationRuleSource {
    Regions: string[];
    Scope?: string;
    SourceLogsConfiguration?: SourceLogsConfiguration;
    SourceMetricsConfiguration?: SourceMetricsConfiguration;
    SourceContextGraphConfiguration?: SourceContextGraphConfiguration;
}
export type AccountIdentifier = string;
export type EncryptionStrategy = "CUSTOMER_MANAGED" | "AWS_OWNED" | (string & {});
export type ResourceArn = string;
export type EncryptionConflictResolutionStrategy = "ALLOW" | "SKIP" | (string & {});
export type EncryptionScope = "ENCRYPTED_SOURCE_ONLY" | "NEW_DESTINATION_LOG_GROUPS" | (string & {});
export interface LogsEncryptionConfiguration {
    EncryptionStrategy: EncryptionStrategy;
    KmsKeyArn?: string;
    EncryptionConflictResolutionStrategy?: EncryptionConflictResolutionStrategy;
    EncryptionScope?: EncryptionScope;
}
export interface LogsBackupConfiguration {
    Region: string;
    KmsKeyArn?: string;
}
export type LogGroupNamePattern = string;
export interface LogGroupNameConfiguration {
    LogGroupNamePattern: string;
}
export type IamRoleArn = string;
export type TagConflictResolutionStrategy = "IN_SYNC" | "ADD_ONLY" | "UPDATE_SYNC" | (string & {});
export interface TagPropagationConfiguration {
    DestinationRoleArn: string;
    TagConflictResolutionStrategy?: TagConflictResolutionStrategy;
}
export interface DestinationLogsConfiguration {
    LogsEncryptionConfiguration?: LogsEncryptionConfiguration;
    BackupConfiguration?: LogsBackupConfiguration;
    LogGroupNameConfiguration?: LogGroupNameConfiguration;
    TagPropagationConfiguration?: TagPropagationConfiguration;
}
export interface MetricsBackupConfiguration {
    Region: string;
}
export interface DestinationMetricsConfiguration {
    BackupConfiguration?: MetricsBackupConfiguration;
}
export interface CentralizationRuleDestination {
    Region: string;
    Account?: string;
    DestinationLogsConfiguration?: DestinationLogsConfiguration;
    DestinationMetricsConfiguration?: DestinationMetricsConfiguration;
}
export interface CentralizationRule {
    Source: CentralizationRuleSource;
    Destination: CentralizationRuleDestination;
}
export type TagKey = string;
export type TagValue = string;
export type TagMapInput = {
    [key: string]: string | undefined;
};
export interface CreateCentralizationRuleForOrganizationInput {
    RuleName: string;
    Rule: CentralizationRule;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateCentralizationRuleForOrganizationOutput {
    RuleArn?: string;
}
export interface CreateDatasetIntegrationInput {
    RoleArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateDatasetIntegrationOutput {
    Arn: string;
    RoleArn: string;
    CreatedAt: Date;
    UpdatedAt: Date;
}
export type SSEAlgorithm = "aws:kms" | "AES256" | (string & {});
export interface Encryption {
    SseAlgorithm: SSEAlgorithm;
    KmsKeyArn?: string;
}
export interface CreateS3TableIntegrationInput {
    Encryption: Encryption;
    RoleArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateS3TableIntegrationOutput {
    Arn?: string;
}
export type TelemetryPipelineName = string;
export type TelemetryPipelineConfigurationBody = string;
export interface TelemetryPipelineConfiguration {
    Body: string;
}
export interface CreateTelemetryPipelineInput {
    Name: string;
    Configuration: TelemetryPipelineConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateTelemetryPipelineOutput {
    Arn?: string;
}
export type ResourceType = "AWS::EC2::Instance" | "AWS::EC2::VPC" | "AWS::Lambda::Function" | "AWS::CloudTrail" | "AWS::EKS::Cluster" | "AWS::WAFv2::WebACL" | "AWS::ElasticLoadBalancingV2::LoadBalancer" | "AWS::Route53Resolver::ResolverEndpoint" | "AWS::BedrockAgentCore::Runtime" | "AWS::BedrockAgentCore::Browser" | "AWS::BedrockAgentCore::CodeInterpreter" | "AWS::BedrockAgentCore::Gateway" | "AWS::BedrockAgentCore::Memory" | "AWS::BedrockAgentCore::WorkloadIdentity" | "AWS::BedrockAgentCore::PaymentManager" | "AWS::SecurityHub::Hub" | "AWS::CloudFront::Distribution" | "AWS::SecurityHub::HubV2" | "AWS::CloudWatch::OTelEnrichment" | "AWS::MSK::Cluster" | "AWS::S3::Bucket" | "AWS::Bedrock::KnowledgeBase" | (string & {});
export type TelemetryType = "Logs" | "Metrics" | "Traces" | (string & {});
export type TelemetrySourceType = "VPC_FLOW_LOGS" | "ROUTE53_RESOLVER_QUERY_LOGS" | "EKS_AUDIT_LOGS" | "EKS_AUTHENTICATOR_LOGS" | "EKS_CONTROLLER_MANAGER_LOGS" | "EKS_SCHEDULER_LOGS" | "EKS_API_LOGS" | (string & {});
export type TelemetrySourceTypes = TelemetrySourceType[];
export type DestinationType = "cloud-watch-logs" | (string & {});
export type RetentionPeriodInDays = number;
export interface VPCFlowLogParameters {
    LogFormat?: string;
    TrafficType?: string;
    MaxAggregationInterval?: number;
}
export type StringList = string[];
export interface AdvancedFieldSelector {
    Field: string;
    Equals?: string[];
    StartsWith?: string[];
    EndsWith?: string[];
    NotEquals?: string[];
    NotStartsWith?: string[];
    NotEndsWith?: string[];
}
export type FieldSelectors = AdvancedFieldSelector[];
export interface AdvancedEventSelector {
    Name?: string;
    FieldSelectors: AdvancedFieldSelector[];
}
export type AdvancedEventSelectors = AdvancedEventSelector[];
export interface CloudtrailParameters {
    AdvancedEventSelectors: AdvancedEventSelector[];
}
export type OutputFormat = "plain" | "json" | (string & {});
export interface ELBLoadBalancerLoggingParameters {
    OutputFormat?: OutputFormat;
    FieldDelimiter?: string;
}
export interface SingleHeader {
    Name?: string;
}
export interface FieldToMatch {
    SingleHeader?: SingleHeader;
    UriPath?: string;
    QueryString?: string;
    Method?: string;
}
export type RedactedFields = FieldToMatch[];
export type FilterBehavior = "KEEP" | "DROP" | (string & {});
export type FilterRequirement = "MEETS_ALL" | "MEETS_ANY" | (string & {});
export type Action = "ALLOW" | "BLOCK" | "COUNT" | "CAPTCHA" | "CHALLENGE" | "EXCLUDED_AS_COUNT" | (string & {});
export interface ActionCondition {
    Action?: Action;
}
export interface LabelNameCondition {
    LabelName?: string;
}
export interface Condition {
    ActionCondition?: ActionCondition;
    LabelNameCondition?: LabelNameCondition;
}
export type Conditions = Condition[];
export interface Filter {
    Behavior?: FilterBehavior;
    Requirement?: FilterRequirement;
    Conditions?: Condition[];
}
export type Filters = Filter[];
export interface LoggingFilter {
    Filters?: Filter[];
    DefaultBehavior?: FilterBehavior;
}
export type WAFLogType = "WAF_LOGS" | (string & {});
export interface WAFLoggingParameters {
    RedactedFields?: FieldToMatch[];
    LoggingFilter?: LoggingFilter;
    LogType?: WAFLogType;
}
export type LogType = "APPLICATION_LOGS" | "USAGE_LOGS" | "SECURITY_FINDING_LOGS" | "ACCESS_LOGS" | "CONNECTION_LOGS" | "S3_SERVER_ACCESS_LOGS" | "ALB_ACCESS_LOGS" | "ALB_CONNECTION_LOGS" | "ALB_HEALTH_CHECK_LOGS" | (string & {});
export type LogTypes = LogType[];
export interface LogDeliveryParameters {
    LogTypes?: LogType[];
}
export type MskEnhancedMonitoringLevel = "DEFAULT" | "PER_BROKER" | "PER_TOPIC_PER_BROKER" | "PER_TOPIC_PER_PARTITION" | (string & {});
export interface MskMonitoringParameters {
    EnhancedMonitoring?: MskEnhancedMonitoringLevel;
}
export type KmsKeyArn = string;
export interface TelemetryDestinationConfiguration {
    DestinationType?: DestinationType;
    DestinationPattern?: string;
    RetentionInDays?: number;
    VPCFlowLogParameters?: VPCFlowLogParameters;
    CloudtrailParameters?: CloudtrailParameters;
    ELBLoadBalancerLoggingParameters?: ELBLoadBalancerLoggingParameters;
    WAFLoggingParameters?: WAFLoggingParameters;
    LogDeliveryParameters?: LogDeliveryParameters;
    MskMonitoringParameters?: MskMonitoringParameters;
    KmsKeyArn?: string;
}
export type AllRegions = boolean;
export interface TelemetryRule {
    ResourceType?: ResourceType;
    TelemetryType: TelemetryType;
    TelemetrySourceTypes?: TelemetrySourceType[];
    DestinationConfiguration?: TelemetryDestinationConfiguration;
    Scope?: string;
    SelectionCriteria?: string;
    AllowFieldUpdates?: boolean;
    Regions?: string[];
    AllRegions?: boolean;
}
export interface CreateTelemetryRuleInput {
    RuleName: string;
    Rule: TelemetryRule;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateTelemetryRuleOutput {
    RuleArn?: string;
}
export interface CreateTelemetryRuleForOrganizationInput {
    RuleName: string;
    Rule: TelemetryRule;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateTelemetryRuleForOrganizationOutput {
    RuleArn?: string;
}
export type RuleIdentifier = string;
export interface DeleteCentralizationRuleForOrganizationInput {
    RuleIdentifier: string;
}
export interface DeleteCentralizationRuleForOrganizationResponse {
}
export interface DeleteDatasetIntegrationInput {
    Arn: string;
}
export interface DeleteDatasetIntegrationResponse {
}
export interface DeleteS3TableIntegrationInput {
    Arn: string;
}
export interface DeleteS3TableIntegrationResponse {
}
export type TelemetryPipelineIdentifier = string;
export interface DeleteTelemetryPipelineInput {
    PipelineIdentifier: string;
}
export interface DeleteTelemetryPipelineOutput {
}
export interface DeleteTelemetryRuleInput {
    RuleIdentifier: string;
}
export interface DeleteTelemetryRuleResponse {
}
export interface DeleteTelemetryRuleForOrganizationInput {
    RuleIdentifier: string;
}
export interface DeleteTelemetryRuleForOrganizationResponse {
}
export interface GetCentralizationRuleForOrganizationInput {
    RuleIdentifier: string;
}
export type RuleHealth = "Healthy" | "Unhealthy" | "Provisioning" | (string & {});
export type CentralizationFailureReason = "TRUSTED_ACCESS_NOT_ENABLED" | "DESTINATION_ACCOUNT_NOT_IN_ORGANIZATION" | "INTERNAL_SERVER_ERROR" | (string & {});
export type TagPropagationStatus = "Healthy" | "Unhealthy" | (string & {});
export type TagPropagationFailureReason = "RoleNotAssumable" | "RoleLacksPermissions" | (string & {});
export type ContextGraphStatus = "Healthy" | "Unhealthy" | "Provisioning" | (string & {});
export interface GetCentralizationRuleForOrganizationOutput {
    RuleName?: string;
    RuleArn?: string;
    CreatorAccountId?: string;
    CreatedTimeStamp?: number;
    CreatedRegion?: string;
    LastUpdateTimeStamp?: number;
    RuleHealth?: RuleHealth;
    FailureReason?: CentralizationFailureReason;
    TagPropagationStatus?: TagPropagationStatus;
    TagPropagationFailureReason?: TagPropagationFailureReason;
    ContextGraphStatus?: ContextGraphStatus;
    CentralizationRule?: CentralizationRule;
}
export interface GetDatasetIntegrationInput {
    Arn: string;
}
export interface GetDatasetIntegrationOutput {
    Arn?: string;
    RoleArn?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export interface GetS3TableIntegrationInput {
    Arn: string;
}
export type IntegrationStatus = "ACTIVE" | "DELETING" | (string & {});
export interface GetS3TableIntegrationOutput {
    Arn?: string;
    RoleArn?: string;
    Status?: IntegrationStatus;
    Encryption?: Encryption;
    DestinationTableBucketArn?: string;
    CreatedTimeStamp?: number;
}
export interface GetTelemetryEnrichmentStatusRequest {
}
export type TelemetryEnrichmentStatus = "Running" | "Stopped" | "Impaired" | (string & {});
export type AwsResourceExplorerManagedViewArn = string;
export interface GetTelemetryEnrichmentStatusOutput {
    Status?: TelemetryEnrichmentStatus;
    AwsResourceExplorerManagedViewArn?: string;
}
export interface GetTelemetryEvaluationStatusRequest {
}
export type Status = "NOT_STARTED" | "STARTING" | "FAILED_START" | "RUNNING" | "STOPPING" | "FAILED_STOP" | "STOPPED" | (string & {});
export type FailureReason = string;
export interface RegionStatus {
    Region?: string;
    Status?: string;
    FailureReason?: string;
    RuleArn?: string;
}
export type RegionStatuses = RegionStatus[];
export interface GetTelemetryEvaluationStatusOutput {
    Status?: Status;
    FailureReason?: string;
    HomeRegion?: string;
    RegionStatuses?: RegionStatus[];
}
export interface GetTelemetryEvaluationStatusForOrganizationRequest {
}
export interface GetTelemetryEvaluationStatusForOrganizationOutput {
    Status?: Status;
    FailureReason?: string;
    HomeRegion?: string;
    RegionStatuses?: RegionStatus[];
}
export interface GetTelemetryPipelineInput {
    PipelineIdentifier: string;
}
export type TelemetryPipelineStatus = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "CREATE_FAILED" | "UPDATE_FAILED" | (string & {});
export interface TelemetryPipelineStatusReason {
    Description?: string;
}
export type TagMapOutput = {
    [key: string]: string | undefined;
};
export interface TelemetryPipeline {
    CreatedTimeStamp?: number;
    LastUpdateTimeStamp?: number;
    Arn?: string;
    Name?: string;
    Configuration?: TelemetryPipelineConfiguration;
    Status?: TelemetryPipelineStatus;
    StatusReason?: TelemetryPipelineStatusReason;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetTelemetryPipelineOutput {
    Pipeline?: TelemetryPipeline;
}
export interface GetTelemetryRuleInput {
    RuleIdentifier: string;
}
export type IsReplicated = boolean;
export interface GetTelemetryRuleOutput {
    RuleName?: string;
    RuleArn?: string;
    CreatedTimeStamp?: number;
    LastUpdateTimeStamp?: number;
    TelemetryRule?: TelemetryRule;
    HomeRegion?: string;
    IsReplicated?: boolean;
    RegionStatuses?: RegionStatus[];
}
export interface GetTelemetryRuleForOrganizationInput {
    RuleIdentifier: string;
}
export interface GetTelemetryRuleForOrganizationOutput {
    RuleName?: string;
    RuleArn?: string;
    CreatedTimeStamp?: number;
    LastUpdateTimeStamp?: number;
    TelemetryRule?: TelemetryRule;
    HomeRegion?: string;
    IsReplicated?: boolean;
    RegionStatuses?: RegionStatus[];
}
export type ListCentralizationRulesForOrganizationMaxResults = number;
export type NextToken = string;
export interface ListCentralizationRulesForOrganizationInput {
    RuleNamePrefix?: string;
    AllRegions?: boolean;
    MaxResults?: number;
    NextToken?: string;
}
export interface CentralizationRuleSummary {
    RuleName?: string;
    RuleArn?: string;
    CreatorAccountId?: string;
    CreatedTimeStamp?: number;
    CreatedRegion?: string;
    LastUpdateTimeStamp?: number;
    RuleHealth?: RuleHealth;
    FailureReason?: CentralizationFailureReason;
    TagPropagationStatus?: TagPropagationStatus;
    TagPropagationFailureReason?: TagPropagationFailureReason;
    ContextGraphStatus?: ContextGraphStatus;
    DestinationAccountId?: string;
    DestinationRegion?: string;
}
export type CentralizationRuleSummaries = CentralizationRuleSummary[];
export interface ListCentralizationRulesForOrganizationOutput {
    CentralizationRuleSummaries?: CentralizationRuleSummary[];
    NextToken?: string;
}
export type ListDatasetIntegrationsMaxResults = number;
export interface ListDatasetIntegrationsInput {
    MaxResults?: number;
    NextToken?: string;
}
export interface DatasetIntegrationSummary {
    Arn: string;
    RoleArn?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export type DatasetIntegrationSummaries = DatasetIntegrationSummary[];
export interface ListDatasetIntegrationsOutput {
    DatasetIntegrationSummaries: DatasetIntegrationSummary[];
    NextToken?: string;
}
export type ResourceIdentifierPrefix = string;
export type ResourceTypes = ResourceType[];
export type TelemetryState = "Enabled" | "Disabled" | "NotApplicable" | (string & {});
export type TelemetryConfigurationState = {
    [key in TelemetryType]?: TelemetryState;
};
export type ListResourceTelemetryMaxResults = number;
export interface ListResourceTelemetryInput {
    ResourceIdentifierPrefix?: string;
    ResourceTypes?: ResourceType[];
    TelemetryConfigurationState?: {
        [key: string]: TelemetryState | undefined;
    };
    ResourceTags?: {
        [key: string]: string | undefined;
    };
    MaxResults?: number;
    NextToken?: string;
}
export type ResourceIdentifier = string;
export interface TelemetryConfiguration {
    AccountIdentifier?: string;
    TelemetryConfigurationState?: {
        [key: string]: TelemetryState | undefined;
    };
    ResourceType?: ResourceType;
    ResourceIdentifier?: string;
    ResourceTags?: {
        [key: string]: string | undefined;
    };
    LastUpdateTimeStamp?: number;
    TelemetrySourceType?: TelemetrySourceType;
}
export type TelemetryConfigurations = TelemetryConfiguration[];
export interface ListResourceTelemetryOutput {
    TelemetryConfigurations?: TelemetryConfiguration[];
    NextToken?: string;
}
export type AccountIdentifiers = string[];
export type ListResourceTelemetryForOrganizationMaxResults = number;
export interface ListResourceTelemetryForOrganizationInput {
    AccountIdentifiers?: string[];
    ResourceIdentifierPrefix?: string;
    ResourceTypes?: ResourceType[];
    TelemetryConfigurationState?: {
        [key: string]: TelemetryState | undefined;
    };
    ResourceTags?: {
        [key: string]: string | undefined;
    };
    MaxResults?: number;
    NextToken?: string;
}
export interface ListResourceTelemetryForOrganizationOutput {
    TelemetryConfigurations?: TelemetryConfiguration[];
    NextToken?: string;
}
export type ListS3TableIntegrationsMaxResults = number;
export interface ListS3TableIntegrationsInput {
    MaxResults?: number;
    NextToken?: string;
}
export interface IntegrationSummary {
    Arn?: string;
    Status?: IntegrationStatus;
}
export type IntegrationSummaries = IntegrationSummary[];
export interface ListS3TableIntegrationsOutput {
    IntegrationSummaries?: IntegrationSummary[];
    NextToken?: string;
}
export interface ListTagsForResourceInput {
    ResourceARN: string;
}
export interface ListTagsForResourceOutput {
    Tags: {
        [key: string]: string | undefined;
    };
}
export type ListTelemetryPipelinesMaxResults = number;
export interface ListTelemetryPipelinesInput {
    MaxResults?: number;
    NextToken?: string;
}
export interface Source {
    Type?: string;
}
export type Sources = Source[];
export interface DataSource {
    Name?: string;
    Type?: string;
}
export type DataSources = DataSource[];
export type Processors = string[];
export type Sinks = string[];
export interface ConfigurationSummary {
    Sources?: Source[];
    DataSources?: DataSource[];
    Processors?: string[];
    ProcessorCount?: number;
    Sinks?: string[];
}
export interface TelemetryPipelineSummary {
    CreatedTimeStamp?: number;
    LastUpdateTimeStamp?: number;
    Arn?: string;
    Name?: string;
    Status?: TelemetryPipelineStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
    ConfigurationSummary?: ConfigurationSummary;
}
export type TelemetryPipelineSummaries = TelemetryPipelineSummary[];
export interface ListTelemetryPipelinesOutput {
    PipelineSummaries?: TelemetryPipelineSummary[];
    NextToken?: string;
}
export type ListTelemetryRulesMaxResults = number;
export interface ListTelemetryRulesInput {
    RuleNamePrefix?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface TelemetryRuleSummary {
    RuleName?: string;
    RuleArn?: string;
    CreatedTimeStamp?: number;
    LastUpdateTimeStamp?: number;
    ResourceType?: ResourceType;
    TelemetryType?: TelemetryType;
    TelemetrySourceTypes?: TelemetrySourceType[];
}
export type TelemetryRuleSummaries = TelemetryRuleSummary[];
export interface ListTelemetryRulesOutput {
    TelemetryRuleSummaries?: TelemetryRuleSummary[];
    NextToken?: string;
}
export type OrganizationUnitIdentifier = string;
export type OrganizationUnitIdentifiers = string[];
export type ListTelemetryRulesForOrganizationMaxResults = number;
export interface ListTelemetryRulesForOrganizationInput {
    RuleNamePrefix?: string;
    SourceAccountIds?: string[];
    SourceOrganizationUnitIds?: string[];
    MaxResults?: number;
    NextToken?: string;
}
export interface ListTelemetryRulesForOrganizationOutput {
    TelemetryRuleSummaries?: TelemetryRuleSummary[];
    NextToken?: string;
}
export interface StartTelemetryEnrichmentRequest {
}
export interface StartTelemetryEnrichmentOutput {
    Status?: TelemetryEnrichmentStatus;
    AwsResourceExplorerManagedViewArn?: string;
}
export interface StartTelemetryEvaluationInput {
    Regions?: string[];
    AllRegions?: boolean;
}
export interface StartTelemetryEvaluationResponse {
}
export interface StartTelemetryEvaluationForOrganizationInput {
    Regions?: string[];
    AllRegions?: boolean;
}
export interface StartTelemetryEvaluationForOrganizationResponse {
}
export interface StopTelemetryEnrichmentRequest {
}
export interface StopTelemetryEnrichmentOutput {
    Status?: TelemetryEnrichmentStatus;
}
export interface StopTelemetryEvaluationRequest {
}
export interface StopTelemetryEvaluationResponse {
}
export interface StopTelemetryEvaluationForOrganizationRequest {
}
export interface StopTelemetryEvaluationForOrganizationResponse {
}
export interface TagResourceInput {
    ResourceARN: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type RecordFormat = "STRING" | "JSON" | (string & {});
export interface Record {
    Data?: string;
    Type?: RecordFormat;
}
export type Records = Record[];
export type SignalType = "LOG" | "METRIC" | (string & {});
export interface TestTelemetryPipelineInput {
    Records: Record[];
    Configuration: TelemetryPipelineConfiguration;
    SignalType?: SignalType;
}
export interface PipelineOutputError {
    Message?: string;
}
export interface PipelineOutput {
    Record?: Record;
    Error?: PipelineOutputError;
}
export type PipelineOutputs = PipelineOutput[];
export interface TestTelemetryPipelineOutput {
    Results?: PipelineOutput[];
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateCentralizationRuleForOrganizationInput {
    RuleIdentifier: string;
    Rule: CentralizationRule;
}
export interface UpdateCentralizationRuleForOrganizationOutput {
    RuleArn?: string;
}
export interface UpdateDatasetIntegrationInput {
    Arn: string;
    RoleArn: string;
}
export interface UpdateDatasetIntegrationOutput {
    Arn: string;
    RoleArn: string;
    CreatedAt: Date;
    UpdatedAt: Date;
}
export interface UpdateTelemetryPipelineInput {
    PipelineIdentifier: string;
    Configuration: TelemetryPipelineConfiguration;
}
export interface UpdateTelemetryPipelineOutput {
}
export interface UpdateTelemetryRuleInput {
    RuleIdentifier: string;
    Rule: TelemetryRule;
}
export interface UpdateTelemetryRuleOutput {
    RuleArn?: string;
}
export interface UpdateTelemetryRuleForOrganizationInput {
    RuleIdentifier: string;
    Rule: TelemetryRule;
}
export interface UpdateTelemetryRuleForOrganizationOutput {
    RuleArn?: string;
}
export interface ValidateTelemetryPipelineConfigurationInput {
    Configuration: TelemetryPipelineConfiguration;
}
export type FieldMap = {
    [key: string]: string | undefined;
};
export interface ValidationError {
    Message?: string;
    Reason?: string;
    FieldMap?: {
        [key: string]: string | undefined;
    };
}
export type ValidationErrors = ValidationError[];
export interface ValidateTelemetryPipelineConfigurationOutput {
    Errors?: ValidationError[];
}
export type CreateCentralizationRuleForOrganizationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Creates a centralization rule that applies across an Amazon Web Services Organization. This operation can only be called by the organization's management account or a delegated administrator account.
 */
export declare const createCentralizationRuleForOrganization: API.OperationMethod<CreateCentralizationRuleForOrganizationInput, CreateCentralizationRuleForOrganizationOutput, CreateCentralizationRuleForOrganizationError, Credentials | HttpClient.HttpClient>;
export type CreateDatasetIntegrationError = AccessDeniedException | ConflictException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Creates a dataset integration for the caller's account in the current region and returns its ARN.
 *
 * To use this operation, you must have permission to access the dataset integration resources through the IAM role specified in the `RoleArn` parameter.
 *
 * If a dataset integration already exists for the account, this operation fails with a `ConflictException`.
 */
export declare const createDatasetIntegration: API.OperationMethod<CreateDatasetIntegrationInput, CreateDatasetIntegrationOutput, CreateDatasetIntegrationError, Credentials | HttpClient.HttpClient>;
export type CreateS3TableIntegrationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Creates an integration between CloudWatch and S3 Tables for analytics. This integration enables querying CloudWatch telemetry data using analytics engines like Amazon Athena, Amazon Redshift, and Apache Spark.
 */
export declare const createS3TableIntegration: API.OperationMethod<CreateS3TableIntegrationInput, CreateS3TableIntegrationOutput, CreateS3TableIntegrationError, Credentials | HttpClient.HttpClient>;
export type CreateTelemetryPipelineError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Creates a telemetry pipeline for processing and transforming telemetry data. The pipeline defines how data flows from sources through processors to destinations, enabling data transformation and delivering capabilities.
 */
export declare const createTelemetryPipeline: API.OperationMethod<CreateTelemetryPipelineInput, CreateTelemetryPipelineOutput, CreateTelemetryPipelineError, Credentials | HttpClient.HttpClient>;
export type CreateTelemetryRuleError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Creates a telemetry rule that defines how telemetry should be configured for Amazon Web Services resources in your account. The rule specifies which resources should have telemetry enabled and how that telemetry data should be collected based on resource type, telemetry type, and selection criteria.
 */
export declare const createTelemetryRule: API.OperationMethod<CreateTelemetryRuleInput, CreateTelemetryRuleOutput, CreateTelemetryRuleError, Credentials | HttpClient.HttpClient>;
export type CreateTelemetryRuleForOrganizationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Creates a telemetry rule that applies across an Amazon Web Services Organization. This operation can only be called by the organization's management account or a delegated administrator account.
 */
export declare const createTelemetryRuleForOrganization: API.OperationMethod<CreateTelemetryRuleForOrganizationInput, CreateTelemetryRuleForOrganizationOutput, CreateTelemetryRuleForOrganizationError, Credentials | HttpClient.HttpClient>;
export type DeleteCentralizationRuleForOrganizationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Deletes an organization-wide centralization rule. This operation can only be called by the organization's management account or a delegated administrator account.
 */
export declare const deleteCentralizationRuleForOrganization: API.OperationMethod<DeleteCentralizationRuleForOrganizationInput, DeleteCentralizationRuleForOrganizationResponse, DeleteCentralizationRuleForOrganizationError, Credentials | HttpClient.HttpClient>;
export type DeleteDatasetIntegrationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Deletes a dataset integration for the caller's account in the current region. This operation is idempotent; if you submit the same delete more than once, each call succeeds.
 */
export declare const deleteDatasetIntegration: API.OperationMethod<DeleteDatasetIntegrationInput, DeleteDatasetIntegrationResponse, DeleteDatasetIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteS3TableIntegrationError = AccessDeniedException | InternalServerException | InvalidStateException | ServiceQuotaExceededException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Deletes an S3 Table integration and its associated data. This operation removes the connection between CloudWatch Observability Admin and S3 Tables.
 */
export declare const deleteS3TableIntegration: API.OperationMethod<DeleteS3TableIntegrationInput, DeleteS3TableIntegrationResponse, DeleteS3TableIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteTelemetryPipelineError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Deletes a telemetry pipeline and its associated resources. This operation stops data processing and removes the pipeline configuration.
 */
export declare const deleteTelemetryPipeline: API.OperationMethod<DeleteTelemetryPipelineInput, DeleteTelemetryPipelineOutput, DeleteTelemetryPipelineError, Credentials | HttpClient.HttpClient>;
export type DeleteTelemetryRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Deletes a telemetry rule from your account. Any telemetry configurations previously created by the rule will remain but no new resources will be configured by this rule.
 */
export declare const deleteTelemetryRule: API.OperationMethod<DeleteTelemetryRuleInput, DeleteTelemetryRuleResponse, DeleteTelemetryRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteTelemetryRuleForOrganizationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Deletes an organization-wide telemetry rule. This operation can only be called by the organization's management account or a delegated administrator account.
 */
export declare const deleteTelemetryRuleForOrganization: API.OperationMethod<DeleteTelemetryRuleForOrganizationInput, DeleteTelemetryRuleForOrganizationResponse, DeleteTelemetryRuleForOrganizationError, Credentials | HttpClient.HttpClient>;
export type GetCentralizationRuleForOrganizationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Retrieves the details of a specific organization centralization rule. This operation can only be called by the organization's management account or a delegated administrator account.
 */
export declare const getCentralizationRuleForOrganization: API.OperationMethod<GetCentralizationRuleForOrganizationInput, GetCentralizationRuleForOrganizationOutput, GetCentralizationRuleForOrganizationError, Credentials | HttpClient.HttpClient>;
export type GetDatasetIntegrationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Returns the dataset integration for the caller's account in the current region.
 */
export declare const getDatasetIntegration: API.OperationMethod<GetDatasetIntegrationInput, GetDatasetIntegrationOutput, GetDatasetIntegrationError, Credentials | HttpClient.HttpClient>;
export type GetS3TableIntegrationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Retrieves information about a specific S3 Table integration, including its configuration, status, and metadata.
 */
export declare const getS3TableIntegration: API.OperationMethod<GetS3TableIntegrationInput, GetS3TableIntegrationOutput, GetS3TableIntegrationError, Credentials | HttpClient.HttpClient>;
export type GetTelemetryEnrichmentStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns the current status of the resource tags for telemetry feature, which enhances telemetry data with additional resource metadata from Resource Explorer.
 */
export declare const getTelemetryEnrichmentStatus: API.OperationMethod<GetTelemetryEnrichmentStatusRequest, GetTelemetryEnrichmentStatusOutput, GetTelemetryEnrichmentStatusError, Credentials | HttpClient.HttpClient>;
export type GetTelemetryEvaluationStatusError = AccessDeniedException | InternalServerException | TooManyRequestsException | CommonErrors;
/**
 * Returns the current onboarding status of the telemetry config feature, including the status of the feature and reason the feature failed to start or stop.
 */
export declare const getTelemetryEvaluationStatus: API.OperationMethod<GetTelemetryEvaluationStatusRequest, GetTelemetryEvaluationStatusOutput, GetTelemetryEvaluationStatusError, Credentials | HttpClient.HttpClient>;
export type GetTelemetryEvaluationStatusForOrganizationError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * This returns the onboarding status of the telemetry configuration feature for the organization. It can only be called by a Management Account of an Amazon Web Services Organization or an assigned Delegated Admin Account of Amazon CloudWatch telemetry config.
 */
export declare const getTelemetryEvaluationStatusForOrganization: API.OperationMethod<GetTelemetryEvaluationStatusForOrganizationRequest, GetTelemetryEvaluationStatusForOrganizationOutput, GetTelemetryEvaluationStatusForOrganizationError, Credentials | HttpClient.HttpClient>;
export type GetTelemetryPipelineError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Retrieves information about a specific telemetry pipeline, including its configuration, status, and metadata.
 */
export declare const getTelemetryPipeline: API.OperationMethod<GetTelemetryPipelineInput, GetTelemetryPipelineOutput, GetTelemetryPipelineError, Credentials | HttpClient.HttpClient>;
export type GetTelemetryRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Retrieves the details of a specific telemetry rule in your account.
 */
export declare const getTelemetryRule: API.OperationMethod<GetTelemetryRuleInput, GetTelemetryRuleOutput, GetTelemetryRuleError, Credentials | HttpClient.HttpClient>;
export type GetTelemetryRuleForOrganizationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Retrieves the details of a specific organization telemetry rule. This operation can only be called by the organization's management account or a delegated administrator account.
 */
export declare const getTelemetryRuleForOrganization: API.OperationMethod<GetTelemetryRuleForOrganizationInput, GetTelemetryRuleForOrganizationOutput, GetTelemetryRuleForOrganizationError, Credentials | HttpClient.HttpClient>;
export type ListCentralizationRulesForOrganizationError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Lists all centralization rules in your organization. This operation can only be called by the organization's management account or a delegated administrator account.
 */
export declare const listCentralizationRulesForOrganization: API.PaginatedOperationMethod<ListCentralizationRulesForOrganizationInput, ListCentralizationRulesForOrganizationOutput, ListCentralizationRulesForOrganizationError, Credentials | HttpClient.HttpClient, CentralizationRuleSummary>;
export type ListDatasetIntegrationsError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Returns the dataset integrations in your account.
 */
export declare const listDatasetIntegrations: API.PaginatedOperationMethod<ListDatasetIntegrationsInput, ListDatasetIntegrationsOutput, ListDatasetIntegrationsError, Credentials | HttpClient.HttpClient, DatasetIntegrationSummary>;
export type ListResourceTelemetryError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Returns a list of telemetry configurations for Amazon Web Services resources supported by telemetry config. For more information, see Auditing CloudWatch telemetry configurations.
 */
export declare const listResourceTelemetry: API.PaginatedOperationMethod<ListResourceTelemetryInput, ListResourceTelemetryOutput, ListResourceTelemetryError, Credentials | HttpClient.HttpClient, TelemetryConfiguration>;
export type ListResourceTelemetryForOrganizationError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Returns a list of telemetry configurations for Amazon Web Services resources supported by telemetry config in the organization.
 */
export declare const listResourceTelemetryForOrganization: API.PaginatedOperationMethod<ListResourceTelemetryForOrganizationInput, ListResourceTelemetryForOrganizationOutput, ListResourceTelemetryForOrganizationError, Credentials | HttpClient.HttpClient, TelemetryConfiguration>;
export type ListS3TableIntegrationsError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Lists all S3 Table integrations in your account. We recommend using pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listS3TableIntegrations: API.PaginatedOperationMethod<ListS3TableIntegrationsInput, ListS3TableIntegrationsOutput, ListS3TableIntegrationsError, Credentials | HttpClient.HttpClient, IntegrationSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Lists all tags attached to the specified resource. Supports telemetry rule resources and telemetry pipeline resources.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTelemetryPipelinesError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Returns a list of telemetry pipelines in your account. Returns up to 100 results. If more than 100 telemetry pipelines exist, include the `NextToken` value from the response to retrieve the next set of results.
 */
export declare const listTelemetryPipelines: API.PaginatedOperationMethod<ListTelemetryPipelinesInput, ListTelemetryPipelinesOutput, ListTelemetryPipelinesError, Credentials | HttpClient.HttpClient, TelemetryPipelineSummary>;
export type ListTelemetryRulesError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Lists all telemetry rules in your account. You can filter the results by specifying a rule name prefix.
 */
export declare const listTelemetryRules: API.PaginatedOperationMethod<ListTelemetryRulesInput, ListTelemetryRulesOutput, ListTelemetryRulesError, Credentials | HttpClient.HttpClient, TelemetryRuleSummary>;
export type ListTelemetryRulesForOrganizationError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Lists all telemetry rules in your organization. This operation can only be called by the organization's management account or a delegated administrator account.
 */
export declare const listTelemetryRulesForOrganization: API.PaginatedOperationMethod<ListTelemetryRulesForOrganizationInput, ListTelemetryRulesForOrganizationOutput, ListTelemetryRulesForOrganizationError, Credentials | HttpClient.HttpClient, TelemetryRuleSummary>;
export type StartTelemetryEnrichmentError = AccessDeniedException | ConflictException | InternalServerException | TooManyRequestsException | CommonErrors;
/**
 * Enables the resource tags for telemetry feature for your account, which enhances telemetry data with additional resource metadata from Resource Explorer to provide richer context for monitoring and observability.
 */
export declare const startTelemetryEnrichment: API.OperationMethod<StartTelemetryEnrichmentRequest, StartTelemetryEnrichmentOutput, StartTelemetryEnrichmentError, Credentials | HttpClient.HttpClient>;
export type StartTelemetryEvaluationError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * This action begins onboarding the caller Amazon Web Services account to the telemetry config feature.
 */
export declare const startTelemetryEvaluation: API.OperationMethod<StartTelemetryEvaluationInput, StartTelemetryEvaluationResponse, StartTelemetryEvaluationError, Credentials | HttpClient.HttpClient>;
export type StartTelemetryEvaluationForOrganizationError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * This actions begins onboarding the organization and all member accounts to the telemetry config feature.
 */
export declare const startTelemetryEvaluationForOrganization: API.OperationMethod<StartTelemetryEvaluationForOrganizationInput, StartTelemetryEvaluationForOrganizationResponse, StartTelemetryEvaluationForOrganizationError, Credentials | HttpClient.HttpClient>;
export type StopTelemetryEnrichmentError = AccessDeniedException | ConflictException | InternalServerException | TooManyRequestsException | CommonErrors;
/**
 * Disables the resource tags for telemetry feature for your account, stopping the enhancement of telemetry data with additional resource metadata.
 */
export declare const stopTelemetryEnrichment: API.OperationMethod<StopTelemetryEnrichmentRequest, StopTelemetryEnrichmentOutput, StopTelemetryEnrichmentError, Credentials | HttpClient.HttpClient>;
export type StopTelemetryEvaluationError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * This action begins offboarding the caller Amazon Web Services account from the telemetry config feature.
 */
export declare const stopTelemetryEvaluation: API.OperationMethod<StopTelemetryEvaluationRequest, StopTelemetryEvaluationResponse, StopTelemetryEvaluationError, Credentials | HttpClient.HttpClient>;
export type StopTelemetryEvaluationForOrganizationError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * This action offboards the Organization of the caller Amazon Web Services account from the telemetry config feature.
 */
export declare const stopTelemetryEvaluationForOrganization: API.OperationMethod<StopTelemetryEvaluationForOrganizationRequest, StopTelemetryEvaluationForOrganizationResponse, StopTelemetryEvaluationForOrganizationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Adds or updates tags for a resource. Supports telemetry rule resources and telemetry pipeline resources.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestTelemetryPipelineError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Tests a pipeline configuration with sample records to validate data processing before deployment. This operation helps ensure your pipeline configuration works as expected.
 */
export declare const testTelemetryPipeline: API.OperationMethod<TestTelemetryPipelineInput, TestTelemetryPipelineOutput, TestTelemetryPipelineError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Removes tags from a resource. Supports telemetry rule resources and telemetry pipeline resources.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCentralizationRuleForOrganizationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Updates an existing centralization rule that applies across an Amazon Web Services Organization. This operation can only be called by the organization's management account or a delegated administrator account.
 */
export declare const updateCentralizationRuleForOrganization: API.OperationMethod<UpdateCentralizationRuleForOrganizationInput, UpdateCentralizationRuleForOrganizationOutput, UpdateCentralizationRuleForOrganizationError, Credentials | HttpClient.HttpClient>;
export type UpdateDatasetIntegrationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Updates a dataset integration for the caller's account in the current region. This operation is idempotent; if you submit the same update more than once, each call succeeds.
 */
export declare const updateDatasetIntegration: API.OperationMethod<UpdateDatasetIntegrationInput, UpdateDatasetIntegrationOutput, UpdateDatasetIntegrationError, Credentials | HttpClient.HttpClient>;
export type UpdateTelemetryPipelineError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Updates the configuration of an existing telemetry pipeline.
 *
 * The following attributes cannot be updated after pipeline creation:
 *
 * - **Pipeline name** - The pipeline name is immutable
 *
 * - **Pipeline ARN** - The ARN is automatically generated and cannot be changed
 *
 * - **Source type** - Once a pipeline is created with a specific source type (such as S3, CloudWatch Logs, GitHub, or third-party sources), it cannot be changed to a different source type
 *
 * Processors can be added, removed, or modified. However, some processors are not supported for third-party pipelines and cannot be added through updates.
 *
 * **Source-Specific Update Rules**
 *
 * ### CloudWatch Logs Sources (Vended and Custom)
 *
 * **Updatable:** `sts_role_arn`
 *
 * **Fixed:** `data_source_name`, `data_source_type`, sink (must remain `@original`)
 *
 * ### S3 Sources (Crowdstrike, Zscaler, SentinelOne, Custom)
 *
 * **Updatable:** All SQS configuration parameters, `sts_role_arn`, codec settings, compression type, bucket ownership settings, sink log group
 *
 * **Fixed:** `notification_type`, `aws.region`
 *
 * ### GitHub Audit Logs
 *
 * **Updatable:** All Amazon Web Services Secrets Manager attributes, `scope` (can switch between ORGANIZATION/ENTERPRISE), `organization` or `enterprise` name, `range`, authentication credentials (PAT or GitHub App)
 *
 * ### Microsoft Sources (Entra ID, Office365, Windows)
 *
 * **Updatable:** All Amazon Web Services Secrets Manager attributes, `tenant_id`, `workspace_id` (Windows only), OAuth2 credentials (`client_id`, `client_secret`)
 *
 * ### Okta Sources (SSO, Auth0)
 *
 * **Updatable:** All Amazon Web Services Secrets Manager attributes, `domain`, `range`, OAuth2 credentials (`client_id`, `client_secret`)
 *
 * ### Palo Alto Networks
 *
 * **Updatable:** All Amazon Web Services Secrets Manager attributes, `hostname`, basic authentication credentials (`username`, `password`)
 *
 * ### ServiceNow CMDB
 *
 * **Updatable:** All Amazon Web Services Secrets Manager attributes, `instance_url`, `range`, OAuth2 credentials (`client_id`, `client_secret`)
 *
 * ### Wiz CNAPP
 *
 * **Updatable:** All Amazon Web Services Secrets Manager attributes, `region`, `range`, OAuth2 credentials (`client_id`, `client_secret`)
 */
export declare const updateTelemetryPipeline: API.OperationMethod<UpdateTelemetryPipelineInput, UpdateTelemetryPipelineOutput, UpdateTelemetryPipelineError, Credentials | HttpClient.HttpClient>;
export type UpdateTelemetryRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Updates an existing telemetry rule in your account. If multiple users attempt to modify the same telemetry rule simultaneously, a ConflictException is returned to provide specific error information for concurrent modification scenarios.
 */
export declare const updateTelemetryRule: API.OperationMethod<UpdateTelemetryRuleInput, UpdateTelemetryRuleOutput, UpdateTelemetryRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateTelemetryRuleForOrganizationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Updates an existing telemetry rule that applies across an Amazon Web Services Organization. This operation can only be called by the organization's management account or a delegated administrator account.
 */
export declare const updateTelemetryRuleForOrganization: API.OperationMethod<UpdateTelemetryRuleForOrganizationInput, UpdateTelemetryRuleForOrganizationOutput, UpdateTelemetryRuleForOrganizationError, Credentials | HttpClient.HttpClient>;
export type ValidateTelemetryPipelineConfigurationError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Validates a pipeline configuration without creating the pipeline. This operation checks the configuration for syntax errors and compatibility issues.
 */
export declare const validateTelemetryPipelineConfiguration: API.OperationMethod<ValidateTelemetryPipelineConfigurationInput, ValidateTelemetryPipelineConfigurationOutput, ValidateTelemetryPipelineConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=observabilityadmin.d.ts.map