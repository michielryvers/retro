import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
    readonly FieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ResourceName = string;
export type Arn = string;
export interface AssociateTrackerConsumerRequest {
    TrackerName: string;
    ConsumerArn: string;
}
export interface AssociateTrackerConsumerResponse {
}
export type Id = string;
export type DeviceIdsList = string[];
export interface BatchDeleteDevicePositionHistoryRequest {
    TrackerName: string;
    DeviceIds: string[];
}
export type BatchItemErrorCode = string;
export interface BatchItemError {
    Code?: string;
    Message?: string;
}
export interface BatchDeleteDevicePositionHistoryError_ {
    DeviceId: string;
    Error: BatchItemError;
}
export type BatchDeleteDevicePositionHistoryErrorList = BatchDeleteDevicePositionHistoryError_[];
export interface BatchDeleteDevicePositionHistoryResponse {
    Errors: BatchDeleteDevicePositionHistoryError_[];
}
export type IdList = string[];
export interface BatchDeleteGeofenceRequest {
    CollectionName: string;
    GeofenceIds: string[];
}
export interface BatchDeleteGeofenceError_ {
    GeofenceId: string;
    Error: BatchItemError;
}
export type BatchDeleteGeofenceErrorList = BatchDeleteGeofenceError_[];
export interface BatchDeleteGeofenceResponse {
    Errors: BatchDeleteGeofenceError_[];
}
export type Position = number[];
export type SensitiveDouble = number;
export interface PositionalAccuracy {
    Horizontal: number;
}
export type PositionPropertyMap = {
    [key: string]: string | undefined;
};
export interface DevicePositionUpdate {
    DeviceId: string;
    SampleTime: Date;
    Position: number[];
    Accuracy?: PositionalAccuracy;
    PositionProperties?: {
        [key: string]: string | undefined;
    };
}
export type DevicePositionUpdateList = DevicePositionUpdate[];
export interface BatchEvaluateGeofencesRequest {
    CollectionName: string;
    DevicePositionUpdates: DevicePositionUpdate[];
}
export interface BatchEvaluateGeofencesError_ {
    DeviceId: string;
    SampleTime: Date;
    Error: BatchItemError;
}
export type BatchEvaluateGeofencesErrorList = BatchEvaluateGeofencesError_[];
export interface BatchEvaluateGeofencesResponse {
    Errors?: BatchEvaluateGeofencesError_[];
}
export interface BatchGetDevicePositionRequest {
    TrackerName: string;
    DeviceIds: string[];
}
export interface BatchGetDevicePositionError_ {
    DeviceId: string;
    Error: BatchItemError;
}
export type BatchGetDevicePositionErrorList = BatchGetDevicePositionError_[];
export interface DevicePosition {
    DeviceId?: string;
    SampleTime: Date;
    ReceivedTime: Date;
    Position: number[];
    Accuracy?: PositionalAccuracy;
    PositionProperties?: {
        [key: string]: string | undefined;
    };
}
export type DevicePositionList = DevicePosition[];
export interface BatchGetDevicePositionResponse {
    Errors: BatchGetDevicePositionError_[];
    DevicePositions: DevicePosition[];
}
export type LinearRing = number[][];
export type LinearRings = number[][][];
export interface Circle {
    Center: number[];
    Radius: number;
}
export type Base64EncodedGeobuf = Uint8Array | redacted.Redacted<Uint8Array>;
export type MultiLinearRings = number[][][][];
export interface GeofenceGeometry {
    Polygon?: number[][][];
    Circle?: Circle;
    Geobuf?: Uint8Array | redacted.Redacted<Uint8Array>;
    MultiPolygon?: number[][][][];
}
export type PropertyMap = {
    [key: string]: string | undefined;
};
export interface BatchPutGeofenceRequestEntry {
    GeofenceId: string;
    Geometry: GeofenceGeometry;
    GeofenceProperties?: {
        [key: string]: string | undefined;
    };
}
export type BatchPutGeofenceRequestEntryList = BatchPutGeofenceRequestEntry[];
export interface BatchPutGeofenceRequest {
    CollectionName: string;
    Entries: BatchPutGeofenceRequestEntry[];
}
export interface BatchPutGeofenceSuccess {
    GeofenceId: string;
    CreateTime: Date;
    UpdateTime: Date;
}
export type BatchPutGeofenceSuccessList = BatchPutGeofenceSuccess[];
export interface BatchPutGeofenceError_ {
    GeofenceId: string;
    Error: BatchItemError;
}
export type BatchPutGeofenceErrorList = BatchPutGeofenceError_[];
export interface BatchPutGeofenceResponse {
    Successes: BatchPutGeofenceSuccess[];
    Errors: BatchPutGeofenceError_[];
}
export interface BatchUpdateDevicePositionRequest {
    TrackerName: string;
    Updates: DevicePositionUpdate[];
}
export interface BatchUpdateDevicePositionError_ {
    DeviceId: string;
    SampleTime: Date;
    Error: BatchItemError;
}
export type BatchUpdateDevicePositionErrorList = BatchUpdateDevicePositionError_[];
export interface BatchUpdateDevicePositionResponse {
    Errors: BatchUpdateDevicePositionError_[];
}
export type WaypointPositionList = number[][];
export type TravelMode = string;
export type SensitiveBoolean = boolean;
export type DistanceUnit = string;
export interface CalculateRouteCarModeOptions {
    AvoidFerries?: boolean;
    AvoidTolls?: boolean;
}
export type DimensionUnit = string;
export interface TruckDimensions {
    Length?: number;
    Height?: number;
    Width?: number;
    Unit?: string;
}
export type VehicleWeightUnit = string;
export interface TruckWeight {
    Total?: number;
    Unit?: string;
}
export interface CalculateRouteTruckModeOptions {
    AvoidFerries?: boolean;
    AvoidTolls?: boolean;
    Dimensions?: TruckDimensions;
    Weight?: TruckWeight;
}
export type OptimizationMode = string;
export type ApiKey = string | redacted.Redacted<string>;
export interface CalculateRouteRequest {
    CalculatorName: string;
    DeparturePosition: number[];
    DestinationPosition: number[];
    WaypointPositions?: number[][];
    TravelMode?: string;
    DepartureTime?: Date;
    DepartNow?: boolean;
    DistanceUnit?: string;
    IncludeLegGeometry?: boolean;
    CarModeOptions?: CalculateRouteCarModeOptions;
    TruckModeOptions?: CalculateRouteTruckModeOptions;
    ArrivalTime?: Date;
    OptimizeFor?: string;
    Key?: string | redacted.Redacted<string>;
}
export type LineString = number[][];
export interface LegGeometry {
    LineString?: number[][];
}
export interface Step {
    StartPosition: number[];
    EndPosition: number[];
    Distance: number;
    DurationSeconds: number;
    GeometryOffset?: number;
}
export type StepList = Step[];
export interface Leg {
    StartPosition: number[];
    EndPosition: number[];
    Distance: number;
    DurationSeconds: number;
    Geometry?: LegGeometry;
    Steps: Step[];
}
export type LegList = Leg[];
export type BoundingBox = number[];
export interface CalculateRouteSummary {
    RouteBBox: number[];
    DataSource: string;
    Distance: number;
    DurationSeconds: number;
    DistanceUnit: string;
}
export interface CalculateRouteResponse {
    Legs: Leg[];
    Summary: CalculateRouteSummary;
}
export type PositionList = number[][];
export interface CalculateRouteMatrixRequest {
    CalculatorName: string;
    DeparturePositions: number[][];
    DestinationPositions: number[][];
    TravelMode?: string;
    DepartureTime?: Date;
    DepartNow?: boolean;
    DistanceUnit?: string;
    CarModeOptions?: CalculateRouteCarModeOptions;
    TruckModeOptions?: CalculateRouteTruckModeOptions;
    Key?: string | redacted.Redacted<string>;
}
export type RouteMatrixErrorCode = string;
export interface RouteMatrixEntryError {
    Code: string;
    Message?: string;
}
export interface RouteMatrixEntry {
    Distance?: number;
    DurationSeconds?: number;
    Error?: RouteMatrixEntryError;
}
export type RouteMatrixRow = RouteMatrixEntry[];
export type RouteMatrix = RouteMatrixEntry[][];
export interface CalculateRouteMatrixSummary {
    DataSource: string;
    RouteCount: number;
    ErrorCount: number;
    DistanceUnit: string;
}
export interface CalculateRouteMatrixResponse {
    RouteMatrix: RouteMatrixEntry[][];
    SnappedDeparturePositions?: number[][];
    SnappedDestinationPositions?: number[][];
    Summary: CalculateRouteMatrixSummary;
}
export type JobId = string;
export interface CancelJobRequest {
    JobId: string;
}
export type GeoArn = string;
export type JobStatus = string;
export interface CancelJobResponse {
    JobArn: string;
    JobId: string;
    Status: string;
}
export type PricingPlan = string;
export type ResourceDescription = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type KmsKeyId = string;
export interface CreateGeofenceCollectionRequest {
    CollectionName: string;
    PricingPlan?: string;
    PricingPlanDataSource?: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    KmsKeyId?: string;
}
export interface CreateGeofenceCollectionResponse {
    CollectionName: string;
    CollectionArn: string;
    CreateTime: Date;
}
export type ApiKeyAction = string;
export type ApiKeyActionList = string[];
export type GeoArnV2 = string;
export type GeoArnList = string[];
export type RefererPattern = string | redacted.Redacted<string>;
export type RefererPatternList = (string | redacted.Redacted<string>)[];
export type AndroidPackageName = string;
export type Sha1CertificateFingerprint = string;
export interface AndroidApp {
    Package: string;
    CertificateFingerprint: string;
}
export type AndroidAppList = AndroidApp[];
export type AppleBundleId = string;
export interface AppleApp {
    BundleId: string;
}
export type AppleAppList = AppleApp[];
export interface ApiKeyRestrictions {
    AllowActions: string[];
    AllowResources: string[];
    AllowReferers?: (string | redacted.Redacted<string>)[];
    AllowAndroidApps?: AndroidApp[];
    AllowAppleApps?: AppleApp[];
}
export interface CreateKeyRequest {
    KeyName: string;
    Restrictions: ApiKeyRestrictions;
    Description?: string;
    ExpireTime?: Date;
    NoExpiry?: boolean;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateKeyResponse {
    Key: string | redacted.Redacted<string>;
    KeyArn: string;
    KeyName: string;
    CreateTime: Date;
}
export type MapStyle = string;
export type CountryCode3 = string | redacted.Redacted<string>;
export type CustomLayer = string;
export type CustomLayerList = string[];
export interface MapConfiguration {
    Style: string;
    PoliticalView?: string | redacted.Redacted<string>;
    CustomLayers?: string[];
}
export interface CreateMapRequest {
    MapName: string;
    Configuration: MapConfiguration;
    PricingPlan?: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateMapResponse {
    MapName: string;
    MapArn: string;
    CreateTime: Date;
}
export type IntendedUse = string;
export interface DataSourceConfiguration {
    IntendedUse?: string;
}
export interface CreatePlaceIndexRequest {
    IndexName: string;
    DataSource: string;
    PricingPlan?: string;
    Description?: string;
    DataSourceConfiguration?: DataSourceConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreatePlaceIndexResponse {
    IndexName: string;
    IndexArn: string;
    CreateTime: Date;
}
export interface CreateRouteCalculatorRequest {
    CalculatorName: string;
    DataSource: string;
    PricingPlan?: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateRouteCalculatorResponse {
    CalculatorName: string;
    CalculatorArn: string;
    CreateTime: Date;
}
export type PositionFiltering = string;
export interface CreateTrackerRequest {
    TrackerName: string;
    PricingPlan?: string;
    KmsKeyId?: string;
    PricingPlanDataSource?: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    PositionFiltering?: string;
    EventBridgeEnabled?: boolean;
    KmsKeyEnableGeospatialQueries?: boolean;
}
export interface CreateTrackerResponse {
    TrackerName: string;
    TrackerArn: string;
    CreateTime: Date;
}
export interface DeleteGeofenceCollectionRequest {
    CollectionName: string;
}
export interface DeleteGeofenceCollectionResponse {
}
export interface DeleteKeyRequest {
    KeyName: string;
    ForceDelete?: boolean;
}
export interface DeleteKeyResponse {
}
export interface DeleteMapRequest {
    MapName: string;
}
export interface DeleteMapResponse {
}
export interface DeletePlaceIndexRequest {
    IndexName: string;
}
export interface DeletePlaceIndexResponse {
}
export interface DeleteRouteCalculatorRequest {
    CalculatorName: string;
}
export interface DeleteRouteCalculatorResponse {
}
export interface DeleteTrackerRequest {
    TrackerName: string;
}
export interface DeleteTrackerResponse {
}
export interface DescribeGeofenceCollectionRequest {
    CollectionName: string;
}
export interface DescribeGeofenceCollectionResponse {
    CollectionName: string;
    CollectionArn: string;
    Description?: string;
    PricingPlan?: string;
    PricingPlanDataSource?: string;
    KmsKeyId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    CreateTime: Date;
    UpdateTime: Date;
    GeofenceCount?: number;
}
export interface DescribeKeyRequest {
    KeyName: string;
}
export interface DescribeKeyResponse {
    Key: string | redacted.Redacted<string>;
    KeyArn: string;
    KeyName: string;
    Restrictions: ApiKeyRestrictions;
    CreateTime: Date;
    ExpireTime: Date;
    UpdateTime: Date;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeMapRequest {
    MapName: string;
}
export interface DescribeMapResponse {
    MapName: string;
    MapArn: string;
    PricingPlan?: string;
    DataSource: string;
    Configuration: MapConfiguration;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    CreateTime: Date;
    UpdateTime: Date;
}
export interface DescribePlaceIndexRequest {
    IndexName: string;
}
export interface DescribePlaceIndexResponse {
    IndexName: string;
    IndexArn: string;
    PricingPlan?: string;
    Description?: string;
    CreateTime: Date;
    UpdateTime: Date;
    DataSource: string;
    DataSourceConfiguration: DataSourceConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeRouteCalculatorRequest {
    CalculatorName: string;
}
export interface DescribeRouteCalculatorResponse {
    CalculatorName: string;
    CalculatorArn: string;
    PricingPlan?: string;
    Description?: string;
    CreateTime: Date;
    UpdateTime: Date;
    DataSource: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeTrackerRequest {
    TrackerName: string;
}
export interface DescribeTrackerResponse {
    TrackerName: string;
    TrackerArn: string;
    Description?: string;
    PricingPlan?: string;
    PricingPlanDataSource?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    CreateTime: Date;
    UpdateTime: Date;
    KmsKeyId?: string;
    PositionFiltering?: string;
    EventBridgeEnabled?: boolean;
    KmsKeyEnableGeospatialQueries?: boolean;
}
export interface DisassociateTrackerConsumerRequest {
    TrackerName: string;
    ConsumerArn: string;
}
export interface DisassociateTrackerConsumerResponse {
}
export interface ForecastGeofenceEventsDeviceState {
    Position: number[];
    Speed?: number;
}
export type SpeedUnit = string;
export type LargeToken = string;
export interface ForecastGeofenceEventsRequest {
    CollectionName: string;
    DeviceState: ForecastGeofenceEventsDeviceState;
    TimeHorizonMinutes?: number;
    DistanceUnit?: string;
    SpeedUnit?: string;
    NextToken?: string;
    MaxResults?: number;
}
export type Uuid = string;
export type NearestDistance = number;
export type ForecastedGeofenceEventType = string;
export interface ForecastedEvent {
    EventId: string;
    GeofenceId: string;
    IsDeviceInGeofence: boolean;
    NearestDistance: number;
    EventType: string;
    ForecastedBreachTime?: Date;
    GeofenceProperties?: {
        [key: string]: string | undefined;
    };
}
export type ForecastedEventsList = ForecastedEvent[];
export interface ForecastGeofenceEventsResponse {
    ForecastedEvents: ForecastedEvent[];
    NextToken?: string;
    DistanceUnit: string;
    SpeedUnit: string;
}
export interface GetDevicePositionRequest {
    TrackerName: string;
    DeviceId: string;
}
export interface GetDevicePositionResponse {
    DeviceId?: string;
    SampleTime: Date;
    ReceivedTime: Date;
    Position: number[];
    Accuracy?: PositionalAccuracy;
    PositionProperties?: {
        [key: string]: string | undefined;
    };
}
export type Token = string;
export interface GetDevicePositionHistoryRequest {
    TrackerName: string;
    DeviceId: string;
    NextToken?: string;
    StartTimeInclusive?: Date;
    EndTimeExclusive?: Date;
    MaxResults?: number;
}
export interface GetDevicePositionHistoryResponse {
    DevicePositions: DevicePosition[];
    NextToken?: string;
}
export interface GetGeofenceRequest {
    CollectionName: string;
    GeofenceId: string;
}
export interface GetGeofenceResponse {
    GeofenceId: string;
    Geometry: GeofenceGeometry;
    Status: string;
    CreateTime: Date;
    UpdateTime: Date;
    GeofenceProperties?: {
        [key: string]: string | undefined;
    };
}
export interface GetJobRequest {
    JobId: string;
}
export type JobAction = string;
export type ValidateAddressAdditionalFeature = string;
export type ValidateAddressAdditionalFeatureList = string[];
export interface ValidateAddressActionOptions {
    AdditionalFeatures?: string[];
}
export interface JobActionOptions {
    ValidateAddress?: ValidateAddressActionOptions;
}
export type JobErrorCode = string;
export type JobErrorMessage = string;
export type JobErrorMessagesList = string[];
export interface JobError {
    Code: string;
    Messages?: string[];
}
export type IamRoleArn = string;
export type JobInputLocation = string;
export type JobInputFormat = string;
export interface JobInputOptions {
    Location: string;
    Format: string;
}
export type JobOutputFormat = string;
export type JobOutputLocation = string;
export interface JobOutputOptions {
    Format: string;
    Location: string;
}
export interface GetJobResponse {
    Action: string;
    ActionOptions?: JobActionOptions;
    CreatedAt: Date;
    EndedAt?: Date;
    Error?: JobError;
    ExecutionRoleArn: string;
    InputOptions: JobInputOptions;
    JobArn: string;
    JobId: string;
    Name?: string;
    OutputOptions: JobOutputOptions;
    Status: string;
    UpdatedAt: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetMapGlyphsRequest {
    MapName: string;
    FontStack: string;
    FontUnicodeRange: string;
    Key?: string | redacted.Redacted<string>;
}
export interface GetMapGlyphsResponse {
    Blob?: Uint8Array;
    ContentType?: string;
    CacheControl?: string;
}
export interface GetMapSpritesRequest {
    MapName: string;
    FileName: string;
    Key?: string | redacted.Redacted<string>;
}
export interface GetMapSpritesResponse {
    Blob?: Uint8Array;
    ContentType?: string;
    CacheControl?: string;
}
export interface GetMapStyleDescriptorRequest {
    MapName: string;
    Key?: string | redacted.Redacted<string>;
}
export interface GetMapStyleDescriptorResponse {
    Blob?: Uint8Array;
    ContentType?: string;
    CacheControl?: string;
}
export type SensitiveString = string | redacted.Redacted<string>;
export interface GetMapTileRequest {
    MapName: string;
    Z: string | redacted.Redacted<string>;
    X: string | redacted.Redacted<string>;
    Y: string | redacted.Redacted<string>;
    Key?: string | redacted.Redacted<string>;
}
export interface GetMapTileResponse {
    Blob?: Uint8Array;
    ContentType?: string;
    CacheControl?: string;
}
export type PlaceId = string | redacted.Redacted<string>;
export type LanguageTag = string;
export interface GetPlaceRequest {
    IndexName: string;
    PlaceId: string | redacted.Redacted<string>;
    Language?: string;
    Key?: string | redacted.Redacted<string>;
}
export interface PlaceGeometry {
    Point?: number[];
}
export type SensitiveInteger = number;
export interface TimeZone {
    Name: string | redacted.Redacted<string>;
    Offset?: number;
}
export type PlaceCategory = string | redacted.Redacted<string>;
export type PlaceCategoryList = (string | redacted.Redacted<string>)[];
export type PlaceSupplementalCategory = string | redacted.Redacted<string>;
export type PlaceSupplementalCategoryList = (string | redacted.Redacted<string>)[];
export interface Place {
    Label?: string | redacted.Redacted<string>;
    Geometry: PlaceGeometry;
    AddressNumber?: string | redacted.Redacted<string>;
    Street?: string | redacted.Redacted<string>;
    Neighborhood?: string | redacted.Redacted<string>;
    Municipality?: string | redacted.Redacted<string>;
    SubRegion?: string | redacted.Redacted<string>;
    Region?: string | redacted.Redacted<string>;
    Country?: string | redacted.Redacted<string>;
    PostalCode?: string | redacted.Redacted<string>;
    Interpolated?: boolean;
    TimeZone?: TimeZone;
    UnitType?: string | redacted.Redacted<string>;
    UnitNumber?: string | redacted.Redacted<string>;
    Categories?: (string | redacted.Redacted<string>)[];
    SupplementalCategories?: (string | redacted.Redacted<string>)[];
    SubMunicipality?: string | redacted.Redacted<string>;
}
export interface GetPlaceResponse {
    Place: Place;
}
export interface TrackingFilterGeometry {
    Polygon?: number[][][];
}
export interface ListDevicePositionsRequest {
    TrackerName: string;
    MaxResults?: number;
    NextToken?: string;
    FilterGeometry?: TrackingFilterGeometry;
}
export interface ListDevicePositionsResponseEntry {
    DeviceId: string;
    SampleTime: Date;
    Position: number[];
    Accuracy?: PositionalAccuracy;
    PositionProperties?: {
        [key: string]: string | undefined;
    };
}
export type ListDevicePositionsResponseEntryList = ListDevicePositionsResponseEntry[];
export interface ListDevicePositionsResponse {
    Entries: ListDevicePositionsResponseEntry[];
    NextToken?: string;
}
export interface ListGeofenceCollectionsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface ListGeofenceCollectionsResponseEntry {
    CollectionName: string;
    Description?: string;
    PricingPlan?: string;
    PricingPlanDataSource?: string;
    CreateTime: Date;
    UpdateTime: Date;
}
export type ListGeofenceCollectionsResponseEntryList = ListGeofenceCollectionsResponseEntry[];
export interface ListGeofenceCollectionsResponse {
    Entries: ListGeofenceCollectionsResponseEntry[];
    NextToken?: string;
}
export interface ListGeofencesRequest {
    CollectionName: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface ListGeofenceResponseEntry {
    GeofenceId: string;
    Geometry: GeofenceGeometry;
    Status: string;
    CreateTime: Date;
    UpdateTime: Date;
    GeofenceProperties?: {
        [key: string]: string | undefined;
    };
}
export type ListGeofenceResponseEntryList = ListGeofenceResponseEntry[];
export interface ListGeofencesResponse {
    Entries: ListGeofenceResponseEntry[];
    NextToken?: string;
}
export interface JobsFilter {
    JobStatus?: string;
}
export interface ListJobsRequest {
    Filter?: JobsFilter;
    MaxResults?: number;
    NextToken?: string;
}
export interface ListJobsResponseEntry {
    Action: string;
    ActionOptions?: JobActionOptions;
    CreatedAt: Date;
    ExecutionRoleArn: string;
    EndedAt?: Date;
    Error?: JobError;
    InputOptions: JobInputOptions;
    JobId: string;
    JobArn: string;
    Name?: string;
    OutputOptions: JobOutputOptions;
    Status: string;
    UpdatedAt: Date;
}
export type ListJobsResponseEntryList = ListJobsResponseEntry[];
export interface ListJobsResponse {
    Entries: ListJobsResponseEntry[];
    NextToken?: string;
}
export type Status = string;
export interface ApiKeyFilter {
    KeyStatus?: string;
}
export interface ListKeysRequest {
    MaxResults?: number;
    NextToken?: string;
    Filter?: ApiKeyFilter;
}
export interface ListKeysResponseEntry {
    KeyName: string;
    ExpireTime: Date;
    Description?: string;
    Restrictions: ApiKeyRestrictions;
    CreateTime: Date;
    UpdateTime: Date;
}
export type ListKeysResponseEntryList = ListKeysResponseEntry[];
export interface ListKeysResponse {
    Entries: ListKeysResponseEntry[];
    NextToken?: string;
}
export interface ListMapsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface ListMapsResponseEntry {
    MapName: string;
    Description?: string;
    DataSource: string;
    PricingPlan?: string;
    CreateTime: Date;
    UpdateTime: Date;
}
export type ListMapsResponseEntryList = ListMapsResponseEntry[];
export interface ListMapsResponse {
    Entries: ListMapsResponseEntry[];
    NextToken?: string;
}
export interface ListPlaceIndexesRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface ListPlaceIndexesResponseEntry {
    IndexName: string;
    Description?: string;
    DataSource: string;
    PricingPlan?: string;
    CreateTime: Date;
    UpdateTime: Date;
}
export type ListPlaceIndexesResponseEntryList = ListPlaceIndexesResponseEntry[];
export interface ListPlaceIndexesResponse {
    Entries: ListPlaceIndexesResponseEntry[];
    NextToken?: string;
}
export interface ListRouteCalculatorsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface ListRouteCalculatorsResponseEntry {
    CalculatorName: string;
    Description?: string;
    DataSource: string;
    PricingPlan?: string;
    CreateTime: Date;
    UpdateTime: Date;
}
export type ListRouteCalculatorsResponseEntryList = ListRouteCalculatorsResponseEntry[];
export interface ListRouteCalculatorsResponse {
    Entries: ListRouteCalculatorsResponseEntry[];
    NextToken?: string;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListTrackerConsumersRequest {
    TrackerName: string;
    MaxResults?: number;
    NextToken?: string;
}
export type ArnList = string[];
export interface ListTrackerConsumersResponse {
    ConsumerArns: string[];
    NextToken?: string;
}
export interface ListTrackersRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface ListTrackersResponseEntry {
    TrackerName: string;
    Description?: string;
    PricingPlan?: string;
    PricingPlanDataSource?: string;
    CreateTime: Date;
    UpdateTime: Date;
}
export type ListTrackersResponseEntryList = ListTrackersResponseEntry[];
export interface ListTrackersResponse {
    Entries: ListTrackersResponseEntry[];
    NextToken?: string;
}
export interface PutGeofenceRequest {
    CollectionName: string;
    GeofenceId: string;
    Geometry: GeofenceGeometry;
    GeofenceProperties?: {
        [key: string]: string | undefined;
    };
}
export interface PutGeofenceResponse {
    GeofenceId: string;
    CreateTime: Date;
    UpdateTime: Date;
}
export type PlaceIndexSearchResultLimit = number;
export interface SearchPlaceIndexForPositionRequest {
    IndexName: string;
    Position: number[];
    MaxResults?: number;
    Language?: string;
    Key?: string | redacted.Redacted<string>;
}
export interface SearchPlaceIndexForPositionSummary {
    Position: number[];
    MaxResults?: number;
    DataSource: string;
    Language?: string;
}
export interface SearchForPositionResult {
    Place: Place;
    Distance: number;
    PlaceId?: string | redacted.Redacted<string>;
}
export type SearchForPositionResultList = SearchForPositionResult[];
export interface SearchPlaceIndexForPositionResponse {
    Summary: SearchPlaceIndexForPositionSummary;
    Results: SearchForPositionResult[];
}
export type CountryCodeList = (string | redacted.Redacted<string>)[];
export type FilterPlaceCategoryList = (string | redacted.Redacted<string>)[];
export interface SearchPlaceIndexForSuggestionsRequest {
    IndexName: string;
    Text: string | redacted.Redacted<string>;
    BiasPosition?: number[];
    FilterBBox?: number[];
    FilterCountries?: (string | redacted.Redacted<string>)[];
    MaxResults?: number;
    Language?: string;
    FilterCategories?: (string | redacted.Redacted<string>)[];
    Key?: string | redacted.Redacted<string>;
}
export interface SearchPlaceIndexForSuggestionsSummary {
    Text: string | redacted.Redacted<string>;
    BiasPosition?: number[];
    FilterBBox?: number[];
    FilterCountries?: (string | redacted.Redacted<string>)[];
    MaxResults?: number;
    DataSource: string;
    Language?: string;
    FilterCategories?: (string | redacted.Redacted<string>)[];
}
export interface SearchForSuggestionsResult {
    Text: string | redacted.Redacted<string>;
    PlaceId?: string | redacted.Redacted<string>;
    Categories?: (string | redacted.Redacted<string>)[];
    SupplementalCategories?: (string | redacted.Redacted<string>)[];
}
export type SearchForSuggestionsResultList = SearchForSuggestionsResult[];
export interface SearchPlaceIndexForSuggestionsResponse {
    Summary: SearchPlaceIndexForSuggestionsSummary;
    Results: SearchForSuggestionsResult[];
}
export interface SearchPlaceIndexForTextRequest {
    IndexName: string;
    Text: string | redacted.Redacted<string>;
    BiasPosition?: number[];
    FilterBBox?: number[];
    FilterCountries?: (string | redacted.Redacted<string>)[];
    MaxResults?: number;
    Language?: string;
    FilterCategories?: (string | redacted.Redacted<string>)[];
    Key?: string | redacted.Redacted<string>;
}
export interface SearchPlaceIndexForTextSummary {
    Text: string | redacted.Redacted<string>;
    BiasPosition?: number[];
    FilterBBox?: number[];
    FilterCountries?: (string | redacted.Redacted<string>)[];
    MaxResults?: number;
    ResultBBox?: number[];
    DataSource: string;
    Language?: string;
    FilterCategories?: (string | redacted.Redacted<string>)[];
}
export interface SearchForTextResult {
    Place: Place;
    Distance?: number;
    Relevance?: number;
    PlaceId?: string | redacted.Redacted<string>;
}
export type SearchForTextResultList = SearchForTextResult[];
export interface SearchPlaceIndexForTextResponse {
    Summary: SearchPlaceIndexForTextSummary;
    Results: SearchForTextResult[];
}
export type ClientToken = string;
export interface StartJobRequest {
    ClientToken?: string;
    Action: string;
    ActionOptions?: JobActionOptions;
    ExecutionRoleArn: string;
    InputOptions: JobInputOptions;
    Name?: string;
    OutputOptions: JobOutputOptions;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface StartJobResponse {
    CreatedAt: Date;
    JobArn: string;
    JobId: string;
    Status: string;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateGeofenceCollectionRequest {
    CollectionName: string;
    PricingPlan?: string;
    PricingPlanDataSource?: string;
    Description?: string;
}
export interface UpdateGeofenceCollectionResponse {
    CollectionName: string;
    CollectionArn: string;
    UpdateTime: Date;
}
export interface UpdateKeyRequest {
    KeyName: string;
    Description?: string;
    ExpireTime?: Date;
    NoExpiry?: boolean;
    ForceUpdate?: boolean;
    Restrictions?: ApiKeyRestrictions;
}
export interface UpdateKeyResponse {
    KeyArn: string;
    KeyName: string;
    UpdateTime: Date;
}
export type CountryCode3OrEmpty = string | redacted.Redacted<string>;
export interface MapConfigurationUpdate {
    PoliticalView?: string | redacted.Redacted<string>;
    CustomLayers?: string[];
}
export interface UpdateMapRequest {
    MapName: string;
    PricingPlan?: string;
    Description?: string;
    ConfigurationUpdate?: MapConfigurationUpdate;
}
export interface UpdateMapResponse {
    MapName: string;
    MapArn: string;
    UpdateTime: Date;
}
export interface UpdatePlaceIndexRequest {
    IndexName: string;
    PricingPlan?: string;
    Description?: string;
    DataSourceConfiguration?: DataSourceConfiguration;
}
export interface UpdatePlaceIndexResponse {
    IndexName: string;
    IndexArn: string;
    UpdateTime: Date;
}
export interface UpdateRouteCalculatorRequest {
    CalculatorName: string;
    PricingPlan?: string;
    Description?: string;
}
export interface UpdateRouteCalculatorResponse {
    CalculatorName: string;
    CalculatorArn: string;
    UpdateTime: Date;
}
export interface UpdateTrackerRequest {
    TrackerName: string;
    PricingPlan?: string;
    PricingPlanDataSource?: string;
    Description?: string;
    PositionFiltering?: string;
    EventBridgeEnabled?: boolean;
    KmsKeyEnableGeospatialQueries?: boolean;
}
export interface UpdateTrackerResponse {
    TrackerName: string;
    TrackerArn: string;
    UpdateTime: Date;
}
export interface WiFiAccessPoint {
    MacAddress: string;
    Rss: number;
}
export type WiFiAccessPointList = WiFiAccessPoint[];
export type EutranCellId = number;
export type Earfcn = number;
export type Pci = number;
export interface LteLocalId {
    Earfcn: number;
    Pci: number;
}
export type Rsrp = number;
export type Rsrq = number;
export interface LteNetworkMeasurements {
    Earfcn: number;
    CellId: number;
    Pci: number;
    Rsrp?: number;
    Rsrq?: number;
}
export type LteNetworkMeasurementsList = LteNetworkMeasurements[];
export interface LteCellDetails {
    CellId: number;
    Mcc: number;
    Mnc: number;
    LocalId?: LteLocalId;
    NetworkMeasurements?: LteNetworkMeasurements[];
    TimingAdvance?: number;
    NrCapable?: boolean;
    Rsrp?: number;
    Rsrq?: number;
    Tac?: number;
}
export type LteCellDetailsList = LteCellDetails[];
export interface CellSignals {
    LteCellDetails: LteCellDetails[];
}
export interface DeviceState {
    DeviceId: string;
    SampleTime: Date;
    Position: number[];
    Accuracy?: PositionalAccuracy;
    Ipv4Address?: string;
    WiFiAccessPoints?: WiFiAccessPoint[];
    CellSignals?: CellSignals;
}
export interface VerifyDevicePositionRequest {
    TrackerName: string;
    DeviceState: DeviceState;
    DistanceUnit?: string;
}
export interface InferredState {
    Position?: number[];
    Accuracy?: PositionalAccuracy;
    DeviationDistance?: number;
    ProxyDetected: boolean;
}
export interface VerifyDevicePositionResponse {
    InferredState: InferredState;
    DeviceId: string;
    SampleTime: Date;
    ReceivedTime: Date;
    DistanceUnit: string;
}
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    Name: string;
    Message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AssociateTrackerConsumerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an association between a geofence collection and a tracker resource. This allows the tracker resource to communicate location data to the linked geofence collection.
 *
 * You can associate up to five geofence collections to each tracker resource.
 *
 * Currently not supported -- Cross-account configurations, such as creating associations between a tracker resource in one account and a geofence collection in another account.
 */
export declare const associateTrackerConsumer: API.OperationMethod<AssociateTrackerConsumerRequest, AssociateTrackerConsumerResponse, AssociateTrackerConsumerError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteDevicePositionHistoryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the position history of one or more devices from a tracker resource.
 */
export declare const batchDeleteDevicePositionHistory: API.OperationMethod<BatchDeleteDevicePositionHistoryRequest, BatchDeleteDevicePositionHistoryResponse, BatchDeleteDevicePositionHistoryError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteGeofenceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a batch of geofences from a geofence collection.
 *
 * This operation deletes the resource permanently.
 */
export declare const batchDeleteGeofence: API.OperationMethod<BatchDeleteGeofenceRequest, BatchDeleteGeofenceResponse, BatchDeleteGeofenceError, Credentials | HttpClient.HttpClient>;
export type BatchEvaluateGeofencesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Evaluates device positions against the geofence geometries from a given geofence collection.
 *
 * This operation always returns an empty response because geofences are asynchronously evaluated. The evaluation determines if the device has entered or exited a geofenced area, and then publishes one of the following events to Amazon EventBridge:
 *
 * - `ENTER` if Amazon Location determines that the tracked device has entered a geofenced area.
 *
 * - `EXIT` if Amazon Location determines that the tracked device has exited a geofenced area.
 *
 * The last geofence that a device was observed within is tracked for 30 days after the most recent device position update.
 *
 * Geofence evaluation uses the given device position. It does not account for the optional `Accuracy` of a `DevicePositionUpdate`.
 *
 * The `DeviceID` is used as a string to represent the device. You do not need to have a `Tracker` associated with the `DeviceID`.
 */
export declare const batchEvaluateGeofences: API.OperationMethod<BatchEvaluateGeofencesRequest, BatchEvaluateGeofencesResponse, BatchEvaluateGeofencesError, Credentials | HttpClient.HttpClient>;
export type BatchGetDevicePositionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the latest device positions for requested devices.
 */
export declare const batchGetDevicePosition: API.OperationMethod<BatchGetDevicePositionRequest, BatchGetDevicePositionResponse, BatchGetDevicePositionError, Credentials | HttpClient.HttpClient>;
export type BatchPutGeofenceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * A batch request for storing geofence geometries into a given geofence collection, or updates the geometry of an existing geofence if a geofence ID is included in the request.
 */
export declare const batchPutGeofence: API.OperationMethod<BatchPutGeofenceRequest, BatchPutGeofenceResponse, BatchPutGeofenceError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateDevicePositionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Uploads position update data for one or more devices to a tracker resource (up to 10 devices per batch). Amazon Location uses the data when it reports the last known device position and position history. Amazon Location retains location data for 30 days.
 *
 * Position updates are handled based on the `PositionFiltering` property of the tracker. When `PositionFiltering` is set to `TimeBased`, updates are evaluated against linked geofence collections, and location data is stored at a maximum of one position per 30 second interval. If your update frequency is more often than every 30 seconds, only one update per 30 seconds is stored for each unique device ID.
 *
 * When `PositionFiltering` is set to `DistanceBased` filtering, location data is stored and evaluated against linked geofence collections only if the device has moved more than 30 m (98.4 ft).
 *
 * When `PositionFiltering` is set to `AccuracyBased` filtering, location data is stored and evaluated against linked geofence collections only if the device has moved more than the measured accuracy. For example, if two consecutive updates from a device have a horizontal accuracy of 5 m and 10 m, the second update is neither stored or evaluated if the device has moved less than 15 m. If `PositionFiltering` is set to `AccuracyBased` filtering, Amazon Location uses the default value `{ "Horizontal": 0}` when accuracy is not provided on a `DevicePositionUpdate`.
 */
export declare const batchUpdateDevicePosition: API.OperationMethod<BatchUpdateDevicePositionRequest, BatchUpdateDevicePositionResponse, BatchUpdateDevicePositionError, Credentials | HttpClient.HttpClient>;
export type CalculateRouteError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend you upgrade to `CalculateRoutes` or `CalculateIsolines` unless you require Grab data.
 *
 * - `CalculateRoute` is part of a previous Amazon Location Service Routes API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The version 2 `CalculateRoutes` operation gives better results for point-to-point routing, while the version 2 `CalculateIsolines` operation adds support for calculating service areas and travel time envelopes.
 *
 * - If you are using an Amazon Web Services SDK or the Amazon Web Services CLI, note that the Routes API version 2 is found under `geo-routes` or `geo_routes`, not under `location`.
 *
 * - Since Grab is not yet fully supported in Routes API version 2, we recommend you continue using API version 1 when using Grab.
 *
 * Calculates a route given the following required parameters: `DeparturePosition` and `DestinationPosition`. Requires that you first create a route calculator resource.
 *
 * By default, a request that doesn't specify a departure time uses the best time of day to travel with the best traffic conditions when calculating the route.
 *
 * Additional options include:
 *
 * - Specifying a departure time using either `DepartureTime` or `DepartNow`. This calculates a route based on predictive traffic data at the given time.
 *
 * You can't specify both `DepartureTime` and `DepartNow` in a single request. Specifying both parameters returns a validation error.
 *
 * - Specifying a travel mode using TravelMode sets the transportation mode used to calculate the routes. This also lets you specify additional route preferences in `CarModeOptions` if traveling by `Car`, or `TruckModeOptions` if traveling by `Truck`.
 *
 * If you specify `walking` for the travel mode and your data provider is Esri, the start and destination must be within 40km.
 */
export declare const calculateRoute: API.OperationMethod<CalculateRouteRequest, CalculateRouteResponse, CalculateRouteError, Credentials | HttpClient.HttpClient>;
export type CalculateRouteMatrixError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend you upgrade to the V2 `CalculateRouteMatrix` unless you require Grab data.
 *
 * - This version of `CalculateRouteMatrix` is part of a previous Amazon Location Service Routes API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The version 2 `CalculateRouteMatrix` operation gives better results for matrix routing calculations.
 *
 * - If you are using an Amazon Web Services SDK or the Amazon Web Services CLI, note that the Routes API version 2 is found under `geo-routes` or `geo_routes`, not under `location`.
 *
 * - Since Grab is not yet fully supported in Routes API version 2, we recommend you continue using API version 1 when using Grab.
 *
 * - Start your version 2 API journey with the Routes V2 API Reference or the Developer Guide.
 *
 * Calculates a route matrix given the following required parameters: `DeparturePositions` and `DestinationPositions`. `CalculateRouteMatrix` calculates routes and returns the travel time and travel distance from each departure position to each destination position in the request. For example, given departure positions A and B, and destination positions X and Y, `CalculateRouteMatrix` will return time and distance for routes from A to X, A to Y, B to X, and B to Y (in that order). The number of results returned (and routes calculated) will be the number of `DeparturePositions` times the number of `DestinationPositions`.
 *
 * Your account is charged for each route calculated, not the number of requests.
 *
 * Requires that you first create a route calculator resource.
 *
 * By default, a request that doesn't specify a departure time uses the best time of day to travel with the best traffic conditions when calculating routes.
 *
 * Additional options include:
 *
 * - Specifying a departure time using either `DepartureTime` or `DepartNow`. This calculates routes based on predictive traffic data at the given time.
 *
 * You can't specify both `DepartureTime` and `DepartNow` in a single request. Specifying both parameters returns a validation error.
 *
 * - Specifying a travel mode using TravelMode sets the transportation mode used to calculate the routes. This also lets you specify additional route preferences in `CarModeOptions` if traveling by `Car`, or `TruckModeOptions` if traveling by `Truck`.
 */
export declare const calculateRouteMatrix: API.OperationMethod<CalculateRouteMatrixRequest, CalculateRouteMatrixResponse, CalculateRouteMatrixError, Credentials | HttpClient.HttpClient>;
export type CancelJobError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | ResourceNotFoundException | CommonErrors;
/**
 * `CancelJob` cancels a job that is currently running or pending. If the job is already in a terminal state (`Completed`, `Failed`, or `Cancelled`), the operation returns successfully with the current status.
 *
 * For more information, see Job concepts in the *Amazon Location Service Developer Guide*.
 */
export declare const cancelJob: API.OperationMethod<CancelJobRequest, CancelJobResponse, CancelJobError, Credentials | HttpClient.HttpClient>;
export type CreateGeofenceCollectionError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a geofence collection, which manages and stores geofences.
 */
export declare const createGeofenceCollection: API.OperationMethod<CreateGeofenceCollectionRequest, CreateGeofenceCollectionResponse, CreateGeofenceCollectionError, Credentials | HttpClient.HttpClient>;
export type CreateKeyError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an API key resource in your Amazon Web Services account, which lets you grant actions for Amazon Location resources to the API key bearer.
 *
 * For more information, see Use API keys to authenticate in the *Amazon Location Service Developer Guide*.
 */
export declare const createKey: API.OperationMethod<CreateKeyRequest, CreateKeyResponse, CreateKeyError, Credentials | HttpClient.HttpClient>;
export type CreateMapError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend upgrading to the Maps API V2 unless you require `Grab` data.
 *
 * - `CreateMap` is part of a previous Amazon Location Service Maps API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The Maps API version 2 has a simplified interface that can be used without creating or managing map resources.
 *
 * - If you are using an AWS SDK or the AWS CLI, note that the Maps API version 2 is found under `geo-maps` or `geo_maps`, not under `location`.
 *
 * - Since `Grab` is not yet fully supported in Maps API version 2, we recommend you continue using API version 1 when using `Grab`.
 *
 * - Start your version 2 API journey with the Maps V2 API Reference or the Developer Guide.
 *
 * Creates a map resource in your Amazon Web Services account, which provides map tiles of different styles sourced from global location data providers.
 *
 * If your application is tracking or routing assets you use in your business, such as delivery vehicles or employees, you must not use Esri as your geolocation provider. See section 82 of the Amazon Web Services service terms for more details.
 */
export declare const createMap: API.OperationMethod<CreateMapRequest, CreateMapResponse, CreateMapError, Credentials | HttpClient.HttpClient>;
export type CreatePlaceIndexError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend you upgrade to the Places API V2 unless you require Grab data.
 *
 * - `CreatePlaceIndex` is part of a previous Amazon Location Service Places API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The Places API version 2 has a simplified interface that can be used without creating or managing place index resources.
 *
 * - If you are using an Amazon Web Services SDK or the Amazon Web Services CLI, note that the Places API version 2 is found under `geo-places` or `geo_places`, not under `location`.
 *
 * - Since Grab is not yet fully supported in Places API version 2, we recommend you continue using API version 1 when using Grab.
 *
 * - Start your version 2 API journey with the Places V2 API Reference or the Developer Guide.
 *
 * Creates a place index resource in your Amazon Web Services account. Use a place index resource to geocode addresses and other text queries by using the `SearchPlaceIndexForText` operation, and reverse geocode coordinates by using the `SearchPlaceIndexForPosition` operation, and enable autosuggestions by using the `SearchPlaceIndexForSuggestions` operation.
 *
 * If your application is tracking or routing assets you use in your business, such as delivery vehicles or employees, you must not use Esri as your geolocation provider. See section 82 of the Amazon Web Services service terms for more details.
 */
export declare const createPlaceIndex: API.OperationMethod<CreatePlaceIndexRequest, CreatePlaceIndexResponse, CreatePlaceIndexError, Credentials | HttpClient.HttpClient>;
export type CreateRouteCalculatorError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend you upgrade to the Routes API V2 unless you require Grab data.
 *
 * - `CreateRouteCalculator` is part of a previous Amazon Location Service Routes API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The Routes API version 2 has a simplified interface that can be used without creating or managing route calculator resources.
 *
 * - If you are using an Amazon Web Services SDK or the Amazon Web Services CLI, note that the Routes API version 2 is found under `geo-routes` or `geo_routes`, not under `location`.
 *
 * - Since Grab is not yet fully supported in Routes API version 2, we recommend you continue using API version 1 when using Grab.
 *
 * - Start your version 2 API journey with the Routes V2 API Reference or the Developer Guide.
 *
 * Creates a route calculator resource in your Amazon Web Services account.
 *
 * You can send requests to a route calculator resource to estimate travel time, distance, and get directions. A route calculator sources traffic and road network data from your chosen data provider.
 *
 * If your application is tracking or routing assets you use in your business, such as delivery vehicles or employees, you must not use Esri as your geolocation provider. See section 82 of the Amazon Web Services service terms for more details.
 */
export declare const createRouteCalculator: API.OperationMethod<CreateRouteCalculatorRequest, CreateRouteCalculatorResponse, CreateRouteCalculatorError, Credentials | HttpClient.HttpClient>;
export type CreateTrackerError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a tracker resource in your Amazon Web Services account, which lets you retrieve current and historical location of devices.
 */
export declare const createTracker: API.OperationMethod<CreateTrackerRequest, CreateTrackerResponse, CreateTrackerError, Credentials | HttpClient.HttpClient>;
export type DeleteGeofenceCollectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a geofence collection from your Amazon Web Services account.
 *
 * This operation deletes the resource permanently. If the geofence collection is the target of a tracker resource, the devices will no longer be monitored.
 */
export declare const deleteGeofenceCollection: API.OperationMethod<DeleteGeofenceCollectionRequest, DeleteGeofenceCollectionResponse, DeleteGeofenceCollectionError, Credentials | HttpClient.HttpClient>;
export type DeleteKeyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified API key. The API key must have been deactivated more than 90 days previously.
 *
 * For more information, see Use API keys to authenticate in the *Amazon Location Service Developer Guide*.
 */
export declare const deleteKey: API.OperationMethod<DeleteKeyRequest, DeleteKeyResponse, DeleteKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteMapError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend upgrading to the Maps API V2 unless you require `Grab` data.
 *
 * - `DeleteMap` is part of a previous Amazon Location Service Maps API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The Maps API version 2 has a simplified interface that can be used without creating or managing map resources.
 *
 * - If you are using an AWS SDK or the AWS CLI, note that the Maps API version 2 is found under `geo-maps` or `geo_maps`, not under `location`.
 *
 * - Since `Grab` is not yet fully supported in Maps API version 2, we recommend you continue using API version 1 when using `Grab`.
 *
 * - Start your version 2 API journey with the Maps V2 API Reference or the Developer Guide.
 *
 * Deletes a map resource from your Amazon Web Services account.
 *
 * This operation deletes the resource permanently. If the map is being used in an application, the map may not render.
 */
export declare const deleteMap: API.OperationMethod<DeleteMapRequest, DeleteMapResponse, DeleteMapError, Credentials | HttpClient.HttpClient>;
export type DeletePlaceIndexError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend you upgrade to the Places API V2 unless you require Grab data.
 *
 * - `DeletePlaceIndex` is part of a previous Amazon Location Service Places API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The Places API version 2 has a simplified interface that can be used without creating or managing place index resources.
 *
 * - If you are using an Amazon Web Services SDK or the Amazon Web Services CLI, note that the Places API version 2 is found under `geo-places` or `geo_places`, not under `location`.
 *
 * - Since Grab is not yet fully supported in Places API version 2, we recommend you continue using API version 1 when using Grab.
 *
 * - Start your version 2 API journey with the Places V2 API Reference or the Developer Guide.
 *
 * Deletes a place index resource from your Amazon Web Services account.
 *
 * This operation deletes the resource permanently.
 */
export declare const deletePlaceIndex: API.OperationMethod<DeletePlaceIndexRequest, DeletePlaceIndexResponse, DeletePlaceIndexError, Credentials | HttpClient.HttpClient>;
export type DeleteRouteCalculatorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend you upgrade to the Routes API V2 unless you require Grab data.
 *
 * - `DeleteRouteCalculator` is part of a previous Amazon Location Service Routes API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The Routes API version 2 has a simplified interface that can be used without creating or managing route calculator resources.
 *
 * - If you are using an Amazon Web Services SDK or the Amazon Web Services CLI, note that the Routes API version 2 is found under `geo-routes` or `geo_routes`, not under `location`.
 *
 * - Since Grab is not yet fully supported in Routes API version 2, we recommend you continue using API version 1 when using Grab.
 *
 * - Start your version 2 API journey with the Routes V2 API Reference or the Developer Guide.
 *
 * Deletes a route calculator resource from your Amazon Web Services account.
 *
 * This operation deletes the resource permanently.
 */
export declare const deleteRouteCalculator: API.OperationMethod<DeleteRouteCalculatorRequest, DeleteRouteCalculatorResponse, DeleteRouteCalculatorError, Credentials | HttpClient.HttpClient>;
export type DeleteTrackerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a tracker resource from your Amazon Web Services account.
 *
 * This operation deletes the resource permanently. If the tracker resource is in use, you may encounter an error. Make sure that the target resource isn't a dependency for your applications.
 */
export declare const deleteTracker: API.OperationMethod<DeleteTrackerRequest, DeleteTrackerResponse, DeleteTrackerError, Credentials | HttpClient.HttpClient>;
export type DescribeGeofenceCollectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the geofence collection details.
 */
export declare const describeGeofenceCollection: API.OperationMethod<DescribeGeofenceCollectionRequest, DescribeGeofenceCollectionResponse, DescribeGeofenceCollectionError, Credentials | HttpClient.HttpClient>;
export type DescribeKeyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the API key resource details.
 *
 * For more information, see Use API keys to authenticate in the *Amazon Location Service Developer Guide*.
 */
export declare const describeKey: API.OperationMethod<DescribeKeyRequest, DescribeKeyResponse, DescribeKeyError, Credentials | HttpClient.HttpClient>;
export type DescribeMapError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend upgrading to the Maps API V2 unless you require `Grab` data.
 *
 * - `DescribeMap` is part of a previous Amazon Location Service Maps API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The Maps API version 2 has a simplified interface that can be used without creating or managing map resources.
 *
 * - If you are using an AWS SDK or the AWS CLI, note that the Maps API version 2 is found under `geo-maps` or `geo_maps`, not under `location`.
 *
 * - Since `Grab` is not yet fully supported in Maps API version 2, we recommend you continue using API version 1 when using `Grab`.
 *
 * - Start your version 2 API journey with the Maps V2 API Reference or the Developer Guide.
 *
 * Retrieves the map resource details.
 */
export declare const describeMap: API.OperationMethod<DescribeMapRequest, DescribeMapResponse, DescribeMapError, Credentials | HttpClient.HttpClient>;
export type DescribePlaceIndexError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend you upgrade to the Places API V2 unless you require Grab data.
 *
 * - `DescribePlaceIndex` is part of a previous Amazon Location Service Places API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The Places API version 2 has a simplified interface that can be used without creating or managing place index resources.
 *
 * - If you are using an Amazon Web Services SDK or the Amazon Web Services CLI, note that the Places API version 2 is found under `geo-places` or `geo_places`, not under `location`.
 *
 * - Since Grab is not yet fully supported in Places API version 2, we recommend you continue using API version 1 when using Grab.
 *
 * - Start your version 2 API journey with the Places V2 API Reference or the Developer Guide.
 *
 * Retrieves the place index resource details.
 */
export declare const describePlaceIndex: API.OperationMethod<DescribePlaceIndexRequest, DescribePlaceIndexResponse, DescribePlaceIndexError, Credentials | HttpClient.HttpClient>;
export type DescribeRouteCalculatorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend you upgrade to the Routes API V2 unless you require Grab data.
 *
 * - `DescribeRouteCalculator` is part of a previous Amazon Location Service Routes API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The Routes API version 2 has a simplified interface that can be used without creating or managing route calculator resources.
 *
 * - If you are using an Amazon Web Services SDK or the Amazon Web Services CLI, note that the Routes API version 2 is found under `geo-routes` or `geo_routes`, not under `location`.
 *
 * - Since Grab is not yet fully supported in Routes API version 2, we recommend you continue using API version 1 when using Grab.
 *
 * - Start your version 2 API journey with the Routes V2 API Reference or the Developer Guide.
 *
 * Retrieves the route calculator resource details.
 */
export declare const describeRouteCalculator: API.OperationMethod<DescribeRouteCalculatorRequest, DescribeRouteCalculatorResponse, DescribeRouteCalculatorError, Credentials | HttpClient.HttpClient>;
export type DescribeTrackerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the tracker resource details.
 */
export declare const describeTracker: API.OperationMethod<DescribeTrackerRequest, DescribeTrackerResponse, DescribeTrackerError, Credentials | HttpClient.HttpClient>;
export type DisassociateTrackerConsumerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the association between a tracker resource and a geofence collection.
 *
 * Once you unlink a tracker resource from a geofence collection, the tracker positions will no longer be automatically evaluated against geofences.
 */
export declare const disassociateTrackerConsumer: API.OperationMethod<DisassociateTrackerConsumerRequest, DisassociateTrackerConsumerResponse, DisassociateTrackerConsumerError, Credentials | HttpClient.HttpClient>;
export type ForecastGeofenceEventsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This action forecasts future geofence events that are likely to occur within a specified time horizon if a device continues moving at its current speed. Each forecasted event is associated with a geofence from a provided geofence collection. A forecast event can have one of the following states:
 *
 * `ENTER`: The device position is outside the referenced geofence, but the device may cross into the geofence during the forecasting time horizon if it maintains its current speed.
 *
 * `EXIT`: The device position is inside the referenced geofence, but the device may leave the geofence during the forecasted time horizon if the device maintains it's current speed.
 *
 * `IDLE`:The device is inside the geofence, and it will remain inside the geofence through the end of the time horizon if the device maintains it's current speed.
 *
 * Heading direction is not considered in the current version. The API takes a conservative approach and includes events that can occur for any heading.
 */
export declare const forecastGeofenceEvents: API.PaginatedOperationMethod<ForecastGeofenceEventsRequest, ForecastGeofenceEventsResponse, ForecastGeofenceEventsError, Credentials | HttpClient.HttpClient, ForecastedEvent>;
export type GetDevicePositionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a device's most recent position according to its sample time.
 *
 * Device positions are deleted after 30 days.
 */
export declare const getDevicePosition: API.OperationMethod<GetDevicePositionRequest, GetDevicePositionResponse, GetDevicePositionError, Credentials | HttpClient.HttpClient>;
export type GetDevicePositionHistoryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the device position history from a tracker resource within a specified range of time.
 *
 * Device positions are deleted after 30 days.
 */
export declare const getDevicePositionHistory: API.PaginatedOperationMethod<GetDevicePositionHistoryRequest, GetDevicePositionHistoryResponse, GetDevicePositionHistoryError, Credentials | HttpClient.HttpClient, DevicePosition>;
export type GetGeofenceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the geofence details from a geofence collection.
 *
 * The returned geometry will always match the geometry format used when the geofence was created.
 */
export declare const getGeofence: API.OperationMethod<GetGeofenceRequest, GetGeofenceResponse, GetGeofenceError, Credentials | HttpClient.HttpClient>;
export type GetJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `GetJob` retrieves detailed information about a specific job, including its current status, configuration, and error information if the job failed.
 *
 * For more information, see Job concepts in the *Amazon Location Service Developer Guide*.
 */
export declare const getJob: API.OperationMethod<GetJobRequest, GetJobResponse, GetJobError, Credentials | HttpClient.HttpClient>;
export type GetMapGlyphsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend upgrading to `GetGlyphs` unless you require `Grab` data.
 *
 * - `GetMapGlyphs` is part of a previous Amazon Location Service Maps API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The version 2 `GetGlyphs` operation gives a better user experience and is compatible with the remainder of the V2 Maps API.
 *
 * - If you are using an AWS SDK or the AWS CLI, note that the Maps API version 2 is found under `geo-maps` or `geo_maps`, not under `location`.
 *
 * - Since `Grab` is not yet fully supported in Maps API version 2, we recommend you continue using API version 1 when using `Grab`.
 *
 * - Start your version 2 API journey with the Maps V2 API Reference or the Developer Guide.
 *
 * Retrieves glyphs used to display labels on a map.
 */
export declare const getMapGlyphs: API.OperationMethod<GetMapGlyphsRequest, GetMapGlyphsResponse, GetMapGlyphsError, Credentials | HttpClient.HttpClient>;
export type GetMapSpritesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend upgrading to `GetSprites` unless you require `Grab` data.
 *
 * - `GetMapSprites` is part of a previous Amazon Location Service Maps API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The version 2 `GetSprites` operation gives a better user experience and is compatible with the remainder of the V2 Maps API.
 *
 * - If you are using an AWS SDK or the AWS CLI, note that the Maps API version 2 is found under `geo-maps` or `geo_maps`, not under `location`.
 *
 * - Since `Grab` is not yet fully supported in Maps API version 2, we recommend you continue using API version 1 when using `Grab`.
 *
 * - Start your version 2 API journey with the Maps V2 API Reference or the Developer Guide.
 *
 * Retrieves the sprite sheet corresponding to a map resource. The sprite sheet is a PNG image paired with a JSON document describing the offsets of individual icons that will be displayed on a rendered map.
 */
export declare const getMapSprites: API.OperationMethod<GetMapSpritesRequest, GetMapSpritesResponse, GetMapSpritesError, Credentials | HttpClient.HttpClient>;
export type GetMapStyleDescriptorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend upgrading to `GetStyleDescriptor` unless you require `Grab` data.
 *
 * - `GetMapStyleDescriptor` is part of a previous Amazon Location Service Maps API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The version 2 `GetStyleDescriptor` operation gives a better user experience and is compatible with the remainder of the V2 Maps API.
 *
 * - If you are using an AWS SDK or the AWS CLI, note that the Maps API version 2 is found under `geo-maps` or `geo_maps`, not under `location`.
 *
 * - Since `Grab` is not yet fully supported in Maps API version 2, we recommend you continue using API version 1 when using `Grab`.
 *
 * - Start your version 2 API journey with the Maps V2 API Reference or the Developer Guide.
 *
 * Retrieves the map style descriptor from a map resource.
 *
 * The style descriptor contains speciU+FB01cations on how features render on a map. For example, what data to display, what order to display the data in, and the style for the data. Style descriptors follow the Mapbox Style Specification.
 */
export declare const getMapStyleDescriptor: API.OperationMethod<GetMapStyleDescriptorRequest, GetMapStyleDescriptorResponse, GetMapStyleDescriptorError, Credentials | HttpClient.HttpClient>;
export type GetMapTileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend upgrading to `GetTile` unless you require `Grab` data.
 *
 * - `GetMapTile` is part of a previous Amazon Location Service Maps API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The version 2 `GetTile` operation gives a better user experience and is compatible with the remainder of the V2 Maps API.
 *
 * - If you are using an AWS SDK or the AWS CLI, note that the Maps API version 2 is found under `geo-maps` or `geo_maps`, not under `location`.
 *
 * - Since `Grab` is not yet fully supported in Maps API version 2, we recommend you continue using API version 1 when using `Grab`.
 *
 * - Start your version 2 API journey with the Maps V2 API Reference or the Developer Guide.
 *
 * Retrieves a vector data tile from the map resource. Map tiles are used by clients to render a map. they're addressed using a grid arrangement with an X coordinate, Y coordinate, and Z (zoom) level.
 *
 * The origin (0, 0) is the top left of the map. Increasing the zoom level by 1 doubles both the X and Y dimensions, so a tile containing data for the entire world at (0/0/0) will be split into 4 tiles at zoom 1 (1/0/0, 1/0/1, 1/1/0, 1/1/1).
 */
export declare const getMapTile: API.OperationMethod<GetMapTileRequest, GetMapTileResponse, GetMapTileError, Credentials | HttpClient.HttpClient>;
export type GetPlaceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend you upgrade to the V2 `GetPlace` operation unless you require Grab data.
 *
 * - This version of `GetPlace` is part of a previous Amazon Location Service Places API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - Version 2 of the `GetPlace` operation interoperates with the rest of the Places V2 API, while this version does not.
 *
 * - If you are using an Amazon Web Services SDK or the Amazon Web Services CLI, note that the Places API version 2 is found under `geo-places` or `geo_places`, not under `location`.
 *
 * - Since Grab is not yet fully supported in Places API version 2, we recommend you continue using API version 1 when using Grab.
 *
 * - Start your version 2 API journey with the Places V2 API Reference or the Developer Guide.
 *
 * Finds a place by its unique ID. A `PlaceId` is returned by other search operations.
 *
 * A PlaceId is valid only if all of the following are the same in the original search request and the call to `GetPlace`.
 *
 * - Customer Amazon Web Services account
 *
 * - Amazon Web Services Region
 *
 * - Data provider specified in the place index resource
 *
 * If your Place index resource is configured with Grab as your geolocation provider and Storage as Intended use, the GetPlace operation is unavailable. For more information, see AWS service terms.
 */
export declare const getPlace: API.OperationMethod<GetPlaceRequest, GetPlaceResponse, GetPlaceError, Credentials | HttpClient.HttpClient>;
export type ListDevicePositionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * A batch request to retrieve all device positions.
 */
export declare const listDevicePositions: API.PaginatedOperationMethod<ListDevicePositionsRequest, ListDevicePositionsResponse, ListDevicePositionsError, Credentials | HttpClient.HttpClient, ListDevicePositionsResponseEntry>;
export type ListGeofenceCollectionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists geofence collections in your Amazon Web Services account.
 */
export declare const listGeofenceCollections: API.PaginatedOperationMethod<ListGeofenceCollectionsRequest, ListGeofenceCollectionsResponse, ListGeofenceCollectionsError, Credentials | HttpClient.HttpClient, ListGeofenceCollectionsResponseEntry>;
export type ListGeofencesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists geofences stored in a given geofence collection.
 */
export declare const listGeofences: API.PaginatedOperationMethod<ListGeofencesRequest, ListGeofencesResponse, ListGeofencesError, Credentials | HttpClient.HttpClient, ListGeofenceResponseEntry>;
export type ListJobsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `ListJobs` retrieves a list of jobs with optional filtering and pagination support.
 *
 * For more information, see Job concepts in the *Amazon Location Service Developer Guide*.
 */
export declare const listJobs: API.PaginatedOperationMethod<ListJobsRequest, ListJobsResponse, ListJobsError, Credentials | HttpClient.HttpClient, ListJobsResponseEntry>;
export type ListKeysError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists API key resources in your Amazon Web Services account.
 *
 * For more information, see Use API keys to authenticate in the *Amazon Location Service Developer Guide*.
 */
export declare const listKeys: API.PaginatedOperationMethod<ListKeysRequest, ListKeysResponse, ListKeysError, Credentials | HttpClient.HttpClient, ListKeysResponseEntry>;
export type ListMapsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend upgrading to the Maps API V2 unless you require `Grab` data.
 *
 * - `ListMaps` is part of a previous Amazon Location Service Maps API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The Maps API version 2 has a simplified interface that can be used without creating or managing map resources.
 *
 * - If you are using an AWS SDK or the AWS CLI, note that the Maps API version 2 is found under `geo-maps` or `geo_maps`, not under `location`.
 *
 * - Since `Grab` is not yet fully supported in Maps API version 2, we recommend you continue using API version 1 when using `Grab`.
 *
 * - Start your version 2 API journey with the Maps V2 API Reference or the Developer Guide.
 *
 * Lists map resources in your Amazon Web Services account.
 */
export declare const listMaps: API.PaginatedOperationMethod<ListMapsRequest, ListMapsResponse, ListMapsError, Credentials | HttpClient.HttpClient, ListMapsResponseEntry>;
export type ListPlaceIndexesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend you upgrade to the Places API V2 unless you require Grab data.
 *
 * - `ListPlaceIndexes` is part of a previous Amazon Location Service Places API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The Places API version 2 has a simplified interface that can be used without creating or managing place index resources.
 *
 * - If you are using an Amazon Web Services SDK or the Amazon Web Services CLI, note that the Places API version 2 is found under `geo-places` or `geo_places`, not under `location`.
 *
 * - Since Grab is not yet fully supported in Places API version 2, we recommend you continue using API version 1 when using Grab.
 *
 * - Start your version 2 API journey with the Places V2 API Reference or the Developer Guide.
 *
 * Lists place index resources in your Amazon Web Services account.
 */
export declare const listPlaceIndexes: API.PaginatedOperationMethod<ListPlaceIndexesRequest, ListPlaceIndexesResponse, ListPlaceIndexesError, Credentials | HttpClient.HttpClient, ListPlaceIndexesResponseEntry>;
export type ListRouteCalculatorsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend you upgrade to the Routes API V2 unless you require Grab data.
 *
 * - `ListRouteCalculators` is part of a previous Amazon Location Service Routes API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The Routes API version 2 has a simplified interface that can be used without creating or managing route calculator resources.
 *
 * - If you are using an Amazon Web Services SDK or the Amazon Web Services CLI, note that the Routes API version 2 is found under `geo-routes` or `geo_routes`, not under `location`.
 *
 * - Since Grab is not yet fully supported in Routes API version 2, we recommend you continue using API version 1 when using Grab.
 *
 * - Start your version 2 API journey with the Routes V2 API Reference or the Developer Guide.
 *
 * Lists route calculator resources in your Amazon Web Services account.
 */
export declare const listRouteCalculators: API.PaginatedOperationMethod<ListRouteCalculatorsRequest, ListRouteCalculatorsResponse, ListRouteCalculatorsError, Credentials | HttpClient.HttpClient, ListRouteCalculatorsResponseEntry>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of tags that are applied to the specified Amazon Location resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTrackerConsumersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists geofence collections currently associated to the given tracker resource.
 */
export declare const listTrackerConsumers: API.PaginatedOperationMethod<ListTrackerConsumersRequest, ListTrackerConsumersResponse, ListTrackerConsumersError, Credentials | HttpClient.HttpClient, Arn>;
export type ListTrackersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists tracker resources in your Amazon Web Services account.
 */
export declare const listTrackers: API.PaginatedOperationMethod<ListTrackersRequest, ListTrackersResponse, ListTrackersError, Credentials | HttpClient.HttpClient, ListTrackersResponseEntry>;
export type PutGeofenceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stores a geofence geometry in a given geofence collection, or updates the geometry of an existing geofence if a geofence ID is included in the request.
 */
export declare const putGeofence: API.OperationMethod<PutGeofenceRequest, PutGeofenceResponse, PutGeofenceError, Credentials | HttpClient.HttpClient>;
export type SearchPlaceIndexForPositionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend you upgrade to `ReverseGeocode` or `SearchNearby` unless you require Grab data.
 *
 * - `SearchPlaceIndexForPosition` is part of a previous Amazon Location Service Places API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The version 2 `ReverseGeocode` operation gives better results in the address reverse-geocoding use case, while the version 2 `SearchNearby` operation gives better results when searching for businesses and points of interest near a specific location.
 *
 * - If you are using an Amazon Web Services SDK or the Amazon Web Services CLI, note that the Places API version 2 is found under `geo-places` or `geo_places`, not under `location`.
 *
 * - Since Grab is not yet fully supported in Places API version 2, we recommend you continue using API version 1 when using Grab.
 *
 * Reverse geocodes a given coordinate and returns a legible address. Allows you to search for Places or points of interest near a given position.
 */
export declare const searchPlaceIndexForPosition: API.OperationMethod<SearchPlaceIndexForPositionRequest, SearchPlaceIndexForPositionResponse, SearchPlaceIndexForPositionError, Credentials | HttpClient.HttpClient>;
export type SearchPlaceIndexForSuggestionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend you upgrade to `Suggest` or `Autocomplete` unless you require Grab data.
 *
 * - `SearchPlaceIndexForSuggestions` is part of a previous Amazon Location Service Places API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The version 2 `Suggest` operation gives better results for typeahead place search suggestions with fuzzy matching, while the version 2 `Autocomplete` operation gives better results for address completion based on partial input.
 *
 * - If you are using an Amazon Web Services SDK or the Amazon Web Services CLI, note that the Places API version 2 is found under `geo-places` or `geo_places`, not under `location`.
 *
 * - Since Grab is not yet fully supported in Places API version 2, we recommend you continue using API version 1 when using Grab.
 *
 * Generates suggestions for addresses and points of interest based on partial or misspelled free-form text. This operation is also known as autocomplete, autosuggest, or fuzzy matching.
 *
 * Optional parameters let you narrow your search results by bounding box or country, or bias your search toward a specific position on the globe.
 *
 * You can search for suggested place names near a specified position by using `BiasPosition`, or filter results within a bounding box by using `FilterBBox`. These parameters are mutually exclusive; using both `BiasPosition` and `FilterBBox` in the same command returns an error.
 */
export declare const searchPlaceIndexForSuggestions: API.OperationMethod<SearchPlaceIndexForSuggestionsRequest, SearchPlaceIndexForSuggestionsResponse, SearchPlaceIndexForSuggestionsError, Credentials | HttpClient.HttpClient>;
export type SearchPlaceIndexForTextError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend you upgrade to `Geocode` or `SearchText` unless you require Grab data.
 *
 * - `SearchPlaceIndexForText` is part of a previous Amazon Location Service Places API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The version 2 `Geocode` operation gives better results in the address geocoding use case, while the version 2 `SearchText` operation gives better results when searching for businesses and points of interest.
 *
 * - If you are using an Amazon Web Services SDK or the Amazon Web Services CLI, note that the Places API version 2 is found under `geo-places` or `geo_places`, not under `location`.
 *
 * - Since Grab is not yet fully supported in Places API version 2, we recommend you continue using API version 1 when using Grab.
 *
 * Geocodes free-form text, such as an address, name, city, or region to allow you to search for Places or points of interest.
 *
 * Optional parameters let you narrow your search results by bounding box or country, or bias your search toward a specific position on the globe.
 *
 * You can search for places near a given position using `BiasPosition`, or filter results within a bounding box using `FilterBBox`. Providing both parameters simultaneously returns an error.
 *
 * Search results are returned in order of highest to lowest relevance.
 */
export declare const searchPlaceIndexForText: API.OperationMethod<SearchPlaceIndexForTextRequest, SearchPlaceIndexForTextResponse, SearchPlaceIndexForTextError, Credentials | HttpClient.HttpClient>;
export type StartJobError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `StartJob` starts a new asynchronous bulk processing job. You specify the input data location in Amazon S3, the action to perform, and the output location where results are written.
 *
 * For more information, see Job concepts in the *Amazon Location Service Developer Guide*.
 */
export declare const startJob: API.OperationMethod<StartJobRequest, StartJobResponse, StartJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified Amazon Location Service resource.
 *
 * Tags can help you organize and categorize your resources. You can also use them to scope user permissions, by granting a user permission to access or change only resources with certain tag values.
 *
 * You can use the `TagResource` operation with an Amazon Location Service resource that already has tags. If you specify a new tag key for the resource, this tag is appended to the tags already associated with the resource. If you specify a tag key that's already associated with the resource, the new tag value that you specify replaces the previous value for that tag.
 *
 * You can associate up to 50 tags with a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from the specified Amazon Location resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateGeofenceCollectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified properties of a given geofence collection.
 */
export declare const updateGeofenceCollection: API.OperationMethod<UpdateGeofenceCollectionRequest, UpdateGeofenceCollectionResponse, UpdateGeofenceCollectionError, Credentials | HttpClient.HttpClient>;
export type UpdateKeyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified properties of a given API key resource.
 */
export declare const updateKey: API.OperationMethod<UpdateKeyRequest, UpdateKeyResponse, UpdateKeyError, Credentials | HttpClient.HttpClient>;
export type UpdateMapError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend upgrading to the Maps API V2 unless you require `Grab` data.
 *
 * - `UpdateMap` is part of a previous Amazon Location Service Maps API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The Maps API version 2 has a simplified interface that can be used without creating or managing map resources.
 *
 * - If you are using an AWS SDK or the AWS CLI, note that the Maps API version 2 is found under `geo-maps` or `geo_maps`, not under `location`.
 *
 * - Since `Grab` is not yet fully supported in Maps API version 2, we recommend you continue using API version 1 when using `Grab`.
 *
 * - Start your version 2 API journey with the Maps V2 API Reference or the Developer Guide.
 *
 * Updates the specified properties of a given map resource.
 */
export declare const updateMap: API.OperationMethod<UpdateMapRequest, UpdateMapResponse, UpdateMapError, Credentials | HttpClient.HttpClient>;
export type UpdatePlaceIndexError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend you upgrade to the Places API V2 unless you require Grab data.
 *
 * - `UpdatePlaceIndex` is part of a previous Amazon Location Service Places API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The Places API version 2 has a simplified interface that can be used without creating or managing place index resources.
 *
 * - If you are using an Amazon Web Services SDK or the Amazon Web Services CLI, note that the Places API version 2 is found under `geo-places` or `geo_places`, not under `location`.
 *
 * - Since Grab is not yet fully supported in Places API version 2, we recommend you continue using API version 1 when using Grab.
 *
 * - Start your version 2 API journey with the Places V2 API Reference or the Developer Guide.
 *
 * Updates the specified properties of a given place index resource.
 */
export declare const updatePlaceIndex: API.OperationMethod<UpdatePlaceIndexRequest, UpdatePlaceIndexResponse, UpdatePlaceIndexError, Credentials | HttpClient.HttpClient>;
export type UpdateRouteCalculatorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation is no longer current and may be deprecated in the future. We recommend you upgrade to the Routes API V2 unless you require Grab data.
 *
 * - `UpdateRouteCalculator` is part of a previous Amazon Location Service Routes API (version 1) which has been superseded by a more intuitive, powerful, and complete API (version 2).
 *
 * - The Routes API version 2 has a simplified interface that can be used without creating or managing route calculator resources.
 *
 * - If you are using an Amazon Web Services SDK or the Amazon Web Services CLI, note that the Routes API version 2 is found under `geo-routes` or `geo_routes`, not under `location`.
 *
 * - Since Grab is not yet fully supported in Routes API version 2, we recommend you continue using API version 1 when using Grab.
 *
 * - Start your version 2 API journey with the Routes V2 API Reference or the Developer Guide.
 *
 * Updates the specified properties for a given route calculator resource.
 */
export declare const updateRouteCalculator: API.OperationMethod<UpdateRouteCalculatorRequest, UpdateRouteCalculatorResponse, UpdateRouteCalculatorError, Credentials | HttpClient.HttpClient>;
export type UpdateTrackerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified properties of a given tracker resource.
 */
export declare const updateTracker: API.OperationMethod<UpdateTrackerRequest, UpdateTrackerResponse, UpdateTrackerError, Credentials | HttpClient.HttpClient>;
export type VerifyDevicePositionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Verifies the integrity of the device's position by determining if it was reported behind a proxy, and by comparing it to an inferred position estimated based on the device's state.
 *
 * The Location Integrity SDK provides enhanced features related to device verification, and it is available for use by request. To get access to the SDK, contact Sales Support.
 */
export declare const verifyDevicePosition: API.OperationMethod<VerifyDevicePositionRequest, VerifyDevicePositionResponse, VerifyDevicePositionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=location.d.ts.map