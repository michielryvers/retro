import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials as Creds } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const DeveloperUserAlreadyRegisteredException_base: S.TaggedErrorClass<"DeveloperUserAlreadyRegisteredException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DeveloperUserAlreadyRegisteredException extends /*@__PURE__*/ DeveloperUserAlreadyRegisteredException_base {
}
declare const ExternalServiceException_base: S.TaggedErrorClass<"ExternalServiceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ExternalServiceException extends /*@__PURE__*/ ExternalServiceException_base {
}
declare const InternalErrorException_base: S.TaggedErrorClass<"InternalErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalErrorException extends /*@__PURE__*/ InternalErrorException_base {
}
declare const InvalidIdentityPoolConfigurationException_base: S.TaggedErrorClass<"InvalidIdentityPoolConfigurationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidIdentityPoolConfigurationException extends /*@__PURE__*/ InvalidIdentityPoolConfigurationException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NotAuthorizedException_base: S.TaggedErrorClass<"NotAuthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class NotAuthorizedException extends /*@__PURE__*/ NotAuthorizedException_base {
}
declare const ResourceConflictException_base: S.TaggedErrorClass<"ResourceConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceConflictException extends /*@__PURE__*/ ResourceConflictException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type IdentityPoolName = string;
export type IdentityPoolUnauthenticated = boolean;
export type ClassicFlow = boolean;
export type IdentityProviderName = string;
export type IdentityProviderId = string;
export type IdentityProviders = {
    [key: string]: string | undefined;
};
export type DeveloperProviderName = string;
export type ARNString = string;
export type OIDCProviderList = string[];
export type CognitoIdentityProviderName = string;
export type CognitoIdentityProviderClientId = string;
export type CognitoIdentityProviderTokenCheck = boolean;
export interface CognitoIdentityProvider {
    ProviderName?: string;
    ClientId?: string;
    ServerSideTokenCheck?: boolean;
}
export type CognitoIdentityProviderList = CognitoIdentityProvider[];
export type SAMLProviderList = string[];
export type TagKeysType = string;
export type TagValueType = string;
export type IdentityPoolTagsType = {
    [key: string]: string | undefined;
};
export interface CreateIdentityPoolInput {
    IdentityPoolName: string;
    AllowUnauthenticatedIdentities: boolean;
    AllowClassicFlow?: boolean;
    SupportedLoginProviders?: {
        [key: string]: string | undefined;
    };
    DeveloperProviderName?: string;
    OpenIdConnectProviderARNs?: string[];
    CognitoIdentityProviders?: CognitoIdentityProvider[];
    SamlProviderARNs?: string[];
    IdentityPoolTags?: {
        [key: string]: string | undefined;
    };
}
export type IdentityPoolId = string;
export interface IdentityPool {
    IdentityPoolId: string;
    IdentityPoolName: string;
    AllowUnauthenticatedIdentities: boolean;
    AllowClassicFlow?: boolean;
    SupportedLoginProviders?: {
        [key: string]: string | undefined;
    };
    DeveloperProviderName?: string;
    OpenIdConnectProviderARNs?: string[];
    CognitoIdentityProviders?: CognitoIdentityProvider[];
    SamlProviderARNs?: string[];
    IdentityPoolTags?: {
        [key: string]: string | undefined;
    };
}
export type IdentityId = string;
export type IdentityIdList = string[];
export interface DeleteIdentitiesInput {
    IdentityIdsToDelete: string[];
}
export type ErrorCode = "AccessDenied" | "InternalServerError" | (string & {});
export interface UnprocessedIdentityId {
    IdentityId?: string;
    ErrorCode?: ErrorCode;
}
export type UnprocessedIdentityIdList = UnprocessedIdentityId[];
export interface DeleteIdentitiesResponse {
    UnprocessedIdentityIds?: UnprocessedIdentityId[];
}
export interface DeleteIdentityPoolInput {
    IdentityPoolId: string;
}
export interface DeleteIdentityPoolResponse {
}
export interface DescribeIdentityInput {
    IdentityId: string;
}
export type LoginsList = string[];
export interface IdentityDescription {
    IdentityId?: string;
    Logins?: string[];
    CreationDate?: Date;
    LastModifiedDate?: Date;
}
export interface DescribeIdentityPoolInput {
    IdentityPoolId: string;
}
export type IdentityProviderToken = string | redacted.Redacted<string>;
export type LoginsMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export interface GetCredentialsForIdentityInput {
    IdentityId: string;
    Logins?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    CustomRoleArn?: string;
}
export type AccessKeyString = string;
export type SecretKeyString = string | redacted.Redacted<string>;
export type SessionTokenString = string;
export interface Credentials {
    AccessKeyId?: string;
    SecretKey?: string | redacted.Redacted<string>;
    SessionToken?: string | redacted.Redacted<string>;
    Expiration?: Date;
}
export interface GetCredentialsForIdentityResponse {
    IdentityId?: string;
    Credentials?: Credentials;
}
export type AccountId = string;
export interface GetIdInput {
    AccountId?: string;
    IdentityPoolId: string;
    Logins?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export interface GetIdResponse {
    IdentityId?: string;
}
export interface GetIdentityPoolRolesInput {
    IdentityPoolId: string;
}
export type RoleType = string;
export type RolesMap = {
    [key: string]: string | undefined;
};
export type RoleMappingType = "Token" | "Rules" | (string & {});
export type AmbiguousRoleResolutionType = "AuthenticatedRole" | "Deny" | (string & {});
export type ClaimName = string;
export type MappingRuleMatchType = "Equals" | "Contains" | "StartsWith" | "NotEqual" | (string & {});
export type ClaimValue = string;
export interface MappingRule {
    Claim: string;
    MatchType: MappingRuleMatchType;
    Value: string;
    RoleARN: string;
}
export type MappingRulesList = MappingRule[];
export interface RulesConfigurationType {
    Rules: MappingRule[];
}
export interface RoleMapping {
    Type: RoleMappingType;
    AmbiguousRoleResolution?: AmbiguousRoleResolutionType;
    RulesConfiguration?: RulesConfigurationType;
}
export type RoleMappingMap = {
    [key: string]: RoleMapping | undefined;
};
export interface GetIdentityPoolRolesResponse {
    IdentityPoolId?: string;
    Roles?: {
        [key: string]: string | undefined;
    };
    RoleMappings?: {
        [key: string]: RoleMapping | undefined;
    };
}
export interface GetOpenIdTokenInput {
    IdentityId: string;
    Logins?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export type OIDCToken = string | redacted.Redacted<string>;
export interface GetOpenIdTokenResponse {
    IdentityId?: string;
    Token?: string | redacted.Redacted<string>;
}
export type PrincipalTagID = string;
export type PrincipalTagValue = string;
export type PrincipalTags = {
    [key: string]: string | undefined;
};
export type TokenDuration = number;
export interface GetOpenIdTokenForDeveloperIdentityInput {
    IdentityPoolId: string;
    IdentityId?: string;
    Logins: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    PrincipalTags?: {
        [key: string]: string | undefined;
    };
    TokenDuration?: number;
}
export interface GetOpenIdTokenForDeveloperIdentityResponse {
    IdentityId?: string;
    Token?: string | redacted.Redacted<string>;
}
export interface GetPrincipalTagAttributeMapInput {
    IdentityPoolId: string;
    IdentityProviderName: string;
}
export type UseDefaults = boolean;
export interface GetPrincipalTagAttributeMapResponse {
    IdentityPoolId?: string;
    IdentityProviderName?: string;
    UseDefaults?: boolean;
    PrincipalTags?: {
        [key: string]: string | undefined;
    };
}
export type QueryLimit = number;
export type PaginationKey = string;
export type HideDisabled = boolean;
export interface ListIdentitiesInput {
    IdentityPoolId: string;
    MaxResults: number;
    NextToken?: string;
    HideDisabled?: boolean;
}
export type IdentitiesList = IdentityDescription[];
export interface ListIdentitiesResponse {
    IdentityPoolId?: string;
    Identities?: IdentityDescription[];
    NextToken?: string;
}
export interface ListIdentityPoolsInput {
    MaxResults: number;
    NextToken?: string;
}
export interface IdentityPoolShortDescription {
    IdentityPoolId?: string;
    IdentityPoolName?: string;
}
export type IdentityPoolsList = IdentityPoolShortDescription[];
export interface ListIdentityPoolsResponse {
    IdentityPools?: IdentityPoolShortDescription[];
    NextToken?: string;
}
export interface ListTagsForResourceInput {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type DeveloperUserIdentifier = string;
export interface LookupDeveloperIdentityInput {
    IdentityPoolId: string;
    IdentityId?: string;
    DeveloperUserIdentifier?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type DeveloperUserIdentifierList = string[];
export interface LookupDeveloperIdentityResponse {
    IdentityId?: string;
    DeveloperUserIdentifierList?: string[];
    NextToken?: string;
}
export interface MergeDeveloperIdentitiesInput {
    SourceUserIdentifier: string;
    DestinationUserIdentifier: string;
    DeveloperProviderName: string;
    IdentityPoolId: string;
}
export interface MergeDeveloperIdentitiesResponse {
    IdentityId?: string;
}
export interface SetIdentityPoolRolesInput {
    IdentityPoolId: string;
    Roles: {
        [key: string]: string | undefined;
    };
    RoleMappings?: {
        [key: string]: RoleMapping | undefined;
    };
}
export interface SetIdentityPoolRolesResponse {
}
export interface SetPrincipalTagAttributeMapInput {
    IdentityPoolId: string;
    IdentityProviderName: string;
    UseDefaults?: boolean;
    PrincipalTags?: {
        [key: string]: string | undefined;
    };
}
export interface SetPrincipalTagAttributeMapResponse {
    IdentityPoolId?: string;
    IdentityProviderName?: string;
    UseDefaults?: boolean;
    PrincipalTags?: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceInput {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export interface UnlinkDeveloperIdentityInput {
    IdentityId: string;
    IdentityPoolId: string;
    DeveloperProviderName: string;
    DeveloperUserIdentifier: string;
}
export interface UnlinkDeveloperIdentityResponse {
}
export interface UnlinkIdentityInput {
    IdentityId: string;
    Logins: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    LoginsToRemove: string[];
}
export interface UnlinkIdentityResponse {
}
export type IdentityPoolTagsListType = string[];
export interface UntagResourceInput {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export type CreateIdentityPoolError = InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | ResourceConflictException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new identity pool. The identity pool is a store of user identity
 * information that is specific to your Amazon Web Services account. The keys for
 * `SupportedLoginProviders` are as follows:
 *
 * - Facebook: `graph.facebook.com`
 *
 * - Google: `accounts.google.com`
 *
 * - Sign in With Apple: `appleid.apple.com`
 *
 * - Amazon: `www.amazon.com`
 *
 * - Twitter: `api.twitter.com`
 *
 * - Digits: `www.digits.com`
 *
 * If you don't provide a value for a parameter, Amazon Cognito sets it to its default value.
 *
 * You must use Amazon Web Services developer credentials to call this
 * operation.
 */
export declare const createIdentityPool: API.OperationMethod<CreateIdentityPoolInput, IdentityPool, CreateIdentityPoolError, Creds | HttpClient.HttpClient>;
export type DeleteIdentitiesError = InternalErrorException | InvalidParameterException | TooManyRequestsException | CommonErrors;
/**
 * Deletes identities from an identity pool. You can specify a list of 1-60 identities
 * that you want to delete.
 *
 * You must use Amazon Web Services developer credentials to call this
 * operation.
 */
export declare const deleteIdentities: API.OperationMethod<DeleteIdentitiesInput, DeleteIdentitiesResponse, DeleteIdentitiesError, Creds | HttpClient.HttpClient>;
export type DeleteIdentityPoolError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an identity pool. Once a pool is deleted, users will not be able to
 * authenticate with the pool.
 *
 * You must use Amazon Web Services developer credentials to call this
 * operation.
 */
export declare const deleteIdentityPool: API.OperationMethod<DeleteIdentityPoolInput, DeleteIdentityPoolResponse, DeleteIdentityPoolError, Creds | HttpClient.HttpClient>;
export type DescribeIdentityError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns metadata related to the given identity, including when the identity was
 * created and any associated linked logins.
 *
 * You must use Amazon Web Services developer credentials to call this
 * operation.
 */
export declare const describeIdentity: API.OperationMethod<DescribeIdentityInput, IdentityDescription, DescribeIdentityError, Creds | HttpClient.HttpClient>;
export type DescribeIdentityPoolError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details about a particular identity pool, including the pool name, ID
 * description, creation date, and current number of users.
 *
 * You must use Amazon Web Services developer credentials to call this
 * operation.
 */
export declare const describeIdentityPool: API.OperationMethod<DescribeIdentityPoolInput, IdentityPool, DescribeIdentityPoolError, Creds | HttpClient.HttpClient>;
export type GetCredentialsForIdentityError = ExternalServiceException | InternalErrorException | InvalidIdentityPoolConfigurationException | InvalidParameterException | NotAuthorizedException | ResourceConflictException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns credentials for the provided identity ID. Any provided logins will be
 * validated against supported login providers. If the token is for
 * `cognito-identity.amazonaws.com`, it will be passed through to Security Token Service with the appropriate role for the token.
 *
 * This is a public API. You do not need any credentials to call this API.
 */
export declare const getCredentialsForIdentity: API.OperationMethod<GetCredentialsForIdentityInput, GetCredentialsForIdentityResponse, GetCredentialsForIdentityError, Creds | HttpClient.HttpClient>;
export type GetIdError = ExternalServiceException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | ResourceConflictException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Generates (or retrieves) IdentityID. Supplying multiple logins will create an
 * implicit linked account.
 *
 * This is a public API. You do not need any credentials to call this API.
 */
export declare const getId: API.OperationMethod<GetIdInput, GetIdResponse, GetIdError, Creds | HttpClient.HttpClient>;
export type GetIdentityPoolRolesError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceConflictException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the roles for an identity pool.
 *
 * You must use Amazon Web Services developer credentials to call this
 * operation.
 */
export declare const getIdentityPoolRoles: API.OperationMethod<GetIdentityPoolRolesInput, GetIdentityPoolRolesResponse, GetIdentityPoolRolesError, Creds | HttpClient.HttpClient>;
export type GetOpenIdTokenError = ExternalServiceException | InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceConflictException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets an OpenID token, using a known Cognito ID. This known Cognito ID is returned by
 * GetId. You can optionally add additional logins for the identity.
 * Supplying multiple logins creates an implicit link.
 *
 * The OpenID token is valid for 10 minutes.
 *
 * This is a public API. You do not need any credentials to call this API.
 */
export declare const getOpenIdToken: API.OperationMethod<GetOpenIdTokenInput, GetOpenIdTokenResponse, GetOpenIdTokenError, Creds | HttpClient.HttpClient>;
export type GetOpenIdTokenForDeveloperIdentityError = DeveloperUserAlreadyRegisteredException | InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceConflictException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Registers (or retrieves) a Cognito `IdentityId` and an OpenID Connect
 * token for a user authenticated by your backend authentication process. Supplying multiple
 * logins will create an implicit linked account. You can only specify one developer provider
 * as part of the `Logins` map, which is linked to the identity pool. The developer
 * provider is the "domain" by which Cognito will refer to your users.
 *
 * You can use `GetOpenIdTokenForDeveloperIdentity` to create a new identity
 * and to link new logins (that is, user credentials issued by a public provider or developer
 * provider) to an existing identity. When you want to create a new identity, the
 * `IdentityId` should be null. When you want to associate a new login with an
 * existing authenticated/unauthenticated identity, you can do so by providing the existing
 * `IdentityId`. This API will create the identity in the specified
 * `IdentityPoolId`.
 *
 * You must use Amazon Web Services developer credentials to call this
 * operation.
 */
export declare const getOpenIdTokenForDeveloperIdentity: API.OperationMethod<GetOpenIdTokenForDeveloperIdentityInput, GetOpenIdTokenForDeveloperIdentityResponse, GetOpenIdTokenForDeveloperIdentityError, Creds | HttpClient.HttpClient>;
export type GetPrincipalTagAttributeMapError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Use `GetPrincipalTagAttributeMap` to list all mappings between
 * `PrincipalTags` and user attributes.
 */
export declare const getPrincipalTagAttributeMap: API.OperationMethod<GetPrincipalTagAttributeMapInput, GetPrincipalTagAttributeMapResponse, GetPrincipalTagAttributeMapError, Creds | HttpClient.HttpClient>;
export type ListIdentitiesError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists the identities in an identity pool.
 *
 * You must use Amazon Web Services developer credentials to call this
 * operation.
 */
export declare const listIdentities: API.OperationMethod<ListIdentitiesInput, ListIdentitiesResponse, ListIdentitiesError, Creds | HttpClient.HttpClient>;
export type ListIdentityPoolsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists all of the Cognito identity pools registered for your account.
 *
 * You must use Amazon Web Services developer credentials to call this
 * operation.
 */
export declare const listIdentityPools: API.PaginatedOperationMethod<ListIdentityPoolsInput, ListIdentityPoolsResponse, ListIdentityPoolsError, Creds | HttpClient.HttpClient, IdentityPoolShortDescription>;
export type ListTagsForResourceError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists the tags that are assigned to an Amazon Cognito identity pool.
 *
 * A tag is a label that you can apply to identity pools to categorize and manage them in
 * different ways, such as by purpose, owner, environment, or other criteria.
 *
 * You can use this action up to 10 times per second, per account.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceResponse, ListTagsForResourceError, Creds | HttpClient.HttpClient>;
export type LookupDeveloperIdentityError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceConflictException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the `IdentityID` associated with a
 * `DeveloperUserIdentifier` or the list of `DeveloperUserIdentifier`
 * values associated with an `IdentityId` for an existing identity. Either
 * `IdentityID` or `DeveloperUserIdentifier` must not be null. If you
 * supply only one of these values, the other value will be searched in the database and
 * returned as a part of the response. If you supply both,
 * `DeveloperUserIdentifier` will be matched against `IdentityID`. If
 * the values are verified against the database, the response returns both values and is the
 * same as the request. Otherwise, a `ResourceConflictException` is
 * thrown.
 *
 * `LookupDeveloperIdentity` is intended for low-throughput control plane
 * operations: for example, to enable customer service to locate an identity ID by username.
 * If you are using it for higher-volume operations such as user authentication, your requests
 * are likely to be throttled. GetOpenIdTokenForDeveloperIdentity is a
 * better option for higher-volume operations for user authentication.
 *
 * You must use Amazon Web Services developer credentials to call this
 * operation.
 */
export declare const lookupDeveloperIdentity: API.OperationMethod<LookupDeveloperIdentityInput, LookupDeveloperIdentityResponse, LookupDeveloperIdentityError, Creds | HttpClient.HttpClient>;
export type MergeDeveloperIdentitiesError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceConflictException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Merges two users having different `IdentityId`s, existing in the same
 * identity pool, and identified by the same developer provider. You can use this action to
 * request that discrete users be merged and identified as a single user in the Cognito
 * environment. Cognito associates the given source user (`SourceUserIdentifier`)
 * with the `IdentityId` of the `DestinationUserIdentifier`. Only
 * developer-authenticated users can be merged. If the users to be merged are associated with
 * the same public provider, but as two different users, an exception will be
 * thrown.
 *
 * The number of linked logins is limited to 20. So, the number of linked logins for the
 * source user, `SourceUserIdentifier`, and the destination user,
 * `DestinationUserIdentifier`, together should not be larger than 20.
 * Otherwise, an exception will be thrown.
 *
 * You must use Amazon Web Services developer credentials to call this
 * operation.
 */
export declare const mergeDeveloperIdentities: API.OperationMethod<MergeDeveloperIdentitiesInput, MergeDeveloperIdentitiesResponse, MergeDeveloperIdentitiesError, Creds | HttpClient.HttpClient>;
export type SetIdentityPoolRolesError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceConflictException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Sets the roles for an identity pool. These roles are used when making calls to GetCredentialsForIdentity action.
 *
 * You must use Amazon Web Services developer credentials to call this
 * operation.
 */
export declare const setIdentityPoolRoles: API.OperationMethod<SetIdentityPoolRolesInput, SetIdentityPoolRolesResponse, SetIdentityPoolRolesError, Creds | HttpClient.HttpClient>;
export type SetPrincipalTagAttributeMapError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * You can use this operation to use default (username and clientID) attribute or custom
 * attribute mappings.
 */
export declare const setPrincipalTagAttributeMap: API.OperationMethod<SetPrincipalTagAttributeMapInput, SetPrincipalTagAttributeMapResponse, SetPrincipalTagAttributeMapError, Creds | HttpClient.HttpClient>;
export type TagResourceError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Assigns a set of tags to the specified Amazon Cognito identity pool. A tag is a label
 * that you can use to categorize and manage identity pools in different ways, such as by
 * purpose, owner, environment, or other criteria.
 *
 * Each tag consists of a key and value, both of which you define. A key is a general
 * category for more specific values. For example, if you have two versions of an identity
 * pool, one for testing and another for production, you might assign an
 * `Environment` tag key to both identity pools. The value of this key might be
 * `Test` for one identity pool and `Production` for the
 * other.
 *
 * Tags are useful for cost tracking and access control. You can activate your tags so that
 * they appear on the Billing and Cost Management console, where you can track the costs
 * associated with your identity pools. In an IAM policy, you can constrain
 * permissions for identity pools based on specific tags or tag values.
 *
 * You can use this action up to 5 times per second, per account. An identity pool can have
 * as many as 50 tags.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceResponse, TagResourceError, Creds | HttpClient.HttpClient>;
export type UnlinkDeveloperIdentityError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceConflictException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Unlinks a `DeveloperUserIdentifier` from an existing identity. Unlinked
 * developer users will be considered new identities next time they are seen. If, for a given
 * Cognito identity, you remove all federated identities as well as the developer user
 * identifier, the Cognito identity becomes inaccessible.
 *
 * You must use Amazon Web Services developer credentials to call this
 * operation.
 */
export declare const unlinkDeveloperIdentity: API.OperationMethod<UnlinkDeveloperIdentityInput, UnlinkDeveloperIdentityResponse, UnlinkDeveloperIdentityError, Creds | HttpClient.HttpClient>;
export type UnlinkIdentityError = ExternalServiceException | InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceConflictException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Unlinks a federated identity from an existing account. Unlinked logins will be
 * considered new identities next time they are seen. Removing the last linked login will make
 * this identity inaccessible.
 *
 * This is a public API. You do not need any credentials to call this API.
 */
export declare const unlinkIdentity: API.OperationMethod<UnlinkIdentityInput, UnlinkIdentityResponse, UnlinkIdentityError, Creds | HttpClient.HttpClient>;
export type UntagResourceError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes the specified tags from the specified Amazon Cognito identity pool. You can use
 * this action up to 5 times per second, per account
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceResponse, UntagResourceError, Creds | HttpClient.HttpClient>;
export type UpdateIdentityPoolError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | ResourceConflictException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the configuration of an identity pool.
 *
 * If you don't provide a value for a parameter, Amazon Cognito sets it to its default value.
 *
 * You must use Amazon Web Services developer credentials to call this
 * operation.
 */
export declare const updateIdentityPool: API.OperationMethod<IdentityPool, IdentityPool, UpdateIdentityPoolError, Creds | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cognito-identity.d.ts.map