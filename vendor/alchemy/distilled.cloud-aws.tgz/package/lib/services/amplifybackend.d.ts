import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const GatewayTimeoutException_base: S.TaggedErrorClass<"GatewayTimeoutException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class GatewayTimeoutException extends /*@__PURE__*/ GatewayTimeoutException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly LimitType: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export interface CloneBackendRequest {
    AppId: string;
    BackendEnvironmentName: string;
    TargetEnvironmentName?: string;
}
export interface CloneBackendResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export interface ResourceConfig {
}
export interface CreateBackendRequest {
    AppId?: string;
    AppName?: string;
    BackendEnvironmentName?: string;
    ResourceConfig?: ResourceConfig;
    ResourceName?: string;
}
export interface CreateBackendResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export type Mode = "API_KEY" | "AWS_IAM" | "AMAZON_COGNITO_USER_POOLS" | "OPENID_CONNECT" | (string & {});
export interface BackendAPIAppSyncAuthSettings {
    CognitoUserPoolId?: string;
    Description?: string;
    ExpirationTime?: number;
    OpenIDAuthTTL?: string;
    OpenIDClientId?: string;
    OpenIDIatTTL?: string;
    OpenIDIssueURL?: string;
    OpenIDProviderName?: string;
}
export interface BackendAPIAuthType {
    Mode?: Mode;
    Settings?: BackendAPIAppSyncAuthSettings;
}
export type ListOfBackendAPIAuthType = BackendAPIAuthType[];
export type ResolutionStrategy = "OPTIMISTIC_CONCURRENCY" | "LAMBDA" | "AUTOMERGE" | "NONE" | (string & {});
export interface BackendAPIConflictResolution {
    ResolutionStrategy?: ResolutionStrategy;
}
export interface BackendAPIResourceConfig {
    AdditionalAuthTypes?: BackendAPIAuthType[];
    ApiName?: string;
    ConflictResolution?: BackendAPIConflictResolution;
    DefaultAuthType?: BackendAPIAuthType;
    Service?: string;
    TransformSchema?: string;
}
export interface CreateBackendAPIRequest {
    AppId: string;
    BackendEnvironmentName?: string;
    ResourceConfig?: BackendAPIResourceConfig;
    ResourceName?: string;
}
export interface CreateBackendAPIResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export type AuthResources = "USER_POOL_ONLY" | "IDENTITY_POOL_AND_USER_POOL" | (string & {});
export interface CreateBackendAuthIdentityPoolConfig {
    IdentityPoolName?: string;
    UnauthenticatedLogin?: boolean;
}
export type Service = "COGNITO" | (string & {});
export type DeliveryMethod = "EMAIL" | "SMS" | (string & {});
export interface EmailSettings {
    EmailMessage?: string;
    EmailSubject?: string;
}
export interface SmsSettings {
    SmsMessage?: string;
}
export interface CreateBackendAuthForgotPasswordConfig {
    DeliveryMethod?: DeliveryMethod;
    EmailSettings?: EmailSettings;
    SmsSettings?: SmsSettings;
}
export type MFAMode = "ON" | "OFF" | "OPTIONAL" | (string & {});
export type MfaTypesElement = "SMS" | "TOTP" | (string & {});
export type ListOfMfaTypesElement = MfaTypesElement[];
export interface Settings {
    MfaTypes?: MfaTypesElement[];
    SmsMessage?: string;
}
export interface CreateBackendAuthMFAConfig {
    MFAMode?: MFAMode;
    Settings?: Settings;
}
export type OAuthGrantType = "CODE" | "IMPLICIT" | (string & {});
export type OAuthScopesElement = "PHONE" | "EMAIL" | "OPENID" | "PROFILE" | "AWS_COGNITO_SIGNIN_USER_ADMIN" | (string & {});
export type ListOfOAuthScopesElement = OAuthScopesElement[];
export type ListOf__string = string[];
export interface BackendAuthSocialProviderConfig {
    ClientId?: string;
    ClientSecret?: string;
}
export interface BackendAuthAppleProviderConfig {
    ClientId?: string;
    KeyId?: string;
    PrivateKey?: string;
    TeamId?: string;
}
export interface SocialProviderSettings {
    Facebook?: BackendAuthSocialProviderConfig;
    Google?: BackendAuthSocialProviderConfig;
    LoginWithAmazon?: BackendAuthSocialProviderConfig;
    SignInWithApple?: BackendAuthAppleProviderConfig;
}
export interface CreateBackendAuthOAuthConfig {
    DomainPrefix?: string;
    OAuthGrantType?: OAuthGrantType;
    OAuthScopes?: OAuthScopesElement[];
    RedirectSignInURIs?: string[];
    RedirectSignOutURIs?: string[];
    SocialProviderSettings?: SocialProviderSettings;
}
export type AdditionalConstraintsElement = "REQUIRE_DIGIT" | "REQUIRE_LOWERCASE" | "REQUIRE_SYMBOL" | "REQUIRE_UPPERCASE" | (string & {});
export type ListOfAdditionalConstraintsElement = AdditionalConstraintsElement[];
export interface CreateBackendAuthPasswordPolicyConfig {
    AdditionalConstraints?: AdditionalConstraintsElement[];
    MinimumLength?: number;
}
export type RequiredSignUpAttributesElement = "ADDRESS" | "BIRTHDATE" | "EMAIL" | "FAMILY_NAME" | "GENDER" | "GIVEN_NAME" | "LOCALE" | "MIDDLE_NAME" | "NAME" | "NICKNAME" | "PHONE_NUMBER" | "PICTURE" | "PREFERRED_USERNAME" | "PROFILE" | "UPDATED_AT" | "WEBSITE" | "ZONE_INFO" | (string & {});
export type ListOfRequiredSignUpAttributesElement = RequiredSignUpAttributesElement[];
export type SignInMethod = "EMAIL" | "EMAIL_AND_PHONE_NUMBER" | "PHONE_NUMBER" | "USERNAME" | (string & {});
export interface CreateBackendAuthVerificationMessageConfig {
    DeliveryMethod?: DeliveryMethod;
    EmailSettings?: EmailSettings;
    SmsSettings?: SmsSettings;
}
export interface CreateBackendAuthUserPoolConfig {
    ForgotPassword?: CreateBackendAuthForgotPasswordConfig;
    Mfa?: CreateBackendAuthMFAConfig;
    OAuth?: CreateBackendAuthOAuthConfig;
    PasswordPolicy?: CreateBackendAuthPasswordPolicyConfig;
    RequiredSignUpAttributes?: RequiredSignUpAttributesElement[];
    SignInMethod?: SignInMethod;
    UserPoolName?: string;
    VerificationMessage?: CreateBackendAuthVerificationMessageConfig;
}
export interface CreateBackendAuthResourceConfig {
    AuthResources?: AuthResources;
    IdentityPoolConfigs?: CreateBackendAuthIdentityPoolConfig;
    Service?: Service;
    UserPoolConfigs?: CreateBackendAuthUserPoolConfig;
}
export interface CreateBackendAuthRequest {
    AppId: string;
    BackendEnvironmentName?: string;
    ResourceConfig?: CreateBackendAuthResourceConfig;
    ResourceName?: string;
}
export interface CreateBackendAuthResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export interface CreateBackendConfigRequest {
    AppId: string;
    BackendManagerAppId?: string;
}
export interface CreateBackendConfigResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    JobId?: string;
    Status?: string;
}
export type AuthenticatedElement = "READ" | "CREATE_AND_UPDATE" | "DELETE" | (string & {});
export type ListOfAuthenticatedElement = AuthenticatedElement[];
export type UnAuthenticatedElement = "READ" | "CREATE_AND_UPDATE" | "DELETE" | (string & {});
export type ListOfUnAuthenticatedElement = UnAuthenticatedElement[];
export interface BackendStoragePermissions {
    Authenticated?: AuthenticatedElement[];
    UnAuthenticated?: UnAuthenticatedElement[];
}
export type ServiceName = "S3" | (string & {});
export interface CreateBackendStorageResourceConfig {
    BucketName?: string;
    Permissions?: BackendStoragePermissions;
    ServiceName?: ServiceName;
}
export interface CreateBackendStorageRequest {
    AppId: string;
    BackendEnvironmentName?: string;
    ResourceConfig?: CreateBackendStorageResourceConfig;
    ResourceName?: string;
}
export interface CreateBackendStorageResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    JobId?: string;
    Status?: string;
}
export interface CreateTokenRequest {
    AppId: string;
}
export interface CreateTokenResponse {
    AppId?: string;
    ChallengeCode?: string;
    SessionId?: string;
    Ttl?: string;
}
export interface DeleteBackendRequest {
    AppId: string;
    BackendEnvironmentName: string;
}
export interface DeleteBackendResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export interface DeleteBackendAPIRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceConfig?: BackendAPIResourceConfig;
    ResourceName?: string;
}
export interface DeleteBackendAPIResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export interface DeleteBackendAuthRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceName?: string;
}
export interface DeleteBackendAuthResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export interface DeleteBackendStorageRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceName?: string;
    ServiceName?: ServiceName;
}
export interface DeleteBackendStorageResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    JobId?: string;
    Status?: string;
}
export interface DeleteTokenRequest {
    AppId: string;
    SessionId: string;
}
export interface DeleteTokenResponse {
    IsSuccess?: boolean;
}
export interface GenerateBackendAPIModelsRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceName?: string;
}
export interface GenerateBackendAPIModelsResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export interface GetBackendRequest {
    AppId: string;
    BackendEnvironmentName?: string;
}
export interface GetBackendResponse {
    AmplifyFeatureFlags?: string;
    AmplifyMetaConfig?: string;
    AppId?: string;
    AppName?: string;
    BackendEnvironmentList?: string[];
    BackendEnvironmentName?: string;
    Error?: string;
}
export interface GetBackendAPIRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceConfig?: BackendAPIResourceConfig;
    ResourceName?: string;
}
export interface GetBackendAPIResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    ResourceConfig?: BackendAPIResourceConfig;
    ResourceName?: string;
}
export interface GetBackendAPIModelsRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceName?: string;
}
export type Status = "LATEST" | "STALE" | (string & {});
export interface GetBackendAPIModelsResponse {
    Models?: string;
    Status?: Status;
    ModelIntrospectionSchema?: string;
}
export interface GetBackendAuthRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceName?: string;
}
export interface GetBackendAuthResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    ResourceConfig?: CreateBackendAuthResourceConfig & {
        AuthResources: AuthResources;
        Service: Service;
        UserPoolConfigs: CreateBackendAuthUserPoolConfig & {
            RequiredSignUpAttributes: ListOfRequiredSignUpAttributesElement;
            SignInMethod: SignInMethod;
            UserPoolName: string;
            ForgotPassword: CreateBackendAuthForgotPasswordConfig & {
                DeliveryMethod: DeliveryMethod;
            };
            Mfa: CreateBackendAuthMFAConfig & {
                MFAMode: MFAMode;
            };
            OAuth: CreateBackendAuthOAuthConfig & {
                OAuthGrantType: OAuthGrantType;
                OAuthScopes: ListOfOAuthScopesElement;
                RedirectSignInURIs: ListOf__string;
                RedirectSignOutURIs: ListOf__string;
            };
            PasswordPolicy: CreateBackendAuthPasswordPolicyConfig & {
                MinimumLength: number;
            };
            VerificationMessage: CreateBackendAuthVerificationMessageConfig & {
                DeliveryMethod: DeliveryMethod;
            };
        };
        IdentityPoolConfigs: CreateBackendAuthIdentityPoolConfig & {
            IdentityPoolName: string;
            UnauthenticatedLogin: boolean;
        };
    };
    ResourceName?: string;
}
export interface GetBackendJobRequest {
    AppId: string;
    BackendEnvironmentName: string;
    JobId: string;
}
export interface GetBackendJobResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    CreateTime?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
    UpdateTime?: string;
}
export interface GetBackendStorageRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceName?: string;
}
export interface GetBackendStorageResourceConfig {
    BucketName?: string;
    Imported?: boolean;
    Permissions?: BackendStoragePermissions;
    ServiceName?: ServiceName;
}
export interface GetBackendStorageResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    ResourceConfig?: GetBackendStorageResourceConfig & {
        Imported: boolean;
        ServiceName: ServiceName;
        Permissions: BackendStoragePermissions & {
            Authenticated: ListOfAuthenticatedElement;
        };
    };
    ResourceName?: string;
}
export interface GetTokenRequest {
    AppId: string;
    SessionId: string;
}
export interface GetTokenResponse {
    AppId?: string;
    ChallengeCode?: string;
    SessionId?: string;
    Ttl?: string;
}
export interface ImportBackendAuthRequest {
    AppId: string;
    BackendEnvironmentName: string;
    IdentityPoolId?: string;
    NativeClientId?: string;
    UserPoolId?: string;
    WebClientId?: string;
}
export interface ImportBackendAuthResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export interface ImportBackendStorageRequest {
    AppId: string;
    BackendEnvironmentName: string;
    BucketName?: string;
    ServiceName?: ServiceName;
}
export interface ImportBackendStorageResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    JobId?: string;
    Status?: string;
}
export type __integerMin1Max25 = number;
export interface ListBackendJobsRequest {
    AppId: string;
    BackendEnvironmentName: string;
    JobId?: string;
    MaxResults?: number;
    NextToken?: string;
    Operation?: string;
    Status?: string;
}
export interface BackendJobRespObj {
    AppId?: string;
    BackendEnvironmentName?: string;
    CreateTime?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
    UpdateTime?: string;
}
export type ListOfBackendJobRespObj = BackendJobRespObj[];
export interface ListBackendJobsResponse {
    Jobs?: (BackendJobRespObj & {
        AppId: string;
        BackendEnvironmentName: string;
    })[];
    NextToken?: string;
}
export interface ListS3BucketsRequest {
    NextToken?: string;
}
export interface S3BucketInfo {
    CreationDate?: string;
    Name?: string;
}
export type ListOfS3BucketInfo = S3BucketInfo[];
export interface ListS3BucketsResponse {
    Buckets?: S3BucketInfo[];
    NextToken?: string;
}
export interface RemoveAllBackendsRequest {
    AppId: string;
    CleanAmplifyApp?: boolean;
}
export interface RemoveAllBackendsResponse {
    AppId?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export interface RemoveBackendConfigRequest {
    AppId: string;
}
export interface RemoveBackendConfigResponse {
    Error?: string;
}
export interface UpdateBackendAPIRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceConfig?: BackendAPIResourceConfig;
    ResourceName?: string;
}
export interface UpdateBackendAPIResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export interface UpdateBackendAuthIdentityPoolConfig {
    UnauthenticatedLogin?: boolean;
}
export interface UpdateBackendAuthForgotPasswordConfig {
    DeliveryMethod?: DeliveryMethod;
    EmailSettings?: EmailSettings;
    SmsSettings?: SmsSettings;
}
export interface UpdateBackendAuthMFAConfig {
    MFAMode?: MFAMode;
    Settings?: Settings;
}
export interface UpdateBackendAuthOAuthConfig {
    DomainPrefix?: string;
    OAuthGrantType?: OAuthGrantType;
    OAuthScopes?: OAuthScopesElement[];
    RedirectSignInURIs?: string[];
    RedirectSignOutURIs?: string[];
    SocialProviderSettings?: SocialProviderSettings;
}
export interface UpdateBackendAuthPasswordPolicyConfig {
    AdditionalConstraints?: AdditionalConstraintsElement[];
    MinimumLength?: number;
}
export interface UpdateBackendAuthVerificationMessageConfig {
    DeliveryMethod?: DeliveryMethod;
    EmailSettings?: EmailSettings;
    SmsSettings?: SmsSettings;
}
export interface UpdateBackendAuthUserPoolConfig {
    ForgotPassword?: UpdateBackendAuthForgotPasswordConfig;
    Mfa?: UpdateBackendAuthMFAConfig;
    OAuth?: UpdateBackendAuthOAuthConfig;
    PasswordPolicy?: UpdateBackendAuthPasswordPolicyConfig;
    VerificationMessage?: UpdateBackendAuthVerificationMessageConfig;
}
export interface UpdateBackendAuthResourceConfig {
    AuthResources?: AuthResources;
    IdentityPoolConfigs?: UpdateBackendAuthIdentityPoolConfig;
    Service?: Service;
    UserPoolConfigs?: UpdateBackendAuthUserPoolConfig;
}
export interface UpdateBackendAuthRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceConfig?: UpdateBackendAuthResourceConfig;
    ResourceName?: string;
}
export interface UpdateBackendAuthResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
}
export interface LoginAuthConfigReqObj {
    AwsCognitoIdentityPoolId?: string;
    AwsCognitoRegion?: string;
    AwsUserPoolsId?: string;
    AwsUserPoolsWebClientId?: string;
}
export interface UpdateBackendConfigRequest {
    AppId: string;
    LoginAuthConfig?: LoginAuthConfigReqObj;
}
export interface UpdateBackendConfigResponse {
    AppId?: string;
    BackendManagerAppId?: string;
    Error?: string;
    LoginAuthConfig?: LoginAuthConfigReqObj;
}
export interface UpdateBackendJobRequest {
    AppId: string;
    BackendEnvironmentName: string;
    JobId: string;
    Operation?: string;
    Status?: string;
}
export interface UpdateBackendJobResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    CreateTime?: string;
    Error?: string;
    JobId?: string;
    Operation?: string;
    Status?: string;
    UpdateTime?: string;
}
export interface UpdateBackendStorageResourceConfig {
    Permissions?: BackendStoragePermissions;
    ServiceName?: ServiceName;
}
export interface UpdateBackendStorageRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceConfig?: UpdateBackendStorageResourceConfig;
    ResourceName?: string;
}
export interface UpdateBackendStorageResponse {
    AppId?: string;
    BackendEnvironmentName?: string;
    JobId?: string;
    Status?: string;
}
export type CloneBackendError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * This operation clones an existing backend.
 */
export declare const cloneBackend: API.OperationMethod<CloneBackendRequest, CloneBackendResponse, CloneBackendError, Credentials | HttpClient.HttpClient>;
export type CreateBackendError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * This operation creates a backend for an Amplify app. Backends are automatically created at the time of app creation.
 */
export declare const createBackend: API.OperationMethod<CreateBackendRequest, CreateBackendResponse, CreateBackendError, Credentials | HttpClient.HttpClient>;
export type CreateBackendAPIError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new backend API resource.
 */
export declare const createBackendAPI: API.OperationMethod<CreateBackendAPIRequest, CreateBackendAPIResponse, CreateBackendAPIError, Credentials | HttpClient.HttpClient>;
export type CreateBackendAuthError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new backend authentication resource.
 */
export declare const createBackendAuth: API.OperationMethod<CreateBackendAuthRequest, CreateBackendAuthResponse, CreateBackendAuthError, Credentials | HttpClient.HttpClient>;
export type CreateBackendConfigError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a config object for a backend.
 */
export declare const createBackendConfig: API.OperationMethod<CreateBackendConfigRequest, CreateBackendConfigResponse, CreateBackendConfigError, Credentials | HttpClient.HttpClient>;
export type CreateBackendStorageError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a backend storage resource.
 */
export declare const createBackendStorage: API.OperationMethod<CreateBackendStorageRequest, CreateBackendStorageResponse, CreateBackendStorageError, Credentials | HttpClient.HttpClient>;
export type CreateTokenError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Generates a one-time challenge code to authenticate a user into your Amplify Admin UI.
 */
export declare const createToken: API.OperationMethod<CreateTokenRequest, CreateTokenResponse, CreateTokenError, Credentials | HttpClient.HttpClient>;
export type DeleteBackendError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes an existing environment from your Amplify project.
 */
export declare const deleteBackend: API.OperationMethod<DeleteBackendRequest, DeleteBackendResponse, DeleteBackendError, Credentials | HttpClient.HttpClient>;
export type DeleteBackendAPIError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an existing backend API resource.
 */
export declare const deleteBackendAPI: API.OperationMethod<DeleteBackendAPIRequest, DeleteBackendAPIResponse, DeleteBackendAPIError, Credentials | HttpClient.HttpClient>;
export type DeleteBackendAuthError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an existing backend authentication resource.
 */
export declare const deleteBackendAuth: API.OperationMethod<DeleteBackendAuthRequest, DeleteBackendAuthResponse, DeleteBackendAuthError, Credentials | HttpClient.HttpClient>;
export type DeleteBackendStorageError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes the specified backend storage resource.
 */
export declare const deleteBackendStorage: API.OperationMethod<DeleteBackendStorageRequest, DeleteBackendStorageResponse, DeleteBackendStorageError, Credentials | HttpClient.HttpClient>;
export type DeleteTokenError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the challenge token based on the given appId and sessionId.
 */
export declare const deleteToken: API.OperationMethod<DeleteTokenRequest, DeleteTokenResponse, DeleteTokenError, Credentials | HttpClient.HttpClient>;
export type GenerateBackendAPIModelsError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Generates a model schema for an existing backend API resource.
 */
export declare const generateBackendAPIModels: API.OperationMethod<GenerateBackendAPIModelsRequest, GenerateBackendAPIModelsResponse, GenerateBackendAPIModelsError, Credentials | HttpClient.HttpClient>;
export type GetBackendError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Provides project-level details for your Amplify UI project.
 */
export declare const getBackend: API.OperationMethod<GetBackendRequest, GetBackendResponse, GetBackendError, Credentials | HttpClient.HttpClient>;
export type GetBackendAPIError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the details for a backend API.
 */
export declare const getBackendAPI: API.OperationMethod<GetBackendAPIRequest, GetBackendAPIResponse, GetBackendAPIError, Credentials | HttpClient.HttpClient>;
export type GetBackendAPIModelsError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a model introspection schema for an existing backend API resource.
 */
export declare const getBackendAPIModels: API.OperationMethod<GetBackendAPIModelsRequest, GetBackendAPIModelsResponse, GetBackendAPIModelsError, Credentials | HttpClient.HttpClient>;
export type GetBackendAuthError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a backend auth details.
 */
export declare const getBackendAuth: API.OperationMethod<GetBackendAuthRequest, GetBackendAuthResponse, GetBackendAuthError, Credentials | HttpClient.HttpClient>;
export type GetBackendJobError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns information about a specific job.
 */
export declare const getBackendJob: API.OperationMethod<GetBackendJobRequest, GetBackendJobResponse, GetBackendJobError, Credentials | HttpClient.HttpClient>;
export type GetBackendStorageError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details for a backend storage resource.
 */
export declare const getBackendStorage: API.OperationMethod<GetBackendStorageRequest, GetBackendStorageResponse, GetBackendStorageError, Credentials | HttpClient.HttpClient>;
export type GetTokenError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the challenge token based on the given appId and sessionId.
 */
export declare const getToken: API.OperationMethod<GetTokenRequest, GetTokenResponse, GetTokenError, Credentials | HttpClient.HttpClient>;
export type ImportBackendAuthError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Imports an existing backend authentication resource.
 */
export declare const importBackendAuth: API.OperationMethod<ImportBackendAuthRequest, ImportBackendAuthResponse, ImportBackendAuthError, Credentials | HttpClient.HttpClient>;
export type ImportBackendStorageError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Imports an existing backend storage resource.
 */
export declare const importBackendStorage: API.OperationMethod<ImportBackendStorageRequest, ImportBackendStorageResponse, ImportBackendStorageError, Credentials | HttpClient.HttpClient>;
export type ListBackendJobsError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists the jobs for the backend of an Amplify app.
 */
export declare const listBackendJobs: API.OperationMethod<ListBackendJobsRequest, ListBackendJobsResponse, ListBackendJobsError, Credentials | HttpClient.HttpClient>;
export type ListS3BucketsError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * The list of S3 buckets in your account.
 */
export declare const listS3Buckets: API.OperationMethod<ListS3BucketsRequest, ListS3BucketsResponse, ListS3BucketsError, Credentials | HttpClient.HttpClient>;
export type RemoveAllBackendsError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes all backend environments from your Amplify project.
 */
export declare const removeAllBackends: API.OperationMethod<RemoveAllBackendsRequest, RemoveAllBackendsResponse, RemoveAllBackendsError, Credentials | HttpClient.HttpClient>;
export type RemoveBackendConfigError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes the AWS resources required to access the Amplify Admin UI.
 */
export declare const removeBackendConfig: API.OperationMethod<RemoveBackendConfigRequest, RemoveBackendConfigResponse, RemoveBackendConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateBackendAPIError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing backend API resource.
 */
export declare const updateBackendAPI: API.OperationMethod<UpdateBackendAPIRequest, UpdateBackendAPIResponse, UpdateBackendAPIError, Credentials | HttpClient.HttpClient>;
export type UpdateBackendAuthError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing backend authentication resource.
 */
export declare const updateBackendAuth: API.OperationMethod<UpdateBackendAuthRequest, UpdateBackendAuthResponse, UpdateBackendAuthError, Credentials | HttpClient.HttpClient>;
export type UpdateBackendConfigError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the AWS resources required to access the Amplify Admin UI.
 */
export declare const updateBackendConfig: API.OperationMethod<UpdateBackendConfigRequest, UpdateBackendConfigResponse, UpdateBackendConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateBackendJobError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a specific job.
 */
export declare const updateBackendJob: API.OperationMethod<UpdateBackendJobRequest, UpdateBackendJobResponse, UpdateBackendJobError, Credentials | HttpClient.HttpClient>;
export type UpdateBackendStorageError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing backend storage resource.
 */
export declare const updateBackendStorage: API.OperationMethod<UpdateBackendStorageRequest, UpdateBackendStorageResponse, UpdateBackendStorageError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=amplifybackend.d.ts.map