import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import * as T from "../traits.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly ResourceId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly ResourceId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly ResourceId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly ResourceId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly ResourceId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type EarthObservationJobArn = string;
export interface DeleteEarthObservationJobInput {
    Arn: string;
}
export interface DeleteEarthObservationJobOutput {
}
export type VectorEnrichmentJobArn = string;
export interface DeleteVectorEnrichmentJobInput {
    Arn: string;
}
export interface DeleteVectorEnrichmentJobOutput {
}
export type ExecutionRoleArn = string;
export type S3Uri = string;
export type KmsKey = string;
export interface ExportS3DataInput {
    S3Uri: string;
    KmsKeyId?: string;
}
export interface OutputConfigInput {
    S3Data: ExportS3DataInput;
}
export interface ExportEarthObservationJobInput {
    Arn: string;
    ClientToken?: string;
    ExecutionRoleArn: string;
    OutputConfig: OutputConfigInput;
    ExportSourceImages?: boolean;
}
export type EarthObservationJobExportStatus = string;
export interface ExportEarthObservationJobOutput {
    Arn: string;
    CreationTime: Date;
    ExportStatus: string;
    ExecutionRoleArn: string;
    OutputConfig: OutputConfigInput;
    ExportSourceImages?: boolean;
}
export interface VectorEnrichmentJobS3Data {
    S3Uri: string;
    KmsKeyId?: string;
}
export interface ExportVectorEnrichmentJobOutputConfig {
    S3Data: VectorEnrichmentJobS3Data;
}
export interface ExportVectorEnrichmentJobInput {
    Arn: string;
    ClientToken?: string;
    ExecutionRoleArn: string;
    OutputConfig: ExportVectorEnrichmentJobOutputConfig;
}
export type VectorEnrichmentJobExportStatus = string;
export interface ExportVectorEnrichmentJobOutput {
    Arn: string;
    CreationTime: Date;
    ExecutionRoleArn: string;
    ExportStatus: string;
    OutputConfig: ExportVectorEnrichmentJobOutputConfig;
}
export interface GetEarthObservationJobInput {
    Arn: string;
}
export type EarthObservationJobStatus = string;
export type DataCollectionArn = string;
export interface TimeRangeFilterOutput {
    StartTime: Date;
    EndTime: Date;
}
export type Position = number[];
export type LinearRing = number[][];
export type LinearRings = number[][][];
export interface PolygonGeometryInput {
    Coordinates: number[][][];
}
export type LinearRingsList = number[][][][];
export interface MultiPolygonGeometryInput {
    Coordinates: number[][][][];
}
export type AreaOfInterestGeometry = {
    PolygonGeometry: PolygonGeometryInput;
    MultiPolygonGeometry?: never;
} | {
    PolygonGeometry?: never;
    MultiPolygonGeometry: MultiPolygonGeometryInput;
};
export type AreaOfInterest = {
    AreaOfInterestGeometry: AreaOfInterestGeometry;
};
export interface EoCloudCoverInput {
    LowerBound: number;
    UpperBound: number;
}
export interface ViewOffNadirInput {
    LowerBound: number;
    UpperBound: number;
}
export interface ViewSunAzimuthInput {
    LowerBound: number;
    UpperBound: number;
}
export interface ViewSunElevationInput {
    LowerBound: number;
    UpperBound: number;
}
export type ComparisonOperator = string;
export interface PlatformInput {
    Value: string;
    ComparisonOperator?: string;
}
export interface LandsatCloudCoverLandInput {
    LowerBound: number;
    UpperBound: number;
}
export type Property = {
    EoCloudCover: EoCloudCoverInput;
    ViewOffNadir?: never;
    ViewSunAzimuth?: never;
    ViewSunElevation?: never;
    Platform?: never;
    LandsatCloudCoverLand?: never;
} | {
    EoCloudCover?: never;
    ViewOffNadir: ViewOffNadirInput;
    ViewSunAzimuth?: never;
    ViewSunElevation?: never;
    Platform?: never;
    LandsatCloudCoverLand?: never;
} | {
    EoCloudCover?: never;
    ViewOffNadir?: never;
    ViewSunAzimuth: ViewSunAzimuthInput;
    ViewSunElevation?: never;
    Platform?: never;
    LandsatCloudCoverLand?: never;
} | {
    EoCloudCover?: never;
    ViewOffNadir?: never;
    ViewSunAzimuth?: never;
    ViewSunElevation: ViewSunElevationInput;
    Platform?: never;
    LandsatCloudCoverLand?: never;
} | {
    EoCloudCover?: never;
    ViewOffNadir?: never;
    ViewSunAzimuth?: never;
    ViewSunElevation?: never;
    Platform: PlatformInput;
    LandsatCloudCoverLand?: never;
} | {
    EoCloudCover?: never;
    ViewOffNadir?: never;
    ViewSunAzimuth?: never;
    ViewSunElevation?: never;
    Platform?: never;
    LandsatCloudCoverLand: LandsatCloudCoverLandInput;
};
export interface PropertyFilter {
    Property: Property;
}
export type PropertyFiltersList = PropertyFilter[];
export type LogicalOperator = string;
export interface PropertyFilters {
    Properties?: PropertyFilter[];
    LogicalOperator?: string;
}
export interface RasterDataCollectionQueryOutput {
    RasterDataCollectionArn: string;
    RasterDataCollectionName: string;
    TimeRangeFilter: TimeRangeFilterOutput;
    AreaOfInterest?: AreaOfInterest;
    PropertyFilters?: PropertyFilters;
}
export interface InputConfigOutput {
    PreviousEarthObservationJobArn?: string;
    RasterDataCollectionQuery?: RasterDataCollectionQueryOutput;
}
export type StringListInput = string[];
export type OutputType = string;
export interface Operation {
    Name: string;
    Equation: string;
    OutputType?: string;
}
export type OperationsListInput = Operation[];
export interface CustomIndicesInput {
    Operations?: Operation[];
}
export interface BandMathConfigInput {
    PredefinedIndices?: string[];
    CustomIndices?: CustomIndicesInput;
}
export type Unit = string;
export interface UserDefined {
    Value: number;
    Unit: string;
}
export interface OutputResolutionResamplingInput {
    UserDefined: UserDefined;
}
export type AlgorithmNameResampling = string;
export interface ResamplingConfigInput {
    OutputResolution: OutputResolutionResamplingInput;
    AlgorithmName?: string;
    TargetBands?: string[];
}
export type GroupBy = string;
export type TemporalStatistics = string;
export type TemporalStatisticsListInput = string[];
export interface TemporalStatisticsConfigInput {
    GroupBy?: string;
    Statistics: string[];
    TargetBands?: string[];
}
export type AlgorithmNameCloudRemoval = string;
export interface CloudRemovalConfigInput {
    AlgorithmName?: string;
    InterpolationValue?: string;
    TargetBands?: string[];
}
export type ZonalStatistics = string;
export type ZonalStatisticsListInput = string[];
export interface ZonalStatisticsConfigInput {
    ZoneS3Path: string;
    Statistics: string[];
    TargetBands?: string[];
    ZoneS3PathKmsKeyId?: string;
}
export type AlgorithmNameGeoMosaic = string;
export interface GeoMosaicConfigInput {
    AlgorithmName?: string;
    TargetBands?: string[];
}
export type PredefinedResolution = string;
export interface OutputResolutionStackInput {
    Predefined?: string;
    UserDefined?: UserDefined;
}
export interface StackConfigInput {
    OutputResolution?: OutputResolutionStackInput;
    TargetBands?: string[];
}
export interface CloudMaskingConfigInput {
}
export interface LandCoverSegmentationConfigInput {
}
export type JobConfigInput = {
    BandMathConfig: BandMathConfigInput;
    ResamplingConfig?: never;
    TemporalStatisticsConfig?: never;
    CloudRemovalConfig?: never;
    ZonalStatisticsConfig?: never;
    GeoMosaicConfig?: never;
    StackConfig?: never;
    CloudMaskingConfig?: never;
    LandCoverSegmentationConfig?: never;
} | {
    BandMathConfig?: never;
    ResamplingConfig: ResamplingConfigInput;
    TemporalStatisticsConfig?: never;
    CloudRemovalConfig?: never;
    ZonalStatisticsConfig?: never;
    GeoMosaicConfig?: never;
    StackConfig?: never;
    CloudMaskingConfig?: never;
    LandCoverSegmentationConfig?: never;
} | {
    BandMathConfig?: never;
    ResamplingConfig?: never;
    TemporalStatisticsConfig: TemporalStatisticsConfigInput;
    CloudRemovalConfig?: never;
    ZonalStatisticsConfig?: never;
    GeoMosaicConfig?: never;
    StackConfig?: never;
    CloudMaskingConfig?: never;
    LandCoverSegmentationConfig?: never;
} | {
    BandMathConfig?: never;
    ResamplingConfig?: never;
    TemporalStatisticsConfig?: never;
    CloudRemovalConfig: CloudRemovalConfigInput;
    ZonalStatisticsConfig?: never;
    GeoMosaicConfig?: never;
    StackConfig?: never;
    CloudMaskingConfig?: never;
    LandCoverSegmentationConfig?: never;
} | {
    BandMathConfig?: never;
    ResamplingConfig?: never;
    TemporalStatisticsConfig?: never;
    CloudRemovalConfig?: never;
    ZonalStatisticsConfig: ZonalStatisticsConfigInput;
    GeoMosaicConfig?: never;
    StackConfig?: never;
    CloudMaskingConfig?: never;
    LandCoverSegmentationConfig?: never;
} | {
    BandMathConfig?: never;
    ResamplingConfig?: never;
    TemporalStatisticsConfig?: never;
    CloudRemovalConfig?: never;
    ZonalStatisticsConfig?: never;
    GeoMosaicConfig: GeoMosaicConfigInput;
    StackConfig?: never;
    CloudMaskingConfig?: never;
    LandCoverSegmentationConfig?: never;
} | {
    BandMathConfig?: never;
    ResamplingConfig?: never;
    TemporalStatisticsConfig?: never;
    CloudRemovalConfig?: never;
    ZonalStatisticsConfig?: never;
    GeoMosaicConfig?: never;
    StackConfig: StackConfigInput;
    CloudMaskingConfig?: never;
    LandCoverSegmentationConfig?: never;
} | {
    BandMathConfig?: never;
    ResamplingConfig?: never;
    TemporalStatisticsConfig?: never;
    CloudRemovalConfig?: never;
    ZonalStatisticsConfig?: never;
    GeoMosaicConfig?: never;
    StackConfig?: never;
    CloudMaskingConfig: CloudMaskingConfigInput;
    LandCoverSegmentationConfig?: never;
} | {
    BandMathConfig?: never;
    ResamplingConfig?: never;
    TemporalStatisticsConfig?: never;
    CloudRemovalConfig?: never;
    ZonalStatisticsConfig?: never;
    GeoMosaicConfig?: never;
    StackConfig?: never;
    CloudMaskingConfig?: never;
    LandCoverSegmentationConfig: LandCoverSegmentationConfigInput;
};
export interface OutputBand {
    BandName: string;
    OutputDataType: string;
}
export type EarthObservationJobOutputBands = OutputBand[];
export type EarthObservationJobErrorType = string;
export interface EarthObservationJobErrorDetails {
    Type?: string;
    Message?: string;
}
export type ExportErrorType = string;
export interface ExportErrorDetailsOutput {
    Type?: string;
    Message?: string;
}
export interface ExportErrorDetails {
    ExportResults?: ExportErrorDetailsOutput;
    ExportSourceImages?: ExportErrorDetailsOutput;
}
export type Tags = {
    [key: string]: string | undefined;
};
export interface GetEarthObservationJobOutput {
    Arn: string;
    Name: string;
    CreationTime: Date;
    DurationInSeconds: number;
    Status: string;
    KmsKeyId?: string;
    InputConfig: InputConfigOutput;
    JobConfig: JobConfigInput;
    OutputBands?: OutputBand[];
    ExecutionRoleArn?: string;
    ErrorDetails?: EarthObservationJobErrorDetails;
    ExportStatus?: string;
    ExportErrorDetails?: ExportErrorDetails;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetRasterDataCollectionInput {
    Arn: string;
}
export type DataCollectionType = string;
export interface Filter {
    Name: string;
    Type: string;
    Minimum?: number;
    Maximum?: number;
}
export type FilterList = Filter[];
export type ImageSourceBandList = string[];
export interface GetRasterDataCollectionOutput {
    Name: string;
    Arn: string;
    Type: string;
    Description: string;
    DescriptionPageUrl: string;
    SupportedFilters: Filter[];
    ImageSourceBands: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type TargetOptions = string;
export interface GetTileInput {
    x: number;
    y: number;
    z: number;
    ImageAssets: string[];
    Target: string;
    Arn: string;
    ImageMask?: boolean;
    OutputFormat?: string;
    TimeRangeFilter?: string;
    PropertyFilters?: string;
    OutputDataType?: string;
    ExecutionRoleArn?: string;
}
export interface GetTileOutput {
    BinaryFile?: T.StreamingOutputBody;
}
export interface GetVectorEnrichmentJobInput {
    Arn: string;
}
export type VectorEnrichmentJobType = string;
export type VectorEnrichmentJobStatus = string;
export type VectorEnrichmentJobDocumentType = string;
export type VectorEnrichmentJobDataSourceConfigInput = {
    S3Data: VectorEnrichmentJobS3Data;
};
export interface VectorEnrichmentJobInputConfig {
    DocumentType: string;
    DataSourceConfig: VectorEnrichmentJobDataSourceConfigInput;
}
export interface ReverseGeocodingConfig {
    YAttributeName: string;
    XAttributeName: string;
}
export interface MapMatchingConfig {
    IdAttributeName: string;
    YAttributeName: string;
    XAttributeName: string;
    TimestampAttributeName: string;
}
export type VectorEnrichmentJobConfig = {
    ReverseGeocodingConfig: ReverseGeocodingConfig;
    MapMatchingConfig?: never;
} | {
    ReverseGeocodingConfig?: never;
    MapMatchingConfig: MapMatchingConfig;
};
export type VectorEnrichmentJobErrorType = string;
export interface VectorEnrichmentJobErrorDetails {
    ErrorType?: string;
    ErrorMessage?: string;
}
export type VectorEnrichmentJobExportErrorType = string;
export interface VectorEnrichmentJobExportErrorDetails {
    Type?: string;
    Message?: string;
}
export interface GetVectorEnrichmentJobOutput {
    Arn: string;
    Type: string;
    Name: string;
    CreationTime: Date;
    DurationInSeconds: number;
    Status: string;
    KmsKeyId?: string;
    InputConfig: VectorEnrichmentJobInputConfig;
    JobConfig: VectorEnrichmentJobConfig;
    ExecutionRoleArn: string;
    ErrorDetails?: VectorEnrichmentJobErrorDetails;
    ExportStatus?: string;
    ExportErrorDetails?: VectorEnrichmentJobExportErrorDetails;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type SortOrder = string;
export type NextToken = string | redacted.Redacted<string>;
export interface ListEarthObservationJobInput {
    StatusEquals?: string;
    SortOrder?: string;
    SortBy?: string;
    NextToken?: string | redacted.Redacted<string>;
    MaxResults?: number;
}
export interface ListEarthObservationJobOutputConfig {
    Arn: string;
    Name: string;
    CreationTime: Date;
    DurationInSeconds: number;
    Status: string;
    OperationType: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type EarthObservationJobList = ListEarthObservationJobOutputConfig[];
export interface ListEarthObservationJobOutput {
    EarthObservationJobSummaries: ListEarthObservationJobOutputConfig[];
    NextToken?: string | redacted.Redacted<string>;
}
export interface ListRasterDataCollectionsInput {
    NextToken?: string | redacted.Redacted<string>;
    MaxResults?: number;
}
export interface RasterDataCollectionMetadata {
    Name: string;
    Arn: string;
    Type: string;
    Description: string;
    DescriptionPageUrl?: string;
    SupportedFilters: Filter[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type DataCollectionsList = RasterDataCollectionMetadata[];
export interface ListRasterDataCollectionsOutput {
    RasterDataCollectionSummaries: RasterDataCollectionMetadata[];
    NextToken?: string | redacted.Redacted<string>;
}
export type Arn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListVectorEnrichmentJobInput {
    StatusEquals?: string;
    SortOrder?: string;
    SortBy?: string;
    NextToken?: string | redacted.Redacted<string>;
    MaxResults?: number;
}
export interface ListVectorEnrichmentJobOutputConfig {
    Arn: string;
    Name: string;
    Type: string;
    CreationTime: Date;
    DurationInSeconds: number;
    Status: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type VectorEnrichmentJobList = ListVectorEnrichmentJobOutputConfig[];
export interface ListVectorEnrichmentJobOutput {
    VectorEnrichmentJobSummaries: ListVectorEnrichmentJobOutputConfig[];
    NextToken?: string | redacted.Redacted<string>;
}
export interface TimeRangeFilterInput {
    StartTime: Date;
    EndTime: Date;
}
export interface RasterDataCollectionQueryWithBandFilterInput {
    TimeRangeFilter: TimeRangeFilterInput;
    AreaOfInterest?: AreaOfInterest;
    PropertyFilters?: PropertyFilters;
    BandFilter?: string[];
}
export interface SearchRasterDataCollectionInput {
    Arn: string;
    RasterDataCollectionQuery: RasterDataCollectionQueryWithBandFilterInput;
    NextToken?: string | redacted.Redacted<string>;
}
export interface Geometry {
    Type: string;
    Coordinates: number[][][];
}
export interface AssetValue {
    Href?: string;
}
export type AssetsMap = {
    [key: string]: AssetValue | undefined;
};
export interface Properties {
    EoCloudCover?: number;
    ViewOffNadir?: number;
    ViewSunAzimuth?: number;
    ViewSunElevation?: number;
    Platform?: string;
    LandsatCloudCoverLand?: number;
}
export interface ItemSource {
    Id: string;
    Geometry: Geometry;
    Assets?: {
        [key: string]: AssetValue | undefined;
    };
    DateTime: Date;
    Properties?: Properties;
}
export type ItemSourceList = ItemSource[];
export interface SearchRasterDataCollectionOutput {
    ApproximateResultCount: number;
    NextToken?: string | redacted.Redacted<string>;
    Items?: ItemSource[];
}
export interface RasterDataCollectionQueryInput {
    RasterDataCollectionArn: string;
    TimeRangeFilter: TimeRangeFilterInput;
    AreaOfInterest?: AreaOfInterest;
    PropertyFilters?: PropertyFilters;
}
export interface InputConfigInput {
    PreviousEarthObservationJobArn?: string;
    RasterDataCollectionQuery?: RasterDataCollectionQueryInput;
}
export interface StartEarthObservationJobInput {
    Name: string;
    ClientToken?: string;
    KmsKeyId?: string;
    InputConfig: InputConfigInput;
    JobConfig: JobConfigInput;
    ExecutionRoleArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface StartEarthObservationJobOutput {
    Name: string;
    Arn: string;
    CreationTime: Date;
    DurationInSeconds: number;
    Status: string;
    KmsKeyId?: string;
    InputConfig?: InputConfigOutput;
    JobConfig: JobConfigInput;
    ExecutionRoleArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface StartVectorEnrichmentJobInput {
    Name: string;
    ClientToken?: string;
    KmsKeyId?: string;
    InputConfig: VectorEnrichmentJobInputConfig;
    JobConfig: VectorEnrichmentJobConfig;
    ExecutionRoleArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface StartVectorEnrichmentJobOutput {
    Name: string;
    Arn: string;
    Type: string;
    CreationTime: Date;
    DurationInSeconds: number;
    Status: string;
    KmsKeyId?: string;
    InputConfig: VectorEnrichmentJobInputConfig;
    JobConfig: VectorEnrichmentJobConfig;
    ExecutionRoleArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface StopEarthObservationJobInput {
    Arn: string;
}
export interface StopEarthObservationJobOutput {
}
export interface StopVectorEnrichmentJobInput {
    Arn: string;
}
export interface StopVectorEnrichmentJobOutput {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export type DeleteEarthObservationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this operation to delete an Earth Observation job.
 */
export declare const deleteEarthObservationJob: API.OperationMethod<DeleteEarthObservationJobInput, DeleteEarthObservationJobOutput, DeleteEarthObservationJobError, Credentials | HttpClient.HttpClient>;
export type DeleteVectorEnrichmentJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this operation to delete a Vector Enrichment job.
 */
export declare const deleteVectorEnrichmentJob: API.OperationMethod<DeleteVectorEnrichmentJobInput, DeleteVectorEnrichmentJobOutput, DeleteVectorEnrichmentJobError, Credentials | HttpClient.HttpClient>;
export type ExportEarthObservationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this operation to export results of an Earth Observation job and optionally source images used as input to the EOJ to an Amazon S3 location.
 */
export declare const exportEarthObservationJob: API.OperationMethod<ExportEarthObservationJobInput, ExportEarthObservationJobOutput, ExportEarthObservationJobError, Credentials | HttpClient.HttpClient>;
export type ExportVectorEnrichmentJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this operation to copy results of a Vector Enrichment job to an Amazon S3 location.
 */
export declare const exportVectorEnrichmentJob: API.OperationMethod<ExportVectorEnrichmentJobInput, ExportVectorEnrichmentJobOutput, ExportVectorEnrichmentJobError, Credentials | HttpClient.HttpClient>;
export type GetEarthObservationJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the details for a previously initiated Earth Observation job.
 */
export declare const getEarthObservationJob: API.OperationMethod<GetEarthObservationJobInput, GetEarthObservationJobOutput, GetEarthObservationJobError, Credentials | HttpClient.HttpClient>;
export type GetRasterDataCollectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this operation to get details of a specific raster data collection.
 */
export declare const getRasterDataCollection: API.OperationMethod<GetRasterDataCollectionInput, GetRasterDataCollectionOutput, GetRasterDataCollectionError, Credentials | HttpClient.HttpClient>;
export type GetTileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a web mercator tile for the given Earth Observation job.
 */
export declare const getTile: API.OperationMethod<GetTileInput, GetTileOutput, GetTileError, Credentials | HttpClient.HttpClient>;
export type GetVectorEnrichmentJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details of a Vector Enrichment Job for a given job Amazon Resource Name (ARN).
 */
export declare const getVectorEnrichmentJob: API.OperationMethod<GetVectorEnrichmentJobInput, GetVectorEnrichmentJobOutput, GetVectorEnrichmentJobError, Credentials | HttpClient.HttpClient>;
export type ListEarthObservationJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this operation to get a list of the Earth Observation jobs associated with the calling Amazon Web Services account.
 */
export declare const listEarthObservationJobs: API.PaginatedOperationMethod<ListEarthObservationJobInput, ListEarthObservationJobOutput, ListEarthObservationJobsError, Credentials | HttpClient.HttpClient, ListEarthObservationJobOutputConfig>;
export type ListRasterDataCollectionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this operation to get raster data collections.
 */
export declare const listRasterDataCollections: API.PaginatedOperationMethod<ListRasterDataCollectionsInput, ListRasterDataCollectionsOutput, ListRasterDataCollectionsError, Credentials | HttpClient.HttpClient, RasterDataCollectionMetadata>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags attached to the resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVectorEnrichmentJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of vector enrichment jobs.
 */
export declare const listVectorEnrichmentJobs: API.PaginatedOperationMethod<ListVectorEnrichmentJobInput, ListVectorEnrichmentJobOutput, ListVectorEnrichmentJobsError, Credentials | HttpClient.HttpClient, ListVectorEnrichmentJobOutputConfig>;
export type SearchRasterDataCollectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows you run image query on a specific raster data collection to get a list of the satellite imagery matching the selected filters.
 */
export declare const searchRasterDataCollection: API.PaginatedOperationMethod<SearchRasterDataCollectionInput, SearchRasterDataCollectionOutput, SearchRasterDataCollectionError, Credentials | HttpClient.HttpClient, unknown>;
export type StartEarthObservationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this operation to create an Earth observation job.
 */
export declare const startEarthObservationJob: API.OperationMethod<StartEarthObservationJobInput, StartEarthObservationJobOutput, StartEarthObservationJobError, Credentials | HttpClient.HttpClient>;
export type StartVectorEnrichmentJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a Vector Enrichment job for the supplied job type. Currently, there are two supported job types: reverse geocoding and map matching.
 */
export declare const startVectorEnrichmentJob: API.OperationMethod<StartVectorEnrichmentJobInput, StartVectorEnrichmentJobOutput, StartVectorEnrichmentJobError, Credentials | HttpClient.HttpClient>;
export type StopEarthObservationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this operation to stop an existing earth observation job.
 */
export declare const stopEarthObservationJob: API.OperationMethod<StopEarthObservationJobInput, StopEarthObservationJobOutput, StopEarthObservationJobError, Credentials | HttpClient.HttpClient>;
export type StopVectorEnrichmentJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops the Vector Enrichment job for a given job ARN.
 */
export declare const stopVectorEnrichmentJob: API.OperationMethod<StopVectorEnrichmentJobInput, StopVectorEnrichmentJobOutput, StopVectorEnrichmentJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The resource you want to tag.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The resource you want to untag.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=sagemaker-geospatial.d.ts.map