import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AuthorizationException_base: S.TaggedErrorClass<"AuthorizationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AuthorizationException extends /*@__PURE__*/ AuthorizationException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const EntitlementNotAllowedException_base: S.TaggedErrorClass<"EntitlementNotAllowedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EntitlementNotAllowedException extends /*@__PURE__*/ EntitlementNotAllowedException_base {
}
declare const FailedDependencyException_base: S.TaggedErrorClass<"FailedDependencyException", {
    readonly message: any;
    readonly ErrorCode: any;
}>;
export declare class FailedDependencyException extends /*@__PURE__*/ FailedDependencyException_base {
}
declare const FilterLimitExceededException_base: S.TaggedErrorClass<"FilterLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class FilterLimitExceededException extends /*@__PURE__*/ FilterLimitExceededException_base {
}
declare const InvalidParameterValueException_base: S.TaggedErrorClass<"InvalidParameterValueException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const InvalidResourceStateException_base: S.TaggedErrorClass<"InvalidResourceStateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidResourceStateException extends /*@__PURE__*/ InvalidResourceStateException_base {
}
declare const LicenseConfigurationNotFound_base: S.TaggedErrorClass<"LicenseConfigurationNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class LicenseConfigurationNotFound extends /*@__PURE__*/ LicenseConfigurationNotFound_base {
}
declare const LicenseUsageException_base: S.TaggedErrorClass<"LicenseUsageException", {
    readonly message: any;
}>;
export declare class LicenseUsageException extends /*@__PURE__*/ LicenseUsageException_base {
}
declare const NoEntitlementsAllowedException_base: S.TaggedErrorClass<"NoEntitlementsAllowedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoEntitlementsAllowedException extends /*@__PURE__*/ NoEntitlementsAllowedException_base {
}
declare const RateLimitExceededException_base: S.TaggedErrorClass<"RateLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class RateLimitExceededException extends /*@__PURE__*/ RateLimitExceededException_base {
}
declare const RedirectException_base: S.TaggedErrorClass<"RedirectException", {
    readonly Location: any;
    readonly message: any;
}>;
export declare class RedirectException extends /*@__PURE__*/ RedirectException_base {
}
declare const ResourceLimitExceededException_base: S.TaggedErrorClass<"ResourceLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceLimitExceededException extends /*@__PURE__*/ ResourceLimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServerInternalException_base: S.TaggedErrorClass<"ServerInternalException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServerInternalException extends /*@__PURE__*/ ServerInternalException_base {
}
declare const UnsupportedDigitalSignatureMethodException_base: S.TaggedErrorClass<"UnsupportedDigitalSignatureMethodException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedDigitalSignatureMethodException extends /*@__PURE__*/ UnsupportedDigitalSignatureMethodException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Arn = string;
export interface AcceptGrantRequest {
    GrantArn: string;
}
export type GrantStatus = "PENDING_WORKFLOW" | "PENDING_ACCEPT" | "REJECTED" | "ACTIVE" | "FAILED_WORKFLOW" | "DELETED" | "PENDING_DELETE" | "DISABLED" | "WORKFLOW_COMPLETED" | (string & {});
export interface AcceptGrantResponse {
    GrantArn?: string;
    Status?: GrantStatus;
    Version?: string;
}
export interface CheckInLicenseRequest {
    LicenseConsumptionToken: string;
    Beneficiary?: string;
}
export interface CheckInLicenseResponse {
}
export type EntitlementDataUnit = "Count" | "None" | "Seconds" | "Microseconds" | "Milliseconds" | "Bytes" | "Kilobytes" | "Megabytes" | "Gigabytes" | "Terabytes" | "Bits" | "Kilobits" | "Megabits" | "Gigabits" | "Terabits" | "Percent" | "Bytes/Second" | "Kilobytes/Second" | "Megabytes/Second" | "Gigabytes/Second" | "Terabytes/Second" | "Bits/Second" | "Kilobits/Second" | "Megabits/Second" | "Gigabits/Second" | "Terabits/Second" | "Count/Second" | (string & {});
export interface EntitlementData {
    Name: string;
    Value?: string;
    Unit: EntitlementDataUnit;
}
export type EntitlementDataList = EntitlementData[];
export type DigitalSignatureMethod = "JWT_PS384" | (string & {});
export interface Metadata {
    Name?: string;
    Value?: string;
}
export type MetadataList = Metadata[];
export type ClientToken = string;
export interface CheckoutBorrowLicenseRequest {
    LicenseArn: string;
    Entitlements: EntitlementData[];
    DigitalSignatureMethod: DigitalSignatureMethod;
    NodeId?: string;
    CheckoutMetadata?: Metadata[];
    ClientToken: string;
}
export type SignedToken = string;
export type ISO8601DateTime = string;
export interface CheckoutBorrowLicenseResponse {
    LicenseArn?: string;
    LicenseConsumptionToken?: string;
    EntitlementsAllowed?: EntitlementData[];
    NodeId?: string;
    SignedToken?: string;
    IssuedAt?: string;
    Expiration?: string;
    CheckoutMetadata?: Metadata[];
}
export type CheckoutType = "PROVISIONAL" | "PERPETUAL" | (string & {});
export interface CheckoutLicenseRequest {
    ProductSKU: string;
    CheckoutType: CheckoutType;
    KeyFingerprint: string;
    Entitlements: EntitlementData[];
    ClientToken: string;
    Beneficiary?: string;
    NodeId?: string;
}
export interface CheckoutLicenseResponse {
    CheckoutType?: CheckoutType;
    LicenseConsumptionToken?: string;
    EntitlementsAllowed?: EntitlementData[];
    SignedToken?: string;
    NodeId?: string;
    IssuedAt?: string;
    Expiration?: string;
    LicenseArn?: string;
}
export type PrincipalArnList = string[];
export type AllowedOperation = "CreateGrant" | "CheckoutLicense" | "CheckoutBorrowLicense" | "CheckInLicense" | "ExtendConsumptionLicense" | "ListPurchasedLicenses" | "CreateToken" | (string & {});
export type AllowedOperationList = AllowedOperation[];
export interface Tag {
    Key?: string;
    Value?: string;
}
export type TagList = Tag[];
export interface CreateGrantRequest {
    ClientToken: string;
    GrantName: string;
    LicenseArn: string;
    Principals: string[];
    HomeRegion: string;
    AllowedOperations: AllowedOperation[];
    Tags?: Tag[];
}
export interface CreateGrantResponse {
    GrantArn?: string;
    Status?: GrantStatus;
    Version?: string;
}
export type StatusReasonMessage = string;
export type ActivationOverrideBehavior = "DISTRIBUTED_GRANTS_ONLY" | "ALL_GRANTS_PERMITTED_BY_ISSUER" | (string & {});
export interface Options {
    ActivationOverrideBehavior?: ActivationOverrideBehavior;
}
export interface CreateGrantVersionRequest {
    ClientToken: string;
    GrantArn: string;
    GrantName?: string;
    AllowedOperations?: AllowedOperation[];
    Status?: GrantStatus;
    StatusReason?: string;
    SourceVersion?: string;
    Options?: Options;
}
export interface CreateGrantVersionResponse {
    GrantArn?: string;
    Status?: GrantStatus;
    Version?: string;
}
export interface Issuer {
    Name: string;
    SignKey?: string;
}
export interface DatetimeRange {
    Begin: string;
    End?: string;
}
export type BoxBoolean = boolean;
export type EntitlementUnit = "Count" | "None" | "Seconds" | "Microseconds" | "Milliseconds" | "Bytes" | "Kilobytes" | "Megabytes" | "Gigabytes" | "Terabytes" | "Bits" | "Kilobits" | "Megabits" | "Gigabits" | "Terabits" | "Percent" | "Bytes/Second" | "Kilobytes/Second" | "Megabytes/Second" | "Gigabytes/Second" | "Terabytes/Second" | "Bits/Second" | "Kilobits/Second" | "Megabits/Second" | "Gigabits/Second" | "Terabits/Second" | "Count/Second" | (string & {});
export interface Entitlement {
    Name: string;
    Value?: string;
    MaxCount?: number;
    Overage?: boolean;
    Unit: EntitlementUnit;
    AllowCheckIn?: boolean;
}
export type EntitlementList = Entitlement[];
export type RenewType = "None" | "Weekly" | "Monthly" | (string & {});
export type BoxInteger = number;
export interface ProvisionalConfiguration {
    MaxTimeToLiveInMinutes: number;
}
export interface BorrowConfiguration {
    AllowEarlyCheckIn: boolean;
    MaxTimeToLiveInMinutes: number;
}
export interface ConsumptionConfiguration {
    RenewType?: RenewType;
    ProvisionalConfiguration?: ProvisionalConfiguration;
    BorrowConfiguration?: BorrowConfiguration;
}
export interface CreateLicenseRequest {
    LicenseName: string;
    ProductName: string;
    ProductSKU: string;
    Issuer: Issuer;
    HomeRegion: string;
    Validity: DatetimeRange;
    Entitlements: Entitlement[];
    Beneficiary: string;
    ConsumptionConfiguration: ConsumptionConfiguration;
    LicenseMetadata?: Metadata[];
    ClientToken: string;
    Tags?: Tag[];
}
export type LicenseStatus = "AVAILABLE" | "PENDING_AVAILABLE" | "DEACTIVATED" | "SUSPENDED" | "EXPIRED" | "PENDING_DELETE" | "DELETED" | (string & {});
export interface CreateLicenseResponse {
    LicenseArn?: string;
    Status?: LicenseStatus;
    Version?: string;
}
export type LicenseAssetResourceName = string;
export type LicenseAssetResourceDescription = string;
export interface LicenseAssetGroupConfiguration {
    UsageDimension?: string;
}
export type LicenseAssetGroupConfigurationList = LicenseAssetGroupConfiguration[];
export type LicenseAssetRulesetArnList = string[];
export interface LicenseAssetGroupProperty {
    Key: string;
    Value: string;
}
export type LicenseAssetGroupPropertyList = LicenseAssetGroupProperty[];
export interface CreateLicenseAssetGroupRequest {
    Name: string;
    Description?: string;
    LicenseAssetGroupConfigurations: LicenseAssetGroupConfiguration[];
    AssociatedLicenseAssetRulesetARNs: string[];
    Properties?: LicenseAssetGroupProperty[];
    Tags?: Tag[];
    ClientToken: string;
}
export interface CreateLicenseAssetGroupResponse {
    LicenseAssetGroupArn: string;
    Status: string;
}
export type StringList = string[];
export interface MatchingRuleStatement {
    KeyToMatch: string;
    Constraint: string;
    ValueToMatch: string[];
}
export type MatchingRuleStatementList = MatchingRuleStatement[];
export interface ScriptRuleStatement {
    KeyToMatch: string;
    Script: string;
}
export type ScriptRuleStatementList = ScriptRuleStatement[];
export interface AndRuleStatement {
    MatchingRuleStatements?: MatchingRuleStatement[];
    ScriptRuleStatements?: ScriptRuleStatement[];
}
export interface OrRuleStatement {
    MatchingRuleStatements?: MatchingRuleStatement[];
    ScriptRuleStatements?: ScriptRuleStatement[];
}
export interface LicenseConfigurationRuleStatement {
    AndRuleStatement?: AndRuleStatement;
    OrRuleStatement?: OrRuleStatement;
    MatchingRuleStatement?: MatchingRuleStatement;
}
export interface LicenseRuleStatement {
    AndRuleStatement?: AndRuleStatement;
    OrRuleStatement?: OrRuleStatement;
    MatchingRuleStatement?: MatchingRuleStatement;
}
export interface InstanceRuleStatement {
    AndRuleStatement?: AndRuleStatement;
    OrRuleStatement?: OrRuleStatement;
    MatchingRuleStatement?: MatchingRuleStatement;
    ScriptRuleStatement?: ScriptRuleStatement;
}
export interface RuleStatement {
    LicenseConfigurationRuleStatement?: LicenseConfigurationRuleStatement;
    LicenseRuleStatement?: LicenseRuleStatement;
    InstanceRuleStatement?: InstanceRuleStatement;
}
export interface LicenseAssetRule {
    RuleStatement: RuleStatement;
}
export type LicenseAssetRuleList = LicenseAssetRule[];
export interface CreateLicenseAssetRulesetRequest {
    Name: string;
    Description?: string;
    Rules: LicenseAssetRule[];
    Tags?: Tag[];
    ClientToken: string;
}
export interface CreateLicenseAssetRulesetResponse {
    LicenseAssetRulesetArn: string;
}
export type LicenseCountingType = "vCPU" | "Instance" | "Core" | "Socket" | (string & {});
export type BoxLong = number;
export interface ProductInformationFilter {
    ProductInformationFilterName: string;
    ProductInformationFilterValue?: string[];
    ProductInformationFilterComparator: string;
}
export type ProductInformationFilterList = ProductInformationFilter[];
export interface ProductInformation {
    ResourceType: string;
    ProductInformationFilterList: ProductInformationFilter[];
}
export type ProductInformationList = ProductInformation[];
export interface CreateLicenseConfigurationRequest {
    Name: string;
    Description?: string;
    LicenseCountingType: LicenseCountingType;
    LicenseCount?: number;
    LicenseCountHardLimit?: boolean;
    LicenseRules?: string[];
    Tags?: Tag[];
    DisassociateWhenNotFound?: boolean;
    ProductInformationList?: ProductInformation[];
    LicenseExpiry?: number;
}
export interface CreateLicenseConfigurationResponse {
    LicenseConfigurationArn?: string;
}
export type UsageOperation = string;
export type ProductCodeId = string;
export type ProductCodeType = "marketplace" | (string & {});
export interface ProductCodeListItem {
    ProductCodeId: string;
    ProductCodeType: ProductCodeType;
}
export type ProductCodeList = ProductCodeListItem[];
export interface LicenseConversionContext {
    UsageOperation?: string;
    ProductCodes?: ProductCodeListItem[];
}
export interface CreateLicenseConversionTaskForResourceRequest {
    ResourceArn: string;
    SourceLicenseContext: LicenseConversionContext;
    DestinationLicenseContext: LicenseConversionContext;
}
export type LicenseConversionTaskId = string;
export interface CreateLicenseConversionTaskForResourceResponse {
    LicenseConversionTaskId?: string;
}
export type ReportGeneratorName = string;
export type ReportType = "LicenseConfigurationSummaryReport" | "LicenseConfigurationUsageReport" | "LicenseAssetGroupUsageReport" | (string & {});
export type ReportTypeList = ReportType[];
export type ArnList = string[];
export interface ReportContext {
    licenseConfigurationArns?: string[];
    licenseAssetGroupArns?: string[];
    reportStartDate?: Date;
    reportEndDate?: Date;
}
export type ReportFrequencyType = "DAY" | "WEEK" | "MONTH" | "ONE_TIME" | (string & {});
export interface ReportFrequency {
    value?: number;
    period?: ReportFrequencyType;
}
export type ClientRequestToken = string;
export interface CreateLicenseManagerReportGeneratorRequest {
    ReportGeneratorName: string;
    Type: ReportType[];
    ReportContext: ReportContext;
    ReportFrequency: ReportFrequency;
    ClientToken: string;
    Description?: string;
    Tags?: Tag[];
}
export interface CreateLicenseManagerReportGeneratorResponse {
    LicenseManagerReportGeneratorArn?: string;
}
export interface CreateLicenseVersionRequest {
    LicenseArn: string;
    LicenseName: string;
    ProductName: string;
    Issuer: Issuer;
    HomeRegion: string;
    Validity: DatetimeRange;
    LicenseMetadata?: Metadata[];
    Entitlements: Entitlement[];
    ConsumptionConfiguration: ConsumptionConfiguration;
    Status: LicenseStatus;
    ClientToken: string;
    SourceVersion?: string;
    ResetUsage?: boolean;
}
export interface CreateLicenseVersionResponse {
    LicenseArn?: string;
    Version?: string;
    Status?: LicenseStatus;
}
export type MaxSize3StringList = string[];
export interface CreateTokenRequest {
    LicenseArn: string;
    RoleArns?: string[];
    ExpirationInDays?: number;
    TokenProperties?: string[];
    ClientToken: string;
}
export type TokenType = "REFRESH_TOKEN" | (string & {});
export type TokenString = string;
export interface CreateTokenResponse {
    TokenId?: string;
    TokenType?: TokenType;
    Token?: string | redacted.Redacted<string>;
}
export interface DeleteGrantRequest {
    GrantArn: string;
    StatusReason?: string;
    Version: string;
}
export interface DeleteGrantResponse {
    GrantArn?: string;
    Status?: GrantStatus;
    Version?: string;
}
export interface DeleteLicenseRequest {
    LicenseArn: string;
    SourceVersion: string;
}
export type LicenseDeletionStatus = "PENDING_DELETE" | "DELETED" | (string & {});
export interface DeleteLicenseResponse {
    Status?: LicenseDeletionStatus;
    DeletionDate?: string;
}
export interface DeleteLicenseAssetGroupRequest {
    LicenseAssetGroupArn: string;
}
export type LicenseAssetGroupStatus = "ACTIVE" | "DISABLED" | "DELETED" | (string & {});
export interface DeleteLicenseAssetGroupResponse {
    Status: LicenseAssetGroupStatus;
}
export interface DeleteLicenseAssetRulesetRequest {
    LicenseAssetRulesetArn: string;
}
export interface DeleteLicenseAssetRulesetResponse {
}
export interface DeleteLicenseConfigurationRequest {
    LicenseConfigurationArn: string;
}
export interface DeleteLicenseConfigurationResponse {
}
export interface DeleteLicenseManagerReportGeneratorRequest {
    LicenseManagerReportGeneratorArn: string;
}
export interface DeleteLicenseManagerReportGeneratorResponse {
}
export interface DeleteTokenRequest {
    TokenId: string;
}
export interface DeleteTokenResponse {
}
export interface ExtendLicenseConsumptionRequest {
    LicenseConsumptionToken: string;
    DryRun?: boolean;
}
export interface ExtendLicenseConsumptionResponse {
    LicenseConsumptionToken?: string;
    Expiration?: string;
}
export interface GetAccessTokenRequest {
    Token: string | redacted.Redacted<string>;
    TokenProperties?: string[];
}
export interface GetAccessTokenResponse {
    AccessToken?: string | redacted.Redacted<string>;
}
export interface GetGrantRequest {
    GrantArn: string;
    Version?: string;
}
export interface Grant {
    GrantArn: string;
    GrantName: string;
    ParentArn: string;
    LicenseArn: string;
    GranteePrincipalArn: string;
    HomeRegion: string;
    GrantStatus: GrantStatus;
    StatusReason?: string;
    Version: string;
    GrantedOperations: AllowedOperation[];
    Options?: Options;
}
export interface GetGrantResponse {
    Grant?: Grant;
}
export interface GetLicenseRequest {
    LicenseArn: string;
    Version?: string;
}
export interface IssuerDetails {
    Name?: string;
    SignKey?: string;
    KeyFingerprint?: string;
}
export interface License {
    LicenseArn?: string;
    LicenseName?: string;
    ProductName?: string;
    ProductSKU?: string;
    Issuer?: IssuerDetails;
    HomeRegion?: string;
    Status?: LicenseStatus;
    Validity?: DatetimeRange;
    Beneficiary?: string;
    Entitlements?: Entitlement[];
    ConsumptionConfiguration?: ConsumptionConfiguration;
    LicenseMetadata?: Metadata[];
    CreateTime?: string;
    Version?: string;
}
export interface GetLicenseResponse {
    License?: License;
}
export interface GetLicenseAssetGroupRequest {
    LicenseAssetGroupArn: string;
}
export interface LicenseAssetGroup {
    Name: string;
    Description?: string;
    LicenseAssetGroupConfigurations?: LicenseAssetGroupConfiguration[];
    AssociatedLicenseAssetRulesetARNs: string[];
    Properties?: LicenseAssetGroupProperty[];
    LicenseAssetGroupArn: string;
    Status: LicenseAssetGroupStatus;
    StatusMessage?: string;
    LatestUsageAnalysisTime?: Date;
    LatestResourceDiscoveryTime?: Date;
}
export interface GetLicenseAssetGroupResponse {
    LicenseAssetGroup: LicenseAssetGroup;
}
export interface GetLicenseAssetRulesetRequest {
    LicenseAssetRulesetArn: string;
}
export interface LicenseAssetRuleset {
    Name: string;
    Description?: string;
    Rules: LicenseAssetRule[];
    LicenseAssetRulesetArn: string;
}
export interface GetLicenseAssetRulesetResponse {
    LicenseAssetRuleset: LicenseAssetRuleset;
}
export interface GetLicenseConfigurationRequest {
    LicenseConfigurationArn: string;
}
export type ResourceType = "EC2_INSTANCE" | "EC2_HOST" | "EC2_AMI" | "RDS" | "SYSTEMS_MANAGER_MANAGED_INSTANCE" | (string & {});
export interface ConsumedLicenseSummary {
    ResourceType?: ResourceType;
    ConsumedLicenses?: number;
}
export type ConsumedLicenseSummaryList = ConsumedLicenseSummary[];
export interface ManagedResourceSummary {
    ResourceType?: ResourceType;
    AssociationCount?: number;
}
export type ManagedResourceSummaryList = ManagedResourceSummary[];
export interface AutomatedDiscoveryInformation {
    LastRunTime?: Date;
}
export interface GetLicenseConfigurationResponse {
    LicenseConfigurationId?: string;
    LicenseConfigurationArn?: string;
    Name?: string;
    Description?: string;
    LicenseCountingType?: LicenseCountingType;
    LicenseRules?: string[];
    LicenseCount?: number;
    LicenseCountHardLimit?: boolean;
    ConsumedLicenses?: number;
    Status?: string;
    OwnerAccountId?: string;
    ConsumedLicenseSummaryList?: ConsumedLicenseSummary[];
    ManagedResourceSummaryList?: ManagedResourceSummary[];
    Tags?: Tag[];
    ProductInformationList?: ProductInformation[];
    AutomatedDiscoveryInformation?: AutomatedDiscoveryInformation;
    DisassociateWhenNotFound?: boolean;
    LicenseExpiry?: number;
}
export interface GetLicenseConversionTaskRequest {
    LicenseConversionTaskId: string;
}
export type LicenseConversionTaskStatus = "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | (string & {});
export interface GetLicenseConversionTaskResponse {
    LicenseConversionTaskId?: string;
    ResourceArn?: string;
    SourceLicenseContext?: LicenseConversionContext;
    DestinationLicenseContext?: LicenseConversionContext;
    StatusMessage?: string;
    Status?: LicenseConversionTaskStatus;
    StartTime?: Date;
    LicenseConversionTime?: Date;
    EndTime?: Date;
}
export interface GetLicenseManagerReportGeneratorRequest {
    LicenseManagerReportGeneratorArn: string;
}
export interface S3Location {
    bucket?: string;
    keyPrefix?: string;
}
export interface ReportGenerator {
    ReportGeneratorName?: string;
    ReportType?: ReportType[];
    ReportContext?: ReportContext;
    ReportFrequency?: ReportFrequency;
    LicenseManagerReportGeneratorArn?: string;
    LastRunStatus?: string;
    LastRunFailureReason?: string;
    LastReportGenerationTime?: string;
    ReportCreatorAccount?: string;
    Description?: string;
    S3Location?: S3Location;
    CreateTime?: string;
    Tags?: Tag[];
}
export interface GetLicenseManagerReportGeneratorResponse {
    ReportGenerator?: ReportGenerator;
}
export interface GetLicenseUsageRequest {
    LicenseArn: string;
}
export interface EntitlementUsage {
    Name: string;
    ConsumedValue: string;
    MaxCount?: string;
    Unit: EntitlementDataUnit;
}
export type EntitlementUsageList = EntitlementUsage[];
export interface LicenseUsage {
    EntitlementUsages?: EntitlementUsage[];
}
export interface GetLicenseUsageResponse {
    LicenseUsage?: LicenseUsage;
}
export interface GetServiceSettingsRequest {
}
export interface OrganizationConfiguration {
    EnableIntegration: boolean;
}
export interface CrossAccountDiscoveryServiceStatus {
    Message?: string;
}
export interface RegionStatus {
    Status?: string;
}
export type RegionStatusMap = {
    [key: string]: RegionStatus | undefined;
};
export interface CrossRegionDiscoveryStatus {
    Message?: {
        [key: string]: RegionStatus | undefined;
    };
}
export interface ServiceStatus {
    CrossAccountDiscovery?: CrossAccountDiscoveryServiceStatus;
    CrossRegionDiscovery?: CrossRegionDiscoveryStatus;
}
export interface GetServiceSettingsResponse {
    S3BucketArn?: string;
    SnsTopicArn?: string;
    OrganizationConfiguration?: OrganizationConfiguration;
    EnableCrossAccountsDiscovery?: boolean;
    LicenseManagerResourceShareArn?: string;
    CrossRegionDiscoveryHomeRegion?: string;
    CrossRegionDiscoverySourceRegions?: string[];
    ServiceStatus?: ServiceStatus;
}
export interface ListAssetsForLicenseAssetGroupRequest {
    LicenseAssetGroupArn: string;
    AssetType: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface Asset {
    AssetArn?: string;
    LatestAssetDiscoveryTime?: Date;
}
export type AssetList = Asset[];
export interface ListAssetsForLicenseAssetGroupResponse {
    Assets?: Asset[];
    NextToken?: string;
}
export interface ListAssociationsForLicenseConfigurationRequest {
    LicenseConfigurationArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface LicenseConfigurationAssociation {
    ResourceArn?: string;
    ResourceType?: ResourceType;
    ResourceOwnerId?: string;
    AssociationTime?: Date;
    AmiAssociationScope?: string;
}
export type LicenseConfigurationAssociations = LicenseConfigurationAssociation[];
export interface ListAssociationsForLicenseConfigurationResponse {
    LicenseConfigurationAssociations?: LicenseConfigurationAssociation[];
    NextToken?: string;
}
export type FilterName = string;
export type FilterValue = string;
export type FilterValues = string[];
export interface Filter {
    Name?: string;
    Values?: string[];
}
export type FilterList = Filter[];
export type MaxSize100 = number;
export interface ListDistributedGrantsRequest {
    GrantArns?: string[];
    Filters?: Filter[];
    NextToken?: string;
    MaxResults?: number;
}
export type GrantList = Grant[];
export interface ListDistributedGrantsResponse {
    Grants?: Grant[];
    NextToken?: string;
}
export interface ListFailuresForLicenseConfigurationOperationsRequest {
    LicenseConfigurationArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface LicenseOperationFailure {
    ResourceArn?: string;
    ResourceType?: ResourceType;
    ErrorMessage?: string;
    FailureTime?: Date;
    OperationName?: string;
    ResourceOwnerId?: string;
    OperationRequestedBy?: string;
    MetadataList?: Metadata[];
}
export type LicenseOperationFailureList = LicenseOperationFailure[];
export interface ListFailuresForLicenseConfigurationOperationsResponse {
    LicenseOperationFailureList?: LicenseOperationFailure[];
    NextToken?: string;
}
export type Filters = Filter[];
export interface ListLicenseAssetGroupsRequest {
    Filters?: Filter[];
    MaxResults?: number;
    NextToken?: string;
}
export type LicenseAssetGroupList = LicenseAssetGroup[];
export interface ListLicenseAssetGroupsResponse {
    LicenseAssetGroups?: LicenseAssetGroup[];
    NextToken?: string;
}
export interface ListLicenseAssetRulesetsRequest {
    Filters?: Filter[];
    ShowAWSManagedLicenseAssetRulesets?: boolean;
    MaxResults?: number;
    NextToken?: string;
}
export type LicenseAssetRulesetList = LicenseAssetRuleset[];
export interface ListLicenseAssetRulesetsResponse {
    LicenseAssetRulesets?: LicenseAssetRuleset[];
    NextToken?: string;
}
export interface ListLicenseConfigurationsRequest {
    LicenseConfigurationArns?: string[];
    MaxResults?: number;
    NextToken?: string;
    Filters?: Filter[];
}
export interface LicenseConfiguration {
    LicenseConfigurationId?: string;
    LicenseConfigurationArn?: string;
    Name?: string;
    Description?: string;
    LicenseCountingType?: LicenseCountingType;
    LicenseRules?: string[];
    LicenseCount?: number;
    LicenseCountHardLimit?: boolean;
    DisassociateWhenNotFound?: boolean;
    ConsumedLicenses?: number;
    Status?: string;
    OwnerAccountId?: string;
    ConsumedLicenseSummaryList?: ConsumedLicenseSummary[];
    ManagedResourceSummaryList?: ManagedResourceSummary[];
    ProductInformationList?: ProductInformation[];
    AutomatedDiscoveryInformation?: AutomatedDiscoveryInformation;
    LicenseExpiry?: number;
}
export type LicenseConfigurations = LicenseConfiguration[];
export interface ListLicenseConfigurationsResponse {
    LicenseConfigurations?: LicenseConfiguration[];
    NextToken?: string;
}
export interface ListLicenseConfigurationsForOrganizationRequest {
    LicenseConfigurationArns?: string[];
    MaxResults?: number;
    NextToken?: string;
    Filters?: Filter[];
}
export interface ListLicenseConfigurationsForOrganizationResponse {
    LicenseConfigurations?: LicenseConfiguration[];
    NextToken?: string;
}
export interface ListLicenseConversionTasksRequest {
    NextToken?: string;
    MaxResults?: number;
    Filters?: Filter[];
}
export interface LicenseConversionTask {
    LicenseConversionTaskId?: string;
    ResourceArn?: string;
    SourceLicenseContext?: LicenseConversionContext;
    DestinationLicenseContext?: LicenseConversionContext;
    Status?: LicenseConversionTaskStatus;
    StatusMessage?: string;
    StartTime?: Date;
    LicenseConversionTime?: Date;
    EndTime?: Date;
}
export type LicenseConversionTasks = LicenseConversionTask[];
export interface ListLicenseConversionTasksResponse {
    LicenseConversionTasks?: LicenseConversionTask[];
    NextToken?: string;
}
export interface ListLicenseManagerReportGeneratorsRequest {
    Filters?: Filter[];
    NextToken?: string;
    MaxResults?: number;
}
export type ReportGeneratorList = ReportGenerator[];
export interface ListLicenseManagerReportGeneratorsResponse {
    ReportGenerators?: ReportGenerator[];
    NextToken?: string;
}
export interface ListLicensesRequest {
    LicenseArns?: string[];
    Filters?: Filter[];
    NextToken?: string;
    MaxResults?: number;
}
export type LicenseList = License[];
export interface ListLicensesResponse {
    Licenses?: License[];
    NextToken?: string;
}
export interface ListLicenseSpecificationsForResourceRequest {
    ResourceArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface LicenseSpecification {
    LicenseConfigurationArn: string;
    AmiAssociationScope?: string;
}
export type LicenseSpecifications = LicenseSpecification[];
export interface ListLicenseSpecificationsForResourceResponse {
    LicenseSpecifications?: LicenseSpecification[];
    NextToken?: string;
}
export interface ListLicenseVersionsRequest {
    LicenseArn: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface ListLicenseVersionsResponse {
    Licenses?: License[];
    NextToken?: string;
}
export interface ListReceivedGrantsRequest {
    GrantArns?: string[];
    Filters?: Filter[];
    NextToken?: string;
    MaxResults?: number;
}
export interface ListReceivedGrantsResponse {
    Grants?: Grant[];
    NextToken?: string;
}
export interface ListReceivedGrantsForOrganizationRequest {
    LicenseArn: string;
    Filters?: Filter[];
    NextToken?: string;
    MaxResults?: number;
}
export interface ListReceivedGrantsForOrganizationResponse {
    Grants?: Grant[];
    NextToken?: string;
}
export interface ListReceivedLicensesRequest {
    LicenseArns?: string[];
    Filters?: Filter[];
    NextToken?: string;
    MaxResults?: number;
}
export type ReceivedStatus = "PENDING_WORKFLOW" | "PENDING_ACCEPT" | "REJECTED" | "ACTIVE" | "FAILED_WORKFLOW" | "DELETED" | "DISABLED" | "WORKFLOW_COMPLETED" | (string & {});
export interface ReceivedMetadata {
    ReceivedStatus?: ReceivedStatus;
    ReceivedStatusReason?: string;
    AllowedOperations?: AllowedOperation[];
}
export interface GrantedLicense {
    LicenseArn?: string;
    LicenseName?: string;
    ProductName?: string;
    ProductSKU?: string;
    Issuer?: IssuerDetails;
    HomeRegion?: string;
    Status?: LicenseStatus;
    Validity?: DatetimeRange;
    Beneficiary?: string;
    Entitlements?: Entitlement[];
    ConsumptionConfiguration?: ConsumptionConfiguration;
    LicenseMetadata?: Metadata[];
    CreateTime?: string;
    Version?: string;
    ReceivedMetadata?: ReceivedMetadata;
}
export type GrantedLicenseList = GrantedLicense[];
export interface ListReceivedLicensesResponse {
    Licenses?: GrantedLicense[];
    NextToken?: string;
}
export interface ListReceivedLicensesForOrganizationRequest {
    Filters?: Filter[];
    NextToken?: string;
    MaxResults?: number;
}
export interface ListReceivedLicensesForOrganizationResponse {
    Licenses?: GrantedLicense[];
    NextToken?: string;
}
export type InventoryFilterCondition = "EQUALS" | "NOT_EQUALS" | "BEGINS_WITH" | "CONTAINS" | (string & {});
export interface InventoryFilter {
    Name: string;
    Condition: InventoryFilterCondition;
    Value?: string;
}
export type InventoryFilterList = InventoryFilter[];
export interface ListResourceInventoryRequest {
    MaxResults?: number;
    NextToken?: string;
    Filters?: InventoryFilter[];
}
export interface ResourceInventory {
    ResourceId?: string;
    ResourceType?: ResourceType;
    ResourceArn?: string;
    Platform?: string;
    PlatformVersion?: string;
    ResourceOwningAccountId?: string;
    MarketplaceProductCodes?: string[];
    UsageOperation?: string;
    AmiId?: string;
    HostId?: string;
    Region?: string;
    InstanceType?: string;
}
export type ResourceInventoryList = ResourceInventory[];
export interface ListResourceInventoryResponse {
    ResourceInventoryList?: ResourceInventory[];
    NextToken?: string;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export interface ListTokensRequest {
    TokenIds?: string[];
    Filters?: Filter[];
    NextToken?: string;
    MaxResults?: number;
}
export interface TokenData {
    TokenId?: string;
    TokenType?: string;
    LicenseArn?: string;
    ExpirationTime?: string;
    TokenProperties?: string[];
    RoleArns?: string[];
    Status?: string;
}
export type TokenList = TokenData[];
export interface ListTokensResponse {
    Tokens?: TokenData[];
    NextToken?: string;
}
export interface ListUsageForLicenseConfigurationRequest {
    LicenseConfigurationArn: string;
    MaxResults?: number;
    NextToken?: string;
    Filters?: Filter[];
}
export interface LicenseConfigurationUsage {
    ResourceArn?: string;
    ResourceType?: ResourceType;
    ResourceStatus?: string;
    ResourceOwnerId?: string;
    AssociationTime?: Date;
    ConsumedLicenses?: number;
}
export type LicenseConfigurationUsageList = LicenseConfigurationUsage[];
export interface ListUsageForLicenseConfigurationResponse {
    LicenseConfigurationUsageList?: LicenseConfigurationUsage[];
    NextToken?: string;
}
export interface RejectGrantRequest {
    GrantArn: string;
}
export interface RejectGrantResponse {
    GrantArn?: string;
    Status?: GrantStatus;
    Version?: string;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateLicenseAssetGroupRequest {
    Name?: string;
    Description?: string;
    LicenseAssetGroupConfigurations?: LicenseAssetGroupConfiguration[];
    AssociatedLicenseAssetRulesetARNs: string[];
    Properties?: LicenseAssetGroupProperty[];
    LicenseAssetGroupArn: string;
    Status?: LicenseAssetGroupStatus;
    ClientToken: string;
}
export interface UpdateLicenseAssetGroupResponse {
    LicenseAssetGroupArn: string;
    Status: string;
}
export interface UpdateLicenseAssetRulesetRequest {
    Name?: string;
    Description?: string;
    Rules: LicenseAssetRule[];
    LicenseAssetRulesetArn: string;
    ClientToken: string;
}
export interface UpdateLicenseAssetRulesetResponse {
    LicenseAssetRulesetArn: string;
}
export type LicenseConfigurationStatus = "AVAILABLE" | "DISABLED" | (string & {});
export interface UpdateLicenseConfigurationRequest {
    LicenseConfigurationArn: string;
    LicenseConfigurationStatus?: LicenseConfigurationStatus;
    LicenseRules?: string[];
    LicenseCount?: number;
    LicenseCountHardLimit?: boolean;
    Name?: string;
    Description?: string;
    ProductInformationList?: ProductInformation[];
    DisassociateWhenNotFound?: boolean;
    LicenseExpiry?: number;
}
export interface UpdateLicenseConfigurationResponse {
}
export interface UpdateLicenseManagerReportGeneratorRequest {
    LicenseManagerReportGeneratorArn: string;
    ReportGeneratorName: string;
    Type: ReportType[];
    ReportContext: ReportContext;
    ReportFrequency: ReportFrequency;
    ClientToken: string;
    Description?: string;
}
export interface UpdateLicenseManagerReportGeneratorResponse {
}
export interface UpdateLicenseSpecificationsForResourceRequest {
    ResourceArn: string;
    AddLicenseSpecifications?: LicenseSpecification[];
    RemoveLicenseSpecifications?: LicenseSpecification[];
}
export interface UpdateLicenseSpecificationsForResourceResponse {
}
export interface UpdateServiceSettingsRequest {
    S3BucketArn?: string;
    SnsTopicArn?: string;
    OrganizationConfiguration?: OrganizationConfiguration;
    EnableCrossAccountsDiscovery?: boolean;
    EnabledDiscoverySourceRegions?: string[];
}
export interface UpdateServiceSettingsResponse {
}
export type Message = string;
export type Location = string;
export type AcceptGrantError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Accepts the specified grant.
 */
export declare const acceptGrant: API.OperationMethod<AcceptGrantRequest, AcceptGrantResponse, AcceptGrantError, Credentials | HttpClient.HttpClient>;
export type CheckInLicenseError = AccessDeniedException | AuthorizationException | ConflictException | InvalidParameterValueException | RateLimitExceededException | ResourceNotFoundException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Checks in the specified license. Check in a license when it is no longer in use.
 */
export declare const checkInLicense: API.OperationMethod<CheckInLicenseRequest, CheckInLicenseResponse, CheckInLicenseError, Credentials | HttpClient.HttpClient>;
export type CheckoutBorrowLicenseError = AccessDeniedException | AuthorizationException | EntitlementNotAllowedException | InvalidParameterValueException | NoEntitlementsAllowedException | RateLimitExceededException | RedirectException | ResourceNotFoundException | ServerInternalException | UnsupportedDigitalSignatureMethodException | ValidationException | CommonErrors;
/**
 * Checks out the specified license for offline use.
 */
export declare const checkoutBorrowLicense: API.OperationMethod<CheckoutBorrowLicenseRequest, CheckoutBorrowLicenseResponse, CheckoutBorrowLicenseError, Credentials | HttpClient.HttpClient>;
export type CheckoutLicenseError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | NoEntitlementsAllowedException | RateLimitExceededException | RedirectException | ResourceNotFoundException | ServerInternalException | UnsupportedDigitalSignatureMethodException | ValidationException | CommonErrors;
/**
 * Checks out the specified license.
 *
 * If the account that created the license is the same that is performing the check out, you must
 * specify the account as the beneficiary.
 */
export declare const checkoutLicense: API.OperationMethod<CheckoutLicenseRequest, CheckoutLicenseResponse, CheckoutLicenseError, Credentials | HttpClient.HttpClient>;
export type CreateGrantError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Creates a grant for the specified license. A grant shares the use of license
 * entitlements with a specific Amazon Web Services account, an organization, or an
 * organizational unit (OU). For more information, see Granted licenses in License Manager in the *License Manager User Guide*.
 */
export declare const createGrant: API.OperationMethod<CreateGrantRequest, CreateGrantResponse, CreateGrantError, Credentials | HttpClient.HttpClient>;
export type CreateGrantVersionError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Creates a new version of the specified grant. For more information, see
 * Granted licenses in License Manager in the *License Manager User Guide*.
 */
export declare const createGrantVersion: API.OperationMethod<CreateGrantVersionRequest, CreateGrantVersionResponse, CreateGrantVersionError, Credentials | HttpClient.HttpClient>;
export type CreateLicenseError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | RedirectException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Creates a license.
 */
export declare const createLicense: API.OperationMethod<CreateLicenseRequest, CreateLicenseResponse, CreateLicenseError, Credentials | HttpClient.HttpClient>;
export type CreateLicenseAssetGroupError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Creates a license asset group.
 */
export declare const createLicenseAssetGroup: API.OperationMethod<CreateLicenseAssetGroupRequest, CreateLicenseAssetGroupResponse, CreateLicenseAssetGroupError, Credentials | HttpClient.HttpClient>;
export type CreateLicenseAssetRulesetError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Creates a license asset ruleset.
 */
export declare const createLicenseAssetRuleset: API.OperationMethod<CreateLicenseAssetRulesetRequest, CreateLicenseAssetRulesetResponse, CreateLicenseAssetRulesetError, Credentials | HttpClient.HttpClient>;
export type CreateLicenseConfigurationError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Creates a license configuration.
 *
 * A license configuration is an abstraction of a customer license agreement that can be
 * consumed and enforced by License Manager. Components include specifications for the license
 * type (licensing by instance, socket, CPU, or vCPU), allowed tenancy (shared tenancy,
 * Dedicated Instance, Dedicated Host, or all of these), license affinity to host (how long a
 * license must be associated with a host), and the number of licenses purchased and used.
 */
export declare const createLicenseConfiguration: API.OperationMethod<CreateLicenseConfigurationRequest, CreateLicenseConfigurationResponse, CreateLicenseConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateLicenseConversionTaskForResourceError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Creates a new license conversion task.
 */
export declare const createLicenseConversionTaskForResource: API.OperationMethod<CreateLicenseConversionTaskForResourceRequest, CreateLicenseConversionTaskForResourceResponse, CreateLicenseConversionTaskForResourceError, Credentials | HttpClient.HttpClient>;
export type CreateLicenseManagerReportGeneratorError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ResourceNotFoundException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Creates a report generator.
 */
export declare const createLicenseManagerReportGenerator: API.OperationMethod<CreateLicenseManagerReportGeneratorRequest, CreateLicenseManagerReportGeneratorResponse, CreateLicenseManagerReportGeneratorError, Credentials | HttpClient.HttpClient>;
export type CreateLicenseVersionError = AccessDeniedException | AuthorizationException | ConflictException | RateLimitExceededException | RedirectException | ResourceNotFoundException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Creates a new version of the specified license.
 */
export declare const createLicenseVersion: API.OperationMethod<CreateLicenseVersionRequest, CreateLicenseVersionResponse, CreateLicenseVersionError, Credentials | HttpClient.HttpClient>;
export type CreateTokenError = AccessDeniedException | AuthorizationException | RateLimitExceededException | RedirectException | ResourceLimitExceededException | ResourceNotFoundException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Creates a long-lived token.
 *
 * A refresh token is a JWT token used to get an access token. With an access token,
 * you can call AssumeRoleWithWebIdentity to get role credentials that you can use to
 * call License Manager to manage the specified license.
 */
export declare const createToken: API.OperationMethod<CreateTokenRequest, CreateTokenResponse, CreateTokenError, Credentials | HttpClient.HttpClient>;
export type DeleteGrantError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Deletes the specified grant.
 */
export declare const deleteGrant: API.OperationMethod<DeleteGrantRequest, DeleteGrantResponse, DeleteGrantError, Credentials | HttpClient.HttpClient>;
export type DeleteLicenseError = AccessDeniedException | AuthorizationException | ConflictException | InvalidParameterValueException | RateLimitExceededException | RedirectException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Deletes the specified license.
 */
export declare const deleteLicense: API.OperationMethod<DeleteLicenseRequest, DeleteLicenseResponse, DeleteLicenseError, Credentials | HttpClient.HttpClient>;
export type DeleteLicenseAssetGroupError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Deletes a license asset group.
 */
export declare const deleteLicenseAssetGroup: API.OperationMethod<DeleteLicenseAssetGroupRequest, DeleteLicenseAssetGroupResponse, DeleteLicenseAssetGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteLicenseAssetRulesetError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Deletes a license asset ruleset.
 */
export declare const deleteLicenseAssetRuleset: API.OperationMethod<DeleteLicenseAssetRulesetRequest, DeleteLicenseAssetRulesetResponse, DeleteLicenseAssetRulesetError, Credentials | HttpClient.HttpClient>;
export type DeleteLicenseConfigurationError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | LicenseConfigurationNotFound | CommonErrors;
/**
 * Deletes the specified license configuration.
 *
 * You cannot delete a license configuration that is in use.
 */
export declare const deleteLicenseConfiguration: API.OperationMethod<DeleteLicenseConfigurationRequest, DeleteLicenseConfigurationResponse, DeleteLicenseConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteLicenseManagerReportGeneratorError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ResourceNotFoundException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Deletes the specified report generator.
 *
 * This action deletes the report generator, which stops it from generating future reports.
 * The action cannot be reversed. It has no effect on the previous reports from this generator.
 */
export declare const deleteLicenseManagerReportGenerator: API.OperationMethod<DeleteLicenseManagerReportGeneratorRequest, DeleteLicenseManagerReportGeneratorResponse, DeleteLicenseManagerReportGeneratorError, Credentials | HttpClient.HttpClient>;
export type DeleteTokenError = AccessDeniedException | AuthorizationException | RateLimitExceededException | RedirectException | ResourceNotFoundException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Deletes the specified token. Must be called in the license home Region.
 */
export declare const deleteToken: API.OperationMethod<DeleteTokenRequest, DeleteTokenResponse, DeleteTokenError, Credentials | HttpClient.HttpClient>;
export type ExtendLicenseConsumptionError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceNotFoundException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Extends the expiration date for license consumption.
 */
export declare const extendLicenseConsumption: API.OperationMethod<ExtendLicenseConsumptionRequest, ExtendLicenseConsumptionResponse, ExtendLicenseConsumptionError, Credentials | HttpClient.HttpClient>;
export type GetAccessTokenError = AccessDeniedException | AuthorizationException | RateLimitExceededException | ServerInternalException | ValidationException | InvalidParameterValueException | CommonErrors;
/**
 * Gets a temporary access token to use with AssumeRoleWithWebIdentity. Access tokens
 * are valid for one hour.
 */
export declare const getAccessToken: API.OperationMethod<GetAccessTokenRequest, GetAccessTokenResponse, GetAccessTokenError, Credentials | HttpClient.HttpClient>;
export type GetGrantError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | ResourceNotFoundException | CommonErrors;
/**
 * Gets detailed information about the specified grant.
 */
export declare const getGrant: API.OperationMethod<GetGrantRequest, GetGrantResponse, GetGrantError, Credentials | HttpClient.HttpClient>;
export type GetLicenseError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | ResourceNotFoundException | CommonErrors;
/**
 * Gets detailed information about the specified license.
 */
export declare const getLicense: API.OperationMethod<GetLicenseRequest, GetLicenseResponse, GetLicenseError, Credentials | HttpClient.HttpClient>;
export type GetLicenseAssetGroupError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Gets a license asset group.
 */
export declare const getLicenseAssetGroup: API.OperationMethod<GetLicenseAssetGroupRequest, GetLicenseAssetGroupResponse, GetLicenseAssetGroupError, Credentials | HttpClient.HttpClient>;
export type GetLicenseAssetRulesetError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Gets a license asset ruleset.
 */
export declare const getLicenseAssetRuleset: API.OperationMethod<GetLicenseAssetRulesetRequest, GetLicenseAssetRulesetResponse, GetLicenseAssetRulesetError, Credentials | HttpClient.HttpClient>;
export type GetLicenseConfigurationError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | LicenseConfigurationNotFound | CommonErrors;
/**
 * Gets detailed information about the specified license configuration.
 */
export declare const getLicenseConfiguration: API.OperationMethod<GetLicenseConfigurationRequest, GetLicenseConfigurationResponse, GetLicenseConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetLicenseConversionTaskError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Gets information about the specified license type conversion task.
 */
export declare const getLicenseConversionTask: API.OperationMethod<GetLicenseConversionTaskRequest, GetLicenseConversionTaskResponse, GetLicenseConversionTaskError, Credentials | HttpClient.HttpClient>;
export type GetLicenseManagerReportGeneratorError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ResourceNotFoundException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Gets information about the specified report generator.
 */
export declare const getLicenseManagerReportGenerator: API.OperationMethod<GetLicenseManagerReportGeneratorRequest, GetLicenseManagerReportGeneratorResponse, GetLicenseManagerReportGeneratorError, Credentials | HttpClient.HttpClient>;
export type GetLicenseUsageError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Gets detailed information about the usage of the specified license.
 */
export declare const getLicenseUsage: API.OperationMethod<GetLicenseUsageRequest, GetLicenseUsageResponse, GetLicenseUsageError, Credentials | HttpClient.HttpClient>;
export type GetServiceSettingsError = AccessDeniedException | AuthorizationException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Gets the License Manager settings for the current Region.
 */
export declare const getServiceSettings: API.OperationMethod<GetServiceSettingsRequest, GetServiceSettingsResponse, GetServiceSettingsError, Credentials | HttpClient.HttpClient>;
export type ListAssetsForLicenseAssetGroupError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists assets for a license asset group.
 */
export declare const listAssetsForLicenseAssetGroup: API.OperationMethod<ListAssetsForLicenseAssetGroupRequest, ListAssetsForLicenseAssetGroupResponse, ListAssetsForLicenseAssetGroupError, Credentials | HttpClient.HttpClient>;
export type ListAssociationsForLicenseConfigurationError = AccessDeniedException | AuthorizationException | FilterLimitExceededException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Lists the resource associations for the specified license configuration.
 *
 * Resource associations need not consume licenses from a license configuration.
 * For example, an AMI or a stopped instance might not consume a license (depending on
 * the license rules).
 */
export declare const listAssociationsForLicenseConfiguration: API.OperationMethod<ListAssociationsForLicenseConfigurationRequest, ListAssociationsForLicenseConfigurationResponse, ListAssociationsForLicenseConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListDistributedGrantsError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists the grants distributed for the specified license.
 */
export declare const listDistributedGrants: API.OperationMethod<ListDistributedGrantsRequest, ListDistributedGrantsResponse, ListDistributedGrantsError, Credentials | HttpClient.HttpClient>;
export type ListFailuresForLicenseConfigurationOperationsError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Lists the license configuration operations that failed.
 */
export declare const listFailuresForLicenseConfigurationOperations: API.OperationMethod<ListFailuresForLicenseConfigurationOperationsRequest, ListFailuresForLicenseConfigurationOperationsResponse, ListFailuresForLicenseConfigurationOperationsError, Credentials | HttpClient.HttpClient>;
export type ListLicenseAssetGroupsError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists license asset groups.
 */
export declare const listLicenseAssetGroups: API.OperationMethod<ListLicenseAssetGroupsRequest, ListLicenseAssetGroupsResponse, ListLicenseAssetGroupsError, Credentials | HttpClient.HttpClient>;
export type ListLicenseAssetRulesetsError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists license asset rulesets.
 */
export declare const listLicenseAssetRulesets: API.OperationMethod<ListLicenseAssetRulesetsRequest, ListLicenseAssetRulesetsResponse, ListLicenseAssetRulesetsError, Credentials | HttpClient.HttpClient>;
export type ListLicenseConfigurationsError = AccessDeniedException | AuthorizationException | FilterLimitExceededException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Lists the license configurations for your account.
 */
export declare const listLicenseConfigurations: API.OperationMethod<ListLicenseConfigurationsRequest, ListLicenseConfigurationsResponse, ListLicenseConfigurationsError, Credentials | HttpClient.HttpClient>;
export type ListLicenseConfigurationsForOrganizationError = AccessDeniedException | AuthorizationException | FilterLimitExceededException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Lists license configurations for an organization.
 */
export declare const listLicenseConfigurationsForOrganization: API.OperationMethod<ListLicenseConfigurationsForOrganizationRequest, ListLicenseConfigurationsForOrganizationResponse, ListLicenseConfigurationsForOrganizationError, Credentials | HttpClient.HttpClient>;
export type ListLicenseConversionTasksError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Lists the license type conversion tasks for your account.
 */
export declare const listLicenseConversionTasks: API.OperationMethod<ListLicenseConversionTasksRequest, ListLicenseConversionTasksResponse, ListLicenseConversionTasksError, Credentials | HttpClient.HttpClient>;
export type ListLicenseManagerReportGeneratorsError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ResourceNotFoundException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists the report generators for your account.
 */
export declare const listLicenseManagerReportGenerators: API.OperationMethod<ListLicenseManagerReportGeneratorsRequest, ListLicenseManagerReportGeneratorsResponse, ListLicenseManagerReportGeneratorsError, Credentials | HttpClient.HttpClient>;
export type ListLicensesError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists the licenses for your account.
 */
export declare const listLicenses: API.OperationMethod<ListLicensesRequest, ListLicensesResponse, ListLicensesError, Credentials | HttpClient.HttpClient>;
export type ListLicenseSpecificationsForResourceError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Describes the license configurations for the specified resource.
 */
export declare const listLicenseSpecificationsForResource: API.OperationMethod<ListLicenseSpecificationsForResourceRequest, ListLicenseSpecificationsForResourceResponse, ListLicenseSpecificationsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListLicenseVersionsError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Lists all versions of the specified license.
 */
export declare const listLicenseVersions: API.OperationMethod<ListLicenseVersionsRequest, ListLicenseVersionsResponse, ListLicenseVersionsError, Credentials | HttpClient.HttpClient>;
export type ListReceivedGrantsError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists grants that are received. Received grants are grants created while specifying the
 * recipient as this Amazon Web Services account, your organization, or an organizational unit
 * (OU) to which this member account belongs.
 */
export declare const listReceivedGrants: API.OperationMethod<ListReceivedGrantsRequest, ListReceivedGrantsResponse, ListReceivedGrantsError, Credentials | HttpClient.HttpClient>;
export type ListReceivedGrantsForOrganizationError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists the grants received for all accounts in the organization.
 */
export declare const listReceivedGrantsForOrganization: API.OperationMethod<ListReceivedGrantsForOrganizationRequest, ListReceivedGrantsForOrganizationResponse, ListReceivedGrantsForOrganizationError, Credentials | HttpClient.HttpClient>;
export type ListReceivedLicensesError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists received licenses.
 */
export declare const listReceivedLicenses: API.OperationMethod<ListReceivedLicensesRequest, ListReceivedLicensesResponse, ListReceivedLicensesError, Credentials | HttpClient.HttpClient>;
export type ListReceivedLicensesForOrganizationError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists the licenses received for all accounts in the organization.
 */
export declare const listReceivedLicensesForOrganization: API.OperationMethod<ListReceivedLicensesForOrganizationRequest, ListReceivedLicensesForOrganizationResponse, ListReceivedLicensesForOrganizationError, Credentials | HttpClient.HttpClient>;
export type ListResourceInventoryError = AccessDeniedException | AuthorizationException | FailedDependencyException | FilterLimitExceededException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Lists resources managed using Systems Manager inventory.
 */
export declare const listResourceInventory: API.OperationMethod<ListResourceInventoryRequest, ListResourceInventoryResponse, ListResourceInventoryError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists the tags for the specified resource. For more information about tagging support in
 * License Manager, see the TagResource operation.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTokensError = AccessDeniedException | AuthorizationException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists your tokens.
 */
export declare const listTokens: API.OperationMethod<ListTokensRequest, ListTokensResponse, ListTokensError, Credentials | HttpClient.HttpClient>;
export type ListUsageForLicenseConfigurationError = AccessDeniedException | AuthorizationException | FilterLimitExceededException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Lists all license usage records for a license configuration, displaying license
 * consumption details by resource at a selected point in time. Use this action to audit the
 * current license consumption for any license inventory and configuration.
 */
export declare const listUsageForLicenseConfiguration: API.OperationMethod<ListUsageForLicenseConfigurationRequest, ListUsageForLicenseConfigurationResponse, ListUsageForLicenseConfigurationError, Credentials | HttpClient.HttpClient>;
export type RejectGrantError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Rejects the specified grant.
 */
export declare const rejectGrant: API.OperationMethod<RejectGrantRequest, RejectGrantResponse, RejectGrantError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Adds the specified tags to the specified resource. The following resources support
 * tagging in License Manager:
 *
 * - Licenses
 *
 * - Grants
 *
 * - License configurations
 *
 * - Report generators
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Removes the specified tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateLicenseAssetGroupError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Updates a license asset group.
 */
export declare const updateLicenseAssetGroup: API.OperationMethod<UpdateLicenseAssetGroupRequest, UpdateLicenseAssetGroupResponse, UpdateLicenseAssetGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateLicenseAssetRulesetError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Updates a license asset ruleset.
 */
export declare const updateLicenseAssetRuleset: API.OperationMethod<UpdateLicenseAssetRulesetRequest, UpdateLicenseAssetRulesetResponse, UpdateLicenseAssetRulesetError, Credentials | HttpClient.HttpClient>;
export type UpdateLicenseConfigurationError = AccessDeniedException | AuthorizationException | ConflictException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | LicenseConfigurationNotFound | CommonErrors;
/**
 * Modifies the attributes of an existing license configuration.
 */
export declare const updateLicenseConfiguration: API.OperationMethod<UpdateLicenseConfigurationRequest, UpdateLicenseConfigurationResponse, UpdateLicenseConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateLicenseManagerReportGeneratorError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ResourceNotFoundException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Updates a report generator.
 *
 * After you make changes to a report generator, it starts generating new reports within 60 minutes of being updated.
 */
export declare const updateLicenseManagerReportGenerator: API.OperationMethod<UpdateLicenseManagerReportGeneratorRequest, UpdateLicenseManagerReportGeneratorResponse, UpdateLicenseManagerReportGeneratorError, Credentials | HttpClient.HttpClient>;
export type UpdateLicenseSpecificationsForResourceError = AccessDeniedException | AuthorizationException | ConflictException | InvalidParameterValueException | InvalidResourceStateException | LicenseUsageException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Adds or removes the specified license configurations for the specified Amazon Web Services resource.
 *
 * You can update the license specifications of AMIs, instances, and hosts.
 * You cannot update the license specifications for launch templates and CloudFormation templates,
 * as they send license configurations to the operation that creates the resource.
 */
export declare const updateLicenseSpecificationsForResource: API.OperationMethod<UpdateLicenseSpecificationsForResourceRequest, UpdateLicenseSpecificationsForResourceResponse, UpdateLicenseSpecificationsForResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceSettingsError = AccessDeniedException | AuthorizationException | ConflictException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Updates License Manager settings for the current Region.
 */
export declare const updateServiceSettings: API.OperationMethod<UpdateServiceSettingsRequest, UpdateServiceSettingsResponse, UpdateServiceSettingsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=license-manager.d.ts.map