import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import * as T from "../traits.ts";
declare const BadGatewayException_base: S.TaggedErrorClass<"BadGatewayException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class BadGatewayException extends /*@__PURE__*/ BadGatewayException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DependencyFailedException_base: S.TaggedErrorClass<"DependencyFailedException", {
    readonly message: any;
}>;
export declare class DependencyFailedException extends /*@__PURE__*/ DependencyFailedException_base {
}
declare const InternalFailureException_base: S.TaggedErrorClass<"InternalFailureException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly retryAfterSeconds: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const LoopDetectedException_base: S.TaggedErrorClass<"LoopDetectedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class LoopDetectedException extends /*@__PURE__*/ LoopDetectedException_base {
}
declare const NotAcceptableException_base: S.TaggedErrorClass<"NotAcceptableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotAcceptableException extends /*@__PURE__*/ NotAcceptableException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const RequestTimeoutException_base: S.TaggedErrorClass<"RequestTimeoutException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class RequestTimeoutException extends /*@__PURE__*/ RequestTimeoutException_base {
}
declare const UnsupportedMediaTypeException_base: S.TaggedErrorClass<"UnsupportedMediaTypeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedMediaTypeException extends /*@__PURE__*/ UnsupportedMediaTypeException_base {
}
export type BotName = string;
export type BotAlias = string;
export type UserId = string;
export interface DeleteSessionRequest {
    botName: string;
    botAlias: string;
    userId: string;
}
export interface DeleteSessionResponse {
    botName?: string;
    botAlias?: string;
    userId?: string;
    sessionId?: string;
}
export type IntentSummaryCheckpointLabel = string;
export interface GetSessionRequest {
    botName: string;
    botAlias: string;
    userId: string;
    checkpointLabelFilter?: string;
}
export type IntentName = string;
export type StringMap = {
    [key: string]: string | undefined;
};
export type ConfirmationStatus = "None" | "Confirmed" | "Denied" | (string & {});
export type DialogActionType = "ElicitIntent" | "ConfirmIntent" | "ElicitSlot" | "Close" | "Delegate" | (string & {});
export type FulfillmentState = "Fulfilled" | "Failed" | "ReadyForFulfillment" | (string & {});
export interface IntentSummary {
    intentName?: string;
    checkpointLabel?: string;
    slots?: {
        [key: string]: string | undefined;
    };
    confirmationStatus?: ConfirmationStatus;
    dialogActionType: DialogActionType;
    fulfillmentState?: FulfillmentState;
    slotToElicit?: string;
}
export type IntentSummaryList = IntentSummary[];
export type Text = string | redacted.Redacted<string>;
export type MessageFormatType = "PlainText" | "CustomPayload" | "SSML" | "Composite" | (string & {});
export interface DialogAction {
    type: DialogActionType;
    intentName?: string;
    slots?: {
        [key: string]: string | undefined;
    };
    slotToElicit?: string;
    fulfillmentState?: FulfillmentState;
    message?: string | redacted.Redacted<string>;
    messageFormat?: MessageFormatType;
}
export type ActiveContextName = string;
export type ActiveContextTimeToLiveInSeconds = number;
export type ActiveContextTurnsToLive = number;
export interface ActiveContextTimeToLive {
    timeToLiveInSeconds?: number;
    turnsToLive?: number;
}
export type ParameterName = string;
export type ActiveContextParametersMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export interface ActiveContext {
    name: string;
    timeToLive: ActiveContextTimeToLive;
    parameters: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export type ActiveContextsList = ActiveContext[];
export interface GetSessionResponse {
    recentIntentSummaryView?: IntentSummary[];
    sessionAttributes?: {
        [key: string]: string | undefined;
    };
    sessionId?: string;
    dialogAction?: DialogAction;
    activeContexts?: ActiveContext[];
}
export type SynthesizedJsonAttributesString = string | redacted.Redacted<string>;
export type HttpContentType = string;
export type Accept = string;
export type SynthesizedJsonActiveContextsString = string | redacted.Redacted<string>;
export interface PostContentRequest {
    botName: string;
    botAlias: string;
    userId: string;
    sessionAttributes?: string | redacted.Redacted<string>;
    requestAttributes?: string | redacted.Redacted<string>;
    contentType: string;
    accept?: string;
    inputStream: T.StreamingInputBody;
    activeContexts?: string | redacted.Redacted<string>;
}
export type SynthesizedJsonString = string;
export type SensitiveString = string | redacted.Redacted<string>;
export type DialogState = "ElicitIntent" | "ConfirmIntent" | "ElicitSlot" | "Fulfilled" | "ReadyForFulfillment" | "Failed" | (string & {});
export type SensitiveStringUnbounded = string | redacted.Redacted<string>;
export type BotVersion = string;
export interface PostContentResponse {
    contentType?: string;
    intentName?: string;
    nluIntentConfidence?: string;
    alternativeIntents?: string;
    slots?: string;
    sessionAttributes?: string;
    sentimentResponse?: string;
    message?: string | redacted.Redacted<string>;
    encodedMessage?: string | redacted.Redacted<string>;
    messageFormat?: MessageFormatType;
    dialogState?: DialogState;
    slotToElicit?: string;
    inputTranscript?: string;
    encodedInputTranscript?: string | redacted.Redacted<string>;
    audioStream?: T.StreamingOutputBody;
    botVersion?: string;
    sessionId?: string;
    activeContexts?: string | redacted.Redacted<string>;
}
export interface PostTextRequest {
    botName: string;
    botAlias: string;
    userId: string;
    sessionAttributes?: {
        [key: string]: string | undefined;
    };
    requestAttributes?: {
        [key: string]: string | undefined;
    };
    inputText: string | redacted.Redacted<string>;
    activeContexts?: ActiveContext[];
}
export interface IntentConfidence {
    score?: number;
}
export interface PredictedIntent {
    intentName?: string;
    nluIntentConfidence?: IntentConfidence;
    slots?: {
        [key: string]: string | undefined;
    };
}
export type IntentList = PredictedIntent[];
export type SentimentLabel = string;
export type SentimentScore = string;
export interface SentimentResponse {
    sentimentLabel?: string;
    sentimentScore?: string;
}
export type ContentType = "application/vnd.amazonaws.card.generic" | (string & {});
export type StringWithLength = string;
export type StringUrlWithLength = string;
export type ButtonTextStringWithLength = string;
export type ButtonValueStringWithLength = string;
export interface Button {
    text: string;
    value: string;
}
export type ListOfButtons = Button[];
export interface GenericAttachment {
    title?: string;
    subTitle?: string;
    attachmentLinkUrl?: string;
    imageUrl?: string;
    buttons?: Button[];
}
export type GenericAttachmentList = GenericAttachment[];
export interface ResponseCard {
    version?: string;
    contentType?: ContentType;
    genericAttachments?: GenericAttachment[];
}
export interface PostTextResponse {
    intentName?: string;
    nluIntentConfidence?: IntentConfidence;
    alternativeIntents?: PredictedIntent[];
    slots?: {
        [key: string]: string | undefined;
    };
    sessionAttributes?: {
        [key: string]: string | undefined;
    };
    message?: string | redacted.Redacted<string>;
    sentimentResponse?: SentimentResponse;
    messageFormat?: MessageFormatType;
    dialogState?: DialogState;
    slotToElicit?: string;
    responseCard?: ResponseCard;
    sessionId?: string;
    botVersion?: string;
    activeContexts?: ActiveContext[];
}
export interface PutSessionRequest {
    botName: string;
    botAlias: string;
    userId: string;
    sessionAttributes?: {
        [key: string]: string | undefined;
    };
    dialogAction?: DialogAction;
    recentIntentSummaryView?: IntentSummary[];
    accept?: string;
    activeContexts?: ActiveContext[];
}
export interface PutSessionResponse {
    contentType?: string;
    intentName?: string;
    slots?: string;
    sessionAttributes?: string;
    message?: string | redacted.Redacted<string>;
    encodedMessage?: string | redacted.Redacted<string>;
    messageFormat?: MessageFormatType;
    dialogState?: DialogState;
    slotToElicit?: string;
    audioStream?: T.StreamingOutputBody;
    sessionId?: string;
    activeContexts?: string | redacted.Redacted<string>;
}
export type ErrorMessage = string;
export type DeleteSessionError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Removes session information for a specified bot, alias, and user ID.
 */
export declare const deleteSession: API.OperationMethod<DeleteSessionRequest, DeleteSessionResponse, DeleteSessionError, Credentials | HttpClient.HttpClient>;
export type GetSessionError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Returns session information for a specified bot, alias, and user
 * ID.
 */
export declare const getSession: API.OperationMethod<GetSessionRequest, GetSessionResponse, GetSessionError, Credentials | HttpClient.HttpClient>;
export type PostContentError = BadGatewayException | BadRequestException | ConflictException | DependencyFailedException | InternalFailureException | LimitExceededException | LoopDetectedException | NotAcceptableException | NotFoundException | RequestTimeoutException | UnsupportedMediaTypeException | CommonErrors;
/**
 * Sends user input (text or speech) to Amazon Lex. Clients use this API to
 * send text and audio requests to Amazon Lex at runtime. Amazon Lex interprets the
 * user input using the machine learning model that it built for the bot.
 *
 * The `PostContent` operation supports audio input at 8kHz
 * and 16kHz. You can use 8kHz audio to achieve higher speech recognition
 * accuracy in telephone audio applications.
 *
 * In response, Amazon Lex returns the next message to convey to the user.
 * Consider the following example messages:
 *
 * - For a user input "I would like a pizza," Amazon Lex might return a
 * response with a message eliciting slot data (for example,
 * `PizzaSize`): "What size pizza would you like?".
 *
 * - After the user provides all of the pizza order information, Amazon Lex
 * might return a response with a message to get user confirmation:
 * "Order the pizza?".
 *
 * - After the user replies "Yes" to the confirmation prompt, Amazon Lex
 * might return a conclusion statement: "Thank you, your cheese pizza has
 * been ordered.".
 *
 * Not all Amazon Lex messages require a response from the user. For example,
 * conclusion statements do not require a response. Some messages require
 * only a yes or no response. In addition to the `message`, Amazon Lex
 * provides additional context about the message in the response that you can
 * use to enhance client behavior, such as displaying the appropriate client
 * user interface. Consider the following examples:
 *
 * - If the message is to elicit slot data, Amazon Lex returns the
 * following context information:
 *
 * - `x-amz-lex-dialog-state` header set to
 * `ElicitSlot`
 *
 * - `x-amz-lex-intent-name` header set to the intent name
 * in the current context
 *
 * - `x-amz-lex-slot-to-elicit` header set to the slot name
 * for which the `message` is eliciting information
 *
 * - `x-amz-lex-slots` header set to a map of slots
 * configured for the intent with their current values
 *
 * - If the message is a confirmation prompt, the
 * `x-amz-lex-dialog-state` header is set to
 * `Confirmation` and the
 * `x-amz-lex-slot-to-elicit` header is omitted.
 *
 * - If the message is a clarification prompt configured for the
 * intent, indicating that the user intent is not understood, the
 * `x-amz-dialog-state` header is set to
 * `ElicitIntent` and the `x-amz-slot-to-elicit`
 * header is omitted.
 *
 * In addition, Amazon Lex also returns your application-specific
 * `sessionAttributes`. For more information, see Managing
 * Conversation Context.
 */
export declare const postContent: API.OperationMethod<PostContentRequest, PostContentResponse, PostContentError, Credentials | HttpClient.HttpClient>;
export type PostTextError = BadGatewayException | BadRequestException | ConflictException | DependencyFailedException | InternalFailureException | LimitExceededException | LoopDetectedException | NotFoundException | CommonErrors;
/**
 * Sends user input to Amazon Lex. Client applications can use this API to
 * send requests to Amazon Lex at runtime. Amazon Lex then interprets the user input
 * using the machine learning model it built for the bot.
 *
 * In response, Amazon Lex returns the next `message` to convey to
 * the user an optional `responseCard` to display. Consider the
 * following example messages:
 *
 * - For a user input "I would like a pizza", Amazon Lex might return a
 * response with a message eliciting slot data (for example, PizzaSize):
 * "What size pizza would you like?"
 *
 * - After the user provides all of the pizza order information,
 * Amazon Lex might return a response with a message to obtain user
 * confirmation "Proceed with the pizza order?".
 *
 * - After the user replies to a confirmation prompt with a "yes",
 * Amazon Lex might return a conclusion statement: "Thank you, your cheese
 * pizza has been ordered.".
 *
 * Not all Amazon Lex messages require a user response. For example, a
 * conclusion statement does not require a response. Some messages require
 * only a "yes" or "no" user response. In addition to the
 * `message`, Amazon Lex provides additional context about the
 * message in the response that you might use to enhance client behavior, for
 * example, to display the appropriate client user interface. These are the
 * `slotToElicit`, `dialogState`,
 * `intentName`, and `slots` fields in the response.
 * Consider the following examples:
 *
 * - If the message is to elicit slot data, Amazon Lex returns the
 * following context information:
 *
 * - `dialogState` set to ElicitSlot
 *
 * - `intentName` set to the intent name in the current
 * context
 *
 * - `slotToElicit` set to the slot name for which the
 * `message` is eliciting information
 *
 * - `slots` set to a map of slots, configured for the
 * intent, with currently known values
 *
 * - If the message is a confirmation prompt, the
 * `dialogState` is set to ConfirmIntent and
 * `SlotToElicit` is set to null.
 *
 * - If the message is a clarification prompt (configured for the
 * intent) that indicates that user intent is not understood, the
 * `dialogState` is set to ElicitIntent and
 * `slotToElicit` is set to null.
 *
 * In addition, Amazon Lex also returns your application-specific
 * `sessionAttributes`. For more information, see Managing
 * Conversation Context.
 */
export declare const postText: API.OperationMethod<PostTextRequest, PostTextResponse, PostTextError, Credentials | HttpClient.HttpClient>;
export type PutSessionError = BadGatewayException | BadRequestException | ConflictException | DependencyFailedException | InternalFailureException | LimitExceededException | NotAcceptableException | NotFoundException | CommonErrors;
/**
 * Creates a new session or modifies an existing session with an Amazon Lex
 * bot. Use this operation to enable your application to set the state of the
 * bot.
 *
 * For more information, see Managing
 * Sessions.
 */
export declare const putSession: API.OperationMethod<PutSessionRequest, PutSessionResponse, PutSessionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=lex-runtime-service.d.ts.map