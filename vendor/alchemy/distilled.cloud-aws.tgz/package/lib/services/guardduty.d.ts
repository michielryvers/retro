import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly Type: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
    readonly Type: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly Type: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
    readonly Type: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly Type: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type DetectorId = string;
export interface AcceptAdministratorInvitationRequest {
    DetectorId: string;
    AdministratorId?: string;
    InvitationId?: string;
}
export interface AcceptAdministratorInvitationResponse {
}
export interface AcceptInvitationRequest {
    DetectorId: string;
    MasterId?: string;
    InvitationId?: string;
}
export interface AcceptInvitationResponse {
}
export type FindingId = string;
export type FindingIds = string[];
export interface ArchiveFindingsRequest {
    DetectorId: string;
    FindingIds?: string[];
}
export interface ArchiveFindingsResponse {
}
export type RuleId = string;
export type AssociationMode = "LIVE" | "DRY_RUN" | (string & {});
export type ClientToken = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateCustomDetectionRuleAssociationRequest {
    RuleId?: string;
    Mode?: AssociationMode;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type AssociationId = string;
export type DetectionRuleArn = string;
export type AccountId = string;
export interface AssociationDetail {
    AssociationId?: string;
    Arn?: string;
    RuleId?: string;
    AccountId?: string;
    Mode?: AssociationMode;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    ExpiresAt?: Date;
}
export interface CreateCustomDetectionRuleAssociationResponse {
    RuleAssociation: AssociationDetail & {
        AssociationId: AssociationId;
        Arn: DetectionRuleArn;
        RuleId: RuleId;
        AccountId: AccountId;
        Mode: AssociationMode;
        CreatedAt: Date;
        UpdatedAt: Date;
    };
}
export type DetectionRuleAccountIds = string[];
export interface CreateCustomDetectionRuleOrgConfigurationRequest {
    RuleId?: string;
    Mode?: AssociationMode;
    IncludeAccountIds?: string[];
    ExcludeAccountIds?: string[];
    ClientToken?: string;
}
export interface CreateCustomDetectionRuleOrgConfigurationResponse {
}
export type FindingPublishingFrequency = "FIFTEEN_MINUTES" | "ONE_HOUR" | "SIX_HOURS" | (string & {});
export interface S3LogsConfiguration {
    Enable?: boolean;
}
export interface KubernetesAuditLogsConfiguration {
    Enable?: boolean;
}
export interface KubernetesConfiguration {
    AuditLogs?: KubernetesAuditLogsConfiguration;
}
export interface ScanEc2InstanceWithFindings {
    EbsVolumes?: boolean;
}
export interface MalwareProtectionConfiguration {
    ScanEc2InstanceWithFindings?: ScanEc2InstanceWithFindings;
}
export interface DataSourceConfigurations {
    S3Logs?: S3LogsConfiguration;
    Kubernetes?: KubernetesConfiguration;
    MalwareProtection?: MalwareProtectionConfiguration;
}
export type DetectorFeature = "S3_DATA_EVENTS" | "EKS_AUDIT_LOGS" | "EBS_MALWARE_PROTECTION" | "RDS_LOGIN_EVENTS" | "LAMBDA_NETWORK_LOGS" | "EKS_RUNTIME_MONITORING" | "RUNTIME_MONITORING" | "AI_PROTECTION" | "AI_ANALYST" | (string & {});
export type FeatureStatus = "ENABLED" | "DISABLED" | (string & {});
export type FeatureAdditionalConfiguration = "EKS_ADDON_MANAGEMENT" | "ECS_FARGATE_AGENT_MANAGEMENT" | "EC2_AGENT_MANAGEMENT" | (string & {});
export interface DetectorAdditionalConfiguration {
    Name?: FeatureAdditionalConfiguration;
    Status?: FeatureStatus;
}
export type DetectorAdditionalConfigurations = DetectorAdditionalConfiguration[];
export interface DetectorFeatureConfiguration {
    Name?: DetectorFeature;
    Status?: FeatureStatus;
    AdditionalConfiguration?: DetectorAdditionalConfiguration[];
}
export type DetectorFeatureConfigurations = DetectorFeatureConfiguration[];
export interface CreateDetectorRequest {
    Enable?: boolean;
    ClientToken?: string;
    FindingPublishingFrequency?: FindingPublishingFrequency;
    DataSources?: DataSourceConfigurations;
    Tags?: {
        [key: string]: string | undefined;
    };
    Features?: DetectorFeatureConfiguration[];
}
export type DataSourceStatus = "ENABLED" | "DISABLED" | (string & {});
export interface EbsVolumesResult {
    Status?: DataSourceStatus;
    Reason?: string;
}
export interface ScanEc2InstanceWithFindingsResult {
    EbsVolumes?: EbsVolumesResult;
}
export interface MalwareProtectionConfigurationResult {
    ScanEc2InstanceWithFindings?: ScanEc2InstanceWithFindingsResult;
    ServiceRole?: string;
}
export interface UnprocessedDataSourcesResult {
    MalwareProtection?: MalwareProtectionConfigurationResult;
}
export interface CreateDetectorResponse {
    DetectorId?: string;
    UnprocessedDataSources?: UnprocessedDataSourcesResult;
}
export type FilterName = string;
export type FilterDescription = string;
export type FilterAction = "NOOP" | "ARCHIVE" | (string & {});
export type FilterRank = number;
export type Eq = string[];
export type Neq = string[];
export type Equals = string[];
export type NotEquals = string[];
export type Match = string;
export type Matches = string[];
export type NotMatch = string;
export type NotMatches = string[];
export interface Condition {
    Eq?: string[];
    Neq?: string[];
    Gt?: number;
    Gte?: number;
    Lt?: number;
    Lte?: number;
    Equals?: string[];
    NotEquals?: string[];
    GreaterThan?: number;
    GreaterThanOrEqual?: number;
    LessThan?: number;
    LessThanOrEqual?: number;
    Matches?: string[];
    NotMatches?: string[];
}
export type Criterion = {
    [key: string]: Condition | undefined;
};
export interface FindingCriteria {
    Criterion?: {
        [key: string]: Condition | undefined;
    };
}
export interface CreateFilterRequest {
    DetectorId: string;
    Name?: string;
    Description?: string;
    Action?: FilterAction;
    Rank?: number;
    FindingCriteria?: FindingCriteria;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateFilterResponse {
    Name: string;
}
export type TriggerPrompt = string;
export interface CreateInvestigationRequest {
    DetectorId: string;
    TriggerPrompt?: string;
    ClientToken?: string;
}
export type InvestigationId = string;
export interface CreateInvestigationResponse {
    InvestigationId: string;
}
export type Name = string;
export type IpSetFormat = "TXT" | "STIX" | "OTX_CSV" | "ALIEN_VAULT" | "PROOF_POINT" | "FIRE_EYE" | (string & {});
export type Location = string;
export interface CreateIPSetRequest {
    DetectorId: string;
    Name?: string;
    Format?: IpSetFormat;
    Location?: string;
    Activate?: boolean;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    ExpectedBucketOwner?: string;
}
export interface CreateIPSetResponse {
    IpSetId: string;
}
export type MalwareProtectionPlanObjectPrefixesList = string[];
export interface CreateS3BucketResource {
    BucketName?: string;
    ObjectPrefixes?: string[];
}
export interface CreateProtectedResource {
    S3Bucket?: CreateS3BucketResource;
}
export type MalwareProtectionPlanTaggingActionStatus = "ENABLED" | "DISABLED" | (string & {});
export interface MalwareProtectionPlanTaggingAction {
    Status?: MalwareProtectionPlanTaggingActionStatus;
}
export interface MalwareProtectionPlanActions {
    Tagging?: MalwareProtectionPlanTaggingAction;
}
export interface CreateMalwareProtectionPlanRequest {
    ClientToken?: string;
    Role?: string;
    ProtectedResource?: CreateProtectedResource;
    Actions?: MalwareProtectionPlanActions;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateMalwareProtectionPlanResponse {
    MalwareProtectionPlanId?: string;
}
export type Email = string | redacted.Redacted<string>;
export interface AccountDetail {
    AccountId?: string;
    Email?: string | redacted.Redacted<string>;
}
export type AccountDetails = AccountDetail[];
export interface CreateMembersRequest {
    DetectorId: string;
    AccountDetails?: AccountDetail[];
}
export interface UnprocessedAccount {
    AccountId?: string;
    Result?: string;
}
export type UnprocessedAccounts = UnprocessedAccount[];
export interface CreateMembersResponse {
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export type DestinationType = "S3" | (string & {});
export interface DestinationProperties {
    DestinationArn?: string;
    KmsKeyArn?: string;
}
export interface CreatePublishingDestinationRequest {
    DetectorId: string;
    DestinationType?: DestinationType;
    DestinationProperties?: DestinationProperties;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreatePublishingDestinationResponse {
    DestinationId: string;
}
export type FindingType = string;
export type FindingTypes = string[];
export interface CreateSampleFindingsRequest {
    DetectorId: string;
    FindingTypes?: string[];
}
export interface CreateSampleFindingsResponse {
}
export type ThreatEntitySetFormat = "TXT" | "STIX" | "OTX_CSV" | "ALIEN_VAULT" | "PROOF_POINT" | "FIRE_EYE" | (string & {});
export type ExpectedBucketOwner = string;
export interface CreateThreatEntitySetRequest {
    DetectorId: string;
    Name?: string;
    Format?: ThreatEntitySetFormat;
    Location?: string;
    ExpectedBucketOwner?: string;
    Activate?: boolean;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateThreatEntitySetResponse {
    ThreatEntitySetId: string;
}
export type ThreatIntelSetFormat = "TXT" | "STIX" | "OTX_CSV" | "ALIEN_VAULT" | "PROOF_POINT" | "FIRE_EYE" | (string & {});
export interface CreateThreatIntelSetRequest {
    DetectorId: string;
    Name?: string;
    Format?: ThreatIntelSetFormat;
    Location?: string;
    Activate?: boolean;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    ExpectedBucketOwner?: string;
}
export interface CreateThreatIntelSetResponse {
    ThreatIntelSetId: string;
}
export type TrustedEntitySetFormat = "TXT" | "STIX" | "OTX_CSV" | "ALIEN_VAULT" | "PROOF_POINT" | "FIRE_EYE" | (string & {});
export interface CreateTrustedEntitySetRequest {
    DetectorId: string;
    Name?: string;
    Format?: TrustedEntitySetFormat;
    Location?: string;
    ExpectedBucketOwner?: string;
    Activate?: boolean;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateTrustedEntitySetResponse {
    TrustedEntitySetId: string;
}
export type AccountIds = string[];
export interface DeclineInvitationsRequest {
    AccountIds?: string[];
}
export interface DeclineInvitationsResponse {
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export interface DeleteCustomDetectionRuleAssociationRequest {
    RuleId: string;
    AssociationId: string;
}
export interface DeleteCustomDetectionRuleAssociationResponse {
}
export interface DeleteCustomDetectionRuleOrgConfigurationRequest {
    RuleId: string;
    Mode?: AssociationMode;
}
export interface DeleteCustomDetectionRuleOrgConfigurationResponse {
}
export interface DeleteDetectorRequest {
    DetectorId: string;
}
export interface DeleteDetectorResponse {
}
export interface DeleteFilterRequest {
    DetectorId: string;
    FilterName: string;
}
export interface DeleteFilterResponse {
}
export interface DeleteInvitationsRequest {
    AccountIds?: string[];
}
export interface DeleteInvitationsResponse {
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export interface DeleteIPSetRequest {
    DetectorId: string;
    IpSetId?: string;
}
export interface DeleteIPSetResponse {
}
export interface DeleteMalwareProtectionPlanRequest {
    MalwareProtectionPlanId?: string;
}
export interface DeleteMalwareProtectionPlanResponse {
}
export interface DeleteMembersRequest {
    DetectorId: string;
    AccountIds?: string[];
}
export interface DeleteMembersResponse {
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export interface DeletePublishingDestinationRequest {
    DetectorId: string;
    DestinationId: string;
}
export interface DeletePublishingDestinationResponse {
}
export interface DeleteThreatEntitySetRequest {
    DetectorId: string;
    ThreatEntitySetId?: string;
}
export interface DeleteThreatEntitySetResponse {
}
export interface DeleteThreatIntelSetRequest {
    DetectorId: string;
    ThreatIntelSetId: string;
}
export interface DeleteThreatIntelSetResponse {
}
export interface DeleteTrustedEntitySetRequest {
    DetectorId: string;
    TrustedEntitySetId: string;
}
export interface DeleteTrustedEntitySetResponse {
}
export type IntegerValueWithMax = number;
export type CriterionKey = "EC2_INSTANCE_ARN" | "SCAN_ID" | "ACCOUNT_ID" | "GUARDDUTY_FINDING_ID" | "SCAN_START_TIME" | "SCAN_STATUS" | "SCAN_TYPE" | (string & {});
export type NonEmptyString = string;
export type LongValue = number;
export interface FilterCondition {
    EqualsValue?: string;
    GreaterThan?: number;
    LessThan?: number;
}
export interface FilterCriterion {
    CriterionKey?: CriterionKey;
    FilterCondition?: FilterCondition;
}
export type FilterCriterionList = FilterCriterion[];
export interface FilterCriteria {
    FilterCriterion?: FilterCriterion[];
}
export type OrderBy = "ASC" | "DESC" | (string & {});
export interface SortCriteria {
    AttributeName?: string;
    OrderBy?: OrderBy;
}
export interface DescribeMalwareScansRequest {
    DetectorId: string;
    NextToken?: string;
    MaxResults?: number;
    FilterCriteria?: FilterCriteria;
    SortCriteria?: SortCriteria;
}
export type ScanStatus = "RUNNING" | "COMPLETED" | "FAILED" | "SKIPPED" | (string & {});
export type TriggerType = "BACKUP" | "GUARDDUTY" | (string & {});
export interface TriggerDetails {
    GuardDutyFindingId?: string;
    Description?: string;
    TriggerType?: TriggerType;
}
export type InstanceArn = string;
export interface ResourceDetails {
    InstanceArn?: string;
}
export type ScanResult = "CLEAN" | "INFECTED" | (string & {});
export interface ScanResultDetails {
    ScanResult?: ScanResult;
}
export type PositiveLong = number;
export interface VolumeDetail {
    VolumeArn?: string;
    VolumeType?: string;
    DeviceName?: string;
    VolumeSizeInGB?: number;
    EncryptionType?: string;
    SnapshotArn?: string;
    KmsKeyArn?: string;
}
export type VolumeDetails = VolumeDetail[];
export type ScanType = "GUARDDUTY_INITIATED" | "ON_DEMAND" | (string & {});
export interface Scan {
    DetectorId?: string;
    AdminDetectorId?: string;
    ScanId?: string;
    ScanStatus?: ScanStatus;
    FailureReason?: string;
    ScanStartTime?: Date;
    ScanEndTime?: Date;
    TriggerDetails?: TriggerDetails;
    ResourceDetails?: ResourceDetails;
    ScanResultDetails?: ScanResultDetails;
    AccountId?: string;
    TotalBytes?: number;
    FileCount?: number;
    AttachedVolumes?: VolumeDetail[];
    ScanType?: ScanType;
}
export type Scans = Scan[];
export interface DescribeMalwareScansResponse {
    Scans: Scan[];
    NextToken?: string;
}
export type MaxResults = number;
export interface DescribeOrganizationConfigurationRequest {
    DetectorId: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface OrganizationS3LogsConfigurationResult {
    AutoEnable?: boolean;
}
export interface OrganizationKubernetesAuditLogsConfigurationResult {
    AutoEnable?: boolean;
}
export interface OrganizationKubernetesConfigurationResult {
    AuditLogs?: OrganizationKubernetesAuditLogsConfigurationResult;
}
export interface OrganizationEbsVolumesResult {
    AutoEnable?: boolean;
}
export interface OrganizationScanEc2InstanceWithFindingsResult {
    EbsVolumes?: OrganizationEbsVolumesResult;
}
export interface OrganizationMalwareProtectionConfigurationResult {
    ScanEc2InstanceWithFindings?: OrganizationScanEc2InstanceWithFindingsResult;
}
export interface OrganizationDataSourceConfigurationsResult {
    S3Logs?: OrganizationS3LogsConfigurationResult;
    Kubernetes?: OrganizationKubernetesConfigurationResult;
    MalwareProtection?: OrganizationMalwareProtectionConfigurationResult;
}
export type OrgFeature = "S3_DATA_EVENTS" | "EKS_AUDIT_LOGS" | "EBS_MALWARE_PROTECTION" | "RDS_LOGIN_EVENTS" | "LAMBDA_NETWORK_LOGS" | "EKS_RUNTIME_MONITORING" | "RUNTIME_MONITORING" | "AI_PROTECTION" | (string & {});
export type OrgFeatureStatus = "NEW" | "NONE" | "ALL" | (string & {});
export type OrgFeatureAdditionalConfiguration = "EKS_ADDON_MANAGEMENT" | "ECS_FARGATE_AGENT_MANAGEMENT" | "EC2_AGENT_MANAGEMENT" | (string & {});
export interface OrganizationAdditionalConfigurationResult {
    Name?: OrgFeatureAdditionalConfiguration;
    AutoEnable?: OrgFeatureStatus;
}
export type OrganizationAdditionalConfigurationResults = OrganizationAdditionalConfigurationResult[];
export interface OrganizationFeatureConfigurationResult {
    Name?: OrgFeature;
    AutoEnable?: OrgFeatureStatus;
    AdditionalConfiguration?: OrganizationAdditionalConfigurationResult[];
}
export type OrganizationFeaturesConfigurationsResults = OrganizationFeatureConfigurationResult[];
export type AutoEnableMembers = "NEW" | "ALL" | "NONE" | (string & {});
export interface DescribeOrganizationConfigurationResponse {
    AutoEnable?: boolean;
    MemberAccountLimitReached: boolean;
    DataSources?: OrganizationDataSourceConfigurationsResult & {
        S3Logs: OrganizationS3LogsConfigurationResult & {
            AutoEnable: boolean;
        };
        Kubernetes: OrganizationKubernetesConfigurationResult & {
            AuditLogs: OrganizationKubernetesAuditLogsConfigurationResult & {
                AutoEnable: boolean;
            };
        };
    };
    Features?: OrganizationFeatureConfigurationResult[];
    NextToken?: string;
    AutoEnableOrganizationMembers?: AutoEnableMembers;
}
export interface DescribePublishingDestinationRequest {
    DetectorId: string;
    DestinationId: string;
}
export type PublishingStatus = "PENDING_VERIFICATION" | "PUBLISHING" | "UNABLE_TO_PUBLISH_FIX_DESTINATION_PROPERTY" | "STOPPED" | (string & {});
export interface DescribePublishingDestinationResponse {
    DestinationId: string;
    DestinationType: DestinationType;
    Status: PublishingStatus;
    PublishingFailureStartTimestamp: number;
    DestinationProperties: DestinationProperties;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DisableOrganizationAdminAccountRequest {
    AdminAccountId?: string;
}
export interface DisableOrganizationAdminAccountResponse {
}
export interface DisassociateFromAdministratorAccountRequest {
    DetectorId: string;
}
export interface DisassociateFromAdministratorAccountResponse {
}
export interface DisassociateFromMasterAccountRequest {
    DetectorId: string;
}
export interface DisassociateFromMasterAccountResponse {
}
export interface DisassociateMembersRequest {
    DetectorId: string;
    AccountIds?: string[];
}
export interface DisassociateMembersResponse {
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export interface EnableOrganizationAdminAccountRequest {
    AdminAccountId?: string;
}
export interface EnableOrganizationAdminAccountResponse {
}
export interface GetAdministratorAccountRequest {
    DetectorId: string;
}
export interface Administrator {
    AccountId?: string;
    InvitationId?: string;
    RelationshipStatus?: string;
    InvitedAt?: string;
}
export interface GetAdministratorAccountResponse {
    Administrator: Administrator;
}
export type CoverageFilterCriterionKey = "ACCOUNT_ID" | "RESOURCE_TYPE" | "COVERAGE_STATUS" | "ADDON_VERSION" | "CLUSTER_NAME" | "ECS_CLUSTER_NAME" | "MANAGEMENT_TYPE" | "EKS_CLUSTER_NAME" | "AGENT_VERSION" | "INSTANCE_ID" | "CLUSTER_ARN" | (string & {});
export interface CoverageFilterCondition {
    Equals?: string[];
    NotEquals?: string[];
}
export interface CoverageFilterCriterion {
    CriterionKey?: CoverageFilterCriterionKey;
    FilterCondition?: CoverageFilterCondition;
}
export type CoverageFilterCriterionList = CoverageFilterCriterion[];
export interface CoverageFilterCriteria {
    FilterCriterion?: CoverageFilterCriterion[];
}
export type CoverageStatisticsType = "COUNT_BY_RESOURCE_TYPE" | "COUNT_BY_COVERAGE_STATUS" | (string & {});
export type CoverageStatisticsTypeList = CoverageStatisticsType[];
export interface GetCoverageStatisticsRequest {
    DetectorId: string;
    FilterCriteria?: CoverageFilterCriteria;
    StatisticsType?: CoverageStatisticsType[];
}
export type ResourceType = "EKS" | "ECS" | "EC2" | (string & {});
export type CountByResourceType = {
    [key in ResourceType]?: number;
};
export type CoverageStatus = "HEALTHY" | "UNHEALTHY" | (string & {});
export type CountByCoverageStatus = {
    [key in CoverageStatus]?: number;
};
export interface CoverageStatistics {
    CountByResourceType?: {
        [key: string]: number | undefined;
    };
    CountByCoverageStatus?: {
        [key: string]: number | undefined;
    };
}
export interface GetCoverageStatisticsResponse {
    CoverageStatistics?: CoverageStatistics;
}
export interface GetCustomDetectionRuleRequest {
    RuleId: string;
}
export type RuleName = string;
export type DetectionRuleDescription = string;
export type DetectionRuleSeverity = "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | (string & {});
export type DetectionRuleDataSource = "CloudTrailManagementEvent" | (string & {});
export type MitreTactic = string;
export type MitreTechnique = string;
export type DetectionRuleServiceName = string;
export type RuleExpression = string;
export interface RuleDefinition {
    Expression?: string;
}
export type RuleLanguage = "SQL" | (string & {});
export type RuleSchema = "CloudTrail" | (string & {});
export interface RuleDetail {
    RuleId?: string;
    Arn?: string;
    Name?: string;
    Description?: string;
    Severity?: DetectionRuleSeverity;
    DataSource?: DetectionRuleDataSource;
    Tactic?: string;
    Technique?: string;
    Service?: string;
    Definition?: RuleDefinition;
    Language?: RuleLanguage;
    Schema?: RuleSchema;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export interface GetCustomDetectionRuleResponse {
    Rule: RuleDetail & {
        RuleId: RuleId;
        Arn: DetectionRuleArn;
        Name: RuleName;
        Description: DetectionRuleDescription;
        Severity: DetectionRuleSeverity;
        DataSource: DetectionRuleDataSource;
        Tactic: MitreTactic;
        Technique: MitreTechnique;
        Service: DetectionRuleServiceName;
        Definition: RuleDefinition & {
            Expression: RuleExpression;
        };
        CreatedAt: Date;
    };
}
export interface GetCustomDetectionRuleAssociationRequest {
    RuleId: string;
    AssociationId: string;
}
export interface GetCustomDetectionRuleAssociationResponse {
    RuleAssociation: AssociationDetail & {
        AssociationId: AssociationId;
        Arn: DetectionRuleArn;
        RuleId: RuleId;
        AccountId: AccountId;
        Mode: AssociationMode;
        CreatedAt: Date;
        UpdatedAt: Date;
    };
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetCustomDetectionRuleOrgConfigurationRequest {
    RuleId: string;
    Mode?: AssociationMode;
}
export type DetectionRuleConfigurationStatus = "ACTIVE" | "PROCESSING" | "FAILED" | (string & {});
export interface DetectionRuleOrgConfiguration {
    RuleId?: string;
    Mode?: AssociationMode;
    Status?: DetectionRuleConfigurationStatus;
    StatusReason?: string;
    IncludeAccountIds?: string[];
    ExcludeAccountIds?: string[];
    CreatedAt?: Date;
    UpdatedAt?: Date;
    ExpiresAt?: Date;
}
export interface GetCustomDetectionRuleOrgConfigurationResponse {
    Configuration: DetectionRuleOrgConfiguration & {
        RuleId: RuleId;
        Mode: AssociationMode;
        Status: DetectionRuleConfigurationStatus;
        IncludeAccountIds: DetectionRuleAccountIds;
        ExcludeAccountIds: DetectionRuleAccountIds;
        CreatedAt: Date;
        UpdatedAt: Date;
    };
}
export interface GetDetectorRequest {
    DetectorId: string;
}
export type DetectorStatus = "ENABLED" | "DISABLED" | (string & {});
export interface CloudTrailConfigurationResult {
    Status?: DataSourceStatus;
}
export interface DNSLogsConfigurationResult {
    Status?: DataSourceStatus;
}
export interface FlowLogsConfigurationResult {
    Status?: DataSourceStatus;
}
export interface S3LogsConfigurationResult {
    Status?: DataSourceStatus;
}
export interface KubernetesAuditLogsConfigurationResult {
    Status?: DataSourceStatus;
}
export interface KubernetesConfigurationResult {
    AuditLogs?: KubernetesAuditLogsConfigurationResult;
}
export interface DataSourceConfigurationsResult {
    CloudTrail?: CloudTrailConfigurationResult;
    DNSLogs?: DNSLogsConfigurationResult;
    FlowLogs?: FlowLogsConfigurationResult;
    S3Logs?: S3LogsConfigurationResult;
    Kubernetes?: KubernetesConfigurationResult;
    MalwareProtection?: MalwareProtectionConfigurationResult;
}
export type DetectorFeatureResult = "FLOW_LOGS" | "CLOUD_TRAIL" | "DNS_LOGS" | "S3_DATA_EVENTS" | "EKS_AUDIT_LOGS" | "EBS_MALWARE_PROTECTION" | "RDS_LOGIN_EVENTS" | "LAMBDA_NETWORK_LOGS" | "EKS_RUNTIME_MONITORING" | "RUNTIME_MONITORING" | "AI_PROTECTION" | "AI_ANALYST" | (string & {});
export type ManagedBy = "GUARDDUTY_POLICY" | (string & {});
export interface DetectorAdditionalConfigurationResult {
    Name?: FeatureAdditionalConfiguration;
    Status?: FeatureStatus;
    UpdatedAt?: Date;
    ManagedBy?: ManagedBy;
}
export type DetectorAdditionalConfigurationResults = DetectorAdditionalConfigurationResult[];
export interface DetectorFeatureConfigurationResult {
    Name?: DetectorFeatureResult;
    Status?: FeatureStatus;
    UpdatedAt?: Date;
    AdditionalConfiguration?: DetectorAdditionalConfigurationResult[];
    ManagedBy?: ManagedBy;
}
export type DetectorFeatureConfigurationsResults = DetectorFeatureConfigurationResult[];
export interface GetDetectorResponse {
    CreatedAt?: string;
    FindingPublishingFrequency?: FindingPublishingFrequency;
    ServiceRole: string;
    Status: DetectorStatus;
    UpdatedAt?: string;
    DataSources?: DataSourceConfigurationsResult & {
        CloudTrail: CloudTrailConfigurationResult & {
            Status: DataSourceStatus;
        };
        DNSLogs: DNSLogsConfigurationResult & {
            Status: DataSourceStatus;
        };
        FlowLogs: FlowLogsConfigurationResult & {
            Status: DataSourceStatus;
        };
        S3Logs: S3LogsConfigurationResult & {
            Status: DataSourceStatus;
        };
        Kubernetes: KubernetesConfigurationResult & {
            AuditLogs: KubernetesAuditLogsConfigurationResult & {
                Status: DataSourceStatus;
            };
        };
    };
    Tags?: {
        [key: string]: string | undefined;
    };
    Features?: DetectorFeatureConfigurationResult[];
}
export interface GetFilterRequest {
    DetectorId: string;
    FilterName: string;
}
export type FilterVersion = number;
export interface GetFilterResponse {
    Name: string;
    Description?: string;
    Action: FilterAction;
    Rank?: number;
    FindingCriteria: FindingCriteria;
    Tags?: {
        [key: string]: string | undefined;
    };
    CreatedAt?: Date;
    UpdatedAt?: Date;
    Version?: number;
}
export interface GetFindingsRequest {
    DetectorId: string;
    FindingIds?: string[];
    SortCriteria?: SortCriteria;
}
export interface AccessKeyDetails {
    AccessKeyId?: string;
    PrincipalId?: string;
    UserName?: string;
    UserType?: string;
}
export interface Owner {
    Id?: string;
}
export interface Tag {
    Key?: string;
    Value?: string;
}
export type Tags = Tag[];
export interface DefaultServerSideEncryption {
    EncryptionType?: string;
    KmsMasterKeyArn?: string;
}
export interface AccessControlList {
    AllowsPublicReadAccess?: boolean;
    AllowsPublicWriteAccess?: boolean;
}
export interface BucketPolicy {
    AllowsPublicReadAccess?: boolean;
    AllowsPublicWriteAccess?: boolean;
}
export interface BlockPublicAccess {
    IgnorePublicAcls?: boolean;
    RestrictPublicBuckets?: boolean;
    BlockPublicAcls?: boolean;
    BlockPublicPolicy?: boolean;
}
export interface BucketLevelPermissions {
    AccessControlList?: AccessControlList;
    BucketPolicy?: BucketPolicy;
    BlockPublicAccess?: BlockPublicAccess;
}
export interface AccountLevelPermissions {
    BlockPublicAccess?: BlockPublicAccess;
}
export interface PermissionConfiguration {
    BucketLevelPermissions?: BucketLevelPermissions;
    AccountLevelPermissions?: AccountLevelPermissions;
}
export interface PublicAccess {
    PermissionConfiguration?: PermissionConfiguration;
    EffectivePermission?: string;
}
export interface S3ObjectDetail {
    ObjectArn?: string;
    Key?: string;
    ETag?: string;
    Hash?: string;
    VersionId?: string;
}
export type S3ObjectDetails = S3ObjectDetail[];
export interface S3BucketDetail {
    Arn?: string;
    Name?: string;
    Type?: string;
    CreatedAt?: Date;
    Owner?: Owner;
    Tags?: Tag[];
    DefaultServerSideEncryption?: DefaultServerSideEncryption;
    PublicAccess?: PublicAccess;
    S3ObjectDetails?: S3ObjectDetail[];
}
export type S3BucketDetails = S3BucketDetail[];
export interface IamInstanceProfile {
    Arn?: string;
    Id?: string;
}
export type Ipv6Addresses = string[];
export type SensitiveString = string | redacted.Redacted<string>;
export interface PrivateIpAddressDetails {
    PrivateDnsName?: string;
    PrivateIpAddress?: string | redacted.Redacted<string>;
}
export type PrivateIpAddresses = PrivateIpAddressDetails[];
export interface SecurityGroup {
    GroupId?: string;
    GroupName?: string;
}
export type SecurityGroups = SecurityGroup[];
export interface NetworkInterface {
    Ipv6Addresses?: string[];
    NetworkInterfaceId?: string;
    PrivateDnsName?: string;
    PrivateIpAddress?: string | redacted.Redacted<string>;
    PrivateIpAddresses?: PrivateIpAddressDetails[];
    PublicDnsName?: string;
    PublicIp?: string;
    SecurityGroups?: SecurityGroup[];
    SubnetId?: string;
    VpcId?: string;
}
export type NetworkInterfaces = NetworkInterface[];
export interface ProductCode {
    Code?: string;
    ProductType?: string;
}
export type ProductCodes = ProductCode[];
export interface InstanceDetails {
    AvailabilityZone?: string;
    IamInstanceProfile?: IamInstanceProfile;
    ImageDescription?: string;
    ImageId?: string;
    InstanceId?: string;
    InstanceState?: string;
    InstanceType?: string;
    OutpostArn?: string;
    LaunchTime?: string;
    NetworkInterfaces?: NetworkInterface[];
    Platform?: string;
    ProductCodes?: ProductCode[];
    Tags?: Tag[];
}
export interface EksClusterDetails {
    Name?: string;
    Arn?: string;
    VpcId?: string;
    Status?: string;
    Tags?: Tag[];
    CreatedAt?: Date;
}
export type Groups = string[];
export type SessionNameList = string[];
export interface ImpersonatedUser {
    Username?: string;
    Groups?: string[];
}
export interface KubernetesUserDetails {
    Username?: string;
    Uid?: string;
    Groups?: string[];
    SessionName?: string[];
    ImpersonatedUser?: ImpersonatedUser;
}
export interface VolumeMount {
    Name?: string;
    MountPath?: string;
}
export type VolumeMounts = VolumeMount[];
export interface SecurityContext {
    Privileged?: boolean;
    AllowPrivilegeEscalation?: boolean;
}
export interface Container {
    ContainerRuntime?: string;
    Id?: string;
    Name?: string;
    Image?: string;
    ImagePrefix?: string;
    VolumeMounts?: VolumeMount[];
    SecurityContext?: SecurityContext;
}
export type Containers = Container[];
export interface HostPath {
    Path?: string;
}
export interface Volume {
    Name?: string;
    HostPath?: HostPath;
}
export type Volumes = Volume[];
export interface KubernetesWorkloadDetails {
    Name?: string;
    Type?: string;
    Uid?: string;
    Namespace?: string;
    HostNetwork?: boolean;
    ServiceAccountName?: string;
    Containers?: Container[];
    Volumes?: Volume[];
    HostIPC?: boolean;
    HostPID?: boolean;
}
export interface KubernetesDetails {
    KubernetesUserDetails?: KubernetesUserDetails;
    KubernetesWorkloadDetails?: KubernetesWorkloadDetails;
}
export interface EbsVolumeDetails {
    ScannedVolumeDetails?: VolumeDetail[];
    SkippedVolumeDetails?: VolumeDetail[];
}
export interface EcsTaskDetails {
    Arn?: string;
    DefinitionArn?: string;
    Version?: string;
    TaskCreatedAt?: Date;
    StartedAt?: Date;
    StartedBy?: string;
    Tags?: Tag[];
    Volumes?: Volume[];
    Containers?: Container[];
    Group?: string;
    LaunchType?: string;
}
export interface EcsClusterDetails {
    Name?: string;
    Arn?: string;
    Status?: string;
    ActiveServicesCount?: number;
    RegisteredContainerInstancesCount?: number;
    RunningTasksCount?: number;
    Tags?: Tag[];
    TaskDetails?: EcsTaskDetails;
}
export type SubnetIds = string[];
export interface VpcConfig {
    SubnetIds?: string[];
    VpcId?: string;
    SecurityGroups?: SecurityGroup[];
}
export interface LambdaDetails {
    FunctionArn?: string;
    FunctionName?: string;
    Description?: string;
    LastModifiedAt?: Date;
    RevisionId?: string;
    FunctionVersion?: string;
    Role?: string;
    VpcConfig?: VpcConfig;
    Tags?: Tag[];
}
export interface RdsDbInstanceDetails {
    DbInstanceIdentifier?: string;
    Engine?: string;
    EngineVersion?: string;
    DbClusterIdentifier?: string;
    DbInstanceArn?: string;
    DbiResourceId?: string;
    Tags?: Tag[];
}
export interface RdsLimitlessDbDetails {
    DbShardGroupIdentifier?: string;
    DbShardGroupResourceId?: string;
    DbShardGroupArn?: string;
    Engine?: string;
    EngineVersion?: string;
    DbClusterIdentifier?: string;
    Tags?: Tag[];
}
export interface RdsDbUserDetails {
    User?: string;
    Application?: string;
    Database?: string;
    Ssl?: string;
    AuthMethod?: string;
}
export interface EbsSnapshotDetails {
    SnapshotArn?: string;
}
export interface Ec2ImageDetails {
    ImageArn?: string;
}
export interface ScanConfigurationContinuousScanDetails {
    StartTime?: Date;
    EndTime: Date;
}
export interface RecoveryPointDetails {
    RecoveryPointArn?: string;
    BackupVaultName?: string;
    ContinuousScanDetails?: ScanConfigurationContinuousScanDetails;
}
export interface BedrockGuardrail {
    Arn?: string;
    Version?: string;
}
export type BedrockGuardrails = BedrockGuardrail[];
export type GuardrailAction = "GUARDRAIL_INTERVENED" | "NONE" | (string & {});
export type GuardrailSource = "INPUT" | "OUTPUT" | (string & {});
export type ContentPolicyFilterType = "PROMPT_ATTACK" | "JAILBREAK" | "HATE" | "INSULTS" | "SEXUAL" | "VIOLENCE" | "MISCONDUCT" | (string & {});
export type ConfidenceLevel = "HIGH" | "MEDIUM" | "LOW" | "NONE" | (string & {});
export type ContentPolicyFilterAction = "BLOCKED" | "NONE" | (string & {});
export interface ContentPolicyFilter {
    Type?: ContentPolicyFilterType;
    Confidence?: ConfidenceLevel;
    Action?: ContentPolicyFilterAction;
}
export type ContentPolicyFilters = ContentPolicyFilter[];
export interface BedrockGuardrailDetails {
    GuardrailArn?: string;
    GuardrailVersion?: string;
    Guardrails?: BedrockGuardrail[];
    GuardrailAction?: GuardrailAction;
    GuardrailSource?: GuardrailSource;
    ContentPolicyFilters?: ContentPolicyFilter[];
}
export interface ModelDetail {
    ModelId?: string;
}
export type ModelDetails = ModelDetail[];
export interface Resource {
    AccessKeyDetails?: AccessKeyDetails;
    S3BucketDetails?: S3BucketDetail[];
    InstanceDetails?: InstanceDetails;
    EksClusterDetails?: EksClusterDetails;
    KubernetesDetails?: KubernetesDetails;
    ResourceType?: string;
    EbsVolumeDetails?: EbsVolumeDetails;
    EcsClusterDetails?: EcsClusterDetails;
    ContainerDetails?: Container;
    LambdaDetails?: LambdaDetails;
    RdsDbInstanceDetails?: RdsDbInstanceDetails;
    RdsLimitlessDbDetails?: RdsLimitlessDbDetails;
    RdsDbUserDetails?: RdsDbUserDetails;
    EbsSnapshotDetails?: EbsSnapshotDetails;
    Ec2ImageDetails?: Ec2ImageDetails;
    RecoveryPointDetails?: RecoveryPointDetails;
    BedrockGuardrailDetails?: BedrockGuardrailDetails;
    ModelDetails?: ModelDetail[];
}
export interface DomainDetails {
    Domain?: string;
}
export interface City {
    CityName?: string;
}
export interface Country {
    CountryCode?: string;
    CountryName?: string;
}
export interface GeoLocation {
    Lat?: number;
    Lon?: number;
}
export interface Organization {
    Asn?: string;
    AsnOrg?: string;
    Isp?: string;
    Org?: string;
}
export interface RemoteIpDetails {
    City?: City;
    Country?: Country;
    GeoLocation?: GeoLocation;
    IpAddressV4?: string | redacted.Redacted<string>;
    IpAddressV6?: string | redacted.Redacted<string>;
    Organization?: Organization;
}
export interface RemoteAccountDetails {
    AccountId?: string;
    Affiliated?: boolean;
    AwsServiceName?: string;
}
export type AffectedResources = {
    [key: string]: string | undefined;
};
export interface AwsApiCallAction {
    Api?: string;
    CallerType?: string;
    DomainDetails?: DomainDetails;
    ErrorCode?: string;
    UserAgent?: string;
    RemoteIpDetails?: RemoteIpDetails;
    ServiceName?: string;
    RemoteAccountDetails?: RemoteAccountDetails;
    AffectedResources?: {
        [key: string]: string | undefined;
    };
}
export interface DnsRequestAction {
    Domain?: string;
    Protocol?: string;
    Blocked?: boolean;
    DomainWithSuffix?: string;
    VpcOwnerAccountId?: string;
}
export interface LocalPortDetails {
    Port?: number;
    PortName?: string;
}
export interface LocalIpDetails {
    IpAddressV4?: string | redacted.Redacted<string>;
    IpAddressV6?: string | redacted.Redacted<string>;
}
export interface RemotePortDetails {
    Port?: number;
    PortName?: string;
}
export interface NetworkConnectionAction {
    Blocked?: boolean;
    ConnectionDirection?: string;
    LocalPortDetails?: LocalPortDetails;
    Protocol?: string;
    LocalIpDetails?: LocalIpDetails;
    LocalNetworkInterface?: string;
    RemoteIpDetails?: RemoteIpDetails;
    RemotePortDetails?: RemotePortDetails;
}
export interface PortProbeDetail {
    LocalPortDetails?: LocalPortDetails;
    LocalIpDetails?: LocalIpDetails;
    RemoteIpDetails?: RemoteIpDetails;
}
export type PortProbeDetails = PortProbeDetail[];
export interface PortProbeAction {
    Blocked?: boolean;
    PortProbeDetails?: PortProbeDetail[];
}
export type SourceIps = string[];
export interface KubernetesApiCallAction {
    RequestUri?: string;
    Verb?: string;
    Resource?: string;
    Subresource?: string;
    Namespace?: string;
    ResourceName?: string;
    SourceIps?: string[];
    UserAgent?: string;
    RemoteIpDetails?: RemoteIpDetails;
    StatusCode?: number;
    Parameters?: string;
}
export interface KubernetesPermissionCheckedDetails {
    Verb?: string;
    Resource?: string;
    Namespace?: string;
    Allowed?: boolean;
}
export interface KubernetesRoleBindingDetails {
    Kind?: string;
    Name?: string;
    Uid?: string;
    RoleRefName?: string;
    RoleRefKind?: string;
}
export interface KubernetesRoleDetails {
    Kind?: string;
    Name?: string;
    Uid?: string;
}
export interface LoginAttribute {
    User?: string;
    Application?: string;
    FailedLoginAttempts?: number;
    SuccessfulLoginAttempts?: number;
}
export type LoginAttributes = LoginAttribute[];
export interface RdsLoginAttemptAction {
    RemoteIpDetails?: RemoteIpDetails;
    LoginAttributes?: LoginAttribute[];
}
export interface Action {
    ActionType?: string;
    AwsApiCallAction?: AwsApiCallAction;
    DnsRequestAction?: DnsRequestAction;
    NetworkConnectionAction?: NetworkConnectionAction;
    PortProbeAction?: PortProbeAction;
    KubernetesApiCallAction?: KubernetesApiCallAction;
    KubernetesPermissionCheckedDetails?: KubernetesPermissionCheckedDetails;
    KubernetesRoleBindingDetails?: KubernetesRoleBindingDetails;
    KubernetesRoleDetails?: KubernetesRoleDetails;
    RdsLoginAttemptAction?: RdsLoginAttemptAction;
}
export type ThreatNames = string[];
export interface ThreatIntelligenceDetail {
    ThreatListName?: string;
    ThreatNames?: string[];
    ThreatFileSha256?: string;
}
export type ThreatIntelligenceDetails = ThreatIntelligenceDetail[];
export interface Evidence {
    ThreatIntelligenceDetails?: ThreatIntelligenceDetail[];
}
export interface ServiceAdditionalInfo {
    Value?: string;
    Type?: string;
}
export type Sources = string[];
export interface ScannedItemCount {
    TotalGb?: number;
    Files?: number;
    Volumes?: number;
}
export interface ThreatsDetectedItemCount {
    Files?: number;
}
export interface HighestSeverityThreatDetails {
    Severity?: string;
    ThreatName?: string;
    Count?: number;
}
export interface ScanFilePath {
    FilePath?: string;
    VolumeArn?: string;
    Hash?: string;
    FileName?: string;
}
export type FilePaths = ScanFilePath[];
export interface ScanThreatName {
    Name?: string;
    Severity?: string;
    ItemCount?: number;
    FilePaths?: ScanFilePath[];
}
export type ScanThreatNames = ScanThreatName[];
export interface ThreatDetectedByName {
    ItemCount?: number;
    UniqueThreatNameCount?: number;
    Shortened?: boolean;
    ThreatNames?: ScanThreatName[];
}
export interface ScanDetections {
    ScannedItemCount?: ScannedItemCount;
    ThreatsDetectedItemCount?: ThreatsDetectedItemCount;
    HighestSeverityThreatDetails?: HighestSeverityThreatDetails;
    ThreatDetectedByName?: ThreatDetectedByName;
}
export interface EbsVolumeScanDetails {
    ScanId?: string;
    ScanStartedAt?: Date;
    ScanCompletedAt?: Date;
    TriggerFindingId?: string;
    Sources?: string[];
    ScanDetections?: ScanDetections;
    ScanType?: ScanType;
}
export interface LineageObject {
    StartTime?: Date;
    NamespacePid?: number;
    UserId?: number;
    Name?: string;
    Pid?: number;
    Uuid?: string;
    ExecutablePath?: string;
    Euid?: number;
    ParentUuid?: string;
}
export type Lineage = LineageObject[];
export interface ProcessDetails {
    Name?: string;
    ExecutablePath?: string;
    ExecutableSha256?: string;
    NamespacePid?: number;
    Pwd?: string;
    Pid?: number;
    StartTime?: Date;
    Uuid?: string;
    ParentUuid?: string;
    User?: string;
    UserId?: number;
    Euid?: number;
    Lineage?: LineageObject[];
}
export type FlagsList = string[];
export type MemoryRegionsList = string[];
export type RelatedFilePathsList = string[];
export interface RuntimeContext {
    ModifyingProcess?: ProcessDetails;
    ModifiedAt?: Date;
    ScriptPath?: string;
    LibraryPath?: string;
    LdPreloadValue?: string;
    SocketPath?: string;
    RuncBinaryPath?: string;
    ReleaseAgentPath?: string;
    MountSource?: string;
    MountTarget?: string;
    FileSystemType?: string;
    Flags?: string[];
    ModuleName?: string;
    ModuleFilePath?: string;
    ModuleSha256?: string;
    ShellHistoryFilePath?: string;
    TargetProcess?: ProcessDetails;
    AddressFamily?: string;
    IanaProtocolNumber?: number;
    MemoryRegions?: string[];
    ToolName?: string;
    ToolCategory?: string;
    ServiceName?: string;
    CommandLineExample?: string;
    ThreatFilePath?: string;
    FileOperation?: string;
    FilePath?: string;
    RelatedFilePaths?: string[];
}
export interface RuntimeDetails {
    Process?: ProcessDetails;
    Context?: RuntimeContext;
}
export type ProfileType = "FREQUENCY" | "VOLUME" | (string & {});
export type ProfileSubtype = "FREQUENT" | "INFREQUENT" | "UNSEEN" | "RARE" | "COUNT" | "AVERAGE" | (string & {});
export type ObservationTexts = string[];
export type ObservationNumbers = number[];
export interface Observations {
    Text?: string[];
    Number?: number[];
}
export interface AnomalyObject {
    ProfileType?: ProfileType;
    ProfileSubtype?: ProfileSubtype;
    Observations?: Observations;
}
export type AnomalyProfileFeatureObjects = AnomalyObject[];
export type AnomalyProfileFeatures = {
    [key: string]: AnomalyObject[] | undefined;
};
export type AnomalyProfiles = {
    [key: string]: {
        [key: string]: AnomalyObject[] | undefined;
    } | undefined;
};
export type AnomalyUnusualBehaviorFeature = {
    [key: string]: AnomalyObject | undefined;
};
export type Behavior = {
    [key: string]: {
        [key: string]: AnomalyObject | undefined;
    } | undefined;
};
export interface AnomalyUnusual {
    Behavior?: {
        [key: string]: {
            [key: string]: AnomalyObject | undefined;
        } | undefined;
    };
}
export interface Anomaly {
    Profiles?: {
        [key: string]: {
            [key: string]: AnomalyObject[] | undefined;
        } | undefined;
    };
    Unusual?: AnomalyUnusual;
}
export type SequenceDescription = string;
export interface Account {
    Uid?: string;
    Name?: string;
}
export interface User {
    Name?: string;
    Uid?: string;
    Type?: string;
    CredentialUid?: string;
    Account?: Account;
}
export type MfaStatus = "ENABLED" | "DISABLED" | (string & {});
export interface Session {
    Uid?: string;
    MfaStatus?: MfaStatus;
    CreatedTime?: Date;
    Issuer?: string;
}
export type ProcessName = string;
export type ProcessPath = string;
export type ProcessSha256 = string;
export interface ActorProcess {
    Name?: string;
    Path?: string;
    Sha256?: string;
}
export interface Actor {
    Id?: string;
    User?: User;
    Session?: Session;
    Process?: ActorProcess;
}
export type Actors = Actor[];
export type FindingResourceType = "EC2_INSTANCE" | "EC2_NETWORK_INTERFACE" | "S3_BUCKET" | "S3_OBJECT" | "ACCESS_KEY" | "EKS_CLUSTER" | "KUBERNETES_WORKLOAD" | "CONTAINER" | "ECS_CLUSTER" | "ECS_TASK" | "AUTOSCALING_AUTO_SCALING_GROUP" | "IAM_INSTANCE_PROFILE" | "CLOUDFORMATION_STACK" | "EC2_LAUNCH_TEMPLATE" | "EC2_VPC" | "EC2_IMAGE" | "BEDROCK_CUSTOM_MODEL" | "BEDROCK_IMPORTED_MODEL" | "BEDROCK_PROVISIONED_MODEL" | "BEDROCK_CUSTOM_MODEL_DEPLOYMENT" | "BEDROCK_INFERENCE_PROFILE" | "BEDROCK_APPLICATION_INFERENCE_PROFILE" | "BEDROCK_PROMPT" | "BEDROCK_PROMPT_ROUTER" | "BEDROCK_GUARDRAIL" | "SAGEMAKER_ENDPOINT" | (string & {});
export type PublicAccessStatus = "BLOCKED" | "ALLOWED" | (string & {});
export type PublicAclIgnoreBehavior = "IGNORED" | "NOT_IGNORED" | (string & {});
export type PublicBucketRestrictBehavior = "RESTRICTED" | "NOT_RESTRICTED" | (string & {});
export interface PublicAccessConfiguration {
    PublicAclAccess?: PublicAccessStatus;
    PublicPolicyAccess?: PublicAccessStatus;
    PublicAclIgnoreBehavior?: PublicAclIgnoreBehavior;
    PublicBucketRestrictBehavior?: PublicBucketRestrictBehavior;
}
export type S3ObjectUids = string[];
export interface S3Bucket {
    OwnerId?: string;
    CreatedAt?: Date;
    EncryptionType?: string;
    EncryptionKeyArn?: string;
    EffectivePermission?: string;
    PublicReadAccess?: PublicAccessStatus;
    PublicWriteAccess?: PublicAccessStatus;
    AccountPublicAccess?: PublicAccessConfiguration;
    BucketPublicAccess?: PublicAccessConfiguration;
    S3ObjectUids?: string[];
}
export type Ec2NetworkInterfaceUids = string[];
export interface Ec2Instance {
    AvailabilityZone?: string;
    ImageDescription?: string;
    InstanceState?: string;
    IamInstanceProfile?: IamInstanceProfile;
    InstanceType?: string;
    OutpostArn?: string;
    Platform?: string;
    ProductCodes?: ProductCode[];
    Ec2NetworkInterfaceUids?: string[];
}
export interface AccessKey {
    PrincipalId?: string;
    UserName?: string;
    UserType?: string;
}
export interface Ec2NetworkInterface {
    Ipv6Addresses?: string[];
    PrivateIpAddresses?: PrivateIpAddressDetails[];
    PublicIp?: string;
    SecurityGroups?: SecurityGroup[];
    SubNetId?: string;
    VpcId?: string;
}
export interface S3Object {
    ETag?: string;
    Key?: string;
    VersionId?: string;
}
export type ClusterStatus = "CREATING" | "ACTIVE" | "DELETING" | "FAILED" | "UPDATING" | "PENDING" | (string & {});
export type Ec2InstanceUid = string;
export type Ec2InstanceUids = string[];
export interface EksCluster {
    Arn?: string;
    CreatedAt?: Date;
    Status?: ClusterStatus;
    VpcId?: string;
    Ec2InstanceUids?: string[];
}
export type ContainerUid = string;
export type ContainerUids = string[];
export type KubernetesResourcesTypes = "PODS" | "JOBS" | "CRONJOBS" | "DEPLOYMENTS" | "DAEMONSETS" | "STATEFULSETS" | "REPLICASETS" | "REPLICATIONCONTROLLERS" | (string & {});
export interface KubernetesWorkload {
    ContainerUids?: string[];
    Namespace?: string;
    KubernetesResourcesTypes?: KubernetesResourcesTypes;
}
export type ContainerImageUid = string;
export interface ContainerFindingResource {
    Image?: string;
    ImageUid?: string;
}
export type EcsClusterStatus = "ACTIVE" | "PROVISIONING" | "DEPROVISIONING" | "FAILED" | "INACTIVE" | (string & {});
export interface EcsCluster {
    Status?: EcsClusterStatus;
    Ec2InstanceUids?: string[];
}
export type EcsLaunchType = "FARGATE" | "EC2" | (string & {});
export interface EcsTask {
    CreatedAt?: Date;
    TaskDefinitionArn?: string;
    LaunchType?: EcsLaunchType;
    ContainerUids?: string[];
}
export interface IamInstanceProfileV2 {
    Ec2InstanceUids?: string[];
}
export interface AutoscalingAutoScalingGroup {
    Ec2InstanceUids?: string[];
}
export type LaunchTemplateVersion = string;
export interface Ec2LaunchTemplate {
    Ec2InstanceUids?: string[];
    Version?: string;
}
export interface Ec2Vpc {
    Ec2InstanceUids?: string[];
}
export interface Ec2Image {
    Ec2InstanceUids?: string[];
}
export interface CloudformationStack {
    Ec2InstanceUids?: string[];
}
export interface BedrockGuardrailResource {
    Version?: string;
    GuardrailAction?: GuardrailAction;
    GuardrailSource?: GuardrailSource;
}
export interface ResourceData {
    S3Bucket?: S3Bucket;
    Ec2Instance?: Ec2Instance;
    AccessKey?: AccessKey;
    Ec2NetworkInterface?: Ec2NetworkInterface;
    S3Object?: S3Object;
    EksCluster?: EksCluster;
    KubernetesWorkload?: KubernetesWorkload;
    Container?: ContainerFindingResource;
    EcsCluster?: EcsCluster;
    EcsTask?: EcsTask;
    IamInstanceProfile?: IamInstanceProfileV2;
    AutoscalingAutoScalingGroup?: AutoscalingAutoScalingGroup;
    Ec2LaunchTemplate?: Ec2LaunchTemplate;
    Ec2Vpc?: Ec2Vpc;
    Ec2Image?: Ec2Image;
    CloudformationStack?: CloudformationStack;
    BedrockGuardrail?: BedrockGuardrailResource;
}
export interface ResourceV2 {
    Uid?: string;
    Name?: string;
    AccountId?: string;
    ResourceType?: FindingResourceType;
    Region?: string;
    Service?: string;
    CloudPartition?: string;
    Tags?: Tag[];
    Data?: ResourceData;
}
export type Resources = ResourceV2[];
export interface NetworkGeoLocation {
    City?: string;
    Country?: string;
    Latitude?: number;
    Longitude?: number;
}
export interface AutonomousSystem {
    Name?: string;
    Number?: number;
}
export type NetworkDirection = "INBOUND" | "OUTBOUND" | (string & {});
export interface NetworkConnection {
    Direction?: NetworkDirection;
}
export interface NetworkEndpoint {
    Id?: string;
    Ip?: string;
    Domain?: string;
    Port?: number;
    Location?: NetworkGeoLocation;
    AutonomousSystem?: AutonomousSystem;
    Connection?: NetworkConnection;
}
export type NetworkEndpoints = NetworkEndpoint[];
export type SignalType = "FINDING" | "CLOUD_TRAIL" | "S3_DATA_EVENTS" | "EKS_AUDIT_LOGS" | "FLOW_LOGS" | "DNS_LOGS" | "RUNTIME_MONITORING" | (string & {});
export type SignalDescription = string;
export type ResourceUids = string[];
export type ActorIds = string[];
export type EndpointIds = string[];
export type IndicatorType = "SUSPICIOUS_USER_AGENT" | "SUSPICIOUS_NETWORK" | "MALICIOUS_IP" | "TOR_IP" | "ATTACK_TACTIC" | "HIGH_RISK_API" | "ATTACK_TECHNIQUE" | "UNUSUAL_API_FOR_ACCOUNT" | "UNUSUAL_ASN_FOR_ACCOUNT" | "UNUSUAL_ASN_FOR_USER" | "SUSPICIOUS_PROCESS" | "MALICIOUS_DOMAIN" | "MALICIOUS_PROCESS" | "CRYPTOMINING_IP" | "CRYPTOMINING_DOMAIN" | "CRYPTOMINING_PROCESS" | "MALICIOUS_FILE" | "VULNERABILITY" | "MALICIOUS_PACKAGE" | "MISCONFIGURATION" | "REACHABILITY" | "SENSITIVE_DATA" | (string & {});
export type IndicatorValueString = string;
export type IndicatorValues = string[];
export type IndicatorTitle = string;
export interface Indicator {
    Key?: IndicatorType;
    Values?: string[];
    Title?: string;
}
export type Indicators = Indicator[];
export type ActivityType = "API_CALL" | (string & {});
export interface ApiCall {
    Operation?: string;
    Service?: string;
    Error?: string;
    UserAgent?: string;
}
export interface Activity {
    Type?: ActivityType;
    Api?: ApiCall;
}
export type Activities = Activity[];
export interface Signal {
    Uid?: string;
    Type?: SignalType;
    Description?: string;
    Name?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    FirstSeenAt?: Date;
    LastSeenAt?: Date;
    Severity?: number;
    Count?: number;
    ResourceUids?: string[];
    ActorIds?: string[];
    EndpointIds?: string[];
    SignalIndicators?: Indicator[];
    Activities?: Activity[];
}
export type Signals = Signal[];
export type AdditionalSequenceTypes = string[];
export interface Sequence {
    Uid?: string;
    Description?: string;
    Actors?: Actor[];
    Resources?: ResourceV2[];
    Endpoints?: NetworkEndpoint[];
    Signals?: Signal[];
    SequenceIndicators?: Indicator[];
    AdditionalSequenceTypes?: string[];
}
export interface Detection {
    Anomaly?: Anomaly;
    Sequence?: Sequence;
}
export interface ItemPath {
    NestedItemPath?: string;
    Hash?: string;
}
export type ItemPaths = ItemPath[];
export interface AdditionalInfo {
    VersionId?: string;
    DeviceName?: string;
}
export interface ItemDetails {
    ResourceArn?: string;
    ItemPath?: string;
    Hash?: string;
    AdditionalInfo?: AdditionalInfo;
}
export type ItemDetailsList = ItemDetails[];
export interface Threat {
    Name?: string;
    Source?: string;
    ItemPaths?: ItemPath[];
    Count?: number;
    Hash?: string;
    ItemDetails?: ItemDetails[];
}
export type Threats = Threat[];
export type MalwareProtectionScanType = "BACKUP_INITIATED" | "ON_DEMAND" | "GUARDDUTY_INITIATED" | (string & {});
export type ScanCategory = "FULL_SCAN" | "INCREMENTAL_SCAN" | (string & {});
export interface IncrementalScanDetails {
    BaselineResourceArn?: string;
}
export interface MalwareProtectionFindingsScanConfiguration {
    TriggerType?: TriggerType;
    IncrementalScanDetails?: IncrementalScanDetails;
}
export interface MalwareScanDetails {
    Threats?: Threat[];
    ScanId?: string;
    ScanType?: MalwareProtectionScanType;
    ScanCategory?: ScanCategory;
    ScanConfiguration?: MalwareProtectionFindingsScanConfiguration;
    UniqueThreatCount?: number;
}
export interface Service {
    Action?: Action;
    Evidence?: Evidence;
    Archived?: boolean;
    Count?: number;
    DetectorId?: string;
    EventFirstSeen?: string;
    EventLastSeen?: string;
    ResourceRole?: string;
    ServiceName?: string;
    UserFeedback?: string;
    AdditionalInfo?: ServiceAdditionalInfo;
    FeatureName?: string;
    EbsVolumeScanDetails?: EbsVolumeScanDetails;
    RuntimeDetails?: RuntimeDetails;
    Detection?: Detection;
    MalwareScanDetails?: MalwareScanDetails;
}
export interface Finding {
    AccountId?: string;
    Arn?: string;
    Confidence?: number;
    CreatedAt?: string;
    Description?: string;
    Id?: string;
    Partition?: string;
    Region?: string;
    Resource?: Resource;
    SchemaVersion?: string;
    Service?: Service;
    Severity?: number;
    Title?: string;
    Type?: string;
    UpdatedAt?: string;
    AssociatedAttackSequenceArn?: string;
}
export type Findings = Finding[];
export interface GetFindingsResponse {
    Findings: (Finding & {
        AccountId: string;
        Arn: string;
        CreatedAt: string;
        Id: string;
        Region: string;
        Resource: Resource;
        SchemaVersion: string;
        Severity: number;
        Type: FindingType;
        UpdatedAt: string;
        Service: Service & {
            Detection: Detection & {
                Sequence: Sequence & {
                    Uid: string;
                    Description: SequenceDescription;
                    Signals: (Signal & {
                        Uid: string;
                        Type: SignalType;
                        Name: string;
                        CreatedAt: Date;
                        UpdatedAt: Date;
                        FirstSeenAt: Date;
                        LastSeenAt: Date;
                        Count: number;
                        SignalIndicators: (Indicator & {
                            Key: IndicatorType;
                        })[];
                        Activities: (Activity & {
                            Type: ActivityType;
                        })[];
                    })[];
                    Actors: (Actor & {
                        Id: string;
                        User: User & {
                            Name: string;
                            Uid: string;
                            Type: string;
                            Account: Account & {
                                Uid: string;
                            };
                        };
                        Process: ActorProcess & {
                            Name: ProcessName;
                            Path: ProcessPath;
                        };
                    })[];
                    Resources: (ResourceV2 & {
                        Uid: string;
                        ResourceType: FindingResourceType;
                        Data: ResourceData & {
                            Container: ContainerFindingResource & {
                                Image: string;
                            };
                        };
                    })[];
                    Endpoints: (NetworkEndpoint & {
                        Id: string;
                        Location: NetworkGeoLocation & {
                            City: string;
                            Country: string;
                            Latitude: number;
                            Longitude: number;
                        };
                        AutonomousSystem: AutonomousSystem & {
                            Name: string;
                            Number: number;
                        };
                        Connection: NetworkConnection & {
                            Direction: NetworkDirection;
                        };
                    })[];
                    SequenceIndicators: (Indicator & {
                        Key: IndicatorType;
                    })[];
                };
            };
            MalwareScanDetails: MalwareScanDetails & {
                ScanConfiguration: MalwareProtectionFindingsScanConfiguration & {
                    IncrementalScanDetails: IncrementalScanDetails & {
                        BaselineResourceArn: NonEmptyString;
                    };
                };
            };
        };
    })[];
}
export type FindingStatisticType = "COUNT_BY_SEVERITY" | (string & {});
export type FindingStatisticTypes = FindingStatisticType[];
export type GroupByType = "ACCOUNT" | "DATE" | "FINDING_TYPE" | "RESOURCE" | "SEVERITY" | (string & {});
export type MaxResults100 = number;
export interface GetFindingsStatisticsRequest {
    DetectorId: string;
    FindingStatisticTypes?: FindingStatisticType[];
    FindingCriteria?: FindingCriteria;
    GroupBy?: GroupByType;
    OrderBy?: OrderBy;
    MaxResults?: number;
}
export type CountBySeverity = {
    [key: string]: number | undefined;
};
export interface AccountStatistics {
    AccountId?: string;
    LastGeneratedAt?: Date;
    TotalFindings?: number;
}
export type GroupedByAccount = AccountStatistics[];
export interface DateStatistics {
    Date?: Date;
    LastGeneratedAt?: Date;
    Severity?: number;
    TotalFindings?: number;
}
export type GroupedByDate = DateStatistics[];
export interface FindingTypeStatistics {
    FindingType?: string;
    LastGeneratedAt?: Date;
    TotalFindings?: number;
}
export type GroupedByFindingType = FindingTypeStatistics[];
export interface ResourceStatistics {
    AccountId?: string;
    LastGeneratedAt?: Date;
    ResourceId?: string;
    ResourceType?: string;
    TotalFindings?: number;
}
export type GroupedByResource = ResourceStatistics[];
export interface SeverityStatistics {
    LastGeneratedAt?: Date;
    Severity?: number;
    TotalFindings?: number;
}
export type GroupedBySeverity = SeverityStatistics[];
export interface FindingStatistics {
    CountBySeverity?: {
        [key: string]: number | undefined;
    };
    GroupedByAccount?: AccountStatistics[];
    GroupedByDate?: DateStatistics[];
    GroupedByFindingType?: FindingTypeStatistics[];
    GroupedByResource?: ResourceStatistics[];
    GroupedBySeverity?: SeverityStatistics[];
}
export interface GetFindingsStatisticsResponse {
    FindingStatistics: FindingStatistics;
    NextToken?: string;
}
export interface GetInvestigationRequest {
    DetectorId: string;
    InvestigationId: string;
}
export type InvestigationStatus = "RUNNING" | "COMPLETED" | "FAILED" | (string & {});
export type TriggeredBy = string;
export interface Product {
    Name?: string;
    Feature?: string;
}
export interface InvestigationMetadata {
    Version?: string;
    Product?: Product;
}
export type CloudProvider = "AWS" | (string & {});
export interface CloudDetails {
    Provider?: CloudProvider;
    Region?: string;
    Account?: string;
}
export type RiskLevel = "Info" | "Low" | "Medium" | "High" | "Critical" | (string & {});
export type RiskDetails = string;
export type Confidence = "Unknown" | "Low" | "Medium" | "High" | (string & {});
export type InvestigationErrorDetails = string;
export interface Investigation {
    InvestigationId?: string;
    Status?: InvestigationStatus;
    TriggerPrompt?: string;
    TriggeredBy?: string;
    Metadata?: InvestigationMetadata;
    Cloud?: CloudDetails;
    RiskLevel?: RiskLevel;
    Risk?: string;
    Confidence?: Confidence;
    Summary?: string;
    StartTime?: Date;
    EndTime?: Date;
    Error?: string;
}
export interface GetInvestigationResponse {
    Investigation: Investigation & {
        InvestigationId: InvestigationId;
        Status: InvestigationStatus;
        TriggerPrompt: TriggerPrompt;
        TriggeredBy: TriggeredBy;
        Metadata: InvestigationMetadata & {
            Version: string;
            Product: Product & {
                Name: string;
            };
        };
        Cloud: CloudDetails & {
            Provider: CloudProvider;
            Region: string;
            Account: string;
        };
    };
}
export interface GetInvitationsCountRequest {
}
export interface GetInvitationsCountResponse {
    InvitationsCount?: number;
}
export interface GetIPSetRequest {
    DetectorId: string;
    IpSetId?: string;
}
export type IpSetStatus = "INACTIVE" | "ACTIVATING" | "ACTIVE" | "DEACTIVATING" | "ERROR" | "DELETE_PENDING" | "DELETED" | (string & {});
export interface GetIPSetResponse {
    Name: string;
    Format: IpSetFormat;
    Location: string;
    Status: IpSetStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
    ExpectedBucketOwner?: string;
}
export interface GetMalwareProtectionPlanRequest {
    MalwareProtectionPlanId?: string;
}
export type MalwareProtectionPlanStatus = "ACTIVE" | "WARNING" | "ERROR" | (string & {});
export interface MalwareProtectionPlanStatusReason {
    Code?: string;
    Message?: string;
}
export type MalwareProtectionPlanStatusReasonsList = MalwareProtectionPlanStatusReason[];
export interface GetMalwareProtectionPlanResponse {
    Arn?: string;
    Role?: string;
    ProtectedResource?: CreateProtectedResource;
    Actions?: MalwareProtectionPlanActions;
    CreatedAt?: Date;
    Status?: MalwareProtectionPlanStatus;
    StatusReasons?: MalwareProtectionPlanStatusReason[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetMalwareScanRequest {
    ScanId?: string;
}
export type MalwareProtectionResourceType = "EBS_RECOVERY_POINT" | "EBS_SNAPSHOT" | "EBS_VOLUME" | "EC2_AMI" | "EC2_INSTANCE" | "EC2_RECOVERY_POINT" | "S3_RECOVERY_POINT" | "S3_BUCKET" | "S3_POINT_IN_TIME_RECOVERY" | (string & {});
export type NonNegativeInteger = number;
export type MalwareProtectionScanStatus = "RUNNING" | "COMPLETED" | "COMPLETED_WITH_ISSUES" | "FAILED" | "SKIPPED" | (string & {});
export type ScanStatusReason = "ACCESS_DENIED" | "RESOURCE_NOT_FOUND" | "SNAPSHOT_SIZE_LIMIT_EXCEEDED" | "RESOURCE_UNAVAILABLE" | "INCONSISTENT_SOURCE" | "INCREMENTAL_NO_DIFFERENCE" | "NO_EBS_VOLUMES_FOUND" | "UNSUPPORTED_PRODUCT_CODE_TYPE" | "AMI_SNAPSHOT_LIMIT_EXCEEDED" | "UNRELATED_RESOURCES" | "BASE_RESOURCE_NOT_SCANNED" | "BASE_CREATED_AFTER_TARGET" | "UNSUPPORTED_FOR_INCREMENTAL" | "UNSUPPORTED_AMI" | "UNSUPPORTED_SNAPSHOT" | "UNSUPPORTED_COMPOSITE_RECOVERY_POINT" | "ALL_FILES_SKIPPED_OR_FAILED" | (string & {});
export interface EbsSnapshot {
    DeviceName?: string;
}
export interface ScannedResourceDetails {
    EbsVolume?: VolumeDetail;
    EbsSnapshot?: EbsSnapshot;
}
export interface ScannedResource {
    ScannedResourceArn?: string;
    ScannedResourceType?: MalwareProtectionResourceType;
    ScannedResourceStatus?: MalwareProtectionScanStatus;
    ScanStatusReason?: ScanStatusReason;
    ResourceDetails?: ScannedResourceDetails;
}
export type ScannedResources = ScannedResource[];
export interface ScanConfigurationRecoveryPoint {
    BackupVaultName?: string;
    ContinuousScanDetails?: ScanConfigurationContinuousScanDetails;
}
export interface ScanConfiguration {
    Role?: string;
    TriggerDetails?: TriggerDetails;
    IncrementalScanDetails?: IncrementalScanDetails;
    RecoveryPoint?: ScanConfigurationRecoveryPoint;
}
export type ScanResultStatus = "NO_THREATS_FOUND" | "THREATS_FOUND" | (string & {});
export type DetectionSource = "AMAZON" | "BITDEFENDER" | (string & {});
export interface ScanResultThreat {
    Name?: string;
    Source?: DetectionSource;
    Count?: number;
    Hash?: string;
    ItemDetails?: ItemDetails[];
}
export type ScanResultThreats = ScanResultThreat[];
export interface GetMalwareScanResultDetails {
    ScanResultStatus?: ScanResultStatus;
    SkippedFileCount?: number;
    FailedFileCount?: number;
    ThreatFoundFileCount?: number;
    TotalFileCount?: number;
    TotalBytes?: number;
    UniqueThreatCount?: number;
    Threats?: ScanResultThreat[];
}
export interface GetMalwareScanResponse {
    ScanId?: string;
    DetectorId?: string;
    AdminDetectorId?: string;
    ResourceArn?: string;
    ResourceType?: MalwareProtectionResourceType;
    ScannedResourcesCount?: number;
    SkippedResourcesCount?: number;
    FailedResourcesCount?: number;
    ScannedResources?: ScannedResource[];
    ScanConfiguration?: ScanConfiguration & {
        IncrementalScanDetails: IncrementalScanDetails & {
            BaselineResourceArn: NonEmptyString;
        };
    };
    ScanCategory?: ScanCategory;
    ScanStatus?: MalwareProtectionScanStatus;
    ScanStatusReason?: ScanStatusReason;
    ScanType?: MalwareProtectionScanType;
    ScanStartedAt?: Date;
    ScanCompletedAt?: Date;
    ScanResultDetails?: GetMalwareScanResultDetails;
}
export interface GetMalwareScanSettingsRequest {
    DetectorId: string;
}
export type ScanCriterionKey = "EC2_INSTANCE_TAG" | (string & {});
export interface ScanConditionPair {
    Key?: string;
    Value?: string;
}
export type MapEquals = ScanConditionPair[];
export interface ScanCondition {
    MapEquals?: ScanConditionPair[];
}
export type ScanCriterion = {
    [key in ScanCriterionKey]?: ScanCondition;
};
export interface ScanResourceCriteria {
    Include?: {
        [key: string]: ScanCondition | undefined;
    };
    Exclude?: {
        [key: string]: ScanCondition | undefined;
    };
}
export type EbsSnapshotPreservation = "NO_RETENTION" | "RETENTION_WITH_FINDING" | (string & {});
export interface GetMalwareScanSettingsResponse {
    ScanResourceCriteria?: ScanResourceCriteria & {
        Include: {
            [key: string]: (ScanCondition & {
                MapEquals: (ScanConditionPair & {
                    Key: TagKey;
                })[];
            }) | undefined;
        };
        Exclude: {
            [key: string]: (ScanCondition & {
                MapEquals: (ScanConditionPair & {
                    Key: TagKey;
                })[];
            }) | undefined;
        };
    };
    EbsSnapshotPreservation?: EbsSnapshotPreservation;
}
export interface GetMasterAccountRequest {
    DetectorId: string;
}
export interface Master {
    AccountId?: string;
    InvitationId?: string;
    RelationshipStatus?: string;
    InvitedAt?: string;
}
export interface GetMasterAccountResponse {
    Master: Master;
}
export interface GetMemberDetectorsRequest {
    DetectorId: string;
    AccountIds?: string[];
}
export interface MemberAdditionalConfigurationResult {
    Name?: OrgFeatureAdditionalConfiguration;
    Status?: FeatureStatus;
    UpdatedAt?: Date;
    ManagedBy?: ManagedBy;
}
export type MemberAdditionalConfigurationResults = MemberAdditionalConfigurationResult[];
export interface MemberFeaturesConfigurationResult {
    Name?: OrgFeature;
    Status?: FeatureStatus;
    UpdatedAt?: Date;
    AdditionalConfiguration?: MemberAdditionalConfigurationResult[];
    ManagedBy?: ManagedBy;
}
export type MemberFeaturesConfigurationsResults = MemberFeaturesConfigurationResult[];
export interface MemberDataSourceConfiguration {
    AccountId?: string;
    DataSources?: DataSourceConfigurationsResult;
    Features?: MemberFeaturesConfigurationResult[];
}
export type MemberDataSourceConfigurations = MemberDataSourceConfiguration[];
export interface GetMemberDetectorsResponse {
    MemberDataSourceConfigurations: (MemberDataSourceConfiguration & {
        AccountId: AccountId;
        DataSources: DataSourceConfigurationsResult & {
            CloudTrail: CloudTrailConfigurationResult & {
                Status: DataSourceStatus;
            };
            DNSLogs: DNSLogsConfigurationResult & {
                Status: DataSourceStatus;
            };
            FlowLogs: FlowLogsConfigurationResult & {
                Status: DataSourceStatus;
            };
            S3Logs: S3LogsConfigurationResult & {
                Status: DataSourceStatus;
            };
            Kubernetes: KubernetesConfigurationResult & {
                AuditLogs: KubernetesAuditLogsConfigurationResult & {
                    Status: DataSourceStatus;
                };
            };
        };
    })[];
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export interface GetMembersRequest {
    DetectorId: string;
    AccountIds?: string[];
}
export interface Member {
    AccountId?: string;
    DetectorId?: string;
    MasterId?: string;
    Email?: string | redacted.Redacted<string>;
    RelationshipStatus?: string;
    InvitedAt?: string;
    UpdatedAt?: string;
    AdministratorId?: string;
}
export type Members = Member[];
export interface GetMembersResponse {
    Members: (Member & {
        AccountId: AccountId;
        MasterId: string;
        Email: Email;
        RelationshipStatus: string;
        UpdatedAt: string;
    })[];
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export interface GetOrganizationStatisticsRequest {
}
export interface OrganizationFeatureStatisticsAdditionalConfiguration {
    Name?: OrgFeatureAdditionalConfiguration;
    EnabledAccountsCount?: number;
}
export type OrganizationFeatureStatisticsAdditionalConfigurations = OrganizationFeatureStatisticsAdditionalConfiguration[];
export interface OrganizationFeatureStatistics {
    Name?: OrgFeature;
    EnabledAccountsCount?: number;
    AdditionalConfiguration?: OrganizationFeatureStatisticsAdditionalConfiguration[];
}
export type OrganizationFeatureStatisticsResults = OrganizationFeatureStatistics[];
export interface OrganizationStatistics {
    TotalAccountsCount?: number;
    MemberAccountsCount?: number;
    ActiveAccountsCount?: number;
    EnabledAccountsCount?: number;
    CountByFeature?: OrganizationFeatureStatistics[];
}
export interface OrganizationDetails {
    UpdatedAt?: Date;
    OrganizationStatistics?: OrganizationStatistics;
}
export interface GetOrganizationStatisticsResponse {
    OrganizationDetails?: OrganizationDetails;
}
export interface GetRemainingFreeTrialDaysRequest {
    DetectorId: string;
    AccountIds: string[];
}
export interface DataSourceFreeTrial {
    FreeTrialDaysRemaining?: number;
}
export interface KubernetesDataSourceFreeTrial {
    AuditLogs?: DataSourceFreeTrial;
}
export interface MalwareProtectionDataSourceFreeTrial {
    ScanEc2InstanceWithFindings?: DataSourceFreeTrial;
}
export interface DataSourcesFreeTrial {
    CloudTrail?: DataSourceFreeTrial;
    DnsLogs?: DataSourceFreeTrial;
    FlowLogs?: DataSourceFreeTrial;
    S3Logs?: DataSourceFreeTrial;
    Kubernetes?: KubernetesDataSourceFreeTrial;
    MalwareProtection?: MalwareProtectionDataSourceFreeTrial;
}
export type FreeTrialFeatureResult = "FLOW_LOGS" | "CLOUD_TRAIL" | "DNS_LOGS" | "S3_DATA_EVENTS" | "EKS_AUDIT_LOGS" | "EBS_MALWARE_PROTECTION" | "RDS_LOGIN_EVENTS" | "LAMBDA_NETWORK_LOGS" | "EKS_RUNTIME_MONITORING" | "EC2_RUNTIME_MONITORING" | "FARGATE_RUNTIME_MONITORING" | "AI_PROTECTION" | (string & {});
export interface FreeTrialFeatureConfigurationResult {
    Name?: FreeTrialFeatureResult;
    FreeTrialDaysRemaining?: number;
}
export type FreeTrialFeatureConfigurationsResults = FreeTrialFeatureConfigurationResult[];
export interface AccountFreeTrialInfo {
    AccountId?: string;
    DataSources?: DataSourcesFreeTrial;
    Features?: FreeTrialFeatureConfigurationResult[];
}
export type AccountFreeTrialInfos = AccountFreeTrialInfo[];
export interface GetRemainingFreeTrialDaysResponse {
    Accounts?: AccountFreeTrialInfo[];
    UnprocessedAccounts?: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export interface GetThreatEntitySetRequest {
    DetectorId: string;
    ThreatEntitySetId?: string;
}
export type ThreatEntitySetStatus = "INACTIVE" | "ACTIVATING" | "ACTIVE" | "DEACTIVATING" | "ERROR" | "DELETE_PENDING" | "DELETED" | (string & {});
export interface GetThreatEntitySetResponse {
    Name: string;
    Format: ThreatEntitySetFormat;
    Location: string;
    ExpectedBucketOwner?: string;
    Status: ThreatEntitySetStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
    CreatedAt?: Date;
    UpdatedAt?: Date;
    ErrorDetails?: string;
}
export interface GetThreatIntelSetRequest {
    DetectorId: string;
    ThreatIntelSetId: string;
}
export type ThreatIntelSetStatus = "INACTIVE" | "ACTIVATING" | "ACTIVE" | "DEACTIVATING" | "ERROR" | "DELETE_PENDING" | "DELETED" | (string & {});
export interface GetThreatIntelSetResponse {
    Name: string;
    Format: ThreatIntelSetFormat;
    Location: string;
    Status: ThreatIntelSetStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
    ExpectedBucketOwner?: string;
}
export interface GetTrustedEntitySetRequest {
    DetectorId: string;
    TrustedEntitySetId: string;
}
export type TrustedEntitySetStatus = "INACTIVE" | "ACTIVATING" | "ACTIVE" | "DEACTIVATING" | "ERROR" | "DELETE_PENDING" | "DELETED" | (string & {});
export interface GetTrustedEntitySetResponse {
    Name: string;
    Format: TrustedEntitySetFormat;
    Location: string;
    ExpectedBucketOwner?: string;
    Status: TrustedEntitySetStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
    CreatedAt?: Date;
    UpdatedAt?: Date;
    ErrorDetails?: string;
}
export type UsageStatisticType = "SUM_BY_ACCOUNT" | "SUM_BY_DATA_SOURCE" | "SUM_BY_RESOURCE" | "TOP_RESOURCES" | "SUM_BY_FEATURES" | "TOP_ACCOUNTS_BY_FEATURE" | (string & {});
export type DataSource = "FLOW_LOGS" | "CLOUD_TRAIL" | "DNS_LOGS" | "S3_LOGS" | "KUBERNETES_AUDIT_LOGS" | "EC2_MALWARE_SCAN" | (string & {});
export type DataSourceList = DataSource[];
export type ResourceList = string[];
export type UsageFeature = "FLOW_LOGS" | "CLOUD_TRAIL" | "DNS_LOGS" | "S3_DATA_EVENTS" | "EKS_AUDIT_LOGS" | "EBS_MALWARE_PROTECTION" | "RDS_LOGIN_EVENTS" | "LAMBDA_NETWORK_LOGS" | "EKS_RUNTIME_MONITORING" | "EC2_RUNTIME_MONITORING" | "FARGATE_RUNTIME_MONITORING" | "RDS_DBI_PROTECTION_PROVISIONED" | "RDS_DBI_PROTECTION_SERVERLESS" | "AI_PROTECTION" | (string & {});
export type UsageFeatureList = UsageFeature[];
export interface UsageCriteria {
    AccountIds?: string[];
    DataSources?: DataSource[];
    Resources?: string[];
    Features?: UsageFeature[];
}
export interface GetUsageStatisticsRequest {
    DetectorId: string;
    UsageStatisticType?: UsageStatisticType;
    UsageCriteria?: UsageCriteria;
    Unit?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface Total {
    Amount?: string;
    Unit?: string;
}
export interface UsageAccountResult {
    AccountId?: string;
    Total?: Total;
}
export type UsageAccountResultList = UsageAccountResult[];
export interface UsageTopAccountResult {
    AccountId?: string;
    Total?: Total;
}
export type UsageTopAccountsByFeatureList = UsageTopAccountResult[];
export interface UsageTopAccountsResult {
    Feature?: UsageFeature;
    Accounts?: UsageTopAccountResult[];
}
export type UsageTopAccountsResultList = UsageTopAccountsResult[];
export interface UsageDataSourceResult {
    DataSource?: DataSource;
    Total?: Total;
}
export type UsageDataSourceResultList = UsageDataSourceResult[];
export interface UsageResourceResult {
    Resource?: string;
    Total?: Total;
}
export type UsageResourceResultList = UsageResourceResult[];
export interface UsageFeatureResult {
    Feature?: UsageFeature;
    Total?: Total;
}
export type UsageFeatureResultList = UsageFeatureResult[];
export interface UsageStatistics {
    SumByAccount?: UsageAccountResult[];
    TopAccountsByFeature?: UsageTopAccountsResult[];
    SumByDataSource?: UsageDataSourceResult[];
    SumByResource?: UsageResourceResult[];
    TopResources?: UsageResourceResult[];
    SumByFeature?: UsageFeatureResult[];
}
export interface GetUsageStatisticsResponse {
    UsageStatistics?: UsageStatistics;
    NextToken?: string;
}
export interface InviteMembersRequest {
    DetectorId: string;
    AccountIds?: string[];
    DisableEmailNotification?: boolean;
    Message?: string;
}
export interface InviteMembersResponse {
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export type CoverageSortKey = "ACCOUNT_ID" | "COVERAGE_STATUS" | "ISSUE" | "ADDON_VERSION" | "UPDATED_AT" | "CLUSTER_NAME" | "EKS_CLUSTER_NAME" | "ECS_CLUSTER_NAME" | "INSTANCE_ID" | (string & {});
export interface CoverageSortCriteria {
    AttributeName?: CoverageSortKey;
    OrderBy?: OrderBy;
}
export interface ListCoverageRequest {
    DetectorId: string;
    NextToken?: string;
    MaxResults?: number;
    FilterCriteria?: CoverageFilterCriteria;
    SortCriteria?: CoverageSortCriteria;
}
export interface AddonDetails {
    AddonVersion?: string;
    AddonStatus?: string;
}
export type ManagementType = "AUTO_MANAGED" | "MANUAL" | "DISABLED" | (string & {});
export interface CoverageEksClusterDetails {
    ClusterName?: string;
    CoveredNodes?: number;
    CompatibleNodes?: number;
    AddonDetails?: AddonDetails;
    ManagementType?: ManagementType;
}
export type Issues = string[];
export interface FargateDetails {
    Issues?: string[];
    ManagementType?: ManagementType;
}
export interface ContainerInstanceDetails {
    CoveredContainerInstances?: number;
    CompatibleContainerInstances?: number;
}
export interface CoverageEcsClusterDetails {
    ClusterName?: string;
    FargateDetails?: FargateDetails;
    ContainerInstanceDetails?: ContainerInstanceDetails;
}
export interface AgentDetails {
    Version?: string;
}
export interface CoverageEc2InstanceDetails {
    InstanceId?: string;
    InstanceType?: string;
    ClusterArn?: string;
    AgentDetails?: AgentDetails;
    ManagementType?: ManagementType;
}
export interface CoverageResourceDetails {
    EksClusterDetails?: CoverageEksClusterDetails;
    EcsClusterDetails?: CoverageEcsClusterDetails;
    Ec2InstanceDetails?: CoverageEc2InstanceDetails;
    ResourceType?: ResourceType;
}
export interface CoverageResource {
    ResourceId?: string;
    DetectorId?: string;
    AccountId?: string;
    ResourceDetails?: CoverageResourceDetails;
    CoverageStatus?: CoverageStatus;
    Issue?: string;
    UpdatedAt?: Date;
}
export type CoverageResources = CoverageResource[];
export interface ListCoverageResponse {
    Resources: CoverageResource[];
    NextToken?: string;
}
export type DetectionRuleMaxResults = number;
export interface ListCustomDetectionRuleAssociationsRequest {
    MaxResults?: number;
    NextToken?: string;
    RuleId?: string;
    Mode?: AssociationMode;
}
export interface AssociationSummary {
    AssociationId?: string;
    Arn?: string;
    RuleId?: string;
    Mode?: AssociationMode;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    ExpiresAt?: Date;
}
export type AssociationSummaryList = AssociationSummary[];
export interface ListCustomDetectionRuleAssociationsResponse {
    RuleAssociations: (AssociationSummary & {
        AssociationId: AssociationId;
        Arn: DetectionRuleArn;
        RuleId: RuleId;
        Mode: AssociationMode;
        CreatedAt: Date;
        UpdatedAt: Date;
    })[];
    NextToken?: string;
}
export interface ListCustomDetectionRuleOrgConfigurationsRequest {
    MaxResults?: number;
    NextToken?: string;
    Status?: DetectionRuleConfigurationStatus;
}
export interface DetectionRuleOrgConfigurationSummary {
    RuleId?: string;
    Mode?: AssociationMode;
    Status?: DetectionRuleConfigurationStatus;
    StatusReason?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    ExpiresAt?: Date;
}
export type DetectionRuleOrgConfigurationSummaryList = DetectionRuleOrgConfigurationSummary[];
export interface ListCustomDetectionRuleOrgConfigurationsResponse {
    Configurations: (DetectionRuleOrgConfigurationSummary & {
        RuleId: RuleId;
        Mode: AssociationMode;
        Status: DetectionRuleConfigurationStatus;
        CreatedAt: Date;
        UpdatedAt: Date;
    })[];
    NextToken?: string;
}
export type FilterFieldName = "name" | "description" | "dataSource" | "severity" | "tactic" | "technique" | "service" | (string & {});
export type DetectionRuleFilterValue = string;
export type DetectionRuleFilterValues = string[];
export type DetectionRuleFilterCondition = "EQUALS" | "CONTAINS" | (string & {});
export interface DetectionRuleFilter {
    Name?: FilterFieldName;
    Values?: string[];
    Condition?: DetectionRuleFilterCondition;
}
export type DetectionRuleFilterList = DetectionRuleFilter[];
export interface ListCustomDetectionRulesRequest {
    MaxResults?: number;
    NextToken?: string;
    Filters?: DetectionRuleFilter[];
}
export interface RuleSummary {
    RuleId?: string;
    Arn?: string;
    Name?: string;
    Description?: string;
    Severity?: DetectionRuleSeverity;
    DataSource?: DetectionRuleDataSource;
    Tactic?: string;
    Technique?: string;
    Service?: string;
    Language?: RuleLanguage;
    Schema?: RuleSchema;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export type RuleSummaryList = RuleSummary[];
export interface ListCustomDetectionRulesResponse {
    Rules: (RuleSummary & {
        RuleId: RuleId;
        Arn: DetectionRuleArn;
        Name: RuleName;
        Description: DetectionRuleDescription;
        Severity: DetectionRuleSeverity;
        DataSource: DetectionRuleDataSource;
        Tactic: MitreTactic;
        Technique: MitreTechnique;
        Service: DetectionRuleServiceName;
        CreatedAt: Date;
    })[];
    NextToken?: string;
}
export interface ListDetectorsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export type DetectorIds = string[];
export interface ListDetectorsResponse {
    DetectorIds: string[];
    NextToken?: string;
}
export interface ListFiltersRequest {
    DetectorId: string;
    MaxResults?: number;
    NextToken?: string;
}
export type FilterNames = string[];
export interface ListFiltersResponse {
    FilterNames: string[];
    NextToken?: string;
}
export interface ListFindingsRequest {
    DetectorId: string;
    FindingCriteria?: FindingCriteria;
    SortCriteria?: SortCriteria;
    MaxResults?: number;
    NextToken?: string;
}
export interface ListFindingsResponse {
    FindingIds: string[];
    NextToken?: string;
}
export type InvestigationSortField = "START_TIME" | "END_TIME" | "STATUS" | "RISK_LEVEL" | "CONFIDENCE" | (string & {});
export interface InvestigationSortCriteria {
    AttributeName?: InvestigationSortField;
    OrderBy?: OrderBy;
}
export type NextToken = string;
export interface ListInvestigationsRequest {
    DetectorId: string;
    SortCriteria?: InvestigationSortCriteria;
    MaxResults?: number;
    NextToken?: string;
}
export type InvestigationTitle = string;
export interface InvestigationSummary {
    InvestigationId?: string;
    Status?: InvestigationStatus;
    TriggerPrompt?: string;
    RiskLevel?: RiskLevel;
    Confidence?: Confidence;
    Title?: string;
    AccountId?: string;
    StartTime?: Date;
    EndTime?: Date;
}
export type InvestigationSummaries = InvestigationSummary[];
export interface ListInvestigationsResponse {
    Investigations: InvestigationSummary[];
    NextToken?: string;
}
export interface ListInvitationsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface Invitation {
    AccountId?: string;
    InvitationId?: string;
    RelationshipStatus?: string;
    InvitedAt?: string;
}
export type Invitations = Invitation[];
export interface ListInvitationsResponse {
    Invitations?: Invitation[];
    NextToken?: string;
}
export interface ListIPSetsRequest {
    DetectorId: string;
    MaxResults?: number;
    NextToken?: string;
}
export type IpSetIds = string[];
export interface ListIPSetsResponse {
    IpSetIds: string[];
    NextToken?: string;
}
export interface ListMalwareProtectionPlansRequest {
    NextToken?: string;
}
export interface MalwareProtectionPlanSummary {
    MalwareProtectionPlanId?: string;
}
export type MalwareProtectionPlansSummary = MalwareProtectionPlanSummary[];
export interface ListMalwareProtectionPlansResponse {
    MalwareProtectionPlans?: MalwareProtectionPlanSummary[];
    NextToken?: string;
}
export type ListMalwareScansCriterionKey = "RESOURCE_ARN" | "SCAN_ID" | "ACCOUNT_ID" | "GUARDDUTY_FINDING_ID" | "RESOURCE_TYPE" | "SCAN_START_TIME" | "SCAN_STATUS" | "SCAN_TYPE" | (string & {});
export interface ListMalwareScansFilterCriterion {
    ListMalwareScansCriterionKey?: ListMalwareScansCriterionKey;
    FilterCondition?: FilterCondition;
}
export type ListMalwareScansFilterCriterionList = ListMalwareScansFilterCriterion[];
export interface ListMalwareScansFilterCriteria {
    ListMalwareScansFilterCriterion?: ListMalwareScansFilterCriterion[];
}
export interface ListMalwareScansRequest {
    MaxResults?: number;
    NextToken?: string;
    FilterCriteria?: ListMalwareScansFilterCriteria;
    SortCriteria?: SortCriteria;
}
export interface MalwareScan {
    ResourceArn?: string;
    ResourceType?: MalwareProtectionResourceType;
    ScanId?: string;
    ScanStatus?: MalwareProtectionScanStatus;
    ScanResultStatus?: ScanResultStatus;
    ScanType?: MalwareProtectionScanType;
    ScanStartedAt?: Date;
    ScanCompletedAt?: Date;
}
export type MalwareScans = MalwareScan[];
export interface ListMalwareScansResponse {
    Scans: MalwareScan[];
    NextToken?: string;
}
export interface ListMembersRequest {
    DetectorId: string;
    MaxResults?: number;
    NextToken?: string;
    OnlyAssociated?: string;
}
export interface ListMembersResponse {
    Members?: (Member & {
        AccountId: AccountId;
        MasterId: string;
        Email: Email;
        RelationshipStatus: string;
        UpdatedAt: string;
    })[];
    NextToken?: string;
}
export interface ListOrganizationAdminAccountsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export type AdminStatus = "ENABLED" | "DISABLE_IN_PROGRESS" | (string & {});
export interface AdminAccount {
    AdminAccountId?: string;
    AdminStatus?: AdminStatus;
}
export type AdminAccounts = AdminAccount[];
export interface ListOrganizationAdminAccountsResponse {
    AdminAccounts?: AdminAccount[];
    NextToken?: string;
}
export interface ListPublishingDestinationsRequest {
    DetectorId: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface Destination {
    DestinationId?: string;
    DestinationType?: DestinationType;
    Status?: PublishingStatus;
}
export type Destinations = Destination[];
export interface ListPublishingDestinationsResponse {
    Destinations: (Destination & {
        DestinationId: string;
        DestinationType: DestinationType;
        Status: PublishingStatus;
    })[];
    NextToken?: string;
}
export type GuardDutyArn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListThreatEntitySetsRequest {
    DetectorId: string;
    MaxResults?: number;
    NextToken?: string;
}
export type ThreatEntitySetIds = string[];
export interface ListThreatEntitySetsResponse {
    ThreatEntitySetIds: string[];
    NextToken?: string;
}
export interface ListThreatIntelSetsRequest {
    DetectorId: string;
    MaxResults?: number;
    NextToken?: string;
}
export type ThreatIntelSetIds = string[];
export interface ListThreatIntelSetsResponse {
    ThreatIntelSetIds: string[];
    NextToken?: string;
}
export interface ListTrustedEntitySetsRequest {
    DetectorId: string;
    MaxResults?: number;
    NextToken?: string;
}
export type TrustedEntitySetIds = string[];
export interface ListTrustedEntitySetsResponse {
    TrustedEntitySetIds: string[];
    NextToken?: string;
}
export interface S3ObjectForSendObjectMalwareScan {
    Bucket?: string;
    Key?: string;
    VersionId?: string;
}
export interface SendObjectMalwareScanRequest {
    S3Object?: S3ObjectForSendObjectMalwareScan;
}
export interface SendObjectMalwareScanResponse {
}
export type ResourceArn = string;
export interface ContinuousScanDetails {
    StartTime?: Date;
    EndTime: Date;
}
export interface RecoveryPoint {
    BackupVaultName?: string;
    ContinuousScanDetails?: ContinuousScanDetails;
}
export interface StartMalwareScanConfiguration {
    Role?: string;
    IncrementalScanDetails?: IncrementalScanDetails;
    RecoveryPoint?: RecoveryPoint;
}
export interface StartMalwareScanRequest {
    ResourceArn?: string;
    ClientToken?: string;
    ScanConfiguration?: StartMalwareScanConfiguration;
}
export interface StartMalwareScanResponse {
    ScanId?: string;
}
export interface StartMonitoringMembersRequest {
    DetectorId: string;
    AccountIds?: string[];
}
export interface StartMonitoringMembersResponse {
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export interface StopMonitoringMembersRequest {
    DetectorId: string;
    AccountIds?: string[];
}
export interface StopMonitoringMembersResponse {
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export interface TagResourceRequest {
    ResourceArn?: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export interface UnarchiveFindingsRequest {
    DetectorId: string;
    FindingIds?: string[];
}
export interface UnarchiveFindingsResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateCustomDetectionRuleAssociationRequest {
    RuleId: string;
    AssociationId: string;
    Mode?: AssociationMode;
}
export interface UpdateCustomDetectionRuleAssociationResponse {
}
export interface UpdateCustomDetectionRuleOrgConfigurationRequest {
    RuleId: string;
    Mode?: AssociationMode;
    IncludeAccountIds?: string[];
    ExcludeAccountIds?: string[];
}
export interface UpdateCustomDetectionRuleOrgConfigurationResponse {
}
export interface UpdateDetectorRequest {
    DetectorId: string;
    Enable?: boolean;
    FindingPublishingFrequency?: FindingPublishingFrequency;
    DataSources?: DataSourceConfigurations;
    Features?: DetectorFeatureConfiguration[];
}
export interface UpdateDetectorResponse {
}
export interface UpdateFilterRequest {
    DetectorId: string;
    FilterName: string;
    Description?: string;
    Action?: FilterAction;
    Rank?: number;
    FindingCriteria?: FindingCriteria;
}
export interface UpdateFilterResponse {
    Name: string;
}
export type Feedback = "USEFUL" | "NOT_USEFUL" | (string & {});
export interface UpdateFindingsFeedbackRequest {
    DetectorId: string;
    FindingIds?: string[];
    Feedback?: Feedback;
    Comments?: string | redacted.Redacted<string>;
}
export interface UpdateFindingsFeedbackResponse {
}
export interface UpdateIPSetRequest {
    DetectorId: string;
    IpSetId?: string;
    Name?: string;
    Location?: string;
    Activate?: boolean;
    ExpectedBucketOwner?: string;
}
export interface UpdateIPSetResponse {
}
export interface UpdateS3BucketResource {
    ObjectPrefixes?: string[];
}
export interface UpdateProtectedResource {
    S3Bucket?: UpdateS3BucketResource;
}
export interface UpdateMalwareProtectionPlanRequest {
    MalwareProtectionPlanId: string;
    Role?: string;
    Actions?: MalwareProtectionPlanActions;
    ProtectedResource?: UpdateProtectedResource;
}
export interface UpdateMalwareProtectionPlanResponse {
}
export interface UpdateMalwareScanSettingsRequest {
    DetectorId: string;
    ScanResourceCriteria?: ScanResourceCriteria;
    EbsSnapshotPreservation?: EbsSnapshotPreservation;
}
export interface UpdateMalwareScanSettingsResponse {
}
export interface MemberAdditionalConfiguration {
    Name?: OrgFeatureAdditionalConfiguration;
    Status?: FeatureStatus;
}
export type MemberAdditionalConfigurations = MemberAdditionalConfiguration[];
export interface MemberFeaturesConfiguration {
    Name?: OrgFeature;
    Status?: FeatureStatus;
    AdditionalConfiguration?: MemberAdditionalConfiguration[];
}
export type MemberFeaturesConfigurations = MemberFeaturesConfiguration[];
export interface UpdateMemberDetectorsRequest {
    DetectorId: string;
    AccountIds?: string[];
    DataSources?: DataSourceConfigurations;
    Features?: MemberFeaturesConfiguration[];
}
export interface UpdateMemberDetectorsResponse {
    UnprocessedAccounts: (UnprocessedAccount & {
        AccountId: AccountId;
        Result: string;
    })[];
}
export interface OrganizationS3LogsConfiguration {
    AutoEnable?: boolean;
}
export interface OrganizationKubernetesAuditLogsConfiguration {
    AutoEnable?: boolean;
}
export interface OrganizationKubernetesConfiguration {
    AuditLogs?: OrganizationKubernetesAuditLogsConfiguration;
}
export interface OrganizationEbsVolumes {
    AutoEnable?: boolean;
}
export interface OrganizationScanEc2InstanceWithFindings {
    EbsVolumes?: OrganizationEbsVolumes;
}
export interface OrganizationMalwareProtectionConfiguration {
    ScanEc2InstanceWithFindings?: OrganizationScanEc2InstanceWithFindings;
}
export interface OrganizationDataSourceConfigurations {
    S3Logs?: OrganizationS3LogsConfiguration;
    Kubernetes?: OrganizationKubernetesConfiguration;
    MalwareProtection?: OrganizationMalwareProtectionConfiguration;
}
export interface OrganizationAdditionalConfiguration {
    Name?: OrgFeatureAdditionalConfiguration;
    AutoEnable?: OrgFeatureStatus;
}
export type OrganizationAdditionalConfigurations = OrganizationAdditionalConfiguration[];
export interface OrganizationFeatureConfiguration {
    Name?: OrgFeature;
    AutoEnable?: OrgFeatureStatus;
    AdditionalConfiguration?: OrganizationAdditionalConfiguration[];
}
export type OrganizationFeaturesConfigurations = OrganizationFeatureConfiguration[];
export interface UpdateOrganizationConfigurationRequest {
    DetectorId: string;
    AutoEnable?: boolean;
    DataSources?: OrganizationDataSourceConfigurations;
    Features?: OrganizationFeatureConfiguration[];
    AutoEnableOrganizationMembers?: AutoEnableMembers;
}
export interface UpdateOrganizationConfigurationResponse {
}
export interface UpdatePublishingDestinationRequest {
    DetectorId: string;
    DestinationId: string;
    DestinationProperties?: DestinationProperties;
}
export interface UpdatePublishingDestinationResponse {
}
export interface UpdateThreatEntitySetRequest {
    DetectorId: string;
    ThreatEntitySetId?: string;
    Name?: string;
    Location?: string;
    ExpectedBucketOwner?: string;
    Activate?: boolean;
}
export interface UpdateThreatEntitySetResponse {
}
export interface UpdateThreatIntelSetRequest {
    DetectorId: string;
    ThreatIntelSetId: string;
    Name?: string;
    Location?: string;
    Activate?: boolean;
    ExpectedBucketOwner?: string;
}
export interface UpdateThreatIntelSetResponse {
}
export interface UpdateTrustedEntitySetRequest {
    DetectorId: string;
    TrustedEntitySetId: string;
    Name?: string;
    Location?: string;
    ExpectedBucketOwner?: string;
    Activate?: boolean;
}
export interface UpdateTrustedEntitySetResponse {
}
export type AcceptAdministratorInvitationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Accepts the invitation to be a member account and get monitored by a GuardDuty administrator account that sent the invitation.
 */
export declare const acceptAdministratorInvitation: API.OperationMethod<AcceptAdministratorInvitationRequest, AcceptAdministratorInvitationResponse, AcceptAdministratorInvitationError, Credentials | HttpClient.HttpClient>;
export type AcceptInvitationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Accepts the invitation to be monitored by a GuardDuty administrator account.
 */
export declare const acceptInvitation: API.OperationMethod<AcceptInvitationRequest, AcceptInvitationResponse, AcceptInvitationError, Credentials | HttpClient.HttpClient>;
export type ArchiveFindingsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Archives GuardDuty findings that are specified by the list of finding IDs.
 *
 * Only the administrator account can archive findings. Member accounts don't have permission to archive findings from their accounts.
 */
export declare const archiveFindings: API.OperationMethod<ArchiveFindingsRequest, ArchiveFindingsResponse, ArchiveFindingsError, Credentials | HttpClient.HttpClient>;
export type CreateCustomDetectionRuleAssociationError = AccessDeniedException | BadRequestException | ConflictException | InternalServerErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Enables a custom detection rule for your account by creating an association. You specify the rule and the mode in which it operates.
 */
export declare const createCustomDetectionRuleAssociation: API.OperationMethod<CreateCustomDetectionRuleAssociationRequest, CreateCustomDetectionRuleAssociationResponse, CreateCustomDetectionRuleAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateCustomDetectionRuleOrgConfigurationError = AccessDeniedException | BadRequestException | ConflictException | InternalServerErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Creates an organization-level configuration that enables a custom detection rule across your organization. This operation is available only to the delegated administrator account.
 */
export declare const createCustomDetectionRuleOrgConfiguration: API.OperationMethod<CreateCustomDetectionRuleOrgConfigurationRequest, CreateCustomDetectionRuleOrgConfigurationResponse, CreateCustomDetectionRuleOrgConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateDetectorError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Creates a single GuardDuty detector. A detector is a resource that represents the GuardDuty service. To start using GuardDuty, you must create a detector in each Region where you enable the service. You can have only one detector per account per Region. All data sources are enabled in a new detector by default.
 *
 * - When you don't specify any `features`, with an exception to `RUNTIME_MONITORING`, all the optional features are enabled by default.
 *
 * - When you specify some of the `features`, any feature that is not specified in the API call gets enabled by default, with an exception to `RUNTIME_MONITORING`.
 *
 * Specifying both EKS Runtime Monitoring (`EKS_RUNTIME_MONITORING`) and Runtime Monitoring (`RUNTIME_MONITORING`) will cause an error. You can add only one of these two features because Runtime Monitoring already includes the threat detection for Amazon EKS resources. For more information, see Runtime Monitoring.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const createDetector: API.OperationMethod<CreateDetectorRequest, CreateDetectorResponse, CreateDetectorError, Credentials | HttpClient.HttpClient>;
export type CreateFilterError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Creates a filter using the specified finding criteria. The maximum number of saved filters per Amazon Web Services account per Region is 100. For more information, see Quotas for GuardDuty.
 */
export declare const createFilter: API.OperationMethod<CreateFilterRequest, CreateFilterResponse, CreateFilterError, Credentials | HttpClient.HttpClient>;
export type CreateInvestigationError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * This API is currently available as a preview. During the preview, you can initiate up to 10 investigations per account per day, with a total limit of 100 investigations per account. This feature is available in the following Amazon Web Services Regions: US East (N. Virginia), US East (Ohio), US West (Oregon), Canada (Central), Europe (Frankfurt), Europe (Ireland), Europe (London), Europe (Paris), Europe (Stockholm), and Asia Pacific (Tokyo).
 *
 * Initiates a GuardDuty investigation that automatically analyzes security findings, correlates related activity, performs account-level analysis, and produces a structured investigation summary with recommended next steps.
 *
 * Only the administrator account can create an investigation. Member accounts don't have permission to create investigations from their accounts.
 *
 * To use this operation, the `AI_ANALYST` feature must be enabled on your detector.
 *
 * This feature uses Amazon Bedrock models that leverage Cross-Region Inference (CRIS), which automatically selects the optimal Amazon Web Services Region within your geography to process the investigation analysis and generate the investigation report. This maximizes available compute resources, model availability, and delivers the best customer experience. Your data remains stored only in the Region where the investigation request originates, however, investigation data and summary results may be processed outside that Region. All data is transmitted encrypted across Amazon's secure network. For more information, see GuardDuty Investigation.
 */
export declare const createInvestigation: API.OperationMethod<CreateInvestigationRequest, CreateInvestigationResponse, CreateInvestigationError, Credentials | HttpClient.HttpClient>;
export type CreateIPSetError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Creates a new IPSet, which is called a trusted IP list in the console user interface. An IPSet is a list of IP addresses that are trusted for secure communication with Amazon Web Services infrastructure and applications. GuardDuty doesn't generate findings for IP addresses that are included in IPSets. Only users from the administrator account can use this operation.
 */
export declare const createIPSet: API.OperationMethod<CreateIPSetRequest, CreateIPSetResponse, CreateIPSetError, Credentials | HttpClient.HttpClient>;
export type CreateMalwareProtectionPlanError = AccessDeniedException | BadRequestException | ConflictException | InternalServerErrorException | CommonErrors;
/**
 * Creates a new Malware Protection plan for the protected resource.
 *
 * When you create a Malware Protection plan, the Amazon Web Services service terms for GuardDuty Malware Protection apply. For more information, see Amazon Web Services service terms for GuardDuty Malware Protection.
 */
export declare const createMalwareProtectionPlan: API.OperationMethod<CreateMalwareProtectionPlanRequest, CreateMalwareProtectionPlanResponse, CreateMalwareProtectionPlanError, Credentials | HttpClient.HttpClient>;
export type CreateMembersError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Creates member accounts of the current Amazon Web Services account by specifying a list of Amazon Web Services account IDs. This step is a prerequisite for managing the associated member accounts either by invitation or through an organization.
 *
 * As a delegated administrator, using `CreateMembers` will enable GuardDuty in the added member accounts, with the exception of the organization delegated administrator account. A delegated administrator must enable GuardDuty prior to being added as a member.
 *
 * When you use CreateMembers as an Organizations delegated administrator, GuardDuty applies your organization's auto-enable settings to the member accounts in this request, irrespective of the accounts being new or existing members. For more information about the existing auto-enable settings for your organization, see DescribeOrganizationConfiguration.
 *
 * If you disassociate a member account that was added by invitation, the member account details obtained from this API, including the associated email addresses, will be retained. This is done so that the delegated administrator can invoke the InviteMembers API without the need to invoke the CreateMembers API again. To remove the details associated with a member account, the delegated administrator must invoke the DeleteMembers API.
 *
 * When the member accounts added through Organizations are later disassociated, you (administrator) can't invite them by calling the InviteMembers API. You can create an association with these member accounts again only by calling the CreateMembers API.
 */
export declare const createMembers: API.OperationMethod<CreateMembersRequest, CreateMembersResponse, CreateMembersError, Credentials | HttpClient.HttpClient>;
export type CreatePublishingDestinationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Creates a publishing destination where you can export your GuardDuty findings. Before you start exporting the findings, the destination resource must exist.
 */
export declare const createPublishingDestination: API.OperationMethod<CreatePublishingDestinationRequest, CreatePublishingDestinationResponse, CreatePublishingDestinationError, Credentials | HttpClient.HttpClient>;
export type CreateSampleFindingsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Generates sample findings of types specified by the list of finding types. If 'NULL' is specified for `findingTypes`, the API generates sample findings of all supported finding types.
 */
export declare const createSampleFindings: API.OperationMethod<CreateSampleFindingsRequest, CreateSampleFindingsResponse, CreateSampleFindingsError, Credentials | HttpClient.HttpClient>;
export type CreateThreatEntitySetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Creates a new threat entity set. In a threat entity set, you can provide known malicious threat entities for your Amazon Web Services environment. GuardDuty generates findings based on the entries in the threat entity sets. Only users of the administrator account can manage entity sets, which automatically apply to member accounts.
 */
export declare const createThreatEntitySet: API.OperationMethod<CreateThreatEntitySetRequest, CreateThreatEntitySetResponse, CreateThreatEntitySetError, Credentials | HttpClient.HttpClient>;
export type CreateThreatIntelSetError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Creates a new ThreatIntelSet. ThreatIntelSets consist of known malicious IP addresses. GuardDuty generates findings based on ThreatIntelSets. Only users of the administrator account can use this operation.
 */
export declare const createThreatIntelSet: API.OperationMethod<CreateThreatIntelSetRequest, CreateThreatIntelSetResponse, CreateThreatIntelSetError, Credentials | HttpClient.HttpClient>;
export type CreateTrustedEntitySetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Creates a new trusted entity set. In the trusted entity set, you can provide IP addresses and domains that you believe are secure for communication in your Amazon Web Services environment. GuardDuty will not generate findings for the entries that are specified in a trusted entity set. At any given time, you can have only one trusted entity set.
 *
 * Only users of the administrator account can manage the entity sets, which automatically apply to member accounts.
 */
export declare const createTrustedEntitySet: API.OperationMethod<CreateTrustedEntitySetRequest, CreateTrustedEntitySetResponse, CreateTrustedEntitySetError, Credentials | HttpClient.HttpClient>;
export type DeclineInvitationsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Declines invitations sent to the current member account by Amazon Web Services accounts specified by their account IDs.
 */
export declare const declineInvitations: API.OperationMethod<DeclineInvitationsRequest, DeclineInvitationsResponse, DeclineInvitationsError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomDetectionRuleAssociationError = AccessDeniedException | BadRequestException | InternalServerErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Disables a custom detection rule by deleting its association. This operation is idempotent.
 */
export declare const deleteCustomDetectionRuleAssociation: API.OperationMethod<DeleteCustomDetectionRuleAssociationRequest, DeleteCustomDetectionRuleAssociationResponse, DeleteCustomDetectionRuleAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomDetectionRuleOrgConfigurationError = AccessDeniedException | BadRequestException | ConflictException | InternalServerErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the organization-level configuration for a custom detection rule. This operation is available only to the delegated administrator account.
 */
export declare const deleteCustomDetectionRuleOrgConfiguration: API.OperationMethod<DeleteCustomDetectionRuleOrgConfigurationRequest, DeleteCustomDetectionRuleOrgConfigurationResponse, DeleteCustomDetectionRuleOrgConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteDetectorError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Deletes an Amazon GuardDuty detector that is specified by the detector ID.
 */
export declare const deleteDetector: API.OperationMethod<DeleteDetectorRequest, DeleteDetectorResponse, DeleteDetectorError, Credentials | HttpClient.HttpClient>;
export type DeleteFilterError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Deletes the filter specified by the filter name.
 */
export declare const deleteFilter: API.OperationMethod<DeleteFilterRequest, DeleteFilterResponse, DeleteFilterError, Credentials | HttpClient.HttpClient>;
export type DeleteInvitationsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Deletes invitations sent to the current member account by Amazon Web Services accounts specified by their account IDs.
 */
export declare const deleteInvitations: API.OperationMethod<DeleteInvitationsRequest, DeleteInvitationsResponse, DeleteInvitationsError, Credentials | HttpClient.HttpClient>;
export type DeleteIPSetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Deletes the IPSet specified by the `ipSetId`. IPSets are called trusted IP lists in the console user interface.
 */
export declare const deleteIPSet: API.OperationMethod<DeleteIPSetRequest, DeleteIPSetResponse, DeleteIPSetError, Credentials | HttpClient.HttpClient>;
export type DeleteMalwareProtectionPlanError = AccessDeniedException | BadRequestException | InternalServerErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the Malware Protection plan ID associated with the Malware Protection plan resource. Use this API only when you no longer want to protect the resource associated with this Malware Protection plan ID.
 */
export declare const deleteMalwareProtectionPlan: API.OperationMethod<DeleteMalwareProtectionPlanRequest, DeleteMalwareProtectionPlanResponse, DeleteMalwareProtectionPlanError, Credentials | HttpClient.HttpClient>;
export type DeleteMembersError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Deletes GuardDuty member accounts (to the current GuardDuty administrator account) specified by the account IDs.
 *
 * With `autoEnableOrganizationMembers` configuration for your organization set to `ALL`, you'll receive an error if you attempt to disable GuardDuty for a member account in your organization.
 */
export declare const deleteMembers: API.OperationMethod<DeleteMembersRequest, DeleteMembersResponse, DeleteMembersError, Credentials | HttpClient.HttpClient>;
export type DeletePublishingDestinationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Deletes the publishing definition with the specified `destinationId`.
 */
export declare const deletePublishingDestination: API.OperationMethod<DeletePublishingDestinationRequest, DeletePublishingDestinationResponse, DeletePublishingDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteThreatEntitySetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Deletes the threat entity set that is associated with the specified `threatEntitySetId`.
 */
export declare const deleteThreatEntitySet: API.OperationMethod<DeleteThreatEntitySetRequest, DeleteThreatEntitySetResponse, DeleteThreatEntitySetError, Credentials | HttpClient.HttpClient>;
export type DeleteThreatIntelSetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Deletes the ThreatIntelSet specified by the ThreatIntelSet ID.
 */
export declare const deleteThreatIntelSet: API.OperationMethod<DeleteThreatIntelSetRequest, DeleteThreatIntelSetResponse, DeleteThreatIntelSetError, Credentials | HttpClient.HttpClient>;
export type DeleteTrustedEntitySetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Deletes the trusted entity set that is associated with the specified `trustedEntitySetId`.
 */
export declare const deleteTrustedEntitySet: API.OperationMethod<DeleteTrustedEntitySetRequest, DeleteTrustedEntitySetResponse, DeleteTrustedEntitySetError, Credentials | HttpClient.HttpClient>;
export type DescribeMalwareScansError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns a list of malware scans. Each member account can view the malware scans for their own accounts. An administrator can view the malware scans for all the member accounts.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const describeMalwareScans: API.PaginatedOperationMethod<DescribeMalwareScansRequest, DescribeMalwareScansResponse, DescribeMalwareScansError, Credentials | HttpClient.HttpClient, Scan>;
export type DescribeOrganizationConfigurationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns information about the account selected as the delegated administrator for GuardDuty.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const describeOrganizationConfiguration: API.PaginatedOperationMethod<DescribeOrganizationConfigurationRequest, DescribeOrganizationConfigurationResponse, DescribeOrganizationConfigurationError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribePublishingDestinationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns information about the publishing destination specified by the provided `destinationId`.
 */
export declare const describePublishingDestination: API.OperationMethod<DescribePublishingDestinationRequest, DescribePublishingDestinationResponse, DescribePublishingDestinationError, Credentials | HttpClient.HttpClient>;
export type DisableOrganizationAdminAccountError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Removes the existing GuardDuty delegated administrator of the organization. Only the organization's management account can run this API operation.
 */
export declare const disableOrganizationAdminAccount: API.OperationMethod<DisableOrganizationAdminAccountRequest, DisableOrganizationAdminAccountResponse, DisableOrganizationAdminAccountError, Credentials | HttpClient.HttpClient>;
export type DisassociateFromAdministratorAccountError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Disassociates the current GuardDuty member account from its administrator account.
 *
 * When you disassociate an invited member from a GuardDuty delegated administrator, the member account details obtained from the CreateMembers API, including the associated email addresses, are retained. This is done so that the delegated administrator can invoke the InviteMembers API without the need to invoke the CreateMembers API again. To remove the details associated with a member account, the delegated administrator must invoke the DeleteMembers API.
 *
 * With `autoEnableOrganizationMembers` configuration for your organization set to `ALL`, you'll receive an error if you attempt to disable GuardDuty in a member account.
 */
export declare const disassociateFromAdministratorAccount: API.OperationMethod<DisassociateFromAdministratorAccountRequest, DisassociateFromAdministratorAccountResponse, DisassociateFromAdministratorAccountError, Credentials | HttpClient.HttpClient>;
export type DisassociateFromMasterAccountError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Disassociates the current GuardDuty member account from its administrator account.
 *
 * When you disassociate an invited member from a GuardDuty delegated administrator, the member account details obtained from the CreateMembers API, including the associated email addresses, are retained. This is done so that the delegated administrator can invoke the InviteMembers API without the need to invoke the CreateMembers API again. To remove the details associated with a member account, the delegated administrator must invoke the DeleteMembers API.
 */
export declare const disassociateFromMasterAccount: API.OperationMethod<DisassociateFromMasterAccountRequest, DisassociateFromMasterAccountResponse, DisassociateFromMasterAccountError, Credentials | HttpClient.HttpClient>;
export type DisassociateMembersError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Disassociates GuardDuty member accounts (from the current administrator account) specified by the account IDs.
 *
 * When you disassociate an invited member from a GuardDuty delegated administrator, the member account details obtained from the CreateMembers API, including the associated email addresses, are retained. This is done so that the delegated administrator can invoke the InviteMembers API without the need to invoke the CreateMembers API again. To remove the details associated with a member account, the delegated administrator must invoke the DeleteMembers API.
 *
 * With `autoEnableOrganizationMembers` configuration for your organization set to `ALL`, you'll receive an error if you attempt to disassociate a member account before removing them from your organization.
 *
 * If you disassociate a member account that was added by invitation, the member account details obtained from this API, including the associated email addresses, will be retained. This is done so that the delegated administrator can invoke the InviteMembers API without the need to invoke the CreateMembers API again. To remove the details associated with a member account, the delegated administrator must invoke the DeleteMembers API.
 *
 * When the member accounts added through Organizations are later disassociated, you (administrator) can't invite them by calling the InviteMembers API. You can create an association with these member accounts again only by calling the CreateMembers API.
 */
export declare const disassociateMembers: API.OperationMethod<DisassociateMembersRequest, DisassociateMembersResponse, DisassociateMembersError, Credentials | HttpClient.HttpClient>;
export type EnableOrganizationAdminAccountError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Designates an Amazon Web Services account within the organization as your GuardDuty delegated administrator. Only the organization's management account can run this API operation.
 */
export declare const enableOrganizationAdminAccount: API.OperationMethod<EnableOrganizationAdminAccountRequest, EnableOrganizationAdminAccountResponse, EnableOrganizationAdminAccountError, Credentials | HttpClient.HttpClient>;
export type GetAdministratorAccountError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Provides the details of the GuardDuty administrator account associated with the current GuardDuty member account.
 *
 * Based on the type of account that runs this API, the following list shows how the API behavior varies:
 *
 * - When the GuardDuty administrator account runs this API, it will return success (`HTTP 200`) but no content.
 *
 * - When a member account runs this API, it will return the details of the GuardDuty administrator account that is associated with this calling member account.
 *
 * - When an individual account (not associated with an organization) runs this API, it will return success (`HTTP 200`) but no content.
 */
export declare const getAdministratorAccount: API.OperationMethod<GetAdministratorAccountRequest, GetAdministratorAccountResponse, GetAdministratorAccountError, Credentials | HttpClient.HttpClient>;
export type GetCoverageStatisticsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves aggregated statistics for your account. If you are a GuardDuty administrator, you can retrieve the statistics for all the resources associated with the active member accounts in your organization who have enabled Runtime Monitoring and have the GuardDuty security agent running on their resources.
 */
export declare const getCoverageStatistics: API.OperationMethod<GetCoverageStatisticsRequest, GetCoverageStatisticsResponse, GetCoverageStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetCustomDetectionRuleError = AccessDeniedException | BadRequestException | InternalServerErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Returns details for a custom detection rule in GuardDuty, including its detection logic.
 */
export declare const getCustomDetectionRule: API.OperationMethod<GetCustomDetectionRuleRequest, GetCustomDetectionRuleResponse, GetCustomDetectionRuleError, Credentials | HttpClient.HttpClient>;
export type GetCustomDetectionRuleAssociationError = AccessDeniedException | BadRequestException | InternalServerErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Returns details for a custom detection rule association.
 */
export declare const getCustomDetectionRuleAssociation: API.OperationMethod<GetCustomDetectionRuleAssociationRequest, GetCustomDetectionRuleAssociationResponse, GetCustomDetectionRuleAssociationError, Credentials | HttpClient.HttpClient>;
export type GetCustomDetectionRuleOrgConfigurationError = AccessDeniedException | BadRequestException | InternalServerErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Returns the organization-level configuration for a custom detection rule.
 */
export declare const getCustomDetectionRuleOrgConfiguration: API.OperationMethod<GetCustomDetectionRuleOrgConfigurationRequest, GetCustomDetectionRuleOrgConfigurationResponse, GetCustomDetectionRuleOrgConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetDetectorError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves a GuardDuty detector specified by the detectorId.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const getDetector: API.OperationMethod<GetDetectorRequest, GetDetectorResponse, GetDetectorError, Credentials | HttpClient.HttpClient>;
export type GetFilterError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns the details of the filter specified by the filter name.
 */
export declare const getFilter: API.OperationMethod<GetFilterRequest, GetFilterResponse, GetFilterError, Credentials | HttpClient.HttpClient>;
export type GetFindingsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Describes Amazon GuardDuty findings specified by finding IDs.
 */
export declare const getFindings: API.OperationMethod<GetFindingsRequest, GetFindingsResponse, GetFindingsError, Credentials | HttpClient.HttpClient>;
export type GetFindingsStatisticsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists GuardDuty findings statistics for the specified detector ID.
 *
 * You must provide either `findingStatisticTypes` or `groupBy` parameter, and not both. You can use the `maxResults` and `orderBy` parameters only when using `groupBy`.
 *
 * There might be regional differences because some flags might not be available in all the Regions where GuardDuty is currently supported. For more information, see Regions and endpoints.
 */
export declare const getFindingsStatistics: API.OperationMethod<GetFindingsStatisticsRequest, GetFindingsStatisticsResponse, GetFindingsStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetInvestigationError = AccessDeniedException | BadRequestException | InternalServerErrorException | ResourceNotFoundException | CommonErrors;
/**
 * This API is currently available as a preview. This feature is available in the following Amazon Web Services Regions: US East (N. Virginia), US East (Ohio), US West (Oregon), Canada (Central), Europe (Frankfurt), Europe (Ireland), Europe (London), Europe (Paris), Europe (Stockholm), and Asia Pacific (Tokyo).
 *
 * Retrieves the results and status of a specific GuardDuty investigation.
 *
 * An administrator account can retrieve any investigation within the organization. Member accounts can only retrieve investigations that belong to them.
 */
export declare const getInvestigation: API.OperationMethod<GetInvestigationRequest, GetInvestigationResponse, GetInvestigationError, Credentials | HttpClient.HttpClient>;
export type GetInvitationsCountError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns the count of all GuardDuty membership invitations that were sent to the current member account except the currently accepted invitation.
 */
export declare const getInvitationsCount: API.OperationMethod<GetInvitationsCountRequest, GetInvitationsCountResponse, GetInvitationsCountError, Credentials | HttpClient.HttpClient>;
export type GetIPSetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves the IPSet specified by the `ipSetId`.
 */
export declare const getIPSet: API.OperationMethod<GetIPSetRequest, GetIPSetResponse, GetIPSetError, Credentials | HttpClient.HttpClient>;
export type GetMalwareProtectionPlanError = AccessDeniedException | BadRequestException | InternalServerErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the Malware Protection plan details associated with a Malware Protection plan ID.
 */
export declare const getMalwareProtectionPlan: API.OperationMethod<GetMalwareProtectionPlanRequest, GetMalwareProtectionPlanResponse, GetMalwareProtectionPlanError, Credentials | HttpClient.HttpClient>;
export type GetMalwareScanError = BadRequestException | InternalServerErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the detailed information for a specific malware scan. Each member account can view the malware scan details for their own account. An administrator can view malware scan details for all accounts in the organization.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const getMalwareScan: API.OperationMethod<GetMalwareScanRequest, GetMalwareScanResponse, GetMalwareScanError, Credentials | HttpClient.HttpClient>;
export type GetMalwareScanSettingsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns the details of the malware scan settings.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const getMalwareScanSettings: API.OperationMethod<GetMalwareScanSettingsRequest, GetMalwareScanSettingsResponse, GetMalwareScanSettingsError, Credentials | HttpClient.HttpClient>;
export type GetMasterAccountError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Provides the details for the GuardDuty administrator account associated with the current GuardDuty member account.
 */
export declare const getMasterAccount: API.OperationMethod<GetMasterAccountRequest, GetMasterAccountResponse, GetMasterAccountError, Credentials | HttpClient.HttpClient>;
export type GetMemberDetectorsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Describes which data sources are enabled for the member account's detector.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const getMemberDetectors: API.OperationMethod<GetMemberDetectorsRequest, GetMemberDetectorsResponse, GetMemberDetectorsError, Credentials | HttpClient.HttpClient>;
export type GetMembersError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves GuardDuty member accounts (of the current GuardDuty administrator account) specified by the account IDs.
 */
export declare const getMembers: API.OperationMethod<GetMembersRequest, GetMembersResponse, GetMembersError, Credentials | HttpClient.HttpClient>;
export type GetOrganizationStatisticsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves how many active member accounts have each feature enabled within GuardDuty. Only a delegated GuardDuty administrator of an organization can run this API.
 *
 * When you create a new organization, it might take up to 24 hours to generate the statistics for the entire organization.
 */
export declare const getOrganizationStatistics: API.OperationMethod<GetOrganizationStatisticsRequest, GetOrganizationStatisticsResponse, GetOrganizationStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetRemainingFreeTrialDaysError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Provides the number of days left for each data source used in the free trial period.
 */
export declare const getRemainingFreeTrialDays: API.OperationMethod<GetRemainingFreeTrialDaysRequest, GetRemainingFreeTrialDaysResponse, GetRemainingFreeTrialDaysError, Credentials | HttpClient.HttpClient>;
export type GetThreatEntitySetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves the threat entity set associated with the specified `threatEntitySetId`.
 */
export declare const getThreatEntitySet: API.OperationMethod<GetThreatEntitySetRequest, GetThreatEntitySetResponse, GetThreatEntitySetError, Credentials | HttpClient.HttpClient>;
export type GetThreatIntelSetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves the ThreatIntelSet that is specified by the ThreatIntelSet ID.
 */
export declare const getThreatIntelSet: API.OperationMethod<GetThreatIntelSetRequest, GetThreatIntelSetResponse, GetThreatIntelSetError, Credentials | HttpClient.HttpClient>;
export type GetTrustedEntitySetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves the trusted entity set associated with the specified `trustedEntitySetId`.
 */
export declare const getTrustedEntitySet: API.OperationMethod<GetTrustedEntitySetRequest, GetTrustedEntitySetResponse, GetTrustedEntitySetError, Credentials | HttpClient.HttpClient>;
export type GetUsageStatisticsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists Amazon GuardDuty usage statistics over the last 30 days for the specified detector ID. For newly enabled detectors or data sources, the cost returned will include only the usage so far under 30 days. This may differ from the cost metrics in the console, which project usage over 30 days to provide a monthly cost estimate. For more information, see Understanding How Usage Costs are Calculated.
 */
export declare const getUsageStatistics: API.PaginatedOperationMethod<GetUsageStatisticsRequest, GetUsageStatisticsResponse, GetUsageStatisticsError, Credentials | HttpClient.HttpClient, unknown>;
export type InviteMembersError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Invites Amazon Web Services accounts to become members of an organization administered by the Amazon Web Services account that invokes this API. If you are using Amazon Web Services Organizations to manage your GuardDuty environment, this step is not needed. For more information, see Managing accounts with organizations.
 *
 * To invite Amazon Web Services accounts, the first step is to ensure that GuardDuty has been enabled in the potential member accounts. You can now invoke this API to add accounts by invitation. The invited accounts can either accept or decline the invitation from their GuardDuty accounts. Each invited Amazon Web Services account can choose to accept the invitation from only one Amazon Web Services account. For more information, see Managing GuardDuty accounts by invitation.
 *
 * After the invite has been accepted and you choose to disassociate a member account (by using DisassociateMembers) from your account, the details of the member account obtained by invoking CreateMembers, including the associated email addresses, will be retained. This is done so that you can invoke InviteMembers without the need to invoke CreateMembers again. To remove the details associated with a member account, you must also invoke DeleteMembers.
 *
 * If you disassociate a member account that was added by invitation, the member account details obtained from this API, including the associated email addresses, will be retained. This is done so that the delegated administrator can invoke the InviteMembers API without the need to invoke the CreateMembers API again. To remove the details associated with a member account, the delegated administrator must invoke the DeleteMembers API.
 *
 * When the member accounts added through Organizations are later disassociated, you (administrator) can't invite them by calling the InviteMembers API. You can create an association with these member accounts again only by calling the CreateMembers API.
 */
export declare const inviteMembers: API.OperationMethod<InviteMembersRequest, InviteMembersResponse, InviteMembersError, Credentials | HttpClient.HttpClient>;
export type ListCoverageError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists coverage details for your GuardDuty account. If you're a GuardDuty administrator, you can retrieve all resources associated with the active member accounts in your organization.
 *
 * Make sure the accounts have Runtime Monitoring enabled and GuardDuty agent running on their resources.
 */
export declare const listCoverage: API.PaginatedOperationMethod<ListCoverageRequest, ListCoverageResponse, ListCoverageError, Credentials | HttpClient.HttpClient, CoverageResource>;
export type ListCustomDetectionRuleAssociationsError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns all custom detection rule associations for your account. You can filter by rule ID and mode.
 */
export declare const listCustomDetectionRuleAssociations: API.PaginatedOperationMethod<ListCustomDetectionRuleAssociationsRequest, ListCustomDetectionRuleAssociationsResponse, ListCustomDetectionRuleAssociationsError, Credentials | HttpClient.HttpClient, AssociationSummary>;
export type ListCustomDetectionRuleOrgConfigurationsError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns all organization-level configurations for custom detection rules. You can filter the results by status.
 */
export declare const listCustomDetectionRuleOrgConfigurations: API.PaginatedOperationMethod<ListCustomDetectionRuleOrgConfigurationsRequest, ListCustomDetectionRuleOrgConfigurationsResponse, ListCustomDetectionRuleOrgConfigurationsError, Credentials | HttpClient.HttpClient, DetectionRuleOrgConfigurationSummary>;
export type ListCustomDetectionRulesError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns all available custom detection rules in GuardDuty. You can filter the results by data source, severity, tactic, technique, and service.
 */
export declare const listCustomDetectionRules: API.PaginatedOperationMethod<ListCustomDetectionRulesRequest, ListCustomDetectionRulesResponse, ListCustomDetectionRulesError, Credentials | HttpClient.HttpClient, RuleSummary>;
export type ListDetectorsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists detectorIds of all the existing Amazon GuardDuty detector resources.
 */
export declare const listDetectors: API.PaginatedOperationMethod<ListDetectorsRequest, ListDetectorsResponse, ListDetectorsError, Credentials | HttpClient.HttpClient, DetectorId>;
export type ListFiltersError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns a paginated list of the current filters.
 */
export declare const listFilters: API.PaginatedOperationMethod<ListFiltersRequest, ListFiltersResponse, ListFiltersError, Credentials | HttpClient.HttpClient, FilterName>;
export type ListFindingsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists GuardDuty findings for the specified detector ID.
 *
 * There might be regional differences because some flags might not be available in all the Regions where GuardDuty is currently supported. For more information, see Regions and endpoints.
 */
export declare const listFindings: API.PaginatedOperationMethod<ListFindingsRequest, ListFindingsResponse, ListFindingsError, Credentials | HttpClient.HttpClient, FindingId>;
export type ListInvestigationsError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * This API is currently available as a preview. This feature is available in the following Amazon Web Services Regions: US East (N. Virginia), US East (Ohio), US West (Oregon), Canada (Central), Europe (Frankfurt), Europe (Ireland), Europe (London), Europe (Paris), Europe (Stockholm), and Asia Pacific (Tokyo).
 *
 * Returns a list of investigations associated with the specified GuardDuty detector.
 *
 * An administrator account sees all investigations across the organization. Member accounts see only the investigations that belong to them.
 */
export declare const listInvestigations: API.PaginatedOperationMethod<ListInvestigationsRequest, ListInvestigationsResponse, ListInvestigationsError, Credentials | HttpClient.HttpClient, InvestigationSummary>;
export type ListInvitationsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists all GuardDuty membership invitations that were sent to the current Amazon Web Services account.
 */
export declare const listInvitations: API.PaginatedOperationMethod<ListInvitationsRequest, ListInvitationsResponse, ListInvitationsError, Credentials | HttpClient.HttpClient, Invitation>;
export type ListIPSetsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists the IPSets of the GuardDuty service specified by the detector ID. If you use this operation from a member account, the IPSets returned are the IPSets from the associated administrator account.
 */
export declare const listIPSets: API.PaginatedOperationMethod<ListIPSetsRequest, ListIPSetsResponse, ListIPSetsError, Credentials | HttpClient.HttpClient, string>;
export type ListMalwareProtectionPlansError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists the Malware Protection plan IDs associated with the protected resources in your Amazon Web Services account.
 */
export declare const listMalwareProtectionPlans: API.OperationMethod<ListMalwareProtectionPlansRequest, ListMalwareProtectionPlansResponse, ListMalwareProtectionPlansError, Credentials | HttpClient.HttpClient>;
export type ListMalwareScansError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns a list of malware scans. Each member account can view the malware scans for their own accounts. An administrator can view the malware scans for all of its members' accounts.
 */
export declare const listMalwareScans: API.PaginatedOperationMethod<ListMalwareScansRequest, ListMalwareScansResponse, ListMalwareScansError, Credentials | HttpClient.HttpClient, MalwareScan>;
export type ListMembersError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists details about all member accounts for the current GuardDuty administrator account.
 */
export declare const listMembers: API.PaginatedOperationMethod<ListMembersRequest, ListMembersResponse, ListMembersError, Credentials | HttpClient.HttpClient, Member>;
export type ListOrganizationAdminAccountsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists the accounts designated as GuardDuty delegated administrators. Only the organization's management account can run this API operation.
 */
export declare const listOrganizationAdminAccounts: API.PaginatedOperationMethod<ListOrganizationAdminAccountsRequest, ListOrganizationAdminAccountsResponse, ListOrganizationAdminAccountsError, Credentials | HttpClient.HttpClient, AdminAccount>;
export type ListPublishingDestinationsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Returns a list of publishing destinations associated with the specified `detectorId`.
 */
export declare const listPublishingDestinations: API.PaginatedOperationMethod<ListPublishingDestinationsRequest, ListPublishingDestinationsResponse, ListPublishingDestinationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists tags for a resource. Tagging is currently supported for detectors, finding filters, IP sets, threat intel sets, and publishing destination, with a limit of 50 tags per resource. When invoked, this operation returns all assigned tags for a given resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListThreatEntitySetsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists the threat entity sets associated with the specified GuardDuty detector ID. If you use this operation from a member account, the threat entity sets that are returned as a response, belong to the administrator account.
 */
export declare const listThreatEntitySets: API.PaginatedOperationMethod<ListThreatEntitySetsRequest, ListThreatEntitySetsResponse, ListThreatEntitySetsError, Credentials | HttpClient.HttpClient, string>;
export type ListThreatIntelSetsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists the ThreatIntelSets of the GuardDuty service specified by the detector ID. If you use this operation from a member account, the ThreatIntelSets associated with the administrator account are returned.
 */
export declare const listThreatIntelSets: API.PaginatedOperationMethod<ListThreatIntelSetsRequest, ListThreatIntelSetsResponse, ListThreatIntelSetsError, Credentials | HttpClient.HttpClient, string>;
export type ListTrustedEntitySetsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Lists the trusted entity sets associated with the specified GuardDuty detector ID. If you use this operation from a member account, the trusted entity sets that are returned as a response, belong to the administrator account.
 */
export declare const listTrustedEntitySets: API.PaginatedOperationMethod<ListTrustedEntitySetsRequest, ListTrustedEntitySetsResponse, ListTrustedEntitySetsError, Credentials | HttpClient.HttpClient, string>;
export type SendObjectMalwareScanError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Initiates a malware scan for a specific S3 object. This API allows you to perform on-demand malware scanning of individual objects in S3 buckets that have Malware Protection for S3 enabled.
 *
 * When you use this API, the Amazon Web Services service terms for GuardDuty Malware Protection apply. For more information, see Amazon Web Services service terms for GuardDuty Malware Protection.
 */
export declare const sendObjectMalwareScan: API.OperationMethod<SendObjectMalwareScanRequest, SendObjectMalwareScanResponse, SendObjectMalwareScanError, Credentials | HttpClient.HttpClient>;
export type StartMalwareScanError = BadRequestException | ConflictException | InternalServerErrorException | CommonErrors;
/**
 * Initiates the malware scan. Invoking this API will automatically create the Service-linked role in the corresponding account if the resourceArn belongs to an EC2 instance.
 *
 * When the malware scan starts, you can use the associated scan ID to track the status of the scan. For more information, see ListMalwareScans and GetMalwareScan.
 *
 * When you use this API, the Amazon Web Services service terms for GuardDuty Malware Protection apply. For more information, see Amazon Web Services service terms for GuardDuty Malware Protection.
 */
export declare const startMalwareScan: API.OperationMethod<StartMalwareScanRequest, StartMalwareScanResponse, StartMalwareScanError, Credentials | HttpClient.HttpClient>;
export type StartMonitoringMembersError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Turns on GuardDuty monitoring of the specified member accounts. Use this operation to restart monitoring of accounts that you stopped monitoring with the StopMonitoringMembers operation.
 */
export declare const startMonitoringMembers: API.OperationMethod<StartMonitoringMembersRequest, StartMonitoringMembersResponse, StartMonitoringMembersError, Credentials | HttpClient.HttpClient>;
export type StopMonitoringMembersError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Stops GuardDuty monitoring for the specified member accounts. Use the `StartMonitoringMembers` operation to restart monitoring for those accounts.
 *
 * With `autoEnableOrganizationMembers` configuration for your organization set to `ALL`, you'll receive an error if you attempt to stop monitoring the member accounts in your organization.
 */
export declare const stopMonitoringMembers: API.OperationMethod<StopMonitoringMembersRequest, StopMonitoringMembersResponse, StopMonitoringMembersError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Adds tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UnarchiveFindingsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Unarchives GuardDuty findings specified by the `findingIds`.
 */
export declare const unarchiveFindings: API.OperationMethod<UnarchiveFindingsRequest, UnarchiveFindingsResponse, UnarchiveFindingsError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCustomDetectionRuleAssociationError = AccessDeniedException | BadRequestException | ConflictException | InternalServerErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the mode of an existing custom detection rule association.
 */
export declare const updateCustomDetectionRuleAssociation: API.OperationMethod<UpdateCustomDetectionRuleAssociationRequest, UpdateCustomDetectionRuleAssociationResponse, UpdateCustomDetectionRuleAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateCustomDetectionRuleOrgConfigurationError = AccessDeniedException | BadRequestException | ConflictException | InternalServerErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the organization-level configuration for a custom detection rule, including the mode and include/exclude account lists.
 */
export declare const updateCustomDetectionRuleOrgConfiguration: API.OperationMethod<UpdateCustomDetectionRuleOrgConfigurationRequest, UpdateCustomDetectionRuleOrgConfigurationResponse, UpdateCustomDetectionRuleOrgConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateDetectorError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates the GuardDuty detector specified by the detector ID.
 *
 * Specifying both EKS Runtime Monitoring (`EKS_RUNTIME_MONITORING`) and Runtime Monitoring (`RUNTIME_MONITORING`) will cause an error. You can add only one of these two features because Runtime Monitoring already includes the threat detection for Amazon EKS resources. For more information, see Runtime Monitoring.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const updateDetector: API.OperationMethod<UpdateDetectorRequest, UpdateDetectorResponse, UpdateDetectorError, Credentials | HttpClient.HttpClient>;
export type UpdateFilterError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates the filter specified by the filter name.
 */
export declare const updateFilter: API.OperationMethod<UpdateFilterRequest, UpdateFilterResponse, UpdateFilterError, Credentials | HttpClient.HttpClient>;
export type UpdateFindingsFeedbackError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Marks the specified GuardDuty findings as useful or not useful.
 */
export declare const updateFindingsFeedback: API.OperationMethod<UpdateFindingsFeedbackRequest, UpdateFindingsFeedbackResponse, UpdateFindingsFeedbackError, Credentials | HttpClient.HttpClient>;
export type UpdateIPSetError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates the IPSet specified by the IPSet ID.
 */
export declare const updateIPSet: API.OperationMethod<UpdateIPSetRequest, UpdateIPSetResponse, UpdateIPSetError, Credentials | HttpClient.HttpClient>;
export type UpdateMalwareProtectionPlanError = AccessDeniedException | BadRequestException | InternalServerErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an existing Malware Protection plan resource.
 */
export declare const updateMalwareProtectionPlan: API.OperationMethod<UpdateMalwareProtectionPlanRequest, UpdateMalwareProtectionPlanResponse, UpdateMalwareProtectionPlanError, Credentials | HttpClient.HttpClient>;
export type UpdateMalwareScanSettingsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates the malware scan settings.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const updateMalwareScanSettings: API.OperationMethod<UpdateMalwareScanSettingsRequest, UpdateMalwareScanSettingsResponse, UpdateMalwareScanSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateMemberDetectorsError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Contains information on member accounts to be updated.
 *
 * Specifying both EKS Runtime Monitoring (`EKS_RUNTIME_MONITORING`) and Runtime Monitoring (`RUNTIME_MONITORING`) will cause an error. You can add only one of these two features because Runtime Monitoring already includes the threat detection for Amazon EKS resources. For more information, see Runtime Monitoring.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const updateMemberDetectors: API.OperationMethod<UpdateMemberDetectorsRequest, UpdateMemberDetectorsResponse, UpdateMemberDetectorsError, Credentials | HttpClient.HttpClient>;
export type UpdateOrganizationConfigurationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Configures the delegated administrator account with the provided values. You must provide a value for either `autoEnableOrganizationMembers` or `autoEnable`, but not both.
 *
 * Specifying both EKS Runtime Monitoring (`EKS_RUNTIME_MONITORING`) and Runtime Monitoring (`RUNTIME_MONITORING`) will cause an error. You can add only one of these two features because Runtime Monitoring already includes the threat detection for Amazon EKS resources. For more information, see Runtime Monitoring.
 *
 * There might be regional differences because some data sources might not be available in all the Amazon Web Services Regions where GuardDuty is presently supported. For more information, see Regions and endpoints.
 */
export declare const updateOrganizationConfiguration: API.OperationMethod<UpdateOrganizationConfigurationRequest, UpdateOrganizationConfigurationResponse, UpdateOrganizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdatePublishingDestinationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates information about the publishing destination specified by the `destinationId`.
 */
export declare const updatePublishingDestination: API.OperationMethod<UpdatePublishingDestinationRequest, UpdatePublishingDestinationResponse, UpdatePublishingDestinationError, Credentials | HttpClient.HttpClient>;
export type UpdateThreatEntitySetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates the threat entity set associated with the specified `threatEntitySetId`.
 */
export declare const updateThreatEntitySet: API.OperationMethod<UpdateThreatEntitySetRequest, UpdateThreatEntitySetResponse, UpdateThreatEntitySetError, Credentials | HttpClient.HttpClient>;
export type UpdateThreatIntelSetError = AccessDeniedException | BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates the ThreatIntelSet specified by the ThreatIntelSet ID.
 */
export declare const updateThreatIntelSet: API.OperationMethod<UpdateThreatIntelSetRequest, UpdateThreatIntelSetResponse, UpdateThreatIntelSetError, Credentials | HttpClient.HttpClient>;
export type UpdateTrustedEntitySetError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates the trusted entity set associated with the specified `trustedEntitySetId`.
 */
export declare const updateTrustedEntitySet: API.OperationMethod<UpdateTrustedEntitySetRequest, UpdateTrustedEntitySetResponse, UpdateTrustedEntitySetError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=guardduty.d.ts.map