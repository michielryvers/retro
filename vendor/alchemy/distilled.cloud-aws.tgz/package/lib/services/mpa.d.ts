import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
    readonly ResourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SessionArn = string;
export interface CancelSessionRequest {
    SessionArn: string;
}
export interface CancelSessionResponse {
}
export type Token = string;
export interface MofNApprovalStrategy {
    MinApprovalsRequired: number;
}
export type ApprovalStrategy = {
    MofN: MofNApprovalStrategy;
};
export type IdentityId = string;
export interface ApprovalTeamRequestApprover {
    PrimaryIdentityId: string;
    PrimaryIdentitySourceArn: string;
}
export type ApprovalTeamRequestApprovers = ApprovalTeamRequestApprover[];
export type Description = string | redacted.Redacted<string>;
export type QualifiedPolicyArn = string;
export interface PolicyReference {
    PolicyArn: string;
}
export type PoliciesReferences = PolicyReference[];
export type ApprovalTeamName = string;
export type TagKey = string | redacted.Redacted<string>;
export type TagValue = string | redacted.Redacted<string>;
export type Tags = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export interface CreateApprovalTeamRequest {
    ClientToken?: string;
    ApprovalStrategy: ApprovalStrategy;
    Approvers: ApprovalTeamRequestApprover[];
    Description: string | redacted.Redacted<string>;
    Policies: PolicyReference[];
    Name: string;
    Tags?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export type IsoTimestamp = Date;
export type ApprovalTeamArn = string;
export interface CreateApprovalTeamResponse {
    CreationTime?: Date;
    Arn?: string;
    Name?: string;
    VersionId?: string;
}
export type IdcInstanceArn = string;
export interface IamIdentityCenter {
    InstanceArn: string;
    Region: string;
}
export interface IdentitySourceParameters {
    IamIdentityCenter?: IamIdentityCenter;
}
export interface CreateIdentitySourceRequest {
    IdentitySourceParameters: IdentitySourceParameters;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export type IdentitySourceType = "IAM_IDENTITY_CENTER" | (string & {});
export interface CreateIdentitySourceResponse {
    IdentitySourceType?: IdentitySourceType;
    IdentitySourceArn?: string;
    CreationTime?: Date;
}
export interface DeleteIdentitySourceRequest {
    IdentitySourceArn: string;
}
export interface DeleteIdentitySourceResponse {
}
export interface DeleteInactiveApprovalTeamVersionRequest {
    Arn: string;
    VersionId: string;
}
export interface DeleteInactiveApprovalTeamVersionResponse {
}
export interface GetApprovalTeamRequest {
    Arn: string;
}
export type ApprovalStrategyResponse = {
    MofN: MofNApprovalStrategy;
};
export type ParticipantId = string;
export type IdentityStatus = "PENDING" | "ACCEPTED" | "REJECTED" | "INVALID" | (string & {});
export type ApproverLastActivity = "VOTED" | "BASELINED" | "RESPONDED_TO_INVITATION" | (string & {});
export type MfaType = "EMAIL_OTP" | (string & {});
export type MfaSyncStatus = "IN_SYNC" | "OUT_OF_SYNC" | (string & {});
export interface MfaMethod {
    Type: MfaType;
    SyncStatus: MfaSyncStatus;
}
export type MfaMethods = MfaMethod[];
export interface GetApprovalTeamResponseApprover {
    ApproverId?: string;
    ResponseTime?: Date;
    PrimaryIdentityId?: string;
    PrimaryIdentitySourceArn?: string;
    PrimaryIdentityStatus?: IdentityStatus;
    LastActivity?: ApproverLastActivity;
    LastActivityTime?: Date;
    PendingBaselineSessionArn?: string;
    MfaMethods?: MfaMethod[];
}
export type GetApprovalTeamResponseApprovers = GetApprovalTeamResponseApprover[];
export type ApprovalTeamStatus = "ACTIVE" | "INACTIVE" | "DELETING" | "PENDING" | (string & {});
export type ApprovalTeamStatusCode = "VALIDATING" | "PENDING_ACTIVATION" | "FAILED_VALIDATION" | "FAILED_ACTIVATION" | "UPDATE_PENDING_APPROVAL" | "UPDATE_PENDING_ACTIVATION" | "UPDATE_FAILED_APPROVAL" | "UPDATE_FAILED_ACTIVATION" | "UPDATE_FAILED_VALIDATION" | "DELETE_PENDING_APPROVAL" | "DELETE_FAILED_APPROVAL" | "DELETE_FAILED_VALIDATION" | (string & {});
export type Message = string;
export interface PendingUpdate {
    VersionId?: string;
    Description?: string;
    ApprovalStrategy?: ApprovalStrategyResponse;
    NumberOfApprovers?: number;
    Status?: ApprovalTeamStatus;
    StatusCode?: ApprovalTeamStatusCode;
    StatusMessage?: string;
    Approvers?: GetApprovalTeamResponseApprover[];
    UpdateInitiationTime?: Date;
}
export interface GetApprovalTeamResponse {
    CreationTime?: Date;
    ApprovalStrategy?: ApprovalStrategyResponse;
    NumberOfApprovers?: number;
    Approvers?: GetApprovalTeamResponseApprover[];
    Arn?: string;
    Description?: string | redacted.Redacted<string>;
    Name?: string;
    Status?: ApprovalTeamStatus;
    StatusCode?: ApprovalTeamStatusCode;
    StatusMessage?: string;
    UpdateSessionArn?: string;
    VersionId?: string;
    Policies?: PolicyReference[];
    LastUpdateTime?: Date;
    PendingUpdate?: PendingUpdate;
}
export interface GetIdentitySourceRequest {
    IdentitySourceArn: string;
}
export interface IamIdentityCenterForGet {
    InstanceArn?: string;
    ApprovalPortalUrl?: string;
    Region?: string;
}
export type IdentitySourceParametersForGet = {
    IamIdentityCenter: IamIdentityCenterForGet;
};
export type IdentitySourceStatus = "CREATING" | "ACTIVE" | "DELETING" | "ERROR" | (string & {});
export type IdentitySourceStatusCode = "ACCESS_DENIED" | "DELETION_FAILED" | "IDC_INSTANCE_NOT_FOUND" | "IDC_INSTANCE_NOT_VALID" | (string & {});
export interface GetIdentitySourceResponse {
    IdentitySourceType?: IdentitySourceType;
    IdentitySourceParameters?: IdentitySourceParametersForGet;
    IdentitySourceArn?: string;
    CreationTime?: Date;
    Status?: IdentitySourceStatus;
    StatusCode?: IdentitySourceStatusCode;
    StatusMessage?: string;
}
export interface GetPolicyVersionRequest {
    PolicyVersionArn: string;
}
export type UnqualifiedPolicyArn = string;
export type PolicyVersionId = number;
export type PolicyType = "AWS_MANAGED" | "AWS_RAM" | (string & {});
export type PolicyName = string;
export type PolicyStatus = "ATTACHABLE" | "DEPRECATED" | (string & {});
export type PolicyDocument = string | redacted.Redacted<string>;
export interface PolicyVersion {
    Arn: string;
    PolicyArn: string;
    VersionId: number;
    PolicyType: PolicyType;
    IsDefault: boolean;
    Name: string;
    Status: PolicyStatus;
    CreationTime: Date;
    LastUpdatedTime: Date;
    Document: string | redacted.Redacted<string>;
}
export interface GetPolicyVersionResponse {
    PolicyVersion: PolicyVersion;
}
export interface GetResourcePolicyRequest {
    ResourceArn: string;
    PolicyName: string;
    PolicyType: PolicyType;
}
export interface GetResourcePolicyResponse {
    ResourceArn: string;
    PolicyType: PolicyType;
    PolicyVersionArn?: string;
    PolicyName: string;
    PolicyDocument: string | redacted.Redacted<string>;
}
export interface GetSessionRequest {
    SessionArn: string;
}
export type SessionKey = string | redacted.Redacted<string>;
export type SessionValue = string | redacted.Redacted<string>;
export type SessionMetadata = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export type SessionStatus = "PENDING" | "CANCELLED" | "APPROVED" | "FAILED" | "CREATING" | (string & {});
export type SessionStatusCode = "REJECTED" | "EXPIRED" | "CONFIGURATION_CHANGED" | "ALL_APPROVERS_IN_SESSION" | (string & {});
export type SessionExecutionStatus = "EXECUTED" | "FAILED" | "PENDING" | (string & {});
export type ActionName = string;
export type ServicePrincipal = string;
export type AccountId = string;
export type Region = string;
export type RequesterComment = string | redacted.Redacted<string>;
export type ActionCompletionStrategy = "AUTO_COMPLETION_UPON_APPROVAL" | (string & {});
export type SessionResponse = "APPROVED" | "REJECTED" | "NO_RESPONSE" | (string & {});
export interface GetSessionResponseApproverResponse {
    ApproverId?: string;
    IdentitySourceArn?: string;
    IdentityId?: string;
    Response?: SessionResponse;
    ResponseTime?: Date;
}
export type GetSessionResponseApproverResponses = GetSessionResponseApproverResponse[];
export type AdditionalSecurityRequirement = "APPROVER_VERIFICATION_REQUIRED" | (string & {});
export type AdditionalSecurityRequirements = AdditionalSecurityRequirement[];
export interface GetSessionResponse {
    SessionArn?: string;
    ApprovalTeamArn?: string;
    ApprovalTeamName?: string;
    ProtectedResourceArn?: string;
    ApprovalStrategy?: ApprovalStrategyResponse;
    NumberOfApprovers?: number;
    InitiationTime?: Date;
    ExpirationTime?: Date;
    CompletionTime?: Date;
    Description?: string | redacted.Redacted<string>;
    Metadata?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    Status?: SessionStatus;
    StatusCode?: SessionStatusCode;
    StatusMessage?: string;
    ExecutionStatus?: SessionExecutionStatus;
    ActionName?: string;
    RequesterServicePrincipal?: string;
    RequesterPrincipalArn?: string;
    RequesterAccountId?: string;
    RequesterRegion?: string;
    RequesterComment?: string | redacted.Redacted<string>;
    ActionCompletionStrategy?: ActionCompletionStrategy;
    ApproverResponses?: GetSessionResponseApproverResponse[];
    AdditionalSecurityRequirements?: AdditionalSecurityRequirement[];
}
export type MaxResults = number;
export interface ListApprovalTeamsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface ListApprovalTeamsResponseApprovalTeam {
    CreationTime?: Date;
    ApprovalStrategy?: ApprovalStrategyResponse;
    NumberOfApprovers?: number;
    Arn?: string;
    Name?: string;
    Description?: string | redacted.Redacted<string>;
    Status?: ApprovalTeamStatus;
    StatusCode?: ApprovalTeamStatusCode;
    StatusMessage?: string;
}
export type ListApprovalTeamsResponseApprovalTeams = ListApprovalTeamsResponseApprovalTeam[];
export interface ListApprovalTeamsResponse {
    NextToken?: string;
    ApprovalTeams?: ListApprovalTeamsResponseApprovalTeam[];
}
export interface ListIdentitySourcesRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface IamIdentityCenterForList {
    InstanceArn?: string;
    ApprovalPortalUrl?: string;
    Region?: string;
}
export type IdentitySourceParametersForList = {
    IamIdentityCenter: IamIdentityCenterForList;
};
export interface IdentitySourceForList {
    IdentitySourceType?: IdentitySourceType;
    IdentitySourceParameters?: IdentitySourceParametersForList;
    IdentitySourceArn?: string;
    CreationTime?: Date;
    Status?: IdentitySourceStatus;
    StatusCode?: IdentitySourceStatusCode;
    StatusMessage?: string;
}
export type IdentitySources = IdentitySourceForList[];
export interface ListIdentitySourcesResponse {
    NextToken?: string;
    IdentitySources?: IdentitySourceForList[];
}
export interface ListPoliciesRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface Policy {
    Arn: string;
    DefaultVersion: number;
    PolicyType: PolicyType;
    Name: string;
}
export type Policies = Policy[];
export interface ListPoliciesResponse {
    NextToken?: string;
    Policies?: Policy[];
}
export interface ListPolicyVersionsRequest {
    MaxResults?: number;
    NextToken?: string;
    PolicyArn: string;
}
export interface PolicyVersionSummary {
    Arn: string;
    PolicyArn: string;
    VersionId: number;
    PolicyType: PolicyType;
    IsDefault: boolean;
    Name: string;
    Status: PolicyStatus;
    CreationTime: Date;
    LastUpdatedTime: Date;
}
export type PolicyVersions = PolicyVersionSummary[];
export interface ListPolicyVersionsResponse {
    NextToken?: string;
    PolicyVersions?: PolicyVersionSummary[];
}
export interface ListResourcePoliciesRequest {
    ResourceArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface ListResourcePoliciesResponseResourcePolicy {
    PolicyArn?: string;
    PolicyType?: PolicyType;
    PolicyName?: string;
}
export type ListResourcePoliciesResponseResourcePolicies = ListResourcePoliciesResponseResourcePolicy[];
export interface ListResourcePoliciesResponse {
    NextToken?: string;
    ResourcePolicies?: ListResourcePoliciesResponseResourcePolicy[];
}
export type FilterField = "ActionName" | "ApprovalTeamName" | "VotingTime" | "Vote" | "SessionStatus" | "InitiationTime" | (string & {});
export type Operator = "EQ" | "NE" | "GT" | "LT" | "GTE" | "LTE" | "CONTAINS" | "NOT_CONTAINS" | "BETWEEN" | (string & {});
export interface Filter {
    FieldName?: FilterField;
    Operator?: Operator;
    Value?: string;
}
export type Filters = Filter[];
export interface ListSessionsRequest {
    ApprovalTeamArn: string;
    MaxResults?: number;
    NextToken?: string;
    Filters?: Filter[];
}
export interface ListSessionsResponseSession {
    SessionArn?: string;
    ApprovalTeamName?: string;
    ApprovalTeamArn?: string;
    InitiationTime?: Date;
    ExpirationTime?: Date;
    CompletionTime?: Date;
    Description?: string | redacted.Redacted<string>;
    ActionName?: string;
    ProtectedResourceArn?: string;
    RequesterServicePrincipal?: string;
    RequesterPrincipalArn?: string;
    RequesterRegion?: string;
    RequesterAccountId?: string;
    Status?: SessionStatus;
    StatusCode?: SessionStatusCode;
    StatusMessage?: string;
    ActionCompletionStrategy?: ActionCompletionStrategy;
    AdditionalSecurityRequirements?: AdditionalSecurityRequirement[];
}
export type ListSessionsResponseSessions = ListSessionsResponseSession[];
export interface ListSessionsResponse {
    NextToken?: string;
    Sessions?: ListSessionsResponseSession[];
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export interface StartActiveApprovalTeamDeletionRequest {
    PendingWindowDays?: number;
    Arn: string;
}
export interface StartActiveApprovalTeamDeletionResponse {
    DeletionCompletionTime?: Date;
    DeletionStartTime?: Date;
}
export type StartApprovalTeamBaselineApproverIds = string[];
export interface StartApprovalTeamBaselineRequest {
    Arn: string;
    ApproverIds?: string[];
}
export interface StartApprovalTeamBaselineResponse {
    BaselineSessionArn?: string;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = (string | redacted.Redacted<string>)[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: (string | redacted.Redacted<string>)[];
}
export interface UntagResourceResponse {
}
export type UpdateAction = "SYNCHRONIZE_MFA_DEVICES" | (string & {});
export type UpdateActions = UpdateAction[];
export interface UpdateApprovalTeamRequest {
    ApprovalStrategy?: ApprovalStrategy;
    Approvers?: ApprovalTeamRequestApprover[];
    Description?: string | redacted.Redacted<string>;
    Arn: string;
    UpdateActions?: UpdateAction[];
}
export interface UpdateApprovalTeamResponse {
    VersionId?: string;
}
export type CancelSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels an approval session. For more information, see Session in the *Multi-party approval User Guide*.
 */
export declare const cancelSession: API.OperationMethod<CancelSessionRequest, CancelSessionResponse, CancelSessionError, Credentials | HttpClient.HttpClient>;
export type CreateApprovalTeamError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new approval team. For more information, see Approval team in the *Multi-party approval User Guide*.
 */
export declare const createApprovalTeam: API.OperationMethod<CreateApprovalTeamRequest, CreateApprovalTeamResponse, CreateApprovalTeamError, Credentials | HttpClient.HttpClient>;
export type CreateIdentitySourceError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new identity source. For more information, see Identity Source in the *Multi-party approval User Guide*.
 */
export declare const createIdentitySource: API.OperationMethod<CreateIdentitySourceRequest, CreateIdentitySourceResponse, CreateIdentitySourceError, Credentials | HttpClient.HttpClient>;
export type DeleteIdentitySourceError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an identity source. For more information, see Identity Source in the *Multi-party approval User Guide*.
 */
export declare const deleteIdentitySource: API.OperationMethod<DeleteIdentitySourceRequest, DeleteIdentitySourceResponse, DeleteIdentitySourceError, Credentials | HttpClient.HttpClient>;
export type DeleteInactiveApprovalTeamVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an inactive approval team. For more information, see Team health in the *Multi-party approval User Guide*.
 *
 * You can also use this operation to delete a team draft. For more information, see Interacting with drafts in the *Multi-party approval User Guide*.
 */
export declare const deleteInactiveApprovalTeamVersion: API.OperationMethod<DeleteInactiveApprovalTeamVersionRequest, DeleteInactiveApprovalTeamVersionResponse, DeleteInactiveApprovalTeamVersionError, Credentials | HttpClient.HttpClient>;
export type GetApprovalTeamError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details for an approval team.
 */
export declare const getApprovalTeam: API.OperationMethod<GetApprovalTeamRequest, GetApprovalTeamResponse, GetApprovalTeamError, Credentials | HttpClient.HttpClient>;
export type GetIdentitySourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details for an identity source. For more information, see Identity Source in the *Multi-party approval User Guide*.
 */
export declare const getIdentitySource: API.OperationMethod<GetIdentitySourceRequest, GetIdentitySourceResponse, GetIdentitySourceError, Credentials | HttpClient.HttpClient>;
export type GetPolicyVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details for the version of a policy. Policies define the permissions for team resources.
 */
export declare const getPolicyVersion: API.OperationMethod<GetPolicyVersionRequest, GetPolicyVersionResponse, GetPolicyVersionError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDeniedException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details about a policy for a resource.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetSessionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details for an approval session. For more information, see Session in the *Multi-party approval User Guide*.
 */
export declare const getSession: API.OperationMethod<GetSessionRequest, GetSessionResponse, GetSessionError, Credentials | HttpClient.HttpClient>;
export type ListApprovalTeamsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of approval teams.
 */
export declare const listApprovalTeams: API.PaginatedOperationMethod<ListApprovalTeamsRequest, ListApprovalTeamsResponse, ListApprovalTeamsError, Credentials | HttpClient.HttpClient, ListApprovalTeamsResponseApprovalTeam>;
export type ListIdentitySourcesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of identity sources. For more information, see Identity Source in the *Multi-party approval User Guide*.
 */
export declare const listIdentitySources: API.PaginatedOperationMethod<ListIdentitySourcesRequest, ListIdentitySourcesResponse, ListIdentitySourcesError, Credentials | HttpClient.HttpClient, IdentitySourceForList>;
export type ListPoliciesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of policies. Policies define the permissions for team resources.
 */
export declare const listPolicies: API.PaginatedOperationMethod<ListPoliciesRequest, ListPoliciesResponse, ListPoliciesError, Credentials | HttpClient.HttpClient, Policy>;
export type ListPolicyVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the versions for policies. Policies define the permissions for team resources.
 */
export declare const listPolicyVersions: API.PaginatedOperationMethod<ListPolicyVersionsRequest, ListPolicyVersionsResponse, ListPolicyVersionsError, Credentials | HttpClient.HttpClient, PolicyVersionSummary>;
export type ListResourcePoliciesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of policies for a resource.
 */
export declare const listResourcePolicies: API.PaginatedOperationMethod<ListResourcePoliciesRequest, ListResourcePoliciesResponse, ListResourcePoliciesError, Credentials | HttpClient.HttpClient, ListResourcePoliciesResponseResourcePolicy>;
export type ListSessionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of approval sessions. For more information, see Session in the *Multi-party approval User Guide*.
 */
export declare const listSessions: API.PaginatedOperationMethod<ListSessionsRequest, ListSessionsResponse, ListSessionsError, Credentials | HttpClient.HttpClient, ListSessionsResponseSession>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartActiveApprovalTeamDeletionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the deletion process for an active approval team.
 *
 * **Deletions require team approval**
 *
 * Requests to delete an active team must be approved by the team.
 */
export declare const startActiveApprovalTeamDeletion: API.OperationMethod<StartActiveApprovalTeamDeletionRequest, StartActiveApprovalTeamDeletionResponse, StartActiveApprovalTeamDeletionError, Credentials | HttpClient.HttpClient>;
export type StartApprovalTeamBaselineError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a baseline session for specified approvers on an `ACTIVE` approval team.
 */
export declare const startApprovalTeamBaseline: API.OperationMethod<StartApprovalTeamBaselineRequest, StartApprovalTeamBaselineResponse, StartApprovalTeamBaselineError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates or updates a resource tag. Each tag is a label consisting of a user-defined key and value. Tags can help you manage, identify, organize, search for, and filter resources.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a resource tag. Each tag is a label consisting of a user-defined key and value. Tags can help you manage, identify, organize, search for, and filter resources.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApprovalTeamError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an approval team. You can request to update the team description, approval threshold, and approvers in the team.
 *
 * **Updates require team approval**
 *
 * Updates to an active team must be approved by the team.
 */
export declare const updateApprovalTeam: API.OperationMethod<UpdateApprovalTeamRequest, UpdateApprovalTeamResponse, UpdateApprovalTeamError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=mpa.d.ts.map