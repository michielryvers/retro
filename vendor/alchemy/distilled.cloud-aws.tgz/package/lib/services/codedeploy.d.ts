import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AlarmsLimitExceededException_base: S.TaggedErrorClass<"AlarmsLimitExceededException", {
    readonly message: any;
}>;
export declare class AlarmsLimitExceededException extends /*@__PURE__*/ AlarmsLimitExceededException_base {
}
declare const ApplicationAlreadyExistsException_base: S.TaggedErrorClass<"ApplicationAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ApplicationAlreadyExistsException extends /*@__PURE__*/ ApplicationAlreadyExistsException_base {
}
declare const ApplicationDoesNotExistException_base: S.TaggedErrorClass<"ApplicationDoesNotExistException", {
    readonly message: any;
}>;
export declare class ApplicationDoesNotExistException extends /*@__PURE__*/ ApplicationDoesNotExistException_base {
}
declare const ApplicationLimitExceededException_base: S.TaggedErrorClass<"ApplicationLimitExceededException", {
    readonly message: any;
}>;
export declare class ApplicationLimitExceededException extends /*@__PURE__*/ ApplicationLimitExceededException_base {
}
declare const ApplicationNameRequiredException_base: S.TaggedErrorClass<"ApplicationNameRequiredException", {
    readonly message: any;
}>;
export declare class ApplicationNameRequiredException extends /*@__PURE__*/ ApplicationNameRequiredException_base {
}
declare const ArnNotSupportedException_base: S.TaggedErrorClass<"ArnNotSupportedException", {
    readonly message: any;
}>;
export declare class ArnNotSupportedException extends /*@__PURE__*/ ArnNotSupportedException_base {
}
declare const BatchLimitExceededException_base: S.TaggedErrorClass<"BatchLimitExceededException", {
    readonly message: any;
}>;
export declare class BatchLimitExceededException extends /*@__PURE__*/ BatchLimitExceededException_base {
}
declare const BucketNameFilterRequiredException_base: S.TaggedErrorClass<"BucketNameFilterRequiredException", {
    readonly message: any;
}>;
export declare class BucketNameFilterRequiredException extends /*@__PURE__*/ BucketNameFilterRequiredException_base {
}
declare const DeploymentAlreadyCompletedException_base: S.TaggedErrorClass<"DeploymentAlreadyCompletedException", {
    readonly message: any;
}>;
export declare class DeploymentAlreadyCompletedException extends /*@__PURE__*/ DeploymentAlreadyCompletedException_base {
}
declare const DeploymentConfigAlreadyExistsException_base: S.TaggedErrorClass<"DeploymentConfigAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DeploymentConfigAlreadyExistsException extends /*@__PURE__*/ DeploymentConfigAlreadyExistsException_base {
}
declare const DeploymentConfigDoesNotExistException_base: S.TaggedErrorClass<"DeploymentConfigDoesNotExistException", {
    readonly message: any;
}>;
export declare class DeploymentConfigDoesNotExistException extends /*@__PURE__*/ DeploymentConfigDoesNotExistException_base {
}
declare const DeploymentConfigInUseException_base: S.TaggedErrorClass<"DeploymentConfigInUseException", {
    readonly message: any;
}>;
export declare class DeploymentConfigInUseException extends /*@__PURE__*/ DeploymentConfigInUseException_base {
}
declare const DeploymentConfigLimitExceededException_base: S.TaggedErrorClass<"DeploymentConfigLimitExceededException", {
    readonly message: any;
}>;
export declare class DeploymentConfigLimitExceededException extends /*@__PURE__*/ DeploymentConfigLimitExceededException_base {
}
declare const DeploymentConfigNameRequiredException_base: S.TaggedErrorClass<"DeploymentConfigNameRequiredException", {
    readonly message: any;
}>;
export declare class DeploymentConfigNameRequiredException extends /*@__PURE__*/ DeploymentConfigNameRequiredException_base {
}
declare const DeploymentDoesNotExistException_base: S.TaggedErrorClass<"DeploymentDoesNotExistException", {
    readonly message: any;
}>;
export declare class DeploymentDoesNotExistException extends /*@__PURE__*/ DeploymentDoesNotExistException_base {
}
declare const DeploymentGroupAlreadyExistsException_base: S.TaggedErrorClass<"DeploymentGroupAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DeploymentGroupAlreadyExistsException extends /*@__PURE__*/ DeploymentGroupAlreadyExistsException_base {
}
declare const DeploymentGroupDoesNotExistException_base: S.TaggedErrorClass<"DeploymentGroupDoesNotExistException", {
    readonly message: any;
}>;
export declare class DeploymentGroupDoesNotExistException extends /*@__PURE__*/ DeploymentGroupDoesNotExistException_base {
}
declare const DeploymentGroupLimitExceededException_base: S.TaggedErrorClass<"DeploymentGroupLimitExceededException", {
    readonly message: any;
}>;
export declare class DeploymentGroupLimitExceededException extends /*@__PURE__*/ DeploymentGroupLimitExceededException_base {
}
declare const DeploymentGroupNameRequiredException_base: S.TaggedErrorClass<"DeploymentGroupNameRequiredException", {
    readonly message: any;
}>;
export declare class DeploymentGroupNameRequiredException extends /*@__PURE__*/ DeploymentGroupNameRequiredException_base {
}
declare const DeploymentIdRequiredException_base: S.TaggedErrorClass<"DeploymentIdRequiredException", {
    readonly message: any;
}>;
export declare class DeploymentIdRequiredException extends /*@__PURE__*/ DeploymentIdRequiredException_base {
}
declare const DeploymentIsNotInReadyStateException_base: S.TaggedErrorClass<"DeploymentIsNotInReadyStateException", {
    readonly message: any;
}>;
export declare class DeploymentIsNotInReadyStateException extends /*@__PURE__*/ DeploymentIsNotInReadyStateException_base {
}
declare const DeploymentLimitExceededException_base: S.TaggedErrorClass<"DeploymentLimitExceededException", {
    readonly message: any;
}>;
export declare class DeploymentLimitExceededException extends /*@__PURE__*/ DeploymentLimitExceededException_base {
}
declare const DeploymentNotStartedException_base: S.TaggedErrorClass<"DeploymentNotStartedException", {
    readonly message: any;
}>;
export declare class DeploymentNotStartedException extends /*@__PURE__*/ DeploymentNotStartedException_base {
}
declare const DeploymentTargetDoesNotExistException_base: S.TaggedErrorClass<"DeploymentTargetDoesNotExistException", {
    readonly message: any;
}>;
export declare class DeploymentTargetDoesNotExistException extends /*@__PURE__*/ DeploymentTargetDoesNotExistException_base {
}
declare const DeploymentTargetIdRequiredException_base: S.TaggedErrorClass<"DeploymentTargetIdRequiredException", {
    readonly message: any;
}>;
export declare class DeploymentTargetIdRequiredException extends /*@__PURE__*/ DeploymentTargetIdRequiredException_base {
}
declare const DeploymentTargetListSizeExceededException_base: S.TaggedErrorClass<"DeploymentTargetListSizeExceededException", {
    readonly message: any;
}>;
export declare class DeploymentTargetListSizeExceededException extends /*@__PURE__*/ DeploymentTargetListSizeExceededException_base {
}
declare const DescriptionTooLongException_base: S.TaggedErrorClass<"DescriptionTooLongException", {
    readonly message: any;
}>;
export declare class DescriptionTooLongException extends /*@__PURE__*/ DescriptionTooLongException_base {
}
declare const ECSServiceMappingLimitExceededException_base: S.TaggedErrorClass<"ECSServiceMappingLimitExceededException", {
    readonly message: any;
}>;
export declare class ECSServiceMappingLimitExceededException extends /*@__PURE__*/ ECSServiceMappingLimitExceededException_base {
}
declare const GitHubAccountTokenDoesNotExistException_base: S.TaggedErrorClass<"GitHubAccountTokenDoesNotExistException", {
    readonly message: any;
}>;
export declare class GitHubAccountTokenDoesNotExistException extends /*@__PURE__*/ GitHubAccountTokenDoesNotExistException_base {
}
declare const GitHubAccountTokenNameRequiredException_base: S.TaggedErrorClass<"GitHubAccountTokenNameRequiredException", {
    readonly message: any;
}>;
export declare class GitHubAccountTokenNameRequiredException extends /*@__PURE__*/ GitHubAccountTokenNameRequiredException_base {
}
declare const IamArnRequiredException_base: S.TaggedErrorClass<"IamArnRequiredException", {
    readonly message: any;
}>;
export declare class IamArnRequiredException extends /*@__PURE__*/ IamArnRequiredException_base {
}
declare const IamSessionArnAlreadyRegisteredException_base: S.TaggedErrorClass<"IamSessionArnAlreadyRegisteredException", {
    readonly message: any;
}>;
export declare class IamSessionArnAlreadyRegisteredException extends /*@__PURE__*/ IamSessionArnAlreadyRegisteredException_base {
}
declare const IamUserArnAlreadyRegisteredException_base: S.TaggedErrorClass<"IamUserArnAlreadyRegisteredException", {
    readonly message: any;
}>;
export declare class IamUserArnAlreadyRegisteredException extends /*@__PURE__*/ IamUserArnAlreadyRegisteredException_base {
}
declare const IamUserArnRequiredException_base: S.TaggedErrorClass<"IamUserArnRequiredException", {
    readonly message: any;
}>;
export declare class IamUserArnRequiredException extends /*@__PURE__*/ IamUserArnRequiredException_base {
}
declare const InstanceDoesNotExistException_base: S.TaggedErrorClass<"InstanceDoesNotExistException", {
    readonly message: any;
}>;
export declare class InstanceDoesNotExistException extends /*@__PURE__*/ InstanceDoesNotExistException_base {
}
declare const InstanceIdRequiredException_base: S.TaggedErrorClass<"InstanceIdRequiredException", {
    readonly message: any;
}>;
export declare class InstanceIdRequiredException extends /*@__PURE__*/ InstanceIdRequiredException_base {
}
declare const InstanceLimitExceededException_base: S.TaggedErrorClass<"InstanceLimitExceededException", {
    readonly message: any;
}>;
export declare class InstanceLimitExceededException extends /*@__PURE__*/ InstanceLimitExceededException_base {
}
declare const InstanceNameAlreadyRegisteredException_base: S.TaggedErrorClass<"InstanceNameAlreadyRegisteredException", {
    readonly message: any;
}>;
export declare class InstanceNameAlreadyRegisteredException extends /*@__PURE__*/ InstanceNameAlreadyRegisteredException_base {
}
declare const InstanceNameRequiredException_base: S.TaggedErrorClass<"InstanceNameRequiredException", {
    readonly message: any;
}>;
export declare class InstanceNameRequiredException extends /*@__PURE__*/ InstanceNameRequiredException_base {
}
declare const InstanceNotRegisteredException_base: S.TaggedErrorClass<"InstanceNotRegisteredException", {
    readonly message: any;
}>;
export declare class InstanceNotRegisteredException extends /*@__PURE__*/ InstanceNotRegisteredException_base {
}
declare const InvalidAlarmConfigException_base: S.TaggedErrorClass<"InvalidAlarmConfigException", {
    readonly message: any;
}>;
export declare class InvalidAlarmConfigException extends /*@__PURE__*/ InvalidAlarmConfigException_base {
}
declare const InvalidApplicationNameException_base: S.TaggedErrorClass<"InvalidApplicationNameException", {
    readonly message: any;
}>;
export declare class InvalidApplicationNameException extends /*@__PURE__*/ InvalidApplicationNameException_base {
}
declare const InvalidArnException_base: S.TaggedErrorClass<"InvalidArnException", {
    readonly message: any;
}>;
export declare class InvalidArnException extends /*@__PURE__*/ InvalidArnException_base {
}
declare const InvalidAutoRollbackConfigException_base: S.TaggedErrorClass<"InvalidAutoRollbackConfigException", {
    readonly message: any;
}>;
export declare class InvalidAutoRollbackConfigException extends /*@__PURE__*/ InvalidAutoRollbackConfigException_base {
}
declare const InvalidAutoScalingGroupException_base: S.TaggedErrorClass<"InvalidAutoScalingGroupException", {
    readonly message: any;
}>;
export declare class InvalidAutoScalingGroupException extends /*@__PURE__*/ InvalidAutoScalingGroupException_base {
}
declare const InvalidBlueGreenDeploymentConfigurationException_base: S.TaggedErrorClass<"InvalidBlueGreenDeploymentConfigurationException", {
    readonly message: any;
}>;
export declare class InvalidBlueGreenDeploymentConfigurationException extends /*@__PURE__*/ InvalidBlueGreenDeploymentConfigurationException_base {
}
declare const InvalidBucketNameFilterException_base: S.TaggedErrorClass<"InvalidBucketNameFilterException", {
    readonly message: any;
}>;
export declare class InvalidBucketNameFilterException extends /*@__PURE__*/ InvalidBucketNameFilterException_base {
}
declare const InvalidComputePlatformException_base: S.TaggedErrorClass<"InvalidComputePlatformException", {
    readonly message: any;
}>;
export declare class InvalidComputePlatformException extends /*@__PURE__*/ InvalidComputePlatformException_base {
}
declare const InvalidDeployedStateFilterException_base: S.TaggedErrorClass<"InvalidDeployedStateFilterException", {
    readonly message: any;
}>;
export declare class InvalidDeployedStateFilterException extends /*@__PURE__*/ InvalidDeployedStateFilterException_base {
}
declare const InvalidDeploymentConfigNameException_base: S.TaggedErrorClass<"InvalidDeploymentConfigNameException", {
    readonly message: any;
}>;
export declare class InvalidDeploymentConfigNameException extends /*@__PURE__*/ InvalidDeploymentConfigNameException_base {
}
declare const InvalidDeploymentGroupNameException_base: S.TaggedErrorClass<"InvalidDeploymentGroupNameException", {
    readonly message: any;
}>;
export declare class InvalidDeploymentGroupNameException extends /*@__PURE__*/ InvalidDeploymentGroupNameException_base {
}
declare const InvalidDeploymentIdException_base: S.TaggedErrorClass<"InvalidDeploymentIdException", {
    readonly message: any;
}>;
export declare class InvalidDeploymentIdException extends /*@__PURE__*/ InvalidDeploymentIdException_base {
}
declare const InvalidDeploymentInstanceTypeException_base: S.TaggedErrorClass<"InvalidDeploymentInstanceTypeException", {
    readonly message: any;
}>;
export declare class InvalidDeploymentInstanceTypeException extends /*@__PURE__*/ InvalidDeploymentInstanceTypeException_base {
}
declare const InvalidDeploymentStatusException_base: S.TaggedErrorClass<"InvalidDeploymentStatusException", {
    readonly message: any;
}>;
export declare class InvalidDeploymentStatusException extends /*@__PURE__*/ InvalidDeploymentStatusException_base {
}
declare const InvalidDeploymentStyleException_base: S.TaggedErrorClass<"InvalidDeploymentStyleException", {
    readonly message: any;
}>;
export declare class InvalidDeploymentStyleException extends /*@__PURE__*/ InvalidDeploymentStyleException_base {
}
declare const InvalidDeploymentTargetIdException_base: S.TaggedErrorClass<"InvalidDeploymentTargetIdException", {
    readonly message: any;
}>;
export declare class InvalidDeploymentTargetIdException extends /*@__PURE__*/ InvalidDeploymentTargetIdException_base {
}
declare const InvalidDeploymentWaitTypeException_base: S.TaggedErrorClass<"InvalidDeploymentWaitTypeException", {
    readonly message: any;
}>;
export declare class InvalidDeploymentWaitTypeException extends /*@__PURE__*/ InvalidDeploymentWaitTypeException_base {
}
declare const InvalidEC2TagCombinationException_base: S.TaggedErrorClass<"InvalidEC2TagCombinationException", {
    readonly message: any;
}>;
export declare class InvalidEC2TagCombinationException extends /*@__PURE__*/ InvalidEC2TagCombinationException_base {
}
declare const InvalidEC2TagException_base: S.TaggedErrorClass<"InvalidEC2TagException", {
    readonly message: any;
}>;
export declare class InvalidEC2TagException extends /*@__PURE__*/ InvalidEC2TagException_base {
}
declare const InvalidECSServiceException_base: S.TaggedErrorClass<"InvalidECSServiceException", {
    readonly message: any;
}>;
export declare class InvalidECSServiceException extends /*@__PURE__*/ InvalidECSServiceException_base {
}
declare const InvalidExternalIdException_base: S.TaggedErrorClass<"InvalidExternalIdException", {
    readonly message: any;
}>;
export declare class InvalidExternalIdException extends /*@__PURE__*/ InvalidExternalIdException_base {
}
declare const InvalidFileExistsBehaviorException_base: S.TaggedErrorClass<"InvalidFileExistsBehaviorException", {
    readonly message: any;
}>;
export declare class InvalidFileExistsBehaviorException extends /*@__PURE__*/ InvalidFileExistsBehaviorException_base {
}
declare const InvalidGitHubAccountTokenException_base: S.TaggedErrorClass<"InvalidGitHubAccountTokenException", {
    readonly message: any;
}>;
export declare class InvalidGitHubAccountTokenException extends /*@__PURE__*/ InvalidGitHubAccountTokenException_base {
}
declare const InvalidGitHubAccountTokenNameException_base: S.TaggedErrorClass<"InvalidGitHubAccountTokenNameException", {
    readonly message: any;
}>;
export declare class InvalidGitHubAccountTokenNameException extends /*@__PURE__*/ InvalidGitHubAccountTokenNameException_base {
}
declare const InvalidIamSessionArnException_base: S.TaggedErrorClass<"InvalidIamSessionArnException", {
    readonly message: any;
}>;
export declare class InvalidIamSessionArnException extends /*@__PURE__*/ InvalidIamSessionArnException_base {
}
declare const InvalidIamUserArnException_base: S.TaggedErrorClass<"InvalidIamUserArnException", {
    readonly message: any;
}>;
export declare class InvalidIamUserArnException extends /*@__PURE__*/ InvalidIamUserArnException_base {
}
declare const InvalidIgnoreApplicationStopFailuresValueException_base: S.TaggedErrorClass<"InvalidIgnoreApplicationStopFailuresValueException", {
    readonly message: any;
}>;
export declare class InvalidIgnoreApplicationStopFailuresValueException extends /*@__PURE__*/ InvalidIgnoreApplicationStopFailuresValueException_base {
}
declare const InvalidInputException_base: S.TaggedErrorClass<"InvalidInputException", {
    readonly message: any;
}>;
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const InvalidInstanceNameException_base: S.TaggedErrorClass<"InvalidInstanceNameException", {
    readonly message: any;
}>;
export declare class InvalidInstanceNameException extends /*@__PURE__*/ InvalidInstanceNameException_base {
}
declare const InvalidInstanceStatusException_base: S.TaggedErrorClass<"InvalidInstanceStatusException", {
    readonly message: any;
}>;
export declare class InvalidInstanceStatusException extends /*@__PURE__*/ InvalidInstanceStatusException_base {
}
declare const InvalidInstanceTypeException_base: S.TaggedErrorClass<"InvalidInstanceTypeException", {
    readonly message: any;
}>;
export declare class InvalidInstanceTypeException extends /*@__PURE__*/ InvalidInstanceTypeException_base {
}
declare const InvalidKeyPrefixFilterException_base: S.TaggedErrorClass<"InvalidKeyPrefixFilterException", {
    readonly message: any;
}>;
export declare class InvalidKeyPrefixFilterException extends /*@__PURE__*/ InvalidKeyPrefixFilterException_base {
}
declare const InvalidLifecycleEventHookExecutionIdException_base: S.TaggedErrorClass<"InvalidLifecycleEventHookExecutionIdException", {
    readonly message: any;
}>;
export declare class InvalidLifecycleEventHookExecutionIdException extends /*@__PURE__*/ InvalidLifecycleEventHookExecutionIdException_base {
}
declare const InvalidLifecycleEventHookExecutionStatusException_base: S.TaggedErrorClass<"InvalidLifecycleEventHookExecutionStatusException", {
    readonly message: any;
}>;
export declare class InvalidLifecycleEventHookExecutionStatusException extends /*@__PURE__*/ InvalidLifecycleEventHookExecutionStatusException_base {
}
declare const InvalidLoadBalancerInfoException_base: S.TaggedErrorClass<"InvalidLoadBalancerInfoException", {
    readonly message: any;
}>;
export declare class InvalidLoadBalancerInfoException extends /*@__PURE__*/ InvalidLoadBalancerInfoException_base {
}
declare const InvalidMinimumHealthyHostValueException_base: S.TaggedErrorClass<"InvalidMinimumHealthyHostValueException", {
    readonly message: any;
}>;
export declare class InvalidMinimumHealthyHostValueException extends /*@__PURE__*/ InvalidMinimumHealthyHostValueException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}>;
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidOnPremisesTagCombinationException_base: S.TaggedErrorClass<"InvalidOnPremisesTagCombinationException", {
    readonly message: any;
}>;
export declare class InvalidOnPremisesTagCombinationException extends /*@__PURE__*/ InvalidOnPremisesTagCombinationException_base {
}
declare const InvalidOperationException_base: S.TaggedErrorClass<"InvalidOperationException", {
    readonly message: any;
}>;
export declare class InvalidOperationException extends /*@__PURE__*/ InvalidOperationException_base {
}
declare const InvalidRegistrationStatusException_base: S.TaggedErrorClass<"InvalidRegistrationStatusException", {
    readonly message: any;
}>;
export declare class InvalidRegistrationStatusException extends /*@__PURE__*/ InvalidRegistrationStatusException_base {
}
declare const InvalidRevisionException_base: S.TaggedErrorClass<"InvalidRevisionException", {
    readonly message: any;
}>;
export declare class InvalidRevisionException extends /*@__PURE__*/ InvalidRevisionException_base {
}
declare const InvalidRoleException_base: S.TaggedErrorClass<"InvalidRoleException", {
    readonly message: any;
}>;
export declare class InvalidRoleException extends /*@__PURE__*/ InvalidRoleException_base {
}
declare const InvalidSortByException_base: S.TaggedErrorClass<"InvalidSortByException", {
    readonly message: any;
}>;
export declare class InvalidSortByException extends /*@__PURE__*/ InvalidSortByException_base {
}
declare const InvalidSortOrderException_base: S.TaggedErrorClass<"InvalidSortOrderException", {
    readonly message: any;
}>;
export declare class InvalidSortOrderException extends /*@__PURE__*/ InvalidSortOrderException_base {
}
declare const InvalidTagException_base: S.TaggedErrorClass<"InvalidTagException", {
    readonly message: any;
}>;
export declare class InvalidTagException extends /*@__PURE__*/ InvalidTagException_base {
}
declare const InvalidTagFilterException_base: S.TaggedErrorClass<"InvalidTagFilterException", {
    readonly message: any;
}>;
export declare class InvalidTagFilterException extends /*@__PURE__*/ InvalidTagFilterException_base {
}
declare const InvalidTagsToAddException_base: S.TaggedErrorClass<"InvalidTagsToAddException", {
    readonly message: any;
}>;
export declare class InvalidTagsToAddException extends /*@__PURE__*/ InvalidTagsToAddException_base {
}
declare const InvalidTargetFilterNameException_base: S.TaggedErrorClass<"InvalidTargetFilterNameException", {
    readonly message: any;
}>;
export declare class InvalidTargetFilterNameException extends /*@__PURE__*/ InvalidTargetFilterNameException_base {
}
declare const InvalidTargetGroupPairException_base: S.TaggedErrorClass<"InvalidTargetGroupPairException", {
    readonly message: any;
}>;
export declare class InvalidTargetGroupPairException extends /*@__PURE__*/ InvalidTargetGroupPairException_base {
}
declare const InvalidTargetInstancesException_base: S.TaggedErrorClass<"InvalidTargetInstancesException", {
    readonly message: any;
}>;
export declare class InvalidTargetInstancesException extends /*@__PURE__*/ InvalidTargetInstancesException_base {
}
declare const InvalidTimeRangeException_base: S.TaggedErrorClass<"InvalidTimeRangeException", {
    readonly message: any;
}>;
export declare class InvalidTimeRangeException extends /*@__PURE__*/ InvalidTimeRangeException_base {
}
declare const InvalidTrafficRoutingConfigurationException_base: S.TaggedErrorClass<"InvalidTrafficRoutingConfigurationException", {
    readonly message: any;
}>;
export declare class InvalidTrafficRoutingConfigurationException extends /*@__PURE__*/ InvalidTrafficRoutingConfigurationException_base {
}
declare const InvalidTriggerConfigException_base: S.TaggedErrorClass<"InvalidTriggerConfigException", {
    readonly message: any;
}>;
export declare class InvalidTriggerConfigException extends /*@__PURE__*/ InvalidTriggerConfigException_base {
}
declare const InvalidUpdateOutdatedInstancesOnlyValueException_base: S.TaggedErrorClass<"InvalidUpdateOutdatedInstancesOnlyValueException", {
    readonly message: any;
}>;
export declare class InvalidUpdateOutdatedInstancesOnlyValueException extends /*@__PURE__*/ InvalidUpdateOutdatedInstancesOnlyValueException_base {
}
declare const InvalidZonalDeploymentConfigurationException_base: S.TaggedErrorClass<"InvalidZonalDeploymentConfigurationException", {
    readonly message: any;
}>;
export declare class InvalidZonalDeploymentConfigurationException extends /*@__PURE__*/ InvalidZonalDeploymentConfigurationException_base {
}
declare const LifecycleEventAlreadyCompletedException_base: S.TaggedErrorClass<"LifecycleEventAlreadyCompletedException", {
    readonly message: any;
}>;
export declare class LifecycleEventAlreadyCompletedException extends /*@__PURE__*/ LifecycleEventAlreadyCompletedException_base {
}
declare const LifecycleHookLimitExceededException_base: S.TaggedErrorClass<"LifecycleHookLimitExceededException", {
    readonly message: any;
}>;
export declare class LifecycleHookLimitExceededException extends /*@__PURE__*/ LifecycleHookLimitExceededException_base {
}
declare const MultipleIamArnsProvidedException_base: S.TaggedErrorClass<"MultipleIamArnsProvidedException", {
    readonly message: any;
}>;
export declare class MultipleIamArnsProvidedException extends /*@__PURE__*/ MultipleIamArnsProvidedException_base {
}
declare const OperationNotSupportedException_base: S.TaggedErrorClass<"OperationNotSupportedException", {
    readonly message: any;
}>;
export declare class OperationNotSupportedException extends /*@__PURE__*/ OperationNotSupportedException_base {
}
declare const ResourceArnRequiredException_base: S.TaggedErrorClass<"ResourceArnRequiredException", {
    readonly message: any;
}>;
export declare class ResourceArnRequiredException extends /*@__PURE__*/ ResourceArnRequiredException_base {
}
declare const ResourceValidationException_base: S.TaggedErrorClass<"ResourceValidationException", {
    readonly message: any;
}>;
export declare class ResourceValidationException extends /*@__PURE__*/ ResourceValidationException_base {
}
declare const RevisionDoesNotExistException_base: S.TaggedErrorClass<"RevisionDoesNotExistException", {
    readonly message: any;
}>;
export declare class RevisionDoesNotExistException extends /*@__PURE__*/ RevisionDoesNotExistException_base {
}
declare const RevisionRequiredException_base: S.TaggedErrorClass<"RevisionRequiredException", {
    readonly message: any;
}>;
export declare class RevisionRequiredException extends /*@__PURE__*/ RevisionRequiredException_base {
}
declare const RoleRequiredException_base: S.TaggedErrorClass<"RoleRequiredException", {
    readonly message: any;
}>;
export declare class RoleRequiredException extends /*@__PURE__*/ RoleRequiredException_base {
}
declare const TagLimitExceededException_base: S.TaggedErrorClass<"TagLimitExceededException", {
    readonly message: any;
}>;
export declare class TagLimitExceededException extends /*@__PURE__*/ TagLimitExceededException_base {
}
declare const TagRequiredException_base: S.TaggedErrorClass<"TagRequiredException", {
    readonly message: any;
}>;
export declare class TagRequiredException extends /*@__PURE__*/ TagRequiredException_base {
}
declare const TagSetListLimitExceededException_base: S.TaggedErrorClass<"TagSetListLimitExceededException", {
    readonly message: any;
}>;
export declare class TagSetListLimitExceededException extends /*@__PURE__*/ TagSetListLimitExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}>;
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TriggerTargetsLimitExceededException_base: S.TaggedErrorClass<"TriggerTargetsLimitExceededException", {
    readonly message: any;
}>;
export declare class TriggerTargetsLimitExceededException extends /*@__PURE__*/ TriggerTargetsLimitExceededException_base {
}
declare const UnsupportedActionForDeploymentTypeException_base: S.TaggedErrorClass<"UnsupportedActionForDeploymentTypeException", {
    readonly message: any;
}>;
export declare class UnsupportedActionForDeploymentTypeException extends /*@__PURE__*/ UnsupportedActionForDeploymentTypeException_base {
}
export type Key = string;
export type Value = string;
export interface Tag {
    Key?: string;
    Value?: string;
}
export type TagList = Tag[];
export type InstanceName = string;
export type InstanceNameList = string[];
export interface AddTagsToOnPremisesInstancesInput {
    tags: Tag[];
    instanceNames: string[];
}
export interface AddTagsToOnPremisesInstancesResponse {
}
export type ApplicationName = string;
export type RevisionLocationType = "S3" | "GitHub" | "String" | "AppSpecContent" | (string & {});
export type S3Bucket = string;
export type S3Key = string;
export type BundleType = "tar" | "tgz" | "zip" | "YAML" | "JSON" | (string & {});
export type VersionId = string;
export type ETag = string;
export interface S3Location {
    bucket?: string;
    key?: string;
    bundleType?: BundleType;
    version?: string;
    eTag?: string;
}
export type Repository = string;
export type CommitId = string;
export interface GitHubLocation {
    repository?: string;
    commitId?: string;
}
export type RawStringContent = string;
export type RawStringSha256 = string;
export interface RawString {
    content?: string;
    sha256?: string;
}
export interface AppSpecContent {
    content?: string;
    sha256?: string;
}
export interface RevisionLocation {
    revisionType?: RevisionLocationType;
    s3Location?: S3Location;
    gitHubLocation?: GitHubLocation;
    string?: RawString;
    appSpecContent?: AppSpecContent;
}
export type RevisionLocationList = RevisionLocation[];
export interface BatchGetApplicationRevisionsInput {
    applicationName: string;
    revisions: RevisionLocation[];
}
export type ErrorMessage = string;
export type Description = string;
export type DeploymentGroupName = string;
export type DeploymentGroupsList = string[];
export interface GenericRevisionInfo {
    description?: string;
    deploymentGroups?: string[];
    firstUsedTime?: Date;
    lastUsedTime?: Date;
    registerTime?: Date;
}
export interface RevisionInfo {
    revisionLocation?: RevisionLocation;
    genericRevisionInfo?: GenericRevisionInfo;
}
export type RevisionInfoList = RevisionInfo[];
export interface BatchGetApplicationRevisionsOutput {
    applicationName?: string;
    errorMessage?: string;
    revisions?: RevisionInfo[];
}
export type ApplicationsList = string[];
export interface BatchGetApplicationsInput {
    applicationNames: string[];
}
export type ApplicationId = string;
export type GitHubAccountTokenName = string;
export type ComputePlatform = "Server" | "Lambda" | "ECS" | (string & {});
export interface ApplicationInfo {
    applicationId?: string;
    applicationName?: string;
    createTime?: Date;
    linkedToGitHub?: boolean;
    gitHubAccountName?: string;
    computePlatform?: ComputePlatform;
}
export type ApplicationsInfoList = ApplicationInfo[];
export interface BatchGetApplicationsOutput {
    applicationsInfo?: ApplicationInfo[];
}
export interface BatchGetDeploymentGroupsInput {
    applicationName: string;
    deploymentGroupNames: string[];
}
export type DeploymentGroupId = string;
export type DeploymentConfigName = string;
export type EC2TagFilterType = "KEY_ONLY" | "VALUE_ONLY" | "KEY_AND_VALUE" | (string & {});
export interface EC2TagFilter {
    Key?: string;
    Value?: string;
    Type?: EC2TagFilterType;
}
export type EC2TagFilterList = EC2TagFilter[];
export type TagFilterType = "KEY_ONLY" | "VALUE_ONLY" | "KEY_AND_VALUE" | (string & {});
export interface TagFilter {
    Key?: string;
    Value?: string;
    Type?: TagFilterType;
}
export type TagFilterList = TagFilter[];
export type AutoScalingGroupName = string;
export type AutoScalingGroupHook = string;
export interface AutoScalingGroup {
    name?: string;
    hook?: string;
    terminationHook?: string;
}
export type AutoScalingGroupList = AutoScalingGroup[];
export type Role = string;
export type TriggerName = string;
export type TriggerTargetArn = string;
export type TriggerEventType = "DeploymentStart" | "DeploymentSuccess" | "DeploymentFailure" | "DeploymentStop" | "DeploymentRollback" | "DeploymentReady" | "InstanceStart" | "InstanceSuccess" | "InstanceFailure" | "InstanceReady" | (string & {});
export type TriggerEventTypeList = TriggerEventType[];
export interface TriggerConfig {
    triggerName?: string;
    triggerTargetArn?: string;
    triggerEvents?: TriggerEventType[];
}
export type TriggerConfigList = TriggerConfig[];
export type AlarmName = string;
export interface Alarm {
    name?: string;
}
export type AlarmList = Alarm[];
export interface AlarmConfiguration {
    enabled?: boolean;
    ignorePollAlarmFailure?: boolean;
    alarms?: Alarm[];
}
export type AutoRollbackEvent = "DEPLOYMENT_FAILURE" | "DEPLOYMENT_STOP_ON_ALARM" | "DEPLOYMENT_STOP_ON_REQUEST" | (string & {});
export type AutoRollbackEventsList = AutoRollbackEvent[];
export interface AutoRollbackConfiguration {
    enabled?: boolean;
    events?: AutoRollbackEvent[];
}
export type DeploymentType = "IN_PLACE" | "BLUE_GREEN" | (string & {});
export type DeploymentOption = "WITH_TRAFFIC_CONTROL" | "WITHOUT_TRAFFIC_CONTROL" | (string & {});
export interface DeploymentStyle {
    deploymentType?: DeploymentType;
    deploymentOption?: DeploymentOption;
}
export type OutdatedInstancesStrategy = "UPDATE" | "IGNORE" | (string & {});
export type InstanceAction = "TERMINATE" | "KEEP_ALIVE" | (string & {});
export type Duration = number;
export interface BlueInstanceTerminationOption {
    action?: InstanceAction;
    terminationWaitTimeInMinutes?: number;
}
export type DeploymentReadyAction = "CONTINUE_DEPLOYMENT" | "STOP_DEPLOYMENT" | (string & {});
export interface DeploymentReadyOption {
    actionOnTimeout?: DeploymentReadyAction;
    waitTimeInMinutes?: number;
}
export type GreenFleetProvisioningAction = "DISCOVER_EXISTING" | "COPY_AUTO_SCALING_GROUP" | (string & {});
export interface GreenFleetProvisioningOption {
    action?: GreenFleetProvisioningAction;
}
export interface BlueGreenDeploymentConfiguration {
    terminateBlueInstancesOnDeploymentSuccess?: BlueInstanceTerminationOption;
    deploymentReadyOption?: DeploymentReadyOption;
    greenFleetProvisioningOption?: GreenFleetProvisioningOption;
}
export type ELBName = string;
export interface ELBInfo {
    name?: string;
}
export type ELBInfoList = ELBInfo[];
export type TargetGroupName = string;
export interface TargetGroupInfo {
    name?: string;
}
export type TargetGroupInfoList = TargetGroupInfo[];
export type ListenerArn = string;
export type ListenerArnList = string[];
export interface TrafficRoute {
    listenerArns?: string[];
}
export interface TargetGroupPairInfo {
    targetGroups?: TargetGroupInfo[];
    prodTrafficRoute?: TrafficRoute;
    testTrafficRoute?: TrafficRoute;
}
export type TargetGroupPairInfoList = TargetGroupPairInfo[];
export interface LoadBalancerInfo {
    elbInfoList?: ELBInfo[];
    targetGroupInfoList?: TargetGroupInfo[];
    targetGroupPairInfoList?: TargetGroupPairInfo[];
}
export type DeploymentId = string;
export type DeploymentStatus = "Created" | "Queued" | "InProgress" | "Baking" | "Succeeded" | "Failed" | "Stopped" | "Ready" | (string & {});
export interface LastDeploymentInfo {
    deploymentId?: string;
    status?: DeploymentStatus;
    endTime?: Date;
    createTime?: Date;
}
export type EC2TagSetList = EC2TagFilter[][];
export interface EC2TagSet {
    ec2TagSetList?: EC2TagFilter[][];
}
export type OnPremisesTagSetList = TagFilter[][];
export interface OnPremisesTagSet {
    onPremisesTagSetList?: TagFilter[][];
}
export type ECSServiceName = string;
export type ECSClusterName = string;
export interface ECSService {
    serviceName?: string;
    clusterName?: string;
}
export type ECSServiceList = ECSService[];
export interface DeploymentGroupInfo {
    applicationName?: string;
    deploymentGroupId?: string;
    deploymentGroupName?: string;
    deploymentConfigName?: string;
    ec2TagFilters?: EC2TagFilter[];
    onPremisesInstanceTagFilters?: TagFilter[];
    autoScalingGroups?: AutoScalingGroup[];
    serviceRoleArn?: string;
    targetRevision?: RevisionLocation;
    triggerConfigurations?: TriggerConfig[];
    alarmConfiguration?: AlarmConfiguration;
    autoRollbackConfiguration?: AutoRollbackConfiguration;
    deploymentStyle?: DeploymentStyle;
    outdatedInstancesStrategy?: OutdatedInstancesStrategy;
    blueGreenDeploymentConfiguration?: BlueGreenDeploymentConfiguration;
    loadBalancerInfo?: LoadBalancerInfo;
    lastSuccessfulDeployment?: LastDeploymentInfo;
    lastAttemptedDeployment?: LastDeploymentInfo;
    ec2TagSet?: EC2TagSet;
    onPremisesTagSet?: OnPremisesTagSet;
    computePlatform?: ComputePlatform;
    ecsServices?: ECSService[];
    terminationHookEnabled?: boolean;
}
export type DeploymentGroupInfoList = DeploymentGroupInfo[];
export interface BatchGetDeploymentGroupsOutput {
    deploymentGroupsInfo?: DeploymentGroupInfo[];
    errorMessage?: string;
}
export type InstanceId = string;
export type InstancesList = string[];
export interface BatchGetDeploymentInstancesInput {
    deploymentId: string;
    instanceIds: string[];
}
export type InstanceStatus = "Pending" | "InProgress" | "Succeeded" | "Failed" | "Skipped" | "Unknown" | "Ready" | (string & {});
export type LifecycleEventName = string;
export type LifecycleErrorCode = "Success" | "ScriptMissing" | "ScriptNotExecutable" | "ScriptTimedOut" | "ScriptFailed" | "UnknownError" | (string & {});
export type ScriptName = string;
export type LifecycleMessage = string;
export type LogTail = string;
export interface Diagnostics {
    errorCode?: LifecycleErrorCode;
    scriptName?: string;
    message?: string;
    logTail?: string;
}
export type LifecycleEventStatus = "Pending" | "InProgress" | "Succeeded" | "Failed" | "Skipped" | "Unknown" | (string & {});
export interface LifecycleEvent {
    lifecycleEventName?: string;
    diagnostics?: Diagnostics;
    startTime?: Date;
    endTime?: Date;
    status?: LifecycleEventStatus;
}
export type LifecycleEventList = LifecycleEvent[];
export type InstanceType = "Blue" | "Green" | (string & {});
export interface InstanceSummary {
    deploymentId?: string;
    instanceId?: string;
    status?: InstanceStatus;
    lastUpdatedAt?: Date;
    lifecycleEvents?: LifecycleEvent[];
    instanceType?: InstanceType;
}
export type InstanceSummaryList = InstanceSummary[];
export interface BatchGetDeploymentInstancesOutput {
    instancesSummary?: InstanceSummary[];
    errorMessage?: string;
}
export type DeploymentsList = string[];
export interface BatchGetDeploymentsInput {
    deploymentIds: string[];
}
export type ErrorCode = "AGENT_ISSUE" | "ALARM_ACTIVE" | "APPLICATION_MISSING" | "AUTOSCALING_VALIDATION_ERROR" | "AUTO_SCALING_CONFIGURATION" | "AUTO_SCALING_IAM_ROLE_PERMISSIONS" | "CODEDEPLOY_RESOURCE_CANNOT_BE_FOUND" | "CUSTOMER_APPLICATION_UNHEALTHY" | "DEPLOYMENT_GROUP_MISSING" | "ECS_UPDATE_ERROR" | "ELASTIC_LOAD_BALANCING_INVALID" | "ELB_INVALID_INSTANCE" | "HEALTH_CONSTRAINTS" | "HEALTH_CONSTRAINTS_INVALID" | "HOOK_EXECUTION_FAILURE" | "IAM_ROLE_MISSING" | "IAM_ROLE_PERMISSIONS" | "INTERNAL_ERROR" | "INVALID_ECS_SERVICE" | "INVALID_LAMBDA_CONFIGURATION" | "INVALID_LAMBDA_FUNCTION" | "INVALID_REVISION" | "MANUAL_STOP" | "MISSING_BLUE_GREEN_DEPLOYMENT_CONFIGURATION" | "MISSING_ELB_INFORMATION" | "MISSING_GITHUB_TOKEN" | "NO_EC2_SUBSCRIPTION" | "NO_INSTANCES" | "OVER_MAX_INSTANCES" | "RESOURCE_LIMIT_EXCEEDED" | "REVISION_MISSING" | "THROTTLED" | "TIMEOUT" | "CLOUDFORMATION_STACK_FAILURE" | (string & {});
export interface ErrorInformation {
    code?: ErrorCode;
    message?: string;
}
export type InstanceCount = number;
export interface DeploymentOverview {
    Pending?: number;
    InProgress?: number;
    Succeeded?: number;
    Failed?: number;
    Skipped?: number;
    Ready?: number;
}
export type DeploymentCreator = "user" | "autoscaling" | "codeDeployRollback" | "CodeDeploy" | "CodeDeployAutoUpdate" | "CloudFormation" | "CloudFormationRollback" | "autoscalingTermination" | (string & {});
export interface RollbackInfo {
    rollbackDeploymentId?: string;
    rollbackTriggeringDeploymentId?: string;
    rollbackMessage?: string;
}
export type AutoScalingGroupNameList = string[];
export interface TargetInstances {
    tagFilters?: EC2TagFilter[];
    autoScalingGroups?: string[];
    ec2TagSet?: EC2TagSet;
}
export type AdditionalDeploymentStatusInfo = string;
export type FileExistsBehavior = "DISALLOW" | "OVERWRITE" | "RETAIN" | (string & {});
export type DeploymentMode = "STANDARD" | "RESTART" | (string & {});
export type DeploymentStatusMessageList = string[];
export type ExternalId = string;
export interface RelatedDeployments {
    autoUpdateOutdatedInstancesRootDeploymentId?: string;
    autoUpdateOutdatedInstancesDeploymentIds?: string[];
}
export interface DeploymentInfo {
    applicationName?: string;
    deploymentGroupName?: string;
    deploymentConfigName?: string;
    deploymentId?: string;
    previousRevision?: RevisionLocation;
    revision?: RevisionLocation;
    status?: DeploymentStatus;
    errorInformation?: ErrorInformation;
    createTime?: Date;
    startTime?: Date;
    completeTime?: Date;
    deploymentOverview?: DeploymentOverview;
    description?: string;
    creator?: DeploymentCreator;
    ignoreApplicationStopFailures?: boolean;
    autoRollbackConfiguration?: AutoRollbackConfiguration;
    updateOutdatedInstancesOnly?: boolean;
    rollbackInfo?: RollbackInfo;
    deploymentStyle?: DeploymentStyle;
    targetInstances?: TargetInstances;
    instanceTerminationWaitTimeStarted?: boolean;
    blueGreenDeploymentConfiguration?: BlueGreenDeploymentConfiguration;
    loadBalancerInfo?: LoadBalancerInfo;
    additionalDeploymentStatusInfo?: string;
    fileExistsBehavior?: FileExistsBehavior;
    deploymentMode?: DeploymentMode;
    deploymentStatusMessages?: string[];
    computePlatform?: ComputePlatform;
    externalId?: string;
    relatedDeployments?: RelatedDeployments;
    overrideAlarmConfiguration?: AlarmConfiguration;
}
export type DeploymentsInfoList = DeploymentInfo[];
export interface BatchGetDeploymentsOutput {
    deploymentsInfo?: DeploymentInfo[];
}
export type TargetId = string;
export type TargetIdList = string[];
export interface BatchGetDeploymentTargetsInput {
    deploymentId: string;
    targetIds: string[];
}
export type DeploymentTargetType = "InstanceTarget" | "LambdaTarget" | "ECSTarget" | "CloudFormationTarget" | (string & {});
export type TargetArn = string;
export type TargetStatus = "Pending" | "InProgress" | "Succeeded" | "Failed" | "Skipped" | "Unknown" | "Ready" | (string & {});
export type TargetLabel = "Blue" | "Green" | (string & {});
export interface InstanceTarget {
    deploymentId?: string;
    targetId?: string;
    targetArn?: string;
    status?: TargetStatus;
    lastUpdatedAt?: Date;
    lifecycleEvents?: LifecycleEvent[];
    instanceLabel?: TargetLabel;
}
export type LambdaFunctionName = string;
export type LambdaFunctionAlias = string;
export type Version = string;
export type TrafficWeight = number;
export interface LambdaFunctionInfo {
    functionName?: string;
    functionAlias?: string;
    currentVersion?: string;
    targetVersion?: string;
    targetVersionWeight?: number;
}
export interface LambdaTarget {
    deploymentId?: string;
    targetId?: string;
    targetArn?: string;
    status?: TargetStatus;
    lastUpdatedAt?: Date;
    lifecycleEvents?: LifecycleEvent[];
    lambdaFunctionInfo?: LambdaFunctionInfo;
}
export type ECSTaskSetIdentifier = string;
export type ECSTaskSetCount = number;
export type ECSTaskSetStatus = string;
export interface ECSTaskSet {
    identifer?: string;
    desiredCount?: number;
    pendingCount?: number;
    runningCount?: number;
    status?: string;
    trafficWeight?: number;
    targetGroup?: TargetGroupInfo;
    taskSetLabel?: TargetLabel;
}
export type ECSTaskSetList = ECSTaskSet[];
export interface ECSTarget {
    deploymentId?: string;
    targetId?: string;
    targetArn?: string;
    lastUpdatedAt?: Date;
    lifecycleEvents?: LifecycleEvent[];
    status?: TargetStatus;
    taskSetsInfo?: ECSTaskSet[];
}
export type CloudFormationResourceType = string;
export interface CloudFormationTarget {
    deploymentId?: string;
    targetId?: string;
    lastUpdatedAt?: Date;
    lifecycleEvents?: LifecycleEvent[];
    status?: TargetStatus;
    resourceType?: string;
    targetVersionWeight?: number;
}
export interface DeploymentTarget {
    deploymentTargetType?: DeploymentTargetType;
    instanceTarget?: InstanceTarget;
    lambdaTarget?: LambdaTarget;
    ecsTarget?: ECSTarget;
    cloudFormationTarget?: CloudFormationTarget;
}
export type DeploymentTargetList = DeploymentTarget[];
export interface BatchGetDeploymentTargetsOutput {
    deploymentTargets?: DeploymentTarget[];
}
export interface BatchGetOnPremisesInstancesInput {
    instanceNames: string[];
}
export type IamSessionArn = string;
export type IamUserArn = string;
export type InstanceArn = string;
export interface InstanceInfo {
    instanceName?: string;
    iamSessionArn?: string;
    iamUserArn?: string;
    instanceArn?: string;
    registerTime?: Date;
    deregisterTime?: Date;
    tags?: Tag[];
}
export type InstanceInfoList = InstanceInfo[];
export interface BatchGetOnPremisesInstancesOutput {
    instanceInfos?: InstanceInfo[];
}
export type DeploymentWaitType = "READY_WAIT" | "TERMINATION_WAIT" | (string & {});
export interface ContinueDeploymentInput {
    deploymentId?: string;
    deploymentWaitType?: DeploymentWaitType;
}
export interface ContinueDeploymentResponse {
}
export interface CreateApplicationInput {
    applicationName: string;
    computePlatform?: ComputePlatform;
    tags?: Tag[];
}
export interface CreateApplicationOutput {
    applicationId?: string;
}
export interface CreateDeploymentInput {
    applicationName: string;
    deploymentGroupName?: string;
    revision?: RevisionLocation;
    deploymentConfigName?: string;
    description?: string;
    ignoreApplicationStopFailures?: boolean;
    targetInstances?: TargetInstances;
    autoRollbackConfiguration?: AutoRollbackConfiguration;
    updateOutdatedInstancesOnly?: boolean;
    fileExistsBehavior?: FileExistsBehavior;
    deploymentMode?: DeploymentMode;
    overrideAlarmConfiguration?: AlarmConfiguration;
}
export interface CreateDeploymentOutput {
    deploymentId?: string;
}
export type MinimumHealthyHostsType = "HOST_COUNT" | "FLEET_PERCENT" | (string & {});
export type MinimumHealthyHostsValue = number;
export interface MinimumHealthyHosts {
    type?: MinimumHealthyHostsType;
    value?: number;
}
export type TrafficRoutingType = "TimeBasedCanary" | "TimeBasedLinear" | "AllAtOnce" | (string & {});
export type Percentage = number;
export type WaitTimeInMins = number;
export interface TimeBasedCanary {
    canaryPercentage?: number;
    canaryInterval?: number;
}
export interface TimeBasedLinear {
    linearPercentage?: number;
    linearInterval?: number;
}
export interface TrafficRoutingConfig {
    type?: TrafficRoutingType;
    timeBasedCanary?: TimeBasedCanary;
    timeBasedLinear?: TimeBasedLinear;
}
export type WaitTimeInSeconds = number;
export type MinimumHealthyHostsPerZoneType = "HOST_COUNT" | "FLEET_PERCENT" | (string & {});
export type MinimumHealthyHostsPerZoneValue = number;
export interface MinimumHealthyHostsPerZone {
    type?: MinimumHealthyHostsPerZoneType;
    value?: number;
}
export interface ZonalConfig {
    firstZoneMonitorDurationInSeconds?: number;
    monitorDurationInSeconds?: number;
    minimumHealthyHostsPerZone?: MinimumHealthyHostsPerZone;
}
export interface CreateDeploymentConfigInput {
    deploymentConfigName: string;
    minimumHealthyHosts?: MinimumHealthyHosts;
    trafficRoutingConfig?: TrafficRoutingConfig;
    computePlatform?: ComputePlatform;
    zonalConfig?: ZonalConfig;
}
export type DeploymentConfigId = string;
export interface CreateDeploymentConfigOutput {
    deploymentConfigId?: string;
}
export interface CreateDeploymentGroupInput {
    applicationName: string;
    deploymentGroupName: string;
    deploymentConfigName?: string;
    ec2TagFilters?: EC2TagFilter[];
    onPremisesInstanceTagFilters?: TagFilter[];
    autoScalingGroups?: string[];
    serviceRoleArn: string;
    triggerConfigurations?: TriggerConfig[];
    alarmConfiguration?: AlarmConfiguration;
    autoRollbackConfiguration?: AutoRollbackConfiguration;
    outdatedInstancesStrategy?: OutdatedInstancesStrategy;
    deploymentStyle?: DeploymentStyle;
    blueGreenDeploymentConfiguration?: BlueGreenDeploymentConfiguration;
    loadBalancerInfo?: LoadBalancerInfo;
    ec2TagSet?: EC2TagSet;
    ecsServices?: ECSService[];
    onPremisesTagSet?: OnPremisesTagSet;
    tags?: Tag[];
    terminationHookEnabled?: boolean;
}
export interface CreateDeploymentGroupOutput {
    deploymentGroupId?: string;
}
export interface DeleteApplicationInput {
    applicationName: string;
}
export interface DeleteApplicationResponse {
}
export interface DeleteDeploymentConfigInput {
    deploymentConfigName: string;
}
export interface DeleteDeploymentConfigResponse {
}
export interface DeleteDeploymentGroupInput {
    applicationName: string;
    deploymentGroupName: string;
}
export interface DeleteDeploymentGroupOutput {
    hooksNotCleanedUp?: AutoScalingGroup[];
}
export interface DeleteGitHubAccountTokenInput {
    tokenName?: string;
}
export interface DeleteGitHubAccountTokenOutput {
    tokenName?: string;
}
export interface DeleteResourcesByExternalIdInput {
    externalId?: string;
}
export interface DeleteResourcesByExternalIdOutput {
}
export interface DeregisterOnPremisesInstanceInput {
    instanceName: string;
}
export interface DeregisterOnPremisesInstanceResponse {
}
export interface GetApplicationInput {
    applicationName: string;
}
export interface GetApplicationOutput {
    application?: ApplicationInfo;
}
export interface GetApplicationRevisionInput {
    applicationName: string;
    revision: RevisionLocation;
}
export interface GetApplicationRevisionOutput {
    applicationName?: string;
    revision?: RevisionLocation;
    revisionInfo?: GenericRevisionInfo;
}
export interface GetDeploymentInput {
    deploymentId: string;
}
export interface GetDeploymentOutput {
    deploymentInfo?: DeploymentInfo;
}
export interface GetDeploymentConfigInput {
    deploymentConfigName: string;
}
export interface DeploymentConfigInfo {
    deploymentConfigId?: string;
    deploymentConfigName?: string;
    minimumHealthyHosts?: MinimumHealthyHosts;
    createTime?: Date;
    computePlatform?: ComputePlatform;
    trafficRoutingConfig?: TrafficRoutingConfig;
    zonalConfig?: ZonalConfig;
}
export interface GetDeploymentConfigOutput {
    deploymentConfigInfo?: DeploymentConfigInfo;
}
export interface GetDeploymentGroupInput {
    applicationName: string;
    deploymentGroupName: string;
}
export interface GetDeploymentGroupOutput {
    deploymentGroupInfo?: DeploymentGroupInfo;
}
export interface GetDeploymentInstanceInput {
    deploymentId: string;
    instanceId: string;
}
export interface GetDeploymentInstanceOutput {
    instanceSummary?: InstanceSummary;
}
export interface GetDeploymentTargetInput {
    deploymentId: string;
    targetId: string;
}
export interface GetDeploymentTargetOutput {
    deploymentTarget?: DeploymentTarget;
}
export interface GetOnPremisesInstanceInput {
    instanceName: string;
}
export interface GetOnPremisesInstanceOutput {
    instanceInfo?: InstanceInfo;
}
export type ApplicationRevisionSortBy = "registerTime" | "firstUsedTime" | "lastUsedTime" | (string & {});
export type SortOrder = "ascending" | "descending" | (string & {});
export type ListStateFilterAction = "include" | "exclude" | "ignore" | (string & {});
export type NextToken = string;
export interface ListApplicationRevisionsInput {
    applicationName: string;
    sortBy?: ApplicationRevisionSortBy;
    sortOrder?: SortOrder;
    s3Bucket?: string;
    s3KeyPrefix?: string;
    deployed?: ListStateFilterAction;
    nextToken?: string;
}
export interface ListApplicationRevisionsOutput {
    revisions?: RevisionLocation[];
    nextToken?: string;
}
export interface ListApplicationsInput {
    nextToken?: string;
}
export interface ListApplicationsOutput {
    applications?: string[];
    nextToken?: string;
}
export interface ListDeploymentConfigsInput {
    nextToken?: string;
}
export type DeploymentConfigsList = string[];
export interface ListDeploymentConfigsOutput {
    deploymentConfigsList?: string[];
    nextToken?: string;
}
export interface ListDeploymentGroupsInput {
    applicationName: string;
    nextToken?: string;
}
export interface ListDeploymentGroupsOutput {
    applicationName?: string;
    deploymentGroups?: string[];
    nextToken?: string;
}
export type InstanceStatusList = InstanceStatus[];
export type InstanceTypeList = InstanceType[];
export interface ListDeploymentInstancesInput {
    deploymentId: string;
    nextToken?: string;
    instanceStatusFilter?: InstanceStatus[];
    instanceTypeFilter?: InstanceType[];
}
export interface ListDeploymentInstancesOutput {
    instancesList?: string[];
    nextToken?: string;
}
export type DeploymentStatusList = DeploymentStatus[];
export interface TimeRange {
    start?: Date;
    end?: Date;
}
export interface ListDeploymentsInput {
    applicationName?: string;
    deploymentGroupName?: string;
    externalId?: string;
    includeOnlyStatuses?: DeploymentStatus[];
    createTimeRange?: TimeRange;
    nextToken?: string;
}
export interface ListDeploymentsOutput {
    deployments?: string[];
    nextToken?: string;
}
export type TargetFilterName = "TargetStatus" | "ServerInstanceLabel" | (string & {});
export type FilterValue = string;
export type FilterValueList = string[];
export type TargetFilters = {
    [key in TargetFilterName]?: string[];
};
export interface ListDeploymentTargetsInput {
    deploymentId: string;
    nextToken?: string;
    targetFilters?: {
        [key: string]: string[] | undefined;
    };
}
export interface ListDeploymentTargetsOutput {
    targetIds?: string[];
    nextToken?: string;
}
export interface ListGitHubAccountTokenNamesInput {
    nextToken?: string;
}
export type GitHubAccountTokenNameList = string[];
export interface ListGitHubAccountTokenNamesOutput {
    tokenNameList?: string[];
    nextToken?: string;
}
export type RegistrationStatus = "Registered" | "Deregistered" | (string & {});
export interface ListOnPremisesInstancesInput {
    registrationStatus?: RegistrationStatus;
    tagFilters?: TagFilter[];
    nextToken?: string;
}
export interface ListOnPremisesInstancesOutput {
    instanceNames?: string[];
    nextToken?: string;
}
export type Arn = string;
export interface ListTagsForResourceInput {
    ResourceArn: string;
    NextToken?: string;
}
export interface ListTagsForResourceOutput {
    Tags?: Tag[];
    NextToken?: string;
}
export type LifecycleEventHookExecutionId = string;
export interface PutLifecycleEventHookExecutionStatusInput {
    deploymentId?: string;
    lifecycleEventHookExecutionId?: string;
    status?: LifecycleEventStatus;
}
export interface PutLifecycleEventHookExecutionStatusOutput {
    lifecycleEventHookExecutionId?: string;
}
export interface RegisterApplicationRevisionInput {
    applicationName: string;
    description?: string;
    revision: RevisionLocation;
}
export interface RegisterApplicationRevisionResponse {
}
export interface RegisterOnPremisesInstanceInput {
    instanceName: string;
    iamSessionArn?: string;
    iamUserArn?: string;
}
export interface RegisterOnPremisesInstanceResponse {
}
export interface RemoveTagsFromOnPremisesInstancesInput {
    tags: Tag[];
    instanceNames: string[];
}
export interface RemoveTagsFromOnPremisesInstancesResponse {
}
export interface SkipWaitTimeForInstanceTerminationInput {
    deploymentId?: string;
}
export interface SkipWaitTimeForInstanceTerminationResponse {
}
export interface StopDeploymentInput {
    deploymentId: string;
    autoRollbackEnabled?: boolean;
}
export type StopStatus = "Pending" | "Succeeded" | (string & {});
export type Message = string;
export interface StopDeploymentOutput {
    status?: StopStatus;
    statusMessage?: string;
}
export interface TagResourceInput {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateApplicationInput {
    applicationName?: string;
    newApplicationName?: string;
}
export interface UpdateApplicationResponse {
}
export interface UpdateDeploymentGroupInput {
    applicationName: string;
    currentDeploymentGroupName: string;
    newDeploymentGroupName?: string;
    deploymentConfigName?: string;
    ec2TagFilters?: EC2TagFilter[];
    onPremisesInstanceTagFilters?: TagFilter[];
    autoScalingGroups?: string[];
    serviceRoleArn?: string;
    triggerConfigurations?: TriggerConfig[];
    alarmConfiguration?: AlarmConfiguration;
    autoRollbackConfiguration?: AutoRollbackConfiguration;
    outdatedInstancesStrategy?: OutdatedInstancesStrategy;
    deploymentStyle?: DeploymentStyle;
    blueGreenDeploymentConfiguration?: BlueGreenDeploymentConfiguration;
    loadBalancerInfo?: LoadBalancerInfo;
    ec2TagSet?: EC2TagSet;
    ecsServices?: ECSService[];
    onPremisesTagSet?: OnPremisesTagSet;
    terminationHookEnabled?: boolean;
}
export interface UpdateDeploymentGroupOutput {
    hooksNotCleanedUp?: AutoScalingGroup[];
}
export type AddTagsToOnPremisesInstancesError = InstanceLimitExceededException | InstanceNameRequiredException | InstanceNotRegisteredException | InvalidInstanceNameException | InvalidTagException | TagLimitExceededException | TagRequiredException | CommonErrors;
/**
 * Adds tags to on-premises instances.
 */
export declare const addTagsToOnPremisesInstances: API.OperationMethod<AddTagsToOnPremisesInstancesInput, AddTagsToOnPremisesInstancesResponse, AddTagsToOnPremisesInstancesError, Credentials | HttpClient.HttpClient>;
export type BatchGetApplicationRevisionsError = ApplicationDoesNotExistException | ApplicationNameRequiredException | BatchLimitExceededException | InvalidApplicationNameException | InvalidRevisionException | RevisionRequiredException | CommonErrors;
/**
 * Gets information about one or more application revisions. The maximum number of
 * application revisions that can be returned is 25.
 */
export declare const batchGetApplicationRevisions: API.OperationMethod<BatchGetApplicationRevisionsInput, BatchGetApplicationRevisionsOutput, BatchGetApplicationRevisionsError, Credentials | HttpClient.HttpClient>;
export type BatchGetApplicationsError = ApplicationDoesNotExistException | ApplicationNameRequiredException | BatchLimitExceededException | InvalidApplicationNameException | CommonErrors;
/**
 * Gets information about one or more applications. The maximum number of applications
 * that can be returned is 100.
 */
export declare const batchGetApplications: API.OperationMethod<BatchGetApplicationsInput, BatchGetApplicationsOutput, BatchGetApplicationsError, Credentials | HttpClient.HttpClient>;
export type BatchGetDeploymentGroupsError = ApplicationDoesNotExistException | ApplicationNameRequiredException | BatchLimitExceededException | DeploymentConfigDoesNotExistException | DeploymentGroupNameRequiredException | InvalidApplicationNameException | InvalidDeploymentGroupNameException | CommonErrors;
/**
 * Gets information about one or more deployment groups.
 */
export declare const batchGetDeploymentGroups: API.OperationMethod<BatchGetDeploymentGroupsInput, BatchGetDeploymentGroupsOutput, BatchGetDeploymentGroupsError, Credentials | HttpClient.HttpClient>;
export type BatchGetDeploymentInstancesError = BatchLimitExceededException | DeploymentDoesNotExistException | DeploymentIdRequiredException | InstanceIdRequiredException | InvalidComputePlatformException | InvalidDeploymentIdException | InvalidInstanceNameException | CommonErrors;
/**
 * This method works, but is deprecated. Use `BatchGetDeploymentTargets`
 * instead.
 *
 * Returns an array of one or more instances associated with a deployment. This method
 * works with EC2/On-premises and Lambda compute platforms. The newer
 * `BatchGetDeploymentTargets` works with all compute platforms. The maximum
 * number of instances that can be returned is 25.
 */
export declare const batchGetDeploymentInstances: API.OperationMethod<BatchGetDeploymentInstancesInput, BatchGetDeploymentInstancesOutput, BatchGetDeploymentInstancesError, Credentials | HttpClient.HttpClient>;
export type BatchGetDeploymentsError = BatchLimitExceededException | DeploymentIdRequiredException | InvalidDeploymentIdException | CommonErrors;
/**
 * Gets information about one or more deployments. The maximum number of deployments that
 * can be returned is 25.
 */
export declare const batchGetDeployments: API.OperationMethod<BatchGetDeploymentsInput, BatchGetDeploymentsOutput, BatchGetDeploymentsError, Credentials | HttpClient.HttpClient>;
export type BatchGetDeploymentTargetsError = DeploymentDoesNotExistException | DeploymentIdRequiredException | DeploymentNotStartedException | DeploymentTargetDoesNotExistException | DeploymentTargetIdRequiredException | DeploymentTargetListSizeExceededException | InstanceDoesNotExistException | InvalidDeploymentIdException | InvalidDeploymentTargetIdException | CommonErrors;
/**
 * Returns an array of one or more targets associated with a deployment. This method
 * works with all compute types and should be used instead of the deprecated
 * `BatchGetDeploymentInstances`. The maximum number of targets that can be
 * returned is 25.
 *
 * The type of targets returned depends on the deployment's compute platform or
 * deployment method:
 *
 * - **EC2/On-premises**: Information about Amazon EC2 instance targets.
 *
 * - **Lambda**: Information about
 * Lambda functions targets.
 *
 * - **Amazon ECS**: Information about Amazon ECS service targets.
 *
 * - **CloudFormation**: Information about
 * targets of blue/green deployments initiated by a CloudFormation stack
 * update.
 */
export declare const batchGetDeploymentTargets: API.OperationMethod<BatchGetDeploymentTargetsInput, BatchGetDeploymentTargetsOutput, BatchGetDeploymentTargetsError, Credentials | HttpClient.HttpClient>;
export type BatchGetOnPremisesInstancesError = BatchLimitExceededException | InstanceNameRequiredException | InvalidInstanceNameException | CommonErrors;
/**
 * Gets information about one or more on-premises instances. The maximum number of
 * on-premises instances that can be returned is 25.
 */
export declare const batchGetOnPremisesInstances: API.OperationMethod<BatchGetOnPremisesInstancesInput, BatchGetOnPremisesInstancesOutput, BatchGetOnPremisesInstancesError, Credentials | HttpClient.HttpClient>;
export type ContinueDeploymentError = DeploymentAlreadyCompletedException | DeploymentDoesNotExistException | DeploymentIdRequiredException | DeploymentIsNotInReadyStateException | InvalidDeploymentIdException | InvalidDeploymentStatusException | InvalidDeploymentWaitTypeException | UnsupportedActionForDeploymentTypeException | CommonErrors;
/**
 * For a blue/green deployment, starts the process of rerouting traffic from instances in
 * the original environment to instances in the replacement environment without waiting for
 * a specified wait time to elapse. (Traffic rerouting, which is achieved by registering
 * instances in the replacement environment with the load balancer, can start as soon as
 * all instances have a status of Ready.)
 */
export declare const continueDeployment: API.OperationMethod<ContinueDeploymentInput, ContinueDeploymentResponse, ContinueDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = ApplicationAlreadyExistsException | ApplicationLimitExceededException | ApplicationNameRequiredException | InvalidApplicationNameException | InvalidComputePlatformException | InvalidTagsToAddException | ThrottlingException | CommonErrors;
/**
 * Creates an application.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationInput, CreateApplicationOutput, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentError = AlarmsLimitExceededException | ApplicationDoesNotExistException | ApplicationNameRequiredException | DeploymentConfigDoesNotExistException | DeploymentGroupDoesNotExistException | DeploymentGroupNameRequiredException | DeploymentLimitExceededException | DescriptionTooLongException | InvalidAlarmConfigException | InvalidApplicationNameException | InvalidAutoRollbackConfigException | InvalidAutoScalingGroupException | InvalidComputePlatformException | InvalidDeploymentConfigNameException | InvalidDeploymentGroupNameException | InvalidECSServiceException | InvalidFileExistsBehaviorException | InvalidGitHubAccountTokenException | InvalidIgnoreApplicationStopFailuresValueException | InvalidInputException | InvalidLoadBalancerInfoException | InvalidRevisionException | InvalidRoleException | InvalidTargetInstancesException | InvalidTrafficRoutingConfigurationException | InvalidUpdateOutdatedInstancesOnlyValueException | RevisionDoesNotExistException | RevisionRequiredException | ThrottlingException | CommonErrors;
/**
 * Deploys an application revision through the specified deployment group.
 */
export declare const createDeployment: API.OperationMethod<CreateDeploymentInput, CreateDeploymentOutput, CreateDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentConfigError = DeploymentConfigAlreadyExistsException | DeploymentConfigLimitExceededException | DeploymentConfigNameRequiredException | InvalidComputePlatformException | InvalidDeploymentConfigNameException | InvalidMinimumHealthyHostValueException | InvalidTrafficRoutingConfigurationException | InvalidZonalDeploymentConfigurationException | CommonErrors;
/**
 * Creates a deployment configuration.
 */
export declare const createDeploymentConfig: API.OperationMethod<CreateDeploymentConfigInput, CreateDeploymentConfigOutput, CreateDeploymentConfigError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentGroupError = AlarmsLimitExceededException | ApplicationDoesNotExistException | ApplicationNameRequiredException | DeploymentConfigDoesNotExistException | DeploymentGroupAlreadyExistsException | DeploymentGroupLimitExceededException | DeploymentGroupNameRequiredException | ECSServiceMappingLimitExceededException | InvalidAlarmConfigException | InvalidApplicationNameException | InvalidAutoRollbackConfigException | InvalidAutoScalingGroupException | InvalidBlueGreenDeploymentConfigurationException | InvalidDeploymentConfigNameException | InvalidDeploymentGroupNameException | InvalidDeploymentStyleException | InvalidEC2TagCombinationException | InvalidEC2TagException | InvalidECSServiceException | InvalidInputException | InvalidLoadBalancerInfoException | InvalidOnPremisesTagCombinationException | InvalidRoleException | InvalidTagException | InvalidTagsToAddException | InvalidTargetGroupPairException | InvalidTrafficRoutingConfigurationException | InvalidTriggerConfigException | LifecycleHookLimitExceededException | RoleRequiredException | TagSetListLimitExceededException | ThrottlingException | TriggerTargetsLimitExceededException | CommonErrors;
/**
 * Creates a deployment group to which application revisions are deployed.
 */
export declare const createDeploymentGroup: API.OperationMethod<CreateDeploymentGroupInput, CreateDeploymentGroupOutput, CreateDeploymentGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = ApplicationNameRequiredException | InvalidApplicationNameException | InvalidRoleException | CommonErrors;
/**
 * Deletes an application.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationInput, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteDeploymentConfigError = DeploymentConfigInUseException | DeploymentConfigNameRequiredException | InvalidDeploymentConfigNameException | InvalidOperationException | CommonErrors;
/**
 * Deletes a deployment configuration.
 *
 * A deployment configuration cannot be deleted if it is currently in use. Predefined
 * configurations cannot be deleted.
 */
export declare const deleteDeploymentConfig: API.OperationMethod<DeleteDeploymentConfigInput, DeleteDeploymentConfigResponse, DeleteDeploymentConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteDeploymentGroupError = ApplicationNameRequiredException | DeploymentGroupNameRequiredException | InvalidApplicationNameException | InvalidDeploymentGroupNameException | InvalidRoleException | CommonErrors;
/**
 * Deletes a deployment group.
 */
export declare const deleteDeploymentGroup: API.OperationMethod<DeleteDeploymentGroupInput, DeleteDeploymentGroupOutput, DeleteDeploymentGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteGitHubAccountTokenError = GitHubAccountTokenDoesNotExistException | GitHubAccountTokenNameRequiredException | InvalidGitHubAccountTokenNameException | OperationNotSupportedException | ResourceValidationException | CommonErrors;
/**
 * Deletes a GitHub account connection.
 */
export declare const deleteGitHubAccountToken: API.OperationMethod<DeleteGitHubAccountTokenInput, DeleteGitHubAccountTokenOutput, DeleteGitHubAccountTokenError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcesByExternalIdError = CommonErrors;
/**
 * Deletes resources linked to an external ID. This action only applies if you have
 * configured blue/green deployments through CloudFormation.
 *
 * It is not necessary to call this action directly. CloudFormation calls it
 * on your behalf when it needs to delete stack resources. This action is offered
 * publicly in case you need to delete resources to comply with General Data Protection
 * Regulation (GDPR) requirements.
 */
export declare const deleteResourcesByExternalId: API.OperationMethod<DeleteResourcesByExternalIdInput, DeleteResourcesByExternalIdOutput, DeleteResourcesByExternalIdError, Credentials | HttpClient.HttpClient>;
export type DeregisterOnPremisesInstanceError = InstanceNameRequiredException | InvalidInstanceNameException | CommonErrors;
/**
 * Deregisters an on-premises instance.
 */
export declare const deregisterOnPremisesInstance: API.OperationMethod<DeregisterOnPremisesInstanceInput, DeregisterOnPremisesInstanceResponse, DeregisterOnPremisesInstanceError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = ApplicationDoesNotExistException | ApplicationNameRequiredException | InvalidApplicationNameException | CommonErrors;
/**
 * Gets information about an application.
 */
export declare const getApplication: API.OperationMethod<GetApplicationInput, GetApplicationOutput, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetApplicationRevisionError = ApplicationDoesNotExistException | ApplicationNameRequiredException | InvalidApplicationNameException | InvalidRevisionException | RevisionDoesNotExistException | RevisionRequiredException | CommonErrors;
/**
 * Gets information about an application revision.
 */
export declare const getApplicationRevision: API.OperationMethod<GetApplicationRevisionInput, GetApplicationRevisionOutput, GetApplicationRevisionError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentError = DeploymentDoesNotExistException | DeploymentIdRequiredException | InvalidDeploymentIdException | CommonErrors;
/**
 * Gets information about a deployment.
 *
 * The `content` property of the `appSpecContent` object in
 * the returned revision is always null. Use `GetApplicationRevision` and
 * the `sha256` property of the returned `appSpecContent` object
 * to get the content of the deployment's AppSpec file.
 */
export declare const getDeployment: API.OperationMethod<GetDeploymentInput, GetDeploymentOutput, GetDeploymentError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentConfigError = DeploymentConfigDoesNotExistException | DeploymentConfigNameRequiredException | InvalidComputePlatformException | InvalidDeploymentConfigNameException | CommonErrors;
/**
 * Gets information about a deployment configuration.
 */
export declare const getDeploymentConfig: API.OperationMethod<GetDeploymentConfigInput, GetDeploymentConfigOutput, GetDeploymentConfigError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentGroupError = ApplicationDoesNotExistException | ApplicationNameRequiredException | DeploymentConfigDoesNotExistException | DeploymentGroupDoesNotExistException | DeploymentGroupNameRequiredException | InvalidApplicationNameException | InvalidDeploymentGroupNameException | CommonErrors;
/**
 * Gets information about a deployment group.
 */
export declare const getDeploymentGroup: API.OperationMethod<GetDeploymentGroupInput, GetDeploymentGroupOutput, GetDeploymentGroupError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentInstanceError = DeploymentDoesNotExistException | DeploymentIdRequiredException | InstanceDoesNotExistException | InstanceIdRequiredException | InvalidComputePlatformException | InvalidDeploymentIdException | InvalidInstanceNameException | CommonErrors;
/**
 * Gets information about an instance as part of a deployment.
 */
export declare const getDeploymentInstance: API.OperationMethod<GetDeploymentInstanceInput, GetDeploymentInstanceOutput, GetDeploymentInstanceError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentTargetError = DeploymentDoesNotExistException | DeploymentIdRequiredException | DeploymentNotStartedException | DeploymentTargetDoesNotExistException | DeploymentTargetIdRequiredException | InvalidDeploymentIdException | InvalidDeploymentTargetIdException | InvalidInstanceNameException | CommonErrors;
/**
 * Returns information about a deployment target.
 */
export declare const getDeploymentTarget: API.OperationMethod<GetDeploymentTargetInput, GetDeploymentTargetOutput, GetDeploymentTargetError, Credentials | HttpClient.HttpClient>;
export type GetOnPremisesInstanceError = InstanceNameRequiredException | InstanceNotRegisteredException | InvalidInstanceNameException | CommonErrors;
/**
 * Gets information about an on-premises instance.
 */
export declare const getOnPremisesInstance: API.OperationMethod<GetOnPremisesInstanceInput, GetOnPremisesInstanceOutput, GetOnPremisesInstanceError, Credentials | HttpClient.HttpClient>;
export type ListApplicationRevisionsError = ApplicationDoesNotExistException | ApplicationNameRequiredException | BucketNameFilterRequiredException | InvalidApplicationNameException | InvalidBucketNameFilterException | InvalidDeployedStateFilterException | InvalidKeyPrefixFilterException | InvalidNextTokenException | InvalidSortByException | InvalidSortOrderException | CommonErrors;
/**
 * Lists information about revisions for an application.
 */
export declare const listApplicationRevisions: API.PaginatedOperationMethod<ListApplicationRevisionsInput, ListApplicationRevisionsOutput, ListApplicationRevisionsError, Credentials | HttpClient.HttpClient, RevisionLocation>;
export type ListApplicationsError = InvalidNextTokenException | CommonErrors;
/**
 * Lists the applications registered with the user or Amazon Web Services account.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsInput, ListApplicationsOutput, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationName>;
export type ListDeploymentConfigsError = InvalidNextTokenException | CommonErrors;
/**
 * Lists the deployment configurations with the user or Amazon Web Services account.
 */
export declare const listDeploymentConfigs: API.PaginatedOperationMethod<ListDeploymentConfigsInput, ListDeploymentConfigsOutput, ListDeploymentConfigsError, Credentials | HttpClient.HttpClient, DeploymentConfigName>;
export type ListDeploymentGroupsError = ApplicationDoesNotExistException | ApplicationNameRequiredException | InvalidApplicationNameException | InvalidNextTokenException | CommonErrors;
/**
 * Lists the deployment groups for an application registered with the Amazon Web Services
 * user or Amazon Web Services account.
 */
export declare const listDeploymentGroups: API.PaginatedOperationMethod<ListDeploymentGroupsInput, ListDeploymentGroupsOutput, ListDeploymentGroupsError, Credentials | HttpClient.HttpClient, DeploymentGroupName>;
export type ListDeploymentInstancesError = ApplicationDoesNotExistException | DeploymentDoesNotExistException | DeploymentGroupDoesNotExistException | DeploymentIdRequiredException | DeploymentNotStartedException | InvalidComputePlatformException | InvalidDeploymentIdException | InvalidDeploymentInstanceTypeException | InvalidInstanceStatusException | InvalidInstanceTypeException | InvalidNextTokenException | InvalidTargetFilterNameException | CommonErrors;
/**
 * The newer `BatchGetDeploymentTargets` should be used instead because
 * it works with all compute types. `ListDeploymentInstances` throws an
 * exception if it is used with a compute platform other than EC2/On-premises or
 * Lambda.
 *
 * Lists the instance for a deployment associated with the user or Amazon Web Services account.
 */
export declare const listDeploymentInstances: API.PaginatedOperationMethod<ListDeploymentInstancesInput, ListDeploymentInstancesOutput, ListDeploymentInstancesError, Credentials | HttpClient.HttpClient, InstanceId>;
export type ListDeploymentsError = ApplicationDoesNotExistException | ApplicationNameRequiredException | DeploymentGroupDoesNotExistException | DeploymentGroupNameRequiredException | InvalidApplicationNameException | InvalidDeploymentGroupNameException | InvalidDeploymentStatusException | InvalidExternalIdException | InvalidInputException | InvalidNextTokenException | InvalidTimeRangeException | CommonErrors;
/**
 * Lists the deployments in a deployment group for an application registered with the
 * user or Amazon Web Services account.
 */
export declare const listDeployments: API.PaginatedOperationMethod<ListDeploymentsInput, ListDeploymentsOutput, ListDeploymentsError, Credentials | HttpClient.HttpClient, DeploymentId>;
export type ListDeploymentTargetsError = ApplicationDoesNotExistException | DeploymentDoesNotExistException | DeploymentGroupDoesNotExistException | DeploymentIdRequiredException | DeploymentNotStartedException | InvalidDeploymentIdException | InvalidDeploymentInstanceTypeException | InvalidInstanceStatusException | InvalidInstanceTypeException | InvalidNextTokenException | InvalidTargetFilterNameException | CommonErrors;
/**
 * Returns an array of target IDs that are associated a deployment.
 */
export declare const listDeploymentTargets: API.OperationMethod<ListDeploymentTargetsInput, ListDeploymentTargetsOutput, ListDeploymentTargetsError, Credentials | HttpClient.HttpClient>;
export type ListGitHubAccountTokenNamesError = InvalidNextTokenException | OperationNotSupportedException | ResourceValidationException | CommonErrors;
/**
 * Lists the names of stored connections to GitHub accounts.
 */
export declare const listGitHubAccountTokenNames: API.OperationMethod<ListGitHubAccountTokenNamesInput, ListGitHubAccountTokenNamesOutput, ListGitHubAccountTokenNamesError, Credentials | HttpClient.HttpClient>;
export type ListOnPremisesInstancesError = InvalidNextTokenException | InvalidRegistrationStatusException | InvalidTagFilterException | CommonErrors;
/**
 * Gets a list of names for one or more on-premises instances.
 *
 * Unless otherwise specified, both registered and deregistered on-premises instance
 * names are listed. To list only registered or deregistered on-premises instance names,
 * use the registration status parameter.
 */
export declare const listOnPremisesInstances: API.OperationMethod<ListOnPremisesInstancesInput, ListOnPremisesInstancesOutput, ListOnPremisesInstancesError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = ArnNotSupportedException | InvalidArnException | ResourceArnRequiredException | CommonErrors;
/**
 * Returns a list of tags for the resource identified by a specified Amazon Resource
 * Name (ARN). Tags are used to organize and categorize your CodeDeploy resources.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutLifecycleEventHookExecutionStatusError = DeploymentDoesNotExistException | DeploymentIdRequiredException | InvalidDeploymentIdException | InvalidLifecycleEventHookExecutionIdException | InvalidLifecycleEventHookExecutionStatusException | LifecycleEventAlreadyCompletedException | UnsupportedActionForDeploymentTypeException | CommonErrors;
/**
 * Sets the result of a Lambda validation function. The function validates
 * lifecycle hooks during a deployment that uses the Lambda or Amazon ECS compute platform. For Lambda deployments, the available
 * lifecycle hooks are `BeforeAllowTraffic` and `AfterAllowTraffic`.
 * For Amazon ECS deployments, the available lifecycle hooks are
 * `BeforeInstall`, `AfterInstall`,
 * `AfterAllowTestTraffic`, `BeforeAllowTraffic`, and
 * `AfterAllowTraffic`. Lambda validation functions return
 * `Succeeded` or `Failed`. For more information, see AppSpec 'hooks' Section for an Lambda Deployment and
 * AppSpec 'hooks' Section for an Amazon ECS Deployment.
 */
export declare const putLifecycleEventHookExecutionStatus: API.OperationMethod<PutLifecycleEventHookExecutionStatusInput, PutLifecycleEventHookExecutionStatusOutput, PutLifecycleEventHookExecutionStatusError, Credentials | HttpClient.HttpClient>;
export type RegisterApplicationRevisionError = ApplicationDoesNotExistException | ApplicationNameRequiredException | DescriptionTooLongException | InvalidApplicationNameException | InvalidRevisionException | RevisionRequiredException | CommonErrors;
/**
 * Registers with CodeDeploy a revision for the specified application.
 */
export declare const registerApplicationRevision: API.OperationMethod<RegisterApplicationRevisionInput, RegisterApplicationRevisionResponse, RegisterApplicationRevisionError, Credentials | HttpClient.HttpClient>;
export type RegisterOnPremisesInstanceError = IamArnRequiredException | IamSessionArnAlreadyRegisteredException | IamUserArnAlreadyRegisteredException | IamUserArnRequiredException | InstanceNameAlreadyRegisteredException | InstanceNameRequiredException | InvalidIamSessionArnException | InvalidIamUserArnException | InvalidInstanceNameException | MultipleIamArnsProvidedException | CommonErrors;
/**
 * Registers an on-premises instance.
 *
 * Only one IAM ARN (an IAM session ARN or IAM user ARN) is supported in the request. You cannot use both.
 */
export declare const registerOnPremisesInstance: API.OperationMethod<RegisterOnPremisesInstanceInput, RegisterOnPremisesInstanceResponse, RegisterOnPremisesInstanceError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsFromOnPremisesInstancesError = InstanceLimitExceededException | InstanceNameRequiredException | InstanceNotRegisteredException | InvalidInstanceNameException | InvalidTagException | TagLimitExceededException | TagRequiredException | CommonErrors;
/**
 * Removes one or more tags from one or more on-premises instances.
 */
export declare const removeTagsFromOnPremisesInstances: API.OperationMethod<RemoveTagsFromOnPremisesInstancesInput, RemoveTagsFromOnPremisesInstancesResponse, RemoveTagsFromOnPremisesInstancesError, Credentials | HttpClient.HttpClient>;
export type SkipWaitTimeForInstanceTerminationError = DeploymentAlreadyCompletedException | DeploymentDoesNotExistException | DeploymentIdRequiredException | DeploymentNotStartedException | InvalidDeploymentIdException | UnsupportedActionForDeploymentTypeException | CommonErrors;
/**
 * In a blue/green deployment, overrides any specified wait time and starts terminating
 * instances immediately after the traffic routing is complete.
 */
export declare const skipWaitTimeForInstanceTermination: API.OperationMethod<SkipWaitTimeForInstanceTerminationInput, SkipWaitTimeForInstanceTerminationResponse, SkipWaitTimeForInstanceTerminationError, Credentials | HttpClient.HttpClient>;
export type StopDeploymentError = DeploymentAlreadyCompletedException | DeploymentDoesNotExistException | DeploymentGroupDoesNotExistException | DeploymentIdRequiredException | InvalidDeploymentIdException | UnsupportedActionForDeploymentTypeException | CommonErrors;
/**
 * Attempts to stop an ongoing deployment.
 */
export declare const stopDeployment: API.OperationMethod<StopDeploymentInput, StopDeploymentOutput, StopDeploymentError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ApplicationDoesNotExistException | ArnNotSupportedException | DeploymentConfigDoesNotExistException | DeploymentGroupDoesNotExistException | InvalidArnException | InvalidTagsToAddException | ResourceArnRequiredException | TagRequiredException | CommonErrors;
/**
 * Associates the list of tags in the input `Tags` parameter with the
 * resource identified by the `ResourceArn` input parameter.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ApplicationDoesNotExistException | ArnNotSupportedException | DeploymentConfigDoesNotExistException | DeploymentGroupDoesNotExistException | InvalidArnException | InvalidTagsToAddException | ResourceArnRequiredException | TagRequiredException | CommonErrors;
/**
 * Disassociates a resource from a list of tags. The resource is identified by the
 * `ResourceArn` input parameter. The tags are identified by the list of
 * keys in the `TagKeys` input parameter.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = ApplicationAlreadyExistsException | ApplicationDoesNotExistException | ApplicationNameRequiredException | InvalidApplicationNameException | CommonErrors;
/**
 * Changes the name of an application.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationInput, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateDeploymentGroupError = AlarmsLimitExceededException | ApplicationDoesNotExistException | ApplicationNameRequiredException | DeploymentConfigDoesNotExistException | DeploymentGroupAlreadyExistsException | DeploymentGroupDoesNotExistException | DeploymentGroupNameRequiredException | ECSServiceMappingLimitExceededException | InvalidAlarmConfigException | InvalidApplicationNameException | InvalidAutoRollbackConfigException | InvalidAutoScalingGroupException | InvalidBlueGreenDeploymentConfigurationException | InvalidDeploymentConfigNameException | InvalidDeploymentGroupNameException | InvalidDeploymentStyleException | InvalidEC2TagCombinationException | InvalidEC2TagException | InvalidECSServiceException | InvalidInputException | InvalidLoadBalancerInfoException | InvalidOnPremisesTagCombinationException | InvalidRoleException | InvalidTagException | InvalidTargetGroupPairException | InvalidTrafficRoutingConfigurationException | InvalidTriggerConfigException | LifecycleHookLimitExceededException | TagSetListLimitExceededException | ThrottlingException | TriggerTargetsLimitExceededException | CommonErrors;
/**
 * Changes information about a deployment group.
 */
export declare const updateDeploymentGroup: API.OperationMethod<UpdateDeploymentGroupInput, UpdateDeploymentGroupOutput, UpdateDeploymentGroupError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=codedeploy.d.ts.map