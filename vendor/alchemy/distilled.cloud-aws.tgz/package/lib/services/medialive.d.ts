import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import * as T from "../traits.ts";
declare const BadGatewayException_base: S.TaggedErrorClass<"BadGatewayException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class BadGatewayException extends /*@__PURE__*/ BadGatewayException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const GatewayTimeoutException_base: S.TaggedErrorClass<"GatewayTimeoutException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class GatewayTimeoutException extends /*@__PURE__*/ GatewayTimeoutException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const MediaLiveRoleNotYetTrusted_base: S.TaggedErrorClass<"MediaLiveRoleNotYetTrusted", {
    readonly message: any;
    readonly ValidationErrors: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class MediaLiveRoleNotYetTrusted extends /*@__PURE__*/ MediaLiveRoleNotYetTrusted_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnprocessableEntityException_base: S.TaggedErrorClass<"UnprocessableEntityException", {
    readonly message: any;
    readonly ValidationErrors: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableEntityException extends /*@__PURE__*/ UnprocessableEntityException_base {
}
export interface AcceptInputDeviceTransferRequest {
    InputDeviceId: string;
}
export interface AcceptInputDeviceTransferResponse {
}
export type __listOf__string = string[];
export interface BatchDeleteRequest {
    ChannelIds?: string[];
    InputIds?: string[];
    InputSecurityGroupIds?: string[];
    MultiplexIds?: string[];
}
export interface BatchFailedResultModel {
    Arn?: string;
    Code?: string;
    Id?: string;
    Message?: string;
}
export type __listOfBatchFailedResultModel = BatchFailedResultModel[];
export interface BatchSuccessfulResultModel {
    Arn?: string;
    Id?: string;
    State?: string;
}
export type __listOfBatchSuccessfulResultModel = BatchSuccessfulResultModel[];
export interface BatchDeleteResponse {
    Failed?: BatchFailedResultModel[];
    Successful?: BatchSuccessfulResultModel[];
}
export interface BatchStartRequest {
    ChannelIds?: string[];
    MultiplexIds?: string[];
}
export interface BatchStartResponse {
    Failed?: BatchFailedResultModel[];
    Successful?: BatchSuccessfulResultModel[];
}
export interface BatchStopRequest {
    ChannelIds?: string[];
    MultiplexIds?: string[];
}
export interface BatchStopResponse {
    Failed?: BatchFailedResultModel[];
    Successful?: BatchSuccessfulResultModel[];
}
export interface HlsId3SegmentTaggingScheduleActionSettings {
    Tag?: string;
    Id3?: string;
}
export interface HlsTimedMetadataScheduleActionSettings {
    Id3?: string;
}
export type InputTimecodeSource = "ZEROBASED" | "EMBEDDED" | (string & {});
export interface StartTimecode {
    Timecode?: string;
}
export type LastFrameClippingBehavior = "EXCLUDE_LAST_FRAME" | "INCLUDE_LAST_FRAME" | (string & {});
export interface StopTimecode {
    LastFrameClippingBehavior?: LastFrameClippingBehavior;
    Timecode?: string;
}
export interface InputClippingSettings {
    InputTimecodeSource?: InputTimecodeSource;
    StartTimecode?: StartTimecode;
    StopTimecode?: StopTimecode;
}
export interface InputPrepareScheduleActionSettings {
    InputAttachmentNameReference?: string;
    InputClippingSettings?: InputClippingSettings;
    UrlPath?: string[];
}
export interface InputSwitchScheduleActionSettings {
    InputAttachmentNameReference?: string;
    InputClippingSettings?: InputClippingSettings;
    UrlPath?: string[];
}
export type __longMin0Max86400000 = number;
export interface MotionGraphicsActivateScheduleActionSettings {
    Duration?: number;
    PasswordParam?: string;
    Url?: string;
    Username?: string;
}
export interface MotionGraphicsDeactivateScheduleActionSettings {
}
export type PipelineId = "PIPELINE_0" | "PIPELINE_1" | (string & {});
export interface PipelinePauseStateSettings {
    PipelineId?: PipelineId;
}
export type __listOfPipelinePauseStateSettings = PipelinePauseStateSettings[];
export interface PauseStateScheduleActionSettings {
    Pipelines?: PipelinePauseStateSettings[];
}
export type Scte35InputMode = "FIXED" | "FOLLOW_ACTIVE" | (string & {});
export interface Scte35InputScheduleActionSettings {
    InputAttachmentNameReference?: string;
    Mode?: Scte35InputMode;
}
export type __longMin0Max4294967295 = number;
export interface Scte35ReturnToNetworkScheduleActionSettings {
    SpliceEventId?: number;
}
export type __longMin0Max8589934591 = number;
export interface Scte35SpliceInsertScheduleActionSettings {
    Duration?: number;
    SpliceEventId?: number;
}
export type Scte35ArchiveAllowedFlag = "ARCHIVE_NOT_ALLOWED" | "ARCHIVE_ALLOWED" | (string & {});
export type Scte35DeviceRestrictions = "NONE" | "RESTRICT_GROUP0" | "RESTRICT_GROUP1" | "RESTRICT_GROUP2" | (string & {});
export type Scte35NoRegionalBlackoutFlag = "REGIONAL_BLACKOUT" | "NO_REGIONAL_BLACKOUT" | (string & {});
export type Scte35WebDeliveryAllowedFlag = "WEB_DELIVERY_NOT_ALLOWED" | "WEB_DELIVERY_ALLOWED" | (string & {});
export interface Scte35DeliveryRestrictions {
    ArchiveAllowedFlag?: Scte35ArchiveAllowedFlag;
    DeviceRestrictions?: Scte35DeviceRestrictions;
    NoRegionalBlackoutFlag?: Scte35NoRegionalBlackoutFlag;
    WebDeliveryAllowedFlag?: Scte35WebDeliveryAllowedFlag;
}
export type __integerMin0Max255 = number;
export type Scte35SegmentationCancelIndicator = "SEGMENTATION_EVENT_NOT_CANCELED" | "SEGMENTATION_EVENT_CANCELED" | (string & {});
export type __longMin0Max1099511627775 = number;
export interface Scte35SegmentationDescriptor {
    DeliveryRestrictions?: Scte35DeliveryRestrictions;
    SegmentNum?: number;
    SegmentationCancelIndicator?: Scte35SegmentationCancelIndicator;
    SegmentationDuration?: number;
    SegmentationEventId?: number;
    SegmentationTypeId?: number;
    SegmentationUpid?: string;
    SegmentationUpidType?: number;
    SegmentsExpected?: number;
    SubSegmentNum?: number;
    SubSegmentsExpected?: number;
}
export interface Scte35DescriptorSettings {
    SegmentationDescriptorScte35DescriptorSettings?: Scte35SegmentationDescriptor;
}
export interface Scte35Descriptor {
    Scte35DescriptorSettings?: Scte35DescriptorSettings;
}
export type __listOfScte35Descriptor = Scte35Descriptor[];
export interface Scte35TimeSignalScheduleActionSettings {
    Scte35Descriptors?: Scte35Descriptor[];
}
export type __integerMin0 = number;
export type __integerMin1 = number;
export type __stringMax2048 = string;
export interface InputLocation {
    PasswordParam?: string;
    Uri?: string;
    Username?: string;
}
export type __integerMin0Max7 = number;
export type __integerMin0Max100 = number;
export interface StaticImageActivateScheduleActionSettings {
    Duration?: number;
    FadeIn?: number;
    FadeOut?: number;
    Height?: number;
    Image?: InputLocation;
    ImageX?: number;
    ImageY?: number;
    Layer?: number;
    Opacity?: number;
    Width?: number;
}
export interface StaticImageDeactivateScheduleActionSettings {
    FadeOut?: number;
    Layer?: number;
}
export interface StaticImageOutputActivateScheduleActionSettings {
    Duration?: number;
    FadeIn?: number;
    FadeOut?: number;
    Height?: number;
    Image?: InputLocation;
    ImageX?: number;
    ImageY?: number;
    Layer?: number;
    Opacity?: number;
    OutputNames?: string[];
    Width?: number;
}
export interface StaticImageOutputDeactivateScheduleActionSettings {
    FadeOut?: number;
    Layer?: number;
    OutputNames?: string[];
}
export interface Id3SegmentTaggingScheduleActionSettings {
    Id3?: string;
    Tag?: string;
}
export interface TimedMetadataScheduleActionSettings {
    Id3?: string;
}
export interface ScheduleActionSettings {
    HlsId3SegmentTaggingSettings?: HlsId3SegmentTaggingScheduleActionSettings;
    HlsTimedMetadataSettings?: HlsTimedMetadataScheduleActionSettings;
    InputPrepareSettings?: InputPrepareScheduleActionSettings;
    InputSwitchSettings?: InputSwitchScheduleActionSettings;
    MotionGraphicsImageActivateSettings?: MotionGraphicsActivateScheduleActionSettings;
    MotionGraphicsImageDeactivateSettings?: MotionGraphicsDeactivateScheduleActionSettings;
    PauseStateSettings?: PauseStateScheduleActionSettings;
    Scte35InputSettings?: Scte35InputScheduleActionSettings;
    Scte35ReturnToNetworkSettings?: Scte35ReturnToNetworkScheduleActionSettings;
    Scte35SpliceInsertSettings?: Scte35SpliceInsertScheduleActionSettings;
    Scte35TimeSignalSettings?: Scte35TimeSignalScheduleActionSettings;
    StaticImageActivateSettings?: StaticImageActivateScheduleActionSettings;
    StaticImageDeactivateSettings?: StaticImageDeactivateScheduleActionSettings;
    StaticImageOutputActivateSettings?: StaticImageOutputActivateScheduleActionSettings;
    StaticImageOutputDeactivateSettings?: StaticImageOutputDeactivateScheduleActionSettings;
    Id3SegmentTaggingSettings?: Id3SegmentTaggingScheduleActionSettings;
    TimedMetadataSettings?: TimedMetadataScheduleActionSettings;
}
export interface FixedModeScheduleActionStartSettings {
    Time?: string;
}
export type FollowPoint = "END" | "START" | (string & {});
export interface FollowModeScheduleActionStartSettings {
    FollowPoint?: FollowPoint;
    ReferenceActionName?: string;
}
export interface ImmediateModeScheduleActionStartSettings {
}
export interface ScheduleActionStartSettings {
    FixedModeScheduleActionStartSettings?: FixedModeScheduleActionStartSettings;
    FollowModeScheduleActionStartSettings?: FollowModeScheduleActionStartSettings;
    ImmediateModeScheduleActionStartSettings?: ImmediateModeScheduleActionStartSettings;
}
export interface ScheduleAction {
    ActionName?: string;
    ScheduleActionSettings?: ScheduleActionSettings;
    ScheduleActionStartSettings?: ScheduleActionStartSettings;
}
export type __listOfScheduleAction = ScheduleAction[];
export interface BatchScheduleActionCreateRequest {
    ScheduleActions?: ScheduleAction[];
}
export interface BatchScheduleActionDeleteRequest {
    ActionNames?: string[];
}
export interface BatchUpdateScheduleRequest {
    ChannelId: string;
    Creates?: BatchScheduleActionCreateRequest;
    Deletes?: BatchScheduleActionDeleteRequest;
}
export interface BatchScheduleActionCreateResult {
    ScheduleActions?: ScheduleAction[];
}
export interface BatchScheduleActionDeleteResult {
    ScheduleActions?: ScheduleAction[];
}
export interface BatchUpdateScheduleResponse {
    Creates?: BatchScheduleActionCreateResult & {
        ScheduleActions: (ScheduleAction & {
            ActionName: string;
            ScheduleActionSettings: ScheduleActionSettings & {
                HlsTimedMetadataSettings: HlsTimedMetadataScheduleActionSettings & {
                    Id3: string;
                };
                InputPrepareSettings: InputPrepareScheduleActionSettings & {
                    InputClippingSettings: InputClippingSettings & {
                        InputTimecodeSource: InputTimecodeSource;
                    };
                };
                InputSwitchSettings: InputSwitchScheduleActionSettings & {
                    InputAttachmentNameReference: string;
                    InputClippingSettings: InputClippingSettings & {
                        InputTimecodeSource: InputTimecodeSource;
                    };
                };
                PauseStateSettings: PauseStateScheduleActionSettings & {
                    Pipelines: (PipelinePauseStateSettings & {
                        PipelineId: PipelineId;
                    })[];
                };
                Scte35InputSettings: Scte35InputScheduleActionSettings & {
                    Mode: Scte35InputMode;
                };
                Scte35ReturnToNetworkSettings: Scte35ReturnToNetworkScheduleActionSettings & {
                    SpliceEventId: __longMin0Max4294967295;
                };
                Scte35SpliceInsertSettings: Scte35SpliceInsertScheduleActionSettings & {
                    SpliceEventId: __longMin0Max4294967295;
                };
                Scte35TimeSignalSettings: Scte35TimeSignalScheduleActionSettings & {
                    Scte35Descriptors: (Scte35Descriptor & {
                        Scte35DescriptorSettings: Scte35DescriptorSettings & {
                            SegmentationDescriptorScte35DescriptorSettings: Scte35SegmentationDescriptor & {
                                SegmentationCancelIndicator: Scte35SegmentationCancelIndicator;
                                SegmentationEventId: __longMin0Max4294967295;
                                DeliveryRestrictions: Scte35DeliveryRestrictions & {
                                    ArchiveAllowedFlag: Scte35ArchiveAllowedFlag;
                                    DeviceRestrictions: Scte35DeviceRestrictions;
                                    NoRegionalBlackoutFlag: Scte35NoRegionalBlackoutFlag;
                                    WebDeliveryAllowedFlag: Scte35WebDeliveryAllowedFlag;
                                };
                            };
                        };
                    })[];
                };
                StaticImageActivateSettings: StaticImageActivateScheduleActionSettings & {
                    Image: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
                StaticImageOutputActivateSettings: StaticImageOutputActivateScheduleActionSettings & {
                    Image: InputLocation & {
                        Uri: __stringMax2048;
                    };
                    OutputNames: __listOf__string;
                };
                StaticImageOutputDeactivateSettings: StaticImageOutputDeactivateScheduleActionSettings & {
                    OutputNames: __listOf__string;
                };
                TimedMetadataSettings: TimedMetadataScheduleActionSettings & {
                    Id3: string;
                };
            };
            ScheduleActionStartSettings: ScheduleActionStartSettings & {
                FixedModeScheduleActionStartSettings: FixedModeScheduleActionStartSettings & {
                    Time: string;
                };
                FollowModeScheduleActionStartSettings: FollowModeScheduleActionStartSettings & {
                    FollowPoint: FollowPoint;
                    ReferenceActionName: string;
                };
            };
        })[];
    };
    Deletes?: BatchScheduleActionDeleteResult & {
        ScheduleActions: (ScheduleAction & {
            ActionName: string;
            ScheduleActionSettings: ScheduleActionSettings & {
                HlsTimedMetadataSettings: HlsTimedMetadataScheduleActionSettings & {
                    Id3: string;
                };
                InputPrepareSettings: InputPrepareScheduleActionSettings & {
                    InputClippingSettings: InputClippingSettings & {
                        InputTimecodeSource: InputTimecodeSource;
                    };
                };
                InputSwitchSettings: InputSwitchScheduleActionSettings & {
                    InputAttachmentNameReference: string;
                    InputClippingSettings: InputClippingSettings & {
                        InputTimecodeSource: InputTimecodeSource;
                    };
                };
                PauseStateSettings: PauseStateScheduleActionSettings & {
                    Pipelines: (PipelinePauseStateSettings & {
                        PipelineId: PipelineId;
                    })[];
                };
                Scte35InputSettings: Scte35InputScheduleActionSettings & {
                    Mode: Scte35InputMode;
                };
                Scte35ReturnToNetworkSettings: Scte35ReturnToNetworkScheduleActionSettings & {
                    SpliceEventId: __longMin0Max4294967295;
                };
                Scte35SpliceInsertSettings: Scte35SpliceInsertScheduleActionSettings & {
                    SpliceEventId: __longMin0Max4294967295;
                };
                Scte35TimeSignalSettings: Scte35TimeSignalScheduleActionSettings & {
                    Scte35Descriptors: (Scte35Descriptor & {
                        Scte35DescriptorSettings: Scte35DescriptorSettings & {
                            SegmentationDescriptorScte35DescriptorSettings: Scte35SegmentationDescriptor & {
                                SegmentationCancelIndicator: Scte35SegmentationCancelIndicator;
                                SegmentationEventId: __longMin0Max4294967295;
                                DeliveryRestrictions: Scte35DeliveryRestrictions & {
                                    ArchiveAllowedFlag: Scte35ArchiveAllowedFlag;
                                    DeviceRestrictions: Scte35DeviceRestrictions;
                                    NoRegionalBlackoutFlag: Scte35NoRegionalBlackoutFlag;
                                    WebDeliveryAllowedFlag: Scte35WebDeliveryAllowedFlag;
                                };
                            };
                        };
                    })[];
                };
                StaticImageActivateSettings: StaticImageActivateScheduleActionSettings & {
                    Image: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
                StaticImageOutputActivateSettings: StaticImageOutputActivateScheduleActionSettings & {
                    Image: InputLocation & {
                        Uri: __stringMax2048;
                    };
                    OutputNames: __listOf__string;
                };
                StaticImageOutputDeactivateSettings: StaticImageOutputDeactivateScheduleActionSettings & {
                    OutputNames: __listOf__string;
                };
                TimedMetadataSettings: TimedMetadataScheduleActionSettings & {
                    Id3: string;
                };
            };
            ScheduleActionStartSettings: ScheduleActionStartSettings & {
                FixedModeScheduleActionStartSettings: FixedModeScheduleActionStartSettings & {
                    Time: string;
                };
                FollowModeScheduleActionStartSettings: FollowModeScheduleActionStartSettings & {
                    FollowPoint: FollowPoint;
                    ReferenceActionName: string;
                };
            };
        })[];
    };
}
export interface CancelInputDeviceTransferRequest {
    InputDeviceId: string;
}
export interface CancelInputDeviceTransferResponse {
}
export interface ClaimDeviceRequest {
    Id?: string;
}
export interface ClaimDeviceResponse {
}
export type CdiInputResolution = "SD" | "HD" | "FHD" | "UHD" | (string & {});
export interface CdiInputSpecification {
    Resolution?: CdiInputResolution;
}
export type ChannelClass = "STANDARD" | "SINGLE_PIPELINE" | (string & {});
export type __stringMin1 = string;
export interface MediaPackageOutputDestinationSettings {
    ChannelId?: string;
    ChannelGroup?: string;
    ChannelName?: string;
    ChannelEndpointId?: string;
    MediaPackageRegionName?: string;
}
export type __listOfMediaPackageOutputDestinationSettings = MediaPackageOutputDestinationSettings[];
export interface MultiplexProgramChannelDestinationSettings {
    MultiplexId?: string;
    ProgramName?: string;
}
export interface OutputDestinationSettings {
    PasswordParam?: string;
    StreamName?: string;
    Url?: string;
    Username?: string;
    VirtualSourceAddress?: string;
}
export type __listOfOutputDestinationSettings = OutputDestinationSettings[];
export type ConnectionMode = "CALLER" | "LISTENER" | (string & {});
export type __integerMin1Max65535 = number;
export interface SrtOutputDestinationSettings {
    EncryptionPassphraseSecretArn?: string;
    StreamId?: string;
    Url?: string;
    ConnectionMode?: ConnectionMode;
    ListenerPort?: number;
}
export type __listOfSrtOutputDestinationSettings = SrtOutputDestinationSettings[];
export type MediaConnectRouterOutputEncryptionType = "AUTOMATIC" | "SECRETS_MANAGER" | (string & {});
export interface MediaConnectRouterOutputDestinationSettings {
    EncryptionType?: MediaConnectRouterOutputEncryptionType;
    SecretArn?: string;
}
export type __listOfMediaConnectRouterOutputDestinationSettings = MediaConnectRouterOutputDestinationSettings[];
export interface OutputDestination {
    Id?: string;
    MediaPackageSettings?: MediaPackageOutputDestinationSettings[];
    MultiplexSettings?: MultiplexProgramChannelDestinationSettings;
    Settings?: OutputDestinationSettings[];
    SrtSettings?: SrtOutputDestinationSettings[];
    LogicalInterfaceNames?: string[];
    MediaConnectRouterSettings?: MediaConnectRouterOutputDestinationSettings[];
}
export type __listOfOutputDestination = OutputDestination[];
export type AudioNormalizationAlgorithm = "ITU_1770_1" | "ITU_1770_2" | "ITU_1770_3" | "ITU_1770_4" | (string & {});
export type AudioNormalizationAlgorithmControl = "CORRECT_AUDIO" | (string & {});
export type __doubleMinNegative59Max0 = number;
export type AudioNormalizationPeakCalculation = "NONE" | "TRUE_PEAK" | (string & {});
export type __doubleMinNegative8Max0 = number;
export interface AudioNormalizationSettings {
    Algorithm?: AudioNormalizationAlgorithm;
    AlgorithmControl?: AudioNormalizationAlgorithmControl;
    TargetLkfs?: number;
    PeakCalculation?: AudioNormalizationPeakCalculation;
    PeakLimiterThreshold?: number;
}
export type AudioType = "CLEAN_EFFECTS" | "HEARING_IMPAIRED" | "UNDEFINED" | "VISUAL_IMPAIRED_COMMENTARY" | (string & {});
export type AudioDescriptionAudioTypeControl = "FOLLOW_INPUT" | "USE_CONFIGURED" | (string & {});
export type __stringMin2Max2 = string;
export type NielsenWatermarksCbetStepaside = "DISABLED" | "ENABLED" | (string & {});
export type __stringMin1Max7 = string;
export interface NielsenCBET {
    CbetCheckDigitString?: string;
    CbetStepaside?: NielsenWatermarksCbetStepaside;
    Csid?: string;
}
export type NielsenWatermarksDistributionTypes = "FINAL_DISTRIBUTOR" | "PROGRAM_CONTENT" | (string & {});
export type __doubleMin1Max65535 = number;
export type NielsenWatermarkTimezones = "AMERICA_PUERTO_RICO" | "US_ALASKA" | "US_ARIZONA" | "US_CENTRAL" | "US_EASTERN" | "US_HAWAII" | "US_MOUNTAIN" | "US_PACIFIC" | "US_SAMOA" | "UTC" | (string & {});
export interface NielsenNaesIiNw {
    CheckDigitString?: string;
    Sid?: number;
    Timezone?: NielsenWatermarkTimezones;
}
export interface NielsenNwOnly {
    CheckDigitString?: string;
    Sid?: number;
    Timezone?: NielsenWatermarkTimezones;
}
export interface NielsenWatermarksSettings {
    NielsenCbetSettings?: NielsenCBET;
    NielsenDistributionType?: NielsenWatermarksDistributionTypes;
    NielsenNaesIiNwSettings?: NielsenNaesIiNw;
    NielsenNwOnlySettings?: NielsenNwOnly;
}
export interface AudioWatermarkSettings {
    NielsenWatermarksSettings?: NielsenWatermarksSettings;
}
export type AacCodingMode = "AD_RECEIVER_MIX" | "CODING_MODE_1_0" | "CODING_MODE_1_1" | "CODING_MODE_2_0" | "CODING_MODE_5_1" | (string & {});
export type AacInputType = "BROADCASTER_MIXED_AD" | "NORMAL" | (string & {});
export type AacProfile = "HEV1" | "HEV2" | "LC" | (string & {});
export type AacRateControlMode = "CBR" | "VBR" | (string & {});
export type AacRawFormat = "LATM_LOAS" | "NONE" | (string & {});
export type AacSpec = "MPEG2" | "MPEG4" | (string & {});
export type AacVbrQuality = "HIGH" | "LOW" | "MEDIUM_HIGH" | "MEDIUM_LOW" | (string & {});
export interface AacSettings {
    Bitrate?: number;
    CodingMode?: AacCodingMode;
    InputType?: AacInputType;
    Profile?: AacProfile;
    RateControlMode?: AacRateControlMode;
    RawFormat?: AacRawFormat;
    SampleRate?: number;
    Spec?: AacSpec;
    VbrQuality?: AacVbrQuality;
}
export type Ac3BitstreamMode = "COMMENTARY" | "COMPLETE_MAIN" | "DIALOGUE" | "EMERGENCY" | "HEARING_IMPAIRED" | "MUSIC_AND_EFFECTS" | "VISUALLY_IMPAIRED" | "VOICE_OVER" | (string & {});
export type Ac3CodingMode = "CODING_MODE_1_0" | "CODING_MODE_1_1" | "CODING_MODE_2_0" | "CODING_MODE_3_2_LFE" | (string & {});
export type __integerMin1Max31 = number;
export type Ac3DrcProfile = "FILM_STANDARD" | "NONE" | (string & {});
export type Ac3LfeFilter = "DISABLED" | "ENABLED" | (string & {});
export type Ac3MetadataControl = "FOLLOW_INPUT" | "USE_CONFIGURED" | (string & {});
export type Ac3AttenuationControl = "ATTENUATE_3_DB" | "NONE" | (string & {});
export interface Ac3Settings {
    Bitrate?: number;
    BitstreamMode?: Ac3BitstreamMode;
    CodingMode?: Ac3CodingMode;
    Dialnorm?: number;
    DrcProfile?: Ac3DrcProfile;
    LfeFilter?: Ac3LfeFilter;
    MetadataControl?: Ac3MetadataControl;
    AttenuationControl?: Ac3AttenuationControl;
}
export type Eac3AtmosCodingMode = "CODING_MODE_5_1_4" | "CODING_MODE_7_1_4" | "CODING_MODE_9_1_6" | (string & {});
export type Eac3AtmosDrcLine = "FILM_LIGHT" | "FILM_STANDARD" | "MUSIC_LIGHT" | "MUSIC_STANDARD" | "NONE" | "SPEECH" | (string & {});
export type Eac3AtmosDrcRf = "FILM_LIGHT" | "FILM_STANDARD" | "MUSIC_LIGHT" | "MUSIC_STANDARD" | "NONE" | "SPEECH" | (string & {});
export interface Eac3AtmosSettings {
    Bitrate?: number;
    CodingMode?: Eac3AtmosCodingMode;
    Dialnorm?: number;
    DrcLine?: Eac3AtmosDrcLine;
    DrcRf?: Eac3AtmosDrcRf;
    HeightTrim?: number;
    SurroundTrim?: number;
}
export type Eac3AttenuationControl = "ATTENUATE_3_DB" | "NONE" | (string & {});
export type Eac3BitstreamMode = "COMMENTARY" | "COMPLETE_MAIN" | "EMERGENCY" | "HEARING_IMPAIRED" | "VISUALLY_IMPAIRED" | (string & {});
export type Eac3CodingMode = "CODING_MODE_1_0" | "CODING_MODE_2_0" | "CODING_MODE_3_2" | (string & {});
export type Eac3DcFilter = "DISABLED" | "ENABLED" | (string & {});
export type Eac3DrcLine = "FILM_LIGHT" | "FILM_STANDARD" | "MUSIC_LIGHT" | "MUSIC_STANDARD" | "NONE" | "SPEECH" | (string & {});
export type Eac3DrcRf = "FILM_LIGHT" | "FILM_STANDARD" | "MUSIC_LIGHT" | "MUSIC_STANDARD" | "NONE" | "SPEECH" | (string & {});
export type Eac3LfeControl = "LFE" | "NO_LFE" | (string & {});
export type Eac3LfeFilter = "DISABLED" | "ENABLED" | (string & {});
export type Eac3MetadataControl = "FOLLOW_INPUT" | "USE_CONFIGURED" | (string & {});
export type Eac3PassthroughControl = "NO_PASSTHROUGH" | "WHEN_POSSIBLE" | (string & {});
export type Eac3PhaseControl = "NO_SHIFT" | "SHIFT_90_DEGREES" | (string & {});
export type Eac3StereoDownmix = "DPL2" | "LO_RO" | "LT_RT" | "NOT_INDICATED" | (string & {});
export type Eac3SurroundExMode = "DISABLED" | "ENABLED" | "NOT_INDICATED" | (string & {});
export type Eac3SurroundMode = "DISABLED" | "ENABLED" | "NOT_INDICATED" | (string & {});
export interface Eac3Settings {
    AttenuationControl?: Eac3AttenuationControl;
    Bitrate?: number;
    BitstreamMode?: Eac3BitstreamMode;
    CodingMode?: Eac3CodingMode;
    DcFilter?: Eac3DcFilter;
    Dialnorm?: number;
    DrcLine?: Eac3DrcLine;
    DrcRf?: Eac3DrcRf;
    LfeControl?: Eac3LfeControl;
    LfeFilter?: Eac3LfeFilter;
    LoRoCenterMixLevel?: number;
    LoRoSurroundMixLevel?: number;
    LtRtCenterMixLevel?: number;
    LtRtSurroundMixLevel?: number;
    MetadataControl?: Eac3MetadataControl;
    PassthroughControl?: Eac3PassthroughControl;
    PhaseControl?: Eac3PhaseControl;
    StereoDownmix?: Eac3StereoDownmix;
    SurroundExMode?: Eac3SurroundExMode;
    SurroundMode?: Eac3SurroundMode;
}
export type Mp2CodingMode = "CODING_MODE_1_0" | "CODING_MODE_2_0" | (string & {});
export interface Mp2Settings {
    Bitrate?: number;
    CodingMode?: Mp2CodingMode;
    SampleRate?: number;
}
export interface PassThroughSettings {
}
export type WavCodingMode = "CODING_MODE_1_0" | "CODING_MODE_2_0" | "CODING_MODE_4_0" | "CODING_MODE_8_0" | (string & {});
export interface WavSettings {
    BitDepth?: number;
    CodingMode?: WavCodingMode;
    SampleRate?: number;
}
export interface AudioCodecSettings {
    AacSettings?: AacSettings;
    Ac3Settings?: Ac3Settings;
    Eac3AtmosSettings?: Eac3AtmosSettings;
    Eac3Settings?: Eac3Settings;
    Mp2Settings?: Mp2Settings;
    PassThroughSettings?: PassThroughSettings;
    WavSettings?: WavSettings;
}
export type __stringMin1Max35 = string;
export type AudioDescriptionLanguageCodeControl = "FOLLOW_INPUT" | "USE_CONFIGURED" | (string & {});
export type __stringMax255 = string;
export type __integerMinNegative60Max6 = number;
export type __integerMin0Max15 = number;
export interface InputChannelLevel {
    Gain?: number;
    InputChannel?: number;
}
export type __listOfInputChannelLevel = InputChannelLevel[];
export interface AudioChannelMapping {
    InputChannelLevels?: InputChannelLevel[];
    OutputChannel?: number;
}
export type __listOfAudioChannelMapping = AudioChannelMapping[];
export type __integerMin1Max16 = number;
export type __integerMin1Max8 = number;
export interface RemixSettings {
    ChannelMappings?: AudioChannelMapping[];
    ChannelsIn?: number;
    ChannelsOut?: number;
}
export type DashRoleAudio = "ALTERNATE" | "COMMENTARY" | "DESCRIPTION" | "DUB" | "EMERGENCY" | "ENHANCED-AUDIO-INTELLIGIBILITY" | "KARAOKE" | "MAIN" | "SUPPLEMENTARY" | (string & {});
export type __listOfDashRoleAudio = DashRoleAudio[];
export type DvbDashAccessibility = "DVBDASH_1_VISUALLY_IMPAIRED" | "DVBDASH_2_HARD_OF_HEARING" | "DVBDASH_3_SUPPLEMENTAL_COMMENTARY" | "DVBDASH_4_DIRECTORS_COMMENTARY" | "DVBDASH_5_EDUCATIONAL_NOTES" | "DVBDASH_6_MAIN_PROGRAM" | "DVBDASH_7_CLEAN_FEED" | (string & {});
export interface AudioDescription {
    AudioNormalizationSettings?: AudioNormalizationSettings;
    AudioSelectorName?: string;
    AudioType?: AudioType;
    AudioTypeControl?: AudioDescriptionAudioTypeControl;
    AudioWatermarkingSettings?: AudioWatermarkSettings;
    CodecSettings?: AudioCodecSettings;
    LanguageCode?: string;
    LanguageCodeControl?: AudioDescriptionLanguageCodeControl;
    Name?: string;
    RemixSettings?: RemixSettings;
    StreamName?: string;
    AudioDashRoles?: DashRoleAudio[];
    DvbDashAccessibility?: DvbDashAccessibility;
}
export type __listOfAudioDescription = AudioDescription[];
export type AvailBlankingState = "DISABLED" | "ENABLED" | (string & {});
export interface AvailBlanking {
    AvailBlankingImage?: InputLocation;
    State?: AvailBlankingState;
}
export type __stringMax256 = string;
export type __integerMinNegative1000Max1000 = number;
export interface Esam {
    AcquisitionPointId?: string;
    AdAvailOffset?: number;
    PasswordParam?: string;
    PoisEndpoint?: string;
    Username?: string;
    ZoneIdentity?: string;
}
export type Scte35SpliceInsertNoRegionalBlackoutBehavior = "FOLLOW" | "IGNORE" | (string & {});
export type Scte35SpliceInsertWebDeliveryAllowedBehavior = "FOLLOW" | "IGNORE" | (string & {});
export interface Scte35SpliceInsert {
    AdAvailOffset?: number;
    NoRegionalBlackoutFlag?: Scte35SpliceInsertNoRegionalBlackoutBehavior;
    WebDeliveryAllowedFlag?: Scte35SpliceInsertWebDeliveryAllowedBehavior;
}
export type Scte35AposNoRegionalBlackoutBehavior = "FOLLOW" | "IGNORE" | (string & {});
export type Scte35AposWebDeliveryAllowedBehavior = "FOLLOW" | "IGNORE" | (string & {});
export interface Scte35TimeSignalApos {
    AdAvailOffset?: number;
    NoRegionalBlackoutFlag?: Scte35AposNoRegionalBlackoutBehavior;
    WebDeliveryAllowedFlag?: Scte35AposWebDeliveryAllowedBehavior;
}
export interface AvailSettings {
    Esam?: Esam;
    Scte35SpliceInsert?: Scte35SpliceInsert;
    Scte35TimeSignalApos?: Scte35TimeSignalApos;
}
export type Scte35SegmentationScope = "ALL_OUTPUT_GROUPS" | "SCTE35_ENABLED_OUTPUT_GROUPS" | (string & {});
export interface AvailConfiguration {
    AvailSettings?: AvailSettings;
    Scte35SegmentationScope?: Scte35SegmentationScope;
}
export type BlackoutSlateNetworkEndBlackout = "DISABLED" | "ENABLED" | (string & {});
export type __stringMin34Max34 = string;
export type BlackoutSlateState = "DISABLED" | "ENABLED" | (string & {});
export interface BlackoutSlate {
    BlackoutSlateImage?: InputLocation;
    NetworkEndBlackout?: BlackoutSlateNetworkEndBlackout;
    NetworkEndBlackoutImage?: InputLocation;
    NetworkId?: string;
    State?: BlackoutSlateState;
}
export type AccessibilityType = "DOES_NOT_IMPLEMENT_ACCESSIBILITY_FEATURES" | "IMPLEMENTS_ACCESSIBILITY_FEATURES" | (string & {});
export interface AribDestinationSettings {
}
export type BurnInAlignment = "CENTERED" | "LEFT" | "SMART" | (string & {});
export type BurnInBackgroundColor = "BLACK" | "NONE" | "WHITE" | (string & {});
export type BurnInFontColor = "BLACK" | "BLUE" | "GREEN" | "RED" | "WHITE" | "YELLOW" | (string & {});
export type __integerMin96Max600 = number;
export type BurnInOutlineColor = "BLACK" | "BLUE" | "GREEN" | "RED" | "WHITE" | "YELLOW" | (string & {});
export type __integerMin0Max10 = number;
export type BurnInShadowColor = "BLACK" | "NONE" | "WHITE" | (string & {});
export type BurnInTeletextGridControl = "FIXED" | "SCALED" | (string & {});
export type BurnInDestinationSubtitleRows = "ROWS_16" | "ROWS_20" | "ROWS_24" | (string & {});
export interface BurnInDestinationSettings {
    Alignment?: BurnInAlignment;
    BackgroundColor?: BurnInBackgroundColor;
    BackgroundOpacity?: number;
    Font?: InputLocation;
    FontColor?: BurnInFontColor;
    FontOpacity?: number;
    FontResolution?: number;
    FontSize?: string;
    OutlineColor?: BurnInOutlineColor;
    OutlineSize?: number;
    ShadowColor?: BurnInShadowColor;
    ShadowOpacity?: number;
    ShadowXOffset?: number;
    ShadowYOffset?: number;
    TeletextGridControl?: BurnInTeletextGridControl;
    XPosition?: number;
    YPosition?: number;
    SubtitleRows?: BurnInDestinationSubtitleRows;
}
export type DvbSubDestinationAlignment = "CENTERED" | "LEFT" | "SMART" | (string & {});
export type DvbSubDestinationBackgroundColor = "BLACK" | "NONE" | "WHITE" | (string & {});
export type DvbSubDestinationFontColor = "BLACK" | "BLUE" | "GREEN" | "RED" | "WHITE" | "YELLOW" | (string & {});
export type DvbSubDestinationOutlineColor = "BLACK" | "BLUE" | "GREEN" | "RED" | "WHITE" | "YELLOW" | (string & {});
export type DvbSubDestinationShadowColor = "BLACK" | "NONE" | "WHITE" | (string & {});
export type DvbSubDestinationTeletextGridControl = "FIXED" | "SCALED" | (string & {});
export type DvbSubDestinationSubtitleRows = "ROWS_16" | "ROWS_20" | "ROWS_24" | (string & {});
export interface DvbSubDestinationSettings {
    Alignment?: DvbSubDestinationAlignment;
    BackgroundColor?: DvbSubDestinationBackgroundColor;
    BackgroundOpacity?: number;
    Font?: InputLocation;
    FontColor?: DvbSubDestinationFontColor;
    FontOpacity?: number;
    FontResolution?: number;
    FontSize?: string;
    OutlineColor?: DvbSubDestinationOutlineColor;
    OutlineSize?: number;
    ShadowColor?: DvbSubDestinationShadowColor;
    ShadowOpacity?: number;
    ShadowXOffset?: number;
    ShadowYOffset?: number;
    TeletextGridControl?: DvbSubDestinationTeletextGridControl;
    XPosition?: number;
    YPosition?: number;
    SubtitleRows?: DvbSubDestinationSubtitleRows;
}
export type __stringMax1000 = string;
export type EbuTtDFillLineGapControl = "DISABLED" | "ENABLED" | (string & {});
export type EbuTtDDestinationStyleControl = "EXCLUDE" | "INCLUDE" | (string & {});
export type __integerMin1Max800 = number;
export type __integerMin80Max800 = number;
export interface EbuTtDDestinationSettings {
    CopyrightHolder?: string;
    FillLineGap?: EbuTtDFillLineGapControl;
    FontFamily?: string;
    StyleControl?: EbuTtDDestinationStyleControl;
    DefaultFontSize?: number;
    DefaultLineHeight?: number;
}
export type __integerMin1Max15 = number;
export interface EmbeddedCaptionPositionSettings {
    YPositionLine?: number;
}
export type EmbeddedDestinationStyleControl = "MANUAL" | "PASSTHROUGH" | (string & {});
export interface EmbeddedDestinationSettings {
    Position?: EmbeddedCaptionPositionSettings;
    StyleControl?: EmbeddedDestinationStyleControl;
}
export interface EmbeddedPlusScte20DestinationSettings {
}
export interface RtmpCaptionInfoDestinationSettings {
}
export interface Scte20PlusEmbeddedDestinationSettings {
}
export interface Scte27DestinationSettings {
}
export interface SmpteTtDestinationSettings {
}
export interface TeletextDestinationSettings {
}
export type TtmlDestinationStyleControl = "PASSTHROUGH" | "USE_CONFIGURED" | "MANUAL" | (string & {});
export interface TextCaptionPositionSettings {
    YPositionPercentage?: number;
}
export interface TtmlDestinationSettings {
    StyleControl?: TtmlDestinationStyleControl;
    Position?: TextCaptionPositionSettings;
}
export type WebvttDestinationStyleControl = "NO_STYLE_DATA" | "PASSTHROUGH" | "MANUAL" | (string & {});
export interface WebvttDestinationSettings {
    StyleControl?: WebvttDestinationStyleControl;
    Position?: TextCaptionPositionSettings;
}
export interface CaptionDestinationSettings {
    AribDestinationSettings?: AribDestinationSettings;
    BurnInDestinationSettings?: BurnInDestinationSettings;
    DvbSubDestinationSettings?: DvbSubDestinationSettings;
    EbuTtDDestinationSettings?: EbuTtDDestinationSettings;
    EmbeddedDestinationSettings?: EmbeddedDestinationSettings;
    EmbeddedPlusScte20DestinationSettings?: EmbeddedPlusScte20DestinationSettings;
    RtmpCaptionInfoDestinationSettings?: RtmpCaptionInfoDestinationSettings;
    Scte20PlusEmbeddedDestinationSettings?: Scte20PlusEmbeddedDestinationSettings;
    Scte27DestinationSettings?: Scte27DestinationSettings;
    SmpteTtDestinationSettings?: SmpteTtDestinationSettings;
    TeletextDestinationSettings?: TeletextDestinationSettings;
    TtmlDestinationSettings?: TtmlDestinationSettings;
    WebvttDestinationSettings?: WebvttDestinationSettings;
}
export type DashRoleCaption = "ALTERNATE" | "CAPTION" | "COMMENTARY" | "DESCRIPTION" | "DUB" | "EASYREADER" | "EMERGENCY" | "FORCED-SUBTITLE" | "KARAOKE" | "MAIN" | "METADATA" | "SUBTITLE" | "SUPPLEMENTARY" | (string & {});
export type __listOfDashRoleCaption = DashRoleCaption[];
export interface CaptionDescription {
    Accessibility?: AccessibilityType;
    CaptionSelectorName?: string;
    DestinationSettings?: CaptionDestinationSettings;
    LanguageCode?: string;
    LanguageDescription?: string;
    Name?: string;
    CaptionDashRoles?: DashRoleCaption[];
    DvbDashAccessibility?: DvbDashAccessibility;
}
export type __listOfCaptionDescription = CaptionDescription[];
export type FeatureActivationsInputPrepareScheduleActions = "DISABLED" | "ENABLED" | (string & {});
export type FeatureActivationsOutputStaticImageOverlayScheduleActions = "DISABLED" | "ENABLED" | (string & {});
export interface FeatureActivations {
    InputPrepareScheduleActions?: FeatureActivationsInputPrepareScheduleActions;
    OutputStaticImageOverlayScheduleActions?: FeatureActivationsOutputStaticImageOverlayScheduleActions;
}
export type __integerMinNegative60Max60 = number;
export type GlobalConfigurationInputEndAction = "NONE" | "SWITCH_AND_LOOP_INPUTS" | (string & {});
export type __integerMin0Max1000000 = number;
export type __stringMin6Max6 = string;
export type InputLossImageType = "COLOR" | "SLATE" | (string & {});
export interface InputLossBehavior {
    BlackFrameMsec?: number;
    InputLossImageColor?: string;
    InputLossImageSlate?: InputLocation;
    InputLossImageType?: InputLossImageType;
    RepeatFrameMsec?: number;
}
export type GlobalConfigurationOutputLockingMode = "EPOCH_LOCKING" | "PIPELINE_LOCKING" | "DISABLED" | (string & {});
export type GlobalConfigurationOutputTimingSource = "INPUT_CLOCK" | "SYSTEM_CLOCK" | (string & {});
export type GlobalConfigurationLowFramerateInputs = "DISABLED" | "ENABLED" | (string & {});
export interface EpochLockingSettings {
    CustomEpoch?: string;
    JamSyncTime?: string;
}
export type PipelineLockingMethod = "SOURCE_TIMECODE" | "VIDEO_ALIGNMENT" | (string & {});
export interface PipelineLockingSettings {
    PipelineLockingMethod?: PipelineLockingMethod;
    CustomEpoch?: string;
}
export interface DisabledLockingSettings {
    CustomEpoch?: string;
}
export interface OutputLockingSettings {
    EpochLockingSettings?: EpochLockingSettings;
    PipelineLockingSettings?: PipelineLockingSettings;
    DisabledLockingSettings?: DisabledLockingSettings;
}
export interface GlobalConfiguration {
    InitialAudioGain?: number;
    InputEndAction?: GlobalConfigurationInputEndAction;
    InputLossBehavior?: InputLossBehavior;
    OutputLockingMode?: GlobalConfigurationOutputLockingMode;
    OutputTimingSource?: GlobalConfigurationOutputTimingSource;
    SupportLowFramerateInputs?: GlobalConfigurationLowFramerateInputs;
    OutputLockingSettings?: OutputLockingSettings;
}
export type MotionGraphicsInsertion = "DISABLED" | "ENABLED" | (string & {});
export interface HtmlMotionGraphicsSettings {
}
export interface MotionGraphicsSettings {
    HtmlMotionGraphicsSettings?: HtmlMotionGraphicsSettings;
}
export interface MotionGraphicsConfiguration {
    MotionGraphicsInsertion?: MotionGraphicsInsertion;
    MotionGraphicsSettings?: MotionGraphicsSettings;
}
export type NielsenPcmToId3TaggingState = "DISABLED" | "ENABLED" | (string & {});
export interface NielsenConfiguration {
    DistributorId?: string;
    NielsenPcmToId3Tagging?: NielsenPcmToId3TaggingState;
}
export type __stringMax32 = string;
export type S3CannedAcl = "AUTHENTICATED_READ" | "BUCKET_OWNER_FULL_CONTROL" | "BUCKET_OWNER_READ" | "PUBLIC_READ" | (string & {});
export interface ArchiveS3Settings {
    CannedAcl?: S3CannedAcl;
}
export interface ArchiveCdnSettings {
    ArchiveS3Settings?: ArchiveS3Settings;
}
export interface OutputLocationRef {
    DestinationRefId?: string;
}
export interface ArchiveGroupSettings {
    ArchiveCdnSettings?: ArchiveCdnSettings;
    Destination?: OutputLocationRef;
    RolloverInterval?: number;
}
export interface FrameCaptureS3Settings {
    CannedAcl?: S3CannedAcl;
}
export interface FrameCaptureCdnSettings {
    FrameCaptureS3Settings?: FrameCaptureS3Settings;
}
export interface FrameCaptureGroupSettings {
    Destination?: OutputLocationRef;
    FrameCaptureCdnSettings?: FrameCaptureCdnSettings;
}
export type HlsAdMarkers = "ADOBE" | "ELEMENTAL" | "ELEMENTAL_SCTE35" | (string & {});
export type __listOfHlsAdMarkers = HlsAdMarkers[];
export type __integerMin1Max4 = number;
export type __stringMin3Max3 = string;
export interface CaptionLanguageMapping {
    CaptionChannel?: number;
    LanguageCode?: string;
    LanguageDescription?: string;
}
export type __listOfCaptionLanguageMapping = CaptionLanguageMapping[];
export type HlsCaptionLanguageSetting = "INSERT" | "NONE" | "OMIT" | (string & {});
export type HlsClientCache = "DISABLED" | "ENABLED" | (string & {});
export type HlsCodecSpecification = "RFC_4281" | "RFC_6381" | (string & {});
export type __stringMin32Max32 = string;
export type HlsDirectoryStructure = "SINGLE_DIRECTORY" | "SUBDIRECTORY_PER_STREAM" | (string & {});
export type HlsDiscontinuityTags = "INSERT" | "NEVER_INSERT" | (string & {});
export type HlsEncryptionType = "AES128" | "SAMPLE_AES" | (string & {});
export type __integerMin0Max600 = number;
export type HlsAkamaiHttpTransferMode = "CHUNKED" | "NON_CHUNKED" | (string & {});
export interface HlsAkamaiSettings {
    ConnectionRetryInterval?: number;
    FilecacheDuration?: number;
    HttpTransferMode?: HlsAkamaiHttpTransferMode;
    NumRetries?: number;
    RestartDelay?: number;
    Salt?: string;
    Token?: string;
}
export interface HlsBasicPutSettings {
    ConnectionRetryInterval?: number;
    FilecacheDuration?: number;
    NumRetries?: number;
    RestartDelay?: number;
}
export type HlsMediaStoreStorageClass = "TEMPORAL" | (string & {});
export interface HlsMediaStoreSettings {
    ConnectionRetryInterval?: number;
    FilecacheDuration?: number;
    MediaStoreStorageClass?: HlsMediaStoreStorageClass;
    NumRetries?: number;
    RestartDelay?: number;
}
export interface HlsS3Settings {
    CannedAcl?: S3CannedAcl;
}
export type HlsWebdavHttpTransferMode = "CHUNKED" | "NON_CHUNKED" | (string & {});
export interface HlsWebdavSettings {
    ConnectionRetryInterval?: number;
    FilecacheDuration?: number;
    HttpTransferMode?: HlsWebdavHttpTransferMode;
    NumRetries?: number;
    RestartDelay?: number;
}
export interface HlsCdnSettings {
    HlsAkamaiSettings?: HlsAkamaiSettings;
    HlsBasicPutSettings?: HlsBasicPutSettings;
    HlsMediaStoreSettings?: HlsMediaStoreSettings;
    HlsS3Settings?: HlsS3Settings;
    HlsWebdavSettings?: HlsWebdavSettings;
}
export type HlsId3SegmentTaggingState = "DISABLED" | "ENABLED" | (string & {});
export type IFrameOnlyPlaylistType = "DISABLED" | "STANDARD" | (string & {});
export type HlsIncompleteSegmentBehavior = "AUTO" | "SUPPRESS" | (string & {});
export type __integerMin3 = number;
export type InputLossActionForHlsOut = "EMIT_OUTPUT" | "PAUSE_OUTPUT" | (string & {});
export type HlsIvInManifest = "EXCLUDE" | "INCLUDE" | (string & {});
export type HlsIvSource = "EXPLICIT" | "FOLLOWS_SEGMENT_NUMBER" | (string & {});
export interface StaticKeySettings {
    KeyProviderServer?: InputLocation;
    StaticKeyValue?: string | redacted.Redacted<string>;
}
export interface KeyProviderSettings {
    StaticKeySettings?: StaticKeySettings;
}
export type HlsManifestCompression = "GZIP" | "NONE" | (string & {});
export type HlsManifestDurationFormat = "FLOATING_POINT" | "INTEGER" | (string & {});
export type HlsMode = "LIVE" | "VOD" | (string & {});
export type HlsOutputSelection = "MANIFESTS_AND_SEGMENTS" | "SEGMENTS_ONLY" | "VARIANT_MANIFESTS_AND_SEGMENTS" | (string & {});
export type HlsProgramDateTime = "EXCLUDE" | "INCLUDE" | (string & {});
export type HlsProgramDateTimeClock = "INITIALIZE_FROM_OUTPUT_TIMECODE" | "SYSTEM_CLOCK" | (string & {});
export type __integerMin0Max3600 = number;
export type HlsRedundantManifest = "DISABLED" | "ENABLED" | (string & {});
export type HlsSegmentationMode = "USE_INPUT_SEGMENTATION" | "USE_SEGMENT_DURATION" | (string & {});
export type HlsStreamInfResolution = "EXCLUDE" | "INCLUDE" | (string & {});
export type HlsTimedMetadataId3Frame = "NONE" | "PRIV" | "TDRL" | (string & {});
export type HlsTsFileMode = "SEGMENTED_FILES" | "SINGLE_FILE" | (string & {});
export interface HlsGroupSettings {
    AdMarkers?: HlsAdMarkers[];
    BaseUrlContent?: string;
    BaseUrlContent1?: string;
    BaseUrlManifest?: string;
    BaseUrlManifest1?: string;
    CaptionLanguageMappings?: CaptionLanguageMapping[];
    CaptionLanguageSetting?: HlsCaptionLanguageSetting;
    ClientCache?: HlsClientCache;
    CodecSpecification?: HlsCodecSpecification;
    ConstantIv?: string;
    Destination?: OutputLocationRef;
    DirectoryStructure?: HlsDirectoryStructure;
    DiscontinuityTags?: HlsDiscontinuityTags;
    EncryptionType?: HlsEncryptionType;
    HlsCdnSettings?: HlsCdnSettings;
    HlsId3SegmentTagging?: HlsId3SegmentTaggingState;
    IFrameOnlyPlaylists?: IFrameOnlyPlaylistType;
    IncompleteSegmentBehavior?: HlsIncompleteSegmentBehavior;
    IndexNSegments?: number;
    InputLossAction?: InputLossActionForHlsOut;
    IvInManifest?: HlsIvInManifest;
    IvSource?: HlsIvSource;
    KeepSegments?: number;
    KeyFormat?: string;
    KeyFormatVersions?: string;
    KeyProviderSettings?: KeyProviderSettings;
    ManifestCompression?: HlsManifestCompression;
    ManifestDurationFormat?: HlsManifestDurationFormat;
    MinSegmentLength?: number;
    Mode?: HlsMode;
    OutputSelection?: HlsOutputSelection;
    ProgramDateTime?: HlsProgramDateTime;
    ProgramDateTimeClock?: HlsProgramDateTimeClock;
    ProgramDateTimePeriod?: number;
    RedundantManifest?: HlsRedundantManifest;
    SegmentLength?: number;
    SegmentationMode?: HlsSegmentationMode;
    SegmentsPerSubdirectory?: number;
    StreamInfResolution?: HlsStreamInfResolution;
    TimedMetadataId3Frame?: HlsTimedMetadataId3Frame;
    TimedMetadataId3Period?: number;
    TimestampDeltaMilliseconds?: number;
    TsFileMode?: HlsTsFileMode;
}
export type CmafId3Behavior = "DISABLED" | "ENABLED" | (string & {});
export type CmafKLVBehavior = "NO_PASSTHROUGH" | "PASSTHROUGH" | (string & {});
export type CmafNielsenId3Behavior = "NO_PASSTHROUGH" | "PASSTHROUGH" | (string & {});
export type Scte35Type = "NONE" | "SCTE_35_WITHOUT_SEGMENTATION" | "SCTE_35_WITHOUT_IDR" | (string & {});
export type CmafIngestSegmentLengthUnits = "MILLISECONDS" | "SECONDS" | (string & {});
export type CmafTimedMetadataId3Frame = "NONE" | "PRIV" | "TDRL" | (string & {});
export type __integerMin0Max10000 = number;
export type CmafTimedMetadataPassthrough = "DISABLED" | "ENABLED" | (string & {});
export interface MediaPackageAdditionalDestinations {
    Destination?: OutputLocationRef;
}
export type __listOfMediaPackageAdditionalDestinations = MediaPackageAdditionalDestinations[];
export type __listOfOutputLocationRef = OutputLocationRef[];
export type __doubleMin250Max5000 = number;
export type __doubleMinNegative1Max5 = number;
export type __doubleMin32Max46 = number;
export interface AbWatermarkingCustomProfile {
    EmbeddingFrequency?: number;
    SceneCut?: number;
    TargetPsnr?: number;
}
export type __integerMin1Max511 = number;
export type __integerMin1Max1000 = number;
export type AbWatermarkingProfile = "CAMCORDING" | "CUSTOM" | "DEFAULT" | "HQ" | "MEZZANINE" | "ROBUST" | (string & {});
export type AbWatermarkerIdLength = "ID_2048" | "ID_512" | (string & {});
export interface MediaPackageV2AbWatermarkerIrdetoSettings {
    AdditionalDestinationsAlternateDestinations?: OutputLocationRef[];
    AlternateDestination?: OutputLocationRef;
    CustomProfile?: AbWatermarkingCustomProfile;
    License?: string;
    OperatorId?: number;
    PolyPeriod?: number;
    Profile?: AbWatermarkingProfile;
    WatermarkIdLength?: AbWatermarkerIdLength;
}
export interface MediaPackageV2WatermarkingSettings {
    MediaPackageV2AbWatermarkerIrdetoSettings?: MediaPackageV2AbWatermarkerIrdetoSettings;
}
export interface MediaPackageV2GroupSettings {
    CaptionLanguageMappings?: CaptionLanguageMapping[];
    Id3Behavior?: CmafId3Behavior;
    KlvBehavior?: CmafKLVBehavior;
    NielsenId3Behavior?: CmafNielsenId3Behavior;
    Scte35Type?: Scte35Type;
    SegmentLength?: number;
    SegmentLengthUnits?: CmafIngestSegmentLengthUnits;
    TimedMetadataId3Frame?: CmafTimedMetadataId3Frame;
    TimedMetadataId3Period?: number;
    TimedMetadataPassthrough?: CmafTimedMetadataPassthrough;
    AdditionalDestinations?: MediaPackageAdditionalDestinations[];
    WatermarkingSettings?: MediaPackageV2WatermarkingSettings;
}
export interface MediaPackageGroupSettings {
    Destination?: OutputLocationRef;
    MediapackageV2GroupSettings?: MediaPackageV2GroupSettings;
}
export type SmoothGroupAudioOnlyTimecodeControl = "PASSTHROUGH" | "USE_CONFIGURED_CLOCK" | (string & {});
export type SmoothGroupCertificateMode = "SELF_SIGNED" | "VERIFY_AUTHENTICITY" | (string & {});
export type SmoothGroupEventIdMode = "NO_EVENT_ID" | "USE_CONFIGURED" | "USE_TIMESTAMP" | (string & {});
export type SmoothGroupEventStopBehavior = "NONE" | "SEND_EOS" | (string & {});
export type InputLossActionForMsSmoothOut = "EMIT_OUTPUT" | "PAUSE_OUTPUT" | (string & {});
export type SmoothGroupSegmentationMode = "USE_INPUT_SEGMENTATION" | "USE_SEGMENT_DURATION" | (string & {});
export type SmoothGroupSparseTrackType = "NONE" | "SCTE_35" | "SCTE_35_WITHOUT_SEGMENTATION" | (string & {});
export type SmoothGroupStreamManifestBehavior = "DO_NOT_SEND" | "SEND" | (string & {});
export type SmoothGroupTimestampOffsetMode = "USE_CONFIGURED_OFFSET" | "USE_EVENT_START_DATE" | (string & {});
export interface MsSmoothGroupSettings {
    AcquisitionPointId?: string;
    AudioOnlyTimecodeControl?: SmoothGroupAudioOnlyTimecodeControl;
    CertificateMode?: SmoothGroupCertificateMode;
    ConnectionRetryInterval?: number;
    Destination?: OutputLocationRef;
    EventId?: string;
    EventIdMode?: SmoothGroupEventIdMode;
    EventStopBehavior?: SmoothGroupEventStopBehavior;
    FilecacheDuration?: number;
    FragmentLength?: number;
    InputLossAction?: InputLossActionForMsSmoothOut;
    NumRetries?: number;
    RestartDelay?: number;
    SegmentationMode?: SmoothGroupSegmentationMode;
    SendDelayMs?: number;
    SparseTrackType?: SmoothGroupSparseTrackType;
    StreamManifestBehavior?: SmoothGroupStreamManifestBehavior;
    TimestampOffset?: string;
    TimestampOffsetMode?: SmoothGroupTimestampOffsetMode;
}
export interface MultiplexGroupSettings {
}
export type RtmpAdMarkers = "ON_CUE_POINT_SCTE35" | (string & {});
export type __listOfRtmpAdMarkers = RtmpAdMarkers[];
export type AuthenticationScheme = "AKAMAI" | "COMMON" | (string & {});
export type RtmpCacheFullBehavior = "DISCONNECT_IMMEDIATELY" | "WAIT_FOR_SERVER" | (string & {});
export type __integerMin30 = number;
export type RtmpCaptionData = "ALL" | "FIELD1_608" | "FIELD1_AND_FIELD2_608" | (string & {});
export type InputLossActionForRtmpOut = "EMIT_OUTPUT" | "PAUSE_OUTPUT" | (string & {});
export type IncludeFillerNalUnits = "AUTO" | "DROP" | "INCLUDE" | (string & {});
export interface RtmpGroupSettings {
    AdMarkers?: RtmpAdMarkers[];
    AuthenticationScheme?: AuthenticationScheme;
    CacheFullBehavior?: RtmpCacheFullBehavior;
    CacheLength?: number;
    CaptionData?: RtmpCaptionData;
    InputLossAction?: InputLossActionForRtmpOut;
    RestartDelay?: number;
    IncludeFillerNalUnits?: IncludeFillerNalUnits;
}
export type InputLossActionForUdpOut = "DROP_PROGRAM" | "DROP_TS" | "EMIT_PROGRAM" | (string & {});
export type UdpTimedMetadataId3Frame = "NONE" | "PRIV" | "TDRL" | (string & {});
export interface UdpGroupSettings {
    InputLossAction?: InputLossActionForUdpOut;
    TimedMetadataId3Frame?: UdpTimedMetadataId3Frame;
    TimedMetadataId3Period?: number;
}
export type __integerMin0Max2000 = number;
export type __stringMax100 = string;
export interface CmafIngestCaptionLanguageMapping {
    CaptionChannel?: number;
    LanguageCode?: string;
}
export type __listOfCmafIngestCaptionLanguageMapping = CmafIngestCaptionLanguageMapping[];
export interface AdditionalDestinations {
    Destination?: OutputLocationRef;
}
export type __listOfAdditionalDestinations = AdditionalDestinations[];
export interface CmafIngestAbWatermarkerIrdetoSettings {
    AdditionalDestinationsAlternateDestinations?: OutputLocationRef[];
    AlternateDestination?: OutputLocationRef;
    CustomProfile?: AbWatermarkingCustomProfile;
    License?: string;
    OperatorId?: number;
    PolyPeriod?: number;
    Profile?: AbWatermarkingProfile;
    WatermarkIdLength?: AbWatermarkerIdLength;
}
export interface CmafIngestWatermarkingSettings {
    CmafIngestAbWatermarkerIrdetoSettings?: CmafIngestAbWatermarkerIrdetoSettings;
}
export interface CmafIngestGroupSettings {
    Destination?: OutputLocationRef;
    NielsenId3Behavior?: CmafNielsenId3Behavior;
    Scte35Type?: Scte35Type;
    SegmentLength?: number;
    SegmentLengthUnits?: CmafIngestSegmentLengthUnits;
    SendDelayMs?: number;
    KlvBehavior?: CmafKLVBehavior;
    KlvNameModifier?: string;
    NielsenId3NameModifier?: string;
    Scte35NameModifier?: string;
    Id3Behavior?: CmafId3Behavior;
    Id3NameModifier?: string;
    CaptionLanguageMappings?: CmafIngestCaptionLanguageMapping[];
    TimedMetadataId3Frame?: CmafTimedMetadataId3Frame;
    TimedMetadataId3Period?: number;
    TimedMetadataPassthrough?: CmafTimedMetadataPassthrough;
    AdditionalDestinations?: AdditionalDestinations[];
    WatermarkingSettings?: CmafIngestWatermarkingSettings;
}
export interface SrtGroupSettings {
    InputLossAction?: InputLossActionForUdpOut;
}
export interface MediaConnectRouterGroupSettings {
    AvailabilityZones?: string[];
}
export interface OutputGroupSettings {
    ArchiveGroupSettings?: ArchiveGroupSettings;
    FrameCaptureGroupSettings?: FrameCaptureGroupSettings;
    HlsGroupSettings?: HlsGroupSettings;
    MediaPackageGroupSettings?: MediaPackageGroupSettings;
    MsSmoothGroupSettings?: MsSmoothGroupSettings;
    MultiplexGroupSettings?: MultiplexGroupSettings;
    RtmpGroupSettings?: RtmpGroupSettings;
    UdpGroupSettings?: UdpGroupSettings;
    CmafIngestGroupSettings?: CmafIngestGroupSettings;
    SrtGroupSettings?: SrtGroupSettings;
    MediaConnectRouterGroupSettings?: MediaConnectRouterGroupSettings;
}
export type __stringMin1Max255 = string;
export type M2tsAbsentInputAudioBehavior = "DROP" | "ENCODE_SILENCE" | (string & {});
export type M2tsArib = "DISABLED" | "ENABLED" | (string & {});
export type M2tsAribCaptionsPidControl = "AUTO" | "USE_CONFIGURED" | (string & {});
export type M2tsAudioBufferModel = "ATSC" | "DVB" | (string & {});
export type M2tsAudioStreamType = "ATSC" | "DVB" | (string & {});
export type M2tsBufferModel = "MULTIPLEX" | "NONE" | (string & {});
export type M2tsCcDescriptor = "DISABLED" | "ENABLED" | (string & {});
export type __integerMin0Max65536 = number;
export type __stringMin1Max256 = string;
export type __integerMin25Max10000 = number;
export interface DvbNitSettings {
    NetworkId?: number;
    NetworkName?: string;
    RepInterval?: number;
}
export type DvbSdtOutputSdt = "SDT_FOLLOW" | "SDT_FOLLOW_IF_PRESENT" | "SDT_MANUAL" | "SDT_NONE" | (string & {});
export type __integerMin25Max2000 = number;
export interface DvbSdtSettings {
    OutputSdt?: DvbSdtOutputSdt;
    RepInterval?: number;
    ServiceName?: string;
    ServiceProviderName?: string;
}
export type __integerMin1000Max30000 = number;
export interface DvbTdtSettings {
    RepInterval?: number;
}
export type M2tsEbifControl = "NONE" | "PASSTHROUGH" | (string & {});
export type M2tsAudioInterval = "VIDEO_AND_FIXED_INTERVALS" | "VIDEO_INTERVAL" | (string & {});
export type M2tsEbpPlacement = "VIDEO_AND_AUDIO_PIDS" | "VIDEO_PID" | (string & {});
export type M2tsEsRateInPes = "EXCLUDE" | "INCLUDE" | (string & {});
export type __doubleMin0 = number;
export type M2tsKlv = "NONE" | "PASSTHROUGH" | (string & {});
export type M2tsNielsenId3Behavior = "NO_PASSTHROUGH" | "PASSTHROUGH" | (string & {});
export type __integerMin0Max1000 = number;
export type M2tsPcrControl = "CONFIGURED_PCR_PERIOD" | "PCR_EVERY_PES_PACKET" | (string & {});
export type __integerMin0Max500 = number;
export type __integerMin0Max65535 = number;
export type M2tsRateMode = "CBR" | "VBR" | (string & {});
export type M2tsScte35Control = "NONE" | "PASSTHROUGH" | "SCTE_35_WITHOUT_IDR" | (string & {});
export type M2tsSegmentationMarkers = "EBP" | "EBP_LEGACY" | "NONE" | "PSI_SEGSTART" | "RAI_ADAPT" | "RAI_SEGSTART" | (string & {});
export type M2tsSegmentationStyle = "MAINTAIN_CADENCE" | "RESET_CADENCE" | (string & {});
export type __doubleMin1 = number;
export type M2tsTimedMetadataBehavior = "NO_PASSTHROUGH" | "PASSTHROUGH" | (string & {});
export type __doubleMin0Max5000 = number;
export interface M2tsSettings {
    AbsentInputAudioBehavior?: M2tsAbsentInputAudioBehavior;
    Arib?: M2tsArib;
    AribCaptionsPid?: string;
    AribCaptionsPidControl?: M2tsAribCaptionsPidControl;
    AudioBufferModel?: M2tsAudioBufferModel;
    AudioFramesPerPes?: number;
    AudioPids?: string;
    AudioStreamType?: M2tsAudioStreamType;
    Bitrate?: number;
    BufferModel?: M2tsBufferModel;
    CcDescriptor?: M2tsCcDescriptor;
    DvbNitSettings?: DvbNitSettings;
    DvbSdtSettings?: DvbSdtSettings;
    DvbSubPids?: string;
    DvbTdtSettings?: DvbTdtSettings;
    DvbTeletextPid?: string;
    Ebif?: M2tsEbifControl;
    EbpAudioInterval?: M2tsAudioInterval;
    EbpLookaheadMs?: number;
    EbpPlacement?: M2tsEbpPlacement;
    EcmPid?: string;
    EsRateInPes?: M2tsEsRateInPes;
    EtvPlatformPid?: string;
    EtvSignalPid?: string;
    FragmentTime?: number;
    Klv?: M2tsKlv;
    KlvDataPids?: string;
    NielsenId3Behavior?: M2tsNielsenId3Behavior;
    NullPacketBitrate?: number;
    PatInterval?: number;
    PcrControl?: M2tsPcrControl;
    PcrPeriod?: number;
    PcrPid?: string;
    PmtInterval?: number;
    PmtPid?: string;
    ProgramNum?: number;
    RateMode?: M2tsRateMode;
    Scte27Pids?: string;
    Scte35Control?: M2tsScte35Control;
    Scte35Pid?: string;
    SegmentationMarkers?: M2tsSegmentationMarkers;
    SegmentationStyle?: M2tsSegmentationStyle;
    SegmentationTime?: number;
    TimedMetadataBehavior?: M2tsTimedMetadataBehavior;
    TimedMetadataPid?: string;
    TransportStreamId?: number;
    VideoPid?: string;
    Scte35PrerollPullupMilliseconds?: number;
}
export interface RawSettings {
}
export interface ArchiveContainerSettings {
    M2tsSettings?: M2tsSettings;
    RawSettings?: RawSettings;
}
export interface ArchiveOutputSettings {
    ContainerSettings?: ArchiveContainerSettings;
    Extension?: string;
    NameModifier?: string;
}
export interface FrameCaptureOutputSettings {
    NameModifier?: string;
}
export type HlsH265PackagingType = "HEV1" | "HVC1" | (string & {});
export type AudioOnlyHlsTrackType = "ALTERNATE_AUDIO_AUTO_SELECT" | "ALTERNATE_AUDIO_AUTO_SELECT_DEFAULT" | "ALTERNATE_AUDIO_NOT_AUTO_SELECT" | "AUDIO_ONLY_VARIANT_STREAM" | (string & {});
export type AudioOnlyHlsSegmentType = "AAC" | "FMP4" | (string & {});
export interface AudioOnlyHlsSettings {
    AudioGroupId?: string;
    AudioOnlyImage?: InputLocation;
    AudioTrackType?: AudioOnlyHlsTrackType;
    SegmentType?: AudioOnlyHlsSegmentType;
}
export type Fmp4NielsenId3Behavior = "NO_PASSTHROUGH" | "PASSTHROUGH" | (string & {});
export type Fmp4TimedMetadataBehavior = "NO_PASSTHROUGH" | "PASSTHROUGH" | (string & {});
export interface Fmp4HlsSettings {
    AudioRenditionSets?: string;
    NielsenId3Behavior?: Fmp4NielsenId3Behavior;
    TimedMetadataBehavior?: Fmp4TimedMetadataBehavior;
}
export interface FrameCaptureHlsSettings {
}
export type M3u8NielsenId3Behavior = "NO_PASSTHROUGH" | "PASSTHROUGH" | (string & {});
export type M3u8PcrControl = "CONFIGURED_PCR_PERIOD" | "PCR_EVERY_PES_PACKET" | (string & {});
export type M3u8Scte35Behavior = "NO_PASSTHROUGH" | "PASSTHROUGH" | (string & {});
export type M3u8TimedMetadataBehavior = "NO_PASSTHROUGH" | "PASSTHROUGH" | (string & {});
export type M3u8KlvBehavior = "NO_PASSTHROUGH" | "PASSTHROUGH" | (string & {});
export interface M3u8Settings {
    AudioFramesPerPes?: number;
    AudioPids?: string;
    EcmPid?: string;
    NielsenId3Behavior?: M3u8NielsenId3Behavior;
    PatInterval?: number;
    PcrControl?: M3u8PcrControl;
    PcrPeriod?: number;
    PcrPid?: string;
    PmtInterval?: number;
    PmtPid?: string;
    ProgramNum?: number;
    Scte35Behavior?: M3u8Scte35Behavior;
    Scte35Pid?: string;
    TimedMetadataBehavior?: M3u8TimedMetadataBehavior;
    TimedMetadataPid?: string;
    TransportStreamId?: number;
    VideoPid?: string;
    KlvBehavior?: M3u8KlvBehavior;
    KlvDataPids?: string;
}
export interface StandardHlsSettings {
    AudioRenditionSets?: string;
    M3u8Settings?: M3u8Settings;
}
export interface HlsSettings {
    AudioOnlyHlsSettings?: AudioOnlyHlsSettings;
    Fmp4HlsSettings?: Fmp4HlsSettings;
    FrameCaptureHlsSettings?: FrameCaptureHlsSettings;
    StandardHlsSettings?: StandardHlsSettings;
}
export interface HlsOutputSettings {
    H265PackagingType?: HlsH265PackagingType;
    HlsSettings?: HlsSettings;
    NameModifier?: string;
    SegmentModifier?: string;
}
export type HlsAutoSelect = "NO" | "OMIT" | "YES" | (string & {});
export type HlsDefault = "NO" | "OMIT" | "YES" | (string & {});
export type OutputUsage = "MULTIVIEW_EQUAL_SIZE_VIEW" | "MULTIVIEW_PRIMARY_VIEW" | "MULTIVIEW_SECONDARY_VIEW" | (string & {});
export type __listOfOutputUsage = OutputUsage[];
export interface MediaPackageV2DestinationSettings {
    AudioGroupId?: string;
    AudioRenditionSets?: string;
    HlsAutoSelect?: HlsAutoSelect;
    HlsDefault?: HlsDefault;
    OutputUsage?: OutputUsage[];
}
export interface MediaPackageOutputSettings {
    MediaPackageV2DestinationSettings?: MediaPackageV2DestinationSettings;
}
export type MsSmoothH265PackagingType = "HEV1" | "HVC1" | (string & {});
export interface MsSmoothOutputSettings {
    H265PackagingType?: MsSmoothH265PackagingType;
    NameModifier?: string;
}
export interface MultiplexM2tsSettings {
    AbsentInputAudioBehavior?: M2tsAbsentInputAudioBehavior;
    Arib?: M2tsArib;
    AudioBufferModel?: M2tsAudioBufferModel;
    AudioFramesPerPes?: number;
    AudioStreamType?: M2tsAudioStreamType;
    CcDescriptor?: M2tsCcDescriptor;
    Ebif?: M2tsEbifControl;
    EsRateInPes?: M2tsEsRateInPes;
    Klv?: M2tsKlv;
    NielsenId3Behavior?: M2tsNielsenId3Behavior;
    PcrControl?: M2tsPcrControl;
    PcrPeriod?: number;
    Scte35Control?: M2tsScte35Control;
    Scte35PrerollPullupMilliseconds?: number;
}
export interface MultiplexContainerSettings {
    MultiplexM2tsSettings?: MultiplexM2tsSettings;
}
export interface MultiplexOutputSettings {
    Destination?: OutputLocationRef;
    ContainerSettings?: MultiplexContainerSettings;
}
export type RtmpOutputCertificateMode = "SELF_SIGNED" | "VERIFY_AUTHENTICITY" | (string & {});
export interface RtmpOutputSettings {
    CertificateMode?: RtmpOutputCertificateMode;
    ConnectionRetryInterval?: number;
    Destination?: OutputLocationRef;
    NumRetries?: number;
}
export interface UdpContainerSettings {
    M2tsSettings?: M2tsSettings;
}
export type __integerMin4Max20 = number;
export type FecOutputIncludeFec = "COLUMN" | "COLUMN_AND_ROW" | (string & {});
export type __integerMin1Max20 = number;
export interface FecOutputSettings {
    ColumnDepth?: number;
    IncludeFec?: FecOutputIncludeFec;
    RowLength?: number;
}
export interface UdpOutputSettings {
    BufferMsec?: number;
    ContainerSettings?: UdpContainerSettings;
    Destination?: OutputLocationRef;
    FecOutputSettings?: FecOutputSettings;
}
export interface CmafIngestOutputSettings {
    NameModifier?: string;
}
export type SrtEncryptionType = "AES128" | "AES192" | "AES256" | (string & {});
export type __integerMin40Max16000 = number;
export interface SrtOutputSettings {
    BufferMsec?: number;
    ContainerSettings?: UdpContainerSettings;
    Destination?: OutputLocationRef;
    EncryptionType?: SrtEncryptionType;
    Latency?: number;
}
export interface MediaConnectRouterOutputConnectionMap {
    Pipeline0?: string;
    Pipeline1?: string;
}
export interface MediaConnectRouterContainerSettings {
    M2tsSettings?: M2tsSettings;
}
export interface MediaConnectRouterOutputSettings {
    ConnectedRouterInputs?: MediaConnectRouterOutputConnectionMap;
    ContainerSettings?: MediaConnectRouterContainerSettings;
    Destination?: OutputLocationRef;
}
export interface OutputSettings {
    ArchiveOutputSettings?: ArchiveOutputSettings;
    FrameCaptureOutputSettings?: FrameCaptureOutputSettings;
    HlsOutputSettings?: HlsOutputSettings;
    MediaPackageOutputSettings?: MediaPackageOutputSettings;
    MsSmoothOutputSettings?: MsSmoothOutputSettings;
    MultiplexOutputSettings?: MultiplexOutputSettings;
    RtmpOutputSettings?: RtmpOutputSettings;
    UdpOutputSettings?: UdpOutputSettings;
    CmafIngestOutputSettings?: CmafIngestOutputSettings;
    SrtOutputSettings?: SrtOutputSettings;
    MediaConnectRouterOutputSettings?: MediaConnectRouterOutputSettings;
}
export interface Output {
    AudioDescriptionNames?: string[];
    CaptionDescriptionNames?: string[];
    OutputName?: string;
    OutputSettings?: OutputSettings;
    VideoDescriptionName?: string;
}
export type __listOfOutput = Output[];
export interface OutputGroup {
    Name?: string;
    OutputGroupSettings?: OutputGroupSettings;
    Outputs?: Output[];
}
export type __listOfOutputGroup = OutputGroup[];
export type TimecodeConfigSource = "EMBEDDED" | "SYSTEMCLOCK" | "ZEROBASED" | (string & {});
export type __integerMin1Max1000000 = number;
export interface TimecodeConfig {
    Source?: TimecodeConfigSource;
    SyncThreshold?: number;
}
export type __integerMin1Max3600000 = number;
export type FrameCaptureIntervalUnit = "MILLISECONDS" | "SECONDS" | (string & {});
export type TimecodeBurninFontSize = "EXTRA_SMALL_10" | "LARGE_48" | "MEDIUM_32" | "SMALL_16" | (string & {});
export type TimecodeBurninPosition = "BOTTOM_CENTER" | "BOTTOM_LEFT" | "BOTTOM_RIGHT" | "MIDDLE_CENTER" | "MIDDLE_LEFT" | "MIDDLE_RIGHT" | "TOP_CENTER" | "TOP_LEFT" | "TOP_RIGHT" | (string & {});
export interface TimecodeBurninSettings {
    FontSize?: TimecodeBurninFontSize;
    Position?: TimecodeBurninPosition;
    Prefix?: string;
}
export interface FrameCaptureSettings {
    CaptureInterval?: number;
    CaptureIntervalUnits?: FrameCaptureIntervalUnit;
    TimecodeBurninSettings?: TimecodeBurninSettings;
}
export type H264AdaptiveQuantization = "AUTO" | "HIGH" | "HIGHER" | "LOW" | "MAX" | "MEDIUM" | "OFF" | (string & {});
export type AfdSignaling = "AUTO" | "FIXED" | "NONE" | (string & {});
export type __integerMin1000 = number;
export type H264ColorMetadata = "IGNORE" | "INSERT" | (string & {});
export interface ColorSpacePassthroughSettings {
}
export interface Rec601Settings {
}
export interface Rec709Settings {
}
export interface H264ColorSpaceSettings {
    ColorSpacePassthroughSettings?: ColorSpacePassthroughSettings;
    Rec601Settings?: Rec601Settings;
    Rec709Settings?: Rec709Settings;
}
export type H264EntropyEncoding = "CABAC" | "CAVLC" | (string & {});
export type TemporalFilterPostFilterSharpening = "AUTO" | "DISABLED" | "ENABLED" | (string & {});
export type TemporalFilterStrength = "AUTO" | "STRENGTH_1" | "STRENGTH_2" | "STRENGTH_3" | "STRENGTH_4" | "STRENGTH_5" | "STRENGTH_6" | "STRENGTH_7" | "STRENGTH_8" | "STRENGTH_9" | "STRENGTH_10" | "STRENGTH_11" | "STRENGTH_12" | "STRENGTH_13" | "STRENGTH_14" | "STRENGTH_15" | "STRENGTH_16" | (string & {});
export interface TemporalFilterSettings {
    PostFilterSharpening?: TemporalFilterPostFilterSharpening;
    Strength?: TemporalFilterStrength;
}
export type BandwidthReductionPostFilterSharpening = "DISABLED" | "SHARPENING_1" | "SHARPENING_2" | "SHARPENING_3" | (string & {});
export type BandwidthReductionFilterStrength = "AUTO" | "STRENGTH_1" | "STRENGTH_2" | "STRENGTH_3" | "STRENGTH_4" | (string & {});
export interface BandwidthReductionFilterSettings {
    PostFilterSharpening?: BandwidthReductionPostFilterSharpening;
    Strength?: BandwidthReductionFilterStrength;
}
export interface H264FilterSettings {
    TemporalFilterSettings?: TemporalFilterSettings;
    BandwidthReductionFilterSettings?: BandwidthReductionFilterSettings;
}
export type FixedAfd = "AFD_0000" | "AFD_0010" | "AFD_0011" | "AFD_0100" | "AFD_1000" | "AFD_1001" | "AFD_1010" | "AFD_1011" | "AFD_1101" | "AFD_1110" | "AFD_1111" | (string & {});
export type H264FlickerAq = "DISABLED" | "ENABLED" | (string & {});
export type H264ForceFieldPictures = "DISABLED" | "ENABLED" | (string & {});
export type H264FramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type H264GopBReference = "DISABLED" | "ENABLED" | (string & {});
export type H264GopSizeUnits = "FRAMES" | "SECONDS" | (string & {});
export type H264Level = "H264_LEVEL_1" | "H264_LEVEL_1_1" | "H264_LEVEL_1_2" | "H264_LEVEL_1_3" | "H264_LEVEL_2" | "H264_LEVEL_2_1" | "H264_LEVEL_2_2" | "H264_LEVEL_3" | "H264_LEVEL_3_1" | "H264_LEVEL_3_2" | "H264_LEVEL_4" | "H264_LEVEL_4_1" | "H264_LEVEL_4_2" | "H264_LEVEL_5" | "H264_LEVEL_5_1" | "H264_LEVEL_5_2" | "H264_LEVEL_AUTO" | (string & {});
export type H264LookAheadRateControl = "HIGH" | "LOW" | "MEDIUM" | (string & {});
export type __integerMin0Max30 = number;
export type __integerMin1Max6 = number;
export type H264ParControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type H264Profile = "BASELINE" | "HIGH" | "HIGH_10BIT" | "HIGH_422" | "HIGH_422_10BIT" | "MAIN" | (string & {});
export type H264QualityLevel = "ENHANCED_QUALITY" | "STANDARD_QUALITY" | (string & {});
export type __integerMin1Max10 = number;
export type H264RateControlMode = "CBR" | "MULTIPLEX" | "QVBR" | "VBR" | (string & {});
export type H264ScanType = "INTERLACED" | "PROGRESSIVE" | (string & {});
export type H264SceneChangeDetect = "DISABLED" | "ENABLED" | (string & {});
export type __integerMin1Max32 = number;
export type __integerMin0Max128 = number;
export type H264SpatialAq = "DISABLED" | "ENABLED" | (string & {});
export type H264SubGopLength = "DYNAMIC" | "FIXED" | (string & {});
export type H264Syntax = "DEFAULT" | "RP2027" | (string & {});
export type H264TemporalAq = "DISABLED" | "ENABLED" | (string & {});
export type H264TimecodeInsertionBehavior = "DISABLED" | "PIC_TIMING_SEI" | (string & {});
export type __integerMin1Max51 = number;
export interface H264Settings {
    AdaptiveQuantization?: H264AdaptiveQuantization;
    AfdSignaling?: AfdSignaling;
    Bitrate?: number;
    BufFillPct?: number;
    BufSize?: number;
    ColorMetadata?: H264ColorMetadata;
    ColorSpaceSettings?: H264ColorSpaceSettings;
    EntropyEncoding?: H264EntropyEncoding;
    FilterSettings?: H264FilterSettings;
    FixedAfd?: FixedAfd;
    FlickerAq?: H264FlickerAq;
    ForceFieldPictures?: H264ForceFieldPictures;
    FramerateControl?: H264FramerateControl;
    FramerateDenominator?: number;
    FramerateNumerator?: number;
    GopBReference?: H264GopBReference;
    GopClosedCadence?: number;
    GopNumBFrames?: number;
    GopSize?: number;
    GopSizeUnits?: H264GopSizeUnits;
    Level?: H264Level;
    LookAheadRateControl?: H264LookAheadRateControl;
    MaxBitrate?: number;
    MinIInterval?: number;
    NumRefFrames?: number;
    ParControl?: H264ParControl;
    ParDenominator?: number;
    ParNumerator?: number;
    Profile?: H264Profile;
    QualityLevel?: H264QualityLevel;
    QvbrQualityLevel?: number;
    RateControlMode?: H264RateControlMode;
    ScanType?: H264ScanType;
    SceneChangeDetect?: H264SceneChangeDetect;
    Slices?: number;
    Softness?: number;
    SpatialAq?: H264SpatialAq;
    SubgopLength?: H264SubGopLength;
    Syntax?: H264Syntax;
    TemporalAq?: H264TemporalAq;
    TimecodeInsertion?: H264TimecodeInsertionBehavior;
    TimecodeBurninSettings?: TimecodeBurninSettings;
    MinQp?: number;
    MinBitrate?: number;
}
export type H265AdaptiveQuantization = "AUTO" | "HIGH" | "HIGHER" | "LOW" | "MAX" | "MEDIUM" | "OFF" | (string & {});
export type H265AlternativeTransferFunction = "INSERT" | "OMIT" | (string & {});
export type __integerMin100000Max40000000 = number;
export type __integerMin100000Max80000000 = number;
export type H265ColorMetadata = "IGNORE" | "INSERT" | (string & {});
export interface DolbyVision81Settings {
}
export type __integerMin0Max32768 = number;
export interface Hdr10Settings {
    MaxCll?: number;
    MaxFall?: number;
}
export interface Hlg2020Settings {
}
export interface H265ColorSpaceSettings {
    ColorSpacePassthroughSettings?: ColorSpacePassthroughSettings;
    DolbyVision81Settings?: DolbyVision81Settings;
    Hdr10Settings?: Hdr10Settings;
    Rec601Settings?: Rec601Settings;
    Rec709Settings?: Rec709Settings;
    Hlg2020Settings?: Hlg2020Settings;
}
export interface H265FilterSettings {
    TemporalFilterSettings?: TemporalFilterSettings;
    BandwidthReductionFilterSettings?: BandwidthReductionFilterSettings;
}
export type H265FlickerAq = "DISABLED" | "ENABLED" | (string & {});
export type __integerMin1Max3003 = number;
export type H265GopSizeUnits = "FRAMES" | "SECONDS" | (string & {});
export type H265Level = "H265_LEVEL_1" | "H265_LEVEL_2" | "H265_LEVEL_2_1" | "H265_LEVEL_3" | "H265_LEVEL_3_1" | "H265_LEVEL_4" | "H265_LEVEL_4_1" | "H265_LEVEL_5" | "H265_LEVEL_5_1" | "H265_LEVEL_5_2" | "H265_LEVEL_6" | "H265_LEVEL_6_1" | "H265_LEVEL_6_2" | "H265_LEVEL_AUTO" | (string & {});
export type H265LookAheadRateControl = "HIGH" | "LOW" | "MEDIUM" | (string & {});
export type H265Profile = "MAIN" | "MAIN_10BIT" | (string & {});
export type H265RateControlMode = "CBR" | "MULTIPLEX" | "QVBR" | (string & {});
export type H265ScanType = "INTERLACED" | "PROGRESSIVE" | (string & {});
export type H265SceneChangeDetect = "DISABLED" | "ENABLED" | (string & {});
export type H265Tier = "HIGH" | "MAIN" | (string & {});
export type H265TimecodeInsertionBehavior = "DISABLED" | "PIC_TIMING_SEI" | (string & {});
export type H265MvOverPictureBoundaries = "DISABLED" | "ENABLED" | (string & {});
export type H265MvTemporalPredictor = "DISABLED" | "ENABLED" | (string & {});
export type __integerMin64Max2160 = number;
export type H265TilePadding = "NONE" | "PADDED" | (string & {});
export type __integerMin256Max3840 = number;
export type H265TreeblockSize = "AUTO" | "TREE_SIZE_32X32" | (string & {});
export type H265Deblocking = "DISABLED" | "ENABLED" | (string & {});
export type H265GopBReference = "DISABLED" | "ENABLED" | (string & {});
export type __integerMin0Max3 = number;
export type __integerMin0Max40000000 = number;
export type H265SubGopLength = "DYNAMIC" | "FIXED" | (string & {});
export interface H265Settings {
    AdaptiveQuantization?: H265AdaptiveQuantization;
    AfdSignaling?: AfdSignaling;
    AlternativeTransferFunction?: H265AlternativeTransferFunction;
    Bitrate?: number;
    BufSize?: number;
    ColorMetadata?: H265ColorMetadata;
    ColorSpaceSettings?: H265ColorSpaceSettings;
    FilterSettings?: H265FilterSettings;
    FixedAfd?: FixedAfd;
    FlickerAq?: H265FlickerAq;
    FramerateDenominator?: number;
    FramerateNumerator?: number;
    GopClosedCadence?: number;
    GopSize?: number;
    GopSizeUnits?: H265GopSizeUnits;
    Level?: H265Level;
    LookAheadRateControl?: H265LookAheadRateControl;
    MaxBitrate?: number;
    MinIInterval?: number;
    ParDenominator?: number;
    ParNumerator?: number;
    Profile?: H265Profile;
    QvbrQualityLevel?: number;
    RateControlMode?: H265RateControlMode;
    ScanType?: H265ScanType;
    SceneChangeDetect?: H265SceneChangeDetect;
    Slices?: number;
    Tier?: H265Tier;
    TimecodeInsertion?: H265TimecodeInsertionBehavior;
    TimecodeBurninSettings?: TimecodeBurninSettings;
    MvOverPictureBoundaries?: H265MvOverPictureBoundaries;
    MvTemporalPredictor?: H265MvTemporalPredictor;
    TileHeight?: number;
    TilePadding?: H265TilePadding;
    TileWidth?: number;
    TreeblockSize?: H265TreeblockSize;
    MinQp?: number;
    Deblocking?: H265Deblocking;
    GopBReference?: H265GopBReference;
    GopNumBFrames?: number;
    MinBitrate?: number;
    SubgopLength?: H265SubGopLength;
}
export type Mpeg2AdaptiveQuantization = "AUTO" | "HIGH" | "LOW" | "MEDIUM" | "OFF" | (string & {});
export type Mpeg2ColorMetadata = "IGNORE" | "INSERT" | (string & {});
export type Mpeg2ColorSpace = "AUTO" | "PASSTHROUGH" | (string & {});
export type Mpeg2DisplayRatio = "DISPLAYRATIO16X9" | "DISPLAYRATIO4X3" | (string & {});
export interface Mpeg2FilterSettings {
    TemporalFilterSettings?: TemporalFilterSettings;
}
export type Mpeg2GopSizeUnits = "FRAMES" | "SECONDS" | (string & {});
export type Mpeg2ScanType = "INTERLACED" | "PROGRESSIVE" | (string & {});
export type Mpeg2SubGopLength = "DYNAMIC" | "FIXED" | (string & {});
export type Mpeg2TimecodeInsertionBehavior = "DISABLED" | "GOP_TIMECODE" | (string & {});
export interface Mpeg2Settings {
    AdaptiveQuantization?: Mpeg2AdaptiveQuantization;
    AfdSignaling?: AfdSignaling;
    ColorMetadata?: Mpeg2ColorMetadata;
    ColorSpace?: Mpeg2ColorSpace;
    DisplayAspectRatio?: Mpeg2DisplayRatio;
    FilterSettings?: Mpeg2FilterSettings;
    FixedAfd?: FixedAfd;
    FramerateDenominator?: number;
    FramerateNumerator?: number;
    GopClosedCadence?: number;
    GopNumBFrames?: number;
    GopSize?: number;
    GopSizeUnits?: Mpeg2GopSizeUnits;
    ScanType?: Mpeg2ScanType;
    SubgopLength?: Mpeg2SubGopLength;
    TimecodeInsertion?: Mpeg2TimecodeInsertionBehavior;
    TimecodeBurninSettings?: TimecodeBurninSettings;
}
export type __integerMin50000Max24000000 = number;
export interface Av1ColorSpaceSettings {
    ColorSpacePassthroughSettings?: ColorSpacePassthroughSettings;
    Hdr10Settings?: Hdr10Settings;
    Rec601Settings?: Rec601Settings;
    Rec709Settings?: Rec709Settings;
    Hlg2020Settings?: Hlg2020Settings;
}
export type Av1GopSizeUnits = "FRAMES" | "SECONDS" | (string & {});
export type Av1Level = "AV1_LEVEL_2" | "AV1_LEVEL_2_1" | "AV1_LEVEL_3" | "AV1_LEVEL_3_1" | "AV1_LEVEL_4" | "AV1_LEVEL_4_1" | "AV1_LEVEL_5" | "AV1_LEVEL_5_1" | "AV1_LEVEL_5_2" | "AV1_LEVEL_5_3" | "AV1_LEVEL_6" | "AV1_LEVEL_6_1" | "AV1_LEVEL_6_2" | "AV1_LEVEL_6_3" | "AV1_LEVEL_AUTO" | (string & {});
export type Av1LookAheadRateControl = "HIGH" | "LOW" | "MEDIUM" | (string & {});
export type __integerMin50000Max12000000 = number;
export type Av1SceneChangeDetect = "DISABLED" | "ENABLED" | (string & {});
export type Av1RateControlMode = "CBR" | "QVBR" | (string & {});
export type __integerMin0Max8000000 = number;
export type Av1SpatialAq = "DISABLED" | "ENABLED" | (string & {});
export type Av1TemporalAq = "DISABLED" | "ENABLED" | (string & {});
export type Av1TimecodeInsertionBehavior = "DISABLED" | "METADATA_OBU" | (string & {});
export type Av1BitDepth = "DEPTH_10" | "DEPTH_8" | (string & {});
export interface Av1Settings {
    AfdSignaling?: AfdSignaling;
    BufSize?: number;
    ColorSpaceSettings?: Av1ColorSpaceSettings;
    FixedAfd?: FixedAfd;
    FramerateDenominator?: number;
    FramerateNumerator?: number;
    GopSize?: number;
    GopSizeUnits?: Av1GopSizeUnits;
    Level?: Av1Level;
    LookAheadRateControl?: Av1LookAheadRateControl;
    MaxBitrate?: number;
    MinIInterval?: number;
    ParDenominator?: number;
    ParNumerator?: number;
    QvbrQualityLevel?: number;
    SceneChangeDetect?: Av1SceneChangeDetect;
    TimecodeBurninSettings?: TimecodeBurninSettings;
    Bitrate?: number;
    RateControlMode?: Av1RateControlMode;
    MinBitrate?: number;
    SpatialAq?: Av1SpatialAq;
    TemporalAq?: Av1TemporalAq;
    TimecodeInsertion?: Av1TimecodeInsertionBehavior;
    BitDepth?: Av1BitDepth;
}
export interface VideoCodecSettings {
    FrameCaptureSettings?: FrameCaptureSettings;
    H264Settings?: H264Settings;
    H265Settings?: H265Settings;
    Mpeg2Settings?: Mpeg2Settings;
    Av1Settings?: Av1Settings;
}
export type VideoDescriptionRespondToAfd = "NONE" | "PASSTHROUGH" | "RESPOND" | (string & {});
export type VideoDescriptionScalingBehavior = "DEFAULT" | "STRETCH_TO_OUTPUT" | "SMART_CROP" | (string & {});
export type __integerMin2Max8192 = number;
export type __integerMin0Max8190 = number;
export interface VideoPositionRectangle {
    Height?: number;
    Width?: number;
    X?: number;
    Y?: number;
}
export interface VideoDescription {
    CodecSettings?: VideoCodecSettings;
    Height?: number;
    Name?: string;
    RespondToAfd?: VideoDescriptionRespondToAfd;
    ScalingBehavior?: VideoDescriptionScalingBehavior;
    Sharpness?: number;
    Width?: number;
    CropRectangle?: VideoPositionRectangle;
    OutputPositionRectangle?: VideoPositionRectangle;
    Border?: number;
}
export type __listOfVideoDescription = VideoDescription[];
export type ThumbnailState = "AUTO" | "DISABLED" | (string & {});
export interface ThumbnailConfiguration {
    State?: ThumbnailState;
}
export type ColorSpace = "HDR10" | "HLG_2020" | "REC_601" | "REC_709" | (string & {});
export interface ColorCorrection {
    InputColorSpace?: ColorSpace;
    OutputColorSpace?: ColorSpace;
    Uri?: string;
}
export type __listOfColorCorrection = ColorCorrection[];
export interface ColorCorrectionSettings {
    GlobalColorCorrections?: ColorCorrection[];
}
export interface EncoderSettings {
    AudioDescriptions?: AudioDescription[];
    AvailBlanking?: AvailBlanking;
    AvailConfiguration?: AvailConfiguration;
    BlackoutSlate?: BlackoutSlate;
    CaptionDescriptions?: CaptionDescription[];
    FeatureActivations?: FeatureActivations;
    GlobalConfiguration?: GlobalConfiguration;
    MotionGraphicsConfiguration?: MotionGraphicsConfiguration;
    NielsenConfiguration?: NielsenConfiguration;
    OutputGroups?: OutputGroup[];
    TimecodeConfig?: TimecodeConfig;
    VideoDescriptions?: VideoDescription[];
    ThumbnailConfiguration?: ThumbnailConfiguration;
    ColorCorrectionSettings?: ColorCorrectionSettings;
}
export interface AudioSilenceFailoverSettings {
    AudioSelectorName?: string;
    AudioSilenceThresholdMsec?: number;
}
export type __integerMin100 = number;
export interface InputLossFailoverSettings {
    InputLossThresholdMsec?: number;
}
export type __doubleMin0Max1 = number;
export interface VideoBlackFailoverSettings {
    BlackDetectThreshold?: number;
    VideoBlackThresholdMsec?: number;
}
export interface FailoverConditionSettings {
    AudioSilenceSettings?: AudioSilenceFailoverSettings;
    InputLossSettings?: InputLossFailoverSettings;
    VideoBlackSettings?: VideoBlackFailoverSettings;
}
export interface FailoverCondition {
    FailoverConditionSettings?: FailoverConditionSettings;
}
export type __listOfFailoverCondition = FailoverCondition[];
export type InputPreference = "EQUAL_INPUT_PREFERENCE" | "PRIMARY_INPUT_PREFERRED" | (string & {});
export interface AutomaticInputFailoverSettings {
    ErrorClearTimeMsec?: number;
    FailoverConditions?: FailoverCondition[];
    InputPreference?: InputPreference;
    SecondaryInputId?: string;
}
export interface AudioHlsRenditionSelection {
    GroupId?: string;
    Name?: string;
}
export type AudioLanguageSelectionPolicy = "LOOSE" | "STRICT" | (string & {});
export interface AudioLanguageSelection {
    LanguageCode?: string;
    LanguageSelectionPolicy?: AudioLanguageSelectionPolicy;
}
export type __integerMin0Max8191 = number;
export type DolbyEProgramSelection = "ALL_CHANNELS" | "PROGRAM_1" | "PROGRAM_2" | "PROGRAM_3" | "PROGRAM_4" | "PROGRAM_5" | "PROGRAM_6" | "PROGRAM_7" | "PROGRAM_8" | (string & {});
export interface AudioDolbyEDecode {
    ProgramSelection?: DolbyEProgramSelection;
}
export type __doubleMinNegative60Max60 = number;
export interface AudioPreMixerSettings {
    AudioNormalizationSettings?: AudioNormalizationSettings;
    Channels?: number;
    GainDb?: number;
    RemixSettings?: RemixSettings;
}
export interface AudioPid {
    DolbyEDecode?: AudioDolbyEDecode;
    Pid?: number;
    PremixSettings?: AudioPreMixerSettings;
}
export type __listOfAudioPid = AudioPid[];
export interface AudioPidSelection {
    Pid?: number;
    Pids?: AudioPid[];
}
export interface AudioTrack {
    Track?: number;
    PremixSettings?: AudioPreMixerSettings;
}
export type __listOfAudioTrack = AudioTrack[];
export interface AudioTrackSelection {
    Tracks?: AudioTrack[];
    DolbyEDecode?: AudioDolbyEDecode;
}
export interface AudioSelectorSettings {
    AudioHlsRenditionSelection?: AudioHlsRenditionSelection;
    AudioLanguageSelection?: AudioLanguageSelection;
    AudioPidSelection?: AudioPidSelection;
    AudioTrackSelection?: AudioTrackSelection;
}
export interface AudioSelector {
    Name?: string;
    SelectorSettings?: AudioSelectorSettings;
}
export type __listOfAudioSelector = AudioSelector[];
export interface AncillarySourceSettings {
    SourceAncillaryChannelNumber?: number;
}
export interface AribSourceSettings {
}
export type DvbSubOcrLanguage = "DEU" | "ENG" | "FRA" | "NLD" | "POR" | "SPA" | (string & {});
export interface DvbSubSourceSettings {
    OcrLanguage?: DvbSubOcrLanguage;
    Pid?: number;
}
export type EmbeddedConvert608To708 = "DISABLED" | "UPCONVERT" | (string & {});
export type EmbeddedScte20Detection = "AUTO" | "OFF" | (string & {});
export type __integerMin1Max5 = number;
export interface EmbeddedSourceSettings {
    Convert608To708?: EmbeddedConvert608To708;
    Scte20Detection?: EmbeddedScte20Detection;
    Source608ChannelNumber?: number;
    Source608TrackNumber?: number;
}
export type Scte20Convert608To708 = "DISABLED" | "UPCONVERT" | (string & {});
export interface Scte20SourceSettings {
    Convert608To708?: Scte20Convert608To708;
    Source608ChannelNumber?: number;
}
export type Scte27OcrLanguage = "DEU" | "ENG" | "FRA" | "NLD" | "POR" | "SPA" | (string & {});
export interface Scte27SourceSettings {
    OcrLanguage?: Scte27OcrLanguage;
    Pid?: number;
}
export type __doubleMin0Max100 = number;
export interface CaptionRectangle {
    Height?: number;
    LeftOffset?: number;
    TopOffset?: number;
    Width?: number;
}
export interface TeletextSourceSettings {
    OutputRectangle?: CaptionRectangle;
    PageNumber?: string;
}
export type CaptionSynchronizationMode = "NO_VIDEO_DELAY" | "VIDEO_ALIGNED_CAPTIONS" | (string & {});
export interface SmartSubtitleSourceSettings {
    CaptionSynchronizationMode?: CaptionSynchronizationMode;
    InferenceFeedOutput?: string;
}
export interface CaptionSelectorSettings {
    AncillarySourceSettings?: AncillarySourceSettings;
    AribSourceSettings?: AribSourceSettings;
    DvbSubSourceSettings?: DvbSubSourceSettings;
    EmbeddedSourceSettings?: EmbeddedSourceSettings;
    Scte20SourceSettings?: Scte20SourceSettings;
    Scte27SourceSettings?: Scte27SourceSettings;
    TeletextSourceSettings?: TeletextSourceSettings;
    SmartSubtitleSourceSettings?: SmartSubtitleSourceSettings;
}
export interface CaptionSelector {
    LanguageCode?: string;
    Name?: string;
    SelectorSettings?: CaptionSelectorSettings;
}
export type __listOfCaptionSelector = CaptionSelector[];
export type InputDeblockFilter = "DISABLED" | "ENABLED" | (string & {});
export type InputDenoiseFilter = "DISABLED" | "ENABLED" | (string & {});
export type InputFilter = "AUTO" | "DISABLED" | "FORCED" | (string & {});
export type HlsScte35SourceType = "MANIFEST" | "SEGMENTS" | (string & {});
export interface HlsInputSettings {
    Bandwidth?: number;
    BufferSegments?: number;
    Retries?: number;
    RetryInterval?: number;
    Scte35Source?: HlsScte35SourceType;
}
export type NetworkInputServerValidation = "CHECK_CRYPTOGRAPHY_AND_VALIDATE_NAME" | "CHECK_CRYPTOGRAPHY_ONLY" | (string & {});
export interface MulticastInputSettings {
    SourceIpAddress?: string;
}
export interface NetworkInputSettings {
    HlsInputSettings?: HlsInputSettings;
    ServerValidation?: NetworkInputServerValidation;
    MulticastInputSettings?: MulticastInputSettings;
}
export type __integerMin32Max8191 = number;
export type Smpte2038DataPreference = "IGNORE" | "PREFER" | (string & {});
export type InputSourceEndBehavior = "CONTINUE" | "LOOP" | (string & {});
export type VideoSelectorColorSpace = "FOLLOW" | "HDR10" | "HLG_2020" | "REC_601" | "REC_709" | (string & {});
export interface VideoSelectorColorSpaceSettings {
    Hdr10Settings?: Hdr10Settings;
}
export type VideoSelectorColorSpaceUsage = "FALLBACK" | "FORCE" | (string & {});
export interface VideoSelectorPid {
    Pid?: number;
}
export interface VideoSelectorProgramId {
    ProgramId?: number;
}
export interface VideoSelectorSettings {
    VideoSelectorPid?: VideoSelectorPid;
    VideoSelectorProgramId?: VideoSelectorProgramId;
}
export interface VideoSelector {
    ColorSpace?: VideoSelectorColorSpace;
    ColorSpaceSettings?: VideoSelectorColorSpaceSettings;
    ColorSpaceUsage?: VideoSelectorColorSpaceUsage;
    SelectorSettings?: VideoSelectorSettings;
}
export interface InputSettings {
    AudioSelectors?: AudioSelector[];
    CaptionSelectors?: CaptionSelector[];
    DeblockFilter?: InputDeblockFilter;
    DenoiseFilter?: InputDenoiseFilter;
    FilterStrength?: number;
    InputFilter?: InputFilter;
    NetworkInputSettings?: NetworkInputSettings;
    Scte35Pid?: number;
    Smpte2038DataPreference?: Smpte2038DataPreference;
    SourceEndBehavior?: InputSourceEndBehavior;
    VideoSelector?: VideoSelector;
}
export interface InputAttachment {
    AutomaticInputFailoverSettings?: AutomaticInputFailoverSettings;
    InputAttachmentName?: string;
    InputId?: string;
    InputSettings?: InputSettings;
    LogicalInterfaceNames?: string[];
}
export type __listOfInputAttachment = InputAttachment[];
export type InputCodec = "MPEG2" | "AVC" | "HEVC" | (string & {});
export type InputMaximumBitrate = "MAX_10_MBPS" | "MAX_20_MBPS" | "MAX_50_MBPS" | (string & {});
export type InputResolution = "SD" | "HD" | "UHD" | (string & {});
export interface InputSpecification {
    Codec?: InputCodec;
    MaximumBitrate?: InputMaximumBitrate;
    Resolution?: InputResolution;
}
export type LogLevel = "ERROR" | "WARNING" | "INFO" | "DEBUG" | "DISABLED" | (string & {});
export type MaintenanceDay = "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | "SUNDAY" | (string & {});
export type __stringPattern010920300 = string;
export interface MaintenanceCreateSettings {
    MaintenanceDay?: MaintenanceDay;
    MaintenanceStartTime?: string;
}
export type Tags = {
    [key: string]: string | undefined;
};
export interface VpcOutputSettings {
    PublicAddressAllocationIds?: string[];
    SecurityGroupIds?: string[];
    SubnetIds?: string[];
}
export interface AnywhereSettings {
    ChannelPlacementGroupId?: string;
    ClusterId?: string;
}
export interface ChannelEngineVersionRequest {
    Version?: string;
}
export type LinkedChannelType = "FOLLOWING_CHANNEL" | "PRIMARY_CHANNEL" | (string & {});
export interface FollowerChannelSettings {
    LinkedChannelType?: LinkedChannelType;
    PrimaryChannelArn?: string;
}
export interface PrimaryChannelSettings {
    LinkedChannelType?: LinkedChannelType;
}
export interface LinkedChannelSettings {
    FollowerChannelSettings?: FollowerChannelSettings;
    PrimaryChannelSettings?: PrimaryChannelSettings;
}
export interface AudioFeedInput {
    AudioSelectorName?: string;
    FeedInput?: string;
}
export type __listOfAudioFeedInput = AudioFeedInput[];
export type EnrichmentMethod = "SCTE35_ELEMENTAL_INFERENCE_QUERY_PARAMS" | (string & {});
export type __listOfEnrichmentMethod = EnrichmentMethod[];
export interface InferenceSettings {
    FeedArn?: string;
    AudioFeedInputs?: AudioFeedInput[];
    EnrichmentMethods?: EnrichmentMethod[];
}
export interface CreateChannelRequest {
    CdiInputSpecification?: CdiInputSpecification;
    ChannelClass?: ChannelClass;
    Destinations?: OutputDestination[];
    EncoderSettings?: EncoderSettings;
    InputAttachments?: InputAttachment[];
    InputSpecification?: InputSpecification;
    LogLevel?: LogLevel;
    Maintenance?: MaintenanceCreateSettings;
    Name?: string;
    RequestId?: string;
    Reserved?: string;
    RoleArn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Vpc?: VpcOutputSettings;
    AnywhereSettings?: AnywhereSettings;
    ChannelEngineVersion?: ChannelEngineVersionRequest;
    DryRun?: boolean;
    LinkedChannelSettings?: LinkedChannelSettings;
    ChannelSecurityGroups?: string[];
    InferenceSettings?: InferenceSettings;
}
export interface ChannelEgressEndpoint {
    SourceIp?: string;
}
export type __listOfChannelEgressEndpoint = ChannelEgressEndpoint[];
export interface MaintenanceStatus {
    MaintenanceDay?: MaintenanceDay;
    MaintenanceDeadline?: string;
    MaintenanceScheduledDate?: string;
    MaintenanceStartTime?: string;
}
export type __timestampIso8601 = Date;
export interface ChannelEngineVersionResponse {
    ExpirationDate?: Date;
    Version?: string;
}
export interface MediaConnectRouterOutputConnection {
    RouterInputArn?: string;
}
export type MediaConnectRouterOutputConnections = {
    [key: string]: MediaConnectRouterOutputConnection | undefined;
};
export interface PipelineDetail {
    ActiveInputAttachmentName?: string;
    ActiveInputSwitchActionName?: string;
    ActiveMotionGraphicsActionName?: string;
    ActiveMotionGraphicsUri?: string;
    PipelineId?: string;
    ChannelEngineVersion?: ChannelEngineVersionResponse;
    MediaConnectRouterOutputConnectionMap?: {
        [key: string]: MediaConnectRouterOutputConnection | undefined;
    };
}
export type __listOfPipelineDetail = PipelineDetail[];
export type ChannelState = "CREATING" | "CREATE_FAILED" | "IDLE" | "STARTING" | "RUNNING" | "RECOVERING" | "STOPPING" | "DELETING" | "DELETED" | "UPDATING" | "UPDATE_FAILED" | (string & {});
export interface VpcOutputSettingsDescription {
    AvailabilityZones?: string[];
    NetworkInterfaceIds?: string[];
    SecurityGroupIds?: string[];
    SubnetIds?: string[];
}
export interface DescribeAnywhereSettings {
    ChannelPlacementGroupId?: string;
    ClusterId?: string;
}
export interface DescribeFollowerChannelSettings {
    LinkedChannelType?: LinkedChannelType;
    PrimaryChannelArn?: string;
}
export interface DescribePrimaryChannelSettings {
    FollowingChannelArns?: string[];
    LinkedChannelType?: LinkedChannelType;
}
export interface DescribeLinkedChannelSettings {
    FollowerChannelSettings?: DescribeFollowerChannelSettings;
    PrimaryChannelSettings?: DescribePrimaryChannelSettings;
}
export interface DescribeInferenceSettings {
    FeedArn?: string;
    AudioFeedInputs?: AudioFeedInput[];
    EnrichmentMethods?: EnrichmentMethod[];
}
export interface Channel {
    Arn?: string;
    CdiInputSpecification?: CdiInputSpecification;
    ChannelClass?: ChannelClass;
    Destinations?: OutputDestination[];
    EgressEndpoints?: ChannelEgressEndpoint[];
    EncoderSettings?: EncoderSettings;
    Id?: string;
    InputAttachments?: InputAttachment[];
    InputSpecification?: InputSpecification;
    LogLevel?: LogLevel;
    Maintenance?: MaintenanceStatus;
    Name?: string;
    PipelineDetails?: PipelineDetail[];
    PipelinesRunningCount?: number;
    RoleArn?: string;
    State?: ChannelState;
    Tags?: {
        [key: string]: string | undefined;
    };
    Vpc?: VpcOutputSettingsDescription;
    AnywhereSettings?: DescribeAnywhereSettings;
    ChannelEngineVersion?: ChannelEngineVersionResponse;
    LinkedChannelSettings?: DescribeLinkedChannelSettings;
    ChannelSecurityGroups?: string[];
    InferenceSettings?: DescribeInferenceSettings;
}
export interface CreateChannelResponse {
    Channel?: Channel & {
        EncoderSettings: EncoderSettings & {
            AudioDescriptions: (AudioDescription & {
                AudioSelectorName: string;
                Name: __stringMax255;
                AudioWatermarkingSettings: AudioWatermarkSettings & {
                    NielsenWatermarksSettings: NielsenWatermarksSettings & {
                        NielsenCbetSettings: NielsenCBET & {
                            CbetCheckDigitString: __stringMin2Max2;
                            CbetStepaside: NielsenWatermarksCbetStepaside;
                            Csid: __stringMin1Max7;
                        };
                        NielsenNaesIiNwSettings: NielsenNaesIiNw & {
                            CheckDigitString: __stringMin2Max2;
                            Sid: __doubleMin1Max65535;
                        };
                        NielsenNwOnlySettings: NielsenNwOnly & {
                            CheckDigitString: __stringMin2Max2;
                            Sid: __doubleMin1Max65535;
                        };
                    };
                };
                RemixSettings: RemixSettings & {
                    ChannelMappings: (AudioChannelMapping & {
                        InputChannelLevels: (InputChannelLevel & {
                            Gain: __integerMinNegative60Max6;
                            InputChannel: __integerMin0Max15;
                        })[];
                        OutputChannel: __integerMin0Max7;
                    })[];
                };
            })[];
            OutputGroups: (OutputGroup & {
                OutputGroupSettings: OutputGroupSettings & {
                    ArchiveGroupSettings: ArchiveGroupSettings & {
                        Destination: OutputLocationRef;
                    };
                    FrameCaptureGroupSettings: FrameCaptureGroupSettings & {
                        Destination: OutputLocationRef;
                    };
                    HlsGroupSettings: HlsGroupSettings & {
                        Destination: OutputLocationRef;
                        CaptionLanguageMappings: (CaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                            LanguageDescription: __stringMin1;
                        })[];
                        KeyProviderSettings: KeyProviderSettings & {
                            StaticKeySettings: StaticKeySettings & {
                                StaticKeyValue: __stringMin32Max32;
                                KeyProviderServer: InputLocation & {
                                    Uri: __stringMax2048;
                                };
                            };
                        };
                    };
                    MediaPackageGroupSettings: MediaPackageGroupSettings & {
                        Destination: OutputLocationRef;
                        MediapackageV2GroupSettings: MediaPackageV2GroupSettings & {
                            CaptionLanguageMappings: (CaptionLanguageMapping & {
                                CaptionChannel: __integerMin1Max4;
                                LanguageCode: __stringMin3Max3;
                                LanguageDescription: __stringMin1;
                            })[];
                            AdditionalDestinations: (MediaPackageAdditionalDestinations & {
                                Destination: OutputLocationRef;
                            })[];
                            WatermarkingSettings: MediaPackageV2WatermarkingSettings & {
                                MediaPackageV2AbWatermarkerIrdetoSettings: MediaPackageV2AbWatermarkerIrdetoSettings & {
                                    AlternateDestination: OutputLocationRef;
                                    OperatorId: __integerMin1Max511;
                                    Profile: AbWatermarkingProfile;
                                    CustomProfile: AbWatermarkingCustomProfile & {
                                        EmbeddingFrequency: __doubleMin250Max5000;
                                        SceneCut: __doubleMinNegative1Max5;
                                        TargetPsnr: __doubleMin32Max46;
                                    };
                                };
                            };
                        };
                    };
                    MsSmoothGroupSettings: MsSmoothGroupSettings & {
                        Destination: OutputLocationRef;
                    };
                    CmafIngestGroupSettings: CmafIngestGroupSettings & {
                        Destination: OutputLocationRef;
                        CaptionLanguageMappings: (CmafIngestCaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                        })[];
                        AdditionalDestinations: (AdditionalDestinations & {
                            Destination: OutputLocationRef;
                        })[];
                        WatermarkingSettings: CmafIngestWatermarkingSettings & {
                            CmafIngestAbWatermarkerIrdetoSettings: CmafIngestAbWatermarkerIrdetoSettings & {
                                AlternateDestination: OutputLocationRef;
                                OperatorId: __integerMin1Max511;
                                Profile: AbWatermarkingProfile;
                                CustomProfile: AbWatermarkingCustomProfile & {
                                    EmbeddingFrequency: __doubleMin250Max5000;
                                    SceneCut: __doubleMinNegative1Max5;
                                    TargetPsnr: __doubleMin32Max46;
                                };
                            };
                        };
                    };
                };
                Outputs: (Output & {
                    OutputSettings: OutputSettings & {
                        ArchiveOutputSettings: ArchiveOutputSettings & {
                            ContainerSettings: ArchiveContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                        };
                        HlsOutputSettings: HlsOutputSettings & {
                            HlsSettings: HlsSettings & {
                                AudioOnlyHlsSettings: AudioOnlyHlsSettings & {
                                    AudioOnlyImage: InputLocation & {
                                        Uri: __stringMax2048;
                                    };
                                };
                                StandardHlsSettings: StandardHlsSettings & {
                                    M3u8Settings: M3u8Settings;
                                };
                            };
                        };
                        MultiplexOutputSettings: MultiplexOutputSettings & {
                            Destination: OutputLocationRef;
                        };
                        RtmpOutputSettings: RtmpOutputSettings & {
                            Destination: OutputLocationRef;
                        };
                        UdpOutputSettings: UdpOutputSettings & {
                            ContainerSettings: UdpContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                            Destination: OutputLocationRef;
                        };
                        SrtOutputSettings: SrtOutputSettings & {
                            ContainerSettings: UdpContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                            Destination: OutputLocationRef;
                        };
                        MediaConnectRouterOutputSettings: MediaConnectRouterOutputSettings & {
                            ContainerSettings: MediaConnectRouterContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                            Destination: OutputLocationRef;
                        };
                    };
                })[];
            })[];
            TimecodeConfig: TimecodeConfig & {
                Source: TimecodeConfigSource;
            };
            VideoDescriptions: (VideoDescription & {
                Name: string;
                CodecSettings: VideoCodecSettings & {
                    FrameCaptureSettings: FrameCaptureSettings & {
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    H264Settings: H264Settings & {
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    H265Settings: H265Settings & {
                        FramerateDenominator: __integerMin1Max3003;
                        FramerateNumerator: __integerMin1;
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    Mpeg2Settings: Mpeg2Settings & {
                        FramerateDenominator: __integerMin1;
                        FramerateNumerator: __integerMin1;
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    Av1Settings: Av1Settings & {
                        FramerateDenominator: __integerMin1Max3003;
                        FramerateNumerator: __integerMin1;
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                };
                CropRectangle: VideoPositionRectangle & {
                    Height: __integerMin2Max8192;
                    Width: __integerMin2Max8192;
                    X: __integerMin0Max8190;
                    Y: __integerMin0Max8190;
                };
                OutputPositionRectangle: VideoPositionRectangle & {
                    Height: __integerMin2Max8192;
                    Width: __integerMin2Max8192;
                    X: __integerMin0Max8190;
                    Y: __integerMin0Max8190;
                };
            })[];
            AvailBlanking: AvailBlanking & {
                AvailBlankingImage: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
            AvailConfiguration: AvailConfiguration & {
                AvailSettings: AvailSettings & {
                    Esam: Esam & {
                        AcquisitionPointId: __stringMax256;
                        PoisEndpoint: __stringMax2048;
                    };
                };
            };
            BlackoutSlate: BlackoutSlate & {
                BlackoutSlateImage: InputLocation & {
                    Uri: __stringMax2048;
                };
                NetworkEndBlackoutImage: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
            CaptionDescriptions: (CaptionDescription & {
                CaptionSelectorName: string;
                Name: string;
                DestinationSettings: CaptionDestinationSettings & {
                    BurnInDestinationSettings: BurnInDestinationSettings & {
                        Font: InputLocation & {
                            Uri: __stringMax2048;
                        };
                    };
                    DvbSubDestinationSettings: DvbSubDestinationSettings & {
                        Font: InputLocation & {
                            Uri: __stringMax2048;
                        };
                    };
                };
            })[];
            GlobalConfiguration: GlobalConfiguration & {
                InputLossBehavior: InputLossBehavior & {
                    InputLossImageSlate: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
            };
            MotionGraphicsConfiguration: MotionGraphicsConfiguration & {
                MotionGraphicsSettings: MotionGraphicsSettings;
            };
            ThumbnailConfiguration: ThumbnailConfiguration & {
                State: ThumbnailState;
            };
            ColorCorrectionSettings: ColorCorrectionSettings & {
                GlobalColorCorrections: (ColorCorrection & {
                    InputColorSpace: ColorSpace;
                    OutputColorSpace: ColorSpace;
                    Uri: string;
                })[];
            };
        };
        InputAttachments: (InputAttachment & {
            AutomaticInputFailoverSettings: AutomaticInputFailoverSettings & {
                SecondaryInputId: string;
                FailoverConditions: (FailoverCondition & {
                    FailoverConditionSettings: FailoverConditionSettings & {
                        AudioSilenceSettings: AudioSilenceFailoverSettings & {
                            AudioSelectorName: string;
                        };
                    };
                })[];
            };
            InputSettings: InputSettings & {
                AudioSelectors: (AudioSelector & {
                    Name: __stringMin1;
                    SelectorSettings: AudioSelectorSettings & {
                        AudioHlsRenditionSelection: AudioHlsRenditionSelection & {
                            GroupId: __stringMin1;
                            Name: __stringMin1;
                        };
                        AudioLanguageSelection: AudioLanguageSelection & {
                            LanguageCode: string;
                        };
                        AudioPidSelection: AudioPidSelection & {
                            Pid: __integerMin0Max8191;
                            Pids: (AudioPid & {
                                Pid: __integerMin0Max8191;
                                DolbyEDecode: AudioDolbyEDecode & {
                                    ProgramSelection: DolbyEProgramSelection;
                                };
                                PremixSettings: AudioPreMixerSettings & {
                                    RemixSettings: RemixSettings & {
                                        ChannelMappings: (AudioChannelMapping & {
                                            InputChannelLevels: (InputChannelLevel & {
                                                Gain: __integerMinNegative60Max6;
                                                InputChannel: __integerMin0Max15;
                                            })[];
                                            OutputChannel: __integerMin0Max7;
                                        })[];
                                    };
                                };
                            })[];
                        };
                        AudioTrackSelection: AudioTrackSelection & {
                            Tracks: (AudioTrack & {
                                Track: __integerMin1;
                                PremixSettings: AudioPreMixerSettings & {
                                    RemixSettings: RemixSettings & {
                                        ChannelMappings: (AudioChannelMapping & {
                                            InputChannelLevels: (InputChannelLevel & {
                                                Gain: __integerMinNegative60Max6;
                                                InputChannel: __integerMin0Max15;
                                            })[];
                                            OutputChannel: __integerMin0Max7;
                                        })[];
                                    };
                                };
                            })[];
                            DolbyEDecode: AudioDolbyEDecode & {
                                ProgramSelection: DolbyEProgramSelection;
                            };
                        };
                    };
                })[];
                CaptionSelectors: (CaptionSelector & {
                    Name: __stringMin1;
                    SelectorSettings: CaptionSelectorSettings & {
                        TeletextSourceSettings: TeletextSourceSettings & {
                            OutputRectangle: CaptionRectangle & {
                                Height: __doubleMin0Max100;
                                LeftOffset: __doubleMin0Max100;
                                TopOffset: __doubleMin0Max100;
                                Width: __doubleMin0Max100;
                            };
                        };
                    };
                })[];
            };
        })[];
    };
}
export interface CreateChannelPlacementGroupRequest {
    ClusterId: string;
    Name?: string;
    Nodes?: string[];
    RequestId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type ChannelPlacementGroupState = "UNASSIGNED" | "ASSIGNING" | "ASSIGNED" | "DELETING" | "DELETE_FAILED" | "DELETED" | "UNASSIGNING" | (string & {});
export interface CreateChannelPlacementGroupResponse {
    Arn?: string;
    Channels?: string[];
    ClusterId?: string;
    Id?: string;
    Name?: string;
    Nodes?: string[];
    State?: ChannelPlacementGroupState;
}
export type CloudWatchAlarmTemplateComparisonOperator = "GreaterThanOrEqualToThreshold" | "GreaterThanThreshold" | "LessThanThreshold" | "LessThanOrEqualToThreshold" | (string & {});
export type __stringMin0Max1024 = string;
export type __stringPatternS = string;
export type __stringMax64 = string;
export type __stringMin1Max255PatternS = string;
export type __integerMin10Max86400 = number;
export type CloudWatchAlarmTemplateStatistic = "SampleCount" | "Average" | "Sum" | "Minimum" | "Maximum" | (string & {});
export type TagMap = {
    [key: string]: string | undefined;
};
export type CloudWatchAlarmTemplateTargetResourceType = "CLOUDFRONT_DISTRIBUTION" | "MEDIALIVE_MULTIPLEX" | "MEDIALIVE_CHANNEL" | "MEDIALIVE_INPUT_DEVICE" | "MEDIAPACKAGE_CHANNEL" | "MEDIAPACKAGE_ORIGIN_ENDPOINT" | "MEDIACONNECT_FLOW" | "S3_BUCKET" | "MEDIATAILOR_PLAYBACK_CONFIGURATION" | (string & {});
export type CloudWatchAlarmTemplateTreatMissingData = "notBreaching" | "breaching" | "ignore" | "missing" | (string & {});
export type __stringMin1Max256PatternS = string;
export interface CreateCloudWatchAlarmTemplateRequest {
    ComparisonOperator?: CloudWatchAlarmTemplateComparisonOperator;
    DatapointsToAlarm?: number;
    Description?: string;
    EvaluationPeriods?: number;
    GroupIdentifier?: string;
    MetricName?: string;
    Name?: string;
    Period?: number;
    Statistic?: CloudWatchAlarmTemplateStatistic;
    Tags?: {
        [key: string]: string | undefined;
    };
    TargetResourceType?: CloudWatchAlarmTemplateTargetResourceType;
    Threshold?: number;
    TreatMissingData?: CloudWatchAlarmTemplateTreatMissingData;
    RequestId?: string;
}
export type __stringPatternArnMedialiveCloudwatchAlarmTemplate = string;
export type __stringMin7Max11PatternAws097 = string;
export interface CreateCloudWatchAlarmTemplateResponse {
    Arn?: string;
    ComparisonOperator?: CloudWatchAlarmTemplateComparisonOperator;
    CreatedAt?: Date;
    DatapointsToAlarm?: number;
    Description?: string;
    EvaluationPeriods?: number;
    GroupId?: string;
    Id?: string;
    MetricName?: string;
    ModifiedAt?: Date;
    Name?: string;
    Period?: number;
    Statistic?: CloudWatchAlarmTemplateStatistic;
    Tags?: {
        [key: string]: string | undefined;
    };
    TargetResourceType?: CloudWatchAlarmTemplateTargetResourceType;
    Threshold?: number;
    TreatMissingData?: CloudWatchAlarmTemplateTreatMissingData;
}
export interface CreateCloudWatchAlarmTemplateGroupRequest {
    Description?: string;
    Name?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    RequestId?: string;
}
export type __stringPatternArnMedialiveCloudwatchAlarmTemplateGroup = string;
export interface CreateCloudWatchAlarmTemplateGroupResponse {
    Arn?: string;
    CreatedAt?: Date;
    Description?: string;
    Id?: string;
    ModifiedAt?: Date;
    Name?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type ClusterType = "ON_PREMISES" | (string & {});
export interface InterfaceMappingCreateRequest {
    LogicalInterfaceName?: string;
    NetworkId?: string;
}
export type __listOfInterfaceMappingCreateRequest = InterfaceMappingCreateRequest[];
export interface ClusterNetworkSettingsCreateRequest {
    DefaultRoute?: string;
    InterfaceMappings?: InterfaceMappingCreateRequest[];
}
export interface CreateClusterRequest {
    ClusterType?: ClusterType;
    InstanceRoleArn?: string;
    Name?: string;
    NetworkSettings?: ClusterNetworkSettingsCreateRequest;
    RequestId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface InterfaceMapping {
    LogicalInterfaceName?: string;
    NetworkId?: string;
}
export type __listOfInterfaceMapping = InterfaceMapping[];
export interface ClusterNetworkSettings {
    DefaultRoute?: string;
    InterfaceMappings?: InterfaceMapping[];
}
export type ClusterState = "CREATING" | "CREATE_FAILED" | "ACTIVE" | "DELETING" | "DELETE_FAILED" | "DELETED" | (string & {});
export interface CreateClusterResponse {
    Arn?: string;
    ChannelIds?: string[];
    ClusterType?: ClusterType;
    Id?: string;
    InstanceRoleArn?: string;
    Name?: string;
    NetworkSettings?: ClusterNetworkSettings;
    State?: ClusterState;
}
export type __stringMin1Max2048PatternArn = string;
export interface EventBridgeRuleTemplateTarget {
    Arn?: string;
}
export type __listOfEventBridgeRuleTemplateTarget = EventBridgeRuleTemplateTarget[];
export type EventBridgeRuleTemplateEventType = "MEDIALIVE_MULTIPLEX_ALERT" | "MEDIALIVE_MULTIPLEX_STATE_CHANGE" | "MEDIALIVE_CHANNEL_ALERT" | "MEDIALIVE_CHANNEL_INPUT_CHANGE" | "MEDIALIVE_CHANNEL_STATE_CHANGE" | "MEDIAPACKAGE_INPUT_NOTIFICATION" | "MEDIAPACKAGE_KEY_PROVIDER_NOTIFICATION" | "MEDIAPACKAGE_HARVEST_JOB_NOTIFICATION" | "SIGNAL_MAP_ACTIVE_ALARM" | "MEDIACONNECT_ALERT" | "MEDIACONNECT_SOURCE_HEALTH" | "MEDIACONNECT_OUTPUT_HEALTH" | "MEDIACONNECT_FLOW_STATUS_CHANGE" | (string & {});
export interface CreateEventBridgeRuleTemplateRequest {
    Description?: string;
    EventTargets?: EventBridgeRuleTemplateTarget[];
    EventType?: EventBridgeRuleTemplateEventType;
    GroupIdentifier?: string;
    Name?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    RequestId?: string;
}
export type __stringPatternArnMedialiveEventbridgeRuleTemplate = string;
export interface CreateEventBridgeRuleTemplateResponse {
    Arn?: string;
    CreatedAt?: Date;
    Description?: string;
    EventTargets?: (EventBridgeRuleTemplateTarget & {
        Arn: __stringMin1Max2048PatternArn;
    })[];
    EventType?: EventBridgeRuleTemplateEventType;
    GroupId?: string;
    Id?: string;
    ModifiedAt?: Date;
    Name?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateEventBridgeRuleTemplateGroupRequest {
    Description?: string;
    Name?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    RequestId?: string;
}
export type __stringPatternArnMedialiveEventbridgeRuleTemplateGroup = string;
export interface CreateEventBridgeRuleTemplateGroupResponse {
    Arn?: string;
    CreatedAt?: Date;
    Description?: string;
    Id?: string;
    ModifiedAt?: Date;
    Name?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface InputRequestDestinationRoute {
    Cidr?: string;
    Gateway?: string;
}
export type __listOfInputRequestDestinationRoute = InputRequestDestinationRoute[];
export interface InputDestinationRequest {
    StreamName?: string;
    Network?: string;
    NetworkRoutes?: InputRequestDestinationRoute[];
    StaticIpAddress?: string;
}
export type __listOfInputDestinationRequest = InputDestinationRequest[];
export interface InputDeviceSettings {
    Id?: string;
}
export type __listOfInputDeviceSettings = InputDeviceSettings[];
export interface MediaConnectFlowRequest {
    FlowArn?: string;
}
export type __listOfMediaConnectFlowRequest = MediaConnectFlowRequest[];
export interface InputSourceRequest {
    PasswordParam?: string;
    Url?: string;
    Username?: string;
}
export type __listOfInputSourceRequest = InputSourceRequest[];
export type InputType = "UDP_PUSH" | "RTP_PUSH" | "RTMP_PUSH" | "RTMP_PULL" | "URL_PULL" | "MP4_FILE" | "MEDIACONNECT" | "INPUT_DEVICE" | "AWS_CDI" | "TS_FILE" | "SRT_CALLER" | "MULTICAST" | "SMPTE_2110_RECEIVER_GROUP" | "SDI" | "MEDIACONNECT_ROUTER" | "SRT_LISTENER" | (string & {});
export interface InputVpcRequest {
    SecurityGroupIds?: string[];
    SubnetIds?: string[];
}
export type Algorithm = "AES128" | "AES192" | "AES256" | (string & {});
export interface SrtCallerDecryptionRequest {
    Algorithm?: Algorithm;
    PassphraseSecretArn?: string;
}
export interface SrtCallerSourceRequest {
    Decryption?: SrtCallerDecryptionRequest;
    MinimumLatency?: number;
    SrtListenerAddress?: string;
    SrtListenerPort?: string;
    StreamId?: string;
}
export type __listOfSrtCallerSourceRequest = SrtCallerSourceRequest[];
export interface SrtListenerDecryptionRequest {
    Algorithm?: Algorithm;
    PassphraseSecretArn?: string;
}
export interface SrtListenerSettingsRequest {
    Decryption?: SrtListenerDecryptionRequest;
    MinimumLatency?: number;
    StreamId?: string;
}
export interface SrtSettingsRequest {
    SrtCallerSources?: SrtCallerSourceRequest[];
    SrtListenerSettings?: SrtListenerSettingsRequest;
}
export type InputNetworkLocation = "AWS" | "ON_PREMISES" | (string & {});
export interface MulticastSourceCreateRequest {
    SourceIp?: string;
    Url?: string;
}
export type __listOfMulticastSourceCreateRequest = MulticastSourceCreateRequest[];
export interface MulticastSettingsCreateRequest {
    Sources?: MulticastSourceCreateRequest[];
}
export interface InputSdpLocation {
    MediaIndex?: number;
    SdpUrl?: string;
}
export type __listOfInputSdpLocation = InputSdpLocation[];
export interface Smpte2110ReceiverGroupSdpSettings {
    AncillarySdps?: InputSdpLocation[];
    AudioSdps?: InputSdpLocation[];
    VideoSdp?: InputSdpLocation;
}
export interface Smpte2110ReceiverGroup {
    SdpSettings?: Smpte2110ReceiverGroupSdpSettings;
}
export type __listOfSmpte2110ReceiverGroup = Smpte2110ReceiverGroup[];
export interface Smpte2110ReceiverGroupSettings {
    Smpte2110ReceiverGroups?: Smpte2110ReceiverGroup[];
}
export type InputSdiSources = string[];
export interface RouterDestinationSettings {
    AvailabilityZoneName?: string;
}
export type __listOfRouterDestinationSettings = RouterDestinationSettings[];
export type RouterEncryptionType = "AUTOMATIC" | "SECRETS_MANAGER" | (string & {});
export interface RouterSettings {
    Destinations?: RouterDestinationSettings[];
    EncryptionType?: RouterEncryptionType;
    SecretArn?: string;
}
export interface CreateInputRequest {
    Destinations?: InputDestinationRequest[];
    InputDevices?: InputDeviceSettings[];
    InputSecurityGroups?: string[];
    MediaConnectFlows?: MediaConnectFlowRequest[];
    Name?: string;
    RequestId?: string;
    RoleArn?: string;
    Sources?: InputSourceRequest[];
    Tags?: {
        [key: string]: string | undefined;
    };
    Type?: InputType;
    Vpc?: InputVpcRequest;
    SrtSettings?: SrtSettingsRequest;
    InputNetworkLocation?: InputNetworkLocation;
    MulticastSettings?: MulticastSettingsCreateRequest;
    Smpte2110ReceiverGroupSettings?: Smpte2110ReceiverGroupSettings;
    SdiSources?: string[];
    RouterSettings?: RouterSettings;
}
export interface InputDestinationVpc {
    AvailabilityZone?: string;
    NetworkInterfaceId?: string;
}
export interface InputDestinationRoute {
    Cidr?: string;
    Gateway?: string;
}
export type __listOfInputDestinationRoute = InputDestinationRoute[];
export interface InputDestination {
    Ip?: string;
    Port?: string;
    Url?: string;
    Vpc?: InputDestinationVpc;
    Network?: string;
    NetworkRoutes?: InputDestinationRoute[];
}
export type __listOfInputDestination = InputDestination[];
export type InputClass = "STANDARD" | "SINGLE_PIPELINE" | (string & {});
export type InputSourceType = "STATIC" | "DYNAMIC" | (string & {});
export interface MediaConnectFlow {
    FlowArn?: string;
}
export type __listOfMediaConnectFlow = MediaConnectFlow[];
export interface InputSource {
    PasswordParam?: string;
    Url?: string;
    Username?: string;
}
export type __listOfInputSource = InputSource[];
export type InputState = "CREATING" | "DETACHED" | "ATTACHED" | "DELETING" | "DELETED" | (string & {});
export interface SrtCallerDecryption {
    Algorithm?: Algorithm;
    PassphraseSecretArn?: string;
}
export interface SrtCallerSource {
    Decryption?: SrtCallerDecryption;
    MinimumLatency?: number;
    SrtListenerAddress?: string;
    SrtListenerPort?: string;
    StreamId?: string;
}
export type __listOfSrtCallerSource = SrtCallerSource[];
export interface SrtListenerDecryption {
    Algorithm?: Algorithm;
    PassphraseSecretArn?: string;
}
export interface SrtListenerSettings {
    Decryption?: SrtListenerDecryption;
    MinimumLatency?: number;
    StreamId?: string;
}
export interface SrtSettings {
    SrtCallerSources?: SrtCallerSource[];
    SrtListenerSettings?: SrtListenerSettings;
}
export interface MulticastSource {
    SourceIp?: string;
    Url?: string;
}
export type __listOfMulticastSource = MulticastSource[];
export interface MulticastSettings {
    Sources?: MulticastSource[];
}
export interface RouterDestination {
    AvailabilityZoneName?: string;
    RouterOutputArn?: string;
}
export type __listOfRouterDestination = RouterDestination[];
export interface RouterInputSettings {
    Destinations?: RouterDestination[];
    EncryptionType?: RouterEncryptionType;
    SecretArn?: string;
}
export interface Input {
    Arn?: string;
    AttachedChannels?: string[];
    Destinations?: InputDestination[];
    Id?: string;
    InputClass?: InputClass;
    InputDevices?: InputDeviceSettings[];
    InputPartnerIds?: string[];
    InputSourceType?: InputSourceType;
    MediaConnectFlows?: MediaConnectFlow[];
    Name?: string;
    RoleArn?: string;
    SecurityGroups?: string[];
    Sources?: InputSource[];
    State?: InputState;
    Tags?: {
        [key: string]: string | undefined;
    };
    Type?: InputType;
    SrtSettings?: SrtSettings;
    InputNetworkLocation?: InputNetworkLocation;
    MulticastSettings?: MulticastSettings;
    Smpte2110ReceiverGroupSettings?: Smpte2110ReceiverGroupSettings;
    SdiSources?: string[];
    RouterSettings?: RouterInputSettings;
}
export interface CreateInputResponse {
    Input?: Input & {
        SrtSettings: SrtSettings & {
            SrtListenerSettings: SrtListenerSettings & {
                Decryption: SrtListenerDecryption & {
                    Algorithm: Algorithm;
                    PassphraseSecretArn: string;
                };
            };
        };
        MulticastSettings: MulticastSettings & {
            Sources: (MulticastSource & {
                Url: string;
            })[];
        };
    };
}
export interface InputWhitelistRuleCidr {
    Cidr?: string;
}
export type __listOfInputWhitelistRuleCidr = InputWhitelistRuleCidr[];
export interface CreateInputSecurityGroupRequest {
    Tags?: {
        [key: string]: string | undefined;
    };
    WhitelistRules?: InputWhitelistRuleCidr[];
}
export type InputSecurityGroupState = "IDLE" | "IN_USE" | "UPDATING" | "DELETED" | (string & {});
export interface InputWhitelistRule {
    Cidr?: string;
}
export type __listOfInputWhitelistRule = InputWhitelistRule[];
export interface InputSecurityGroup {
    Arn?: string;
    Id?: string;
    Inputs?: string[];
    State?: InputSecurityGroupState;
    Tags?: {
        [key: string]: string | undefined;
    };
    WhitelistRules?: InputWhitelistRule[];
    Channels?: string[];
}
export interface CreateInputSecurityGroupResponse {
    SecurityGroup?: InputSecurityGroup;
}
export type __integerMin800Max3000 = number;
export type __integerMin1000000Max100000000 = number;
export type __integerMin0Max100000000 = number;
export interface MultiplexSettings {
    MaximumVideoBufferDelayMilliseconds?: number;
    TransportStreamBitrate?: number;
    TransportStreamId?: number;
    TransportStreamReservedBitrate?: number;
}
export interface CreateMultiplexRequest {
    AvailabilityZones?: string[];
    MultiplexSettings?: MultiplexSettings;
    Name?: string;
    RequestId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface MultiplexMediaConnectOutputDestinationSettings {
    EntitlementArn?: string;
}
export interface MultiplexOutputDestination {
    MediaConnectSettings?: MultiplexMediaConnectOutputDestinationSettings;
}
export type __listOfMultiplexOutputDestination = MultiplexOutputDestination[];
export type MultiplexState = "CREATING" | "CREATE_FAILED" | "IDLE" | "STARTING" | "RUNNING" | "RECOVERING" | "STOPPING" | "DELETING" | "DELETED" | (string & {});
export interface Multiplex {
    Arn?: string;
    AvailabilityZones?: string[];
    Destinations?: MultiplexOutputDestination[];
    Id?: string;
    MultiplexSettings?: MultiplexSettings;
    Name?: string;
    PipelinesRunningCount?: number;
    ProgramCount?: number;
    State?: MultiplexState;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateMultiplexResponse {
    Multiplex?: Multiplex & {
        MultiplexSettings: MultiplexSettings & {
            TransportStreamBitrate: __integerMin1000000Max100000000;
            TransportStreamId: __integerMin0Max65535;
        };
    };
}
export type PreferredChannelPipeline = "CURRENTLY_ACTIVE" | "PIPELINE_0" | "PIPELINE_1" | (string & {});
export interface MultiplexProgramServiceDescriptor {
    ProviderName?: string;
    ServiceName?: string;
}
export type __integerMin100000Max100000000 = number;
export type __integerMinNegative5Max5 = number;
export interface MultiplexStatmuxVideoSettings {
    MaximumBitrate?: number;
    MinimumBitrate?: number;
    Priority?: number;
}
export interface MultiplexVideoSettings {
    ConstantBitrate?: number;
    StatmuxSettings?: MultiplexStatmuxVideoSettings;
}
export interface MultiplexProgramSettings {
    PreferredChannelPipeline?: PreferredChannelPipeline;
    ProgramNumber?: number;
    ServiceDescriptor?: MultiplexProgramServiceDescriptor;
    VideoSettings?: MultiplexVideoSettings;
}
export interface CreateMultiplexProgramRequest {
    MultiplexId: string;
    MultiplexProgramSettings?: MultiplexProgramSettings;
    ProgramName?: string;
    RequestId?: string;
}
export type __listOf__integer = number[];
export interface MultiplexProgramPacketIdentifiersMap {
    AudioPids?: number[];
    DvbSubPids?: number[];
    DvbTeletextPid?: number;
    EtvPlatformPid?: number;
    EtvSignalPid?: number;
    KlvDataPids?: number[];
    PcrPid?: number;
    PmtPid?: number;
    PrivateMetadataPid?: number;
    Scte27Pids?: number[];
    Scte35Pid?: number;
    TimedMetadataPid?: number;
    VideoPid?: number;
    AribCaptionsPid?: number;
    DvbTeletextPids?: number[];
    EcmPid?: number;
    Smpte2038Pid?: number;
}
export interface MultiplexProgramPipelineDetail {
    ActiveChannelPipeline?: string;
    PipelineId?: string;
}
export type __listOfMultiplexProgramPipelineDetail = MultiplexProgramPipelineDetail[];
export interface MultiplexProgram {
    ChannelId?: string;
    MultiplexProgramSettings?: MultiplexProgramSettings;
    PacketIdentifiersMap?: MultiplexProgramPacketIdentifiersMap;
    PipelineDetails?: MultiplexProgramPipelineDetail[];
    ProgramName?: string;
}
export interface CreateMultiplexProgramResponse {
    MultiplexProgram?: MultiplexProgram & {
        MultiplexProgramSettings: MultiplexProgramSettings & {
            ProgramNumber: __integerMin0Max65535;
            ServiceDescriptor: MultiplexProgramServiceDescriptor & {
                ProviderName: __stringMax256;
                ServiceName: __stringMax256;
            };
        };
    };
}
export interface IpPoolCreateRequest {
    Cidr?: string;
}
export type __listOfIpPoolCreateRequest = IpPoolCreateRequest[];
export interface RouteCreateRequest {
    Cidr?: string;
    Gateway?: string;
}
export type __listOfRouteCreateRequest = RouteCreateRequest[];
export interface CreateNetworkRequest {
    IpPools?: IpPoolCreateRequest[];
    Name?: string;
    RequestId?: string;
    Routes?: RouteCreateRequest[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface IpPool {
    Cidr?: string;
}
export type __listOfIpPool = IpPool[];
export interface Route {
    Cidr?: string;
    Gateway?: string;
}
export type __listOfRoute = Route[];
export type NetworkState = "CREATING" | "CREATE_FAILED" | "ACTIVE" | "DELETING" | "IDLE" | "IN_USE" | "UPDATING" | "DELETE_FAILED" | "DELETED" | (string & {});
export interface CreateNetworkResponse {
    Arn?: string;
    AssociatedClusterIds?: string[];
    Id?: string;
    IpPools?: IpPool[];
    Name?: string;
    Routes?: Route[];
    State?: NetworkState;
}
export type NetworkInterfaceMode = "NAT" | "BRIDGE" | (string & {});
export interface NodeInterfaceMappingCreateRequest {
    LogicalInterfaceName?: string;
    NetworkInterfaceMode?: NetworkInterfaceMode;
    PhysicalInterfaceName?: string;
}
export type __listOfNodeInterfaceMappingCreateRequest = NodeInterfaceMappingCreateRequest[];
export type NodeRole = "BACKUP" | "ACTIVE" | (string & {});
export interface CreateNodeRequest {
    ClusterId: string;
    Name?: string;
    NodeInterfaceMappings?: NodeInterfaceMappingCreateRequest[];
    RequestId?: string;
    Role?: NodeRole;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type NodeConnectionState = "CONNECTED" | "DISCONNECTED" | (string & {});
export interface NodeInterfaceMapping {
    LogicalInterfaceName?: string;
    NetworkInterfaceMode?: NetworkInterfaceMode;
    PhysicalInterfaceName?: string;
    PhysicalInterfaceIpAddresses?: string[];
}
export type __listOfNodeInterfaceMapping = NodeInterfaceMapping[];
export type NodeState = "CREATED" | "REGISTERING" | "READY_TO_ACTIVATE" | "REGISTRATION_FAILED" | "ACTIVATION_FAILED" | "ACTIVE" | "READY" | "IN_USE" | "DEREGISTERING" | "DRAINING" | "DEREGISTRATION_FAILED" | "DEREGISTERED" | (string & {});
export interface SdiSourceMapping {
    CardNumber?: number;
    ChannelNumber?: number;
    SdiSource?: string;
}
export type SdiSourceMappings = SdiSourceMapping[];
export interface CreateNodeResponse {
    Arn?: string;
    ChannelPlacementGroups?: string[];
    ClusterId?: string;
    ConnectionState?: NodeConnectionState;
    Id?: string;
    InstanceArn?: string;
    Name?: string;
    NodeInterfaceMappings?: NodeInterfaceMapping[];
    Role?: NodeRole;
    State?: NodeState;
    SdiSourceMappings?: SdiSourceMapping[];
}
export interface CreateNodeRegistrationScriptRequest {
    ClusterId: string;
    Id?: string;
    Name?: string;
    NodeInterfaceMappings?: NodeInterfaceMapping[];
    RequestId?: string;
    Role?: NodeRole;
}
export interface CreateNodeRegistrationScriptResponse {
    NodeRegistrationScript?: string;
}
export interface CreatePartnerInputRequest {
    InputId: string;
    RequestId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreatePartnerInputResponse {
    Input?: Input & {
        SrtSettings: SrtSettings & {
            SrtListenerSettings: SrtListenerSettings & {
                Decryption: SrtListenerDecryption & {
                    Algorithm: Algorithm;
                    PassphraseSecretArn: string;
                };
            };
        };
        MulticastSettings: MulticastSettings & {
            Sources: (MulticastSource & {
                Url: string;
            })[];
        };
    };
}
export type SdiSourceMode = "QUADRANT" | "INTERLEAVE" | (string & {});
export type SdiSourceType = "SINGLE" | "QUAD" | (string & {});
export interface CreateSdiSourceRequest {
    Mode?: SdiSourceMode;
    Name?: string;
    RequestId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Type?: SdiSourceType;
}
export type SdiSourceState = "IDLE" | "IN_USE" | "DELETED" | (string & {});
export interface SdiSource {
    Arn?: string;
    Id?: string;
    Inputs?: string[];
    Mode?: SdiSourceMode;
    Name?: string;
    State?: SdiSourceState;
    Type?: SdiSourceType;
}
export interface CreateSdiSourceResponse {
    SdiSource?: SdiSource;
}
export type __listOf__stringPatternS = string[];
export type __stringMin1Max2048 = string;
export interface CreateSignalMapRequest {
    CloudWatchAlarmTemplateGroupIdentifiers?: string[];
    Description?: string;
    DiscoveryEntryPointArn?: string;
    EventBridgeRuleTemplateGroupIdentifiers?: string[];
    Name?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    RequestId?: string;
}
export type __stringPatternArnMedialiveSignalMap = string;
export type __listOf__stringMin7Max11PatternAws097 = string[];
export interface MediaResourceNeighbor {
    Arn?: string;
    Name?: string;
}
export type __listOfMediaResourceNeighbor = MediaResourceNeighbor[];
export interface MediaResource {
    Destinations?: MediaResourceNeighbor[];
    Name?: string;
    Sources?: MediaResourceNeighbor[];
}
export type FailedMediaResourceMap = {
    [key: string]: MediaResource | undefined;
};
export type SignalMapMonitorDeploymentStatus = "NOT_DEPLOYED" | "DRY_RUN_DEPLOYMENT_COMPLETE" | "DRY_RUN_DEPLOYMENT_FAILED" | "DRY_RUN_DEPLOYMENT_IN_PROGRESS" | "DEPLOYMENT_COMPLETE" | "DEPLOYMENT_FAILED" | "DEPLOYMENT_IN_PROGRESS" | "DELETE_COMPLETE" | "DELETE_FAILED" | "DELETE_IN_PROGRESS" | (string & {});
export interface SuccessfulMonitorDeployment {
    DetailsUri?: string;
    Status?: SignalMapMonitorDeploymentStatus;
}
export type MediaResourceMap = {
    [key: string]: MediaResource | undefined;
};
export interface MonitorDeployment {
    DetailsUri?: string;
    ErrorMessage?: string;
    Status?: SignalMapMonitorDeploymentStatus;
}
export type SignalMapStatus = "CREATE_IN_PROGRESS" | "CREATE_COMPLETE" | "CREATE_FAILED" | "UPDATE_IN_PROGRESS" | "UPDATE_COMPLETE" | "UPDATE_REVERTED" | "UPDATE_FAILED" | "READY" | "NOT_READY" | (string & {});
export interface CreateSignalMapResponse {
    Arn?: string;
    CloudWatchAlarmTemplateGroupIds?: string[];
    CreatedAt?: Date;
    Description?: string;
    DiscoveryEntryPointArn?: string;
    ErrorMessage?: string;
    EventBridgeRuleTemplateGroupIds?: string[];
    FailedMediaResourceMap?: {
        [key: string]: (MediaResource & {
            Destinations: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
            Sources: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
        }) | undefined;
    };
    Id?: string;
    LastDiscoveredAt?: Date;
    LastSuccessfulMonitorDeployment?: SuccessfulMonitorDeployment & {
        DetailsUri: __stringMin1Max2048;
        Status: SignalMapMonitorDeploymentStatus;
    };
    MediaResourceMap?: {
        [key: string]: (MediaResource & {
            Destinations: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
            Sources: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
        }) | undefined;
    };
    ModifiedAt?: Date;
    MonitorChangesPendingDeployment?: boolean;
    MonitorDeployment?: MonitorDeployment & {
        Status: SignalMapMonitorDeploymentStatus;
    };
    Name?: string;
    Status?: SignalMapStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateTagsRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateTagsResponse {
}
export interface DeleteChannelRequest {
    ChannelId: string;
}
export interface DeleteChannelResponse {
    Arn?: string;
    CdiInputSpecification?: CdiInputSpecification;
    ChannelClass?: ChannelClass;
    Destinations?: OutputDestination[];
    EgressEndpoints?: ChannelEgressEndpoint[];
    EncoderSettings?: EncoderSettings & {
        AudioDescriptions: (AudioDescription & {
            AudioSelectorName: string;
            Name: __stringMax255;
            AudioWatermarkingSettings: AudioWatermarkSettings & {
                NielsenWatermarksSettings: NielsenWatermarksSettings & {
                    NielsenCbetSettings: NielsenCBET & {
                        CbetCheckDigitString: __stringMin2Max2;
                        CbetStepaside: NielsenWatermarksCbetStepaside;
                        Csid: __stringMin1Max7;
                    };
                    NielsenNaesIiNwSettings: NielsenNaesIiNw & {
                        CheckDigitString: __stringMin2Max2;
                        Sid: __doubleMin1Max65535;
                    };
                    NielsenNwOnlySettings: NielsenNwOnly & {
                        CheckDigitString: __stringMin2Max2;
                        Sid: __doubleMin1Max65535;
                    };
                };
            };
            RemixSettings: RemixSettings & {
                ChannelMappings: (AudioChannelMapping & {
                    InputChannelLevels: (InputChannelLevel & {
                        Gain: __integerMinNegative60Max6;
                        InputChannel: __integerMin0Max15;
                    })[];
                    OutputChannel: __integerMin0Max7;
                })[];
            };
        })[];
        OutputGroups: (OutputGroup & {
            OutputGroupSettings: OutputGroupSettings & {
                ArchiveGroupSettings: ArchiveGroupSettings & {
                    Destination: OutputLocationRef;
                };
                FrameCaptureGroupSettings: FrameCaptureGroupSettings & {
                    Destination: OutputLocationRef;
                };
                HlsGroupSettings: HlsGroupSettings & {
                    Destination: OutputLocationRef;
                    CaptionLanguageMappings: (CaptionLanguageMapping & {
                        CaptionChannel: __integerMin1Max4;
                        LanguageCode: __stringMin3Max3;
                        LanguageDescription: __stringMin1;
                    })[];
                    KeyProviderSettings: KeyProviderSettings & {
                        StaticKeySettings: StaticKeySettings & {
                            StaticKeyValue: __stringMin32Max32;
                            KeyProviderServer: InputLocation & {
                                Uri: __stringMax2048;
                            };
                        };
                    };
                };
                MediaPackageGroupSettings: MediaPackageGroupSettings & {
                    Destination: OutputLocationRef;
                    MediapackageV2GroupSettings: MediaPackageV2GroupSettings & {
                        CaptionLanguageMappings: (CaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                            LanguageDescription: __stringMin1;
                        })[];
                        AdditionalDestinations: (MediaPackageAdditionalDestinations & {
                            Destination: OutputLocationRef;
                        })[];
                        WatermarkingSettings: MediaPackageV2WatermarkingSettings & {
                            MediaPackageV2AbWatermarkerIrdetoSettings: MediaPackageV2AbWatermarkerIrdetoSettings & {
                                AlternateDestination: OutputLocationRef;
                                OperatorId: __integerMin1Max511;
                                Profile: AbWatermarkingProfile;
                                CustomProfile: AbWatermarkingCustomProfile & {
                                    EmbeddingFrequency: __doubleMin250Max5000;
                                    SceneCut: __doubleMinNegative1Max5;
                                    TargetPsnr: __doubleMin32Max46;
                                };
                            };
                        };
                    };
                };
                MsSmoothGroupSettings: MsSmoothGroupSettings & {
                    Destination: OutputLocationRef;
                };
                CmafIngestGroupSettings: CmafIngestGroupSettings & {
                    Destination: OutputLocationRef;
                    CaptionLanguageMappings: (CmafIngestCaptionLanguageMapping & {
                        CaptionChannel: __integerMin1Max4;
                        LanguageCode: __stringMin3Max3;
                    })[];
                    AdditionalDestinations: (AdditionalDestinations & {
                        Destination: OutputLocationRef;
                    })[];
                    WatermarkingSettings: CmafIngestWatermarkingSettings & {
                        CmafIngestAbWatermarkerIrdetoSettings: CmafIngestAbWatermarkerIrdetoSettings & {
                            AlternateDestination: OutputLocationRef;
                            OperatorId: __integerMin1Max511;
                            Profile: AbWatermarkingProfile;
                            CustomProfile: AbWatermarkingCustomProfile & {
                                EmbeddingFrequency: __doubleMin250Max5000;
                                SceneCut: __doubleMinNegative1Max5;
                                TargetPsnr: __doubleMin32Max46;
                            };
                        };
                    };
                };
            };
            Outputs: (Output & {
                OutputSettings: OutputSettings & {
                    ArchiveOutputSettings: ArchiveOutputSettings & {
                        ContainerSettings: ArchiveContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                    };
                    HlsOutputSettings: HlsOutputSettings & {
                        HlsSettings: HlsSettings & {
                            AudioOnlyHlsSettings: AudioOnlyHlsSettings & {
                                AudioOnlyImage: InputLocation & {
                                    Uri: __stringMax2048;
                                };
                            };
                            StandardHlsSettings: StandardHlsSettings & {
                                M3u8Settings: M3u8Settings;
                            };
                        };
                    };
                    MultiplexOutputSettings: MultiplexOutputSettings & {
                        Destination: OutputLocationRef;
                    };
                    RtmpOutputSettings: RtmpOutputSettings & {
                        Destination: OutputLocationRef;
                    };
                    UdpOutputSettings: UdpOutputSettings & {
                        ContainerSettings: UdpContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                    SrtOutputSettings: SrtOutputSettings & {
                        ContainerSettings: UdpContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                    MediaConnectRouterOutputSettings: MediaConnectRouterOutputSettings & {
                        ContainerSettings: MediaConnectRouterContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                };
            })[];
        })[];
        TimecodeConfig: TimecodeConfig & {
            Source: TimecodeConfigSource;
        };
        VideoDescriptions: (VideoDescription & {
            Name: string;
            CodecSettings: VideoCodecSettings & {
                FrameCaptureSettings: FrameCaptureSettings & {
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                H264Settings: H264Settings & {
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                H265Settings: H265Settings & {
                    FramerateDenominator: __integerMin1Max3003;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                Mpeg2Settings: Mpeg2Settings & {
                    FramerateDenominator: __integerMin1;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                Av1Settings: Av1Settings & {
                    FramerateDenominator: __integerMin1Max3003;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
            };
            CropRectangle: VideoPositionRectangle & {
                Height: __integerMin2Max8192;
                Width: __integerMin2Max8192;
                X: __integerMin0Max8190;
                Y: __integerMin0Max8190;
            };
            OutputPositionRectangle: VideoPositionRectangle & {
                Height: __integerMin2Max8192;
                Width: __integerMin2Max8192;
                X: __integerMin0Max8190;
                Y: __integerMin0Max8190;
            };
        })[];
        AvailBlanking: AvailBlanking & {
            AvailBlankingImage: InputLocation & {
                Uri: __stringMax2048;
            };
        };
        AvailConfiguration: AvailConfiguration & {
            AvailSettings: AvailSettings & {
                Esam: Esam & {
                    AcquisitionPointId: __stringMax256;
                    PoisEndpoint: __stringMax2048;
                };
            };
        };
        BlackoutSlate: BlackoutSlate & {
            BlackoutSlateImage: InputLocation & {
                Uri: __stringMax2048;
            };
            NetworkEndBlackoutImage: InputLocation & {
                Uri: __stringMax2048;
            };
        };
        CaptionDescriptions: (CaptionDescription & {
            CaptionSelectorName: string;
            Name: string;
            DestinationSettings: CaptionDestinationSettings & {
                BurnInDestinationSettings: BurnInDestinationSettings & {
                    Font: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
                DvbSubDestinationSettings: DvbSubDestinationSettings & {
                    Font: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
            };
        })[];
        GlobalConfiguration: GlobalConfiguration & {
            InputLossBehavior: InputLossBehavior & {
                InputLossImageSlate: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
        };
        MotionGraphicsConfiguration: MotionGraphicsConfiguration & {
            MotionGraphicsSettings: MotionGraphicsSettings;
        };
        ThumbnailConfiguration: ThumbnailConfiguration & {
            State: ThumbnailState;
        };
        ColorCorrectionSettings: ColorCorrectionSettings & {
            GlobalColorCorrections: (ColorCorrection & {
                InputColorSpace: ColorSpace;
                OutputColorSpace: ColorSpace;
                Uri: string;
            })[];
        };
    };
    Id?: string;
    InputAttachments?: (InputAttachment & {
        AutomaticInputFailoverSettings: AutomaticInputFailoverSettings & {
            SecondaryInputId: string;
            FailoverConditions: (FailoverCondition & {
                FailoverConditionSettings: FailoverConditionSettings & {
                    AudioSilenceSettings: AudioSilenceFailoverSettings & {
                        AudioSelectorName: string;
                    };
                };
            })[];
        };
        InputSettings: InputSettings & {
            AudioSelectors: (AudioSelector & {
                Name: __stringMin1;
                SelectorSettings: AudioSelectorSettings & {
                    AudioHlsRenditionSelection: AudioHlsRenditionSelection & {
                        GroupId: __stringMin1;
                        Name: __stringMin1;
                    };
                    AudioLanguageSelection: AudioLanguageSelection & {
                        LanguageCode: string;
                    };
                    AudioPidSelection: AudioPidSelection & {
                        Pid: __integerMin0Max8191;
                        Pids: (AudioPid & {
                            Pid: __integerMin0Max8191;
                            DolbyEDecode: AudioDolbyEDecode & {
                                ProgramSelection: DolbyEProgramSelection;
                            };
                            PremixSettings: AudioPreMixerSettings & {
                                RemixSettings: RemixSettings & {
                                    ChannelMappings: (AudioChannelMapping & {
                                        InputChannelLevels: (InputChannelLevel & {
                                            Gain: __integerMinNegative60Max6;
                                            InputChannel: __integerMin0Max15;
                                        })[];
                                        OutputChannel: __integerMin0Max7;
                                    })[];
                                };
                            };
                        })[];
                    };
                    AudioTrackSelection: AudioTrackSelection & {
                        Tracks: (AudioTrack & {
                            Track: __integerMin1;
                            PremixSettings: AudioPreMixerSettings & {
                                RemixSettings: RemixSettings & {
                                    ChannelMappings: (AudioChannelMapping & {
                                        InputChannelLevels: (InputChannelLevel & {
                                            Gain: __integerMinNegative60Max6;
                                            InputChannel: __integerMin0Max15;
                                        })[];
                                        OutputChannel: __integerMin0Max7;
                                    })[];
                                };
                            };
                        })[];
                        DolbyEDecode: AudioDolbyEDecode & {
                            ProgramSelection: DolbyEProgramSelection;
                        };
                    };
                };
            })[];
            CaptionSelectors: (CaptionSelector & {
                Name: __stringMin1;
                SelectorSettings: CaptionSelectorSettings & {
                    TeletextSourceSettings: TeletextSourceSettings & {
                        OutputRectangle: CaptionRectangle & {
                            Height: __doubleMin0Max100;
                            LeftOffset: __doubleMin0Max100;
                            TopOffset: __doubleMin0Max100;
                            Width: __doubleMin0Max100;
                        };
                    };
                };
            })[];
        };
    })[];
    InputSpecification?: InputSpecification;
    LogLevel?: LogLevel;
    Maintenance?: MaintenanceStatus;
    Name?: string;
    PipelineDetails?: PipelineDetail[];
    PipelinesRunningCount?: number;
    RoleArn?: string;
    State?: ChannelState;
    Tags?: {
        [key: string]: string | undefined;
    };
    Vpc?: VpcOutputSettingsDescription;
    AnywhereSettings?: DescribeAnywhereSettings;
    ChannelEngineVersion?: ChannelEngineVersionResponse;
    LinkedChannelSettings?: DescribeLinkedChannelSettings;
    ChannelSecurityGroups?: string[];
    InferenceSettings?: DescribeInferenceSettings;
}
export interface DeleteChannelPlacementGroupRequest {
    ChannelPlacementGroupId: string;
    ClusterId: string;
}
export interface DeleteChannelPlacementGroupResponse {
    Arn?: string;
    Channels?: string[];
    ClusterId?: string;
    Id?: string;
    Name?: string;
    Nodes?: string[];
    State?: ChannelPlacementGroupState;
}
export interface DeleteCloudWatchAlarmTemplateRequest {
    Identifier: string;
}
export interface DeleteCloudWatchAlarmTemplateResponse {
}
export interface DeleteCloudWatchAlarmTemplateGroupRequest {
    Identifier: string;
}
export interface DeleteCloudWatchAlarmTemplateGroupResponse {
}
export interface DeleteClusterRequest {
    ClusterId: string;
}
export interface DeleteClusterResponse {
    Arn?: string;
    ChannelIds?: string[];
    ClusterType?: ClusterType;
    Id?: string;
    InstanceRoleArn?: string;
    Name?: string;
    NetworkSettings?: ClusterNetworkSettings;
    State?: ClusterState;
}
export interface DeleteEventBridgeRuleTemplateRequest {
    Identifier: string;
}
export interface DeleteEventBridgeRuleTemplateResponse {
}
export interface DeleteEventBridgeRuleTemplateGroupRequest {
    Identifier: string;
}
export interface DeleteEventBridgeRuleTemplateGroupResponse {
}
export interface DeleteInputRequest {
    InputId: string;
}
export interface DeleteInputResponse {
}
export interface DeleteInputSecurityGroupRequest {
    InputSecurityGroupId: string;
}
export interface DeleteInputSecurityGroupResponse {
}
export interface DeleteMultiplexRequest {
    MultiplexId: string;
}
export interface DeleteMultiplexResponse {
    Arn?: string;
    AvailabilityZones?: string[];
    Destinations?: MultiplexOutputDestination[];
    Id?: string;
    MultiplexSettings?: MultiplexSettings & {
        TransportStreamBitrate: __integerMin1000000Max100000000;
        TransportStreamId: __integerMin0Max65535;
    };
    Name?: string;
    PipelinesRunningCount?: number;
    ProgramCount?: number;
    State?: MultiplexState;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DeleteMultiplexProgramRequest {
    MultiplexId: string;
    ProgramName: string;
}
export interface DeleteMultiplexProgramResponse {
    ChannelId?: string;
    MultiplexProgramSettings?: MultiplexProgramSettings & {
        ProgramNumber: __integerMin0Max65535;
        ServiceDescriptor: MultiplexProgramServiceDescriptor & {
            ProviderName: __stringMax256;
            ServiceName: __stringMax256;
        };
    };
    PacketIdentifiersMap?: MultiplexProgramPacketIdentifiersMap;
    PipelineDetails?: MultiplexProgramPipelineDetail[];
    ProgramName?: string;
}
export interface DeleteNetworkRequest {
    NetworkId: string;
}
export interface DeleteNetworkResponse {
    Arn?: string;
    AssociatedClusterIds?: string[];
    Id?: string;
    IpPools?: IpPool[];
    Name?: string;
    Routes?: Route[];
    State?: NetworkState;
}
export interface DeleteNodeRequest {
    ClusterId: string;
    NodeId: string;
}
export interface DeleteNodeResponse {
    Arn?: string;
    ChannelPlacementGroups?: string[];
    ClusterId?: string;
    ConnectionState?: NodeConnectionState;
    Id?: string;
    InstanceArn?: string;
    Name?: string;
    NodeInterfaceMappings?: NodeInterfaceMapping[];
    Role?: NodeRole;
    State?: NodeState;
    SdiSourceMappings?: SdiSourceMapping[];
}
export interface DeleteReservationRequest {
    ReservationId: string;
}
export type OfferingDurationUnits = "MONTHS" | (string & {});
export type OfferingType = "NO_UPFRONT" | (string & {});
export type ReservationAutomaticRenewal = "DISABLED" | "ENABLED" | "UNAVAILABLE" | (string & {});
export interface RenewalSettings {
    AutomaticRenewal?: ReservationAutomaticRenewal;
    RenewalCount?: number;
}
export type ReservationCodec = "MPEG2" | "AVC" | "HEVC" | "AUDIO" | "LINK" | "AV1" | (string & {});
export type ReservationMaximumBitrate = "MAX_10_MBPS" | "MAX_20_MBPS" | "MAX_50_MBPS" | (string & {});
export type ReservationMaximumFramerate = "MAX_30_FPS" | "MAX_60_FPS" | (string & {});
export type ReservationResolution = "SD" | "HD" | "FHD" | "UHD" | (string & {});
export type ReservationResourceType = "INPUT" | "OUTPUT" | "MULTIPLEX" | "CHANNEL" | (string & {});
export type ReservationSpecialFeature = "ADVANCED_AUDIO" | "AUDIO_NORMALIZATION" | "MGHD" | "MGUHD" | (string & {});
export type ReservationVideoQuality = "STANDARD" | "ENHANCED" | "PREMIUM" | (string & {});
export interface ReservationResourceSpecification {
    ChannelClass?: ChannelClass;
    Codec?: ReservationCodec;
    MaximumBitrate?: ReservationMaximumBitrate;
    MaximumFramerate?: ReservationMaximumFramerate;
    Resolution?: ReservationResolution;
    ResourceType?: ReservationResourceType;
    SpecialFeature?: ReservationSpecialFeature;
    VideoQuality?: ReservationVideoQuality;
}
export type ReservationState = "ACTIVE" | "EXPIRED" | "CANCELED" | "DELETED" | (string & {});
export interface DeleteReservationResponse {
    Arn?: string;
    Count?: number;
    CurrencyCode?: string;
    Duration?: number;
    DurationUnits?: OfferingDurationUnits;
    End?: string;
    FixedPrice?: number;
    Name?: string;
    OfferingDescription?: string;
    OfferingId?: string;
    OfferingType?: OfferingType;
    Region?: string;
    RenewalSettings?: RenewalSettings;
    ReservationId?: string;
    ResourceSpecification?: ReservationResourceSpecification;
    Start?: string;
    State?: ReservationState;
    Tags?: {
        [key: string]: string | undefined;
    };
    UsagePrice?: number;
}
export interface DeleteScheduleRequest {
    ChannelId: string;
}
export interface DeleteScheduleResponse {
}
export interface DeleteSdiSourceRequest {
    SdiSourceId: string;
}
export interface DeleteSdiSourceResponse {
    SdiSource?: SdiSource;
}
export interface DeleteSignalMapRequest {
    Identifier: string;
}
export interface DeleteSignalMapResponse {
}
export interface DeleteTagsRequest {
    ResourceArn: string;
    TagKeys?: string[];
}
export interface DeleteTagsResponse {
}
export interface DescribeAccountConfigurationRequest {
}
export interface AccountConfiguration {
    KmsKeyId?: string;
}
export interface DescribeAccountConfigurationResponse {
    AccountConfiguration?: AccountConfiguration;
}
export interface DescribeChannelRequest {
    ChannelId: string;
}
export interface DescribeChannelResponse {
    Arn?: string;
    CdiInputSpecification?: CdiInputSpecification;
    ChannelClass?: ChannelClass;
    Destinations?: OutputDestination[];
    EgressEndpoints?: ChannelEgressEndpoint[];
    EncoderSettings?: EncoderSettings & {
        AudioDescriptions: (AudioDescription & {
            AudioSelectorName: string;
            Name: __stringMax255;
            AudioWatermarkingSettings: AudioWatermarkSettings & {
                NielsenWatermarksSettings: NielsenWatermarksSettings & {
                    NielsenCbetSettings: NielsenCBET & {
                        CbetCheckDigitString: __stringMin2Max2;
                        CbetStepaside: NielsenWatermarksCbetStepaside;
                        Csid: __stringMin1Max7;
                    };
                    NielsenNaesIiNwSettings: NielsenNaesIiNw & {
                        CheckDigitString: __stringMin2Max2;
                        Sid: __doubleMin1Max65535;
                    };
                    NielsenNwOnlySettings: NielsenNwOnly & {
                        CheckDigitString: __stringMin2Max2;
                        Sid: __doubleMin1Max65535;
                    };
                };
            };
            RemixSettings: RemixSettings & {
                ChannelMappings: (AudioChannelMapping & {
                    InputChannelLevels: (InputChannelLevel & {
                        Gain: __integerMinNegative60Max6;
                        InputChannel: __integerMin0Max15;
                    })[];
                    OutputChannel: __integerMin0Max7;
                })[];
            };
        })[];
        OutputGroups: (OutputGroup & {
            OutputGroupSettings: OutputGroupSettings & {
                ArchiveGroupSettings: ArchiveGroupSettings & {
                    Destination: OutputLocationRef;
                };
                FrameCaptureGroupSettings: FrameCaptureGroupSettings & {
                    Destination: OutputLocationRef;
                };
                HlsGroupSettings: HlsGroupSettings & {
                    Destination: OutputLocationRef;
                    CaptionLanguageMappings: (CaptionLanguageMapping & {
                        CaptionChannel: __integerMin1Max4;
                        LanguageCode: __stringMin3Max3;
                        LanguageDescription: __stringMin1;
                    })[];
                    KeyProviderSettings: KeyProviderSettings & {
                        StaticKeySettings: StaticKeySettings & {
                            StaticKeyValue: __stringMin32Max32;
                            KeyProviderServer: InputLocation & {
                                Uri: __stringMax2048;
                            };
                        };
                    };
                };
                MediaPackageGroupSettings: MediaPackageGroupSettings & {
                    Destination: OutputLocationRef;
                    MediapackageV2GroupSettings: MediaPackageV2GroupSettings & {
                        CaptionLanguageMappings: (CaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                            LanguageDescription: __stringMin1;
                        })[];
                        AdditionalDestinations: (MediaPackageAdditionalDestinations & {
                            Destination: OutputLocationRef;
                        })[];
                        WatermarkingSettings: MediaPackageV2WatermarkingSettings & {
                            MediaPackageV2AbWatermarkerIrdetoSettings: MediaPackageV2AbWatermarkerIrdetoSettings & {
                                AlternateDestination: OutputLocationRef;
                                OperatorId: __integerMin1Max511;
                                Profile: AbWatermarkingProfile;
                                CustomProfile: AbWatermarkingCustomProfile & {
                                    EmbeddingFrequency: __doubleMin250Max5000;
                                    SceneCut: __doubleMinNegative1Max5;
                                    TargetPsnr: __doubleMin32Max46;
                                };
                            };
                        };
                    };
                };
                MsSmoothGroupSettings: MsSmoothGroupSettings & {
                    Destination: OutputLocationRef;
                };
                CmafIngestGroupSettings: CmafIngestGroupSettings & {
                    Destination: OutputLocationRef;
                    CaptionLanguageMappings: (CmafIngestCaptionLanguageMapping & {
                        CaptionChannel: __integerMin1Max4;
                        LanguageCode: __stringMin3Max3;
                    })[];
                    AdditionalDestinations: (AdditionalDestinations & {
                        Destination: OutputLocationRef;
                    })[];
                    WatermarkingSettings: CmafIngestWatermarkingSettings & {
                        CmafIngestAbWatermarkerIrdetoSettings: CmafIngestAbWatermarkerIrdetoSettings & {
                            AlternateDestination: OutputLocationRef;
                            OperatorId: __integerMin1Max511;
                            Profile: AbWatermarkingProfile;
                            CustomProfile: AbWatermarkingCustomProfile & {
                                EmbeddingFrequency: __doubleMin250Max5000;
                                SceneCut: __doubleMinNegative1Max5;
                                TargetPsnr: __doubleMin32Max46;
                            };
                        };
                    };
                };
            };
            Outputs: (Output & {
                OutputSettings: OutputSettings & {
                    ArchiveOutputSettings: ArchiveOutputSettings & {
                        ContainerSettings: ArchiveContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                    };
                    HlsOutputSettings: HlsOutputSettings & {
                        HlsSettings: HlsSettings & {
                            AudioOnlyHlsSettings: AudioOnlyHlsSettings & {
                                AudioOnlyImage: InputLocation & {
                                    Uri: __stringMax2048;
                                };
                            };
                            StandardHlsSettings: StandardHlsSettings & {
                                M3u8Settings: M3u8Settings;
                            };
                        };
                    };
                    MultiplexOutputSettings: MultiplexOutputSettings & {
                        Destination: OutputLocationRef;
                    };
                    RtmpOutputSettings: RtmpOutputSettings & {
                        Destination: OutputLocationRef;
                    };
                    UdpOutputSettings: UdpOutputSettings & {
                        ContainerSettings: UdpContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                    SrtOutputSettings: SrtOutputSettings & {
                        ContainerSettings: UdpContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                    MediaConnectRouterOutputSettings: MediaConnectRouterOutputSettings & {
                        ContainerSettings: MediaConnectRouterContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                };
            })[];
        })[];
        TimecodeConfig: TimecodeConfig & {
            Source: TimecodeConfigSource;
        };
        VideoDescriptions: (VideoDescription & {
            Name: string;
            CodecSettings: VideoCodecSettings & {
                FrameCaptureSettings: FrameCaptureSettings & {
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                H264Settings: H264Settings & {
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                H265Settings: H265Settings & {
                    FramerateDenominator: __integerMin1Max3003;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                Mpeg2Settings: Mpeg2Settings & {
                    FramerateDenominator: __integerMin1;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                Av1Settings: Av1Settings & {
                    FramerateDenominator: __integerMin1Max3003;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
            };
            CropRectangle: VideoPositionRectangle & {
                Height: __integerMin2Max8192;
                Width: __integerMin2Max8192;
                X: __integerMin0Max8190;
                Y: __integerMin0Max8190;
            };
            OutputPositionRectangle: VideoPositionRectangle & {
                Height: __integerMin2Max8192;
                Width: __integerMin2Max8192;
                X: __integerMin0Max8190;
                Y: __integerMin0Max8190;
            };
        })[];
        AvailBlanking: AvailBlanking & {
            AvailBlankingImage: InputLocation & {
                Uri: __stringMax2048;
            };
        };
        AvailConfiguration: AvailConfiguration & {
            AvailSettings: AvailSettings & {
                Esam: Esam & {
                    AcquisitionPointId: __stringMax256;
                    PoisEndpoint: __stringMax2048;
                };
            };
        };
        BlackoutSlate: BlackoutSlate & {
            BlackoutSlateImage: InputLocation & {
                Uri: __stringMax2048;
            };
            NetworkEndBlackoutImage: InputLocation & {
                Uri: __stringMax2048;
            };
        };
        CaptionDescriptions: (CaptionDescription & {
            CaptionSelectorName: string;
            Name: string;
            DestinationSettings: CaptionDestinationSettings & {
                BurnInDestinationSettings: BurnInDestinationSettings & {
                    Font: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
                DvbSubDestinationSettings: DvbSubDestinationSettings & {
                    Font: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
            };
        })[];
        GlobalConfiguration: GlobalConfiguration & {
            InputLossBehavior: InputLossBehavior & {
                InputLossImageSlate: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
        };
        MotionGraphicsConfiguration: MotionGraphicsConfiguration & {
            MotionGraphicsSettings: MotionGraphicsSettings;
        };
        ThumbnailConfiguration: ThumbnailConfiguration & {
            State: ThumbnailState;
        };
        ColorCorrectionSettings: ColorCorrectionSettings & {
            GlobalColorCorrections: (ColorCorrection & {
                InputColorSpace: ColorSpace;
                OutputColorSpace: ColorSpace;
                Uri: string;
            })[];
        };
    };
    Id?: string;
    InputAttachments?: (InputAttachment & {
        AutomaticInputFailoverSettings: AutomaticInputFailoverSettings & {
            SecondaryInputId: string;
            FailoverConditions: (FailoverCondition & {
                FailoverConditionSettings: FailoverConditionSettings & {
                    AudioSilenceSettings: AudioSilenceFailoverSettings & {
                        AudioSelectorName: string;
                    };
                };
            })[];
        };
        InputSettings: InputSettings & {
            AudioSelectors: (AudioSelector & {
                Name: __stringMin1;
                SelectorSettings: AudioSelectorSettings & {
                    AudioHlsRenditionSelection: AudioHlsRenditionSelection & {
                        GroupId: __stringMin1;
                        Name: __stringMin1;
                    };
                    AudioLanguageSelection: AudioLanguageSelection & {
                        LanguageCode: string;
                    };
                    AudioPidSelection: AudioPidSelection & {
                        Pid: __integerMin0Max8191;
                        Pids: (AudioPid & {
                            Pid: __integerMin0Max8191;
                            DolbyEDecode: AudioDolbyEDecode & {
                                ProgramSelection: DolbyEProgramSelection;
                            };
                            PremixSettings: AudioPreMixerSettings & {
                                RemixSettings: RemixSettings & {
                                    ChannelMappings: (AudioChannelMapping & {
                                        InputChannelLevels: (InputChannelLevel & {
                                            Gain: __integerMinNegative60Max6;
                                            InputChannel: __integerMin0Max15;
                                        })[];
                                        OutputChannel: __integerMin0Max7;
                                    })[];
                                };
                            };
                        })[];
                    };
                    AudioTrackSelection: AudioTrackSelection & {
                        Tracks: (AudioTrack & {
                            Track: __integerMin1;
                            PremixSettings: AudioPreMixerSettings & {
                                RemixSettings: RemixSettings & {
                                    ChannelMappings: (AudioChannelMapping & {
                                        InputChannelLevels: (InputChannelLevel & {
                                            Gain: __integerMinNegative60Max6;
                                            InputChannel: __integerMin0Max15;
                                        })[];
                                        OutputChannel: __integerMin0Max7;
                                    })[];
                                };
                            };
                        })[];
                        DolbyEDecode: AudioDolbyEDecode & {
                            ProgramSelection: DolbyEProgramSelection;
                        };
                    };
                };
            })[];
            CaptionSelectors: (CaptionSelector & {
                Name: __stringMin1;
                SelectorSettings: CaptionSelectorSettings & {
                    TeletextSourceSettings: TeletextSourceSettings & {
                        OutputRectangle: CaptionRectangle & {
                            Height: __doubleMin0Max100;
                            LeftOffset: __doubleMin0Max100;
                            TopOffset: __doubleMin0Max100;
                            Width: __doubleMin0Max100;
                        };
                    };
                };
            })[];
        };
    })[];
    InputSpecification?: InputSpecification;
    LogLevel?: LogLevel;
    Maintenance?: MaintenanceStatus;
    Name?: string;
    PipelineDetails?: PipelineDetail[];
    PipelinesRunningCount?: number;
    RoleArn?: string;
    State?: ChannelState;
    Tags?: {
        [key: string]: string | undefined;
    };
    Vpc?: VpcOutputSettingsDescription;
    AnywhereSettings?: DescribeAnywhereSettings;
    ChannelEngineVersion?: ChannelEngineVersionResponse;
    LinkedChannelSettings?: DescribeLinkedChannelSettings;
    ChannelSecurityGroups?: string[];
    InferenceSettings?: DescribeInferenceSettings;
}
export interface DescribeChannelPlacementGroupRequest {
    ChannelPlacementGroupId: string;
    ClusterId: string;
}
export interface DescribeChannelPlacementGroupResponse {
    Arn?: string;
    Channels?: string[];
    ClusterId?: string;
    Id?: string;
    Name?: string;
    Nodes?: string[];
    State?: ChannelPlacementGroupState;
}
export interface DescribeClusterRequest {
    ClusterId: string;
}
export interface DescribeClusterResponse {
    Arn?: string;
    ChannelIds?: string[];
    ClusterType?: ClusterType;
    Id?: string;
    InstanceRoleArn?: string;
    Name?: string;
    NetworkSettings?: ClusterNetworkSettings;
    State?: ClusterState;
}
export interface DescribeInputRequest {
    InputId: string;
}
export interface DescribeInputResponse {
    Arn?: string;
    AttachedChannels?: string[];
    Destinations?: InputDestination[];
    Id?: string;
    InputClass?: InputClass;
    InputDevices?: InputDeviceSettings[];
    InputPartnerIds?: string[];
    InputSourceType?: InputSourceType;
    MediaConnectFlows?: MediaConnectFlow[];
    Name?: string;
    RoleArn?: string;
    SecurityGroups?: string[];
    Sources?: InputSource[];
    State?: InputState;
    Tags?: {
        [key: string]: string | undefined;
    };
    Type?: InputType;
    SrtSettings?: SrtSettings & {
        SrtListenerSettings: SrtListenerSettings & {
            Decryption: SrtListenerDecryption & {
                Algorithm: Algorithm;
                PassphraseSecretArn: string;
            };
        };
    };
    InputNetworkLocation?: InputNetworkLocation;
    MulticastSettings?: MulticastSettings & {
        Sources: (MulticastSource & {
            Url: string;
        })[];
    };
    Smpte2110ReceiverGroupSettings?: Smpte2110ReceiverGroupSettings;
    SdiSources?: string[];
    RouterSettings?: RouterInputSettings;
}
export interface DescribeInputDeviceRequest {
    InputDeviceId: string;
}
export type InputDeviceConnectionState = "DISCONNECTED" | "CONNECTED" | (string & {});
export type DeviceSettingsSyncState = "SYNCED" | "SYNCING" | (string & {});
export type DeviceUpdateStatus = "UP_TO_DATE" | "NOT_UP_TO_DATE" | "UPDATING" | (string & {});
export type InputDeviceActiveInput = "HDMI" | "SDI" | (string & {});
export type InputDeviceConfiguredInput = "AUTO" | "HDMI" | "SDI" | (string & {});
export type InputDeviceState = "IDLE" | "STREAMING" | (string & {});
export type InputDeviceScanType = "INTERLACED" | "PROGRESSIVE" | (string & {});
export interface InputDeviceHdSettings {
    ActiveInput?: InputDeviceActiveInput;
    ConfiguredInput?: InputDeviceConfiguredInput;
    DeviceState?: InputDeviceState;
    Framerate?: number;
    Height?: number;
    MaxBitrate?: number;
    ScanType?: InputDeviceScanType;
    Width?: number;
    LatencyMs?: number;
}
export type InputDeviceIpScheme = "STATIC" | "DHCP" | (string & {});
export interface InputDeviceNetworkSettings {
    DnsAddresses?: string[];
    Gateway?: string;
    IpAddress?: string;
    IpScheme?: InputDeviceIpScheme;
    SubnetMask?: string;
}
export type InputDeviceType = "HD" | "UHD" | (string & {});
export type InputDeviceCodec = "HEVC" | "AVC" | (string & {});
export interface InputDeviceMediaConnectSettings {
    FlowArn?: string;
    RoleArn?: string;
    SecretArn?: string;
    SourceName?: string;
}
export type InputDeviceUhdAudioChannelPairProfile = "DISABLED" | "VBR-AAC_HHE-16000" | "VBR-AAC_HE-64000" | "VBR-AAC_LC-128000" | "CBR-AAC_HQ-192000" | "CBR-AAC_HQ-256000" | "CBR-AAC_HQ-384000" | "CBR-AAC_HQ-512000" | (string & {});
export interface InputDeviceUhdAudioChannelPairConfig {
    Id?: number;
    Profile?: InputDeviceUhdAudioChannelPairProfile;
}
export type __listOfInputDeviceUhdAudioChannelPairConfig = InputDeviceUhdAudioChannelPairConfig[];
export interface InputDeviceUhdSettings {
    ActiveInput?: InputDeviceActiveInput;
    ConfiguredInput?: InputDeviceConfiguredInput;
    DeviceState?: InputDeviceState;
    Framerate?: number;
    Height?: number;
    MaxBitrate?: number;
    ScanType?: InputDeviceScanType;
    Width?: number;
    LatencyMs?: number;
    Codec?: InputDeviceCodec;
    MediaconnectSettings?: InputDeviceMediaConnectSettings;
    AudioChannelPairs?: InputDeviceUhdAudioChannelPairConfig[];
    InputResolution?: string;
}
export type InputDeviceOutputType = "NONE" | "MEDIALIVE_INPUT" | "MEDIACONNECT_FLOW" | (string & {});
export interface DescribeInputDeviceResponse {
    Arn?: string;
    ConnectionState?: InputDeviceConnectionState;
    DeviceSettingsSyncState?: DeviceSettingsSyncState;
    DeviceUpdateStatus?: DeviceUpdateStatus;
    HdDeviceSettings?: InputDeviceHdSettings;
    Id?: string;
    MacAddress?: string;
    Name?: string;
    NetworkSettings?: InputDeviceNetworkSettings;
    SerialNumber?: string;
    Type?: InputDeviceType;
    UhdDeviceSettings?: InputDeviceUhdSettings;
    Tags?: {
        [key: string]: string | undefined;
    };
    AvailabilityZone?: string;
    MedialiveInputArns?: string[];
    OutputType?: InputDeviceOutputType;
}
export type AcceptHeader = "image/jpeg" | (string & {});
export interface DescribeInputDeviceThumbnailRequest {
    InputDeviceId: string;
    Accept?: AcceptHeader;
}
export type ContentType = "image/jpeg" | (string & {});
export type __timestamp = Date;
export interface DescribeInputDeviceThumbnailResponse {
    Body?: T.StreamingOutputBody;
    ContentType?: ContentType;
    ContentLength?: number;
    ETag?: string;
    LastModified?: Date;
}
export interface DescribeInputSecurityGroupRequest {
    InputSecurityGroupId: string;
}
export interface DescribeInputSecurityGroupResponse {
    Arn?: string;
    Id?: string;
    Inputs?: string[];
    State?: InputSecurityGroupState;
    Tags?: {
        [key: string]: string | undefined;
    };
    WhitelistRules?: InputWhitelistRule[];
    Channels?: string[];
}
export interface DescribeMultiplexRequest {
    MultiplexId: string;
}
export interface DescribeMultiplexResponse {
    Arn?: string;
    AvailabilityZones?: string[];
    Destinations?: MultiplexOutputDestination[];
    Id?: string;
    MultiplexSettings?: MultiplexSettings & {
        TransportStreamBitrate: __integerMin1000000Max100000000;
        TransportStreamId: __integerMin0Max65535;
    };
    Name?: string;
    PipelinesRunningCount?: number;
    ProgramCount?: number;
    State?: MultiplexState;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeMultiplexProgramRequest {
    MultiplexId: string;
    ProgramName: string;
}
export interface DescribeMultiplexProgramResponse {
    ChannelId?: string;
    MultiplexProgramSettings?: MultiplexProgramSettings & {
        ProgramNumber: __integerMin0Max65535;
        ServiceDescriptor: MultiplexProgramServiceDescriptor & {
            ProviderName: __stringMax256;
            ServiceName: __stringMax256;
        };
    };
    PacketIdentifiersMap?: MultiplexProgramPacketIdentifiersMap;
    PipelineDetails?: MultiplexProgramPipelineDetail[];
    ProgramName?: string;
}
export interface DescribeNetworkRequest {
    NetworkId: string;
}
export interface DescribeNetworkResponse {
    Arn?: string;
    AssociatedClusterIds?: string[];
    Id?: string;
    IpPools?: IpPool[];
    Name?: string;
    Routes?: Route[];
    State?: NetworkState;
}
export interface DescribeNodeRequest {
    ClusterId: string;
    NodeId: string;
}
export interface DescribeNodeResponse {
    Arn?: string;
    ChannelPlacementGroups?: string[];
    ClusterId?: string;
    ConnectionState?: NodeConnectionState;
    Id?: string;
    InstanceArn?: string;
    Name?: string;
    NodeInterfaceMappings?: NodeInterfaceMapping[];
    Role?: NodeRole;
    State?: NodeState;
    SdiSourceMappings?: SdiSourceMapping[];
}
export interface DescribeOfferingRequest {
    OfferingId: string;
}
export interface DescribeOfferingResponse {
    Arn?: string;
    CurrencyCode?: string;
    Duration?: number;
    DurationUnits?: OfferingDurationUnits;
    FixedPrice?: number;
    OfferingDescription?: string;
    OfferingId?: string;
    OfferingType?: OfferingType;
    Region?: string;
    ResourceSpecification?: ReservationResourceSpecification;
    UsagePrice?: number;
}
export interface DescribeReservationRequest {
    ReservationId: string;
}
export interface DescribeReservationResponse {
    Arn?: string;
    Count?: number;
    CurrencyCode?: string;
    Duration?: number;
    DurationUnits?: OfferingDurationUnits;
    End?: string;
    FixedPrice?: number;
    Name?: string;
    OfferingDescription?: string;
    OfferingId?: string;
    OfferingType?: OfferingType;
    Region?: string;
    RenewalSettings?: RenewalSettings;
    ReservationId?: string;
    ResourceSpecification?: ReservationResourceSpecification;
    Start?: string;
    State?: ReservationState;
    Tags?: {
        [key: string]: string | undefined;
    };
    UsagePrice?: number;
}
export type MaxResults = number;
export interface DescribeScheduleRequest {
    ChannelId: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface DescribeScheduleResponse {
    NextToken?: string;
    ScheduleActions?: (ScheduleAction & {
        ActionName: string;
        ScheduleActionSettings: ScheduleActionSettings & {
            HlsTimedMetadataSettings: HlsTimedMetadataScheduleActionSettings & {
                Id3: string;
            };
            InputPrepareSettings: InputPrepareScheduleActionSettings & {
                InputClippingSettings: InputClippingSettings & {
                    InputTimecodeSource: InputTimecodeSource;
                };
            };
            InputSwitchSettings: InputSwitchScheduleActionSettings & {
                InputAttachmentNameReference: string;
                InputClippingSettings: InputClippingSettings & {
                    InputTimecodeSource: InputTimecodeSource;
                };
            };
            PauseStateSettings: PauseStateScheduleActionSettings & {
                Pipelines: (PipelinePauseStateSettings & {
                    PipelineId: PipelineId;
                })[];
            };
            Scte35InputSettings: Scte35InputScheduleActionSettings & {
                Mode: Scte35InputMode;
            };
            Scte35ReturnToNetworkSettings: Scte35ReturnToNetworkScheduleActionSettings & {
                SpliceEventId: __longMin0Max4294967295;
            };
            Scte35SpliceInsertSettings: Scte35SpliceInsertScheduleActionSettings & {
                SpliceEventId: __longMin0Max4294967295;
            };
            Scte35TimeSignalSettings: Scte35TimeSignalScheduleActionSettings & {
                Scte35Descriptors: (Scte35Descriptor & {
                    Scte35DescriptorSettings: Scte35DescriptorSettings & {
                        SegmentationDescriptorScte35DescriptorSettings: Scte35SegmentationDescriptor & {
                            SegmentationCancelIndicator: Scte35SegmentationCancelIndicator;
                            SegmentationEventId: __longMin0Max4294967295;
                            DeliveryRestrictions: Scte35DeliveryRestrictions & {
                                ArchiveAllowedFlag: Scte35ArchiveAllowedFlag;
                                DeviceRestrictions: Scte35DeviceRestrictions;
                                NoRegionalBlackoutFlag: Scte35NoRegionalBlackoutFlag;
                                WebDeliveryAllowedFlag: Scte35WebDeliveryAllowedFlag;
                            };
                        };
                    };
                })[];
            };
            StaticImageActivateSettings: StaticImageActivateScheduleActionSettings & {
                Image: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
            StaticImageOutputActivateSettings: StaticImageOutputActivateScheduleActionSettings & {
                Image: InputLocation & {
                    Uri: __stringMax2048;
                };
                OutputNames: __listOf__string;
            };
            StaticImageOutputDeactivateSettings: StaticImageOutputDeactivateScheduleActionSettings & {
                OutputNames: __listOf__string;
            };
            TimedMetadataSettings: TimedMetadataScheduleActionSettings & {
                Id3: string;
            };
        };
        ScheduleActionStartSettings: ScheduleActionStartSettings & {
            FixedModeScheduleActionStartSettings: FixedModeScheduleActionStartSettings & {
                Time: string;
            };
            FollowModeScheduleActionStartSettings: FollowModeScheduleActionStartSettings & {
                FollowPoint: FollowPoint;
                ReferenceActionName: string;
            };
        };
    })[];
}
export interface DescribeSdiSourceRequest {
    SdiSourceId: string;
}
export interface DescribeSdiSourceResponse {
    SdiSource?: SdiSource;
}
export interface DescribeThumbnailsRequest {
    ChannelId: string;
    PipelineId?: string;
    ThumbnailType?: string;
}
export type ThumbnailType = "UNSPECIFIED" | "CURRENT_ACTIVE" | (string & {});
export interface Thumbnail {
    Body?: string;
    ContentType?: string;
    ThumbnailType?: ThumbnailType;
    TimeStamp?: Date;
}
export type __listOfThumbnail = Thumbnail[];
export interface ThumbnailDetail {
    PipelineId?: string;
    Thumbnails?: Thumbnail[];
}
export type __listOfThumbnailDetail = ThumbnailDetail[];
export interface DescribeThumbnailsResponse {
    ThumbnailDetails?: ThumbnailDetail[];
}
export interface GetCloudWatchAlarmTemplateRequest {
    Identifier: string;
}
export interface GetCloudWatchAlarmTemplateResponse {
    Arn?: string;
    ComparisonOperator?: CloudWatchAlarmTemplateComparisonOperator;
    CreatedAt?: Date;
    DatapointsToAlarm?: number;
    Description?: string;
    EvaluationPeriods?: number;
    GroupId?: string;
    Id?: string;
    MetricName?: string;
    ModifiedAt?: Date;
    Name?: string;
    Period?: number;
    Statistic?: CloudWatchAlarmTemplateStatistic;
    Tags?: {
        [key: string]: string | undefined;
    };
    TargetResourceType?: CloudWatchAlarmTemplateTargetResourceType;
    Threshold?: number;
    TreatMissingData?: CloudWatchAlarmTemplateTreatMissingData;
}
export interface GetCloudWatchAlarmTemplateGroupRequest {
    Identifier: string;
}
export interface GetCloudWatchAlarmTemplateGroupResponse {
    Arn?: string;
    CreatedAt?: Date;
    Description?: string;
    Id?: string;
    ModifiedAt?: Date;
    Name?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetEventBridgeRuleTemplateRequest {
    Identifier: string;
}
export interface GetEventBridgeRuleTemplateResponse {
    Arn?: string;
    CreatedAt?: Date;
    Description?: string;
    EventTargets?: (EventBridgeRuleTemplateTarget & {
        Arn: __stringMin1Max2048PatternArn;
    })[];
    EventType?: EventBridgeRuleTemplateEventType;
    GroupId?: string;
    Id?: string;
    ModifiedAt?: Date;
    Name?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetEventBridgeRuleTemplateGroupRequest {
    Identifier: string;
}
export interface GetEventBridgeRuleTemplateGroupResponse {
    Arn?: string;
    CreatedAt?: Date;
    Description?: string;
    Id?: string;
    ModifiedAt?: Date;
    Name?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetSignalMapRequest {
    Identifier: string;
}
export interface GetSignalMapResponse {
    Arn?: string;
    CloudWatchAlarmTemplateGroupIds?: string[];
    CreatedAt?: Date;
    Description?: string;
    DiscoveryEntryPointArn?: string;
    ErrorMessage?: string;
    EventBridgeRuleTemplateGroupIds?: string[];
    FailedMediaResourceMap?: {
        [key: string]: (MediaResource & {
            Destinations: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
            Sources: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
        }) | undefined;
    };
    Id?: string;
    LastDiscoveredAt?: Date;
    LastSuccessfulMonitorDeployment?: SuccessfulMonitorDeployment & {
        DetailsUri: __stringMin1Max2048;
        Status: SignalMapMonitorDeploymentStatus;
    };
    MediaResourceMap?: {
        [key: string]: (MediaResource & {
            Destinations: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
            Sources: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
        }) | undefined;
    };
    ModifiedAt?: Date;
    MonitorChangesPendingDeployment?: boolean;
    MonitorDeployment?: MonitorDeployment & {
        Status: SignalMapMonitorDeploymentStatus;
    };
    Name?: string;
    Status?: SignalMapStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListAlertsRequest {
    ChannelId: string;
    MaxResults?: number;
    NextToken?: string;
    StateFilter?: string;
}
export type ChannelAlertState = "SET" | "CLEARED" | (string & {});
export interface ChannelAlert {
    AlertType?: string;
    ClearedTimestamp?: Date;
    Id?: string;
    Message?: string;
    PipelineId?: string;
    SetTimestamp?: Date;
    State?: ChannelAlertState;
}
export type __listOfChannelAlert = ChannelAlert[];
export interface ListAlertsResponse {
    Alerts?: ChannelAlert[];
    NextToken?: string;
}
export interface ListChannelPlacementGroupsRequest {
    ClusterId: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface DescribeChannelPlacementGroupSummary {
    Arn?: string;
    Channels?: string[];
    ClusterId?: string;
    Id?: string;
    Name?: string;
    Nodes?: string[];
    State?: ChannelPlacementGroupState;
}
export type __listOfDescribeChannelPlacementGroupSummary = DescribeChannelPlacementGroupSummary[];
export interface ListChannelPlacementGroupsResponse {
    ChannelPlacementGroups?: DescribeChannelPlacementGroupSummary[];
    NextToken?: string;
}
export interface ListChannelsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export type __listOfChannelEngineVersionResponse = ChannelEngineVersionResponse[];
export interface ChannelSummary {
    Arn?: string;
    CdiInputSpecification?: CdiInputSpecification;
    ChannelClass?: ChannelClass;
    Destinations?: OutputDestination[];
    EgressEndpoints?: ChannelEgressEndpoint[];
    Id?: string;
    InputAttachments?: InputAttachment[];
    InputSpecification?: InputSpecification;
    LogLevel?: LogLevel;
    Maintenance?: MaintenanceStatus;
    Name?: string;
    PipelinesRunningCount?: number;
    RoleArn?: string;
    State?: ChannelState;
    Tags?: {
        [key: string]: string | undefined;
    };
    Vpc?: VpcOutputSettingsDescription;
    AnywhereSettings?: DescribeAnywhereSettings;
    ChannelEngineVersion?: ChannelEngineVersionResponse;
    UsedChannelEngineVersions?: ChannelEngineVersionResponse[];
    LinkedChannelSettings?: DescribeLinkedChannelSettings;
    ChannelSecurityGroups?: string[];
    InferenceSettings?: DescribeInferenceSettings;
}
export type __listOfChannelSummary = ChannelSummary[];
export interface ListChannelsResponse {
    Channels?: (ChannelSummary & {
        InputAttachments: (InputAttachment & {
            AutomaticInputFailoverSettings: AutomaticInputFailoverSettings & {
                SecondaryInputId: string;
                FailoverConditions: (FailoverCondition & {
                    FailoverConditionSettings: FailoverConditionSettings & {
                        AudioSilenceSettings: AudioSilenceFailoverSettings & {
                            AudioSelectorName: string;
                        };
                    };
                })[];
            };
            InputSettings: InputSettings & {
                AudioSelectors: (AudioSelector & {
                    Name: __stringMin1;
                    SelectorSettings: AudioSelectorSettings & {
                        AudioHlsRenditionSelection: AudioHlsRenditionSelection & {
                            GroupId: __stringMin1;
                            Name: __stringMin1;
                        };
                        AudioLanguageSelection: AudioLanguageSelection & {
                            LanguageCode: string;
                        };
                        AudioPidSelection: AudioPidSelection & {
                            Pid: __integerMin0Max8191;
                            Pids: (AudioPid & {
                                Pid: __integerMin0Max8191;
                                DolbyEDecode: AudioDolbyEDecode & {
                                    ProgramSelection: DolbyEProgramSelection;
                                };
                                PremixSettings: AudioPreMixerSettings & {
                                    RemixSettings: RemixSettings & {
                                        ChannelMappings: (AudioChannelMapping & {
                                            InputChannelLevels: (InputChannelLevel & {
                                                Gain: __integerMinNegative60Max6;
                                                InputChannel: __integerMin0Max15;
                                            })[];
                                            OutputChannel: __integerMin0Max7;
                                        })[];
                                    };
                                };
                            })[];
                        };
                        AudioTrackSelection: AudioTrackSelection & {
                            Tracks: (AudioTrack & {
                                Track: __integerMin1;
                                PremixSettings: AudioPreMixerSettings & {
                                    RemixSettings: RemixSettings & {
                                        ChannelMappings: (AudioChannelMapping & {
                                            InputChannelLevels: (InputChannelLevel & {
                                                Gain: __integerMinNegative60Max6;
                                                InputChannel: __integerMin0Max15;
                                            })[];
                                            OutputChannel: __integerMin0Max7;
                                        })[];
                                    };
                                };
                            })[];
                            DolbyEDecode: AudioDolbyEDecode & {
                                ProgramSelection: DolbyEProgramSelection;
                            };
                        };
                    };
                })[];
                CaptionSelectors: (CaptionSelector & {
                    Name: __stringMin1;
                    SelectorSettings: CaptionSelectorSettings & {
                        TeletextSourceSettings: TeletextSourceSettings & {
                            OutputRectangle: CaptionRectangle & {
                                Height: __doubleMin0Max100;
                                LeftOffset: __doubleMin0Max100;
                                TopOffset: __doubleMin0Max100;
                                Width: __doubleMin0Max100;
                            };
                        };
                    };
                })[];
            };
        })[];
    })[];
    NextToken?: string;
}
export interface ListCloudWatchAlarmTemplateGroupsRequest {
    MaxResults?: number;
    NextToken?: string;
    Scope?: string;
    SignalMapIdentifier?: string;
}
export interface CloudWatchAlarmTemplateGroupSummary {
    Arn?: string;
    CreatedAt?: Date;
    Description?: string;
    Id?: string;
    ModifiedAt?: Date;
    Name?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    TemplateCount?: number;
}
export type __listOfCloudWatchAlarmTemplateGroupSummary = CloudWatchAlarmTemplateGroupSummary[];
export interface ListCloudWatchAlarmTemplateGroupsResponse {
    CloudWatchAlarmTemplateGroups?: (CloudWatchAlarmTemplateGroupSummary & {
        Arn: __stringPatternArnMedialiveCloudwatchAlarmTemplateGroup;
        CreatedAt: __timestampIso8601;
        Id: __stringMin7Max11PatternAws097;
        Name: __stringMin1Max255PatternS;
        TemplateCount: number;
    })[];
    NextToken?: string;
}
export interface ListCloudWatchAlarmTemplatesRequest {
    GroupIdentifier?: string;
    MaxResults?: number;
    NextToken?: string;
    Scope?: string;
    SignalMapIdentifier?: string;
}
export interface CloudWatchAlarmTemplateSummary {
    Arn?: string;
    ComparisonOperator?: CloudWatchAlarmTemplateComparisonOperator;
    CreatedAt?: Date;
    DatapointsToAlarm?: number;
    Description?: string;
    EvaluationPeriods?: number;
    GroupId?: string;
    Id?: string;
    MetricName?: string;
    ModifiedAt?: Date;
    Name?: string;
    Period?: number;
    Statistic?: CloudWatchAlarmTemplateStatistic;
    Tags?: {
        [key: string]: string | undefined;
    };
    TargetResourceType?: CloudWatchAlarmTemplateTargetResourceType;
    Threshold?: number;
    TreatMissingData?: CloudWatchAlarmTemplateTreatMissingData;
}
export type __listOfCloudWatchAlarmTemplateSummary = CloudWatchAlarmTemplateSummary[];
export interface ListCloudWatchAlarmTemplatesResponse {
    CloudWatchAlarmTemplates?: (CloudWatchAlarmTemplateSummary & {
        Arn: __stringPatternArnMedialiveCloudwatchAlarmTemplate;
        ComparisonOperator: CloudWatchAlarmTemplateComparisonOperator;
        CreatedAt: __timestampIso8601;
        EvaluationPeriods: __integerMin1;
        GroupId: __stringMin7Max11PatternAws097;
        Id: __stringMin7Max11PatternAws097;
        MetricName: __stringMax64;
        Name: __stringMin1Max255PatternS;
        Period: __integerMin10Max86400;
        Statistic: CloudWatchAlarmTemplateStatistic;
        TargetResourceType: CloudWatchAlarmTemplateTargetResourceType;
        Threshold: number;
        TreatMissingData: CloudWatchAlarmTemplateTreatMissingData;
    })[];
    NextToken?: string;
}
export interface ListClusterAlertsRequest {
    ClusterId: string;
    MaxResults?: number;
    NextToken?: string;
    StateFilter?: string;
}
export type ClusterAlertState = "SET" | "CLEARED" | (string & {});
export interface ClusterAlert {
    AlertType?: string;
    ChannelId?: string;
    ClearedTimestamp?: Date;
    Id?: string;
    Message?: string;
    NodeId?: string;
    SetTimestamp?: Date;
    State?: ClusterAlertState;
}
export type __listOfClusterAlert = ClusterAlert[];
export interface ListClusterAlertsResponse {
    Alerts?: ClusterAlert[];
    NextToken?: string;
}
export interface ListClustersRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface DescribeClusterSummary {
    Arn?: string;
    ChannelIds?: string[];
    ClusterType?: ClusterType;
    Id?: string;
    InstanceRoleArn?: string;
    Name?: string;
    NetworkSettings?: ClusterNetworkSettings;
    State?: ClusterState;
}
export type __listOfDescribeClusterSummary = DescribeClusterSummary[];
export interface ListClustersResponse {
    Clusters?: DescribeClusterSummary[];
    NextToken?: string;
}
export interface ListEventBridgeRuleTemplateGroupsRequest {
    MaxResults?: number;
    NextToken?: string;
    SignalMapIdentifier?: string;
}
export interface EventBridgeRuleTemplateGroupSummary {
    Arn?: string;
    CreatedAt?: Date;
    Description?: string;
    Id?: string;
    ModifiedAt?: Date;
    Name?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    TemplateCount?: number;
}
export type __listOfEventBridgeRuleTemplateGroupSummary = EventBridgeRuleTemplateGroupSummary[];
export interface ListEventBridgeRuleTemplateGroupsResponse {
    EventBridgeRuleTemplateGroups?: (EventBridgeRuleTemplateGroupSummary & {
        Arn: __stringPatternArnMedialiveEventbridgeRuleTemplateGroup;
        CreatedAt: __timestampIso8601;
        Id: __stringMin7Max11PatternAws097;
        Name: __stringMin1Max255PatternS;
        TemplateCount: number;
    })[];
    NextToken?: string;
}
export interface ListEventBridgeRuleTemplatesRequest {
    GroupIdentifier?: string;
    MaxResults?: number;
    NextToken?: string;
    SignalMapIdentifier?: string;
}
export type __integerMax5 = number;
export interface EventBridgeRuleTemplateSummary {
    Arn?: string;
    CreatedAt?: Date;
    Description?: string;
    EventTargetCount?: number;
    EventType?: EventBridgeRuleTemplateEventType;
    GroupId?: string;
    Id?: string;
    ModifiedAt?: Date;
    Name?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfEventBridgeRuleTemplateSummary = EventBridgeRuleTemplateSummary[];
export interface ListEventBridgeRuleTemplatesResponse {
    EventBridgeRuleTemplates?: (EventBridgeRuleTemplateSummary & {
        Arn: __stringPatternArnMedialiveEventbridgeRuleTemplate;
        CreatedAt: __timestampIso8601;
        EventTargetCount: __integerMax5;
        EventType: EventBridgeRuleTemplateEventType;
        GroupId: __stringMin7Max11PatternAws097;
        Id: __stringMin7Max11PatternAws097;
        Name: __stringMin1Max255PatternS;
    })[];
    NextToken?: string;
}
export interface ListInputDevicesRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface InputDeviceSummary {
    Arn?: string;
    ConnectionState?: InputDeviceConnectionState;
    DeviceSettingsSyncState?: DeviceSettingsSyncState;
    DeviceUpdateStatus?: DeviceUpdateStatus;
    HdDeviceSettings?: InputDeviceHdSettings;
    Id?: string;
    MacAddress?: string;
    Name?: string;
    NetworkSettings?: InputDeviceNetworkSettings;
    SerialNumber?: string;
    Type?: InputDeviceType;
    UhdDeviceSettings?: InputDeviceUhdSettings;
    Tags?: {
        [key: string]: string | undefined;
    };
    AvailabilityZone?: string;
    MedialiveInputArns?: string[];
    OutputType?: InputDeviceOutputType;
}
export type __listOfInputDeviceSummary = InputDeviceSummary[];
export interface ListInputDevicesResponse {
    InputDevices?: InputDeviceSummary[];
    NextToken?: string;
}
export interface ListInputDeviceTransfersRequest {
    MaxResults?: number;
    NextToken?: string;
    TransferType?: string;
}
export type InputDeviceTransferType = "OUTGOING" | "INCOMING" | (string & {});
export interface TransferringInputDeviceSummary {
    Id?: string;
    Message?: string;
    TargetCustomerId?: string;
    TransferType?: InputDeviceTransferType;
}
export type __listOfTransferringInputDeviceSummary = TransferringInputDeviceSummary[];
export interface ListInputDeviceTransfersResponse {
    InputDeviceTransfers?: TransferringInputDeviceSummary[];
    NextToken?: string;
}
export interface ListInputsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export type __listOfInput = Input[];
export interface ListInputsResponse {
    Inputs?: (Input & {
        SrtSettings: SrtSettings & {
            SrtListenerSettings: SrtListenerSettings & {
                Decryption: SrtListenerDecryption & {
                    Algorithm: Algorithm;
                    PassphraseSecretArn: string;
                };
            };
        };
        MulticastSettings: MulticastSettings & {
            Sources: (MulticastSource & {
                Url: string;
            })[];
        };
    })[];
    NextToken?: string;
}
export interface ListInputSecurityGroupsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export type __listOfInputSecurityGroup = InputSecurityGroup[];
export interface ListInputSecurityGroupsResponse {
    InputSecurityGroups?: InputSecurityGroup[];
    NextToken?: string;
}
export interface ListMultiplexAlertsRequest {
    MaxResults?: number;
    MultiplexId: string;
    NextToken?: string;
    StateFilter?: string;
}
export type MultiplexAlertState = "SET" | "CLEARED" | (string & {});
export interface MultiplexAlert {
    AlertType?: string;
    ClearedTimestamp?: Date;
    Id?: string;
    Message?: string;
    PipelineId?: string;
    SetTimestamp?: Date;
    State?: MultiplexAlertState;
}
export type __listOfMultiplexAlert = MultiplexAlert[];
export interface ListMultiplexAlertsResponse {
    Alerts?: MultiplexAlert[];
    NextToken?: string;
}
export interface ListMultiplexesRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface MultiplexSettingsSummary {
    TransportStreamBitrate?: number;
}
export interface MultiplexSummary {
    Arn?: string;
    AvailabilityZones?: string[];
    Id?: string;
    MultiplexSettings?: MultiplexSettingsSummary;
    Name?: string;
    PipelinesRunningCount?: number;
    ProgramCount?: number;
    State?: MultiplexState;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfMultiplexSummary = MultiplexSummary[];
export interface ListMultiplexesResponse {
    Multiplexes?: MultiplexSummary[];
    NextToken?: string;
}
export interface ListMultiplexProgramsRequest {
    MaxResults?: number;
    MultiplexId: string;
    NextToken?: string;
}
export interface MultiplexProgramSummary {
    ChannelId?: string;
    ProgramName?: string;
}
export type __listOfMultiplexProgramSummary = MultiplexProgramSummary[];
export interface ListMultiplexProgramsResponse {
    MultiplexPrograms?: MultiplexProgramSummary[];
    NextToken?: string;
}
export interface ListNetworksRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface DescribeNetworkSummary {
    Arn?: string;
    AssociatedClusterIds?: string[];
    Id?: string;
    IpPools?: IpPool[];
    Name?: string;
    Routes?: Route[];
    State?: NetworkState;
}
export type __listOfDescribeNetworkSummary = DescribeNetworkSummary[];
export interface ListNetworksResponse {
    Networks?: DescribeNetworkSummary[];
    NextToken?: string;
}
export interface ListNodesRequest {
    ClusterId: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface DescribeNodeSummary {
    Arn?: string;
    ChannelPlacementGroups?: string[];
    ClusterId?: string;
    ConnectionState?: NodeConnectionState;
    Id?: string;
    InstanceArn?: string;
    ManagedInstanceId?: string;
    Name?: string;
    NodeInterfaceMappings?: NodeInterfaceMapping[];
    Role?: NodeRole;
    State?: NodeState;
    SdiSourceMappings?: SdiSourceMapping[];
}
export type __listOfDescribeNodeSummary = DescribeNodeSummary[];
export interface ListNodesResponse {
    NextToken?: string;
    Nodes?: DescribeNodeSummary[];
}
export interface ListOfferingsRequest {
    ChannelClass?: string;
    ChannelConfiguration?: string;
    Codec?: string;
    Duration?: string;
    MaxResults?: number;
    MaximumBitrate?: string;
    MaximumFramerate?: string;
    NextToken?: string;
    Resolution?: string;
    ResourceType?: string;
    SpecialFeature?: string;
    VideoQuality?: string;
}
export interface Offering {
    Arn?: string;
    CurrencyCode?: string;
    Duration?: number;
    DurationUnits?: OfferingDurationUnits;
    FixedPrice?: number;
    OfferingDescription?: string;
    OfferingId?: string;
    OfferingType?: OfferingType;
    Region?: string;
    ResourceSpecification?: ReservationResourceSpecification;
    UsagePrice?: number;
}
export type __listOfOffering = Offering[];
export interface ListOfferingsResponse {
    NextToken?: string;
    Offerings?: Offering[];
}
export interface ListReservationsRequest {
    ChannelClass?: string;
    Codec?: string;
    MaxResults?: number;
    MaximumBitrate?: string;
    MaximumFramerate?: string;
    NextToken?: string;
    Resolution?: string;
    ResourceType?: string;
    SpecialFeature?: string;
    VideoQuality?: string;
}
export interface Reservation {
    Arn?: string;
    Count?: number;
    CurrencyCode?: string;
    Duration?: number;
    DurationUnits?: OfferingDurationUnits;
    End?: string;
    FixedPrice?: number;
    Name?: string;
    OfferingDescription?: string;
    OfferingId?: string;
    OfferingType?: OfferingType;
    Region?: string;
    RenewalSettings?: RenewalSettings;
    ReservationId?: string;
    ResourceSpecification?: ReservationResourceSpecification;
    Start?: string;
    State?: ReservationState;
    Tags?: {
        [key: string]: string | undefined;
    };
    UsagePrice?: number;
}
export type __listOfReservation = Reservation[];
export interface ListReservationsResponse {
    NextToken?: string;
    Reservations?: Reservation[];
}
export interface ListSdiSourcesRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface SdiSourceSummary {
    Arn?: string;
    Id?: string;
    Inputs?: string[];
    Mode?: SdiSourceMode;
    Name?: string;
    State?: SdiSourceState;
    Type?: SdiSourceType;
}
export type __listOfSdiSourceSummary = SdiSourceSummary[];
export interface ListSdiSourcesResponse {
    NextToken?: string;
    SdiSources?: SdiSourceSummary[];
}
export interface ListSignalMapsRequest {
    CloudWatchAlarmTemplateGroupIdentifier?: string;
    EventBridgeRuleTemplateGroupIdentifier?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface SignalMapSummary {
    Arn?: string;
    CreatedAt?: Date;
    Description?: string;
    Id?: string;
    ModifiedAt?: Date;
    MonitorDeploymentStatus?: SignalMapMonitorDeploymentStatus;
    Name?: string;
    Status?: SignalMapStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfSignalMapSummary = SignalMapSummary[];
export interface ListSignalMapsResponse {
    NextToken?: string;
    SignalMaps?: (SignalMapSummary & {
        Arn: __stringPatternArnMedialiveSignalMap;
        CreatedAt: __timestampIso8601;
        Id: __stringMin7Max11PatternAws097;
        MonitorDeploymentStatus: SignalMapMonitorDeploymentStatus;
        Name: __stringMin1Max255PatternS;
        Status: SignalMapStatus;
    })[];
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListVersionsRequest {
}
export interface ListVersionsResponse {
    Versions?: ChannelEngineVersionResponse[];
}
export interface PurchaseOfferingRequest {
    Count?: number;
    Name?: string;
    OfferingId: string;
    RenewalSettings?: RenewalSettings;
    RequestId?: string;
    Start?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface PurchaseOfferingResponse {
    Reservation?: Reservation;
}
export type RebootInputDeviceForce = "NO" | "YES" | (string & {});
export interface RebootInputDeviceRequest {
    Force?: RebootInputDeviceForce;
    InputDeviceId: string;
}
export interface RebootInputDeviceResponse {
}
export interface RejectInputDeviceTransferRequest {
    InputDeviceId: string;
}
export interface RejectInputDeviceTransferResponse {
}
export type ChannelPipelineIdToRestart = "PIPELINE_0" | "PIPELINE_1" | (string & {});
export type __listOfChannelPipelineIdToRestart = ChannelPipelineIdToRestart[];
export interface RestartChannelPipelinesRequest {
    ChannelId: string;
    PipelineIds?: ChannelPipelineIdToRestart[];
}
export interface RestartChannelPipelinesResponse {
    Arn?: string;
    CdiInputSpecification?: CdiInputSpecification;
    ChannelClass?: ChannelClass;
    Destinations?: OutputDestination[];
    EgressEndpoints?: ChannelEgressEndpoint[];
    EncoderSettings?: EncoderSettings & {
        AudioDescriptions: (AudioDescription & {
            AudioSelectorName: string;
            Name: __stringMax255;
            AudioWatermarkingSettings: AudioWatermarkSettings & {
                NielsenWatermarksSettings: NielsenWatermarksSettings & {
                    NielsenCbetSettings: NielsenCBET & {
                        CbetCheckDigitString: __stringMin2Max2;
                        CbetStepaside: NielsenWatermarksCbetStepaside;
                        Csid: __stringMin1Max7;
                    };
                    NielsenNaesIiNwSettings: NielsenNaesIiNw & {
                        CheckDigitString: __stringMin2Max2;
                        Sid: __doubleMin1Max65535;
                    };
                    NielsenNwOnlySettings: NielsenNwOnly & {
                        CheckDigitString: __stringMin2Max2;
                        Sid: __doubleMin1Max65535;
                    };
                };
            };
            RemixSettings: RemixSettings & {
                ChannelMappings: (AudioChannelMapping & {
                    InputChannelLevels: (InputChannelLevel & {
                        Gain: __integerMinNegative60Max6;
                        InputChannel: __integerMin0Max15;
                    })[];
                    OutputChannel: __integerMin0Max7;
                })[];
            };
        })[];
        OutputGroups: (OutputGroup & {
            OutputGroupSettings: OutputGroupSettings & {
                ArchiveGroupSettings: ArchiveGroupSettings & {
                    Destination: OutputLocationRef;
                };
                FrameCaptureGroupSettings: FrameCaptureGroupSettings & {
                    Destination: OutputLocationRef;
                };
                HlsGroupSettings: HlsGroupSettings & {
                    Destination: OutputLocationRef;
                    CaptionLanguageMappings: (CaptionLanguageMapping & {
                        CaptionChannel: __integerMin1Max4;
                        LanguageCode: __stringMin3Max3;
                        LanguageDescription: __stringMin1;
                    })[];
                    KeyProviderSettings: KeyProviderSettings & {
                        StaticKeySettings: StaticKeySettings & {
                            StaticKeyValue: __stringMin32Max32;
                            KeyProviderServer: InputLocation & {
                                Uri: __stringMax2048;
                            };
                        };
                    };
                };
                MediaPackageGroupSettings: MediaPackageGroupSettings & {
                    Destination: OutputLocationRef;
                    MediapackageV2GroupSettings: MediaPackageV2GroupSettings & {
                        CaptionLanguageMappings: (CaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                            LanguageDescription: __stringMin1;
                        })[];
                        AdditionalDestinations: (MediaPackageAdditionalDestinations & {
                            Destination: OutputLocationRef;
                        })[];
                        WatermarkingSettings: MediaPackageV2WatermarkingSettings & {
                            MediaPackageV2AbWatermarkerIrdetoSettings: MediaPackageV2AbWatermarkerIrdetoSettings & {
                                AlternateDestination: OutputLocationRef;
                                OperatorId: __integerMin1Max511;
                                Profile: AbWatermarkingProfile;
                                CustomProfile: AbWatermarkingCustomProfile & {
                                    EmbeddingFrequency: __doubleMin250Max5000;
                                    SceneCut: __doubleMinNegative1Max5;
                                    TargetPsnr: __doubleMin32Max46;
                                };
                            };
                        };
                    };
                };
                MsSmoothGroupSettings: MsSmoothGroupSettings & {
                    Destination: OutputLocationRef;
                };
                CmafIngestGroupSettings: CmafIngestGroupSettings & {
                    Destination: OutputLocationRef;
                    CaptionLanguageMappings: (CmafIngestCaptionLanguageMapping & {
                        CaptionChannel: __integerMin1Max4;
                        LanguageCode: __stringMin3Max3;
                    })[];
                    AdditionalDestinations: (AdditionalDestinations & {
                        Destination: OutputLocationRef;
                    })[];
                    WatermarkingSettings: CmafIngestWatermarkingSettings & {
                        CmafIngestAbWatermarkerIrdetoSettings: CmafIngestAbWatermarkerIrdetoSettings & {
                            AlternateDestination: OutputLocationRef;
                            OperatorId: __integerMin1Max511;
                            Profile: AbWatermarkingProfile;
                            CustomProfile: AbWatermarkingCustomProfile & {
                                EmbeddingFrequency: __doubleMin250Max5000;
                                SceneCut: __doubleMinNegative1Max5;
                                TargetPsnr: __doubleMin32Max46;
                            };
                        };
                    };
                };
            };
            Outputs: (Output & {
                OutputSettings: OutputSettings & {
                    ArchiveOutputSettings: ArchiveOutputSettings & {
                        ContainerSettings: ArchiveContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                    };
                    HlsOutputSettings: HlsOutputSettings & {
                        HlsSettings: HlsSettings & {
                            AudioOnlyHlsSettings: AudioOnlyHlsSettings & {
                                AudioOnlyImage: InputLocation & {
                                    Uri: __stringMax2048;
                                };
                            };
                            StandardHlsSettings: StandardHlsSettings & {
                                M3u8Settings: M3u8Settings;
                            };
                        };
                    };
                    MultiplexOutputSettings: MultiplexOutputSettings & {
                        Destination: OutputLocationRef;
                    };
                    RtmpOutputSettings: RtmpOutputSettings & {
                        Destination: OutputLocationRef;
                    };
                    UdpOutputSettings: UdpOutputSettings & {
                        ContainerSettings: UdpContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                    SrtOutputSettings: SrtOutputSettings & {
                        ContainerSettings: UdpContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                    MediaConnectRouterOutputSettings: MediaConnectRouterOutputSettings & {
                        ContainerSettings: MediaConnectRouterContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                };
            })[];
        })[];
        TimecodeConfig: TimecodeConfig & {
            Source: TimecodeConfigSource;
        };
        VideoDescriptions: (VideoDescription & {
            Name: string;
            CodecSettings: VideoCodecSettings & {
                FrameCaptureSettings: FrameCaptureSettings & {
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                H264Settings: H264Settings & {
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                H265Settings: H265Settings & {
                    FramerateDenominator: __integerMin1Max3003;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                Mpeg2Settings: Mpeg2Settings & {
                    FramerateDenominator: __integerMin1;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                Av1Settings: Av1Settings & {
                    FramerateDenominator: __integerMin1Max3003;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
            };
            CropRectangle: VideoPositionRectangle & {
                Height: __integerMin2Max8192;
                Width: __integerMin2Max8192;
                X: __integerMin0Max8190;
                Y: __integerMin0Max8190;
            };
            OutputPositionRectangle: VideoPositionRectangle & {
                Height: __integerMin2Max8192;
                Width: __integerMin2Max8192;
                X: __integerMin0Max8190;
                Y: __integerMin0Max8190;
            };
        })[];
        AvailBlanking: AvailBlanking & {
            AvailBlankingImage: InputLocation & {
                Uri: __stringMax2048;
            };
        };
        AvailConfiguration: AvailConfiguration & {
            AvailSettings: AvailSettings & {
                Esam: Esam & {
                    AcquisitionPointId: __stringMax256;
                    PoisEndpoint: __stringMax2048;
                };
            };
        };
        BlackoutSlate: BlackoutSlate & {
            BlackoutSlateImage: InputLocation & {
                Uri: __stringMax2048;
            };
            NetworkEndBlackoutImage: InputLocation & {
                Uri: __stringMax2048;
            };
        };
        CaptionDescriptions: (CaptionDescription & {
            CaptionSelectorName: string;
            Name: string;
            DestinationSettings: CaptionDestinationSettings & {
                BurnInDestinationSettings: BurnInDestinationSettings & {
                    Font: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
                DvbSubDestinationSettings: DvbSubDestinationSettings & {
                    Font: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
            };
        })[];
        GlobalConfiguration: GlobalConfiguration & {
            InputLossBehavior: InputLossBehavior & {
                InputLossImageSlate: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
        };
        MotionGraphicsConfiguration: MotionGraphicsConfiguration & {
            MotionGraphicsSettings: MotionGraphicsSettings;
        };
        ThumbnailConfiguration: ThumbnailConfiguration & {
            State: ThumbnailState;
        };
        ColorCorrectionSettings: ColorCorrectionSettings & {
            GlobalColorCorrections: (ColorCorrection & {
                InputColorSpace: ColorSpace;
                OutputColorSpace: ColorSpace;
                Uri: string;
            })[];
        };
    };
    Id?: string;
    InputAttachments?: (InputAttachment & {
        AutomaticInputFailoverSettings: AutomaticInputFailoverSettings & {
            SecondaryInputId: string;
            FailoverConditions: (FailoverCondition & {
                FailoverConditionSettings: FailoverConditionSettings & {
                    AudioSilenceSettings: AudioSilenceFailoverSettings & {
                        AudioSelectorName: string;
                    };
                };
            })[];
        };
        InputSettings: InputSettings & {
            AudioSelectors: (AudioSelector & {
                Name: __stringMin1;
                SelectorSettings: AudioSelectorSettings & {
                    AudioHlsRenditionSelection: AudioHlsRenditionSelection & {
                        GroupId: __stringMin1;
                        Name: __stringMin1;
                    };
                    AudioLanguageSelection: AudioLanguageSelection & {
                        LanguageCode: string;
                    };
                    AudioPidSelection: AudioPidSelection & {
                        Pid: __integerMin0Max8191;
                        Pids: (AudioPid & {
                            Pid: __integerMin0Max8191;
                            DolbyEDecode: AudioDolbyEDecode & {
                                ProgramSelection: DolbyEProgramSelection;
                            };
                            PremixSettings: AudioPreMixerSettings & {
                                RemixSettings: RemixSettings & {
                                    ChannelMappings: (AudioChannelMapping & {
                                        InputChannelLevels: (InputChannelLevel & {
                                            Gain: __integerMinNegative60Max6;
                                            InputChannel: __integerMin0Max15;
                                        })[];
                                        OutputChannel: __integerMin0Max7;
                                    })[];
                                };
                            };
                        })[];
                    };
                    AudioTrackSelection: AudioTrackSelection & {
                        Tracks: (AudioTrack & {
                            Track: __integerMin1;
                            PremixSettings: AudioPreMixerSettings & {
                                RemixSettings: RemixSettings & {
                                    ChannelMappings: (AudioChannelMapping & {
                                        InputChannelLevels: (InputChannelLevel & {
                                            Gain: __integerMinNegative60Max6;
                                            InputChannel: __integerMin0Max15;
                                        })[];
                                        OutputChannel: __integerMin0Max7;
                                    })[];
                                };
                            };
                        })[];
                        DolbyEDecode: AudioDolbyEDecode & {
                            ProgramSelection: DolbyEProgramSelection;
                        };
                    };
                };
            })[];
            CaptionSelectors: (CaptionSelector & {
                Name: __stringMin1;
                SelectorSettings: CaptionSelectorSettings & {
                    TeletextSourceSettings: TeletextSourceSettings & {
                        OutputRectangle: CaptionRectangle & {
                            Height: __doubleMin0Max100;
                            LeftOffset: __doubleMin0Max100;
                            TopOffset: __doubleMin0Max100;
                            Width: __doubleMin0Max100;
                        };
                    };
                };
            })[];
        };
    })[];
    InputSpecification?: InputSpecification;
    LogLevel?: LogLevel;
    Maintenance?: MaintenanceStatus;
    MaintenanceStatus?: string;
    Name?: string;
    PipelineDetails?: PipelineDetail[];
    PipelinesRunningCount?: number;
    RoleArn?: string;
    State?: ChannelState;
    Tags?: {
        [key: string]: string | undefined;
    };
    Vpc?: VpcOutputSettingsDescription;
    AnywhereSettings?: DescribeAnywhereSettings;
    ChannelEngineVersion?: ChannelEngineVersionResponse;
    LinkedChannelSettings?: DescribeLinkedChannelSettings;
    ChannelSecurityGroups?: string[];
    InferenceSettings?: DescribeInferenceSettings;
}
export interface StartChannelRequest {
    ChannelId: string;
}
export interface StartChannelResponse {
    Arn?: string;
    CdiInputSpecification?: CdiInputSpecification;
    ChannelClass?: ChannelClass;
    Destinations?: OutputDestination[];
    EgressEndpoints?: ChannelEgressEndpoint[];
    EncoderSettings?: EncoderSettings & {
        AudioDescriptions: (AudioDescription & {
            AudioSelectorName: string;
            Name: __stringMax255;
            AudioWatermarkingSettings: AudioWatermarkSettings & {
                NielsenWatermarksSettings: NielsenWatermarksSettings & {
                    NielsenCbetSettings: NielsenCBET & {
                        CbetCheckDigitString: __stringMin2Max2;
                        CbetStepaside: NielsenWatermarksCbetStepaside;
                        Csid: __stringMin1Max7;
                    };
                    NielsenNaesIiNwSettings: NielsenNaesIiNw & {
                        CheckDigitString: __stringMin2Max2;
                        Sid: __doubleMin1Max65535;
                    };
                    NielsenNwOnlySettings: NielsenNwOnly & {
                        CheckDigitString: __stringMin2Max2;
                        Sid: __doubleMin1Max65535;
                    };
                };
            };
            RemixSettings: RemixSettings & {
                ChannelMappings: (AudioChannelMapping & {
                    InputChannelLevels: (InputChannelLevel & {
                        Gain: __integerMinNegative60Max6;
                        InputChannel: __integerMin0Max15;
                    })[];
                    OutputChannel: __integerMin0Max7;
                })[];
            };
        })[];
        OutputGroups: (OutputGroup & {
            OutputGroupSettings: OutputGroupSettings & {
                ArchiveGroupSettings: ArchiveGroupSettings & {
                    Destination: OutputLocationRef;
                };
                FrameCaptureGroupSettings: FrameCaptureGroupSettings & {
                    Destination: OutputLocationRef;
                };
                HlsGroupSettings: HlsGroupSettings & {
                    Destination: OutputLocationRef;
                    CaptionLanguageMappings: (CaptionLanguageMapping & {
                        CaptionChannel: __integerMin1Max4;
                        LanguageCode: __stringMin3Max3;
                        LanguageDescription: __stringMin1;
                    })[];
                    KeyProviderSettings: KeyProviderSettings & {
                        StaticKeySettings: StaticKeySettings & {
                            StaticKeyValue: __stringMin32Max32;
                            KeyProviderServer: InputLocation & {
                                Uri: __stringMax2048;
                            };
                        };
                    };
                };
                MediaPackageGroupSettings: MediaPackageGroupSettings & {
                    Destination: OutputLocationRef;
                    MediapackageV2GroupSettings: MediaPackageV2GroupSettings & {
                        CaptionLanguageMappings: (CaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                            LanguageDescription: __stringMin1;
                        })[];
                        AdditionalDestinations: (MediaPackageAdditionalDestinations & {
                            Destination: OutputLocationRef;
                        })[];
                        WatermarkingSettings: MediaPackageV2WatermarkingSettings & {
                            MediaPackageV2AbWatermarkerIrdetoSettings: MediaPackageV2AbWatermarkerIrdetoSettings & {
                                AlternateDestination: OutputLocationRef;
                                OperatorId: __integerMin1Max511;
                                Profile: AbWatermarkingProfile;
                                CustomProfile: AbWatermarkingCustomProfile & {
                                    EmbeddingFrequency: __doubleMin250Max5000;
                                    SceneCut: __doubleMinNegative1Max5;
                                    TargetPsnr: __doubleMin32Max46;
                                };
                            };
                        };
                    };
                };
                MsSmoothGroupSettings: MsSmoothGroupSettings & {
                    Destination: OutputLocationRef;
                };
                CmafIngestGroupSettings: CmafIngestGroupSettings & {
                    Destination: OutputLocationRef;
                    CaptionLanguageMappings: (CmafIngestCaptionLanguageMapping & {
                        CaptionChannel: __integerMin1Max4;
                        LanguageCode: __stringMin3Max3;
                    })[];
                    AdditionalDestinations: (AdditionalDestinations & {
                        Destination: OutputLocationRef;
                    })[];
                    WatermarkingSettings: CmafIngestWatermarkingSettings & {
                        CmafIngestAbWatermarkerIrdetoSettings: CmafIngestAbWatermarkerIrdetoSettings & {
                            AlternateDestination: OutputLocationRef;
                            OperatorId: __integerMin1Max511;
                            Profile: AbWatermarkingProfile;
                            CustomProfile: AbWatermarkingCustomProfile & {
                                EmbeddingFrequency: __doubleMin250Max5000;
                                SceneCut: __doubleMinNegative1Max5;
                                TargetPsnr: __doubleMin32Max46;
                            };
                        };
                    };
                };
            };
            Outputs: (Output & {
                OutputSettings: OutputSettings & {
                    ArchiveOutputSettings: ArchiveOutputSettings & {
                        ContainerSettings: ArchiveContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                    };
                    HlsOutputSettings: HlsOutputSettings & {
                        HlsSettings: HlsSettings & {
                            AudioOnlyHlsSettings: AudioOnlyHlsSettings & {
                                AudioOnlyImage: InputLocation & {
                                    Uri: __stringMax2048;
                                };
                            };
                            StandardHlsSettings: StandardHlsSettings & {
                                M3u8Settings: M3u8Settings;
                            };
                        };
                    };
                    MultiplexOutputSettings: MultiplexOutputSettings & {
                        Destination: OutputLocationRef;
                    };
                    RtmpOutputSettings: RtmpOutputSettings & {
                        Destination: OutputLocationRef;
                    };
                    UdpOutputSettings: UdpOutputSettings & {
                        ContainerSettings: UdpContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                    SrtOutputSettings: SrtOutputSettings & {
                        ContainerSettings: UdpContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                    MediaConnectRouterOutputSettings: MediaConnectRouterOutputSettings & {
                        ContainerSettings: MediaConnectRouterContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                };
            })[];
        })[];
        TimecodeConfig: TimecodeConfig & {
            Source: TimecodeConfigSource;
        };
        VideoDescriptions: (VideoDescription & {
            Name: string;
            CodecSettings: VideoCodecSettings & {
                FrameCaptureSettings: FrameCaptureSettings & {
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                H264Settings: H264Settings & {
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                H265Settings: H265Settings & {
                    FramerateDenominator: __integerMin1Max3003;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                Mpeg2Settings: Mpeg2Settings & {
                    FramerateDenominator: __integerMin1;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                Av1Settings: Av1Settings & {
                    FramerateDenominator: __integerMin1Max3003;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
            };
            CropRectangle: VideoPositionRectangle & {
                Height: __integerMin2Max8192;
                Width: __integerMin2Max8192;
                X: __integerMin0Max8190;
                Y: __integerMin0Max8190;
            };
            OutputPositionRectangle: VideoPositionRectangle & {
                Height: __integerMin2Max8192;
                Width: __integerMin2Max8192;
                X: __integerMin0Max8190;
                Y: __integerMin0Max8190;
            };
        })[];
        AvailBlanking: AvailBlanking & {
            AvailBlankingImage: InputLocation & {
                Uri: __stringMax2048;
            };
        };
        AvailConfiguration: AvailConfiguration & {
            AvailSettings: AvailSettings & {
                Esam: Esam & {
                    AcquisitionPointId: __stringMax256;
                    PoisEndpoint: __stringMax2048;
                };
            };
        };
        BlackoutSlate: BlackoutSlate & {
            BlackoutSlateImage: InputLocation & {
                Uri: __stringMax2048;
            };
            NetworkEndBlackoutImage: InputLocation & {
                Uri: __stringMax2048;
            };
        };
        CaptionDescriptions: (CaptionDescription & {
            CaptionSelectorName: string;
            Name: string;
            DestinationSettings: CaptionDestinationSettings & {
                BurnInDestinationSettings: BurnInDestinationSettings & {
                    Font: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
                DvbSubDestinationSettings: DvbSubDestinationSettings & {
                    Font: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
            };
        })[];
        GlobalConfiguration: GlobalConfiguration & {
            InputLossBehavior: InputLossBehavior & {
                InputLossImageSlate: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
        };
        MotionGraphicsConfiguration: MotionGraphicsConfiguration & {
            MotionGraphicsSettings: MotionGraphicsSettings;
        };
        ThumbnailConfiguration: ThumbnailConfiguration & {
            State: ThumbnailState;
        };
        ColorCorrectionSettings: ColorCorrectionSettings & {
            GlobalColorCorrections: (ColorCorrection & {
                InputColorSpace: ColorSpace;
                OutputColorSpace: ColorSpace;
                Uri: string;
            })[];
        };
    };
    Id?: string;
    InputAttachments?: (InputAttachment & {
        AutomaticInputFailoverSettings: AutomaticInputFailoverSettings & {
            SecondaryInputId: string;
            FailoverConditions: (FailoverCondition & {
                FailoverConditionSettings: FailoverConditionSettings & {
                    AudioSilenceSettings: AudioSilenceFailoverSettings & {
                        AudioSelectorName: string;
                    };
                };
            })[];
        };
        InputSettings: InputSettings & {
            AudioSelectors: (AudioSelector & {
                Name: __stringMin1;
                SelectorSettings: AudioSelectorSettings & {
                    AudioHlsRenditionSelection: AudioHlsRenditionSelection & {
                        GroupId: __stringMin1;
                        Name: __stringMin1;
                    };
                    AudioLanguageSelection: AudioLanguageSelection & {
                        LanguageCode: string;
                    };
                    AudioPidSelection: AudioPidSelection & {
                        Pid: __integerMin0Max8191;
                        Pids: (AudioPid & {
                            Pid: __integerMin0Max8191;
                            DolbyEDecode: AudioDolbyEDecode & {
                                ProgramSelection: DolbyEProgramSelection;
                            };
                            PremixSettings: AudioPreMixerSettings & {
                                RemixSettings: RemixSettings & {
                                    ChannelMappings: (AudioChannelMapping & {
                                        InputChannelLevels: (InputChannelLevel & {
                                            Gain: __integerMinNegative60Max6;
                                            InputChannel: __integerMin0Max15;
                                        })[];
                                        OutputChannel: __integerMin0Max7;
                                    })[];
                                };
                            };
                        })[];
                    };
                    AudioTrackSelection: AudioTrackSelection & {
                        Tracks: (AudioTrack & {
                            Track: __integerMin1;
                            PremixSettings: AudioPreMixerSettings & {
                                RemixSettings: RemixSettings & {
                                    ChannelMappings: (AudioChannelMapping & {
                                        InputChannelLevels: (InputChannelLevel & {
                                            Gain: __integerMinNegative60Max6;
                                            InputChannel: __integerMin0Max15;
                                        })[];
                                        OutputChannel: __integerMin0Max7;
                                    })[];
                                };
                            };
                        })[];
                        DolbyEDecode: AudioDolbyEDecode & {
                            ProgramSelection: DolbyEProgramSelection;
                        };
                    };
                };
            })[];
            CaptionSelectors: (CaptionSelector & {
                Name: __stringMin1;
                SelectorSettings: CaptionSelectorSettings & {
                    TeletextSourceSettings: TeletextSourceSettings & {
                        OutputRectangle: CaptionRectangle & {
                            Height: __doubleMin0Max100;
                            LeftOffset: __doubleMin0Max100;
                            TopOffset: __doubleMin0Max100;
                            Width: __doubleMin0Max100;
                        };
                    };
                };
            })[];
        };
    })[];
    InputSpecification?: InputSpecification;
    LogLevel?: LogLevel;
    Maintenance?: MaintenanceStatus;
    Name?: string;
    PipelineDetails?: PipelineDetail[];
    PipelinesRunningCount?: number;
    RoleArn?: string;
    State?: ChannelState;
    Tags?: {
        [key: string]: string | undefined;
    };
    Vpc?: VpcOutputSettingsDescription;
    AnywhereSettings?: DescribeAnywhereSettings;
    ChannelEngineVersion?: ChannelEngineVersionResponse;
    LinkedChannelSettings?: DescribeLinkedChannelSettings;
    ChannelSecurityGroups?: string[];
    InferenceSettings?: DescribeInferenceSettings;
}
export interface StartDeleteMonitorDeploymentRequest {
    Identifier: string;
}
export interface StartDeleteMonitorDeploymentResponse {
    Arn?: string;
    CloudWatchAlarmTemplateGroupIds?: string[];
    CreatedAt?: Date;
    Description?: string;
    DiscoveryEntryPointArn?: string;
    ErrorMessage?: string;
    EventBridgeRuleTemplateGroupIds?: string[];
    FailedMediaResourceMap?: {
        [key: string]: (MediaResource & {
            Destinations: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
            Sources: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
        }) | undefined;
    };
    Id?: string;
    LastDiscoveredAt?: Date;
    LastSuccessfulMonitorDeployment?: SuccessfulMonitorDeployment & {
        DetailsUri: __stringMin1Max2048;
        Status: SignalMapMonitorDeploymentStatus;
    };
    MediaResourceMap?: {
        [key: string]: (MediaResource & {
            Destinations: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
            Sources: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
        }) | undefined;
    };
    ModifiedAt?: Date;
    MonitorChangesPendingDeployment?: boolean;
    MonitorDeployment?: MonitorDeployment & {
        Status: SignalMapMonitorDeploymentStatus;
    };
    Name?: string;
    Status?: SignalMapStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface StartInputDeviceRequest {
    InputDeviceId: string;
}
export interface StartInputDeviceResponse {
}
export interface StartInputDeviceMaintenanceWindowRequest {
    InputDeviceId: string;
}
export interface StartInputDeviceMaintenanceWindowResponse {
}
export interface StartMonitorDeploymentRequest {
    DryRun?: boolean;
    Identifier: string;
}
export interface StartMonitorDeploymentResponse {
    Arn?: string;
    CloudWatchAlarmTemplateGroupIds?: string[];
    CreatedAt?: Date;
    Description?: string;
    DiscoveryEntryPointArn?: string;
    ErrorMessage?: string;
    EventBridgeRuleTemplateGroupIds?: string[];
    FailedMediaResourceMap?: {
        [key: string]: (MediaResource & {
            Destinations: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
            Sources: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
        }) | undefined;
    };
    Id?: string;
    LastDiscoveredAt?: Date;
    LastSuccessfulMonitorDeployment?: SuccessfulMonitorDeployment & {
        DetailsUri: __stringMin1Max2048;
        Status: SignalMapMonitorDeploymentStatus;
    };
    MediaResourceMap?: {
        [key: string]: (MediaResource & {
            Destinations: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
            Sources: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
        }) | undefined;
    };
    ModifiedAt?: Date;
    MonitorChangesPendingDeployment?: boolean;
    MonitorDeployment?: MonitorDeployment & {
        Status: SignalMapMonitorDeploymentStatus;
    };
    Name?: string;
    Status?: SignalMapStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface StartMultiplexRequest {
    MultiplexId: string;
}
export interface StartMultiplexResponse {
    Arn?: string;
    AvailabilityZones?: string[];
    Destinations?: MultiplexOutputDestination[];
    Id?: string;
    MultiplexSettings?: MultiplexSettings & {
        TransportStreamBitrate: __integerMin1000000Max100000000;
        TransportStreamId: __integerMin0Max65535;
    };
    Name?: string;
    PipelinesRunningCount?: number;
    ProgramCount?: number;
    State?: MultiplexState;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface StartUpdateSignalMapRequest {
    CloudWatchAlarmTemplateGroupIdentifiers?: string[];
    Description?: string;
    DiscoveryEntryPointArn?: string;
    EventBridgeRuleTemplateGroupIdentifiers?: string[];
    ForceRediscovery?: boolean;
    Identifier: string;
    Name?: string;
}
export interface StartUpdateSignalMapResponse {
    Arn?: string;
    CloudWatchAlarmTemplateGroupIds?: string[];
    CreatedAt?: Date;
    Description?: string;
    DiscoveryEntryPointArn?: string;
    ErrorMessage?: string;
    EventBridgeRuleTemplateGroupIds?: string[];
    FailedMediaResourceMap?: {
        [key: string]: (MediaResource & {
            Destinations: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
            Sources: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
        }) | undefined;
    };
    Id?: string;
    LastDiscoveredAt?: Date;
    LastSuccessfulMonitorDeployment?: SuccessfulMonitorDeployment & {
        DetailsUri: __stringMin1Max2048;
        Status: SignalMapMonitorDeploymentStatus;
    };
    MediaResourceMap?: {
        [key: string]: (MediaResource & {
            Destinations: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
            Sources: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
        }) | undefined;
    };
    ModifiedAt?: Date;
    MonitorChangesPendingDeployment?: boolean;
    MonitorDeployment?: MonitorDeployment & {
        Status: SignalMapMonitorDeploymentStatus;
    };
    Name?: string;
    Status?: SignalMapStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface StopChannelRequest {
    ChannelId: string;
}
export interface StopChannelResponse {
    Arn?: string;
    CdiInputSpecification?: CdiInputSpecification;
    ChannelClass?: ChannelClass;
    Destinations?: OutputDestination[];
    EgressEndpoints?: ChannelEgressEndpoint[];
    EncoderSettings?: EncoderSettings & {
        AudioDescriptions: (AudioDescription & {
            AudioSelectorName: string;
            Name: __stringMax255;
            AudioWatermarkingSettings: AudioWatermarkSettings & {
                NielsenWatermarksSettings: NielsenWatermarksSettings & {
                    NielsenCbetSettings: NielsenCBET & {
                        CbetCheckDigitString: __stringMin2Max2;
                        CbetStepaside: NielsenWatermarksCbetStepaside;
                        Csid: __stringMin1Max7;
                    };
                    NielsenNaesIiNwSettings: NielsenNaesIiNw & {
                        CheckDigitString: __stringMin2Max2;
                        Sid: __doubleMin1Max65535;
                    };
                    NielsenNwOnlySettings: NielsenNwOnly & {
                        CheckDigitString: __stringMin2Max2;
                        Sid: __doubleMin1Max65535;
                    };
                };
            };
            RemixSettings: RemixSettings & {
                ChannelMappings: (AudioChannelMapping & {
                    InputChannelLevels: (InputChannelLevel & {
                        Gain: __integerMinNegative60Max6;
                        InputChannel: __integerMin0Max15;
                    })[];
                    OutputChannel: __integerMin0Max7;
                })[];
            };
        })[];
        OutputGroups: (OutputGroup & {
            OutputGroupSettings: OutputGroupSettings & {
                ArchiveGroupSettings: ArchiveGroupSettings & {
                    Destination: OutputLocationRef;
                };
                FrameCaptureGroupSettings: FrameCaptureGroupSettings & {
                    Destination: OutputLocationRef;
                };
                HlsGroupSettings: HlsGroupSettings & {
                    Destination: OutputLocationRef;
                    CaptionLanguageMappings: (CaptionLanguageMapping & {
                        CaptionChannel: __integerMin1Max4;
                        LanguageCode: __stringMin3Max3;
                        LanguageDescription: __stringMin1;
                    })[];
                    KeyProviderSettings: KeyProviderSettings & {
                        StaticKeySettings: StaticKeySettings & {
                            StaticKeyValue: __stringMin32Max32;
                            KeyProviderServer: InputLocation & {
                                Uri: __stringMax2048;
                            };
                        };
                    };
                };
                MediaPackageGroupSettings: MediaPackageGroupSettings & {
                    Destination: OutputLocationRef;
                    MediapackageV2GroupSettings: MediaPackageV2GroupSettings & {
                        CaptionLanguageMappings: (CaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                            LanguageDescription: __stringMin1;
                        })[];
                        AdditionalDestinations: (MediaPackageAdditionalDestinations & {
                            Destination: OutputLocationRef;
                        })[];
                        WatermarkingSettings: MediaPackageV2WatermarkingSettings & {
                            MediaPackageV2AbWatermarkerIrdetoSettings: MediaPackageV2AbWatermarkerIrdetoSettings & {
                                AlternateDestination: OutputLocationRef;
                                OperatorId: __integerMin1Max511;
                                Profile: AbWatermarkingProfile;
                                CustomProfile: AbWatermarkingCustomProfile & {
                                    EmbeddingFrequency: __doubleMin250Max5000;
                                    SceneCut: __doubleMinNegative1Max5;
                                    TargetPsnr: __doubleMin32Max46;
                                };
                            };
                        };
                    };
                };
                MsSmoothGroupSettings: MsSmoothGroupSettings & {
                    Destination: OutputLocationRef;
                };
                CmafIngestGroupSettings: CmafIngestGroupSettings & {
                    Destination: OutputLocationRef;
                    CaptionLanguageMappings: (CmafIngestCaptionLanguageMapping & {
                        CaptionChannel: __integerMin1Max4;
                        LanguageCode: __stringMin3Max3;
                    })[];
                    AdditionalDestinations: (AdditionalDestinations & {
                        Destination: OutputLocationRef;
                    })[];
                    WatermarkingSettings: CmafIngestWatermarkingSettings & {
                        CmafIngestAbWatermarkerIrdetoSettings: CmafIngestAbWatermarkerIrdetoSettings & {
                            AlternateDestination: OutputLocationRef;
                            OperatorId: __integerMin1Max511;
                            Profile: AbWatermarkingProfile;
                            CustomProfile: AbWatermarkingCustomProfile & {
                                EmbeddingFrequency: __doubleMin250Max5000;
                                SceneCut: __doubleMinNegative1Max5;
                                TargetPsnr: __doubleMin32Max46;
                            };
                        };
                    };
                };
            };
            Outputs: (Output & {
                OutputSettings: OutputSettings & {
                    ArchiveOutputSettings: ArchiveOutputSettings & {
                        ContainerSettings: ArchiveContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                    };
                    HlsOutputSettings: HlsOutputSettings & {
                        HlsSettings: HlsSettings & {
                            AudioOnlyHlsSettings: AudioOnlyHlsSettings & {
                                AudioOnlyImage: InputLocation & {
                                    Uri: __stringMax2048;
                                };
                            };
                            StandardHlsSettings: StandardHlsSettings & {
                                M3u8Settings: M3u8Settings;
                            };
                        };
                    };
                    MultiplexOutputSettings: MultiplexOutputSettings & {
                        Destination: OutputLocationRef;
                    };
                    RtmpOutputSettings: RtmpOutputSettings & {
                        Destination: OutputLocationRef;
                    };
                    UdpOutputSettings: UdpOutputSettings & {
                        ContainerSettings: UdpContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                    SrtOutputSettings: SrtOutputSettings & {
                        ContainerSettings: UdpContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                    MediaConnectRouterOutputSettings: MediaConnectRouterOutputSettings & {
                        ContainerSettings: MediaConnectRouterContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                };
            })[];
        })[];
        TimecodeConfig: TimecodeConfig & {
            Source: TimecodeConfigSource;
        };
        VideoDescriptions: (VideoDescription & {
            Name: string;
            CodecSettings: VideoCodecSettings & {
                FrameCaptureSettings: FrameCaptureSettings & {
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                H264Settings: H264Settings & {
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                H265Settings: H265Settings & {
                    FramerateDenominator: __integerMin1Max3003;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                Mpeg2Settings: Mpeg2Settings & {
                    FramerateDenominator: __integerMin1;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                Av1Settings: Av1Settings & {
                    FramerateDenominator: __integerMin1Max3003;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
            };
            CropRectangle: VideoPositionRectangle & {
                Height: __integerMin2Max8192;
                Width: __integerMin2Max8192;
                X: __integerMin0Max8190;
                Y: __integerMin0Max8190;
            };
            OutputPositionRectangle: VideoPositionRectangle & {
                Height: __integerMin2Max8192;
                Width: __integerMin2Max8192;
                X: __integerMin0Max8190;
                Y: __integerMin0Max8190;
            };
        })[];
        AvailBlanking: AvailBlanking & {
            AvailBlankingImage: InputLocation & {
                Uri: __stringMax2048;
            };
        };
        AvailConfiguration: AvailConfiguration & {
            AvailSettings: AvailSettings & {
                Esam: Esam & {
                    AcquisitionPointId: __stringMax256;
                    PoisEndpoint: __stringMax2048;
                };
            };
        };
        BlackoutSlate: BlackoutSlate & {
            BlackoutSlateImage: InputLocation & {
                Uri: __stringMax2048;
            };
            NetworkEndBlackoutImage: InputLocation & {
                Uri: __stringMax2048;
            };
        };
        CaptionDescriptions: (CaptionDescription & {
            CaptionSelectorName: string;
            Name: string;
            DestinationSettings: CaptionDestinationSettings & {
                BurnInDestinationSettings: BurnInDestinationSettings & {
                    Font: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
                DvbSubDestinationSettings: DvbSubDestinationSettings & {
                    Font: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
            };
        })[];
        GlobalConfiguration: GlobalConfiguration & {
            InputLossBehavior: InputLossBehavior & {
                InputLossImageSlate: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
        };
        MotionGraphicsConfiguration: MotionGraphicsConfiguration & {
            MotionGraphicsSettings: MotionGraphicsSettings;
        };
        ThumbnailConfiguration: ThumbnailConfiguration & {
            State: ThumbnailState;
        };
        ColorCorrectionSettings: ColorCorrectionSettings & {
            GlobalColorCorrections: (ColorCorrection & {
                InputColorSpace: ColorSpace;
                OutputColorSpace: ColorSpace;
                Uri: string;
            })[];
        };
    };
    Id?: string;
    InputAttachments?: (InputAttachment & {
        AutomaticInputFailoverSettings: AutomaticInputFailoverSettings & {
            SecondaryInputId: string;
            FailoverConditions: (FailoverCondition & {
                FailoverConditionSettings: FailoverConditionSettings & {
                    AudioSilenceSettings: AudioSilenceFailoverSettings & {
                        AudioSelectorName: string;
                    };
                };
            })[];
        };
        InputSettings: InputSettings & {
            AudioSelectors: (AudioSelector & {
                Name: __stringMin1;
                SelectorSettings: AudioSelectorSettings & {
                    AudioHlsRenditionSelection: AudioHlsRenditionSelection & {
                        GroupId: __stringMin1;
                        Name: __stringMin1;
                    };
                    AudioLanguageSelection: AudioLanguageSelection & {
                        LanguageCode: string;
                    };
                    AudioPidSelection: AudioPidSelection & {
                        Pid: __integerMin0Max8191;
                        Pids: (AudioPid & {
                            Pid: __integerMin0Max8191;
                            DolbyEDecode: AudioDolbyEDecode & {
                                ProgramSelection: DolbyEProgramSelection;
                            };
                            PremixSettings: AudioPreMixerSettings & {
                                RemixSettings: RemixSettings & {
                                    ChannelMappings: (AudioChannelMapping & {
                                        InputChannelLevels: (InputChannelLevel & {
                                            Gain: __integerMinNegative60Max6;
                                            InputChannel: __integerMin0Max15;
                                        })[];
                                        OutputChannel: __integerMin0Max7;
                                    })[];
                                };
                            };
                        })[];
                    };
                    AudioTrackSelection: AudioTrackSelection & {
                        Tracks: (AudioTrack & {
                            Track: __integerMin1;
                            PremixSettings: AudioPreMixerSettings & {
                                RemixSettings: RemixSettings & {
                                    ChannelMappings: (AudioChannelMapping & {
                                        InputChannelLevels: (InputChannelLevel & {
                                            Gain: __integerMinNegative60Max6;
                                            InputChannel: __integerMin0Max15;
                                        })[];
                                        OutputChannel: __integerMin0Max7;
                                    })[];
                                };
                            };
                        })[];
                        DolbyEDecode: AudioDolbyEDecode & {
                            ProgramSelection: DolbyEProgramSelection;
                        };
                    };
                };
            })[];
            CaptionSelectors: (CaptionSelector & {
                Name: __stringMin1;
                SelectorSettings: CaptionSelectorSettings & {
                    TeletextSourceSettings: TeletextSourceSettings & {
                        OutputRectangle: CaptionRectangle & {
                            Height: __doubleMin0Max100;
                            LeftOffset: __doubleMin0Max100;
                            TopOffset: __doubleMin0Max100;
                            Width: __doubleMin0Max100;
                        };
                    };
                };
            })[];
        };
    })[];
    InputSpecification?: InputSpecification;
    LogLevel?: LogLevel;
    Maintenance?: MaintenanceStatus;
    Name?: string;
    PipelineDetails?: PipelineDetail[];
    PipelinesRunningCount?: number;
    RoleArn?: string;
    State?: ChannelState;
    Tags?: {
        [key: string]: string | undefined;
    };
    Vpc?: VpcOutputSettingsDescription;
    AnywhereSettings?: DescribeAnywhereSettings;
    ChannelEngineVersion?: ChannelEngineVersionResponse;
    LinkedChannelSettings?: DescribeLinkedChannelSettings;
    ChannelSecurityGroups?: string[];
    InferenceSettings?: DescribeInferenceSettings;
}
export interface StopInputDeviceRequest {
    InputDeviceId: string;
}
export interface StopInputDeviceResponse {
}
export interface StopMultiplexRequest {
    MultiplexId: string;
}
export interface StopMultiplexResponse {
    Arn?: string;
    AvailabilityZones?: string[];
    Destinations?: MultiplexOutputDestination[];
    Id?: string;
    MultiplexSettings?: MultiplexSettings & {
        TransportStreamBitrate: __integerMin1000000Max100000000;
        TransportStreamId: __integerMin0Max65535;
    };
    Name?: string;
    PipelinesRunningCount?: number;
    ProgramCount?: number;
    State?: MultiplexState;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface TransferInputDeviceRequest {
    InputDeviceId: string;
    TargetCustomerId?: string;
    TargetRegion?: string;
    TransferMessage?: string;
}
export interface TransferInputDeviceResponse {
}
export interface UpdateAccountConfigurationRequest {
    AccountConfiguration?: AccountConfiguration;
}
export interface UpdateAccountConfigurationResponse {
    AccountConfiguration?: AccountConfiguration;
}
export interface MaintenanceUpdateSettings {
    MaintenanceDay?: MaintenanceDay;
    MaintenanceScheduledDate?: string;
    MaintenanceStartTime?: string;
}
export interface SpecialRouterSettings {
    RouterArn?: string;
}
export interface UpdateChannelRequest {
    CdiInputSpecification?: CdiInputSpecification;
    ChannelId: string;
    Destinations?: OutputDestination[];
    EncoderSettings?: EncoderSettings;
    InputAttachments?: InputAttachment[];
    InputSpecification?: InputSpecification;
    LogLevel?: LogLevel;
    Maintenance?: MaintenanceUpdateSettings;
    Name?: string;
    RoleArn?: string;
    ChannelEngineVersion?: ChannelEngineVersionRequest;
    DryRun?: boolean;
    AnywhereSettings?: AnywhereSettings;
    LinkedChannelSettings?: LinkedChannelSettings;
    ChannelSecurityGroups?: string[];
    InferenceSettings?: InferenceSettings;
    SpecialRouterSettings?: SpecialRouterSettings;
}
export interface UpdateChannelResponse {
    Channel?: Channel & {
        EncoderSettings: EncoderSettings & {
            AudioDescriptions: (AudioDescription & {
                AudioSelectorName: string;
                Name: __stringMax255;
                AudioWatermarkingSettings: AudioWatermarkSettings & {
                    NielsenWatermarksSettings: NielsenWatermarksSettings & {
                        NielsenCbetSettings: NielsenCBET & {
                            CbetCheckDigitString: __stringMin2Max2;
                            CbetStepaside: NielsenWatermarksCbetStepaside;
                            Csid: __stringMin1Max7;
                        };
                        NielsenNaesIiNwSettings: NielsenNaesIiNw & {
                            CheckDigitString: __stringMin2Max2;
                            Sid: __doubleMin1Max65535;
                        };
                        NielsenNwOnlySettings: NielsenNwOnly & {
                            CheckDigitString: __stringMin2Max2;
                            Sid: __doubleMin1Max65535;
                        };
                    };
                };
                RemixSettings: RemixSettings & {
                    ChannelMappings: (AudioChannelMapping & {
                        InputChannelLevels: (InputChannelLevel & {
                            Gain: __integerMinNegative60Max6;
                            InputChannel: __integerMin0Max15;
                        })[];
                        OutputChannel: __integerMin0Max7;
                    })[];
                };
            })[];
            OutputGroups: (OutputGroup & {
                OutputGroupSettings: OutputGroupSettings & {
                    ArchiveGroupSettings: ArchiveGroupSettings & {
                        Destination: OutputLocationRef;
                    };
                    FrameCaptureGroupSettings: FrameCaptureGroupSettings & {
                        Destination: OutputLocationRef;
                    };
                    HlsGroupSettings: HlsGroupSettings & {
                        Destination: OutputLocationRef;
                        CaptionLanguageMappings: (CaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                            LanguageDescription: __stringMin1;
                        })[];
                        KeyProviderSettings: KeyProviderSettings & {
                            StaticKeySettings: StaticKeySettings & {
                                StaticKeyValue: __stringMin32Max32;
                                KeyProviderServer: InputLocation & {
                                    Uri: __stringMax2048;
                                };
                            };
                        };
                    };
                    MediaPackageGroupSettings: MediaPackageGroupSettings & {
                        Destination: OutputLocationRef;
                        MediapackageV2GroupSettings: MediaPackageV2GroupSettings & {
                            CaptionLanguageMappings: (CaptionLanguageMapping & {
                                CaptionChannel: __integerMin1Max4;
                                LanguageCode: __stringMin3Max3;
                                LanguageDescription: __stringMin1;
                            })[];
                            AdditionalDestinations: (MediaPackageAdditionalDestinations & {
                                Destination: OutputLocationRef;
                            })[];
                            WatermarkingSettings: MediaPackageV2WatermarkingSettings & {
                                MediaPackageV2AbWatermarkerIrdetoSettings: MediaPackageV2AbWatermarkerIrdetoSettings & {
                                    AlternateDestination: OutputLocationRef;
                                    OperatorId: __integerMin1Max511;
                                    Profile: AbWatermarkingProfile;
                                    CustomProfile: AbWatermarkingCustomProfile & {
                                        EmbeddingFrequency: __doubleMin250Max5000;
                                        SceneCut: __doubleMinNegative1Max5;
                                        TargetPsnr: __doubleMin32Max46;
                                    };
                                };
                            };
                        };
                    };
                    MsSmoothGroupSettings: MsSmoothGroupSettings & {
                        Destination: OutputLocationRef;
                    };
                    CmafIngestGroupSettings: CmafIngestGroupSettings & {
                        Destination: OutputLocationRef;
                        CaptionLanguageMappings: (CmafIngestCaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                        })[];
                        AdditionalDestinations: (AdditionalDestinations & {
                            Destination: OutputLocationRef;
                        })[];
                        WatermarkingSettings: CmafIngestWatermarkingSettings & {
                            CmafIngestAbWatermarkerIrdetoSettings: CmafIngestAbWatermarkerIrdetoSettings & {
                                AlternateDestination: OutputLocationRef;
                                OperatorId: __integerMin1Max511;
                                Profile: AbWatermarkingProfile;
                                CustomProfile: AbWatermarkingCustomProfile & {
                                    EmbeddingFrequency: __doubleMin250Max5000;
                                    SceneCut: __doubleMinNegative1Max5;
                                    TargetPsnr: __doubleMin32Max46;
                                };
                            };
                        };
                    };
                };
                Outputs: (Output & {
                    OutputSettings: OutputSettings & {
                        ArchiveOutputSettings: ArchiveOutputSettings & {
                            ContainerSettings: ArchiveContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                        };
                        HlsOutputSettings: HlsOutputSettings & {
                            HlsSettings: HlsSettings & {
                                AudioOnlyHlsSettings: AudioOnlyHlsSettings & {
                                    AudioOnlyImage: InputLocation & {
                                        Uri: __stringMax2048;
                                    };
                                };
                                StandardHlsSettings: StandardHlsSettings & {
                                    M3u8Settings: M3u8Settings;
                                };
                            };
                        };
                        MultiplexOutputSettings: MultiplexOutputSettings & {
                            Destination: OutputLocationRef;
                        };
                        RtmpOutputSettings: RtmpOutputSettings & {
                            Destination: OutputLocationRef;
                        };
                        UdpOutputSettings: UdpOutputSettings & {
                            ContainerSettings: UdpContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                            Destination: OutputLocationRef;
                        };
                        SrtOutputSettings: SrtOutputSettings & {
                            ContainerSettings: UdpContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                            Destination: OutputLocationRef;
                        };
                        MediaConnectRouterOutputSettings: MediaConnectRouterOutputSettings & {
                            ContainerSettings: MediaConnectRouterContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                            Destination: OutputLocationRef;
                        };
                    };
                })[];
            })[];
            TimecodeConfig: TimecodeConfig & {
                Source: TimecodeConfigSource;
            };
            VideoDescriptions: (VideoDescription & {
                Name: string;
                CodecSettings: VideoCodecSettings & {
                    FrameCaptureSettings: FrameCaptureSettings & {
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    H264Settings: H264Settings & {
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    H265Settings: H265Settings & {
                        FramerateDenominator: __integerMin1Max3003;
                        FramerateNumerator: __integerMin1;
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    Mpeg2Settings: Mpeg2Settings & {
                        FramerateDenominator: __integerMin1;
                        FramerateNumerator: __integerMin1;
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    Av1Settings: Av1Settings & {
                        FramerateDenominator: __integerMin1Max3003;
                        FramerateNumerator: __integerMin1;
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                };
                CropRectangle: VideoPositionRectangle & {
                    Height: __integerMin2Max8192;
                    Width: __integerMin2Max8192;
                    X: __integerMin0Max8190;
                    Y: __integerMin0Max8190;
                };
                OutputPositionRectangle: VideoPositionRectangle & {
                    Height: __integerMin2Max8192;
                    Width: __integerMin2Max8192;
                    X: __integerMin0Max8190;
                    Y: __integerMin0Max8190;
                };
            })[];
            AvailBlanking: AvailBlanking & {
                AvailBlankingImage: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
            AvailConfiguration: AvailConfiguration & {
                AvailSettings: AvailSettings & {
                    Esam: Esam & {
                        AcquisitionPointId: __stringMax256;
                        PoisEndpoint: __stringMax2048;
                    };
                };
            };
            BlackoutSlate: BlackoutSlate & {
                BlackoutSlateImage: InputLocation & {
                    Uri: __stringMax2048;
                };
                NetworkEndBlackoutImage: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
            CaptionDescriptions: (CaptionDescription & {
                CaptionSelectorName: string;
                Name: string;
                DestinationSettings: CaptionDestinationSettings & {
                    BurnInDestinationSettings: BurnInDestinationSettings & {
                        Font: InputLocation & {
                            Uri: __stringMax2048;
                        };
                    };
                    DvbSubDestinationSettings: DvbSubDestinationSettings & {
                        Font: InputLocation & {
                            Uri: __stringMax2048;
                        };
                    };
                };
            })[];
            GlobalConfiguration: GlobalConfiguration & {
                InputLossBehavior: InputLossBehavior & {
                    InputLossImageSlate: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
            };
            MotionGraphicsConfiguration: MotionGraphicsConfiguration & {
                MotionGraphicsSettings: MotionGraphicsSettings;
            };
            ThumbnailConfiguration: ThumbnailConfiguration & {
                State: ThumbnailState;
            };
            ColorCorrectionSettings: ColorCorrectionSettings & {
                GlobalColorCorrections: (ColorCorrection & {
                    InputColorSpace: ColorSpace;
                    OutputColorSpace: ColorSpace;
                    Uri: string;
                })[];
            };
        };
        InputAttachments: (InputAttachment & {
            AutomaticInputFailoverSettings: AutomaticInputFailoverSettings & {
                SecondaryInputId: string;
                FailoverConditions: (FailoverCondition & {
                    FailoverConditionSettings: FailoverConditionSettings & {
                        AudioSilenceSettings: AudioSilenceFailoverSettings & {
                            AudioSelectorName: string;
                        };
                    };
                })[];
            };
            InputSettings: InputSettings & {
                AudioSelectors: (AudioSelector & {
                    Name: __stringMin1;
                    SelectorSettings: AudioSelectorSettings & {
                        AudioHlsRenditionSelection: AudioHlsRenditionSelection & {
                            GroupId: __stringMin1;
                            Name: __stringMin1;
                        };
                        AudioLanguageSelection: AudioLanguageSelection & {
                            LanguageCode: string;
                        };
                        AudioPidSelection: AudioPidSelection & {
                            Pid: __integerMin0Max8191;
                            Pids: (AudioPid & {
                                Pid: __integerMin0Max8191;
                                DolbyEDecode: AudioDolbyEDecode & {
                                    ProgramSelection: DolbyEProgramSelection;
                                };
                                PremixSettings: AudioPreMixerSettings & {
                                    RemixSettings: RemixSettings & {
                                        ChannelMappings: (AudioChannelMapping & {
                                            InputChannelLevels: (InputChannelLevel & {
                                                Gain: __integerMinNegative60Max6;
                                                InputChannel: __integerMin0Max15;
                                            })[];
                                            OutputChannel: __integerMin0Max7;
                                        })[];
                                    };
                                };
                            })[];
                        };
                        AudioTrackSelection: AudioTrackSelection & {
                            Tracks: (AudioTrack & {
                                Track: __integerMin1;
                                PremixSettings: AudioPreMixerSettings & {
                                    RemixSettings: RemixSettings & {
                                        ChannelMappings: (AudioChannelMapping & {
                                            InputChannelLevels: (InputChannelLevel & {
                                                Gain: __integerMinNegative60Max6;
                                                InputChannel: __integerMin0Max15;
                                            })[];
                                            OutputChannel: __integerMin0Max7;
                                        })[];
                                    };
                                };
                            })[];
                            DolbyEDecode: AudioDolbyEDecode & {
                                ProgramSelection: DolbyEProgramSelection;
                            };
                        };
                    };
                })[];
                CaptionSelectors: (CaptionSelector & {
                    Name: __stringMin1;
                    SelectorSettings: CaptionSelectorSettings & {
                        TeletextSourceSettings: TeletextSourceSettings & {
                            OutputRectangle: CaptionRectangle & {
                                Height: __doubleMin0Max100;
                                LeftOffset: __doubleMin0Max100;
                                TopOffset: __doubleMin0Max100;
                                Width: __doubleMin0Max100;
                            };
                        };
                    };
                })[];
            };
        })[];
    };
}
export interface UpdateChannelClassRequest {
    ChannelClass?: ChannelClass;
    ChannelId: string;
    Destinations?: OutputDestination[];
}
export interface UpdateChannelClassResponse {
    Channel?: Channel & {
        EncoderSettings: EncoderSettings & {
            AudioDescriptions: (AudioDescription & {
                AudioSelectorName: string;
                Name: __stringMax255;
                AudioWatermarkingSettings: AudioWatermarkSettings & {
                    NielsenWatermarksSettings: NielsenWatermarksSettings & {
                        NielsenCbetSettings: NielsenCBET & {
                            CbetCheckDigitString: __stringMin2Max2;
                            CbetStepaside: NielsenWatermarksCbetStepaside;
                            Csid: __stringMin1Max7;
                        };
                        NielsenNaesIiNwSettings: NielsenNaesIiNw & {
                            CheckDigitString: __stringMin2Max2;
                            Sid: __doubleMin1Max65535;
                        };
                        NielsenNwOnlySettings: NielsenNwOnly & {
                            CheckDigitString: __stringMin2Max2;
                            Sid: __doubleMin1Max65535;
                        };
                    };
                };
                RemixSettings: RemixSettings & {
                    ChannelMappings: (AudioChannelMapping & {
                        InputChannelLevels: (InputChannelLevel & {
                            Gain: __integerMinNegative60Max6;
                            InputChannel: __integerMin0Max15;
                        })[];
                        OutputChannel: __integerMin0Max7;
                    })[];
                };
            })[];
            OutputGroups: (OutputGroup & {
                OutputGroupSettings: OutputGroupSettings & {
                    ArchiveGroupSettings: ArchiveGroupSettings & {
                        Destination: OutputLocationRef;
                    };
                    FrameCaptureGroupSettings: FrameCaptureGroupSettings & {
                        Destination: OutputLocationRef;
                    };
                    HlsGroupSettings: HlsGroupSettings & {
                        Destination: OutputLocationRef;
                        CaptionLanguageMappings: (CaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                            LanguageDescription: __stringMin1;
                        })[];
                        KeyProviderSettings: KeyProviderSettings & {
                            StaticKeySettings: StaticKeySettings & {
                                StaticKeyValue: __stringMin32Max32;
                                KeyProviderServer: InputLocation & {
                                    Uri: __stringMax2048;
                                };
                            };
                        };
                    };
                    MediaPackageGroupSettings: MediaPackageGroupSettings & {
                        Destination: OutputLocationRef;
                        MediapackageV2GroupSettings: MediaPackageV2GroupSettings & {
                            CaptionLanguageMappings: (CaptionLanguageMapping & {
                                CaptionChannel: __integerMin1Max4;
                                LanguageCode: __stringMin3Max3;
                                LanguageDescription: __stringMin1;
                            })[];
                            AdditionalDestinations: (MediaPackageAdditionalDestinations & {
                                Destination: OutputLocationRef;
                            })[];
                            WatermarkingSettings: MediaPackageV2WatermarkingSettings & {
                                MediaPackageV2AbWatermarkerIrdetoSettings: MediaPackageV2AbWatermarkerIrdetoSettings & {
                                    AlternateDestination: OutputLocationRef;
                                    OperatorId: __integerMin1Max511;
                                    Profile: AbWatermarkingProfile;
                                    CustomProfile: AbWatermarkingCustomProfile & {
                                        EmbeddingFrequency: __doubleMin250Max5000;
                                        SceneCut: __doubleMinNegative1Max5;
                                        TargetPsnr: __doubleMin32Max46;
                                    };
                                };
                            };
                        };
                    };
                    MsSmoothGroupSettings: MsSmoothGroupSettings & {
                        Destination: OutputLocationRef;
                    };
                    CmafIngestGroupSettings: CmafIngestGroupSettings & {
                        Destination: OutputLocationRef;
                        CaptionLanguageMappings: (CmafIngestCaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                        })[];
                        AdditionalDestinations: (AdditionalDestinations & {
                            Destination: OutputLocationRef;
                        })[];
                        WatermarkingSettings: CmafIngestWatermarkingSettings & {
                            CmafIngestAbWatermarkerIrdetoSettings: CmafIngestAbWatermarkerIrdetoSettings & {
                                AlternateDestination: OutputLocationRef;
                                OperatorId: __integerMin1Max511;
                                Profile: AbWatermarkingProfile;
                                CustomProfile: AbWatermarkingCustomProfile & {
                                    EmbeddingFrequency: __doubleMin250Max5000;
                                    SceneCut: __doubleMinNegative1Max5;
                                    TargetPsnr: __doubleMin32Max46;
                                };
                            };
                        };
                    };
                };
                Outputs: (Output & {
                    OutputSettings: OutputSettings & {
                        ArchiveOutputSettings: ArchiveOutputSettings & {
                            ContainerSettings: ArchiveContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                        };
                        HlsOutputSettings: HlsOutputSettings & {
                            HlsSettings: HlsSettings & {
                                AudioOnlyHlsSettings: AudioOnlyHlsSettings & {
                                    AudioOnlyImage: InputLocation & {
                                        Uri: __stringMax2048;
                                    };
                                };
                                StandardHlsSettings: StandardHlsSettings & {
                                    M3u8Settings: M3u8Settings;
                                };
                            };
                        };
                        MultiplexOutputSettings: MultiplexOutputSettings & {
                            Destination: OutputLocationRef;
                        };
                        RtmpOutputSettings: RtmpOutputSettings & {
                            Destination: OutputLocationRef;
                        };
                        UdpOutputSettings: UdpOutputSettings & {
                            ContainerSettings: UdpContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                            Destination: OutputLocationRef;
                        };
                        SrtOutputSettings: SrtOutputSettings & {
                            ContainerSettings: UdpContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                            Destination: OutputLocationRef;
                        };
                        MediaConnectRouterOutputSettings: MediaConnectRouterOutputSettings & {
                            ContainerSettings: MediaConnectRouterContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                            Destination: OutputLocationRef;
                        };
                    };
                })[];
            })[];
            TimecodeConfig: TimecodeConfig & {
                Source: TimecodeConfigSource;
            };
            VideoDescriptions: (VideoDescription & {
                Name: string;
                CodecSettings: VideoCodecSettings & {
                    FrameCaptureSettings: FrameCaptureSettings & {
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    H264Settings: H264Settings & {
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    H265Settings: H265Settings & {
                        FramerateDenominator: __integerMin1Max3003;
                        FramerateNumerator: __integerMin1;
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    Mpeg2Settings: Mpeg2Settings & {
                        FramerateDenominator: __integerMin1;
                        FramerateNumerator: __integerMin1;
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    Av1Settings: Av1Settings & {
                        FramerateDenominator: __integerMin1Max3003;
                        FramerateNumerator: __integerMin1;
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                };
                CropRectangle: VideoPositionRectangle & {
                    Height: __integerMin2Max8192;
                    Width: __integerMin2Max8192;
                    X: __integerMin0Max8190;
                    Y: __integerMin0Max8190;
                };
                OutputPositionRectangle: VideoPositionRectangle & {
                    Height: __integerMin2Max8192;
                    Width: __integerMin2Max8192;
                    X: __integerMin0Max8190;
                    Y: __integerMin0Max8190;
                };
            })[];
            AvailBlanking: AvailBlanking & {
                AvailBlankingImage: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
            AvailConfiguration: AvailConfiguration & {
                AvailSettings: AvailSettings & {
                    Esam: Esam & {
                        AcquisitionPointId: __stringMax256;
                        PoisEndpoint: __stringMax2048;
                    };
                };
            };
            BlackoutSlate: BlackoutSlate & {
                BlackoutSlateImage: InputLocation & {
                    Uri: __stringMax2048;
                };
                NetworkEndBlackoutImage: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
            CaptionDescriptions: (CaptionDescription & {
                CaptionSelectorName: string;
                Name: string;
                DestinationSettings: CaptionDestinationSettings & {
                    BurnInDestinationSettings: BurnInDestinationSettings & {
                        Font: InputLocation & {
                            Uri: __stringMax2048;
                        };
                    };
                    DvbSubDestinationSettings: DvbSubDestinationSettings & {
                        Font: InputLocation & {
                            Uri: __stringMax2048;
                        };
                    };
                };
            })[];
            GlobalConfiguration: GlobalConfiguration & {
                InputLossBehavior: InputLossBehavior & {
                    InputLossImageSlate: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
            };
            MotionGraphicsConfiguration: MotionGraphicsConfiguration & {
                MotionGraphicsSettings: MotionGraphicsSettings;
            };
            ThumbnailConfiguration: ThumbnailConfiguration & {
                State: ThumbnailState;
            };
            ColorCorrectionSettings: ColorCorrectionSettings & {
                GlobalColorCorrections: (ColorCorrection & {
                    InputColorSpace: ColorSpace;
                    OutputColorSpace: ColorSpace;
                    Uri: string;
                })[];
            };
        };
        InputAttachments: (InputAttachment & {
            AutomaticInputFailoverSettings: AutomaticInputFailoverSettings & {
                SecondaryInputId: string;
                FailoverConditions: (FailoverCondition & {
                    FailoverConditionSettings: FailoverConditionSettings & {
                        AudioSilenceSettings: AudioSilenceFailoverSettings & {
                            AudioSelectorName: string;
                        };
                    };
                })[];
            };
            InputSettings: InputSettings & {
                AudioSelectors: (AudioSelector & {
                    Name: __stringMin1;
                    SelectorSettings: AudioSelectorSettings & {
                        AudioHlsRenditionSelection: AudioHlsRenditionSelection & {
                            GroupId: __stringMin1;
                            Name: __stringMin1;
                        };
                        AudioLanguageSelection: AudioLanguageSelection & {
                            LanguageCode: string;
                        };
                        AudioPidSelection: AudioPidSelection & {
                            Pid: __integerMin0Max8191;
                            Pids: (AudioPid & {
                                Pid: __integerMin0Max8191;
                                DolbyEDecode: AudioDolbyEDecode & {
                                    ProgramSelection: DolbyEProgramSelection;
                                };
                                PremixSettings: AudioPreMixerSettings & {
                                    RemixSettings: RemixSettings & {
                                        ChannelMappings: (AudioChannelMapping & {
                                            InputChannelLevels: (InputChannelLevel & {
                                                Gain: __integerMinNegative60Max6;
                                                InputChannel: __integerMin0Max15;
                                            })[];
                                            OutputChannel: __integerMin0Max7;
                                        })[];
                                    };
                                };
                            })[];
                        };
                        AudioTrackSelection: AudioTrackSelection & {
                            Tracks: (AudioTrack & {
                                Track: __integerMin1;
                                PremixSettings: AudioPreMixerSettings & {
                                    RemixSettings: RemixSettings & {
                                        ChannelMappings: (AudioChannelMapping & {
                                            InputChannelLevels: (InputChannelLevel & {
                                                Gain: __integerMinNegative60Max6;
                                                InputChannel: __integerMin0Max15;
                                            })[];
                                            OutputChannel: __integerMin0Max7;
                                        })[];
                                    };
                                };
                            })[];
                            DolbyEDecode: AudioDolbyEDecode & {
                                ProgramSelection: DolbyEProgramSelection;
                            };
                        };
                    };
                })[];
                CaptionSelectors: (CaptionSelector & {
                    Name: __stringMin1;
                    SelectorSettings: CaptionSelectorSettings & {
                        TeletextSourceSettings: TeletextSourceSettings & {
                            OutputRectangle: CaptionRectangle & {
                                Height: __doubleMin0Max100;
                                LeftOffset: __doubleMin0Max100;
                                TopOffset: __doubleMin0Max100;
                                Width: __doubleMin0Max100;
                            };
                        };
                    };
                })[];
            };
        })[];
    };
}
export interface UpdateChannelPlacementGroupRequest {
    ChannelPlacementGroupId: string;
    ClusterId: string;
    Name?: string;
    Nodes?: string[];
}
export interface UpdateChannelPlacementGroupResponse {
    Arn?: string;
    Channels?: string[];
    ClusterId?: string;
    Id?: string;
    Name?: string;
    Nodes?: string[];
    State?: ChannelPlacementGroupState;
}
export interface UpdateCloudWatchAlarmTemplateRequest {
    ComparisonOperator?: CloudWatchAlarmTemplateComparisonOperator;
    DatapointsToAlarm?: number;
    Description?: string;
    EvaluationPeriods?: number;
    GroupIdentifier?: string;
    Identifier: string;
    MetricName?: string;
    Name?: string;
    Period?: number;
    Statistic?: CloudWatchAlarmTemplateStatistic;
    TargetResourceType?: CloudWatchAlarmTemplateTargetResourceType;
    Threshold?: number;
    TreatMissingData?: CloudWatchAlarmTemplateTreatMissingData;
}
export interface UpdateCloudWatchAlarmTemplateResponse {
    Arn?: string;
    ComparisonOperator?: CloudWatchAlarmTemplateComparisonOperator;
    CreatedAt?: Date;
    DatapointsToAlarm?: number;
    Description?: string;
    EvaluationPeriods?: number;
    GroupId?: string;
    Id?: string;
    MetricName?: string;
    ModifiedAt?: Date;
    Name?: string;
    Period?: number;
    Statistic?: CloudWatchAlarmTemplateStatistic;
    Tags?: {
        [key: string]: string | undefined;
    };
    TargetResourceType?: CloudWatchAlarmTemplateTargetResourceType;
    Threshold?: number;
    TreatMissingData?: CloudWatchAlarmTemplateTreatMissingData;
}
export interface UpdateCloudWatchAlarmTemplateGroupRequest {
    Description?: string;
    Identifier: string;
}
export interface UpdateCloudWatchAlarmTemplateGroupResponse {
    Arn?: string;
    CreatedAt?: Date;
    Description?: string;
    Id?: string;
    ModifiedAt?: Date;
    Name?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface InterfaceMappingUpdateRequest {
    LogicalInterfaceName?: string;
    NetworkId?: string;
}
export type __listOfInterfaceMappingUpdateRequest = InterfaceMappingUpdateRequest[];
export interface ClusterNetworkSettingsUpdateRequest {
    DefaultRoute?: string;
    InterfaceMappings?: InterfaceMappingUpdateRequest[];
}
export interface UpdateClusterRequest {
    ClusterId: string;
    Name?: string;
    NetworkSettings?: ClusterNetworkSettingsUpdateRequest;
}
export interface UpdateClusterResponse {
    Arn?: string;
    ChannelIds?: string[];
    ClusterType?: ClusterType;
    Id?: string;
    Name?: string;
    NetworkSettings?: ClusterNetworkSettings;
    State?: ClusterState;
}
export interface UpdateEventBridgeRuleTemplateRequest {
    Description?: string;
    EventTargets?: EventBridgeRuleTemplateTarget[];
    EventType?: EventBridgeRuleTemplateEventType;
    GroupIdentifier?: string;
    Identifier: string;
    Name?: string;
}
export interface UpdateEventBridgeRuleTemplateResponse {
    Arn?: string;
    CreatedAt?: Date;
    Description?: string;
    EventTargets?: (EventBridgeRuleTemplateTarget & {
        Arn: __stringMin1Max2048PatternArn;
    })[];
    EventType?: EventBridgeRuleTemplateEventType;
    GroupId?: string;
    Id?: string;
    ModifiedAt?: Date;
    Name?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface UpdateEventBridgeRuleTemplateGroupRequest {
    Description?: string;
    Identifier: string;
}
export interface UpdateEventBridgeRuleTemplateGroupResponse {
    Arn?: string;
    CreatedAt?: Date;
    Description?: string;
    Id?: string;
    ModifiedAt?: Date;
    Name?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface InputDeviceRequest {
    Id?: string;
}
export type __listOfInputDeviceRequest = InputDeviceRequest[];
export interface MulticastSourceUpdateRequest {
    SourceIp?: string;
    Url?: string;
}
export type __listOfMulticastSourceUpdateRequest = MulticastSourceUpdateRequest[];
export interface MulticastSettingsUpdateRequest {
    Sources?: MulticastSourceUpdateRequest[];
}
export interface UpdateInputRequest {
    Destinations?: InputDestinationRequest[];
    InputDevices?: InputDeviceRequest[];
    InputId: string;
    InputSecurityGroups?: string[];
    MediaConnectFlows?: MediaConnectFlowRequest[];
    Name?: string;
    RoleArn?: string;
    Sources?: InputSourceRequest[];
    SrtSettings?: SrtSettingsRequest;
    MulticastSettings?: MulticastSettingsUpdateRequest;
    Smpte2110ReceiverGroupSettings?: Smpte2110ReceiverGroupSettings;
    SdiSources?: string[];
    SpecialRouterSettings?: SpecialRouterSettings;
}
export interface UpdateInputResponse {
    Input?: Input & {
        SrtSettings: SrtSettings & {
            SrtListenerSettings: SrtListenerSettings & {
                Decryption: SrtListenerDecryption & {
                    Algorithm: Algorithm;
                    PassphraseSecretArn: string;
                };
            };
        };
        MulticastSettings: MulticastSettings & {
            Sources: (MulticastSource & {
                Url: string;
            })[];
        };
    };
}
export interface InputDeviceMediaConnectConfigurableSettings {
    FlowArn?: string;
    RoleArn?: string;
    SecretArn?: string;
    SourceName?: string;
}
export type InputDeviceConfigurableAudioChannelPairProfile = "DISABLED" | "VBR-AAC_HHE-16000" | "VBR-AAC_HE-64000" | "VBR-AAC_LC-128000" | "CBR-AAC_HQ-192000" | "CBR-AAC_HQ-256000" | "CBR-AAC_HQ-384000" | "CBR-AAC_HQ-512000" | (string & {});
export interface InputDeviceConfigurableAudioChannelPairConfig {
    Id?: number;
    Profile?: InputDeviceConfigurableAudioChannelPairProfile;
}
export type __listOfInputDeviceConfigurableAudioChannelPairConfig = InputDeviceConfigurableAudioChannelPairConfig[];
export interface InputDeviceConfigurableSettings {
    ConfiguredInput?: InputDeviceConfiguredInput;
    MaxBitrate?: number;
    LatencyMs?: number;
    Codec?: InputDeviceCodec;
    MediaconnectSettings?: InputDeviceMediaConnectConfigurableSettings;
    AudioChannelPairs?: InputDeviceConfigurableAudioChannelPairConfig[];
    InputResolution?: string;
}
export interface UpdateInputDeviceRequest {
    HdDeviceSettings?: InputDeviceConfigurableSettings;
    InputDeviceId: string;
    Name?: string;
    UhdDeviceSettings?: InputDeviceConfigurableSettings;
    AvailabilityZone?: string;
}
export interface UpdateInputDeviceResponse {
    Arn?: string;
    ConnectionState?: InputDeviceConnectionState;
    DeviceSettingsSyncState?: DeviceSettingsSyncState;
    DeviceUpdateStatus?: DeviceUpdateStatus;
    HdDeviceSettings?: InputDeviceHdSettings;
    Id?: string;
    MacAddress?: string;
    Name?: string;
    NetworkSettings?: InputDeviceNetworkSettings;
    SerialNumber?: string;
    Type?: InputDeviceType;
    UhdDeviceSettings?: InputDeviceUhdSettings;
    Tags?: {
        [key: string]: string | undefined;
    };
    AvailabilityZone?: string;
    MedialiveInputArns?: string[];
    OutputType?: InputDeviceOutputType;
}
export interface UpdateInputSecurityGroupRequest {
    InputSecurityGroupId: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    WhitelistRules?: InputWhitelistRuleCidr[];
}
export interface UpdateInputSecurityGroupResponse {
    SecurityGroup?: InputSecurityGroup;
}
export type MultiplexPacketIdentifiersMapping = {
    [key: string]: MultiplexProgramPacketIdentifiersMap | undefined;
};
export interface UpdateMultiplexRequest {
    MultiplexId: string;
    MultiplexSettings?: MultiplexSettings;
    Name?: string;
    PacketIdentifiersMapping?: {
        [key: string]: MultiplexProgramPacketIdentifiersMap | undefined;
    };
}
export interface UpdateMultiplexResponse {
    Multiplex?: Multiplex & {
        MultiplexSettings: MultiplexSettings & {
            TransportStreamBitrate: __integerMin1000000Max100000000;
            TransportStreamId: __integerMin0Max65535;
        };
    };
}
export interface UpdateMultiplexProgramRequest {
    MultiplexId: string;
    MultiplexProgramSettings?: MultiplexProgramSettings;
    ProgramName: string;
}
export interface UpdateMultiplexProgramResponse {
    MultiplexProgram?: MultiplexProgram & {
        MultiplexProgramSettings: MultiplexProgramSettings & {
            ProgramNumber: __integerMin0Max65535;
            ServiceDescriptor: MultiplexProgramServiceDescriptor & {
                ProviderName: __stringMax256;
                ServiceName: __stringMax256;
            };
        };
    };
}
export interface IpPoolUpdateRequest {
    Cidr?: string;
}
export type __listOfIpPoolUpdateRequest = IpPoolUpdateRequest[];
export interface RouteUpdateRequest {
    Cidr?: string;
    Gateway?: string;
}
export type __listOfRouteUpdateRequest = RouteUpdateRequest[];
export interface UpdateNetworkRequest {
    IpPools?: IpPoolUpdateRequest[];
    Name?: string;
    NetworkId: string;
    Routes?: RouteUpdateRequest[];
}
export interface UpdateNetworkResponse {
    Arn?: string;
    AssociatedClusterIds?: string[];
    Id?: string;
    IpPools?: IpPool[];
    Name?: string;
    Routes?: Route[];
    State?: NetworkState;
}
export interface SdiSourceMappingUpdateRequest {
    CardNumber?: number;
    ChannelNumber?: number;
    SdiSource?: string;
}
export type SdiSourceMappingsUpdateRequest = SdiSourceMappingUpdateRequest[];
export interface UpdateNodeRequest {
    ClusterId: string;
    Name?: string;
    NodeId: string;
    Role?: NodeRole;
    SdiSourceMappings?: SdiSourceMappingUpdateRequest[];
}
export interface UpdateNodeResponse {
    Arn?: string;
    ChannelPlacementGroups?: string[];
    ClusterId?: string;
    ConnectionState?: NodeConnectionState;
    Id?: string;
    InstanceArn?: string;
    Name?: string;
    NodeInterfaceMappings?: NodeInterfaceMapping[];
    Role?: NodeRole;
    State?: NodeState;
    SdiSourceMappings?: SdiSourceMapping[];
}
export type UpdateNodeStateShape = "ACTIVE" | "DRAINING" | (string & {});
export interface UpdateNodeStateRequest {
    ClusterId: string;
    NodeId: string;
    State?: UpdateNodeStateShape;
}
export interface UpdateNodeStateResponse {
    Arn?: string;
    ChannelPlacementGroups?: string[];
    ClusterId?: string;
    ConnectionState?: NodeConnectionState;
    Id?: string;
    InstanceArn?: string;
    Name?: string;
    NodeInterfaceMappings?: NodeInterfaceMapping[];
    Role?: NodeRole;
    State?: NodeState;
    SdiSourceMappings?: SdiSourceMapping[];
}
export interface UpdateReservationRequest {
    Name?: string;
    RenewalSettings?: RenewalSettings;
    ReservationId: string;
}
export interface UpdateReservationResponse {
    Reservation?: Reservation;
}
export interface UpdateSdiSourceRequest {
    Mode?: SdiSourceMode;
    Name?: string;
    SdiSourceId: string;
    Type?: SdiSourceType;
}
export interface UpdateSdiSourceResponse {
    SdiSource?: SdiSource;
}
export interface ValidationError {
    ElementPath?: string;
    ErrorMessage?: string;
}
export type __listOfValidationError = ValidationError[];
export type AcceptInputDeviceTransferError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Accept an incoming input device transfer. The ownership of the device will transfer to your AWS account.
 */
export declare const acceptInputDeviceTransfer: API.OperationMethod<AcceptInputDeviceTransferRequest, AcceptInputDeviceTransferResponse, AcceptInputDeviceTransferError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Starts delete of resources.
 */
export declare const batchDelete: API.OperationMethod<BatchDeleteRequest, BatchDeleteResponse, BatchDeleteError, Credentials | HttpClient.HttpClient>;
export type BatchStartError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Starts existing resources
 */
export declare const batchStart: API.OperationMethod<BatchStartRequest, BatchStartResponse, BatchStartError, Credentials | HttpClient.HttpClient>;
export type BatchStopError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Stops running resources
 */
export declare const batchStop: API.OperationMethod<BatchStopRequest, BatchStopResponse, BatchStopError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateScheduleError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Update a channel schedule
 */
export declare const batchUpdateSchedule: API.OperationMethod<BatchUpdateScheduleRequest, BatchUpdateScheduleResponse, BatchUpdateScheduleError, Credentials | HttpClient.HttpClient>;
export type CancelInputDeviceTransferError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Cancel an input device transfer that you have requested.
 */
export declare const cancelInputDeviceTransfer: API.OperationMethod<CancelInputDeviceTransferRequest, CancelInputDeviceTransferResponse, CancelInputDeviceTransferError, Credentials | HttpClient.HttpClient>;
export type ClaimDeviceError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Send a request to claim an AWS Elemental device that you have purchased from a third-party vendor. After the request succeeds, you will own the device.
 */
export declare const claimDevice: API.OperationMethod<ClaimDeviceRequest, ClaimDeviceResponse, ClaimDeviceError, Credentials | HttpClient.HttpClient>;
export type CreateChannelError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | UnprocessableEntityException | MediaLiveRoleNotYetTrusted | CommonErrors;
/**
 * Creates a new channel
 */
export declare const createChannel: API.OperationMethod<CreateChannelRequest, CreateChannelResponse, CreateChannelError, Credentials | HttpClient.HttpClient>;
export type CreateChannelPlacementGroupError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Create a ChannelPlacementGroup in the specified Cluster. As part of the create operation, you specify the Nodes to attach the group to.After you create a ChannelPlacementGroup, you add Channels to the group (you do this by modifying the Channels to add them to a specific group). You now have an association of Channels to ChannelPlacementGroup, and ChannelPlacementGroup to Nodes. This association means that all the Channels in the group are able to run on any of the Nodes associated with the group.
 */
export declare const createChannelPlacementGroup: API.OperationMethod<CreateChannelPlacementGroupRequest, CreateChannelPlacementGroupResponse, CreateChannelPlacementGroupError, Credentials | HttpClient.HttpClient>;
export type CreateCloudWatchAlarmTemplateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a cloudwatch alarm template to dynamically generate cloudwatch metric alarms on targeted resource types.
 */
export declare const createCloudWatchAlarmTemplate: API.OperationMethod<CreateCloudWatchAlarmTemplateRequest, CreateCloudWatchAlarmTemplateResponse, CreateCloudWatchAlarmTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateCloudWatchAlarmTemplateGroupError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a cloudwatch alarm template group to group your cloudwatch alarm templates and to attach to signal maps for dynamically creating alarms.
 */
export declare const createCloudWatchAlarmTemplateGroup: API.OperationMethod<CreateCloudWatchAlarmTemplateGroupRequest, CreateCloudWatchAlarmTemplateGroupResponse, CreateCloudWatchAlarmTemplateGroupError, Credentials | HttpClient.HttpClient>;
export type CreateClusterError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Create a new Cluster.
 */
export declare const createCluster: API.OperationMethod<CreateClusterRequest, CreateClusterResponse, CreateClusterError, Credentials | HttpClient.HttpClient>;
export type CreateEventBridgeRuleTemplateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an eventbridge rule template to monitor events and send notifications to your targeted resources.
 */
export declare const createEventBridgeRuleTemplate: API.OperationMethod<CreateEventBridgeRuleTemplateRequest, CreateEventBridgeRuleTemplateResponse, CreateEventBridgeRuleTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateEventBridgeRuleTemplateGroupError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an eventbridge rule template group to group your eventbridge rule templates and to attach to signal maps for dynamically creating notification rules.
 */
export declare const createEventBridgeRuleTemplateGroup: API.OperationMethod<CreateEventBridgeRuleTemplateGroupRequest, CreateEventBridgeRuleTemplateGroupResponse, CreateEventBridgeRuleTemplateGroupError, Credentials | HttpClient.HttpClient>;
export type CreateInputError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Create an input
 */
export declare const createInput: API.OperationMethod<CreateInputRequest, CreateInputResponse, CreateInputError, Credentials | HttpClient.HttpClient>;
export type CreateInputSecurityGroupError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Creates a Input Security Group
 */
export declare const createInputSecurityGroup: API.OperationMethod<CreateInputSecurityGroupRequest, CreateInputSecurityGroupResponse, CreateInputSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type CreateMultiplexError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Create a new multiplex.
 */
export declare const createMultiplex: API.OperationMethod<CreateMultiplexRequest, CreateMultiplexResponse, CreateMultiplexError, Credentials | HttpClient.HttpClient>;
export type CreateMultiplexProgramError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Create a new program in the multiplex.
 */
export declare const createMultiplexProgram: API.OperationMethod<CreateMultiplexProgramRequest, CreateMultiplexProgramResponse, CreateMultiplexProgramError, Credentials | HttpClient.HttpClient>;
export type CreateNetworkError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Create as many Networks as you need. You will associate one or more Clusters with each Network.Each Network provides MediaLive Anywhere with required information about the network in your organization that you are using for video encoding using MediaLive.
 */
export declare const createNetwork: API.OperationMethod<CreateNetworkRequest, CreateNetworkResponse, CreateNetworkError, Credentials | HttpClient.HttpClient>;
export type CreateNodeError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Create a Node in the specified Cluster. You can also create Nodes using the CreateNodeRegistrationScript. Note that you can't move a Node to another Cluster.
 */
export declare const createNode: API.OperationMethod<CreateNodeRequest, CreateNodeResponse, CreateNodeError, Credentials | HttpClient.HttpClient>;
export type CreateNodeRegistrationScriptError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Create the Register Node script for all the nodes intended for a specific Cluster. You will then run the script on each hardware unit that is intended for that Cluster. The script creates a Node in the specified Cluster. It then binds the Node to this hardware unit, and activates the node hardware for use with MediaLive Anywhere.
 */
export declare const createNodeRegistrationScript: API.OperationMethod<CreateNodeRegistrationScriptRequest, CreateNodeRegistrationScriptResponse, CreateNodeRegistrationScriptError, Credentials | HttpClient.HttpClient>;
export type CreatePartnerInputError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Create a partner input
 */
export declare const createPartnerInput: API.OperationMethod<CreatePartnerInputRequest, CreatePartnerInputResponse, CreatePartnerInputError, Credentials | HttpClient.HttpClient>;
export type CreateSdiSourceError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Create an SdiSource for each video source that uses the SDI protocol. You will reference the SdiSource when you create an SDI input in MediaLive. You will also reference it in an SdiSourceMapping, in order to create a connection between the logical SdiSource and the physical SDI card and port that the physical SDI source uses.
 */
export declare const createSdiSource: API.OperationMethod<CreateSdiSourceRequest, CreateSdiSourceResponse, CreateSdiSourceError, Credentials | HttpClient.HttpClient>;
export type CreateSignalMapError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Initiates the creation of a new signal map. Will discover a new mediaResourceMap based on the provided discoveryEntryPointArn.
 */
export declare const createSignalMap: API.OperationMethod<CreateSignalMapRequest, CreateSignalMapResponse, CreateSignalMapError, Credentials | HttpClient.HttpClient>;
export type CreateTagsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Create tags for a resource
 */
export declare const createTags: API.OperationMethod<CreateTagsRequest, CreateTagsResponse, CreateTagsError, Credentials | HttpClient.HttpClient>;
export type DeleteChannelError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Starts deletion of channel. The associated outputs are also deleted.
 */
export declare const deleteChannel: API.OperationMethod<DeleteChannelRequest, DeleteChannelResponse, DeleteChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteChannelPlacementGroupError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete the specified ChannelPlacementGroup that exists in the specified Cluster.
 */
export declare const deleteChannelPlacementGroup: API.OperationMethod<DeleteChannelPlacementGroupRequest, DeleteChannelPlacementGroupResponse, DeleteChannelPlacementGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteCloudWatchAlarmTemplateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a cloudwatch alarm template.
 */
export declare const deleteCloudWatchAlarmTemplate: API.OperationMethod<DeleteCloudWatchAlarmTemplateRequest, DeleteCloudWatchAlarmTemplateResponse, DeleteCloudWatchAlarmTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteCloudWatchAlarmTemplateGroupError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a cloudwatch alarm template group. You must detach this group from all signal maps and ensure its existing templates are moved to another group or deleted.
 */
export declare const deleteCloudWatchAlarmTemplateGroup: API.OperationMethod<DeleteCloudWatchAlarmTemplateGroupRequest, DeleteCloudWatchAlarmTemplateGroupResponse, DeleteCloudWatchAlarmTemplateGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete a Cluster. The Cluster must be idle.
 */
export declare const deleteCluster: API.OperationMethod<DeleteClusterRequest, DeleteClusterResponse, DeleteClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteEventBridgeRuleTemplateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an eventbridge rule template.
 */
export declare const deleteEventBridgeRuleTemplate: API.OperationMethod<DeleteEventBridgeRuleTemplateRequest, DeleteEventBridgeRuleTemplateResponse, DeleteEventBridgeRuleTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteEventBridgeRuleTemplateGroupError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an eventbridge rule template group. You must detach this group from all signal maps and ensure its existing templates are moved to another group or deleted.
 */
export declare const deleteEventBridgeRuleTemplateGroup: API.OperationMethod<DeleteEventBridgeRuleTemplateGroupRequest, DeleteEventBridgeRuleTemplateGroupResponse, DeleteEventBridgeRuleTemplateGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteInputError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the input end point
 */
export declare const deleteInput: API.OperationMethod<DeleteInputRequest, DeleteInputResponse, DeleteInputError, Credentials | HttpClient.HttpClient>;
export type DeleteInputSecurityGroupError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an Input Security Group
 */
export declare const deleteInputSecurityGroup: API.OperationMethod<DeleteInputSecurityGroupRequest, DeleteInputSecurityGroupResponse, DeleteInputSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteMultiplexError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete a multiplex. The multiplex must be idle.
 */
export declare const deleteMultiplex: API.OperationMethod<DeleteMultiplexRequest, DeleteMultiplexResponse, DeleteMultiplexError, Credentials | HttpClient.HttpClient>;
export type DeleteMultiplexProgramError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete a program from a multiplex.
 */
export declare const deleteMultiplexProgram: API.OperationMethod<DeleteMultiplexProgramRequest, DeleteMultiplexProgramResponse, DeleteMultiplexProgramError, Credentials | HttpClient.HttpClient>;
export type DeleteNetworkError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete a Network. The Network must have no resources associated with it.
 */
export declare const deleteNetwork: API.OperationMethod<DeleteNetworkRequest, DeleteNetworkResponse, DeleteNetworkError, Credentials | HttpClient.HttpClient>;
export type DeleteNodeError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete a Node. The Node must be IDLE.
 */
export declare const deleteNode: API.OperationMethod<DeleteNodeRequest, DeleteNodeResponse, DeleteNodeError, Credentials | HttpClient.HttpClient>;
export type DeleteReservationError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete an expired reservation.
 */
export declare const deleteReservation: API.OperationMethod<DeleteReservationRequest, DeleteReservationResponse, DeleteReservationError, Credentials | HttpClient.HttpClient>;
export type DeleteScheduleError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete all schedule actions on a channel.
 */
export declare const deleteSchedule: API.OperationMethod<DeleteScheduleRequest, DeleteScheduleResponse, DeleteScheduleError, Credentials | HttpClient.HttpClient>;
export type DeleteSdiSourceError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete an SdiSource. The SdiSource must not be part of any SidSourceMapping and must not be attached to any input.
 */
export declare const deleteSdiSource: API.OperationMethod<DeleteSdiSourceRequest, DeleteSdiSourceResponse, DeleteSdiSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteSignalMapError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the specified signal map.
 */
export declare const deleteSignalMap: API.OperationMethod<DeleteSignalMapRequest, DeleteSignalMapResponse, DeleteSignalMapError, Credentials | HttpClient.HttpClient>;
export type DeleteTagsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Removes tags for a resource
 */
export declare const deleteTags: API.OperationMethod<DeleteTagsRequest, DeleteTagsResponse, DeleteTagsError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountConfigurationError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Describe account configuration
 */
export declare const describeAccountConfiguration: API.OperationMethod<DescribeAccountConfigurationRequest, DescribeAccountConfigurationResponse, DescribeAccountConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeChannelError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details about a channel
 */
export declare const describeChannel: API.OperationMethod<DescribeChannelRequest, DescribeChannelResponse, DescribeChannelError, Credentials | HttpClient.HttpClient>;
export type DescribeChannelPlacementGroupError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get details about a ChannelPlacementGroup.
 */
export declare const describeChannelPlacementGroup: API.OperationMethod<DescribeChannelPlacementGroupRequest, DescribeChannelPlacementGroupResponse, DescribeChannelPlacementGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeClusterError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get details about a Cluster.
 */
export declare const describeCluster: API.OperationMethod<DescribeClusterRequest, DescribeClusterResponse, DescribeClusterError, Credentials | HttpClient.HttpClient>;
export type DescribeInputError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Produces details about an input
 */
export declare const describeInput: API.OperationMethod<DescribeInputRequest, DescribeInputResponse, DescribeInputError, Credentials | HttpClient.HttpClient>;
export type DescribeInputDeviceError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the details for the input device
 */
export declare const describeInputDevice: API.OperationMethod<DescribeInputDeviceRequest, DescribeInputDeviceResponse, DescribeInputDeviceError, Credentials | HttpClient.HttpClient>;
export type DescribeInputDeviceThumbnailError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get the latest thumbnail data for the input device.
 */
export declare const describeInputDeviceThumbnail: API.OperationMethod<DescribeInputDeviceThumbnailRequest, DescribeInputDeviceThumbnailResponse, DescribeInputDeviceThumbnailError, Credentials | HttpClient.HttpClient>;
export type DescribeInputSecurityGroupError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Produces a summary of an Input Security Group
 */
export declare const describeInputSecurityGroup: API.OperationMethod<DescribeInputSecurityGroupRequest, DescribeInputSecurityGroupResponse, DescribeInputSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeMultiplexError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details about a multiplex.
 */
export declare const describeMultiplex: API.OperationMethod<DescribeMultiplexRequest, DescribeMultiplexResponse, DescribeMultiplexError, Credentials | HttpClient.HttpClient>;
export type DescribeMultiplexProgramError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get the details for a program in a multiplex.
 */
export declare const describeMultiplexProgram: API.OperationMethod<DescribeMultiplexProgramRequest, DescribeMultiplexProgramResponse, DescribeMultiplexProgramError, Credentials | HttpClient.HttpClient>;
export type DescribeNetworkError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get details about a Network.
 */
export declare const describeNetwork: API.OperationMethod<DescribeNetworkRequest, DescribeNetworkResponse, DescribeNetworkError, Credentials | HttpClient.HttpClient>;
export type DescribeNodeError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get details about a Node in the specified Cluster.
 */
export declare const describeNode: API.OperationMethod<DescribeNodeRequest, DescribeNodeResponse, DescribeNodeError, Credentials | HttpClient.HttpClient>;
export type DescribeOfferingError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get details for an offering.
 */
export declare const describeOffering: API.OperationMethod<DescribeOfferingRequest, DescribeOfferingResponse, DescribeOfferingError, Credentials | HttpClient.HttpClient>;
export type DescribeReservationError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get details for a reservation.
 */
export declare const describeReservation: API.OperationMethod<DescribeReservationRequest, DescribeReservationResponse, DescribeReservationError, Credentials | HttpClient.HttpClient>;
export type DescribeScheduleError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get a channel schedule
 */
export declare const describeSchedule: API.PaginatedOperationMethod<DescribeScheduleRequest, DescribeScheduleResponse, DescribeScheduleError, Credentials | HttpClient.HttpClient, ScheduleAction>;
export type DescribeSdiSourceError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details about a SdiSource.
 */
export declare const describeSdiSource: API.OperationMethod<DescribeSdiSourceRequest, DescribeSdiSourceResponse, DescribeSdiSourceError, Credentials | HttpClient.HttpClient>;
export type DescribeThumbnailsError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Describe the latest thumbnails data.
 */
export declare const describeThumbnails: API.OperationMethod<DescribeThumbnailsRequest, DescribeThumbnailsResponse, DescribeThumbnailsError, Credentials | HttpClient.HttpClient>;
export type GetCloudWatchAlarmTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the specified cloudwatch alarm template.
 */
export declare const getCloudWatchAlarmTemplate: API.OperationMethod<GetCloudWatchAlarmTemplateRequest, GetCloudWatchAlarmTemplateResponse, GetCloudWatchAlarmTemplateError, Credentials | HttpClient.HttpClient>;
export type GetCloudWatchAlarmTemplateGroupError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the specified cloudwatch alarm template group.
 */
export declare const getCloudWatchAlarmTemplateGroup: API.OperationMethod<GetCloudWatchAlarmTemplateGroupRequest, GetCloudWatchAlarmTemplateGroupResponse, GetCloudWatchAlarmTemplateGroupError, Credentials | HttpClient.HttpClient>;
export type GetEventBridgeRuleTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the specified eventbridge rule template.
 */
export declare const getEventBridgeRuleTemplate: API.OperationMethod<GetEventBridgeRuleTemplateRequest, GetEventBridgeRuleTemplateResponse, GetEventBridgeRuleTemplateError, Credentials | HttpClient.HttpClient>;
export type GetEventBridgeRuleTemplateGroupError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the specified eventbridge rule template group.
 */
export declare const getEventBridgeRuleTemplateGroup: API.OperationMethod<GetEventBridgeRuleTemplateGroupRequest, GetEventBridgeRuleTemplateGroupResponse, GetEventBridgeRuleTemplateGroupError, Credentials | HttpClient.HttpClient>;
export type GetSignalMapError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the specified signal map.
 */
export declare const getSignalMap: API.OperationMethod<GetSignalMapRequest, GetSignalMapResponse, GetSignalMapError, Credentials | HttpClient.HttpClient>;
export type ListAlertsError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * List the alerts for a channel with optional filtering based on alert state.
 */
export declare const listAlerts: API.PaginatedOperationMethod<ListAlertsRequest, ListAlertsResponse, ListAlertsError, Credentials | HttpClient.HttpClient, ChannelAlert>;
export type ListChannelPlacementGroupsError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the list of ChannelPlacementGroups in the specified Cluster.
 */
export declare const listChannelPlacementGroups: API.PaginatedOperationMethod<ListChannelPlacementGroupsRequest, ListChannelPlacementGroupsResponse, ListChannelPlacementGroupsError, Credentials | HttpClient.HttpClient, DescribeChannelPlacementGroupSummary>;
export type ListChannelsError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Produces list of channels that have been created
 */
export declare const listChannels: API.PaginatedOperationMethod<ListChannelsRequest, ListChannelsResponse, ListChannelsError, Credentials | HttpClient.HttpClient, ChannelSummary>;
export type ListCloudWatchAlarmTemplateGroupsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists cloudwatch alarm template groups.
 */
export declare const listCloudWatchAlarmTemplateGroups: API.PaginatedOperationMethod<ListCloudWatchAlarmTemplateGroupsRequest, ListCloudWatchAlarmTemplateGroupsResponse, ListCloudWatchAlarmTemplateGroupsError, Credentials | HttpClient.HttpClient, CloudWatchAlarmTemplateGroupSummary>;
export type ListCloudWatchAlarmTemplatesError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists cloudwatch alarm templates.
 */
export declare const listCloudWatchAlarmTemplates: API.PaginatedOperationMethod<ListCloudWatchAlarmTemplatesRequest, ListCloudWatchAlarmTemplatesResponse, ListCloudWatchAlarmTemplatesError, Credentials | HttpClient.HttpClient, CloudWatchAlarmTemplateSummary>;
export type ListClusterAlertsError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * List the alerts for a cluster with optional filtering based on alert state.
 */
export declare const listClusterAlerts: API.PaginatedOperationMethod<ListClusterAlertsRequest, ListClusterAlertsResponse, ListClusterAlertsError, Credentials | HttpClient.HttpClient, ClusterAlert>;
export type ListClustersError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the list of Clusters.
 */
export declare const listClusters: API.PaginatedOperationMethod<ListClustersRequest, ListClustersResponse, ListClustersError, Credentials | HttpClient.HttpClient, DescribeClusterSummary>;
export type ListEventBridgeRuleTemplateGroupsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists eventbridge rule template groups.
 */
export declare const listEventBridgeRuleTemplateGroups: API.PaginatedOperationMethod<ListEventBridgeRuleTemplateGroupsRequest, ListEventBridgeRuleTemplateGroupsResponse, ListEventBridgeRuleTemplateGroupsError, Credentials | HttpClient.HttpClient, EventBridgeRuleTemplateGroupSummary>;
export type ListEventBridgeRuleTemplatesError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists eventbridge rule templates.
 */
export declare const listEventBridgeRuleTemplates: API.PaginatedOperationMethod<ListEventBridgeRuleTemplatesRequest, ListEventBridgeRuleTemplatesResponse, ListEventBridgeRuleTemplatesError, Credentials | HttpClient.HttpClient, EventBridgeRuleTemplateSummary>;
export type ListInputDevicesError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * List input devices
 */
export declare const listInputDevices: API.PaginatedOperationMethod<ListInputDevicesRequest, ListInputDevicesResponse, ListInputDevicesError, Credentials | HttpClient.HttpClient, InputDeviceSummary>;
export type ListInputDeviceTransfersError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * List input devices that are currently being transferred. List input devices that you are transferring from your AWS account or input devices that another AWS account is transferring to you.
 */
export declare const listInputDeviceTransfers: API.PaginatedOperationMethod<ListInputDeviceTransfersRequest, ListInputDeviceTransfersResponse, ListInputDeviceTransfersError, Credentials | HttpClient.HttpClient, TransferringInputDeviceSummary>;
export type ListInputsError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Produces list of inputs that have been created
 */
export declare const listInputs: API.PaginatedOperationMethod<ListInputsRequest, ListInputsResponse, ListInputsError, Credentials | HttpClient.HttpClient, Input>;
export type ListInputSecurityGroupsError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Produces a list of Input Security Groups for an account
 */
export declare const listInputSecurityGroups: API.PaginatedOperationMethod<ListInputSecurityGroupsRequest, ListInputSecurityGroupsResponse, ListInputSecurityGroupsError, Credentials | HttpClient.HttpClient, InputSecurityGroup>;
export type ListMultiplexAlertsError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * List the alerts for a multiplex with optional filtering based on alert state.
 */
export declare const listMultiplexAlerts: API.PaginatedOperationMethod<ListMultiplexAlertsRequest, ListMultiplexAlertsResponse, ListMultiplexAlertsError, Credentials | HttpClient.HttpClient, MultiplexAlert>;
export type ListMultiplexesError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a list of the existing multiplexes.
 */
export declare const listMultiplexes: API.PaginatedOperationMethod<ListMultiplexesRequest, ListMultiplexesResponse, ListMultiplexesError, Credentials | HttpClient.HttpClient, MultiplexSummary>;
export type ListMultiplexProgramsError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * List the programs that currently exist for a specific multiplex.
 */
export declare const listMultiplexPrograms: API.PaginatedOperationMethod<ListMultiplexProgramsRequest, ListMultiplexProgramsResponse, ListMultiplexProgramsError, Credentials | HttpClient.HttpClient, MultiplexProgramSummary>;
export type ListNetworksError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the list of Networks.
 */
export declare const listNetworks: API.PaginatedOperationMethod<ListNetworksRequest, ListNetworksResponse, ListNetworksError, Credentials | HttpClient.HttpClient, DescribeNetworkSummary>;
export type ListNodesError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the list of Nodes.
 */
export declare const listNodes: API.PaginatedOperationMethod<ListNodesRequest, ListNodesResponse, ListNodesError, Credentials | HttpClient.HttpClient, DescribeNodeSummary>;
export type ListOfferingsError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * List offerings available for purchase.
 */
export declare const listOfferings: API.PaginatedOperationMethod<ListOfferingsRequest, ListOfferingsResponse, ListOfferingsError, Credentials | HttpClient.HttpClient, Offering>;
export type ListReservationsError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * List purchased reservations.
 */
export declare const listReservations: API.PaginatedOperationMethod<ListReservationsRequest, ListReservationsResponse, ListReservationsError, Credentials | HttpClient.HttpClient, Reservation>;
export type ListSdiSourcesError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * List all the SdiSources in the AWS account.
 */
export declare const listSdiSources: API.PaginatedOperationMethod<ListSdiSourcesRequest, ListSdiSourcesResponse, ListSdiSourcesError, Credentials | HttpClient.HttpClient, SdiSourceSummary>;
export type ListSignalMapsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists signal maps.
 */
export declare const listSignalMaps: API.PaginatedOperationMethod<ListSignalMapsRequest, ListSignalMapsResponse, ListSignalMapsError, Credentials | HttpClient.HttpClient, SignalMapSummary>;
export type ListTagsForResourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Produces list of tags that have been created for a resource
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVersionsError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves an array of all the encoder engine versions that are available in this AWS account.
 */
export declare const listVersions: API.OperationMethod<ListVersionsRequest, ListVersionsResponse, ListVersionsError, Credentials | HttpClient.HttpClient>;
export type PurchaseOfferingError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Purchase an offering and create a reservation.
 */
export declare const purchaseOffering: API.OperationMethod<PurchaseOfferingRequest, PurchaseOfferingResponse, PurchaseOfferingError, Credentials | HttpClient.HttpClient>;
export type RebootInputDeviceError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Send a reboot command to the specified input device. The device will begin rebooting within a few seconds of sending the command. When the reboot is complete, the device's connection status will change to connected.
 */
export declare const rebootInputDevice: API.OperationMethod<RebootInputDeviceRequest, RebootInputDeviceResponse, RebootInputDeviceError, Credentials | HttpClient.HttpClient>;
export type RejectInputDeviceTransferError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Reject the transfer of the specified input device to your AWS account.
 */
export declare const rejectInputDeviceTransfer: API.OperationMethod<RejectInputDeviceTransferRequest, RejectInputDeviceTransferResponse, RejectInputDeviceTransferError, Credentials | HttpClient.HttpClient>;
export type RestartChannelPipelinesError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Restart pipelines in one channel that is currently running.
 */
export declare const restartChannelPipelines: API.OperationMethod<RestartChannelPipelinesRequest, RestartChannelPipelinesResponse, RestartChannelPipelinesError, Credentials | HttpClient.HttpClient>;
export type StartChannelError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Starts an existing channel
 */
export declare const startChannel: API.OperationMethod<StartChannelRequest, StartChannelResponse, StartChannelError, Credentials | HttpClient.HttpClient>;
export type StartDeleteMonitorDeploymentError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Initiates a deployment to delete the monitor of the specified signal map.
 */
export declare const startDeleteMonitorDeployment: API.OperationMethod<StartDeleteMonitorDeploymentRequest, StartDeleteMonitorDeploymentResponse, StartDeleteMonitorDeploymentError, Credentials | HttpClient.HttpClient>;
export type StartInputDeviceError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Start an input device that is attached to a MediaConnect flow. (There is no need to start a device that is attached to a MediaLive input; MediaLive starts the device when the channel starts.)
 */
export declare const startInputDevice: API.OperationMethod<StartInputDeviceRequest, StartInputDeviceResponse, StartInputDeviceError, Credentials | HttpClient.HttpClient>;
export type StartInputDeviceMaintenanceWindowError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Start a maintenance window for the specified input device. Starting a maintenance window will give the device up to two hours to install software. If the device was streaming prior to the maintenance, it will resume streaming when the software is fully installed. Devices automatically install updates while they are powered on and their MediaLive channels are stopped. A maintenance window allows you to update a device without having to stop MediaLive channels that use the device. The device must remain powered on and connected to the internet for the duration of the maintenance.
 */
export declare const startInputDeviceMaintenanceWindow: API.OperationMethod<StartInputDeviceMaintenanceWindowRequest, StartInputDeviceMaintenanceWindowResponse, StartInputDeviceMaintenanceWindowError, Credentials | HttpClient.HttpClient>;
export type StartMonitorDeploymentError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Initiates a deployment to deploy the latest monitor of the specified signal map.
 */
export declare const startMonitorDeployment: API.OperationMethod<StartMonitorDeploymentRequest, StartMonitorDeploymentResponse, StartMonitorDeploymentError, Credentials | HttpClient.HttpClient>;
export type StartMultiplexError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Start (run) the multiplex. Starting the multiplex does not start the channels. You must explicitly start each channel.
 */
export declare const startMultiplex: API.OperationMethod<StartMultiplexRequest, StartMultiplexResponse, StartMultiplexError, Credentials | HttpClient.HttpClient>;
export type StartUpdateSignalMapError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Initiates an update for the specified signal map. Will discover a new signal map if a changed discoveryEntryPointArn is provided.
 */
export declare const startUpdateSignalMap: API.OperationMethod<StartUpdateSignalMapRequest, StartUpdateSignalMapResponse, StartUpdateSignalMapError, Credentials | HttpClient.HttpClient>;
export type StopChannelError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Stops a running channel
 */
export declare const stopChannel: API.OperationMethod<StopChannelRequest, StopChannelResponse, StopChannelError, Credentials | HttpClient.HttpClient>;
export type StopInputDeviceError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Stop an input device that is attached to a MediaConnect flow. (There is no need to stop a device that is attached to a MediaLive input; MediaLive automatically stops the device when the channel stops.)
 */
export declare const stopInputDevice: API.OperationMethod<StopInputDeviceRequest, StopInputDeviceResponse, StopInputDeviceError, Credentials | HttpClient.HttpClient>;
export type StopMultiplexError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Stops a running multiplex. If the multiplex isn't running, this action has no effect.
 */
export declare const stopMultiplex: API.OperationMethod<StopMultiplexRequest, StopMultiplexResponse, StopMultiplexError, Credentials | HttpClient.HttpClient>;
export type TransferInputDeviceError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Start an input device transfer to another AWS account. After you make the request, the other account must accept or reject the transfer.
 */
export declare const transferInputDevice: API.OperationMethod<TransferInputDeviceRequest, TransferInputDeviceResponse, TransferInputDeviceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountConfigurationError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Update account configuration
 */
export declare const updateAccountConfiguration: API.OperationMethod<UpdateAccountConfigurationRequest, UpdateAccountConfigurationResponse, UpdateAccountConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | UnprocessableEntityException | CommonErrors;
/**
 * Updates a channel.
 */
export declare const updateChannel: API.OperationMethod<UpdateChannelRequest, UpdateChannelResponse, UpdateChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelClassError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Changes the class of the channel.
 */
export declare const updateChannelClass: API.OperationMethod<UpdateChannelClassRequest, UpdateChannelClassResponse, UpdateChannelClassError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelPlacementGroupError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Change the settings for a ChannelPlacementGroup.
 */
export declare const updateChannelPlacementGroup: API.OperationMethod<UpdateChannelPlacementGroupRequest, UpdateChannelPlacementGroupResponse, UpdateChannelPlacementGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateCloudWatchAlarmTemplateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the specified cloudwatch alarm template.
 */
export declare const updateCloudWatchAlarmTemplate: API.OperationMethod<UpdateCloudWatchAlarmTemplateRequest, UpdateCloudWatchAlarmTemplateResponse, UpdateCloudWatchAlarmTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateCloudWatchAlarmTemplateGroupError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the specified cloudwatch alarm template group.
 */
export declare const updateCloudWatchAlarmTemplateGroup: API.OperationMethod<UpdateCloudWatchAlarmTemplateGroupRequest, UpdateCloudWatchAlarmTemplateGroupResponse, UpdateCloudWatchAlarmTemplateGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Change the settings for a Cluster.
 */
export declare const updateCluster: API.OperationMethod<UpdateClusterRequest, UpdateClusterResponse, UpdateClusterError, Credentials | HttpClient.HttpClient>;
export type UpdateEventBridgeRuleTemplateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the specified eventbridge rule template.
 */
export declare const updateEventBridgeRuleTemplate: API.OperationMethod<UpdateEventBridgeRuleTemplateRequest, UpdateEventBridgeRuleTemplateResponse, UpdateEventBridgeRuleTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateEventBridgeRuleTemplateGroupError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the specified eventbridge rule template group.
 */
export declare const updateEventBridgeRuleTemplateGroup: API.OperationMethod<UpdateEventBridgeRuleTemplateGroupRequest, UpdateEventBridgeRuleTemplateGroupResponse, UpdateEventBridgeRuleTemplateGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateInputError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Updates an input.
 */
export declare const updateInput: API.OperationMethod<UpdateInputRequest, UpdateInputResponse, UpdateInputError, Credentials | HttpClient.HttpClient>;
export type UpdateInputDeviceError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Updates the parameters for the input device.
 */
export declare const updateInputDevice: API.OperationMethod<UpdateInputDeviceRequest, UpdateInputDeviceResponse, UpdateInputDeviceError, Credentials | HttpClient.HttpClient>;
export type UpdateInputSecurityGroupError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Update an Input Security Group's Whilelists.
 */
export declare const updateInputSecurityGroup: API.OperationMethod<UpdateInputSecurityGroupRequest, UpdateInputSecurityGroupResponse, UpdateInputSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateMultiplexError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | UnprocessableEntityException | CommonErrors;
/**
 * Updates a multiplex.
 */
export declare const updateMultiplex: API.OperationMethod<UpdateMultiplexRequest, UpdateMultiplexResponse, UpdateMultiplexError, Credentials | HttpClient.HttpClient>;
export type UpdateMultiplexProgramError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | UnprocessableEntityException | CommonErrors;
/**
 * Update a program in a multiplex.
 */
export declare const updateMultiplexProgram: API.OperationMethod<UpdateMultiplexProgramRequest, UpdateMultiplexProgramResponse, UpdateMultiplexProgramError, Credentials | HttpClient.HttpClient>;
export type UpdateNetworkError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Change the settings for a Network.
 */
export declare const updateNetwork: API.OperationMethod<UpdateNetworkRequest, UpdateNetworkResponse, UpdateNetworkError, Credentials | HttpClient.HttpClient>;
export type UpdateNodeError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Change the settings for a Node.
 */
export declare const updateNode: API.OperationMethod<UpdateNodeRequest, UpdateNodeResponse, UpdateNodeError, Credentials | HttpClient.HttpClient>;
export type UpdateNodeStateError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Update the state of a node.
 */
export declare const updateNodeState: API.OperationMethod<UpdateNodeStateRequest, UpdateNodeStateResponse, UpdateNodeStateError, Credentials | HttpClient.HttpClient>;
export type UpdateReservationError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Update reservation.
 */
export declare const updateReservation: API.OperationMethod<UpdateReservationRequest, UpdateReservationResponse, UpdateReservationError, Credentials | HttpClient.HttpClient>;
export type UpdateSdiSourceError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Change some of the settings in an SdiSource.
 */
export declare const updateSdiSource: API.OperationMethod<UpdateSdiSourceRequest, UpdateSdiSourceResponse, UpdateSdiSourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=medialive.d.ts.map