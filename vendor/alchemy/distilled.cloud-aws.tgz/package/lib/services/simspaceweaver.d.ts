import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema";
import * as HttpClient from "effect/http/HttpClient";
import * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SimSpaceWeaverResourceName = string;
export type BucketName = string;
export type ObjectKeyPrefix = string;
export interface S3Destination {
    BucketName: string;
    ObjectKeyPrefix?: string;
}
export interface CreateSnapshotInput {
    Simulation: string;
    Destination: S3Destination;
}
export interface CreateSnapshotOutput {
}
export interface DeleteAppInput {
    Simulation: string;
    Domain: string;
    App: string;
}
export interface DeleteAppOutput {
}
export interface DeleteSimulationInput {
    Simulation: string;
}
export interface DeleteSimulationOutput {
}
export type SimSpaceWeaverLongResourceName = string;
export interface DescribeAppInput {
    Simulation: string;
    Domain: string;
    App: string;
}
export type SimulationAppStatus = string;
export type SimulationAppTargetStatus = string;
export type NonEmptyString = string;
export type LaunchCommandList = string[];
export interface LaunchOverrides {
    LaunchCommands?: string[];
}
export type Description = string;
export type PortNumber = number;
export interface SimulationAppPortMapping {
    Declared?: number;
    Actual?: number;
}
export type AppPortMappings = SimulationAppPortMapping[];
export interface SimulationAppEndpointInfo {
    Address?: string;
    IngressPortMappings?: SimulationAppPortMapping[];
}
export interface DescribeAppOutput {
    Name?: string;
    Simulation?: string;
    Domain?: string;
    Status?: string;
    TargetStatus?: string;
    LaunchOverrides?: LaunchOverrides;
    Description?: string;
    EndpointInfo?: SimulationAppEndpointInfo;
}
export interface DescribeSimulationInput {
    Simulation: string;
}
export type UUID = string;
export type SimSpaceWeaverArn = string;
export type RoleArn = string;
export type SimulationStatus = string;
export type SimulationTargetStatus = string;
export type ObjectKey = string;
export interface S3Location {
    BucketName: string;
    ObjectKey: string;
}
export type OptionalString = string;
export type LogGroupArn = string;
export interface CloudWatchLogsLogGroup {
    LogGroupArn?: string;
}
export interface LogDestination {
    CloudWatchLogsLogGroup?: CloudWatchLogsLogGroup;
}
export type LogDestinations = LogDestination[];
export interface LoggingConfiguration {
    Destinations?: LogDestination[];
}
export type LifecycleManagementStrategy = string;
export interface Domain {
    Name?: string;
    Lifecycle?: string;
}
export type DomainList = Domain[];
export type ClockStatus = string;
export type ClockTargetStatus = string;
export interface SimulationClock {
    Status?: string;
    TargetStatus?: string;
}
export type SimulationClockList = SimulationClock[];
export interface LiveSimulationState {
    Domains?: Domain[];
    Clocks?: SimulationClock[];
}
export type TimeToLiveString = string;
export interface DescribeSimulationOutput {
    Name?: string;
    ExecutionId?: string;
    Arn?: string;
    Description?: string;
    RoleArn?: string;
    CreationTime?: Date;
    Status?: string;
    TargetStatus?: string;
    SchemaS3Location?: S3Location;
    SchemaError?: string;
    LoggingConfiguration?: LoggingConfiguration;
    LiveSimulationState?: LiveSimulationState;
    MaximumDuration?: string;
    SnapshotS3Location?: S3Location;
    StartError?: string;
}
export type PositiveInteger = number;
export interface ListAppsInput {
    Simulation: string;
    Domain?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface SimulationAppMetadata {
    Name?: string;
    Simulation?: string;
    Domain?: string;
    Status?: string;
    TargetStatus?: string;
}
export type SimulationAppList = SimulationAppMetadata[];
export interface ListAppsOutput {
    Apps?: SimulationAppMetadata[];
    NextToken?: string;
}
export interface ListSimulationsInput {
    MaxResults?: number;
    NextToken?: string;
}
export interface SimulationMetadata {
    Name?: string;
    Arn?: string;
    CreationTime?: Date;
    Status?: string;
    TargetStatus?: string;
}
export type SimulationList = SimulationMetadata[];
export interface ListSimulationsOutput {
    Simulations?: SimulationMetadata[];
    NextToken?: string;
}
export interface ListTagsForResourceInput {
    ResourceArn: string;
}
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface ListTagsForResourceOutput {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type ClientToken = string | redacted.Redacted<string>;
export interface StartAppInput {
    ClientToken?: string | redacted.Redacted<string>;
    Simulation: string;
    Domain: string;
    Name: string;
    Description?: string;
    LaunchOverrides?: LaunchOverrides;
}
export interface StartAppOutput {
    Name?: string;
    Domain?: string;
    Simulation?: string;
}
export interface StartClockInput {
    Simulation: string;
}
export interface StartClockOutput {
}
export interface StartSimulationInput {
    ClientToken?: string | redacted.Redacted<string>;
    Name: string;
    Description?: string;
    RoleArn: string;
    SchemaS3Location?: S3Location;
    MaximumDuration?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    SnapshotS3Location?: S3Location;
}
export interface StartSimulationOutput {
    Arn?: string;
    ExecutionId?: string;
    CreationTime?: Date;
}
export interface StopAppInput {
    Simulation: string;
    Domain: string;
    App: string;
}
export interface StopAppOutput {
}
export interface StopClockInput {
    Simulation: string;
}
export interface StopClockOutput {
}
export interface StopSimulationInput {
    Simulation: string;
}
export interface StopSimulationOutput {
}
export interface TagResourceInput {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceOutput {
}
export type CreateSnapshotError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates a snapshot of the specified simulation.
 * A snapshot is a file that contains simulation state data at a specific time.
 * The state data saved in a snapshot includes entity data from the State Fabric,
 * the simulation configuration specified in the schema, and the clock tick number.
 * You can use the snapshot to initialize a new simulation.
 * For more information about snapshots, see Snapshots
 * in the *SimSpace Weaver User Guide*.
 *
 * You specify a `Destination` when you create a snapshot.
 * The `Destination` is the name of an Amazon S3 bucket and an optional
 * `ObjectKeyPrefix`. The `ObjectKeyPrefix` is
 * usually the name of a folder in the bucket. SimSpace Weaver creates a
 * `snapshot` folder inside the `Destination` and
 * places the snapshot file there.
 *
 * The snapshot file is an Amazon S3 object. It has an object key with the
 * form:
 * *object-key-prefix*\/snapshot/*simulation-name*-*YYMMdd*-*HHmm*-*ss*.zip, where:
 *
 * -
 * *YY*
 * is the 2-digit year
 *
 * -
 * *MM*
 * is the 2-digit month
 *
 * -
 * *dd*
 * is the 2-digit day of the month
 *
 * -
 * *HH*
 * is the 2-digit hour (24-hour clock)
 *
 * -
 * *mm*
 * is the 2-digit minutes
 *
 * -
 * *ss*
 * is the 2-digit seconds
 */
export declare const createSnapshot: API.OperationMethod<CreateSnapshotInput, CreateSnapshotOutput, CreateSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteAppError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the instance of the given custom app.
 */
export declare const deleteApp: API.OperationMethod<DeleteAppInput, DeleteAppOutput, DeleteAppError, Credentials | HttpClient.HttpClient>;
export type DeleteSimulationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes all SimSpace Weaver resources assigned to the given simulation.
 *
 * Your simulation uses resources in other Amazon Web Services. This API operation doesn't delete
 * resources in other Amazon Web Services.
 */
export declare const deleteSimulation: API.OperationMethod<DeleteSimulationInput, DeleteSimulationOutput, DeleteSimulationError, Credentials | HttpClient.HttpClient>;
export type DescribeAppError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the state of the given custom app.
 */
export declare const describeApp: API.OperationMethod<DescribeAppInput, DescribeAppOutput, DescribeAppError, Credentials | HttpClient.HttpClient>;
export type DescribeSimulationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the current state of the given simulation.
 */
export declare const describeSimulation: API.OperationMethod<DescribeSimulationInput, DescribeSimulationOutput, DescribeSimulationError, Credentials | HttpClient.HttpClient>;
export type ListAppsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all custom apps or service apps for the given simulation and domain.
 */
export declare const listApps: API.PaginatedOperationMethod<ListAppsInput, ListAppsOutput, ListAppsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSimulationsError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Lists the SimSpace Weaver simulations in the Amazon Web Services account used to make the API call.
 */
export declare const listSimulations: API.PaginatedOperationMethod<ListSimulationsInput, ListSimulationsOutput, ListSimulationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all tags on a SimSpace Weaver resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartAppError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Starts a custom app with the configuration specified in the simulation schema.
 */
export declare const startApp: API.OperationMethod<StartAppInput, StartAppOutput, StartAppError, Credentials | HttpClient.HttpClient>;
export type StartClockError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Starts the simulation clock.
 */
export declare const startClock: API.OperationMethod<StartClockInput, StartClockOutput, StartClockError, Credentials | HttpClient.HttpClient>;
export type StartSimulationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Starts a simulation with the given name. You must choose to start your
 * simulation from a schema or from a snapshot.
 * For more information about the schema, see the schema reference
 * in the *SimSpace Weaver User Guide*.
 * For more information about snapshots, see Snapshots
 * in the *SimSpace Weaver User Guide*.
 */
export declare const startSimulation: API.OperationMethod<StartSimulationInput, StartSimulationOutput, StartSimulationError, Credentials | HttpClient.HttpClient>;
export type StopAppError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Stops the given custom app and shuts down all of its allocated compute resources.
 */
export declare const stopApp: API.OperationMethod<StopAppInput, StopAppOutput, StopAppError, Credentials | HttpClient.HttpClient>;
export type StopClockError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Stops the simulation clock.
 */
export declare const stopClock: API.OperationMethod<StopClockInput, StopClockOutput, StopClockError, Credentials | HttpClient.HttpClient>;
export type StopSimulationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Stops the given simulation.
 *
 * You can't restart a simulation after you stop it. If you want to restart a simulation, then
 * you must stop it, delete it, and start a new instance of it.
 */
export declare const stopSimulation: API.OperationMethod<StopSimulationInput, StopSimulationOutput, StopSimulationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Adds tags to a SimSpace Weaver resource. For more information about tags, see Tagging Amazon Web Services resources in the
 * *Amazon Web Services General Reference*.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes tags from a SimSpace Weaver resource. For more information about tags, see Tagging Amazon Web Services resources in the
 * *Amazon Web Services General Reference*.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=simspaceweaver.d.ts.map