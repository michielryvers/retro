import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials as Creds } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const EksClusterConnectionUpdating_base: S.TaggedErrorClass<"EksClusterConnectionUpdating", {
    readonly message: any;
}>;
export declare class EksClusterConnectionUpdating extends /*@__PURE__*/ EksClusterConnectionUpdating_base {
}
declare const EKSRequestThrottledException_base: S.TaggedErrorClass<"EKSRequestThrottledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class EKSRequestThrottledException extends /*@__PURE__*/ EKSRequestThrottledException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidResourceArn_base: S.TaggedErrorClass<"InvalidResourceArn", {
    readonly message: any;
}>;
export declare class InvalidResourceArn extends /*@__PURE__*/ InvalidResourceArn_base {
}
declare const RequestThrottledException_base: S.TaggedErrorClass<"RequestThrottledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RequestThrottledException extends /*@__PURE__*/ RequestThrottledException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ResourceIdString = string;
export interface CancelJobRunRequest {
    id: string;
    virtualClusterId: string;
}
export interface CancelJobRunResponse {
    id?: string;
    virtualClusterId?: string;
}
export type ResourceNameString = string;
export type ClientToken = string;
export type ParametricIAMRoleArn = string;
export type ParametricReleaseLabel = string;
export type String1024 = string;
export type SensitivePropertiesMap = {
    [key: string]: string | undefined;
};
export interface Configuration {
    classification: string;
    properties?: {
        [key: string]: string | undefined;
    };
    configurations?: Configuration[];
}
export type ConfigurationList = Configuration[];
export type TemplateParameter = string;
export type String256 = string;
export interface ParametricCloudWatchMonitoringConfiguration {
    logGroupName?: string;
    logStreamNamePrefix?: string;
}
export type UriString = string;
export interface ParametricS3MonitoringConfiguration {
    logUri?: string;
}
export interface ParametricMonitoringConfiguration {
    persistentAppUI?: string;
    cloudWatchMonitoringConfiguration?: ParametricCloudWatchMonitoringConfiguration;
    s3MonitoringConfiguration?: ParametricS3MonitoringConfiguration;
}
export interface ParametricConfigurationOverrides {
    applicationConfiguration?: Configuration[];
    monitoringConfiguration?: ParametricMonitoringConfiguration;
}
export type EntryPointPath = string | redacted.Redacted<string>;
export type EntryPointArgument = string | redacted.Redacted<string>;
export type EntryPointArguments = (string | redacted.Redacted<string>)[];
export type SparkSubmitParameters = string | redacted.Redacted<string>;
export interface SparkSubmitJobDriver {
    entryPoint: string | redacted.Redacted<string>;
    entryPointArguments?: (string | redacted.Redacted<string>)[];
    sparkSubmitParameters?: string | redacted.Redacted<string>;
}
export type SparkSqlParameters = string | redacted.Redacted<string>;
export interface SparkSqlJobDriver {
    entryPoint?: string | redacted.Redacted<string>;
    sparkSqlParameters?: string | redacted.Redacted<string>;
}
export interface JobDriver {
    sparkSubmitJobDriver?: SparkSubmitJobDriver;
    sparkSqlJobDriver?: SparkSqlJobDriver;
}
export type TemplateParameterName = string;
export type TemplateParameterDataType = "NUMBER" | "STRING" | (string & {});
export interface TemplateParameterConfiguration {
    type?: TemplateParameterDataType;
    defaultValue?: string;
}
export type TemplateParameterConfigurationMap = {
    [key: string]: TemplateParameterConfiguration | undefined;
};
export type String128 = string;
export type StringEmpty256 = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface JobTemplateData {
    executionRoleArn: string;
    releaseLabel: string;
    configurationOverrides?: ParametricConfigurationOverrides;
    jobDriver: JobDriver;
    parameterConfiguration?: {
        [key: string]: TemplateParameterConfiguration | undefined;
    };
    jobTags?: {
        [key: string]: string | undefined;
    };
}
export type KmsKeyArn = string;
export interface CreateJobTemplateRequest {
    name: string;
    clientToken: string;
    jobTemplateData: JobTemplateData;
    tags?: {
        [key: string]: string | undefined;
    };
    kmsKeyArn?: string;
}
export type JobTemplateArn = string;
export interface CreateJobTemplateResponse {
    id?: string;
    name?: string;
    arn?: string;
    createdAt?: Date;
}
export type EndpointType = string;
export type ReleaseLabel = string;
export type IAMRoleArn = string;
export type ACMCertArn = string;
export type AllowAWSToRetainLogs = "ENABLED" | "DISABLED" | (string & {});
export interface ManagedLogs {
    allowAWSToRetainLogs?: AllowAWSToRetainLogs;
    encryptionKeyArn?: string;
}
export type PersistentAppUI = "ENABLED" | "DISABLED" | (string & {});
export type LogGroupName = string;
export interface CloudWatchMonitoringConfiguration {
    logGroupName: string;
    logStreamNamePrefix?: string;
}
export interface S3MonitoringConfiguration {
    logUri: string;
    encryptionKeyArn?: string;
}
export type RotationSize = string;
export type MaxFilesToKeep = number;
export interface ContainerLogRotationConfiguration {
    rotationSize: string;
    maxFilesToKeep: number;
}
export interface MonitoringConfiguration {
    managedLogs?: ManagedLogs;
    persistentAppUI?: PersistentAppUI;
    cloudWatchMonitoringConfiguration?: CloudWatchMonitoringConfiguration;
    s3MonitoringConfiguration?: S3MonitoringConfiguration;
    containerLogRotationConfiguration?: ContainerLogRotationConfiguration;
}
export interface ConfigurationOverrides {
    applicationConfiguration?: Configuration[];
    monitoringConfiguration?: MonitoringConfiguration;
}
export type SessionIdleTimeoutInMinutes = number;
export interface CreateManagedEndpointRequest {
    name: string;
    virtualClusterId: string;
    type: string;
    releaseLabel: string;
    executionRoleArn: string;
    certificateArn?: string;
    configurationOverrides?: ConfigurationOverrides;
    clientToken: string;
    tags?: {
        [key: string]: string | undefined;
    };
    sessionIdleTimeoutInMinutes?: number;
}
export type EndpointArn = string;
export interface CreateManagedEndpointResponse {
    id?: string;
    name?: string;
    arn?: string;
    virtualClusterId?: string;
}
export type ContainerProviderType = "EKS" | (string & {});
export type ClusterId = string;
export type KubernetesNamespace = string;
export type NodeLabelString = string;
export interface EksInfo {
    namespace?: string;
    nodeLabel?: string;
}
export type ContainerInfo = {
    eksInfo: EksInfo;
};
export interface ContainerProvider {
    type: ContainerProviderType;
    id: string;
    info?: ContainerInfo;
}
export type SessionTagValue = string;
export interface SecureNamespaceInfo {
    clusterId?: string;
    namespace?: string;
}
export interface LakeFormationConfiguration {
    authorizedSessionTagValue?: string;
    secureNamespaceInfo?: SecureNamespaceInfo;
    queryEngineRoleArn?: string;
}
export type CertificateProviderType = "PEM" | (string & {});
export type SecretsManagerArn = string;
export interface TLSCertificateConfiguration {
    certificateProviderType?: CertificateProviderType;
    publicCertificateSecretArn?: string;
    privateCertificateSecretArn?: string;
}
export interface InTransitEncryptionConfiguration {
    tlsCertificateConfiguration?: TLSCertificateConfiguration;
}
export interface EncryptionConfiguration {
    inTransitEncryptionConfiguration?: InTransitEncryptionConfiguration;
}
export interface AuthorizationConfiguration {
    lakeFormationConfiguration?: LakeFormationConfiguration;
    encryptionConfiguration?: EncryptionConfiguration;
}
export type IdentityCenterInstanceARN = string;
export type EmrIdentityCenterApplicationARN = string;
export interface IdentityCenterConfiguration {
    enableIdentityCenter?: boolean;
    identityCenterApplicationAssignmentRequired?: boolean;
    identityCenterInstanceARN?: string;
    emrIdentityCenterApplicationARN?: string;
}
export interface IAMConfiguration {
    systemRole?: string;
}
export interface AuthenticationConfiguration {
    identityCenterConfiguration?: IdentityCenterConfiguration;
    iamConfiguration?: IAMConfiguration;
}
export interface SecurityConfigurationData {
    authorizationConfiguration?: AuthorizationConfiguration;
    authenticationConfiguration?: AuthenticationConfiguration;
}
export interface CreateSecurityConfigurationRequest {
    clientToken: string;
    name: string;
    containerProvider?: ContainerProvider;
    securityConfigurationData: SecurityConfigurationData;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type SecurityConfigurationArn = string;
export interface CreateSecurityConfigurationResponse {
    id?: string;
    name?: string;
    arn?: string;
}
export type InQueueJobLimitInteger = number;
export type JobLimitInteger = number;
export interface SchedulerConfiguration {
    maxInQueueJobRuns?: number;
    maxConcurrentJobRuns?: number;
}
export interface CreateVirtualClusterRequest {
    name: string;
    containerProvider: ContainerProvider;
    clientToken: string;
    tags?: {
        [key: string]: string | undefined;
    };
    securityConfigurationId?: string;
    sessionEnabled?: boolean;
    schedulerConfiguration?: SchedulerConfiguration;
}
export type VirtualClusterArn = string;
export interface CreateVirtualClusterResponse {
    id?: string;
    name?: string;
    arn?: string;
}
export interface DeleteJobTemplateRequest {
    id: string;
}
export interface DeleteJobTemplateResponse {
    id?: string;
}
export interface DeleteManagedEndpointRequest {
    id: string;
    virtualClusterId: string;
}
export interface DeleteManagedEndpointResponse {
    id?: string;
    virtualClusterId?: string;
}
export interface DeleteSecurityConfigurationRequest {
    id: string;
}
export interface DeleteSecurityConfigurationResponse {
    id?: string;
}
export interface DeleteVirtualClusterRequest {
    id: string;
}
export interface DeleteVirtualClusterResponse {
    id?: string;
}
export interface DescribeJobRunRequest {
    id: string;
    virtualClusterId: string;
}
export type JobArn = string;
export type JobRunState = "PENDING" | "SUBMITTED" | "RUNNING" | "FAILED" | "CANCELLED" | "CANCEL_PENDING" | "COMPLETED" | (string & {});
export type RequestIdentityUserArn = string;
export type FailureReason = "INTERNAL_ERROR" | "USER_ERROR" | "VALIDATION_ERROR" | "CLUSTER_UNAVAILABLE" | (string & {});
export type JavaInteger = number;
export interface RetryPolicyConfiguration {
    maxAttempts: number;
}
export interface RetryPolicyExecution {
    currentAttemptCount: number;
}
export interface JobRun {
    id?: string;
    name?: string;
    virtualClusterId?: string;
    arn?: string;
    state?: JobRunState;
    clientToken?: string;
    executionRoleArn?: string;
    releaseLabel?: string;
    configurationOverrides?: ConfigurationOverrides;
    jobDriver?: JobDriver;
    createdAt?: Date;
    createdBy?: string;
    finishedAt?: Date;
    stateDetails?: string;
    failureReason?: FailureReason;
    tags?: {
        [key: string]: string | undefined;
    };
    retryPolicyConfiguration?: RetryPolicyConfiguration;
    retryPolicyExecution?: RetryPolicyExecution;
}
export interface DescribeJobRunResponse {
    jobRun?: JobRun;
}
export interface DescribeJobTemplateRequest {
    id: string;
}
export type String2048 = string;
export interface JobTemplate {
    name?: string;
    id?: string;
    arn?: string;
    createdAt?: Date;
    createdBy?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    jobTemplateData: JobTemplateData;
    kmsKeyArn?: string;
    decryptionError?: string;
}
export interface DescribeJobTemplateResponse {
    jobTemplate?: JobTemplate;
}
export interface DescribeManagedEndpointRequest {
    id: string;
    virtualClusterId: string;
}
export type EndpointState = "CREATING" | "ACTIVE" | "TERMINATING" | "TERMINATED" | "TERMINATED_WITH_ERRORS" | (string & {});
export type Base64Encoded = string;
export interface Certificate {
    certificateArn?: string;
    certificateData?: string;
}
export type SubnetIds = string[];
export interface Endpoint {
    id?: string;
    name?: string;
    arn?: string;
    virtualClusterId?: string;
    type?: string;
    state?: EndpointState;
    releaseLabel?: string;
    executionRoleArn?: string;
    certificateArn?: string;
    certificateAuthority?: Certificate;
    configurationOverrides?: ConfigurationOverrides;
    serverUrl?: string;
    authProxyUrl?: string;
    createdAt?: Date;
    securityGroup?: string;
    subnetIds?: string[];
    stateDetails?: string;
    failureReason?: FailureReason;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeManagedEndpointResponse {
    endpoint?: Endpoint;
}
export interface DescribeSecurityConfigurationRequest {
    id: string;
}
export interface SecurityConfiguration {
    id?: string;
    name?: string;
    arn?: string;
    createdAt?: Date;
    createdBy?: string;
    securityConfigurationData?: SecurityConfigurationData;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeSecurityConfigurationResponse {
    securityConfiguration?: SecurityConfiguration;
}
export interface DescribeVirtualClusterRequest {
    id: string;
}
export type VirtualClusterState = "RUNNING" | "TERMINATING" | "TERMINATED" | "ARRESTED" | (string & {});
export type NonNegativeInteger = number;
export interface SchedulerStatus {
    currentInQueueJobRuns?: number;
    currentConcurrentJobRuns?: number;
}
export interface VirtualCluster {
    id?: string;
    name?: string;
    arn?: string;
    state?: VirtualClusterState;
    containerProvider?: ContainerProvider;
    createdAt?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    securityConfigurationId?: string;
    sessionEnabled?: boolean;
    schedulerConfiguration?: SchedulerConfiguration;
    schedulerStatus?: SchedulerStatus;
}
export interface DescribeVirtualClusterResponse {
    virtualCluster?: VirtualCluster;
}
export type CredentialType = string;
export type LogContext = string;
export interface GetManagedEndpointSessionCredentialsRequest {
    endpointIdentifier: string;
    virtualClusterIdentifier: string;
    executionRoleArn: string;
    credentialType: string;
    durationInSeconds?: number;
    logContext?: string;
    clientToken?: string;
}
export type Token = string | redacted.Redacted<string>;
export type Credentials = {
    token: string | redacted.Redacted<string>;
};
export interface GetManagedEndpointSessionCredentialsResponse {
    id?: string;
    credentials?: Credentials;
    endpointCredentials?: Credentials;
    expiresAt?: Date;
}
export type JobRunStates = JobRunState[];
export type NextToken = string;
export interface ListJobRunsRequest {
    virtualClusterId: string;
    createdBefore?: Date;
    createdAfter?: Date;
    name?: string;
    states?: JobRunState[];
    maxResults?: number;
    nextToken?: string;
}
export type JobRuns = JobRun[];
export interface ListJobRunsResponse {
    jobRuns?: JobRun[];
    nextToken?: string;
}
export interface ListJobTemplatesRequest {
    createdAfter?: Date;
    createdBefore?: Date;
    maxResults?: number;
    nextToken?: string;
}
export type JobTemplates = JobTemplate[];
export interface ListJobTemplatesResponse {
    templates?: JobTemplate[];
    nextToken?: string;
}
export type EndpointTypes = string[];
export type EndpointStates = EndpointState[];
export interface ListManagedEndpointsRequest {
    virtualClusterId: string;
    createdBefore?: Date;
    createdAfter?: Date;
    types?: string[];
    states?: EndpointState[];
    maxResults?: number;
    nextToken?: string;
}
export type Endpoints = Endpoint[];
export interface ListManagedEndpointsResponse {
    endpoints?: Endpoint[];
    nextToken?: string;
}
export interface ListSecurityConfigurationsRequest {
    createdAfter?: Date;
    createdBefore?: Date;
    maxResults?: number;
    nextToken?: string;
}
export type SecurityConfigurations = SecurityConfiguration[];
export interface ListSecurityConfigurationsResponse {
    securityConfigurations?: SecurityConfiguration[];
    nextToken?: string;
}
export type RsiArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export type VirtualClusterStates = VirtualClusterState[];
export interface ListVirtualClustersRequest {
    containerProviderId?: string;
    containerProviderType?: ContainerProviderType;
    createdAfter?: Date;
    createdBefore?: Date;
    states?: VirtualClusterState[];
    maxResults?: number;
    nextToken?: string;
    eksAccessEntryIntegrated?: boolean;
}
export type VirtualClusters = VirtualCluster[];
export interface ListVirtualClustersResponse {
    virtualClusters?: VirtualCluster[];
    nextToken?: string;
}
export type TemplateParameterInputMap = {
    [key: string]: string | undefined;
};
export interface StartJobRunRequest {
    name?: string;
    virtualClusterId: string;
    clientToken: string;
    executionRoleArn?: string;
    releaseLabel?: string;
    jobDriver?: JobDriver;
    configurationOverrides?: ConfigurationOverrides;
    tags?: {
        [key: string]: string | undefined;
    };
    jobTemplateId?: string;
    jobTemplateParameters?: {
        [key: string]: string | undefined;
    };
    retryPolicyConfiguration?: RetryPolicyConfiguration;
}
export interface StartJobRunResponse {
    id?: string;
    name?: string;
    arn?: string;
    virtualClusterId?: string;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateVirtualClusterRequest {
    id: string;
    schedulerConfiguration?: SchedulerConfiguration;
    clientToken: string;
}
export interface UpdateVirtualClusterResponse {
    virtualCluster?: VirtualCluster;
}
export type CancelJobRunError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Cancels a job run. A job run is a unit of work, such as a Spark jar, PySpark script, or
 * SparkSQL query, that you submit to Amazon EMR on EKS.
 */
export declare const cancelJobRun: API.OperationMethod<CancelJobRunRequest, CancelJobRunResponse, CancelJobRunError, Creds | HttpClient.HttpClient>;
export type CreateJobTemplateError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Creates a job template. Job template stores values of StartJobRun API request in a
 * template and can be used to start a job run. Job template allows two use cases: avoid
 * repeating recurring StartJobRun API request values, enforcing certain values in StartJobRun
 * API request.
 */
export declare const createJobTemplate: API.OperationMethod<CreateJobTemplateRequest, CreateJobTemplateResponse, CreateJobTemplateError, Creds | HttpClient.HttpClient>;
export type CreateManagedEndpointError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Creates a managed endpoint. A managed endpoint is a gateway that connects Amazon EMR Studio to Amazon EMR on EKS so that Amazon EMR Studio can
 * communicate with your virtual cluster.
 */
export declare const createManagedEndpoint: API.OperationMethod<CreateManagedEndpointRequest, CreateManagedEndpointResponse, CreateManagedEndpointError, Creds | HttpClient.HttpClient>;
export type CreateSecurityConfigurationError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Creates a security configuration. Security configurations in Amazon EMR on EKS are
 * templates for different security setups. You can use security configurations to configure
 * the Lake Formation integration setup. You can also create a security configuration
 * to re-use a security setup each time you create a virtual cluster.
 */
export declare const createSecurityConfiguration: API.OperationMethod<CreateSecurityConfigurationRequest, CreateSecurityConfigurationResponse, CreateSecurityConfigurationError, Creds | HttpClient.HttpClient>;
export type CreateVirtualClusterError = EKSRequestThrottledException | InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | EksClusterConnectionUpdating | CommonErrors;
/**
 * Creates a virtual cluster. Virtual cluster is a managed entity on Amazon EMR on EKS. You can create, update, describe, list and delete virtual clusters. They do not consume any
 * additional resource in your system. A single virtual cluster maps to a single Kubernetes
 * namespace. Given this relationship, you can model virtual clusters the same way you model
 * Kubernetes namespaces to meet your requirements.
 */
export declare const createVirtualCluster: API.OperationMethod<CreateVirtualClusterRequest, CreateVirtualClusterResponse, CreateVirtualClusterError, Creds | HttpClient.HttpClient>;
export type DeleteJobTemplateError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a job template. Job template stores values of StartJobRun API request in a
 * template and can be used to start a job run. Job template allows two use cases: avoid
 * repeating recurring StartJobRun API request values, enforcing certain values in StartJobRun
 * API request.
 */
export declare const deleteJobTemplate: API.OperationMethod<DeleteJobTemplateRequest, DeleteJobTemplateResponse, DeleteJobTemplateError, Creds | HttpClient.HttpClient>;
export type DeleteManagedEndpointError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a managed endpoint. A managed endpoint is a gateway that connects Amazon EMR Studio to Amazon EMR on EKS so that Amazon EMR Studio can
 * communicate with your virtual cluster.
 */
export declare const deleteManagedEndpoint: API.OperationMethod<DeleteManagedEndpointRequest, DeleteManagedEndpointResponse, DeleteManagedEndpointError, Creds | HttpClient.HttpClient>;
export type DeleteSecurityConfigurationError = InternalServerException | ValidationException | CommonErrors;
/**
 * Deletes a security configuration.
 */
export declare const deleteSecurityConfiguration: API.OperationMethod<DeleteSecurityConfigurationRequest, DeleteSecurityConfigurationResponse, DeleteSecurityConfigurationError, Creds | HttpClient.HttpClient>;
export type DeleteVirtualClusterError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a virtual cluster. Virtual cluster is a managed entity on Amazon EMR on EKS. You can create, update, describe, list and delete virtual clusters. They do not consume any
 * additional resource in your system. A single virtual cluster maps to a single Kubernetes
 * namespace. Given this relationship, you can model virtual clusters the same way you model
 * Kubernetes namespaces to meet your requirements.
 */
export declare const deleteVirtualCluster: API.OperationMethod<DeleteVirtualClusterRequest, DeleteVirtualClusterResponse, DeleteVirtualClusterError, Creds | HttpClient.HttpClient>;
export type DescribeJobRunError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Displays detailed information about a job run. A job run is a unit of work, such as a
 * Spark jar, PySpark script, or SparkSQL query, that you submit to Amazon EMR on EKS.
 */
export declare const describeJobRun: API.OperationMethod<DescribeJobRunRequest, DescribeJobRunResponse, DescribeJobRunError, Creds | HttpClient.HttpClient>;
export type DescribeJobTemplateError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Displays detailed information about a specified job template. Job template stores values
 * of StartJobRun API request in a template and can be used to start a job run. Job template
 * allows two use cases: avoid repeating recurring StartJobRun API request values, enforcing
 * certain values in StartJobRun API request.
 */
export declare const describeJobTemplate: API.OperationMethod<DescribeJobTemplateRequest, DescribeJobTemplateResponse, DescribeJobTemplateError, Creds | HttpClient.HttpClient>;
export type DescribeManagedEndpointError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Displays detailed information about a managed endpoint. A managed endpoint is a gateway
 * that connects Amazon EMR Studio to Amazon EMR on EKS so that Amazon EMR Studio can communicate with your virtual cluster.
 */
export declare const describeManagedEndpoint: API.OperationMethod<DescribeManagedEndpointRequest, DescribeManagedEndpointResponse, DescribeManagedEndpointError, Creds | HttpClient.HttpClient>;
export type DescribeSecurityConfigurationError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Displays detailed information about a specified security configuration. Security
 * configurations in Amazon EMR on EKS are templates for different security setups. You
 * can use security configurations to configure the Lake Formation integration setup.
 * You can also create a security configuration to re-use a security setup each time you
 * create a virtual cluster.
 */
export declare const describeSecurityConfiguration: API.OperationMethod<DescribeSecurityConfigurationRequest, DescribeSecurityConfigurationResponse, DescribeSecurityConfigurationError, Creds | HttpClient.HttpClient>;
export type DescribeVirtualClusterError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Displays detailed information about a specified virtual cluster. Virtual cluster is a
 * managed entity on Amazon EMR on EKS. You can create, update, describe, list and delete virtual
 * clusters. They do not consume any additional resource in your system. A single virtual
 * cluster maps to a single Kubernetes namespace. Given this relationship, you can model
 * virtual clusters the same way you model Kubernetes namespaces to meet your
 * requirements.
 */
export declare const describeVirtualCluster: API.OperationMethod<DescribeVirtualClusterRequest, DescribeVirtualClusterResponse, DescribeVirtualClusterError, Creds | HttpClient.HttpClient>;
export type GetManagedEndpointSessionCredentialsError = InternalServerException | RequestThrottledException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Generate a session token to connect to a managed endpoint.
 */
export declare const getManagedEndpointSessionCredentials: API.OperationMethod<GetManagedEndpointSessionCredentialsRequest, GetManagedEndpointSessionCredentialsResponse, GetManagedEndpointSessionCredentialsError, Creds | HttpClient.HttpClient>;
export type ListJobRunsError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists job runs based on a set of parameters. A job run is a unit of work, such as a
 * Spark jar, PySpark script, or SparkSQL query, that you submit to Amazon EMR on EKS.
 */
export declare const listJobRuns: API.PaginatedOperationMethod<ListJobRunsRequest, ListJobRunsResponse, ListJobRunsError, Creds | HttpClient.HttpClient, JobRun>;
export type ListJobTemplatesError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists job templates based on a set of parameters. Job template stores values of
 * StartJobRun API request in a template and can be used to start a job run. Job template
 * allows two use cases: avoid repeating recurring StartJobRun API request values, enforcing
 * certain values in StartJobRun API request.
 */
export declare const listJobTemplates: API.PaginatedOperationMethod<ListJobTemplatesRequest, ListJobTemplatesResponse, ListJobTemplatesError, Creds | HttpClient.HttpClient, JobTemplate>;
export type ListManagedEndpointsError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists managed endpoints based on a set of parameters. A managed endpoint is a gateway
 * that connects Amazon EMR Studio to Amazon EMR on EKS so that Amazon EMR Studio can communicate with your virtual cluster.
 */
export declare const listManagedEndpoints: API.PaginatedOperationMethod<ListManagedEndpointsRequest, ListManagedEndpointsResponse, ListManagedEndpointsError, Creds | HttpClient.HttpClient, Endpoint>;
export type ListSecurityConfigurationsError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists security configurations based on a set of parameters. Security configurations in
 * Amazon EMR on EKS are templates for different security setups. You can use security
 * configurations to configure the Lake Formation integration setup. You can also
 * create a security configuration to re-use a security setup each time you create a virtual
 * cluster.
 */
export declare const listSecurityConfigurations: API.PaginatedOperationMethod<ListSecurityConfigurationsRequest, ListSecurityConfigurationsResponse, ListSecurityConfigurationsError, Creds | HttpClient.HttpClient, SecurityConfiguration>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists the tags assigned to the resources.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Creds | HttpClient.HttpClient>;
export type ListVirtualClustersError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists information about the specified virtual cluster. Virtual cluster is a managed
 * entity on Amazon EMR on EKS. You can create, update, describe, list and delete virtual
 * clusters. They do not consume any additional resource in your system. A single virtual
 * cluster maps to a single Kubernetes namespace. Given this relationship, you can model
 * virtual clusters the same way you model Kubernetes namespaces to meet your
 * requirements.
 */
export declare const listVirtualClusters: API.PaginatedOperationMethod<ListVirtualClustersRequest, ListVirtualClustersResponse, ListVirtualClustersError, Creds | HttpClient.HttpClient, VirtualCluster>;
export type StartJobRunError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Starts a job run. A job run is a unit of work, such as a Spark jar, PySpark script, or
 * SparkSQL query, that you submit to Amazon EMR on EKS.
 */
export declare const startJobRun: API.OperationMethod<StartJobRunRequest, StartJobRunResponse, StartJobRunError, Creds | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | InvalidResourceArn | CommonErrors;
/**
 * Assigns tags to resources. A tag is a label that you assign to an Amazon Web Services
 * resource. Each tag consists of a key and an optional value, both of which you define. Tags
 * enable you to categorize your Amazon Web Services resources by attributes such as purpose,
 * owner, or environment. When you have many resources of the same type, you can quickly
 * identify a specific resource based on the tags you've assigned to it. For example, you can
 * define a set of tags for your Amazon EMR on EKS clusters to help you track each
 * cluster's owner and stack level. We recommend that you devise a consistent set of tag keys
 * for each resource type. You can then search and filter the resources based on the tags that
 * you add.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Creds | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | InvalidResourceArn | CommonErrors;
/**
 * Removes tags from resources.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Creds | HttpClient.HttpClient>;
export type UpdateVirtualClusterError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a virtual cluster. Virtual cluster is a managed entity on Amazon EMR on EKS. You can create, update, describe, list and delete virtual clusters. They do not consume any
 * additional resource in your system. A single virtual cluster maps to a single Kubernetes
 * namespace. Given this relationship, you can model virtual clusters the same way you model
 * Kubernetes namespaces to meet your requirements.
 */
export declare const updateVirtualCluster: API.OperationMethod<UpdateVirtualClusterRequest, UpdateVirtualClusterResponse, UpdateVirtualClusterError, Creds | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=emr-containers.d.ts.map