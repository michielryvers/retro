import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}>;
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}>;
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SubscriptionProviderArn = string;
export interface DeregisterSubscriptionProviderRequest {
    SubscriptionProviderArn: string;
}
export interface DeregisterSubscriptionProviderResponse {
}
export interface GetRegisteredSubscriptionProviderRequest {
    SubscriptionProviderArn: string;
}
export type SubscriptionProviderSource = string;
export type SecretArn = string;
export type SubscriptionProviderStatus = string;
export interface GetRegisteredSubscriptionProviderResponse {
    SubscriptionProviderArn?: string;
    SubscriptionProviderSource?: string;
    SecretArn?: string;
    SubscriptionProviderStatus?: string;
    SubscriptionProviderStatusMessage?: string;
    LastSuccessfulDataRetrievalTime?: string;
}
export interface GetServiceSettingsRequest {
}
export type LinuxSubscriptionsDiscovery = string;
export type StringList = string[];
export type OrganizationIntegration = string;
export interface LinuxSubscriptionsDiscoverySettings {
    SourceRegions: string[];
    OrganizationIntegration: string;
}
export type Status = string;
export type StringMap = {
    [key: string]: string | undefined;
};
export interface GetServiceSettingsResponse {
    LinuxSubscriptionsDiscovery?: string;
    LinuxSubscriptionsDiscoverySettings?: LinuxSubscriptionsDiscoverySettings;
    Status?: string;
    StatusMessage?: {
        [key: string]: string | undefined;
    };
    HomeRegions?: string[];
}
export type Operator = string;
export interface Filter {
    Name?: string;
    Values?: string[];
    Operator?: string;
}
export type FilterList = Filter[];
export type BoxInteger = number;
export interface ListLinuxSubscriptionInstancesRequest {
    Filters?: Filter[];
    MaxResults?: number;
    NextToken?: string;
}
export type ProductCodeList = string[];
export interface Instance {
    AmiId?: string;
    InstanceID?: string;
    InstanceType?: string;
    AccountID?: string;
    Status?: string;
    Region?: string;
    UsageOperation?: string;
    ProductCode?: string[];
    LastUpdatedTime?: string;
    SubscriptionName?: string;
    OsVersion?: string;
    SubscriptionProviderCreateTime?: string;
    SubscriptionProviderUpdateTime?: string;
    DualSubscription?: string;
    RegisteredWithSubscriptionProvider?: string;
}
export type InstanceList = Instance[];
export interface ListLinuxSubscriptionInstancesResponse {
    Instances?: Instance[];
    NextToken?: string;
}
export interface ListLinuxSubscriptionsRequest {
    Filters?: Filter[];
    MaxResults?: number;
    NextToken?: string;
}
export type BoxLong = number;
export interface Subscription {
    Name?: string;
    Type?: string;
    InstanceCount?: number;
}
export type SubscriptionList = Subscription[];
export interface ListLinuxSubscriptionsResponse {
    Subscriptions?: Subscription[];
    NextToken?: string;
}
export type SubscriptionProviderSourceList = string[];
export interface ListRegisteredSubscriptionProvidersRequest {
    SubscriptionProviderSources?: string[];
    MaxResults?: number;
    NextToken?: string;
}
export interface RegisteredSubscriptionProvider {
    SubscriptionProviderArn?: string;
    SubscriptionProviderSource?: string;
    SecretArn?: string;
    SubscriptionProviderStatus?: string;
    SubscriptionProviderStatusMessage?: string;
    LastSuccessfulDataRetrievalTime?: string;
}
export type RegisteredSubscriptionProviderList = RegisteredSubscriptionProvider[];
export interface ListRegisteredSubscriptionProvidersResponse {
    RegisteredSubscriptionProviders?: RegisteredSubscriptionProvider[];
    NextToken?: string;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export type Tags = {
    [key: string]: string | undefined;
};
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface RegisterSubscriptionProviderRequest {
    SubscriptionProviderSource: string;
    SecretArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface RegisterSubscriptionProviderResponse {
    SubscriptionProviderSource?: string;
    SubscriptionProviderArn?: string;
    SubscriptionProviderStatus?: string;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateServiceSettingsRequest {
    LinuxSubscriptionsDiscovery: string;
    LinuxSubscriptionsDiscoverySettings: LinuxSubscriptionsDiscoverySettings;
    AllowUpdate?: boolean;
}
export interface UpdateServiceSettingsResponse {
    LinuxSubscriptionsDiscovery?: string;
    LinuxSubscriptionsDiscoverySettings?: LinuxSubscriptionsDiscoverySettings;
    Status?: string;
    StatusMessage?: {
        [key: string]: string | undefined;
    };
    HomeRegions?: string[];
}
export type DeregisterSubscriptionProviderError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Remove a third-party subscription provider from the Bring Your Own License (BYOL) subscriptions
 * registered to your account.
 */
export declare const deregisterSubscriptionProvider: API.OperationMethod<DeregisterSubscriptionProviderRequest, DeregisterSubscriptionProviderResponse, DeregisterSubscriptionProviderError, Credentials | HttpClient.HttpClient>;
export type GetRegisteredSubscriptionProviderError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get details for a Bring Your Own License (BYOL) subscription that's registered to your account.
 */
export declare const getRegisteredSubscriptionProvider: API.OperationMethod<GetRegisteredSubscriptionProviderRequest, GetRegisteredSubscriptionProviderResponse, GetRegisteredSubscriptionProviderError, Credentials | HttpClient.HttpClient>;
export type GetServiceSettingsError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the Linux subscriptions service settings for your account.
 */
export declare const getServiceSettings: API.OperationMethod<GetServiceSettingsRequest, GetServiceSettingsResponse, GetServiceSettingsError, Credentials | HttpClient.HttpClient>;
export type ListLinuxSubscriptionInstancesError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the running Amazon EC2 instances that were discovered with commercial Linux
 * subscriptions.
 */
export declare const listLinuxSubscriptionInstances: API.PaginatedOperationMethod<ListLinuxSubscriptionInstancesRequest, ListLinuxSubscriptionInstancesResponse, ListLinuxSubscriptionInstancesError, Credentials | HttpClient.HttpClient, Instance>;
export type ListLinuxSubscriptionsError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the Linux subscriptions that have been discovered. If you have linked your
 * organization, the returned results will include data aggregated across your accounts in
 * Organizations.
 */
export declare const listLinuxSubscriptions: API.PaginatedOperationMethod<ListLinuxSubscriptionsRequest, ListLinuxSubscriptionsResponse, ListLinuxSubscriptionsError, Credentials | HttpClient.HttpClient, Subscription>;
export type ListRegisteredSubscriptionProvidersError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List Bring Your Own License (BYOL) subscription registration resources for your account.
 */
export declare const listRegisteredSubscriptionProviders: API.PaginatedOperationMethod<ListRegisteredSubscriptionProvidersRequest, ListRegisteredSubscriptionProvidersResponse, ListRegisteredSubscriptionProvidersError, Credentials | HttpClient.HttpClient, RegisteredSubscriptionProvider>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List the metadata tags that are assigned to the
 * specified Amazon Web Services resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RegisterSubscriptionProviderError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Register the supported third-party subscription provider for your Bring Your Own License (BYOL) subscription.
 */
export declare const registerSubscriptionProvider: API.OperationMethod<RegisterSubscriptionProviderRequest, RegisterSubscriptionProviderResponse, RegisterSubscriptionProviderError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Add metadata tags to the specified Amazon Web Services resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Remove one or more metadata tag from the specified Amazon Web Services resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceSettingsError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the service settings for Linux subscriptions.
 */
export declare const updateServiceSettings: API.OperationMethod<UpdateServiceSettingsRequest, UpdateServiceSettingsResponse, UpdateServiceSettingsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=license-manager-linux-subscriptions.d.ts.map