import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BillingViewHealthStatusException_base: S.TaggedErrorClass<"BillingViewHealthStatusException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BillingViewHealthStatusException extends /*@__PURE__*/ BillingViewHealthStatusException_base {
}
declare const CreationLimitExceededException_base: S.TaggedErrorClass<"CreationLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CreationLimitExceededException extends /*@__PURE__*/ CreationLimitExceededException_base {
}
declare const DuplicateRecordException_base: S.TaggedErrorClass<"DuplicateRecordException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DuplicateRecordException extends /*@__PURE__*/ DuplicateRecordException_base {
}
declare const ExpiredNextTokenException_base: S.TaggedErrorClass<"ExpiredNextTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ExpiredNextTokenException extends /*@__PURE__*/ ExpiredNextTokenException_base {
}
declare const InternalErrorException_base: S.TaggedErrorClass<"InternalErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalErrorException extends /*@__PURE__*/ InternalErrorException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ResourceLockedException_base: S.TaggedErrorClass<"ResourceLockedException", {
    readonly message: any;
}>;
export declare class ResourceLockedException extends /*@__PURE__*/ ResourceLockedException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type AccountId = string;
export type BudgetName = string;
export type NumericValue = string;
export type UnitValue = string;
export interface Spend {
    Amount: string;
    Unit: string;
}
export type PlannedBudgetLimits = {
    [key: string]: Spend | undefined;
};
export type DimensionValue = string;
export type DimensionValues = string[];
export type CostFilters = {
    [key: string]: string[] | undefined;
};
export interface CostTypes {
    IncludeTax?: boolean;
    IncludeSubscription?: boolean;
    UseBlended?: boolean;
    IncludeRefund?: boolean;
    IncludeCredit?: boolean;
    IncludeUpfront?: boolean;
    IncludeRecurring?: boolean;
    IncludeOtherSubscription?: boolean;
    IncludeSupport?: boolean;
    IncludeDiscount?: boolean;
    UseAmortized?: boolean;
}
export type TimeUnit = "DAILY" | "MONTHLY" | "QUARTERLY" | "ANNUALLY" | "CUSTOM" | (string & {});
export interface TimePeriod {
    Start?: Date;
    End?: Date;
}
export interface CalculatedSpend {
    ActualSpend: Spend;
    ForecastedSpend?: Spend;
}
export type BudgetType = "USAGE" | "COST" | "RI_UTILIZATION" | "RI_COVERAGE" | "SAVINGS_PLANS_UTILIZATION" | "SAVINGS_PLANS_COVERAGE" | (string & {});
export type AutoAdjustType = "HISTORICAL" | "FORECAST" | (string & {});
export type AdjustmentPeriod = number;
export interface HistoricalOptions {
    BudgetAdjustmentPeriod: number;
    LookBackAvailablePeriods?: number;
}
export interface AutoAdjustData {
    AutoAdjustType: AutoAdjustType;
    HistoricalOptions?: HistoricalOptions;
    LastAutoAdjustTime?: Date;
}
export type Expressions = Expression[];
export type Dimension = "AZ" | "INSTANCE_TYPE" | "LINKED_ACCOUNT" | "LINKED_ACCOUNT_NAME" | "OPERATION" | "PURCHASE_TYPE" | "REGION" | "SERVICE" | "SERVICE_CODE" | "USAGE_TYPE" | "USAGE_TYPE_GROUP" | "RECORD_TYPE" | "OPERATING_SYSTEM" | "TENANCY" | "SCOPE" | "PLATFORM" | "SUBSCRIPTION_ID" | "LEGAL_ENTITY_NAME" | "INVOICING_ENTITY" | "DEPLOYMENT_OPTION" | "DATABASE_ENGINE" | "CACHE_ENGINE" | "INSTANCE_TYPE_FAMILY" | "BILLING_ENTITY" | "RESERVATION_ID" | "RESOURCE_ID" | "RIGHTSIZING_TYPE" | "SAVINGS_PLANS_TYPE" | "SAVINGS_PLAN_ARN" | "PAYMENT_OPTION" | "RESERVATION_MODIFIED" | "TAG_KEY" | "COST_CATEGORY_NAME" | (string & {});
export type Value = string;
export type Values = string[];
export type MatchOption = "EQUALS" | "ABSENT" | "STARTS_WITH" | "ENDS_WITH" | "CONTAINS" | "GREATER_THAN_OR_EQUAL" | "CASE_SENSITIVE" | "CASE_INSENSITIVE" | (string & {});
export type MatchOptions = MatchOption[];
export interface ExpressionDimensionValues {
    Key: Dimension;
    Values: string[];
    MatchOptions?: MatchOption[];
}
export type TagKey = string;
export interface TagValues {
    Key?: string;
    Values?: string[];
    MatchOptions?: MatchOption[];
}
export type CostCategoryName = string;
export interface CostCategoryValues {
    Key?: string;
    Values?: string[];
    MatchOptions?: MatchOption[];
}
export interface Expression {
    Or?: Expression[];
    And?: Expression[];
    Not?: Expression;
    Dimensions?: ExpressionDimensionValues;
    Tags?: TagValues;
    CostCategories?: CostCategoryValues;
}
export type Metric = "BlendedCost" | "UnblendedCost" | "AmortizedCost" | "NetUnblendedCost" | "NetAmortizedCost" | "UsageQuantity" | "NormalizedUsageAmount" | "Hours" | (string & {});
export type Metrics = Metric[];
export type BillingViewArn = string;
export type HealthStatusValue = "HEALTHY" | "UNHEALTHY" | (string & {});
export type HealthStatusReason = "BILLING_VIEW_NO_ACCESS" | "BILLING_VIEW_UNHEALTHY" | "FILTER_INVALID" | "MULTI_YEAR_HISTORICAL_DATA_DISABLED" | (string & {});
export interface HealthStatus {
    Status?: HealthStatusValue;
    StatusReason?: HealthStatusReason;
    LastUpdatedTime?: Date;
}
export interface Budget {
    BudgetName: string;
    BudgetLimit?: Spend;
    PlannedBudgetLimits?: {
        [key: string]: Spend | undefined;
    };
    CostFilters?: {
        [key: string]: string[] | undefined;
    };
    CostTypes?: CostTypes;
    TimeUnit: TimeUnit;
    TimePeriod?: TimePeriod;
    CalculatedSpend?: CalculatedSpend;
    BudgetType: BudgetType;
    LastUpdatedTime?: Date;
    AutoAdjustData?: AutoAdjustData;
    FilterExpression?: Expression;
    Metrics?: Metric[];
    BillingViewArn?: string;
    HealthStatus?: HealthStatus;
}
export type NotificationType = "ACTUAL" | "FORECASTED" | (string & {});
export type ComparisonOperator = "GREATER_THAN" | "LESS_THAN" | "EQUAL_TO" | (string & {});
export type NotificationThreshold = number;
export type ThresholdType = "PERCENTAGE" | "ABSOLUTE_VALUE" | (string & {});
export type NotificationState = "OK" | "ALARM" | (string & {});
export interface Notification {
    NotificationType: NotificationType;
    ComparisonOperator: ComparisonOperator;
    Threshold: number;
    ThresholdType?: ThresholdType;
    NotificationState?: NotificationState;
}
export type SubscriptionType = "SNS" | "EMAIL" | (string & {});
export type SubscriberAddress = string | redacted.Redacted<string>;
export interface Subscriber {
    SubscriptionType: SubscriptionType;
    Address: string | redacted.Redacted<string>;
}
export type Subscribers = Subscriber[];
export interface NotificationWithSubscribers {
    Notification: Notification;
    Subscribers: Subscriber[];
}
export type NotificationWithSubscribersList = NotificationWithSubscribers[];
export type ResourceTagKey = string;
export type ResourceTagValue = string;
export interface ResourceTag {
    Key: string;
    Value: string;
}
export type ResourceTagList = ResourceTag[];
export interface CreateBudgetRequest {
    AccountId: string;
    Budget: Budget;
    NotificationsWithSubscribers?: NotificationWithSubscribers[];
    ResourceTags?: ResourceTag[];
}
export interface CreateBudgetResponse {
}
export type ActionType = "APPLY_IAM_POLICY" | "APPLY_SCP_POLICY" | "RUN_SSM_DOCUMENTS" | (string & {});
export interface ActionThreshold {
    ActionThresholdValue: number;
    ActionThresholdType: ThresholdType;
}
export type PolicyArn = string;
export type Role = string;
export type Roles = string[];
export type Group = string;
export type Groups = string[];
export type User = string;
export type Users = string[];
export interface IamActionDefinition {
    PolicyArn: string;
    Roles?: string[];
    Groups?: string[];
    Users?: string[];
}
export type PolicyId = string;
export type TargetId = string;
export type TargetIds = string[];
export interface ScpActionDefinition {
    PolicyId: string;
    TargetIds: string[];
}
export type ActionSubType = "STOP_EC2_INSTANCES" | "STOP_RDS_INSTANCES" | (string & {});
export type Region = string;
export type InstanceId = string;
export type InstanceIds = string[];
export interface SsmActionDefinition {
    ActionSubType: ActionSubType;
    Region: string;
    InstanceIds: string[];
}
export interface Definition {
    IamActionDefinition?: IamActionDefinition;
    ScpActionDefinition?: ScpActionDefinition;
    SsmActionDefinition?: SsmActionDefinition;
}
export type RoleArn = string;
export type ApprovalModel = "AUTOMATIC" | "MANUAL" | (string & {});
export interface CreateBudgetActionRequest {
    AccountId: string;
    BudgetName: string;
    NotificationType: NotificationType;
    ActionType: ActionType;
    ActionThreshold: ActionThreshold;
    Definition: Definition;
    ExecutionRoleArn: string;
    ApprovalModel: ApprovalModel;
    Subscribers: Subscriber[];
    ResourceTags?: ResourceTag[];
}
export type ActionId = string;
export interface CreateBudgetActionResponse {
    AccountId: string;
    BudgetName: string;
    ActionId: string;
}
export interface CreateNotificationRequest {
    AccountId: string;
    BudgetName: string;
    Notification: Notification;
    Subscribers: Subscriber[];
}
export interface CreateNotificationResponse {
}
export interface CreateSubscriberRequest {
    AccountId: string;
    BudgetName: string;
    Notification: Notification;
    Subscriber: Subscriber;
}
export interface CreateSubscriberResponse {
}
export interface DeleteBudgetRequest {
    AccountId: string;
    BudgetName: string;
}
export interface DeleteBudgetResponse {
}
export interface DeleteBudgetActionRequest {
    AccountId: string;
    BudgetName: string;
    ActionId: string;
}
export type ActionStatus = "STANDBY" | "PENDING" | "EXECUTION_IN_PROGRESS" | "EXECUTION_SUCCESS" | "EXECUTION_FAILURE" | "REVERSE_IN_PROGRESS" | "REVERSE_SUCCESS" | "REVERSE_FAILURE" | "RESET_IN_PROGRESS" | "RESET_FAILURE" | (string & {});
export interface Action {
    ActionId: string;
    BudgetName: string;
    NotificationType: NotificationType;
    ActionType: ActionType;
    ActionThreshold: ActionThreshold;
    Definition: Definition;
    ExecutionRoleArn: string;
    ApprovalModel: ApprovalModel;
    Status: ActionStatus;
    Subscribers: Subscriber[];
}
export interface DeleteBudgetActionResponse {
    AccountId: string;
    BudgetName: string;
    Action: Action;
}
export interface DeleteNotificationRequest {
    AccountId: string;
    BudgetName: string;
    Notification: Notification;
}
export interface DeleteNotificationResponse {
}
export interface DeleteSubscriberRequest {
    AccountId: string;
    BudgetName: string;
    Notification: Notification;
    Subscriber: Subscriber;
}
export interface DeleteSubscriberResponse {
}
export interface DescribeBudgetRequest {
    AccountId: string;
    BudgetName: string;
    ShowFilterExpression?: boolean;
}
export interface DescribeBudgetResponse {
    Budget?: Budget;
}
export interface DescribeBudgetActionRequest {
    AccountId: string;
    BudgetName: string;
    ActionId: string;
}
export interface DescribeBudgetActionResponse {
    AccountId: string;
    BudgetName: string;
    Action: Action;
}
export type MaxResults = number;
export interface DescribeBudgetActionHistoriesRequest {
    AccountId: string;
    BudgetName: string;
    ActionId: string;
    TimePeriod?: TimePeriod;
    MaxResults?: number;
    NextToken?: string;
}
export type EventType = "SYSTEM" | "CREATE_ACTION" | "DELETE_ACTION" | "UPDATE_ACTION" | "EXECUTE_ACTION" | (string & {});
export interface ActionHistoryDetails {
    Message: string;
    Action: Action;
}
export interface ActionHistory {
    Timestamp: Date;
    Status: ActionStatus;
    EventType: EventType;
    ActionHistoryDetails: ActionHistoryDetails;
}
export type ActionHistories = ActionHistory[];
export interface DescribeBudgetActionHistoriesResponse {
    ActionHistories: ActionHistory[];
    NextToken?: string;
}
export interface DescribeBudgetActionsForAccountRequest {
    AccountId: string;
    MaxResults?: number;
    NextToken?: string;
}
export type Actions = Action[];
export interface DescribeBudgetActionsForAccountResponse {
    Actions: Action[];
    NextToken?: string;
}
export interface DescribeBudgetActionsForBudgetRequest {
    AccountId: string;
    BudgetName: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface DescribeBudgetActionsForBudgetResponse {
    Actions: Action[];
    NextToken?: string;
}
export type MaxResultsBudgetNotifications = number;
export interface DescribeBudgetNotificationsForAccountRequest {
    AccountId: string;
    MaxResults?: number;
    NextToken?: string;
}
export type Notifications = Notification[];
export interface BudgetNotificationsForAccount {
    Notifications?: Notification[];
    BudgetName?: string;
}
export type BudgetNotificationsForAccountList = BudgetNotificationsForAccount[];
export interface DescribeBudgetNotificationsForAccountResponse {
    BudgetNotificationsForAccount?: BudgetNotificationsForAccount[];
    NextToken?: string;
}
export interface DescribeBudgetPerformanceHistoryRequest {
    AccountId: string;
    BudgetName: string;
    TimePeriod?: TimePeriod;
    MaxResults?: number;
    NextToken?: string;
}
export interface BudgetedAndActualAmounts {
    BudgetedAmount?: Spend;
    ActualAmount?: Spend;
    TimePeriod?: TimePeriod;
}
export type BudgetedAndActualAmountsList = BudgetedAndActualAmounts[];
export interface BudgetPerformanceHistory {
    BudgetName?: string;
    BudgetType?: BudgetType;
    CostFilters?: {
        [key: string]: string[] | undefined;
    };
    CostTypes?: CostTypes;
    TimeUnit?: TimeUnit;
    BillingViewArn?: string;
    BudgetedAndActualAmountsList?: BudgetedAndActualAmounts[];
    FilterExpression?: Expression;
    Metrics?: Metric[];
}
export interface DescribeBudgetPerformanceHistoryResponse {
    BudgetPerformanceHistory?: BudgetPerformanceHistory;
    NextToken?: string;
}
export type MaxResultsDescribeBudgets = number;
export interface DescribeBudgetsRequest {
    AccountId: string;
    MaxResults?: number;
    NextToken?: string;
    ShowFilterExpression?: boolean;
}
export type Budgets = Budget[];
export interface DescribeBudgetsResponse {
    Budgets?: Budget[];
    NextToken?: string;
}
export interface DescribeNotificationsForBudgetRequest {
    AccountId: string;
    BudgetName: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface DescribeNotificationsForBudgetResponse {
    Notifications?: Notification[];
    NextToken?: string;
}
export interface DescribeSubscribersForNotificationRequest {
    AccountId: string;
    BudgetName: string;
    Notification: Notification;
    MaxResults?: number;
    NextToken?: string;
}
export interface DescribeSubscribersForNotificationResponse {
    Subscribers?: Subscriber[];
    NextToken?: string;
}
export type ExecutionType = "APPROVE_BUDGET_ACTION" | "RETRY_BUDGET_ACTION" | "REVERSE_BUDGET_ACTION" | "RESET_BUDGET_ACTION" | (string & {});
export interface ExecuteBudgetActionRequest {
    AccountId: string;
    BudgetName: string;
    ActionId: string;
    ExecutionType: ExecutionType;
}
export interface ExecuteBudgetActionResponse {
    AccountId: string;
    BudgetName: string;
    ActionId: string;
    ExecutionType: ExecutionType;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export interface ListTagsForResourceResponse {
    ResourceTags?: ResourceTag[];
}
export interface TagResourceRequest {
    ResourceARN: string;
    ResourceTags: ResourceTag[];
}
export interface TagResourceResponse {
}
export type ResourceTagKeyList = string[];
export interface UntagResourceRequest {
    ResourceARN: string;
    ResourceTagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateBudgetRequest {
    AccountId: string;
    NewBudget: Budget;
}
export interface UpdateBudgetResponse {
}
export interface UpdateBudgetActionRequest {
    AccountId: string;
    BudgetName: string;
    ActionId: string;
    NotificationType?: NotificationType;
    ActionThreshold?: ActionThreshold;
    Definition?: Definition;
    ExecutionRoleArn?: string;
    ApprovalModel?: ApprovalModel;
    Subscribers?: Subscriber[];
}
export interface UpdateBudgetActionResponse {
    AccountId: string;
    BudgetName: string;
    OldAction: Action;
    NewAction: Action;
}
export interface UpdateNotificationRequest {
    AccountId: string;
    BudgetName: string;
    OldNotification: Notification;
    NewNotification: Notification;
}
export interface UpdateNotificationResponse {
}
export interface UpdateSubscriberRequest {
    AccountId: string;
    BudgetName: string;
    Notification: Notification;
    OldSubscriber: Subscriber;
    NewSubscriber: Subscriber;
}
export interface UpdateSubscriberResponse {
}
export type ErrorMessage = string;
export type CreateBudgetError = AccessDeniedException | BillingViewHealthStatusException | CreationLimitExceededException | DuplicateRecordException | InternalErrorException | InvalidParameterException | NotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a budget and, if included, notifications and subscribers.
 *
 * Only one of `BudgetLimit` or `PlannedBudgetLimits` can be present in
 * the syntax at one time. Use the syntax that matches your use case. The Request Syntax
 * section shows the `BudgetLimit` syntax. For `PlannedBudgetLimits`,
 * see the Examples section.
 *
 * Similarly, only one set of filter and metric selections can be present in the syntax
 * at one time. Either `FilterExpression` and `Metrics` or
 * `CostFilters` and `CostTypes`, not both or a different
 * combination. We recommend using `FilterExpression` and `Metrics`
 * as they provide more flexible and powerful filtering capabilities. The Request Syntax
 * section shows the `FilterExpression`/`Metrics` syntax.
 */
export declare const createBudget: API.OperationMethod<CreateBudgetRequest, CreateBudgetResponse, CreateBudgetError, Credentials | HttpClient.HttpClient>;
export type CreateBudgetActionError = AccessDeniedException | CreationLimitExceededException | DuplicateRecordException | InternalErrorException | InvalidParameterException | NotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a budget action.
 */
export declare const createBudgetAction: API.OperationMethod<CreateBudgetActionRequest, CreateBudgetActionResponse, CreateBudgetActionError, Credentials | HttpClient.HttpClient>;
export type CreateNotificationError = AccessDeniedException | CreationLimitExceededException | DuplicateRecordException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a notification. You must create the budget before you create the associated notification.
 */
export declare const createNotification: API.OperationMethod<CreateNotificationRequest, CreateNotificationResponse, CreateNotificationError, Credentials | HttpClient.HttpClient>;
export type CreateSubscriberError = AccessDeniedException | CreationLimitExceededException | DuplicateRecordException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a subscriber. You must create the associated budget and notification before you create the subscriber.
 */
export declare const createSubscriber: API.OperationMethod<CreateSubscriberRequest, CreateSubscriberResponse, CreateSubscriberError, Credentials | HttpClient.HttpClient>;
export type DeleteBudgetError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a budget. You can delete your budget at any time.
 *
 * Deleting a budget also deletes the notifications and subscribers that are associated with that budget.
 */
export declare const deleteBudget: API.OperationMethod<DeleteBudgetRequest, DeleteBudgetResponse, DeleteBudgetError, Credentials | HttpClient.HttpClient>;
export type DeleteBudgetActionError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ResourceLockedException | ThrottlingException | CommonErrors;
/**
 * Deletes a budget action.
 */
export declare const deleteBudgetAction: API.OperationMethod<DeleteBudgetActionRequest, DeleteBudgetActionResponse, DeleteBudgetActionError, Credentials | HttpClient.HttpClient>;
export type DeleteNotificationError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a notification.
 *
 * Deleting a notification also deletes the subscribers that are associated with the notification.
 */
export declare const deleteNotification: API.OperationMethod<DeleteNotificationRequest, DeleteNotificationResponse, DeleteNotificationError, Credentials | HttpClient.HttpClient>;
export type DeleteSubscriberError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a subscriber.
 *
 * Deleting the last subscriber to a notification also deletes the notification.
 */
export declare const deleteSubscriber: API.OperationMethod<DeleteSubscriberRequest, DeleteSubscriberResponse, DeleteSubscriberError, Credentials | HttpClient.HttpClient>;
export type DescribeBudgetError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a budget.
 *
 * The Request Syntax section shows the `BudgetLimit` syntax. For
 * `PlannedBudgetLimits`, see the Examples section.
 */
export declare const describeBudget: API.OperationMethod<DescribeBudgetRequest, DescribeBudgetResponse, DescribeBudgetError, Credentials | HttpClient.HttpClient>;
export type DescribeBudgetActionError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a budget action detail.
 */
export declare const describeBudgetAction: API.OperationMethod<DescribeBudgetActionRequest, DescribeBudgetActionResponse, DescribeBudgetActionError, Credentials | HttpClient.HttpClient>;
export type DescribeBudgetActionHistoriesError = AccessDeniedException | InternalErrorException | InvalidNextTokenException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a budget action history detail.
 */
export declare const describeBudgetActionHistories: API.PaginatedOperationMethod<DescribeBudgetActionHistoriesRequest, DescribeBudgetActionHistoriesResponse, DescribeBudgetActionHistoriesError, Credentials | HttpClient.HttpClient, ActionHistory>;
export type DescribeBudgetActionsForAccountError = AccessDeniedException | InternalErrorException | InvalidNextTokenException | InvalidParameterException | ThrottlingException | CommonErrors;
/**
 * Describes all of the budget actions for an account.
 */
export declare const describeBudgetActionsForAccount: API.PaginatedOperationMethod<DescribeBudgetActionsForAccountRequest, DescribeBudgetActionsForAccountResponse, DescribeBudgetActionsForAccountError, Credentials | HttpClient.HttpClient, Action>;
export type DescribeBudgetActionsForBudgetError = AccessDeniedException | InternalErrorException | InvalidNextTokenException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes all of the budget actions for a budget.
 */
export declare const describeBudgetActionsForBudget: API.PaginatedOperationMethod<DescribeBudgetActionsForBudgetRequest, DescribeBudgetActionsForBudgetResponse, DescribeBudgetActionsForBudgetError, Credentials | HttpClient.HttpClient, Action>;
export type DescribeBudgetNotificationsForAccountError = AccessDeniedException | ExpiredNextTokenException | InternalErrorException | InvalidNextTokenException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the budget names and notifications that are associated with an account.
 */
export declare const describeBudgetNotificationsForAccount: API.PaginatedOperationMethod<DescribeBudgetNotificationsForAccountRequest, DescribeBudgetNotificationsForAccountResponse, DescribeBudgetNotificationsForAccountError, Credentials | HttpClient.HttpClient, BudgetNotificationsForAccount>;
export type DescribeBudgetPerformanceHistoryError = AccessDeniedException | BillingViewHealthStatusException | ExpiredNextTokenException | InternalErrorException | InvalidNextTokenException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the history for `DAILY`, `MONTHLY`, and `QUARTERLY` budgets. Budget history isn't available for `ANNUAL` budgets.
 */
export declare const describeBudgetPerformanceHistory: API.PaginatedOperationMethod<DescribeBudgetPerformanceHistoryRequest, DescribeBudgetPerformanceHistoryResponse, DescribeBudgetPerformanceHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeBudgetsError = AccessDeniedException | ExpiredNextTokenException | InternalErrorException | InvalidNextTokenException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the budgets that are associated with an account.
 *
 * The Request Syntax section shows the `BudgetLimit` syntax. For
 * `PlannedBudgetLimits`, see the Examples section.
 */
export declare const describeBudgets: API.PaginatedOperationMethod<DescribeBudgetsRequest, DescribeBudgetsResponse, DescribeBudgetsError, Credentials | HttpClient.HttpClient, Budget>;
export type DescribeNotificationsForBudgetError = AccessDeniedException | ExpiredNextTokenException | InternalErrorException | InvalidNextTokenException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the notifications that are associated with a budget.
 */
export declare const describeNotificationsForBudget: API.PaginatedOperationMethod<DescribeNotificationsForBudgetRequest, DescribeNotificationsForBudgetResponse, DescribeNotificationsForBudgetError, Credentials | HttpClient.HttpClient, Notification>;
export type DescribeSubscribersForNotificationError = AccessDeniedException | ExpiredNextTokenException | InternalErrorException | InvalidNextTokenException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the subscribers that are associated with a notification.
 */
export declare const describeSubscribersForNotification: API.PaginatedOperationMethod<DescribeSubscribersForNotificationRequest, DescribeSubscribersForNotificationResponse, DescribeSubscribersForNotificationError, Credentials | HttpClient.HttpClient, Subscriber>;
export type ExecuteBudgetActionError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ResourceLockedException | ThrottlingException | CommonErrors;
/**
 * Executes a budget action.
 */
export declare const executeBudgetAction: API.OperationMethod<ExecuteBudgetActionRequest, ExecuteBudgetActionResponse, ExecuteBudgetActionError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists tags associated with a budget or budget action resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates tags for a budget or budget action resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes tags associated with a budget or budget action resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBudgetError = AccessDeniedException | BillingViewHealthStatusException | InternalErrorException | InvalidParameterException | NotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Updates a budget. You can change every part of a budget except for the `budgetName` and the `calculatedSpend`. When you modify a budget, the `calculatedSpend` drops to zero until Amazon Web Services has new usage data to use for forecasting.
 *
 * Only one of `BudgetLimit` or `PlannedBudgetLimits` can be present in
 * the syntax at one time. Use the syntax that matches your case. The Request Syntax
 * section shows the `BudgetLimit` syntax. For `PlannedBudgetLimits`,
 * see the Examples section.
 *
 * Similarly, only one set of filter and metric selections can be present in the syntax
 * at one time. Either `FilterExpression` and `Metrics` or
 * `CostFilters` and `CostTypes`, not both or a different
 * combination. We recommend using `FilterExpression` and `Metrics`
 * as they provide more flexible and powerful filtering capabilities. The Request Syntax
 * section shows the `FilterExpression`/`Metrics` syntax.
 */
export declare const updateBudget: API.OperationMethod<UpdateBudgetRequest, UpdateBudgetResponse, UpdateBudgetError, Credentials | HttpClient.HttpClient>;
export type UpdateBudgetActionError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ResourceLockedException | ThrottlingException | CommonErrors;
/**
 * Updates a budget action.
 */
export declare const updateBudgetAction: API.OperationMethod<UpdateBudgetActionRequest, UpdateBudgetActionResponse, UpdateBudgetActionError, Credentials | HttpClient.HttpClient>;
export type UpdateNotificationError = AccessDeniedException | DuplicateRecordException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a notification.
 */
export declare const updateNotification: API.OperationMethod<UpdateNotificationRequest, UpdateNotificationResponse, UpdateNotificationError, Credentials | HttpClient.HttpClient>;
export type UpdateSubscriberError = AccessDeniedException | DuplicateRecordException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a subscriber.
 */
export declare const updateSubscriber: API.OperationMethod<UpdateSubscriberRequest, UpdateSubscriberResponse, UpdateSubscriberError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=budgets.d.ts.map