import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import * as T from "../traits.ts";
declare const AccessDenied_base: S.TaggedErrorClass<"AccessDenied", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDenied extends /*@__PURE__*/ AccessDenied_base {
}
declare const BatchTooLarge_base: S.TaggedErrorClass<"BatchTooLarge", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BatchTooLarge extends /*@__PURE__*/ BatchTooLarge_base {
}
declare const CachePolicyAlreadyExists_base: S.TaggedErrorClass<"CachePolicyAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CachePolicyAlreadyExists extends /*@__PURE__*/ CachePolicyAlreadyExists_base {
}
declare const CachePolicyInUse_base: S.TaggedErrorClass<"CachePolicyInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class CachePolicyInUse extends /*@__PURE__*/ CachePolicyInUse_base {
}
declare const CannotChangeImmutablePublicKeyFields_base: S.TaggedErrorClass<"CannotChangeImmutablePublicKeyFields", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CannotChangeImmutablePublicKeyFields extends /*@__PURE__*/ CannotChangeImmutablePublicKeyFields_base {
}
declare const CannotDeleteEntityWhileInUse_base: S.TaggedErrorClass<"CannotDeleteEntityWhileInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class CannotDeleteEntityWhileInUse extends /*@__PURE__*/ CannotDeleteEntityWhileInUse_base {
}
declare const CannotUpdateEntityWhileInUse_base: S.TaggedErrorClass<"CannotUpdateEntityWhileInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class CannotUpdateEntityWhileInUse extends /*@__PURE__*/ CannotUpdateEntityWhileInUse_base {
}
declare const CloudFrontOriginAccessIdentityAlreadyExists_base: S.TaggedErrorClass<"CloudFrontOriginAccessIdentityAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CloudFrontOriginAccessIdentityAlreadyExists extends /*@__PURE__*/ CloudFrontOriginAccessIdentityAlreadyExists_base {
}
declare const CloudFrontOriginAccessIdentityInUse_base: S.TaggedErrorClass<"CloudFrontOriginAccessIdentityInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class CloudFrontOriginAccessIdentityInUse extends /*@__PURE__*/ CloudFrontOriginAccessIdentityInUse_base {
}
declare const CNAMEAlreadyExists_base: S.TaggedErrorClass<"CNAMEAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CNAMEAlreadyExists extends /*@__PURE__*/ CNAMEAlreadyExists_base {
}
declare const ContinuousDeploymentPolicyAlreadyExists_base: S.TaggedErrorClass<"ContinuousDeploymentPolicyAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ContinuousDeploymentPolicyAlreadyExists extends /*@__PURE__*/ ContinuousDeploymentPolicyAlreadyExists_base {
}
declare const ContinuousDeploymentPolicyInUse_base: S.TaggedErrorClass<"ContinuousDeploymentPolicyInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class ContinuousDeploymentPolicyInUse extends /*@__PURE__*/ ContinuousDeploymentPolicyInUse_base {
}
declare const DistributionAlreadyExists_base: S.TaggedErrorClass<"DistributionAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DistributionAlreadyExists extends /*@__PURE__*/ DistributionAlreadyExists_base {
}
declare const DistributionNotDisabled_base: S.TaggedErrorClass<"DistributionNotDisabled", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DistributionNotDisabled extends /*@__PURE__*/ DistributionNotDisabled_base {
}
declare const EntityAlreadyExists_base: S.TaggedErrorClass<"EntityAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class EntityAlreadyExists extends /*@__PURE__*/ EntityAlreadyExists_base {
}
declare const EntityLimitExceeded_base: S.TaggedErrorClass<"EntityLimitExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class EntityLimitExceeded extends /*@__PURE__*/ EntityLimitExceeded_base {
}
declare const EntityNotFound_base: S.TaggedErrorClass<"EntityNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EntityNotFound extends /*@__PURE__*/ EntityNotFound_base {
}
declare const EntitySizeLimitExceeded_base: S.TaggedErrorClass<"EntitySizeLimitExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class EntitySizeLimitExceeded extends /*@__PURE__*/ EntitySizeLimitExceeded_base {
}
declare const FieldLevelEncryptionConfigAlreadyExists_base: S.TaggedErrorClass<"FieldLevelEncryptionConfigAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class FieldLevelEncryptionConfigAlreadyExists extends /*@__PURE__*/ FieldLevelEncryptionConfigAlreadyExists_base {
}
declare const FieldLevelEncryptionConfigInUse_base: S.TaggedErrorClass<"FieldLevelEncryptionConfigInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class FieldLevelEncryptionConfigInUse extends /*@__PURE__*/ FieldLevelEncryptionConfigInUse_base {
}
declare const FieldLevelEncryptionProfileAlreadyExists_base: S.TaggedErrorClass<"FieldLevelEncryptionProfileAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class FieldLevelEncryptionProfileAlreadyExists extends /*@__PURE__*/ FieldLevelEncryptionProfileAlreadyExists_base {
}
declare const FieldLevelEncryptionProfileInUse_base: S.TaggedErrorClass<"FieldLevelEncryptionProfileInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class FieldLevelEncryptionProfileInUse extends /*@__PURE__*/ FieldLevelEncryptionProfileInUse_base {
}
declare const FieldLevelEncryptionProfileSizeExceeded_base: S.TaggedErrorClass<"FieldLevelEncryptionProfileSizeExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class FieldLevelEncryptionProfileSizeExceeded extends /*@__PURE__*/ FieldLevelEncryptionProfileSizeExceeded_base {
}
declare const FunctionAlreadyExists_base: S.TaggedErrorClass<"FunctionAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class FunctionAlreadyExists extends /*@__PURE__*/ FunctionAlreadyExists_base {
}
declare const FunctionInUse_base: S.TaggedErrorClass<"FunctionInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class FunctionInUse extends /*@__PURE__*/ FunctionInUse_base {
}
declare const FunctionSizeLimitExceeded_base: S.TaggedErrorClass<"FunctionSizeLimitExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class FunctionSizeLimitExceeded extends /*@__PURE__*/ FunctionSizeLimitExceeded_base {
}
declare const IllegalDelete_base: S.TaggedErrorClass<"IllegalDelete", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IllegalDelete extends /*@__PURE__*/ IllegalDelete_base {
}
declare const IllegalFieldLevelEncryptionConfigAssociationWithCacheBehavior_base: S.TaggedErrorClass<"IllegalFieldLevelEncryptionConfigAssociationWithCacheBehavior", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IllegalFieldLevelEncryptionConfigAssociationWithCacheBehavior extends /*@__PURE__*/ IllegalFieldLevelEncryptionConfigAssociationWithCacheBehavior_base {
}
declare const IllegalOriginAccessConfiguration_base: S.TaggedErrorClass<"IllegalOriginAccessConfiguration", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IllegalOriginAccessConfiguration extends /*@__PURE__*/ IllegalOriginAccessConfiguration_base {
}
declare const IllegalUpdate_base: S.TaggedErrorClass<"IllegalUpdate", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IllegalUpdate extends /*@__PURE__*/ IllegalUpdate_base {
}
declare const InconsistentQuantities_base: S.TaggedErrorClass<"InconsistentQuantities", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InconsistentQuantities extends /*@__PURE__*/ InconsistentQuantities_base {
}
declare const InvalidArgument_base: S.TaggedErrorClass<"InvalidArgument", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidArgument extends /*@__PURE__*/ InvalidArgument_base {
}
declare const InvalidAssociation_base: S.TaggedErrorClass<"InvalidAssociation", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidAssociation extends /*@__PURE__*/ InvalidAssociation_base {
}
declare const InvalidDefaultRootObject_base: S.TaggedErrorClass<"InvalidDefaultRootObject", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDefaultRootObject extends /*@__PURE__*/ InvalidDefaultRootObject_base {
}
declare const InvalidDomainNameForOriginAccessControl_base: S.TaggedErrorClass<"InvalidDomainNameForOriginAccessControl", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDomainNameForOriginAccessControl extends /*@__PURE__*/ InvalidDomainNameForOriginAccessControl_base {
}
declare const InvalidErrorCode_base: S.TaggedErrorClass<"InvalidErrorCode", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidErrorCode extends /*@__PURE__*/ InvalidErrorCode_base {
}
declare const InvalidForwardCookies_base: S.TaggedErrorClass<"InvalidForwardCookies", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidForwardCookies extends /*@__PURE__*/ InvalidForwardCookies_base {
}
declare const InvalidFunctionAssociation_base: S.TaggedErrorClass<"InvalidFunctionAssociation", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidFunctionAssociation extends /*@__PURE__*/ InvalidFunctionAssociation_base {
}
declare const InvalidGeoRestrictionParameter_base: S.TaggedErrorClass<"InvalidGeoRestrictionParameter", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidGeoRestrictionParameter extends /*@__PURE__*/ InvalidGeoRestrictionParameter_base {
}
declare const InvalidHeadersForS3Origin_base: S.TaggedErrorClass<"InvalidHeadersForS3Origin", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidHeadersForS3Origin extends /*@__PURE__*/ InvalidHeadersForS3Origin_base {
}
declare const InvalidIfMatchVersion_base: S.TaggedErrorClass<"InvalidIfMatchVersion", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidIfMatchVersion extends /*@__PURE__*/ InvalidIfMatchVersion_base {
}
declare const InvalidLambdaFunctionAssociation_base: S.TaggedErrorClass<"InvalidLambdaFunctionAssociation", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidLambdaFunctionAssociation extends /*@__PURE__*/ InvalidLambdaFunctionAssociation_base {
}
declare const InvalidLocationCode_base: S.TaggedErrorClass<"InvalidLocationCode", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidLocationCode extends /*@__PURE__*/ InvalidLocationCode_base {
}
declare const InvalidMinimumProtocolVersion_base: S.TaggedErrorClass<"InvalidMinimumProtocolVersion", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidMinimumProtocolVersion extends /*@__PURE__*/ InvalidMinimumProtocolVersion_base {
}
declare const InvalidOrigin_base: S.TaggedErrorClass<"InvalidOrigin", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidOrigin extends /*@__PURE__*/ InvalidOrigin_base {
}
declare const InvalidOriginAccessControl_base: S.TaggedErrorClass<"InvalidOriginAccessControl", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidOriginAccessControl extends /*@__PURE__*/ InvalidOriginAccessControl_base {
}
declare const InvalidOriginAccessIdentity_base: S.TaggedErrorClass<"InvalidOriginAccessIdentity", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidOriginAccessIdentity extends /*@__PURE__*/ InvalidOriginAccessIdentity_base {
}
declare const InvalidOriginKeepaliveTimeout_base: S.TaggedErrorClass<"InvalidOriginKeepaliveTimeout", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidOriginKeepaliveTimeout extends /*@__PURE__*/ InvalidOriginKeepaliveTimeout_base {
}
declare const InvalidOriginReadTimeout_base: S.TaggedErrorClass<"InvalidOriginReadTimeout", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidOriginReadTimeout extends /*@__PURE__*/ InvalidOriginReadTimeout_base {
}
declare const InvalidProtocolSettings_base: S.TaggedErrorClass<"InvalidProtocolSettings", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidProtocolSettings extends /*@__PURE__*/ InvalidProtocolSettings_base {
}
declare const InvalidQueryStringParameters_base: S.TaggedErrorClass<"InvalidQueryStringParameters", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidQueryStringParameters extends /*@__PURE__*/ InvalidQueryStringParameters_base {
}
declare const InvalidRelativePath_base: S.TaggedErrorClass<"InvalidRelativePath", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRelativePath extends /*@__PURE__*/ InvalidRelativePath_base {
}
declare const InvalidRequiredProtocol_base: S.TaggedErrorClass<"InvalidRequiredProtocol", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequiredProtocol extends /*@__PURE__*/ InvalidRequiredProtocol_base {
}
declare const InvalidResponseCode_base: S.TaggedErrorClass<"InvalidResponseCode", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidResponseCode extends /*@__PURE__*/ InvalidResponseCode_base {
}
declare const InvalidTagging_base: S.TaggedErrorClass<"InvalidTagging", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTagging extends /*@__PURE__*/ InvalidTagging_base {
}
declare const InvalidTTLOrder_base: S.TaggedErrorClass<"InvalidTTLOrder", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTTLOrder extends /*@__PURE__*/ InvalidTTLOrder_base {
}
declare const InvalidViewerCertificate_base: S.TaggedErrorClass<"InvalidViewerCertificate", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidViewerCertificate extends /*@__PURE__*/ InvalidViewerCertificate_base {
}
declare const InvalidWebACLId_base: S.TaggedErrorClass<"InvalidWebACLId", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidWebACLId extends /*@__PURE__*/ InvalidWebACLId_base {
}
declare const KeyGroupAlreadyExists_base: S.TaggedErrorClass<"KeyGroupAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class KeyGroupAlreadyExists extends /*@__PURE__*/ KeyGroupAlreadyExists_base {
}
declare const MissingBody_base: S.TaggedErrorClass<"MissingBody", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MissingBody extends /*@__PURE__*/ MissingBody_base {
}
declare const MonitoringSubscriptionAlreadyExists_base: S.TaggedErrorClass<"MonitoringSubscriptionAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class MonitoringSubscriptionAlreadyExists extends /*@__PURE__*/ MonitoringSubscriptionAlreadyExists_base {
}
declare const NoSuchCachePolicy_base: S.TaggedErrorClass<"NoSuchCachePolicy", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchCachePolicy extends /*@__PURE__*/ NoSuchCachePolicy_base {
}
declare const NoSuchCloudFrontOriginAccessIdentity_base: S.TaggedErrorClass<"NoSuchCloudFrontOriginAccessIdentity", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchCloudFrontOriginAccessIdentity extends /*@__PURE__*/ NoSuchCloudFrontOriginAccessIdentity_base {
}
declare const NoSuchContinuousDeploymentPolicy_base: S.TaggedErrorClass<"NoSuchContinuousDeploymentPolicy", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchContinuousDeploymentPolicy extends /*@__PURE__*/ NoSuchContinuousDeploymentPolicy_base {
}
declare const NoSuchDistribution_base: S.TaggedErrorClass<"NoSuchDistribution", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchDistribution extends /*@__PURE__*/ NoSuchDistribution_base {
}
declare const NoSuchFieldLevelEncryptionConfig_base: S.TaggedErrorClass<"NoSuchFieldLevelEncryptionConfig", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchFieldLevelEncryptionConfig extends /*@__PURE__*/ NoSuchFieldLevelEncryptionConfig_base {
}
declare const NoSuchFieldLevelEncryptionProfile_base: S.TaggedErrorClass<"NoSuchFieldLevelEncryptionProfile", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchFieldLevelEncryptionProfile extends /*@__PURE__*/ NoSuchFieldLevelEncryptionProfile_base {
}
declare const NoSuchFunctionExists_base: S.TaggedErrorClass<"NoSuchFunctionExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchFunctionExists extends /*@__PURE__*/ NoSuchFunctionExists_base {
}
declare const NoSuchInvalidation_base: S.TaggedErrorClass<"NoSuchInvalidation", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchInvalidation extends /*@__PURE__*/ NoSuchInvalidation_base {
}
declare const NoSuchMonitoringSubscription_base: S.TaggedErrorClass<"NoSuchMonitoringSubscription", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchMonitoringSubscription extends /*@__PURE__*/ NoSuchMonitoringSubscription_base {
}
declare const NoSuchOrigin_base: S.TaggedErrorClass<"NoSuchOrigin", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchOrigin extends /*@__PURE__*/ NoSuchOrigin_base {
}
declare const NoSuchOriginAccessControl_base: S.TaggedErrorClass<"NoSuchOriginAccessControl", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchOriginAccessControl extends /*@__PURE__*/ NoSuchOriginAccessControl_base {
}
declare const NoSuchOriginRequestPolicy_base: S.TaggedErrorClass<"NoSuchOriginRequestPolicy", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchOriginRequestPolicy extends /*@__PURE__*/ NoSuchOriginRequestPolicy_base {
}
declare const NoSuchPublicKey_base: S.TaggedErrorClass<"NoSuchPublicKey", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchPublicKey extends /*@__PURE__*/ NoSuchPublicKey_base {
}
declare const NoSuchRealtimeLogConfig_base: S.TaggedErrorClass<"NoSuchRealtimeLogConfig", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchRealtimeLogConfig extends /*@__PURE__*/ NoSuchRealtimeLogConfig_base {
}
declare const NoSuchResource_base: S.TaggedErrorClass<"NoSuchResource", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchResource extends /*@__PURE__*/ NoSuchResource_base {
}
declare const NoSuchResponseHeadersPolicy_base: S.TaggedErrorClass<"NoSuchResponseHeadersPolicy", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchResponseHeadersPolicy extends /*@__PURE__*/ NoSuchResponseHeadersPolicy_base {
}
declare const NoSuchStreamingDistribution_base: S.TaggedErrorClass<"NoSuchStreamingDistribution", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchStreamingDistribution extends /*@__PURE__*/ NoSuchStreamingDistribution_base {
}
declare const OriginAccessControlAlreadyExists_base: S.TaggedErrorClass<"OriginAccessControlAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class OriginAccessControlAlreadyExists extends /*@__PURE__*/ OriginAccessControlAlreadyExists_base {
}
declare const OriginAccessControlInUse_base: S.TaggedErrorClass<"OriginAccessControlInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class OriginAccessControlInUse extends /*@__PURE__*/ OriginAccessControlInUse_base {
}
declare const OriginRequestPolicyAlreadyExists_base: S.TaggedErrorClass<"OriginRequestPolicyAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class OriginRequestPolicyAlreadyExists extends /*@__PURE__*/ OriginRequestPolicyAlreadyExists_base {
}
declare const OriginRequestPolicyInUse_base: S.TaggedErrorClass<"OriginRequestPolicyInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class OriginRequestPolicyInUse extends /*@__PURE__*/ OriginRequestPolicyInUse_base {
}
declare const PreconditionFailed_base: S.TaggedErrorClass<"PreconditionFailed", {
    readonly message: any;
}>;
export declare class PreconditionFailed extends /*@__PURE__*/ PreconditionFailed_base {
}
declare const PublicKeyAlreadyExists_base: S.TaggedErrorClass<"PublicKeyAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class PublicKeyAlreadyExists extends /*@__PURE__*/ PublicKeyAlreadyExists_base {
}
declare const PublicKeyInUse_base: S.TaggedErrorClass<"PublicKeyInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class PublicKeyInUse extends /*@__PURE__*/ PublicKeyInUse_base {
}
declare const QueryArgProfileEmpty_base: S.TaggedErrorClass<"QueryArgProfileEmpty", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class QueryArgProfileEmpty extends /*@__PURE__*/ QueryArgProfileEmpty_base {
}
declare const RealtimeLogConfigAlreadyExists_base: S.TaggedErrorClass<"RealtimeLogConfigAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class RealtimeLogConfigAlreadyExists extends /*@__PURE__*/ RealtimeLogConfigAlreadyExists_base {
}
declare const RealtimeLogConfigInUse_base: S.TaggedErrorClass<"RealtimeLogConfigInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class RealtimeLogConfigInUse extends /*@__PURE__*/ RealtimeLogConfigInUse_base {
}
declare const RealtimeLogConfigOwnerMismatch_base: S.TaggedErrorClass<"RealtimeLogConfigOwnerMismatch", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class RealtimeLogConfigOwnerMismatch extends /*@__PURE__*/ RealtimeLogConfigOwnerMismatch_base {
}
declare const ResourceInUse_base: S.TaggedErrorClass<"ResourceInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class ResourceInUse extends /*@__PURE__*/ ResourceInUse_base {
}
declare const ResourceNotDisabled_base: S.TaggedErrorClass<"ResourceNotDisabled", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceNotDisabled extends /*@__PURE__*/ ResourceNotDisabled_base {
}
declare const ResponseHeadersPolicyAlreadyExists_base: S.TaggedErrorClass<"ResponseHeadersPolicyAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResponseHeadersPolicyAlreadyExists extends /*@__PURE__*/ ResponseHeadersPolicyAlreadyExists_base {
}
declare const ResponseHeadersPolicyInUse_base: S.TaggedErrorClass<"ResponseHeadersPolicyInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class ResponseHeadersPolicyInUse extends /*@__PURE__*/ ResponseHeadersPolicyInUse_base {
}
declare const StagingDistributionInUse_base: S.TaggedErrorClass<"StagingDistributionInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class StagingDistributionInUse extends /*@__PURE__*/ StagingDistributionInUse_base {
}
declare const StreamingDistributionAlreadyExists_base: S.TaggedErrorClass<"StreamingDistributionAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class StreamingDistributionAlreadyExists extends /*@__PURE__*/ StreamingDistributionAlreadyExists_base {
}
declare const StreamingDistributionNotDisabled_base: S.TaggedErrorClass<"StreamingDistributionNotDisabled", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class StreamingDistributionNotDisabled extends /*@__PURE__*/ StreamingDistributionNotDisabled_base {
}
declare const TestFunctionFailed_base: S.TaggedErrorClass<"TestFunctionFailed", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class TestFunctionFailed extends /*@__PURE__*/ TestFunctionFailed_base {
}
declare const TooLongCSPInResponseHeadersPolicy_base: S.TaggedErrorClass<"TooLongCSPInResponseHeadersPolicy", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooLongCSPInResponseHeadersPolicy extends /*@__PURE__*/ TooLongCSPInResponseHeadersPolicy_base {
}
declare const TooManyCacheBehaviors_base: S.TaggedErrorClass<"TooManyCacheBehaviors", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyCacheBehaviors extends /*@__PURE__*/ TooManyCacheBehaviors_base {
}
declare const TooManyCachePolicies_base: S.TaggedErrorClass<"TooManyCachePolicies", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyCachePolicies extends /*@__PURE__*/ TooManyCachePolicies_base {
}
declare const TooManyCertificates_base: S.TaggedErrorClass<"TooManyCertificates", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyCertificates extends /*@__PURE__*/ TooManyCertificates_base {
}
declare const TooManyCloudFrontOriginAccessIdentities_base: S.TaggedErrorClass<"TooManyCloudFrontOriginAccessIdentities", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyCloudFrontOriginAccessIdentities extends /*@__PURE__*/ TooManyCloudFrontOriginAccessIdentities_base {
}
declare const TooManyContinuousDeploymentPolicies_base: S.TaggedErrorClass<"TooManyContinuousDeploymentPolicies", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyContinuousDeploymentPolicies extends /*@__PURE__*/ TooManyContinuousDeploymentPolicies_base {
}
declare const TooManyCookieNamesInWhiteList_base: S.TaggedErrorClass<"TooManyCookieNamesInWhiteList", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyCookieNamesInWhiteList extends /*@__PURE__*/ TooManyCookieNamesInWhiteList_base {
}
declare const TooManyCookiesInCachePolicy_base: S.TaggedErrorClass<"TooManyCookiesInCachePolicy", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyCookiesInCachePolicy extends /*@__PURE__*/ TooManyCookiesInCachePolicy_base {
}
declare const TooManyCookiesInOriginRequestPolicy_base: S.TaggedErrorClass<"TooManyCookiesInOriginRequestPolicy", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyCookiesInOriginRequestPolicy extends /*@__PURE__*/ TooManyCookiesInOriginRequestPolicy_base {
}
declare const TooManyCustomHeadersInResponseHeadersPolicy_base: S.TaggedErrorClass<"TooManyCustomHeadersInResponseHeadersPolicy", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyCustomHeadersInResponseHeadersPolicy extends /*@__PURE__*/ TooManyCustomHeadersInResponseHeadersPolicy_base {
}
declare const TooManyDistributionCNAMEs_base: S.TaggedErrorClass<"TooManyDistributionCNAMEs", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributionCNAMEs extends /*@__PURE__*/ TooManyDistributionCNAMEs_base {
}
declare const TooManyDistributions_base: S.TaggedErrorClass<"TooManyDistributions", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributions extends /*@__PURE__*/ TooManyDistributions_base {
}
declare const TooManyDistributionsAssociatedToCachePolicy_base: S.TaggedErrorClass<"TooManyDistributionsAssociatedToCachePolicy", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributionsAssociatedToCachePolicy extends /*@__PURE__*/ TooManyDistributionsAssociatedToCachePolicy_base {
}
declare const TooManyDistributionsAssociatedToFieldLevelEncryptionConfig_base: S.TaggedErrorClass<"TooManyDistributionsAssociatedToFieldLevelEncryptionConfig", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributionsAssociatedToFieldLevelEncryptionConfig extends /*@__PURE__*/ TooManyDistributionsAssociatedToFieldLevelEncryptionConfig_base {
}
declare const TooManyDistributionsAssociatedToKeyGroup_base: S.TaggedErrorClass<"TooManyDistributionsAssociatedToKeyGroup", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributionsAssociatedToKeyGroup extends /*@__PURE__*/ TooManyDistributionsAssociatedToKeyGroup_base {
}
declare const TooManyDistributionsAssociatedToOriginAccessControl_base: S.TaggedErrorClass<"TooManyDistributionsAssociatedToOriginAccessControl", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributionsAssociatedToOriginAccessControl extends /*@__PURE__*/ TooManyDistributionsAssociatedToOriginAccessControl_base {
}
declare const TooManyDistributionsAssociatedToOriginRequestPolicy_base: S.TaggedErrorClass<"TooManyDistributionsAssociatedToOriginRequestPolicy", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributionsAssociatedToOriginRequestPolicy extends /*@__PURE__*/ TooManyDistributionsAssociatedToOriginRequestPolicy_base {
}
declare const TooManyDistributionsAssociatedToResponseHeadersPolicy_base: S.TaggedErrorClass<"TooManyDistributionsAssociatedToResponseHeadersPolicy", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributionsAssociatedToResponseHeadersPolicy extends /*@__PURE__*/ TooManyDistributionsAssociatedToResponseHeadersPolicy_base {
}
declare const TooManyDistributionsWithFunctionAssociations_base: S.TaggedErrorClass<"TooManyDistributionsWithFunctionAssociations", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributionsWithFunctionAssociations extends /*@__PURE__*/ TooManyDistributionsWithFunctionAssociations_base {
}
declare const TooManyDistributionsWithLambdaAssociations_base: S.TaggedErrorClass<"TooManyDistributionsWithLambdaAssociations", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributionsWithLambdaAssociations extends /*@__PURE__*/ TooManyDistributionsWithLambdaAssociations_base {
}
declare const TooManyDistributionsWithSingleFunctionARN_base: S.TaggedErrorClass<"TooManyDistributionsWithSingleFunctionARN", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributionsWithSingleFunctionARN extends /*@__PURE__*/ TooManyDistributionsWithSingleFunctionARN_base {
}
declare const TooManyFieldLevelEncryptionConfigs_base: S.TaggedErrorClass<"TooManyFieldLevelEncryptionConfigs", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyFieldLevelEncryptionConfigs extends /*@__PURE__*/ TooManyFieldLevelEncryptionConfigs_base {
}
declare const TooManyFieldLevelEncryptionContentTypeProfiles_base: S.TaggedErrorClass<"TooManyFieldLevelEncryptionContentTypeProfiles", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyFieldLevelEncryptionContentTypeProfiles extends /*@__PURE__*/ TooManyFieldLevelEncryptionContentTypeProfiles_base {
}
declare const TooManyFieldLevelEncryptionEncryptionEntities_base: S.TaggedErrorClass<"TooManyFieldLevelEncryptionEncryptionEntities", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyFieldLevelEncryptionEncryptionEntities extends /*@__PURE__*/ TooManyFieldLevelEncryptionEncryptionEntities_base {
}
declare const TooManyFieldLevelEncryptionFieldPatterns_base: S.TaggedErrorClass<"TooManyFieldLevelEncryptionFieldPatterns", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyFieldLevelEncryptionFieldPatterns extends /*@__PURE__*/ TooManyFieldLevelEncryptionFieldPatterns_base {
}
declare const TooManyFieldLevelEncryptionProfiles_base: S.TaggedErrorClass<"TooManyFieldLevelEncryptionProfiles", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyFieldLevelEncryptionProfiles extends /*@__PURE__*/ TooManyFieldLevelEncryptionProfiles_base {
}
declare const TooManyFieldLevelEncryptionQueryArgProfiles_base: S.TaggedErrorClass<"TooManyFieldLevelEncryptionQueryArgProfiles", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyFieldLevelEncryptionQueryArgProfiles extends /*@__PURE__*/ TooManyFieldLevelEncryptionQueryArgProfiles_base {
}
declare const TooManyFunctionAssociations_base: S.TaggedErrorClass<"TooManyFunctionAssociations", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyFunctionAssociations extends /*@__PURE__*/ TooManyFunctionAssociations_base {
}
declare const TooManyFunctions_base: S.TaggedErrorClass<"TooManyFunctions", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyFunctions extends /*@__PURE__*/ TooManyFunctions_base {
}
declare const TooManyHeadersInCachePolicy_base: S.TaggedErrorClass<"TooManyHeadersInCachePolicy", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyHeadersInCachePolicy extends /*@__PURE__*/ TooManyHeadersInCachePolicy_base {
}
declare const TooManyHeadersInForwardedValues_base: S.TaggedErrorClass<"TooManyHeadersInForwardedValues", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyHeadersInForwardedValues extends /*@__PURE__*/ TooManyHeadersInForwardedValues_base {
}
declare const TooManyHeadersInOriginRequestPolicy_base: S.TaggedErrorClass<"TooManyHeadersInOriginRequestPolicy", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyHeadersInOriginRequestPolicy extends /*@__PURE__*/ TooManyHeadersInOriginRequestPolicy_base {
}
declare const TooManyInvalidationsInProgress_base: S.TaggedErrorClass<"TooManyInvalidationsInProgress", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyInvalidationsInProgress extends /*@__PURE__*/ TooManyInvalidationsInProgress_base {
}
declare const TooManyKeyGroups_base: S.TaggedErrorClass<"TooManyKeyGroups", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyKeyGroups extends /*@__PURE__*/ TooManyKeyGroups_base {
}
declare const TooManyKeyGroupsAssociatedToDistribution_base: S.TaggedErrorClass<"TooManyKeyGroupsAssociatedToDistribution", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyKeyGroupsAssociatedToDistribution extends /*@__PURE__*/ TooManyKeyGroupsAssociatedToDistribution_base {
}
declare const TooManyLambdaFunctionAssociations_base: S.TaggedErrorClass<"TooManyLambdaFunctionAssociations", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyLambdaFunctionAssociations extends /*@__PURE__*/ TooManyLambdaFunctionAssociations_base {
}
declare const TooManyOriginAccessControls_base: S.TaggedErrorClass<"TooManyOriginAccessControls", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyOriginAccessControls extends /*@__PURE__*/ TooManyOriginAccessControls_base {
}
declare const TooManyOriginCustomHeaders_base: S.TaggedErrorClass<"TooManyOriginCustomHeaders", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyOriginCustomHeaders extends /*@__PURE__*/ TooManyOriginCustomHeaders_base {
}
declare const TooManyOriginGroupsPerDistribution_base: S.TaggedErrorClass<"TooManyOriginGroupsPerDistribution", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyOriginGroupsPerDistribution extends /*@__PURE__*/ TooManyOriginGroupsPerDistribution_base {
}
declare const TooManyOriginRequestPolicies_base: S.TaggedErrorClass<"TooManyOriginRequestPolicies", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyOriginRequestPolicies extends /*@__PURE__*/ TooManyOriginRequestPolicies_base {
}
declare const TooManyOrigins_base: S.TaggedErrorClass<"TooManyOrigins", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyOrigins extends /*@__PURE__*/ TooManyOrigins_base {
}
declare const TooManyPublicKeys_base: S.TaggedErrorClass<"TooManyPublicKeys", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyPublicKeys extends /*@__PURE__*/ TooManyPublicKeys_base {
}
declare const TooManyPublicKeysInKeyGroup_base: S.TaggedErrorClass<"TooManyPublicKeysInKeyGroup", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyPublicKeysInKeyGroup extends /*@__PURE__*/ TooManyPublicKeysInKeyGroup_base {
}
declare const TooManyQueryStringParameters_base: S.TaggedErrorClass<"TooManyQueryStringParameters", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyQueryStringParameters extends /*@__PURE__*/ TooManyQueryStringParameters_base {
}
declare const TooManyQueryStringsInCachePolicy_base: S.TaggedErrorClass<"TooManyQueryStringsInCachePolicy", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyQueryStringsInCachePolicy extends /*@__PURE__*/ TooManyQueryStringsInCachePolicy_base {
}
declare const TooManyQueryStringsInOriginRequestPolicy_base: S.TaggedErrorClass<"TooManyQueryStringsInOriginRequestPolicy", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyQueryStringsInOriginRequestPolicy extends /*@__PURE__*/ TooManyQueryStringsInOriginRequestPolicy_base {
}
declare const TooManyRealtimeLogConfigs_base: S.TaggedErrorClass<"TooManyRealtimeLogConfigs", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyRealtimeLogConfigs extends /*@__PURE__*/ TooManyRealtimeLogConfigs_base {
}
declare const TooManyRemoveHeadersInResponseHeadersPolicy_base: S.TaggedErrorClass<"TooManyRemoveHeadersInResponseHeadersPolicy", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyRemoveHeadersInResponseHeadersPolicy extends /*@__PURE__*/ TooManyRemoveHeadersInResponseHeadersPolicy_base {
}
declare const TooManyResponseHeadersPolicies_base: S.TaggedErrorClass<"TooManyResponseHeadersPolicies", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyResponseHeadersPolicies extends /*@__PURE__*/ TooManyResponseHeadersPolicies_base {
}
declare const TooManyStreamingDistributionCNAMEs_base: S.TaggedErrorClass<"TooManyStreamingDistributionCNAMEs", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyStreamingDistributionCNAMEs extends /*@__PURE__*/ TooManyStreamingDistributionCNAMEs_base {
}
declare const TooManyStreamingDistributions_base: S.TaggedErrorClass<"TooManyStreamingDistributions", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyStreamingDistributions extends /*@__PURE__*/ TooManyStreamingDistributions_base {
}
declare const TooManyTrustedSigners_base: S.TaggedErrorClass<"TooManyTrustedSigners", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTrustedSigners extends /*@__PURE__*/ TooManyTrustedSigners_base {
}
declare const TrustedKeyGroupDoesNotExist_base: S.TaggedErrorClass<"TrustedKeyGroupDoesNotExist", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TrustedKeyGroupDoesNotExist extends /*@__PURE__*/ TrustedKeyGroupDoesNotExist_base {
}
declare const TrustedSignerDoesNotExist_base: S.TaggedErrorClass<"TrustedSignerDoesNotExist", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TrustedSignerDoesNotExist extends /*@__PURE__*/ TrustedSignerDoesNotExist_base {
}
declare const UnsupportedOperation_base: S.TaggedErrorClass<"UnsupportedOperation", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedOperation extends /*@__PURE__*/ UnsupportedOperation_base {
}
export interface AssociateAliasRequest {
    TargetDistributionId: string;
    Alias: string;
}
export interface AssociateAliasResponse {
}
export interface AssociateDistributionTenantWebACLRequest {
    Id: string;
    WebACLArn: string;
    IfMatch?: string;
}
export interface AssociateDistributionTenantWebACLResult {
    Id?: string;
    WebACLArn?: string;
    ETag?: string;
}
export interface AssociateDistributionWebACLRequest {
    Id: string;
    WebACLArn: string;
    IfMatch?: string;
}
export interface AssociateDistributionWebACLResult {
    Id?: string;
    WebACLArn?: string;
    ETag?: string;
}
export interface CopyDistributionRequest {
    PrimaryDistributionId: string;
    Staging?: boolean;
    IfMatch?: string;
    CallerReference: string;
    Enabled?: boolean;
}
export type KeyPairIdList = string[];
export interface KeyPairIds {
    Quantity: number;
    Items?: string[];
}
export interface Signer {
    AwsAccountNumber?: string;
    KeyPairIds?: KeyPairIds;
}
export type SignerList = Signer[];
export interface ActiveTrustedSigners {
    Enabled: boolean;
    Quantity: number;
    Items?: Signer[];
}
export interface KGKeyPairIds {
    KeyGroupId?: string;
    KeyPairIds?: KeyPairIds;
}
export type KGKeyPairIdsList = KGKeyPairIds[];
export interface ActiveTrustedKeyGroups {
    Enabled: boolean;
    Quantity: number;
    Items?: KGKeyPairIds[];
}
export type AliasList = string[];
export interface Aliases {
    Quantity: number;
    Items?: string[];
}
export type SensitiveStringType = string | redacted.Redacted<string>;
export interface OriginCustomHeader {
    HeaderName: string;
    HeaderValue: string | redacted.Redacted<string>;
}
export type OriginCustomHeadersList = OriginCustomHeader[];
export interface CustomHeaders {
    Quantity: number;
    Items?: OriginCustomHeader[];
}
export interface S3OriginConfig {
    OriginAccessIdentity?: string;
    OriginReadTimeout?: number;
}
export type OriginProtocolPolicy = "http-only" | "match-viewer" | "https-only" | (string & {});
export type SslProtocol = "SSLv3" | "TLSv1" | "TLSv1.1" | "TLSv1.2" | (string & {});
export type SslProtocolsList = SslProtocol[];
export interface OriginSslProtocols {
    Quantity: number;
    Items: SslProtocol[];
}
export type IpAddressType = "ipv4" | "ipv6" | "dualstack" | (string & {});
export interface OriginMtlsConfig {
    ClientCertificateArn: string;
}
export interface CustomOriginConfig {
    HTTPPort: number;
    HTTPSPort: number;
    OriginProtocolPolicy: OriginProtocolPolicy;
    OriginSslProtocols?: OriginSslProtocols;
    OriginReadTimeout?: number;
    OriginKeepaliveTimeout?: number;
    IpAddressType?: IpAddressType;
    OriginMtlsConfig?: OriginMtlsConfig;
}
export interface VpcOriginConfig {
    VpcOriginId: string;
    OwnerAccountId?: string;
    OriginReadTimeout?: number;
    OriginKeepaliveTimeout?: number;
}
export type OriginShieldRegion = string;
export interface OriginShield {
    Enabled: boolean;
    OriginShieldRegion?: string;
}
export interface Origin {
    Id: string;
    DomainName: string;
    OriginPath?: string;
    CustomHeaders?: CustomHeaders;
    S3OriginConfig?: S3OriginConfig;
    CustomOriginConfig?: CustomOriginConfig;
    VpcOriginConfig?: VpcOriginConfig;
    ConnectionAttempts?: number;
    ConnectionTimeout?: number;
    ResponseCompletionTimeout?: number;
    OriginShield?: OriginShield;
    OriginAccessControlId?: string;
}
export type OriginList = Origin[];
export interface Origins {
    Quantity: number;
    Items: Origin[];
}
export type StatusCodeList = number[];
export interface StatusCodes {
    Quantity: number;
    Items: number[];
}
export interface OriginGroupFailoverCriteria {
    StatusCodes: StatusCodes;
}
export interface OriginGroupMember {
    OriginId: string;
}
export type OriginGroupMemberList = OriginGroupMember[];
export interface OriginGroupMembers {
    Quantity: number;
    Items: OriginGroupMember[];
}
export type OriginGroupSelectionCriteria = "default" | "media-quality-based" | (string & {});
export interface OriginGroup {
    Id: string;
    FailoverCriteria: OriginGroupFailoverCriteria;
    Members: OriginGroupMembers;
    SelectionCriteria?: OriginGroupSelectionCriteria;
}
export type OriginGroupList = OriginGroup[];
export interface OriginGroups {
    Quantity: number;
    Items?: OriginGroup[];
}
export type AwsAccountNumberList = string[];
export interface TrustedSigners {
    Enabled: boolean;
    Quantity: number;
    Items?: string[];
}
export type TrustedKeyGroupIdList = string[];
export interface TrustedKeyGroups {
    Enabled: boolean;
    Quantity: number;
    Items?: string[];
}
export type ViewerProtocolPolicy = "allow-all" | "https-only" | "redirect-to-https" | (string & {});
export type Method = "GET" | "HEAD" | "POST" | "PUT" | "PATCH" | "OPTIONS" | "DELETE" | (string & {});
export type MethodsList = Method[];
export interface CachedMethods {
    Quantity: number;
    Items: Method[];
}
export interface AllowedMethods {
    Quantity: number;
    Items: Method[];
    CachedMethods?: CachedMethods;
}
export type LambdaFunctionARN = string;
export type EventType = "viewer-request" | "viewer-response" | "origin-request" | "origin-response" | (string & {});
export interface LambdaFunctionAssociation {
    LambdaFunctionARN: string;
    EventType: EventType;
    IncludeBody?: boolean;
}
export type LambdaFunctionAssociationList = LambdaFunctionAssociation[];
export interface LambdaFunctionAssociations {
    Quantity: number;
    Items?: LambdaFunctionAssociation[];
}
export type FunctionARN = string;
export interface FunctionAssociation {
    FunctionARN: string;
    EventType: EventType;
}
export type FunctionAssociationList = FunctionAssociation[];
export interface FunctionAssociations {
    Quantity: number;
    Items?: FunctionAssociation[];
}
export interface GrpcConfig {
    Enabled: boolean;
}
export type ItemSelection = "none" | "whitelist" | "all" | (string & {});
export type CookieNameList = string[];
export interface CookieNames {
    Quantity: number;
    Items?: string[];
}
export interface CookiePreference {
    Forward: ItemSelection;
    WhitelistedNames?: CookieNames;
}
export type HeaderList = string[];
export interface Headers {
    Quantity: number;
    Items?: string[];
}
export type QueryStringCacheKeysList = string[];
export interface QueryStringCacheKeys {
    Quantity: number;
    Items?: string[];
}
export interface ForwardedValues {
    QueryString: boolean;
    Cookies: CookiePreference;
    Headers?: Headers;
    QueryStringCacheKeys?: QueryStringCacheKeys;
}
export interface DefaultCacheBehavior {
    TargetOriginId: string;
    TrustedSigners?: TrustedSigners;
    TrustedKeyGroups?: TrustedKeyGroups;
    ViewerProtocolPolicy: ViewerProtocolPolicy;
    AllowedMethods?: AllowedMethods;
    SmoothStreaming?: boolean;
    Compress?: boolean;
    LambdaFunctionAssociations?: LambdaFunctionAssociations;
    FunctionAssociations?: FunctionAssociations;
    FieldLevelEncryptionId?: string;
    RealtimeLogConfigArn?: string;
    CachePolicyId?: string;
    OriginRequestPolicyId?: string;
    ResponseHeadersPolicyId?: string;
    GrpcConfig?: GrpcConfig;
    ForwardedValues?: ForwardedValues;
    MinTTL?: number;
    DefaultTTL?: number;
    MaxTTL?: number;
}
export interface CacheBehavior {
    PathPattern: string;
    TargetOriginId: string;
    TrustedSigners?: TrustedSigners;
    TrustedKeyGroups?: TrustedKeyGroups;
    ViewerProtocolPolicy: ViewerProtocolPolicy;
    AllowedMethods?: AllowedMethods;
    SmoothStreaming?: boolean;
    Compress?: boolean;
    LambdaFunctionAssociations?: LambdaFunctionAssociations;
    FunctionAssociations?: FunctionAssociations;
    FieldLevelEncryptionId?: string;
    RealtimeLogConfigArn?: string;
    CachePolicyId?: string;
    OriginRequestPolicyId?: string;
    ResponseHeadersPolicyId?: string;
    GrpcConfig?: GrpcConfig;
    ForwardedValues?: ForwardedValues;
    MinTTL?: number;
    DefaultTTL?: number;
    MaxTTL?: number;
}
export type CacheBehaviorList = CacheBehavior[];
export interface CacheBehaviors {
    Quantity: number;
    Items?: CacheBehavior[];
}
export interface CustomErrorResponse {
    ErrorCode: number;
    ResponsePagePath?: string;
    ResponseCode?: string;
    ErrorCachingMinTTL?: number;
}
export type CustomErrorResponseList = CustomErrorResponse[];
export interface CustomErrorResponses {
    Quantity: number;
    Items?: CustomErrorResponse[];
}
export type CommentType = string | redacted.Redacted<string>;
export interface LoggingConfig {
    Enabled?: boolean;
    IncludeCookies?: boolean;
    Bucket?: string;
    Prefix?: string;
}
export type PriceClass = "PriceClass_100" | "PriceClass_200" | "PriceClass_All" | "None" | (string & {});
export type ServerCertificateId = string;
export type SSLSupportMethod = "sni-only" | "vip" | "static-ip" | (string & {});
export type MinimumProtocolVersion = "SSLv3" | "TLSv1" | "TLSv1_2016" | "TLSv1.1_2016" | "TLSv1.2_2018" | "TLSv1.2_2019" | "TLSv1.2_2021" | "TLSv1.3_2025" | "TLSv1.2_2025" | (string & {});
export type CertificateSource = "cloudfront" | "iam" | "acm" | (string & {});
export interface ViewerCertificate {
    CloudFrontDefaultCertificate?: boolean;
    IAMCertificateId?: string;
    ACMCertificateArn?: string;
    SSLSupportMethod?: SSLSupportMethod;
    MinimumProtocolVersion?: MinimumProtocolVersion;
    Certificate?: string;
    CertificateSource?: CertificateSource;
}
export type GeoRestrictionType = "blacklist" | "whitelist" | "none" | (string & {});
export type LocationList = string[];
export interface GeoRestriction {
    RestrictionType: GeoRestrictionType;
    Quantity: number;
    Items?: string[];
}
export interface Restrictions {
    GeoRestriction: GeoRestriction;
}
export type HttpVersion = "http1.1" | "http2" | "http3" | "http2and3" | "HTTP1.1" | "HTTP2" | "HTTP3" | "HTTP2AND3" | (string & {});
export type ParameterName = string;
export type ParameterValue = string;
export interface StringSchemaConfig {
    Comment?: string | redacted.Redacted<string>;
    DefaultValue?: string;
    Required: boolean;
}
export interface ParameterDefinitionSchema {
    StringSchema?: StringSchemaConfig;
}
export interface ParameterDefinition {
    Name: string;
    Definition: ParameterDefinitionSchema;
}
export type ParameterDefinitions = ParameterDefinition[];
export interface TenantConfig {
    ParameterDefinitions?: ParameterDefinition[];
}
export type ConnectionMode = "direct" | "tenant-only" | (string & {});
export type ViewerMtlsMode = "required" | "optional" | "passthrough" | (string & {});
export interface TrustStoreConfig {
    TrustStoreId: string;
    AdvertiseTrustStoreCaNames?: boolean;
    IgnoreCertificateExpiry?: boolean;
}
export interface ViewerMtlsConfig {
    Mode?: ViewerMtlsMode;
    TrustStoreConfig?: TrustStoreConfig;
}
export type ResourceId = string;
export interface ConnectionFunctionAssociation {
    Id: string;
}
export interface CacheTagConfig {
    HeaderName: string;
}
export interface DistributionConfig {
    CallerReference: string;
    Aliases?: Aliases;
    DefaultRootObject?: string;
    Origins: Origins;
    OriginGroups?: OriginGroups;
    DefaultCacheBehavior: DefaultCacheBehavior;
    CacheBehaviors?: CacheBehaviors;
    CustomErrorResponses?: CustomErrorResponses;
    Comment: string | redacted.Redacted<string>;
    Logging?: LoggingConfig;
    PriceClass?: PriceClass;
    Enabled: boolean;
    ViewerCertificate?: ViewerCertificate;
    Restrictions?: Restrictions;
    WebACLId?: string;
    HttpVersion?: HttpVersion;
    IsIPV6Enabled?: boolean;
    ContinuousDeploymentPolicyId?: string;
    Staging?: boolean;
    AnycastIpListId?: string;
    TenantConfig?: TenantConfig;
    ConnectionMode?: ConnectionMode;
    ViewerMtlsConfig?: ViewerMtlsConfig;
    ConnectionFunctionAssociation?: ConnectionFunctionAssociation;
    CacheTagConfig?: CacheTagConfig;
}
export type ICPRecordalStatus = "APPROVED" | "SUSPENDED" | "PENDING" | (string & {});
export interface AliasICPRecordal {
    CNAME?: string;
    ICPRecordalStatus?: ICPRecordalStatus;
}
export type AliasICPRecordals = AliasICPRecordal[];
export interface Distribution {
    Id: string;
    ARN: string;
    Status: string;
    LastModifiedTime: Date;
    InProgressInvalidationBatches: number;
    DomainName: string;
    ActiveTrustedSigners?: ActiveTrustedSigners;
    ActiveTrustedKeyGroups?: ActiveTrustedKeyGroups;
    DistributionConfig: DistributionConfig;
    AliasICPRecordals?: AliasICPRecordal[];
}
export interface CopyDistributionResult {
    Distribution?: Distribution;
    Location?: string;
    ETag?: string;
}
export type AnycastIpListName = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value?: string;
}
export type TagList = Tag[];
export interface Tags {
    Items?: Tag[];
}
export type IpamCidrStatus = "provisioned" | "failed-provision" | "provisioning" | "deprovisioned" | "failed-deprovision" | "deprovisioning" | "advertised" | "failed-advertise" | "advertising" | "withdrawn" | "failed-withdraw" | "withdrawing" | (string & {});
export interface IpamCidrConfig {
    Cidr: string;
    IpamPoolArn: string;
    AnycastIp?: string;
    Status?: IpamCidrStatus;
}
export type IpamCidrConfigList = IpamCidrConfig[];
export interface CreateAnycastIpListRequest {
    Name: string;
    IpCount: number;
    Tags?: Tags;
    IpAddressType?: IpAddressType;
    IpamCidrConfigs?: IpamCidrConfig[];
}
export interface IpamConfig {
    Quantity: number;
    IpamCidrConfigs: IpamCidrConfig[];
}
export type AnycastIps = string[];
export interface AnycastIpList {
    Id: string;
    Name: string;
    Status: string;
    Arn: string;
    IpAddressType?: IpAddressType;
    IpamConfig?: IpamConfig;
    AnycastIps: string[];
    IpCount: number;
    LastModifiedTime: Date;
}
export interface CreateAnycastIpListResult {
    AnycastIpList?: AnycastIpList;
    ETag?: string;
}
export type CachePolicyHeaderBehavior = "none" | "whitelist" | (string & {});
export interface CachePolicyHeadersConfig {
    HeaderBehavior: CachePolicyHeaderBehavior;
    Headers?: Headers;
}
export type CachePolicyCookieBehavior = "none" | "whitelist" | "allExcept" | "all" | (string & {});
export interface CachePolicyCookiesConfig {
    CookieBehavior: CachePolicyCookieBehavior;
    Cookies?: CookieNames;
}
export type CachePolicyQueryStringBehavior = "none" | "whitelist" | "allExcept" | "all" | (string & {});
export type QueryStringNamesList = string[];
export interface QueryStringNames {
    Quantity: number;
    Items?: string[];
}
export interface CachePolicyQueryStringsConfig {
    QueryStringBehavior: CachePolicyQueryStringBehavior;
    QueryStrings?: QueryStringNames;
}
export interface ParametersInCacheKeyAndForwardedToOrigin {
    EnableAcceptEncodingGzip: boolean;
    EnableAcceptEncodingBrotli?: boolean;
    HeadersConfig: CachePolicyHeadersConfig;
    CookiesConfig: CachePolicyCookiesConfig;
    QueryStringsConfig: CachePolicyQueryStringsConfig;
}
export interface CachePolicyConfig {
    Comment?: string;
    Name: string;
    DefaultTTL?: number;
    MaxTTL?: number;
    MinTTL: number;
    ParametersInCacheKeyAndForwardedToOrigin?: ParametersInCacheKeyAndForwardedToOrigin;
}
export interface CreateCachePolicyRequest {
    CachePolicyConfig: CachePolicyConfig;
}
export interface CachePolicy {
    Id: string;
    LastModifiedTime: Date;
    CachePolicyConfig: CachePolicyConfig;
}
export interface CreateCachePolicyResult {
    CachePolicy?: CachePolicy;
    Location?: string;
    ETag?: string;
}
export interface CloudFrontOriginAccessIdentityConfig {
    CallerReference: string;
    Comment: string;
}
export interface CreateCloudFrontOriginAccessIdentityRequest {
    CloudFrontOriginAccessIdentityConfig: CloudFrontOriginAccessIdentityConfig;
}
export interface CloudFrontOriginAccessIdentity {
    Id: string;
    S3CanonicalUserId: string;
    CloudFrontOriginAccessIdentityConfig?: CloudFrontOriginAccessIdentityConfig;
}
export interface CreateCloudFrontOriginAccessIdentityResult {
    CloudFrontOriginAccessIdentity?: CloudFrontOriginAccessIdentity;
    Location?: string;
    ETag?: string;
}
export type FunctionName = string;
export type FunctionRuntime = "cloudfront-js-1.0" | "cloudfront-js-2.0" | (string & {});
export type KeyValueStoreARN = string;
export interface KeyValueStoreAssociation {
    KeyValueStoreARN: string;
}
export type KeyValueStoreAssociationList = KeyValueStoreAssociation[];
export interface KeyValueStoreAssociations {
    Quantity: number;
    Items?: KeyValueStoreAssociation[];
}
export interface FunctionConfig {
    Comment?: string;
    Runtime: FunctionRuntime;
    KeyValueStoreAssociations?: KeyValueStoreAssociations;
}
export type FunctionBlob = Uint8Array | redacted.Redacted<Uint8Array>;
export interface CreateConnectionFunctionRequest {
    Name: string;
    ConnectionFunctionConfig: FunctionConfig;
    ConnectionFunctionCode: Uint8Array | redacted.Redacted<Uint8Array>;
    Tags?: Tags;
}
export type FunctionStage = "DEVELOPMENT" | "LIVE" | (string & {});
export interface ConnectionFunctionSummary {
    Name: string;
    Id: string;
    ConnectionFunctionConfig: FunctionConfig;
    ConnectionFunctionArn: string;
    Status: string;
    Stage: FunctionStage;
    CreatedTime: Date;
    LastModifiedTime: Date;
}
export interface CreateConnectionFunctionResult {
    ConnectionFunctionSummary?: ConnectionFunctionSummary;
    Location?: string;
    ETag?: string;
}
export interface CreateConnectionGroupRequest {
    Name: string;
    Ipv6Enabled?: boolean;
    Tags?: Tags;
    AnycastIpListId?: string;
    Enabled?: boolean;
}
export interface ConnectionGroup {
    Id?: string;
    Name?: string;
    Arn?: string;
    CreatedTime?: Date;
    LastModifiedTime?: Date;
    Tags?: Tags;
    Ipv6Enabled?: boolean;
    RoutingEndpoint?: string;
    AnycastIpListId?: string;
    Status?: string;
    Enabled?: boolean;
    IsDefault?: boolean;
}
export interface CreateConnectionGroupResult {
    ConnectionGroup?: ConnectionGroup;
    ETag?: string;
}
export type StagingDistributionDnsNameList = string[];
export interface StagingDistributionDnsNames {
    Quantity: number;
    Items?: string[];
}
export interface SessionStickinessConfig {
    IdleTTL: number;
    MaximumTTL: number;
}
export interface ContinuousDeploymentSingleWeightConfig {
    Weight: number;
    SessionStickinessConfig?: SessionStickinessConfig;
}
export interface ContinuousDeploymentSingleHeaderConfig {
    Header: string;
    Value: string;
}
export type ContinuousDeploymentPolicyType = "SingleWeight" | "SingleHeader" | (string & {});
export interface TrafficConfig {
    SingleWeightConfig?: ContinuousDeploymentSingleWeightConfig;
    SingleHeaderConfig?: ContinuousDeploymentSingleHeaderConfig;
    Type: ContinuousDeploymentPolicyType;
}
export interface ContinuousDeploymentPolicyConfig {
    StagingDistributionDnsNames: StagingDistributionDnsNames;
    Enabled: boolean;
    TrafficConfig?: TrafficConfig;
}
export interface CreateContinuousDeploymentPolicyRequest {
    ContinuousDeploymentPolicyConfig: ContinuousDeploymentPolicyConfig;
}
export interface ContinuousDeploymentPolicy {
    Id: string;
    LastModifiedTime: Date;
    ContinuousDeploymentPolicyConfig: ContinuousDeploymentPolicyConfig;
}
export interface CreateContinuousDeploymentPolicyResult {
    ContinuousDeploymentPolicy?: ContinuousDeploymentPolicy;
    Location?: string;
    ETag?: string;
}
export interface CreateDistributionRequest {
    DistributionConfig: DistributionConfig;
}
export interface CreateDistributionResult {
    Distribution?: Distribution;
    Location?: string;
    ETag?: string;
}
export interface DomainItem {
    Domain: string;
}
export type DomainList = DomainItem[];
export type CustomizationActionType = "override" | "disable" | (string & {});
export interface WebAclCustomization {
    Action: CustomizationActionType;
    Arn?: string;
}
export interface Certificate {
    Arn: string;
}
export interface GeoRestrictionCustomization {
    RestrictionType: GeoRestrictionType;
    Locations?: string[];
}
export interface Customizations {
    WebAcl?: WebAclCustomization;
    Certificate?: Certificate;
    GeoRestrictions?: GeoRestrictionCustomization;
}
export interface Parameter {
    Name: string;
    Value: string;
}
export type Parameters = Parameter[];
export type ValidationTokenHost = "cloudfront" | "self-hosted" | (string & {});
export type CertificateTransparencyLoggingPreference = "enabled" | "disabled" | (string & {});
export interface ManagedCertificateRequest {
    ValidationTokenHost: ValidationTokenHost;
    PrimaryDomainName?: string;
    CertificateTransparencyLoggingPreference?: CertificateTransparencyLoggingPreference;
}
export interface CreateDistributionTenantRequest {
    DistributionId: string;
    Name: string;
    Domains: DomainItem[];
    Tags?: Tags;
    Customizations?: Customizations;
    Parameters?: Parameter[];
    ConnectionGroupId?: string;
    ManagedCertificateRequest?: ManagedCertificateRequest;
    Enabled?: boolean;
}
export type DomainStatus = "active" | "inactive" | (string & {});
export interface DomainResult {
    Domain: string;
    Status?: DomainStatus;
}
export type DomainResultList = DomainResult[];
export interface DistributionTenant {
    Id?: string;
    DistributionId?: string;
    Name?: string;
    Arn?: string;
    Domains?: DomainResult[];
    Tags?: Tags;
    Customizations?: Customizations;
    Parameters?: Parameter[];
    ConnectionGroupId?: string;
    CreatedTime?: Date;
    LastModifiedTime?: Date;
    Enabled?: boolean;
    Status?: string;
}
export interface CreateDistributionTenantResult {
    DistributionTenant?: DistributionTenant;
    ETag?: string;
}
export interface DistributionConfigWithTags {
    DistributionConfig: DistributionConfig;
    Tags: Tags;
}
export interface CreateDistributionWithTagsRequest {
    DistributionConfigWithTags: DistributionConfigWithTags;
}
export interface CreateDistributionWithTagsResult {
    Distribution?: Distribution;
    Location?: string;
    ETag?: string;
}
export interface QueryArgProfile {
    QueryArg: string;
    ProfileId: string;
}
export type QueryArgProfileList = QueryArgProfile[];
export interface QueryArgProfiles {
    Quantity: number;
    Items?: QueryArgProfile[];
}
export interface QueryArgProfileConfig {
    ForwardWhenQueryArgProfileIsUnknown: boolean;
    QueryArgProfiles?: QueryArgProfiles;
}
export type Format = "URLEncoded" | (string & {});
export interface ContentTypeProfile {
    Format: Format;
    ProfileId?: string;
    ContentType: string;
}
export type ContentTypeProfileList = ContentTypeProfile[];
export interface ContentTypeProfiles {
    Quantity: number;
    Items?: ContentTypeProfile[];
}
export interface ContentTypeProfileConfig {
    ForwardWhenContentTypeIsUnknown: boolean;
    ContentTypeProfiles?: ContentTypeProfiles;
}
export interface FieldLevelEncryptionConfig {
    CallerReference: string;
    Comment?: string;
    QueryArgProfileConfig?: QueryArgProfileConfig;
    ContentTypeProfileConfig?: ContentTypeProfileConfig;
}
export interface CreateFieldLevelEncryptionConfigRequest {
    FieldLevelEncryptionConfig: FieldLevelEncryptionConfig;
}
export interface FieldLevelEncryption {
    Id: string;
    LastModifiedTime: Date;
    FieldLevelEncryptionConfig: FieldLevelEncryptionConfig;
}
export interface CreateFieldLevelEncryptionConfigResult {
    FieldLevelEncryption?: FieldLevelEncryption;
    Location?: string;
    ETag?: string;
}
export type FieldPatternList = string[];
export interface FieldPatterns {
    Quantity: number;
    Items?: string[];
}
export interface EncryptionEntity {
    PublicKeyId: string;
    ProviderId: string;
    FieldPatterns: FieldPatterns;
}
export type EncryptionEntityList = EncryptionEntity[];
export interface EncryptionEntities {
    Quantity: number;
    Items?: EncryptionEntity[];
}
export interface FieldLevelEncryptionProfileConfig {
    Name: string;
    CallerReference: string;
    Comment?: string;
    EncryptionEntities: EncryptionEntities;
}
export interface CreateFieldLevelEncryptionProfileRequest {
    FieldLevelEncryptionProfileConfig: FieldLevelEncryptionProfileConfig;
}
export interface FieldLevelEncryptionProfile {
    Id: string;
    LastModifiedTime: Date;
    FieldLevelEncryptionProfileConfig: FieldLevelEncryptionProfileConfig;
}
export interface CreateFieldLevelEncryptionProfileResult {
    FieldLevelEncryptionProfile?: FieldLevelEncryptionProfile;
    Location?: string;
    ETag?: string;
}
export interface CreateFunctionRequest {
    Name: string;
    FunctionConfig: FunctionConfig;
    FunctionCode: Uint8Array | redacted.Redacted<Uint8Array>;
    Tags?: Tags;
}
export interface FunctionMetadata {
    FunctionARN: string;
    Stage?: FunctionStage;
    CreatedTime?: Date;
    LastModifiedTime: Date;
}
export interface FunctionSummary {
    Name: string;
    Status?: string;
    FunctionConfig: FunctionConfig;
    FunctionMetadata: FunctionMetadata;
}
export interface CreateFunctionResult {
    FunctionSummary?: FunctionSummary;
    Location?: string;
    ETag?: string;
}
export type PathList = string[];
export interface Paths {
    Quantity: number;
    Items?: string[];
}
export interface InvalidationBatch {
    Paths: Paths;
    CallerReference: string;
}
export interface CreateInvalidationRequest {
    DistributionId: string;
    InvalidationBatch: InvalidationBatch;
}
export interface Invalidation {
    Id: string;
    Status: string;
    CreateTime: Date;
    InvalidationBatch: InvalidationBatch;
}
export interface CreateInvalidationResult {
    Location?: string;
    Invalidation?: Invalidation;
}
export interface CreateInvalidationForDistributionTenantRequest {
    Id: string;
    InvalidationBatch: InvalidationBatch;
}
export interface CreateInvalidationForDistributionTenantResult {
    Location?: string;
    Invalidation?: Invalidation;
}
export type PublicKeyIdList = string[];
export interface KeyGroupConfig {
    Name: string;
    Items: string[];
    Comment?: string;
}
export interface CreateKeyGroupRequest {
    KeyGroupConfig: KeyGroupConfig;
}
export interface KeyGroup {
    Id: string;
    LastModifiedTime: Date;
    KeyGroupConfig: KeyGroupConfig;
}
export interface CreateKeyGroupResult {
    KeyGroup?: KeyGroup;
    Location?: string;
    ETag?: string;
}
export type KeyValueStoreName = string;
export type KeyValueStoreComment = string;
export type ImportSourceType = "S3" | (string & {});
export interface ImportSource {
    SourceType: ImportSourceType;
    SourceARN: string;
}
export interface CreateKeyValueStoreRequest {
    Name: string;
    Comment?: string;
    ImportSource?: ImportSource;
    Tags?: Tags;
}
export interface KeyValueStore {
    Name: string;
    Id: string;
    Comment?: string;
    ARN: string;
    Status?: string;
    LastModifiedTime: Date;
}
export interface CreateKeyValueStoreResult {
    KeyValueStore?: KeyValueStore;
    ETag?: string;
    Location?: string;
}
export type RealtimeMetricsSubscriptionStatus = "Enabled" | "Disabled" | (string & {});
export interface RealtimeMetricsSubscriptionConfig {
    RealtimeMetricsSubscriptionStatus: RealtimeMetricsSubscriptionStatus;
}
export interface MonitoringSubscription {
    RealtimeMetricsSubscriptionConfig?: RealtimeMetricsSubscriptionConfig;
}
export interface CreateMonitoringSubscriptionRequest {
    DistributionId: string;
    MonitoringSubscription: MonitoringSubscription;
}
export interface CreateMonitoringSubscriptionResult {
    MonitoringSubscription?: MonitoringSubscription;
}
export type OriginAccessControlSigningProtocols = "sigv4" | "sigv4a" | (string & {});
export type OriginAccessControlSigningBehaviors = "never" | "always" | "no-override" | "always-amz-auth" | (string & {});
export type OriginAccessControlOriginTypes = "s3" | "mediastore" | "mediapackagev2" | "lambda" | (string & {});
export interface OriginAccessControlConfig {
    Name: string;
    Description?: string;
    SigningProtocol: OriginAccessControlSigningProtocols;
    SigningBehavior: OriginAccessControlSigningBehaviors;
    OriginAccessControlOriginType: OriginAccessControlOriginTypes;
}
export interface CreateOriginAccessControlRequest {
    OriginAccessControlConfig: OriginAccessControlConfig;
}
export interface OriginAccessControl {
    Id: string;
    OriginAccessControlConfig?: OriginAccessControlConfig;
}
export interface CreateOriginAccessControlResult {
    OriginAccessControl?: OriginAccessControl;
    Location?: string;
    ETag?: string;
}
export type OriginRequestPolicyHeaderBehavior = "none" | "whitelist" | "allViewer" | "allViewerAndWhitelistCloudFront" | "allExcept" | (string & {});
export interface OriginRequestPolicyHeadersConfig {
    HeaderBehavior: OriginRequestPolicyHeaderBehavior;
    Headers?: Headers;
}
export type OriginRequestPolicyCookieBehavior = "none" | "whitelist" | "all" | "allExcept" | (string & {});
export interface OriginRequestPolicyCookiesConfig {
    CookieBehavior: OriginRequestPolicyCookieBehavior;
    Cookies?: CookieNames;
}
export type OriginRequestPolicyQueryStringBehavior = "none" | "whitelist" | "all" | "allExcept" | (string & {});
export interface OriginRequestPolicyQueryStringsConfig {
    QueryStringBehavior: OriginRequestPolicyQueryStringBehavior;
    QueryStrings?: QueryStringNames;
}
export interface OriginRequestPolicyConfig {
    Comment?: string;
    Name: string;
    HeadersConfig: OriginRequestPolicyHeadersConfig;
    CookiesConfig: OriginRequestPolicyCookiesConfig;
    QueryStringsConfig: OriginRequestPolicyQueryStringsConfig;
}
export interface CreateOriginRequestPolicyRequest {
    OriginRequestPolicyConfig: OriginRequestPolicyConfig;
}
export interface OriginRequestPolicy {
    Id: string;
    LastModifiedTime: Date;
    OriginRequestPolicyConfig: OriginRequestPolicyConfig;
}
export interface CreateOriginRequestPolicyResult {
    OriginRequestPolicy?: OriginRequestPolicy;
    Location?: string;
    ETag?: string;
}
export interface PublicKeyConfig {
    CallerReference: string;
    Name: string;
    EncodedKey: string;
    Comment?: string;
}
export interface CreatePublicKeyRequest {
    PublicKeyConfig: PublicKeyConfig;
}
export interface PublicKey {
    Id: string;
    CreatedTime: Date;
    PublicKeyConfig: PublicKeyConfig;
}
export interface CreatePublicKeyResult {
    PublicKey?: PublicKey;
    Location?: string;
    ETag?: string;
}
export interface KinesisStreamConfig {
    RoleARN: string;
    StreamARN: string;
}
export interface EndPoint {
    StreamType: string;
    KinesisStreamConfig?: KinesisStreamConfig;
}
export type EndPointList = EndPoint[];
export type FieldList = string[];
export interface CreateRealtimeLogConfigRequest {
    EndPoints: EndPoint[];
    Fields: string[];
    Name: string;
    SamplingRate: number;
}
export interface RealtimeLogConfig {
    ARN: string;
    Name: string;
    SamplingRate: number;
    EndPoints: EndPoint[];
    Fields: string[];
}
export interface CreateRealtimeLogConfigResult {
    RealtimeLogConfig?: RealtimeLogConfig;
}
export type AccessControlAllowOriginsList = string[];
export interface ResponseHeadersPolicyAccessControlAllowOrigins {
    Quantity: number;
    Items: string[];
}
export type AccessControlAllowHeadersList = string[];
export interface ResponseHeadersPolicyAccessControlAllowHeaders {
    Quantity: number;
    Items: string[];
}
export type ResponseHeadersPolicyAccessControlAllowMethodsValues = "GET" | "POST" | "OPTIONS" | "PUT" | "DELETE" | "PATCH" | "HEAD" | "ALL" | (string & {});
export type AccessControlAllowMethodsList = ResponseHeadersPolicyAccessControlAllowMethodsValues[];
export interface ResponseHeadersPolicyAccessControlAllowMethods {
    Quantity: number;
    Items: ResponseHeadersPolicyAccessControlAllowMethodsValues[];
}
export type AccessControlExposeHeadersList = string[];
export interface ResponseHeadersPolicyAccessControlExposeHeaders {
    Quantity: number;
    Items?: string[];
}
export interface ResponseHeadersPolicyCorsConfig {
    AccessControlAllowOrigins: ResponseHeadersPolicyAccessControlAllowOrigins;
    AccessControlAllowHeaders: ResponseHeadersPolicyAccessControlAllowHeaders;
    AccessControlAllowMethods: ResponseHeadersPolicyAccessControlAllowMethods;
    AccessControlAllowCredentials: boolean;
    AccessControlExposeHeaders?: ResponseHeadersPolicyAccessControlExposeHeaders;
    AccessControlMaxAgeSec?: number;
    OriginOverride: boolean;
}
export interface ResponseHeadersPolicyXSSProtection {
    Override: boolean;
    Protection: boolean;
    ModeBlock?: boolean;
    ReportUri?: string;
}
export type FrameOptionsList = "DENY" | "SAMEORIGIN" | (string & {});
export interface ResponseHeadersPolicyFrameOptions {
    Override: boolean;
    FrameOption: FrameOptionsList;
}
export type ReferrerPolicyList = "no-referrer" | "no-referrer-when-downgrade" | "origin" | "origin-when-cross-origin" | "same-origin" | "strict-origin" | "strict-origin-when-cross-origin" | "unsafe-url" | (string & {});
export interface ResponseHeadersPolicyReferrerPolicy {
    Override: boolean;
    ReferrerPolicy: ReferrerPolicyList;
}
export interface ResponseHeadersPolicyContentSecurityPolicy {
    Override: boolean;
    ContentSecurityPolicy: string;
}
export interface ResponseHeadersPolicyContentTypeOptions {
    Override: boolean;
}
export interface ResponseHeadersPolicyStrictTransportSecurity {
    Override: boolean;
    IncludeSubdomains?: boolean;
    Preload?: boolean;
    AccessControlMaxAgeSec: number;
}
export interface ResponseHeadersPolicySecurityHeadersConfig {
    XSSProtection?: ResponseHeadersPolicyXSSProtection;
    FrameOptions?: ResponseHeadersPolicyFrameOptions;
    ReferrerPolicy?: ResponseHeadersPolicyReferrerPolicy;
    ContentSecurityPolicy?: ResponseHeadersPolicyContentSecurityPolicy;
    ContentTypeOptions?: ResponseHeadersPolicyContentTypeOptions;
    StrictTransportSecurity?: ResponseHeadersPolicyStrictTransportSecurity;
}
export type SamplingRate = number;
export interface ResponseHeadersPolicyServerTimingHeadersConfig {
    Enabled: boolean;
    SamplingRate?: number;
}
export interface ResponseHeadersPolicyCustomHeader {
    Header: string;
    Value: string;
    Override: boolean;
}
export type ResponseHeadersPolicyCustomHeaderList = ResponseHeadersPolicyCustomHeader[];
export interface ResponseHeadersPolicyCustomHeadersConfig {
    Quantity: number;
    Items?: ResponseHeadersPolicyCustomHeader[];
}
export interface ResponseHeadersPolicyRemoveHeader {
    Header: string;
}
export type ResponseHeadersPolicyRemoveHeaderList = ResponseHeadersPolicyRemoveHeader[];
export interface ResponseHeadersPolicyRemoveHeadersConfig {
    Quantity: number;
    Items?: ResponseHeadersPolicyRemoveHeader[];
}
export interface ResponseHeadersPolicyConfig {
    Comment?: string;
    Name: string;
    CorsConfig?: ResponseHeadersPolicyCorsConfig;
    SecurityHeadersConfig?: ResponseHeadersPolicySecurityHeadersConfig;
    ServerTimingHeadersConfig?: ResponseHeadersPolicyServerTimingHeadersConfig;
    CustomHeadersConfig?: ResponseHeadersPolicyCustomHeadersConfig;
    RemoveHeadersConfig?: ResponseHeadersPolicyRemoveHeadersConfig;
}
export interface CreateResponseHeadersPolicyRequest {
    ResponseHeadersPolicyConfig: ResponseHeadersPolicyConfig;
}
export interface ResponseHeadersPolicy {
    Id: string;
    LastModifiedTime: Date;
    ResponseHeadersPolicyConfig: ResponseHeadersPolicyConfig;
}
export interface CreateResponseHeadersPolicyResult {
    ResponseHeadersPolicy?: ResponseHeadersPolicy;
    Location?: string;
    ETag?: string;
}
export interface S3Origin {
    DomainName: string;
    OriginAccessIdentity: string;
}
export interface StreamingLoggingConfig {
    Enabled: boolean;
    Bucket: string;
    Prefix: string;
}
export interface StreamingDistributionConfig {
    CallerReference: string;
    S3Origin: S3Origin;
    Aliases?: Aliases;
    Comment: string;
    Logging?: StreamingLoggingConfig;
    TrustedSigners: TrustedSigners;
    PriceClass?: PriceClass;
    Enabled: boolean;
}
export interface CreateStreamingDistributionRequest {
    StreamingDistributionConfig: StreamingDistributionConfig;
}
export interface StreamingDistribution {
    Id: string;
    ARN: string;
    Status: string;
    LastModifiedTime?: Date;
    DomainName: string;
    ActiveTrustedSigners: ActiveTrustedSigners;
    StreamingDistributionConfig: StreamingDistributionConfig;
}
export interface CreateStreamingDistributionResult {
    StreamingDistribution?: StreamingDistribution;
    Location?: string;
    ETag?: string;
}
export interface StreamingDistributionConfigWithTags {
    StreamingDistributionConfig: StreamingDistributionConfig;
    Tags: Tags;
}
export interface CreateStreamingDistributionWithTagsRequest {
    StreamingDistributionConfigWithTags: StreamingDistributionConfigWithTags;
}
export interface CreateStreamingDistributionWithTagsResult {
    StreamingDistribution?: StreamingDistribution;
    Location?: string;
    ETag?: string;
}
export interface CaCertificatesBundleS3Location {
    Bucket: string;
    Key: string;
    Region: string;
    Version?: string;
}
export type CaCertificatesBundleSource = {
    CaCertificatesBundleS3Location: CaCertificatesBundleS3Location;
};
export interface CreateTrustStoreRequest {
    Name: string;
    CaCertificatesBundleSource: CaCertificatesBundleSource;
    UseClientCertificateOCSPEndpoint?: boolean;
    Tags?: Tags;
}
export type TrustStoreStatus = "pending" | "active" | "failed" | (string & {});
export interface TrustStore {
    Id?: string;
    Arn?: string;
    Name?: string;
    Status?: TrustStoreStatus;
    NumberOfCaCertificates?: number;
    LastModifiedTime?: Date;
    Reason?: string;
    UseClientCertificateOCSPEndpoint?: boolean;
}
export interface CreateTrustStoreResult {
    TrustStore?: TrustStore;
    ETag?: string;
}
export interface VpcOriginEndpointConfig {
    Name: string;
    Arn: string;
    HTTPPort: number;
    HTTPSPort: number;
    OriginProtocolPolicy: OriginProtocolPolicy;
    OriginSslProtocols?: OriginSslProtocols;
}
export interface CreateVpcOriginRequest {
    VpcOriginEndpointConfig: VpcOriginEndpointConfig;
    Tags?: Tags;
}
export interface VpcOrigin {
    Id: string;
    Arn: string;
    AccountId?: string;
    Status: string;
    CreatedTime: Date;
    LastModifiedTime: Date;
    VpcOriginEndpointConfig: VpcOriginEndpointConfig;
}
export interface CreateVpcOriginResult {
    VpcOrigin?: VpcOrigin;
    Location?: string;
    ETag?: string;
}
export interface DeleteAnycastIpListRequest {
    Id: string;
    IfMatch: string;
}
export interface DeleteAnycastIpListResponse {
}
export interface DeleteCachePolicyRequest {
    Id: string;
    IfMatch?: string;
}
export interface DeleteCachePolicyResponse {
}
export interface DeleteCloudFrontOriginAccessIdentityRequest {
    Id: string;
    IfMatch?: string;
}
export interface DeleteCloudFrontOriginAccessIdentityResponse {
}
export interface DeleteConnectionFunctionRequest {
    Id: string;
    IfMatch: string;
}
export interface DeleteConnectionFunctionResponse {
}
export interface DeleteConnectionGroupRequest {
    Id: string;
    IfMatch: string;
}
export interface DeleteConnectionGroupResponse {
}
export interface DeleteContinuousDeploymentPolicyRequest {
    Id: string;
    IfMatch?: string;
}
export interface DeleteContinuousDeploymentPolicyResponse {
}
export interface DeleteDistributionRequest {
    Id: string;
    IfMatch?: string;
}
export interface DeleteDistributionResponse {
}
export interface DeleteDistributionTenantRequest {
    Id: string;
    IfMatch: string;
}
export interface DeleteDistributionTenantResponse {
}
export interface DeleteFieldLevelEncryptionConfigRequest {
    Id: string;
    IfMatch?: string;
}
export interface DeleteFieldLevelEncryptionConfigResponse {
}
export interface DeleteFieldLevelEncryptionProfileRequest {
    Id: string;
    IfMatch?: string;
}
export interface DeleteFieldLevelEncryptionProfileResponse {
}
export interface DeleteFunctionRequest {
    Name: string;
    IfMatch: string;
}
export interface DeleteFunctionResponse {
}
export interface DeleteKeyGroupRequest {
    Id: string;
    IfMatch?: string;
}
export interface DeleteKeyGroupResponse {
}
export interface DeleteKeyValueStoreRequest {
    Name: string;
    IfMatch: string;
}
export interface DeleteKeyValueStoreResponse {
}
export interface DeleteMonitoringSubscriptionRequest {
    DistributionId: string;
}
export interface DeleteMonitoringSubscriptionResult {
}
export interface DeleteOriginAccessControlRequest {
    Id: string;
    IfMatch?: string;
}
export interface DeleteOriginAccessControlResponse {
}
export interface DeleteOriginRequestPolicyRequest {
    Id: string;
    IfMatch?: string;
}
export interface DeleteOriginRequestPolicyResponse {
}
export interface DeletePublicKeyRequest {
    Id: string;
    IfMatch?: string;
}
export interface DeletePublicKeyResponse {
}
export interface DeleteRealtimeLogConfigRequest {
    Name?: string;
    ARN?: string;
}
export interface DeleteRealtimeLogConfigResponse {
}
export interface DeleteResourcePolicyRequest {
    ResourceArn: string;
}
export interface DeleteResourcePolicyResponse {
}
export interface DeleteResponseHeadersPolicyRequest {
    Id: string;
    IfMatch?: string;
}
export interface DeleteResponseHeadersPolicyResponse {
}
export interface DeleteStreamingDistributionRequest {
    Id: string;
    IfMatch?: string;
}
export interface DeleteStreamingDistributionResponse {
}
export interface DeleteTrustStoreRequest {
    Id: string;
    IfMatch: string;
}
export interface DeleteTrustStoreResponse {
}
export interface DeleteVpcOriginRequest {
    Id: string;
    IfMatch: string;
}
export interface DeleteVpcOriginResult {
    VpcOrigin?: VpcOrigin;
    ETag?: string;
}
export interface DescribeConnectionFunctionRequest {
    Identifier: string;
    Stage?: FunctionStage;
}
export interface DescribeConnectionFunctionResult {
    ConnectionFunctionSummary?: ConnectionFunctionSummary;
    ETag?: string;
}
export interface DescribeFunctionRequest {
    Name: string;
    Stage?: FunctionStage;
}
export interface DescribeFunctionResult {
    FunctionSummary?: FunctionSummary;
    ETag?: string;
}
export interface DescribeKeyValueStoreRequest {
    Name: string;
}
export interface DescribeKeyValueStoreResult {
    KeyValueStore?: KeyValueStore;
    ETag?: string;
}
export interface DisassociateDistributionTenantWebACLRequest {
    Id: string;
    IfMatch?: string;
}
export interface DisassociateDistributionTenantWebACLResult {
    Id?: string;
    ETag?: string;
}
export interface DisassociateDistributionWebACLRequest {
    Id: string;
    IfMatch?: string;
}
export interface DisassociateDistributionWebACLResult {
    Id?: string;
    ETag?: string;
}
export interface GetAnycastIpListRequest {
    Id: string;
}
export interface GetAnycastIpListResult {
    AnycastIpList?: AnycastIpList;
    ETag?: string;
}
export interface GetCachePolicyRequest {
    Id: string;
}
export interface GetCachePolicyResult {
    CachePolicy?: CachePolicy;
    ETag?: string;
}
export interface GetCachePolicyConfigRequest {
    Id: string;
}
export interface GetCachePolicyConfigResult {
    CachePolicyConfig?: CachePolicyConfig;
    ETag?: string;
}
export interface GetCloudFrontOriginAccessIdentityRequest {
    Id: string;
}
export interface GetCloudFrontOriginAccessIdentityResult {
    CloudFrontOriginAccessIdentity?: CloudFrontOriginAccessIdentity;
    ETag?: string;
}
export interface GetCloudFrontOriginAccessIdentityConfigRequest {
    Id: string;
}
export interface GetCloudFrontOriginAccessIdentityConfigResult {
    CloudFrontOriginAccessIdentityConfig?: CloudFrontOriginAccessIdentityConfig;
    ETag?: string;
}
export interface GetConnectionFunctionRequest {
    Identifier: string;
    Stage?: FunctionStage;
}
export interface GetConnectionFunctionResult {
    ConnectionFunctionCode?: T.StreamingOutputBody;
    ETag?: string;
    ContentType?: string;
}
export interface GetConnectionGroupRequest {
    Identifier: string;
}
export interface GetConnectionGroupResult {
    ConnectionGroup?: ConnectionGroup;
    ETag?: string;
}
export interface GetConnectionGroupByRoutingEndpointRequest {
    RoutingEndpoint: string;
}
export interface GetConnectionGroupByRoutingEndpointResult {
    ConnectionGroup?: ConnectionGroup;
    ETag?: string;
}
export interface GetContinuousDeploymentPolicyRequest {
    Id: string;
}
export interface GetContinuousDeploymentPolicyResult {
    ContinuousDeploymentPolicy?: ContinuousDeploymentPolicy;
    ETag?: string;
}
export interface GetContinuousDeploymentPolicyConfigRequest {
    Id: string;
}
export interface GetContinuousDeploymentPolicyConfigResult {
    ContinuousDeploymentPolicyConfig?: ContinuousDeploymentPolicyConfig;
    ETag?: string;
}
export interface GetDistributionRequest {
    Id: string;
}
export interface GetDistributionResult {
    Distribution?: Distribution;
    ETag?: string;
}
export interface GetDistributionConfigRequest {
    Id: string;
}
export interface GetDistributionConfigResult {
    DistributionConfig?: DistributionConfig;
    ETag?: string;
}
export interface GetDistributionTenantRequest {
    Identifier: string;
}
export interface GetDistributionTenantResult {
    DistributionTenant?: DistributionTenant;
    ETag?: string;
}
export interface GetDistributionTenantByDomainRequest {
    Domain: string;
}
export interface GetDistributionTenantByDomainResult {
    DistributionTenant?: DistributionTenant;
    ETag?: string;
}
export interface GetFieldLevelEncryptionRequest {
    Id: string;
}
export interface GetFieldLevelEncryptionResult {
    FieldLevelEncryption?: FieldLevelEncryption;
    ETag?: string;
}
export interface GetFieldLevelEncryptionConfigRequest {
    Id: string;
}
export interface GetFieldLevelEncryptionConfigResult {
    FieldLevelEncryptionConfig?: FieldLevelEncryptionConfig;
    ETag?: string;
}
export interface GetFieldLevelEncryptionProfileRequest {
    Id: string;
}
export interface GetFieldLevelEncryptionProfileResult {
    FieldLevelEncryptionProfile?: FieldLevelEncryptionProfile;
    ETag?: string;
}
export interface GetFieldLevelEncryptionProfileConfigRequest {
    Id: string;
}
export interface GetFieldLevelEncryptionProfileConfigResult {
    FieldLevelEncryptionProfileConfig?: FieldLevelEncryptionProfileConfig;
    ETag?: string;
}
export interface GetFunctionRequest {
    Name: string;
    Stage?: FunctionStage;
}
export interface GetFunctionResult {
    FunctionCode?: T.StreamingOutputBody;
    ETag?: string;
    ContentType?: string;
}
export interface GetInvalidationRequest {
    DistributionId: string;
    Id: string;
}
export interface GetInvalidationResult {
    Invalidation?: Invalidation;
}
export interface GetInvalidationForDistributionTenantRequest {
    DistributionTenantId: string;
    Id: string;
}
export interface GetInvalidationForDistributionTenantResult {
    Invalidation?: Invalidation;
}
export interface GetKeyGroupRequest {
    Id: string;
}
export interface GetKeyGroupResult {
    KeyGroup?: KeyGroup;
    ETag?: string;
}
export interface GetKeyGroupConfigRequest {
    Id: string;
}
export interface GetKeyGroupConfigResult {
    KeyGroupConfig?: KeyGroupConfig;
    ETag?: string;
}
export interface GetManagedCertificateDetailsRequest {
    Identifier: string;
}
export type ManagedCertificateStatus = "pending-validation" | "issued" | "inactive" | "expired" | "validation-timed-out" | "revoked" | "failed" | (string & {});
export interface ValidationTokenDetail {
    Domain: string;
    RedirectTo?: string;
    RedirectFrom?: string;
}
export type ValidationTokenDetailList = ValidationTokenDetail[];
export interface ManagedCertificateDetails {
    CertificateArn?: string;
    CertificateStatus?: ManagedCertificateStatus;
    ValidationTokenHost?: ValidationTokenHost;
    ValidationTokenDetails?: ValidationTokenDetail[];
}
export interface GetManagedCertificateDetailsResult {
    ManagedCertificateDetails?: ManagedCertificateDetails;
}
export interface GetMonitoringSubscriptionRequest {
    DistributionId: string;
}
export interface GetMonitoringSubscriptionResult {
    MonitoringSubscription?: MonitoringSubscription;
}
export interface GetOriginAccessControlRequest {
    Id: string;
}
export interface GetOriginAccessControlResult {
    OriginAccessControl?: OriginAccessControl;
    ETag?: string;
}
export interface GetOriginAccessControlConfigRequest {
    Id: string;
}
export interface GetOriginAccessControlConfigResult {
    OriginAccessControlConfig?: OriginAccessControlConfig;
    ETag?: string;
}
export interface GetOriginRequestPolicyRequest {
    Id: string;
}
export interface GetOriginRequestPolicyResult {
    OriginRequestPolicy?: OriginRequestPolicy;
    ETag?: string;
}
export interface GetOriginRequestPolicyConfigRequest {
    Id: string;
}
export interface GetOriginRequestPolicyConfigResult {
    OriginRequestPolicyConfig?: OriginRequestPolicyConfig;
    ETag?: string;
}
export interface GetPublicKeyRequest {
    Id: string;
}
export interface GetPublicKeyResult {
    PublicKey?: PublicKey;
    ETag?: string;
}
export interface GetPublicKeyConfigRequest {
    Id: string;
}
export interface GetPublicKeyConfigResult {
    PublicKeyConfig?: PublicKeyConfig;
    ETag?: string;
}
export interface GetRealtimeLogConfigRequest {
    Name?: string;
    ARN?: string;
}
export interface GetRealtimeLogConfigResult {
    RealtimeLogConfig?: RealtimeLogConfig;
}
export interface GetResourcePolicyRequest {
    ResourceArn: string;
}
export interface GetResourcePolicyResult {
    ResourceArn?: string;
    PolicyDocument?: string;
}
export interface GetResponseHeadersPolicyRequest {
    Id: string;
}
export interface GetResponseHeadersPolicyResult {
    ResponseHeadersPolicy?: ResponseHeadersPolicy;
    ETag?: string;
}
export interface GetResponseHeadersPolicyConfigRequest {
    Id: string;
}
export interface GetResponseHeadersPolicyConfigResult {
    ResponseHeadersPolicyConfig?: ResponseHeadersPolicyConfig;
    ETag?: string;
}
export interface GetStreamingDistributionRequest {
    Id: string;
}
export interface GetStreamingDistributionResult {
    StreamingDistribution?: StreamingDistribution;
    ETag?: string;
}
export interface GetStreamingDistributionConfigRequest {
    Id: string;
}
export interface GetStreamingDistributionConfigResult {
    StreamingDistributionConfig?: StreamingDistributionConfig;
    ETag?: string;
}
export interface GetTrustStoreRequest {
    Identifier: string;
}
export interface GetTrustStoreResult {
    TrustStore?: TrustStore;
    ETag?: string;
}
export interface GetVpcOriginRequest {
    Id: string;
}
export interface GetVpcOriginResult {
    VpcOrigin?: VpcOrigin;
    ETag?: string;
}
export interface ListAnycastIpListsRequest {
    Marker?: string;
    MaxItems?: number;
}
export interface AnycastIpListSummary {
    Id: string;
    Name: string;
    Status: string;
    Arn: string;
    IpCount: number;
    LastModifiedTime: Date;
    IpAddressType?: IpAddressType;
    ETag?: string;
    IpamConfig?: IpamConfig;
}
export type AnycastIpListSummaries = AnycastIpListSummary[];
export interface AnycastIpListCollection {
    Items?: AnycastIpListSummary[];
    Marker?: string;
    NextMarker?: string;
    MaxItems: number;
    IsTruncated: boolean;
    Quantity: number;
}
export interface ListAnycastIpListsResult {
    AnycastIpLists?: AnycastIpListCollection;
}
export type CachePolicyType = "managed" | "custom" | (string & {});
export interface ListCachePoliciesRequest {
    Type?: CachePolicyType;
    Marker?: string;
    MaxItems?: number;
}
export interface CachePolicySummary {
    Type: CachePolicyType;
    CachePolicy: CachePolicy;
}
export type CachePolicySummaryList = CachePolicySummary[];
export interface CachePolicyList {
    NextMarker?: string;
    MaxItems: number;
    Quantity: number;
    Items?: CachePolicySummary[];
}
export interface ListCachePoliciesResult {
    CachePolicyList?: CachePolicyList;
}
export interface ListCloudFrontOriginAccessIdentitiesRequest {
    Marker?: string;
    MaxItems?: number;
}
export interface CloudFrontOriginAccessIdentitySummary {
    Id: string;
    S3CanonicalUserId: string;
    Comment: string;
}
export type CloudFrontOriginAccessIdentitySummaryList = CloudFrontOriginAccessIdentitySummary[];
export interface CloudFrontOriginAccessIdentityList {
    Marker?: string;
    NextMarker?: string;
    MaxItems: number;
    IsTruncated: boolean;
    Quantity: number;
    Items?: CloudFrontOriginAccessIdentitySummary[];
}
export interface ListCloudFrontOriginAccessIdentitiesResult {
    CloudFrontOriginAccessIdentityList?: CloudFrontOriginAccessIdentityList;
}
export type DistributionIdString = string;
export type AliasString = string;
export type ListConflictingAliasesMaxItemsInteger = number;
export interface ListConflictingAliasesRequest {
    DistributionId: string;
    Alias: string;
    Marker?: string;
    MaxItems?: number;
}
export interface ConflictingAlias {
    Alias?: string;
    DistributionId?: string;
    AccountId?: string;
}
export type ConflictingAliases = ConflictingAlias[];
export interface ConflictingAliasesList {
    NextMarker?: string;
    MaxItems?: number;
    Quantity?: number;
    Items?: ConflictingAlias[];
}
export interface ListConflictingAliasesResult {
    ConflictingAliasesList?: ConflictingAliasesList;
}
export interface ListConnectionFunctionsRequest {
    Marker?: string;
    MaxItems?: number;
    Stage?: FunctionStage;
}
export type ConnectionFunctionSummaryList = ConnectionFunctionSummary[];
export interface ListConnectionFunctionsResult {
    NextMarker?: string;
    ConnectionFunctions?: ConnectionFunctionSummary[];
}
export interface ConnectionGroupAssociationFilter {
    AnycastIpListId?: string;
}
export interface ListConnectionGroupsRequest {
    AssociationFilter?: ConnectionGroupAssociationFilter;
    Marker?: string;
    MaxItems?: number;
}
export interface ConnectionGroupSummary {
    Id: string;
    Name: string;
    Arn: string;
    RoutingEndpoint: string;
    CreatedTime: Date;
    LastModifiedTime: Date;
    ETag: string;
    AnycastIpListId?: string;
    Enabled?: boolean;
    Status?: string;
    IsDefault?: boolean;
}
export type ConnectionGroupSummaryList = ConnectionGroupSummary[];
export interface ListConnectionGroupsResult {
    NextMarker?: string;
    ConnectionGroups?: ConnectionGroupSummary[];
}
export interface ListContinuousDeploymentPoliciesRequest {
    Marker?: string;
    MaxItems?: number;
}
export interface ContinuousDeploymentPolicySummary {
    ContinuousDeploymentPolicy: ContinuousDeploymentPolicy;
}
export type ContinuousDeploymentPolicySummaryList = ContinuousDeploymentPolicySummary[];
export interface ContinuousDeploymentPolicyList {
    NextMarker?: string;
    MaxItems: number;
    Quantity: number;
    Items?: ContinuousDeploymentPolicySummary[];
}
export interface ListContinuousDeploymentPoliciesResult {
    ContinuousDeploymentPolicyList?: ContinuousDeploymentPolicyList;
}
export interface ListDistributionsRequest {
    Marker?: string;
    MaxItems?: number;
}
export interface DistributionSummary {
    Id: string;
    ARN: string;
    ETag?: string;
    Status: string;
    LastModifiedTime: Date;
    DomainName: string;
    Aliases: Aliases;
    Origins: Origins;
    OriginGroups?: OriginGroups;
    DefaultCacheBehavior: DefaultCacheBehavior;
    CacheBehaviors: CacheBehaviors;
    CustomErrorResponses: CustomErrorResponses;
    Comment: string | redacted.Redacted<string>;
    PriceClass: PriceClass;
    Enabled: boolean;
    ViewerCertificate: ViewerCertificate;
    Restrictions: Restrictions;
    WebACLId?: string;
    HttpVersion: HttpVersion;
    IsIPV6Enabled: boolean;
    AliasICPRecordals?: AliasICPRecordal[];
    Staging: boolean;
    ConnectionMode?: ConnectionMode;
    AnycastIpListId?: string;
    ViewerMtlsConfig?: ViewerMtlsConfig;
    ConnectionFunctionAssociation?: ConnectionFunctionAssociation;
}
export type DistributionSummaryList = DistributionSummary[];
export interface DistributionList {
    Marker?: string;
    NextMarker?: string;
    MaxItems: number;
    IsTruncated: boolean;
    Quantity: number;
    Items?: DistributionSummary[];
}
export interface ListDistributionsResult {
    DistributionList?: DistributionList;
}
export interface ListDistributionsByAnycastIpListIdRequest {
    Marker?: string;
    MaxItems?: number;
    AnycastIpListId: string;
}
export interface ListDistributionsByAnycastIpListIdResult {
    DistributionList?: DistributionList;
}
export interface ListDistributionsByCachePolicyIdRequest {
    Marker?: string;
    MaxItems?: number;
    CachePolicyId: string;
}
export type DistributionIdListSummary = string[];
export interface DistributionIdList {
    Marker?: string;
    NextMarker?: string;
    MaxItems: number;
    IsTruncated: boolean;
    Quantity: number;
    Items?: string[];
}
export interface ListDistributionsByCachePolicyIdResult {
    DistributionIdList?: DistributionIdList;
}
export interface ListDistributionsByConnectionFunctionRequest {
    Marker?: string;
    MaxItems?: number;
    ConnectionFunctionIdentifier: string;
}
export interface ListDistributionsByConnectionFunctionResult {
    DistributionList?: DistributionList;
}
export interface ListDistributionsByConnectionModeRequest {
    Marker?: string;
    MaxItems?: number;
    ConnectionMode: ConnectionMode;
}
export interface ListDistributionsByConnectionModeResult {
    DistributionList?: DistributionList;
}
export interface ListDistributionsByKeyGroupRequest {
    Marker?: string;
    MaxItems?: number;
    KeyGroupId: string;
}
export interface ListDistributionsByKeyGroupResult {
    DistributionIdList?: DistributionIdList;
}
export interface ListDistributionsByOriginRequestPolicyIdRequest {
    Marker?: string;
    MaxItems?: number;
    OriginRequestPolicyId: string;
}
export interface ListDistributionsByOriginRequestPolicyIdResult {
    DistributionIdList?: DistributionIdList;
}
export interface ListDistributionsByOwnedResourceRequest {
    ResourceArn: string;
    Marker?: string;
    MaxItems?: number;
}
export interface DistributionIdOwner {
    DistributionId: string;
    OwnerAccountId: string;
}
export type DistributionIdOwnerItemList = DistributionIdOwner[];
export interface DistributionIdOwnerList {
    Marker?: string;
    NextMarker?: string;
    MaxItems: number;
    IsTruncated: boolean;
    Quantity: number;
    Items?: DistributionIdOwner[];
}
export interface ListDistributionsByOwnedResourceResult {
    DistributionList?: DistributionIdOwnerList;
}
export interface ListDistributionsByRealtimeLogConfigRequest {
    Marker?: string;
    MaxItems?: number;
    RealtimeLogConfigName?: string;
    RealtimeLogConfigArn?: string;
}
export interface ListDistributionsByRealtimeLogConfigResult {
    DistributionList?: DistributionList;
}
export interface ListDistributionsByResponseHeadersPolicyIdRequest {
    Marker?: string;
    MaxItems?: number;
    ResponseHeadersPolicyId: string;
}
export interface ListDistributionsByResponseHeadersPolicyIdResult {
    DistributionIdList?: DistributionIdList;
}
export interface ListDistributionsByTrustStoreRequest {
    TrustStoreIdentifier: string;
    Marker?: string;
    MaxItems?: number;
}
export interface ListDistributionsByTrustStoreResult {
    DistributionList?: DistributionList;
}
export interface ListDistributionsByVpcOriginIdRequest {
    Marker?: string;
    MaxItems?: number;
    VpcOriginId: string;
}
export interface ListDistributionsByVpcOriginIdResult {
    DistributionIdList?: DistributionIdList;
}
export interface ListDistributionsByWebACLIdRequest {
    Marker?: string;
    MaxItems?: number;
    WebACLId: string;
}
export interface ListDistributionsByWebACLIdResult {
    DistributionList?: DistributionList;
}
export interface DistributionTenantAssociationFilter {
    DistributionId?: string;
    ConnectionGroupId?: string;
}
export interface ListDistributionTenantsRequest {
    AssociationFilter?: DistributionTenantAssociationFilter;
    Marker?: string;
    MaxItems?: number;
}
export interface DistributionTenantSummary {
    Id: string;
    DistributionId: string;
    Name: string;
    Arn: string;
    Domains: DomainResult[];
    ConnectionGroupId?: string;
    Customizations?: Customizations;
    CreatedTime: Date;
    LastModifiedTime: Date;
    ETag: string;
    Enabled?: boolean;
    Status?: string;
}
export type DistributionTenantList = DistributionTenantSummary[];
export interface ListDistributionTenantsResult {
    NextMarker?: string;
    DistributionTenantList?: DistributionTenantSummary[];
}
export interface ListDistributionTenantsByCustomizationRequest {
    WebACLArn?: string;
    CertificateArn?: string;
    Marker?: string;
    MaxItems?: number;
}
export interface ListDistributionTenantsByCustomizationResult {
    NextMarker?: string;
    DistributionTenantList?: DistributionTenantSummary[];
}
export interface DistributionResourceId {
    DistributionId?: string;
    DistributionTenantId?: string;
}
export interface ListDomainConflictsRequest {
    Domain: string;
    DomainControlValidationResource: DistributionResourceId;
    MaxItems?: number;
    Marker?: string;
}
export type DistributionResourceType = "distribution" | "distribution-tenant" | (string & {});
export interface DomainConflict {
    Domain: string;
    ResourceType: DistributionResourceType;
    ResourceId: string;
    AccountId: string;
}
export type DomainConflictsList = DomainConflict[];
export interface ListDomainConflictsResult {
    DomainConflicts?: DomainConflict[];
    NextMarker?: string;
}
export interface ListFieldLevelEncryptionConfigsRequest {
    Marker?: string;
    MaxItems?: number;
}
export interface FieldLevelEncryptionSummary {
    Id: string;
    LastModifiedTime: Date;
    Comment?: string;
    QueryArgProfileConfig?: QueryArgProfileConfig;
    ContentTypeProfileConfig?: ContentTypeProfileConfig;
}
export type FieldLevelEncryptionSummaryList = FieldLevelEncryptionSummary[];
export interface FieldLevelEncryptionList {
    NextMarker?: string;
    MaxItems: number;
    Quantity: number;
    Items?: FieldLevelEncryptionSummary[];
}
export interface ListFieldLevelEncryptionConfigsResult {
    FieldLevelEncryptionList?: FieldLevelEncryptionList;
}
export interface ListFieldLevelEncryptionProfilesRequest {
    Marker?: string;
    MaxItems?: number;
}
export interface FieldLevelEncryptionProfileSummary {
    Id: string;
    LastModifiedTime: Date;
    Name: string;
    EncryptionEntities: EncryptionEntities;
    Comment?: string;
}
export type FieldLevelEncryptionProfileSummaryList = FieldLevelEncryptionProfileSummary[];
export interface FieldLevelEncryptionProfileList {
    NextMarker?: string;
    MaxItems: number;
    Quantity: number;
    Items?: FieldLevelEncryptionProfileSummary[];
}
export interface ListFieldLevelEncryptionProfilesResult {
    FieldLevelEncryptionProfileList?: FieldLevelEncryptionProfileList;
}
export interface ListFunctionsRequest {
    Marker?: string;
    MaxItems?: number;
    Stage?: FunctionStage;
}
export type FunctionSummaryList = FunctionSummary[];
export interface FunctionList {
    NextMarker?: string;
    MaxItems: number;
    Quantity: number;
    Items?: FunctionSummary[];
}
export interface ListFunctionsResult {
    FunctionList?: FunctionList;
}
export interface ListInvalidationsRequest {
    DistributionId: string;
    Marker?: string;
    MaxItems?: number;
}
export interface InvalidationSummary {
    Id: string;
    CreateTime: Date;
    Status: string;
}
export type InvalidationSummaryList = InvalidationSummary[];
export interface InvalidationList {
    Marker?: string;
    NextMarker?: string;
    MaxItems: number;
    IsTruncated: boolean;
    Quantity: number;
    Items?: InvalidationSummary[];
}
export interface ListInvalidationsResult {
    InvalidationList?: InvalidationList;
}
export interface ListInvalidationsForDistributionTenantRequest {
    Id: string;
    Marker?: string;
    MaxItems?: number;
}
export interface ListInvalidationsForDistributionTenantResult {
    InvalidationList?: InvalidationList;
}
export interface ListKeyGroupsRequest {
    Marker?: string;
    MaxItems?: number;
}
export interface KeyGroupSummary {
    KeyGroup: KeyGroup;
}
export type KeyGroupSummaryList = KeyGroupSummary[];
export interface KeyGroupList {
    NextMarker?: string;
    MaxItems: number;
    Quantity: number;
    Items?: KeyGroupSummary[];
}
export interface ListKeyGroupsResult {
    KeyGroupList?: KeyGroupList;
}
export interface ListKeyValueStoresRequest {
    Marker?: string;
    MaxItems?: number;
    Status?: string;
}
export type KeyValueStoreSummaryList = KeyValueStore[];
export interface KeyValueStoreList {
    NextMarker?: string;
    MaxItems: number;
    Quantity: number;
    Items?: KeyValueStore[];
}
export interface ListKeyValueStoresResult {
    KeyValueStoreList?: KeyValueStoreList;
}
export interface ListOriginAccessControlsRequest {
    Marker?: string;
    MaxItems?: number;
}
export interface OriginAccessControlSummary {
    Id: string;
    Description?: string;
    Name: string;
    SigningProtocol: OriginAccessControlSigningProtocols;
    SigningBehavior: OriginAccessControlSigningBehaviors;
    OriginAccessControlOriginType: OriginAccessControlOriginTypes;
}
export type OriginAccessControlSummaryList = OriginAccessControlSummary[];
export interface OriginAccessControlList {
    Marker?: string;
    NextMarker?: string;
    MaxItems: number;
    IsTruncated: boolean;
    Quantity: number;
    Items?: OriginAccessControlSummary[];
}
export interface ListOriginAccessControlsResult {
    OriginAccessControlList?: OriginAccessControlList;
}
export type OriginRequestPolicyType = "managed" | "custom" | (string & {});
export interface ListOriginRequestPoliciesRequest {
    Type?: OriginRequestPolicyType;
    Marker?: string;
    MaxItems?: number;
}
export interface OriginRequestPolicySummary {
    Type: OriginRequestPolicyType;
    OriginRequestPolicy: OriginRequestPolicy;
}
export type OriginRequestPolicySummaryList = OriginRequestPolicySummary[];
export interface OriginRequestPolicyList {
    NextMarker?: string;
    MaxItems: number;
    Quantity: number;
    Items?: OriginRequestPolicySummary[];
}
export interface ListOriginRequestPoliciesResult {
    OriginRequestPolicyList?: OriginRequestPolicyList;
}
export interface ListPublicKeysRequest {
    Marker?: string;
    MaxItems?: number;
}
export interface PublicKeySummary {
    Id: string;
    Name: string;
    CreatedTime: Date;
    EncodedKey: string;
    Comment?: string;
}
export type PublicKeySummaryList = PublicKeySummary[];
export interface PublicKeyList {
    NextMarker?: string;
    MaxItems: number;
    Quantity: number;
    Items?: PublicKeySummary[];
}
export interface ListPublicKeysResult {
    PublicKeyList?: PublicKeyList;
}
export interface ListRealtimeLogConfigsRequest {
    MaxItems?: number;
    Marker?: string;
}
export type RealtimeLogConfigList = RealtimeLogConfig[];
export interface RealtimeLogConfigs {
    MaxItems: number;
    Items?: RealtimeLogConfig[];
    IsTruncated: boolean;
    Marker?: string;
    NextMarker?: string;
}
export interface ListRealtimeLogConfigsResult {
    RealtimeLogConfigs?: RealtimeLogConfigs;
}
export type ResponseHeadersPolicyType = "managed" | "custom" | (string & {});
export interface ListResponseHeadersPoliciesRequest {
    Type?: ResponseHeadersPolicyType;
    Marker?: string;
    MaxItems?: number;
}
export interface ResponseHeadersPolicySummary {
    Type: ResponseHeadersPolicyType;
    ResponseHeadersPolicy: ResponseHeadersPolicy;
}
export type ResponseHeadersPolicySummaryList = ResponseHeadersPolicySummary[];
export interface ResponseHeadersPolicyList {
    NextMarker?: string;
    MaxItems: number;
    Quantity: number;
    Items?: ResponseHeadersPolicySummary[];
}
export interface ListResponseHeadersPoliciesResult {
    ResponseHeadersPolicyList?: ResponseHeadersPolicyList;
}
export interface ListStreamingDistributionsRequest {
    Marker?: string;
    MaxItems?: number;
}
export interface StreamingDistributionSummary {
    Id: string;
    ARN: string;
    Status: string;
    LastModifiedTime: Date;
    DomainName: string;
    S3Origin: S3Origin;
    Aliases: Aliases;
    TrustedSigners: TrustedSigners;
    Comment: string;
    PriceClass: PriceClass;
    Enabled: boolean;
}
export type StreamingDistributionSummaryList = StreamingDistributionSummary[];
export interface StreamingDistributionList {
    Marker?: string;
    NextMarker?: string;
    MaxItems: number;
    IsTruncated: boolean;
    Quantity: number;
    Items?: StreamingDistributionSummary[];
}
export interface ListStreamingDistributionsResult {
    StreamingDistributionList?: StreamingDistributionList;
}
export type ResourceARN = string;
export interface ListTagsForResourceRequest {
    Resource: string;
}
export interface ListTagsForResourceResult {
    Tags: Tags;
}
export interface ListTrustStoresRequest {
    Marker?: string;
    MaxItems?: number;
}
export interface TrustStoreSummary {
    Id: string;
    Arn: string;
    Name: string;
    Status: TrustStoreStatus;
    NumberOfCaCertificates: number;
    LastModifiedTime: Date;
    Reason?: string;
    ETag: string;
}
export type TrustStoreList = TrustStoreSummary[];
export interface ListTrustStoresResult {
    NextMarker?: string;
    TrustStoreList?: TrustStoreSummary[];
}
export interface ListVpcOriginsRequest {
    Marker?: string;
    MaxItems?: number;
}
export interface VpcOriginSummary {
    Id: string;
    Name: string;
    Status: string;
    CreatedTime: Date;
    LastModifiedTime: Date;
    Arn: string;
    AccountId?: string;
    OriginEndpointArn: string;
}
export type VpcOriginSummaryList = VpcOriginSummary[];
export interface VpcOriginList {
    Marker?: string;
    NextMarker?: string;
    MaxItems?: number;
    IsTruncated?: boolean;
    Quantity?: number;
    Items?: VpcOriginSummary[];
}
export interface ListVpcOriginsResult {
    VpcOriginList?: VpcOriginList;
}
export interface PublishConnectionFunctionRequest {
    Id: string;
    IfMatch: string;
}
export interface PublishConnectionFunctionResult {
    ConnectionFunctionSummary?: ConnectionFunctionSummary;
}
export interface PublishFunctionRequest {
    Name: string;
    IfMatch: string;
}
export interface PublishFunctionResult {
    FunctionSummary?: FunctionSummary;
}
export interface PutResourcePolicyRequest {
    ResourceArn: string;
    PolicyDocument: string;
}
export interface PutResourcePolicyResult {
    ResourceArn?: string;
}
export interface TagResourceRequest {
    Resource: string;
    Tags: Tags;
}
export interface TagResourceResponse {
}
export type FunctionEventObject = Uint8Array | redacted.Redacted<Uint8Array>;
export interface TestConnectionFunctionRequest {
    Id: string;
    IfMatch: string;
    Stage?: FunctionStage;
    ConnectionObject: Uint8Array | redacted.Redacted<Uint8Array>;
}
export type FunctionExecutionLogList = string[];
export interface ConnectionFunctionTestResult {
    ConnectionFunctionSummary?: ConnectionFunctionSummary;
    ComputeUtilization?: string;
    ConnectionFunctionExecutionLogs?: string[];
    ConnectionFunctionErrorMessage?: string | redacted.Redacted<string>;
    ConnectionFunctionOutput?: string | redacted.Redacted<string>;
}
export interface TestConnectionFunctionResult {
    ConnectionFunctionTestResult?: ConnectionFunctionTestResult;
}
export interface TestFunctionRequest {
    Name: string;
    IfMatch: string;
    Stage?: FunctionStage;
    EventObject: Uint8Array | redacted.Redacted<Uint8Array>;
}
export interface TestResult {
    FunctionSummary?: FunctionSummary;
    ComputeUtilization?: string;
    FunctionExecutionLogs?: string[];
    FunctionErrorMessage?: string | redacted.Redacted<string>;
    FunctionOutput?: string | redacted.Redacted<string>;
}
export interface TestFunctionResult {
    TestResult?: TestResult;
}
export type TagKeyList = string[];
export interface TagKeys {
    Items?: string[];
}
export interface UntagResourceRequest {
    Resource: string;
    TagKeys: TagKeys;
}
export interface UntagResourceResponse {
}
export interface UpdateAnycastIpListRequest {
    Id: string;
    IpAddressType?: IpAddressType;
    IpamCidrConfigs?: IpamCidrConfig[];
    IfMatch: string;
}
export interface UpdateAnycastIpListResult {
    AnycastIpList?: AnycastIpList;
    ETag?: string;
}
export interface UpdateCachePolicyRequest {
    CachePolicyConfig: CachePolicyConfig;
    Id: string;
    IfMatch?: string;
}
export interface UpdateCachePolicyResult {
    CachePolicy?: CachePolicy;
    ETag?: string;
}
export interface UpdateCloudFrontOriginAccessIdentityRequest {
    CloudFrontOriginAccessIdentityConfig: CloudFrontOriginAccessIdentityConfig;
    Id: string;
    IfMatch?: string;
}
export interface UpdateCloudFrontOriginAccessIdentityResult {
    CloudFrontOriginAccessIdentity?: CloudFrontOriginAccessIdentity;
    ETag?: string;
}
export interface UpdateConnectionFunctionRequest {
    Id: string;
    IfMatch: string;
    ConnectionFunctionConfig: FunctionConfig;
    ConnectionFunctionCode: Uint8Array | redacted.Redacted<Uint8Array>;
}
export interface UpdateConnectionFunctionResult {
    ConnectionFunctionSummary?: ConnectionFunctionSummary;
    ETag?: string;
}
export interface UpdateConnectionGroupRequest {
    Id: string;
    Ipv6Enabled?: boolean;
    IfMatch: string;
    AnycastIpListId?: string;
    Enabled?: boolean;
}
export interface UpdateConnectionGroupResult {
    ConnectionGroup?: ConnectionGroup;
    ETag?: string;
}
export interface UpdateContinuousDeploymentPolicyRequest {
    ContinuousDeploymentPolicyConfig: ContinuousDeploymentPolicyConfig;
    Id: string;
    IfMatch?: string;
}
export interface UpdateContinuousDeploymentPolicyResult {
    ContinuousDeploymentPolicy?: ContinuousDeploymentPolicy;
    ETag?: string;
}
export interface UpdateDistributionRequest {
    DistributionConfig: DistributionConfig;
    Id: string;
    IfMatch?: string;
}
export interface UpdateDistributionResult {
    Distribution?: Distribution;
    ETag?: string;
}
export interface UpdateDistributionTenantRequest {
    Id: string;
    DistributionId?: string;
    Domains?: DomainItem[];
    Customizations?: Customizations;
    Parameters?: Parameter[];
    ConnectionGroupId?: string;
    IfMatch: string;
    ManagedCertificateRequest?: ManagedCertificateRequest;
    Enabled?: boolean;
}
export interface UpdateDistributionTenantResult {
    DistributionTenant?: DistributionTenant;
    ETag?: string;
}
export interface UpdateDistributionWithStagingConfigRequest {
    Id: string;
    StagingDistributionId?: string;
    IfMatch?: string;
}
export interface UpdateDistributionWithStagingConfigResult {
    Distribution?: Distribution;
    ETag?: string;
}
export interface UpdateDomainAssociationRequest {
    Domain: string;
    TargetResource: DistributionResourceId;
    IfMatch?: string;
}
export interface UpdateDomainAssociationResult {
    Domain?: string;
    ResourceId?: string;
    ETag?: string;
}
export interface UpdateFieldLevelEncryptionConfigRequest {
    FieldLevelEncryptionConfig: FieldLevelEncryptionConfig;
    Id: string;
    IfMatch?: string;
}
export interface UpdateFieldLevelEncryptionConfigResult {
    FieldLevelEncryption?: FieldLevelEncryption;
    ETag?: string;
}
export interface UpdateFieldLevelEncryptionProfileRequest {
    FieldLevelEncryptionProfileConfig: FieldLevelEncryptionProfileConfig;
    Id: string;
    IfMatch?: string;
}
export interface UpdateFieldLevelEncryptionProfileResult {
    FieldLevelEncryptionProfile?: FieldLevelEncryptionProfile;
    ETag?: string;
}
export interface UpdateFunctionRequest {
    Name: string;
    IfMatch: string;
    FunctionConfig: FunctionConfig;
    FunctionCode: Uint8Array | redacted.Redacted<Uint8Array>;
}
export interface UpdateFunctionResult {
    FunctionSummary?: FunctionSummary;
    ETag?: string;
}
export interface UpdateKeyGroupRequest {
    KeyGroupConfig: KeyGroupConfig;
    Id: string;
    IfMatch?: string;
}
export interface UpdateKeyGroupResult {
    KeyGroup?: KeyGroup;
    ETag?: string;
}
export interface UpdateKeyValueStoreRequest {
    Name: string;
    Comment: string;
    IfMatch: string;
}
export interface UpdateKeyValueStoreResult {
    KeyValueStore?: KeyValueStore;
    ETag?: string;
}
export interface UpdateOriginAccessControlRequest {
    OriginAccessControlConfig: OriginAccessControlConfig;
    Id: string;
    IfMatch?: string;
}
export interface UpdateOriginAccessControlResult {
    OriginAccessControl?: OriginAccessControl;
    ETag?: string;
}
export interface UpdateOriginRequestPolicyRequest {
    OriginRequestPolicyConfig: OriginRequestPolicyConfig;
    Id: string;
    IfMatch?: string;
}
export interface UpdateOriginRequestPolicyResult {
    OriginRequestPolicy?: OriginRequestPolicy;
    ETag?: string;
}
export interface UpdatePublicKeyRequest {
    PublicKeyConfig: PublicKeyConfig;
    Id: string;
    IfMatch?: string;
}
export interface UpdatePublicKeyResult {
    PublicKey?: PublicKey;
    ETag?: string;
}
export interface UpdateRealtimeLogConfigRequest {
    EndPoints?: EndPoint[];
    Fields?: string[];
    Name?: string;
    ARN?: string;
    SamplingRate?: number;
}
export interface UpdateRealtimeLogConfigResult {
    RealtimeLogConfig?: RealtimeLogConfig;
}
export interface UpdateResponseHeadersPolicyRequest {
    ResponseHeadersPolicyConfig: ResponseHeadersPolicyConfig;
    Id: string;
    IfMatch?: string;
}
export interface UpdateResponseHeadersPolicyResult {
    ResponseHeadersPolicy?: ResponseHeadersPolicy;
    ETag?: string;
}
export interface UpdateStreamingDistributionRequest {
    StreamingDistributionConfig: StreamingDistributionConfig;
    Id: string;
    IfMatch?: string;
}
export interface UpdateStreamingDistributionResult {
    StreamingDistribution?: StreamingDistribution;
    ETag?: string;
}
export interface UpdateTrustStoreRequest {
    Id: string;
    CaCertificatesBundleSource?: CaCertificatesBundleSource;
    UseClientCertificateOCSPEndpoint?: boolean;
    IfMatch: string;
}
export interface UpdateTrustStoreResult {
    TrustStore?: TrustStore;
    ETag?: string;
}
export interface UpdateVpcOriginRequest {
    VpcOriginEndpointConfig: VpcOriginEndpointConfig;
    Id: string;
    IfMatch: string;
}
export interface UpdateVpcOriginResult {
    VpcOrigin?: VpcOrigin;
    ETag?: string;
}
export interface VerifyDnsConfigurationRequest {
    Domain?: string;
    Identifier: string;
}
export type DnsConfigurationStatus = "valid-configuration" | "invalid-configuration" | "unknown-configuration" | (string & {});
export interface DnsConfiguration {
    Domain: string;
    Status: DnsConfigurationStatus;
    Reason?: string;
}
export type DnsConfigurationList = DnsConfiguration[];
export interface VerifyDnsConfigurationResult {
    DnsConfigurationList?: DnsConfiguration[];
}
export type AssociateAliasError = AccessDenied | IllegalUpdate | InvalidArgument | NoSuchDistribution | TooManyDistributionCNAMEs | CommonErrors;
/**
 * The `AssociateAlias` API operation only supports standard distributions. To move domains between distribution tenants and/or standard distributions, we recommend that you use the UpdateDomainAssociation API operation instead.
 *
 * Associates an alias with a CloudFront standard distribution. An alias is commonly known as a custom domain or vanity domain. It can also be called a CNAME or alternate domain name.
 *
 * With this operation, you can move an alias that's already used for a standard distribution to a different standard distribution. This prevents the downtime that could occur if you first remove the alias from one standard distribution and then separately add the alias to another standard distribution.
 *
 * To use this operation, specify the alias and the ID of the target standard distribution.
 *
 * For more information, including how to set up the target standard distribution, prerequisites that you must complete, and other restrictions, see Moving an alternate domain name to a different standard distribution or distribution tenant in the *Amazon CloudFront Developer Guide*.
 */
export declare const associateAlias: API.OperationMethod<AssociateAliasRequest, AssociateAliasResponse, AssociateAliasError, Credentials | HttpClient.HttpClient>;
export type AssociateDistributionTenantWebACLError = AccessDenied | EntityLimitExceeded | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | CommonErrors;
/**
 * Associates the WAF web ACL with a distribution tenant.
 */
export declare const associateDistributionTenantWebACL: API.OperationMethod<AssociateDistributionTenantWebACLRequest, AssociateDistributionTenantWebACLResult, AssociateDistributionTenantWebACLError, Credentials | HttpClient.HttpClient>;
export type AssociateDistributionWebACLError = AccessDenied | EntityLimitExceeded | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | CommonErrors;
/**
 * Associates the WAF web ACL with a distribution.
 */
export declare const associateDistributionWebACL: API.OperationMethod<AssociateDistributionWebACLRequest, AssociateDistributionWebACLResult, AssociateDistributionWebACLError, Credentials | HttpClient.HttpClient>;
export type CopyDistributionError = AccessDenied | CNAMEAlreadyExists | DistributionAlreadyExists | IllegalFieldLevelEncryptionConfigAssociationWithCacheBehavior | InconsistentQuantities | InvalidArgument | InvalidDefaultRootObject | InvalidErrorCode | InvalidForwardCookies | InvalidFunctionAssociation | InvalidGeoRestrictionParameter | InvalidHeadersForS3Origin | InvalidIfMatchVersion | InvalidLambdaFunctionAssociation | InvalidLocationCode | InvalidMinimumProtocolVersion | InvalidOrigin | InvalidOriginAccessControl | InvalidOriginAccessIdentity | InvalidOriginKeepaliveTimeout | InvalidOriginReadTimeout | InvalidProtocolSettings | InvalidQueryStringParameters | InvalidRelativePath | InvalidRequiredProtocol | InvalidResponseCode | InvalidTTLOrder | InvalidViewerCertificate | InvalidWebACLId | MissingBody | NoSuchCachePolicy | NoSuchDistribution | NoSuchFieldLevelEncryptionConfig | NoSuchOrigin | NoSuchOriginRequestPolicy | NoSuchRealtimeLogConfig | NoSuchResponseHeadersPolicy | PreconditionFailed | RealtimeLogConfigOwnerMismatch | TooManyCacheBehaviors | TooManyCertificates | TooManyCookieNamesInWhiteList | TooManyDistributionCNAMEs | TooManyDistributions | TooManyDistributionsAssociatedToCachePolicy | TooManyDistributionsAssociatedToFieldLevelEncryptionConfig | TooManyDistributionsAssociatedToKeyGroup | TooManyDistributionsAssociatedToOriginAccessControl | TooManyDistributionsAssociatedToOriginRequestPolicy | TooManyDistributionsAssociatedToResponseHeadersPolicy | TooManyDistributionsWithFunctionAssociations | TooManyDistributionsWithLambdaAssociations | TooManyDistributionsWithSingleFunctionARN | TooManyFunctionAssociations | TooManyHeadersInForwardedValues | TooManyKeyGroupsAssociatedToDistribution | TooManyLambdaFunctionAssociations | TooManyOriginCustomHeaders | TooManyOriginGroupsPerDistribution | TooManyOrigins | TooManyQueryStringParameters | TooManyTrustedSigners | TrustedKeyGroupDoesNotExist | TrustedSignerDoesNotExist | CommonErrors;
/**
 * Creates a staging distribution using the configuration of the provided primary distribution. A staging distribution is a copy of an existing distribution (called the primary distribution) that you can use in a continuous deployment workflow.
 *
 * After you create a staging distribution, you can use `UpdateDistribution` to modify the staging distribution's configuration. Then you can use `CreateContinuousDeploymentPolicy` to incrementally move traffic to the staging distribution.
 *
 * This API operation requires the following IAM permissions:
 *
 * - GetDistribution
 *
 * - CreateDistribution
 *
 * - CopyDistribution
 */
export declare const copyDistribution: API.OperationMethod<CopyDistributionRequest, CopyDistributionResult, CopyDistributionError, Credentials | HttpClient.HttpClient>;
export type CreateAnycastIpListError = AccessDenied | EntityAlreadyExists | EntityLimitExceeded | InvalidArgument | InvalidTagging | UnsupportedOperation | CommonErrors;
/**
 * Creates an Anycast static IP list.
 */
export declare const createAnycastIpList: API.OperationMethod<CreateAnycastIpListRequest, CreateAnycastIpListResult, CreateAnycastIpListError, Credentials | HttpClient.HttpClient>;
export type CreateCachePolicyError = AccessDenied | CachePolicyAlreadyExists | InconsistentQuantities | InvalidArgument | TooManyCachePolicies | TooManyCookiesInCachePolicy | TooManyHeadersInCachePolicy | TooManyQueryStringsInCachePolicy | CommonErrors;
/**
 * Creates a cache policy.
 *
 * After you create a cache policy, you can attach it to one or more cache behaviors. When it's attached to a cache behavior, the cache policy determines the following:
 *
 * - The values that CloudFront includes in the *cache key*. These values can include HTTP headers, cookies, and URL query strings. CloudFront uses the cache key to find an object in its cache that it can return to the viewer.
 *
 * - The default, minimum, and maximum time to live (TTL) values that you want objects to stay in the CloudFront cache.
 *
 * If your minimum TTL is greater than 0, CloudFront will cache content for at least the duration specified in the cache policy's minimum TTL, even if the `Cache-Control: no-cache`, `no-store`, or `private` directives are present in the origin headers.
 *
 * The headers, cookies, and query strings that are included in the cache key are also included in requests that CloudFront sends to the origin. CloudFront sends a request when it can't find an object in its cache that matches the request's cache key. If you want to send values to the origin but *not* include them in the cache key, use `OriginRequestPolicy`.
 *
 * For more information about cache policies, see Controlling the cache key in the *Amazon CloudFront Developer Guide*.
 */
export declare const createCachePolicy: API.OperationMethod<CreateCachePolicyRequest, CreateCachePolicyResult, CreateCachePolicyError, Credentials | HttpClient.HttpClient>;
export type CreateCloudFrontOriginAccessIdentityError = CloudFrontOriginAccessIdentityAlreadyExists | InconsistentQuantities | InvalidArgument | MissingBody | TooManyCloudFrontOriginAccessIdentities | CommonErrors;
/**
 * Creates a new origin access identity. If you're using Amazon S3 for your origin, you can use an origin access identity to require users to access your content using a CloudFront URL instead of the Amazon S3 URL. For more information about how to use origin access identities, see Serving Private Content through CloudFront in the *Amazon CloudFront Developer Guide*.
 */
export declare const createCloudFrontOriginAccessIdentity: API.OperationMethod<CreateCloudFrontOriginAccessIdentityRequest, CreateCloudFrontOriginAccessIdentityResult, CreateCloudFrontOriginAccessIdentityError, Credentials | HttpClient.HttpClient>;
export type CreateConnectionFunctionError = AccessDenied | EntityAlreadyExists | EntityLimitExceeded | EntitySizeLimitExceeded | InvalidArgument | InvalidTagging | UnsupportedOperation | CommonErrors;
/**
 * Creates a connection function.
 */
export declare const createConnectionFunction: API.OperationMethod<CreateConnectionFunctionRequest, CreateConnectionFunctionResult, CreateConnectionFunctionError, Credentials | HttpClient.HttpClient>;
export type CreateConnectionGroupError = AccessDenied | EntityAlreadyExists | EntityLimitExceeded | EntityNotFound | InvalidArgument | InvalidTagging | CommonErrors;
/**
 * Creates a connection group.
 */
export declare const createConnectionGroup: API.OperationMethod<CreateConnectionGroupRequest, CreateConnectionGroupResult, CreateConnectionGroupError, Credentials | HttpClient.HttpClient>;
export type CreateContinuousDeploymentPolicyError = AccessDenied | ContinuousDeploymentPolicyAlreadyExists | InconsistentQuantities | InvalidArgument | StagingDistributionInUse | TooManyContinuousDeploymentPolicies | CommonErrors;
/**
 * Creates a continuous deployment policy that distributes traffic for a custom domain name to two different CloudFront distributions.
 *
 * To use a continuous deployment policy, first use `CopyDistribution` to create a staging distribution, then use `UpdateDistribution` to modify the staging distribution's configuration.
 *
 * After you create and update a staging distribution, you can use a continuous deployment policy to incrementally move traffic to the staging distribution. This workflow enables you to test changes to a distribution's configuration before moving all of your domain's production traffic to the new configuration.
 */
export declare const createContinuousDeploymentPolicy: API.OperationMethod<CreateContinuousDeploymentPolicyRequest, CreateContinuousDeploymentPolicyResult, CreateContinuousDeploymentPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateDistributionError = AccessDenied | CNAMEAlreadyExists | ContinuousDeploymentPolicyInUse | DistributionAlreadyExists | EntityLimitExceeded | EntityNotFound | IllegalFieldLevelEncryptionConfigAssociationWithCacheBehavior | IllegalOriginAccessConfiguration | InconsistentQuantities | InvalidArgument | InvalidDefaultRootObject | InvalidDomainNameForOriginAccessControl | InvalidErrorCode | InvalidForwardCookies | InvalidFunctionAssociation | InvalidGeoRestrictionParameter | InvalidHeadersForS3Origin | InvalidLambdaFunctionAssociation | InvalidLocationCode | InvalidMinimumProtocolVersion | InvalidOrigin | InvalidOriginAccessControl | InvalidOriginAccessIdentity | InvalidOriginKeepaliveTimeout | InvalidOriginReadTimeout | InvalidProtocolSettings | InvalidQueryStringParameters | InvalidRelativePath | InvalidRequiredProtocol | InvalidResponseCode | InvalidTTLOrder | InvalidViewerCertificate | InvalidWebACLId | MissingBody | NoSuchCachePolicy | NoSuchContinuousDeploymentPolicy | NoSuchFieldLevelEncryptionConfig | NoSuchOrigin | NoSuchOriginRequestPolicy | NoSuchRealtimeLogConfig | NoSuchResponseHeadersPolicy | RealtimeLogConfigOwnerMismatch | TooManyCacheBehaviors | TooManyCertificates | TooManyCookieNamesInWhiteList | TooManyDistributionCNAMEs | TooManyDistributions | TooManyDistributionsAssociatedToCachePolicy | TooManyDistributionsAssociatedToFieldLevelEncryptionConfig | TooManyDistributionsAssociatedToKeyGroup | TooManyDistributionsAssociatedToOriginAccessControl | TooManyDistributionsAssociatedToOriginRequestPolicy | TooManyDistributionsAssociatedToResponseHeadersPolicy | TooManyDistributionsWithFunctionAssociations | TooManyDistributionsWithLambdaAssociations | TooManyDistributionsWithSingleFunctionARN | TooManyFunctionAssociations | TooManyHeadersInForwardedValues | TooManyKeyGroupsAssociatedToDistribution | TooManyLambdaFunctionAssociations | TooManyOriginCustomHeaders | TooManyOriginGroupsPerDistribution | TooManyOrigins | TooManyQueryStringParameters | TooManyTrustedSigners | TrustedKeyGroupDoesNotExist | TrustedSignerDoesNotExist | CommonErrors;
/**
 * Creates a CloudFront distribution.
 */
export declare const createDistribution: API.OperationMethod<CreateDistributionRequest, CreateDistributionResult, CreateDistributionError, Credentials | HttpClient.HttpClient>;
export type CreateDistributionTenantError = AccessDenied | CNAMEAlreadyExists | EntityAlreadyExists | EntityLimitExceeded | EntityNotFound | InvalidArgument | InvalidAssociation | InvalidTagging | CommonErrors;
/**
 * Creates a distribution tenant.
 */
export declare const createDistributionTenant: API.OperationMethod<CreateDistributionTenantRequest, CreateDistributionTenantResult, CreateDistributionTenantError, Credentials | HttpClient.HttpClient>;
export type CreateDistributionWithTagsError = AccessDenied | CNAMEAlreadyExists | ContinuousDeploymentPolicyInUse | DistributionAlreadyExists | EntityNotFound | IllegalFieldLevelEncryptionConfigAssociationWithCacheBehavior | IllegalOriginAccessConfiguration | InconsistentQuantities | InvalidArgument | InvalidDefaultRootObject | InvalidDomainNameForOriginAccessControl | InvalidErrorCode | InvalidForwardCookies | InvalidFunctionAssociation | InvalidGeoRestrictionParameter | InvalidHeadersForS3Origin | InvalidLambdaFunctionAssociation | InvalidLocationCode | InvalidMinimumProtocolVersion | InvalidOrigin | InvalidOriginAccessControl | InvalidOriginAccessIdentity | InvalidOriginKeepaliveTimeout | InvalidOriginReadTimeout | InvalidProtocolSettings | InvalidQueryStringParameters | InvalidRelativePath | InvalidRequiredProtocol | InvalidResponseCode | InvalidTagging | InvalidTTLOrder | InvalidViewerCertificate | InvalidWebACLId | MissingBody | NoSuchCachePolicy | NoSuchContinuousDeploymentPolicy | NoSuchFieldLevelEncryptionConfig | NoSuchOrigin | NoSuchOriginRequestPolicy | NoSuchRealtimeLogConfig | NoSuchResponseHeadersPolicy | RealtimeLogConfigOwnerMismatch | TooManyCacheBehaviors | TooManyCertificates | TooManyCookieNamesInWhiteList | TooManyDistributionCNAMEs | TooManyDistributions | TooManyDistributionsAssociatedToCachePolicy | TooManyDistributionsAssociatedToFieldLevelEncryptionConfig | TooManyDistributionsAssociatedToKeyGroup | TooManyDistributionsAssociatedToOriginAccessControl | TooManyDistributionsAssociatedToOriginRequestPolicy | TooManyDistributionsAssociatedToResponseHeadersPolicy | TooManyDistributionsWithFunctionAssociations | TooManyDistributionsWithLambdaAssociations | TooManyDistributionsWithSingleFunctionARN | TooManyFunctionAssociations | TooManyHeadersInForwardedValues | TooManyKeyGroupsAssociatedToDistribution | TooManyLambdaFunctionAssociations | TooManyOriginCustomHeaders | TooManyOriginGroupsPerDistribution | TooManyOrigins | TooManyQueryStringParameters | TooManyTrustedSigners | TrustedKeyGroupDoesNotExist | TrustedSignerDoesNotExist | CommonErrors;
/**
 * Create a new distribution with tags. This API operation requires the following IAM permissions:
 *
 * - CreateDistribution
 *
 * - TagResource
 */
export declare const createDistributionWithTags: API.OperationMethod<CreateDistributionWithTagsRequest, CreateDistributionWithTagsResult, CreateDistributionWithTagsError, Credentials | HttpClient.HttpClient>;
export type CreateFieldLevelEncryptionConfigError = FieldLevelEncryptionConfigAlreadyExists | InconsistentQuantities | InvalidArgument | NoSuchFieldLevelEncryptionProfile | QueryArgProfileEmpty | TooManyFieldLevelEncryptionConfigs | TooManyFieldLevelEncryptionContentTypeProfiles | TooManyFieldLevelEncryptionQueryArgProfiles | CommonErrors;
/**
 * Create a new field-level encryption configuration.
 */
export declare const createFieldLevelEncryptionConfig: API.OperationMethod<CreateFieldLevelEncryptionConfigRequest, CreateFieldLevelEncryptionConfigResult, CreateFieldLevelEncryptionConfigError, Credentials | HttpClient.HttpClient>;
export type CreateFieldLevelEncryptionProfileError = FieldLevelEncryptionProfileAlreadyExists | FieldLevelEncryptionProfileSizeExceeded | InconsistentQuantities | InvalidArgument | NoSuchPublicKey | TooManyFieldLevelEncryptionEncryptionEntities | TooManyFieldLevelEncryptionFieldPatterns | TooManyFieldLevelEncryptionProfiles | CommonErrors;
/**
 * Create a field-level encryption profile.
 */
export declare const createFieldLevelEncryptionProfile: API.OperationMethod<CreateFieldLevelEncryptionProfileRequest, CreateFieldLevelEncryptionProfileResult, CreateFieldLevelEncryptionProfileError, Credentials | HttpClient.HttpClient>;
export type CreateFunctionError = FunctionAlreadyExists | FunctionSizeLimitExceeded | InvalidArgument | TooManyFunctions | UnsupportedOperation | CommonErrors;
/**
 * Creates a CloudFront function.
 *
 * To create a function, you provide the function code and some configuration information about the function. The response contains an Amazon Resource Name (ARN) that uniquely identifies the function.
 *
 * When you create a function, it's in the `DEVELOPMENT` stage. In this stage, you can test the function with `TestFunction`, and update it with `UpdateFunction`.
 *
 * When you're ready to use your function with a CloudFront distribution, use `PublishFunction` to copy the function from the `DEVELOPMENT` stage to `LIVE`. When it's live, you can attach the function to a distribution's cache behavior, using the function's ARN.
 */
export declare const createFunction: API.OperationMethod<CreateFunctionRequest, CreateFunctionResult, CreateFunctionError, Credentials | HttpClient.HttpClient>;
export type CreateInvalidationError = AccessDenied | BatchTooLarge | InconsistentQuantities | InvalidArgument | MissingBody | NoSuchDistribution | TooManyInvalidationsInProgress | CommonErrors;
/**
 * Create a new invalidation. For more information, see Invalidating files in the *Amazon CloudFront Developer Guide*.
 */
export declare const createInvalidation: API.OperationMethod<CreateInvalidationRequest, CreateInvalidationResult, CreateInvalidationError, Credentials | HttpClient.HttpClient>;
export type CreateInvalidationForDistributionTenantError = AccessDenied | BatchTooLarge | EntityNotFound | InconsistentQuantities | InvalidArgument | MissingBody | TooManyInvalidationsInProgress | CommonErrors;
/**
 * Creates an invalidation for a distribution tenant. For more information, see Invalidating files in the *Amazon CloudFront Developer Guide*.
 */
export declare const createInvalidationForDistributionTenant: API.OperationMethod<CreateInvalidationForDistributionTenantRequest, CreateInvalidationForDistributionTenantResult, CreateInvalidationForDistributionTenantError, Credentials | HttpClient.HttpClient>;
export type CreateKeyGroupError = InvalidArgument | KeyGroupAlreadyExists | TooManyKeyGroups | TooManyPublicKeysInKeyGroup | CommonErrors;
/**
 * Creates a key group that you can use with CloudFront signed URLs and signed cookies.
 *
 * To create a key group, you must specify at least one public key for the key group. After you create a key group, you can reference it from one or more cache behaviors. When you reference a key group in a cache behavior, CloudFront requires signed URLs or signed cookies for all requests that match the cache behavior. The URLs or cookies must be signed with a private key whose corresponding public key is in the key group. The signed URL or cookie contains information about which public key CloudFront should use to verify the signature. For more information, see Serving private content in the *Amazon CloudFront Developer Guide*.
 */
export declare const createKeyGroup: API.OperationMethod<CreateKeyGroupRequest, CreateKeyGroupResult, CreateKeyGroupError, Credentials | HttpClient.HttpClient>;
export type CreateKeyValueStoreError = AccessDenied | EntityAlreadyExists | EntityLimitExceeded | EntitySizeLimitExceeded | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Specifies the key value store resource to add to your account. In your account, the key value store names must be unique. You can also import key value store data in JSON format from an S3 bucket by providing a valid `ImportSource` that you own.
 */
export declare const createKeyValueStore: API.OperationMethod<CreateKeyValueStoreRequest, CreateKeyValueStoreResult, CreateKeyValueStoreError, Credentials | HttpClient.HttpClient>;
export type CreateMonitoringSubscriptionError = AccessDenied | MonitoringSubscriptionAlreadyExists | NoSuchDistribution | UnsupportedOperation | CommonErrors;
/**
 * Enables or disables additional Amazon CloudWatch metrics for the specified CloudFront distribution. The additional metrics incur an additional cost.
 *
 * For more information, see Viewing additional CloudFront distribution metrics in the *Amazon CloudFront Developer Guide*.
 */
export declare const createMonitoringSubscription: API.OperationMethod<CreateMonitoringSubscriptionRequest, CreateMonitoringSubscriptionResult, CreateMonitoringSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateOriginAccessControlError = InvalidArgument | OriginAccessControlAlreadyExists | TooManyOriginAccessControls | CommonErrors;
/**
 * Creates a new origin access control in CloudFront. After you create an origin access control, you can add it to an origin in a CloudFront distribution so that CloudFront sends authenticated (signed) requests to the origin.
 *
 * This makes it possible to block public access to the origin, allowing viewers (users) to access the origin's content only through CloudFront.
 *
 * For more information about using a CloudFront origin access control, see Restricting access to an Amazon Web Services origin in the *Amazon CloudFront Developer Guide*.
 */
export declare const createOriginAccessControl: API.OperationMethod<CreateOriginAccessControlRequest, CreateOriginAccessControlResult, CreateOriginAccessControlError, Credentials | HttpClient.HttpClient>;
export type CreateOriginRequestPolicyError = AccessDenied | InconsistentQuantities | InvalidArgument | OriginRequestPolicyAlreadyExists | TooManyCookiesInOriginRequestPolicy | TooManyHeadersInOriginRequestPolicy | TooManyOriginRequestPolicies | TooManyQueryStringsInOriginRequestPolicy | CommonErrors;
/**
 * Creates an origin request policy.
 *
 * After you create an origin request policy, you can attach it to one or more cache behaviors. When it's attached to a cache behavior, the origin request policy determines the values that CloudFront includes in requests that it sends to the origin. Each request that CloudFront sends to the origin includes the following:
 *
 * - The request body and the URL path (without the domain name) from the viewer request.
 *
 * - The headers that CloudFront automatically includes in every origin request, including `Host`, `User-Agent`, and `X-Amz-Cf-Id`.
 *
 * - All HTTP headers, cookies, and URL query strings that are specified in the cache policy or the origin request policy. These can include items from the viewer request and, in the case of headers, additional ones that are added by CloudFront.
 *
 * CloudFront sends a request when it can't find a valid object in its cache that matches the request. If you want to send values to the origin and also include them in the cache key, use `CachePolicy`.
 *
 * For more information about origin request policies, see Controlling origin requests in the *Amazon CloudFront Developer Guide*.
 */
export declare const createOriginRequestPolicy: API.OperationMethod<CreateOriginRequestPolicyRequest, CreateOriginRequestPolicyResult, CreateOriginRequestPolicyError, Credentials | HttpClient.HttpClient>;
export type CreatePublicKeyError = InvalidArgument | PublicKeyAlreadyExists | TooManyPublicKeys | CommonErrors;
/**
 * Uploads a public key to CloudFront that you can use with signed URLs and signed cookies, or with field-level encryption.
 */
export declare const createPublicKey: API.OperationMethod<CreatePublicKeyRequest, CreatePublicKeyResult, CreatePublicKeyError, Credentials | HttpClient.HttpClient>;
export type CreateRealtimeLogConfigError = AccessDenied | InvalidArgument | RealtimeLogConfigAlreadyExists | TooManyRealtimeLogConfigs | CommonErrors;
/**
 * Creates a real-time log configuration.
 *
 * After you create a real-time log configuration, you can attach it to one or more cache behaviors to send real-time log data to the specified Amazon Kinesis data stream.
 *
 * For more information about real-time log configurations, see Real-time logs in the *Amazon CloudFront Developer Guide*.
 */
export declare const createRealtimeLogConfig: API.OperationMethod<CreateRealtimeLogConfigRequest, CreateRealtimeLogConfigResult, CreateRealtimeLogConfigError, Credentials | HttpClient.HttpClient>;
export type CreateResponseHeadersPolicyError = AccessDenied | InconsistentQuantities | InvalidArgument | ResponseHeadersPolicyAlreadyExists | TooLongCSPInResponseHeadersPolicy | TooManyCustomHeadersInResponseHeadersPolicy | TooManyRemoveHeadersInResponseHeadersPolicy | TooManyResponseHeadersPolicies | CommonErrors;
/**
 * Creates a response headers policy.
 *
 * A response headers policy contains information about a set of HTTP headers. To create a response headers policy, you provide some metadata about the policy and a set of configurations that specify the headers.
 *
 * After you create a response headers policy, you can use its ID to attach it to one or more cache behaviors in a CloudFront distribution. When it's attached to a cache behavior, the response headers policy affects the HTTP headers that CloudFront includes in HTTP responses to requests that match the cache behavior. CloudFront adds or removes response headers according to the configuration of the response headers policy.
 *
 * For more information, see Adding or removing HTTP headers in CloudFront responses in the *Amazon CloudFront Developer Guide*.
 */
export declare const createResponseHeadersPolicy: API.OperationMethod<CreateResponseHeadersPolicyRequest, CreateResponseHeadersPolicyResult, CreateResponseHeadersPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateStreamingDistributionError = AccessDenied | CNAMEAlreadyExists | InconsistentQuantities | InvalidArgument | InvalidOrigin | InvalidOriginAccessControl | InvalidOriginAccessIdentity | MissingBody | StreamingDistributionAlreadyExists | TooManyStreamingDistributionCNAMEs | TooManyStreamingDistributions | TooManyTrustedSigners | TrustedSignerDoesNotExist | CommonErrors;
/**
 * This API is deprecated. Amazon CloudFront is deprecating real-time messaging protocol (RTMP) distributions on December 31, 2020. For more information, read the announcement on the Amazon CloudFront discussion forum.
 */
export declare const createStreamingDistribution: API.OperationMethod<CreateStreamingDistributionRequest, CreateStreamingDistributionResult, CreateStreamingDistributionError, Credentials | HttpClient.HttpClient>;
export type CreateStreamingDistributionWithTagsError = AccessDenied | CNAMEAlreadyExists | InconsistentQuantities | InvalidArgument | InvalidOrigin | InvalidOriginAccessControl | InvalidOriginAccessIdentity | InvalidTagging | MissingBody | StreamingDistributionAlreadyExists | TooManyStreamingDistributionCNAMEs | TooManyStreamingDistributions | TooManyTrustedSigners | TrustedSignerDoesNotExist | CommonErrors;
/**
 * This API is deprecated. Amazon CloudFront is deprecating real-time messaging protocol (RTMP) distributions on December 31, 2020. For more information, read the announcement on the Amazon CloudFront discussion forum.
 */
export declare const createStreamingDistributionWithTags: API.OperationMethod<CreateStreamingDistributionWithTagsRequest, CreateStreamingDistributionWithTagsResult, CreateStreamingDistributionWithTagsError, Credentials | HttpClient.HttpClient>;
export type CreateTrustStoreError = AccessDenied | EntityAlreadyExists | EntityLimitExceeded | EntityNotFound | InvalidArgument | InvalidTagging | CommonErrors;
/**
 * Creates a trust store.
 */
export declare const createTrustStore: API.OperationMethod<CreateTrustStoreRequest, CreateTrustStoreResult, CreateTrustStoreError, Credentials | HttpClient.HttpClient>;
export type CreateVpcOriginError = AccessDenied | EntityAlreadyExists | EntityLimitExceeded | InconsistentQuantities | InvalidArgument | InvalidTagging | UnsupportedOperation | CommonErrors;
/**
 * Create an Amazon CloudFront VPC origin.
 */
export declare const createVpcOrigin: API.OperationMethod<CreateVpcOriginRequest, CreateVpcOriginResult, CreateVpcOriginError, Credentials | HttpClient.HttpClient>;
export type DeleteAnycastIpListError = AccessDenied | CannotDeleteEntityWhileInUse | EntityNotFound | IllegalDelete | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Deletes an Anycast static IP list.
 */
export declare const deleteAnycastIpList: API.OperationMethod<DeleteAnycastIpListRequest, DeleteAnycastIpListResponse, DeleteAnycastIpListError, Credentials | HttpClient.HttpClient>;
export type DeleteCachePolicyError = AccessDenied | CachePolicyInUse | IllegalDelete | InvalidIfMatchVersion | NoSuchCachePolicy | PreconditionFailed | CommonErrors;
/**
 * Deletes a cache policy.
 *
 * You cannot delete a cache policy if it's attached to a cache behavior. First update your distributions to remove the cache policy from all cache behaviors, then delete the cache policy.
 *
 * To delete a cache policy, you must provide the policy's identifier and version. To get these values, you can use `ListCachePolicies` or `GetCachePolicy`.
 */
export declare const deleteCachePolicy: API.OperationMethod<DeleteCachePolicyRequest, DeleteCachePolicyResponse, DeleteCachePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteCloudFrontOriginAccessIdentityError = AccessDenied | CloudFrontOriginAccessIdentityInUse | InvalidIfMatchVersion | NoSuchCloudFrontOriginAccessIdentity | PreconditionFailed | CommonErrors;
/**
 * Delete an origin access identity.
 */
export declare const deleteCloudFrontOriginAccessIdentity: API.OperationMethod<DeleteCloudFrontOriginAccessIdentityRequest, DeleteCloudFrontOriginAccessIdentityResponse, DeleteCloudFrontOriginAccessIdentityError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionFunctionError = AccessDenied | CannotDeleteEntityWhileInUse | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Deletes a connection function.
 */
export declare const deleteConnectionFunction: API.OperationMethod<DeleteConnectionFunctionRequest, DeleteConnectionFunctionResponse, DeleteConnectionFunctionError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionGroupError = AccessDenied | CannotDeleteEntityWhileInUse | EntityNotFound | InvalidIfMatchVersion | PreconditionFailed | ResourceNotDisabled | CommonErrors;
/**
 * Deletes a connection group.
 */
export declare const deleteConnectionGroup: API.OperationMethod<DeleteConnectionGroupRequest, DeleteConnectionGroupResponse, DeleteConnectionGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteContinuousDeploymentPolicyError = AccessDenied | ContinuousDeploymentPolicyInUse | InvalidArgument | InvalidIfMatchVersion | NoSuchContinuousDeploymentPolicy | PreconditionFailed | CommonErrors;
/**
 * Deletes a continuous deployment policy.
 *
 * You cannot delete a continuous deployment policy that's attached to a primary distribution. First update your distribution to remove the continuous deployment policy, then you can delete the policy.
 */
export declare const deleteContinuousDeploymentPolicy: API.OperationMethod<DeleteContinuousDeploymentPolicyRequest, DeleteContinuousDeploymentPolicyResponse, DeleteContinuousDeploymentPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteDistributionError = AccessDenied | DistributionNotDisabled | InvalidIfMatchVersion | NoSuchDistribution | PreconditionFailed | ResourceInUse | CommonErrors;
/**
 * Delete a distribution.
 *
 * Before you can delete a distribution, you must disable it, which requires permission to update the distribution. Once deleted, a distribution cannot be recovered.
 */
export declare const deleteDistribution: API.OperationMethod<DeleteDistributionRequest, DeleteDistributionResponse, DeleteDistributionError, Credentials | HttpClient.HttpClient>;
export type DeleteDistributionTenantError = AccessDenied | EntityNotFound | InvalidIfMatchVersion | PreconditionFailed | ResourceNotDisabled | CommonErrors;
/**
 * Deletes a distribution tenant. If you use this API operation to delete a distribution tenant that is currently enabled, the request will fail.
 *
 * To delete a distribution tenant, you must first disable the distribution tenant by using the `UpdateDistributionTenant` API operation.
 */
export declare const deleteDistributionTenant: API.OperationMethod<DeleteDistributionTenantRequest, DeleteDistributionTenantResponse, DeleteDistributionTenantError, Credentials | HttpClient.HttpClient>;
export type DeleteFieldLevelEncryptionConfigError = AccessDenied | FieldLevelEncryptionConfigInUse | InvalidIfMatchVersion | NoSuchFieldLevelEncryptionConfig | PreconditionFailed | CommonErrors;
/**
 * Remove a field-level encryption configuration.
 */
export declare const deleteFieldLevelEncryptionConfig: API.OperationMethod<DeleteFieldLevelEncryptionConfigRequest, DeleteFieldLevelEncryptionConfigResponse, DeleteFieldLevelEncryptionConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteFieldLevelEncryptionProfileError = AccessDenied | FieldLevelEncryptionProfileInUse | InvalidIfMatchVersion | NoSuchFieldLevelEncryptionProfile | PreconditionFailed | CommonErrors;
/**
 * Remove a field-level encryption profile.
 */
export declare const deleteFieldLevelEncryptionProfile: API.OperationMethod<DeleteFieldLevelEncryptionProfileRequest, DeleteFieldLevelEncryptionProfileResponse, DeleteFieldLevelEncryptionProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteFunctionError = FunctionInUse | InvalidIfMatchVersion | NoSuchFunctionExists | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Deletes a CloudFront function.
 *
 * You cannot delete a function if it's associated with a cache behavior. First, update your distributions to remove the function association from all cache behaviors, then delete the function.
 *
 * To delete a function, you must provide the function's name and version (`ETag` value). To get these values, you can use `ListFunctions` and `DescribeFunction`.
 */
export declare const deleteFunction: API.OperationMethod<DeleteFunctionRequest, DeleteFunctionResponse, DeleteFunctionError, Credentials | HttpClient.HttpClient>;
export type DeleteKeyGroupError = InvalidIfMatchVersion | NoSuchResource | PreconditionFailed | ResourceInUse | CommonErrors;
/**
 * Deletes a key group.
 *
 * You cannot delete a key group that is referenced in a cache behavior. First update your distributions to remove the key group from all cache behaviors, then delete the key group.
 *
 * To delete a key group, you must provide the key group's identifier and version. To get these values, use `ListKeyGroups` followed by `GetKeyGroup` or `GetKeyGroupConfig`.
 */
export declare const deleteKeyGroup: API.OperationMethod<DeleteKeyGroupRequest, DeleteKeyGroupResponse, DeleteKeyGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteKeyValueStoreError = AccessDenied | CannotDeleteEntityWhileInUse | EntityNotFound | InvalidIfMatchVersion | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Specifies the key value store to delete.
 */
export declare const deleteKeyValueStore: API.OperationMethod<DeleteKeyValueStoreRequest, DeleteKeyValueStoreResponse, DeleteKeyValueStoreError, Credentials | HttpClient.HttpClient>;
export type DeleteMonitoringSubscriptionError = AccessDenied | NoSuchDistribution | NoSuchMonitoringSubscription | UnsupportedOperation | CommonErrors;
/**
 * Disables additional CloudWatch metrics for the specified CloudFront distribution.
 */
export declare const deleteMonitoringSubscription: API.OperationMethod<DeleteMonitoringSubscriptionRequest, DeleteMonitoringSubscriptionResult, DeleteMonitoringSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteOriginAccessControlError = AccessDenied | InvalidIfMatchVersion | NoSuchOriginAccessControl | OriginAccessControlInUse | PreconditionFailed | CommonErrors;
/**
 * Deletes a CloudFront origin access control.
 *
 * You cannot delete an origin access control if it's in use. First, update all distributions to remove the origin access control from all origins, then delete the origin access control.
 */
export declare const deleteOriginAccessControl: API.OperationMethod<DeleteOriginAccessControlRequest, DeleteOriginAccessControlResponse, DeleteOriginAccessControlError, Credentials | HttpClient.HttpClient>;
export type DeleteOriginRequestPolicyError = AccessDenied | IllegalDelete | InvalidIfMatchVersion | NoSuchOriginRequestPolicy | OriginRequestPolicyInUse | PreconditionFailed | CommonErrors;
/**
 * Deletes an origin request policy.
 *
 * You cannot delete an origin request policy if it's attached to any cache behaviors. First update your distributions to remove the origin request policy from all cache behaviors, then delete the origin request policy.
 *
 * To delete an origin request policy, you must provide the policy's identifier and version. To get the identifier, you can use `ListOriginRequestPolicies` or `GetOriginRequestPolicy`.
 */
export declare const deleteOriginRequestPolicy: API.OperationMethod<DeleteOriginRequestPolicyRequest, DeleteOriginRequestPolicyResponse, DeleteOriginRequestPolicyError, Credentials | HttpClient.HttpClient>;
export type DeletePublicKeyError = AccessDenied | InvalidIfMatchVersion | NoSuchPublicKey | PreconditionFailed | PublicKeyInUse | CommonErrors;
/**
 * Remove a public key you previously added to CloudFront.
 */
export declare const deletePublicKey: API.OperationMethod<DeletePublicKeyRequest, DeletePublicKeyResponse, DeletePublicKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteRealtimeLogConfigError = AccessDenied | InvalidArgument | NoSuchRealtimeLogConfig | RealtimeLogConfigInUse | CommonErrors;
/**
 * Deletes a real-time log configuration.
 *
 * You cannot delete a real-time log configuration if it's attached to a cache behavior. First update your distributions to remove the real-time log configuration from all cache behaviors, then delete the real-time log configuration.
 *
 * To delete a real-time log configuration, you can provide the configuration's name or its Amazon Resource Name (ARN). You must provide at least one. If you provide both, CloudFront uses the name to identify the real-time log configuration to delete.
 */
export declare const deleteRealtimeLogConfig: API.OperationMethod<DeleteRealtimeLogConfigRequest, DeleteRealtimeLogConfigResponse, DeleteRealtimeLogConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = AccessDenied | EntityNotFound | IllegalDelete | InvalidArgument | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Deletes the resource policy attached to the CloudFront resource.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteResponseHeadersPolicyError = AccessDenied | IllegalDelete | InvalidIfMatchVersion | NoSuchResponseHeadersPolicy | PreconditionFailed | ResponseHeadersPolicyInUse | CommonErrors;
/**
 * Deletes a response headers policy.
 *
 * You cannot delete a response headers policy if it's attached to a cache behavior. First update your distributions to remove the response headers policy from all cache behaviors, then delete the response headers policy.
 *
 * To delete a response headers policy, you must provide the policy's identifier and version. To get these values, you can use `ListResponseHeadersPolicies` or `GetResponseHeadersPolicy`.
 */
export declare const deleteResponseHeadersPolicy: API.OperationMethod<DeleteResponseHeadersPolicyRequest, DeleteResponseHeadersPolicyResponse, DeleteResponseHeadersPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteStreamingDistributionError = AccessDenied | InvalidIfMatchVersion | NoSuchStreamingDistribution | PreconditionFailed | StreamingDistributionNotDisabled | CommonErrors;
/**
 * Delete a streaming distribution. To delete an RTMP distribution using the CloudFront API, perform the following steps.
 *
 * **To delete an RTMP distribution using the CloudFront API**:
 *
 * - Disable the RTMP distribution.
 *
 * - Submit a `GET Streaming Distribution Config` request to get the current configuration and the `Etag` header for the distribution.
 *
 * - Update the XML document that was returned in the response to your `GET Streaming Distribution Config` request to change the value of `Enabled` to `false`.
 *
 * - Submit a `PUT Streaming Distribution Config` request to update the configuration for your distribution. In the request body, include the XML document that you updated in Step 3. Then set the value of the HTTP `If-Match` header to the value of the `ETag` header that CloudFront returned when you submitted the `GET Streaming Distribution Config` request in Step 2.
 *
 * - Review the response to the `PUT Streaming Distribution Config` request to confirm that the distribution was successfully disabled.
 *
 * - Submit a `GET Streaming Distribution Config` request to confirm that your changes have propagated. When propagation is complete, the value of `Status` is `Deployed`.
 *
 * - Submit a `DELETE Streaming Distribution` request. Set the value of the HTTP `If-Match` header to the value of the `ETag` header that CloudFront returned when you submitted the `GET Streaming Distribution Config` request in Step 2.
 *
 * - Review the response to your `DELETE Streaming Distribution` request to confirm that the distribution was successfully deleted.
 *
 * For information about deleting a distribution using the CloudFront console, see Deleting a Distribution in the *Amazon CloudFront Developer Guide*.
 */
export declare const deleteStreamingDistribution: API.OperationMethod<DeleteStreamingDistributionRequest, DeleteStreamingDistributionResponse, DeleteStreamingDistributionError, Credentials | HttpClient.HttpClient>;
export type DeleteTrustStoreError = AccessDenied | CannotDeleteEntityWhileInUse | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | CommonErrors;
/**
 * Deletes a trust store.
 */
export declare const deleteTrustStore: API.OperationMethod<DeleteTrustStoreRequest, DeleteTrustStoreResponse, DeleteTrustStoreError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcOriginError = AccessDenied | CannotDeleteEntityWhileInUse | EntityNotFound | IllegalDelete | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Delete an Amazon CloudFront VPC origin.
 */
export declare const deleteVpcOrigin: API.OperationMethod<DeleteVpcOriginRequest, DeleteVpcOriginResult, DeleteVpcOriginError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectionFunctionError = AccessDenied | EntityNotFound | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Describes a connection function.
 */
export declare const describeConnectionFunction: API.OperationMethod<DescribeConnectionFunctionRequest, DescribeConnectionFunctionResult, DescribeConnectionFunctionError, Credentials | HttpClient.HttpClient>;
export type DescribeFunctionError = NoSuchFunctionExists | UnsupportedOperation | CommonErrors;
/**
 * Gets configuration information and metadata about a CloudFront function, but not the function's code. To get a function's code, use `GetFunction`.
 *
 * To get configuration information and metadata about a function, you must provide the function's name and stage. To get these values, you can use `ListFunctions`.
 */
export declare const describeFunction: API.OperationMethod<DescribeFunctionRequest, DescribeFunctionResult, DescribeFunctionError, Credentials | HttpClient.HttpClient>;
export type DescribeKeyValueStoreError = AccessDenied | EntityNotFound | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Specifies the key value store and its configuration.
 */
export declare const describeKeyValueStore: API.OperationMethod<DescribeKeyValueStoreRequest, DescribeKeyValueStoreResult, DescribeKeyValueStoreError, Credentials | HttpClient.HttpClient>;
export type DisassociateDistributionTenantWebACLError = AccessDenied | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | CommonErrors;
/**
 * Disassociates a distribution tenant from the WAF web ACL.
 */
export declare const disassociateDistributionTenantWebACL: API.OperationMethod<DisassociateDistributionTenantWebACLRequest, DisassociateDistributionTenantWebACLResult, DisassociateDistributionTenantWebACLError, Credentials | HttpClient.HttpClient>;
export type DisassociateDistributionWebACLError = AccessDenied | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | CommonErrors;
/**
 * Disassociates a distribution from the WAF web ACL.
 */
export declare const disassociateDistributionWebACL: API.OperationMethod<DisassociateDistributionWebACLRequest, DisassociateDistributionWebACLResult, DisassociateDistributionWebACLError, Credentials | HttpClient.HttpClient>;
export type GetAnycastIpListError = AccessDenied | EntityNotFound | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Gets an Anycast static IP list.
 */
export declare const getAnycastIpList: API.OperationMethod<GetAnycastIpListRequest, GetAnycastIpListResult, GetAnycastIpListError, Credentials | HttpClient.HttpClient>;
export type GetCachePolicyError = AccessDenied | NoSuchCachePolicy | CommonErrors;
/**
 * Gets a cache policy, including the following metadata:
 *
 * - The policy's identifier.
 *
 * - The date and time when the policy was last modified.
 *
 * To get a cache policy, you must provide the policy's identifier. If the cache policy is attached to a distribution's cache behavior, you can get the policy's identifier using `ListDistributions` or `GetDistribution`. If the cache policy is not attached to a cache behavior, you can get the identifier using `ListCachePolicies`.
 */
export declare const getCachePolicy: API.OperationMethod<GetCachePolicyRequest, GetCachePolicyResult, GetCachePolicyError, Credentials | HttpClient.HttpClient>;
export type GetCachePolicyConfigError = AccessDenied | NoSuchCachePolicy | CommonErrors;
/**
 * Gets a cache policy configuration.
 *
 * To get a cache policy configuration, you must provide the policy's identifier. If the cache policy is attached to a distribution's cache behavior, you can get the policy's identifier using `ListDistributions` or `GetDistribution`. If the cache policy is not attached to a cache behavior, you can get the identifier using `ListCachePolicies`.
 */
export declare const getCachePolicyConfig: API.OperationMethod<GetCachePolicyConfigRequest, GetCachePolicyConfigResult, GetCachePolicyConfigError, Credentials | HttpClient.HttpClient>;
export type GetCloudFrontOriginAccessIdentityError = AccessDenied | NoSuchCloudFrontOriginAccessIdentity | CommonErrors;
/**
 * Get the information about an origin access identity.
 */
export declare const getCloudFrontOriginAccessIdentity: API.OperationMethod<GetCloudFrontOriginAccessIdentityRequest, GetCloudFrontOriginAccessIdentityResult, GetCloudFrontOriginAccessIdentityError, Credentials | HttpClient.HttpClient>;
export type GetCloudFrontOriginAccessIdentityConfigError = AccessDenied | NoSuchCloudFrontOriginAccessIdentity | CommonErrors;
/**
 * Get the configuration information about an origin access identity.
 */
export declare const getCloudFrontOriginAccessIdentityConfig: API.OperationMethod<GetCloudFrontOriginAccessIdentityConfigRequest, GetCloudFrontOriginAccessIdentityConfigResult, GetCloudFrontOriginAccessIdentityConfigError, Credentials | HttpClient.HttpClient>;
export type GetConnectionFunctionError = AccessDenied | EntityNotFound | UnsupportedOperation | CommonErrors;
/**
 * Gets a connection function.
 */
export declare const getConnectionFunction: API.OperationMethod<GetConnectionFunctionRequest, GetConnectionFunctionResult, GetConnectionFunctionError, Credentials | HttpClient.HttpClient>;
export type GetConnectionGroupError = AccessDenied | EntityNotFound | CommonErrors;
/**
 * Gets information about a connection group.
 */
export declare const getConnectionGroup: API.OperationMethod<GetConnectionGroupRequest, GetConnectionGroupResult, GetConnectionGroupError, Credentials | HttpClient.HttpClient>;
export type GetConnectionGroupByRoutingEndpointError = AccessDenied | EntityNotFound | CommonErrors;
/**
 * Gets information about a connection group by using the endpoint that you specify.
 */
export declare const getConnectionGroupByRoutingEndpoint: API.OperationMethod<GetConnectionGroupByRoutingEndpointRequest, GetConnectionGroupByRoutingEndpointResult, GetConnectionGroupByRoutingEndpointError, Credentials | HttpClient.HttpClient>;
export type GetContinuousDeploymentPolicyError = AccessDenied | NoSuchContinuousDeploymentPolicy | CommonErrors;
/**
 * Gets a continuous deployment policy, including metadata (the policy's identifier and the date and time when the policy was last modified).
 */
export declare const getContinuousDeploymentPolicy: API.OperationMethod<GetContinuousDeploymentPolicyRequest, GetContinuousDeploymentPolicyResult, GetContinuousDeploymentPolicyError, Credentials | HttpClient.HttpClient>;
export type GetContinuousDeploymentPolicyConfigError = AccessDenied | NoSuchContinuousDeploymentPolicy | CommonErrors;
/**
 * Gets configuration information about a continuous deployment policy.
 */
export declare const getContinuousDeploymentPolicyConfig: API.OperationMethod<GetContinuousDeploymentPolicyConfigRequest, GetContinuousDeploymentPolicyConfigResult, GetContinuousDeploymentPolicyConfigError, Credentials | HttpClient.HttpClient>;
export type GetDistributionError = AccessDenied | NoSuchDistribution | CommonErrors;
/**
 * Get the information about a distribution.
 */
export declare const getDistribution: API.OperationMethod<GetDistributionRequest, GetDistributionResult, GetDistributionError, Credentials | HttpClient.HttpClient>;
export type GetDistributionConfigError = AccessDenied | NoSuchDistribution | CommonErrors;
/**
 * Get the configuration information about a distribution.
 */
export declare const getDistributionConfig: API.OperationMethod<GetDistributionConfigRequest, GetDistributionConfigResult, GetDistributionConfigError, Credentials | HttpClient.HttpClient>;
export type GetDistributionTenantError = AccessDenied | EntityNotFound | CommonErrors;
/**
 * Gets information about a distribution tenant.
 */
export declare const getDistributionTenant: API.OperationMethod<GetDistributionTenantRequest, GetDistributionTenantResult, GetDistributionTenantError, Credentials | HttpClient.HttpClient>;
export type GetDistributionTenantByDomainError = AccessDenied | EntityNotFound | CommonErrors;
/**
 * Gets information about a distribution tenant by the associated domain.
 */
export declare const getDistributionTenantByDomain: API.OperationMethod<GetDistributionTenantByDomainRequest, GetDistributionTenantByDomainResult, GetDistributionTenantByDomainError, Credentials | HttpClient.HttpClient>;
export type GetFieldLevelEncryptionError = AccessDenied | NoSuchFieldLevelEncryptionConfig | CommonErrors;
/**
 * Get the field-level encryption configuration information.
 */
export declare const getFieldLevelEncryption: API.OperationMethod<GetFieldLevelEncryptionRequest, GetFieldLevelEncryptionResult, GetFieldLevelEncryptionError, Credentials | HttpClient.HttpClient>;
export type GetFieldLevelEncryptionConfigError = AccessDenied | NoSuchFieldLevelEncryptionConfig | CommonErrors;
/**
 * Get the field-level encryption configuration information.
 */
export declare const getFieldLevelEncryptionConfig: API.OperationMethod<GetFieldLevelEncryptionConfigRequest, GetFieldLevelEncryptionConfigResult, GetFieldLevelEncryptionConfigError, Credentials | HttpClient.HttpClient>;
export type GetFieldLevelEncryptionProfileError = AccessDenied | NoSuchFieldLevelEncryptionProfile | CommonErrors;
/**
 * Get the field-level encryption profile information.
 */
export declare const getFieldLevelEncryptionProfile: API.OperationMethod<GetFieldLevelEncryptionProfileRequest, GetFieldLevelEncryptionProfileResult, GetFieldLevelEncryptionProfileError, Credentials | HttpClient.HttpClient>;
export type GetFieldLevelEncryptionProfileConfigError = AccessDenied | NoSuchFieldLevelEncryptionProfile | CommonErrors;
/**
 * Get the field-level encryption profile configuration information.
 */
export declare const getFieldLevelEncryptionProfileConfig: API.OperationMethod<GetFieldLevelEncryptionProfileConfigRequest, GetFieldLevelEncryptionProfileConfigResult, GetFieldLevelEncryptionProfileConfigError, Credentials | HttpClient.HttpClient>;
export type GetFunctionError = NoSuchFunctionExists | UnsupportedOperation | CommonErrors;
/**
 * Gets the code of a CloudFront function. To get configuration information and metadata about a function, use `DescribeFunction`.
 *
 * To get a function's code, you must provide the function's name and stage. To get these values, you can use `ListFunctions`.
 */
export declare const getFunction: API.OperationMethod<GetFunctionRequest, GetFunctionResult, GetFunctionError, Credentials | HttpClient.HttpClient>;
export type GetInvalidationError = AccessDenied | NoSuchDistribution | NoSuchInvalidation | CommonErrors;
/**
 * Get the information about an invalidation.
 */
export declare const getInvalidation: API.OperationMethod<GetInvalidationRequest, GetInvalidationResult, GetInvalidationError, Credentials | HttpClient.HttpClient>;
export type GetInvalidationForDistributionTenantError = AccessDenied | EntityNotFound | NoSuchInvalidation | CommonErrors;
/**
 * Gets information about a specific invalidation for a distribution tenant.
 */
export declare const getInvalidationForDistributionTenant: API.OperationMethod<GetInvalidationForDistributionTenantRequest, GetInvalidationForDistributionTenantResult, GetInvalidationForDistributionTenantError, Credentials | HttpClient.HttpClient>;
export type GetKeyGroupError = NoSuchResource | CommonErrors;
/**
 * Gets a key group, including the date and time when the key group was last modified.
 *
 * To get a key group, you must provide the key group's identifier. If the key group is referenced in a distribution's cache behavior, you can get the key group's identifier using `ListDistributions` or `GetDistribution`. If the key group is not referenced in a cache behavior, you can get the identifier using `ListKeyGroups`.
 */
export declare const getKeyGroup: API.OperationMethod<GetKeyGroupRequest, GetKeyGroupResult, GetKeyGroupError, Credentials | HttpClient.HttpClient>;
export type GetKeyGroupConfigError = NoSuchResource | CommonErrors;
/**
 * Gets a key group configuration.
 *
 * To get a key group configuration, you must provide the key group's identifier. If the key group is referenced in a distribution's cache behavior, you can get the key group's identifier using `ListDistributions` or `GetDistribution`. If the key group is not referenced in a cache behavior, you can get the identifier using `ListKeyGroups`.
 */
export declare const getKeyGroupConfig: API.OperationMethod<GetKeyGroupConfigRequest, GetKeyGroupConfigResult, GetKeyGroupConfigError, Credentials | HttpClient.HttpClient>;
export type GetManagedCertificateDetailsError = AccessDenied | EntityNotFound | CommonErrors;
/**
 * Gets details about the CloudFront managed ACM certificate.
 */
export declare const getManagedCertificateDetails: API.OperationMethod<GetManagedCertificateDetailsRequest, GetManagedCertificateDetailsResult, GetManagedCertificateDetailsError, Credentials | HttpClient.HttpClient>;
export type GetMonitoringSubscriptionError = AccessDenied | NoSuchDistribution | NoSuchMonitoringSubscription | UnsupportedOperation | CommonErrors;
/**
 * Gets information about whether additional CloudWatch metrics are enabled for the specified CloudFront distribution.
 */
export declare const getMonitoringSubscription: API.OperationMethod<GetMonitoringSubscriptionRequest, GetMonitoringSubscriptionResult, GetMonitoringSubscriptionError, Credentials | HttpClient.HttpClient>;
export type GetOriginAccessControlError = AccessDenied | NoSuchOriginAccessControl | CommonErrors;
/**
 * Gets a CloudFront origin access control, including its unique identifier.
 */
export declare const getOriginAccessControl: API.OperationMethod<GetOriginAccessControlRequest, GetOriginAccessControlResult, GetOriginAccessControlError, Credentials | HttpClient.HttpClient>;
export type GetOriginAccessControlConfigError = AccessDenied | NoSuchOriginAccessControl | CommonErrors;
/**
 * Gets a CloudFront origin access control configuration.
 */
export declare const getOriginAccessControlConfig: API.OperationMethod<GetOriginAccessControlConfigRequest, GetOriginAccessControlConfigResult, GetOriginAccessControlConfigError, Credentials | HttpClient.HttpClient>;
export type GetOriginRequestPolicyError = AccessDenied | NoSuchOriginRequestPolicy | CommonErrors;
/**
 * Gets an origin request policy, including the following metadata:
 *
 * - The policy's identifier.
 *
 * - The date and time when the policy was last modified.
 *
 * To get an origin request policy, you must provide the policy's identifier. If the origin request policy is attached to a distribution's cache behavior, you can get the policy's identifier using `ListDistributions` or `GetDistribution`. If the origin request policy is not attached to a cache behavior, you can get the identifier using `ListOriginRequestPolicies`.
 */
export declare const getOriginRequestPolicy: API.OperationMethod<GetOriginRequestPolicyRequest, GetOriginRequestPolicyResult, GetOriginRequestPolicyError, Credentials | HttpClient.HttpClient>;
export type GetOriginRequestPolicyConfigError = AccessDenied | NoSuchOriginRequestPolicy | CommonErrors;
/**
 * Gets an origin request policy configuration.
 *
 * To get an origin request policy configuration, you must provide the policy's identifier. If the origin request policy is attached to a distribution's cache behavior, you can get the policy's identifier using `ListDistributions` or `GetDistribution`. If the origin request policy is not attached to a cache behavior, you can get the identifier using `ListOriginRequestPolicies`.
 */
export declare const getOriginRequestPolicyConfig: API.OperationMethod<GetOriginRequestPolicyConfigRequest, GetOriginRequestPolicyConfigResult, GetOriginRequestPolicyConfigError, Credentials | HttpClient.HttpClient>;
export type GetPublicKeyError = AccessDenied | NoSuchPublicKey | CommonErrors;
/**
 * Gets a public key.
 */
export declare const getPublicKey: API.OperationMethod<GetPublicKeyRequest, GetPublicKeyResult, GetPublicKeyError, Credentials | HttpClient.HttpClient>;
export type GetPublicKeyConfigError = AccessDenied | NoSuchPublicKey | CommonErrors;
/**
 * Gets a public key configuration.
 */
export declare const getPublicKeyConfig: API.OperationMethod<GetPublicKeyConfigRequest, GetPublicKeyConfigResult, GetPublicKeyConfigError, Credentials | HttpClient.HttpClient>;
export type GetRealtimeLogConfigError = AccessDenied | InvalidArgument | NoSuchRealtimeLogConfig | CommonErrors;
/**
 * Gets a real-time log configuration.
 *
 * To get a real-time log configuration, you can provide the configuration's name or its Amazon Resource Name (ARN). You must provide at least one. If you provide both, CloudFront uses the name to identify the real-time log configuration to get.
 */
export declare const getRealtimeLogConfig: API.OperationMethod<GetRealtimeLogConfigRequest, GetRealtimeLogConfigResult, GetRealtimeLogConfigError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDenied | EntityNotFound | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Retrieves the resource policy for the specified CloudFront resource that you own and have shared.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest, GetResourcePolicyResult, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetResponseHeadersPolicyError = AccessDenied | NoSuchResponseHeadersPolicy | CommonErrors;
/**
 * Gets a response headers policy, including metadata (the policy's identifier and the date and time when the policy was last modified).
 *
 * To get a response headers policy, you must provide the policy's identifier. If the response headers policy is attached to a distribution's cache behavior, you can get the policy's identifier using `ListDistributions` or `GetDistribution`. If the response headers policy is not attached to a cache behavior, you can get the identifier using `ListResponseHeadersPolicies`.
 */
export declare const getResponseHeadersPolicy: API.OperationMethod<GetResponseHeadersPolicyRequest, GetResponseHeadersPolicyResult, GetResponseHeadersPolicyError, Credentials | HttpClient.HttpClient>;
export type GetResponseHeadersPolicyConfigError = AccessDenied | NoSuchResponseHeadersPolicy | CommonErrors;
/**
 * Gets a response headers policy configuration.
 *
 * To get a response headers policy configuration, you must provide the policy's identifier. If the response headers policy is attached to a distribution's cache behavior, you can get the policy's identifier using `ListDistributions` or `GetDistribution`. If the response headers policy is not attached to a cache behavior, you can get the identifier using `ListResponseHeadersPolicies`.
 */
export declare const getResponseHeadersPolicyConfig: API.OperationMethod<GetResponseHeadersPolicyConfigRequest, GetResponseHeadersPolicyConfigResult, GetResponseHeadersPolicyConfigError, Credentials | HttpClient.HttpClient>;
export type GetStreamingDistributionError = AccessDenied | NoSuchStreamingDistribution | CommonErrors;
/**
 * Gets information about a specified RTMP distribution, including the distribution configuration.
 */
export declare const getStreamingDistribution: API.OperationMethod<GetStreamingDistributionRequest, GetStreamingDistributionResult, GetStreamingDistributionError, Credentials | HttpClient.HttpClient>;
export type GetStreamingDistributionConfigError = AccessDenied | NoSuchStreamingDistribution | CommonErrors;
/**
 * Get the configuration information about a streaming distribution.
 */
export declare const getStreamingDistributionConfig: API.OperationMethod<GetStreamingDistributionConfigRequest, GetStreamingDistributionConfigResult, GetStreamingDistributionConfigError, Credentials | HttpClient.HttpClient>;
export type GetTrustStoreError = AccessDenied | EntityNotFound | InvalidArgument | CommonErrors;
/**
 * Gets a trust store.
 */
export declare const getTrustStore: API.OperationMethod<GetTrustStoreRequest, GetTrustStoreResult, GetTrustStoreError, Credentials | HttpClient.HttpClient>;
export type GetVpcOriginError = AccessDenied | EntityNotFound | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Get the details of an Amazon CloudFront VPC origin.
 */
export declare const getVpcOrigin: API.OperationMethod<GetVpcOriginRequest, GetVpcOriginResult, GetVpcOriginError, Credentials | HttpClient.HttpClient>;
export type ListAnycastIpListsError = AccessDenied | EntityNotFound | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Lists your Anycast static IP lists.
 */
export declare const listAnycastIpLists: API.OperationMethod<ListAnycastIpListsRequest, ListAnycastIpListsResult, ListAnycastIpListsError, Credentials | HttpClient.HttpClient>;
export type ListCachePoliciesError = AccessDenied | InvalidArgument | NoSuchCachePolicy | CommonErrors;
/**
 * Gets a list of cache policies.
 *
 * You can optionally apply a filter to return only the managed policies created by Amazon Web Services, or only the custom policies created in your Amazon Web Services account.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listCachePolicies: API.OperationMethod<ListCachePoliciesRequest, ListCachePoliciesResult, ListCachePoliciesError, Credentials | HttpClient.HttpClient>;
export type ListCloudFrontOriginAccessIdentitiesError = InvalidArgument | CommonErrors;
/**
 * Lists origin access identities.
 */
export declare const listCloudFrontOriginAccessIdentities: API.PaginatedOperationMethod<ListCloudFrontOriginAccessIdentitiesRequest, ListCloudFrontOriginAccessIdentitiesResult, ListCloudFrontOriginAccessIdentitiesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListConflictingAliasesError = InvalidArgument | NoSuchDistribution | CommonErrors;
/**
 * The `ListConflictingAliases` API operation only supports standard distributions. To list domain conflicts for both standard distributions and distribution tenants, we recommend that you use the ListDomainConflicts API operation instead.
 *
 * Gets a list of aliases that conflict or overlap with the provided alias, and the associated CloudFront standard distribution and Amazon Web Services accounts for each conflicting alias. An alias is commonly known as a custom domain or vanity domain. It can also be called a CNAME or alternate domain name.
 *
 * In the returned list, the standard distribution and account IDs are partially hidden, which allows you to identify the standard distribution and accounts that you own, and helps to protect the information of ones that you don't own.
 *
 * Use this operation to find aliases that are in use in CloudFront that conflict or overlap with the provided alias. For example, if you provide `www.example.com` as input, the returned list can include `www.example.com` and the overlapping wildcard alternate domain name (`*.example.com`), if they exist. If you provide `*.example.com` as input, the returned list can include `*.example.com` and any alternate domain names covered by that wildcard (for example, `www.example.com`, `test.example.com`, `dev.example.com`, and so on), if they exist.
 *
 * To list conflicting aliases, specify the alias to search and the ID of a standard distribution in your account that has an attached TLS certificate that includes the provided alias. For more information, including how to set up the standard distribution and certificate, see Moving an alternate domain name to a different standard distribution or distribution tenant in the *Amazon CloudFront Developer Guide*.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listConflictingAliases: API.OperationMethod<ListConflictingAliasesRequest, ListConflictingAliasesResult, ListConflictingAliasesError, Credentials | HttpClient.HttpClient>;
export type ListConnectionFunctionsError = AccessDenied | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Lists connection functions.
 */
export declare const listConnectionFunctions: API.PaginatedOperationMethod<ListConnectionFunctionsRequest, ListConnectionFunctionsResult, ListConnectionFunctionsError, Credentials | HttpClient.HttpClient, ConnectionFunctionSummary>;
export type ListConnectionGroupsError = AccessDenied | EntityNotFound | InvalidArgument | CommonErrors;
/**
 * Lists the connection groups in your Amazon Web Services account.
 */
export declare const listConnectionGroups: API.PaginatedOperationMethod<ListConnectionGroupsRequest, ListConnectionGroupsResult, ListConnectionGroupsError, Credentials | HttpClient.HttpClient, ConnectionGroupSummary>;
export type ListContinuousDeploymentPoliciesError = AccessDenied | InvalidArgument | NoSuchContinuousDeploymentPolicy | CommonErrors;
/**
 * Gets a list of the continuous deployment policies in your Amazon Web Services account.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listContinuousDeploymentPolicies: API.OperationMethod<ListContinuousDeploymentPoliciesRequest, ListContinuousDeploymentPoliciesResult, ListContinuousDeploymentPoliciesError, Credentials | HttpClient.HttpClient>;
export type ListDistributionsError = InvalidArgument | CommonErrors;
/**
 * List CloudFront distributions.
 */
export declare const listDistributions: API.PaginatedOperationMethod<ListDistributionsRequest, ListDistributionsResult, ListDistributionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDistributionsByAnycastIpListIdError = AccessDenied | EntityNotFound | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Lists the distributions in your account that are associated with the specified `AnycastIpListId`.
 */
export declare const listDistributionsByAnycastIpListId: API.OperationMethod<ListDistributionsByAnycastIpListIdRequest, ListDistributionsByAnycastIpListIdResult, ListDistributionsByAnycastIpListIdError, Credentials | HttpClient.HttpClient>;
export type ListDistributionsByCachePolicyIdError = AccessDenied | InvalidArgument | NoSuchCachePolicy | CommonErrors;
/**
 * Gets a list of distribution IDs for distributions that have a cache behavior that's associated with the specified cache policy.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listDistributionsByCachePolicyId: API.OperationMethod<ListDistributionsByCachePolicyIdRequest, ListDistributionsByCachePolicyIdResult, ListDistributionsByCachePolicyIdError, Credentials | HttpClient.HttpClient>;
export type ListDistributionsByConnectionFunctionError = AccessDenied | EntityNotFound | InvalidArgument | CommonErrors;
/**
 * Lists distributions by connection function.
 */
export declare const listDistributionsByConnectionFunction: API.PaginatedOperationMethod<ListDistributionsByConnectionFunctionRequest, ListDistributionsByConnectionFunctionResult, ListDistributionsByConnectionFunctionError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDistributionsByConnectionModeError = AccessDenied | InvalidArgument | CommonErrors;
/**
 * Lists the distributions by the connection mode that you specify.
 */
export declare const listDistributionsByConnectionMode: API.PaginatedOperationMethod<ListDistributionsByConnectionModeRequest, ListDistributionsByConnectionModeResult, ListDistributionsByConnectionModeError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDistributionsByKeyGroupError = InvalidArgument | NoSuchResource | CommonErrors;
/**
 * Gets a list of distribution IDs for distributions that have a cache behavior that references the specified key group.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listDistributionsByKeyGroup: API.OperationMethod<ListDistributionsByKeyGroupRequest, ListDistributionsByKeyGroupResult, ListDistributionsByKeyGroupError, Credentials | HttpClient.HttpClient>;
export type ListDistributionsByOriginRequestPolicyIdError = AccessDenied | InvalidArgument | NoSuchOriginRequestPolicy | CommonErrors;
/**
 * Gets a list of distribution IDs for distributions that have a cache behavior that's associated with the specified origin request policy.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listDistributionsByOriginRequestPolicyId: API.OperationMethod<ListDistributionsByOriginRequestPolicyIdRequest, ListDistributionsByOriginRequestPolicyIdResult, ListDistributionsByOriginRequestPolicyIdError, Credentials | HttpClient.HttpClient>;
export type ListDistributionsByOwnedResourceError = AccessDenied | EntityNotFound | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Lists the CloudFront distributions that are associated with the specified resource that you own.
 */
export declare const listDistributionsByOwnedResource: API.OperationMethod<ListDistributionsByOwnedResourceRequest, ListDistributionsByOwnedResourceResult, ListDistributionsByOwnedResourceError, Credentials | HttpClient.HttpClient>;
export type ListDistributionsByRealtimeLogConfigError = InvalidArgument | CommonErrors;
/**
 * Gets a list of distributions that have a cache behavior that's associated with the specified real-time log configuration.
 *
 * You can specify the real-time log configuration by its name or its Amazon Resource Name (ARN). You must provide at least one. If you provide both, CloudFront uses the name to identify the real-time log configuration to list distributions for.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listDistributionsByRealtimeLogConfig: API.OperationMethod<ListDistributionsByRealtimeLogConfigRequest, ListDistributionsByRealtimeLogConfigResult, ListDistributionsByRealtimeLogConfigError, Credentials | HttpClient.HttpClient>;
export type ListDistributionsByResponseHeadersPolicyIdError = AccessDenied | InvalidArgument | NoSuchResponseHeadersPolicy | CommonErrors;
/**
 * Gets a list of distribution IDs for distributions that have a cache behavior that's associated with the specified response headers policy.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listDistributionsByResponseHeadersPolicyId: API.OperationMethod<ListDistributionsByResponseHeadersPolicyIdRequest, ListDistributionsByResponseHeadersPolicyIdResult, ListDistributionsByResponseHeadersPolicyIdError, Credentials | HttpClient.HttpClient>;
export type ListDistributionsByTrustStoreError = AccessDenied | EntityNotFound | InvalidArgument | CommonErrors;
/**
 * Lists distributions by trust store.
 */
export declare const listDistributionsByTrustStore: API.PaginatedOperationMethod<ListDistributionsByTrustStoreRequest, ListDistributionsByTrustStoreResult, ListDistributionsByTrustStoreError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDistributionsByVpcOriginIdError = AccessDenied | EntityNotFound | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * List CloudFront distributions by their VPC origin ID.
 */
export declare const listDistributionsByVpcOriginId: API.OperationMethod<ListDistributionsByVpcOriginIdRequest, ListDistributionsByVpcOriginIdResult, ListDistributionsByVpcOriginIdError, Credentials | HttpClient.HttpClient>;
export type ListDistributionsByWebACLIdError = InvalidArgument | InvalidWebACLId | CommonErrors;
/**
 * List the distributions that are associated with a specified WAF web ACL.
 */
export declare const listDistributionsByWebACLId: API.OperationMethod<ListDistributionsByWebACLIdRequest, ListDistributionsByWebACLIdResult, ListDistributionsByWebACLIdError, Credentials | HttpClient.HttpClient>;
export type ListDistributionTenantsError = AccessDenied | EntityNotFound | InvalidArgument | CommonErrors;
/**
 * Lists the distribution tenants in your Amazon Web Services account.
 */
export declare const listDistributionTenants: API.PaginatedOperationMethod<ListDistributionTenantsRequest, ListDistributionTenantsResult, ListDistributionTenantsError, Credentials | HttpClient.HttpClient, DistributionTenantSummary>;
export type ListDistributionTenantsByCustomizationError = AccessDenied | EntityNotFound | InvalidArgument | CommonErrors;
/**
 * Lists distribution tenants by the customization that you specify.
 *
 * You must specify either the `CertificateArn` parameter or `WebACLArn` parameter, but not both in the same request.
 */
export declare const listDistributionTenantsByCustomization: API.PaginatedOperationMethod<ListDistributionTenantsByCustomizationRequest, ListDistributionTenantsByCustomizationResult, ListDistributionTenantsByCustomizationError, Credentials | HttpClient.HttpClient, DistributionTenantSummary>;
export type ListDomainConflictsError = AccessDenied | EntityNotFound | InvalidArgument | CommonErrors;
/**
 * We recommend that you use the `ListDomainConflicts` API operation to check for domain conflicts, as it supports both standard distributions and distribution tenants. ListConflictingAliases performs similar checks but only supports standard distributions.
 *
 * Lists existing domain associations that conflict with the domain that you specify.
 *
 * You can use this API operation to identify potential domain conflicts when moving domains between standard distributions and/or distribution tenants. Domain conflicts must be resolved first before they can be moved.
 *
 * For example, if you provide `www.example.com` as input, the returned list can include `www.example.com` and the overlapping wildcard alternate domain name (`*.example.com`), if they exist. If you provide `*.example.com` as input, the returned list can include `*.example.com` and any alternate domain names covered by that wildcard (for example, `www.example.com`, `test.example.com`, `dev.example.com`, and so on), if they exist.
 *
 * To list conflicting domains, specify the following:
 *
 * - The domain to search for
 *
 * - The ID of a standard distribution or distribution tenant in your account that has an attached TLS certificate, which covers the specified domain
 *
 * For more information, including how to set up the standard distribution or distribution tenant, and the certificate, see Moving an alternate domain name to a different standard distribution or distribution tenant in the *Amazon CloudFront Developer Guide*.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listDomainConflicts: API.PaginatedOperationMethod<ListDomainConflictsRequest, ListDomainConflictsResult, ListDomainConflictsError, Credentials | HttpClient.HttpClient, DomainConflict>;
export type ListFieldLevelEncryptionConfigsError = InvalidArgument | CommonErrors;
/**
 * List all field-level encryption configurations that have been created in CloudFront for this account.
 */
export declare const listFieldLevelEncryptionConfigs: API.OperationMethod<ListFieldLevelEncryptionConfigsRequest, ListFieldLevelEncryptionConfigsResult, ListFieldLevelEncryptionConfigsError, Credentials | HttpClient.HttpClient>;
export type ListFieldLevelEncryptionProfilesError = InvalidArgument | CommonErrors;
/**
 * Request a list of field-level encryption profiles that have been created in CloudFront for this account.
 */
export declare const listFieldLevelEncryptionProfiles: API.OperationMethod<ListFieldLevelEncryptionProfilesRequest, ListFieldLevelEncryptionProfilesResult, ListFieldLevelEncryptionProfilesError, Credentials | HttpClient.HttpClient>;
export type ListFunctionsError = InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Gets a list of all CloudFront functions in your Amazon Web Services account.
 *
 * You can optionally apply a filter to return only the functions that are in the specified stage, either `DEVELOPMENT` or `LIVE`.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listFunctions: API.OperationMethod<ListFunctionsRequest, ListFunctionsResult, ListFunctionsError, Credentials | HttpClient.HttpClient>;
export type ListInvalidationsError = AccessDenied | InvalidArgument | NoSuchDistribution | CommonErrors;
/**
 * Lists invalidation batches.
 */
export declare const listInvalidations: API.PaginatedOperationMethod<ListInvalidationsRequest, ListInvalidationsResult, ListInvalidationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListInvalidationsForDistributionTenantError = AccessDenied | EntityNotFound | InvalidArgument | CommonErrors;
/**
 * Lists the invalidations for a distribution tenant.
 */
export declare const listInvalidationsForDistributionTenant: API.PaginatedOperationMethod<ListInvalidationsForDistributionTenantRequest, ListInvalidationsForDistributionTenantResult, ListInvalidationsForDistributionTenantError, Credentials | HttpClient.HttpClient, unknown>;
export type ListKeyGroupsError = InvalidArgument | CommonErrors;
/**
 * Gets a list of key groups.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listKeyGroups: API.OperationMethod<ListKeyGroupsRequest, ListKeyGroupsResult, ListKeyGroupsError, Credentials | HttpClient.HttpClient>;
export type ListKeyValueStoresError = AccessDenied | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Specifies the key value stores to list.
 */
export declare const listKeyValueStores: API.PaginatedOperationMethod<ListKeyValueStoresRequest, ListKeyValueStoresResult, ListKeyValueStoresError, Credentials | HttpClient.HttpClient, unknown>;
export type ListOriginAccessControlsError = InvalidArgument | CommonErrors;
/**
 * Gets the list of CloudFront origin access controls (OACs) in this Amazon Web Services account.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send another request that specifies the `NextMarker` value from the current response as the `Marker` value in the next request.
 *
 * If you're not using origin access controls for your Amazon Web Services account, the `ListOriginAccessControls` operation doesn't return the `Items` element in the response.
 */
export declare const listOriginAccessControls: API.PaginatedOperationMethod<ListOriginAccessControlsRequest, ListOriginAccessControlsResult, ListOriginAccessControlsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListOriginRequestPoliciesError = AccessDenied | InvalidArgument | NoSuchOriginRequestPolicy | CommonErrors;
/**
 * Gets a list of origin request policies.
 *
 * You can optionally apply a filter to return only the managed policies created by Amazon Web Services, or only the custom policies created in your Amazon Web Services account.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listOriginRequestPolicies: API.OperationMethod<ListOriginRequestPoliciesRequest, ListOriginRequestPoliciesResult, ListOriginRequestPoliciesError, Credentials | HttpClient.HttpClient>;
export type ListPublicKeysError = InvalidArgument | CommonErrors;
/**
 * List all public keys that have been added to CloudFront for this account.
 */
export declare const listPublicKeys: API.PaginatedOperationMethod<ListPublicKeysRequest, ListPublicKeysResult, ListPublicKeysError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRealtimeLogConfigsError = AccessDenied | InvalidArgument | NoSuchRealtimeLogConfig | CommonErrors;
/**
 * Gets a list of real-time log configurations.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listRealtimeLogConfigs: API.OperationMethod<ListRealtimeLogConfigsRequest, ListRealtimeLogConfigsResult, ListRealtimeLogConfigsError, Credentials | HttpClient.HttpClient>;
export type ListResponseHeadersPoliciesError = AccessDenied | InvalidArgument | NoSuchResponseHeadersPolicy | CommonErrors;
/**
 * Gets a list of response headers policies.
 *
 * You can optionally apply a filter to get only the managed policies created by Amazon Web Services, or only the custom policies created in your Amazon Web Services account.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listResponseHeadersPolicies: API.OperationMethod<ListResponseHeadersPoliciesRequest, ListResponseHeadersPoliciesResult, ListResponseHeadersPoliciesError, Credentials | HttpClient.HttpClient>;
export type ListStreamingDistributionsError = InvalidArgument | CommonErrors;
/**
 * List streaming distributions.
 */
export declare const listStreamingDistributions: API.PaginatedOperationMethod<ListStreamingDistributionsRequest, ListStreamingDistributionsResult, ListStreamingDistributionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDenied | InvalidArgument | InvalidTagging | NoSuchResource | CommonErrors;
/**
 * List tags for a CloudFront resource. For more information, see Tagging a distribution in the *Amazon CloudFront Developer Guide*.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResult, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTrustStoresError = AccessDenied | EntityNotFound | InvalidArgument | CommonErrors;
/**
 * Lists trust stores.
 */
export declare const listTrustStores: API.PaginatedOperationMethod<ListTrustStoresRequest, ListTrustStoresResult, ListTrustStoresError, Credentials | HttpClient.HttpClient, TrustStoreSummary>;
export type ListVpcOriginsError = AccessDenied | EntityNotFound | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * List the CloudFront VPC origins in your account.
 */
export declare const listVpcOrigins: API.OperationMethod<ListVpcOriginsRequest, ListVpcOriginsResult, ListVpcOriginsError, Credentials | HttpClient.HttpClient>;
export type PublishConnectionFunctionError = AccessDenied | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Publishes a connection function.
 */
export declare const publishConnectionFunction: API.OperationMethod<PublishConnectionFunctionRequest, PublishConnectionFunctionResult, PublishConnectionFunctionError, Credentials | HttpClient.HttpClient>;
export type PublishFunctionError = InvalidArgument | InvalidIfMatchVersion | NoSuchFunctionExists | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Publishes a CloudFront function by copying the function code from the `DEVELOPMENT` stage to `LIVE`. This automatically updates all cache behaviors that are using this function to use the newly published copy in the `LIVE` stage.
 *
 * When a function is published to the `LIVE` stage, you can attach the function to a distribution's cache behavior, using the function's Amazon Resource Name (ARN).
 *
 * To publish a function, you must provide the function's name and version (`ETag` value). To get these values, you can use `ListFunctions` and `DescribeFunction`.
 */
export declare const publishFunction: API.OperationMethod<PublishFunctionRequest, PublishFunctionResult, PublishFunctionError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = AccessDenied | EntityNotFound | IllegalUpdate | InvalidArgument | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Creates a resource control policy for a given CloudFront resource.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest, PutResourcePolicyResult, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDenied | InvalidArgument | InvalidTagging | NoSuchResource | CommonErrors;
/**
 * Add tags to a CloudFront resource. For more information, see Tagging a distribution in the *Amazon CloudFront Developer Guide*.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestConnectionFunctionError = EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | TestFunctionFailed | UnsupportedOperation | CommonErrors;
/**
 * Tests a connection function.
 */
export declare const testConnectionFunction: API.OperationMethod<TestConnectionFunctionRequest, TestConnectionFunctionResult, TestConnectionFunctionError, Credentials | HttpClient.HttpClient>;
export type TestFunctionError = InvalidArgument | InvalidIfMatchVersion | NoSuchFunctionExists | TestFunctionFailed | UnsupportedOperation | CommonErrors;
/**
 * Tests a CloudFront function.
 *
 * To test a function, you provide an *event object* that represents an HTTP request or response that your CloudFront distribution could receive in production. CloudFront runs the function, passing it the event object that you provided, and returns the function's result (the modified event object) in the response. The response also contains function logs and error messages, if any exist. For more information about testing functions, see Testing functions in the *Amazon CloudFront Developer Guide*.
 *
 * To test a function, you provide the function's name and version (`ETag` value) along with the event object. To get the function's name and version, you can use `ListFunctions` and `DescribeFunction`.
 */
export declare const testFunction: API.OperationMethod<TestFunctionRequest, TestFunctionResult, TestFunctionError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDenied | InvalidArgument | InvalidTagging | NoSuchResource | CommonErrors;
/**
 * Remove tags from a CloudFront resource. For more information, see Tagging a distribution in the *Amazon CloudFront Developer Guide*.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAnycastIpListError = AccessDenied | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Updates an Anycast static IP list.
 */
export declare const updateAnycastIpList: API.OperationMethod<UpdateAnycastIpListRequest, UpdateAnycastIpListResult, UpdateAnycastIpListError, Credentials | HttpClient.HttpClient>;
export type UpdateCachePolicyError = AccessDenied | CachePolicyAlreadyExists | IllegalUpdate | InconsistentQuantities | InvalidArgument | InvalidIfMatchVersion | NoSuchCachePolicy | PreconditionFailed | TooManyCookiesInCachePolicy | TooManyHeadersInCachePolicy | TooManyQueryStringsInCachePolicy | CommonErrors;
/**
 * Updates a cache policy configuration.
 *
 * When you update a cache policy configuration, all the fields are updated with the values provided in the request. You cannot update some fields independent of others. To update a cache policy configuration:
 *
 * - Use `GetCachePolicyConfig` to get the current configuration.
 *
 * - Locally modify the fields in the cache policy configuration that you want to update.
 *
 * - Call `UpdateCachePolicy` by providing the entire cache policy configuration, including the fields that you modified and those that you didn't.
 *
 * If your minimum TTL is greater than 0, CloudFront will cache content for at least the duration specified in the cache policy's minimum TTL, even if the `Cache-Control: no-cache`, `no-store`, or `private` directives are present in the origin headers.
 */
export declare const updateCachePolicy: API.OperationMethod<UpdateCachePolicyRequest, UpdateCachePolicyResult, UpdateCachePolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateCloudFrontOriginAccessIdentityError = AccessDenied | IllegalUpdate | InconsistentQuantities | InvalidArgument | InvalidIfMatchVersion | MissingBody | NoSuchCloudFrontOriginAccessIdentity | PreconditionFailed | CommonErrors;
/**
 * Update an origin access identity.
 */
export declare const updateCloudFrontOriginAccessIdentity: API.OperationMethod<UpdateCloudFrontOriginAccessIdentityRequest, UpdateCloudFrontOriginAccessIdentityResult, UpdateCloudFrontOriginAccessIdentityError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectionFunctionError = AccessDenied | EntityNotFound | EntitySizeLimitExceeded | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Updates a connection function.
 */
export declare const updateConnectionFunction: API.OperationMethod<UpdateConnectionFunctionRequest, UpdateConnectionFunctionResult, UpdateConnectionFunctionError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectionGroupError = AccessDenied | EntityAlreadyExists | EntityLimitExceeded | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | ResourceInUse | CommonErrors;
/**
 * Updates a connection group.
 */
export declare const updateConnectionGroup: API.OperationMethod<UpdateConnectionGroupRequest, UpdateConnectionGroupResult, UpdateConnectionGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateContinuousDeploymentPolicyError = AccessDenied | InconsistentQuantities | InvalidArgument | InvalidIfMatchVersion | NoSuchContinuousDeploymentPolicy | PreconditionFailed | StagingDistributionInUse | CommonErrors;
/**
 * Updates a continuous deployment policy. You can update a continuous deployment policy to enable or disable it, to change the percentage of traffic that it sends to the staging distribution, or to change the staging distribution that it sends traffic to.
 *
 * When you update a continuous deployment policy configuration, all the fields are updated with the values that are provided in the request. You cannot update some fields independent of others. To update a continuous deployment policy configuration:
 *
 * - Use `GetContinuousDeploymentPolicyConfig` to get the current configuration.
 *
 * - Locally modify the fields in the continuous deployment policy configuration that you want to update.
 *
 * - Use `UpdateContinuousDeploymentPolicy`, providing the entire continuous deployment policy configuration, including the fields that you modified and those that you didn't.
 */
export declare const updateContinuousDeploymentPolicy: API.OperationMethod<UpdateContinuousDeploymentPolicyRequest, UpdateContinuousDeploymentPolicyResult, UpdateContinuousDeploymentPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateDistributionError = AccessDenied | CNAMEAlreadyExists | ContinuousDeploymentPolicyInUse | EntityNotFound | IllegalFieldLevelEncryptionConfigAssociationWithCacheBehavior | IllegalOriginAccessConfiguration | IllegalUpdate | InconsistentQuantities | InvalidArgument | InvalidDefaultRootObject | InvalidDomainNameForOriginAccessControl | InvalidErrorCode | InvalidForwardCookies | InvalidFunctionAssociation | InvalidGeoRestrictionParameter | InvalidHeadersForS3Origin | InvalidIfMatchVersion | InvalidLambdaFunctionAssociation | InvalidLocationCode | InvalidMinimumProtocolVersion | InvalidOriginAccessControl | InvalidOriginAccessIdentity | InvalidOriginKeepaliveTimeout | InvalidOriginReadTimeout | InvalidQueryStringParameters | InvalidRelativePath | InvalidRequiredProtocol | InvalidResponseCode | InvalidTTLOrder | InvalidViewerCertificate | InvalidWebACLId | MissingBody | NoSuchCachePolicy | NoSuchContinuousDeploymentPolicy | NoSuchDistribution | NoSuchFieldLevelEncryptionConfig | NoSuchOrigin | NoSuchOriginRequestPolicy | NoSuchRealtimeLogConfig | NoSuchResponseHeadersPolicy | PreconditionFailed | RealtimeLogConfigOwnerMismatch | StagingDistributionInUse | TooManyCacheBehaviors | TooManyCertificates | TooManyCookieNamesInWhiteList | TooManyDistributionCNAMEs | TooManyDistributionsAssociatedToCachePolicy | TooManyDistributionsAssociatedToFieldLevelEncryptionConfig | TooManyDistributionsAssociatedToKeyGroup | TooManyDistributionsAssociatedToOriginAccessControl | TooManyDistributionsAssociatedToOriginRequestPolicy | TooManyDistributionsAssociatedToResponseHeadersPolicy | TooManyDistributionsWithFunctionAssociations | TooManyDistributionsWithLambdaAssociations | TooManyDistributionsWithSingleFunctionARN | TooManyFunctionAssociations | TooManyHeadersInForwardedValues | TooManyKeyGroupsAssociatedToDistribution | TooManyLambdaFunctionAssociations | TooManyOriginCustomHeaders | TooManyOriginGroupsPerDistribution | TooManyOrigins | TooManyQueryStringParameters | TooManyTrustedSigners | TrustedKeyGroupDoesNotExist | TrustedSignerDoesNotExist | CommonErrors;
/**
 * Updates the configuration for a CloudFront distribution.
 *
 * The update process includes getting the current distribution configuration, updating it to make your changes, and then submitting an `UpdateDistribution` request to make the updates.
 *
 * **To update a web distribution using the CloudFront API**
 *
 * - Use `GetDistributionConfig` to get the current configuration, including the version identifier (`ETag`).
 *
 * - Update the distribution configuration that was returned in the response. Note the following important requirements and restrictions:
 *
 * - You must copy the `ETag` field value from the response. (You'll use it for the `IfMatch` parameter in your request.) Then, remove the `ETag` field from the distribution configuration.
 *
 * - You can't change the value of `CallerReference`.
 *
 * - Submit an `UpdateDistribution` request, providing the updated distribution configuration. The new configuration replaces the existing configuration. The values that you specify in an `UpdateDistribution` request are not merged into your existing configuration. Make sure to include all fields: the ones that you modified and also the ones that you didn't.
 */
export declare const updateDistribution: API.OperationMethod<UpdateDistributionRequest, UpdateDistributionResult, UpdateDistributionError, Credentials | HttpClient.HttpClient>;
export type UpdateDistributionTenantError = AccessDenied | CNAMEAlreadyExists | EntityAlreadyExists | EntityLimitExceeded | EntityNotFound | InvalidArgument | InvalidAssociation | InvalidIfMatchVersion | PreconditionFailed | CommonErrors;
/**
 * Updates a distribution tenant.
 */
export declare const updateDistributionTenant: API.OperationMethod<UpdateDistributionTenantRequest, UpdateDistributionTenantResult, UpdateDistributionTenantError, Credentials | HttpClient.HttpClient>;
export type UpdateDistributionWithStagingConfigError = AccessDenied | CNAMEAlreadyExists | EntityLimitExceeded | EntityNotFound | IllegalFieldLevelEncryptionConfigAssociationWithCacheBehavior | IllegalUpdate | InconsistentQuantities | InvalidArgument | InvalidDefaultRootObject | InvalidErrorCode | InvalidForwardCookies | InvalidFunctionAssociation | InvalidGeoRestrictionParameter | InvalidHeadersForS3Origin | InvalidIfMatchVersion | InvalidLambdaFunctionAssociation | InvalidLocationCode | InvalidMinimumProtocolVersion | InvalidOriginAccessControl | InvalidOriginAccessIdentity | InvalidOriginKeepaliveTimeout | InvalidOriginReadTimeout | InvalidQueryStringParameters | InvalidRelativePath | InvalidRequiredProtocol | InvalidResponseCode | InvalidTTLOrder | InvalidViewerCertificate | InvalidWebACLId | MissingBody | NoSuchCachePolicy | NoSuchDistribution | NoSuchFieldLevelEncryptionConfig | NoSuchOrigin | NoSuchOriginRequestPolicy | NoSuchRealtimeLogConfig | NoSuchResponseHeadersPolicy | PreconditionFailed | RealtimeLogConfigOwnerMismatch | TooManyCacheBehaviors | TooManyCertificates | TooManyCookieNamesInWhiteList | TooManyDistributionCNAMEs | TooManyDistributionsAssociatedToCachePolicy | TooManyDistributionsAssociatedToFieldLevelEncryptionConfig | TooManyDistributionsAssociatedToKeyGroup | TooManyDistributionsAssociatedToOriginAccessControl | TooManyDistributionsAssociatedToOriginRequestPolicy | TooManyDistributionsAssociatedToResponseHeadersPolicy | TooManyDistributionsWithFunctionAssociations | TooManyDistributionsWithLambdaAssociations | TooManyDistributionsWithSingleFunctionARN | TooManyFunctionAssociations | TooManyHeadersInForwardedValues | TooManyKeyGroupsAssociatedToDistribution | TooManyLambdaFunctionAssociations | TooManyOriginCustomHeaders | TooManyOriginGroupsPerDistribution | TooManyOrigins | TooManyQueryStringParameters | TooManyTrustedSigners | TrustedKeyGroupDoesNotExist | TrustedSignerDoesNotExist | CommonErrors;
/**
 * Copies the staging distribution's configuration to its corresponding primary distribution. The primary distribution retains its `Aliases` (also known as alternate domain names or CNAMEs) and `ContinuousDeploymentPolicyId` value, but otherwise its configuration is overwritten to match the staging distribution.
 *
 * You can use this operation in a continuous deployment workflow after you have tested configuration changes on the staging distribution. After using a continuous deployment policy to move a portion of your domain name's traffic to the staging distribution and verifying that it works as intended, you can use this operation to copy the staging distribution's configuration to the primary distribution. This action will disable the continuous deployment policy and move your domain's traffic back to the primary distribution.
 *
 * This API operation requires the following IAM permissions:
 *
 * - GetDistribution
 *
 * - UpdateDistribution
 */
export declare const updateDistributionWithStagingConfig: API.OperationMethod<UpdateDistributionWithStagingConfigRequest, UpdateDistributionWithStagingConfigResult, UpdateDistributionWithStagingConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainAssociationError = AccessDenied | EntityNotFound | IllegalUpdate | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | CommonErrors;
/**
 * We recommend that you use the `UpdateDomainAssociation` API operation to move a domain association, as it supports both standard distributions and distribution tenants. AssociateAlias performs similar checks but only supports standard distributions.
 *
 * Moves a domain from its current standard distribution or distribution tenant to another one.
 *
 * You must first disable the source distribution (standard distribution or distribution tenant) and then separately call this operation to move the domain to another target distribution (standard distribution or distribution tenant).
 *
 * To use this operation, specify the domain and the ID of the target resource (standard distribution or distribution tenant). For more information, including how to set up the target resource, prerequisites that you must complete, and other restrictions, see Moving an alternate domain name to a different standard distribution or distribution tenant in the *Amazon CloudFront Developer Guide*.
 */
export declare const updateDomainAssociation: API.OperationMethod<UpdateDomainAssociationRequest, UpdateDomainAssociationResult, UpdateDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateFieldLevelEncryptionConfigError = AccessDenied | IllegalUpdate | InconsistentQuantities | InvalidArgument | InvalidIfMatchVersion | NoSuchFieldLevelEncryptionConfig | NoSuchFieldLevelEncryptionProfile | PreconditionFailed | QueryArgProfileEmpty | TooManyFieldLevelEncryptionContentTypeProfiles | TooManyFieldLevelEncryptionQueryArgProfiles | CommonErrors;
/**
 * Update a field-level encryption configuration.
 */
export declare const updateFieldLevelEncryptionConfig: API.OperationMethod<UpdateFieldLevelEncryptionConfigRequest, UpdateFieldLevelEncryptionConfigResult, UpdateFieldLevelEncryptionConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateFieldLevelEncryptionProfileError = AccessDenied | FieldLevelEncryptionProfileAlreadyExists | FieldLevelEncryptionProfileSizeExceeded | IllegalUpdate | InconsistentQuantities | InvalidArgument | InvalidIfMatchVersion | NoSuchFieldLevelEncryptionProfile | NoSuchPublicKey | PreconditionFailed | TooManyFieldLevelEncryptionEncryptionEntities | TooManyFieldLevelEncryptionFieldPatterns | CommonErrors;
/**
 * Update a field-level encryption profile.
 */
export declare const updateFieldLevelEncryptionProfile: API.OperationMethod<UpdateFieldLevelEncryptionProfileRequest, UpdateFieldLevelEncryptionProfileResult, UpdateFieldLevelEncryptionProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateFunctionError = FunctionSizeLimitExceeded | InvalidArgument | InvalidIfMatchVersion | NoSuchFunctionExists | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Updates a CloudFront function.
 *
 * You can update a function's code or the comment that describes the function. You cannot update a function's name.
 *
 * To update a function, you provide the function's name and version (`ETag` value) along with the updated function code. To get the name and version, you can use `ListFunctions` and `DescribeFunction`.
 */
export declare const updateFunction: API.OperationMethod<UpdateFunctionRequest, UpdateFunctionResult, UpdateFunctionError, Credentials | HttpClient.HttpClient>;
export type UpdateKeyGroupError = InvalidArgument | InvalidIfMatchVersion | KeyGroupAlreadyExists | NoSuchResource | PreconditionFailed | TooManyPublicKeysInKeyGroup | CommonErrors;
/**
 * Updates a key group.
 *
 * When you update a key group, all the fields are updated with the values provided in the request. You cannot update some fields independent of others. To update a key group:
 *
 * - Get the current key group with `GetKeyGroup` or `GetKeyGroupConfig`.
 *
 * - Locally modify the fields in the key group that you want to update. For example, add or remove public key IDs.
 *
 * - Call `UpdateKeyGroup` with the entire key group object, including the fields that you modified and those that you didn't.
 */
export declare const updateKeyGroup: API.OperationMethod<UpdateKeyGroupRequest, UpdateKeyGroupResult, UpdateKeyGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateKeyValueStoreError = AccessDenied | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Specifies the key value store to update.
 */
export declare const updateKeyValueStore: API.OperationMethod<UpdateKeyValueStoreRequest, UpdateKeyValueStoreResult, UpdateKeyValueStoreError, Credentials | HttpClient.HttpClient>;
export type UpdateOriginAccessControlError = AccessDenied | IllegalUpdate | InvalidArgument | InvalidIfMatchVersion | NoSuchOriginAccessControl | OriginAccessControlAlreadyExists | PreconditionFailed | CommonErrors;
/**
 * Updates a CloudFront origin access control.
 */
export declare const updateOriginAccessControl: API.OperationMethod<UpdateOriginAccessControlRequest, UpdateOriginAccessControlResult, UpdateOriginAccessControlError, Credentials | HttpClient.HttpClient>;
export type UpdateOriginRequestPolicyError = AccessDenied | IllegalUpdate | InconsistentQuantities | InvalidArgument | InvalidIfMatchVersion | NoSuchOriginRequestPolicy | OriginRequestPolicyAlreadyExists | PreconditionFailed | TooManyCookiesInOriginRequestPolicy | TooManyHeadersInOriginRequestPolicy | TooManyQueryStringsInOriginRequestPolicy | CommonErrors;
/**
 * Updates an origin request policy configuration.
 *
 * When you update an origin request policy configuration, all the fields are updated with the values provided in the request. You cannot update some fields independent of others. To update an origin request policy configuration:
 *
 * - Use `GetOriginRequestPolicyConfig` to get the current configuration.
 *
 * - Locally modify the fields in the origin request policy configuration that you want to update.
 *
 * - Call `UpdateOriginRequestPolicy` by providing the entire origin request policy configuration, including the fields that you modified and those that you didn't.
 */
export declare const updateOriginRequestPolicy: API.OperationMethod<UpdateOriginRequestPolicyRequest, UpdateOriginRequestPolicyResult, UpdateOriginRequestPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdatePublicKeyError = AccessDenied | CannotChangeImmutablePublicKeyFields | IllegalUpdate | InvalidArgument | InvalidIfMatchVersion | NoSuchPublicKey | PreconditionFailed | CommonErrors;
/**
 * Update public key information. Note that the only value you can change is the comment.
 */
export declare const updatePublicKey: API.OperationMethod<UpdatePublicKeyRequest, UpdatePublicKeyResult, UpdatePublicKeyError, Credentials | HttpClient.HttpClient>;
export type UpdateRealtimeLogConfigError = AccessDenied | InvalidArgument | NoSuchRealtimeLogConfig | CommonErrors;
/**
 * Updates a real-time log configuration.
 *
 * When you update a real-time log configuration, all the parameters are updated with the values provided in the request. You cannot update some parameters independent of others. To update a real-time log configuration:
 *
 * - Call `GetRealtimeLogConfig` to get the current real-time log configuration.
 *
 * - Locally modify the parameters in the real-time log configuration that you want to update.
 *
 * - Call this API (`UpdateRealtimeLogConfig`) by providing the entire real-time log configuration, including the parameters that you modified and those that you didn't.
 *
 * You cannot update a real-time log configuration's `Name` or `ARN`.
 */
export declare const updateRealtimeLogConfig: API.OperationMethod<UpdateRealtimeLogConfigRequest, UpdateRealtimeLogConfigResult, UpdateRealtimeLogConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateResponseHeadersPolicyError = AccessDenied | IllegalUpdate | InconsistentQuantities | InvalidArgument | InvalidIfMatchVersion | NoSuchResponseHeadersPolicy | PreconditionFailed | ResponseHeadersPolicyAlreadyExists | TooLongCSPInResponseHeadersPolicy | TooManyCustomHeadersInResponseHeadersPolicy | TooManyRemoveHeadersInResponseHeadersPolicy | CommonErrors;
/**
 * Updates a response headers policy.
 *
 * When you update a response headers policy, the entire policy is replaced. You cannot update some policy fields independent of others. To update a response headers policy configuration:
 *
 * - Use `GetResponseHeadersPolicyConfig` to get the current policy's configuration.
 *
 * - Modify the fields in the response headers policy configuration that you want to update.
 *
 * - Call `UpdateResponseHeadersPolicy`, providing the entire response headers policy configuration, including the fields that you modified and those that you didn't.
 */
export declare const updateResponseHeadersPolicy: API.OperationMethod<UpdateResponseHeadersPolicyRequest, UpdateResponseHeadersPolicyResult, UpdateResponseHeadersPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateStreamingDistributionError = AccessDenied | CNAMEAlreadyExists | IllegalUpdate | InconsistentQuantities | InvalidArgument | InvalidIfMatchVersion | InvalidOriginAccessControl | InvalidOriginAccessIdentity | MissingBody | NoSuchStreamingDistribution | PreconditionFailed | TooManyStreamingDistributionCNAMEs | TooManyTrustedSigners | TrustedSignerDoesNotExist | CommonErrors;
/**
 * Update a streaming distribution.
 */
export declare const updateStreamingDistribution: API.OperationMethod<UpdateStreamingDistributionRequest, UpdateStreamingDistributionResult, UpdateStreamingDistributionError, Credentials | HttpClient.HttpClient>;
export type UpdateTrustStoreError = AccessDenied | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | CommonErrors;
/**
 * Updates a trust store.
 */
export declare const updateTrustStore: API.OperationMethod<UpdateTrustStoreRequest, UpdateTrustStoreResult, UpdateTrustStoreError, Credentials | HttpClient.HttpClient>;
export type UpdateVpcOriginError = AccessDenied | CannotUpdateEntityWhileInUse | EntityAlreadyExists | EntityLimitExceeded | EntityNotFound | IllegalUpdate | InconsistentQuantities | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Update an Amazon CloudFront VPC origin in your account.
 */
export declare const updateVpcOrigin: API.OperationMethod<UpdateVpcOriginRequest, UpdateVpcOriginResult, UpdateVpcOriginError, Credentials | HttpClient.HttpClient>;
export type VerifyDnsConfigurationError = AccessDenied | EntityNotFound | InvalidArgument | CommonErrors;
/**
 * Verify the DNS configuration for your domain names. This API operation checks whether your domain name points to the correct routing endpoint of the connection group, such as d111111abcdef8.cloudfront.net. You can use this API operation to troubleshoot and resolve DNS configuration issues.
 */
export declare const verifyDnsConfiguration: API.OperationMethod<VerifyDnsConfigurationRequest, VerifyDnsConfigurationResult, VerifyDnsConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cloudfront.d.ts.map