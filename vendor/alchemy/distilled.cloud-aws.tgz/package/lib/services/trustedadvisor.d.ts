import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type RecommendationResourceArn = string;
export interface RecommendationResourceExclusion {
    arn: string;
    isExcluded: boolean;
}
export type RecommendationResourceExclusionList = RecommendationResourceExclusion[];
export interface BatchUpdateRecommendationResourceExclusionRequest {
    recommendationResourceExclusions: RecommendationResourceExclusion[];
}
export interface UpdateRecommendationResourceExclusionError {
    arn?: string;
    errorCode?: string;
    errorMessage?: string;
}
export type UpdateRecommendationResourceExclusionErrorList = UpdateRecommendationResourceExclusionError[];
export interface BatchUpdateRecommendationResourceExclusionResponse {
    batchUpdateRecommendationResourceExclusionErrors: UpdateRecommendationResourceExclusionError[];
}
export type OrganizationRecommendationIdentifier = string;
export interface GetOrganizationRecommendationRequest {
    organizationRecommendationIdentifier: string;
}
export type RecommendationType = "standard" | "priority" | (string & {});
export type RecommendationStatus = "ok" | "warning" | "error" | (string & {});
export type RecommendationLifecycleStage = "in_progress" | "pending_response" | "dismissed" | "resolved" | (string & {});
export type RecommendationPillar = "cost_optimizing" | "performance" | "security" | "service_limits" | "fault_tolerance" | "operational_excellence" | (string & {});
export type RecommendationPillarList = RecommendationPillar[];
export type RecommendationSource = "aws_config" | "compute_optimizer" | "cost_explorer" | "lse" | "manual" | "pse" | "rds" | "resilience" | "resilience_hub" | "security_hub" | "stir" | "ta_check" | "well_architected" | "cost_optimization_hub" | (string & {});
export type RecommendationAwsService = string;
export type RecommendationAwsServiceList = string[];
export interface RecommendationResourcesAggregates {
    okCount: number;
    warningCount: number;
    errorCount: number;
    excludedCount?: number;
}
export interface RecommendationCostOptimizingAggregates {
    estimatedMonthlySavings: number;
    estimatedPercentMonthlySavings: number;
}
export interface RecommendationPillarSpecificAggregates {
    costOptimizing?: RecommendationCostOptimizingAggregates;
}
export type OrganizationRecommendationArn = string;
export type RecommendationUpdateReason = string | redacted.Redacted<string>;
export type UpdateRecommendationLifecycleStageReasonCode = "non_critical_account" | "temporary_account" | "valid_business_case" | "other_methods_available" | "low_priority" | "not_applicable" | "other" | (string & {});
export interface OrganizationRecommendation {
    id: string;
    type: RecommendationType;
    checkArn?: string;
    status: RecommendationStatus;
    lifecycleStage?: RecommendationLifecycleStage;
    pillars: RecommendationPillar[];
    source: RecommendationSource;
    awsServices?: string[];
    name: string;
    resourcesAggregates: RecommendationResourcesAggregates;
    pillarSpecificAggregates?: RecommendationPillarSpecificAggregates;
    createdAt?: Date;
    lastUpdatedAt?: Date;
    arn: string;
    description: string;
    createdBy?: string;
    updatedOnBehalfOf?: string;
    updatedOnBehalfOfJobTitle?: string;
    updateReason?: string | redacted.Redacted<string>;
    updateReasonCode?: UpdateRecommendationLifecycleStageReasonCode;
    resolvedAt?: Date;
}
export interface GetOrganizationRecommendationResponse {
    organizationRecommendation?: OrganizationRecommendation;
}
export type AccountRecommendationIdentifier = string;
export type RecommendationLanguage = "en" | "ja" | "zh" | "fr" | "de" | "ko" | "zh_TW" | "it" | "es" | "pt_BR" | "id" | (string & {});
export interface GetRecommendationRequest {
    recommendationIdentifier: string;
    language?: RecommendationLanguage;
}
export type AccountRecommendationArn = string;
export type StatusReason = "no_data_ok" | (string & {});
export interface Recommendation {
    id: string;
    type: RecommendationType;
    checkArn?: string;
    status: RecommendationStatus;
    lifecycleStage?: RecommendationLifecycleStage;
    pillars: RecommendationPillar[];
    source: RecommendationSource;
    awsServices?: string[];
    name: string;
    resourcesAggregates: RecommendationResourcesAggregates;
    pillarSpecificAggregates?: RecommendationPillarSpecificAggregates;
    createdAt?: Date;
    lastUpdatedAt?: Date;
    arn: string;
    statusReason?: StatusReason;
    description: string;
    createdBy?: string;
    updatedOnBehalfOf?: string;
    updatedOnBehalfOfJobTitle?: string;
    updateReason?: string | redacted.Redacted<string>;
    updateReasonCode?: UpdateRecommendationLifecycleStageReasonCode;
    resolvedAt?: Date;
}
export interface GetRecommendationResponse {
    recommendation?: Recommendation;
}
export interface ListChecksRequest {
    nextToken?: string;
    maxResults?: number;
    pillar?: RecommendationPillar;
    awsService?: string;
    source?: RecommendationSource;
    language?: RecommendationLanguage;
}
export type CheckArn = string;
export type StringMap = {
    [key: string]: string | undefined;
};
export type StringList = string[];
export interface CheckSummary {
    id: string;
    arn: string;
    name: string;
    description: string;
    pillars: RecommendationPillar[];
    awsServices: string[];
    source: RecommendationSource;
    metadata: {
        [key: string]: string | undefined;
    };
    resourceArnQueryable?: boolean;
    awsResourceTypes?: string[];
    checkGranularity?: string;
    recommendationId?: string;
}
export type CheckSummaryList = CheckSummary[];
export interface ListChecksResponse {
    nextToken?: string;
    checkSummaries: CheckSummary[];
}
export type AccountId = string;
export interface ListOrganizationRecommendationAccountsRequest {
    nextToken?: string;
    maxResults?: number;
    organizationRecommendationIdentifier: string;
    affectedAccountId?: string;
}
export interface AccountRecommendationLifecycleSummary {
    accountId?: string;
    accountRecommendationArn?: string;
    lifecycleStage?: RecommendationLifecycleStage;
    updatedOnBehalfOf?: string;
    updatedOnBehalfOfJobTitle?: string;
    updateReason?: string | redacted.Redacted<string>;
    updateReasonCode?: UpdateRecommendationLifecycleStageReasonCode;
    lastUpdatedAt?: Date;
}
export type AccountRecommendationLifecycleSummaryList = AccountRecommendationLifecycleSummary[];
export interface ListOrganizationRecommendationAccountsResponse {
    nextToken?: string;
    accountRecommendationLifecycleSummaries: AccountRecommendationLifecycleSummary[];
}
export type ResourceStatus = "ok" | "warning" | "error" | (string & {});
export type ExclusionStatus = "excluded" | "included" | (string & {});
export interface ListOrganizationRecommendationResourcesRequest {
    nextToken?: string;
    maxResults?: number;
    status?: ResourceStatus;
    exclusionStatus?: ExclusionStatus;
    regionCode?: string;
    organizationRecommendationIdentifier: string;
    affectedAccountId?: string;
}
export type RecommendationRegionCode = string;
export interface OrganizationRecommendationResourceSummary {
    id: string;
    arn: string;
    awsResourceId: string;
    regionCode: string;
    status: ResourceStatus;
    metadata: {
        [key: string]: string | undefined;
    };
    lastUpdatedAt: Date;
    exclusionStatus?: ExclusionStatus;
    accountId?: string;
    recommendationArn: string;
}
export type OrganizationRecommendationResourceSummaryList = OrganizationRecommendationResourceSummary[];
export interface ListOrganizationRecommendationResourcesResponse {
    nextToken?: string;
    organizationRecommendationResourceSummaries: OrganizationRecommendationResourceSummary[];
}
export type CheckIdentifier = string;
export interface ListOrganizationRecommendationsRequest {
    nextToken?: string;
    maxResults?: number;
    type?: RecommendationType;
    status?: RecommendationStatus;
    pillar?: RecommendationPillar;
    awsService?: string;
    source?: RecommendationSource;
    checkIdentifier?: string;
    afterLastUpdatedAt?: Date;
    beforeLastUpdatedAt?: Date;
}
export interface OrganizationRecommendationSummary {
    id: string;
    type: RecommendationType;
    checkArn?: string;
    status: RecommendationStatus;
    lifecycleStage?: RecommendationLifecycleStage;
    pillars: RecommendationPillar[];
    source: RecommendationSource;
    awsServices?: string[];
    name: string;
    resourcesAggregates: RecommendationResourcesAggregates;
    pillarSpecificAggregates?: RecommendationPillarSpecificAggregates;
    createdAt?: Date;
    lastUpdatedAt?: Date;
    arn: string;
}
export type OrganizationRecommendationSummaryList = OrganizationRecommendationSummary[];
export interface ListOrganizationRecommendationsResponse {
    nextToken?: string;
    organizationRecommendationSummaries: OrganizationRecommendationSummary[];
}
export interface ListRecommendationResourcesRequest {
    nextToken?: string;
    maxResults?: number;
    status?: ResourceStatus;
    exclusionStatus?: ExclusionStatus;
    regionCode?: string;
    recommendationIdentifier: string;
    language?: RecommendationLanguage;
}
export interface RecommendationResourceSummary {
    id: string;
    arn: string;
    awsResourceId: string;
    regionCode: string;
    status: ResourceStatus;
    metadata: {
        [key: string]: string | undefined;
    };
    lastUpdatedAt: Date;
    exclusionStatus?: ExclusionStatus;
    recommendationArn: string;
}
export type RecommendationResourceSummaryList = RecommendationResourceSummary[];
export interface ListRecommendationResourcesResponse {
    nextToken?: string;
    recommendationResourceSummaries: RecommendationResourceSummary[];
}
export interface ListRecommendationsRequest {
    nextToken?: string;
    maxResults?: number;
    type?: RecommendationType;
    status?: RecommendationStatus;
    pillar?: RecommendationPillar;
    awsService?: string;
    source?: RecommendationSource;
    checkIdentifier?: string;
    afterLastUpdatedAt?: Date;
    beforeLastUpdatedAt?: Date;
    language?: RecommendationLanguage;
}
export interface RecommendationSummary {
    id: string;
    type: RecommendationType;
    checkArn?: string;
    status: RecommendationStatus;
    lifecycleStage?: RecommendationLifecycleStage;
    pillars: RecommendationPillar[];
    source: RecommendationSource;
    awsServices?: string[];
    name: string;
    resourcesAggregates: RecommendationResourcesAggregates;
    pillarSpecificAggregates?: RecommendationPillarSpecificAggregates;
    createdAt?: Date;
    lastUpdatedAt?: Date;
    arn: string;
    statusReason?: StatusReason;
}
export type RecommendationSummaryList = RecommendationSummary[];
export interface ListRecommendationsResponse {
    nextToken?: string;
    recommendationSummaries: RecommendationSummary[];
}
export type AwsResourceArn = string;
export interface ListRecommendationsForResourceRequest {
    nextToken?: string;
    maxResults?: number;
    awsResourceArn: string;
    pillar?: RecommendationPillar;
    status?: ResourceStatus;
    checkArn?: string;
    language?: RecommendationLanguage;
}
export interface RecommendationForResourceSummary {
    checkArn: string;
    recommendationArn: string;
    awsResourceArn: string;
    status: ResourceStatus;
    lastUpdatedAt: Date;
    exclusionStatus: ExclusionStatus;
    metadata: {
        [key: string]: string | undefined;
    };
    pillars: RecommendationPillar[];
}
export type RecommendationForResourceSummaryList = RecommendationForResourceSummary[];
export interface ListRecommendationsForResourceResponse {
    nextToken?: string;
    recommendationForResourceSummaries: RecommendationForResourceSummary[];
}
export type UpdateRecommendationLifecycleStage = "pending_response" | "in_progress" | "dismissed" | "resolved" | (string & {});
export interface UpdateOrganizationRecommendationLifecycleRequest {
    lifecycleStage: UpdateRecommendationLifecycleStage;
    updateReason?: string | redacted.Redacted<string>;
    updateReasonCode?: UpdateRecommendationLifecycleStageReasonCode;
    organizationRecommendationIdentifier: string;
}
export interface UpdateOrganizationRecommendationLifecycleResponse {
}
export interface UpdateRecommendationLifecycleRequest {
    lifecycleStage: UpdateRecommendationLifecycleStage;
    updateReason?: string | redacted.Redacted<string>;
    updateReasonCode?: UpdateRecommendationLifecycleStageReasonCode;
    recommendationIdentifier: string;
}
export interface UpdateRecommendationLifecycleResponse {
}
export type BatchUpdateRecommendationResourceExclusionError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update one or more exclusion statuses for a list of recommendation resources. This API supports up to 25 unique recommendation resource ARNs per request. This API currently doesn't support prioritized recommendation resources. This API updates global recommendations, eliminating the need to call the API in each AWS Region. After submitting an exclusion update, note that it might take a few minutes for the changes to be reflected in the system.
 */
export declare const batchUpdateRecommendationResourceExclusion: API.OperationMethod<BatchUpdateRecommendationResourceExclusionRequest, BatchUpdateRecommendationResourceExclusionResponse, BatchUpdateRecommendationResourceExclusionError, Credentials | HttpClient.HttpClient>;
export type GetOrganizationRecommendationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a specific recommendation within an AWS Organizations organization. This API supports only prioritized recommendations and provides global priority recommendations, eliminating the need to call the API in each AWS Region.
 */
export declare const getOrganizationRecommendation: API.OperationMethod<GetOrganizationRecommendationRequest, GetOrganizationRecommendationResponse, GetOrganizationRecommendationError, Credentials | HttpClient.HttpClient>;
export type GetRecommendationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a specific Recommendation. This API provides global recommendations, eliminating the need to call the API in each AWS Region.
 */
export declare const getRecommendation: API.OperationMethod<GetRecommendationRequest, GetRecommendationResponse, GetRecommendationError, Credentials | HttpClient.HttpClient>;
export type ListChecksError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List a filterable set of Checks. This API provides global recommendations, eliminating the need to call the API in each AWS Region.
 */
export declare const listChecks: API.PaginatedOperationMethod<ListChecksRequest, ListChecksResponse, ListChecksError, Credentials | HttpClient.HttpClient, CheckSummary>;
export type ListOrganizationRecommendationAccountsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the accounts that own the resources for an organization aggregate recommendation. This API only supports prioritized recommendations and provides global priority recommendations, eliminating the need to call the API in each AWS Region.
 */
export declare const listOrganizationRecommendationAccounts: API.PaginatedOperationMethod<ListOrganizationRecommendationAccountsRequest, ListOrganizationRecommendationAccountsResponse, ListOrganizationRecommendationAccountsError, Credentials | HttpClient.HttpClient, AccountRecommendationLifecycleSummary>;
export type ListOrganizationRecommendationResourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List Resources of a Recommendation within an Organization. This API only supports prioritized recommendations and provides global priority recommendations, eliminating the need to call the API in each AWS Region.
 */
export declare const listOrganizationRecommendationResources: API.PaginatedOperationMethod<ListOrganizationRecommendationResourcesRequest, ListOrganizationRecommendationResourcesResponse, ListOrganizationRecommendationResourcesError, Credentials | HttpClient.HttpClient, OrganizationRecommendationResourceSummary>;
export type ListOrganizationRecommendationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List a filterable set of Recommendations within an Organization. This API only supports prioritized recommendations and provides global priority recommendations, eliminating the need to call the API in each AWS Region.
 */
export declare const listOrganizationRecommendations: API.PaginatedOperationMethod<ListOrganizationRecommendationsRequest, ListOrganizationRecommendationsResponse, ListOrganizationRecommendationsError, Credentials | HttpClient.HttpClient, OrganizationRecommendationSummary>;
export type ListRecommendationResourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List Resources of a Recommendation. This API provides global recommendations, eliminating the need to call the API in each AWS Region.
 */
export declare const listRecommendationResources: API.PaginatedOperationMethod<ListRecommendationResourcesRequest, ListRecommendationResourcesResponse, ListRecommendationResourcesError, Credentials | HttpClient.HttpClient, RecommendationResourceSummary>;
export type ListRecommendationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List a filterable set of Recommendations. This API provides global recommendations, eliminating the need to call the API in each AWS Region.
 */
export declare const listRecommendations: API.PaginatedOperationMethod<ListRecommendationsRequest, ListRecommendationsResponse, ListRecommendationsError, Credentials | HttpClient.HttpClient, RecommendationSummary>;
export type ListRecommendationsForResourceError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all Trusted Advisor recommendations for a given AWS resource ARN.
 */
export declare const listRecommendationsForResource: API.PaginatedOperationMethod<ListRecommendationsForResourceRequest, ListRecommendationsForResourceResponse, ListRecommendationsForResourceError, Credentials | HttpClient.HttpClient, RecommendationForResourceSummary>;
export type UpdateOrganizationRecommendationLifecycleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the lifecycle of a Recommendation within an Organization. This API only supports prioritized recommendations and updates global priority recommendations, eliminating the need to call the API in each AWS Region.
 */
export declare const updateOrganizationRecommendationLifecycle: API.OperationMethod<UpdateOrganizationRecommendationLifecycleRequest, UpdateOrganizationRecommendationLifecycleResponse, UpdateOrganizationRecommendationLifecycleError, Credentials | HttpClient.HttpClient>;
export type UpdateRecommendationLifecycleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the lifecyle of a Recommendation. This API only supports prioritized recommendations and updates global priority recommendations, eliminating the need to call the API in each AWS Region.
 */
export declare const updateRecommendationLifecycle: API.OperationMethod<UpdateRecommendationLifecycleRequest, UpdateRecommendationLifecycleResponse, UpdateRecommendationLifecycleError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=trustedadvisor.d.ts.map