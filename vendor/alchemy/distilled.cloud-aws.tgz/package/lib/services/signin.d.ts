import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly error: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly error: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly error: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly error: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly error: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const TooManyRequestsError_base: S.TaggedErrorClass<"TooManyRequestsError", {
    readonly error: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsError extends /*@__PURE__*/ TooManyRequestsError_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly error: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ClientId = string;
export type GrantType = string;
export type AuthorizationCode = string;
export type RedirectUri = string;
export type CodeVerifier = string;
export type RefreshToken = string | redacted.Redacted<string>;
export interface CreateOAuth2TokenRequestBody {
    clientId: string;
    grantType: string;
    code?: string;
    redirectUri?: string;
    codeVerifier?: string;
    refreshToken?: string | redacted.Redacted<string>;
}
export interface CreateOAuth2TokenRequest {
    tokenInput: CreateOAuth2TokenRequestBody;
}
export interface AccessToken {
    accessKeyId: string;
    secretAccessKey: string;
    sessionToken: string;
}
export type TokenType = string;
export type ExpiresIn = number;
export type IdToken = string;
export interface CreateOAuth2TokenResponseBody {
    accessToken: AccessToken;
    tokenType: string;
    expiresIn: number;
    refreshToken: string | redacted.Redacted<string>;
    idToken?: string;
}
export interface CreateOAuth2TokenResponse {
    tokenOutput: CreateOAuth2TokenResponseBody;
}
export type ClientCredentialsGrantType = string;
export interface CreateOAuth2TokenWithIAMRequest {
    grantType: string;
    resource: string;
}
export type OAuthAccessToken = string | redacted.Redacted<string>;
export type BearerTokenType = string;
export type TokenExpiresIn = number;
export interface CreateOAuth2TokenWithIAMResponse {
    accessToken: string | redacted.Redacted<string>;
    tokenType: string;
    expiresIn: number;
}
export type TargetId = string;
export interface DeleteConsoleAuthorizationConfigurationInput {
    targetId?: string;
}
export interface DeleteConsoleAuthorizationConfigurationOutput {
    targetId: string;
    scope: string;
    consoleAuthorizationEnabled: boolean;
}
export type StatementId = string;
export type ClientToken = string;
export interface DeleteResourcePermissionStatementInput {
    statementId: string;
    clientToken?: string;
}
export interface DeleteResourcePermissionStatementOutput {
}
export interface GetConsoleAuthorizationConfigurationInput {
    targetId?: string;
}
export interface GetConsoleAuthorizationConfigurationOutput {
    targetId: string;
    scope: string;
    consoleAuthorizationEnabled: boolean;
}
export interface GetResourcePolicyInput {
}
export type Principal = {
    [key: string]: string | undefined;
};
export type PolicyActions = string[];
export type ConditionType = string;
export type ConditionValues = string[];
export type Condition = {
    [key: string]: string[] | undefined;
};
export type ConditionBlock = {
    [key: string]: {
        [key: string]: string[] | undefined;
    } | undefined;
};
export interface PolicyStatement {
    effect?: string;
    principal?: {
        [key: string]: string | undefined;
    };
    action?: string[];
    resource?: string;
    condition?: {
        [key: string]: {
            [key: string]: string[] | undefined;
        } | undefined;
    };
}
export type PolicyStatements = PolicyStatement[];
export interface SigninResourceBasedPolicy {
    version?: string;
    statement?: PolicyStatement[];
}
export interface GetResourcePolicyOutput {
    signinResourceBasedPolicy: SigninResourceBasedPolicy;
}
export type IntrospectionToken = string | redacted.Redacted<string>;
export type TokenTypeHint = string;
export interface IntrospectOAuth2TokenWithIAMRequest {
    token: string | redacted.Redacted<string>;
    tokenTypeHint?: string;
}
export type IntrospectedTokenType = string;
export type AccountId = string;
export interface IntrospectOAuth2TokenWithIAMResponse {
    active: boolean;
    clientId?: string;
    userId?: string;
    tokenType?: string;
    exp?: number;
    iat?: number;
    nbf?: number;
    sub?: string;
    aud?: string;
    iss?: string;
    jti?: string;
    accountId?: string;
    signinSession?: string;
    resource?: string;
}
export type ConsolePermissionMaxResults = number;
export type NextToken = string;
export interface ListResourcePermissionStatementsInput {
    maxResults?: number;
    nextToken?: string;
}
export interface PermissionStatementSummary {
    sid: string;
    condition?: {
        [key: string]: {
            [key: string]: string[] | undefined;
        } | undefined;
    };
}
export type PermissionStatementSummaries = PermissionStatementSummary[];
export interface ListResourcePermissionStatementsOutput {
    permissionStatements: PermissionStatementSummary[];
    nextToken?: string;
}
export interface PutConsoleAuthorizationConfigurationInput {
    targetId?: string;
}
export interface PutConsoleAuthorizationConfigurationOutput {
    targetId: string;
    scope: string;
    consoleAuthorizationEnabled: boolean;
}
export type SourceVpc = string;
export type SourceVpce = string;
export type VpcSourceIp = string;
export type SourceIp = string;
export type RequestedRegion = string;
export type ExcludedPrincipal = string;
export interface PutResourcePermissionStatementInput {
    sourceVpc?: string;
    signinSourceVpce?: string;
    consoleSourceVpce?: string;
    vpcSourceIp?: string;
    sourceIp?: string;
    requestedRegion?: string;
    excludedPrincipal?: string;
    clientToken?: string;
}
export interface PutResourcePermissionStatementOutput {
    statementId: string;
}
export type RevocationToken = string | redacted.Redacted<string>;
export interface RevokeOAuth2TokenWithIAMRequest {
    token: string | redacted.Redacted<string>;
}
export interface RevokeOAuth2TokenWithIAMResponse {
}
export type OAuth2ErrorCode = "TOKEN_EXPIRED" | "USER_CREDENTIALS_CHANGED" | "INSUFFICIENT_PERMISSIONS" | "AUTHCODE_EXPIRED" | "server_error" | "INVALID_REQUEST" | "RESOURCE_NOT_FOUND" | "CONFLICT" | "SERVICE_QUOTA_EXCEEDED" | (string & {});
export type CreateOAuth2TokenError = AccessDeniedException | InternalServerException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * CreateOAuth2Token API
 *
 * Path: /v1/token
 * Request Method: POST
 * Content-Type: application/json or application/x-www-form-urlencoded
 *
 * This API implements OAuth 2.0 flows for AWS Sign-In CLI clients, supporting both:
 * 1. Authorization code redemption (grant_type=authorization_code) - NOT idempotent
 * 2. Token refresh (grant_type=refresh_token) - Idempotent within token validity window
 *
 * The operation behavior is determined by the grant_type parameter in the request body:
 *
 * **Authorization Code Flow (NOT Idempotent):**
 * - JSON or form-encoded body with client_id, grant_type=authorization_code, code, redirect_uri, code_verifier
 * - Returns access_token, token_type, expires_in, refresh_token, and id_token
 * - Each authorization code can only be used ONCE for security (prevents replay attacks)
 *
 * **Token Refresh Flow (Idempotent):**
 * - JSON or form-encoded body with client_id, grant_type=refresh_token, refresh_token
 * - Returns access_token, token_type, expires_in, and refresh_token (no id_token)
 * - Multiple calls with same refresh_token return consistent results within validity window
 *
 * Authentication and authorization:
 * - Confidential clients: sigv4 signing required with signin:ExchangeToken permissions
 * - CLI clients (public): authn/authz skipped based on client_id & grant_type
 *
 * Note: This operation cannot be marked as @idempotent because it handles both idempotent
 * (token refresh) and non-idempotent (auth code redemption) flows in a single endpoint.
 */
export declare const createOAuth2Token: API.OperationMethod<CreateOAuth2TokenRequest, CreateOAuth2TokenResponse, CreateOAuth2TokenError, Credentials | HttpClient.HttpClient>;
export type CreateOAuth2TokenWithIAMError = AccessDeniedException | InternalServerException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Grants permission to exchange client credentials for an OAuth 2.0 access token
 * scoped to a resource that can be used to access AWS services from applications
 */
export declare const createOAuth2TokenWithIAM: API.OperationMethod<CreateOAuth2TokenWithIAMRequest, CreateOAuth2TokenWithIAMResponse, CreateOAuth2TokenWithIAMError, Credentials | HttpClient.HttpClient>;
export type DeleteConsoleAuthorizationConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Delete console authorization configuration with automatic scope detection
 */
export declare const deleteConsoleAuthorizationConfiguration: API.OperationMethod<DeleteConsoleAuthorizationConfigurationInput, DeleteConsoleAuthorizationConfigurationOutput, DeleteConsoleAuthorizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePermissionStatementError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Remove a permission statement from the account's SignIn resource-based policy
 */
export declare const deleteResourcePermissionStatement: API.OperationMethod<DeleteResourcePermissionStatementInput, DeleteResourcePermissionStatementOutput, DeleteResourcePermissionStatementError, Credentials | HttpClient.HttpClient>;
export type GetConsoleAuthorizationConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Get console authorization configuration with automatic scope detection
 */
export declare const getConsoleAuthorizationConfiguration: API.OperationMethod<GetConsoleAuthorizationConfigurationInput, GetConsoleAuthorizationConfigurationOutput, GetConsoleAuthorizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsError | CommonErrors;
/**
 * Retrieve the account's consolidated SignIn resource-based policy
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyInput, GetResourcePolicyOutput, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type IntrospectOAuth2TokenWithIAMError = AccessDeniedException | InternalServerException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Grants permission to inspect the metadata and state of an OAuth 2.0
 * access token or refresh token
 *
 * Implements RFC 7662 OAuth 2.0 Token Introspection over a SigV4-authenticated
 * endpoint. Inspects the metadata of an access_token or refresh_token issued
 * by AWS Sign-In and returns the claims associated with it.
 *
 * Inactive token semantics (RFC 7662 §2.2): when the supplied token is
 * unknown, expired, revoked, malformed, or owned by a different account,
 * the response body is exactly { "active": false } with all other claims
 * omitted.
 */
export declare const introspectOAuth2TokenWithIAM: API.OperationMethod<IntrospectOAuth2TokenWithIAMRequest, IntrospectOAuth2TokenWithIAMResponse, IntrospectOAuth2TokenWithIAMError, Credentials | HttpClient.HttpClient>;
export type ListResourcePermissionStatementsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Retrieve all permission statements in the account's SignIn resource-based policy
 */
export declare const listResourcePermissionStatements: API.PaginatedOperationMethod<ListResourcePermissionStatementsInput, ListResourcePermissionStatementsOutput, ListResourcePermissionStatementsError, Credentials | HttpClient.HttpClient, PermissionStatementSummary>;
export type PutConsoleAuthorizationConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Enable console authorization configuration with automatic scope detection
 */
export declare const putConsoleAuthorizationConfiguration: API.OperationMethod<PutConsoleAuthorizationConfigurationInput, PutConsoleAuthorizationConfigurationOutput, PutConsoleAuthorizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutResourcePermissionStatementError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Create a permission statement in the account's SignIn resource-based policy
 */
export declare const putResourcePermissionStatement: API.OperationMethod<PutResourcePermissionStatementInput, PutResourcePermissionStatementOutput, PutResourcePermissionStatementError, Credentials | HttpClient.HttpClient>;
export type RevokeOAuth2TokenWithIAMError = AccessDeniedException | InternalServerException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Grants permission to revoke an OAuth 2.0 refresh token and its associated refresh tokens
 *
 * Revokes a refresh_token issued by AWS Sign-In, invalidating the entire token
 * chain so that the refresh_token can no longer be used to mint new access_tokens.
 *
 * Idempotency: revoking an already-revoked, expired, or otherwise invalid token
 * still returns 200 OK with an empty body. Only the refresh_token type is accepted.
 */
export declare const revokeOAuth2TokenWithIAM: API.OperationMethod<RevokeOAuth2TokenWithIAMRequest, RevokeOAuth2TokenWithIAMResponse, RevokeOAuth2TokenWithIAMError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=signin.d.ts.map