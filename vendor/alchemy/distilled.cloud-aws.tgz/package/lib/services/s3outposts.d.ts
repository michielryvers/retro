import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const OutpostOfflineException_base: S.TaggedErrorClass<"OutpostOfflineException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OutpostOfflineException extends /*@__PURE__*/ OutpostOfflineException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type OutpostId = string;
export type SubnetId = string;
export type SecurityGroupId = string;
export type EndpointAccessType = "Private" | "CustomerOwnedIp" | (string & {});
export type CustomerOwnedIpv4Pool = string;
export interface CreateEndpointRequest {
    OutpostId: string;
    SubnetId: string;
    SecurityGroupId: string;
    AccessType?: EndpointAccessType;
    CustomerOwnedIpv4Pool?: string;
}
export type EndpointArn = string;
export interface CreateEndpointResult {
    EndpointArn?: string;
}
export type EndpointId = string;
export interface DeleteEndpointRequest {
    EndpointId: string;
    OutpostId: string;
}
export interface DeleteEndpointResponse {
}
export type NextToken = string;
export type MaxResults = number;
export interface ListEndpointsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export type CidrBlock = string;
export type EndpointStatus = "Pending" | "Available" | "Deleting" | "Create_Failed" | "Delete_Failed" | (string & {});
export type CreationTime = Date;
export type NetworkInterfaceId = string;
export interface NetworkInterface {
    NetworkInterfaceId?: string;
}
export type NetworkInterfaces = NetworkInterface[];
export type VpcId = string;
export type ErrorCode = string;
export type Message = string;
export interface FailedReason {
    ErrorCode?: string;
    Message?: string;
}
export interface Endpoint {
    EndpointArn?: string;
    OutpostsId?: string;
    CidrBlock?: string;
    Status?: EndpointStatus;
    CreationTime?: Date;
    NetworkInterfaces?: NetworkInterface[];
    VpcId?: string;
    SubnetId?: string;
    SecurityGroupId?: string;
    AccessType?: EndpointAccessType;
    CustomerOwnedIpv4Pool?: string;
    FailedReason?: FailedReason;
}
export type Endpoints = Endpoint[];
export interface ListEndpointsResult {
    Endpoints?: Endpoint[];
    NextToken?: string;
}
export interface ListOutpostsWithS3Request {
    NextToken?: string;
    MaxResults?: number;
}
export type OutpostArn = string;
export type S3OutpostArn = string;
export type AwsAccountId = string;
export type CapacityInBytes = number;
export interface Outpost {
    OutpostArn?: string;
    S3OutpostArn?: string;
    OutpostId?: string;
    OwnerId?: string;
    CapacityInBytes?: number;
}
export type Outposts = Outpost[];
export interface ListOutpostsWithS3Result {
    Outposts?: Outpost[];
    NextToken?: string;
}
export interface ListSharedEndpointsRequest {
    NextToken?: string;
    MaxResults?: number;
    OutpostId: string;
}
export interface ListSharedEndpointsResult {
    Endpoints?: Endpoint[];
    NextToken?: string;
}
export type ErrorMessage = string;
export type CreateEndpointError = AccessDeniedException | ConflictException | InternalServerException | OutpostOfflineException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an endpoint and associates it with the specified Outpost.
 *
 * It can take up to 5 minutes for this action to finish.
 *
 * Related actions include:
 *
 * - DeleteEndpoint
 *
 * - ListEndpoints
 */
export declare const createEndpoint: API.OperationMethod<CreateEndpointRequest, CreateEndpointResult, CreateEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteEndpointError = AccessDeniedException | InternalServerException | OutpostOfflineException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an endpoint.
 *
 * It can take up to 5 minutes for this action to finish.
 *
 * Related actions include:
 *
 * - CreateEndpoint
 *
 * - ListEndpoints
 */
export declare const deleteEndpoint: API.OperationMethod<DeleteEndpointRequest, DeleteEndpointResponse, DeleteEndpointError, Credentials | HttpClient.HttpClient>;
export type ListEndpointsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists endpoints associated with the specified Outpost.
 *
 * Related actions include:
 *
 * - CreateEndpoint
 *
 * - DeleteEndpoint
 */
export declare const listEndpoints: API.PaginatedOperationMethod<ListEndpointsRequest, ListEndpointsResult, ListEndpointsError, Credentials | HttpClient.HttpClient, Endpoint>;
export type ListOutpostsWithS3Error = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the Outposts with S3 on Outposts capacity for your Amazon Web Services account.
 * Includes S3 on Outposts that you have access to as the Outposts owner, or as a shared user
 * from Resource Access Manager (RAM).
 */
export declare const listOutpostsWithS3: API.PaginatedOperationMethod<ListOutpostsWithS3Request, ListOutpostsWithS3Result, ListOutpostsWithS3Error, Credentials | HttpClient.HttpClient, Outpost>;
export type ListSharedEndpointsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all endpoints associated with an Outpost that has been shared by Amazon Web Services Resource Access Manager (RAM).
 *
 * Related actions include:
 *
 * - CreateEndpoint
 *
 * - DeleteEndpoint
 */
export declare const listSharedEndpoints: API.PaginatedOperationMethod<ListSharedEndpointsRequest, ListSharedEndpointsResult, ListSharedEndpointsError, Credentials | HttpClient.HttpClient, Endpoint>;
export {};
//# sourceMappingURL=s3outposts.d.ts.map