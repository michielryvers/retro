import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const CidrBlockInUseException_base: S.TaggedErrorClass<"CidrBlockInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CidrBlockInUseException extends /*@__PURE__*/ CidrBlockInUseException_base {
}
declare const CidrCollectionAlreadyExistsException_base: S.TaggedErrorClass<"CidrCollectionAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CidrCollectionAlreadyExistsException extends /*@__PURE__*/ CidrCollectionAlreadyExistsException_base {
}
declare const CidrCollectionInUseException_base: S.TaggedErrorClass<"CidrCollectionInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CidrCollectionInUseException extends /*@__PURE__*/ CidrCollectionInUseException_base {
}
declare const CidrCollectionVersionMismatchException_base: S.TaggedErrorClass<"CidrCollectionVersionMismatchException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class CidrCollectionVersionMismatchException extends /*@__PURE__*/ CidrCollectionVersionMismatchException_base {
}
declare const ConcurrentModification_base: S.TaggedErrorClass<"ConcurrentModification", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConcurrentModification extends /*@__PURE__*/ ConcurrentModification_base {
}
declare const ConflictingDomainExists_base: S.TaggedErrorClass<"ConflictingDomainExists", {
    readonly message: any;
}>;
export declare class ConflictingDomainExists extends /*@__PURE__*/ ConflictingDomainExists_base {
}
declare const ConflictingTypes_base: S.TaggedErrorClass<"ConflictingTypes", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConflictingTypes extends /*@__PURE__*/ ConflictingTypes_base {
}
declare const DelegationSetAlreadyCreated_base: S.TaggedErrorClass<"DelegationSetAlreadyCreated", {
    readonly message: any;
}>;
export declare class DelegationSetAlreadyCreated extends /*@__PURE__*/ DelegationSetAlreadyCreated_base {
}
declare const DelegationSetAlreadyReusable_base: S.TaggedErrorClass<"DelegationSetAlreadyReusable", {
    readonly message: any;
}>;
export declare class DelegationSetAlreadyReusable extends /*@__PURE__*/ DelegationSetAlreadyReusable_base {
}
declare const DelegationSetInUse_base: S.TaggedErrorClass<"DelegationSetInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class DelegationSetInUse extends /*@__PURE__*/ DelegationSetInUse_base {
}
declare const DelegationSetNotAvailable_base: S.TaggedErrorClass<"DelegationSetNotAvailable", {
    readonly message: any;
}>;
export declare class DelegationSetNotAvailable extends /*@__PURE__*/ DelegationSetNotAvailable_base {
}
declare const DelegationSetNotReusable_base: S.TaggedErrorClass<"DelegationSetNotReusable", {
    readonly message: any;
}>;
export declare class DelegationSetNotReusable extends /*@__PURE__*/ DelegationSetNotReusable_base {
}
declare const DNSSECNotFound_base: S.TaggedErrorClass<"DNSSECNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DNSSECNotFound extends /*@__PURE__*/ DNSSECNotFound_base {
}
declare const HealthCheckAlreadyExists_base: S.TaggedErrorClass<"HealthCheckAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class HealthCheckAlreadyExists extends /*@__PURE__*/ HealthCheckAlreadyExists_base {
}
declare const HealthCheckInUse_base: S.TaggedErrorClass<"HealthCheckInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class HealthCheckInUse extends /*@__PURE__*/ HealthCheckInUse_base {
}
declare const HealthCheckVersionMismatch_base: S.TaggedErrorClass<"HealthCheckVersionMismatch", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class HealthCheckVersionMismatch extends /*@__PURE__*/ HealthCheckVersionMismatch_base {
}
declare const HostedZoneAlreadyExists_base: S.TaggedErrorClass<"HostedZoneAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class HostedZoneAlreadyExists extends /*@__PURE__*/ HostedZoneAlreadyExists_base {
}
declare const HostedZoneNotEmpty_base: S.TaggedErrorClass<"HostedZoneNotEmpty", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class HostedZoneNotEmpty extends /*@__PURE__*/ HostedZoneNotEmpty_base {
}
declare const HostedZoneNotFound_base: S.TaggedErrorClass<"HostedZoneNotFound", {
    readonly message: any;
}>;
export declare class HostedZoneNotFound extends /*@__PURE__*/ HostedZoneNotFound_base {
}
declare const HostedZoneNotPrivate_base: S.TaggedErrorClass<"HostedZoneNotPrivate", {
    readonly message: any;
}>;
export declare class HostedZoneNotPrivate extends /*@__PURE__*/ HostedZoneNotPrivate_base {
}
declare const HostedZonePartiallyDelegated_base: S.TaggedErrorClass<"HostedZonePartiallyDelegated", {
    readonly message: any;
}>;
export declare class HostedZonePartiallyDelegated extends /*@__PURE__*/ HostedZonePartiallyDelegated_base {
}
declare const IncompatibleVersion_base: S.TaggedErrorClass<"IncompatibleVersion", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IncompatibleVersion extends /*@__PURE__*/ IncompatibleVersion_base {
}
declare const InsufficientCloudWatchLogsResourcePolicy_base: S.TaggedErrorClass<"InsufficientCloudWatchLogsResourcePolicy", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientCloudWatchLogsResourcePolicy extends /*@__PURE__*/ InsufficientCloudWatchLogsResourcePolicy_base {
}
declare const InvalidArgument_base: S.TaggedErrorClass<"InvalidArgument", {
    readonly message: any;
}>;
export declare class InvalidArgument extends /*@__PURE__*/ InvalidArgument_base {
}
declare const InvalidChangeBatch_base: S.TaggedErrorClass<"InvalidChangeBatch", {
    readonly messages: any;
    readonly message: any;
}>;
export declare class InvalidChangeBatch extends /*@__PURE__*/ InvalidChangeBatch_base {
}
declare const InvalidDomainName_base: S.TaggedErrorClass<"InvalidDomainName", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDomainName extends /*@__PURE__*/ InvalidDomainName_base {
}
declare const InvalidInput_base: S.TaggedErrorClass<"InvalidInput", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidInput extends /*@__PURE__*/ InvalidInput_base {
}
declare const InvalidKeySigningKeyName_base: S.TaggedErrorClass<"InvalidKeySigningKeyName", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidKeySigningKeyName extends /*@__PURE__*/ InvalidKeySigningKeyName_base {
}
declare const InvalidKeySigningKeyStatus_base: S.TaggedErrorClass<"InvalidKeySigningKeyStatus", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidKeySigningKeyStatus extends /*@__PURE__*/ InvalidKeySigningKeyStatus_base {
}
declare const InvalidKMSArn_base: S.TaggedErrorClass<"InvalidKMSArn", {
    readonly message: any;
}>;
export declare class InvalidKMSArn extends /*@__PURE__*/ InvalidKMSArn_base {
}
declare const InvalidPaginationToken_base: S.TaggedErrorClass<"InvalidPaginationToken", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidPaginationToken extends /*@__PURE__*/ InvalidPaginationToken_base {
}
declare const InvalidSigningStatus_base: S.TaggedErrorClass<"InvalidSigningStatus", {
    readonly message: any;
}>;
export declare class InvalidSigningStatus extends /*@__PURE__*/ InvalidSigningStatus_base {
}
declare const InvalidTrafficPolicyDocument_base: S.TaggedErrorClass<"InvalidTrafficPolicyDocument", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTrafficPolicyDocument extends /*@__PURE__*/ InvalidTrafficPolicyDocument_base {
}
declare const InvalidVPCId_base: S.TaggedErrorClass<"InvalidVPCId", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidVPCId extends /*@__PURE__*/ InvalidVPCId_base {
}
declare const KeySigningKeyAlreadyExists_base: S.TaggedErrorClass<"KeySigningKeyAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class KeySigningKeyAlreadyExists extends /*@__PURE__*/ KeySigningKeyAlreadyExists_base {
}
declare const KeySigningKeyInParentDSRecord_base: S.TaggedErrorClass<"KeySigningKeyInParentDSRecord", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KeySigningKeyInParentDSRecord extends /*@__PURE__*/ KeySigningKeyInParentDSRecord_base {
}
declare const KeySigningKeyInUse_base: S.TaggedErrorClass<"KeySigningKeyInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class KeySigningKeyInUse extends /*@__PURE__*/ KeySigningKeyInUse_base {
}
declare const KeySigningKeyWithActiveStatusNotFound_base: S.TaggedErrorClass<"KeySigningKeyWithActiveStatusNotFound", {
    readonly message: any;
}>;
export declare class KeySigningKeyWithActiveStatusNotFound extends /*@__PURE__*/ KeySigningKeyWithActiveStatusNotFound_base {
}
declare const LastVPCAssociation_base: S.TaggedErrorClass<"LastVPCAssociation", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LastVPCAssociation extends /*@__PURE__*/ LastVPCAssociation_base {
}
declare const LimitsExceeded_base: S.TaggedErrorClass<"LimitsExceeded", {
    readonly message: any;
}>;
export declare class LimitsExceeded extends /*@__PURE__*/ LimitsExceeded_base {
}
declare const NoSuchChange_base: S.TaggedErrorClass<"NoSuchChange", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchChange extends /*@__PURE__*/ NoSuchChange_base {
}
declare const NoSuchCidrCollectionException_base: S.TaggedErrorClass<"NoSuchCidrCollectionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchCidrCollectionException extends /*@__PURE__*/ NoSuchCidrCollectionException_base {
}
declare const NoSuchCidrLocationException_base: S.TaggedErrorClass<"NoSuchCidrLocationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchCidrLocationException extends /*@__PURE__*/ NoSuchCidrLocationException_base {
}
declare const NoSuchCloudWatchLogsLogGroup_base: S.TaggedErrorClass<"NoSuchCloudWatchLogsLogGroup", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchCloudWatchLogsLogGroup extends /*@__PURE__*/ NoSuchCloudWatchLogsLogGroup_base {
}
declare const NoSuchDelegationSet_base: S.TaggedErrorClass<"NoSuchDelegationSet", {
    readonly message: any;
}>;
export declare class NoSuchDelegationSet extends /*@__PURE__*/ NoSuchDelegationSet_base {
}
declare const NoSuchGeoLocation_base: S.TaggedErrorClass<"NoSuchGeoLocation", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchGeoLocation extends /*@__PURE__*/ NoSuchGeoLocation_base {
}
declare const NoSuchHealthCheck_base: S.TaggedErrorClass<"NoSuchHealthCheck", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchHealthCheck extends /*@__PURE__*/ NoSuchHealthCheck_base {
}
declare const NoSuchHostedZone_base: S.TaggedErrorClass<"NoSuchHostedZone", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchHostedZone extends /*@__PURE__*/ NoSuchHostedZone_base {
}
declare const NoSuchKeySigningKey_base: S.TaggedErrorClass<"NoSuchKeySigningKey", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchKeySigningKey extends /*@__PURE__*/ NoSuchKeySigningKey_base {
}
declare const NoSuchQueryLoggingConfig_base: S.TaggedErrorClass<"NoSuchQueryLoggingConfig", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchQueryLoggingConfig extends /*@__PURE__*/ NoSuchQueryLoggingConfig_base {
}
declare const NoSuchTrafficPolicy_base: S.TaggedErrorClass<"NoSuchTrafficPolicy", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchTrafficPolicy extends /*@__PURE__*/ NoSuchTrafficPolicy_base {
}
declare const NoSuchTrafficPolicyInstance_base: S.TaggedErrorClass<"NoSuchTrafficPolicyInstance", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchTrafficPolicyInstance extends /*@__PURE__*/ NoSuchTrafficPolicyInstance_base {
}
declare const NotAuthorizedException_base: S.TaggedErrorClass<"NotAuthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class NotAuthorizedException extends /*@__PURE__*/ NotAuthorizedException_base {
}
declare const PriorRequestNotComplete_base: S.TaggedErrorClass<"PriorRequestNotComplete", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class PriorRequestNotComplete extends /*@__PURE__*/ PriorRequestNotComplete_base {
}
declare const PublicZoneVPCAssociation_base: S.TaggedErrorClass<"PublicZoneVPCAssociation", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PublicZoneVPCAssociation extends /*@__PURE__*/ PublicZoneVPCAssociation_base {
}
declare const QueryLoggingConfigAlreadyExists_base: S.TaggedErrorClass<"QueryLoggingConfigAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class QueryLoggingConfigAlreadyExists extends /*@__PURE__*/ QueryLoggingConfigAlreadyExists_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyHealthChecks_base: S.TaggedErrorClass<"TooManyHealthChecks", {
    readonly message: any;
}>;
export declare class TooManyHealthChecks extends /*@__PURE__*/ TooManyHealthChecks_base {
}
declare const TooManyHostedZones_base: S.TaggedErrorClass<"TooManyHostedZones", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyHostedZones extends /*@__PURE__*/ TooManyHostedZones_base {
}
declare const TooManyKeySigningKeys_base: S.TaggedErrorClass<"TooManyKeySigningKeys", {
    readonly message: any;
}>;
export declare class TooManyKeySigningKeys extends /*@__PURE__*/ TooManyKeySigningKeys_base {
}
declare const TooManyTrafficPolicies_base: S.TaggedErrorClass<"TooManyTrafficPolicies", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTrafficPolicies extends /*@__PURE__*/ TooManyTrafficPolicies_base {
}
declare const TooManyTrafficPolicyInstances_base: S.TaggedErrorClass<"TooManyTrafficPolicyInstances", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTrafficPolicyInstances extends /*@__PURE__*/ TooManyTrafficPolicyInstances_base {
}
declare const TooManyTrafficPolicyVersionsForCurrentPolicy_base: S.TaggedErrorClass<"TooManyTrafficPolicyVersionsForCurrentPolicy", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTrafficPolicyVersionsForCurrentPolicy extends /*@__PURE__*/ TooManyTrafficPolicyVersionsForCurrentPolicy_base {
}
declare const TooManyVPCAssociationAuthorizations_base: S.TaggedErrorClass<"TooManyVPCAssociationAuthorizations", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyVPCAssociationAuthorizations extends /*@__PURE__*/ TooManyVPCAssociationAuthorizations_base {
}
declare const TrafficPolicyAlreadyExists_base: S.TaggedErrorClass<"TrafficPolicyAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class TrafficPolicyAlreadyExists extends /*@__PURE__*/ TrafficPolicyAlreadyExists_base {
}
declare const TrafficPolicyInstanceAlreadyExists_base: S.TaggedErrorClass<"TrafficPolicyInstanceAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class TrafficPolicyInstanceAlreadyExists extends /*@__PURE__*/ TrafficPolicyInstanceAlreadyExists_base {
}
declare const TrafficPolicyInUse_base: S.TaggedErrorClass<"TrafficPolicyInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class TrafficPolicyInUse extends /*@__PURE__*/ TrafficPolicyInUse_base {
}
declare const VPCAssociationAuthorizationNotFound_base: S.TaggedErrorClass<"VPCAssociationAuthorizationNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class VPCAssociationAuthorizationNotFound extends /*@__PURE__*/ VPCAssociationAuthorizationNotFound_base {
}
declare const VPCAssociationNotFound_base: S.TaggedErrorClass<"VPCAssociationNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class VPCAssociationNotFound extends /*@__PURE__*/ VPCAssociationNotFound_base {
}
export type ResourceId = string;
export type SigningKeyName = string;
export interface ActivateKeySigningKeyRequest {
    HostedZoneId: string;
    Name: string;
}
export type ChangeStatus = "PENDING" | "INSYNC" | (string & {});
export type ResourceDescription = string;
export interface ChangeInfo {
    Id: string;
    Status: ChangeStatus;
    SubmittedAt: Date;
    Comment?: string;
}
export interface ActivateKeySigningKeyResponse {
    ChangeInfo: ChangeInfo;
}
export type VPCRegion = "us-east-1" | "us-east-2" | "us-west-1" | "us-west-2" | "eu-west-1" | "eu-west-2" | "eu-west-3" | "eu-central-1" | "eu-central-2" | "ap-east-1" | "me-south-1" | "us-gov-west-1" | "us-gov-east-1" | "us-iso-east-1" | "us-iso-west-1" | "us-isob-east-1" | "me-central-1" | "ap-southeast-1" | "ap-southeast-2" | "ap-southeast-3" | "ap-south-1" | "ap-south-2" | "ap-northeast-1" | "ap-northeast-2" | "ap-northeast-3" | "eu-north-1" | "sa-east-1" | "ca-central-1" | "cn-north-1" | "cn-northwest-1" | "af-south-1" | "eu-south-1" | "eu-south-2" | "ap-southeast-4" | "il-central-1" | "ca-west-1" | "ap-southeast-5" | "mx-central-1" | "us-isof-south-1" | "us-isof-east-1" | "ap-southeast-7" | "ap-east-2" | "eu-isoe-west-1" | "ap-southeast-6" | "us-isob-west-1" | "eusc-de-east-1" | (string & {});
export type VPCId = string;
export interface VPC {
    VPCRegion?: VPCRegion;
    VPCId?: string;
}
export type AssociateVPCComment = string;
export interface AssociateVPCWithHostedZoneRequest {
    HostedZoneId: string;
    VPC: VPC;
    Comment?: string;
}
export interface AssociateVPCWithHostedZoneResponse {
    ChangeInfo: ChangeInfo;
}
export type UUID = string;
export type CollectionVersion = number;
export type CidrLocationNameDefaultNotAllowed = string;
export type CidrCollectionChangeAction = "PUT" | "DELETE_IF_EXISTS" | (string & {});
export type Cidr = string;
export type CidrList = string[];
export interface CidrCollectionChange {
    LocationName: string;
    Action: CidrCollectionChangeAction;
    CidrList: string[];
}
export type CidrCollectionChanges = CidrCollectionChange[];
export interface ChangeCidrCollectionRequest {
    Id: string;
    CollectionVersion?: number;
    Changes: CidrCollectionChange[];
}
export type ChangeId = string;
export interface ChangeCidrCollectionResponse {
    Id: string;
}
export type ChangeAction = "CREATE" | "DELETE" | "UPSERT" | (string & {});
export type DNSName = string;
export type RRType = "SOA" | "A" | "TXT" | "NS" | "CNAME" | "MX" | "NAPTR" | "PTR" | "SRV" | "SPF" | "AAAA" | "CAA" | "DS" | "TLSA" | "SSHFP" | "SVCB" | "HTTPS" | (string & {});
export type ResourceRecordSetIdentifier = string;
export type ResourceRecordSetWeight = number;
export type ResourceRecordSetRegion = "us-east-1" | "us-east-2" | "us-west-1" | "us-west-2" | "ca-central-1" | "eu-west-1" | "eu-west-2" | "eu-west-3" | "eu-central-1" | "eu-central-2" | "ap-southeast-1" | "ap-southeast-2" | "ap-southeast-3" | "ap-northeast-1" | "ap-northeast-2" | "ap-northeast-3" | "eu-north-1" | "sa-east-1" | "cn-north-1" | "cn-northwest-1" | "ap-east-1" | "me-south-1" | "me-central-1" | "ap-south-1" | "ap-south-2" | "af-south-1" | "eu-south-1" | "eu-south-2" | "ap-southeast-4" | "il-central-1" | "ca-west-1" | "ap-southeast-5" | "mx-central-1" | "ap-southeast-7" | "us-gov-east-1" | "us-gov-west-1" | "ap-east-2" | "ap-southeast-6" | "eusc-de-east-1" | (string & {});
export type GeoLocationContinentCode = string;
export type GeoLocationCountryCode = string;
export type GeoLocationSubdivisionCode = string;
export interface GeoLocation {
    ContinentCode?: string;
    CountryCode?: string;
    SubdivisionCode?: string;
}
export type ResourceRecordSetFailover = "PRIMARY" | "SECONDARY" | (string & {});
export type ResourceRecordSetMultiValueAnswer = boolean;
export type TTL = number;
export type RData = string;
export interface ResourceRecord {
    Value: string;
}
export type ResourceRecords = ResourceRecord[];
export type AliasHealthEnabled = boolean;
export interface AliasTarget {
    HostedZoneId: string;
    DNSName: string;
    EvaluateTargetHealth: boolean;
}
export type HealthCheckId = string;
export type TrafficPolicyInstanceId = string;
export type CidrLocationNameDefaultAllowed = string;
export interface CidrRoutingConfig {
    CollectionId: string;
    LocationName: string;
}
export type AWSRegion = string;
export type LocalZoneGroup = string;
export type Latitude = string;
export type Longitude = string;
export interface Coordinates {
    Latitude: string;
    Longitude: string;
}
export type Bias = number;
export interface GeoProximityLocation {
    AWSRegion?: string;
    LocalZoneGroup?: string;
    Coordinates?: Coordinates;
    Bias?: number;
}
export interface ResourceRecordSet {
    Name: string;
    Type: RRType;
    SetIdentifier?: string;
    Weight?: number;
    Region?: ResourceRecordSetRegion;
    GeoLocation?: GeoLocation;
    Failover?: ResourceRecordSetFailover;
    MultiValueAnswer?: boolean;
    TTL?: number;
    ResourceRecords?: ResourceRecord[];
    AliasTarget?: AliasTarget;
    HealthCheckId?: string;
    TrafficPolicyInstanceId?: string;
    CidrRoutingConfig?: CidrRoutingConfig;
    GeoProximityLocation?: GeoProximityLocation;
}
export interface Change {
    Action: ChangeAction;
    ResourceRecordSet: ResourceRecordSet;
}
export type Changes = Change[];
export interface ChangeBatch {
    Comment?: string;
    Changes: Change[];
}
export interface ChangeResourceRecordSetsRequest {
    HostedZoneId: string;
    ChangeBatch: ChangeBatch;
}
export interface ChangeResourceRecordSetsResponse {
    ChangeInfo: ChangeInfo;
}
export type TagResourceType = "healthcheck" | "hostedzone" | (string & {});
export type TagResourceId = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string;
    Value?: string;
}
export type TagList = Tag[];
export type TagKeyList = string[];
export interface ChangeTagsForResourceRequest {
    ResourceType: TagResourceType;
    ResourceId: string;
    AddTags?: Tag[];
    RemoveTagKeys?: string[];
}
export interface ChangeTagsForResourceResponse {
}
export type CollectionName = string;
export type CidrNonce = string;
export interface CreateCidrCollectionRequest {
    Name: string;
    CallerReference: string;
}
export type ARN = string;
export interface CidrCollection {
    Arn?: string;
    Id?: string;
    Name?: string;
    Version?: number;
}
export type ResourceURI = string;
export interface CreateCidrCollectionResponse {
    Collection?: CidrCollection;
    Location?: string;
}
export type HealthCheckNonce = string;
export type IPAddress = string;
export type Port = number;
export type HealthCheckType = "HTTP" | "HTTPS" | "HTTP_STR_MATCH" | "HTTPS_STR_MATCH" | "TCP" | "CALCULATED" | "CLOUDWATCH_METRIC" | "RECOVERY_CONTROL" | (string & {});
export type ResourcePath = string;
export type FullyQualifiedDomainName = string;
export type SearchString = string;
export type RequestInterval = number;
export type FailureThreshold = number;
export type MeasureLatency = boolean;
export type Inverted = boolean;
export type Disabled = boolean;
export type HealthThreshold = number;
export type ChildHealthCheckList = string[];
export type EnableSNI = boolean;
export type HealthCheckRegion = "us-east-1" | "us-west-1" | "us-west-2" | "eu-west-1" | "ap-southeast-1" | "ap-southeast-2" | "ap-northeast-1" | "sa-east-1" | (string & {});
export type HealthCheckRegionList = HealthCheckRegion[];
export type CloudWatchRegion = "us-east-1" | "us-east-2" | "us-west-1" | "us-west-2" | "ca-central-1" | "eu-central-1" | "eu-central-2" | "eu-west-1" | "eu-west-2" | "eu-west-3" | "ap-east-1" | "me-south-1" | "me-central-1" | "ap-south-1" | "ap-south-2" | "ap-southeast-1" | "ap-southeast-2" | "ap-southeast-3" | "ap-northeast-1" | "ap-northeast-2" | "ap-northeast-3" | "eu-north-1" | "sa-east-1" | "cn-northwest-1" | "cn-north-1" | "af-south-1" | "eu-south-1" | "eu-south-2" | "us-gov-west-1" | "us-gov-east-1" | "us-iso-east-1" | "us-iso-west-1" | "us-isob-east-1" | "ap-southeast-4" | "il-central-1" | "ca-west-1" | "ap-southeast-5" | "mx-central-1" | "us-isof-south-1" | "us-isof-east-1" | "ap-southeast-7" | "ap-east-2" | "eu-isoe-west-1" | "ap-southeast-6" | "us-isob-west-1" | "eusc-de-east-1" | (string & {});
export type AlarmName = string;
export interface AlarmIdentifier {
    Region: CloudWatchRegion;
    Name: string;
}
export type InsufficientDataHealthStatus = "Healthy" | "Unhealthy" | "LastKnownStatus" | (string & {});
export type RoutingControlArn = string;
export interface HealthCheckConfig {
    IPAddress?: string;
    Port?: number;
    Type: HealthCheckType;
    ResourcePath?: string;
    FullyQualifiedDomainName?: string;
    SearchString?: string;
    RequestInterval?: number;
    FailureThreshold?: number;
    MeasureLatency?: boolean;
    Inverted?: boolean;
    Disabled?: boolean;
    HealthThreshold?: number;
    ChildHealthChecks?: string[];
    EnableSNI?: boolean;
    Regions?: HealthCheckRegion[];
    AlarmIdentifier?: AlarmIdentifier;
    InsufficientDataHealthStatus?: InsufficientDataHealthStatus;
    RoutingControlArn?: string;
}
export interface CreateHealthCheckRequest {
    CallerReference: string;
    HealthCheckConfig: HealthCheckConfig;
}
export type ServicePrincipal = string;
export interface LinkedService {
    ServicePrincipal?: string;
    Description?: string;
}
export type HealthCheckVersion = number;
export type EvaluationPeriods = number;
export type Threshold = number;
export type ComparisonOperator = "GreaterThanOrEqualToThreshold" | "GreaterThanThreshold" | "LessThanThreshold" | "LessThanOrEqualToThreshold" | (string & {});
export type Period = number;
export type MetricName = string;
export type Namespace = string;
export type Statistic = "Average" | "Sum" | "SampleCount" | "Maximum" | "Minimum" | (string & {});
export type DimensionField = string;
export interface Dimension {
    Name: string;
    Value: string;
}
export type DimensionList = Dimension[];
export interface CloudWatchAlarmConfiguration {
    EvaluationPeriods: number;
    Threshold: number;
    ComparisonOperator: ComparisonOperator;
    Period: number;
    MetricName: string;
    Namespace: string;
    Statistic: Statistic;
    Dimensions?: Dimension[];
}
export interface HealthCheck {
    Id: string;
    CallerReference: string;
    LinkedService?: LinkedService;
    HealthCheckConfig: HealthCheckConfig;
    HealthCheckVersion: number;
    CloudWatchAlarmConfiguration?: CloudWatchAlarmConfiguration;
}
export interface CreateHealthCheckResponse {
    HealthCheck: HealthCheck;
    Location: string;
}
export type Nonce = string;
export type IsPrivateZone = boolean;
export interface HostedZoneConfig {
    Comment?: string;
    PrivateZone?: boolean;
}
export interface CreateHostedZoneRequest {
    Name: string;
    VPC?: VPC;
    CallerReference: string;
    HostedZoneConfig?: HostedZoneConfig;
    DelegationSetId?: string;
}
export type HostedZoneRRSetCount = number;
export type AcceleratedRecoveryStatus = "ENABLING" | "ENABLE_FAILED" | "ENABLING_HOSTED_ZONE_LOCKED" | "ENABLED" | "DISABLING" | "DISABLE_FAILED" | "DISABLED" | "DISABLING_HOSTED_ZONE_LOCKED" | (string & {});
export type FailureReason = string;
export interface HostedZoneFailureReasons {
    AcceleratedRecovery?: string;
}
export interface HostedZoneFeatures {
    AcceleratedRecoveryStatus?: AcceleratedRecoveryStatus;
    FailureReasons?: HostedZoneFailureReasons;
}
export interface HostedZone {
    Id: string;
    Name: string;
    CallerReference: string;
    Config?: HostedZoneConfig;
    ResourceRecordSetCount?: number;
    LinkedService?: LinkedService;
    Features?: HostedZoneFeatures;
}
export type DelegationSetNameServers = string[];
export interface DelegationSet {
    Id?: string;
    CallerReference?: string;
    NameServers: string[];
}
export interface CreateHostedZoneResponse {
    HostedZone: HostedZone;
    ChangeInfo: ChangeInfo;
    DelegationSet?: DelegationSet;
    VPC?: VPC;
    Location: string;
}
export type SigningKeyString = string;
export type SigningKeyStatus = string;
export interface CreateKeySigningKeyRequest {
    CallerReference: string;
    HostedZoneId: string;
    KeyManagementServiceArn: string;
    Name: string;
    Status: string;
}
export type SigningKeyInteger = number;
export type SigningKeyTag = number;
export type SigningKeyStatusMessage = string;
export interface KeySigningKey {
    Name?: string;
    KmsArn?: string;
    Flag?: number;
    SigningAlgorithmMnemonic?: string;
    SigningAlgorithmType?: number;
    DigestAlgorithmMnemonic?: string;
    DigestAlgorithmType?: number;
    KeyTag?: number;
    DigestValue?: string;
    PublicKey?: string;
    DSRecord?: string;
    DNSKEYRecord?: string;
    Status?: string;
    StatusMessage?: string;
    CreatedDate?: Date;
    LastModifiedDate?: Date;
}
export interface CreateKeySigningKeyResponse {
    ChangeInfo: ChangeInfo;
    KeySigningKey: KeySigningKey;
    Location: string;
}
export type CloudWatchLogsLogGroupArn = string;
export interface CreateQueryLoggingConfigRequest {
    HostedZoneId: string;
    CloudWatchLogsLogGroupArn: string;
}
export type QueryLoggingConfigId = string;
export interface QueryLoggingConfig {
    Id: string;
    HostedZoneId: string;
    CloudWatchLogsLogGroupArn: string;
}
export interface CreateQueryLoggingConfigResponse {
    QueryLoggingConfig: QueryLoggingConfig;
    Location: string;
}
export interface CreateReusableDelegationSetRequest {
    CallerReference: string;
    HostedZoneId?: string;
}
export interface CreateReusableDelegationSetResponse {
    DelegationSet: DelegationSet;
    Location: string;
}
export type TrafficPolicyName = string;
export type TrafficPolicyDocument = string;
export type TrafficPolicyComment = string;
export interface CreateTrafficPolicyRequest {
    Name: string;
    Document: string;
    Comment?: string;
}
export type TrafficPolicyId = string;
export type TrafficPolicyVersion = number;
export interface TrafficPolicy {
    Id: string;
    Version: number;
    Name: string;
    Type: RRType;
    Document: string;
    Comment?: string;
}
export interface CreateTrafficPolicyResponse {
    TrafficPolicy: TrafficPolicy;
    Location: string;
}
export interface CreateTrafficPolicyInstanceRequest {
    HostedZoneId: string;
    Name: string;
    TTL: number;
    TrafficPolicyId: string;
    TrafficPolicyVersion: number;
}
export type TrafficPolicyInstanceState = string;
export type Message = string;
export interface TrafficPolicyInstance {
    Id: string;
    HostedZoneId: string;
    Name: string;
    TTL: number;
    State: string;
    Message: string;
    TrafficPolicyId: string;
    TrafficPolicyVersion: number;
    TrafficPolicyType: RRType;
}
export interface CreateTrafficPolicyInstanceResponse {
    TrafficPolicyInstance: TrafficPolicyInstance;
    Location: string;
}
export interface CreateTrafficPolicyVersionRequest {
    Id: string;
    Document: string;
    Comment?: string;
}
export interface CreateTrafficPolicyVersionResponse {
    TrafficPolicy: TrafficPolicy;
    Location: string;
}
export interface CreateVPCAssociationAuthorizationRequest {
    HostedZoneId: string;
    VPC: VPC;
}
export interface CreateVPCAssociationAuthorizationResponse {
    HostedZoneId: string;
    VPC: VPC;
}
export interface DeactivateKeySigningKeyRequest {
    HostedZoneId: string;
    Name: string;
}
export interface DeactivateKeySigningKeyResponse {
    ChangeInfo: ChangeInfo;
}
export interface DeleteCidrCollectionRequest {
    Id: string;
}
export interface DeleteCidrCollectionResponse {
}
export interface DeleteHealthCheckRequest {
    HealthCheckId: string;
}
export interface DeleteHealthCheckResponse {
}
export interface DeleteHostedZoneRequest {
    Id: string;
}
export interface DeleteHostedZoneResponse {
    ChangeInfo: ChangeInfo;
}
export interface DeleteKeySigningKeyRequest {
    HostedZoneId: string;
    Name: string;
}
export interface DeleteKeySigningKeyResponse {
    ChangeInfo: ChangeInfo;
}
export interface DeleteQueryLoggingConfigRequest {
    Id: string;
}
export interface DeleteQueryLoggingConfigResponse {
}
export interface DeleteReusableDelegationSetRequest {
    Id: string;
}
export interface DeleteReusableDelegationSetResponse {
}
export interface DeleteTrafficPolicyRequest {
    Id: string;
    Version: number;
}
export interface DeleteTrafficPolicyResponse {
}
export interface DeleteTrafficPolicyInstanceRequest {
    Id: string;
}
export interface DeleteTrafficPolicyInstanceResponse {
}
export interface DeleteVPCAssociationAuthorizationRequest {
    HostedZoneId: string;
    VPC: VPC;
}
export interface DeleteVPCAssociationAuthorizationResponse {
}
export interface DisableHostedZoneDNSSECRequest {
    HostedZoneId: string;
}
export interface DisableHostedZoneDNSSECResponse {
    ChangeInfo: ChangeInfo;
}
export type DisassociateVPCComment = string;
export interface DisassociateVPCFromHostedZoneRequest {
    HostedZoneId: string;
    VPC: VPC;
    Comment?: string;
}
export interface DisassociateVPCFromHostedZoneResponse {
    ChangeInfo: ChangeInfo;
}
export interface EnableHostedZoneDNSSECRequest {
    HostedZoneId: string;
}
export interface EnableHostedZoneDNSSECResponse {
    ChangeInfo: ChangeInfo;
}
export type AccountLimitType = "MAX_HEALTH_CHECKS_BY_OWNER" | "MAX_HOSTED_ZONES_BY_OWNER" | "MAX_TRAFFIC_POLICY_INSTANCES_BY_OWNER" | "MAX_REUSABLE_DELEGATION_SETS_BY_OWNER" | "MAX_TRAFFIC_POLICIES_BY_OWNER" | (string & {});
export interface GetAccountLimitRequest {
    Type: AccountLimitType;
}
export type LimitValue = number;
export interface AccountLimit {
    Type: AccountLimitType;
    Value: number;
}
export type UsageCount = number;
export interface GetAccountLimitResponse {
    Limit: AccountLimit;
    Count: number;
}
export interface GetChangeRequest {
    Id: string;
}
export interface GetChangeResponse {
    ChangeInfo: ChangeInfo;
}
export interface GetCheckerIpRangesRequest {
}
export type IPAddressCidr = string;
export type CheckerIpRanges = string[];
export interface GetCheckerIpRangesResponse {
    CheckerIpRanges: string[];
}
export interface GetDNSSECRequest {
    HostedZoneId: string;
}
export type ServeSignature = string;
export interface DNSSECStatus {
    ServeSignature?: string;
    StatusMessage?: string;
}
export type KeySigningKeys = KeySigningKey[];
export interface GetDNSSECResponse {
    Status: DNSSECStatus;
    KeySigningKeys: KeySigningKey[];
}
export interface GetGeoLocationRequest {
    ContinentCode?: string;
    CountryCode?: string;
    SubdivisionCode?: string;
}
export type GeoLocationContinentName = string;
export type GeoLocationCountryName = string;
export type GeoLocationSubdivisionName = string;
export interface GeoLocationDetails {
    ContinentCode?: string;
    ContinentName?: string;
    CountryCode?: string;
    CountryName?: string;
    SubdivisionCode?: string;
    SubdivisionName?: string;
}
export interface GetGeoLocationResponse {
    GeoLocationDetails: GeoLocationDetails;
}
export interface GetHealthCheckRequest {
    HealthCheckId: string;
}
export interface GetHealthCheckResponse {
    HealthCheck: HealthCheck;
}
export interface GetHealthCheckCountRequest {
}
export type HealthCheckCount = number;
export interface GetHealthCheckCountResponse {
    HealthCheckCount: number;
}
export interface GetHealthCheckLastFailureReasonRequest {
    HealthCheckId: string;
}
export type Status = string;
export interface StatusReport {
    Status?: string;
    CheckedTime?: Date;
}
export interface HealthCheckObservation {
    Region?: HealthCheckRegion;
    IPAddress?: string;
    StatusReport?: StatusReport;
}
export type HealthCheckObservations = HealthCheckObservation[];
export interface GetHealthCheckLastFailureReasonResponse {
    HealthCheckObservations: HealthCheckObservation[];
}
export interface GetHealthCheckStatusRequest {
    HealthCheckId: string;
}
export interface GetHealthCheckStatusResponse {
    HealthCheckObservations: HealthCheckObservation[];
}
export interface GetHostedZoneRequest {
    Id: string;
}
export type VPCs = VPC[];
export interface GetHostedZoneResponse {
    HostedZone: HostedZone;
    DelegationSet?: DelegationSet;
    VPCs?: VPC[];
}
export interface GetHostedZoneCountRequest {
}
export type HostedZoneCount = number;
export interface GetHostedZoneCountResponse {
    HostedZoneCount: number;
}
export type HostedZoneLimitType = "MAX_RRSETS_BY_ZONE" | "MAX_VPCS_ASSOCIATED_BY_ZONE" | (string & {});
export interface GetHostedZoneLimitRequest {
    Type: HostedZoneLimitType;
    HostedZoneId: string;
}
export interface HostedZoneLimit {
    Type: HostedZoneLimitType;
    Value: number;
}
export interface GetHostedZoneLimitResponse {
    Limit: HostedZoneLimit;
    Count: number;
}
export interface GetQueryLoggingConfigRequest {
    Id: string;
}
export interface GetQueryLoggingConfigResponse {
    QueryLoggingConfig: QueryLoggingConfig;
}
export interface GetReusableDelegationSetRequest {
    Id: string;
}
export interface GetReusableDelegationSetResponse {
    DelegationSet: DelegationSet;
}
export type ReusableDelegationSetLimitType = "MAX_ZONES_BY_REUSABLE_DELEGATION_SET" | (string & {});
export interface GetReusableDelegationSetLimitRequest {
    Type: ReusableDelegationSetLimitType;
    DelegationSetId: string;
}
export interface ReusableDelegationSetLimit {
    Type: ReusableDelegationSetLimitType;
    Value: number;
}
export interface GetReusableDelegationSetLimitResponse {
    Limit: ReusableDelegationSetLimit;
    Count: number;
}
export interface GetTrafficPolicyRequest {
    Id: string;
    Version: number;
}
export interface GetTrafficPolicyResponse {
    TrafficPolicy: TrafficPolicy;
}
export interface GetTrafficPolicyInstanceRequest {
    Id: string;
}
export interface GetTrafficPolicyInstanceResponse {
    TrafficPolicyInstance: TrafficPolicyInstance;
}
export interface GetTrafficPolicyInstanceCountRequest {
}
export type TrafficPolicyInstanceCount = number;
export interface GetTrafficPolicyInstanceCountResponse {
    TrafficPolicyInstanceCount: number;
}
export type PaginationToken = string;
export interface ListCidrBlocksRequest {
    CollectionId: string;
    LocationName?: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface CidrBlockSummary {
    CidrBlock?: string;
    LocationName?: string;
}
export type CidrBlockSummaries = CidrBlockSummary[];
export interface ListCidrBlocksResponse {
    NextToken?: string;
    CidrBlocks?: CidrBlockSummary[];
}
export interface ListCidrCollectionsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface CollectionSummary {
    Arn?: string;
    Id?: string;
    Name?: string;
    Version?: number;
}
export type CollectionSummaries = CollectionSummary[];
export interface ListCidrCollectionsResponse {
    NextToken?: string;
    CidrCollections?: CollectionSummary[];
}
export interface ListCidrLocationsRequest {
    CollectionId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface LocationSummary {
    LocationName?: string;
}
export type LocationSummaries = LocationSummary[];
export interface ListCidrLocationsResponse {
    NextToken?: string;
    CidrLocations?: LocationSummary[];
}
export interface ListGeoLocationsRequest {
    StartContinentCode?: string;
    StartCountryCode?: string;
    StartSubdivisionCode?: string;
    MaxItems?: number;
}
export type GeoLocationDetailsList = GeoLocationDetails[];
export type PageTruncated = boolean;
export interface ListGeoLocationsResponse {
    GeoLocationDetailsList: GeoLocationDetails[];
    IsTruncated: boolean;
    NextContinentCode?: string;
    NextCountryCode?: string;
    NextSubdivisionCode?: string;
    MaxItems: number;
}
export type PageMarker = string;
export interface ListHealthChecksRequest {
    Marker?: string;
    MaxItems?: number;
}
export type HealthChecks = HealthCheck[];
export interface ListHealthChecksResponse {
    HealthChecks?: HealthCheck[];
    Marker?: string;
    IsTruncated: boolean;
    NextMarker?: string;
    MaxItems: number;
}
export type HostedZoneType = "PrivateHostedZone" | (string & {});
export interface ListHostedZonesRequest {
    Marker?: string;
    MaxItems?: number;
    DelegationSetId?: string;
    HostedZoneType?: HostedZoneType;
}
export type HostedZones = HostedZone[];
export interface ListHostedZonesResponse {
    HostedZones?: HostedZone[];
    Marker?: string;
    IsTruncated: boolean;
    NextMarker?: string;
    MaxItems: number;
}
export interface ListHostedZonesByNameRequest {
    DNSName?: string;
    HostedZoneId?: string;
    MaxItems?: number;
}
export interface ListHostedZonesByNameResponse {
    HostedZones?: HostedZone[];
    DNSName?: string;
    HostedZoneId?: string;
    IsTruncated: boolean;
    NextDNSName?: string;
    NextHostedZoneId?: string;
    MaxItems: number;
}
export interface ListHostedZonesByVPCRequest {
    VPCId: string;
    VPCRegion: VPCRegion;
    MaxItems?: number;
    NextToken?: string;
}
export type AWSAccountID = string;
export type HostedZoneOwningService = string;
export interface HostedZoneOwner {
    OwningAccount?: string;
    OwningService?: string;
}
export interface HostedZoneSummary {
    HostedZoneId: string;
    Name: string;
    Owner: HostedZoneOwner;
}
export type HostedZoneSummaries = HostedZoneSummary[];
export interface ListHostedZonesByVPCResponse {
    HostedZoneSummaries: HostedZoneSummary[];
    MaxItems: number;
    NextToken?: string;
}
export interface ListQueryLoggingConfigsRequest {
    HostedZoneId?: string;
    NextToken?: string;
    MaxResults?: number;
}
export type QueryLoggingConfigs = QueryLoggingConfig[];
export interface ListQueryLoggingConfigsResponse {
    QueryLoggingConfigs?: QueryLoggingConfig[];
    NextToken?: string;
}
export interface ListResourceRecordSetsRequest {
    HostedZoneId: string;
    StartRecordName?: string;
    StartRecordType?: RRType;
    StartRecordIdentifier?: string;
    MaxItems?: number;
}
export type ResourceRecordSets = ResourceRecordSet[];
export interface ListResourceRecordSetsResponse {
    ResourceRecordSets?: ResourceRecordSet[];
    IsTruncated: boolean;
    NextRecordName?: string;
    NextRecordType?: RRType;
    NextRecordIdentifier?: string;
    MaxItems: number;
}
export interface ListReusableDelegationSetsRequest {
    Marker?: string;
    MaxItems?: number;
}
export type DelegationSets = DelegationSet[];
export interface ListReusableDelegationSetsResponse {
    DelegationSets: DelegationSet[];
    Marker: string;
    IsTruncated: boolean;
    NextMarker?: string;
    MaxItems: number;
}
export interface ListTagsForResourceRequest {
    ResourceType: TagResourceType;
    ResourceId: string;
}
export interface ResourceTagSet {
    ResourceType?: TagResourceType;
    ResourceId?: string;
    Tags?: Tag[];
}
export interface ListTagsForResourceResponse {
    ResourceTagSet: ResourceTagSet;
}
export type TagResourceIdList = string[];
export interface ListTagsForResourcesRequest {
    ResourceType: TagResourceType;
    ResourceIds: string[];
}
export type ResourceTagSetList = ResourceTagSet[];
export interface ListTagsForResourcesResponse {
    ResourceTagSets: ResourceTagSet[];
}
export interface ListTrafficPoliciesRequest {
    TrafficPolicyIdMarker?: string;
    MaxItems?: number;
}
export interface TrafficPolicySummary {
    Id: string;
    Name: string;
    Type: RRType;
    LatestVersion: number;
    TrafficPolicyCount: number;
}
export type TrafficPolicySummaries = TrafficPolicySummary[];
export interface ListTrafficPoliciesResponse {
    TrafficPolicySummaries: TrafficPolicySummary[];
    IsTruncated: boolean;
    TrafficPolicyIdMarker: string;
    MaxItems: number;
}
export interface ListTrafficPolicyInstancesRequest {
    HostedZoneIdMarker?: string;
    TrafficPolicyInstanceNameMarker?: string;
    TrafficPolicyInstanceTypeMarker?: RRType;
    MaxItems?: number;
}
export type TrafficPolicyInstances = TrafficPolicyInstance[];
export interface ListTrafficPolicyInstancesResponse {
    TrafficPolicyInstances: TrafficPolicyInstance[];
    HostedZoneIdMarker?: string;
    TrafficPolicyInstanceNameMarker?: string;
    TrafficPolicyInstanceTypeMarker?: RRType;
    IsTruncated: boolean;
    MaxItems: number;
}
export interface ListTrafficPolicyInstancesByHostedZoneRequest {
    HostedZoneId: string;
    TrafficPolicyInstanceNameMarker?: string;
    TrafficPolicyInstanceTypeMarker?: RRType;
    MaxItems?: number;
}
export interface ListTrafficPolicyInstancesByHostedZoneResponse {
    TrafficPolicyInstances: TrafficPolicyInstance[];
    TrafficPolicyInstanceNameMarker?: string;
    TrafficPolicyInstanceTypeMarker?: RRType;
    IsTruncated: boolean;
    MaxItems: number;
}
export interface ListTrafficPolicyInstancesByPolicyRequest {
    TrafficPolicyId: string;
    TrafficPolicyVersion: number;
    HostedZoneIdMarker?: string;
    TrafficPolicyInstanceNameMarker?: string;
    TrafficPolicyInstanceTypeMarker?: RRType;
    MaxItems?: number;
}
export interface ListTrafficPolicyInstancesByPolicyResponse {
    TrafficPolicyInstances: TrafficPolicyInstance[];
    HostedZoneIdMarker?: string;
    TrafficPolicyInstanceNameMarker?: string;
    TrafficPolicyInstanceTypeMarker?: RRType;
    IsTruncated: boolean;
    MaxItems: number;
}
export type TrafficPolicyVersionMarker = string;
export interface ListTrafficPolicyVersionsRequest {
    Id: string;
    TrafficPolicyVersionMarker?: string;
    MaxItems?: number;
}
export type TrafficPolicies = TrafficPolicy[];
export interface ListTrafficPolicyVersionsResponse {
    TrafficPolicies: TrafficPolicy[];
    IsTruncated: boolean;
    TrafficPolicyVersionMarker: string;
    MaxItems: number;
}
export interface ListVPCAssociationAuthorizationsRequest {
    HostedZoneId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface ListVPCAssociationAuthorizationsResponse {
    HostedZoneId: string;
    NextToken?: string;
    VPCs?: VPC[];
}
export type SubnetMask = string;
export interface TestDNSAnswerRequest {
    HostedZoneId: string;
    RecordName: string;
    RecordType: RRType;
    ResolverIP?: string;
    EDNS0ClientSubnetIP?: string;
    EDNS0ClientSubnetMask?: string;
}
export type Nameserver = string;
export type RecordDataEntry = string;
export type RecordData = string[];
export type DNSRCode = string;
export type TransportProtocol = string;
export interface TestDNSAnswerResponse {
    Nameserver: string;
    RecordName: string;
    RecordType: RRType;
    RecordData: string[];
    ResponseCode: string;
    Protocol: string;
}
export type ResettableElementName = "FullyQualifiedDomainName" | "Regions" | "ResourcePath" | "ChildHealthChecks" | (string & {});
export type ResettableElementNameList = ResettableElementName[];
export interface UpdateHealthCheckRequest {
    HealthCheckId: string;
    HealthCheckVersion?: number;
    IPAddress?: string;
    Port?: number;
    ResourcePath?: string;
    FullyQualifiedDomainName?: string;
    SearchString?: string;
    FailureThreshold?: number;
    Inverted?: boolean;
    Disabled?: boolean;
    HealthThreshold?: number;
    ChildHealthChecks?: string[];
    EnableSNI?: boolean;
    Regions?: HealthCheckRegion[];
    AlarmIdentifier?: AlarmIdentifier;
    InsufficientDataHealthStatus?: InsufficientDataHealthStatus;
    ResetElements?: ResettableElementName[];
}
export interface UpdateHealthCheckResponse {
    HealthCheck: HealthCheck;
}
export interface UpdateHostedZoneCommentRequest {
    Id: string;
    Comment?: string;
}
export interface UpdateHostedZoneCommentResponse {
    HostedZone: HostedZone;
}
export type AcceleratedRecoveryEnabled = boolean;
export interface UpdateHostedZoneFeaturesRequest {
    HostedZoneId: string;
    EnableAcceleratedRecovery?: boolean;
}
export interface UpdateHostedZoneFeaturesResponse {
}
export interface UpdateTrafficPolicyCommentRequest {
    Id: string;
    Version: number;
    Comment: string;
}
export interface UpdateTrafficPolicyCommentResponse {
    TrafficPolicy: TrafficPolicy;
}
export interface UpdateTrafficPolicyInstanceRequest {
    Id: string;
    TTL: number;
    TrafficPolicyId: string;
    TrafficPolicyVersion: number;
}
export interface UpdateTrafficPolicyInstanceResponse {
    TrafficPolicyInstance: TrafficPolicyInstance;
}
export type ErrorMessage = string;
export type ErrorMessages = string[];
export type ActivateKeySigningKeyError = ConcurrentModification | InvalidInput | InvalidKeySigningKeyStatus | InvalidKMSArn | InvalidSigningStatus | NoSuchKeySigningKey | CommonErrors;
/**
 * Activates a key-signing key (KSK) so that it can be used for signing by DNSSEC. This
 * operation changes the KSK status to `ACTIVE`.
 */
export declare const activateKeySigningKey: API.OperationMethod<ActivateKeySigningKeyRequest, ActivateKeySigningKeyResponse, ActivateKeySigningKeyError, Credentials | HttpClient.HttpClient>;
export type AssociateVPCWithHostedZoneError = ConflictingDomainExists | InvalidInput | InvalidVPCId | LimitsExceeded | NoSuchHostedZone | NotAuthorizedException | PriorRequestNotComplete | PublicZoneVPCAssociation | CommonErrors;
/**
 * Associates an Amazon VPC with a private hosted zone.
 *
 * To perform the association, the VPC and the private hosted zone must already
 * exist. You can't convert a public hosted zone into a private hosted zone.
 *
 * If you want to associate a VPC that was created by using one Amazon Web Services account with a private hosted zone that was created by using a
 * different account, the Amazon Web Services account that created the private hosted
 * zone must first submit a `CreateVPCAssociationAuthorization` request.
 * Then the account that created the VPC must submit an
 * `AssociateVPCWithHostedZone` request.
 *
 * When granting access, the hosted zone and the Amazon VPC must belong to
 * the same partition. A partition is a group of Amazon Web Services Regions. Each
 * Amazon Web Services account is scoped to one partition.
 *
 * The following are the supported partitions:
 *
 * - `aws` - Amazon Web Services Regions
 *
 * - `aws-cn` - China Regions
 *
 * - `aws-us-gov` - Amazon Web Services GovCloud (US) Region
 *
 * For more information, see Access Management
 * in the *Amazon Web Services General Reference*.
 */
export declare const associateVPCWithHostedZone: API.OperationMethod<AssociateVPCWithHostedZoneRequest, AssociateVPCWithHostedZoneResponse, AssociateVPCWithHostedZoneError, Credentials | HttpClient.HttpClient>;
export type ChangeCidrCollectionError = CidrBlockInUseException | CidrCollectionVersionMismatchException | ConcurrentModification | InvalidInput | LimitsExceeded | NoSuchCidrCollectionException | CommonErrors;
/**
 * Creates, changes, or deletes CIDR blocks within a collection. Contains authoritative
 * IP information mapping blocks to one or multiple locations.
 *
 * A change request can update multiple locations in a collection at a time, which is
 * helpful if you want to move one or more CIDR blocks from one location to another in one
 * transaction, without downtime.
 *
 * **Limits**
 *
 * The max number of CIDR blocks included in the request is 1000. As a result, big updates
 * require multiple API calls.
 *
 * ** PUT and DELETE_IF_EXISTS**
 *
 * Use `ChangeCidrCollection` to perform the following actions:
 *
 * - `PUT`: Create a CIDR block within the specified collection.
 *
 * - ` DELETE_IF_EXISTS`: Delete an existing CIDR block from the
 * collection.
 */
export declare const changeCidrCollection: API.OperationMethod<ChangeCidrCollectionRequest, ChangeCidrCollectionResponse, ChangeCidrCollectionError, Credentials | HttpClient.HttpClient>;
export type ChangeResourceRecordSetsError = InvalidChangeBatch | InvalidInput | NoSuchHealthCheck | NoSuchHostedZone | PriorRequestNotComplete | CommonErrors;
/**
 * Creates, changes, or deletes a resource record set, which contains authoritative DNS
 * information for a specified domain name or subdomain name. For example, you can use
 * `ChangeResourceRecordSets` to create a resource record set that routes
 * traffic for test.example.com to a web server that has an IP address of
 * 192.0.2.44.
 *
 * **Deleting Resource Record Sets**
 *
 * To delete a resource record set, you must specify all the same values that you
 * specified when you created it.
 *
 * **Change Batches and Transactional Changes**
 *
 * The request body must include a document with a
 * `ChangeResourceRecordSetsRequest` element. The request body contains a
 * list of change items, known as a change batch. Change batches are considered
 * transactional changes. Route 53 validates the changes in the request and then either
 * makes all or none of the changes in the change batch request. This ensures that DNS
 * routing isn't adversely affected by partial changes to the resource record sets in a
 * hosted zone.
 *
 * For example, suppose a change batch request contains two changes: it deletes the
 * `CNAME` resource record set for www.example.com and creates an alias
 * resource record set for www.example.com. If validation for both records succeeds, Route
 * 53 deletes the first resource record set and creates the second resource record set in a
 * single operation. If validation for either the `DELETE` or the
 * `CREATE` action fails, then the request is canceled, and the original
 * `CNAME` record continues to exist.
 *
 * If you try to delete the same resource record set more than once in a single
 * change batch, Route 53 returns an `InvalidChangeBatch` error.
 *
 * **Traffic Flow**
 *
 * To create resource record sets for complex routing configurations, use either the
 * traffic flow visual editor in the Route 53 console or the API actions for traffic
 * policies and traffic policy instances. Save the configuration as a traffic policy, then
 * associate the traffic policy with one or more domain names (such as example.com) or
 * subdomain names (such as www.example.com), in the same hosted zone or in multiple hosted
 * zones. You can roll back the updates if the new configuration isn't performing as
 * expected. For more information, see Using Traffic Flow to Route
 * DNS Traffic in the Amazon Route 53 Developer
 * Guide.
 *
 * **Create, Delete, and Upsert**
 *
 * Use `ChangeResourceRecordsSetsRequest` to perform the following
 * actions:
 *
 * - `CREATE`: Creates a resource record set that has the specified
 * values.
 *
 * - `DELETE`: Deletes an existing resource record set that has the
 * specified values.
 *
 * - `UPSERT`: If a resource set doesn't exist, Route 53 creates it. If a resource
 * set exists Route 53 updates it with the values in the request.
 *
 * Syntaxes for Creating, Updating, and Deleting Resource Record
 * Sets
 *
 * The syntax for a request depends on the type of resource record set that you want to
 * create, delete, or update, such as weighted, alias, or failover. The XML elements in
 * your request must appear in the order listed in the syntax.
 *
 * For an example for each type of resource record set, see "Examples."
 *
 * Don't refer to the syntax in the "Parameter Syntax" section, which includes
 * all of the elements for every kind of resource record set that you can create, delete,
 * or update by using `ChangeResourceRecordSets`.
 *
 * **Change Propagation to Route 53 DNS Servers**
 *
 * When you submit a `ChangeResourceRecordSets` request, Route 53 propagates your
 * changes to all of the Route 53 authoritative DNS servers managing the hosted zone. While
 * your changes are propagating, `GetChange` returns a status of
 * `PENDING`. When propagation is complete, `GetChange` returns a
 * status of `INSYNC`. Changes generally propagate to all Route 53 name servers
 * managing the hosted zone within 60 seconds. For more information, see GetChange.
 *
 * **Limits on ChangeResourceRecordSets Requests**
 *
 * For information about the limits on a `ChangeResourceRecordSets` request,
 * see Limits in the *Amazon Route 53 Developer Guide*.
 */
export declare const changeResourceRecordSets: API.OperationMethod<ChangeResourceRecordSetsRequest, ChangeResourceRecordSetsResponse, ChangeResourceRecordSetsError, Credentials | HttpClient.HttpClient>;
export type ChangeTagsForResourceError = InvalidInput | NoSuchHealthCheck | NoSuchHostedZone | PriorRequestNotComplete | ThrottlingException | CommonErrors;
/**
 * Adds, edits, or deletes tags for a health check or a hosted zone.
 *
 * For information about using tags for cost allocation, see Using Cost Allocation
 * Tags in the *Billing and Cost Management User Guide*.
 */
export declare const changeTagsForResource: API.OperationMethod<ChangeTagsForResourceRequest, ChangeTagsForResourceResponse, ChangeTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type CreateCidrCollectionError = CidrCollectionAlreadyExistsException | ConcurrentModification | InvalidInput | LimitsExceeded | CommonErrors;
/**
 * Creates a CIDR collection in the current Amazon Web Services account.
 */
export declare const createCidrCollection: API.OperationMethod<CreateCidrCollectionRequest, CreateCidrCollectionResponse, CreateCidrCollectionError, Credentials | HttpClient.HttpClient>;
export type CreateHealthCheckError = HealthCheckAlreadyExists | InvalidInput | TooManyHealthChecks | CommonErrors;
/**
 * Creates a new health check.
 *
 * For information about adding health checks to resource record sets, see HealthCheckId in ChangeResourceRecordSets.
 *
 * **ELB Load Balancers**
 *
 * If you're registering EC2 instances with an Elastic Load Balancing (ELB) load
 * balancer, do not create Amazon Route 53 health checks for the EC2 instances. When you
 * register an EC2 instance with a load balancer, you configure settings for an ELB health
 * check, which performs a similar function to a Route 53 health check.
 *
 * **Private Hosted Zones**
 *
 * You can associate health checks with failover resource record sets in a private hosted
 * zone. Note the following:
 *
 * - Route 53 health checkers are outside the VPC. To check the health of an
 * endpoint within a VPC by IP address, you must assign a public IP address to the
 * instance in the VPC.
 *
 * - You can configure a health checker to check the health of an external resource
 * that the instance relies on, such as a database server.
 *
 * - You can create a CloudWatch metric, associate an alarm with the metric, and
 * then create a health check that is based on the state of the alarm. For example,
 * you might create a CloudWatch metric that checks the status of the Amazon EC2
 * `StatusCheckFailed` metric, add an alarm to the metric, and then
 * create a health check that is based on the state of the alarm. For information
 * about creating CloudWatch metrics and alarms by using the CloudWatch console,
 * see the Amazon
 * CloudWatch User Guide.
 */
export declare const createHealthCheck: API.OperationMethod<CreateHealthCheckRequest, CreateHealthCheckResponse, CreateHealthCheckError, Credentials | HttpClient.HttpClient>;
export type CreateHostedZoneError = ConflictingDomainExists | DelegationSetNotAvailable | DelegationSetNotReusable | HostedZoneAlreadyExists | InvalidDomainName | InvalidInput | InvalidVPCId | NoSuchDelegationSet | TooManyHostedZones | CommonErrors;
/**
 * Creates a new public or private hosted zone. You create records in a public hosted
 * zone to define how you want to route traffic on the internet for a domain, such as
 * example.com, and its subdomains (apex.example.com, acme.example.com). You create records
 * in a private hosted zone to define how you want to route traffic for a domain and its
 * subdomains within one or more Amazon Virtual Private Clouds (Amazon VPCs).
 *
 * You can't convert a public hosted zone to a private hosted zone or vice versa.
 * Instead, you must create a new hosted zone with the same name and create new
 * resource record sets.
 *
 * For more information about charges for hosted zones, see Amazon Route 53 Pricing.
 *
 * Note the following:
 *
 * - You can't create a hosted zone for a top-level domain (TLD) such as
 * .com.
 *
 * - For public hosted zones, Route 53 automatically creates a default SOA record
 * and four NS records for the zone. For more information about SOA and NS records,
 * see NS and SOA Records
 * that Route 53 Creates for a Hosted Zone in the
 * *Amazon Route 53 Developer Guide*.
 *
 * If you want to use the same name servers for multiple public hosted zones, you
 * can optionally associate a reusable delegation set with the hosted zone. See the
 * `DelegationSetId` element.
 *
 * - If your domain is registered with a registrar other than Route 53,
 * you must update the name servers with your registrar to make Route 53 the DNS
 * service for the domain. For more information, see Migrating DNS Service
 * for an Existing Domain to Amazon Route 53 in the
 * *Amazon Route 53 Developer Guide*.
 *
 * When you submit a `CreateHostedZone` request, the initial status of the
 * hosted zone is `PENDING`. For public hosted zones, this means that the NS and
 * SOA records are not yet available on all Route 53 DNS servers. When the NS and
 * SOA records are available, the status of the zone changes to `INSYNC`.
 *
 * The `CreateHostedZone` request requires the caller to have an
 * `ec2:DescribeVpcs` permission.
 *
 * When creating private hosted zones, the Amazon VPC must belong to the same
 * partition where the hosted zone is created. A partition is a group of Amazon Web Services Regions. Each Amazon Web Services account is scoped to one
 * partition.
 *
 * The following are the supported partitions:
 *
 * - `aws` - Amazon Web Services Regions
 *
 * - `aws-cn` - China Regions
 *
 * - `aws-us-gov` - Amazon Web Services GovCloud (US) Region
 *
 * For more information, see Access Management
 * in the *Amazon Web Services General Reference*.
 */
export declare const createHostedZone: API.OperationMethod<CreateHostedZoneRequest, CreateHostedZoneResponse, CreateHostedZoneError, Credentials | HttpClient.HttpClient>;
export type CreateKeySigningKeyError = ConcurrentModification | InvalidArgument | InvalidInput | InvalidKeySigningKeyName | InvalidKeySigningKeyStatus | InvalidKMSArn | InvalidSigningStatus | KeySigningKeyAlreadyExists | NoSuchHostedZone | TooManyKeySigningKeys | CommonErrors;
/**
 * Creates a new key-signing key (KSK) associated with a hosted zone. You can only have
 * two KSKs per hosted zone.
 */
export declare const createKeySigningKey: API.OperationMethod<CreateKeySigningKeyRequest, CreateKeySigningKeyResponse, CreateKeySigningKeyError, Credentials | HttpClient.HttpClient>;
export type CreateQueryLoggingConfigError = ConcurrentModification | InsufficientCloudWatchLogsResourcePolicy | InvalidInput | NoSuchCloudWatchLogsLogGroup | NoSuchHostedZone | QueryLoggingConfigAlreadyExists | CommonErrors;
/**
 * Creates a configuration for DNS query logging. After you create a query logging
 * configuration, Amazon Route 53 begins to publish log data to an Amazon CloudWatch Logs
 * log group.
 *
 * DNS query logs contain information about the queries that Route 53 receives for a
 * specified public hosted zone, such as the following:
 *
 * - Route 53 edge location that responded to the DNS query
 *
 * - Domain or subdomain that was requested
 *
 * - DNS record type, such as A or AAAA
 *
 * - DNS response code, such as `NoError` or
 * `ServFail`
 *
 * ### Log Group and Resource Policy
 *
 * Before you create a query logging configuration, perform the following
 * operations.
 *
 * If you create a query logging configuration using the Route 53
 * console, Route 53 performs these operations automatically.
 *
 * - Create a CloudWatch Logs log group, and make note of the ARN,
 * which you specify when you create a query logging configuration.
 * Note the following:
 *
 * - You must create the log group in the us-east-1
 * region.
 *
 * - You must use the same Amazon Web Services account to create
 * the log group and the hosted zone that you want to configure
 * query logging for.
 *
 * - When you create log groups for query logging, we recommend
 * that you use a consistent prefix, for example:
 *
 * /aws/route53/hosted zone
 * name
 *
 * In the next step, you'll create a resource policy, which
 * controls access to one or more log groups and the associated
 * Amazon Web Services resources, such as Route 53 hosted
 * zones. There's a limit on the number of resource policies
 * that you can create, so we recommend that you use a
 * consistent prefix so you can use the same resource policy
 * for all the log groups that you create for query
 * logging.
 *
 * - Create a CloudWatch Logs resource policy, and give it the
 * permissions that Route 53 needs to create log streams and to send
 * query logs to log streams. You must create the CloudWatch Logs resource policy in the us-east-1
 * region. For the value of `Resource`,
 * specify the ARN for the log group that you created in the previous
 * step. To use the same resource policy for all the CloudWatch Logs
 * log groups that you created for query logging configurations,
 * replace the hosted zone name with `*`, for
 * example:
 *
 * `arn:aws:logs:us-east-1:123412341234:log-group:/aws/route53/*`
 *
 * To avoid the confused deputy problem, a security issue where an
 * entity without a permission for an action can coerce a
 * more-privileged entity to perform it, you can optionally limit the
 * permissions that a service has to a resource in a resource-based
 * policy by supplying the following values:
 *
 * - For `aws:SourceArn`, supply the hosted zone ARN
 * used in creating the query logging configuration. For
 * example, aws:SourceArn:
 * arn:aws:route53:::hostedzone/hosted zone
 * ID.
 *
 * - For `aws:SourceAccount`, supply the account ID
 * for the account that creates the query logging
 * configuration. For example,
 * `aws:SourceAccount:111111111111`.
 *
 * For more information, see The confused
 * deputy problem in the Amazon Web Services
 * IAM User Guide.
 *
 * You can't use the CloudWatch console to create or edit a
 * resource policy. You must use the CloudWatch API, one of the
 * Amazon Web Services SDKs, or the CLI.
 *
 * ### Log Streams and Edge Locations
 *
 * When Route 53 finishes creating the configuration for DNS query logging,
 * it does the following:
 *
 * - Creates a log stream for an edge location the first time that the
 * edge location responds to DNS queries for the specified hosted zone.
 * That log stream is used to log all queries that Route 53 responds to
 * for that edge location.
 *
 * - Begins to send query logs to the applicable log stream.
 *
 * The name of each log stream is in the following format:
 *
 * *hosted zone ID*\/edge location
 * code
 *
 * The edge location code is a three-letter code and an arbitrarily assigned
 * number, for example, DFW3. The three-letter code typically corresponds with
 * the International Air Transport Association airport code for an airport near
 * the edge location. (These abbreviations might change in the future.) For a
 * list of edge locations, see "The Route 53 Global Network" on the Route 53 Product Details
 * page.
 *
 * ### Queries That Are Logged
 *
 * Query logs contain only the queries that DNS resolvers forward to Route
 * 53. If a DNS resolver has already cached the response to a query (such as
 * the IP address for a load balancer for example.com), the resolver will
 * continue to return the cached response. It doesn't forward another query to
 * Route 53 until the TTL for the corresponding resource record set expires.
 * Depending on how many DNS queries are submitted for a resource record set,
 * and depending on the TTL for that resource record set, query logs might
 * contain information about only one query out of every several thousand
 * queries that are submitted to DNS. For more information about how DNS works,
 * see Routing
 * Internet Traffic to Your Website or Web Application in the
 * *Amazon Route 53 Developer Guide*.
 *
 * ### Log File Format
 *
 * For a list of the values in each query log and the format of each value,
 * see Logging DNS
 * Queries in the Amazon Route 53 Developer
 * Guide.
 *
 * ### Pricing
 *
 * For information about charges for query logs, see Amazon CloudWatch Pricing.
 *
 * ### How to Stop Logging
 *
 * If you want Route 53 to stop sending query logs to CloudWatch Logs, delete
 * the query logging configuration. For more information, see DeleteQueryLoggingConfig.
 */
export declare const createQueryLoggingConfig: API.OperationMethod<CreateQueryLoggingConfigRequest, CreateQueryLoggingConfigResponse, CreateQueryLoggingConfigError, Credentials | HttpClient.HttpClient>;
export type CreateReusableDelegationSetError = DelegationSetAlreadyCreated | DelegationSetAlreadyReusable | DelegationSetNotAvailable | HostedZoneNotFound | InvalidArgument | InvalidInput | LimitsExceeded | CommonErrors;
/**
 * Creates a delegation set (a group of four name servers) that can be reused by multiple
 * hosted zones that were created by the same Amazon Web Services account.
 *
 * You can also create a reusable delegation set that uses the four name servers that are
 * associated with an existing hosted zone. Specify the hosted zone ID in the
 * `CreateReusableDelegationSet` request.
 *
 * You can't associate a reusable delegation set with a private hosted zone.
 *
 * For information about using a reusable delegation set to configure white label name
 * servers, see Configuring White
 * Label Name Servers.
 *
 * The process for migrating existing hosted zones to use a reusable delegation set is
 * comparable to the process for configuring white label name servers. You need to perform
 * the following steps:
 *
 * - Create a reusable delegation set.
 *
 * - Recreate hosted zones, and reduce the TTL to 60 seconds or less.
 *
 * - Recreate resource record sets in the new hosted zones.
 *
 * - Change the registrar's name servers to use the name servers for the new hosted
 * zones.
 *
 * - Monitor traffic for the website or application.
 *
 * - Change TTLs back to their original values.
 *
 * If you want to migrate existing hosted zones to use a reusable delegation set, the
 * existing hosted zones can't use any of the name servers that are assigned to the
 * reusable delegation set. If one or more hosted zones do use one or more name servers
 * that are assigned to the reusable delegation set, you can do one of the
 * following:
 *
 * - For small numbers of hosted zones--up to a few hundred--it's
 * relatively easy to create reusable delegation sets until you get one that has
 * four name servers that don't overlap with any of the name servers in your hosted
 * zones.
 *
 * - For larger numbers of hosted zones, the easiest solution is to use more than
 * one reusable delegation set.
 *
 * - For larger numbers of hosted zones, you can also migrate hosted zones that
 * have overlapping name servers to hosted zones that don't have overlapping name
 * servers, then migrate the hosted zones again to use the reusable delegation
 * set.
 */
export declare const createReusableDelegationSet: API.OperationMethod<CreateReusableDelegationSetRequest, CreateReusableDelegationSetResponse, CreateReusableDelegationSetError, Credentials | HttpClient.HttpClient>;
export type CreateTrafficPolicyError = InvalidInput | InvalidTrafficPolicyDocument | TooManyTrafficPolicies | TrafficPolicyAlreadyExists | CommonErrors;
/**
 * Creates a traffic policy, which you use to create multiple DNS resource record sets
 * for one domain name (such as example.com) or one subdomain name (such as
 * www.example.com).
 */
export declare const createTrafficPolicy: API.OperationMethod<CreateTrafficPolicyRequest, CreateTrafficPolicyResponse, CreateTrafficPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateTrafficPolicyInstanceError = InvalidInput | NoSuchHostedZone | NoSuchTrafficPolicy | TooManyTrafficPolicyInstances | TrafficPolicyInstanceAlreadyExists | CommonErrors;
/**
 * Creates resource record sets in a specified hosted zone based on the settings in a
 * specified traffic policy version. In addition, `CreateTrafficPolicyInstance`
 * associates the resource record sets with a specified domain name (such as example.com)
 * or subdomain name (such as www.example.com). Amazon Route 53 responds to DNS queries for
 * the domain or subdomain name by using the resource record sets that
 * `CreateTrafficPolicyInstance` created.
 *
 * After you submit an `CreateTrafficPolicyInstance` request, there's a
 * brief delay while Amazon Route 53 creates the resource record sets that are
 * specified in the traffic policy definition.
 * Use `GetTrafficPolicyInstance` with the `id` of new traffic policy instance to confirm that the `CreateTrafficPolicyInstance`
 * request completed successfully. For more information, see the
 * `State` response element.
 */
export declare const createTrafficPolicyInstance: API.OperationMethod<CreateTrafficPolicyInstanceRequest, CreateTrafficPolicyInstanceResponse, CreateTrafficPolicyInstanceError, Credentials | HttpClient.HttpClient>;
export type CreateTrafficPolicyVersionError = ConcurrentModification | InvalidInput | InvalidTrafficPolicyDocument | NoSuchTrafficPolicy | TooManyTrafficPolicyVersionsForCurrentPolicy | CommonErrors;
/**
 * Creates a new version of an existing traffic policy. When you create a new version of
 * a traffic policy, you specify the ID of the traffic policy that you want to update and a
 * JSON-formatted document that describes the new version. You use traffic policies to
 * create multiple DNS resource record sets for one domain name (such as example.com) or
 * one subdomain name (such as www.example.com). You can create a maximum of 1000 versions
 * of a traffic policy. If you reach the limit and need to create another version, you'll
 * need to start a new traffic policy.
 */
export declare const createTrafficPolicyVersion: API.OperationMethod<CreateTrafficPolicyVersionRequest, CreateTrafficPolicyVersionResponse, CreateTrafficPolicyVersionError, Credentials | HttpClient.HttpClient>;
export type CreateVPCAssociationAuthorizationError = ConcurrentModification | InvalidInput | InvalidVPCId | NoSuchHostedZone | TooManyVPCAssociationAuthorizations | CommonErrors;
/**
 * Authorizes the Amazon Web Services account that created a specified VPC to submit an
 * `AssociateVPCWithHostedZone` request to associate the VPC with a
 * specified hosted zone that was created by a different account. To submit a
 * `CreateVPCAssociationAuthorization` request, you must use the account
 * that created the hosted zone. After you authorize the association, use the account that
 * created the VPC to submit an `AssociateVPCWithHostedZone` request.
 *
 * If you want to associate multiple VPCs that you created by using one account with
 * a hosted zone that you created by using a different account, you must submit one
 * authorization request for each VPC.
 */
export declare const createVPCAssociationAuthorization: API.OperationMethod<CreateVPCAssociationAuthorizationRequest, CreateVPCAssociationAuthorizationResponse, CreateVPCAssociationAuthorizationError, Credentials | HttpClient.HttpClient>;
export type DeactivateKeySigningKeyError = ConcurrentModification | InvalidInput | InvalidKeySigningKeyStatus | InvalidSigningStatus | KeySigningKeyInParentDSRecord | KeySigningKeyInUse | NoSuchKeySigningKey | CommonErrors;
/**
 * Deactivates a key-signing key (KSK) so that it will not be used for signing by DNSSEC.
 * This operation changes the KSK status to `INACTIVE`.
 */
export declare const deactivateKeySigningKey: API.OperationMethod<DeactivateKeySigningKeyRequest, DeactivateKeySigningKeyResponse, DeactivateKeySigningKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteCidrCollectionError = CidrCollectionInUseException | ConcurrentModification | InvalidInput | NoSuchCidrCollectionException | CommonErrors;
/**
 * Deletes a CIDR collection in the current Amazon Web Services account. The collection
 * must be empty before it can be deleted.
 */
export declare const deleteCidrCollection: API.OperationMethod<DeleteCidrCollectionRequest, DeleteCidrCollectionResponse, DeleteCidrCollectionError, Credentials | HttpClient.HttpClient>;
export type DeleteHealthCheckError = HealthCheckInUse | InvalidInput | NoSuchHealthCheck | CommonErrors;
/**
 * Deletes a health check.
 *
 * Amazon Route 53 does not prevent you from deleting a health check even if the
 * health check is associated with one or more resource record sets. If you delete a
 * health check and you don't update the associated resource record sets, the future
 * status of the health check can't be predicted and may change. This will affect the
 * routing of DNS queries for your DNS failover configuration. For more information,
 * see Replacing and Deleting Health Checks in the Amazon Route 53
 * Developer Guide.
 *
 * If you're using Cloud Map and you configured Cloud Map to create a Route 53
 * health check when you register an instance, you can't use the Route 53
 * `DeleteHealthCheck` command to delete the health check. The health check
 * is deleted automatically when you deregister the instance; there can be a delay of
 * several hours before the health check is deleted from Route 53.
 */
export declare const deleteHealthCheck: API.OperationMethod<DeleteHealthCheckRequest, DeleteHealthCheckResponse, DeleteHealthCheckError, Credentials | HttpClient.HttpClient>;
export type DeleteHostedZoneError = HostedZoneNotEmpty | InvalidDomainName | InvalidInput | NoSuchHostedZone | PriorRequestNotComplete | CommonErrors;
/**
 * Deletes a hosted zone.
 *
 * If the hosted zone was created by another service, such as Cloud Map, see
 * Deleting Public Hosted Zones That Were Created by Another Service in the
 * *Amazon Route 53 Developer Guide* for information
 * about how to delete it. (The process is the same for public and private hosted zones
 * that were created by another service.)
 *
 * If you want to keep your domain registration but you want to stop routing internet
 * traffic to your website or web application, we recommend that you delete resource record
 * sets in the hosted zone instead of deleting the hosted zone.
 *
 * If you delete a hosted zone, you can't undelete it. You must create a new hosted
 * zone and update the name servers for your domain registration, which can require up
 * to 48 hours to take effect. (If you delegated responsibility for a subdomain to a
 * hosted zone and you delete the child hosted zone, you must update the name servers
 * in the parent hosted zone.) In addition, if you delete a hosted zone, someone could
 * hijack the domain and route traffic to their own resources using your domain
 * name.
 *
 * If you want to avoid the monthly charge for the hosted zone, you can transfer DNS
 * service for the domain to a free DNS service. When you transfer DNS service, you have to
 * update the name servers for the domain registration. If the domain is registered with
 * Route 53, see UpdateDomainNameservers for information about how to replace Route 53 name servers with name servers for the new DNS service. If the domain is
 * registered with another registrar, use the method provided by the registrar to update
 * name servers for the domain registration. For more information, perform an internet
 * search on "free DNS service."
 *
 * You can delete a hosted zone only if it contains only the default SOA and NS records
 * and has DNSSEC signing disabled. If the hosted zone contains other records or has DNSSEC
 * enabled, you must delete the records and disable DNSSEC before deletion. Attempting to
 * delete a hosted zone with additional records or DNSSEC enabled returns a
 * `HostedZoneNotEmpty` error. For information about deleting records, see
 * ChangeResourceRecordSets.
 *
 * To verify that the hosted zone has been deleted, do one of the following:
 *
 * - Use the `GetHostedZone` action to request information about the
 * hosted zone.
 *
 * - Use the `ListHostedZones` action to get a list of the hosted zones
 * associated with the current Amazon Web Services account.
 */
export declare const deleteHostedZone: API.OperationMethod<DeleteHostedZoneRequest, DeleteHostedZoneResponse, DeleteHostedZoneError, Credentials | HttpClient.HttpClient>;
export type DeleteKeySigningKeyError = ConcurrentModification | InvalidInput | InvalidKeySigningKeyStatus | InvalidKMSArn | InvalidSigningStatus | NoSuchKeySigningKey | CommonErrors;
/**
 * Deletes a key-signing key (KSK). Before you can delete a KSK, you must deactivate it.
 * The KSK must be deactivated before you can delete it regardless of whether the hosted
 * zone is enabled for DNSSEC signing.
 *
 * You can use DeactivateKeySigningKey to deactivate the key before you delete it.
 *
 * Use GetDNSSEC to verify that the KSK is in an `INACTIVE`
 * status.
 */
export declare const deleteKeySigningKey: API.OperationMethod<DeleteKeySigningKeyRequest, DeleteKeySigningKeyResponse, DeleteKeySigningKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteQueryLoggingConfigError = ConcurrentModification | InvalidInput | NoSuchQueryLoggingConfig | CommonErrors;
/**
 * Deletes a configuration for DNS query logging. If you delete a configuration, Amazon
 * Route 53 stops sending query logs to CloudWatch Logs. Route 53 doesn't delete any logs
 * that are already in CloudWatch Logs.
 *
 * For more information about DNS query logs, see CreateQueryLoggingConfig.
 */
export declare const deleteQueryLoggingConfig: API.OperationMethod<DeleteQueryLoggingConfigRequest, DeleteQueryLoggingConfigResponse, DeleteQueryLoggingConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteReusableDelegationSetError = DelegationSetInUse | DelegationSetNotReusable | InvalidInput | NoSuchDelegationSet | CommonErrors;
/**
 * Deletes a reusable delegation set.
 *
 * You can delete a reusable delegation set only if it isn't associated with any
 * hosted zones.
 *
 * To verify that the reusable delegation set is not associated with any hosted zones,
 * submit a GetReusableDelegationSet request and specify the ID of the reusable
 * delegation set that you want to delete.
 */
export declare const deleteReusableDelegationSet: API.OperationMethod<DeleteReusableDelegationSetRequest, DeleteReusableDelegationSetResponse, DeleteReusableDelegationSetError, Credentials | HttpClient.HttpClient>;
export type DeleteTrafficPolicyError = ConcurrentModification | InvalidInput | NoSuchTrafficPolicy | TrafficPolicyInUse | CommonErrors;
/**
 * Deletes a traffic policy.
 *
 * When you delete a traffic policy, Route 53 sets a flag on the policy to indicate that
 * it has been deleted. However, Route 53 never fully deletes the traffic policy. Note the
 * following:
 *
 * - Deleted traffic policies aren't listed if you run ListTrafficPolicies.
 *
 * - There's no way to get a list of deleted policies.
 *
 * - If you retain the ID of the policy, you can get information about the policy,
 * including the traffic policy document, by running GetTrafficPolicy.
 */
export declare const deleteTrafficPolicy: API.OperationMethod<DeleteTrafficPolicyRequest, DeleteTrafficPolicyResponse, DeleteTrafficPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteTrafficPolicyInstanceError = InvalidInput | NoSuchTrafficPolicyInstance | PriorRequestNotComplete | CommonErrors;
/**
 * Deletes a traffic policy instance and all of the resource record sets that Amazon
 * Route 53 created when you created the instance.
 *
 * In the Route 53 console, traffic policy instances are known as policy
 * records.
 */
export declare const deleteTrafficPolicyInstance: API.OperationMethod<DeleteTrafficPolicyInstanceRequest, DeleteTrafficPolicyInstanceResponse, DeleteTrafficPolicyInstanceError, Credentials | HttpClient.HttpClient>;
export type DeleteVPCAssociationAuthorizationError = ConcurrentModification | InvalidInput | InvalidVPCId | NoSuchHostedZone | VPCAssociationAuthorizationNotFound | CommonErrors;
/**
 * Removes authorization to submit an `AssociateVPCWithHostedZone` request to
 * associate a specified VPC with a hosted zone that was created by a different account.
 * You must use the account that created the hosted zone to submit a
 * `DeleteVPCAssociationAuthorization` request.
 *
 * Sending this request only prevents the Amazon Web Services account that created the
 * VPC from associating the VPC with the Amazon Route 53 hosted zone in the future. If
 * the VPC is already associated with the hosted zone,
 * `DeleteVPCAssociationAuthorization` won't disassociate the VPC from
 * the hosted zone. If you want to delete an existing association, use
 * `DisassociateVPCFromHostedZone`.
 */
export declare const deleteVPCAssociationAuthorization: API.OperationMethod<DeleteVPCAssociationAuthorizationRequest, DeleteVPCAssociationAuthorizationResponse, DeleteVPCAssociationAuthorizationError, Credentials | HttpClient.HttpClient>;
export type DisableHostedZoneDNSSECError = ConcurrentModification | DNSSECNotFound | InvalidArgument | InvalidInput | InvalidKeySigningKeyStatus | InvalidKMSArn | KeySigningKeyInParentDSRecord | NoSuchHostedZone | CommonErrors;
/**
 * Disables DNSSEC signing in a specific hosted zone. This action does not deactivate any
 * key-signing keys (KSKs) that are active in the hosted zone.
 */
export declare const disableHostedZoneDNSSEC: API.OperationMethod<DisableHostedZoneDNSSECRequest, DisableHostedZoneDNSSECResponse, DisableHostedZoneDNSSECError, Credentials | HttpClient.HttpClient>;
export type DisassociateVPCFromHostedZoneError = InvalidInput | InvalidVPCId | LastVPCAssociation | NoSuchHostedZone | VPCAssociationNotFound | CommonErrors;
/**
 * Disassociates an Amazon Virtual Private Cloud (Amazon VPC) from an Amazon Route 53
 * private hosted zone. Note the following:
 *
 * - You can't disassociate the last Amazon VPC from a private hosted zone.
 *
 * - You can't convert a private hosted zone into a public hosted zone.
 *
 * - You can submit a `DisassociateVPCFromHostedZone` request using
 * either the account that created the hosted zone or the account that created the
 * Amazon VPC.
 *
 * - Some services, such as Cloud Map and Amazon Elastic File System
 * (Amazon EFS) automatically create hosted zones and associate VPCs with the
 * hosted zones. A service can create a hosted zone using your account or using its
 * own account. You can disassociate a VPC from a hosted zone only if the service
 * created the hosted zone using your account.
 *
 * When you run DisassociateVPCFromHostedZone, if the hosted zone has a value for
 * `OwningAccount`, you can use
 * `DisassociateVPCFromHostedZone`. If the hosted zone has a value
 * for `OwningService`, you can't use
 * `DisassociateVPCFromHostedZone`.
 *
 * When revoking access, the hosted zone and the Amazon VPC must belong to
 * the same partition. A partition is a group of Amazon Web Services Regions. Each
 * Amazon Web Services account is scoped to one partition.
 *
 * The following are the supported partitions:
 *
 * - `aws` - Amazon Web Services Regions
 *
 * - `aws-cn` - China Regions
 *
 * - `aws-us-gov` - Amazon Web Services GovCloud (US) Region
 *
 * For more information, see Access Management
 * in the *Amazon Web Services General Reference*.
 */
export declare const disassociateVPCFromHostedZone: API.OperationMethod<DisassociateVPCFromHostedZoneRequest, DisassociateVPCFromHostedZoneResponse, DisassociateVPCFromHostedZoneError, Credentials | HttpClient.HttpClient>;
export type EnableHostedZoneDNSSECError = ConcurrentModification | DNSSECNotFound | HostedZonePartiallyDelegated | InvalidArgument | InvalidInput | InvalidKeySigningKeyStatus | InvalidKMSArn | KeySigningKeyWithActiveStatusNotFound | NoSuchHostedZone | CommonErrors;
/**
 * Enables DNSSEC signing in a specific hosted zone.
 */
export declare const enableHostedZoneDNSSEC: API.OperationMethod<EnableHostedZoneDNSSECRequest, EnableHostedZoneDNSSECResponse, EnableHostedZoneDNSSECError, Credentials | HttpClient.HttpClient>;
export type GetAccountLimitError = InvalidInput | CommonErrors;
/**
 * Gets the specified limit for the current account, for example, the maximum number of
 * health checks that you can create using the account.
 *
 * For the default limit, see Limits in the
 * *Amazon Route 53 Developer Guide*. To request a higher limit,
 * open a case.
 *
 * You can also view account limits in Amazon Web Services Trusted Advisor. Sign in to
 * the Amazon Web Services Management Console and open the Trusted Advisor console at https://console.aws.amazon.com/trustedadvisor/. Then choose **Service limits** in the navigation pane.
 */
export declare const getAccountLimit: API.OperationMethod<GetAccountLimitRequest, GetAccountLimitResponse, GetAccountLimitError, Credentials | HttpClient.HttpClient>;
export type GetChangeError = InvalidInput | NoSuchChange | CommonErrors;
/**
 * Returns the current status of a change batch request. The status is one of the
 * following values:
 *
 * - `PENDING` indicates that the changes in this request have not
 * propagated to all Amazon Route 53 DNS servers managing the hosted zone. This is the initial status of all
 * change batch requests.
 *
 * - `INSYNC` indicates that the changes have propagated to all Route 53
 * DNS servers managing the hosted zone.
 */
export declare const getChange: API.OperationMethod<GetChangeRequest, GetChangeResponse, GetChangeError, Credentials | HttpClient.HttpClient>;
export type GetCheckerIpRangesError = CommonErrors;
/**
 * Route 53 does not perform authorization for this API because it retrieves information
 * that is already available to the public.
 *
 * `GetCheckerIpRanges` still works, but we recommend that you download
 * ip-ranges.json, which includes IP address ranges for all Amazon Web Services
 * services. For more information, see IP Address Ranges
 * of Amazon Route 53 Servers in the Amazon Route 53 Developer
 * Guide.
 */
export declare const getCheckerIpRanges: API.OperationMethod<GetCheckerIpRangesRequest, GetCheckerIpRangesResponse, GetCheckerIpRangesError, Credentials | HttpClient.HttpClient>;
export type GetDNSSECError = InvalidArgument | InvalidInput | NoSuchHostedZone | CommonErrors;
/**
 * Returns information about DNSSEC for a specific hosted zone, including the key-signing
 * keys (KSKs) in the hosted zone.
 */
export declare const getDNSSEC: API.OperationMethod<GetDNSSECRequest, GetDNSSECResponse, GetDNSSECError, Credentials | HttpClient.HttpClient>;
export type GetGeoLocationError = InvalidInput | NoSuchGeoLocation | CommonErrors;
/**
 * Gets information about whether a specified geographic location is supported for Amazon
 * Route 53 geolocation resource record sets.
 *
 * Route 53 does not perform authorization for this API because it retrieves information
 * that is already available to the public.
 *
 * Use the following syntax to determine whether a continent is supported for
 * geolocation:
 *
 * GET /2013-04-01/geolocation?continentcode=two-letter abbreviation for
 * a continent
 *
 * Use the following syntax to determine whether a country is supported for
 * geolocation:
 *
 * GET /2013-04-01/geolocation?countrycode=two-character country
 * code
 *
 * Use the following syntax to determine whether a subdivision of a country is supported
 * for geolocation:
 *
 * GET /2013-04-01/geolocation?countrycode=two-character country
 * code&subdivisioncode=subdivision
 * code
 */
export declare const getGeoLocation: API.OperationMethod<GetGeoLocationRequest, GetGeoLocationResponse, GetGeoLocationError, Credentials | HttpClient.HttpClient>;
export type GetHealthCheckError = IncompatibleVersion | InvalidInput | NoSuchHealthCheck | CommonErrors;
/**
 * Gets information about a specified health check.
 */
export declare const getHealthCheck: API.OperationMethod<GetHealthCheckRequest, GetHealthCheckResponse, GetHealthCheckError, Credentials | HttpClient.HttpClient>;
export type GetHealthCheckCountError = CommonErrors;
/**
 * Retrieves the number of health checks that are associated with the current Amazon Web Services account.
 */
export declare const getHealthCheckCount: API.OperationMethod<GetHealthCheckCountRequest, GetHealthCheckCountResponse, GetHealthCheckCountError, Credentials | HttpClient.HttpClient>;
export type GetHealthCheckLastFailureReasonError = InvalidInput | NoSuchHealthCheck | CommonErrors;
/**
 * Gets the reason that a specified health check failed most recently.
 */
export declare const getHealthCheckLastFailureReason: API.OperationMethod<GetHealthCheckLastFailureReasonRequest, GetHealthCheckLastFailureReasonResponse, GetHealthCheckLastFailureReasonError, Credentials | HttpClient.HttpClient>;
export type GetHealthCheckStatusError = InvalidInput | NoSuchHealthCheck | CommonErrors;
/**
 * Gets status of a specified health check.
 *
 * This API is intended for use during development to diagnose behavior. It doesn't
 * support production use-cases with high query rates that require immediate and
 * actionable responses.
 */
export declare const getHealthCheckStatus: API.OperationMethod<GetHealthCheckStatusRequest, GetHealthCheckStatusResponse, GetHealthCheckStatusError, Credentials | HttpClient.HttpClient>;
export type GetHostedZoneError = InvalidInput | NoSuchHostedZone | CommonErrors;
/**
 * Gets information about a specified hosted zone including the four name servers
 * assigned to the hosted zone.
 *
 * `` returns the VPCs associated with the specified hosted zone and does not reflect the VPC
 * associations by Route 53 Profiles. To get the associations to a Profile, call the ListProfileAssociations API.
 */
export declare const getHostedZone: API.OperationMethod<GetHostedZoneRequest, GetHostedZoneResponse, GetHostedZoneError, Credentials | HttpClient.HttpClient>;
export type GetHostedZoneCountError = InvalidInput | CommonErrors;
/**
 * Retrieves the number of hosted zones that are associated with the current Amazon Web Services account.
 */
export declare const getHostedZoneCount: API.OperationMethod<GetHostedZoneCountRequest, GetHostedZoneCountResponse, GetHostedZoneCountError, Credentials | HttpClient.HttpClient>;
export type GetHostedZoneLimitError = HostedZoneNotPrivate | InvalidInput | NoSuchHostedZone | CommonErrors;
/**
 * Gets the specified limit for a specified hosted zone, for example, the maximum number
 * of records that you can create in the hosted zone.
 *
 * For the default limit, see Limits in the
 * *Amazon Route 53 Developer Guide*. To request a higher limit,
 * open a case.
 */
export declare const getHostedZoneLimit: API.OperationMethod<GetHostedZoneLimitRequest, GetHostedZoneLimitResponse, GetHostedZoneLimitError, Credentials | HttpClient.HttpClient>;
export type GetQueryLoggingConfigError = InvalidInput | NoSuchQueryLoggingConfig | CommonErrors;
/**
 * Gets information about a specified configuration for DNS query logging.
 *
 * For more information about DNS query logs, see CreateQueryLoggingConfig and Logging DNS
 * Queries.
 */
export declare const getQueryLoggingConfig: API.OperationMethod<GetQueryLoggingConfigRequest, GetQueryLoggingConfigResponse, GetQueryLoggingConfigError, Credentials | HttpClient.HttpClient>;
export type GetReusableDelegationSetError = DelegationSetNotReusable | InvalidInput | NoSuchDelegationSet | CommonErrors;
/**
 * Retrieves information about a specified reusable delegation set, including the four
 * name servers that are assigned to the delegation set.
 */
export declare const getReusableDelegationSet: API.OperationMethod<GetReusableDelegationSetRequest, GetReusableDelegationSetResponse, GetReusableDelegationSetError, Credentials | HttpClient.HttpClient>;
export type GetReusableDelegationSetLimitError = InvalidInput | NoSuchDelegationSet | CommonErrors;
/**
 * Gets the maximum number of hosted zones that you can associate with the specified
 * reusable delegation set.
 *
 * For the default limit, see Limits in the
 * *Amazon Route 53 Developer Guide*. To request a higher limit,
 * open a case.
 */
export declare const getReusableDelegationSetLimit: API.OperationMethod<GetReusableDelegationSetLimitRequest, GetReusableDelegationSetLimitResponse, GetReusableDelegationSetLimitError, Credentials | HttpClient.HttpClient>;
export type GetTrafficPolicyError = InvalidInput | NoSuchTrafficPolicy | CommonErrors;
/**
 * Gets information about a specific traffic policy version.
 *
 * For information about how of deleting a traffic policy affects the response from
 * `GetTrafficPolicy`, see DeleteTrafficPolicy.
 */
export declare const getTrafficPolicy: API.OperationMethod<GetTrafficPolicyRequest, GetTrafficPolicyResponse, GetTrafficPolicyError, Credentials | HttpClient.HttpClient>;
export type GetTrafficPolicyInstanceError = InvalidInput | NoSuchTrafficPolicyInstance | CommonErrors;
/**
 * Gets information about a specified traffic policy instance.
 *
 * Use `GetTrafficPolicyInstance` with the `id` of new traffic policy instance to confirm that the
 * `CreateTrafficPolicyInstance` or an `UpdateTrafficPolicyInstance` request completed successfully.
 * For more information, see the `State` response
 * element.
 *
 * In the Route 53 console, traffic policy instances are known as policy
 * records.
 */
export declare const getTrafficPolicyInstance: API.OperationMethod<GetTrafficPolicyInstanceRequest, GetTrafficPolicyInstanceResponse, GetTrafficPolicyInstanceError, Credentials | HttpClient.HttpClient>;
export type GetTrafficPolicyInstanceCountError = CommonErrors;
/**
 * Gets the number of traffic policy instances that are associated with the current
 * Amazon Web Services account.
 */
export declare const getTrafficPolicyInstanceCount: API.OperationMethod<GetTrafficPolicyInstanceCountRequest, GetTrafficPolicyInstanceCountResponse, GetTrafficPolicyInstanceCountError, Credentials | HttpClient.HttpClient>;
export type ListCidrBlocksError = InvalidInput | NoSuchCidrCollectionException | NoSuchCidrLocationException | CommonErrors;
/**
 * Returns a paginated list of location objects and their CIDR blocks.
 */
export declare const listCidrBlocks: API.PaginatedOperationMethod<ListCidrBlocksRequest, ListCidrBlocksResponse, ListCidrBlocksError, Credentials | HttpClient.HttpClient, CidrBlockSummary>;
export type ListCidrCollectionsError = InvalidInput | CommonErrors;
/**
 * Returns a paginated list of CIDR collections in the Amazon Web Services account
 * (metadata only).
 */
export declare const listCidrCollections: API.PaginatedOperationMethod<ListCidrCollectionsRequest, ListCidrCollectionsResponse, ListCidrCollectionsError, Credentials | HttpClient.HttpClient, CollectionSummary>;
export type ListCidrLocationsError = InvalidInput | NoSuchCidrCollectionException | CommonErrors;
/**
 * Returns a paginated list of CIDR locations for the given collection (metadata only,
 * does not include CIDR blocks).
 */
export declare const listCidrLocations: API.PaginatedOperationMethod<ListCidrLocationsRequest, ListCidrLocationsResponse, ListCidrLocationsError, Credentials | HttpClient.HttpClient, LocationSummary>;
export type ListGeoLocationsError = InvalidInput | CommonErrors;
/**
 * Retrieves a list of supported geographic locations.
 *
 * Countries are listed first, and continents are listed last. If Amazon Route 53
 * supports subdivisions for a country (for example, states or provinces), the subdivisions
 * for that country are listed in alphabetical order immediately after the corresponding
 * country.
 *
 * Route 53 does not perform authorization for this API because it retrieves information
 * that is already available to the public.
 *
 * For a list of supported geolocation codes, see the GeoLocation data
 * type.
 */
export declare const listGeoLocations: API.OperationMethod<ListGeoLocationsRequest, ListGeoLocationsResponse, ListGeoLocationsError, Credentials | HttpClient.HttpClient>;
export type ListHealthChecksError = IncompatibleVersion | InvalidInput | CommonErrors;
/**
 * Retrieve a list of the health checks that are associated with the current Amazon Web Services account.
 */
export declare const listHealthChecks: API.PaginatedOperationMethod<ListHealthChecksRequest, ListHealthChecksResponse, ListHealthChecksError, Credentials | HttpClient.HttpClient, HealthCheck>;
export type ListHostedZonesError = DelegationSetNotReusable | InvalidInput | NoSuchDelegationSet | CommonErrors;
/**
 * Retrieves a list of the public and private hosted zones that are associated with the
 * current Amazon Web Services account. The response includes a `HostedZones`
 * child element for each hosted zone.
 *
 * Amazon Route 53 returns a maximum of 100 items in each response. If you have a lot of
 * hosted zones, you can use the `maxitems` parameter to list them in groups of
 * up to 100.
 */
export declare const listHostedZones: API.PaginatedOperationMethod<ListHostedZonesRequest, ListHostedZonesResponse, ListHostedZonesError, Credentials | HttpClient.HttpClient, HostedZone>;
export type ListHostedZonesByNameError = InvalidDomainName | InvalidInput | CommonErrors;
/**
 * Retrieves a list of your hosted zones in lexicographic order. The response includes a
 * `HostedZones` child element for each hosted zone created by the current
 * Amazon Web Services account.
 *
 * `ListHostedZonesByName` sorts hosted zones by name with the labels
 * reversed. For example:
 *
 * `com.example.www.`
 *
 * Note the trailing dot, which can change the sort order in some circumstances.
 *
 * If the domain name includes escape characters or Punycode,
 * `ListHostedZonesByName` alphabetizes the domain name using the escaped or
 * Punycoded value, which is the format that Amazon Route 53 saves in its database. For
 * example, to create a hosted zone for exämple.com, you specify ex\344mple.com for
 * the domain name. `ListHostedZonesByName` alphabetizes it as:
 *
 * `com.ex\344mple.`
 *
 * The labels are reversed and alphabetized using the escaped value. For more information
 * about valid domain name formats, including internationalized domain names, see DNS
 * Domain Name Format in the Amazon Route 53 Developer
 * Guide.
 *
 * Route 53 returns up to 100 items in each response. If you have a lot of hosted zones,
 * use the `MaxItems` parameter to list them in groups of up to 100. The
 * response includes values that help navigate from one group of `MaxItems`
 * hosted zones to the next:
 *
 * - The `DNSName` and `HostedZoneId` elements in the
 * response contain the values, if any, specified for the `dnsname` and
 * `hostedzoneid` parameters in the request that produced the
 * current response.
 *
 * - The `MaxItems` element in the response contains the value, if any,
 * that you specified for the `maxitems` parameter in the request that
 * produced the current response.
 *
 * - If the value of `IsTruncated` in the response is true, there are
 * more hosted zones associated with the current Amazon Web Services account.
 *
 * If `IsTruncated` is false, this response includes the last hosted
 * zone that is associated with the current account. The `NextDNSName`
 * element and `NextHostedZoneId` elements are omitted from the
 * response.
 *
 * - The `NextDNSName` and `NextHostedZoneId` elements in the
 * response contain the domain name and the hosted zone ID of the next hosted zone
 * that is associated with the current Amazon Web Services account. If you want to
 * list more hosted zones, make another call to `ListHostedZonesByName`,
 * and specify the value of `NextDNSName` and
 * `NextHostedZoneId` in the `dnsname` and
 * `hostedzoneid` parameters, respectively.
 */
export declare const listHostedZonesByName: API.OperationMethod<ListHostedZonesByNameRequest, ListHostedZonesByNameResponse, ListHostedZonesByNameError, Credentials | HttpClient.HttpClient>;
export type ListHostedZonesByVPCError = InvalidInput | InvalidPaginationToken | CommonErrors;
/**
 * Lists all the private hosted zones that a specified VPC is associated with, regardless
 * of which Amazon Web Services account or Amazon Web Services service owns the hosted zones.
 * The `HostedZoneOwner` structure in the response contains one of the following
 * values:
 *
 * - An `OwningAccount` element, which contains the account number of
 * either the current Amazon Web Services account or another Amazon Web Services account. Some services, such as Cloud Map, create
 * hosted zones using the current account.
 *
 * - An `OwningService` element, which identifies the Amazon Web Services
 * service that created and owns the hosted zone. For example, if a hosted zone was
 * created by Amazon Elastic File System (Amazon EFS), the value of
 * `Owner` is `efs.amazonaws.com`.
 *
 * `ListHostedZonesByVPC` returns the hosted zones associated with the specified VPC and does not reflect the hosted zone
 * associations to VPCs via Route 53 Profiles. To get the associations to a Profile, call the ListProfileResourceAssociations API.
 *
 * When listing private hosted zones, the hosted zone and the Amazon VPC must
 * belong to the same partition where the hosted zones were created. A partition is a
 * group of Amazon Web Services Regions. Each Amazon Web Services account is scoped to
 * one partition.
 *
 * The following are the supported partitions:
 *
 * - `aws` - Amazon Web Services Regions
 *
 * - `aws-cn` - China Regions
 *
 * - `aws-us-gov` - Amazon Web Services GovCloud (US) Region
 *
 * For more information, see Access Management
 * in the *Amazon Web Services General Reference*.
 */
export declare const listHostedZonesByVPC: API.OperationMethod<ListHostedZonesByVPCRequest, ListHostedZonesByVPCResponse, ListHostedZonesByVPCError, Credentials | HttpClient.HttpClient>;
export type ListQueryLoggingConfigsError = InvalidInput | InvalidPaginationToken | NoSuchHostedZone | CommonErrors;
/**
 * Lists the configurations for DNS query logging that are associated with the current
 * Amazon Web Services account or the configuration that is associated with a specified
 * hosted zone.
 *
 * For more information about DNS query logs, see CreateQueryLoggingConfig. Additional information, including the format of
 * DNS query logs, appears in Logging DNS Queries in
 * the *Amazon Route 53 Developer Guide*.
 */
export declare const listQueryLoggingConfigs: API.PaginatedOperationMethod<ListQueryLoggingConfigsRequest, ListQueryLoggingConfigsResponse, ListQueryLoggingConfigsError, Credentials | HttpClient.HttpClient, QueryLoggingConfig>;
export type ListResourceRecordSetsError = InvalidInput | NoSuchHostedZone | CommonErrors;
/**
 * Lists the resource record sets in a specified hosted zone.
 *
 * `ListResourceRecordSets` returns up to 300 resource record sets at a time
 * in ASCII order, beginning at a position specified by the `name` and
 * `type` elements.
 *
 * **Sort order**
 *
 * `ListResourceRecordSets` sorts results first by DNS name with the labels
 * reversed, for example:
 *
 * `com.example.www.`
 *
 * Note the trailing dot, which can change the sort order when the record name contains
 * characters that appear before `.` (decimal 46) in the ASCII table. These
 * characters include the following: `! " # $ % & ' ( ) * + , -`
 *
 * When multiple records have the same DNS name, `ListResourceRecordSets`
 * sorts results by the record type.
 *
 * **Specifying where to start listing records**
 *
 * You can use the name and type elements to specify the resource record set that the
 * list begins with:
 *
 * ### If you do not specify Name or Type
 *
 * The results begin with the first resource record set that the hosted zone
 * contains.
 *
 * ### If you specify Name but not Type
 *
 * The results begin with the first resource record set in the list whose
 * name is greater than or equal to `Name`.
 *
 * ### If you specify Type but not Name
 *
 * Amazon Route 53 returns the `InvalidInput` error.
 *
 * ### If you specify both Name and Type
 *
 * The results begin with the first resource record set in the list whose
 * name is greater than or equal to `Name`, and whose type is
 * greater than or equal to `Type`.
 *
 * Type is only used to sort between records with the same record Name.
 *
 * **Resource record sets that are PENDING**
 *
 * This action returns the most current version of the records. This includes records
 * that are `PENDING`, and that are not yet available on all Route 53 DNS
 * servers.
 *
 * **Changing resource record sets**
 *
 * To ensure that you get an accurate listing of the resource record sets for a hosted
 * zone at a point in time, do not submit a `ChangeResourceRecordSets` request
 * while you're paging through the results of a `ListResourceRecordSets`
 * request. If you do, some pages may display results without the latest changes while
 * other pages display results with the latest changes.
 *
 * **Displaying the next page of results**
 *
 * If a `ListResourceRecordSets` command returns more than one page of
 * results, the value of `IsTruncated` is `true`. To display the next
 * page of results, get the values of `NextRecordName`,
 * `NextRecordType`, and `NextRecordIdentifier` (if any) from the
 * response. Then submit another `ListResourceRecordSets` request, and specify
 * those values for `StartRecordName`, `StartRecordType`, and
 * `StartRecordIdentifier`.
 */
export declare const listResourceRecordSets: API.OperationMethod<ListResourceRecordSetsRequest, ListResourceRecordSetsResponse, ListResourceRecordSetsError, Credentials | HttpClient.HttpClient>;
export type ListReusableDelegationSetsError = InvalidInput | CommonErrors;
/**
 * Retrieves a list of the reusable delegation sets that are associated with the current
 * Amazon Web Services account.
 */
export declare const listReusableDelegationSets: API.OperationMethod<ListReusableDelegationSetsRequest, ListReusableDelegationSetsResponse, ListReusableDelegationSetsError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InvalidInput | NoSuchHealthCheck | NoSuchHostedZone | PriorRequestNotComplete | ThrottlingException | CommonErrors;
/**
 * Lists tags for one health check or hosted zone.
 *
 * For information about using tags for cost allocation, see Using Cost Allocation
 * Tags in the *Billing and Cost Management User Guide*.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourcesError = InvalidInput | NoSuchHealthCheck | NoSuchHostedZone | PriorRequestNotComplete | ThrottlingException | CommonErrors;
/**
 * Lists tags for up to 10 health checks or hosted zones.
 *
 * For information about using tags for cost allocation, see Using Cost Allocation
 * Tags in the *Billing and Cost Management User Guide*.
 */
export declare const listTagsForResources: API.OperationMethod<ListTagsForResourcesRequest, ListTagsForResourcesResponse, ListTagsForResourcesError, Credentials | HttpClient.HttpClient>;
export type ListTrafficPoliciesError = InvalidInput | CommonErrors;
/**
 * Gets information about the latest version for every traffic policy that is associated
 * with the current Amazon Web Services account. Policies are listed in the order that they
 * were created in.
 *
 * For information about how of deleting a traffic policy affects the response from
 * `ListTrafficPolicies`, see DeleteTrafficPolicy.
 */
export declare const listTrafficPolicies: API.OperationMethod<ListTrafficPoliciesRequest, ListTrafficPoliciesResponse, ListTrafficPoliciesError, Credentials | HttpClient.HttpClient>;
export type ListTrafficPolicyInstancesError = InvalidInput | NoSuchTrafficPolicyInstance | CommonErrors;
/**
 * Gets information about the traffic policy instances that you created by using the
 * current Amazon Web Services account.
 *
 * After you submit an `UpdateTrafficPolicyInstance` request, there's a
 * brief delay while Amazon Route 53 creates the resource record sets that are
 * specified in the traffic policy definition. For more information, see the
 * `State` response element.
 *
 * Route 53 returns a maximum of 100 items in each response. If you have a lot of traffic
 * policy instances, you can use the `MaxItems` parameter to list them in groups
 * of up to 100.
 */
export declare const listTrafficPolicyInstances: API.OperationMethod<ListTrafficPolicyInstancesRequest, ListTrafficPolicyInstancesResponse, ListTrafficPolicyInstancesError, Credentials | HttpClient.HttpClient>;
export type ListTrafficPolicyInstancesByHostedZoneError = InvalidInput | NoSuchHostedZone | NoSuchTrafficPolicyInstance | CommonErrors;
/**
 * Gets information about the traffic policy instances that you created in a specified
 * hosted zone.
 *
 * After you submit a `CreateTrafficPolicyInstance` or an
 * `UpdateTrafficPolicyInstance` request, there's a brief delay while
 * Amazon Route 53 creates the resource record sets that are specified in the traffic
 * policy definition. For more information, see the `State` response
 * element.
 *
 * Route 53 returns a maximum of 100 items in each response. If you have a lot of traffic
 * policy instances, you can use the `MaxItems` parameter to list them in groups
 * of up to 100.
 */
export declare const listTrafficPolicyInstancesByHostedZone: API.OperationMethod<ListTrafficPolicyInstancesByHostedZoneRequest, ListTrafficPolicyInstancesByHostedZoneResponse, ListTrafficPolicyInstancesByHostedZoneError, Credentials | HttpClient.HttpClient>;
export type ListTrafficPolicyInstancesByPolicyError = InvalidInput | NoSuchTrafficPolicy | NoSuchTrafficPolicyInstance | CommonErrors;
/**
 * Gets information about the traffic policy instances that you created by using a
 * specify traffic policy version.
 *
 * After you submit a `CreateTrafficPolicyInstance` or an
 * `UpdateTrafficPolicyInstance` request, there's a brief delay while
 * Amazon Route 53 creates the resource record sets that are specified in the traffic
 * policy definition. For more information, see the `State` response
 * element.
 *
 * Route 53 returns a maximum of 100 items in each response. If you have a lot of traffic
 * policy instances, you can use the `MaxItems` parameter to list them in groups
 * of up to 100.
 */
export declare const listTrafficPolicyInstancesByPolicy: API.OperationMethod<ListTrafficPolicyInstancesByPolicyRequest, ListTrafficPolicyInstancesByPolicyResponse, ListTrafficPolicyInstancesByPolicyError, Credentials | HttpClient.HttpClient>;
export type ListTrafficPolicyVersionsError = InvalidInput | NoSuchTrafficPolicy | CommonErrors;
/**
 * Gets information about all of the versions for a specified traffic policy.
 *
 * Traffic policy versions are listed in numerical order by
 * `VersionNumber`.
 */
export declare const listTrafficPolicyVersions: API.OperationMethod<ListTrafficPolicyVersionsRequest, ListTrafficPolicyVersionsResponse, ListTrafficPolicyVersionsError, Credentials | HttpClient.HttpClient>;
export type ListVPCAssociationAuthorizationsError = InvalidInput | InvalidPaginationToken | NoSuchHostedZone | CommonErrors;
/**
 * Gets a list of the VPCs that were created by other accounts and that can be associated
 * with a specified hosted zone because you've submitted one or more
 * `CreateVPCAssociationAuthorization` requests.
 *
 * The response includes a `VPCs` element with a `VPC` child
 * element for each VPC that can be associated with the hosted zone.
 */
export declare const listVPCAssociationAuthorizations: API.OperationMethod<ListVPCAssociationAuthorizationsRequest, ListVPCAssociationAuthorizationsResponse, ListVPCAssociationAuthorizationsError, Credentials | HttpClient.HttpClient>;
export type TestDNSAnswerError = InvalidInput | NoSuchHostedZone | CommonErrors;
/**
 * Gets the value that Amazon Route 53 returns in response to a DNS request for a
 * specified record name and type. You can optionally specify the IP address of a DNS
 * resolver, an EDNS0 client subnet IP address, and a subnet mask.
 *
 * This call only supports querying public hosted zones.
 *
 * The `TestDnsAnswer ` returns information similar to what you would expect from the answer
 * section of the `dig` command. Therefore, if you query for the name
 * servers of a subdomain that point to the parent name servers, those will not be
 * returned.
 */
export declare const testDNSAnswer: API.OperationMethod<TestDNSAnswerRequest, TestDNSAnswerResponse, TestDNSAnswerError, Credentials | HttpClient.HttpClient>;
export type UpdateHealthCheckError = HealthCheckVersionMismatch | InvalidInput | NoSuchHealthCheck | CommonErrors;
/**
 * Updates an existing health check. Note that some values can't be updated.
 *
 * For more information about updating health checks, see Creating,
 * Updating, and Deleting Health Checks in the Amazon Route 53
 * Developer Guide.
 */
export declare const updateHealthCheck: API.OperationMethod<UpdateHealthCheckRequest, UpdateHealthCheckResponse, UpdateHealthCheckError, Credentials | HttpClient.HttpClient>;
export type UpdateHostedZoneCommentError = InvalidInput | NoSuchHostedZone | PriorRequestNotComplete | CommonErrors;
/**
 * Updates the comment for a specified hosted zone.
 */
export declare const updateHostedZoneComment: API.OperationMethod<UpdateHostedZoneCommentRequest, UpdateHostedZoneCommentResponse, UpdateHostedZoneCommentError, Credentials | HttpClient.HttpClient>;
export type UpdateHostedZoneFeaturesError = InvalidInput | LimitsExceeded | NoSuchHostedZone | PriorRequestNotComplete | CommonErrors;
/**
 * Updates the features configuration for a hosted zone. This operation allows you to enable or disable specific features for your hosted zone, such as accelerated recovery.
 *
 * Accelerated recovery enables you to update DNS records in your public hosted zone even when the us-east-1 region is unavailable.
 */
export declare const updateHostedZoneFeatures: API.OperationMethod<UpdateHostedZoneFeaturesRequest, UpdateHostedZoneFeaturesResponse, UpdateHostedZoneFeaturesError, Credentials | HttpClient.HttpClient>;
export type UpdateTrafficPolicyCommentError = ConcurrentModification | InvalidInput | NoSuchTrafficPolicy | CommonErrors;
/**
 * Updates the comment for a specified traffic policy version.
 */
export declare const updateTrafficPolicyComment: API.OperationMethod<UpdateTrafficPolicyCommentRequest, UpdateTrafficPolicyCommentResponse, UpdateTrafficPolicyCommentError, Credentials | HttpClient.HttpClient>;
export type UpdateTrafficPolicyInstanceError = ConflictingTypes | InvalidInput | NoSuchTrafficPolicy | NoSuchTrafficPolicyInstance | PriorRequestNotComplete | CommonErrors;
/**
 * After you submit a `UpdateTrafficPolicyInstance` request, there's a brief delay while Route 53 creates the resource record sets
 * that are specified in the traffic policy definition. Use `GetTrafficPolicyInstance` with the `id` of updated traffic policy instance confirm
 * that the
 * `UpdateTrafficPolicyInstance` request completed successfully. For more information, see the `State` response element.
 *
 * Updates the resource record sets in a specified hosted zone that were created based on
 * the settings in a specified traffic policy version.
 *
 * When you update a traffic policy instance, Amazon Route 53 continues to respond to DNS
 * queries for the root resource record set name (such as example.com) while it replaces
 * one group of resource record sets with another. Route 53 performs the following
 * operations:
 *
 * - Route 53 creates a new group of resource record sets based on the specified
 * traffic policy. This is true regardless of how significant the differences are
 * between the existing resource record sets and the new resource record sets.
 *
 * - When all of the new resource record sets have been created, Route 53 starts to
 * respond to DNS queries for the root resource record set name (such as
 * example.com) by using the new resource record sets.
 *
 * - Route 53 deletes the old group of resource record sets that are associated
 * with the root resource record set name.
 */
export declare const updateTrafficPolicyInstance: API.OperationMethod<UpdateTrafficPolicyInstanceRequest, UpdateTrafficPolicyInstanceResponse, UpdateTrafficPolicyInstanceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=route-53.d.ts.map