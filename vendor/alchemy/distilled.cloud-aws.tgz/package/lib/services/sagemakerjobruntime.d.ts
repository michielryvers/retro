import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import * as T from "../traits.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServiceError_base: S.TaggedErrorClass<"InternalServiceError", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServiceError extends /*@__PURE__*/ InternalServiceError_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type JobArn = string;
export type TrajectoryId = string;
export type CompletionStatus = "ready" | "failed" | (string & {});
export interface CompleteRolloutRequest {
    JobArn: string;
    TrajectoryId: string;
    Status?: CompletionStatus;
    ClientToken?: string;
}
export interface CompleteRolloutResponse {
}
export interface SampleRequest {
    JobArn: string;
    TrajectoryId: string;
    Body: T.StreamingInputBody;
}
export interface SampleResponse {
    ContentType?: string;
    Body: T.StreamingOutputBody;
}
export interface SampleWithResponseStreamRequest {
    JobArn: string;
    TrajectoryId: string;
    Body: T.StreamingInputBody;
}
export interface SampleWithResponseStreamResponse {
    ContentType?: string;
    Body: T.StreamingOutputBody;
}
export type DoubleList = number[];
export interface UpdateRewardRequest {
    JobArn: string;
    TrajectoryId: string;
    Rewards: number[];
    ClientToken?: string;
}
export interface UpdateRewardResponse {
}
export type FailureReason = string;
export type CompleteRolloutError = AccessDeniedException | ConflictException | InternalServiceError | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Marks a rollout as complete, indicating that no further turns will be appended
 * to the trajectory. After calling this operation, the trajectory is sealed and
 * eligible for reward submission via the UpdateReward operation.
 */
export declare const completeRollout: API.OperationMethod<CompleteRolloutRequest, CompleteRolloutResponse, CompleteRolloutError, Credentials | HttpClient.HttpClient>;
export type SampleError = AccessDeniedException | InternalServiceError | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends an inference request to the model during a job execution. The request
 * and response bodies are forwarded to and from the model without modification.
 * Each turn (prompt and response) is captured for later use.
 */
export declare const sample: API.OperationMethod<SampleRequest, SampleResponse, SampleError, Credentials | HttpClient.HttpClient>;
export type SampleWithResponseStreamError = AccessDeniedException | InternalServiceError | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends a streaming inference request to the model during a job execution.
 * Returns the response as a stream of payload chunks. Each turn is captured
 * for later use.
 */
export declare const sampleWithResponseStream: API.OperationMethod<SampleWithResponseStreamRequest, SampleWithResponseStreamResponse, SampleWithResponseStreamError, Credentials | HttpClient.HttpClient>;
export type UpdateRewardError = AccessDeniedException | ConflictException | InternalServiceError | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the reward values for a trajectory and transitions it to
 * reward-received status, signaling that it is eligible for processing. Call this
 * operation after CompleteRollout to provide the computed reward scores.
 */
export declare const updateReward: API.OperationMethod<UpdateRewardRequest, UpdateRewardResponse, UpdateRewardError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=sagemakerjobruntime.d.ts.map