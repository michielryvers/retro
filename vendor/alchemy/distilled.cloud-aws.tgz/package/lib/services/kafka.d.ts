import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ClusterConnectivityException_base: S.TaggedErrorClass<"ClusterConnectivityException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ClusterConnectivityException extends /*@__PURE__*/ ClusterConnectivityException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ControllerMovedException_base: S.TaggedErrorClass<"ControllerMovedException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ControllerMovedException extends /*@__PURE__*/ ControllerMovedException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const GroupSubscribedToTopicException_base: S.TaggedErrorClass<"GroupSubscribedToTopicException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class GroupSubscribedToTopicException extends /*@__PURE__*/ GroupSubscribedToTopicException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const KafkaRequestException_base: S.TaggedErrorClass<"KafkaRequestException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KafkaRequestException extends /*@__PURE__*/ KafkaRequestException_base {
}
declare const KafkaTimeoutException_base: S.TaggedErrorClass<"KafkaTimeoutException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class KafkaTimeoutException extends /*@__PURE__*/ KafkaTimeoutException_base {
}
declare const NotControllerException_base: S.TaggedErrorClass<"NotControllerException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class NotControllerException extends /*@__PURE__*/ NotControllerException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ReassignmentInProgressException_base: S.TaggedErrorClass<"ReassignmentInProgressException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ReassignmentInProgressException extends /*@__PURE__*/ ReassignmentInProgressException_base {
}
declare const ServerlessUnsupported_base: S.TaggedErrorClass<"ServerlessUnsupported", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServerlessUnsupported extends /*@__PURE__*/ ServerlessUnsupported_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const TopicExistsException_base: S.TaggedErrorClass<"TopicExistsException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class TopicExistsException extends /*@__PURE__*/ TopicExistsException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const UnknownTopicOrPartitionException_base: S.TaggedErrorClass<"UnknownTopicOrPartitionException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnknownTopicOrPartitionException extends /*@__PURE__*/ UnknownTopicOrPartitionException_base {
}
export type __listOf__string = string[];
export interface BatchAssociateScramSecretRequest {
    ClusterArn: string;
    SecretArnList?: string[];
}
export interface UnprocessedScramSecret {
    ErrorCode?: string;
    ErrorMessage?: string;
    SecretArn?: string;
}
export type __listOfUnprocessedScramSecret = UnprocessedScramSecret[];
export interface BatchAssociateScramSecretResponse {
    ClusterArn?: string;
    UnprocessedScramSecrets?: UnprocessedScramSecret[];
}
export interface BatchDisassociateScramSecretRequest {
    ClusterArn: string;
    SecretArnList?: string[];
}
export interface BatchDisassociateScramSecretResponse {
    ClusterArn?: string;
    UnprocessedScramSecrets?: UnprocessedScramSecret[];
}
export interface EncryptionConfiguration {
    KmsKeyArn?: string;
}
export interface Catalog {
    CatalogArn?: string;
    WarehouseLocation?: string;
}
export interface DeadLetterQueueS3 {
    BucketArn?: string;
    ErrorOutputPrefix?: string;
    ExpectedBucketOwner?: string;
}
export type PartitionStrategy = "TIME_HOUR" | (string & {});
export interface PartitionSource {
    SourceName?: string;
}
export type __listOfPartitionSource = PartitionSource[];
export interface PartitionSpec {
    PartitionStrategy?: PartitionStrategy;
    SourceList?: PartitionSource[];
}
export interface DestinationTable {
    DestinationDatabaseName?: string;
    DestinationTableName?: string;
    PartitionSpec?: PartitionSpec;
}
export type __listOfDestinationTable = DestinationTable[];
export interface SchemaEvolution {
    EnableSchemaEvolution?: boolean;
}
export interface TableCreation {
    EnableTableCreation?: boolean;
}
export type IcebergCompressionType = "ZSTD" | "SNAPPY" | (string & {});
export interface IcebergDestinationConfiguration {
    AppendOnly?: boolean;
    Catalog?: Catalog;
    DataFreshnessInSeconds?: number;
    DeadLetterQueueS3?: DeadLetterQueueS3;
    DestinationTableList?: DestinationTable[];
    SchemaEvolution?: SchemaEvolution;
    ServiceExecutionRoleArn?: string;
    TableCreation?: TableCreation;
    CompressionType?: IcebergCompressionType;
}
export type S3CompressionType = "NONE" | "GZIP" | "ZSTD" | (string & {});
export type S3StorageClass = "STANDARD" | "INTELLIGENT_TIERING" | "GLACIER_IR" | (string & {});
export interface S3Storage {
    BucketArn?: string;
    CompressionType?: S3CompressionType;
    OutputPrefix?: string;
    OutputKeyTemplate?: string;
    StorageClass?: S3StorageClass;
    ExpectedBucketOwner?: string;
}
export interface S3DestinationConfiguration {
    DataFreshnessInSeconds?: number;
    DeadLetterQueueS3?: DeadLetterQueueS3;
    ServiceExecutionRoleArn?: string;
    Storage?: S3Storage;
}
export type __mapOf__string = {
    [key: string]: string | undefined;
};
export type ValueConverter = "BYTE_ARRAY" | "JSON" | "JSON_SCHEMA_GSR" | "STRING" | (string & {});
export interface RecordConverter {
    ValueConverter?: ValueConverter;
}
export interface RecordSchema {
    GsrArn?: string;
}
export interface TopicConfiguration {
    RecordConverter?: RecordConverter;
    RecordSchema?: RecordSchema;
    TopicArn?: string;
}
export type __listOfTopicConfiguration = TopicConfiguration[];
export interface CloudWatchLogs {
    Enabled?: boolean;
    LogGroup?: string;
}
export interface Firehose {
    DeliveryStream?: string;
    Enabled?: boolean;
}
export interface S3 {
    Bucket?: string;
    Enabled?: boolean;
    Prefix?: string;
}
export interface ChannelLoggingInfo {
    CloudWatchLogs?: CloudWatchLogs;
    Firehose?: Firehose;
    S3?: S3;
}
export interface CreateChannelRequest {
    ChannelName?: string;
    ClusterArn: string;
    EncryptionConfiguration?: EncryptionConfiguration;
    IcebergDestinationConfiguration?: IcebergDestinationConfiguration;
    S3DestinationConfiguration?: S3DestinationConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    };
    TopicConfigurationList?: TopicConfiguration[];
    LoggingInfo?: ChannelLoggingInfo;
}
export interface CreateChannelResponse {
    ChannelArn: string;
    ClusterOperationArn?: string;
}
export type BrokerAZDistribution = "DEFAULT" | (string & {});
export type __stringMin5Max32 = string;
export interface ProvisionedThroughput {
    Enabled?: boolean;
    VolumeThroughput?: number;
}
export type __integerMin1Max16384 = number;
export interface EBSStorageInfo {
    ProvisionedThroughput?: ProvisionedThroughput;
    VolumeSize?: number;
}
export interface StorageInfo {
    EbsStorageInfo?: EBSStorageInfo;
}
export interface PublicAccess {
    Type?: string;
}
export interface VpcConnectivityScram {
    Enabled?: boolean;
}
export interface VpcConnectivityIam {
    Enabled?: boolean;
}
export interface VpcConnectivitySasl {
    Scram?: VpcConnectivityScram;
    Iam?: VpcConnectivityIam;
}
export interface VpcConnectivityTls {
    Enabled?: boolean;
}
export interface VpcConnectivityClientAuthentication {
    Sasl?: VpcConnectivitySasl;
    Tls?: VpcConnectivityTls;
}
export interface VpcConnectivity {
    ClientAuthentication?: VpcConnectivityClientAuthentication;
}
export type NetworkType = "IPV4" | "DUAL" | (string & {});
export interface ConnectivityInfo {
    PublicAccess?: PublicAccess;
    VpcConnectivity?: VpcConnectivity;
    NetworkType?: NetworkType;
}
export interface BrokerNodeGroupInfo {
    BrokerAZDistribution?: BrokerAZDistribution;
    ClientSubnets?: string[];
    InstanceType?: string;
    SecurityGroups?: string[];
    StorageInfo?: StorageInfo;
    ConnectivityInfo?: ConnectivityInfo;
    ZoneIds?: string[];
}
export type RebalancingStatus = "PAUSED" | "ACTIVE" | (string & {});
export interface Rebalancing {
    Status?: RebalancingStatus;
}
export interface Scram {
    Enabled?: boolean;
}
export interface Iam {
    Enabled?: boolean;
}
export interface Sasl {
    Scram?: Scram;
    Iam?: Iam;
}
export interface Tls {
    CertificateAuthorityArnList?: string[];
    Enabled?: boolean;
}
export interface Unauthenticated {
    Enabled?: boolean;
}
export interface ClientAuthentication {
    Sasl?: Sasl;
    Tls?: Tls;
    Unauthenticated?: Unauthenticated;
}
export type __stringMin1Max64 = string;
export interface ConfigurationInfo {
    Arn?: string;
    Revision?: number;
}
export interface EncryptionAtRest {
    DataVolumeKMSKeyId?: string;
}
export type ClientBroker = "TLS" | "TLS_PLAINTEXT" | "PLAINTEXT" | (string & {});
export interface EncryptionInTransit {
    ClientBroker?: ClientBroker;
    InCluster?: boolean;
}
export interface EncryptionInfo {
    EncryptionAtRest?: EncryptionAtRest;
    EncryptionInTransit?: EncryptionInTransit;
}
export type EnhancedMonitoring = "DEFAULT" | "PER_BROKER" | "PER_TOPIC_PER_BROKER" | "PER_TOPIC_PER_PARTITION" | (string & {});
export interface JmxExporterInfo {
    EnabledInBroker?: boolean;
}
export interface NodeExporterInfo {
    EnabledInBroker?: boolean;
}
export interface PrometheusInfo {
    JmxExporter?: JmxExporterInfo;
    NodeExporter?: NodeExporterInfo;
}
export interface OpenMonitoringInfo {
    Prometheus?: PrometheusInfo;
}
export type __stringMin1Max128 = string;
export interface AuthorizerLogs {
    CloudWatchLogs?: CloudWatchLogs;
    Firehose?: Firehose;
    S3?: S3;
}
export interface BrokerLogs {
    CloudWatchLogs?: CloudWatchLogs;
    Firehose?: Firehose;
    S3?: S3;
}
export interface LoggingInfo {
    AuthorizerLogs?: AuthorizerLogs;
    BrokerLogs?: BrokerLogs;
}
export type __integerMin1Max15 = number;
export type StorageMode = "LOCAL" | "TIERED" | (string & {});
export interface CreateClusterRequest {
    BrokerNodeGroupInfo?: BrokerNodeGroupInfo;
    Rebalancing?: Rebalancing;
    ClientAuthentication?: ClientAuthentication;
    ClusterName?: string;
    ConfigurationInfo?: ConfigurationInfo;
    EncryptionInfo?: EncryptionInfo;
    EnhancedMonitoring?: EnhancedMonitoring;
    OpenMonitoring?: OpenMonitoringInfo;
    KafkaVersion?: string;
    LoggingInfo?: LoggingInfo;
    NumberOfBrokerNodes?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
    StorageMode?: StorageMode;
}
export type ClusterState = "ACTIVE" | "CREATING" | "DELETING" | "FAILED" | "HEALING" | "MAINTENANCE" | "REBOOTING_BROKER" | "UPDATING" | (string & {});
export interface CreateClusterResponse {
    ClusterArn?: string;
    ClusterName?: string;
    State?: ClusterState;
}
export interface ProvisionedRequest {
    BrokerNodeGroupInfo?: BrokerNodeGroupInfo;
    Rebalancing?: Rebalancing;
    ClientAuthentication?: ClientAuthentication;
    ConfigurationInfo?: ConfigurationInfo;
    EncryptionInfo?: EncryptionInfo;
    EnhancedMonitoring?: EnhancedMonitoring;
    OpenMonitoring?: OpenMonitoringInfo;
    KafkaVersion?: string;
    LoggingInfo?: LoggingInfo;
    NumberOfBrokerNodes?: number;
    StorageMode?: StorageMode;
}
export interface VpcConfig {
    SubnetIds?: string[];
    SecurityGroupIds?: string[];
}
export type __listOfVpcConfig = VpcConfig[];
export interface ServerlessSasl {
    Iam?: Iam;
}
export interface ServerlessClientAuthentication {
    Sasl?: ServerlessSasl;
}
export interface ServerlessRequest {
    VpcConfigs?: VpcConfig[];
    ClientAuthentication?: ServerlessClientAuthentication;
}
export interface CreateClusterV2Request {
    ClusterName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Provisioned?: ProvisionedRequest;
    Serverless?: ServerlessRequest;
}
export type ClusterType = "PROVISIONED" | "SERVERLESS" | (string & {});
export interface CreateClusterV2Response {
    ClusterArn?: string;
    ClusterName?: string;
    State?: ClusterState;
    ClusterType?: ClusterType;
}
export type __blob = Uint8Array;
export interface CreateConfigurationRequest {
    Description?: string;
    KafkaVersions?: string[];
    Name?: string;
    ServerProperties?: Uint8Array;
}
export type __timestampIso8601 = Date;
export interface ConfigurationRevision {
    CreationTime?: Date;
    Description?: string;
    Revision?: number;
}
export type ConfigurationState = "ACTIVE" | "DELETING" | "DELETE_FAILED" | (string & {});
export interface CreateConfigurationResponse {
    Arn?: string;
    CreationTime?: Date;
    LatestRevision?: ConfigurationRevision & {
        CreationTime: __timestampIso8601;
        Revision: number;
    };
    Name?: string;
    State?: ConfigurationState;
}
export type __stringMax1024 = string;
export interface AmazonMskCluster {
    MskClusterArn?: string;
}
export interface ApacheKafkaCluster {
    ApacheKafkaClusterId?: string;
    BootstrapBrokerString?: string;
}
export interface KafkaClusterClientVpcConfig {
    SecurityGroupIds?: string[];
    SubnetIds?: string[];
}
export type KafkaClusterSaslScramMechanism = "SHA256" | "SHA512" | (string & {});
export interface KafkaClusterSaslScramAuthentication {
    Mechanism?: KafkaClusterSaslScramMechanism;
    SecretArn?: string;
}
export interface KafkaClusterMTLSAuthentication {
    SecretArn?: string;
}
export interface KafkaClusterOAuthClientCredentials {
    TokenRequestSecretArn?: string;
}
export type JwtSigningAlgorithm = "RS256" | "ES384" | (string & {});
export interface KafkaClusterOAuthIamJwtBearer {
    Audience?: string;
    SigningAlgorithm?: JwtSigningAlgorithm;
    TokenRequestSecretArn?: string;
}
export interface KafkaClusterOAuthClientCredentialsAssertion {
    Audience?: string;
    SigningAlgorithm?: JwtSigningAlgorithm;
    TokenRequestSecretArn?: string;
}
export type TokenEndpointAuthenticationMethod = "POST" | "BASIC" | "NONE" | (string & {});
export interface KafkaClusterSaslOAuthBearerAuthentication {
    TokenEndpointUrl?: string;
    ClientCredentials?: KafkaClusterOAuthClientCredentials;
    IamJwtBearer?: KafkaClusterOAuthIamJwtBearer;
    ClientCredentialsAssertion?: KafkaClusterOAuthClientCredentialsAssertion;
    TokenEndpointAuthenticationMethod?: TokenEndpointAuthenticationMethod;
    Scope?: string;
    TokenEndpointTlsCertificateArn?: string;
}
export interface KafkaClusterClientAuthentication {
    SaslScram?: KafkaClusterSaslScramAuthentication;
    MTLS?: KafkaClusterMTLSAuthentication;
    SaslOAuthBearer?: KafkaClusterSaslOAuthBearerAuthentication;
}
export type KafkaClusterEncryptionInTransitType = "TLS" | (string & {});
export interface KafkaClusterEncryptionInTransit {
    EncryptionType?: KafkaClusterEncryptionInTransitType;
    RootCaCertificate?: string;
}
export interface KafkaCluster {
    AmazonMskCluster?: AmazonMskCluster;
    ApacheKafkaCluster?: ApacheKafkaCluster;
    VpcConfig?: KafkaClusterClientVpcConfig;
    ClientAuthentication?: KafkaClusterClientAuthentication;
    EncryptionInTransit?: KafkaClusterEncryptionInTransit;
}
export type __listOfKafkaCluster = KafkaCluster[];
export type __stringMax256 = string;
export type __listOf__stringMax256 = string[];
export type ConsumerGroupOffsetSyncMode = "LEGACY" | "ENHANCED" | (string & {});
export interface ConsumerGroupReplication {
    ConsumerGroupsToExclude?: string[];
    ConsumerGroupsToReplicate?: string[];
    DetectAndCopyNewConsumerGroups?: boolean;
    SynchroniseConsumerGroupOffsets?: boolean;
    ConsumerGroupOffsetSyncMode?: ConsumerGroupOffsetSyncMode;
}
export type TargetCompressionType = "NONE" | "GZIP" | "SNAPPY" | "LZ4" | "ZSTD" | (string & {});
export type ReplicationStartingPositionType = "LATEST" | "EARLIEST" | (string & {});
export interface ReplicationStartingPosition {
    Type?: ReplicationStartingPositionType;
}
export type ReplicationTopicNameConfigurationType = "PREFIXED_WITH_SOURCE_CLUSTER_ALIAS" | "IDENTICAL" | (string & {});
export interface ReplicationTopicNameConfiguration {
    Type?: ReplicationTopicNameConfigurationType;
}
export type __stringMax249 = string;
export type __listOf__stringMax249 = string[];
export interface TopicReplication {
    CopyAccessControlListsForTopics?: boolean;
    CopyTopicConfigurations?: boolean;
    DetectAndCopyNewTopics?: boolean;
    StartingPosition?: ReplicationStartingPosition;
    TopicNameConfiguration?: ReplicationTopicNameConfiguration;
    TopicsToExclude?: string[];
    TopicsToReplicate?: string[];
}
export interface ReplicationInfo {
    ConsumerGroupReplication?: ConsumerGroupReplication;
    SourceKafkaClusterArn?: string;
    SourceKafkaClusterId?: string;
    TargetCompressionType?: TargetCompressionType;
    TargetKafkaClusterArn?: string;
    TargetKafkaClusterId?: string;
    TopicReplication?: TopicReplication;
}
export type __listOfReplicationInfo = ReplicationInfo[];
export type __stringMin1Max128Pattern09AZaZ09AZaZ0 = string;
export interface ReplicatorCloudWatchLogs {
    Enabled?: boolean;
    LogGroup?: string;
}
export interface ReplicatorFirehose {
    Enabled?: boolean;
    DeliveryStream?: string;
}
export interface ReplicatorS3 {
    Enabled?: boolean;
    Bucket?: string;
    Prefix?: string;
}
export interface ReplicatorLogDelivery {
    CloudWatchLogs?: ReplicatorCloudWatchLogs;
    Firehose?: ReplicatorFirehose;
    S3?: ReplicatorS3;
}
export interface LogDelivery {
    ReplicatorLogDelivery?: ReplicatorLogDelivery;
}
export interface CreateReplicatorRequest {
    Description?: string;
    KafkaClusters?: KafkaCluster[];
    ReplicationInfoList?: ReplicationInfo[];
    ReplicatorName?: string;
    ServiceExecutionRoleArn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    LogDelivery?: LogDelivery;
}
export type ReplicatorState = "RUNNING" | "CREATING" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export interface CreateReplicatorResponse {
    ReplicatorArn?: string;
    ReplicatorName?: string;
    ReplicatorState?: ReplicatorState;
}
export type __integerMin1 = number;
export interface CreateTopicRequest {
    ClusterArn: string;
    TopicName?: string;
    PartitionCount?: number;
    ReplicationFactor?: number;
    Configs?: string;
}
export type TopicState = "CREATING" | "UPDATING" | "DELETING" | "ACTIVE" | (string & {});
export interface CreateTopicResponse {
    TopicArn?: string;
    TopicName?: string;
    Status?: TopicState;
}
export interface CreateVpcConnectionRequest {
    TargetClusterArn?: string;
    Authentication?: string;
    VpcId?: string;
    ClientSubnets?: string[];
    SecurityGroups?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type VpcConnectionState = "CREATING" | "AVAILABLE" | "INACTIVE" | "DEACTIVATING" | "DELETING" | "FAILED" | "REJECTED" | "REJECTING" | (string & {});
export interface CreateVpcConnectionResponse {
    VpcConnectionArn?: string;
    State?: VpcConnectionState;
    Authentication?: string;
    VpcId?: string;
    ClientSubnets?: string[];
    SecurityGroups?: string[];
    CreationTime?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DeleteChannelRequest {
    ChannelArn: string;
    ClusterArn: string;
}
export interface DeleteChannelResponse {
    ChannelArn: string;
    ClusterOperationArn?: string;
}
export interface DeleteClusterRequest {
    ClusterArn: string;
    CurrentVersion?: string;
}
export interface DeleteClusterResponse {
    ClusterArn?: string;
    State?: ClusterState;
}
export interface DeleteClusterPolicyRequest {
    ClusterArn: string;
}
export interface DeleteClusterPolicyResponse {
}
export interface DeleteConfigurationRequest {
    Arn: string;
}
export interface DeleteConfigurationResponse {
    Arn?: string;
    State?: ConfigurationState;
}
export interface DeleteReplicatorRequest {
    CurrentVersion?: string;
    ReplicatorArn: string;
}
export interface DeleteReplicatorResponse {
    ReplicatorArn?: string;
    ReplicatorState?: ReplicatorState;
}
export interface DeleteTopicRequest {
    ClusterArn: string;
    TopicName: string;
}
export interface DeleteTopicResponse {
    TopicArn?: string;
    TopicName?: string;
    Status?: TopicState;
}
export interface DeleteVpcConnectionRequest {
    Arn: string;
}
export interface DeleteVpcConnectionResponse {
    VpcConnectionArn?: string;
    State?: VpcConnectionState;
}
export interface DescribeChannelRequest {
    ChannelArn: string;
    ClusterArn: string;
}
export type ChannelStatus = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "FAILED" | "SUSPENDING" | "SUSPENDED" | (string & {});
export type ChannelDestinationType = "ICEBERG" | "S3" | (string & {});
export interface ChannelStateInfo {
    Code?: string;
    Message?: string;
}
export interface DescribeChannelResponse {
    ChannelArn: string;
    ChannelName: string;
    EncryptionConfiguration?: EncryptionConfiguration & {
        KmsKeyArn: string;
    };
    IcebergDestinationConfiguration?: IcebergDestinationConfiguration & {
        AppendOnly: boolean;
        DeadLetterQueueS3: DeadLetterQueueS3 & {
            BucketArn: string;
        };
        DestinationTableList: (DestinationTable & {
            PartitionSpec: PartitionSpec & {
                PartitionStrategy: PartitionStrategy;
            };
        })[];
        SchemaEvolution: SchemaEvolution;
        ServiceExecutionRoleArn: string;
        TableCreation: TableCreation;
    };
    S3DestinationConfiguration?: S3DestinationConfiguration & {
        DeadLetterQueueS3: DeadLetterQueueS3 & {
            BucketArn: string;
        };
        ServiceExecutionRoleArn: string;
        Storage: S3Storage & {
            BucketArn: string;
            CompressionType: S3CompressionType;
            StorageClass: S3StorageClass;
        };
    };
    Status: ChannelStatus;
    DestinationType: ChannelDestinationType;
    CreationTime: Date;
    TopicConfigurationList: (TopicConfiguration & {
        RecordConverter: RecordConverter & {
            ValueConverter: ValueConverter;
        };
        TopicArn: string;
        RecordSchema: RecordSchema & {
            GsrArn: string;
        };
    })[];
    LoggingInfo?: ChannelLoggingInfo & {
        CloudWatchLogs: CloudWatchLogs & {
            Enabled: boolean;
        };
        Firehose: Firehose & {
            Enabled: boolean;
        };
        S3: S3 & {
            Enabled: boolean;
        };
    };
    StateInfo?: ChannelStateInfo;
    ClusterOperationArn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeClusterRequest {
    ClusterArn: string;
}
export interface BrokerSoftwareInfo {
    ConfigurationArn?: string;
    ConfigurationRevision?: number;
    KafkaVersion?: string;
}
export interface JmxExporter {
    EnabledInBroker?: boolean;
}
export interface NodeExporter {
    EnabledInBroker?: boolean;
}
export interface Prometheus {
    JmxExporter?: JmxExporter;
    NodeExporter?: NodeExporter;
}
export interface OpenMonitoring {
    Prometheus?: Prometheus;
}
export interface StateInfo {
    Code?: string;
    Message?: string;
}
export type CustomerActionStatus = "CRITICAL_ACTION_REQUIRED" | "ACTION_RECOMMENDED" | "NONE" | (string & {});
export interface ClusterInfo {
    ActiveOperationArn?: string;
    BrokerNodeGroupInfo?: BrokerNodeGroupInfo;
    Rebalancing?: Rebalancing;
    ClientAuthentication?: ClientAuthentication;
    ClusterArn?: string;
    ClusterName?: string;
    CreationTime?: Date;
    CurrentBrokerSoftwareInfo?: BrokerSoftwareInfo;
    CurrentVersion?: string;
    EncryptionInfo?: EncryptionInfo;
    EnhancedMonitoring?: EnhancedMonitoring;
    OpenMonitoring?: OpenMonitoring;
    LoggingInfo?: LoggingInfo;
    NumberOfBrokerNodes?: number;
    State?: ClusterState;
    StateInfo?: StateInfo;
    Tags?: {
        [key: string]: string | undefined;
    };
    ZookeeperConnectString?: string;
    ZookeeperConnectStringTls?: string;
    StorageMode?: StorageMode;
    CustomerActionStatus?: CustomerActionStatus;
}
export interface DescribeClusterResponse {
    ClusterInfo?: ClusterInfo & {
        BrokerNodeGroupInfo: BrokerNodeGroupInfo & {
            ClientSubnets: __listOf__string;
            InstanceType: __stringMin5Max32;
        };
        EncryptionInfo: EncryptionInfo & {
            EncryptionAtRest: EncryptionAtRest & {
                DataVolumeKMSKeyId: string;
            };
        };
        OpenMonitoring: OpenMonitoring & {
            Prometheus: Prometheus & {
                JmxExporter: JmxExporter & {
                    EnabledInBroker: boolean;
                };
                NodeExporter: NodeExporter & {
                    EnabledInBroker: boolean;
                };
            };
        };
        LoggingInfo: LoggingInfo & {
            BrokerLogs: BrokerLogs & {
                CloudWatchLogs: CloudWatchLogs & {
                    Enabled: boolean;
                };
                Firehose: Firehose & {
                    Enabled: boolean;
                };
                S3: S3 & {
                    Enabled: boolean;
                };
            };
            AuthorizerLogs: AuthorizerLogs & {
                CloudWatchLogs: CloudWatchLogs & {
                    Enabled: boolean;
                };
                Firehose: Firehose & {
                    Enabled: boolean;
                };
                S3: S3 & {
                    Enabled: boolean;
                };
            };
        };
    };
}
export interface DescribeClusterOperationRequest {
    ClusterOperationArn: string;
}
export interface ErrorInfo {
    ErrorCode?: string;
    ErrorString?: string;
}
export interface ClusterOperationStepInfo {
    StepStatus?: string;
}
export interface ClusterOperationStep {
    StepInfo?: ClusterOperationStepInfo;
    StepName?: string;
}
export type __listOfClusterOperationStep = ClusterOperationStep[];
export interface BrokerEBSVolumeInfo {
    KafkaBrokerNodeId?: string;
    ProvisionedThroughput?: ProvisionedThroughput;
    VolumeSizeGB?: number;
}
export type __listOfBrokerEBSVolumeInfo = BrokerEBSVolumeInfo[];
export interface ZookeeperAccess {
    Enabled?: boolean;
}
export type __listOf__double = number[];
export interface BrokerCountUpdateInfo {
    CreatedBrokerIds?: number[];
    DeletedBrokerIds?: number[];
}
export interface MutableClusterInfo {
    BrokerEBSVolumeInfo?: BrokerEBSVolumeInfo[];
    ConfigurationInfo?: ConfigurationInfo;
    NumberOfBrokerNodes?: number;
    EnhancedMonitoring?: EnhancedMonitoring;
    OpenMonitoring?: OpenMonitoring;
    ZookeeperAccess?: ZookeeperAccess;
    KafkaVersion?: string;
    LoggingInfo?: LoggingInfo;
    InstanceType?: string;
    ClientAuthentication?: ClientAuthentication;
    EncryptionInfo?: EncryptionInfo;
    ConnectivityInfo?: ConnectivityInfo;
    StorageMode?: StorageMode;
    BrokerCountUpdateInfo?: BrokerCountUpdateInfo;
    Rebalancing?: Rebalancing;
}
export type UserIdentityType = "AWSACCOUNT" | "AWSSERVICE" | (string & {});
export interface UserIdentity {
    Type?: UserIdentityType;
    PrincipalId?: string;
}
export interface VpcConnectionInfo {
    VpcConnectionArn?: string;
    Owner?: string;
    UserIdentity?: UserIdentity;
    CreationTime?: Date;
}
export interface ClusterOperationInfo {
    ClientRequestId?: string;
    ClusterArn?: string;
    CreationTime?: Date;
    EndTime?: Date;
    ErrorInfo?: ErrorInfo;
    OperationArn?: string;
    OperationState?: string;
    OperationSteps?: ClusterOperationStep[];
    OperationType?: string;
    SourceClusterInfo?: MutableClusterInfo;
    TargetClusterInfo?: MutableClusterInfo;
    VpcConnectionInfo?: VpcConnectionInfo;
}
export interface DescribeClusterOperationResponse {
    ClusterOperationInfo?: ClusterOperationInfo & {
        SourceClusterInfo: MutableClusterInfo & {
            BrokerEBSVolumeInfo: (BrokerEBSVolumeInfo & {
                KafkaBrokerNodeId: string;
            })[];
            ConfigurationInfo: ConfigurationInfo & {
                Arn: string;
                Revision: number;
            };
            OpenMonitoring: OpenMonitoring & {
                Prometheus: Prometheus & {
                    JmxExporter: JmxExporter & {
                        EnabledInBroker: boolean;
                    };
                    NodeExporter: NodeExporter & {
                        EnabledInBroker: boolean;
                    };
                };
            };
            LoggingInfo: LoggingInfo & {
                BrokerLogs: BrokerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
                AuthorizerLogs: AuthorizerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
            };
            EncryptionInfo: EncryptionInfo & {
                EncryptionAtRest: EncryptionAtRest & {
                    DataVolumeKMSKeyId: string;
                };
            };
        };
        TargetClusterInfo: MutableClusterInfo & {
            BrokerEBSVolumeInfo: (BrokerEBSVolumeInfo & {
                KafkaBrokerNodeId: string;
            })[];
            ConfigurationInfo: ConfigurationInfo & {
                Arn: string;
                Revision: number;
            };
            OpenMonitoring: OpenMonitoring & {
                Prometheus: Prometheus & {
                    JmxExporter: JmxExporter & {
                        EnabledInBroker: boolean;
                    };
                    NodeExporter: NodeExporter & {
                        EnabledInBroker: boolean;
                    };
                };
            };
            LoggingInfo: LoggingInfo & {
                BrokerLogs: BrokerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
                AuthorizerLogs: AuthorizerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
            };
            EncryptionInfo: EncryptionInfo & {
                EncryptionAtRest: EncryptionAtRest & {
                    DataVolumeKMSKeyId: string;
                };
            };
        };
    };
}
export interface DescribeClusterOperationV2Request {
    ClusterOperationArn: string;
}
export interface ClusterOperationV2Provisioned {
    OperationSteps?: ClusterOperationStep[];
    SourceClusterInfo?: MutableClusterInfo;
    TargetClusterInfo?: MutableClusterInfo;
    VpcConnectionInfo?: VpcConnectionInfo;
}
export interface ServerlessConnectivityInfo {
    NetworkType?: NetworkType;
}
export interface VpcConnectionInfoServerless {
    CreationTime?: Date;
    Owner?: string;
    UserIdentity?: UserIdentity;
    VpcConnectionArn?: string;
}
export interface ClusterOperationV2Serverless {
    SourceClusterInfo?: ServerlessConnectivityInfo;
    TargetClusterInfo?: ServerlessConnectivityInfo;
    VpcConnectionInfo?: VpcConnectionInfoServerless;
}
export interface ClusterOperationV2 {
    ClusterArn?: string;
    ClusterType?: ClusterType;
    StartTime?: Date;
    EndTime?: Date;
    ErrorInfo?: ErrorInfo;
    OperationArn?: string;
    OperationState?: string;
    OperationType?: string;
    Provisioned?: ClusterOperationV2Provisioned;
    Serverless?: ClusterOperationV2Serverless;
}
export interface DescribeClusterOperationV2Response {
    ClusterOperationInfo?: ClusterOperationV2 & {
        Provisioned: ClusterOperationV2Provisioned & {
            SourceClusterInfo: MutableClusterInfo & {
                BrokerEBSVolumeInfo: (BrokerEBSVolumeInfo & {
                    KafkaBrokerNodeId: string;
                })[];
                ConfigurationInfo: ConfigurationInfo & {
                    Arn: string;
                    Revision: number;
                };
                OpenMonitoring: OpenMonitoring & {
                    Prometheus: Prometheus & {
                        JmxExporter: JmxExporter & {
                            EnabledInBroker: boolean;
                        };
                        NodeExporter: NodeExporter & {
                            EnabledInBroker: boolean;
                        };
                    };
                };
                LoggingInfo: LoggingInfo & {
                    BrokerLogs: BrokerLogs & {
                        CloudWatchLogs: CloudWatchLogs & {
                            Enabled: boolean;
                        };
                        Firehose: Firehose & {
                            Enabled: boolean;
                        };
                        S3: S3 & {
                            Enabled: boolean;
                        };
                    };
                    AuthorizerLogs: AuthorizerLogs & {
                        CloudWatchLogs: CloudWatchLogs & {
                            Enabled: boolean;
                        };
                        Firehose: Firehose & {
                            Enabled: boolean;
                        };
                        S3: S3 & {
                            Enabled: boolean;
                        };
                    };
                };
                EncryptionInfo: EncryptionInfo & {
                    EncryptionAtRest: EncryptionAtRest & {
                        DataVolumeKMSKeyId: string;
                    };
                };
            };
            TargetClusterInfo: MutableClusterInfo & {
                BrokerEBSVolumeInfo: (BrokerEBSVolumeInfo & {
                    KafkaBrokerNodeId: string;
                })[];
                ConfigurationInfo: ConfigurationInfo & {
                    Arn: string;
                    Revision: number;
                };
                OpenMonitoring: OpenMonitoring & {
                    Prometheus: Prometheus & {
                        JmxExporter: JmxExporter & {
                            EnabledInBroker: boolean;
                        };
                        NodeExporter: NodeExporter & {
                            EnabledInBroker: boolean;
                        };
                    };
                };
                LoggingInfo: LoggingInfo & {
                    BrokerLogs: BrokerLogs & {
                        CloudWatchLogs: CloudWatchLogs & {
                            Enabled: boolean;
                        };
                        Firehose: Firehose & {
                            Enabled: boolean;
                        };
                        S3: S3 & {
                            Enabled: boolean;
                        };
                    };
                    AuthorizerLogs: AuthorizerLogs & {
                        CloudWatchLogs: CloudWatchLogs & {
                            Enabled: boolean;
                        };
                        Firehose: Firehose & {
                            Enabled: boolean;
                        };
                        S3: S3 & {
                            Enabled: boolean;
                        };
                    };
                };
                EncryptionInfo: EncryptionInfo & {
                    EncryptionAtRest: EncryptionAtRest & {
                        DataVolumeKMSKeyId: string;
                    };
                };
            };
        };
    };
}
export interface DescribeClusterV2Request {
    ClusterArn: string;
}
export interface Provisioned {
    BrokerNodeGroupInfo?: BrokerNodeGroupInfo;
    Rebalancing?: Rebalancing;
    CurrentBrokerSoftwareInfo?: BrokerSoftwareInfo;
    ClientAuthentication?: ClientAuthentication;
    EncryptionInfo?: EncryptionInfo;
    EnhancedMonitoring?: EnhancedMonitoring;
    OpenMonitoring?: OpenMonitoringInfo;
    LoggingInfo?: LoggingInfo;
    NumberOfBrokerNodes?: number;
    ZookeeperConnectString?: string;
    ZookeeperConnectStringTls?: string;
    StorageMode?: StorageMode;
    CustomerActionStatus?: CustomerActionStatus;
}
export interface Serverless {
    VpcConfigs?: VpcConfig[];
    ClientAuthentication?: ServerlessClientAuthentication;
    ConnectivityInfo?: ServerlessConnectivityInfo;
}
export interface Cluster {
    ActiveOperationArn?: string;
    ClusterType?: ClusterType;
    ClusterArn?: string;
    ClusterName?: string;
    CreationTime?: Date;
    CurrentVersion?: string;
    State?: ClusterState;
    StateInfo?: StateInfo;
    Tags?: {
        [key: string]: string | undefined;
    };
    Provisioned?: Provisioned;
    Serverless?: Serverless;
}
export interface DescribeClusterV2Response {
    ClusterInfo?: Cluster & {
        Provisioned: Provisioned & {
            BrokerNodeGroupInfo: BrokerNodeGroupInfo & {
                ClientSubnets: __listOf__string;
                InstanceType: __stringMin5Max32;
            };
            NumberOfBrokerNodes: __integerMin1Max15;
            EncryptionInfo: EncryptionInfo & {
                EncryptionAtRest: EncryptionAtRest & {
                    DataVolumeKMSKeyId: string;
                };
            };
            OpenMonitoring: OpenMonitoringInfo & {
                Prometheus: PrometheusInfo & {
                    JmxExporter: JmxExporterInfo & {
                        EnabledInBroker: boolean;
                    };
                    NodeExporter: NodeExporterInfo & {
                        EnabledInBroker: boolean;
                    };
                };
            };
            LoggingInfo: LoggingInfo & {
                BrokerLogs: BrokerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
                AuthorizerLogs: AuthorizerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
            };
        };
        Serverless: Serverless & {
            VpcConfigs: (VpcConfig & {
                SubnetIds: __listOf__string;
            })[];
        };
    };
}
export interface DescribeConfigurationRequest {
    Arn: string;
}
export interface DescribeConfigurationResponse {
    Arn?: string;
    CreationTime?: Date;
    Description?: string;
    KafkaVersions?: string[];
    LatestRevision?: ConfigurationRevision & {
        CreationTime: __timestampIso8601;
        Revision: number;
    };
    Name?: string;
    State?: ConfigurationState;
}
export interface DescribeConfigurationRevisionRequest {
    Arn: string;
    Revision: number;
}
export interface DescribeConfigurationRevisionResponse {
    Arn?: string;
    CreationTime?: Date;
    Description?: string;
    Revision?: number;
    ServerProperties?: Uint8Array;
}
export interface DescribeReplicatorRequest {
    ReplicatorArn: string;
}
export interface KafkaClusterDescription {
    AmazonMskCluster?: AmazonMskCluster;
    ApacheKafkaCluster?: ApacheKafkaCluster;
    KafkaClusterAlias?: string;
    VpcConfig?: KafkaClusterClientVpcConfig;
    ClientAuthentication?: KafkaClusterClientAuthentication;
    EncryptionInTransit?: KafkaClusterEncryptionInTransit;
}
export type __listOfKafkaClusterDescription = KafkaClusterDescription[];
export interface ReplicationInfoDescription {
    ConsumerGroupReplication?: ConsumerGroupReplication;
    SourceKafkaClusterAlias?: string;
    TargetCompressionType?: TargetCompressionType;
    TargetKafkaClusterAlias?: string;
    TopicReplication?: TopicReplication;
}
export type __listOfReplicationInfoDescription = ReplicationInfoDescription[];
export interface ReplicationStateInfo {
    Code?: string;
    Message?: string;
}
export interface DescribeReplicatorResponse {
    CreationTime?: Date;
    CurrentVersion?: string;
    IsReplicatorReference?: boolean;
    KafkaClusters?: (KafkaClusterDescription & {
        AmazonMskCluster: AmazonMskCluster & {
            MskClusterArn: string;
        };
        ApacheKafkaCluster: ApacheKafkaCluster & {
            ApacheKafkaClusterId: string;
            BootstrapBrokerString: string;
        };
        VpcConfig: KafkaClusterClientVpcConfig & {
            SubnetIds: __listOf__string;
        };
        ClientAuthentication: KafkaClusterClientAuthentication & {
            SaslScram: KafkaClusterSaslScramAuthentication & {
                Mechanism: KafkaClusterSaslScramMechanism;
                SecretArn: string;
            };
            MTLS: KafkaClusterMTLSAuthentication & {
                SecretArn: string;
            };
            SaslOAuthBearer: KafkaClusterSaslOAuthBearerAuthentication & {
                TokenEndpointUrl: string;
                TokenEndpointAuthenticationMethod: TokenEndpointAuthenticationMethod;
                ClientCredentials: KafkaClusterOAuthClientCredentials & {
                    TokenRequestSecretArn: string;
                };
                IamJwtBearer: KafkaClusterOAuthIamJwtBearer & {
                    Audience: string;
                    SigningAlgorithm: JwtSigningAlgorithm;
                };
                ClientCredentialsAssertion: KafkaClusterOAuthClientCredentialsAssertion & {
                    Audience: string;
                    SigningAlgorithm: JwtSigningAlgorithm;
                };
            };
        };
        EncryptionInTransit: KafkaClusterEncryptionInTransit & {
            EncryptionType: KafkaClusterEncryptionInTransitType;
        };
    })[];
    ReplicationInfoList?: (ReplicationInfoDescription & {
        ConsumerGroupReplication: ConsumerGroupReplication & {
            ConsumerGroupsToReplicate: __listOf__stringMax256;
        };
        TopicReplication: TopicReplication & {
            TopicsToReplicate: __listOf__stringMax249;
        };
    })[];
    ReplicatorArn?: string;
    ReplicatorDescription?: string;
    ReplicatorName?: string;
    ReplicatorResourceArn?: string;
    ReplicatorState?: ReplicatorState;
    ServiceExecutionRoleArn?: string;
    StateInfo?: ReplicationStateInfo;
    Tags?: {
        [key: string]: string | undefined;
    };
    LogDelivery?: LogDelivery & {
        ReplicatorLogDelivery: ReplicatorLogDelivery & {
            CloudWatchLogs: ReplicatorCloudWatchLogs & {
                Enabled: boolean;
            };
            Firehose: ReplicatorFirehose & {
                Enabled: boolean;
            };
            S3: ReplicatorS3 & {
                Enabled: boolean;
            };
        };
    };
}
export interface DescribeTopicRequest {
    ClusterArn: string;
    TopicName: string;
}
export interface DescribeTopicResponse {
    TopicArn?: string;
    TopicName?: string;
    ReplicationFactor?: number;
    PartitionCount?: number;
    Configs?: string;
    Status?: TopicState;
}
export type MaxResults = number;
export interface DescribeTopicPartitionsRequest {
    ClusterArn: string;
    TopicName: string;
    MaxResults?: number;
    NextToken?: string;
}
export type __listOf__integer = number[];
export interface TopicPartitionInfo {
    Partition?: number;
    Leader?: number;
    Replicas?: number[];
    Isr?: number[];
}
export type __listOfTopicPartitionInfo = TopicPartitionInfo[];
export interface DescribeTopicPartitionsResponse {
    Partitions?: TopicPartitionInfo[];
    NextToken?: string;
}
export interface DescribeVpcConnectionRequest {
    Arn: string;
}
export interface DescribeVpcConnectionResponse {
    VpcConnectionArn?: string;
    TargetClusterArn?: string;
    State?: VpcConnectionState;
    Authentication?: string;
    VpcId?: string;
    Subnets?: string[];
    SecurityGroups?: string[];
    CreationTime?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetBootstrapBrokersRequest {
    ClusterArn: string;
}
export interface GetBootstrapBrokersResponse {
    BootstrapBrokerString?: string;
    BootstrapBrokerStringTls?: string;
    BootstrapBrokerStringSaslScram?: string;
    BootstrapBrokerStringSaslIam?: string;
    BootstrapBrokerStringPublicTls?: string;
    BootstrapBrokerStringPublicSaslScram?: string;
    BootstrapBrokerStringPublicSaslIam?: string;
    BootstrapBrokerStringVpcConnectivityTls?: string;
    BootstrapBrokerStringVpcConnectivitySaslScram?: string;
    BootstrapBrokerStringVpcConnectivitySaslIam?: string;
    BootstrapBrokerStringIpv6?: string;
    BootstrapBrokerStringTlsIpv6?: string;
    BootstrapBrokerStringSaslScramIpv6?: string;
    BootstrapBrokerStringSaslIamIpv6?: string;
}
export interface GetClusterPolicyRequest {
    ClusterArn: string;
}
export interface GetClusterPolicyResponse {
    CurrentVersion?: string;
    Policy?: string;
}
export interface GetCompatibleKafkaVersionsRequest {
    ClusterArn?: string;
}
export interface CompatibleKafkaVersion {
    SourceVersion?: string;
    TargetVersions?: string[];
}
export type __listOfCompatibleKafkaVersion = CompatibleKafkaVersion[];
export interface GetCompatibleKafkaVersionsResponse {
    CompatibleKafkaVersions?: CompatibleKafkaVersion[];
}
export interface ListChannelsRequest {
    ClusterArn: string;
    MaxResults?: number;
    NextToken?: string;
    TopicNameFilter?: string;
}
export interface ChannelInfo {
    ChannelArn?: string;
    ChannelName?: string;
    Status?: ChannelStatus;
    CreationTime?: Date;
    DestinationType?: ChannelDestinationType;
    ClusterOperationArn?: string;
}
export type __listOfChannelInfo = ChannelInfo[];
export interface ListChannelsResponse {
    Channels?: (ChannelInfo & {
        ChannelArn: string;
        ChannelName: string;
        Status: ChannelStatus;
        CreationTime: __timestampIso8601;
        DestinationType: ChannelDestinationType;
    })[];
    NextToken?: string;
}
export interface ListClientVpcConnectionsRequest {
    ClusterArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface ClientVpcConnection {
    Authentication?: string;
    CreationTime?: Date;
    State?: VpcConnectionState;
    VpcConnectionArn?: string;
    Owner?: string;
}
export type __listOfClientVpcConnection = ClientVpcConnection[];
export interface ListClientVpcConnectionsResponse {
    ClientVpcConnections?: (ClientVpcConnection & {
        VpcConnectionArn: string;
    })[];
    NextToken?: string;
}
export interface ListClusterOperationsRequest {
    ClusterArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export type __listOfClusterOperationInfo = ClusterOperationInfo[];
export interface ListClusterOperationsResponse {
    ClusterOperationInfoList?: (ClusterOperationInfo & {
        SourceClusterInfo: MutableClusterInfo & {
            BrokerEBSVolumeInfo: (BrokerEBSVolumeInfo & {
                KafkaBrokerNodeId: string;
            })[];
            ConfigurationInfo: ConfigurationInfo & {
                Arn: string;
                Revision: number;
            };
            OpenMonitoring: OpenMonitoring & {
                Prometheus: Prometheus & {
                    JmxExporter: JmxExporter & {
                        EnabledInBroker: boolean;
                    };
                    NodeExporter: NodeExporter & {
                        EnabledInBroker: boolean;
                    };
                };
            };
            LoggingInfo: LoggingInfo & {
                BrokerLogs: BrokerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
                AuthorizerLogs: AuthorizerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
            };
            EncryptionInfo: EncryptionInfo & {
                EncryptionAtRest: EncryptionAtRest & {
                    DataVolumeKMSKeyId: string;
                };
            };
        };
        TargetClusterInfo: MutableClusterInfo & {
            BrokerEBSVolumeInfo: (BrokerEBSVolumeInfo & {
                KafkaBrokerNodeId: string;
            })[];
            ConfigurationInfo: ConfigurationInfo & {
                Arn: string;
                Revision: number;
            };
            OpenMonitoring: OpenMonitoring & {
                Prometheus: Prometheus & {
                    JmxExporter: JmxExporter & {
                        EnabledInBroker: boolean;
                    };
                    NodeExporter: NodeExporter & {
                        EnabledInBroker: boolean;
                    };
                };
            };
            LoggingInfo: LoggingInfo & {
                BrokerLogs: BrokerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
                AuthorizerLogs: AuthorizerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
            };
            EncryptionInfo: EncryptionInfo & {
                EncryptionAtRest: EncryptionAtRest & {
                    DataVolumeKMSKeyId: string;
                };
            };
        };
    })[];
    NextToken?: string;
}
export interface ListClusterOperationsV2Request {
    ClusterArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface ClusterOperationV2Summary {
    ClusterArn?: string;
    ClusterType?: ClusterType;
    StartTime?: Date;
    EndTime?: Date;
    OperationArn?: string;
    OperationState?: string;
    OperationType?: string;
}
export type __listOfClusterOperationV2Summary = ClusterOperationV2Summary[];
export interface ListClusterOperationsV2Response {
    ClusterOperationInfoList?: ClusterOperationV2Summary[];
    NextToken?: string;
}
export interface ListClustersRequest {
    ClusterNameFilter?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type __listOfClusterInfo = ClusterInfo[];
export interface ListClustersResponse {
    ClusterInfoList?: (ClusterInfo & {
        BrokerNodeGroupInfo: BrokerNodeGroupInfo & {
            ClientSubnets: __listOf__string;
            InstanceType: __stringMin5Max32;
        };
        EncryptionInfo: EncryptionInfo & {
            EncryptionAtRest: EncryptionAtRest & {
                DataVolumeKMSKeyId: string;
            };
        };
        OpenMonitoring: OpenMonitoring & {
            Prometheus: Prometheus & {
                JmxExporter: JmxExporter & {
                    EnabledInBroker: boolean;
                };
                NodeExporter: NodeExporter & {
                    EnabledInBroker: boolean;
                };
            };
        };
        LoggingInfo: LoggingInfo & {
            BrokerLogs: BrokerLogs & {
                CloudWatchLogs: CloudWatchLogs & {
                    Enabled: boolean;
                };
                Firehose: Firehose & {
                    Enabled: boolean;
                };
                S3: S3 & {
                    Enabled: boolean;
                };
            };
            AuthorizerLogs: AuthorizerLogs & {
                CloudWatchLogs: CloudWatchLogs & {
                    Enabled: boolean;
                };
                Firehose: Firehose & {
                    Enabled: boolean;
                };
                S3: S3 & {
                    Enabled: boolean;
                };
            };
        };
    })[];
    NextToken?: string;
}
export interface ListClustersV2Request {
    ClusterNameFilter?: string;
    ClusterTypeFilter?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type __listOfCluster = Cluster[];
export interface ListClustersV2Response {
    ClusterInfoList?: (Cluster & {
        Provisioned: Provisioned & {
            BrokerNodeGroupInfo: BrokerNodeGroupInfo & {
                ClientSubnets: __listOf__string;
                InstanceType: __stringMin5Max32;
            };
            NumberOfBrokerNodes: __integerMin1Max15;
            EncryptionInfo: EncryptionInfo & {
                EncryptionAtRest: EncryptionAtRest & {
                    DataVolumeKMSKeyId: string;
                };
            };
            OpenMonitoring: OpenMonitoringInfo & {
                Prometheus: PrometheusInfo & {
                    JmxExporter: JmxExporterInfo & {
                        EnabledInBroker: boolean;
                    };
                    NodeExporter: NodeExporterInfo & {
                        EnabledInBroker: boolean;
                    };
                };
            };
            LoggingInfo: LoggingInfo & {
                BrokerLogs: BrokerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
                AuthorizerLogs: AuthorizerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
            };
        };
        Serverless: Serverless & {
            VpcConfigs: (VpcConfig & {
                SubnetIds: __listOf__string;
            })[];
        };
    })[];
    NextToken?: string;
}
export interface ListConfigurationRevisionsRequest {
    Arn: string;
    MaxResults?: number;
    NextToken?: string;
}
export type __listOfConfigurationRevision = ConfigurationRevision[];
export interface ListConfigurationRevisionsResponse {
    NextToken?: string;
    Revisions?: (ConfigurationRevision & {
        CreationTime: __timestampIso8601;
        Revision: number;
    })[];
}
export interface ListConfigurationsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface Configuration {
    Arn?: string;
    CreationTime?: Date;
    Description?: string;
    KafkaVersions?: string[];
    LatestRevision?: ConfigurationRevision;
    Name?: string;
    State?: ConfigurationState;
}
export type __listOfConfiguration = Configuration[];
export interface ListConfigurationsResponse {
    Configurations?: (Configuration & {
        Arn: string;
        CreationTime: __timestampIso8601;
        Description: string;
        KafkaVersions: __listOf__string;
        LatestRevision: ConfigurationRevision & {
            CreationTime: __timestampIso8601;
            Revision: number;
        };
        Name: string;
        State: ConfigurationState;
    })[];
    NextToken?: string;
}
export interface ListKafkaVersionsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export type KafkaVersionStatus = "ACTIVE" | "DEPRECATED" | (string & {});
export interface KafkaVersion {
    Version?: string;
    Status?: KafkaVersionStatus;
}
export type __listOfKafkaVersion = KafkaVersion[];
export interface ListKafkaVersionsResponse {
    KafkaVersions?: KafkaVersion[];
    NextToken?: string;
}
export interface ListNodesRequest {
    ClusterArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface BrokerNodeInfo {
    AttachedENIId?: string;
    BrokerId?: number;
    ClientSubnet?: string;
    ClientVpcIpAddress?: string;
    CurrentBrokerSoftwareInfo?: BrokerSoftwareInfo;
    Endpoints?: string[];
}
export interface ControllerNodeInfo {
    Endpoints?: string[];
}
export type NodeType = "BROKER" | (string & {});
export interface ZookeeperNodeInfo {
    AttachedENIId?: string;
    ClientVpcIpAddress?: string;
    Endpoints?: string[];
    ZookeeperId?: number;
    ZookeeperVersion?: string;
}
export interface NodeInfo {
    AddedToClusterTime?: string;
    BrokerNodeInfo?: BrokerNodeInfo;
    ControllerNodeInfo?: ControllerNodeInfo;
    InstanceType?: string;
    NodeARN?: string;
    NodeType?: NodeType;
    ZookeeperNodeInfo?: ZookeeperNodeInfo;
}
export type __listOfNodeInfo = NodeInfo[];
export interface ListNodesResponse {
    NextToken?: string;
    NodeInfoList?: NodeInfo[];
}
export interface ListReplicatorsRequest {
    MaxResults?: number;
    NextToken?: string;
    ReplicatorNameFilter?: string;
}
export interface KafkaClusterSummary {
    AmazonMskCluster?: AmazonMskCluster;
    ApacheKafkaCluster?: ApacheKafkaCluster;
    KafkaClusterAlias?: string;
}
export type __listOfKafkaClusterSummary = KafkaClusterSummary[];
export interface ReplicationInfoSummary {
    SourceKafkaClusterAlias?: string;
    TargetKafkaClusterAlias?: string;
}
export type __listOfReplicationInfoSummary = ReplicationInfoSummary[];
export interface ReplicatorSummary {
    CreationTime?: Date;
    CurrentVersion?: string;
    IsReplicatorReference?: boolean;
    KafkaClustersSummary?: KafkaClusterSummary[];
    ReplicationInfoSummaryList?: ReplicationInfoSummary[];
    ReplicatorArn?: string;
    ReplicatorName?: string;
    ReplicatorResourceArn?: string;
    ReplicatorState?: ReplicatorState;
}
export type __listOfReplicatorSummary = ReplicatorSummary[];
export interface ListReplicatorsResponse {
    NextToken?: string;
    Replicators?: (ReplicatorSummary & {
        KafkaClustersSummary: (KafkaClusterSummary & {
            AmazonMskCluster: AmazonMskCluster & {
                MskClusterArn: string;
            };
            ApacheKafkaCluster: ApacheKafkaCluster & {
                ApacheKafkaClusterId: string;
                BootstrapBrokerString: string;
            };
        })[];
    })[];
}
export interface ListScramSecretsRequest {
    ClusterArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface ListScramSecretsResponse {
    NextToken?: string;
    SecretArnList?: string[];
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListTopicsRequest {
    ClusterArn: string;
    MaxResults?: number;
    NextToken?: string;
    TopicNameFilter?: string;
}
export interface TopicInfo {
    TopicArn?: string;
    TopicName?: string;
    ReplicationFactor?: number;
    PartitionCount?: number;
    OutOfSyncReplicaCount?: number;
}
export type __listOfTopicInfo = TopicInfo[];
export interface ListTopicsResponse {
    Topics?: TopicInfo[];
    NextToken?: string;
}
export interface ListVpcConnectionsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface VpcConnection {
    VpcConnectionArn?: string;
    TargetClusterArn?: string;
    CreationTime?: Date;
    Authentication?: string;
    VpcId?: string;
    State?: VpcConnectionState;
}
export type __listOfVpcConnection = VpcConnection[];
export interface ListVpcConnectionsResponse {
    VpcConnections?: (VpcConnection & {
        VpcConnectionArn: string;
        TargetClusterArn: string;
    })[];
    NextToken?: string;
}
export interface PutClusterPolicyRequest {
    ClusterArn: string;
    CurrentVersion?: string;
    Policy?: string;
}
export interface PutClusterPolicyResponse {
    CurrentVersion?: string;
}
export interface RebootBrokerRequest {
    BrokerIds?: string[];
    ClusterArn: string;
}
export interface RebootBrokerResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export interface RejectClientVpcConnectionRequest {
    ClusterArn: string;
    VpcConnectionArn?: string;
}
export interface RejectClientVpcConnectionResponse {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateBrokerCountRequest {
    ClusterArn: string;
    CurrentVersion?: string;
    TargetNumberOfBrokerNodes?: number;
}
export interface UpdateBrokerCountResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export interface UpdateBrokerStorageRequest {
    ClusterArn: string;
    CurrentVersion?: string;
    TargetBrokerEBSVolumeInfo?: BrokerEBSVolumeInfo[];
}
export interface UpdateBrokerStorageResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export interface UpdateBrokerTypeRequest {
    ClusterArn: string;
    CurrentVersion?: string;
    TargetInstanceType?: string;
}
export interface UpdateBrokerTypeResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export interface IcebergDestinationUpdate {
    DataFreshnessInSeconds?: number;
}
export interface S3DestinationUpdate {
    DataFreshnessInSeconds?: number;
}
export interface UpdateChannelRequest {
    ChannelArn: string;
    ClusterArn: string;
    IcebergDestinationUpdate?: IcebergDestinationUpdate;
    S3DestinationUpdate?: S3DestinationUpdate;
}
export interface UpdateChannelResponse {
    ChannelArn: string;
    ClusterOperationArn?: string;
}
export interface UpdateClusterConfigurationRequest {
    ClusterArn: string;
    ConfigurationInfo?: ConfigurationInfo;
    CurrentVersion?: string;
}
export interface UpdateClusterConfigurationResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export interface UpdateClusterKafkaVersionRequest {
    ClusterArn: string;
    ConfigurationInfo?: ConfigurationInfo;
    CurrentVersion?: string;
    TargetKafkaVersion?: string;
}
export interface UpdateClusterKafkaVersionResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export interface UpdateConfigurationRequest {
    Arn: string;
    Description?: string;
    ServerProperties?: Uint8Array;
}
export interface UpdateConfigurationResponse {
    Arn?: string;
    LatestRevision?: ConfigurationRevision & {
        CreationTime: __timestampIso8601;
        Revision: number;
    };
}
export interface UpdateConnectivityRequest {
    ClusterArn: string;
    ConnectivityInfo?: ConnectivityInfo;
    CurrentVersion?: string;
    ZookeeperAccess?: ZookeeperAccess;
}
export interface UpdateConnectivityResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export interface UpdateMonitoringRequest {
    ClusterArn: string;
    CurrentVersion?: string;
    EnhancedMonitoring?: EnhancedMonitoring;
    OpenMonitoring?: OpenMonitoringInfo;
    LoggingInfo?: LoggingInfo;
}
export interface UpdateMonitoringResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export interface UpdateRebalancingRequest {
    ClusterArn: string;
    CurrentVersion?: string;
    Rebalancing?: Rebalancing;
}
export interface UpdateRebalancingResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export interface ConsumerGroupReplicationUpdate {
    ConsumerGroupsToExclude?: string[];
    ConsumerGroupsToReplicate?: string[];
    DetectAndCopyNewConsumerGroups?: boolean;
    SynchroniseConsumerGroupOffsets?: boolean;
}
export interface TopicReplicationUpdate {
    CopyAccessControlListsForTopics?: boolean;
    CopyTopicConfigurations?: boolean;
    DetectAndCopyNewTopics?: boolean;
    TopicsToExclude?: string[];
    TopicsToReplicate?: string[];
}
export interface UpdateReplicationInfoRequest {
    ConsumerGroupReplication?: ConsumerGroupReplicationUpdate;
    CurrentVersion?: string;
    ReplicatorArn: string;
    SourceKafkaClusterArn?: string;
    SourceKafkaClusterId?: string;
    TargetKafkaClusterArn?: string;
    TargetKafkaClusterId?: string;
    TopicReplication?: TopicReplicationUpdate;
    LogDelivery?: LogDelivery;
}
export interface UpdateReplicationInfoResponse {
    ReplicatorArn?: string;
    ReplicatorState?: ReplicatorState;
}
export interface UpdateSecurityRequest {
    ClientAuthentication?: ClientAuthentication;
    ClusterArn: string;
    CurrentVersion?: string;
    EncryptionInfo?: EncryptionInfo;
}
export interface UpdateSecurityResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export interface UpdateStorageRequest {
    ClusterArn: string;
    CurrentVersion?: string;
    ProvisionedThroughput?: ProvisionedThroughput;
    StorageMode?: StorageMode;
    VolumeSizeGB?: number;
}
export interface UpdateStorageResponse {
    ClusterArn?: string;
    ClusterOperationArn?: string;
}
export interface UpdateTopicRequest {
    ClusterArn: string;
    TopicName: string;
    Configs?: string;
    PartitionCount?: number;
}
export interface UpdateTopicResponse {
    TopicArn?: string;
    TopicName?: string;
    Status?: TopicState;
}
export type BatchAssociateScramSecretError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Associates one or more Scram Secrets with an Amazon MSK cluster.
 */
export declare const batchAssociateScramSecret: API.OperationMethod<BatchAssociateScramSecretRequest, BatchAssociateScramSecretResponse, BatchAssociateScramSecretError, Credentials | HttpClient.HttpClient>;
export type BatchDisassociateScramSecretError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Disassociates one or more Scram Secrets from an Amazon MSK cluster.
 */
export declare const batchDisassociateScramSecret: API.OperationMethod<BatchDisassociateScramSecretRequest, BatchDisassociateScramSecretResponse, BatchDisassociateScramSecretError, Credentials | HttpClient.HttpClient>;
export type CreateChannelError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a Channel that streams records from an Amazon MSK Express cluster topic to Amazon S3 or Apache Iceberg.
 */
export declare const createChannel: API.OperationMethod<CreateChannelRequest, CreateChannelResponse, CreateChannelError, Credentials | HttpClient.HttpClient>;
export type CreateClusterError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new MSK cluster.
 */
export declare const createCluster: API.OperationMethod<CreateClusterRequest, CreateClusterResponse, CreateClusterError, Credentials | HttpClient.HttpClient>;
export type CreateClusterV2Error = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new MSK cluster.
 */
export declare const createClusterV2: API.OperationMethod<CreateClusterV2Request, CreateClusterV2Response, CreateClusterV2Error, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new MSK configuration.
 */
export declare const createConfiguration: API.OperationMethod<CreateConfigurationRequest, CreateConfigurationResponse, CreateConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateReplicatorError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates the replicator.
 */
export declare const createReplicator: API.OperationMethod<CreateReplicatorRequest, CreateReplicatorResponse, CreateReplicatorError, Credentials | HttpClient.HttpClient>;
export type CreateTopicError = BadRequestException | ClusterConnectivityException | ConflictException | ControllerMovedException | ForbiddenException | GroupSubscribedToTopicException | InternalServerErrorException | KafkaRequestException | KafkaTimeoutException | NotControllerException | ReassignmentInProgressException | ServiceUnavailableException | TooManyRequestsException | TopicExistsException | UnauthorizedException | UnknownTopicOrPartitionException | ServerlessUnsupported | CommonErrors;
/**
 * Creates a topic in the specified MSK cluster.
 */
export declare const createTopic: API.OperationMethod<CreateTopicRequest, CreateTopicResponse, CreateTopicError, Credentials | HttpClient.HttpClient>;
export type CreateVpcConnectionError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new MSK VPC connection.
 */
export declare const createVpcConnection: API.OperationMethod<CreateVpcConnectionRequest, CreateVpcConnectionResponse, CreateVpcConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the channel specified by channelArn from the cluster specified by clusterArn. The channel transitions through DELETING and is removed when the asynchronous delete completes.
 */
export declare const deleteChannel: API.OperationMethod<DeleteChannelRequest, DeleteChannelResponse, DeleteChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Deletes the MSK cluster specified by the Amazon Resource Name (ARN) in the request.
 */
export declare const deleteCluster: API.OperationMethod<DeleteClusterRequest, DeleteClusterResponse, DeleteClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterPolicyError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Deletes the MSK cluster policy specified by the Amazon Resource Name (ARN) in the request.
 */
export declare const deleteClusterPolicy: API.OperationMethod<DeleteClusterPolicyRequest, DeleteClusterPolicyResponse, DeleteClusterPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Deletes an MSK Configuration.
 */
export declare const deleteConfiguration: API.OperationMethod<DeleteConfigurationRequest, DeleteConfigurationResponse, DeleteConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteReplicatorError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a replicator.
 */
export declare const deleteReplicator: API.OperationMethod<DeleteReplicatorRequest, DeleteReplicatorResponse, DeleteReplicatorError, Credentials | HttpClient.HttpClient>;
export type DeleteTopicError = BadRequestException | ClusterConnectivityException | ControllerMovedException | ForbiddenException | GroupSubscribedToTopicException | InternalServerErrorException | KafkaRequestException | KafkaTimeoutException | NotControllerException | NotFoundException | ReassignmentInProgressException | UnknownTopicOrPartitionException | ServerlessUnsupported | CommonErrors;
/**
 * Deletes a topic in the specified MSK cluster.
 */
export declare const deleteTopic: API.OperationMethod<DeleteTopicRequest, DeleteTopicResponse, DeleteTopicError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcConnectionError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Deletes a MSK VPC connection.
 */
export declare const deleteVpcConnection: API.OperationMethod<DeleteVpcConnectionRequest, DeleteVpcConnectionResponse, DeleteVpcConnectionError, Credentials | HttpClient.HttpClient>;
export type DescribeChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns the current configuration and state of a channel.
 */
export declare const describeChannel: API.OperationMethod<DescribeChannelRequest, DescribeChannelResponse, DescribeChannelError, Credentials | HttpClient.HttpClient>;
export type DescribeClusterError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of the MSK cluster whose Amazon Resource Name (ARN) is specified in the request.
 */
export declare const describeCluster: API.OperationMethod<DescribeClusterRequest, DescribeClusterResponse, DescribeClusterError, Credentials | HttpClient.HttpClient>;
export type DescribeClusterOperationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of the cluster operation specified by the ARN.
 */
export declare const describeClusterOperation: API.OperationMethod<DescribeClusterOperationRequest, DescribeClusterOperationResponse, DescribeClusterOperationError, Credentials | HttpClient.HttpClient>;
export type DescribeClusterOperationV2Error = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of the cluster operation specified by the ARN.
 */
export declare const describeClusterOperationV2: API.OperationMethod<DescribeClusterOperationV2Request, DescribeClusterOperationV2Response, DescribeClusterOperationV2Error, Credentials | HttpClient.HttpClient>;
export type DescribeClusterV2Error = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of the MSK cluster whose Amazon Resource Name (ARN) is specified in the request.
 */
export declare const describeClusterV2: API.OperationMethod<DescribeClusterV2Request, DescribeClusterV2Response, DescribeClusterV2Error, Credentials | HttpClient.HttpClient>;
export type DescribeConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of this MSK configuration.
 */
export declare const describeConfiguration: API.OperationMethod<DescribeConfigurationRequest, DescribeConfigurationResponse, DescribeConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeConfigurationRevisionError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of this revision of the configuration.
 */
export declare const describeConfigurationRevision: API.OperationMethod<DescribeConfigurationRevisionRequest, DescribeConfigurationRevisionResponse, DescribeConfigurationRevisionError, Credentials | HttpClient.HttpClient>;
export type DescribeReplicatorError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Describes a replicator.
 */
export declare const describeReplicator: API.OperationMethod<DescribeReplicatorRequest, DescribeReplicatorResponse, DescribeReplicatorError, Credentials | HttpClient.HttpClient>;
export type DescribeTopicError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | UnauthorizedException | ServerlessUnsupported | CommonErrors;
/**
 * Returns topic details of this topic on a MSK cluster.
 */
export declare const describeTopic: API.OperationMethod<DescribeTopicRequest, DescribeTopicResponse, DescribeTopicError, Credentials | HttpClient.HttpClient>;
export type DescribeTopicPartitionsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Returns partition details of this topic on a MSK cluster.
 */
export declare const describeTopicPartitions: API.PaginatedOperationMethod<DescribeTopicPartitionsRequest, DescribeTopicPartitionsResponse, DescribeTopicPartitionsError, Credentials | HttpClient.HttpClient, TopicPartitionInfo>;
export type DescribeVpcConnectionError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of this MSK VPC connection.
 */
export declare const describeVpcConnection: API.OperationMethod<DescribeVpcConnectionRequest, DescribeVpcConnectionResponse, DescribeVpcConnectionError, Credentials | HttpClient.HttpClient>;
export type GetBootstrapBrokersError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | UnauthorizedException | NotFoundException | CommonErrors;
/**
 * A list of brokers that a client application can use to bootstrap. This list doesn't necessarily include all of the brokers in the cluster. The following Python 3.6 example shows how you can use the Amazon Resource Name (ARN) of a cluster to get its bootstrap brokers. If you don't know the ARN of your cluster, you can use the `ListClusters` operation to get the ARNs of all the clusters in this account and Region.
 */
export declare const getBootstrapBrokers: API.OperationMethod<GetBootstrapBrokersRequest, GetBootstrapBrokersResponse, GetBootstrapBrokersError, Credentials | HttpClient.HttpClient>;
export type GetClusterPolicyError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Get the MSK cluster policy specified by the Amazon Resource Name (ARN) in the request.
 */
export declare const getClusterPolicy: API.OperationMethod<GetClusterPolicyRequest, GetClusterPolicyResponse, GetClusterPolicyError, Credentials | HttpClient.HttpClient>;
export type GetCompatibleKafkaVersionsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets the Apache Kafka versions to which you can update the MSK cluster.
 */
export declare const getCompatibleKafkaVersions: API.OperationMethod<GetCompatibleKafkaVersionsRequest, GetCompatibleKafkaVersionsResponse, GetCompatibleKafkaVersionsError, Credentials | HttpClient.HttpClient>;
export type ListChannelsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns the list of channels in a cluster.
 */
export declare const listChannels: API.OperationMethod<ListChannelsRequest, ListChannelsResponse, ListChannelsError, Credentials | HttpClient.HttpClient>;
export type ListClientVpcConnectionsError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the VPC connections in this Region.
 */
export declare const listClientVpcConnections: API.PaginatedOperationMethod<ListClientVpcConnectionsRequest, ListClientVpcConnectionsResponse, ListClientVpcConnectionsError, Credentials | HttpClient.HttpClient, ClientVpcConnection>;
export type ListClusterOperationsError = BadRequestException | ForbiddenException | InternalServerErrorException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the operations that have been performed on the specified MSK cluster.
 */
export declare const listClusterOperations: API.PaginatedOperationMethod<ListClusterOperationsRequest, ListClusterOperationsResponse, ListClusterOperationsError, Credentials | HttpClient.HttpClient, ClusterOperationInfo>;
export type ListClusterOperationsV2Error = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the operations that have been performed on the specified MSK cluster.
 */
export declare const listClusterOperationsV2: API.PaginatedOperationMethod<ListClusterOperationsV2Request, ListClusterOperationsV2Response, ListClusterOperationsV2Error, Credentials | HttpClient.HttpClient, ClusterOperationV2Summary>;
export type ListClustersError = BadRequestException | ForbiddenException | InternalServerErrorException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the MSK clusters in the current Region.
 */
export declare const listClusters: API.PaginatedOperationMethod<ListClustersRequest, ListClustersResponse, ListClustersError, Credentials | HttpClient.HttpClient, ClusterInfo>;
export type ListClustersV2Error = BadRequestException | ForbiddenException | InternalServerErrorException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the MSK clusters in the current Region.
 */
export declare const listClustersV2: API.PaginatedOperationMethod<ListClustersV2Request, ListClustersV2Response, ListClustersV2Error, Credentials | HttpClient.HttpClient, Cluster>;
export type ListConfigurationRevisionsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the MSK configurations in this Region.
 */
export declare const listConfigurationRevisions: API.PaginatedOperationMethod<ListConfigurationRevisionsRequest, ListConfigurationRevisionsResponse, ListConfigurationRevisionsError, Credentials | HttpClient.HttpClient, ConfigurationRevision>;
export type ListConfigurationsError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the MSK configurations in this Region.
 */
export declare const listConfigurations: API.PaginatedOperationMethod<ListConfigurationsRequest, ListConfigurationsResponse, ListConfigurationsError, Credentials | HttpClient.HttpClient, Configuration>;
export type ListKafkaVersionsError = BadRequestException | ForbiddenException | InternalServerErrorException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of Apache Kafka versions.
 */
export declare const listKafkaVersions: API.PaginatedOperationMethod<ListKafkaVersionsRequest, ListKafkaVersionsResponse, ListKafkaVersionsError, Credentials | HttpClient.HttpClient, KafkaVersion>;
export type ListNodesError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Returns a list of the broker nodes in the cluster.
 */
export declare const listNodes: API.PaginatedOperationMethod<ListNodesRequest, ListNodesResponse, ListNodesError, Credentials | HttpClient.HttpClient, NodeInfo>;
export type ListReplicatorsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Lists the replicators.
 */
export declare const listReplicators: API.PaginatedOperationMethod<ListReplicatorsRequest, ListReplicatorsResponse, ListReplicatorsError, Credentials | HttpClient.HttpClient, ReplicatorSummary>;
export type ListScramSecretsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of the Scram Secrets associated with an Amazon MSK cluster.
 */
export declare const listScramSecrets: API.PaginatedOperationMethod<ListScramSecretsRequest, ListScramSecretsResponse, ListScramSecretsError, Credentials | HttpClient.HttpClient, string>;
export type ListTagsForResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Returns a list of the tags associated with the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTopicsError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | NotFoundException | ServerlessUnsupported | CommonErrors;
/**
 * List topics in a MSK cluster.
 */
export declare const listTopics: API.PaginatedOperationMethod<ListTopicsRequest, ListTopicsResponse, ListTopicsError, Credentials | HttpClient.HttpClient, TopicInfo>;
export type ListVpcConnectionsError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the VPC connections in this Region.
 */
export declare const listVpcConnections: API.PaginatedOperationMethod<ListVpcConnectionsRequest, ListVpcConnectionsResponse, ListVpcConnectionsError, Credentials | HttpClient.HttpClient, VpcConnection>;
export type PutClusterPolicyError = BadRequestException | ForbiddenException | InternalServerErrorException | CommonErrors;
/**
 * Creates or updates the MSK cluster policy specified by the cluster Amazon Resource Name (ARN) in the request.
 */
export declare const putClusterPolicy: API.OperationMethod<PutClusterPolicyRequest, PutClusterPolicyResponse, PutClusterPolicyError, Credentials | HttpClient.HttpClient>;
export type RebootBrokerError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Reboots brokers.
 */
export declare const rebootBroker: API.OperationMethod<RebootBrokerRequest, RebootBrokerResponse, RebootBrokerError, Credentials | HttpClient.HttpClient>;
export type RejectClientVpcConnectionError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns empty response.
 */
export declare const rejectClientVpcConnection: API.OperationMethod<RejectClientVpcConnectionRequest, RejectClientVpcConnectionResponse, RejectClientVpcConnectionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Adds tags to the specified MSK resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Removes the tags associated with the keys that are provided in the query.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBrokerCountError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates the number of broker nodes in the cluster.
 */
export declare const updateBrokerCount: API.OperationMethod<UpdateBrokerCountRequest, UpdateBrokerCountResponse, UpdateBrokerCountError, Credentials | HttpClient.HttpClient>;
export type UpdateBrokerStorageError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates the EBS storage associated with MSK brokers.
 */
export declare const updateBrokerStorage: API.OperationMethod<UpdateBrokerStorageRequest, UpdateBrokerStorageResponse, UpdateBrokerStorageError, Credentials | HttpClient.HttpClient>;
export type UpdateBrokerTypeError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates EC2 instance type.
 */
export declare const updateBrokerType: API.OperationMethod<UpdateBrokerTypeRequest, UpdateBrokerTypeResponse, UpdateBrokerTypeError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates the destination configuration of an existing channel. Exactly one of icebergDestinationUpdate or s3DestinationUpdate must be supplied.
 */
export declare const updateChannel: API.OperationMethod<UpdateChannelRequest, UpdateChannelResponse, UpdateChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates the cluster with the configuration that is specified in the request body.
 */
export declare const updateClusterConfiguration: API.OperationMethod<UpdateClusterConfigurationRequest, UpdateClusterConfigurationResponse, UpdateClusterConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterKafkaVersionError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates the Apache Kafka version for the cluster.
 */
export declare const updateClusterKafkaVersion: API.OperationMethod<UpdateClusterKafkaVersionRequest, UpdateClusterKafkaVersionResponse, UpdateClusterKafkaVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates an MSK configuration.
 */
export declare const updateConfiguration: API.OperationMethod<UpdateConfigurationRequest, UpdateConfigurationResponse, UpdateConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectivityError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates the cluster's connectivity configuration.
 */
export declare const updateConnectivity: API.OperationMethod<UpdateConnectivityRequest, UpdateConnectivityResponse, UpdateConnectivityError, Credentials | HttpClient.HttpClient>;
export type UpdateMonitoringError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates the monitoring settings for the cluster. You can use this operation to specify which Apache Kafka metrics you want Amazon MSK to send to Amazon CloudWatch. You can also specify settings for open monitoring with Prometheus.
 */
export declare const updateMonitoring: API.OperationMethod<UpdateMonitoringRequest, UpdateMonitoringResponse, UpdateMonitoringError, Credentials | HttpClient.HttpClient>;
export type UpdateRebalancingError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Use this resource to update the intelligent rebalancing status of an Amazon MSK Provisioned cluster with Express brokers.
 */
export declare const updateRebalancing: API.OperationMethod<UpdateRebalancingRequest, UpdateRebalancingResponse, UpdateRebalancingError, Credentials | HttpClient.HttpClient>;
export type UpdateReplicationInfoError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates replication info of a replicator.
 */
export declare const updateReplicationInfo: API.OperationMethod<UpdateReplicationInfoRequest, UpdateReplicationInfoResponse, UpdateReplicationInfoError, Credentials | HttpClient.HttpClient>;
export type UpdateSecurityError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates the security settings for the cluster. You can use this operation to specify encryption and authentication on existing clusters.
 */
export declare const updateSecurity: API.OperationMethod<UpdateSecurityRequest, UpdateSecurityResponse, UpdateSecurityError, Credentials | HttpClient.HttpClient>;
export type UpdateStorageError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates cluster broker volume size (or) sets cluster storage mode to TIERED.
 */
export declare const updateStorage: API.OperationMethod<UpdateStorageRequest, UpdateStorageResponse, UpdateStorageError, Credentials | HttpClient.HttpClient>;
export type UpdateTopicError = BadRequestException | ClusterConnectivityException | ControllerMovedException | ForbiddenException | GroupSubscribedToTopicException | InternalServerErrorException | KafkaRequestException | KafkaTimeoutException | NotControllerException | NotFoundException | ReassignmentInProgressException | ServiceUnavailableException | UnauthorizedException | UnknownTopicOrPartitionException | ServerlessUnsupported | CommonErrors;
/**
 * Updates the configuration of the specified topic.
 */
export declare const updateTopic: API.OperationMethod<UpdateTopicRequest, UpdateTopicResponse, UpdateTopicError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=kafka.d.ts.map