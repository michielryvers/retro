import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import * as T from "../traits.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly retryAfterSeconds: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly retryAfterSeconds: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly retryAfterSeconds: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
export interface StageKey {
    restApiId?: string;
    stageName?: string;
}
export type ListOfStageKeys = StageKey[];
export type MapOfStringToString = {
    [key: string]: string | undefined;
};
export interface CreateApiKeyRequest {
    name?: string;
    description?: string;
    enabled?: boolean;
    generateDistinctId?: boolean;
    value?: string | redacted.Redacted<string>;
    stageKeys?: StageKey[];
    customerId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type ListOfString = string[];
export interface ApiKey {
    id?: string;
    value?: string | redacted.Redacted<string>;
    name?: string;
    customerId?: string;
    description?: string;
    enabled?: boolean;
    createdDate?: Date;
    lastUpdatedDate?: Date;
    stageKeys?: string[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export type AuthorizerType = "TOKEN" | "REQUEST" | "COGNITO_USER_POOLS" | (string & {});
export type ProviderARN = string;
export type ListOfARNs = string[];
export interface CreateAuthorizerRequest {
    restApiId: string;
    name: string;
    type: AuthorizerType;
    providerARNs?: string[];
    authType?: string;
    authorizerUri?: string;
    authorizerCredentials?: string;
    identitySource?: string;
    identityValidationExpression?: string;
    authorizerResultTtlInSeconds?: number;
}
export interface Authorizer {
    id?: string;
    name?: string;
    type?: AuthorizerType;
    providerARNs?: string[];
    authType?: string;
    authorizerUri?: string;
    authorizerCredentials?: string;
    identitySource?: string;
    identityValidationExpression?: string;
    authorizerResultTtlInSeconds?: number;
}
export interface CreateBasePathMappingRequest {
    domainName: string;
    domainNameId?: string;
    basePath?: string;
    restApiId: string;
    stage?: string;
}
export interface BasePathMapping {
    basePath?: string;
    restApiId?: string;
    stage?: string;
}
export type CacheClusterSize = "0.5" | "1.6" | "6.1" | "13.5" | "28.4" | "58.2" | "118" | "237" | (string & {});
export interface DeploymentCanarySettings {
    percentTraffic?: number;
    stageVariableOverrides?: {
        [key: string]: string | undefined;
    };
    useStageCache?: boolean;
}
export interface CreateDeploymentRequest {
    restApiId: string;
    stageName?: string;
    stageDescription?: string;
    description?: string;
    cacheClusterEnabled?: boolean;
    cacheClusterSize?: CacheClusterSize;
    variables?: {
        [key: string]: string | undefined;
    };
    canarySettings?: DeploymentCanarySettings;
    tracingEnabled?: boolean;
}
export interface MethodSnapshot {
    authorizationType?: string;
    apiKeyRequired?: boolean;
}
export type MapOfMethodSnapshot = {
    [key: string]: MethodSnapshot | undefined;
};
export type PathToMapOfMethodSnapshot = {
    [key: string]: {
        [key: string]: MethodSnapshot | undefined;
    } | undefined;
};
export interface Deployment {
    id?: string;
    description?: string;
    createdDate?: Date;
    apiSummary?: {
        [key: string]: {
            [key: string]: MethodSnapshot | undefined;
        } | undefined;
    };
}
export type DocumentationPartType = "API" | "AUTHORIZER" | "MODEL" | "RESOURCE" | "METHOD" | "PATH_PARAMETER" | "QUERY_PARAMETER" | "REQUEST_HEADER" | "REQUEST_BODY" | "RESPONSE" | "RESPONSE_HEADER" | "RESPONSE_BODY" | (string & {});
export type DocumentationPartLocationStatusCode = string;
export interface DocumentationPartLocation {
    type: DocumentationPartType;
    path?: string;
    method?: string;
    statusCode?: string;
    name?: string;
}
export interface CreateDocumentationPartRequest {
    restApiId: string;
    location: DocumentationPartLocation;
    properties: string;
}
export interface DocumentationPart {
    id?: string;
    location?: DocumentationPartLocation;
    properties?: string;
}
export interface CreateDocumentationVersionRequest {
    restApiId: string;
    documentationVersion: string;
    stageName?: string;
    description?: string;
}
export interface DocumentationVersion {
    version?: string;
    createdDate?: Date;
    description?: string;
}
export type EndpointType = "REGIONAL" | "EDGE" | "PRIVATE" | (string & {});
export type ListOfEndpointType = EndpointType[];
export type IpAddressType = "ipv4" | "dualstack" | (string & {});
export interface EndpointConfiguration {
    types?: EndpointType[];
    ipAddressType?: IpAddressType;
    vpcEndpointIds?: string[];
}
export type SecurityPolicy = "TLS_1_0" | "TLS_1_2" | "SecurityPolicy_TLS13_1_3_2025_09" | "SecurityPolicy_TLS13_1_3_FIPS_2025_09" | "SecurityPolicy_TLS13_1_2_PFS_PQ_2025_09" | "SecurityPolicy_TLS13_1_2_FIPS_PQ_2025_09" | "SecurityPolicy_TLS13_1_2_FIPS_PFS_PQ_2025_09" | "SecurityPolicy_TLS13_1_2_Ext2_PQ_2025_09" | "SecurityPolicy_TLS13_1_2_Ext2_FIPS_PQ_2025_09" | "SecurityPolicy_TLS13_1_2_PQ_2025_09" | "SecurityPolicy_TLS13_1_2_2021_06" | "SecurityPolicy_TLS13_2025_EDGE" | "SecurityPolicy_TLS12_PFS_2025_EDGE" | "SecurityPolicy_TLS12_2018_EDGE" | (string & {});
export type EndpointAccessMode = "BASIC" | "STRICT" | (string & {});
export interface MutualTlsAuthenticationInput {
    truststoreUri?: string;
    truststoreVersion?: string;
}
export type RoutingMode = "BASE_PATH_MAPPING_ONLY" | "ROUTING_RULE_ONLY" | "ROUTING_RULE_THEN_BASE_PATH_MAPPING" | (string & {});
export interface CreateDomainNameRequest {
    domainName: string;
    certificateName?: string;
    certificateBody?: string;
    certificatePrivateKey?: string;
    certificateChain?: string;
    certificateArn?: string;
    regionalCertificateName?: string;
    regionalCertificateArn?: string;
    endpointConfiguration?: EndpointConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
    securityPolicy?: SecurityPolicy;
    endpointAccessMode?: EndpointAccessMode;
    mutualTlsAuthentication?: MutualTlsAuthenticationInput;
    ownershipVerificationCertificateArn?: string;
    policy?: string;
    routingMode?: RoutingMode;
}
export type DomainNameStatus = "AVAILABLE" | "UPDATING" | "PENDING" | "PENDING_CERTIFICATE_REIMPORT" | "PENDING_OWNERSHIP_VERIFICATION" | "FAILED" | (string & {});
export interface MutualTlsAuthentication {
    truststoreUri?: string;
    truststoreVersion?: string;
    truststoreWarnings?: string[];
}
export interface DomainName {
    domainName?: string;
    domainNameId?: string;
    domainNameArn?: string;
    certificateName?: string;
    certificateArn?: string;
    certificateUploadDate?: Date;
    regionalDomainName?: string;
    regionalHostedZoneId?: string;
    regionalCertificateName?: string;
    regionalCertificateArn?: string;
    distributionDomainName?: string;
    distributionHostedZoneId?: string;
    endpointConfiguration?: EndpointConfiguration;
    domainNameStatus?: DomainNameStatus;
    domainNameStatusMessage?: string;
    securityPolicy?: SecurityPolicy;
    endpointAccessMode?: EndpointAccessMode;
    tags?: {
        [key: string]: string | undefined;
    };
    mutualTlsAuthentication?: MutualTlsAuthentication;
    ownershipVerificationCertificateArn?: string;
    managementPolicy?: string;
    policy?: string;
    routingMode?: RoutingMode;
}
export type AccessAssociationSourceType = "VPCE" | (string & {});
export interface CreateDomainNameAccessAssociationRequest {
    domainNameArn: string;
    accessAssociationSourceType: AccessAssociationSourceType;
    accessAssociationSource: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface DomainNameAccessAssociation {
    domainNameAccessAssociationArn?: string;
    domainNameArn?: string;
    accessAssociationSourceType?: AccessAssociationSourceType;
    accessAssociationSource?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateModelRequest {
    restApiId: string;
    name: string;
    description?: string;
    schema?: string;
    contentType: string;
}
export interface Model {
    id?: string;
    name?: string;
    description?: string;
    schema?: string;
    contentType?: string;
}
export interface CreateRequestValidatorRequest {
    restApiId: string;
    name?: string;
    validateRequestBody?: boolean;
    validateRequestParameters?: boolean;
}
export interface RequestValidator {
    id?: string;
    name?: string;
    validateRequestBody?: boolean;
    validateRequestParameters?: boolean;
}
export interface CreateResourceRequest {
    restApiId: string;
    parentId: string;
    pathPart: string;
}
export type MapOfStringToBoolean = {
    [key: string]: boolean | undefined;
};
export type StatusCode = string;
export interface MethodResponse {
    statusCode?: string;
    responseParameters?: {
        [key: string]: boolean | undefined;
    };
    responseModels?: {
        [key: string]: string | undefined;
    };
}
export type MapOfMethodResponse = {
    [key: string]: MethodResponse | undefined;
};
export type IntegrationType = "HTTP" | "AWS" | "MOCK" | "HTTP_PROXY" | "AWS_PROXY" | (string & {});
export type ConnectionType = "INTERNET" | "VPC_LINK" | (string & {});
export type ContentHandlingStrategy = "CONVERT_TO_BINARY" | "CONVERT_TO_TEXT" | (string & {});
export interface IntegrationResponse {
    statusCode?: string;
    selectionPattern?: string;
    responseParameters?: {
        [key: string]: string | undefined;
    };
    responseTemplates?: {
        [key: string]: string | undefined;
    };
    contentHandling?: ContentHandlingStrategy;
}
export type MapOfIntegrationResponse = {
    [key: string]: IntegrationResponse | undefined;
};
export interface TlsConfig {
    insecureSkipVerification?: boolean;
}
export type ResponseTransferMode = "BUFFERED" | "STREAM" | (string & {});
export interface Integration {
    type?: IntegrationType;
    httpMethod?: string;
    uri?: string;
    connectionType?: ConnectionType;
    connectionId?: string;
    credentials?: string;
    requestParameters?: {
        [key: string]: string | undefined;
    };
    requestTemplates?: {
        [key: string]: string | undefined;
    };
    passthroughBehavior?: string;
    contentHandling?: ContentHandlingStrategy;
    timeoutInMillis?: number;
    cacheNamespace?: string;
    cacheKeyParameters?: string[];
    integrationResponses?: {
        [key: string]: IntegrationResponse | undefined;
    };
    tlsConfig?: TlsConfig;
    responseTransferMode?: ResponseTransferMode;
    integrationTarget?: string;
}
export interface Method {
    httpMethod?: string;
    authorizationType?: string;
    authorizerId?: string;
    apiKeyRequired?: boolean;
    requestValidatorId?: string;
    operationName?: string;
    requestParameters?: {
        [key: string]: boolean | undefined;
    };
    requestModels?: {
        [key: string]: string | undefined;
    };
    methodResponses?: {
        [key: string]: MethodResponse | undefined;
    };
    methodIntegration?: Integration;
    authorizationScopes?: string[];
}
export type MapOfMethod = {
    [key: string]: Method | undefined;
};
export interface Resource {
    id?: string;
    parentId?: string;
    pathPart?: string;
    path?: string;
    resourceMethods?: {
        [key: string]: Method | undefined;
    };
}
export type ApiKeySourceType = "HEADER" | "AUTHORIZER" | (string & {});
export interface CreateRestApiRequest {
    name: string;
    description?: string;
    version?: string;
    cloneFrom?: string;
    binaryMediaTypes?: string[];
    minimumCompressionSize?: number;
    apiKeySource?: ApiKeySourceType;
    endpointConfiguration?: EndpointConfiguration;
    policy?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    disableExecuteApiEndpoint?: boolean;
    securityPolicy?: SecurityPolicy;
    endpointAccessMode?: EndpointAccessMode;
}
export type ApiStatus = "UPDATING" | "AVAILABLE" | "PENDING" | "FAILED" | (string & {});
export interface RestApi {
    id?: string;
    name?: string;
    description?: string;
    createdDate?: Date;
    version?: string;
    warnings?: string[];
    binaryMediaTypes?: string[];
    minimumCompressionSize?: number;
    apiKeySource?: ApiKeySourceType;
    endpointConfiguration?: EndpointConfiguration;
    policy?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    disableExecuteApiEndpoint?: boolean;
    rootResourceId?: string;
    securityPolicy?: SecurityPolicy;
    endpointAccessMode?: EndpointAccessMode;
    apiStatus?: ApiStatus;
    apiStatusMessage?: string;
}
export interface CanarySettings {
    percentTraffic?: number;
    deploymentId?: string;
    stageVariableOverrides?: {
        [key: string]: string | undefined;
    };
    useStageCache?: boolean;
}
export interface CreateStageRequest {
    restApiId: string;
    stageName: string;
    deploymentId: string;
    description?: string;
    cacheClusterEnabled?: boolean;
    cacheClusterSize?: CacheClusterSize;
    variables?: {
        [key: string]: string | undefined;
    };
    documentationVersion?: string;
    canarySettings?: CanarySettings;
    tracingEnabled?: boolean;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type CacheClusterStatus = "CREATE_IN_PROGRESS" | "AVAILABLE" | "DELETE_IN_PROGRESS" | "NOT_AVAILABLE" | "FLUSH_IN_PROGRESS" | (string & {});
export type UnauthorizedCacheControlHeaderStrategy = "FAIL_WITH_403" | "SUCCEED_WITH_RESPONSE_HEADER" | "SUCCEED_WITHOUT_RESPONSE_HEADER" | (string & {});
export interface MethodSetting {
    metricsEnabled?: boolean;
    loggingLevel?: string;
    dataTraceEnabled?: boolean;
    throttlingBurstLimit?: number;
    throttlingRateLimit?: number;
    cachingEnabled?: boolean;
    cacheTtlInSeconds?: number;
    cacheDataEncrypted?: boolean;
    requireAuthorizationForCacheControl?: boolean;
    unauthorizedCacheControlHeaderStrategy?: UnauthorizedCacheControlHeaderStrategy;
}
export type MapOfMethodSettings = {
    [key: string]: MethodSetting | undefined;
};
export interface AccessLogSettings {
    format?: string;
    destinationArn?: string;
}
export interface Stage {
    deploymentId?: string;
    clientCertificateId?: string;
    stageName?: string;
    description?: string;
    cacheClusterEnabled?: boolean;
    cacheClusterSize?: CacheClusterSize;
    cacheClusterStatus?: CacheClusterStatus;
    methodSettings?: {
        [key: string]: MethodSetting | undefined;
    };
    variables?: {
        [key: string]: string | undefined;
    };
    documentationVersion?: string;
    accessLogSettings?: AccessLogSettings;
    canarySettings?: CanarySettings;
    tracingEnabled?: boolean;
    webAclArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    createdDate?: Date;
    lastUpdatedDate?: Date;
}
export interface ThrottleSettings {
    burstLimit?: number;
    rateLimit?: number;
}
export type MapOfApiStageThrottleSettings = {
    [key: string]: ThrottleSettings | undefined;
};
export interface ApiStage {
    apiId?: string;
    stage?: string;
    throttle?: {
        [key: string]: ThrottleSettings | undefined;
    };
}
export type ListOfApiStage = ApiStage[];
export type QuotaPeriodType = "DAY" | "WEEK" | "MONTH" | (string & {});
export interface QuotaSettings {
    limit?: number;
    offset?: number;
    period?: QuotaPeriodType;
}
export interface CreateUsagePlanRequest {
    name: string;
    description?: string;
    apiStages?: ApiStage[];
    throttle?: ThrottleSettings;
    quota?: QuotaSettings;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface UsagePlan {
    id?: string;
    name?: string;
    description?: string;
    apiStages?: ApiStage[];
    throttle?: ThrottleSettings;
    quota?: QuotaSettings;
    productCode?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateUsagePlanKeyRequest {
    usagePlanId: string;
    keyId: string;
    keyType: string;
}
export interface UsagePlanKey {
    id?: string;
    type?: string;
    value?: string;
    name?: string;
}
export interface CreateVpcLinkRequest {
    name: string;
    description?: string;
    targetArns: string[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export type VpcLinkStatus = "AVAILABLE" | "PENDING" | "DELETING" | "FAILED" | (string & {});
export interface VpcLink {
    id?: string;
    name?: string;
    description?: string;
    targetArns?: string[];
    status?: VpcLinkStatus;
    statusMessage?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface DeleteApiKeyRequest {
    apiKey: string;
}
export interface DeleteApiKeyResponse {
}
export interface DeleteAuthorizerRequest {
    restApiId: string;
    authorizerId: string;
}
export interface DeleteAuthorizerResponse {
}
export interface DeleteBasePathMappingRequest {
    domainName: string;
    domainNameId?: string;
    basePath: string;
}
export interface DeleteBasePathMappingResponse {
}
export interface DeleteClientCertificateRequest {
    clientCertificateId: string;
}
export interface DeleteClientCertificateResponse {
}
export interface DeleteDeploymentRequest {
    restApiId: string;
    deploymentId: string;
}
export interface DeleteDeploymentResponse {
}
export interface DeleteDocumentationPartRequest {
    restApiId: string;
    documentationPartId: string;
}
export interface DeleteDocumentationPartResponse {
}
export interface DeleteDocumentationVersionRequest {
    restApiId: string;
    documentationVersion: string;
}
export interface DeleteDocumentationVersionResponse {
}
export interface DeleteDomainNameRequest {
    domainName: string;
    domainNameId?: string;
}
export interface DeleteDomainNameResponse {
}
export interface DeleteDomainNameAccessAssociationRequest {
    domainNameAccessAssociationArn: string;
}
export interface DeleteDomainNameAccessAssociationResponse {
}
export type GatewayResponseType = "DEFAULT_4XX" | "DEFAULT_5XX" | "RESOURCE_NOT_FOUND" | "UNAUTHORIZED" | "INVALID_API_KEY" | "ACCESS_DENIED" | "AUTHORIZER_FAILURE" | "AUTHORIZER_CONFIGURATION_ERROR" | "INVALID_SIGNATURE" | "EXPIRED_TOKEN" | "MISSING_AUTHENTICATION_TOKEN" | "INTEGRATION_FAILURE" | "INTEGRATION_TIMEOUT" | "API_CONFIGURATION_ERROR" | "UNSUPPORTED_MEDIA_TYPE" | "BAD_REQUEST_PARAMETERS" | "BAD_REQUEST_BODY" | "REQUEST_TOO_LARGE" | "THROTTLED" | "QUOTA_EXCEEDED" | "WAF_FILTERED" | (string & {});
export interface DeleteGatewayResponseRequest {
    restApiId: string;
    responseType: GatewayResponseType;
}
export interface DeleteGatewayResponseResponse {
}
export interface DeleteIntegrationRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
}
export interface DeleteIntegrationResponse {
}
export interface DeleteIntegrationResponseRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    statusCode: string;
}
export interface DeleteIntegrationResponseResponse {
}
export interface DeleteMethodRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
}
export interface DeleteMethodResponse {
}
export interface DeleteMethodResponseRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    statusCode: string;
}
export interface DeleteMethodResponseResponse {
}
export interface DeleteModelRequest {
    restApiId: string;
    modelName: string;
}
export interface DeleteModelResponse {
}
export interface DeleteRequestValidatorRequest {
    restApiId: string;
    requestValidatorId: string;
}
export interface DeleteRequestValidatorResponse {
}
export interface DeleteResourceRequest {
    restApiId: string;
    resourceId: string;
}
export interface DeleteResourceResponse {
}
export interface DeleteRestApiRequest {
    restApiId: string;
}
export interface DeleteRestApiResponse {
}
export interface DeleteStageRequest {
    restApiId: string;
    stageName: string;
}
export interface DeleteStageResponse {
}
export interface DeleteUsagePlanRequest {
    usagePlanId: string;
}
export interface DeleteUsagePlanResponse {
}
export interface DeleteUsagePlanKeyRequest {
    usagePlanId: string;
    keyId: string;
}
export interface DeleteUsagePlanKeyResponse {
}
export interface DeleteVpcLinkRequest {
    vpcLinkId: string;
}
export interface DeleteVpcLinkResponse {
}
export interface FlushStageAuthorizersCacheRequest {
    restApiId: string;
    stageName: string;
}
export interface FlushStageAuthorizersCacheResponse {
}
export interface FlushStageCacheRequest {
    restApiId: string;
    stageName: string;
}
export interface FlushStageCacheResponse {
}
export interface GenerateClientCertificateRequest {
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface ClientCertificate {
    clientCertificateId?: string;
    description?: string;
    pemEncodedCertificate?: string;
    createdDate?: Date;
    expirationDate?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetAccountRequest {
}
export interface Account {
    cloudwatchRoleArn?: string;
    throttleSettings?: ThrottleSettings;
    features?: string[];
    apiKeyVersion?: string;
}
export interface GetApiKeyRequest {
    apiKey: string;
    includeValue?: boolean;
}
export interface GetApiKeysRequest {
    position?: string;
    limit?: number;
    nameQuery?: string;
    customerId?: string;
    includeValues?: boolean;
}
export type ListOfApiKey = ApiKey[];
export interface ApiKeys {
    warnings?: string[];
    items?: ApiKey[];
    position?: string;
}
export interface GetAuthorizerRequest {
    restApiId: string;
    authorizerId: string;
}
export interface GetAuthorizersRequest {
    restApiId: string;
    position?: string;
    limit?: number;
}
export type ListOfAuthorizer = Authorizer[];
export interface Authorizers {
    items?: Authorizer[];
    position?: string;
}
export interface GetBasePathMappingRequest {
    domainName: string;
    domainNameId?: string;
    basePath: string;
}
export interface GetBasePathMappingsRequest {
    domainName: string;
    domainNameId?: string;
    position?: string;
    limit?: number;
}
export type ListOfBasePathMapping = BasePathMapping[];
export interface BasePathMappings {
    items?: BasePathMapping[];
    position?: string;
}
export interface GetClientCertificateRequest {
    clientCertificateId: string;
}
export interface GetClientCertificatesRequest {
    position?: string;
    limit?: number;
}
export type ListOfClientCertificate = ClientCertificate[];
export interface ClientCertificates {
    items?: ClientCertificate[];
    position?: string;
}
export interface GetDeploymentRequest {
    restApiId: string;
    deploymentId: string;
    embed?: string[];
}
export interface GetDeploymentsRequest {
    restApiId: string;
    position?: string;
    limit?: number;
}
export type ListOfDeployment = Deployment[];
export interface Deployments {
    items?: Deployment[];
    position?: string;
}
export interface GetDocumentationPartRequest {
    restApiId: string;
    documentationPartId: string;
}
export type LocationStatusType = "DOCUMENTED" | "UNDOCUMENTED" | (string & {});
export interface GetDocumentationPartsRequest {
    restApiId: string;
    type?: DocumentationPartType;
    nameQuery?: string;
    path?: string;
    position?: string;
    limit?: number;
    locationStatus?: LocationStatusType;
}
export type ListOfDocumentationPart = DocumentationPart[];
export interface DocumentationParts {
    items?: DocumentationPart[];
    position?: string;
}
export interface GetDocumentationVersionRequest {
    restApiId: string;
    documentationVersion: string;
}
export interface GetDocumentationVersionsRequest {
    restApiId: string;
    position?: string;
    limit?: number;
}
export type ListOfDocumentationVersion = DocumentationVersion[];
export interface DocumentationVersions {
    items?: DocumentationVersion[];
    position?: string;
}
export interface GetDomainNameRequest {
    domainName: string;
    domainNameId?: string;
}
export type ResourceOwner = "SELF" | "OTHER_ACCOUNTS" | (string & {});
export interface GetDomainNameAccessAssociationsRequest {
    position?: string;
    limit?: number;
    resourceOwner?: ResourceOwner;
}
export type ListOfDomainNameAccessAssociation = DomainNameAccessAssociation[];
export interface DomainNameAccessAssociations {
    items?: DomainNameAccessAssociation[];
    position?: string;
}
export interface GetDomainNamesRequest {
    position?: string;
    limit?: number;
    resourceOwner?: ResourceOwner;
}
export type ListOfDomainName = DomainName[];
export interface DomainNames {
    items?: DomainName[];
    position?: string;
}
export interface GetExportRequest {
    restApiId: string;
    stageName: string;
    exportType: string;
    parameters?: {
        [key: string]: string | undefined;
    };
    accepts?: string;
}
export interface ExportResponse {
    contentType?: string;
    contentDisposition?: string;
    body?: T.StreamingOutputBody;
}
export interface GetGatewayResponseRequest {
    restApiId: string;
    responseType: GatewayResponseType;
}
export interface GatewayResponse {
    responseType?: GatewayResponseType;
    statusCode?: string;
    responseParameters?: {
        [key: string]: string | undefined;
    };
    responseTemplates?: {
        [key: string]: string | undefined;
    };
    defaultResponse?: boolean;
}
export interface GetGatewayResponsesRequest {
    restApiId: string;
    position?: string;
    limit?: number;
}
export type ListOfGatewayResponse = GatewayResponse[];
export interface GatewayResponses {
    items?: GatewayResponse[];
    position?: string;
}
export interface GetIntegrationRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
}
export interface GetIntegrationResponseRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    statusCode: string;
}
export interface GetMethodRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
}
export interface GetMethodResponseRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    statusCode: string;
}
export interface GetModelRequest {
    restApiId: string;
    modelName: string;
    flatten?: boolean;
}
export interface GetModelsRequest {
    restApiId: string;
    position?: string;
    limit?: number;
}
export type ListOfModel = Model[];
export interface Models {
    items?: Model[];
    position?: string;
}
export interface GetModelTemplateRequest {
    restApiId: string;
    modelName: string;
}
export interface Template {
    value?: string;
}
export interface GetRequestValidatorRequest {
    restApiId: string;
    requestValidatorId: string;
}
export interface GetRequestValidatorsRequest {
    restApiId: string;
    position?: string;
    limit?: number;
}
export type ListOfRequestValidator = RequestValidator[];
export interface RequestValidators {
    items?: RequestValidator[];
    position?: string;
}
export interface GetResourceRequest {
    restApiId: string;
    resourceId: string;
    embed?: string[];
}
export interface GetResourcesRequest {
    restApiId: string;
    position?: string;
    limit?: number;
    embed?: string[];
}
export type ListOfResource = Resource[];
export interface Resources {
    items?: Resource[];
    position?: string;
}
export interface GetRestApiRequest {
    restApiId: string;
}
export interface GetRestApisRequest {
    position?: string;
    limit?: number;
}
export type ListOfRestApi = RestApi[];
export interface RestApis {
    items?: RestApi[];
    position?: string;
}
export interface GetSdkRequest {
    restApiId: string;
    stageName: string;
    sdkType: string;
    parameters?: {
        [key: string]: string | undefined;
    };
}
export interface SdkResponse {
    contentType?: string;
    contentDisposition?: string;
    body?: T.StreamingOutputBody;
}
export interface GetSdkTypeRequest {
    id: string;
}
export interface SdkConfigurationProperty {
    name?: string;
    friendlyName?: string;
    description?: string;
    required?: boolean;
    defaultValue?: string;
}
export type ListOfSdkConfigurationProperty = SdkConfigurationProperty[];
export interface SdkType {
    id?: string;
    friendlyName?: string;
    description?: string;
    configurationProperties?: SdkConfigurationProperty[];
}
export interface GetSdkTypesRequest {
    position?: string;
    limit?: number;
}
export type ListOfSdkType = SdkType[];
export interface SdkTypes {
    items?: SdkType[];
}
export interface GetStageRequest {
    restApiId: string;
    stageName: string;
}
export interface GetStagesRequest {
    restApiId: string;
    deploymentId?: string;
}
export type ListOfStage = Stage[];
export interface Stages {
    item?: Stage[];
}
export interface GetTagsRequest {
    resourceArn: string;
    position?: string;
    limit?: number;
}
export interface Tags {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetUsageRequest {
    usagePlanId: string;
    keyId?: string;
    startDate: string;
    endDate: string;
    position?: string;
    limit?: number;
}
export type ListOfLong = number[];
export type ListOfUsage = number[][];
export type MapOfKeyUsages = {
    [key: string]: number[][] | undefined;
};
export interface Usage {
    usagePlanId?: string;
    startDate?: string;
    endDate?: string;
    items?: {
        [key: string]: number[][] | undefined;
    };
    position?: string;
}
export interface GetUsagePlanRequest {
    usagePlanId: string;
}
export interface GetUsagePlanKeyRequest {
    usagePlanId: string;
    keyId: string;
}
export interface GetUsagePlanKeysRequest {
    usagePlanId: string;
    position?: string;
    limit?: number;
    nameQuery?: string;
}
export type ListOfUsagePlanKey = UsagePlanKey[];
export interface UsagePlanKeys {
    items?: UsagePlanKey[];
    position?: string;
}
export interface GetUsagePlansRequest {
    position?: string;
    keyId?: string;
    limit?: number;
}
export type ListOfUsagePlan = UsagePlan[];
export interface UsagePlans {
    items?: UsagePlan[];
    position?: string;
}
export interface GetVpcLinkRequest {
    vpcLinkId: string;
}
export interface GetVpcLinksRequest {
    position?: string;
    limit?: number;
}
export type ListOfVpcLink = VpcLink[];
export interface VpcLinks {
    items?: VpcLink[];
    position?: string;
}
export type ApiKeysFormat = "csv" | (string & {});
export interface ImportApiKeysRequest {
    body: T.StreamingInputBody;
    format: ApiKeysFormat;
    failOnWarnings?: boolean;
}
export interface ApiKeyIds {
    ids?: string[];
    warnings?: string[];
}
export type PutMode = "merge" | "overwrite" | (string & {});
export interface ImportDocumentationPartsRequest {
    restApiId: string;
    mode?: PutMode;
    failOnWarnings?: boolean;
    body: T.StreamingInputBody;
}
export interface DocumentationPartIds {
    ids?: string[];
    warnings?: string[];
}
export interface ImportRestApiRequest {
    failOnWarnings?: boolean;
    parameters?: {
        [key: string]: string | undefined;
    };
    body: T.StreamingInputBody;
}
export interface PutGatewayResponseRequest {
    restApiId: string;
    responseType: GatewayResponseType;
    statusCode?: string;
    responseParameters?: {
        [key: string]: string | undefined;
    };
    responseTemplates?: {
        [key: string]: string | undefined;
    };
}
export interface PutIntegrationRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    type: IntegrationType;
    integrationHttpMethod?: string;
    uri?: string;
    connectionType?: ConnectionType;
    connectionId?: string;
    credentials?: string;
    requestParameters?: {
        [key: string]: string | undefined;
    };
    requestTemplates?: {
        [key: string]: string | undefined;
    };
    passthroughBehavior?: string;
    cacheNamespace?: string;
    cacheKeyParameters?: string[];
    contentHandling?: ContentHandlingStrategy;
    timeoutInMillis?: number;
    tlsConfig?: TlsConfig;
    responseTransferMode?: ResponseTransferMode;
    integrationTarget?: string;
}
export interface PutIntegrationResponseRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    statusCode: string;
    selectionPattern?: string;
    responseParameters?: {
        [key: string]: string | undefined;
    };
    responseTemplates?: {
        [key: string]: string | undefined;
    };
    contentHandling?: ContentHandlingStrategy;
}
export interface PutMethodRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    authorizationType: string;
    authorizerId?: string;
    apiKeyRequired?: boolean;
    operationName?: string;
    requestParameters?: {
        [key: string]: boolean | undefined;
    };
    requestModels?: {
        [key: string]: string | undefined;
    };
    requestValidatorId?: string;
    authorizationScopes?: string[];
}
export interface PutMethodResponseRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    statusCode: string;
    responseParameters?: {
        [key: string]: boolean | undefined;
    };
    responseModels?: {
        [key: string]: string | undefined;
    };
}
export interface PutRestApiRequest {
    restApiId: string;
    mode?: PutMode;
    failOnWarnings?: boolean;
    parameters?: {
        [key: string]: string | undefined;
    };
    body: T.StreamingInputBody;
}
export interface RejectDomainNameAccessAssociationRequest {
    domainNameAccessAssociationArn: string;
    domainNameArn: string;
}
export interface RejectDomainNameAccessAssociationResponse {
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type MapOfStringToList = {
    [key: string]: string[] | undefined;
};
export interface TestInvokeAuthorizerRequest {
    restApiId: string;
    authorizerId: string;
    headers?: {
        [key: string]: string | undefined;
    };
    multiValueHeaders?: {
        [key: string]: string[] | undefined;
    };
    pathWithQueryString?: string;
    body?: string;
    stageVariables?: {
        [key: string]: string | undefined;
    };
    additionalContext?: {
        [key: string]: string | undefined;
    };
}
export interface TestInvokeAuthorizerResponse {
    clientStatus?: number;
    log?: string;
    latency?: number;
    principalId?: string;
    policy?: string;
    authorization?: {
        [key: string]: string[] | undefined;
    };
    claims?: {
        [key: string]: string | undefined;
    };
}
export interface TestInvokeMethodRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    pathWithQueryString?: string;
    body?: string;
    headers?: {
        [key: string]: string | undefined;
    };
    multiValueHeaders?: {
        [key: string]: string[] | undefined;
    };
    clientCertificateId?: string;
    stageVariables?: {
        [key: string]: string | undefined;
    };
}
export interface TestInvokeMethodResponse {
    status?: number;
    body?: string;
    headers?: {
        [key: string]: string | undefined;
    };
    multiValueHeaders?: {
        [key: string]: string[] | undefined;
    };
    log?: string;
    latency?: number;
}
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export type Op = "add" | "remove" | "replace" | "move" | "copy" | "test" | (string & {});
export interface PatchOperation {
    op?: Op;
    path?: string;
    value?: string;
    from?: string;
}
export type ListOfPatchOperation = PatchOperation[];
export interface UpdateAccountRequest {
    patchOperations?: PatchOperation[];
}
export interface UpdateApiKeyRequest {
    apiKey: string;
    patchOperations?: PatchOperation[];
}
export interface UpdateAuthorizerRequest {
    restApiId: string;
    authorizerId: string;
    patchOperations?: PatchOperation[];
}
export interface UpdateBasePathMappingRequest {
    domainName: string;
    domainNameId?: string;
    basePath: string;
    patchOperations?: PatchOperation[];
}
export interface UpdateClientCertificateRequest {
    clientCertificateId: string;
    patchOperations?: PatchOperation[];
}
export interface UpdateDeploymentRequest {
    restApiId: string;
    deploymentId: string;
    patchOperations?: PatchOperation[];
}
export interface UpdateDocumentationPartRequest {
    restApiId: string;
    documentationPartId: string;
    patchOperations?: PatchOperation[];
}
export interface UpdateDocumentationVersionRequest {
    restApiId: string;
    documentationVersion: string;
    patchOperations?: PatchOperation[];
}
export interface UpdateDomainNameRequest {
    domainName: string;
    domainNameId?: string;
    patchOperations?: PatchOperation[];
}
export interface UpdateGatewayResponseRequest {
    restApiId: string;
    responseType: GatewayResponseType;
    patchOperations?: PatchOperation[];
}
export interface UpdateIntegrationRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    patchOperations?: PatchOperation[];
}
export interface UpdateIntegrationResponseRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    statusCode: string;
    patchOperations?: PatchOperation[];
}
export interface UpdateMethodRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    patchOperations?: PatchOperation[];
}
export interface UpdateMethodResponseRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    statusCode: string;
    patchOperations?: PatchOperation[];
}
export interface UpdateModelRequest {
    restApiId: string;
    modelName: string;
    patchOperations?: PatchOperation[];
}
export interface UpdateRequestValidatorRequest {
    restApiId: string;
    requestValidatorId: string;
    patchOperations?: PatchOperation[];
}
export interface UpdateResourceRequest {
    restApiId: string;
    resourceId: string;
    patchOperations?: PatchOperation[];
}
export interface UpdateRestApiRequest {
    restApiId: string;
    patchOperations?: PatchOperation[];
}
export interface UpdateStageRequest {
    restApiId: string;
    stageName: string;
    patchOperations?: PatchOperation[];
}
export interface UpdateUsageRequest {
    usagePlanId: string;
    keyId: string;
    patchOperations?: PatchOperation[];
}
export interface UpdateUsagePlanRequest {
    usagePlanId: string;
    patchOperations?: PatchOperation[];
}
export interface UpdateVpcLinkRequest {
    vpcLinkId: string;
    patchOperations?: PatchOperation[];
}
export type CreateApiKeyError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Create an ApiKey resource.
 */
export declare const createApiKey: API.OperationMethod<CreateApiKeyRequest, ApiKey, CreateApiKeyError, Credentials | HttpClient.HttpClient>;
export type CreateAuthorizerError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Adds a new Authorizer resource to an existing RestApi resource.
 */
export declare const createAuthorizer: API.OperationMethod<CreateAuthorizerRequest, Authorizer, CreateAuthorizerError, Credentials | HttpClient.HttpClient>;
export type CreateBasePathMappingError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new BasePathMapping resource.
 */
export declare const createBasePathMapping: API.OperationMethod<CreateBasePathMappingRequest, BasePathMapping, CreateBasePathMappingError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a Deployment resource, which makes a specified RestApi callable over the internet.
 */
export declare const createDeployment: API.OperationMethod<CreateDeploymentRequest, Deployment, CreateDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateDocumentationPartError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a documentation part.
 */
export declare const createDocumentationPart: API.OperationMethod<CreateDocumentationPartRequest, DocumentationPart, CreateDocumentationPartError, Credentials | HttpClient.HttpClient>;
export type CreateDocumentationVersionError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a documentation version
 */
export declare const createDocumentationVersion: API.OperationMethod<CreateDocumentationVersionRequest, DocumentationVersion, CreateDocumentationVersionError, Credentials | HttpClient.HttpClient>;
export type CreateDomainNameError = BadRequestException | ConflictException | LimitExceededException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new domain name.
 */
export declare const createDomainName: API.OperationMethod<CreateDomainNameRequest, DomainName, CreateDomainNameError, Credentials | HttpClient.HttpClient>;
export type CreateDomainNameAccessAssociationError = BadRequestException | ConflictException | LimitExceededException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a domain name access association resource between an access association source and a private custom
 * domain name.
 */
export declare const createDomainNameAccessAssociation: API.OperationMethod<CreateDomainNameAccessAssociationRequest, DomainNameAccessAssociation, CreateDomainNameAccessAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateModelError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Adds a new Model resource to an existing RestApi resource.
 */
export declare const createModel: API.OperationMethod<CreateModelRequest, Model, CreateModelError, Credentials | HttpClient.HttpClient>;
export type CreateRequestValidatorError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a RequestValidator of a given RestApi.
 */
export declare const createRequestValidator: API.OperationMethod<CreateRequestValidatorRequest, RequestValidator, CreateRequestValidatorError, Credentials | HttpClient.HttpClient>;
export type CreateResourceError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a Resource resource.
 */
export declare const createResource: API.OperationMethod<CreateResourceRequest, Resource, CreateResourceError, Credentials | HttpClient.HttpClient>;
export type CreateRestApiError = BadRequestException | ConflictException | LimitExceededException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new RestApi resource.
 */
export declare const createRestApi: API.OperationMethod<CreateRestApiRequest, RestApi, CreateRestApiError, Credentials | HttpClient.HttpClient>;
export type CreateStageError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new Stage resource that references a pre-existing Deployment for the API.
 */
export declare const createStage: API.OperationMethod<CreateStageRequest, Stage, CreateStageError, Credentials | HttpClient.HttpClient>;
export type CreateUsagePlanError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a usage plan with the throttle and quota limits, as well as the associated API stages, specified in the payload.
 */
export declare const createUsagePlan: API.OperationMethod<CreateUsagePlanRequest, UsagePlan, CreateUsagePlanError, Credentials | HttpClient.HttpClient>;
export type CreateUsagePlanKeyError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a usage plan key for adding an existing API key to a usage plan.
 */
export declare const createUsagePlanKey: API.OperationMethod<CreateUsagePlanKeyRequest, UsagePlanKey, CreateUsagePlanKeyError, Credentials | HttpClient.HttpClient>;
export type CreateVpcLinkError = BadRequestException | ConflictException | LimitExceededException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a VPC link, under the caller's account in a selected region, in an asynchronous operation that typically takes 2-4 minutes to complete and become operational. The caller must have permissions to create and update VPC Endpoint services.
 */
export declare const createVpcLink: API.OperationMethod<CreateVpcLinkRequest, VpcLink, CreateVpcLinkError, Credentials | HttpClient.HttpClient>;
export type DeleteApiKeyError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the ApiKey resource.
 */
export declare const deleteApiKey: API.OperationMethod<DeleteApiKeyRequest, DeleteApiKeyResponse, DeleteApiKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteAuthorizerError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes an existing Authorizer resource.
 */
export declare const deleteAuthorizer: API.OperationMethod<DeleteAuthorizerRequest, DeleteAuthorizerResponse, DeleteAuthorizerError, Credentials | HttpClient.HttpClient>;
export type DeleteBasePathMappingError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the BasePathMapping resource.
 */
export declare const deleteBasePathMapping: API.OperationMethod<DeleteBasePathMappingRequest, DeleteBasePathMappingResponse, DeleteBasePathMappingError, Credentials | HttpClient.HttpClient>;
export type DeleteClientCertificateError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the ClientCertificate resource.
 */
export declare const deleteClientCertificate: API.OperationMethod<DeleteClientCertificateRequest, DeleteClientCertificateResponse, DeleteClientCertificateError, Credentials | HttpClient.HttpClient>;
export type DeleteDeploymentError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a Deployment resource. Deleting a deployment will only succeed if there are no Stage resources associated with it.
 */
export declare const deleteDeployment: API.OperationMethod<DeleteDeploymentRequest, DeleteDeploymentResponse, DeleteDeploymentError, Credentials | HttpClient.HttpClient>;
export type DeleteDocumentationPartError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a documentation part
 */
export declare const deleteDocumentationPart: API.OperationMethod<DeleteDocumentationPartRequest, DeleteDocumentationPartResponse, DeleteDocumentationPartError, Credentials | HttpClient.HttpClient>;
export type DeleteDocumentationVersionError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a documentation version.
 */
export declare const deleteDocumentationVersion: API.OperationMethod<DeleteDocumentationVersionRequest, DeleteDocumentationVersionResponse, DeleteDocumentationVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainNameError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the DomainName resource.
 */
export declare const deleteDomainName: API.OperationMethod<DeleteDomainNameRequest, DeleteDomainNameResponse, DeleteDomainNameError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainNameAccessAssociationError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the DomainNameAccessAssociation resource.
 *
 * Only the AWS account that created the DomainNameAccessAssociation resource can delete it. To stop an access association source in another AWS account from accessing your private custom domain name, use the RejectDomainNameAccessAssociation operation.
 */
export declare const deleteDomainNameAccessAssociation: API.OperationMethod<DeleteDomainNameAccessAssociationRequest, DeleteDomainNameAccessAssociationResponse, DeleteDomainNameAccessAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteGatewayResponseError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Clears any customization of a GatewayResponse of a specified response type on the given RestApi and resets it with the default settings.
 */
export declare const deleteGatewayResponse: API.OperationMethod<DeleteGatewayResponseRequest, DeleteGatewayResponseResponse, DeleteGatewayResponseError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Represents a delete integration.
 */
export declare const deleteIntegration: API.OperationMethod<DeleteIntegrationRequest, DeleteIntegrationResponse, DeleteIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationResponseError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Represents a delete integration response.
 */
export declare const deleteIntegrationResponse: API.OperationMethod<DeleteIntegrationResponseRequest, DeleteIntegrationResponseResponse, DeleteIntegrationResponseError, Credentials | HttpClient.HttpClient>;
export type DeleteMethodError = ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes an existing Method resource.
 */
export declare const deleteMethod: API.OperationMethod<DeleteMethodRequest, DeleteMethodResponse, DeleteMethodError, Credentials | HttpClient.HttpClient>;
export type DeleteMethodResponseError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes an existing MethodResponse resource.
 */
export declare const deleteMethodResponse: API.OperationMethod<DeleteMethodResponseRequest, DeleteMethodResponseResponse, DeleteMethodResponseError, Credentials | HttpClient.HttpClient>;
export type DeleteModelError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a model.
 */
export declare const deleteModel: API.OperationMethod<DeleteModelRequest, DeleteModelResponse, DeleteModelError, Credentials | HttpClient.HttpClient>;
export type DeleteRequestValidatorError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a RequestValidator of a given RestApi.
 */
export declare const deleteRequestValidator: API.OperationMethod<DeleteRequestValidatorRequest, DeleteRequestValidatorResponse, DeleteRequestValidatorError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a Resource resource.
 */
export declare const deleteResource: API.OperationMethod<DeleteResourceRequest, DeleteResourceResponse, DeleteResourceError, Credentials | HttpClient.HttpClient>;
export type DeleteRestApiError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the specified API.
 */
export declare const deleteRestApi: API.OperationMethod<DeleteRestApiRequest, DeleteRestApiResponse, DeleteRestApiError, Credentials | HttpClient.HttpClient>;
export type DeleteStageError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a Stage resource.
 */
export declare const deleteStage: API.OperationMethod<DeleteStageRequest, DeleteStageResponse, DeleteStageError, Credentials | HttpClient.HttpClient>;
export type DeleteUsagePlanError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a usage plan of a given plan Id.
 */
export declare const deleteUsagePlan: API.OperationMethod<DeleteUsagePlanRequest, DeleteUsagePlanResponse, DeleteUsagePlanError, Credentials | HttpClient.HttpClient>;
export type DeleteUsagePlanKeyError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a usage plan key and remove the underlying API key from the associated usage plan.
 */
export declare const deleteUsagePlanKey: API.OperationMethod<DeleteUsagePlanKeyRequest, DeleteUsagePlanKeyResponse, DeleteUsagePlanKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcLinkError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes an existing VpcLink of a specified identifier.
 */
export declare const deleteVpcLink: API.OperationMethod<DeleteVpcLinkRequest, DeleteVpcLinkResponse, DeleteVpcLinkError, Credentials | HttpClient.HttpClient>;
export type FlushStageAuthorizersCacheError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Flushes all authorizer cache entries on a stage.
 */
export declare const flushStageAuthorizersCache: API.OperationMethod<FlushStageAuthorizersCacheRequest, FlushStageAuthorizersCacheResponse, FlushStageAuthorizersCacheError, Credentials | HttpClient.HttpClient>;
export type FlushStageCacheError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Flushes a stage's cache.
 */
export declare const flushStageCache: API.OperationMethod<FlushStageCacheRequest, FlushStageCacheResponse, FlushStageCacheError, Credentials | HttpClient.HttpClient>;
export type GenerateClientCertificateError = BadRequestException | ConflictException | LimitExceededException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Generates a ClientCertificate resource.
 */
export declare const generateClientCertificate: API.OperationMethod<GenerateClientCertificateRequest, ClientCertificate, GenerateClientCertificateError, Credentials | HttpClient.HttpClient>;
export type GetAccountError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets information about the current Account resource.
 */
export declare const getAccount: API.OperationMethod<GetAccountRequest, Account, GetAccountError, Credentials | HttpClient.HttpClient>;
export type GetApiKeyError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets information about the current ApiKey resource.
 */
export declare const getApiKey: API.OperationMethod<GetApiKeyRequest, ApiKey, GetApiKeyError, Credentials | HttpClient.HttpClient>;
export type GetApiKeysError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets information about the current ApiKeys resource.
 */
export declare const getApiKeys: API.PaginatedOperationMethod<GetApiKeysRequest, ApiKeys, GetApiKeysError, Credentials | HttpClient.HttpClient, ApiKey>;
export type GetAuthorizerError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Describe an existing Authorizer resource.
 */
export declare const getAuthorizer: API.OperationMethod<GetAuthorizerRequest, Authorizer, GetAuthorizerError, Credentials | HttpClient.HttpClient>;
export type GetAuthorizersError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Describe an existing Authorizers resource.
 */
export declare const getAuthorizers: API.OperationMethod<GetAuthorizersRequest, Authorizers, GetAuthorizersError, Credentials | HttpClient.HttpClient>;
export type GetBasePathMappingError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Describe a BasePathMapping resource.
 */
export declare const getBasePathMapping: API.OperationMethod<GetBasePathMappingRequest, BasePathMapping, GetBasePathMappingError, Credentials | HttpClient.HttpClient>;
export type GetBasePathMappingsError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Represents a collection of BasePathMapping resources.
 */
export declare const getBasePathMappings: API.PaginatedOperationMethod<GetBasePathMappingsRequest, BasePathMappings, GetBasePathMappingsError, Credentials | HttpClient.HttpClient, BasePathMapping>;
export type GetClientCertificateError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets information about the current ClientCertificate resource.
 */
export declare const getClientCertificate: API.OperationMethod<GetClientCertificateRequest, ClientCertificate, GetClientCertificateError, Credentials | HttpClient.HttpClient>;
export type GetClientCertificatesError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets a collection of ClientCertificate resources.
 */
export declare const getClientCertificates: API.PaginatedOperationMethod<GetClientCertificatesRequest, ClientCertificates, GetClientCertificatesError, Credentials | HttpClient.HttpClient, ClientCertificate>;
export type GetDeploymentError = BadRequestException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets information about a Deployment resource.
 */
export declare const getDeployment: API.OperationMethod<GetDeploymentRequest, Deployment, GetDeploymentError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentsError = BadRequestException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets information about a Deployments collection.
 */
export declare const getDeployments: API.PaginatedOperationMethod<GetDeploymentsRequest, Deployments, GetDeploymentsError, Credentials | HttpClient.HttpClient, Deployment>;
export type GetDocumentationPartError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets a documentation part.
 */
export declare const getDocumentationPart: API.OperationMethod<GetDocumentationPartRequest, DocumentationPart, GetDocumentationPartError, Credentials | HttpClient.HttpClient>;
export type GetDocumentationPartsError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets documentation parts.
 */
export declare const getDocumentationParts: API.OperationMethod<GetDocumentationPartsRequest, DocumentationParts, GetDocumentationPartsError, Credentials | HttpClient.HttpClient>;
export type GetDocumentationVersionError = NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets a documentation version.
 */
export declare const getDocumentationVersion: API.OperationMethod<GetDocumentationVersionRequest, DocumentationVersion, GetDocumentationVersionError, Credentials | HttpClient.HttpClient>;
export type GetDocumentationVersionsError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets documentation versions.
 */
export declare const getDocumentationVersions: API.OperationMethod<GetDocumentationVersionsRequest, DocumentationVersions, GetDocumentationVersionsError, Credentials | HttpClient.HttpClient>;
export type GetDomainNameError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Represents a domain name that is contained in a simpler, more intuitive URL that can be called.
 */
export declare const getDomainName: API.OperationMethod<GetDomainNameRequest, DomainName, GetDomainNameError, Credentials | HttpClient.HttpClient>;
export type GetDomainNameAccessAssociationsError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Represents a collection on DomainNameAccessAssociations resources.
 */
export declare const getDomainNameAccessAssociations: API.OperationMethod<GetDomainNameAccessAssociationsRequest, DomainNameAccessAssociations, GetDomainNameAccessAssociationsError, Credentials | HttpClient.HttpClient>;
export type GetDomainNamesError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Represents a collection of DomainName resources.
 */
export declare const getDomainNames: API.PaginatedOperationMethod<GetDomainNamesRequest, DomainNames, GetDomainNamesError, Credentials | HttpClient.HttpClient, DomainName>;
export type GetExportError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Exports a deployed version of a RestApi in a specified format.
 */
export declare const getExport: API.OperationMethod<GetExportRequest, ExportResponse, GetExportError, Credentials | HttpClient.HttpClient>;
export type GetGatewayResponseError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets a GatewayResponse of a specified response type on the given RestApi.
 */
export declare const getGatewayResponse: API.OperationMethod<GetGatewayResponseRequest, GatewayResponse, GetGatewayResponseError, Credentials | HttpClient.HttpClient>;
export type GetGatewayResponsesError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets the GatewayResponses collection on the given RestApi. If an API developer has not added any definitions for gateway responses, the result will be the API Gateway-generated default GatewayResponses collection for the supported response types.
 */
export declare const getGatewayResponses: API.OperationMethod<GetGatewayResponsesRequest, GatewayResponses, GetGatewayResponsesError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Get the integration settings.
 */
export declare const getIntegration: API.OperationMethod<GetIntegrationRequest, Integration, GetIntegrationError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationResponseError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Represents a get integration response.
 */
export declare const getIntegrationResponse: API.OperationMethod<GetIntegrationResponseRequest, IntegrationResponse, GetIntegrationResponseError, Credentials | HttpClient.HttpClient>;
export type GetMethodError = NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Describe an existing Method resource.
 */
export declare const getMethod: API.OperationMethod<GetMethodRequest, Method, GetMethodError, Credentials | HttpClient.HttpClient>;
export type GetMethodResponseError = NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Describes a MethodResponse resource.
 */
export declare const getMethodResponse: API.OperationMethod<GetMethodResponseRequest, MethodResponse, GetMethodResponseError, Credentials | HttpClient.HttpClient>;
export type GetModelError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Describes an existing model defined for a RestApi resource.
 */
export declare const getModel: API.OperationMethod<GetModelRequest, Model, GetModelError, Credentials | HttpClient.HttpClient>;
export type GetModelsError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Describes existing Models defined for a RestApi resource.
 */
export declare const getModels: API.PaginatedOperationMethod<GetModelsRequest, Models, GetModelsError, Credentials | HttpClient.HttpClient, Model>;
export type GetModelTemplateError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Generates a sample mapping template that can be used to transform a payload into the structure of a model.
 */
export declare const getModelTemplate: API.OperationMethod<GetModelTemplateRequest, Template, GetModelTemplateError, Credentials | HttpClient.HttpClient>;
export type GetRequestValidatorError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets a RequestValidator of a given RestApi.
 */
export declare const getRequestValidator: API.OperationMethod<GetRequestValidatorRequest, RequestValidator, GetRequestValidatorError, Credentials | HttpClient.HttpClient>;
export type GetRequestValidatorsError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets the RequestValidators collection of a given RestApi.
 */
export declare const getRequestValidators: API.OperationMethod<GetRequestValidatorsRequest, RequestValidators, GetRequestValidatorsError, Credentials | HttpClient.HttpClient>;
export type GetResourceError = NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Lists information about a resource.
 */
export declare const getResource: API.OperationMethod<GetResourceRequest, Resource, GetResourceError, Credentials | HttpClient.HttpClient>;
export type GetResourcesError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Lists information about a collection of Resource resources.
 */
export declare const getResources: API.PaginatedOperationMethod<GetResourcesRequest, Resources, GetResourcesError, Credentials | HttpClient.HttpClient, Resource>;
export type GetRestApiError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Lists the RestApi resource in the collection.
 */
export declare const getRestApi: API.OperationMethod<GetRestApiRequest, RestApi, GetRestApiError, Credentials | HttpClient.HttpClient>;
export type GetRestApisError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Lists the RestApis resources for your collection.
 */
export declare const getRestApis: API.PaginatedOperationMethod<GetRestApisRequest, RestApis, GetRestApisError, Credentials | HttpClient.HttpClient, RestApi>;
export type GetSdkError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Generates a client SDK for a RestApi and Stage.
 */
export declare const getSdk: API.OperationMethod<GetSdkRequest, SdkResponse, GetSdkError, Credentials | HttpClient.HttpClient>;
export type GetSdkTypeError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets an SDK type.
 */
export declare const getSdkType: API.OperationMethod<GetSdkTypeRequest, SdkType, GetSdkTypeError, Credentials | HttpClient.HttpClient>;
export type GetSdkTypesError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets SDK types
 */
export declare const getSdkTypes: API.OperationMethod<GetSdkTypesRequest, SdkTypes, GetSdkTypesError, Credentials | HttpClient.HttpClient>;
export type GetStageError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets information about a Stage resource.
 */
export declare const getStage: API.OperationMethod<GetStageRequest, Stage, GetStageError, Credentials | HttpClient.HttpClient>;
export type GetStagesError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets information about one or more Stage resources.
 */
export declare const getStages: API.OperationMethod<GetStagesRequest, Stages, GetStagesError, Credentials | HttpClient.HttpClient>;
export type GetTagsError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets the Tags collection for a given resource.
 */
export declare const getTags: API.OperationMethod<GetTagsRequest, Tags, GetTagsError, Credentials | HttpClient.HttpClient>;
export type GetUsageError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets the usage data of a usage plan in a specified time interval.
 */
export declare const getUsage: API.PaginatedOperationMethod<GetUsageRequest, Usage, GetUsageError, Credentials | HttpClient.HttpClient, unknown>;
export type GetUsagePlanError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets a usage plan of a given plan identifier.
 */
export declare const getUsagePlan: API.OperationMethod<GetUsagePlanRequest, UsagePlan, GetUsagePlanError, Credentials | HttpClient.HttpClient>;
export type GetUsagePlanKeyError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets a usage plan key of a given key identifier.
 */
export declare const getUsagePlanKey: API.OperationMethod<GetUsagePlanKeyRequest, UsagePlanKey, GetUsagePlanKeyError, Credentials | HttpClient.HttpClient>;
export type GetUsagePlanKeysError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets all the usage plan keys representing the API keys added to a specified usage plan.
 */
export declare const getUsagePlanKeys: API.PaginatedOperationMethod<GetUsagePlanKeysRequest, UsagePlanKeys, GetUsagePlanKeysError, Credentials | HttpClient.HttpClient, UsagePlanKey>;
export type GetUsagePlansError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets all the usage plans of the caller's account.
 */
export declare const getUsagePlans: API.PaginatedOperationMethod<GetUsagePlansRequest, UsagePlans, GetUsagePlansError, Credentials | HttpClient.HttpClient, UsagePlan>;
export type GetVpcLinkError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets a specified VPC link under the caller's account in a region.
 */
export declare const getVpcLink: API.OperationMethod<GetVpcLinkRequest, VpcLink, GetVpcLinkError, Credentials | HttpClient.HttpClient>;
export type GetVpcLinksError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets the VpcLinks collection under the caller's account in a selected region.
 */
export declare const getVpcLinks: API.PaginatedOperationMethod<GetVpcLinksRequest, VpcLinks, GetVpcLinksError, Credentials | HttpClient.HttpClient, VpcLink>;
export type ImportApiKeysError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Import API keys from an external source, such as a CSV-formatted file.
 */
export declare const importApiKeys: API.OperationMethod<ImportApiKeysRequest, ApiKeyIds, ImportApiKeysError, Credentials | HttpClient.HttpClient>;
export type ImportDocumentationPartsError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Imports documentation parts
 */
export declare const importDocumentationParts: API.OperationMethod<ImportDocumentationPartsRequest, DocumentationPartIds, ImportDocumentationPartsError, Credentials | HttpClient.HttpClient>;
export type ImportRestApiError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * A feature of the API Gateway control service for creating a new API from an external API definition file.
 */
export declare const importRestApi: API.OperationMethod<ImportRestApiRequest, RestApi, ImportRestApiError, Credentials | HttpClient.HttpClient>;
export type PutGatewayResponseError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a customization of a GatewayResponse of a specified response type and status code on the given RestApi.
 */
export declare const putGatewayResponse: API.OperationMethod<PutGatewayResponseRequest, GatewayResponse, PutGatewayResponseError, Credentials | HttpClient.HttpClient>;
export type PutIntegrationError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Sets up a method's integration.
 */
export declare const putIntegration: API.OperationMethod<PutIntegrationRequest, Integration, PutIntegrationError, Credentials | HttpClient.HttpClient>;
export type PutIntegrationResponseError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Represents a put integration.
 */
export declare const putIntegrationResponse: API.OperationMethod<PutIntegrationResponseRequest, IntegrationResponse, PutIntegrationResponseError, Credentials | HttpClient.HttpClient>;
export type PutMethodError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Add a method to an existing Resource resource.
 */
export declare const putMethod: API.OperationMethod<PutMethodRequest, Method, PutMethodError, Credentials | HttpClient.HttpClient>;
export type PutMethodResponseError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Adds a MethodResponse to an existing Method resource.
 */
export declare const putMethodResponse: API.OperationMethod<PutMethodResponseRequest, MethodResponse, PutMethodResponseError, Credentials | HttpClient.HttpClient>;
export type PutRestApiError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * A feature of the API Gateway control service for updating an existing API with an input of external API definitions.
 * The update can take the form of merging the supplied definition into the existing API or overwriting the existing API.
 */
export declare const putRestApi: API.OperationMethod<PutRestApiRequest, RestApi, PutRestApiError, Credentials | HttpClient.HttpClient>;
export type RejectDomainNameAccessAssociationError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Rejects a domain name access association with a private custom domain name.
 *
 * To reject a domain name access association with an access association source in another AWS account, use this operation. To remove a domain name access association with an access association source in your own account, use the DeleteDomainNameAccessAssociation operation.
 */
export declare const rejectDomainNameAccessAssociation: API.OperationMethod<RejectDomainNameAccessAssociationRequest, RejectDomainNameAccessAssociationResponse, RejectDomainNameAccessAssociationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Adds or updates a tag on a given resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestInvokeAuthorizerError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Simulate the execution of an Authorizer in your RestApi with headers, parameters, and an incoming request body.
 */
export declare const testInvokeAuthorizer: API.OperationMethod<TestInvokeAuthorizerRequest, TestInvokeAuthorizerResponse, TestInvokeAuthorizerError, Credentials | HttpClient.HttpClient>;
export type TestInvokeMethodError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Simulate the invocation of a Method in your RestApi with headers, parameters, and an incoming request body.
 */
export declare const testInvokeMethod: API.OperationMethod<TestInvokeMethodRequest, TestInvokeMethodResponse, TestInvokeMethodError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Removes a tag from a given resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Changes information about the current Account resource.
 */
export declare const updateAccount: API.OperationMethod<UpdateAccountRequest, Account, UpdateAccountError, Credentials | HttpClient.HttpClient>;
export type UpdateApiKeyError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Changes information about an ApiKey resource.
 */
export declare const updateApiKey: API.OperationMethod<UpdateApiKeyRequest, ApiKey, UpdateApiKeyError, Credentials | HttpClient.HttpClient>;
export type UpdateAuthorizerError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates an existing Authorizer resource.
 */
export declare const updateAuthorizer: API.OperationMethod<UpdateAuthorizerRequest, Authorizer, UpdateAuthorizerError, Credentials | HttpClient.HttpClient>;
export type UpdateBasePathMappingError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Changes information about the BasePathMapping resource.
 */
export declare const updateBasePathMapping: API.OperationMethod<UpdateBasePathMappingRequest, BasePathMapping, UpdateBasePathMappingError, Credentials | HttpClient.HttpClient>;
export type UpdateClientCertificateError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Changes information about an ClientCertificate resource.
 */
export declare const updateClientCertificate: API.OperationMethod<UpdateClientCertificateRequest, ClientCertificate, UpdateClientCertificateError, Credentials | HttpClient.HttpClient>;
export type UpdateDeploymentError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Changes information about a Deployment resource.
 */
export declare const updateDeployment: API.OperationMethod<UpdateDeploymentRequest, Deployment, UpdateDeploymentError, Credentials | HttpClient.HttpClient>;
export type UpdateDocumentationPartError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates a documentation part.
 */
export declare const updateDocumentationPart: API.OperationMethod<UpdateDocumentationPartRequest, DocumentationPart, UpdateDocumentationPartError, Credentials | HttpClient.HttpClient>;
export type UpdateDocumentationVersionError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates a documentation version.
 */
export declare const updateDocumentationVersion: API.OperationMethod<UpdateDocumentationVersionRequest, DocumentationVersion, UpdateDocumentationVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainNameError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Changes information about the DomainName resource.
 */
export declare const updateDomainName: API.OperationMethod<UpdateDomainNameRequest, DomainName, UpdateDomainNameError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewayResponseError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates a GatewayResponse of a specified response type on the given RestApi.
 */
export declare const updateGatewayResponse: API.OperationMethod<UpdateGatewayResponseRequest, GatewayResponse, UpdateGatewayResponseError, Credentials | HttpClient.HttpClient>;
export type UpdateIntegrationError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Represents an update integration.
 */
export declare const updateIntegration: API.OperationMethod<UpdateIntegrationRequest, Integration, UpdateIntegrationError, Credentials | HttpClient.HttpClient>;
export type UpdateIntegrationResponseError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Represents an update integration response.
 */
export declare const updateIntegrationResponse: API.OperationMethod<UpdateIntegrationResponseRequest, IntegrationResponse, UpdateIntegrationResponseError, Credentials | HttpClient.HttpClient>;
export type UpdateMethodError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates an existing Method resource.
 */
export declare const updateMethod: API.OperationMethod<UpdateMethodRequest, Method, UpdateMethodError, Credentials | HttpClient.HttpClient>;
export type UpdateMethodResponseError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates an existing MethodResponse resource.
 */
export declare const updateMethodResponse: API.OperationMethod<UpdateMethodResponseRequest, MethodResponse, UpdateMethodResponseError, Credentials | HttpClient.HttpClient>;
export type UpdateModelError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Changes information about a model. The maximum size of the model is 400 KB.
 */
export declare const updateModel: API.OperationMethod<UpdateModelRequest, Model, UpdateModelError, Credentials | HttpClient.HttpClient>;
export type UpdateRequestValidatorError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates a RequestValidator of a given RestApi.
 */
export declare const updateRequestValidator: API.OperationMethod<UpdateRequestValidatorRequest, RequestValidator, UpdateRequestValidatorError, Credentials | HttpClient.HttpClient>;
export type UpdateResourceError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Changes information about a Resource resource.
 */
export declare const updateResource: API.OperationMethod<UpdateResourceRequest, Resource, UpdateResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateRestApiError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Changes information about the specified API.
 */
export declare const updateRestApi: API.OperationMethod<UpdateRestApiRequest, RestApi, UpdateRestApiError, Credentials | HttpClient.HttpClient>;
export type UpdateStageError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Changes information about a Stage resource.
 */
export declare const updateStage: API.OperationMethod<UpdateStageRequest, Stage, UpdateStageError, Credentials | HttpClient.HttpClient>;
export type UpdateUsageError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Grants a temporary extension to the remaining quota of a usage plan associated with a specified API key.
 */
export declare const updateUsage: API.OperationMethod<UpdateUsageRequest, Usage, UpdateUsageError, Credentials | HttpClient.HttpClient>;
export type UpdateUsagePlanError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates a usage plan of a given plan Id.
 */
export declare const updateUsagePlan: API.OperationMethod<UpdateUsagePlanRequest, UsagePlan, UpdateUsagePlanError, Credentials | HttpClient.HttpClient>;
export type UpdateVpcLinkError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates an existing VpcLink of a specified identifier.
 */
export declare const updateVpcLink: API.OperationMethod<UpdateVpcLinkRequest, VpcLink, UpdateVpcLinkError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=api-gateway.d.ts.map