import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ResourceName = string;
export type Arn = string;
export type SetOfARNs = string[];
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type MaxCityNetworksToMonitor = number;
export type LogDeliveryStatus = string;
export interface S3Config {
    BucketName?: string;
    BucketPrefix?: string;
    LogDeliveryStatus?: string;
}
export interface InternetMeasurementsLogDelivery {
    S3Config?: S3Config;
}
export type TrafficPercentageToMonitor = number;
export type Percentage = number;
export type LocalHealthEventsConfigStatus = string;
export interface LocalHealthEventsConfig {
    Status?: string;
    HealthScoreThreshold?: number;
    MinTrafficImpact?: number;
}
export interface HealthEventsConfig {
    AvailabilityScoreThreshold?: number;
    PerformanceScoreThreshold?: number;
    AvailabilityLocalHealthEventsConfig?: LocalHealthEventsConfig;
    PerformanceLocalHealthEventsConfig?: LocalHealthEventsConfig;
}
export interface CreateMonitorInput {
    MonitorName: string;
    Resources?: string[];
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    MaxCityNetworksToMonitor?: number;
    InternetMeasurementsLogDelivery?: InternetMeasurementsLogDelivery;
    TrafficPercentageToMonitor?: number;
    HealthEventsConfig?: HealthEventsConfig;
}
export type MonitorArn = string;
export type MonitorConfigState = string;
export interface CreateMonitorOutput {
    Arn: string;
    Status: string;
}
export interface DeleteMonitorInput {
    MonitorName: string;
}
export interface DeleteMonitorOutput {
}
export type HealthEventName = string;
export type AccountId = string;
export interface GetHealthEventInput {
    MonitorName: string;
    EventId: string;
    LinkedAccountId?: string;
}
export type HealthEventStatus = string;
export interface Network {
    ASName: string;
    ASNumber: number;
}
export type NetworkList = Network[];
export type TriangulationEventType = string;
export interface NetworkImpairment {
    Networks: Network[];
    AsPath: Network[];
    NetworkEventType: string;
}
export interface AvailabilityMeasurement {
    ExperienceScore?: number;
    PercentOfTotalTrafficImpacted?: number;
    PercentOfClientLocationImpacted?: number;
}
export interface RoundTripTime {
    P50?: number;
    P90?: number;
    P95?: number;
}
export interface PerformanceMeasurement {
    ExperienceScore?: number;
    PercentOfTotalTrafficImpacted?: number;
    PercentOfClientLocationImpacted?: number;
    RoundTripTime?: RoundTripTime;
}
export interface InternetHealth {
    Availability?: AvailabilityMeasurement;
    Performance?: PerformanceMeasurement;
}
export type Ipv4PrefixList = string[];
export interface ImpactedLocation {
    ASName: string;
    ASNumber: number;
    Country: string;
    Subdivision?: string;
    Metro?: string;
    City?: string;
    Latitude?: number;
    Longitude?: number;
    CountryCode?: string;
    SubdivisionCode?: string;
    ServiceLocation?: string;
    Status: string;
    CausedBy?: NetworkImpairment;
    InternetHealth?: InternetHealth;
    Ipv4Prefixes?: string[];
}
export type ImpactedLocationsList = ImpactedLocation[];
export type HealthEventImpactType = string;
export interface GetHealthEventOutput {
    EventArn: string;
    EventId: string;
    StartedAt: Date;
    EndedAt?: Date;
    CreatedAt?: Date;
    LastUpdatedAt: Date;
    ImpactedLocations: ImpactedLocation[];
    Status: string;
    PercentOfTotalTrafficImpacted?: number;
    ImpactType: string;
    HealthScoreThreshold?: number;
}
export type InternetEventId = string;
export interface GetInternetEventInput {
    EventId: string;
}
export interface ClientLocation {
    ASName: string;
    ASNumber: number;
    Country: string;
    Subdivision?: string;
    Metro?: string;
    City: string;
    Latitude: number;
    Longitude: number;
}
export type InternetEventType = string;
export type InternetEventStatus = string;
export interface GetInternetEventOutput {
    EventId: string;
    EventArn: string;
    StartedAt: Date;
    EndedAt?: Date;
    ClientLocation: ClientLocation;
    EventType: string;
    EventStatus: string;
}
export interface GetMonitorInput {
    MonitorName: string;
    LinkedAccountId?: string;
}
export type MonitorProcessingStatusCode = string;
export interface GetMonitorOutput {
    MonitorName: string;
    MonitorArn: string;
    Resources: string[];
    Status: string;
    CreatedAt: Date;
    ModifiedAt: Date;
    ProcessingStatus?: string;
    ProcessingStatusInfo?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    MaxCityNetworksToMonitor?: number;
    InternetMeasurementsLogDelivery?: InternetMeasurementsLogDelivery;
    TrafficPercentageToMonitor?: number;
    HealthEventsConfig?: HealthEventsConfig;
}
export type QueryMaxResults = number;
export interface GetQueryResultsInput {
    MonitorName: string;
    QueryId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface QueryField {
    Name?: string;
    Type?: string;
}
export type QueryFields = QueryField[];
export type QueryRow = string[];
export type QueryData = string[][];
export interface GetQueryResultsOutput {
    Fields: QueryField[];
    Data?: string[][];
    NextToken?: string;
}
export interface GetQueryStatusInput {
    MonitorName: string;
    QueryId: string;
}
export type QueryStatus = string;
export interface GetQueryStatusOutput {
    Status: string;
}
export type MaxResults = number;
export interface ListHealthEventsInput {
    MonitorName: string;
    StartTime?: Date;
    EndTime?: Date;
    NextToken?: string;
    MaxResults?: number;
    EventStatus?: string;
    LinkedAccountId?: string;
}
export interface HealthEvent {
    EventArn: string;
    EventId: string;
    StartedAt: Date;
    EndedAt?: Date;
    CreatedAt?: Date;
    LastUpdatedAt: Date;
    ImpactedLocations: ImpactedLocation[];
    Status: string;
    PercentOfTotalTrafficImpacted?: number;
    ImpactType: string;
    HealthScoreThreshold?: number;
}
export type HealthEventList = HealthEvent[];
export interface ListHealthEventsOutput {
    HealthEvents: HealthEvent[];
    NextToken?: string;
}
export type InternetEventMaxResults = number;
export interface ListInternetEventsInput {
    NextToken?: string;
    MaxResults?: number;
    StartTime?: Date;
    EndTime?: Date;
    EventStatus?: string;
    EventType?: string;
}
export interface InternetEventSummary {
    EventId: string;
    EventArn: string;
    StartedAt: Date;
    EndedAt?: Date;
    ClientLocation: ClientLocation;
    EventType: string;
    EventStatus: string;
}
export type InternetEventsList = InternetEventSummary[];
export interface ListInternetEventsOutput {
    InternetEvents: InternetEventSummary[];
    NextToken?: string;
}
export interface ListMonitorsInput {
    NextToken?: string;
    MaxResults?: number;
    MonitorStatus?: string;
    IncludeLinkedAccounts?: boolean;
}
export interface Monitor {
    MonitorName: string;
    MonitorArn: string;
    Status: string;
    ProcessingStatus?: string;
}
export type MonitorList = Monitor[];
export interface ListMonitorsOutput {
    Monitors: Monitor[];
    NextToken?: string;
}
export interface ListTagsForResourceInput {
    ResourceArn: string;
}
export interface ListTagsForResourceOutput {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type QueryType = string;
export type Operator = string;
export type FilterList = string[];
export interface FilterParameter {
    Field?: string;
    Operator?: string;
    Values?: string[];
}
export type FilterParameters = FilterParameter[];
export interface StartQueryInput {
    MonitorName: string;
    StartTime: Date;
    EndTime: Date;
    QueryType: string;
    FilterParameters?: FilterParameter[];
    LinkedAccountId?: string;
}
export interface StartQueryOutput {
    QueryId: string;
}
export interface StopQueryInput {
    MonitorName: string;
    QueryId: string;
}
export interface StopQueryOutput {
}
export interface TagResourceInput {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type TagKeys = string[];
export interface UntagResourceInput {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateMonitorInput {
    MonitorName: string;
    ResourcesToAdd?: string[];
    ResourcesToRemove?: string[];
    Status?: string;
    ClientToken?: string;
    MaxCityNetworksToMonitor?: number;
    InternetMeasurementsLogDelivery?: InternetMeasurementsLogDelivery;
    TrafficPercentageToMonitor?: number;
    HealthEventsConfig?: HealthEventsConfig;
}
export interface UpdateMonitorOutput {
    MonitorArn: string;
    Status: string;
}
export type CreateMonitorError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a monitor in Amazon CloudWatch Internet Monitor. A monitor is built based on information from the application resources that you add: VPCs,
 * Network Load Balancers (NLBs), Amazon CloudFront distributions, and Amazon WorkSpaces directories. Internet Monitor then publishes internet measurements from Amazon Web Services
 * that are specific to the *city-networks*. That is, the locations and ASNs (typically internet service providers or ISPs),
 * where clients access your application. For more information, see Using Amazon CloudWatch Internet Monitor in the Amazon CloudWatch User
 * Guide.
 *
 * When you create a monitor, you choose the percentage of traffic that you want to monitor. You can also set a maximum limit for the
 * number of city-networks where client traffic is monitored, that caps the total traffic that Internet Monitor monitors. A city-network
 * maximum is the limit of city-networks, but you only pay for the number of city-networks that are actually monitored. You can update your monitor
 * at any time to change the percentage of traffic to monitor or the city-networks maximum. For more information, see Choosing a city-network maximum value in the *Amazon CloudWatch User Guide*.
 */
export declare const createMonitor: API.OperationMethod<CreateMonitorInput, CreateMonitorOutput, CreateMonitorError, Credentials | HttpClient.HttpClient>;
export type DeleteMonitorError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a monitor in Amazon CloudWatch Internet Monitor.
 */
export declare const deleteMonitor: API.OperationMethod<DeleteMonitorInput, DeleteMonitorOutput, DeleteMonitorError, Credentials | HttpClient.HttpClient>;
export type GetHealthEventError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information that Amazon CloudWatch Internet Monitor has created and stored about a health event for a specified monitor. This information includes the impacted locations,
 * and all the information related to the event, by location.
 *
 * The information returned includes the impact on performance, availability, and round-trip time, information about the network providers (ASNs),
 * the event type, and so on.
 *
 * Information rolled up at the global traffic level is also returned, including the impact type and total traffic impact.
 */
export declare const getHealthEvent: API.OperationMethod<GetHealthEventInput, GetHealthEventOutput, GetHealthEventError, Credentials | HttpClient.HttpClient>;
export type GetInternetEventError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information that Amazon CloudWatch Internet Monitor has generated about an internet event. Internet Monitor displays information about
 * recent global health events, called internet events, on a global outages map that is available to all Amazon Web Services
 * customers.
 *
 * The information returned here includes the impacted location,
 * when the event started and (if the event is over) ended, the type of event (`PERFORMANCE` or `AVAILABILITY`),
 * and the status (`ACTIVE` or `RESOLVED`).
 */
export declare const getInternetEvent: API.OperationMethod<GetInternetEventInput, GetInternetEventOutput, GetInternetEventError, Credentials | HttpClient.HttpClient>;
export type GetMonitorError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | ResourceNotFoundException | CommonErrors;
/**
 * Gets information about a monitor in Amazon CloudWatch Internet Monitor based on a monitor name. The information returned includes the Amazon Resource Name (ARN), create time,
 * modified time, resources included in the monitor, and status information.
 */
export declare const getMonitor: API.OperationMethod<GetMonitorInput, GetMonitorOutput, GetMonitorError, Credentials | HttpClient.HttpClient>;
export type GetQueryResultsError = AccessDeniedException | InternalServerException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Return the data for a query with the Amazon CloudWatch Internet Monitor query interface. Specify the query that you want to return results for by providing
 * a `QueryId` and a monitor name.
 *
 * For more information about using the query interface, including examples, see
 * Using the Amazon CloudWatch Internet Monitor query interface
 * in the Amazon CloudWatch Internet Monitor User Guide.
 */
export declare const getQueryResults: API.PaginatedOperationMethod<GetQueryResultsInput, GetQueryResultsOutput, GetQueryResultsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetQueryStatusError = AccessDeniedException | InternalServerException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the current status of a query for the Amazon CloudWatch Internet Monitor query interface, for a specified query ID and monitor.
 * When you run a query, check the status to make sure that the query has `SUCCEEDED` before you review the results.
 *
 * - `QUEUED`: The query is scheduled to run.
 *
 * - `RUNNING`: The query is in progress but not complete.
 *
 * - `SUCCEEDED`: The query completed sucessfully.
 *
 * - `FAILED`: The query failed due to an error.
 *
 * - `CANCELED`: The query was canceled.
 */
export declare const getQueryStatus: API.OperationMethod<GetQueryStatusInput, GetQueryStatusOutput, GetQueryStatusError, Credentials | HttpClient.HttpClient>;
export type ListHealthEventsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all health events for a monitor in Amazon CloudWatch Internet Monitor. Returns information for health events including the event start and end times, and
 * the status.
 *
 * Health events that have start times during the time frame that is requested are not included in the list of health events.
 */
export declare const listHealthEvents: API.PaginatedOperationMethod<ListHealthEventsInput, ListHealthEventsOutput, ListHealthEventsError, Credentials | HttpClient.HttpClient, HealthEvent>;
export type ListInternetEventsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists internet events that cause performance or availability issues for client locations. Amazon CloudWatch Internet Monitor displays information about
 * recent global health events, called internet events, on a global outages map that is available to all Amazon Web Services
 * customers.
 *
 * You can constrain the list of internet events returned by providing a start time and end time to define a total
 * time frame for events you want to list. Both start time and end time specify the time when an event started. End time
 * is optional. If you don't include it, the default end time is the current time.
 *
 * You can also limit the events returned to a specific status
 * (`ACTIVE` or `RESOLVED`) or type (`PERFORMANCE` or `AVAILABILITY`).
 */
export declare const listInternetEvents: API.PaginatedOperationMethod<ListInternetEventsInput, ListInternetEventsOutput, ListInternetEventsError, Credentials | HttpClient.HttpClient, InternetEventSummary>;
export type ListMonitorsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all of your monitors for Amazon CloudWatch Internet Monitor and their statuses, along with the Amazon Resource Name (ARN) and name of each monitor.
 */
export declare const listMonitors: API.PaginatedOperationMethod<ListMonitorsInput, ListMonitorsOutput, ListMonitorsError, Credentials | HttpClient.HttpClient, Monitor>;
export type ListTagsForResourceError = AccessDeniedException | BadRequestException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists the tags for a resource. Tags are supported only for monitors in Amazon CloudWatch Internet Monitor.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartQueryError = AccessDeniedException | InternalServerException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Start a query to return data for a specific query type for the Amazon CloudWatch Internet Monitor query interface. Specify a time period
 * for the data that you want returned by using `StartTime` and `EndTime`. You filter the query
 * results to return by providing parameters that you specify with `FilterParameters`.
 *
 * For more information about using the query interface, including examples, see
 * Using the Amazon CloudWatch Internet Monitor query interface
 * in the Amazon CloudWatch Internet Monitor User Guide.
 */
export declare const startQuery: API.OperationMethod<StartQueryInput, StartQueryOutput, StartQueryError, Credentials | HttpClient.HttpClient>;
export type StopQueryError = AccessDeniedException | InternalServerException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stop a query that is progress for a specific monitor.
 */
export declare const stopQuery: API.OperationMethod<StopQueryInput, StopQueryOutput, StopQueryError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | BadRequestException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Adds a tag to a resource. Tags are supported only for monitors in Amazon CloudWatch Internet Monitor. You can add a maximum of 50 tags in Internet Monitor.
 *
 * A minimum of one tag is required for this call. It returns an error if you use the `TagResource` request with 0 tags.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | BadRequestException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes a tag from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateMonitorError = AccessDeniedException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a monitor. You can update a monitor to change the percentage of traffic to monitor or the maximum number of city-networks
 * (locations and ASNs), to add or remove resources, or to change the status of the monitor. Note that you can't change the name of a monitor.
 *
 * The city-network maximum that you choose is the limit, but you only pay for the number of city-networks that are actually monitored.
 * For more information, see Choosing a city-network maximum value in the *Amazon CloudWatch User Guide*.
 */
export declare const updateMonitor: API.OperationMethod<UpdateMonitorInput, UpdateMonitorOutput, UpdateMonitorError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=internetmonitor.d.ts.map