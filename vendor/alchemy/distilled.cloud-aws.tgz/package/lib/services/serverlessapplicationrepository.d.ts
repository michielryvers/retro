import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type __listOf__string = string[];
export interface CreateApplicationRequest {
    Author?: string;
    Description?: string;
    HomePageUrl?: string;
    Labels?: string[];
    LicenseBody?: string;
    LicenseUrl?: string;
    Name?: string;
    ReadmeBody?: string;
    ReadmeUrl?: string;
    SemanticVersion?: string;
    SourceCodeArchiveUrl?: string;
    SourceCodeUrl?: string;
    SpdxLicenseId?: string;
    TemplateBody?: string;
    TemplateUrl?: string;
}
export interface ParameterDefinition {
    AllowedPattern?: string;
    AllowedValues?: string[];
    ConstraintDescription?: string;
    DefaultValue?: string;
    Description?: string;
    MaxLength?: number;
    MaxValue?: number;
    MinLength?: number;
    MinValue?: number;
    Name?: string;
    NoEcho?: boolean;
    ReferencedByResources?: string[];
    Type?: string;
}
export type __listOfParameterDefinition = ParameterDefinition[];
export type Capability = "CAPABILITY_IAM" | "CAPABILITY_NAMED_IAM" | "CAPABILITY_AUTO_EXPAND" | "CAPABILITY_RESOURCE_POLICY" | (string & {});
export type __listOfCapability = Capability[];
export interface Version {
    ApplicationId?: string;
    CreationTime?: string;
    ParameterDefinitions?: ParameterDefinition[];
    RequiredCapabilities?: Capability[];
    ResourcesSupported?: boolean;
    SemanticVersion?: string;
    SourceCodeArchiveUrl?: string;
    SourceCodeUrl?: string;
    TemplateUrl?: string;
}
export interface CreateApplicationResponse {
    ApplicationId?: string;
    Author?: string;
    CreationTime?: string;
    Description?: string;
    HomePageUrl?: string;
    IsVerifiedAuthor?: boolean;
    Labels?: string[];
    LicenseUrl?: string;
    Name?: string;
    ReadmeUrl?: string;
    SpdxLicenseId?: string;
    VerifiedAuthorUrl?: string;
    Version?: Version & {
        ApplicationId: string;
        CreationTime: string;
        ParameterDefinitions: (ParameterDefinition & {
            Name: string;
            ReferencedByResources: __listOf__string;
        })[];
        RequiredCapabilities: __listOfCapability;
        ResourcesSupported: boolean;
        SemanticVersion: string;
        TemplateUrl: string;
    };
}
export interface CreateApplicationVersionRequest {
    ApplicationId: string;
    SemanticVersion: string;
    SourceCodeArchiveUrl?: string;
    SourceCodeUrl?: string;
    TemplateBody?: string;
    TemplateUrl?: string;
}
export interface CreateApplicationVersionResponse {
    ApplicationId?: string;
    CreationTime?: string;
    ParameterDefinitions?: (ParameterDefinition & {
        Name: string;
        ReferencedByResources: __listOf__string;
    })[];
    RequiredCapabilities?: Capability[];
    ResourcesSupported?: boolean;
    SemanticVersion?: string;
    SourceCodeArchiveUrl?: string;
    SourceCodeUrl?: string;
    TemplateUrl?: string;
}
export interface ParameterValue {
    Name?: string;
    Value?: string;
}
export type __listOfParameterValue = ParameterValue[];
export interface RollbackTrigger {
    Arn?: string;
    Type?: string;
}
export type __listOfRollbackTrigger = RollbackTrigger[];
export interface RollbackConfiguration {
    MonitoringTimeInMinutes?: number;
    RollbackTriggers?: RollbackTrigger[];
}
export interface Tag {
    Key?: string;
    Value?: string;
}
export type __listOfTag = Tag[];
export interface CreateCloudFormationChangeSetRequest {
    ApplicationId: string;
    Capabilities?: string[];
    ChangeSetName?: string;
    ClientToken?: string;
    Description?: string;
    NotificationArns?: string[];
    ParameterOverrides?: ParameterValue[];
    ResourceTypes?: string[];
    RollbackConfiguration?: RollbackConfiguration;
    SemanticVersion?: string;
    StackName?: string;
    Tags?: Tag[];
    TemplateId?: string;
}
export interface CreateCloudFormationChangeSetResponse {
    ApplicationId?: string;
    ChangeSetId?: string;
    SemanticVersion?: string;
    StackId?: string;
}
export interface CreateCloudFormationTemplateRequest {
    ApplicationId: string;
    SemanticVersion?: string;
}
export type Status = "PREPARING" | "ACTIVE" | "EXPIRED" | (string & {});
export interface CreateCloudFormationTemplateResponse {
    ApplicationId?: string;
    CreationTime?: string;
    ExpirationTime?: string;
    SemanticVersion?: string;
    Status?: Status;
    TemplateId?: string;
    TemplateUrl?: string;
}
export interface DeleteApplicationRequest {
    ApplicationId: string;
}
export interface DeleteApplicationResponse {
}
export interface GetApplicationRequest {
    ApplicationId: string;
    SemanticVersion?: string;
}
export interface GetApplicationResponse {
    ApplicationId?: string;
    Author?: string;
    CreationTime?: string;
    Description?: string;
    HomePageUrl?: string;
    IsVerifiedAuthor?: boolean;
    Labels?: string[];
    LicenseUrl?: string;
    Name?: string;
    ReadmeUrl?: string;
    SpdxLicenseId?: string;
    VerifiedAuthorUrl?: string;
    Version?: Version & {
        ApplicationId: string;
        CreationTime: string;
        ParameterDefinitions: (ParameterDefinition & {
            Name: string;
            ReferencedByResources: __listOf__string;
        })[];
        RequiredCapabilities: __listOfCapability;
        ResourcesSupported: boolean;
        SemanticVersion: string;
        TemplateUrl: string;
    };
}
export interface GetApplicationPolicyRequest {
    ApplicationId: string;
}
export interface ApplicationPolicyStatement {
    Actions?: string[];
    PrincipalOrgIDs?: string[];
    Principals?: string[];
    StatementId?: string;
}
export type __listOfApplicationPolicyStatement = ApplicationPolicyStatement[];
export interface GetApplicationPolicyResponse {
    Statements?: (ApplicationPolicyStatement & {
        Actions: __listOf__string;
        Principals: __listOf__string;
    })[];
}
export interface GetCloudFormationTemplateRequest {
    ApplicationId: string;
    TemplateId: string;
}
export interface GetCloudFormationTemplateResponse {
    ApplicationId?: string;
    CreationTime?: string;
    ExpirationTime?: string;
    SemanticVersion?: string;
    Status?: Status;
    TemplateId?: string;
    TemplateUrl?: string;
}
export type MaxItems = number;
export interface ListApplicationDependenciesRequest {
    ApplicationId: string;
    MaxItems?: number;
    NextToken?: string;
    SemanticVersion?: string;
}
export interface ApplicationDependencySummary {
    ApplicationId?: string;
    SemanticVersion?: string;
}
export type __listOfApplicationDependencySummary = ApplicationDependencySummary[];
export interface ListApplicationDependenciesResponse {
    Dependencies?: (ApplicationDependencySummary & {
        ApplicationId: string;
        SemanticVersion: string;
    })[];
    NextToken?: string;
}
export interface ListApplicationsRequest {
    MaxItems?: number;
    NextToken?: string;
}
export interface ApplicationSummary {
    ApplicationId?: string;
    Author?: string;
    CreationTime?: string;
    Description?: string;
    HomePageUrl?: string;
    Labels?: string[];
    Name?: string;
    SpdxLicenseId?: string;
}
export type __listOfApplicationSummary = ApplicationSummary[];
export interface ListApplicationsResponse {
    Applications?: (ApplicationSummary & {
        ApplicationId: string;
        Author: string;
        Description: string;
        Name: string;
    })[];
    NextToken?: string;
}
export interface ListApplicationVersionsRequest {
    ApplicationId: string;
    MaxItems?: number;
    NextToken?: string;
}
export interface VersionSummary {
    ApplicationId?: string;
    CreationTime?: string;
    SemanticVersion?: string;
    SourceCodeUrl?: string;
}
export type __listOfVersionSummary = VersionSummary[];
export interface ListApplicationVersionsResponse {
    NextToken?: string;
    Versions?: (VersionSummary & {
        ApplicationId: string;
        CreationTime: string;
        SemanticVersion: string;
    })[];
}
export interface PutApplicationPolicyRequest {
    ApplicationId: string;
    Statements?: ApplicationPolicyStatement[];
}
export interface PutApplicationPolicyResponse {
    Statements?: (ApplicationPolicyStatement & {
        Actions: __listOf__string;
        Principals: __listOf__string;
    })[];
}
export interface UnshareApplicationRequest {
    ApplicationId: string;
    OrganizationId?: string;
}
export interface UnshareApplicationResponse {
}
export interface UpdateApplicationRequest {
    ApplicationId: string;
    Author?: string;
    Description?: string;
    HomePageUrl?: string;
    Labels?: string[];
    ReadmeBody?: string;
    ReadmeUrl?: string;
}
export interface UpdateApplicationResponse {
    ApplicationId?: string;
    Author?: string;
    CreationTime?: string;
    Description?: string;
    HomePageUrl?: string;
    IsVerifiedAuthor?: boolean;
    Labels?: string[];
    LicenseUrl?: string;
    Name?: string;
    ReadmeUrl?: string;
    SpdxLicenseId?: string;
    VerifiedAuthorUrl?: string;
    Version?: Version & {
        ApplicationId: string;
        CreationTime: string;
        ParameterDefinitions: (ParameterDefinition & {
            Name: string;
            ReferencedByResources: __listOf__string;
        })[];
        RequiredCapabilities: __listOfCapability;
        ResourcesSupported: boolean;
        SemanticVersion: string;
        TemplateUrl: string;
    };
}
export type CreateApplicationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Creates an application, optionally including an AWS SAM file to create the first application version in the same call.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationVersionError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Creates an application version.
 */
export declare const createApplicationVersion: API.OperationMethod<CreateApplicationVersionRequest, CreateApplicationVersionResponse, CreateApplicationVersionError, Credentials | HttpClient.HttpClient>;
export type CreateCloudFormationChangeSetError = BadRequestException | ForbiddenException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Creates an AWS CloudFormation change set for the given application.
 */
export declare const createCloudFormationChangeSet: API.OperationMethod<CreateCloudFormationChangeSetRequest, CreateCloudFormationChangeSetResponse, CreateCloudFormationChangeSetError, Credentials | HttpClient.HttpClient>;
export type CreateCloudFormationTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an AWS CloudFormation template.
 */
export declare const createCloudFormationTemplate: API.OperationMethod<CreateCloudFormationTemplateRequest, CreateCloudFormationTemplateResponse, CreateCloudFormationTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the specified application.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the specified application.
 */
export declare const getApplication: API.OperationMethod<GetApplicationRequest, GetApplicationResponse, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetApplicationPolicyError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the policy for the application.
 */
export declare const getApplicationPolicy: API.OperationMethod<GetApplicationPolicyRequest, GetApplicationPolicyResponse, GetApplicationPolicyError, Credentials | HttpClient.HttpClient>;
export type GetCloudFormationTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the specified AWS CloudFormation template.
 */
export declare const getCloudFormationTemplate: API.OperationMethod<GetCloudFormationTemplateRequest, GetCloudFormationTemplateResponse, GetCloudFormationTemplateError, Credentials | HttpClient.HttpClient>;
export type ListApplicationDependenciesError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the list of applications nested in the containing application.
 */
export declare const listApplicationDependencies: API.PaginatedOperationMethod<ListApplicationDependenciesRequest, ListApplicationDependenciesResponse, ListApplicationDependenciesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListApplicationsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Lists applications owned by the requester.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListApplicationVersionsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists versions for the specified application.
 */
export declare const listApplicationVersions: API.PaginatedOperationMethod<ListApplicationVersionsRequest, ListApplicationVersionsResponse, ListApplicationVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type PutApplicationPolicyError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Sets the permission policy for an application. For the list of actions supported for this operation, see
 * Application
 * Permissions
 * .
 */
export declare const putApplicationPolicy: API.OperationMethod<PutApplicationPolicyRequest, PutApplicationPolicyResponse, PutApplicationPolicyError, Credentials | HttpClient.HttpClient>;
export type UnshareApplicationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Unshares an application from an AWS Organization.
 *
 * This operation can be called only from the organization's master account.
 */
export declare const unshareApplication: API.OperationMethod<UnshareApplicationRequest, UnshareApplicationResponse, UnshareApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the specified application.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=serverlessapplicationrepository.d.ts.map