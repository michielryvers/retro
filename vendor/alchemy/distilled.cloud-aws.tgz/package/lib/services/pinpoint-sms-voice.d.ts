import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AlreadyExistsException_base: S.TaggedErrorClass<"AlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AlreadyExistsException extends /*@__PURE__*/ AlreadyExistsException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const InternalServiceErrorException_base: S.TaggedErrorClass<"InternalServiceErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServiceErrorException extends /*@__PURE__*/ InternalServiceErrorException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}>;
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type WordCharactersWithDelimiters = string;
export interface CreateConfigurationSetRequest {
    ConfigurationSetName?: string;
}
export interface CreateConfigurationSetResponse {
}
export interface CloudWatchLogsDestination {
    IamRoleArn?: string;
    LogGroupArn?: string;
}
export interface KinesisFirehoseDestination {
    DeliveryStreamArn?: string;
    IamRoleArn?: string;
}
export type EventType = "INITIATED_CALL" | "RINGING" | "ANSWERED" | "COMPLETED_CALL" | "BUSY" | "FAILED" | "NO_ANSWER" | (string & {});
export type EventTypes = EventType[];
export interface SnsDestination {
    TopicArn?: string;
}
export interface EventDestinationDefinition {
    CloudWatchLogsDestination?: CloudWatchLogsDestination;
    Enabled?: boolean;
    KinesisFirehoseDestination?: KinesisFirehoseDestination;
    MatchingEventTypes?: EventType[];
    SnsDestination?: SnsDestination;
}
export type NonEmptyString = string;
export interface CreateConfigurationSetEventDestinationRequest {
    ConfigurationSetName: string;
    EventDestination?: EventDestinationDefinition;
    EventDestinationName?: string;
}
export interface CreateConfigurationSetEventDestinationResponse {
}
export interface DeleteConfigurationSetRequest {
    ConfigurationSetName: string;
}
export interface DeleteConfigurationSetResponse {
}
export interface DeleteConfigurationSetEventDestinationRequest {
    ConfigurationSetName: string;
    EventDestinationName: string;
}
export interface DeleteConfigurationSetEventDestinationResponse {
}
export interface GetConfigurationSetEventDestinationsRequest {
    ConfigurationSetName: string;
}
export interface EventDestination {
    CloudWatchLogsDestination?: CloudWatchLogsDestination;
    Enabled?: boolean;
    KinesisFirehoseDestination?: KinesisFirehoseDestination;
    MatchingEventTypes?: EventType[];
    Name?: string;
    SnsDestination?: SnsDestination;
}
export type EventDestinations = EventDestination[];
export interface GetConfigurationSetEventDestinationsResponse {
    EventDestinations?: EventDestination[];
}
export interface ListConfigurationSetsRequest {
    NextToken?: string;
    PageSize?: string;
}
export type ConfigurationSets = string[];
export type NextTokenString = string;
export interface ListConfigurationSetsResponse {
    ConfigurationSets?: string[];
    NextToken?: string;
}
export interface CallInstructionsMessageType {
    Text?: string;
}
export interface PlainTextMessageType {
    LanguageCode?: string;
    Text?: string;
    VoiceId?: string;
}
export interface SSMLMessageType {
    LanguageCode?: string;
    Text?: string;
    VoiceId?: string;
}
export interface VoiceMessageContent {
    CallInstructionsMessage?: CallInstructionsMessageType;
    PlainTextMessage?: PlainTextMessageType;
    SSMLMessage?: SSMLMessageType;
}
export interface SendVoiceMessageRequest {
    CallerId?: string;
    ConfigurationSetName?: string;
    Content?: VoiceMessageContent;
    DestinationPhoneNumber?: string;
    OriginationPhoneNumber?: string;
}
export interface SendVoiceMessageResponse {
    MessageId?: string;
}
export interface UpdateConfigurationSetEventDestinationRequest {
    ConfigurationSetName: string;
    EventDestination?: EventDestinationDefinition;
    EventDestinationName: string;
}
export interface UpdateConfigurationSetEventDestinationResponse {
}
export type CreateConfigurationSetError = AlreadyExistsException | BadRequestException | InternalServiceErrorException | LimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * Create a new configuration set. After you create the configuration set, you can add one or more event destinations to it.
 */
export declare const createConfigurationSet: API.OperationMethod<CreateConfigurationSetRequest, CreateConfigurationSetResponse, CreateConfigurationSetError, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationSetEventDestinationError = AlreadyExistsException | BadRequestException | InternalServiceErrorException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Create a new event destination in a configuration set.
 */
export declare const createConfigurationSetEventDestination: API.OperationMethod<CreateConfigurationSetEventDestinationRequest, CreateConfigurationSetEventDestinationResponse, CreateConfigurationSetEventDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationSetError = BadRequestException | InternalServiceErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an existing configuration set.
 */
export declare const deleteConfigurationSet: API.OperationMethod<DeleteConfigurationSetRequest, DeleteConfigurationSetResponse, DeleteConfigurationSetError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationSetEventDestinationError = BadRequestException | InternalServiceErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an event destination in a configuration set.
 */
export declare const deleteConfigurationSetEventDestination: API.OperationMethod<DeleteConfigurationSetEventDestinationRequest, DeleteConfigurationSetEventDestinationResponse, DeleteConfigurationSetEventDestinationError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationSetEventDestinationsError = BadRequestException | InternalServiceErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Obtain information about an event destination, including the types of events it reports, the Amazon Resource Name (ARN) of the destination, and the name of the event destination.
 */
export declare const getConfigurationSetEventDestinations: API.OperationMethod<GetConfigurationSetEventDestinationsRequest, GetConfigurationSetEventDestinationsResponse, GetConfigurationSetEventDestinationsError, Credentials | HttpClient.HttpClient>;
export type ListConfigurationSetsError = BadRequestException | InternalServiceErrorException | TooManyRequestsException | CommonErrors;
/**
 * List all of the configuration sets associated with your Amazon Pinpoint account in the current region.
 */
export declare const listConfigurationSets: API.OperationMethod<ListConfigurationSetsRequest, ListConfigurationSetsResponse, ListConfigurationSetsError, Credentials | HttpClient.HttpClient>;
export type SendVoiceMessageError = BadRequestException | InternalServiceErrorException | TooManyRequestsException | CommonErrors;
/**
 * Create a new voice message and send it to a recipient's phone number.
 */
export declare const sendVoiceMessage: API.OperationMethod<SendVoiceMessageRequest, SendVoiceMessageResponse, SendVoiceMessageError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationSetEventDestinationError = BadRequestException | InternalServiceErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Update an event destination in a configuration set. An event destination is a location that you publish information about your voice calls to. For example, you can log an event to an Amazon CloudWatch destination when a call fails.
 */
export declare const updateConfigurationSetEventDestination: API.OperationMethod<UpdateConfigurationSetEventDestinationRequest, UpdateConfigurationSetEventDestinationResponse, UpdateConfigurationSetEventDestinationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=pinpoint-sms-voice.d.ts.map