import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
    readonly ServiceCode: any;
    readonly QuotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly ServiceCode: any;
    readonly QuotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DirectoryId = string;
export type CertificateAuthorityArn = string;
export type IpAddressType = "IPV4" | "DUALSTACK" | (string & {});
export type SecurityGroupId = string;
export type SecurityGroupIdList = string[];
export interface VpcInformation {
    IpAddressType?: IpAddressType;
    SecurityGroupIds: string[];
}
export type ClientToken = string;
export type Tags = {
    [key: string]: string | undefined;
};
export interface CreateConnectorRequest {
    DirectoryId: string;
    CertificateAuthorityArn: string;
    VpcInformation: VpcInformation;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type ConnectorArn = string;
export interface CreateConnectorResponse {
    ConnectorArn?: string;
}
export interface CreateDirectoryRegistrationRequest {
    DirectoryId: string;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type DirectoryRegistrationArn = string;
export interface CreateDirectoryRegistrationResponse {
    DirectoryRegistrationArn?: string;
}
export interface CreateServicePrincipalNameRequest {
    DirectoryRegistrationArn: string;
    ConnectorArn: string;
    ClientToken?: string;
}
export interface CreateServicePrincipalNameResponse {
}
export type TemplateName = string;
export type ValidityPeriodType = "HOURS" | "DAYS" | "WEEKS" | "MONTHS" | "YEARS" | (string & {});
export interface ValidityPeriod {
    PeriodType: ValidityPeriodType;
    Period: number;
}
export interface CertificateValidity {
    ValidityPeriod: ValidityPeriod;
    RenewalPeriod: ValidityPeriod;
}
export type TemplateNameList = string[];
export type KeySpec = "KEY_EXCHANGE" | "SIGNATURE" | (string & {});
export type CryptoProvidersList = string[];
export interface PrivateKeyAttributesV2 {
    MinimalKeyLength: number;
    KeySpec: KeySpec;
    CryptoProviders?: string[];
}
export type ClientCompatibilityV2 = "WINDOWS_SERVER_2003" | "WINDOWS_SERVER_2008" | "WINDOWS_SERVER_2008_R2" | "WINDOWS_SERVER_2012" | "WINDOWS_SERVER_2012_R2" | "WINDOWS_SERVER_2016" | (string & {});
export interface PrivateKeyFlagsV2 {
    ExportableKey?: boolean;
    StrongKeyProtectionRequired?: boolean;
    ClientVersion: ClientCompatibilityV2;
}
export interface EnrollmentFlagsV2 {
    IncludeSymmetricAlgorithms?: boolean;
    UserInteractionRequired?: boolean;
    RemoveInvalidCertificateFromPersonalStore?: boolean;
    NoSecurityExtension?: boolean;
    EnableKeyReuseOnNtTokenKeysetStorageFull?: boolean;
}
export interface SubjectNameFlagsV2 {
    SanRequireDomainDns?: boolean;
    SanRequireSpn?: boolean;
    SanRequireDirectoryGuid?: boolean;
    SanRequireUpn?: boolean;
    SanRequireEmail?: boolean;
    SanRequireDns?: boolean;
    RequireDnsAsCn?: boolean;
    RequireEmail?: boolean;
    RequireCommonName?: boolean;
    RequireDirectoryPath?: boolean;
}
export interface GeneralFlagsV2 {
    AutoEnrollment?: boolean;
    MachineType?: boolean;
}
export interface KeyUsageFlags {
    DigitalSignature?: boolean;
    NonRepudiation?: boolean;
    KeyEncipherment?: boolean;
    DataEncipherment?: boolean;
    KeyAgreement?: boolean;
}
export interface KeyUsage {
    Critical?: boolean;
    UsageFlags: KeyUsageFlags;
}
export type ApplicationPolicyType = "ALL_APPLICATION_POLICIES" | "ANY_PURPOSE" | "ATTESTATION_IDENTITY_KEY_CERTIFICATE" | "CERTIFICATE_REQUEST_AGENT" | "CLIENT_AUTHENTICATION" | "CODE_SIGNING" | "CTL_USAGE" | "DIGITAL_RIGHTS" | "DIRECTORY_SERVICE_EMAIL_REPLICATION" | "DISALLOWED_LIST" | "DNS_SERVER_TRUST" | "DOCUMENT_ENCRYPTION" | "DOCUMENT_SIGNING" | "DYNAMIC_CODE_GENERATOR" | "EARLY_LAUNCH_ANTIMALWARE_DRIVER" | "EMBEDDED_WINDOWS_SYSTEM_COMPONENT_VERIFICATION" | "ENCLAVE" | "ENCRYPTING_FILE_SYSTEM" | "ENDORSEMENT_KEY_CERTIFICATE" | "FILE_RECOVERY" | "HAL_EXTENSION" | "IP_SECURITY_END_SYSTEM" | "IP_SECURITY_IKE_INTERMEDIATE" | "IP_SECURITY_TUNNEL_TERMINATION" | "IP_SECURITY_USER" | "ISOLATED_USER_MODE" | "KDC_AUTHENTICATION" | "KERNEL_MODE_CODE_SIGNING" | "KEY_PACK_LICENSES" | "KEY_RECOVERY" | "KEY_RECOVERY_AGENT" | "LICENSE_SERVER_VERIFICATION" | "LIFETIME_SIGNING" | "MICROSOFT_PUBLISHER" | "MICROSOFT_TIME_STAMPING" | "MICROSOFT_TRUST_LIST_SIGNING" | "OCSP_SIGNING" | "OEM_WINDOWS_SYSTEM_COMPONENT_VERIFICATION" | "PLATFORM_CERTIFICATE" | "PREVIEW_BUILD_SIGNING" | "PRIVATE_KEY_ARCHIVAL" | "PROTECTED_PROCESS_LIGHT_VERIFICATION" | "PROTECTED_PROCESS_VERIFICATION" | "QUALIFIED_SUBORDINATION" | "REVOKED_LIST_SIGNER" | "ROOT_PROGRAM_AUTO_UPDATE_CA_REVOCATION" | "ROOT_PROGRAM_AUTO_UPDATE_END_REVOCATION" | "ROOT_PROGRAM_NO_OSCP_FAILOVER_TO_CRL" | "ROOT_LIST_SIGNER" | "SECURE_EMAIL" | "SERVER_AUTHENTICATION" | "SMART_CARD_LOGIN" | "SPC_ENCRYPTED_DIGEST_RETRY_COUNT" | "SPC_RELAXED_PE_MARKER_CHECK" | "TIME_STAMPING" | "WINDOWS_HARDWARE_DRIVER_ATTESTED_VERIFICATION" | "WINDOWS_HARDWARE_DRIVER_EXTENDED_VERIFICATION" | "WINDOWS_HARDWARE_DRIVER_VERIFICATION" | "WINDOWS_HELLO_RECOVERY_KEY_ENCRYPTION" | "WINDOWS_KITS_COMPONENT" | "WINDOWS_RT_VERIFICATION" | "WINDOWS_SOFTWARE_EXTENSION_VERIFICATION" | "WINDOWS_STORE" | "WINDOWS_SYSTEM_COMPONENT_VERIFICATION" | "WINDOWS_TCB_COMPONENT" | "WINDOWS_THIRD_PARTY_APPLICATION_COMPONENT" | "WINDOWS_UPDATE" | (string & {});
export type CustomObjectIdentifier = string;
export type ApplicationPolicy = {
    PolicyType: ApplicationPolicyType;
    PolicyObjectIdentifier?: never;
} | {
    PolicyType?: never;
    PolicyObjectIdentifier: string;
};
export type ApplicationPolicyList = ApplicationPolicy[];
export interface ApplicationPolicies {
    Critical?: boolean;
    Policies: ApplicationPolicy[];
}
export interface ExtensionsV2 {
    KeyUsage: KeyUsage;
    ApplicationPolicies?: ApplicationPolicies;
}
export interface TemplateV2 {
    CertificateValidity: CertificateValidity;
    SupersededTemplates?: string[];
    PrivateKeyAttributes: PrivateKeyAttributesV2;
    PrivateKeyFlags: PrivateKeyFlagsV2;
    EnrollmentFlags: EnrollmentFlagsV2;
    SubjectNameFlags: SubjectNameFlagsV2;
    GeneralFlags: GeneralFlagsV2;
    Extensions: ExtensionsV2;
}
export type KeyUsagePropertyType = "ALL" | (string & {});
export interface KeyUsagePropertyFlags {
    Decrypt?: boolean;
    KeyAgreement?: boolean;
    Sign?: boolean;
}
export type KeyUsageProperty = {
    PropertyType: KeyUsagePropertyType;
    PropertyFlags?: never;
} | {
    PropertyType?: never;
    PropertyFlags: KeyUsagePropertyFlags;
};
export type PrivateKeyAlgorithm = "RSA" | "ECDH_P256" | "ECDH_P384" | "ECDH_P521" | (string & {});
export interface PrivateKeyAttributesV3 {
    MinimalKeyLength: number;
    KeySpec: KeySpec;
    CryptoProviders?: string[];
    KeyUsageProperty: KeyUsageProperty;
    Algorithm: PrivateKeyAlgorithm;
}
export type ClientCompatibilityV3 = "WINDOWS_SERVER_2008" | "WINDOWS_SERVER_2008_R2" | "WINDOWS_SERVER_2012" | "WINDOWS_SERVER_2012_R2" | "WINDOWS_SERVER_2016" | (string & {});
export interface PrivateKeyFlagsV3 {
    ExportableKey?: boolean;
    StrongKeyProtectionRequired?: boolean;
    RequireAlternateSignatureAlgorithm?: boolean;
    ClientVersion: ClientCompatibilityV3;
}
export interface EnrollmentFlagsV3 {
    IncludeSymmetricAlgorithms?: boolean;
    UserInteractionRequired?: boolean;
    RemoveInvalidCertificateFromPersonalStore?: boolean;
    NoSecurityExtension?: boolean;
    EnableKeyReuseOnNtTokenKeysetStorageFull?: boolean;
}
export interface SubjectNameFlagsV3 {
    SanRequireDomainDns?: boolean;
    SanRequireSpn?: boolean;
    SanRequireDirectoryGuid?: boolean;
    SanRequireUpn?: boolean;
    SanRequireEmail?: boolean;
    SanRequireDns?: boolean;
    RequireDnsAsCn?: boolean;
    RequireEmail?: boolean;
    RequireCommonName?: boolean;
    RequireDirectoryPath?: boolean;
}
export interface GeneralFlagsV3 {
    AutoEnrollment?: boolean;
    MachineType?: boolean;
}
export type HashAlgorithm = "SHA256" | "SHA384" | "SHA512" | (string & {});
export interface ExtensionsV3 {
    KeyUsage: KeyUsage;
    ApplicationPolicies?: ApplicationPolicies;
}
export interface TemplateV3 {
    CertificateValidity: CertificateValidity;
    SupersededTemplates?: string[];
    PrivateKeyAttributes: PrivateKeyAttributesV3;
    PrivateKeyFlags: PrivateKeyFlagsV3;
    EnrollmentFlags: EnrollmentFlagsV3;
    SubjectNameFlags: SubjectNameFlagsV3;
    GeneralFlags: GeneralFlagsV3;
    HashAlgorithm: HashAlgorithm;
    Extensions: ExtensionsV3;
}
export interface PrivateKeyAttributesV4 {
    MinimalKeyLength: number;
    KeySpec: KeySpec;
    CryptoProviders?: string[];
    KeyUsageProperty?: KeyUsageProperty;
    Algorithm?: PrivateKeyAlgorithm;
}
export type ClientCompatibilityV4 = "WINDOWS_SERVER_2012" | "WINDOWS_SERVER_2012_R2" | "WINDOWS_SERVER_2016" | (string & {});
export interface PrivateKeyFlagsV4 {
    ExportableKey?: boolean;
    StrongKeyProtectionRequired?: boolean;
    RequireAlternateSignatureAlgorithm?: boolean;
    RequireSameKeyRenewal?: boolean;
    UseLegacyProvider?: boolean;
    ClientVersion: ClientCompatibilityV4;
}
export interface EnrollmentFlagsV4 {
    IncludeSymmetricAlgorithms?: boolean;
    UserInteractionRequired?: boolean;
    RemoveInvalidCertificateFromPersonalStore?: boolean;
    NoSecurityExtension?: boolean;
    EnableKeyReuseOnNtTokenKeysetStorageFull?: boolean;
}
export interface SubjectNameFlagsV4 {
    SanRequireDomainDns?: boolean;
    SanRequireSpn?: boolean;
    SanRequireDirectoryGuid?: boolean;
    SanRequireUpn?: boolean;
    SanRequireEmail?: boolean;
    SanRequireDns?: boolean;
    RequireDnsAsCn?: boolean;
    RequireEmail?: boolean;
    RequireCommonName?: boolean;
    RequireDirectoryPath?: boolean;
}
export interface GeneralFlagsV4 {
    AutoEnrollment?: boolean;
    MachineType?: boolean;
}
export interface ExtensionsV4 {
    KeyUsage: KeyUsage;
    ApplicationPolicies?: ApplicationPolicies;
}
export interface TemplateV4 {
    CertificateValidity: CertificateValidity;
    SupersededTemplates?: string[];
    PrivateKeyAttributes: PrivateKeyAttributesV4;
    PrivateKeyFlags: PrivateKeyFlagsV4;
    EnrollmentFlags: EnrollmentFlagsV4;
    SubjectNameFlags: SubjectNameFlagsV4;
    GeneralFlags: GeneralFlagsV4;
    HashAlgorithm?: HashAlgorithm;
    Extensions: ExtensionsV4;
}
export type TemplateDefinition = {
    TemplateV2: TemplateV2;
    TemplateV3?: never;
    TemplateV4?: never;
} | {
    TemplateV2?: never;
    TemplateV3: TemplateV3;
    TemplateV4?: never;
} | {
    TemplateV2?: never;
    TemplateV3?: never;
    TemplateV4: TemplateV4;
};
export interface CreateTemplateRequest {
    ConnectorArn: string;
    Name: string;
    Definition: TemplateDefinition;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type TemplateArn = string;
export interface CreateTemplateResponse {
    TemplateArn?: string;
}
export type GroupSecurityIdentifier = string;
export type DisplayName = string;
export type AccessRight = "ALLOW" | "DENY" | (string & {});
export interface AccessRights {
    Enroll?: AccessRight;
    AutoEnroll?: AccessRight;
}
export interface CreateTemplateGroupAccessControlEntryRequest {
    TemplateArn: string;
    GroupSecurityIdentifier: string;
    GroupDisplayName: string;
    AccessRights: AccessRights;
    ClientToken?: string;
}
export interface CreateTemplateGroupAccessControlEntryResponse {
}
export interface DeleteConnectorRequest {
    ConnectorArn: string;
}
export interface DeleteConnectorResponse {
}
export interface DeleteDirectoryRegistrationRequest {
    DirectoryRegistrationArn: string;
}
export interface DeleteDirectoryRegistrationResponse {
}
export interface DeleteServicePrincipalNameRequest {
    DirectoryRegistrationArn: string;
    ConnectorArn: string;
}
export interface DeleteServicePrincipalNameResponse {
}
export interface DeleteTemplateRequest {
    TemplateArn: string;
}
export interface DeleteTemplateResponse {
}
export interface DeleteTemplateGroupAccessControlEntryRequest {
    TemplateArn: string;
    GroupSecurityIdentifier: string;
}
export interface DeleteTemplateGroupAccessControlEntryResponse {
}
export interface GetConnectorRequest {
    ConnectorArn: string;
}
export type ConnectorStatus = "CREATING" | "ACTIVE" | "DELETING" | "FAILED" | (string & {});
export type ConnectorStatusReason = "CA_CERTIFICATE_REGISTRATION_FAILED" | "DIRECTORY_ACCESS_DENIED" | "INTERNAL_FAILURE" | "INSUFFICIENT_FREE_ADDRESSES" | "INVALID_SUBNET_IP_PROTOCOL" | "PRIVATECA_ACCESS_DENIED" | "PRIVATECA_RESOURCE_NOT_FOUND" | "SECURITY_GROUP_NOT_IN_VPC" | "VPC_ACCESS_DENIED" | "VPC_ENDPOINT_LIMIT_EXCEEDED" | "VPC_RESOURCE_NOT_FOUND" | (string & {});
export interface Connector {
    Arn?: string;
    CertificateAuthorityArn?: string;
    CertificateEnrollmentPolicyServerEndpoint?: string;
    DirectoryId?: string;
    VpcInformation?: VpcInformation;
    Status?: ConnectorStatus;
    StatusReason?: ConnectorStatusReason;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export interface GetConnectorResponse {
    Connector?: Connector;
}
export interface GetDirectoryRegistrationRequest {
    DirectoryRegistrationArn: string;
}
export type DirectoryRegistrationStatus = "CREATING" | "ACTIVE" | "DELETING" | "FAILED" | (string & {});
export type DirectoryRegistrationStatusReason = "DIRECTORY_ACCESS_DENIED" | "DIRECTORY_RESOURCE_NOT_FOUND" | "DIRECTORY_NOT_ACTIVE" | "DIRECTORY_NOT_REACHABLE" | "DIRECTORY_TYPE_NOT_SUPPORTED" | "INTERNAL_FAILURE" | (string & {});
export interface DirectoryRegistration {
    Arn?: string;
    DirectoryId?: string;
    Status?: DirectoryRegistrationStatus;
    StatusReason?: DirectoryRegistrationStatusReason;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export interface GetDirectoryRegistrationResponse {
    DirectoryRegistration?: DirectoryRegistration;
}
export interface GetServicePrincipalNameRequest {
    DirectoryRegistrationArn: string;
    ConnectorArn: string;
}
export type ServicePrincipalNameStatus = "CREATING" | "ACTIVE" | "DELETING" | "FAILED" | (string & {});
export type ServicePrincipalNameStatusReason = "DIRECTORY_ACCESS_DENIED" | "DIRECTORY_NOT_REACHABLE" | "DIRECTORY_RESOURCE_NOT_FOUND" | "SPN_EXISTS_ON_DIFFERENT_AD_OBJECT" | "SPN_LIMIT_EXCEEDED" | "INTERNAL_FAILURE" | (string & {});
export interface ServicePrincipalName {
    DirectoryRegistrationArn?: string;
    ConnectorArn?: string;
    Status?: ServicePrincipalNameStatus;
    StatusReason?: ServicePrincipalNameStatusReason;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export interface GetServicePrincipalNameResponse {
    ServicePrincipalName?: ServicePrincipalName;
}
export interface GetTemplateRequest {
    TemplateArn: string;
}
export type TemplateStatus = "ACTIVE" | "DELETING" | (string & {});
export interface TemplateRevision {
    MajorRevision: number;
    MinorRevision: number;
}
export interface Template {
    Arn?: string;
    ConnectorArn?: string;
    Definition?: TemplateDefinition;
    Name?: string;
    ObjectIdentifier?: string;
    PolicySchema?: number;
    Status?: TemplateStatus;
    Revision?: TemplateRevision;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export interface GetTemplateResponse {
    Template?: Template;
}
export interface GetTemplateGroupAccessControlEntryRequest {
    TemplateArn: string;
    GroupSecurityIdentifier: string;
}
export interface AccessControlEntry {
    GroupDisplayName?: string;
    GroupSecurityIdentifier?: string;
    AccessRights?: AccessRights;
    TemplateArn?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export interface GetTemplateGroupAccessControlEntryResponse {
    AccessControlEntry?: AccessControlEntry;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListConnectorsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface ConnectorSummary {
    Arn?: string;
    CertificateAuthorityArn?: string;
    CertificateEnrollmentPolicyServerEndpoint?: string;
    DirectoryId?: string;
    VpcInformation?: VpcInformation;
    Status?: ConnectorStatus;
    StatusReason?: ConnectorStatusReason;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export type ConnectorList = ConnectorSummary[];
export interface ListConnectorsResponse {
    Connectors?: ConnectorSummary[];
    NextToken?: string;
}
export interface ListDirectoryRegistrationsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface DirectoryRegistrationSummary {
    Arn?: string;
    DirectoryId?: string;
    Status?: DirectoryRegistrationStatus;
    StatusReason?: DirectoryRegistrationStatusReason;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export type DirectoryRegistrationList = DirectoryRegistrationSummary[];
export interface ListDirectoryRegistrationsResponse {
    DirectoryRegistrations?: DirectoryRegistrationSummary[];
    NextToken?: string;
}
export interface ListServicePrincipalNamesRequest {
    MaxResults?: number;
    NextToken?: string;
    DirectoryRegistrationArn: string;
}
export interface ServicePrincipalNameSummary {
    DirectoryRegistrationArn?: string;
    ConnectorArn?: string;
    Status?: ServicePrincipalNameStatus;
    StatusReason?: ServicePrincipalNameStatusReason;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export type ServicePrincipalNameList = ServicePrincipalNameSummary[];
export interface ListServicePrincipalNamesResponse {
    ServicePrincipalNames?: ServicePrincipalNameSummary[];
    NextToken?: string;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListTemplateGroupAccessControlEntriesRequest {
    MaxResults?: number;
    NextToken?: string;
    TemplateArn: string;
}
export interface AccessControlEntrySummary {
    GroupDisplayName?: string;
    GroupSecurityIdentifier?: string;
    AccessRights?: AccessRights;
    TemplateArn?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export type AccessControlEntryList = AccessControlEntrySummary[];
export interface ListTemplateGroupAccessControlEntriesResponse {
    AccessControlEntries?: AccessControlEntrySummary[];
    NextToken?: string;
}
export interface ListTemplatesRequest {
    MaxResults?: number;
    NextToken?: string;
    ConnectorArn: string;
}
export interface TemplateSummary {
    Arn?: string;
    ConnectorArn?: string;
    Definition?: TemplateDefinition;
    Name?: string;
    ObjectIdentifier?: string;
    PolicySchema?: number;
    Status?: TemplateStatus;
    Revision?: TemplateRevision;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export type TemplateList = TemplateSummary[];
export interface ListTemplatesResponse {
    Templates?: TemplateSummary[];
    NextToken?: string;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateTemplateRequest {
    TemplateArn: string;
    Definition?: TemplateDefinition;
    ReenrollAllCertificateHolders?: boolean;
}
export interface UpdateTemplateResponse {
}
export interface UpdateTemplateGroupAccessControlEntryRequest {
    TemplateArn: string;
    GroupSecurityIdentifier: string;
    GroupDisplayName?: string;
    AccessRights?: AccessRights;
}
export interface UpdateTemplateGroupAccessControlEntryResponse {
}
export type ValidationExceptionReason = "FIELD_VALIDATION_FAILED" | "INVALID_CA_SUBJECT" | "INVALID_PERMISSION" | "INVALID_STATE" | "MISMATCHED_CONNECTOR" | "MISMATCHED_VPC" | "NO_CLIENT_TOKEN" | "UNKNOWN_OPERATION" | "OTHER" | (string & {});
export type CreateConnectorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a connector between Amazon Web Services Private CA and an Active Directory. You must specify the private CA,
 * directory ID, and security groups.
 */
export declare const createConnector: API.OperationMethod<CreateConnectorRequest, CreateConnectorResponse, CreateConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateDirectoryRegistrationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a directory registration that authorizes communication between Amazon Web Services Private CA and an
 * Active Directory
 */
export declare const createDirectoryRegistration: API.OperationMethod<CreateDirectoryRegistrationRequest, CreateDirectoryRegistrationResponse, CreateDirectoryRegistrationError, Credentials | HttpClient.HttpClient>;
export type CreateServicePrincipalNameError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a service principal name (SPN) for the service account in Active Directory. Kerberos
 * authentication uses SPNs to associate a service instance with a service sign-in
 * account.
 */
export declare const createServicePrincipalName: API.OperationMethod<CreateServicePrincipalNameRequest, CreateServicePrincipalNameResponse, CreateServicePrincipalNameError, Credentials | HttpClient.HttpClient>;
export type CreateTemplateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Active Directory compatible certificate template. The connectors issues certificates
 * using these templates based on the requester's Active Directory group membership.
 */
export declare const createTemplate: API.OperationMethod<CreateTemplateRequest, CreateTemplateResponse, CreateTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateTemplateGroupAccessControlEntryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a group access control entry. Allow or deny Active Directory groups from enrolling and/or
 * autoenrolling with the template based on the group security identifiers (SIDs).
 */
export declare const createTemplateGroupAccessControlEntry: API.OperationMethod<CreateTemplateGroupAccessControlEntryRequest, CreateTemplateGroupAccessControlEntryResponse, CreateTemplateGroupAccessControlEntryError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a connector for Active Directory. You must provide the Amazon Resource Name (ARN) of the
 * connector that you want to delete. You can find the ARN by calling the https://docs.aws.amazon.com/pca-connector-ad/latest/APIReference/API_ListConnectors
 * action. Deleting a connector does not deregister your directory with Amazon Web Services Private CA. You can
 * deregister your directory by calling the https://docs.aws.amazon.com/pca-connector-ad/latest/APIReference/API_DeleteDirectoryRegistration
 * action.
 */
export declare const deleteConnector: API.OperationMethod<DeleteConnectorRequest, DeleteConnectorResponse, DeleteConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteDirectoryRegistrationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a directory registration. Deleting a directory registration deauthorizes
 * Amazon Web Services Private CA with the directory.
 */
export declare const deleteDirectoryRegistration: API.OperationMethod<DeleteDirectoryRegistrationRequest, DeleteDirectoryRegistrationResponse, DeleteDirectoryRegistrationError, Credentials | HttpClient.HttpClient>;
export type DeleteServicePrincipalNameError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the service principal name (SPN) used by a connector to authenticate with your
 * Active Directory.
 */
export declare const deleteServicePrincipalName: API.OperationMethod<DeleteServicePrincipalNameRequest, DeleteServicePrincipalNameResponse, DeleteServicePrincipalNameError, Credentials | HttpClient.HttpClient>;
export type DeleteTemplateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a template. Certificates issued using the template are still valid until they
 * are revoked or expired.
 */
export declare const deleteTemplate: API.OperationMethod<DeleteTemplateRequest, DeleteTemplateResponse, DeleteTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteTemplateGroupAccessControlEntryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a group access control entry.
 */
export declare const deleteTemplateGroupAccessControlEntry: API.OperationMethod<DeleteTemplateGroupAccessControlEntryRequest, DeleteTemplateGroupAccessControlEntryResponse, DeleteTemplateGroupAccessControlEntryError, Credentials | HttpClient.HttpClient>;
export type GetConnectorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists information about your connector. You specify the connector on input by its ARN
 * (Amazon Resource Name).
 */
export declare const getConnector: API.OperationMethod<GetConnectorRequest, GetConnectorResponse, GetConnectorError, Credentials | HttpClient.HttpClient>;
export type GetDirectoryRegistrationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * A structure that contains information about your directory registration.
 */
export declare const getDirectoryRegistration: API.OperationMethod<GetDirectoryRegistrationRequest, GetDirectoryRegistrationResponse, GetDirectoryRegistrationError, Credentials | HttpClient.HttpClient>;
export type GetServicePrincipalNameError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the service principal name that the connector uses to authenticate with
 * Active Directory.
 */
export declare const getServicePrincipalName: API.OperationMethod<GetServicePrincipalNameRequest, GetServicePrincipalNameResponse, GetServicePrincipalNameError, Credentials | HttpClient.HttpClient>;
export type GetTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a certificate template that the connector uses to issue certificates from a
 * private CA.
 */
export declare const getTemplate: API.OperationMethod<GetTemplateRequest, GetTemplateResponse, GetTemplateError, Credentials | HttpClient.HttpClient>;
export type GetTemplateGroupAccessControlEntryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the group access control entries for a template.
 */
export declare const getTemplateGroupAccessControlEntry: API.OperationMethod<GetTemplateGroupAccessControlEntryRequest, GetTemplateGroupAccessControlEntryResponse, GetTemplateGroupAccessControlEntryError, Credentials | HttpClient.HttpClient>;
export type ListConnectorsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the connectors that you created by using the https://docs.aws.amazon.com/pca-connector-ad/latest/APIReference/API_CreateConnector action.
 */
export declare const listConnectors: API.PaginatedOperationMethod<ListConnectorsRequest, ListConnectorsResponse, ListConnectorsError, Credentials | HttpClient.HttpClient, ConnectorSummary>;
export type ListDirectoryRegistrationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the directory registrations that you created by using the https://docs.aws.amazon.com/pca-connector-ad/latest/APIReference/API_CreateDirectoryRegistration
 * action.
 */
export declare const listDirectoryRegistrations: API.PaginatedOperationMethod<ListDirectoryRegistrationsRequest, ListDirectoryRegistrationsResponse, ListDirectoryRegistrationsError, Credentials | HttpClient.HttpClient, DirectoryRegistrationSummary>;
export type ListServicePrincipalNamesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the service principal names that the connector uses to authenticate with
 * Active Directory.
 */
export declare const listServicePrincipalNames: API.PaginatedOperationMethod<ListServicePrincipalNamesRequest, ListServicePrincipalNamesResponse, ListServicePrincipalNamesError, Credentials | HttpClient.HttpClient, ServicePrincipalNameSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags, if any, that are associated with your resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTemplateGroupAccessControlEntriesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists group access control entries you created.
 */
export declare const listTemplateGroupAccessControlEntries: API.PaginatedOperationMethod<ListTemplateGroupAccessControlEntriesRequest, ListTemplateGroupAccessControlEntriesResponse, ListTemplateGroupAccessControlEntriesError, Credentials | HttpClient.HttpClient, AccessControlEntrySummary>;
export type ListTemplatesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the templates, if any, that are associated with a connector.
 */
export declare const listTemplates: API.PaginatedOperationMethod<ListTemplatesRequest, ListTemplatesResponse, ListTemplatesError, Credentials | HttpClient.HttpClient, TemplateSummary>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds one or more tags to your resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from your resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateTemplateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update template configuration to define the information included in certificates.
 */
export declare const updateTemplate: API.OperationMethod<UpdateTemplateRequest, UpdateTemplateResponse, UpdateTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateTemplateGroupAccessControlEntryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a group access control entry you created using CreateTemplateGroupAccessControlEntry.
 */
export declare const updateTemplateGroupAccessControlEntry: API.OperationMethod<UpdateTemplateGroupAccessControlEntryRequest, UpdateTemplateGroupAccessControlEntryResponse, UpdateTemplateGroupAccessControlEntryError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=pca-connector-ad.d.ts.map