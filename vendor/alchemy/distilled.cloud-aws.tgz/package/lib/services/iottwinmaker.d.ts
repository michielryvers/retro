import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ConnectorFailureException_base: S.TaggedErrorClass<"ConnectorFailureException", {
    readonly message: any;
}>;
export declare class ConnectorFailureException extends /*@__PURE__*/ ConnectorFailureException_base {
}
declare const ConnectorTimeoutException_base: S.TaggedErrorClass<"ConnectorTimeoutException", {
    readonly message: any;
}>;
export declare class ConnectorTimeoutException extends /*@__PURE__*/ ConnectorTimeoutException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const QueryTimeoutException_base: S.TaggedErrorClass<"QueryTimeoutException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class QueryTimeoutException extends /*@__PURE__*/ QueryTimeoutException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Id = string;
export type Name = string;
export type ComponentPath = string;
export type ExternalIdProperty = {
    [key: string]: string | undefined;
};
export type EntityId = string;
export interface EntityPropertyReference {
    componentName?: string;
    componentPath?: string;
    externalIdProperty?: {
        [key: string]: string | undefined;
    };
    entityId?: string;
    propertyName: string;
}
export type DataValueList = DataValue[];
export type DataValueMap = {
    [key: string]: DataValue | undefined;
};
export interface RelationshipValue {
    targetEntityId?: string;
    targetComponentName?: string;
}
export type Expression = string;
export interface DataValue {
    booleanValue?: boolean;
    doubleValue?: number;
    integerValue?: number;
    longValue?: number;
    stringValue?: string;
    listValue?: DataValue[];
    mapValue?: {
        [key: string]: DataValue | undefined;
    };
    relationshipValue?: RelationshipValue;
    expression?: string;
}
export interface PropertyValue {
    timestamp?: Date;
    value: DataValue;
    time?: string;
}
export type PropertyValues = PropertyValue[];
export interface PropertyValueEntry {
    entityPropertyReference: EntityPropertyReference;
    propertyValues?: PropertyValue[];
}
export type Entries = PropertyValueEntry[];
export interface BatchPutPropertyValuesRequest {
    workspaceId: string;
    entries: PropertyValueEntry[];
}
export interface BatchPutPropertyError {
    errorCode: string;
    errorMessage: string;
    entry: PropertyValueEntry;
}
export type Errors = BatchPutPropertyError[];
export interface BatchPutPropertyErrorEntry {
    errors: BatchPutPropertyError[];
}
export type ErrorEntries = BatchPutPropertyErrorEntry[];
export interface BatchPutPropertyValuesResponse {
    errorEntries: BatchPutPropertyErrorEntry[];
}
export interface CancelMetadataTransferJobRequest {
    metadataTransferJobId: string;
}
export type TwinMakerArn = string;
export type MetadataTransferJobState = string;
export type ErrorCode = string;
export type ErrorMessage = string;
export interface ErrorDetails {
    code?: string;
    message?: string;
}
export interface MetadataTransferJobStatus {
    state?: string;
    error?: ErrorDetails;
    queuedPosition?: number;
}
export interface MetadataTransferJobProgress {
    totalCount?: number;
    succeededCount?: number;
    skippedCount?: number;
    failedCount?: number;
}
export interface CancelMetadataTransferJobResponse {
    metadataTransferJobId: string;
    arn: string;
    updateDateTime: Date;
    status: MetadataTransferJobStatus;
    progress?: MetadataTransferJobProgress;
}
export type ComponentTypeId = string;
export type Description = string;
export type Type = string;
export interface Relationship {
    targetComponentTypeId?: string;
    relationshipType?: string;
}
export interface DataType {
    type: string;
    nestedType?: DataType;
    allowedValues?: DataValue[];
    unitOfMeasure?: string;
    relationship?: Relationship;
}
export type Value = string;
export type Configuration = {
    [key: string]: string | undefined;
};
export type PropertyDisplayName = string;
export interface PropertyDefinitionRequest {
    dataType?: DataType;
    isRequiredInEntity?: boolean;
    isExternalId?: boolean;
    isStoredExternally?: boolean;
    isTimeSeries?: boolean;
    defaultValue?: DataValue;
    configuration?: {
        [key: string]: string | undefined;
    };
    displayName?: string;
}
export type PropertyDefinitionsRequest = {
    [key: string]: PropertyDefinitionRequest | undefined;
};
export type ExtendsFrom = string[];
export type RequiredProperties = string[];
export type Scope = string;
export type LambdaArn = string;
export interface LambdaFunction {
    arn: string;
}
export interface DataConnector {
    lambda?: LambdaFunction;
    isNative?: boolean;
}
export interface FunctionRequest {
    requiredProperties?: string[];
    scope?: string;
    implementedBy?: DataConnector;
}
export type FunctionsRequest = {
    [key: string]: FunctionRequest | undefined;
};
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type GroupType = string;
export type PropertyNames = string[];
export interface PropertyGroupRequest {
    groupType?: string;
    propertyNames?: string[];
}
export type PropertyGroupsRequest = {
    [key: string]: PropertyGroupRequest | undefined;
};
export type ComponentTypeName = string;
export interface CompositeComponentTypeRequest {
    componentTypeId?: string;
}
export type CompositeComponentTypesRequest = {
    [key: string]: CompositeComponentTypeRequest | undefined;
};
export interface CreateComponentTypeRequest {
    workspaceId: string;
    isSingleton?: boolean;
    componentTypeId: string;
    description?: string;
    propertyDefinitions?: {
        [key: string]: PropertyDefinitionRequest | undefined;
    };
    extendsFrom?: string[];
    functions?: {
        [key: string]: FunctionRequest | undefined;
    };
    tags?: {
        [key: string]: string | undefined;
    };
    propertyGroups?: {
        [key: string]: PropertyGroupRequest | undefined;
    };
    componentTypeName?: string;
    compositeComponentTypes?: {
        [key: string]: CompositeComponentTypeRequest | undefined;
    };
}
export type State = string;
export interface CreateComponentTypeResponse {
    arn: string;
    creationDateTime: Date;
    state: string;
}
export type EntityName = string;
export type PropertyUpdateType = string;
export interface PropertyRequest {
    definition?: PropertyDefinitionRequest;
    value?: DataValue;
    updateType?: string;
}
export type PropertyRequests = {
    [key: string]: PropertyRequest | undefined;
};
export type PropertyGroupUpdateType = string;
export interface ComponentPropertyGroupRequest {
    groupType?: string;
    propertyNames?: string[];
    updateType?: string;
}
export type ComponentPropertyGroupRequests = {
    [key: string]: ComponentPropertyGroupRequest | undefined;
};
export interface ComponentRequest {
    description?: string;
    componentTypeId?: string;
    properties?: {
        [key: string]: PropertyRequest | undefined;
    };
    propertyGroups?: {
        [key: string]: ComponentPropertyGroupRequest | undefined;
    };
}
export type ComponentsMapRequest = {
    [key: string]: ComponentRequest | undefined;
};
export interface CompositeComponentRequest {
    description?: string;
    properties?: {
        [key: string]: PropertyRequest | undefined;
    };
    propertyGroups?: {
        [key: string]: ComponentPropertyGroupRequest | undefined;
    };
}
export type CompositeComponentsMapRequest = {
    [key: string]: CompositeComponentRequest | undefined;
};
export type ParentEntityId = string;
export interface CreateEntityRequest {
    workspaceId: string;
    entityId?: string;
    entityName: string;
    description?: string;
    components?: {
        [key: string]: ComponentRequest | undefined;
    };
    compositeComponents?: {
        [key: string]: CompositeComponentRequest | undefined;
    };
    parentEntityId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateEntityResponse {
    entityId: string;
    arn: string;
    creationDateTime: Date;
    state: string;
}
export type SourceType = string;
export type S3SourceLocation = string;
export interface S3SourceConfiguration {
    location: string;
}
export type Uuid = string;
export type SiteWiseExternalId = string;
export interface FilterByAssetModel {
    assetModelId?: string;
    assetModelExternalId?: string;
    includeOffspring?: boolean;
    includeAssets?: boolean;
}
export interface FilterByAsset {
    assetId?: string;
    assetExternalId?: string;
    includeOffspring?: boolean;
    includeAssetModel?: boolean;
}
export type IotSiteWiseSourceConfigurationFilter = {
    filterByAssetModel: FilterByAssetModel;
    filterByAsset?: never;
} | {
    filterByAssetModel?: never;
    filterByAsset: FilterByAsset;
};
export type IotSiteWiseSourceConfigurationFilters = IotSiteWiseSourceConfigurationFilter[];
export interface IotSiteWiseSourceConfiguration {
    filters?: IotSiteWiseSourceConfigurationFilter[];
}
export interface FilterByComponentType {
    componentTypeId: string;
}
export interface FilterByEntity {
    entityId: string;
}
export type IotTwinMakerSourceConfigurationFilter = {
    filterByComponentType: FilterByComponentType;
    filterByEntity?: never;
} | {
    filterByComponentType?: never;
    filterByEntity: FilterByEntity;
};
export type IotTwinMakerSourceConfigurationFilters = IotTwinMakerSourceConfigurationFilter[];
export interface IotTwinMakerSourceConfiguration {
    workspace: string;
    filters?: IotTwinMakerSourceConfigurationFilter[];
}
export interface SourceConfiguration {
    type: string;
    s3Configuration?: S3SourceConfiguration;
    iotSiteWiseConfiguration?: IotSiteWiseSourceConfiguration;
    iotTwinMakerConfiguration?: IotTwinMakerSourceConfiguration;
}
export type SourceConfigurations = SourceConfiguration[];
export type DestinationType = string;
export type S3DestinationLocation = string;
export interface S3DestinationConfiguration {
    location: string;
}
export interface IotTwinMakerDestinationConfiguration {
    workspace: string;
}
export interface DestinationConfiguration {
    type: string;
    s3Configuration?: S3DestinationConfiguration;
    iotTwinMakerConfiguration?: IotTwinMakerDestinationConfiguration;
}
export interface CreateMetadataTransferJobRequest {
    metadataTransferJobId?: string;
    description?: string;
    sources: SourceConfiguration[];
    destination: DestinationConfiguration;
}
export interface CreateMetadataTransferJobResponse {
    metadataTransferJobId: string;
    arn: string;
    creationDateTime: Date;
    status: MetadataTransferJobStatus;
}
export type S3Url = string;
export type SceneCapability = string;
export type SceneCapabilities = string[];
export type SceneMetadataValue = string;
export type SceneMetadataMap = {
    [key: string]: string | undefined;
};
export interface CreateSceneRequest {
    workspaceId: string;
    sceneId: string;
    contentLocation: string;
    description?: string;
    capabilities?: string[];
    tags?: {
        [key: string]: string | undefined;
    };
    sceneMetadata?: {
        [key: string]: string | undefined;
    };
}
export interface CreateSceneResponse {
    arn: string;
    creationDateTime: Date;
}
export type SyncSource = string;
export type RoleArn = string;
export interface CreateSyncJobRequest {
    workspaceId: string;
    syncSource: string;
    syncRole: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type SyncJobState = string;
export interface CreateSyncJobResponse {
    arn: string;
    creationDateTime: Date;
    state: string;
}
export type S3Location = string;
export interface CreateWorkspaceRequest {
    workspaceId: string;
    description?: string;
    s3Location?: string;
    role?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateWorkspaceResponse {
    arn: string;
    creationDateTime: Date;
}
export interface DeleteComponentTypeRequest {
    workspaceId: string;
    componentTypeId: string;
}
export interface DeleteComponentTypeResponse {
    state: string;
}
export interface DeleteEntityRequest {
    workspaceId: string;
    entityId: string;
    isRecursive?: boolean;
}
export interface DeleteEntityResponse {
    state: string;
}
export interface DeleteSceneRequest {
    workspaceId: string;
    sceneId: string;
}
export interface DeleteSceneResponse {
}
export interface DeleteSyncJobRequest {
    workspaceId: string;
    syncSource: string;
}
export interface DeleteSyncJobResponse {
    state: string;
}
export interface DeleteWorkspaceRequest {
    workspaceId: string;
}
export type WorkspaceDeleteMessage = string;
export interface DeleteWorkspaceResponse {
    message?: string;
}
export type QueryStatement = string;
export type QueryServiceMaxResults = number;
export type NextToken = string;
export interface ExecuteQueryRequest {
    workspaceId: string;
    queryStatement: string;
    maxResults?: number;
    nextToken?: string;
}
export type ColumnName = string;
export type ColumnType = string;
export interface ColumnDescription {
    name?: string;
    type?: string;
}
export type ColumnDescriptions = ColumnDescription[];
export type QueryResultValue = unknown;
export type RowData = any[];
export interface Row {
    rowData?: any[];
}
export type Rows = Row[];
export interface ExecuteQueryResponse {
    columnDescriptions?: ColumnDescription[];
    rows?: Row[];
    nextToken?: string;
}
export interface GetComponentTypeRequest {
    workspaceId: string;
    componentTypeId: string;
}
export interface PropertyDefinitionResponse {
    dataType: DataType;
    isTimeSeries: boolean;
    isRequiredInEntity: boolean;
    isExternalId: boolean;
    isStoredExternally: boolean;
    isImported: boolean;
    isFinal: boolean;
    isInherited: boolean;
    defaultValue?: DataValue;
    configuration?: {
        [key: string]: string | undefined;
    };
    displayName?: string;
}
export type PropertyDefinitionsResponse = {
    [key: string]: PropertyDefinitionResponse | undefined;
};
export interface FunctionResponse {
    requiredProperties?: string[];
    scope?: string;
    implementedBy?: DataConnector;
    isInherited?: boolean;
}
export type FunctionsResponse = {
    [key: string]: FunctionResponse | undefined;
};
export interface Status {
    state?: string;
    error?: ErrorDetails;
}
export interface PropertyGroupResponse {
    groupType: string;
    propertyNames: string[];
    isInherited: boolean;
}
export type PropertyGroupsResponse = {
    [key: string]: PropertyGroupResponse | undefined;
};
export interface CompositeComponentTypeResponse {
    componentTypeId?: string;
    isInherited?: boolean;
}
export type CompositeComponentTypesResponse = {
    [key: string]: CompositeComponentTypeResponse | undefined;
};
export interface GetComponentTypeResponse {
    workspaceId: string;
    isSingleton?: boolean;
    componentTypeId: string;
    description?: string;
    propertyDefinitions?: {
        [key: string]: PropertyDefinitionResponse | undefined;
    };
    extendsFrom?: string[];
    functions?: {
        [key: string]: FunctionResponse | undefined;
    };
    creationDateTime: Date;
    updateDateTime: Date;
    arn: string;
    isAbstract?: boolean;
    isSchemaInitialized?: boolean;
    status?: Status;
    propertyGroups?: {
        [key: string]: PropertyGroupResponse | undefined;
    };
    syncSource?: string;
    componentTypeName?: string;
    compositeComponentTypes?: {
        [key: string]: CompositeComponentTypeResponse | undefined;
    };
}
export interface GetEntityRequest {
    workspaceId: string;
    entityId: string;
}
export interface PropertyResponse {
    definition?: PropertyDefinitionResponse;
    value?: DataValue;
    areAllPropertyValuesReturned?: boolean;
}
export type PropertyResponses = {
    [key: string]: PropertyResponse | undefined;
};
export interface ComponentPropertyGroupResponse {
    groupType: string;
    propertyNames: string[];
    isInherited: boolean;
}
export type ComponentPropertyGroupResponses = {
    [key: string]: ComponentPropertyGroupResponse | undefined;
};
export interface ComponentSummary {
    componentName: string;
    componentTypeId: string;
    definedIn?: string;
    description?: string;
    propertyGroups?: {
        [key: string]: ComponentPropertyGroupResponse | undefined;
    };
    status: Status;
    syncSource?: string;
    componentPath?: string;
}
export type CompositeComponentResponse = {
    [key: string]: ComponentSummary | undefined;
};
export interface ComponentResponse {
    componentName?: string;
    description?: string;
    componentTypeId?: string;
    status?: Status;
    definedIn?: string;
    properties?: {
        [key: string]: PropertyResponse | undefined;
    };
    propertyGroups?: {
        [key: string]: ComponentPropertyGroupResponse | undefined;
    };
    syncSource?: string;
    areAllPropertiesReturned?: boolean;
    compositeComponents?: {
        [key: string]: ComponentSummary | undefined;
    };
    areAllCompositeComponentsReturned?: boolean;
}
export type ComponentsMap = {
    [key: string]: ComponentResponse | undefined;
};
export interface GetEntityResponse {
    entityId: string;
    entityName: string;
    arn: string;
    status: Status;
    workspaceId: string;
    description?: string;
    components?: {
        [key: string]: ComponentResponse | undefined;
    };
    parentEntityId: string;
    hasChildEntities: boolean;
    creationDateTime: Date;
    updateDateTime: Date;
    syncSource?: string;
    areAllComponentsReturned?: boolean;
}
export interface GetMetadataTransferJobRequest {
    metadataTransferJobId: string;
}
export interface GetMetadataTransferJobResponse {
    metadataTransferJobId: string;
    arn: string;
    description?: string;
    sources: SourceConfiguration[];
    destination: DestinationConfiguration;
    metadataTransferJobRole: string;
    reportUrl?: string;
    creationDateTime: Date;
    updateDateTime: Date;
    status: MetadataTransferJobStatus;
    progress?: MetadataTransferJobProgress;
}
export interface GetPricingPlanRequest {
}
export type BundleName = string;
export type PricingBundles = string[];
export type PricingTier = string;
export interface BundleInformation {
    bundleNames: string[];
    pricingTier?: string;
}
export type PricingMode = string;
export type UpdateReason = string;
export interface PricingPlan {
    billableEntityCount?: number;
    bundleInformation?: BundleInformation;
    effectiveDateTime: Date;
    pricingMode: string;
    updateDateTime: Date;
    updateReason: string;
}
export interface GetPricingPlanResponse {
    currentPricingPlan: PricingPlan;
    pendingPricingPlan?: PricingPlan;
}
export type SelectedPropertyList = string[];
export type MaxResults = number;
export type Order = string;
export interface OrderBy {
    order?: string;
    propertyName: string;
}
export type OrderByList = OrderBy[];
export interface PropertyFilter {
    propertyName?: string;
    operator?: string;
    value?: DataValue;
}
export type PropertyFilters = PropertyFilter[];
export interface TabularConditions {
    orderBy?: OrderBy[];
    propertyFilters?: PropertyFilter[];
}
export interface GetPropertyValueRequest {
    componentName?: string;
    componentPath?: string;
    componentTypeId?: string;
    entityId?: string;
    selectedProperties: string[];
    workspaceId: string;
    maxResults?: number;
    nextToken?: string;
    propertyGroupName?: string;
    tabularConditions?: TabularConditions;
}
export interface PropertyLatestValue {
    propertyReference: EntityPropertyReference;
    propertyValue?: DataValue;
}
export type PropertyLatestValueMap = {
    [key: string]: PropertyLatestValue | undefined;
};
export type PropertyTableValue = {
    [key: string]: DataValue | undefined;
};
export type TabularPropertyValue = {
    [key: string]: DataValue | undefined;
}[];
export type TabularPropertyValues = {
    [key: string]: DataValue | undefined;
}[][];
export interface GetPropertyValueResponse {
    propertyValues?: {
        [key: string]: PropertyLatestValue | undefined;
    };
    nextToken?: string;
    tabularPropertyValues?: {
        [key: string]: DataValue | undefined;
    }[][];
}
export type InterpolationType = string;
export type IntervalInSeconds = number;
export interface InterpolationParameters {
    interpolationType?: string;
    intervalInSeconds?: number;
}
export type OrderByTime = string;
export interface GetPropertyValueHistoryRequest {
    workspaceId: string;
    entityId?: string;
    componentName?: string;
    componentPath?: string;
    componentTypeId?: string;
    selectedProperties: string[];
    propertyFilters?: PropertyFilter[];
    startDateTime?: Date;
    endDateTime?: Date;
    interpolation?: InterpolationParameters;
    nextToken?: string;
    maxResults?: number;
    orderByTime?: string;
    startTime?: string;
    endTime?: string;
}
export type Values = PropertyValue[];
export interface PropertyValueHistory {
    entityPropertyReference: EntityPropertyReference;
    values?: PropertyValue[];
}
export type PropertyValueList = PropertyValueHistory[];
export interface GetPropertyValueHistoryResponse {
    propertyValues: PropertyValueHistory[];
    nextToken?: string;
}
export interface GetSceneRequest {
    workspaceId: string;
    sceneId: string;
}
export type GeneratedSceneMetadataMap = {
    [key: string]: string | undefined;
};
export type SceneErrorCode = string;
export interface SceneError {
    code?: string;
    message?: string;
}
export interface GetSceneResponse {
    workspaceId: string;
    sceneId: string;
    contentLocation: string;
    arn: string;
    creationDateTime: Date;
    updateDateTime: Date;
    description?: string;
    capabilities?: string[];
    sceneMetadata?: {
        [key: string]: string | undefined;
    };
    generatedSceneMetadata?: {
        [key: string]: string | undefined;
    };
    error?: SceneError;
}
export interface GetSyncJobRequest {
    syncSource: string;
    workspaceId?: string;
}
export interface SyncJobStatus {
    state?: string;
    error?: ErrorDetails;
}
export interface GetSyncJobResponse {
    arn: string;
    workspaceId: string;
    syncSource: string;
    syncRole: string;
    status: SyncJobStatus;
    creationDateTime: Date;
    updateDateTime: Date;
}
export type IdOrArn = string;
export interface GetWorkspaceRequest {
    workspaceId: string;
}
export type LinkedService = string;
export type LinkedServices = string[];
export interface GetWorkspaceResponse {
    workspaceId: string;
    arn: string;
    description?: string;
    linkedServices?: string[];
    s3Location?: string;
    role?: string;
    creationDateTime: Date;
    updateDateTime: Date;
}
export interface ListComponentsRequest {
    workspaceId: string;
    entityId: string;
    componentPath?: string;
    maxResults?: number;
    nextToken?: string;
}
export type ComponentSummaries = ComponentSummary[];
export interface ListComponentsResponse {
    componentSummaries: ComponentSummary[];
    nextToken?: string;
}
export type ListComponentTypesFilter = {
    extendsFrom: string;
    namespace?: never;
    isAbstract?: never;
} | {
    extendsFrom?: never;
    namespace: string;
    isAbstract?: never;
} | {
    extendsFrom?: never;
    namespace?: never;
    isAbstract: boolean;
};
export type ListComponentTypesFilters = ListComponentTypesFilter[];
export interface ListComponentTypesRequest {
    workspaceId: string;
    filters?: ListComponentTypesFilter[];
    nextToken?: string;
    maxResults?: number;
}
export interface ComponentTypeSummary {
    arn: string;
    componentTypeId: string;
    creationDateTime: Date;
    updateDateTime: Date;
    description?: string;
    status?: Status;
    componentTypeName?: string;
}
export type ComponentTypeSummaries = ComponentTypeSummary[];
export interface ListComponentTypesResponse {
    workspaceId: string;
    componentTypeSummaries: ComponentTypeSummary[];
    nextToken?: string;
    maxResults?: number;
}
export type ListEntitiesFilter = {
    parentEntityId: string;
    componentTypeId?: never;
    externalId?: never;
} | {
    parentEntityId?: never;
    componentTypeId: string;
    externalId?: never;
} | {
    parentEntityId?: never;
    componentTypeId?: never;
    externalId: string;
};
export type ListEntitiesFilters = ListEntitiesFilter[];
export interface ListEntitiesRequest {
    workspaceId: string;
    filters?: ListEntitiesFilter[];
    maxResults?: number;
    nextToken?: string;
}
export interface EntitySummary {
    entityId: string;
    entityName: string;
    arn: string;
    parentEntityId?: string;
    status: Status;
    description?: string;
    hasChildEntities?: boolean;
    creationDateTime: Date;
    updateDateTime: Date;
}
export type EntitySummaries = EntitySummary[];
export interface ListEntitiesResponse {
    entitySummaries?: EntitySummary[];
    nextToken?: string;
}
export type ListMetadataTransferJobsFilter = {
    workspaceId: string;
    state?: never;
} | {
    workspaceId?: never;
    state: string;
};
export type ListMetadataTransferJobsFilters = ListMetadataTransferJobsFilter[];
export interface ListMetadataTransferJobsRequest {
    sourceType: string;
    destinationType: string;
    filters?: ListMetadataTransferJobsFilter[];
    nextToken?: string;
    maxResults?: number;
}
export interface MetadataTransferJobSummary {
    metadataTransferJobId: string;
    arn: string;
    creationDateTime: Date;
    updateDateTime: Date;
    status: MetadataTransferJobStatus;
    progress?: MetadataTransferJobProgress;
}
export type MetadataTransferJobSummaries = MetadataTransferJobSummary[];
export interface ListMetadataTransferJobsResponse {
    metadataTransferJobSummaries: MetadataTransferJobSummary[];
    nextToken?: string;
}
export interface ListPropertiesRequest {
    workspaceId: string;
    componentName?: string;
    componentPath?: string;
    entityId: string;
    maxResults?: number;
    nextToken?: string;
}
export interface PropertySummary {
    definition?: PropertyDefinitionResponse;
    propertyName: string;
    value?: DataValue;
    areAllPropertyValuesReturned?: boolean;
}
export type PropertySummaries = PropertySummary[];
export interface ListPropertiesResponse {
    propertySummaries: PropertySummary[];
    nextToken?: string;
}
export interface ListScenesRequest {
    workspaceId: string;
    maxResults?: number;
    nextToken?: string;
}
export interface SceneSummary {
    sceneId: string;
    contentLocation: string;
    arn: string;
    creationDateTime: Date;
    updateDateTime: Date;
    description?: string;
}
export type SceneSummaries = SceneSummary[];
export interface ListScenesResponse {
    sceneSummaries?: SceneSummary[];
    nextToken?: string;
}
export interface ListSyncJobsRequest {
    workspaceId: string;
    maxResults?: number;
    nextToken?: string;
}
export interface SyncJobSummary {
    arn?: string;
    workspaceId?: string;
    syncSource?: string;
    status?: SyncJobStatus;
    creationDateTime?: Date;
    updateDateTime?: Date;
}
export type SyncJobSummaries = SyncJobSummary[];
export interface ListSyncJobsResponse {
    syncJobSummaries?: SyncJobSummary[];
    nextToken?: string;
}
export type SyncResourceState = string;
export type SyncResourceType = string;
export type SyncResourceFilter = {
    state: string;
    resourceType?: never;
    resourceId?: never;
    externalId?: never;
} | {
    state?: never;
    resourceType: string;
    resourceId?: never;
    externalId?: never;
} | {
    state?: never;
    resourceType?: never;
    resourceId: string;
    externalId?: never;
} | {
    state?: never;
    resourceType?: never;
    resourceId?: never;
    externalId: string;
};
export type SyncResourceFilters = SyncResourceFilter[];
export interface ListSyncResourcesRequest {
    workspaceId: string;
    syncSource: string;
    filters?: SyncResourceFilter[];
    maxResults?: number;
    nextToken?: string;
}
export interface SyncResourceStatus {
    state?: string;
    error?: ErrorDetails;
}
export interface SyncResourceSummary {
    resourceType?: string;
    externalId?: string;
    resourceId?: string;
    status?: SyncResourceStatus;
    updateDateTime?: Date;
}
export type SyncResourceSummaries = SyncResourceSummary[];
export interface ListSyncResourcesResponse {
    syncResources?: SyncResourceSummary[];
    nextToken?: string;
}
export interface ListTagsForResourceRequest {
    resourceARN: string;
    maxResults?: number;
    nextToken?: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
    nextToken?: string;
}
export interface ListWorkspacesRequest {
    maxResults?: number;
    nextToken?: string;
}
export interface WorkspaceSummary {
    workspaceId: string;
    arn: string;
    description?: string;
    linkedServices?: string[];
    creationDateTime: Date;
    updateDateTime: Date;
}
export type WorkspaceSummaries = WorkspaceSummary[];
export interface ListWorkspacesResponse {
    workspaceSummaries?: WorkspaceSummary[];
    nextToken?: string;
}
export interface TagResourceRequest {
    resourceARN: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceARN: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateComponentTypeRequest {
    workspaceId: string;
    isSingleton?: boolean;
    componentTypeId: string;
    description?: string;
    propertyDefinitions?: {
        [key: string]: PropertyDefinitionRequest | undefined;
    };
    extendsFrom?: string[];
    functions?: {
        [key: string]: FunctionRequest | undefined;
    };
    propertyGroups?: {
        [key: string]: PropertyGroupRequest | undefined;
    };
    componentTypeName?: string;
    compositeComponentTypes?: {
        [key: string]: CompositeComponentTypeRequest | undefined;
    };
}
export interface UpdateComponentTypeResponse {
    workspaceId: string;
    arn: string;
    componentTypeId: string;
    state: string;
}
export type ComponentUpdateType = string;
export interface ComponentUpdateRequest {
    updateType?: string;
    description?: string;
    componentTypeId?: string;
    propertyUpdates?: {
        [key: string]: PropertyRequest | undefined;
    };
    propertyGroupUpdates?: {
        [key: string]: ComponentPropertyGroupRequest | undefined;
    };
}
export type ComponentUpdatesMapRequest = {
    [key: string]: ComponentUpdateRequest | undefined;
};
export interface CompositeComponentUpdateRequest {
    updateType?: string;
    description?: string;
    propertyUpdates?: {
        [key: string]: PropertyRequest | undefined;
    };
    propertyGroupUpdates?: {
        [key: string]: ComponentPropertyGroupRequest | undefined;
    };
}
export type CompositeComponentUpdatesMapRequest = {
    [key: string]: CompositeComponentUpdateRequest | undefined;
};
export type ParentEntityUpdateType = string;
export interface ParentEntityUpdateRequest {
    updateType: string;
    parentEntityId?: string;
}
export interface UpdateEntityRequest {
    workspaceId: string;
    entityId: string;
    entityName?: string;
    description?: string;
    componentUpdates?: {
        [key: string]: ComponentUpdateRequest | undefined;
    };
    compositeComponentUpdates?: {
        [key: string]: CompositeComponentUpdateRequest | undefined;
    };
    parentEntityUpdate?: ParentEntityUpdateRequest;
}
export interface UpdateEntityResponse {
    updateDateTime: Date;
    state: string;
}
export interface UpdatePricingPlanRequest {
    pricingMode: string;
    bundleNames?: string[];
}
export interface UpdatePricingPlanResponse {
    currentPricingPlan: PricingPlan;
    pendingPricingPlan?: PricingPlan;
}
export interface UpdateSceneRequest {
    workspaceId: string;
    sceneId: string;
    contentLocation?: string;
    description?: string;
    capabilities?: string[];
    sceneMetadata?: {
        [key: string]: string | undefined;
    };
}
export interface UpdateSceneResponse {
    updateDateTime: Date;
}
export interface UpdateWorkspaceRequest {
    workspaceId: string;
    description?: string;
    role?: string;
    s3Location?: string;
}
export interface UpdateWorkspaceResponse {
    updateDateTime: Date;
}
export type ExceptionMessage = string;
export type BatchPutPropertyValuesError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sets values for multiple time series properties.
 */
export declare const batchPutPropertyValues: API.OperationMethod<BatchPutPropertyValuesRequest, BatchPutPropertyValuesResponse, BatchPutPropertyValuesError, Credentials | HttpClient.HttpClient>;
export type CancelMetadataTransferJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels the metadata transfer job.
 */
export declare const cancelMetadataTransferJob: API.OperationMethod<CancelMetadataTransferJobRequest, CancelMetadataTransferJobResponse, CancelMetadataTransferJobError, Credentials | HttpClient.HttpClient>;
export type CreateComponentTypeError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a component type.
 */
export declare const createComponentType: API.OperationMethod<CreateComponentTypeRequest, CreateComponentTypeResponse, CreateComponentTypeError, Credentials | HttpClient.HttpClient>;
export type CreateEntityError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an entity.
 */
export declare const createEntity: API.OperationMethod<CreateEntityRequest, CreateEntityResponse, CreateEntityError, Credentials | HttpClient.HttpClient>;
export type CreateMetadataTransferJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new metadata transfer job.
 */
export declare const createMetadataTransferJob: API.OperationMethod<CreateMetadataTransferJobRequest, CreateMetadataTransferJobResponse, CreateMetadataTransferJobError, Credentials | HttpClient.HttpClient>;
export type CreateSceneError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a scene.
 */
export declare const createScene: API.OperationMethod<CreateSceneRequest, CreateSceneResponse, CreateSceneError, Credentials | HttpClient.HttpClient>;
export type CreateSyncJobError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This action creates a SyncJob.
 */
export declare const createSyncJob: API.OperationMethod<CreateSyncJobRequest, CreateSyncJobResponse, CreateSyncJobError, Credentials | HttpClient.HttpClient>;
export type CreateWorkspaceError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a workplace.
 */
export declare const createWorkspace: API.OperationMethod<CreateWorkspaceRequest, CreateWorkspaceResponse, CreateWorkspaceError, Credentials | HttpClient.HttpClient>;
export type DeleteComponentTypeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a component type.
 */
export declare const deleteComponentType: API.OperationMethod<DeleteComponentTypeRequest, DeleteComponentTypeResponse, DeleteComponentTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteEntityError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an entity.
 */
export declare const deleteEntity: API.OperationMethod<DeleteEntityRequest, DeleteEntityResponse, DeleteEntityError, Credentials | HttpClient.HttpClient>;
export type DeleteSceneError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a scene.
 */
export declare const deleteScene: API.OperationMethod<DeleteSceneRequest, DeleteSceneResponse, DeleteSceneError, Credentials | HttpClient.HttpClient>;
export type DeleteSyncJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete the SyncJob.
 */
export declare const deleteSyncJob: API.OperationMethod<DeleteSyncJobRequest, DeleteSyncJobResponse, DeleteSyncJobError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkspaceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a workspace.
 */
export declare const deleteWorkspace: API.OperationMethod<DeleteWorkspaceRequest, DeleteWorkspaceResponse, DeleteWorkspaceError, Credentials | HttpClient.HttpClient>;
export type ExecuteQueryError = AccessDeniedException | InternalServerException | QueryTimeoutException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Run queries to access information from your knowledge graph of entities within
 * individual workspaces.
 *
 * The ExecuteQuery action only works with Amazon Web Services Java SDK2.
 * ExecuteQuery will not work with any Amazon Web Services Java SDK version < 2.x.
 */
export declare const executeQuery: API.PaginatedOperationMethod<ExecuteQueryRequest, ExecuteQueryResponse, ExecuteQueryError, Credentials | HttpClient.HttpClient, unknown>;
export type GetComponentTypeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a component type.
 */
export declare const getComponentType: API.OperationMethod<GetComponentTypeRequest, GetComponentTypeResponse, GetComponentTypeError, Credentials | HttpClient.HttpClient>;
export type GetEntityError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an entity.
 */
export declare const getEntity: API.OperationMethod<GetEntityRequest, GetEntityResponse, GetEntityError, Credentials | HttpClient.HttpClient>;
export type GetMetadataTransferJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a nmetadata transfer job.
 */
export declare const getMetadataTransferJob: API.OperationMethod<GetMetadataTransferJobRequest, GetMetadataTransferJobResponse, GetMetadataTransferJobError, Credentials | HttpClient.HttpClient>;
export type GetPricingPlanError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the pricing plan.
 */
export declare const getPricingPlan: API.OperationMethod<GetPricingPlanRequest, GetPricingPlanResponse, GetPricingPlanError, Credentials | HttpClient.HttpClient>;
export type GetPropertyValueError = AccessDeniedException | ConnectorFailureException | ConnectorTimeoutException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the property values for a component, component type, entity, or workspace.
 *
 * You must specify a value for either `componentName`,
 * `componentTypeId`, `entityId`, or `workspaceId`.
 */
export declare const getPropertyValue: API.PaginatedOperationMethod<GetPropertyValueRequest, GetPropertyValueResponse, GetPropertyValueError, Credentials | HttpClient.HttpClient, unknown>;
export type GetPropertyValueHistoryError = AccessDeniedException | ConnectorFailureException | ConnectorTimeoutException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the history of a time series property value for a component,
 * component type, entity, or workspace.
 *
 * You must specify a value for `workspaceId`. For entity-specific queries,
 * specify values for `componentName` and `entityId`. For cross-entity
 * quries, specify a value for `componentTypeId`.
 */
export declare const getPropertyValueHistory: API.PaginatedOperationMethod<GetPropertyValueHistoryRequest, GetPropertyValueHistoryResponse, GetPropertyValueHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type GetSceneError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a scene.
 */
export declare const getScene: API.OperationMethod<GetSceneRequest, GetSceneResponse, GetSceneError, Credentials | HttpClient.HttpClient>;
export type GetSyncJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the SyncJob.
 */
export declare const getSyncJob: API.OperationMethod<GetSyncJobRequest, GetSyncJobResponse, GetSyncJobError, Credentials | HttpClient.HttpClient>;
export type GetWorkspaceError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a workspace.
 */
export declare const getWorkspace: API.OperationMethod<GetWorkspaceRequest, GetWorkspaceResponse, GetWorkspaceError, Credentials | HttpClient.HttpClient>;
export type ListComponentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This API lists the components of an entity.
 */
export declare const listComponents: API.PaginatedOperationMethod<ListComponentsRequest, ListComponentsResponse, ListComponentsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListComponentTypesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all component types in a workspace.
 */
export declare const listComponentTypes: API.PaginatedOperationMethod<ListComponentTypesRequest, ListComponentTypesResponse, ListComponentTypesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEntitiesError = InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all entities in a workspace.
 */
export declare const listEntities: API.PaginatedOperationMethod<ListEntitiesRequest, ListEntitiesResponse, ListEntitiesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMetadataTransferJobsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the metadata transfer jobs.
 */
export declare const listMetadataTransferJobs: API.PaginatedOperationMethod<ListMetadataTransferJobsRequest, ListMetadataTransferJobsResponse, ListMetadataTransferJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPropertiesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This API lists the properties of a component.
 */
export declare const listProperties: API.PaginatedOperationMethod<ListPropertiesRequest, ListPropertiesResponse, ListPropertiesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListScenesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all scenes in a workspace.
 */
export declare const listScenes: API.PaginatedOperationMethod<ListScenesRequest, ListScenesResponse, ListScenesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSyncJobsError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all SyncJobs.
 */
export declare const listSyncJobs: API.PaginatedOperationMethod<ListSyncJobsRequest, ListSyncJobsResponse, ListSyncJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSyncResourcesError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the sync resources.
 */
export declare const listSyncResources: API.PaginatedOperationMethod<ListSyncResourcesRequest, ListSyncResourcesResponse, ListSyncResourcesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Lists all tags associated with a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWorkspacesError = InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about workspaces in the current account.
 */
export declare const listWorkspaces: API.PaginatedOperationMethod<ListWorkspacesRequest, ListWorkspacesResponse, ListWorkspacesError, Credentials | HttpClient.HttpClient, unknown>;
export type TagResourceError = AccessDeniedException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Adds tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateComponentTypeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates information in a component type.
 */
export declare const updateComponentType: API.OperationMethod<UpdateComponentTypeRequest, UpdateComponentTypeResponse, UpdateComponentTypeError, Credentials | HttpClient.HttpClient>;
export type UpdateEntityError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an entity.
 */
export declare const updateEntity: API.OperationMethod<UpdateEntityRequest, UpdateEntityResponse, UpdateEntityError, Credentials | HttpClient.HttpClient>;
export type UpdatePricingPlanError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the pricing plan.
 */
export declare const updatePricingPlan: API.OperationMethod<UpdatePricingPlanRequest, UpdatePricingPlanResponse, UpdatePricingPlanError, Credentials | HttpClient.HttpClient>;
export type UpdateSceneError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a scene.
 */
export declare const updateScene: API.OperationMethod<UpdateSceneRequest, UpdateSceneResponse, UpdateSceneError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkspaceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a workspace.
 */
export declare const updateWorkspace: API.OperationMethod<UpdateWorkspaceRequest, UpdateWorkspaceResponse, UpdateWorkspaceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iottwinmaker.d.ts.map