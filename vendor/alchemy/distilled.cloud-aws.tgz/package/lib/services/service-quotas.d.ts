import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AWSServiceAccessNotEnabledException_base: S.TaggedErrorClass<"AWSServiceAccessNotEnabledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AWSServiceAccessNotEnabledException extends /*@__PURE__*/ AWSServiceAccessNotEnabledException_base {
}
declare const DependencyAccessDeniedException_base: S.TaggedErrorClass<"DependencyAccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class DependencyAccessDeniedException extends /*@__PURE__*/ DependencyAccessDeniedException_base {
}
declare const IllegalArgumentException_base: S.TaggedErrorClass<"IllegalArgumentException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IllegalArgumentException extends /*@__PURE__*/ IllegalArgumentException_base {
}
declare const InvalidPaginationTokenException_base: S.TaggedErrorClass<"InvalidPaginationTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidPaginationTokenException extends /*@__PURE__*/ InvalidPaginationTokenException_base {
}
declare const InvalidResourceStateException_base: S.TaggedErrorClass<"InvalidResourceStateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidResourceStateException extends /*@__PURE__*/ InvalidResourceStateException_base {
}
declare const NoAvailableOrganizationException_base: S.TaggedErrorClass<"NoAvailableOrganizationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class NoAvailableOrganizationException extends /*@__PURE__*/ NoAvailableOrganizationException_base {
}
declare const NoSuchResourceException_base: S.TaggedErrorClass<"NoSuchResourceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchResourceException extends /*@__PURE__*/ NoSuchResourceException_base {
}
declare const OrganizationNotInAllFeaturesModeException_base: S.TaggedErrorClass<"OrganizationNotInAllFeaturesModeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OrganizationNotInAllFeaturesModeException extends /*@__PURE__*/ OrganizationNotInAllFeaturesModeException_base {
}
declare const QuotaExceededException_base: S.TaggedErrorClass<"QuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class QuotaExceededException extends /*@__PURE__*/ QuotaExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ServiceException_base: S.TaggedErrorClass<"ServiceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceException extends /*@__PURE__*/ ServiceException_base {
}
declare const ServiceQuotaTemplateNotInUseException_base: S.TaggedErrorClass<"ServiceQuotaTemplateNotInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceQuotaTemplateNotInUseException extends /*@__PURE__*/ ServiceQuotaTemplateNotInUseException_base {
}
declare const TagPolicyViolationException_base: S.TaggedErrorClass<"TagPolicyViolationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class TagPolicyViolationException extends /*@__PURE__*/ TagPolicyViolationException_base {
}
declare const TemplatesNotAvailableInRegionException_base: S.TaggedErrorClass<"TemplatesNotAvailableInRegionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TemplatesNotAvailableInRegionException extends /*@__PURE__*/ TemplatesNotAvailableInRegionException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
export interface AssociateServiceQuotaTemplateRequest {
}
export interface AssociateServiceQuotaTemplateResponse {
}
export type RequestId = string;
export interface CreateSupportCaseRequest {
    RequestId: string;
}
export interface CreateSupportCaseResponse {
}
export type ServiceCode = string;
export type QuotaCode = string;
export type AwsRegion = string;
export interface DeleteServiceQuotaIncreaseRequestFromTemplateRequest {
    ServiceCode: string;
    QuotaCode: string;
    AwsRegion: string;
}
export interface DeleteServiceQuotaIncreaseRequestFromTemplateResponse {
}
export interface DisassociateServiceQuotaTemplateRequest {
}
export interface DisassociateServiceQuotaTemplateResponse {
}
export interface GetAssociationForServiceQuotaTemplateRequest {
}
export type ServiceQuotaTemplateAssociationStatus = "ASSOCIATED" | "DISASSOCIATED" | (string & {});
export interface GetAssociationForServiceQuotaTemplateResponse {
    ServiceQuotaTemplateAssociationStatus?: ServiceQuotaTemplateAssociationStatus;
}
export interface GetAutoManagementConfigurationRequest {
}
export type OptInLevel = "ACCOUNT" | (string & {});
export type OptInType = "NotifyOnly" | "NotifyAndAdjust" | (string & {});
export type AmazonResourceName = string;
export type OptInStatus = "ENABLED" | "DISABLED" | (string & {});
export type ExcludedService = string;
export type QuotaName = string;
export interface QuotaInfo {
    QuotaCode?: string;
    QuotaName?: string;
}
export type QuotaInfoList = QuotaInfo[];
export type ExclusionQuotaList = {
    [key: string]: QuotaInfo[] | undefined;
};
export interface GetAutoManagementConfigurationResponse {
    OptInLevel?: OptInLevel;
    OptInType?: OptInType;
    NotificationArn?: string;
    OptInStatus?: OptInStatus;
    ExclusionList?: {
        [key: string]: QuotaInfo[] | undefined;
    };
}
export interface GetAWSDefaultServiceQuotaRequest {
    ServiceCode: string;
    QuotaCode: string;
}
export type ServiceName = string;
export type QuotaArn = string;
export type QuotaValue = number;
export type QuotaUnit = string;
export type QuotaAdjustable = boolean;
export type GlobalQuota = boolean;
export type QuotaMetricNamespace = string;
export type QuotaMetricName = string;
export type MetricDimensionName = string;
export type MetricDimensionValue = string;
export type MetricDimensionsMapDefinition = {
    [key: string]: string | undefined;
};
export type Statistic = string;
export interface MetricInfo {
    MetricNamespace?: string;
    MetricName?: string;
    MetricDimensions?: {
        [key: string]: string | undefined;
    };
    MetricStatisticRecommendation?: string;
}
export type PeriodValue = number;
export type PeriodUnit = "MICROSECOND" | "MILLISECOND" | "SECOND" | "MINUTE" | "HOUR" | "DAY" | "WEEK" | (string & {});
export interface QuotaPeriod {
    PeriodValue?: number;
    PeriodUnit?: PeriodUnit;
}
export type ErrorCode = "DEPENDENCY_ACCESS_DENIED_ERROR" | "DEPENDENCY_THROTTLING_ERROR" | "DEPENDENCY_SERVICE_ERROR" | "SERVICE_QUOTA_NOT_AVAILABLE_ERROR" | (string & {});
export type ErrorMessage = string;
export interface ErrorReason {
    ErrorCode?: ErrorCode;
    ErrorMessage?: string;
}
export type AppliedLevelEnum = "ACCOUNT" | "RESOURCE" | "ALL" | (string & {});
export type QuotaContextScope = "RESOURCE" | "ACCOUNT" | (string & {});
export type QuotaContextScopeType = string;
export type QuotaContextId = string;
export type AdjustableAtLevelEnum = "ACCOUNT" | "PER_RESOURCE" | "ALL" | (string & {});
export interface QuotaContextInfo {
    ContextScope?: QuotaContextScope;
    ContextScopeType?: string;
    ContextId?: string;
    AdjustableAtLevel?: AdjustableAtLevelEnum;
}
export type QuotaDescription = string;
export interface ServiceQuota {
    ServiceCode?: string;
    ServiceName?: string;
    QuotaArn?: string;
    QuotaCode?: string;
    QuotaName?: string;
    Value?: number;
    Unit?: string;
    Adjustable?: boolean;
    GlobalQuota?: boolean;
    UsageMetric?: MetricInfo;
    Period?: QuotaPeriod;
    ErrorReason?: ErrorReason;
    QuotaAppliedAtLevel?: AppliedLevelEnum;
    QuotaContext?: QuotaContextInfo;
    Description?: string;
}
export interface GetAWSDefaultServiceQuotaResponse {
    Quota?: ServiceQuota;
}
export type ReportId = string;
export type NextToken = string;
export type MaxResultsUtilization = number;
export interface GetQuotaUtilizationReportRequest {
    ReportId: string;
    NextToken?: string;
    MaxResults?: number;
}
export type ReportStatus = "PENDING" | "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export type TotalCount = number;
export type UtilizationPct = number;
export type DefaultValue = number;
export type AppliedValue = number;
export interface QuotaUtilizationInfo {
    QuotaCode?: string;
    ServiceCode?: string;
    QuotaName?: string;
    Namespace?: string;
    Utilization?: number;
    DefaultValue?: number;
    AppliedValue?: number;
    ServiceName?: string;
    Adjustable?: boolean;
}
export type QuotaUtilizationInfoList = QuotaUtilizationInfo[];
export type ReportErrorCode = string;
export type ReportErrorMessage = string;
export interface GetQuotaUtilizationReportResponse {
    ReportId?: string;
    Status?: ReportStatus;
    GeneratedAt?: Date;
    TotalCount?: number;
    Quotas?: QuotaUtilizationInfo[];
    NextToken?: string;
    ErrorCode?: string;
    ErrorMessage?: string;
}
export interface GetRequestedServiceQuotaChangeRequest {
    RequestId: string;
}
export type RequestType = "AutomaticManagement" | (string & {});
export type CustomerServiceEngagementId = string;
export type RequestStatus = "PENDING" | "CASE_OPENED" | "APPROVED" | "DENIED" | "CASE_CLOSED" | "NOT_APPROVED" | "INVALID_REQUEST" | (string & {});
export type Requester = string;
export interface RequestedServiceQuotaChange {
    Id?: string;
    RequestType?: RequestType;
    CaseId?: string;
    ServiceCode?: string;
    ServiceName?: string;
    QuotaCode?: string;
    QuotaName?: string;
    DesiredValue?: number;
    Status?: RequestStatus;
    Created?: Date;
    LastUpdated?: Date;
    Requester?: string;
    QuotaArn?: string;
    GlobalQuota?: boolean;
    Unit?: string;
    QuotaRequestedAtLevel?: AppliedLevelEnum;
    QuotaContext?: QuotaContextInfo;
}
export interface GetRequestedServiceQuotaChangeResponse {
    RequestedQuota?: RequestedServiceQuotaChange;
}
export interface GetServiceQuotaRequest {
    ServiceCode: string;
    QuotaCode: string;
    ContextId?: string;
}
export interface GetServiceQuotaResponse {
    Quota?: ServiceQuota;
}
export interface GetServiceQuotaIncreaseRequestFromTemplateRequest {
    ServiceCode: string;
    QuotaCode: string;
    AwsRegion: string;
}
export interface ServiceQuotaIncreaseRequestInTemplate {
    ServiceCode?: string;
    ServiceName?: string;
    QuotaCode?: string;
    QuotaName?: string;
    DesiredValue?: number;
    AwsRegion?: string;
    Unit?: string;
    GlobalQuota?: boolean;
}
export interface GetServiceQuotaIncreaseRequestFromTemplateResponse {
    ServiceQuotaIncreaseRequestInTemplate?: ServiceQuotaIncreaseRequestInTemplate;
}
export type MaxResults = number;
export interface ListAWSDefaultServiceQuotasRequest {
    ServiceCode: string;
    NextToken?: string;
    MaxResults?: number;
}
export type ServiceQuotaListDefinition = ServiceQuota[];
export interface ListAWSDefaultServiceQuotasResponse {
    NextToken?: string;
    Quotas?: ServiceQuota[];
}
export interface ListRequestedServiceQuotaChangeHistoryRequest {
    ServiceCode?: string;
    Status?: RequestStatus;
    NextToken?: string;
    MaxResults?: number;
    QuotaRequestedAtLevel?: AppliedLevelEnum;
}
export type RequestedServiceQuotaChangeHistoryListDefinition = RequestedServiceQuotaChange[];
export interface ListRequestedServiceQuotaChangeHistoryResponse {
    NextToken?: string;
    RequestedQuotas?: RequestedServiceQuotaChange[];
}
export interface ListRequestedServiceQuotaChangeHistoryByQuotaRequest {
    ServiceCode: string;
    QuotaCode: string;
    Status?: RequestStatus;
    NextToken?: string;
    MaxResults?: number;
    QuotaRequestedAtLevel?: AppliedLevelEnum;
}
export interface ListRequestedServiceQuotaChangeHistoryByQuotaResponse {
    NextToken?: string;
    RequestedQuotas?: RequestedServiceQuotaChange[];
}
export interface ListServiceQuotaIncreaseRequestsInTemplateRequest {
    ServiceCode?: string;
    AwsRegion?: string;
    NextToken?: string;
    MaxResults?: number;
}
export type ServiceQuotaIncreaseRequestInTemplateList = ServiceQuotaIncreaseRequestInTemplate[];
export interface ListServiceQuotaIncreaseRequestsInTemplateResponse {
    ServiceQuotaIncreaseRequestInTemplateList?: ServiceQuotaIncreaseRequestInTemplate[];
    NextToken?: string;
}
export interface ListServiceQuotasRequest {
    ServiceCode: string;
    NextToken?: string;
    MaxResults?: number;
    QuotaCode?: string;
    QuotaAppliedAtLevel?: AppliedLevelEnum;
}
export interface ListServiceQuotasResponse {
    NextToken?: string;
    Quotas?: ServiceQuota[];
}
export interface ListServicesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface ServiceInfo {
    ServiceCode?: string;
    ServiceName?: string;
}
export type ServiceInfoListDefinition = ServiceInfo[];
export interface ListServicesResponse {
    NextToken?: string;
    Services?: ServiceInfo[];
}
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type OutputTags = Tag[];
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export interface PutServiceQuotaIncreaseRequestIntoTemplateRequest {
    QuotaCode: string;
    ServiceCode: string;
    AwsRegion: string;
    DesiredValue: number;
}
export interface PutServiceQuotaIncreaseRequestIntoTemplateResponse {
    ServiceQuotaIncreaseRequestInTemplate?: ServiceQuotaIncreaseRequestInTemplate;
}
export type SupportCaseAllowed = boolean;
export interface RequestServiceQuotaIncreaseRequest {
    ServiceCode: string;
    QuotaCode: string;
    DesiredValue: number;
    ContextId?: string;
    SupportCaseAllowed?: boolean;
}
export interface RequestServiceQuotaIncreaseResponse {
    RequestedQuota?: RequestedServiceQuotaChange;
}
export type ExcludedLimit = string;
export type ExcludedQuotaList = string[];
export type ExclusionList = {
    [key: string]: string[] | undefined;
};
export interface StartAutoManagementRequest {
    OptInLevel: OptInLevel;
    OptInType: OptInType;
    NotificationArn?: string;
    ExclusionList?: {
        [key: string]: string[] | undefined;
    };
}
export interface StartAutoManagementResponse {
}
export interface StartQuotaUtilizationReportRequest {
}
export type ReportMessage = string;
export interface StartQuotaUtilizationReportResponse {
    ReportId?: string;
    Status?: ReportStatus;
    Message?: string;
}
export interface StopAutoManagementRequest {
}
export interface StopAutoManagementResponse {
}
export type InputTags = Tag[];
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type InputTagKeys = string[];
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAutoManagementRequest {
    OptInType?: OptInType;
    NotificationArn?: string;
    ExclusionList?: {
        [key: string]: string[] | undefined;
    };
}
export interface UpdateAutoManagementResponse {
}
export type ExceptionMessage = string;
export type AssociateServiceQuotaTemplateError = AccessDeniedException | AWSServiceAccessNotEnabledException | DependencyAccessDeniedException | NoAvailableOrganizationException | OrganizationNotInAllFeaturesModeException | ServiceException | TemplatesNotAvailableInRegionException | TooManyRequestsException | CommonErrors;
/**
 * Associates your quota request template with your organization. When a new
 * Amazon Web Services account is created in your organization, the quota increase requests in the
 * template are automatically applied to the account. You can add a quota increase request
 * for any adjustable quota to your template.
 */
export declare const associateServiceQuotaTemplate: API.OperationMethod<AssociateServiceQuotaTemplateRequest, AssociateServiceQuotaTemplateResponse, AssociateServiceQuotaTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateSupportCaseError = AccessDeniedException | DependencyAccessDeniedException | IllegalArgumentException | InvalidResourceStateException | NoSuchResourceException | ResourceAlreadyExistsException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Creates a Support case for an existing quota increase request. This call only creates
 * a Support case if the request has a `Pending` status.
 */
export declare const createSupportCase: API.OperationMethod<CreateSupportCaseRequest, CreateSupportCaseResponse, CreateSupportCaseError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceQuotaIncreaseRequestFromTemplateError = AccessDeniedException | AWSServiceAccessNotEnabledException | DependencyAccessDeniedException | IllegalArgumentException | NoAvailableOrganizationException | NoSuchResourceException | ServiceException | TemplatesNotAvailableInRegionException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the quota increase request for the specified quota from your quota request
 * template.
 */
export declare const deleteServiceQuotaIncreaseRequestFromTemplate: API.OperationMethod<DeleteServiceQuotaIncreaseRequestFromTemplateRequest, DeleteServiceQuotaIncreaseRequestFromTemplateResponse, DeleteServiceQuotaIncreaseRequestFromTemplateError, Credentials | HttpClient.HttpClient>;
export type DisassociateServiceQuotaTemplateError = AccessDeniedException | AWSServiceAccessNotEnabledException | DependencyAccessDeniedException | NoAvailableOrganizationException | ServiceException | ServiceQuotaTemplateNotInUseException | TemplatesNotAvailableInRegionException | TooManyRequestsException | CommonErrors;
/**
 * Disables your quota request template. After a template is disabled, the quota increase
 * requests in the template are not applied to new Amazon Web Services accounts in your organization.
 * Disabling a quota request template does not apply its quota increase requests.
 */
export declare const disassociateServiceQuotaTemplate: API.OperationMethod<DisassociateServiceQuotaTemplateRequest, DisassociateServiceQuotaTemplateResponse, DisassociateServiceQuotaTemplateError, Credentials | HttpClient.HttpClient>;
export type GetAssociationForServiceQuotaTemplateError = AccessDeniedException | AWSServiceAccessNotEnabledException | DependencyAccessDeniedException | NoAvailableOrganizationException | ServiceException | ServiceQuotaTemplateNotInUseException | TemplatesNotAvailableInRegionException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the status of the association for the quota request template.
 */
export declare const getAssociationForServiceQuotaTemplate: API.OperationMethod<GetAssociationForServiceQuotaTemplateRequest, GetAssociationForServiceQuotaTemplateResponse, GetAssociationForServiceQuotaTemplateError, Credentials | HttpClient.HttpClient>;
export type GetAutoManagementConfigurationError = AccessDeniedException | IllegalArgumentException | NoSuchResourceException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about your Service Quotas Automatic Management configuration. Automatic Management monitors your Service Quotas utilization and notifies you before you
 * run out of your allocated quotas.
 */
export declare const getAutoManagementConfiguration: API.OperationMethod<GetAutoManagementConfigurationRequest, GetAutoManagementConfigurationResponse, GetAutoManagementConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetAWSDefaultServiceQuotaError = AccessDeniedException | IllegalArgumentException | NoSuchResourceException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the default value for the specified quota. The default value does not
 * reflect any quota increases.
 */
export declare const getAWSDefaultServiceQuota: API.OperationMethod<GetAWSDefaultServiceQuotaRequest, GetAWSDefaultServiceQuotaResponse, GetAWSDefaultServiceQuotaError, Credentials | HttpClient.HttpClient>;
export type GetQuotaUtilizationReportError = AccessDeniedException | IllegalArgumentException | InvalidPaginationTokenException | NoSuchResourceException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the quota utilization report for your Amazon Web Services account. This operation returns
 * paginated results showing your quota usage across all Amazon Web Services services, sorted by utilization
 * percentage in descending order (highest utilization first).
 *
 * You must first initiate a report using the `StartQuotaUtilizationReport`
 * operation. The report generation process is asynchronous and may take several seconds to
 * complete. Poll this operation periodically to check the status and retrieve results when
 * the report is ready.
 *
 * Each report contains up to 1,000 quota records per page. Use the `NextToken`
 * parameter to retrieve additional pages of results. Reports are automatically deleted after
 * 15 minutes.
 */
export declare const getQuotaUtilizationReport: API.OperationMethod<GetQuotaUtilizationReportRequest, GetQuotaUtilizationReportResponse, GetQuotaUtilizationReportError, Credentials | HttpClient.HttpClient>;
export type GetRequestedServiceQuotaChangeError = AccessDeniedException | IllegalArgumentException | NoSuchResourceException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the specified quota increase request.
 */
export declare const getRequestedServiceQuotaChange: API.OperationMethod<GetRequestedServiceQuotaChangeRequest, GetRequestedServiceQuotaChangeResponse, GetRequestedServiceQuotaChangeError, Credentials | HttpClient.HttpClient>;
export type GetServiceQuotaError = AccessDeniedException | IllegalArgumentException | NoSuchResourceException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the applied quota value for the specified account-level or resource-level
 * quota. For some quotas, only the default values are available. If the applied quota
 * value is not available for a quota, the quota is not retrieved.
 */
export declare const getServiceQuota: API.OperationMethod<GetServiceQuotaRequest, GetServiceQuotaResponse, GetServiceQuotaError, Credentials | HttpClient.HttpClient>;
export type GetServiceQuotaIncreaseRequestFromTemplateError = AccessDeniedException | AWSServiceAccessNotEnabledException | DependencyAccessDeniedException | IllegalArgumentException | NoAvailableOrganizationException | NoSuchResourceException | ServiceException | TemplatesNotAvailableInRegionException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the specified quota increase request in your quota request
 * template.
 */
export declare const getServiceQuotaIncreaseRequestFromTemplate: API.OperationMethod<GetServiceQuotaIncreaseRequestFromTemplateRequest, GetServiceQuotaIncreaseRequestFromTemplateResponse, GetServiceQuotaIncreaseRequestFromTemplateError, Credentials | HttpClient.HttpClient>;
export type ListAWSDefaultServiceQuotasError = AccessDeniedException | IllegalArgumentException | InvalidPaginationTokenException | NoSuchResourceException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Lists the default values for the quotas for the specified Amazon Web Services service. A default
 * value does not reflect any quota increases.
 */
export declare const listAWSDefaultServiceQuotas: API.PaginatedOperationMethod<ListAWSDefaultServiceQuotasRequest, ListAWSDefaultServiceQuotasResponse, ListAWSDefaultServiceQuotasError, Credentials | HttpClient.HttpClient, ServiceQuota>;
export type ListRequestedServiceQuotaChangeHistoryError = AccessDeniedException | IllegalArgumentException | InvalidPaginationTokenException | NoSuchResourceException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the quota increase requests for the specified Amazon Web Services service. Filter
 * responses to return quota requests at either the account level, resource level, or all
 * levels. Responses include any open or closed requests within 90 days.
 */
export declare const listRequestedServiceQuotaChangeHistory: API.PaginatedOperationMethod<ListRequestedServiceQuotaChangeHistoryRequest, ListRequestedServiceQuotaChangeHistoryResponse, ListRequestedServiceQuotaChangeHistoryError, Credentials | HttpClient.HttpClient, RequestedServiceQuotaChange>;
export type ListRequestedServiceQuotaChangeHistoryByQuotaError = AccessDeniedException | IllegalArgumentException | InvalidPaginationTokenException | NoSuchResourceException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the quota increase requests for the specified quota. Filter responses to
 * return quota requests at either the account level, resource level, or all levels.
 */
export declare const listRequestedServiceQuotaChangeHistoryByQuota: API.PaginatedOperationMethod<ListRequestedServiceQuotaChangeHistoryByQuotaRequest, ListRequestedServiceQuotaChangeHistoryByQuotaResponse, ListRequestedServiceQuotaChangeHistoryByQuotaError, Credentials | HttpClient.HttpClient, RequestedServiceQuotaChange>;
export type ListServiceQuotaIncreaseRequestsInTemplateError = AccessDeniedException | AWSServiceAccessNotEnabledException | DependencyAccessDeniedException | IllegalArgumentException | NoAvailableOrganizationException | ServiceException | TemplatesNotAvailableInRegionException | TooManyRequestsException | CommonErrors;
/**
 * Lists the quota increase requests in the specified quota request template.
 */
export declare const listServiceQuotaIncreaseRequestsInTemplate: API.PaginatedOperationMethod<ListServiceQuotaIncreaseRequestsInTemplateRequest, ListServiceQuotaIncreaseRequestsInTemplateResponse, ListServiceQuotaIncreaseRequestsInTemplateError, Credentials | HttpClient.HttpClient, ServiceQuotaIncreaseRequestInTemplate>;
export type ListServiceQuotasError = AccessDeniedException | IllegalArgumentException | InvalidPaginationTokenException | NoSuchResourceException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Lists the applied quota values for the specified Amazon Web Services service. For some quotas, only
 * the default values are available. If the applied quota value is not available for a
 * quota, the quota is not retrieved. Filter responses to return applied quota values at
 * either the account level, resource level, or all levels.
 */
export declare const listServiceQuotas: API.PaginatedOperationMethod<ListServiceQuotasRequest, ListServiceQuotasResponse, ListServiceQuotasError, Credentials | HttpClient.HttpClient, ServiceQuota>;
export type ListServicesError = AccessDeniedException | IllegalArgumentException | InvalidPaginationTokenException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Lists the names and codes for the Amazon Web Services services integrated with Service Quotas.
 */
export declare const listServices: API.PaginatedOperationMethod<ListServicesRequest, ListServicesResponse, ListServicesError, Credentials | HttpClient.HttpClient, ServiceInfo>;
export type ListTagsForResourceError = AccessDeniedException | IllegalArgumentException | NoSuchResourceException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns a list of the tags assigned to the specified applied quota.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutServiceQuotaIncreaseRequestIntoTemplateError = AccessDeniedException | AWSServiceAccessNotEnabledException | DependencyAccessDeniedException | IllegalArgumentException | NoAvailableOrganizationException | NoSuchResourceException | QuotaExceededException | ServiceException | TemplatesNotAvailableInRegionException | TooManyRequestsException | CommonErrors;
/**
 * Adds a quota increase request to your quota request template.
 */
export declare const putServiceQuotaIncreaseRequestIntoTemplate: API.OperationMethod<PutServiceQuotaIncreaseRequestIntoTemplateRequest, PutServiceQuotaIncreaseRequestIntoTemplateResponse, PutServiceQuotaIncreaseRequestIntoTemplateError, Credentials | HttpClient.HttpClient>;
export type RequestServiceQuotaIncreaseError = AccessDeniedException | DependencyAccessDeniedException | IllegalArgumentException | InvalidResourceStateException | NoSuchResourceException | QuotaExceededException | ResourceAlreadyExistsException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Submits a quota increase request for the specified quota at the account or resource
 * level.
 */
export declare const requestServiceQuotaIncrease: API.OperationMethod<RequestServiceQuotaIncreaseRequest, RequestServiceQuotaIncreaseResponse, RequestServiceQuotaIncreaseError, Credentials | HttpClient.HttpClient>;
export type StartAutoManagementError = AccessDeniedException | IllegalArgumentException | NoSuchResourceException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Starts Service Quotas Automatic Management for an Amazon Web Services account, including notification preferences
 * and excluded quotas configurations. Automatic Management monitors your Service Quotas utilization and notifies you before you
 * run out of your allocated quotas.
 */
export declare const startAutoManagement: API.OperationMethod<StartAutoManagementRequest, StartAutoManagementResponse, StartAutoManagementError, Credentials | HttpClient.HttpClient>;
export type StartQuotaUtilizationReportError = AccessDeniedException | IllegalArgumentException | InvalidPaginationTokenException | NoSuchResourceException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Initiates the generation of a quota utilization report for your Amazon Web Services account. This
 * asynchronous operation analyzes your quota usage across all Amazon Web Services services and returns
 * a unique report identifier that you can use to retrieve the results.
 *
 * The report generation process may take several seconds to complete, depending on the
 * number of quotas in your account. Use the `GetQuotaUtilizationReport` operation
 * to check the status and retrieve the results when the report is ready.
 */
export declare const startQuotaUtilizationReport: API.OperationMethod<StartQuotaUtilizationReportRequest, StartQuotaUtilizationReportResponse, StartQuotaUtilizationReportError, Credentials | HttpClient.HttpClient>;
export type StopAutoManagementError = AccessDeniedException | IllegalArgumentException | NoSuchResourceException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Stops Service Quotas Automatic Management for an Amazon Web Services account and removes all associated
 * configurations. Automatic Management monitors your Service Quotas utilization and notifies you before you
 * run out of your allocated quotas.
 */
export declare const stopAutoManagement: API.OperationMethod<StopAutoManagementRequest, StopAutoManagementResponse, StopAutoManagementError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | IllegalArgumentException | NoSuchResourceException | ServiceException | TagPolicyViolationException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Adds tags to the specified applied quota. You can include one or more tags to add to
 * the quota.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | IllegalArgumentException | NoSuchResourceException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Removes tags from the specified applied quota. You can specify one or more tags to
 * remove.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAutoManagementError = AccessDeniedException | IllegalArgumentException | NoSuchResourceException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Updates your Service Quotas Automatic Management configuration, including notification preferences and
 * excluded quotas. Automatic Management monitors your Service Quotas utilization and notifies you before you
 * run out of your allocated quotas.
 */
export declare const updateAutoManagement: API.OperationMethod<UpdateAutoManagementRequest, UpdateAutoManagementResponse, UpdateAutoManagementError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=service-quotas.d.ts.map