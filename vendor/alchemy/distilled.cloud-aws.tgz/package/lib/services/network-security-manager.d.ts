import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly quotaCode: any;
    readonly serviceCode: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TagPolicyViolationException_base: S.TaggedErrorClass<"TagPolicyViolationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagPolicyViolationException extends /*@__PURE__*/ TagPolicyViolationException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type IdempotencyToken = string;
export type DeploymentName = string;
export type Description = string;
export type EnableCrossAccountVisibility = boolean;
export interface DeploymentConfiguration {
    enableCrossAccountVisibility: boolean;
}
export type PolicyIdentifier = string;
export interface PolicyReference {
    policyIdentifier: string;
}
export type PolicyReferenceList = PolicyReference[];
export type ScopeIdentifier = string;
export interface ScopeReference {
    scopeIdentifier: string;
}
export type ScopeReferenceList = ScopeReference[];
export type IsPublished = boolean;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateDeploymentInput {
    clientToken?: string;
    deploymentName: string;
    deploymentDescription?: string;
    deploymentConfiguration: DeploymentConfiguration;
    associatedPolicyList: PolicyReference[];
    associatedScopeList: ScopeReference[];
    isPublished?: boolean;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type DeploymentId = string;
export type DeploymentArn = string;
export type EntityStatus = "DRAFT" | "ACTIVE" | "DISABLED" | (string & {});
export type PolicyArn = string;
export interface AssociatedPolicy {
    policyArn: string;
}
export type AssociatedPolicyList = AssociatedPolicy[];
export type ScopeArn = string;
export interface AssociatedScope {
    scopeArn: string;
}
export type AssociatedScopeList = AssociatedScope[];
export type EntityVersion = string;
export type UpdateToken = string;
export type IsSnapshot = boolean;
export type HasPublishedVersion = boolean;
export type PolicyFirewallType = "WAF" | "SHIELD_ADVANCED" | (string & {});
export type DeploymentPolicyArnList = string[];
export type ScopeResourceType = "AWS::ApiGateway::Stage" | "AWS::CloudFront::Distribution" | "AWS::EC2::EIP" | "AWS::ElasticLoadBalancingV2::LoadBalancer::application" | "AWS::ElasticLoadBalancing::LoadBalancer" | (string & {});
export type DeploymentResourceTypeList = ScopeResourceType[];
export interface DeploymentCoverageEntry {
    firewallType: PolicyFirewallType;
    policyArns: string[];
    inScopeResourceTypes: ScopeResourceType[];
}
export type DeploymentCoverageList = DeploymentCoverageEntry[];
export interface DeploymentWarningEntry {
    code: string;
    policyArn: string;
    message: string;
}
export type DeploymentWarningList = DeploymentWarningEntry[];
export interface CreateDeploymentOutput {
    deploymentId: string;
    deploymentArn: string;
    deploymentName: string;
    deploymentDescription?: string;
    status: EntityStatus;
    deploymentConfiguration?: DeploymentConfiguration;
    associatedPolicyList: AssociatedPolicy[];
    associatedScopeList: AssociatedScope[];
    version: string;
    updateToken?: string;
    isSnapshot?: boolean;
    hasPublishedVersion?: boolean;
    deploymentCoverage?: DeploymentCoverageEntry[];
    warnings?: DeploymentWarningEntry[];
    updatedAt?: Date;
}
export type DeploymentIdentifier = string;
export interface CreateDeploymentSnapshotInput {
    deploymentIdentifier: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateDeploymentSnapshotOutput {
    deploymentId: string;
    deploymentArn: string;
    deploymentName: string;
    deploymentDescription?: string;
    status: EntityStatus;
    deploymentConfiguration?: DeploymentConfiguration;
    associatedPolicyList: AssociatedPolicy[];
    associatedScopeList: AssociatedScope[];
    version: string;
    updateToken?: string;
    isSnapshot?: boolean;
    hasPublishedVersion?: boolean;
    updatedAt?: Date;
}
export type PolicyName = string;
export type Priority = number;
export type TemplateIdentifier = string;
export type RuleIdentifier = string;
export type TemplateOrRuleReference = {
    templateIdentifier: string;
    ruleIdentifier?: never;
} | {
    templateIdentifier?: never;
    ruleIdentifier: string;
};
export type TemplateAndRuleReferenceList = TemplateOrRuleReference[];
export type RemediationEnabled = boolean;
export type ResourcesCleanUp = boolean;
export type ExistingCustomerWebACLResolution = "RETROFIT" | "OVERRIDE_ASSOCIATION" | "NO_REMEDIATION" | (string & {});
export type WAFConflictResolutionOptions = "MERGE_WHERE_APPLICABLE" | (string & {});
export interface WafConfig {
    existingCustomerWebACLResolution: ExistingCustomerWebACLResolution;
    conflictResolution: WAFConflictResolutionOptions;
}
export interface PolicyConfiguration {
    remediationEnabled: boolean;
    resourcesCleanUp: boolean;
    wafConfig?: WafConfig;
}
export interface CreatePolicyInput {
    clientToken?: string;
    policyName: string;
    policyDescription?: string;
    priority: number;
    associatedTemplateAndRuleList?: TemplateOrRuleReference[];
    firewallType: PolicyFirewallType;
    policyConfiguration: PolicyConfiguration;
    isPublished?: boolean;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type PolicyId = string;
export type TemplateArn = string;
export type RuleArn = string;
export type AssociatedTemplateOrRule = {
    templateArn: string;
    ruleArn?: never;
} | {
    templateArn?: never;
    ruleArn: string;
};
export type AssociatedTemplateAndRuleList = AssociatedTemplateOrRule[];
export interface CreatePolicyOutput {
    policyId: string;
    policyArn: string;
    policyName: string;
    policyDescription?: string;
    status: EntityStatus;
    priority: number;
    associatedTemplateAndRuleList: AssociatedTemplateOrRule[];
    version: string;
    updateToken?: string;
    isSnapshot?: boolean;
    hasPublishedVersion?: boolean;
    firewallType: PolicyFirewallType;
    policyConfiguration?: PolicyConfiguration;
    updatedAt?: Date;
}
export interface CreatePolicySnapshotInput {
    policyIdentifier: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreatePolicySnapshotOutput {
    policyId: string;
    policyArn: string;
    policyName: string;
    policyDescription?: string;
    status: EntityStatus;
    priority: number;
    associatedTemplateAndRuleList: AssociatedTemplateOrRule[];
    version: string;
    updateToken?: string;
    isSnapshot?: boolean;
    hasPublishedVersion?: boolean;
    firewallType: PolicyFirewallType;
    policyConfiguration?: PolicyConfiguration;
    updatedAt?: Date;
}
export type RuleName = string;
export type RuleFirewallType = "WAF" | (string & {});
export type RuleType = "CONFIGURATION" | "INSPECTION" | (string & {});
export type JsonDocument = unknown;
export interface CreateRuleInput {
    clientToken?: string;
    ruleName: string;
    firewallType: RuleFirewallType;
    ruleType: RuleType;
    ruleDescription?: string;
    configuration: any;
    isPublished?: boolean;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type RuleId = string;
export interface CreateRuleOutput {
    ruleId: string;
    ruleArn: string;
    ruleName: string;
    firewallType: RuleFirewallType;
    ruleType?: RuleType;
    ruleDescription?: string;
    configuration: any;
    status: EntityStatus;
    version: string;
    updateToken?: string;
    isSnapshot?: boolean;
    hasPublishedVersion?: boolean;
    updatedAt?: Date;
}
export interface CreateRuleSnapshotInput {
    ruleIdentifier: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateRuleSnapshotOutput {
    ruleId: string;
    ruleArn: string;
    ruleName: string;
    firewallType: RuleFirewallType;
    ruleType?: RuleType;
    ruleDescription?: string;
    configuration: any;
    status: EntityStatus;
    version: string;
    updateToken?: string;
    isSnapshot?: boolean;
    hasPublishedVersion?: boolean;
    updatedAt?: Date;
}
export type ScopeName = string;
export type AccountId = string;
export type AccountList = string[];
export type OrganizationalUnit = string;
export type OrganizationalUnitList = string[];
export interface AccountSet {
    accountIds?: string[];
    organizationalUnits?: string[];
}
export type AccountFilter = {
    includeAll: Record<string, never>;
    include?: never;
    exclude?: never;
} | {
    includeAll?: never;
    include: AccountSet;
    exclude?: never;
} | {
    includeAll?: never;
    include?: never;
    exclude: AccountSet;
};
export type Arn = string;
export type ResourceArnList = string[];
export type StringMap = {
    [key: string]: string | undefined;
};
export type Scheme = "internet-facing" | "internal" | (string & {});
export type IpAddressType = "ipv4" | "dualstack" | "dualstack-without-public-ipv4" | (string & {});
export interface AlbConfiguration {
    scheme?: Scheme;
    ipAddressType?: IpAddressType;
}
export type ResourceCriteria = {
    tags: {
        [key: string]: string | undefined;
    };
    albConfig?: never;
} | {
    tags?: never;
    albConfig: AlbConfiguration;
};
export type ResourceLogicalExpressionList = ResourceLogicalExpression[];
export type ResourceLogicalExpression = {
    criteria: ResourceCriteria;
    and?: never;
    or?: never;
    not?: never;
} | {
    criteria?: never;
    and: ResourceLogicalExpression[];
    or?: never;
    not?: never;
} | {
    criteria?: never;
    and?: never;
    or: ResourceLogicalExpression[];
    not?: never;
} | {
    criteria?: never;
    and?: never;
    or?: never;
    not: ResourceLogicalExpression;
};
export interface ResourceSet {
    explicitArns?: string[];
    expression?: ResourceLogicalExpression;
}
export interface ResourceScope {
    includeAll?: boolean;
    include?: ResourceSet;
    exclude?: ResourceSet;
}
export type ResourceScopeMap = {
    [key in ScopeResourceType]?: ResourceScope;
};
export interface ScopeConfiguration {
    accountFilter?: AccountFilter;
    resourceScopes: {
        [key: string]: ResourceScope | undefined;
    };
}
export interface CreateScopeInput {
    clientToken?: string;
    scopeName: string;
    scopeDescription?: string;
    scopeConfiguration: ScopeConfiguration;
    isPublished?: boolean;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type ScopeId = string;
export interface CreateScopeOutput {
    scopeId: string;
    scopeArn: string;
    scopeName: string;
    scopeDescription?: string;
    scopeConfiguration?: ScopeConfiguration;
    status: EntityStatus;
    version: string;
    updateToken?: string;
    isSnapshot?: boolean;
    hasPublishedVersion?: boolean;
    updatedAt?: Date;
}
export interface CreateScopeSnapshotInput {
    scopeIdentifier: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateScopeSnapshotOutput {
    scopeId: string;
    scopeArn: string;
    scopeName: string;
    scopeDescription?: string;
    scopeConfiguration?: ScopeConfiguration;
    status: EntityStatus;
    version: string;
    updateToken?: string;
    isSnapshot?: boolean;
    hasPublishedVersion?: boolean;
    updatedAt?: Date;
}
export type TemplateName = string;
export interface RuleReference {
    ruleIdentifier: string;
}
export type RuleReferenceList = RuleReference[];
export type TemplateFirewallType = "WAF" | (string & {});
export interface CreateTemplateInput {
    clientToken?: string;
    templateName: string;
    templateDescription?: string;
    associatedRuleList: RuleReference[];
    firewallType: TemplateFirewallType;
    isPublished?: boolean;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type TemplateId = string;
export interface AssociatedRule {
    ruleArn: string;
}
export type AssociatedRuleList = AssociatedRule[];
export interface CreateTemplateOutput {
    templateId: string;
    templateArn: string;
    templateName: string;
    templateDescription?: string;
    status: EntityStatus;
    version: string;
    associatedRuleList: AssociatedRule[];
    updateToken?: string;
    isSnapshot?: boolean;
    hasPublishedVersion?: boolean;
    firewallType: TemplateFirewallType;
    updatedAt?: Date;
}
export interface CreateTemplateSnapshotInput {
    templateIdentifier: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateTemplateSnapshotOutput {
    templateId: string;
    templateArn: string;
    templateName: string;
    templateDescription?: string;
    status: EntityStatus;
    version: string;
    associatedRuleList: AssociatedRule[];
    updateToken?: string;
    isSnapshot?: boolean;
    hasPublishedVersion?: boolean;
    firewallType: TemplateFirewallType;
    updatedAt?: Date;
}
export interface DeleteAdminAccountRequest {
    accountId: string;
}
export interface DeleteAdminAccountResponse {
}
export interface DeleteDeploymentInput {
    deploymentIdentifier: string;
}
export interface DeleteDeploymentResponse {
}
export interface DeletePolicyInput {
    policyIdentifier: string;
}
export interface DeletePolicyResponse {
}
export interface DeleteRuleInput {
    ruleIdentifier: string;
}
export interface DeleteRuleResponse {
}
export interface DeleteScopeInput {
    scopeIdentifier: string;
}
export interface DeleteScopeResponse {
}
export interface DeleteTemplateInput {
    templateIdentifier: string;
}
export interface DeleteTemplateResponse {
}
export type SensitiveString = string | redacted.Redacted<string>;
export type WAFConfigDataType = "DefaultAction" | "VisibilityConfig" | "CaptchaConfig" | "ChallengeConfig" | "CustomResponseBodies" | "LoggingConfiguration" | "DataProtectionConfig" | "AssociationConfig" | "OnSourceDDoSProtectionConfig" | "TokenDomains" | (string & {});
export interface GenerateRuleConfigurationRequest {
    prompt: string | redacted.Redacted<string>;
    ruleFirewallType: RuleFirewallType;
    ruleType: RuleType;
    wafConfigDataType?: WAFConfigDataType;
    currentConfiguration?: string;
    clientToken?: string;
}
export interface GenerateRuleConfigurationResponse {
    configuration: string;
    description?: string;
}
export interface GetAdminAccountRequest {
    accountId: string;
}
export type AdminPriority = number;
export type SensitiveAccountName = string | redacted.Redacted<string>;
export type SensitiveAccountEmail = string | redacted.Redacted<string>;
export interface AccountReference {
    accountId: string;
    name?: string | redacted.Redacted<string>;
    email?: string | redacted.Redacted<string>;
}
export type AccountReferenceList = AccountReference[];
export type OrganizationalUnitId = string;
export interface OrganizationalUnitReference {
    ouId: string;
    name?: string;
}
export type OrganizationalUnitReferenceList = OrganizationalUnitReference[];
export interface AdminScopeSelection {
    accounts?: AccountReference[];
    organizationalUnits?: OrganizationalUnitReference[];
}
export type AdminScopeFilter = {
    includeAll: Record<string, never>;
    includeOnly?: never;
    excludeOnly?: never;
} | {
    includeAll?: never;
    includeOnly: AdminScopeSelection;
    excludeOnly?: never;
} | {
    includeAll?: never;
    includeOnly?: never;
    excludeOnly: AdminScopeSelection;
};
export type FirewallTypeList = PolicyFirewallType[];
export interface AdminFirewallTypeScope {
    allFirewallTypesEnabled?: boolean;
    firewallTypes?: PolicyFirewallType[];
}
export interface AdminScope {
    scopeFilter?: AdminScopeFilter;
    firewallTypeScope?: AdminFirewallTypeScope;
}
export type AdminAccountStatus = "ONBOARDED" | "OFFBOARDED" | (string & {});
export interface AdminAccountDetails {
    adminAccount: string;
    priority: number;
    adminScope?: AdminScope;
    status?: AdminAccountStatus;
}
export interface GetAdminAccountResponse {
    adminAccountDetails?: AdminAccountDetails;
}
export interface GetDeploymentInput {
    deploymentIdentifier: string;
}
export interface GetDeploymentOutput {
    deploymentId: string;
    deploymentArn: string;
    deploymentName: string;
    deploymentDescription?: string;
    status: EntityStatus;
    deploymentConfiguration?: DeploymentConfiguration;
    associatedPolicyList: AssociatedPolicy[];
    associatedScopeList: AssociatedScope[];
    version: string;
    updateToken?: string;
    isSnapshot?: boolean;
    hasPublishedVersion?: boolean;
    updatedAt?: Date;
    deploymentCoverage?: DeploymentCoverageEntry[];
    warnings?: DeploymentWarningEntry[];
}
export interface GetPolicyInput {
    policyIdentifier: string;
}
export interface GetPolicyOutput {
    policyId: string;
    policyArn: string;
    policyName: string;
    policyDescription?: string;
    status: EntityStatus;
    priority: number;
    associatedTemplateAndRuleList: AssociatedTemplateOrRule[];
    version: string;
    updateToken?: string;
    isSnapshot?: boolean;
    hasPublishedVersion?: boolean;
    firewallType: PolicyFirewallType;
    policyConfiguration?: PolicyConfiguration;
    updatedAt?: Date;
}
export interface GetRuleInput {
    ruleIdentifier: string;
}
export interface GetRuleOutput {
    ruleId: string;
    ruleArn: string;
    ruleName: string;
    firewallType: RuleFirewallType;
    ruleType?: RuleType;
    ruleDescription?: string;
    configuration: any;
    status: EntityStatus;
    version: string;
    updateToken?: string;
    isSnapshot?: boolean;
    hasPublishedVersion?: boolean;
    updatedAt?: Date;
}
export interface GetScopeInput {
    scopeIdentifier: string;
}
export interface GetScopeOutput {
    scopeId: string;
    scopeArn: string;
    scopeName: string;
    scopeDescription?: string;
    scopeConfiguration?: ScopeConfiguration;
    status: EntityStatus;
    version: string;
    updateToken?: string;
    isSnapshot?: boolean;
    hasPublishedVersion?: boolean;
    updatedAt?: Date;
}
export interface GetTemplateInput {
    templateIdentifier: string;
}
export interface GetTemplateOutput {
    templateId: string;
    templateArn: string;
    templateName: string;
    templateDescription?: string;
    status: EntityStatus;
    version: string;
    associatedRuleList: AssociatedRule[];
    updateToken?: string;
    isSnapshot?: boolean;
    hasPublishedVersion?: boolean;
    firewallType: TemplateFirewallType;
    updatedAt?: Date;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListAdminAccountsRequest {
    maxResults?: number;
    nextToken?: string;
}
export type SensitiveName = string | redacted.Redacted<string>;
export type SensitiveEmail = string | redacted.Redacted<string>;
export interface AdminAccountSummary {
    accountId: string;
    priority?: number;
    name?: string | redacted.Redacted<string>;
    email?: string | redacted.Redacted<string>;
}
export type AdminAccountSummaryList = AdminAccountSummary[];
export interface ListAdminAccountsResponse {
    nextToken?: string;
    adminAccounts: AdminAccountSummary[];
}
export type SynchronizationStatus = "IN_SYNC" | "OUT_OF_SYNC" | "NOT_APPLICABLE" | (string & {});
export interface ListAggregateResourceSynchronizationStatusesInput {
    synchronizationStatus?: SynchronizationStatus;
    maxResults?: number;
    nextToken?: string;
}
export type ResourceType = "AWS::ApiGateway::Stage" | "AWS::CloudFront::Distribution" | "AWS::EC2::EIP" | "AWS::ElasticLoadBalancingV2::LoadBalancer::application" | "AWS::ElasticLoadBalancing::LoadBalancer" | "AWS::WAFv2::WebACL" | "AWS::Shield::Protection" | "AWS::ShieldRegional::Protection" | (string & {});
export interface ConfigurationIssue {
    configurationName?: string;
    expectedValue?: string;
    actualValue?: string;
}
export type ConfigurationIssueList = ConfigurationIssue[];
export interface InvalidFirewallReasons {
    incorrectSingleValueConfigurations?: ConfigurationIssue[];
    missingAppendableConfigurationValues?: ConfigurationIssue[];
    unexpectedAppendableConfigurationValues?: ConfigurationIssue[];
    incorrectAppendableConfigurationOrder?: ConfigurationIssue[];
    missingMergeableConfigurationValues?: ConfigurationIssue[];
    unexpectedMergeableConfigurationValues?: ConfigurationIssue[];
}
export type FirewallSyncReason = {
    missingFirewall: string;
    invalidFirewall?: never;
} | {
    missingFirewall?: never;
    invalidFirewall: InvalidFirewallReasons;
};
export type OutOfSyncReasons = {
    [key in PolicyFirewallType]?: FirewallSyncReason;
};
export interface NotVisibleMarker {
    reason: string;
}
export type OutOfSyncReasonsView = {
    reasons: {
        [key: string]: FirewallSyncReason | undefined;
    };
    notVisible?: never;
} | {
    reasons?: never;
    notVisible: NotVisibleMarker;
};
export interface RemediationIssueDetails {
    issueType?: string;
    message?: string;
    correctiveAction?: string;
}
export type RemediationIssues = {
    [key in PolicyFirewallType]?: RemediationIssueDetails;
};
export type RemediationIssuesView = {
    issues: {
        [key: string]: RemediationIssueDetails | undefined;
    };
    notVisible?: never;
} | {
    issues?: never;
    notVisible: NotVisibleMarker;
};
export interface ResourceSynchronizationStatusSummary {
    synchronizationStatus: SynchronizationStatus;
    accountId: string;
    resourceArn: string;
    deploymentArn?: string;
    resourceType?: ResourceType;
    updatedAt: Date;
    outOfSyncReasons?: OutOfSyncReasonsView;
    remediationIssues?: RemediationIssuesView;
    evaluatedAt?: Date;
}
export type ResourceSynchronizationStatusSummaryList = ResourceSynchronizationStatusSummary[];
export interface ListAggregateResourceSynchronizationStatusesOutput {
    nextToken?: string;
    resourceSynchronizationStatuses: ResourceSynchronizationStatusSummary[];
}
export type EntityStatusFilter = "ACTIVE" | "DRAFT" | "DISABLED" | (string & {});
export interface ListDeploymentsInput {
    maxResults?: number;
    nextToken?: string;
    status?: EntityStatusFilter;
}
export interface DeploymentSummary {
    deploymentId: string;
    deploymentArn: string;
    deploymentName?: string;
    status?: EntityStatus;
    version?: string;
    hasPublishedVersion?: boolean;
    updatedAt?: Date;
}
export type DeploymentSummaryList = DeploymentSummary[];
export interface ListDeploymentsOutput {
    nextToken?: string;
    deployments: DeploymentSummary[];
}
export interface ListDeploymentSnapshotsInput {
    deploymentIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export interface ListDeploymentSnapshotsOutput {
    nextToken?: string;
    snapshots: DeploymentSummary[];
}
export interface ListPoliciesInput {
    maxResults?: number;
    nextToken?: string;
    status?: EntityStatusFilter;
}
export interface PolicySummary {
    policyId: string;
    policyArn: string;
    policyName?: string;
    status?: EntityStatus;
    version?: string;
    hasPublishedVersion?: boolean;
    firewallType?: PolicyFirewallType;
    priority?: number;
    updatedAt?: Date;
}
export type PolicySummaryList = PolicySummary[];
export interface ListPoliciesOutput {
    nextToken?: string;
    policies: PolicySummary[];
}
export interface ListPolicySnapshotsInput {
    policyIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export interface ListPolicySnapshotsOutput {
    nextToken?: string;
    snapshots: PolicySummary[];
}
export type ResourceIdentifier = string;
export interface ListResourceAssociationsInput {
    resourceIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export type ServiceResourceType = "Rule" | "Template" | "Policy" | "Deployment" | "Scope" | (string & {});
export interface ResourceAssociation {
    arn: string;
    resourceType: ServiceResourceType;
}
export type ResourceAssociationList = ResourceAssociation[];
export interface ListResourceAssociationsOutput {
    nextToken?: string;
    resourceAssociations: ResourceAssociation[];
}
export interface ListResourceSynchronizationStatusesInput {
    deploymentIdentifier: string;
    synchronizationStatus?: SynchronizationStatus;
    maxResults?: number;
    nextToken?: string;
}
export interface ListResourceSynchronizationStatusesOutput {
    nextToken?: string;
    resourceSynchronizationStatuses: ResourceSynchronizationStatusSummary[];
}
export interface ListRulesInput {
    maxResults?: number;
    nextToken?: string;
    status?: EntityStatusFilter;
}
export interface RuleSummary {
    ruleId: string;
    ruleArn: string;
    ruleName: string;
    firewallType?: RuleFirewallType;
    ruleType?: RuleType;
    status?: EntityStatus;
    version?: string;
    hasPublishedVersion?: boolean;
    updatedAt?: Date;
}
export type RuleSummaryList = RuleSummary[];
export interface ListRulesOutput {
    nextToken?: string;
    rules: RuleSummary[];
}
export interface ListRuleSnapshotsInput {
    ruleIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export interface ListRuleSnapshotsOutput {
    nextToken?: string;
    snapshots: RuleSummary[];
}
export interface ListScopesInput {
    maxResults?: number;
    nextToken?: string;
    status?: EntityStatusFilter;
}
export interface ScopeSummary {
    scopeId: string;
    scopeArn: string;
    scopeName?: string;
    status?: EntityStatus;
    version?: string;
    hasPublishedVersion?: boolean;
    updatedAt?: Date;
}
export type ScopeSummaryList = ScopeSummary[];
export interface ListScopesOutput {
    nextToken?: string;
    scopes: ScopeSummary[];
}
export interface ListScopeSnapshotsInput {
    scopeIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export interface ListScopeSnapshotsOutput {
    nextToken?: string;
    snapshots: ScopeSummary[];
}
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListTemplatesInput {
    maxResults?: number;
    nextToken?: string;
    status?: EntityStatusFilter;
}
export interface TemplateSummary {
    templateId: string;
    templateArn: string;
    templateName: string;
    status?: EntityStatus;
    version?: string;
    hasPublishedVersion?: boolean;
    firewallType?: TemplateFirewallType;
    updatedAt?: Date;
}
export type TemplateSummaryList = TemplateSummary[];
export interface ListTemplatesOutput {
    nextToken?: string;
    templates: TemplateSummary[];
}
export interface ListTemplateSnapshotsInput {
    templateIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export interface ListTemplateSnapshotsOutput {
    nextToken?: string;
    snapshots: TemplateSummary[];
}
export type AccountIdList = string[];
export type OrganizationalUnitIdList = string[];
export interface AdminScopeSelectionInput {
    accounts?: string[];
    organizationalUnits?: string[];
}
export type AdminScopeFilterInput = {
    includeAll: Record<string, never>;
    includeOnly?: never;
    excludeOnly?: never;
} | {
    includeAll?: never;
    includeOnly: AdminScopeSelectionInput;
    excludeOnly?: never;
} | {
    includeAll?: never;
    includeOnly?: never;
    excludeOnly: AdminScopeSelectionInput;
};
export interface AdminScopeInput {
    scopeFilter?: AdminScopeFilterInput;
    firewallTypeScope?: AdminFirewallTypeScope;
}
export interface PutAdminAccountRequest {
    accountId: string;
    priority: number;
    adminScope?: AdminScopeInput;
}
export interface PutAdminAccountResponse {
    adminAccountDetails?: AdminAccountDetails;
}
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateDeploymentInput {
    deploymentIdentifier: string;
    updateToken: string;
    deploymentDescription?: string;
    deploymentConfiguration?: DeploymentConfiguration;
    associatedPolicyList?: PolicyReference[];
    associatedScopeList?: ScopeReference[];
    isPublished: boolean;
    clientToken?: string;
}
export interface UpdateDeploymentOutput {
    deploymentId: string;
    deploymentArn: string;
    deploymentName: string;
    deploymentDescription?: string;
    status: EntityStatus;
    deploymentConfiguration?: DeploymentConfiguration;
    associatedPolicyList: AssociatedPolicy[];
    associatedScopeList: AssociatedScope[];
    version: string;
    updateToken?: string;
    isSnapshot?: boolean;
    hasPublishedVersion?: boolean;
    deploymentCoverage?: DeploymentCoverageEntry[];
    warnings?: DeploymentWarningEntry[];
    updatedAt?: Date;
}
export interface UpdatePolicyInput {
    policyIdentifier: string;
    updateToken: string;
    policyDescription?: string;
    priority?: number;
    associatedTemplateAndRuleList?: TemplateOrRuleReference[];
    policyConfiguration?: PolicyConfiguration;
    isPublished: boolean;
    clientToken?: string;
}
export interface UpdatePolicyOutput {
    policyId: string;
    policyArn: string;
    policyName: string;
    policyDescription?: string;
    status: EntityStatus;
    priority: number;
    associatedTemplateAndRuleList: AssociatedTemplateOrRule[];
    version: string;
    updateToken?: string;
    isSnapshot?: boolean;
    hasPublishedVersion?: boolean;
    firewallType: PolicyFirewallType;
    policyConfiguration?: PolicyConfiguration;
    updatedAt?: Date;
}
export interface UpdateRuleInput {
    ruleIdentifier: string;
    updateToken: string;
    ruleType?: RuleType;
    ruleDescription?: string;
    configuration?: any;
    isPublished: boolean;
    clientToken?: string;
}
export interface UpdateRuleOutput {
    ruleId: string;
    ruleArn: string;
    ruleName: string;
    firewallType: RuleFirewallType;
    ruleType?: RuleType;
    ruleDescription?: string;
    configuration: any;
    status: EntityStatus;
    version: string;
    updateToken?: string;
    isSnapshot?: boolean;
    hasPublishedVersion?: boolean;
    updatedAt?: Date;
}
export interface UpdateScopeInput {
    scopeIdentifier: string;
    updateToken: string;
    scopeDescription?: string;
    scopeConfiguration?: ScopeConfiguration;
    isPublished: boolean;
    clientToken?: string;
}
export interface UpdateScopeOutput {
    scopeId: string;
    scopeArn: string;
    scopeName: string;
    scopeDescription?: string;
    scopeConfiguration?: ScopeConfiguration;
    status: EntityStatus;
    version: string;
    updateToken?: string;
    isSnapshot?: boolean;
    hasPublishedVersion?: boolean;
    updatedAt?: Date;
}
export interface UpdateTemplateInput {
    templateIdentifier: string;
    updateToken: string;
    templateDescription?: string;
    associatedRuleList?: RuleReference[];
    isPublished: boolean;
    clientToken?: string;
}
export interface UpdateTemplateOutput {
    templateId: string;
    templateArn: string;
    templateName: string;
    templateDescription?: string;
    status: EntityStatus;
    version: string;
    associatedRuleList: AssociatedRule[];
    updateToken?: string;
    isSnapshot?: boolean;
    hasPublishedVersion?: boolean;
    firewallType: TemplateFirewallType;
    updatedAt?: Date;
}
export type ValidationExceptionReason = "ACCOUNT_NOT_ONBOARDED" | "FIELD_VALIDATION_FAILED" | "OTHER" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type CreateDeploymentError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ServiceUnavailableException | TagPolicyViolationException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a deployment. A deployment applies one or more policies to the accounts and resources selected by a scope. Use `isPublished` to create the deployment in published (`ACTIVE`) or draft (`DRAFT`) state. The response includes coverage information and any warnings about the deployment.
 */
export declare const createDeployment: API.OperationMethod<CreateDeploymentInput, CreateDeploymentOutput, CreateDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentSnapshotError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a snapshot of the current published version of the specified deployment.
 */
export declare const createDeploymentSnapshot: API.OperationMethod<CreateDeploymentSnapshotInput, CreateDeploymentSnapshotOutput, CreateDeploymentSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreatePolicyError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ServiceUnavailableException | TagPolicyViolationException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a policy. A policy combines templates and rules with enforcement settings for a firewall type, such as AWS WAF or AWS Shield Advanced. Use `isPublished` to create the policy in published (`ACTIVE`) or draft (`DRAFT`) state.
 */
export declare const createPolicy: API.OperationMethod<CreatePolicyInput, CreatePolicyOutput, CreatePolicyError, Credentials | HttpClient.HttpClient>;
export type CreatePolicySnapshotError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a snapshot of the current published version of the specified policy.
 */
export declare const createPolicySnapshot: API.OperationMethod<CreatePolicySnapshotInput, CreatePolicySnapshotOutput, CreatePolicySnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateRuleError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ServiceUnavailableException | TagPolicyViolationException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a rule. A rule defines a network security configuration to enforce, such as an AWS WAF rule group or configuration data. Use `isPublished` to create the rule in published (`ACTIVE`) or draft (`DRAFT`) state.
 */
export declare const createRule: API.OperationMethod<CreateRuleInput, CreateRuleOutput, CreateRuleError, Credentials | HttpClient.HttpClient>;
export type CreateRuleSnapshotError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a snapshot of the current published version of the specified rule. A snapshot is an immutable, versioned copy that other resources can reference.
 */
export declare const createRuleSnapshot: API.OperationMethod<CreateRuleSnapshotInput, CreateRuleSnapshotOutput, CreateRuleSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateScopeError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ServiceUnavailableException | TagPolicyViolationException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a scope. A scope selects the accounts and resources that a deployment applies to. Use `isPublished` to create the scope in published (`ACTIVE`) or draft (`DRAFT`) state.
 */
export declare const createScope: API.OperationMethod<CreateScopeInput, CreateScopeOutput, CreateScopeError, Credentials | HttpClient.HttpClient>;
export type CreateScopeSnapshotError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a snapshot of the current published version of the specified scope.
 */
export declare const createScopeSnapshot: API.OperationMethod<CreateScopeSnapshotInput, CreateScopeSnapshotOutput, CreateScopeSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateTemplateError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ServiceUnavailableException | TagPolicyViolationException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a template. A template groups one or more rules to simplify reuse across policies. You can also associate rules with a policy directly, without a template. Use `isPublished` to create the template in published (`ACTIVE`) or draft (`DRAFT`) state.
 */
export declare const createTemplate: API.OperationMethod<CreateTemplateInput, CreateTemplateOutput, CreateTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateTemplateSnapshotError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a snapshot of the current published version of the specified template.
 */
export declare const createTemplateSnapshot: API.OperationMethod<CreateTemplateSnapshotInput, CreateTemplateSnapshotOutput, CreateTemplateSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteAdminAccountError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the specified AWS Network Security Manager administrator account.
 */
export declare const deleteAdminAccount: API.OperationMethod<DeleteAdminAccountRequest, DeleteAdminAccountResponse, DeleteAdminAccountError, Credentials | HttpClient.HttpClient>;
export type DeleteDeploymentError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified deployment.
 */
export declare const deleteDeployment: API.OperationMethod<DeleteDeploymentInput, DeleteDeploymentResponse, DeleteDeploymentError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified policy.
 */
export declare const deletePolicy: API.OperationMethod<DeletePolicyInput, DeletePolicyResponse, DeletePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteRuleError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified rule.
 */
export declare const deleteRule: API.OperationMethod<DeleteRuleInput, DeleteRuleResponse, DeleteRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteScopeError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified scope.
 */
export declare const deleteScope: API.OperationMethod<DeleteScopeInput, DeleteScopeResponse, DeleteScopeError, Credentials | HttpClient.HttpClient>;
export type DeleteTemplateError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified template.
 */
export declare const deleteTemplate: API.OperationMethod<DeleteTemplateInput, DeleteTemplateResponse, DeleteTemplateError, Credentials | HttpClient.HttpClient>;
export type GenerateRuleConfigurationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Generates a rule configuration from a natural-language description. Provide a prompt along with the rule's firewall type and rule type. The service returns a configuration that you can use when you create or update a rule. If you also provide an existing configuration, the service edits that configuration instead of generating a new one.
 */
export declare const generateRuleConfiguration: API.OperationMethod<GenerateRuleConfigurationRequest, GenerateRuleConfigurationResponse, GenerateRuleConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetAdminAccountError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of the specified AWS Network Security Manager administrator account.
 */
export declare const getAdminAccount: API.OperationMethod<GetAdminAccountRequest, GetAdminAccountResponse, GetAdminAccountError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of the specified deployment, including coverage information and any warnings.
 */
export declare const getDeployment: API.OperationMethod<GetDeploymentInput, GetDeploymentOutput, GetDeploymentError, Credentials | HttpClient.HttpClient>;
export type GetPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of the specified policy.
 */
export declare const getPolicy: API.OperationMethod<GetPolicyInput, GetPolicyOutput, GetPolicyError, Credentials | HttpClient.HttpClient>;
export type GetRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of the specified rule.
 */
export declare const getRule: API.OperationMethod<GetRuleInput, GetRuleOutput, GetRuleError, Credentials | HttpClient.HttpClient>;
export type GetScopeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of the specified scope.
 */
export declare const getScope: API.OperationMethod<GetScopeInput, GetScopeOutput, GetScopeError, Credentials | HttpClient.HttpClient>;
export type GetTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of the specified template.
 */
export declare const getTemplate: API.OperationMethod<GetTemplateInput, GetTemplateOutput, GetTemplateError, Credentials | HttpClient.HttpClient>;
export type ListAdminAccountsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the AWS Network Security Manager administrator accounts in the organization.
 */
export declare const listAdminAccounts: API.PaginatedOperationMethod<ListAdminAccountsRequest, ListAdminAccountsResponse, ListAdminAccountsError, Credentials | HttpClient.HttpClient, AdminAccountSummary>;
export type ListAggregateResourceSynchronizationStatusesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the aggregated synchronization statuses of resources across the deployments in your administrator account. You can filter the results by synchronization status and page through them.
 */
export declare const listAggregateResourceSynchronizationStatuses: API.PaginatedOperationMethod<ListAggregateResourceSynchronizationStatusesInput, ListAggregateResourceSynchronizationStatusesOutput, ListAggregateResourceSynchronizationStatusesError, Credentials | HttpClient.HttpClient, ResourceSynchronizationStatusSummary>;
export type ListDeploymentsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the deployments in the account. You can filter the results by status and page through them using `maxResults` and `nextToken`.
 */
export declare const listDeployments: API.PaginatedOperationMethod<ListDeploymentsInput, ListDeploymentsOutput, ListDeploymentsError, Credentials | HttpClient.HttpClient, DeploymentSummary>;
export type ListDeploymentSnapshotsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the snapshots of the specified deployment.
 */
export declare const listDeploymentSnapshots: API.PaginatedOperationMethod<ListDeploymentSnapshotsInput, ListDeploymentSnapshotsOutput, ListDeploymentSnapshotsError, Credentials | HttpClient.HttpClient, DeploymentSummary>;
export type ListPoliciesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the policies in the account. You can filter the results by status and page through them using `maxResults` and `nextToken`.
 */
export declare const listPolicies: API.PaginatedOperationMethod<ListPoliciesInput, ListPoliciesOutput, ListPoliciesError, Credentials | HttpClient.HttpClient, PolicySummary>;
export type ListPolicySnapshotsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the snapshots of the specified policy.
 */
export declare const listPolicySnapshots: API.PaginatedOperationMethod<ListPolicySnapshotsInput, ListPolicySnapshotsOutput, ListPolicySnapshotsError, Credentials | HttpClient.HttpClient, PolicySummary>;
export type ListResourceAssociationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the resources associated with the specified resource.
 */
export declare const listResourceAssociations: API.PaginatedOperationMethod<ListResourceAssociationsInput, ListResourceAssociationsOutput, ListResourceAssociationsError, Credentials | HttpClient.HttpClient, ResourceAssociation>;
export type ListResourceSynchronizationStatusesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the synchronization statuses of the resources covered by the specified deployment. You can filter the results by synchronization status and page through them.
 */
export declare const listResourceSynchronizationStatuses: API.PaginatedOperationMethod<ListResourceSynchronizationStatusesInput, ListResourceSynchronizationStatusesOutput, ListResourceSynchronizationStatusesError, Credentials | HttpClient.HttpClient, ResourceSynchronizationStatusSummary>;
export type ListRulesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the rules in the account. You can filter the results by status and page through them using `maxResults` and `nextToken`.
 */
export declare const listRules: API.PaginatedOperationMethod<ListRulesInput, ListRulesOutput, ListRulesError, Credentials | HttpClient.HttpClient, RuleSummary>;
export type ListRuleSnapshotsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the snapshots of the specified rule.
 */
export declare const listRuleSnapshots: API.PaginatedOperationMethod<ListRuleSnapshotsInput, ListRuleSnapshotsOutput, ListRuleSnapshotsError, Credentials | HttpClient.HttpClient, RuleSummary>;
export type ListScopesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the scopes in the account. You can filter the results by status and page through them using `maxResults` and `nextToken`.
 */
export declare const listScopes: API.PaginatedOperationMethod<ListScopesInput, ListScopesOutput, ListScopesError, Credentials | HttpClient.HttpClient, ScopeSummary>;
export type ListScopeSnapshotsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the snapshots of the specified scope.
 */
export declare const listScopeSnapshots: API.PaginatedOperationMethod<ListScopeSnapshotsInput, ListScopeSnapshotsOutput, ListScopeSnapshotsError, Credentials | HttpClient.HttpClient, ScopeSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags associated with the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTemplatesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the templates in the account. You can filter the results by status and page through them using `maxResults` and `nextToken`.
 */
export declare const listTemplates: API.PaginatedOperationMethod<ListTemplatesInput, ListTemplatesOutput, ListTemplatesError, Credentials | HttpClient.HttpClient, TemplateSummary>;
export type ListTemplateSnapshotsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the snapshots of the specified template.
 */
export declare const listTemplateSnapshots: API.PaginatedOperationMethod<ListTemplateSnapshotsInput, ListTemplateSnapshotsOutput, ListTemplateSnapshotsError, Credentials | HttpClient.HttpClient, TemplateSummary>;
export type PutAdminAccountError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sets the AWS account that serves as an AWS Network Security Manager administrator account, and optionally configures the scope of resources that the administrator can manage.
 *
 * You can't set an administrator account again immediately after you remove it, or while the service creates its service-linked role. Retry the request after a few minutes.
 */
export declare const putAdminAccount: API.OperationMethod<PutAdminAccountRequest, PutAdminAccountResponse, PutAdminAccountError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TagPolicyViolationException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds or overwrites the specified tags on the given resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TagPolicyViolationException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the specified tags from the given resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDeploymentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified deployment. To prevent conflicting concurrent updates, provide the current `updateToken`. Use `isPublished` to publish the update or keep the deployment as a draft.
 */
export declare const updateDeployment: API.OperationMethod<UpdateDeploymentInput, UpdateDeploymentOutput, UpdateDeploymentError, Credentials | HttpClient.HttpClient>;
export type UpdatePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified policy. To prevent conflicting concurrent updates, provide the current `updateToken`. Use `isPublished` to publish the update or keep the policy as a draft.
 */
export declare const updatePolicy: API.OperationMethod<UpdatePolicyInput, UpdatePolicyOutput, UpdatePolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified rule. To prevent conflicting concurrent updates, provide the current `updateToken`. Use `isPublished` to publish the update or keep the rule as a draft.
 */
export declare const updateRule: API.OperationMethod<UpdateRuleInput, UpdateRuleOutput, UpdateRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateScopeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified scope. To prevent conflicting concurrent updates, provide the current `updateToken`. Use `isPublished` to publish the update or keep the scope as a draft.
 */
export declare const updateScope: API.OperationMethod<UpdateScopeInput, UpdateScopeOutput, UpdateScopeError, Credentials | HttpClient.HttpClient>;
export type UpdateTemplateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified template. To prevent conflicting concurrent updates, provide the current `updateToken`. Use `isPublished` to publish the update or keep the template as a draft.
 */
export declare const updateTemplate: API.OperationMethod<UpdateTemplateInput, UpdateTemplateOutput, UpdateTemplateError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=network-security-manager.d.ts.map