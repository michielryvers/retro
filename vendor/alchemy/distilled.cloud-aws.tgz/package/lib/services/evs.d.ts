import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const TagPolicyException_base: S.TaggedErrorClass<"TagPolicyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagPolicyException extends /*@__PURE__*/ TagPolicyException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ClientToken = string;
export type EnvironmentId = string;
export type AllocationId = string;
export interface AssociateEipToVlanRequest {
    clientToken?: string;
    environmentId: string;
    vlanName: string;
    allocationId: string;
}
export type VlanId = number;
export type Cidr = string;
export type SubnetId = string;
export type VlanState = "CREATING" | "CREATED" | "DELETING" | "DELETED" | "CREATE_FAILED" | (string & {});
export type StateDetails = string;
export type AssociationId = string;
export type IpAddress = string;
export interface EipAssociation {
    associationId?: string;
    allocationId?: string;
    ipAddress?: string;
}
export type EipAssociationList = EipAssociation[];
export type NetworkAclId = string;
export interface Vlan {
    vlanId?: number;
    cidr?: string;
    availabilityZone?: string;
    functionName?: string;
    subnetId?: string;
    createdAt?: Date;
    modifiedAt?: Date;
    vlanState?: VlanState;
    stateDetails?: string;
    eipAssociations?: EipAssociation[];
    isPublic?: boolean;
    networkAclId?: string;
}
export interface AssociateEipToVlanResponse {
    vlan?: Vlan;
}
export type ConnectorId = string;
export type EntitlementType = "WINDOWS_SERVER" | (string & {});
export type VmId = string;
export type VmIdList = string[];
export interface CreateEntitlementRequest {
    clientToken?: string;
    environmentId: string;
    connectorId: string;
    entitlementType: EntitlementType;
    vmIds: string[];
}
export type VmName = string;
export type EntitlementStatus = "CREATING" | "CREATED" | "DELETED" | "AT_RISK" | "ENTITLEMENT_REMOVED" | "CREATE_FAILED" | (string & {});
export interface ErrorDetail {
    errorCode: string;
    errorMessage: string;
}
export interface VmEntitlement {
    vmId?: string;
    environmentId?: string;
    connectorId?: string;
    vmName?: string;
    type?: EntitlementType;
    status?: EntitlementStatus;
    lastSyncedAt?: Date;
    startedAt?: Date;
    stoppedAt?: Date;
    errorDetail?: ErrorDetail;
}
export type VmEntitlementList = VmEntitlement[];
export interface CreateEntitlementResponse {
    entitlements?: VmEntitlement[];
}
export type EnvironmentName = string;
export type TagKey = string;
export type TagValue = string;
export type RequestTagMap = {
    [key: string]: string | undefined;
};
export type SecurityGroupId = string;
export type SecurityGroups = string[];
export interface ServiceAccessSecurityGroups {
    securityGroups?: string[];
}
export type VpcId = string;
export type VcfVersion = "VCF-5.2.1" | "VCF-5.2.2" | "SELF_DEPLOYED" | (string & {});
export interface InitialVlanInfo {
    cidr: string;
}
export interface InitialVlans {
    vmkManagement: InitialVlanInfo;
    vmManagement: InitialVlanInfo;
    vMotion: InitialVlanInfo;
    vSan: InitialVlanInfo;
    vTep: InitialVlanInfo;
    edgeVTep: InitialVlanInfo;
    nsxUplink: InitialVlanInfo;
    hcx: InitialVlanInfo;
    expansionVlan1: InitialVlanInfo;
    expansionVlan2: InitialVlanInfo;
    isHcxPublic?: boolean;
    hcxNetworkAclId?: string;
}
export type RouteServerPeering = string;
export type RouteServerPeeringList = string[];
export interface ConnectivityInfo {
    privateRouteServerPeerings: string[];
}
export type SolutionKey = string | redacted.Redacted<string>;
export type VSanLicenseKey = string | redacted.Redacted<string>;
export interface LicenseInfo {
    solutionKey: string | redacted.Redacted<string>;
    vsanKey: string | redacted.Redacted<string>;
}
export type LicenseInfoList = LicenseInfo[];
export type HostName = string;
export type KeyName = string;
export type InstanceType = "i4i.metal" | "i7i.metal-24xl" | "i7i.metal-48xl" | (string & {});
export type PlacementGroupId = string;
export type DedicatedHostId = string;
export interface HostInfoForCreate {
    hostName: string;
    keyName: string;
    instanceType: InstanceType;
    placementGroupId?: string;
    dedicatedHostId?: string;
}
export type HostInfoForCreateList = HostInfoForCreate[];
export interface VcfHostnames {
    vCenter: string;
    nsx: string;
    nsxManager1: string;
    nsxManager2: string;
    nsxManager3: string;
    nsxEdge1: string;
    nsxEdge2: string;
    sddcManager: string;
    cloudBuilder: string;
}
export interface CreateEnvironmentRequest {
    clientToken?: string;
    environmentName?: string;
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    serviceAccessSecurityGroups?: ServiceAccessSecurityGroups;
    vpcId: string;
    serviceAccessSubnetId: string;
    vcfVersion: VcfVersion;
    termsAccepted: boolean;
    initialVlans: InitialVlans;
    connectivityInfo?: ConnectivityInfo;
    licenseInfo?: LicenseInfo[];
    hosts?: HostInfoForCreate[];
    vcfHostnames?: VcfHostnames;
    siteId?: string;
}
export type EnvironmentState = "CREATING" | "CREATED" | "DELETING" | "DELETED" | "CREATE_FAILED" | (string & {});
export type Arn = string;
export type CheckResult = "PASSED" | "FAILED" | "UNKNOWN" | (string & {});
export type CheckType = "KEY_REUSE" | "KEY_COVERAGE" | "REACHABILITY" | "HOST_COUNT" | "VCENTER_REACHABILITY" | "VCENTER_VM_SYNC" | "VCENTER_VM_EVENT" | "OPERATIONS_MANAGER_REACHABILITY" | "SDDC_MANAGER_REACHABILITY" | "SDDC_MANAGER_HOST_COUNT" | "SDDC_MANAGER_KEY_COVERAGE" | "SDDC_MANAGER_KEY_REUSE" | "CONNECTOR_HEALTH" | (string & {});
export interface Check {
    type?: CheckType;
    id?: string;
    result?: CheckResult;
    impairedSince?: Date;
}
export type ChecksList = Check[];
export interface Secret {
    secretArn?: string;
}
export type SecretList = Secret[];
export interface Environment {
    environmentId?: string;
    environmentState?: EnvironmentState;
    stateDetails?: string;
    createdAt?: Date;
    modifiedAt?: Date;
    environmentArn?: string;
    environmentName?: string;
    vpcId?: string;
    serviceAccessSubnetId?: string;
    vcfVersion?: VcfVersion;
    termsAccepted?: boolean;
    licenseInfo?: LicenseInfo[];
    siteId?: string;
    environmentStatus?: CheckResult;
    checks?: Check[];
    connectivityInfo?: ConnectivityInfo;
    vcfHostnames?: VcfHostnames;
    kmsKeyId?: string;
    serviceAccessSecurityGroups?: ServiceAccessSecurityGroups;
    credentials?: Secret[];
}
export interface CreateEnvironmentResponse {
    environment?: Environment;
}
export type ConnectorType = "OPERATIONS_MANAGER" | "SDDC_MANAGER" | "VCENTER" | (string & {});
export type ApplianceFqdn = string;
export type SecretIdentifier = string;
export interface CreateEnvironmentConnectorRequest {
    clientToken?: string;
    environmentId: string;
    type: ConnectorType;
    applianceFqdn: string;
    secretIdentifier: string;
}
export type ConnectorState = "CREATING" | "CREATE_FAILED" | "ACTIVE" | "UPDATING" | "UPDATE_FAILED" | "DELETING" | "DELETED" | (string & {});
export interface ConnectorCheck {
    type?: CheckType;
    result?: CheckResult;
    lastCheckAttempt?: Date;
    impairedSince?: Date;
}
export type ConnectorsChecksList = ConnectorCheck[];
export interface Connector {
    environmentId?: string;
    connectorId?: string;
    type?: ConnectorType;
    applianceFqdn?: string;
    secretArn?: string;
    state?: ConnectorState;
    stateDetails?: string;
    status?: CheckResult;
    checks?: ConnectorCheck[];
    createdAt?: Date;
    modifiedAt?: Date;
}
export interface CreateEnvironmentConnectorResponse {
    connector?: Connector;
}
export type EsxVersion = string;
export interface CreateEnvironmentHostRequest {
    clientToken?: string;
    environmentId: string;
    host: HostInfoForCreate;
    esxVersion?: string;
}
export interface EnvironmentSummary {
    environmentId?: string;
    environmentName?: string;
    vcfVersion?: VcfVersion;
    environmentStatus?: CheckResult;
    environmentState?: EnvironmentState;
    createdAt?: Date;
    modifiedAt?: Date;
    environmentArn?: string;
}
export type HostState = "CREATING" | "CREATED" | "UPDATING" | "DELETING" | "DELETED" | "CREATE_FAILED" | "UPDATE_FAILED" | (string & {});
export type NetworkInterfaceId = string;
export interface NetworkInterface {
    networkInterfaceId?: string;
}
export type NetworkInterfaceList = NetworkInterface[];
export interface Host {
    hostName?: string;
    ipAddress?: string;
    keyName?: string;
    instanceType?: InstanceType;
    placementGroupId?: string;
    dedicatedHostId?: string;
    createdAt?: Date;
    modifiedAt?: Date;
    hostState?: HostState;
    stateDetails?: string;
    ec2InstanceId?: string;
    networkInterfaces?: NetworkInterface[];
}
export interface CreateEnvironmentHostResponse {
    environmentSummary?: EnvironmentSummary;
    host?: Host;
}
export interface DeleteEntitlementRequest {
    clientToken?: string;
    environmentId: string;
    connectorId: string;
    entitlementType: EntitlementType;
    vmIds: string[];
}
export interface DeleteEntitlementResponse {
    entitlements?: VmEntitlement[];
}
export interface DeleteEnvironmentRequest {
    clientToken?: string;
    environmentId: string;
}
export interface DeleteEnvironmentResponse {
    environment?: Environment;
}
export interface DeleteEnvironmentConnectorRequest {
    clientToken?: string;
    environmentId: string;
    connectorId: string;
}
export interface DeleteEnvironmentConnectorResponse {
    connector?: Connector;
    environmentSummary?: EnvironmentSummary;
}
export interface DeleteEnvironmentHostRequest {
    clientToken?: string;
    environmentId: string;
    hostName: string;
}
export interface DeleteEnvironmentHostResponse {
    environmentSummary?: EnvironmentSummary;
    host?: Host;
}
export interface DisassociateEipFromVlanRequest {
    clientToken?: string;
    environmentId: string;
    vlanName: string;
    associationId: string;
}
export interface DisassociateEipFromVlanResponse {
    vlan?: Vlan;
}
export interface GetAccountSettingsRequest {
}
export type SettingName = string;
export type SettingValue = string;
export interface AccountSetting {
    name: string;
    value: string;
}
export type AccountSettingList = AccountSetting[];
export interface GetAccountSettingsResponse {
    settings?: AccountSetting[];
}
export interface GetDepotUrlRequest {
    environmentId: string;
    rotate?: boolean;
}
export interface GetDepotUrlResponse {
    depotUrl: string;
    token: string;
}
export interface GetEnvironmentRequest {
    environmentId: string;
}
export interface GetEnvironmentResponse {
    environment?: Environment;
}
export interface GetVersionsRequest {
}
export type InstanceTypeList = InstanceType[];
export interface VcfVersionInfo {
    vcfVersion: VcfVersion;
    status: string;
    defaultEsxVersion: string;
    instanceTypes: InstanceType[];
}
export type VcfVersionList = VcfVersionInfo[];
export type EsxVersionList = string[];
export interface InstanceTypeEsxVersionsInfo {
    instanceType: InstanceType;
    esxVersions: string[];
}
export type InstanceTypeEsxVersionsList = InstanceTypeEsxVersionsInfo[];
export interface GetVersionsResponse {
    vcfVersions: VcfVersionInfo[];
    instanceTypeEsxVersions: InstanceTypeEsxVersionsInfo[];
}
export type PaginationToken = string;
export type MaxResults = number;
export interface ListEnvironmentConnectorsRequest {
    nextToken?: string;
    maxResults?: number;
    environmentId: string;
}
export type ConnectorList = Connector[];
export interface ListEnvironmentConnectorsResponse {
    nextToken?: string;
    connectors?: Connector[];
}
export interface ListEnvironmentHostsRequest {
    nextToken?: string;
    maxResults?: number;
    environmentId: string;
}
export type HostList = Host[];
export interface ListEnvironmentHostsResponse {
    nextToken?: string;
    environmentHosts?: Host[];
}
export type EnvironmentStateList = EnvironmentState[];
export interface ListEnvironmentsRequest {
    nextToken?: string;
    maxResults?: number;
    state?: EnvironmentState[];
}
export type EnvironmentSummaryList = EnvironmentSummary[];
export interface ListEnvironmentsResponse {
    nextToken?: string;
    environmentSummaries?: EnvironmentSummary[];
}
export interface ListEnvironmentVlansRequest {
    nextToken?: string;
    maxResults?: number;
    environmentId: string;
}
export type VlanList = Vlan[];
export interface ListEnvironmentVlansResponse {
    nextToken?: string;
    environmentVlans?: Vlan[];
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export type ResponseTagMap = {
    [key: string]: string | undefined;
};
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListVmEntitlementsRequest {
    nextToken?: string;
    maxResults?: number;
    environmentId: string;
    connectorId: string;
    entitlementType: EntitlementType;
}
export interface ListVmEntitlementsResponse {
    nextToken?: string;
    entitlements?: VmEntitlement[];
}
export interface PutAccountSettingsRequest {
    settings: AccountSetting[];
}
export interface PutAccountSettingsResponse {
    settings?: AccountSetting[];
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateEnvironmentConnectorRequest {
    clientToken?: string;
    environmentId: string;
    connectorId: string;
    applianceFqdn?: string;
    secretIdentifier?: string;
}
export interface UpdateEnvironmentConnectorResponse {
    connector?: Connector;
}
export type ValidationExceptionReason = "unknownOperation" | "cannotParse" | "fieldValidationFailed" | "other" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AssociateEipToVlanError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates an Elastic IP address with a public HCX VLAN. This operation is only allowed for public HCX VLANs at this time.
 */
export declare const associateEipToVlan: API.OperationMethod<AssociateEipToVlanRequest, AssociateEipToVlanResponse, AssociateEipToVlanError, Credentials | HttpClient.HttpClient>;
export type CreateEntitlementError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a Windows Server License entitlement for virtual machines in an Amazon EVS environment using the provided vCenter Server connector. This is an asynchronous operation. Amazon EVS validates the specified virtual machines before starting usage tracking.
 */
export declare const createEntitlement: API.OperationMethod<CreateEntitlementRequest, CreateEntitlementResponse, CreateEntitlementError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentError = ValidationException | CommonErrors;
/**
 * Creates an Amazon EVS environment that runs VCF software, such as SDDC Manager, NSX Manager, and vCenter Server.
 *
 * When you specify `SELF_DEPLOYED` for `vcfVersion`, Amazon EVS provisions only the VLAN subnets; no hosts are added and no VCF installation is performed. After the environment is created, you can add hosts with `CreateEnvironmentHost` and install VCF yourself. The `licenseInfo`, `hosts`, `vcfHostnames`, `siteId`, and `connectivityInfo` parameters are not supported in this mode.
 *
 * When you specify any other VCF version, Amazon EVS installs and configures VCF for you. For more information, see Self-deployed mode in the *Amazon EVS User Guide*.
 *
 * When Amazon EVS installs VCF, the default ESX version for the selected VCF version will be used. After a host is added with a specific ESX version, it can only be upgraded using vCenter Lifecycle Manager.
 *
 * You cannot use the `dedicatedHostId` and `placementGroupId` parameters together in the same `CreateEnvironment` action. This results in a `ValidationException` response.
 */
export declare const createEnvironment: API.OperationMethod<CreateEnvironmentRequest, CreateEnvironmentResponse, CreateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentConnectorError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a connector for an Amazon EVS environment. A connector allows the Amazon EVS control plane to interface with VCF appliances using a fully qualified domain name.
 *
 * You can create only one connector of each type per environment. For environments where Amazon EVS installs VCF, the `SDDC_MANAGER` connector is created automatically.
 *
 * Amazon EVS requires an active connector to SDDC Manager or VCF Operations Manager to monitor environment health and license compliance.
 */
export declare const createEnvironmentConnector: API.OperationMethod<CreateEnvironmentConnectorRequest, CreateEnvironmentConnectorResponse, CreateEnvironmentConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentHostError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an ESX host and adds it to an Amazon EVS environment.
 *
 * This action can only be used after the Amazon EVS environment is deployed.
 *
 * You can use the `dedicatedHostId` parameter to specify an Amazon EC2 Dedicated Host for ESX host creation.
 *
 * You can use the `placementGroupId` parameter to specify a cluster or partition placement group to launch EC2 instances into.
 *
 * If you don't specify an ESX version when adding hosts using `CreateEnvironmentHost` action, Amazon EVS automatically uses the default ESX version for your environment's VCF version. To find the available ESX versions for a particular VCF version, use the `GetVersions` action.
 *
 * You cannot use the `dedicatedHostId` and `placementGroupId` parameters together in the same `CreateEnvironmentHost` action. This results in a `ValidationException` response.
 */
export declare const createEnvironmentHost: API.OperationMethod<CreateEnvironmentHostRequest, CreateEnvironmentHostResponse, CreateEnvironmentHostError, Credentials | HttpClient.HttpClient>;
export type DeleteEntitlementError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Windows Server License entitlement for virtual machines in an Amazon EVS environment. Deleting an entitlement stops usage tracking for the specified virtual machines.
 */
export declare const deleteEntitlement: API.OperationMethod<DeleteEntitlementRequest, DeleteEntitlementResponse, DeleteEntitlementError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon EVS environment.
 *
 * Amazon EVS environments will only be enabled for deletion once the hosts are deleted. You can delete hosts using the `DeleteEnvironmentHost` action.
 *
 * Environment deletion also deletes the associated Amazon EVS VLAN subnets and Amazon Web Services Secrets Manager secrets that Amazon EVS created. Amazon Web Services resources that you create are not deleted. These resources may continue to incur costs.
 */
export declare const deleteEnvironment: API.OperationMethod<DeleteEnvironmentRequest, DeleteEnvironmentResponse, DeleteEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentConnectorError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a connector from an Amazon EVS environment.
 *
 * Before deleting a connector, you must remove all entitlements that are associated with the same vCenter.
 */
export declare const deleteEnvironmentConnector: API.OperationMethod<DeleteEnvironmentConnectorRequest, DeleteEnvironmentConnectorResponse, DeleteEnvironmentConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentHostError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a host from an Amazon EVS environment.
 *
 * Before deleting a host, you must unassign and decommission the host from within the SDDC Manager user interface. Not doing so could impact the availability of your virtual machines or result in data loss.
 */
export declare const deleteEnvironmentHost: API.OperationMethod<DeleteEnvironmentHostRequest, DeleteEnvironmentHostResponse, DeleteEnvironmentHostError, Credentials | HttpClient.HttpClient>;
export type DisassociateEipFromVlanError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates an Elastic IP address from a public HCX VLAN. This operation is only allowed for public HCX VLANs at this time.
 */
export declare const disassociateEipFromVlan: API.OperationMethod<DisassociateEipFromVlanRequest, DisassociateEipFromVlanResponse, DisassociateEipFromVlanError, Credentials | HttpClient.HttpClient>;
export type GetAccountSettingsError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the configured EVS settings for your Amazon Web Services account in the specified Amazon Web Services Region. If no settings have been set, an empty list is returned.
 */
export declare const getAccountSettings: API.OperationMethod<GetAccountSettingsRequest, GetAccountSettingsResponse, GetAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type GetDepotUrlError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a URL and authentication token for accessing the Amazon EVS Custom Addon depot. Configure the depot URL as a download source in vSphere Lifecycle Manager (vLCM) to sync and install the Amazon EVS Custom Addon.
 *
 * The depot URL remains active until you rotate the authentication token by calling this action with `rotate` set to `true`.
 */
export declare const getDepotUrl: API.OperationMethod<GetDepotUrlRequest, GetDepotUrlResponse, GetDepotUrlError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a description of the specified environment.
 */
export declare const getEnvironment: API.OperationMethod<GetEnvironmentRequest, GetEnvironmentResponse, GetEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetVersionsError = InternalServerException | ThrottlingException | CommonErrors;
/**
 * Returns information about VCF versions, ESX versions and EC2 instance types provided by Amazon EVS. For each VCF version, the response also includes the default ESX version and provided EC2 instance types.
 */
export declare const getVersions: API.OperationMethod<GetVersionsRequest, GetVersionsResponse, GetVersionsError, Credentials | HttpClient.HttpClient>;
export type ListEnvironmentConnectorsError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the connectors within an environment. Returns the status of each connector and its applicable checks, among other connector details.
 */
export declare const listEnvironmentConnectors: API.PaginatedOperationMethod<ListEnvironmentConnectorsRequest, ListEnvironmentConnectorsResponse, ListEnvironmentConnectorsError, Credentials | HttpClient.HttpClient, Connector>;
export type ListEnvironmentHostsError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List the hosts within an environment.
 */
export declare const listEnvironmentHosts: API.PaginatedOperationMethod<ListEnvironmentHostsRequest, ListEnvironmentHostsResponse, ListEnvironmentHostsError, Credentials | HttpClient.HttpClient, Host>;
export type ListEnvironmentsError = ValidationException | CommonErrors;
/**
 * Lists the Amazon EVS environments in your Amazon Web Services account in the specified Amazon Web Services Region.
 */
export declare const listEnvironments: API.PaginatedOperationMethod<ListEnvironmentsRequest, ListEnvironmentsResponse, ListEnvironmentsError, Credentials | HttpClient.HttpClient, EnvironmentSummary>;
export type ListEnvironmentVlansError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists environment VLANs that are associated with the specified environment.
 */
export declare const listEnvironmentVlans: API.PaginatedOperationMethod<ListEnvironmentVlansRequest, ListEnvironmentVlansResponse, ListEnvironmentVlansError, Credentials | HttpClient.HttpClient, Vlan>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Lists the tags for an Amazon EVS resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVmEntitlementsError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the Windows Server License entitlements for virtual machines in an Amazon EVS environment. Returns existing entitlements for virtual machines associated with the specified environment and connector.
 */
export declare const listVmEntitlements: API.PaginatedOperationMethod<ListVmEntitlementsRequest, ListVmEntitlementsResponse, ListVmEntitlementsError, Credentials | HttpClient.HttpClient, VmEntitlement>;
export type PutAccountSettingsError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates account-level EVS settings for your Amazon Web Services account in the specified Amazon Web Services Region.
 *
 * EVS settings included in the request are created or overwritten. Settings omitted from the request retain their current values.
 */
export declare const putAccountSettings: API.OperationMethod<PutAccountSettingsRequest, PutAccountSettingsResponse, PutAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | ServiceQuotaExceededException | TagPolicyException | TooManyTagsException | CommonErrors;
/**
 * Associates the specified tags to an Amazon EVS resource with the specified `resourceArn`. If existing tags on a resource are not specified in the request parameters, they aren't changed. When a resource is deleted, the tags associated with that resource are also deleted. Tags that you create for Amazon EVS resources don't propagate to any other resources associated with the environment. For example, if you tag an environment with this operation, that tag doesn't automatically propagate to the VLAN subnets and hosts associated with the environment.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | TagPolicyException | CommonErrors;
/**
 * Deletes specified tags from an Amazon EVS resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentConnectorError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a connector for an Amazon EVS environment. You can update the Amazon Web Services Secrets Manager secret ARN or the appliance FQDN to reconfigure the connector metadata.
 *
 * You cannot update both the secret and the FQDN in the same request.
 */
export declare const updateEnvironmentConnector: API.OperationMethod<UpdateEnvironmentConnectorRequest, UpdateEnvironmentConnectorResponse, UpdateEnvironmentConnectorError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=evs.d.ts.map