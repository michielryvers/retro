import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly Name: any;
    readonly Value: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly FieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export interface AssociateDefaultViewInput {
    ViewArn: string;
}
export interface AssociateDefaultViewOutput {
    ViewArn?: string;
}
export type ViewArnList = string[];
export interface BatchGetViewInput {
    ViewArns?: string[];
}
export type ViewName = string;
export interface IncludedProperty {
    Name: string;
}
export type IncludedPropertyList = IncludedProperty[];
export interface SearchFilter {
    FilterString: string;
}
export interface View {
    ViewArn?: string;
    ViewName?: string;
    Owner?: string;
    LastUpdatedAt?: Date;
    Scope?: string;
    IncludedProperties?: IncludedProperty[];
    Filters?: SearchFilter;
}
export type ViewList = View[];
export interface BatchGetViewError_ {
    ViewArn: string;
    ErrorMessage: string;
}
export type BatchGetViewErrors = BatchGetViewError_[];
export interface BatchGetViewOutput {
    Views?: View[];
    Errors?: BatchGetViewError_[];
}
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateIndexInput {
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type IndexState = string;
export interface CreateIndexOutput {
    Arn?: string;
    State?: string;
    CreatedAt?: Date;
}
export type RegionList = string[];
export interface CreateResourceExplorerSetupInput {
    RegionList: string[];
    AggregatorRegions?: string[];
    ViewName: string;
}
export interface CreateResourceExplorerSetupOutput {
    TaskId: string;
}
export interface CreateViewInput {
    ClientToken?: string;
    ViewName: string;
    IncludedProperties?: IncludedProperty[];
    Scope?: string;
    Filters?: SearchFilter;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateViewOutput {
    View?: View;
}
export interface DeleteIndexInput {
    Arn: string;
}
export interface DeleteIndexOutput {
    Arn?: string;
    State?: string;
    LastUpdatedAt?: Date;
}
export interface DeleteResourceExplorerSetupInput {
    RegionList?: string[];
    DeleteInAllRegions?: boolean;
}
export interface DeleteResourceExplorerSetupOutput {
    TaskId: string;
}
export interface DeleteViewInput {
    ViewArn: string;
}
export interface DeleteViewOutput {
    ViewArn?: string;
}
export interface DisassociateDefaultViewRequest {
}
export interface DisassociateDefaultViewResponse {
}
export interface GetAccountLevelServiceConfigurationRequest {
}
export type AWSServiceAccessStatus = string;
export interface OrgConfiguration {
    AWSServiceAccessStatus: string;
    ServiceLinkedRole?: string;
}
export interface GetAccountLevelServiceConfigurationOutput {
    OrgConfiguration?: OrgConfiguration;
}
export interface GetDefaultViewRequest {
}
export interface GetDefaultViewOutput {
    ViewArn?: string;
}
export interface GetIndexRequest {
}
export type IndexType = string;
export interface GetIndexOutput {
    Arn?: string;
    Type?: string;
    State?: string;
    ReplicatingFrom?: string[];
    ReplicatingTo?: string[];
    CreatedAt?: Date;
    LastUpdatedAt?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetManagedViewInput {
    ManagedViewArn: string;
}
export interface ManagedView {
    ManagedViewArn?: string;
    ManagedViewName?: string;
    TrustedService?: string;
    LastUpdatedAt?: Date;
    Owner?: string;
    Scope?: string;
    IncludedProperties?: IncludedProperty[];
    Filters?: SearchFilter;
    ResourcePolicy?: string;
    Version?: string;
}
export interface GetManagedViewOutput {
    ManagedView?: ManagedView;
}
export interface GetResourceExplorerSetupInput {
    TaskId: string;
    MaxResults?: number;
    NextToken?: string;
}
export type OperationStatus = string;
export interface Index {
    Region?: string;
    Arn?: string;
    Type?: string;
}
export interface ErrorDetails {
    Code?: string;
    Message?: string;
}
export interface IndexStatus {
    Status?: string;
    Index?: Index;
    ErrorDetails?: ErrorDetails;
}
export interface ViewStatus {
    Status?: string;
    View?: View;
    ErrorDetails?: ErrorDetails;
}
export interface RegionStatus {
    Region?: string;
    Index?: IndexStatus;
    View?: ViewStatus;
}
export type RegionStatusList = RegionStatus[];
export interface GetResourceExplorerSetupOutput {
    Regions?: RegionStatus[];
    NextToken?: string;
}
export interface GetServiceIndexRequest {
}
export interface GetServiceIndexOutput {
    Arn?: string;
    Type?: string;
}
export interface GetServiceViewInput {
    ServiceViewArn: string;
}
export type ServiceViewName = string;
export type RecorderType = string;
export interface ServiceLinkedRecorderInfo {
    ServicePrincipal?: string;
    RecorderName?: string;
    RecorderType?: string;
}
export interface ServiceView {
    ServiceViewArn: string;
    ServiceViewName?: string;
    Filters?: SearchFilter;
    IncludedProperties?: IncludedProperty[];
    StreamingAccessForService?: string;
    ScopeType?: string;
    ServiceLinkedRecorder?: ServiceLinkedRecorderInfo;
}
export interface GetServiceViewOutput {
    View: ServiceView;
}
export interface GetViewInput {
    ViewArn: string;
}
export interface GetViewOutput {
    View?: View;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListIndexesInput {
    Type?: string;
    Regions?: string[];
    MaxResults?: number;
    NextToken?: string;
}
export type IndexList = Index[];
export interface ListIndexesOutput {
    Indexes?: Index[];
    NextToken?: string;
}
export type AccountId = string;
export type AccountIdList = string[];
export interface ListIndexesForMembersInput {
    AccountIdList: string[];
    MaxResults?: number;
    NextToken?: string;
}
export interface MemberIndex {
    AccountId?: string;
    Region?: string;
    Arn?: string;
    Type?: string;
}
export type MemberIndexList = MemberIndex[];
export interface ListIndexesForMembersOutput {
    Indexes?: MemberIndex[];
    NextToken?: string;
}
export interface ListManagedViewsInput {
    MaxResults?: number;
    NextToken?: string;
    ServicePrincipal?: string;
}
export type ManagedViewArnList = string[];
export interface ListManagedViewsOutput {
    NextToken?: string;
    ManagedViews?: string[];
}
export interface ListResourcesInput {
    Filters?: SearchFilter;
    MaxResults?: number;
    ViewArn?: string;
    NextToken?: string;
}
export interface ResourceProperty {
    Name?: string;
    LastReportedAt?: Date;
    Data?: any;
}
export type ResourcePropertyList = ResourceProperty[];
export interface Resource {
    Arn?: string;
    OwningAccountId?: string;
    Region?: string;
    ResourceType?: string;
    Service?: string;
    CfnResourceType?: string;
    LastReportedAt?: Date;
    Properties?: ResourceProperty[];
}
export type ResourceList = Resource[];
export interface ListResourcesOutput {
    Resources?: Resource[];
    NextToken?: string;
    ViewArn?: string;
}
export interface ListServiceIndexesInput {
    Regions?: string[];
    MaxResults?: number;
    NextToken?: string;
}
export interface ListServiceIndexesOutput {
    Indexes?: Index[];
    NextToken?: string;
}
export interface ListServiceViewsInput {
    MaxResults?: number;
    NextToken?: string;
}
export type ServiceViewArnList = string[];
export interface ListServiceViewsOutput {
    NextToken?: string;
    ServiceViews?: string[];
}
export interface ListStreamingAccessForServicesInput {
    MaxResults?: number;
    NextToken?: string;
}
export interface StreamingAccessDetails {
    ServicePrincipal: string;
    CreatedAt: Date;
}
export type StreamingAccessDetailsList = StreamingAccessDetails[];
export interface ListStreamingAccessForServicesOutput {
    StreamingAccessForServices: StreamingAccessDetails[];
    NextToken?: string;
}
export interface ListSupportedResourceTypesInput {
    NextToken?: string;
    MaxResults?: number;
}
export type CFNResourceTypeList = string[];
export interface SupportedResourceType {
    Service?: string;
    ResourceType?: string;
    CFNResourceTypes?: string[];
}
export type ResourceTypeList = SupportedResourceType[];
export interface ListSupportedResourceTypesOutput {
    ResourceTypes?: SupportedResourceType[];
    NextToken?: string;
}
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListViewsInput {
    NextToken?: string;
    MaxResults?: number;
}
export interface ListViewsOutput {
    Views?: string[];
    NextToken?: string;
}
export type QueryString = string | redacted.Redacted<string>;
export interface SearchInput {
    QueryString: string | redacted.Redacted<string>;
    MaxResults?: number;
    ViewArn?: string;
    NextToken?: string;
}
export interface ResourceCount {
    TotalResources?: number;
    Complete?: boolean;
}
export interface SearchOutput {
    Resources?: Resource[];
    NextToken?: string;
    ViewArn?: string;
    Count?: ResourceCount;
}
export interface TagResourceInput {
    resourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type StringList = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateIndexTypeInput {
    Arn: string;
    Type: string;
}
export interface UpdateIndexTypeOutput {
    Arn?: string;
    Type?: string;
    State?: string;
    LastUpdatedAt?: Date;
}
export interface UpdateViewInput {
    ViewArn: string;
    IncludedProperties?: IncludedProperty[];
    Filters?: SearchFilter;
}
export interface UpdateViewOutput {
    View?: View;
}
export interface ValidationExceptionField {
    Name: string;
    ValidationIssue: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AssociateDefaultViewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sets the specified view as the default for the Amazon Web Services Region in which you call this operation. When a user performs a Search that doesn't explicitly specify which view to use, then Amazon Web Services Resource Explorer automatically chooses this default view for searches performed in this Amazon Web Services Region.
 *
 * If an Amazon Web Services Region doesn't have a default view configured, then users must explicitly specify a view with every `Search` operation performed in that Region.
 */
export declare const associateDefaultView: API.OperationMethod<AssociateDefaultViewInput, AssociateDefaultViewOutput, AssociateDefaultViewError, Credentials | HttpClient.HttpClient>;
export type BatchGetViewError = AccessDeniedException | InternalServerException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves details about a list of views.
 */
export declare const batchGetView: API.OperationMethod<BatchGetViewInput, BatchGetViewOutput, BatchGetViewError, Credentials | HttpClient.HttpClient>;
export type CreateIndexError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Turns on Amazon Web Services Resource Explorer in the Amazon Web Services Region in which you called this operation by creating an index. Resource Explorer begins discovering the resources in this Region and stores the details about the resources in the index so that they can be queried by using the Search operation. You can create only one index in a Region.
 *
 * This operation creates only a *local* index. To promote the local index in one Amazon Web Services Region into the aggregator index for the Amazon Web Services account, use the UpdateIndexType operation. For more information, see Turning on cross-Region search by creating an aggregator index in the *Amazon Web Services Resource Explorer User Guide*.
 *
 * For more details about what happens when you turn on Resource Explorer in an Amazon Web Services Region, see Turn on Resource Explorer to index your resources in an Amazon Web Services Region in the *Amazon Web Services Resource Explorer User Guide*.
 *
 * If this is the first Amazon Web Services Region in which you've created an index for Resource Explorer, then this operation also creates a service-linked role in your Amazon Web Services account that allows Resource Explorer to enumerate your resources to populate the index.
 *
 * - **Action**: `resource-explorer-2:CreateIndex`
 *
 * **Resource**: The ARN of the index (as it will exist after the operation completes) in the Amazon Web Services Region and account in which you're trying to create the index. Use the wildcard character (`*`) at the end of the string to match the eventual UUID. For example, the following `Resource` element restricts the role or user to creating an index in only the `us-east-2` Region of the specified account.
 *
 * `"Resource": "arn:aws:resource-explorer-2:us-west-2:*<account-id>*:index/*"`
 *
 * Alternatively, you can use `"Resource": "*"` to allow the role or user to create an index in any Region.
 *
 * - **Action**: `iam:CreateServiceLinkedRole`
 *
 * **Resource**: No specific resource (*).
 *
 * This permission is required only the first time you create an index to turn on Resource Explorer in the account. Resource Explorer uses this to create the service-linked role needed to index the resources in your account. Resource Explorer uses the same service-linked role for all additional indexes you create afterwards.
 */
export declare const createIndex: API.OperationMethod<CreateIndexInput, CreateIndexOutput, CreateIndexError, Credentials | HttpClient.HttpClient>;
export type CreateResourceExplorerSetupError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a Resource Explorer setup configuration across multiple Amazon Web Services Regions. This operation sets up indexes and views in the specified Regions. This operation can also be used to set an aggregator Region for cross-Region resource search.
 */
export declare const createResourceExplorerSetup: API.OperationMethod<CreateResourceExplorerSetupInput, CreateResourceExplorerSetupOutput, CreateResourceExplorerSetupError, Credentials | HttpClient.HttpClient>;
export type CreateViewError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates a view that users can query by using the Search operation. Results from queries that you make using this view include only resources that match the view's `Filters`. For more information about Amazon Web Services Resource Explorer views, see Managing views in the *Amazon Web Services Resource Explorer User Guide*.
 *
 * Only the principals with an IAM identity-based policy that grants `Allow` to the `Search` action on a `Resource` with the Amazon resource name (ARN) of this view can Search using views you create with this operation.
 */
export declare const createView: API.OperationMethod<CreateViewInput, CreateViewOutput, CreateViewError, Credentials | HttpClient.HttpClient>;
export type DeleteIndexError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified index and turns off Amazon Web Services Resource Explorer in the specified Amazon Web Services Region. When you delete an index, Resource Explorer stops discovering and indexing resources in that Region. Resource Explorer also deletes all views in that Region. These actions occur as asynchronous background tasks. You can check to see when the actions are complete by using the GetIndex operation and checking the `Status` response value.
 *
 * If the index you delete is the aggregator index for the Amazon Web Services account, you must wait 24 hours before you can promote another local index to be the aggregator index for the account. Users can't perform account-wide searches using Resource Explorer until another aggregator index is configured.
 */
export declare const deleteIndex: API.OperationMethod<DeleteIndexInput, DeleteIndexOutput, DeleteIndexError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceExplorerSetupError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Resource Explorer setup configuration. This operation removes indexes and views from the specified Regions or all Regions where Resource Explorer is configured.
 */
export declare const deleteResourceExplorerSetup: API.OperationMethod<DeleteResourceExplorerSetupInput, DeleteResourceExplorerSetupOutput, DeleteResourceExplorerSetupError, Credentials | HttpClient.HttpClient>;
export type DeleteViewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deletes the specified view.
 *
 * If the specified view is the default view for its Amazon Web Services Region, then all Search operations in that Region must explicitly specify the view to use until you configure a new default by calling the AssociateDefaultView operation.
 */
export declare const deleteView: API.OperationMethod<DeleteViewInput, DeleteViewOutput, DeleteViewError, Credentials | HttpClient.HttpClient>;
export type DisassociateDefaultViewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * After you call this operation, the affected Amazon Web Services Region no longer has a default view. All Search operations in that Region must explicitly specify a view or the operation fails. You can configure a new default by calling the AssociateDefaultView operation.
 *
 * If an Amazon Web Services Region doesn't have a default view configured, then users must explicitly specify a view with every `Search` operation performed in that Region.
 */
export declare const disassociateDefaultView: API.OperationMethod<DisassociateDefaultViewRequest, DisassociateDefaultViewResponse, DisassociateDefaultViewError, Credentials | HttpClient.HttpClient>;
export type GetAccountLevelServiceConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the status of your account's Amazon Web Services service access, and validates the service linked role required to access the multi-account search feature. Only the management account can invoke this API call.
 */
export declare const getAccountLevelServiceConfiguration: API.OperationMethod<GetAccountLevelServiceConfigurationRequest, GetAccountLevelServiceConfigurationOutput, GetAccountLevelServiceConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetDefaultViewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the Amazon Resource Name (ARN) of the view that is the default for the Amazon Web Services Region in which you call this operation. You can then call GetView to retrieve the details of that view.
 */
export declare const getDefaultView: API.OperationMethod<GetDefaultViewRequest, GetDefaultViewOutput, GetDefaultViewError, Credentials | HttpClient.HttpClient>;
export type GetIndexError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about the Amazon Web Services Resource Explorer index in the Amazon Web Services Region in which you invoked the operation.
 */
export declare const getIndex: API.OperationMethod<GetIndexRequest, GetIndexOutput, GetIndexError, Credentials | HttpClient.HttpClient>;
export type GetManagedViewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves details of the specified Amazon Web Services-managed view.
 */
export declare const getManagedView: API.OperationMethod<GetManagedViewInput, GetManagedViewOutput, GetManagedViewError, Credentials | HttpClient.HttpClient>;
export type GetResourceExplorerSetupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the status and details of a Resource Explorer setup operation. This operation returns information about the progress of creating or deleting Resource Explorer configurations across Regions.
 */
export declare const getResourceExplorerSetup: API.PaginatedOperationMethod<GetResourceExplorerSetupInput, GetResourceExplorerSetupOutput, GetResourceExplorerSetupError, Credentials | HttpClient.HttpClient, RegionStatus>;
export type GetServiceIndexError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the Resource Explorer index in the current Amazon Web Services Region. This operation returns the ARN and type of the index if one exists.
 */
export declare const getServiceIndex: API.OperationMethod<GetServiceIndexRequest, GetServiceIndexOutput, GetServiceIndexError, Credentials | HttpClient.HttpClient>;
export type GetServiceViewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about a specific Resource Explorer service view. This operation returns the configuration and properties of the specified view.
 */
export declare const getServiceView: API.OperationMethod<GetServiceViewInput, GetServiceViewOutput, GetServiceViewError, Credentials | HttpClient.HttpClient>;
export type GetViewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves details of the specified view.
 */
export declare const getView: API.OperationMethod<GetViewInput, GetViewOutput, GetViewError, Credentials | HttpClient.HttpClient>;
export type ListIndexesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of all of the indexes in Amazon Web Services Regions that are currently collecting resource information for Amazon Web Services Resource Explorer.
 */
export declare const listIndexes: API.PaginatedOperationMethod<ListIndexesInput, ListIndexesOutput, ListIndexesError, Credentials | HttpClient.HttpClient, Index>;
export type ListIndexesForMembersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of a member's indexes in all Amazon Web Services Regions that are currently collecting resource information for Amazon Web Services Resource Explorer. Only the management account or a delegated administrator with service access enabled can invoke this API call.
 */
export declare const listIndexesForMembers: API.PaginatedOperationMethod<ListIndexesForMembersInput, ListIndexesForMembersOutput, ListIndexesForMembersError, Credentials | HttpClient.HttpClient, MemberIndex>;
export type ListManagedViewsError = AccessDeniedException | InternalServerException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists the Amazon resource names (ARNs) of the Amazon Web Services-managed views available in the Amazon Web Services Region in which you call this operation.
 */
export declare const listManagedViews: API.PaginatedOperationMethod<ListManagedViewsInput, ListManagedViewsOutput, ListManagedViewsError, Credentials | HttpClient.HttpClient, string>;
export type ListResourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Returns a list of resources and their details that match the specified criteria. This query must use a view. If you don't explicitly specify a view, then Resource Explorer uses the default view for the Amazon Web Services Region in which you call this operation.
 */
export declare const listResources: API.PaginatedOperationMethod<ListResourcesInput, ListResourcesOutput, ListResourcesError, Credentials | HttpClient.HttpClient, Resource>;
export type ListServiceIndexesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all Resource Explorer indexes across the specified Amazon Web Services Regions. This operation returns information about indexes including their ARNs, types, and Regions.
 */
export declare const listServiceIndexes: API.PaginatedOperationMethod<ListServiceIndexesInput, ListServiceIndexesOutput, ListServiceIndexesError, Credentials | HttpClient.HttpClient, Index>;
export type ListServiceViewsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all Resource Explorer service views available in the current Amazon Web Services account. This operation returns the ARNs of available service views.
 */
export declare const listServiceViews: API.PaginatedOperationMethod<ListServiceViewsInput, ListServiceViewsOutput, ListServiceViewsError, Credentials | HttpClient.HttpClient, string>;
export type ListStreamingAccessForServicesError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of Amazon Web Services services that have been granted streaming access to your Resource Explorer data. Streaming access allows Amazon Web Services services to receive real-time updates about your resources as they are indexed by Resource Explorer.
 */
export declare const listStreamingAccessForServices: API.PaginatedOperationMethod<ListStreamingAccessForServicesInput, ListStreamingAccessForServicesOutput, ListStreamingAccessForServicesError, Credentials | HttpClient.HttpClient, StreamingAccessDetails>;
export type ListSupportedResourceTypesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of all resource types currently supported by Amazon Web Services Resource Explorer.
 */
export declare const listSupportedResourceTypes: API.PaginatedOperationMethod<ListSupportedResourceTypesInput, ListSupportedResourceTypesOutput, ListSupportedResourceTypesError, Credentials | HttpClient.HttpClient, SupportedResourceType>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists the tags that are attached to the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListViewsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the Amazon resource names (ARNs) of the views available in the Amazon Web Services Region in which you call this operation.
 *
 * Always check the `NextToken` response parameter for a `null` value when calling a paginated operation. These operations can occasionally return an empty set of results even when there are more results available. The `NextToken` response parameter value is `null` *only* when there are no more results to display.
 */
export declare const listViews: API.PaginatedOperationMethod<ListViewsInput, ListViewsOutput, ListViewsError, Credentials | HttpClient.HttpClient, string>;
export type SearchError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Searches for resources and displays details about all resources that match the specified criteria. You must specify a query string.
 *
 * All search queries must use a view. If you don't explicitly specify a view, then Amazon Web Services Resource Explorer uses the default view for the Amazon Web Services Region in which you call this operation. The results are the logical intersection of the results that match both the `QueryString` parameter supplied to this operation and the `SearchFilter` parameter attached to the view.
 *
 * For the complete syntax supported by the `QueryString` parameter, see Search query syntax reference for Resource Explorer.
 *
 * If your search results are empty, or are missing results that you think should be there, see Troubleshooting Resource Explorer search.
 */
export declare const search: API.PaginatedOperationMethod<SearchInput, SearchOutput, SearchError, Credentials | HttpClient.HttpClient, Resource>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Adds one or more tag key and value pairs to an Amazon Web Services Resource Explorer view or index.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Removes one or more tag key and value pairs from an Amazon Web Services Resource Explorer view or index.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateIndexTypeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Changes the type of the index from one of the following types to the other. For more information about indexes and the role they perform in Amazon Web Services Resource Explorer, see Turning on cross-Region search by creating an aggregator index in the *Amazon Web Services Resource Explorer User Guide*.
 *
 * - ** `AGGREGATOR` index type**
 *
 * The index contains information about resources from all Amazon Web Services Regions in the Amazon Web Services account in which you've created a Resource Explorer index. Resource information from all other Regions is replicated to this Region's index.
 *
 * When you change the index type to `AGGREGATOR`, Resource Explorer turns on replication of all discovered resource information from the other Amazon Web Services Regions in your account to this index. You can then, from this Region only, perform resource search queries that span all Amazon Web Services Regions in the Amazon Web Services account. Turning on replication from all other Regions is performed by asynchronous background tasks. You can check the status of the asynchronous tasks by using the GetIndex operation. When the asynchronous tasks complete, the `Status` response of that operation changes from `UPDATING` to `ACTIVE`. After that, you can start to see results from other Amazon Web Services Regions in query results. However, it can take several hours for replication from all other Regions to complete.
 *
 * You can have only one aggregator index per Amazon Web Services account. Before you can promote a different index to be the aggregator index for the account, you must first demote the existing aggregator index to type `LOCAL`.
 *
 * - ** `LOCAL` index type**
 *
 * The index contains information about resources in only the Amazon Web Services Region in which the index exists. If an aggregator index in another Region exists, then information in this local index is replicated to the aggregator index.
 *
 * When you change the index type to `LOCAL`, Resource Explorer turns off the replication of resource information from all other Amazon Web Services Regions in the Amazon Web Services account to this Region. The aggregator index remains in the `UPDATING` state until all replication with other Regions successfully stops. You can check the status of the asynchronous task by using the GetIndex operation. When Resource Explorer successfully stops all replication with other Regions, the `Status` response of that operation changes from `UPDATING` to `ACTIVE`. Separately, the resource information from other Regions that was previously stored in the index is deleted within 30 days by another background task. Until that asynchronous task completes, some results from other Regions can continue to appear in search results.
 *
 * After you demote an aggregator index to a local index, you must wait 24 hours before you can promote another index to be the new aggregator index for the account.
 */
export declare const updateIndexType: API.OperationMethod<UpdateIndexTypeInput, UpdateIndexTypeOutput, UpdateIndexTypeError, Credentials | HttpClient.HttpClient>;
export type UpdateViewError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Modifies some of the details of a view. You can change the filter string and the list of included properties. You can't change the name of the view.
 */
export declare const updateView: API.OperationMethod<UpdateViewInput, UpdateViewOutput, UpdateViewError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=resource-explorer-2.d.ts.map