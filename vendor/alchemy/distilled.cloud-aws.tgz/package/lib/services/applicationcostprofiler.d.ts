import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ReportId = string;
export interface DeleteReportDefinitionRequest {
    reportId: string;
}
export interface DeleteReportDefinitionResult {
    reportId?: string;
}
export interface GetReportDefinitionRequest {
    reportId: string;
}
export type ReportDescription = string;
export type ReportFrequency = "MONTHLY" | "DAILY" | "ALL" | (string & {});
export type Format = "CSV" | "PARQUET" | (string & {});
export type S3Bucket = string;
export type S3Prefix = string;
export interface S3Location {
    bucket: string;
    prefix: string;
}
export interface GetReportDefinitionResult {
    reportId: string;
    reportDescription: string;
    reportFrequency: ReportFrequency;
    format: Format;
    destinationS3Location: S3Location;
    createdAt: Date;
    lastUpdated: Date;
}
export type S3Key = string;
export type S3BucketRegion = "ap-east-1" | "me-south-1" | "eu-south-1" | "af-south-1" | (string & {});
export interface SourceS3Location {
    bucket: string;
    key: string;
    region?: S3BucketRegion;
}
export interface ImportApplicationUsageRequest {
    sourceS3Location: SourceS3Location;
}
export type ImportId = string;
export interface ImportApplicationUsageResult {
    importId: string;
}
export type Token = string;
export interface ListReportDefinitionsRequest {
    nextToken?: string;
    maxResults?: number;
}
export interface ReportDefinition {
    reportId?: string;
    reportDescription?: string;
    reportFrequency?: ReportFrequency;
    format?: Format;
    destinationS3Location?: S3Location;
    createdAt?: Date;
    lastUpdatedAt?: Date;
}
export type ReportDefinitionList = ReportDefinition[];
export interface ListReportDefinitionsResult {
    reportDefinitions?: ReportDefinition[];
    nextToken?: string;
}
export interface PutReportDefinitionRequest {
    reportId: string;
    reportDescription: string;
    reportFrequency: ReportFrequency;
    format: Format;
    destinationS3Location: S3Location;
}
export interface PutReportDefinitionResult {
    reportId?: string;
}
export interface UpdateReportDefinitionRequest {
    reportId: string;
    reportDescription: string;
    reportFrequency: ReportFrequency;
    format: Format;
    destinationS3Location: S3Location;
}
export interface UpdateReportDefinitionResult {
    reportId?: string;
}
export type ErrorMessage = string;
export type DeleteReportDefinitionError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified report definition in AWS Application Cost Profiler. This stops the report from being
 * generated.
 */
export declare const deleteReportDefinition: API.OperationMethod<DeleteReportDefinitionRequest, DeleteReportDefinitionResult, DeleteReportDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetReportDefinitionError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the definition of a report already configured in AWS Application Cost Profiler.
 */
export declare const getReportDefinition: API.OperationMethod<GetReportDefinitionRequest, GetReportDefinitionResult, GetReportDefinitionError, Credentials | HttpClient.HttpClient>;
export type ImportApplicationUsageError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Ingests application usage data from Amazon Simple Storage Service (Amazon S3).
 *
 * The data must already exist in the S3 location. As part of the action, AWS Application Cost Profiler
 * copies the object from your S3 bucket to an S3 bucket owned by Amazon for processing
 * asynchronously.
 */
export declare const importApplicationUsage: API.OperationMethod<ImportApplicationUsageRequest, ImportApplicationUsageResult, ImportApplicationUsageError, Credentials | HttpClient.HttpClient>;
export type ListReportDefinitionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of all reports and their configurations for your AWS account.
 *
 * The maximum number of reports is one.
 */
export declare const listReportDefinitions: API.PaginatedOperationMethod<ListReportDefinitionsRequest, ListReportDefinitionsResult, ListReportDefinitionsError, Credentials | HttpClient.HttpClient, ReportDefinition>;
export type PutReportDefinitionError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates the report definition for a report in Application Cost Profiler.
 */
export declare const putReportDefinition: API.OperationMethod<PutReportDefinitionRequest, PutReportDefinitionResult, PutReportDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateReportDefinitionError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates existing report in AWS Application Cost Profiler.
 */
export declare const updateReportDefinition: API.OperationMethod<UpdateReportDefinitionRequest, UpdateReportDefinitionResult, UpdateReportDefinitionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=applicationcostprofiler.d.ts.map