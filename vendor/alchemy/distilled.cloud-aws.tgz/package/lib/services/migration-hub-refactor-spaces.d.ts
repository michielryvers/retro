import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidResourcePolicyException_base: S.TaggedErrorClass<"InvalidResourcePolicyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidResourcePolicyException extends /*@__PURE__*/ InvalidResourcePolicyException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
    readonly QuotaCode: any;
    readonly ServiceCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly QuotaCode: any;
    readonly ServiceCode: any;
    readonly RetryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ApplicationName = string;
export type EnvironmentId = string;
export type VpcId = string;
export type ProxyType = string;
export type ApiGatewayEndpointType = string;
export type StageName = string;
export interface ApiGatewayProxyInput {
    EndpointType?: string;
    StageName?: string;
}
export type TagMap = {
    [key: string]: string | undefined;
};
export type ClientToken = string;
export interface CreateApplicationRequest {
    Name: string;
    EnvironmentIdentifier: string;
    VpcId: string;
    ProxyType: string;
    ApiGatewayProxy?: ApiGatewayProxyInput;
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
}
export type ResourceArn = string;
export type AccountId = string;
export type ApplicationId = string;
export type ApplicationState = string;
export interface CreateApplicationResponse {
    Name?: string;
    Arn?: string;
    OwnerAccountId?: string;
    CreatedByAccountId?: string;
    ApplicationId?: string;
    EnvironmentId?: string;
    VpcId?: string;
    ProxyType?: string;
    ApiGatewayProxy?: ApiGatewayProxyInput;
    State?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    LastUpdatedTime?: Date;
    CreatedTime?: Date;
}
export type EnvironmentName = string;
export type Description = string;
export type NetworkFabricType = string;
export interface CreateEnvironmentRequest {
    Name: string;
    Description?: string;
    NetworkFabricType: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
}
export type EnvironmentState = string;
export interface CreateEnvironmentResponse {
    Name?: string;
    Arn?: string;
    Description?: string;
    EnvironmentId?: string;
    NetworkFabricType?: string;
    OwnerAccountId?: string;
    State?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    LastUpdatedTime?: Date;
    CreatedTime?: Date;
}
export type ServiceId = string;
export type RouteType = string;
export type RouteActivationState = string;
export interface DefaultRouteInput {
    ActivationState?: string;
}
export type UriPath = string;
export type HttpMethod = string;
export type HttpMethods = string[];
export interface UriPathRouteInput {
    SourcePath: string;
    ActivationState: string;
    Methods?: string[];
    IncludeChildPaths?: boolean;
    AppendSourcePath?: boolean;
}
export interface CreateRouteRequest {
    EnvironmentIdentifier: string;
    ApplicationIdentifier: string;
    ServiceIdentifier: string;
    RouteType: string;
    DefaultRoute?: DefaultRouteInput;
    UriPathRoute?: UriPathRouteInput;
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
}
export type RouteId = string;
export type RouteState = string;
export interface CreateRouteResponse {
    RouteId?: string;
    Arn?: string;
    OwnerAccountId?: string;
    CreatedByAccountId?: string;
    RouteType?: string;
    ServiceId?: string;
    ApplicationId?: string;
    UriPathRoute?: UriPathRouteInput;
    State?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    LastUpdatedTime?: Date;
    CreatedTime?: Date;
}
export type ServiceName = string;
export type ServiceEndpointType = string;
export type Uri = string;
export interface UrlEndpointInput {
    Url: string;
    HealthUrl?: string;
}
export type LambdaArn = string;
export interface LambdaEndpointInput {
    Arn: string;
}
export interface CreateServiceRequest {
    Name: string;
    Description?: string;
    EnvironmentIdentifier: string;
    ApplicationIdentifier: string;
    VpcId?: string;
    EndpointType: string;
    UrlEndpoint?: UrlEndpointInput;
    LambdaEndpoint?: LambdaEndpointInput;
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
}
export type ServiceState = string;
export interface CreateServiceResponse {
    ServiceId?: string;
    Name?: string;
    Arn?: string;
    OwnerAccountId?: string;
    CreatedByAccountId?: string;
    Description?: string;
    EnvironmentId?: string;
    ApplicationId?: string;
    VpcId?: string;
    EndpointType?: string;
    UrlEndpoint?: UrlEndpointInput;
    LambdaEndpoint?: LambdaEndpointInput;
    State?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    LastUpdatedTime?: Date;
    CreatedTime?: Date;
}
export interface DeleteApplicationRequest {
    EnvironmentIdentifier: string;
    ApplicationIdentifier: string;
}
export interface DeleteApplicationResponse {
    Name?: string;
    Arn?: string;
    ApplicationId?: string;
    EnvironmentId?: string;
    State?: string;
    LastUpdatedTime?: Date;
}
export interface DeleteEnvironmentRequest {
    EnvironmentIdentifier: string;
}
export interface DeleteEnvironmentResponse {
    Name?: string;
    Arn?: string;
    EnvironmentId?: string;
    State?: string;
    LastUpdatedTime?: Date;
}
export type ResourcePolicyIdentifier = string;
export interface DeleteResourcePolicyRequest {
    Identifier: string;
}
export interface DeleteResourcePolicyResponse {
}
export interface DeleteRouteRequest {
    EnvironmentIdentifier: string;
    ApplicationIdentifier: string;
    RouteIdentifier: string;
}
export interface DeleteRouteResponse {
    RouteId?: string;
    Arn?: string;
    ServiceId?: string;
    ApplicationId?: string;
    State?: string;
    LastUpdatedTime?: Date;
}
export interface DeleteServiceRequest {
    EnvironmentIdentifier: string;
    ApplicationIdentifier: string;
    ServiceIdentifier: string;
}
export interface DeleteServiceResponse {
    ServiceId?: string;
    Name?: string;
    Arn?: string;
    EnvironmentId?: string;
    ApplicationId?: string;
    State?: string;
    LastUpdatedTime?: Date;
}
export interface GetApplicationRequest {
    EnvironmentIdentifier: string;
    ApplicationIdentifier: string;
}
export type ApiGatewayId = string;
export type VpcLinkId = string;
export type NlbArn = string;
export type NlbName = string;
export interface ApiGatewayProxyConfig {
    ProxyUrl?: string;
    ApiGatewayId?: string;
    VpcLinkId?: string;
    NlbArn?: string;
    NlbName?: string;
    EndpointType?: string;
    StageName?: string;
}
export type ErrorCode = string;
export type ErrorMessage = string;
export type ResourceIdentifier = string;
export type ErrorResourceType = string;
export type AdditionalDetailsKey = string;
export type AdditionalDetailsValue = string;
export type AdditionalDetails = {
    [key: string]: string | undefined;
};
export interface ErrorResponse {
    Code?: string;
    Message?: string;
    AccountId?: string;
    ResourceIdentifier?: string;
    ResourceType?: string;
    AdditionalDetails?: {
        [key: string]: string | undefined;
    };
}
export interface GetApplicationResponse {
    Name?: string;
    Arn?: string;
    OwnerAccountId?: string;
    CreatedByAccountId?: string;
    ApplicationId?: string;
    EnvironmentId?: string;
    VpcId?: string;
    ProxyType?: string;
    ApiGatewayProxy?: ApiGatewayProxyConfig;
    State?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Error?: ErrorResponse;
    LastUpdatedTime?: Date;
    CreatedTime?: Date;
}
export interface GetEnvironmentRequest {
    EnvironmentIdentifier: string;
}
export type TransitGatewayId = string;
export interface GetEnvironmentResponse {
    Name?: string;
    Arn?: string;
    Description?: string;
    EnvironmentId?: string;
    NetworkFabricType?: string;
    OwnerAccountId?: string;
    TransitGatewayId?: string;
    State?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Error?: ErrorResponse;
    LastUpdatedTime?: Date;
    CreatedTime?: Date;
}
export interface GetResourcePolicyRequest {
    Identifier: string;
}
export type PolicyString = string;
export interface GetResourcePolicyResponse {
    Policy?: string;
}
export interface GetRouteRequest {
    EnvironmentIdentifier: string;
    ApplicationIdentifier: string;
    RouteIdentifier: string;
}
export type PathResourceToIdKey = string;
export type PathResourceToIdValue = string;
export type PathResourceToId = {
    [key: string]: string | undefined;
};
export interface GetRouteResponse {
    RouteId?: string;
    Arn?: string;
    OwnerAccountId?: string;
    CreatedByAccountId?: string;
    RouteType?: string;
    ServiceId?: string;
    ApplicationId?: string;
    EnvironmentId?: string;
    SourcePath?: string;
    Methods?: string[];
    IncludeChildPaths?: boolean;
    PathResourceToId?: {
        [key: string]: string | undefined;
    };
    State?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Error?: ErrorResponse;
    LastUpdatedTime?: Date;
    CreatedTime?: Date;
    AppendSourcePath?: boolean;
}
export interface GetServiceRequest {
    EnvironmentIdentifier: string;
    ApplicationIdentifier: string;
    ServiceIdentifier: string;
}
export interface UrlEndpointConfig {
    Url?: string;
    HealthUrl?: string;
}
export interface LambdaEndpointConfig {
    Arn?: string;
}
export interface GetServiceResponse {
    ServiceId?: string;
    Name?: string;
    Arn?: string;
    OwnerAccountId?: string;
    CreatedByAccountId?: string;
    Description?: string;
    EnvironmentId?: string;
    ApplicationId?: string;
    VpcId?: string;
    EndpointType?: string;
    UrlEndpoint?: UrlEndpointConfig;
    LambdaEndpoint?: LambdaEndpointConfig;
    State?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Error?: ErrorResponse;
    LastUpdatedTime?: Date;
    CreatedTime?: Date;
}
export type NextToken = string;
export type MaxResults = number;
export interface ListApplicationsRequest {
    EnvironmentIdentifier: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface ApiGatewayProxySummary {
    ProxyUrl?: string;
    ApiGatewayId?: string;
    VpcLinkId?: string;
    NlbArn?: string;
    NlbName?: string;
    EndpointType?: string;
    StageName?: string;
}
export interface ApplicationSummary {
    Name?: string;
    Arn?: string;
    OwnerAccountId?: string;
    CreatedByAccountId?: string;
    ApplicationId?: string;
    EnvironmentId?: string;
    VpcId?: string;
    ProxyType?: string;
    ApiGatewayProxy?: ApiGatewayProxySummary;
    State?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Error?: ErrorResponse;
    LastUpdatedTime?: Date;
    CreatedTime?: Date;
}
export type ApplicationSummaries = ApplicationSummary[];
export interface ListApplicationsResponse {
    ApplicationSummaryList?: ApplicationSummary[];
    NextToken?: string;
}
export interface ListEnvironmentsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface EnvironmentSummary {
    Name?: string;
    Arn?: string;
    Description?: string;
    EnvironmentId?: string;
    NetworkFabricType?: string;
    OwnerAccountId?: string;
    TransitGatewayId?: string;
    State?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Error?: ErrorResponse;
    LastUpdatedTime?: Date;
    CreatedTime?: Date;
}
export type EnvironmentSummaries = EnvironmentSummary[];
export interface ListEnvironmentsResponse {
    EnvironmentSummaryList?: EnvironmentSummary[];
    NextToken?: string;
}
export interface ListEnvironmentVpcsRequest {
    EnvironmentIdentifier: string;
    NextToken?: string;
    MaxResults?: number;
}
export type CidrBlock = string;
export type CidrBlocks = string[];
export type Ec2TagValue = string;
export interface EnvironmentVpc {
    EnvironmentId?: string;
    VpcId?: string;
    AccountId?: string;
    CidrBlocks?: string[];
    VpcName?: string;
    LastUpdatedTime?: Date;
    CreatedTime?: Date;
}
export type EnvironmentVpcs = EnvironmentVpc[];
export interface ListEnvironmentVpcsResponse {
    EnvironmentVpcList?: EnvironmentVpc[];
    NextToken?: string;
}
export interface ListRoutesRequest {
    EnvironmentIdentifier: string;
    ApplicationIdentifier: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface RouteSummary {
    RouteId?: string;
    Arn?: string;
    OwnerAccountId?: string;
    CreatedByAccountId?: string;
    RouteType?: string;
    ServiceId?: string;
    ApplicationId?: string;
    EnvironmentId?: string;
    SourcePath?: string;
    Methods?: string[];
    IncludeChildPaths?: boolean;
    PathResourceToId?: {
        [key: string]: string | undefined;
    };
    State?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Error?: ErrorResponse;
    LastUpdatedTime?: Date;
    CreatedTime?: Date;
    AppendSourcePath?: boolean;
}
export type RouteSummaries = RouteSummary[];
export interface ListRoutesResponse {
    RouteSummaryList?: RouteSummary[];
    NextToken?: string;
}
export interface ListServicesRequest {
    EnvironmentIdentifier: string;
    ApplicationIdentifier: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface UrlEndpointSummary {
    Url?: string;
    HealthUrl?: string;
}
export interface LambdaEndpointSummary {
    Arn?: string;
}
export interface ServiceSummary {
    ServiceId?: string;
    Name?: string;
    Arn?: string;
    OwnerAccountId?: string;
    CreatedByAccountId?: string;
    Description?: string;
    EnvironmentId?: string;
    ApplicationId?: string;
    VpcId?: string;
    EndpointType?: string;
    UrlEndpoint?: UrlEndpointSummary;
    LambdaEndpoint?: LambdaEndpointSummary;
    State?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Error?: ErrorResponse;
    LastUpdatedTime?: Date;
    CreatedTime?: Date;
}
export type ServiceSummaries = ServiceSummary[];
export interface ListServicesResponse {
    ServiceSummaryList?: ServiceSummary[];
    NextToken?: string;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface PutResourcePolicyRequest {
    ResourceArn: string;
    Policy: string;
}
export interface PutResourcePolicyResponse {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateRouteRequest {
    EnvironmentIdentifier: string;
    ApplicationIdentifier: string;
    RouteIdentifier: string;
    ActivationState: string;
}
export interface UpdateRouteResponse {
    RouteId?: string;
    Arn?: string;
    ServiceId?: string;
    ApplicationId?: string;
    State?: string;
    LastUpdatedTime?: Date;
}
export type RetryAfterSeconds = number;
export type CreateApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Web Services Migration Hub Refactor Spaces application. The account that owns the environment also owns the
 * applications created inside the environment, regardless of the account that creates the
 * application. Refactor Spaces provisions an Amazon API Gateway, API Gateway VPC link, and
 * Network Load Balancer for the application proxy inside your account.
 *
 * In environments created with a CreateEnvironment:NetworkFabricType of `NONE` you need to configure
 * VPC to VPC connectivity between your service VPC and the application proxy VPC to
 * route traffic through the application proxy to a service with a private URL endpoint. For more
 * information, see
 * Create an application in the *Refactor Spaces User Guide*.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Web Services Migration Hub Refactor Spaces environment. The caller owns the environment resource, and all
 * Refactor Spaces applications, services, and routes created within the environment. They are referred
 * to as the *environment owner*. The environment owner has cross-account
 * visibility and control of Refactor Spaces resources that are added to the environment by other
 * accounts that the environment is shared with.
 *
 * When creating an environment with a CreateEnvironment:NetworkFabricType of `TRANSIT_GATEWAY`, Refactor Spaces
 * provisions a transit gateway to enable services in VPCs to communicate directly across
 * accounts. If CreateEnvironment:NetworkFabricType is `NONE`, Refactor Spaces does not create
 * a transit gateway and you must use your network infrastructure to route traffic to services
 * with private URL endpoints.
 */
export declare const createEnvironment: API.OperationMethod<CreateEnvironmentRequest, CreateEnvironmentResponse, CreateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateRouteError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Web Services Migration Hub Refactor Spaces route. The account owner of the service resource is always the
 * environment owner, regardless of which account creates the route. Routes target a service in
 * the application. If an application does not have any routes, then the first route must be
 * created as a `DEFAULT`
 * `RouteType`.
 *
 * When created, the default route defaults to an active state so state is not a required
 * input. However, like all other state values the state of the default route can be updated
 * after creation, but only when all other routes are also inactive. Conversely, no route can be
 * active without the default route also being active.
 *
 * When you create a route, Refactor Spaces configures the Amazon API Gateway to send traffic
 * to the target service as follows:
 *
 * - **URL Endpoints**
 *
 * If the service has a URL endpoint, and the endpoint resolves to a private IP address,
 * Refactor Spaces routes traffic using the API Gateway VPC link. If a service endpoint
 * resolves to a public IP address, Refactor Spaces routes traffic over the public internet.
 * Services can have HTTP or HTTPS URL endpoints. For HTTPS URLs, publicly-signed
 * certificates are supported. Private Certificate Authorities (CAs) are permitted only if
 * the CA's domain is also publicly resolvable.
 *
 * Refactor Spaces automatically resolves the public Domain Name System (DNS) names that are
 * set in `CreateService:UrlEndpoint `when you create a service. The DNS names
 * resolve when the DNS time-to-live (TTL) expires, or every 60 seconds for TTLs less than 60
 * seconds. This periodic DNS resolution ensures that the route configuration remains
 * up-to-date.
 *
 * **One-time health check**
 *
 * A one-time health check is performed on the service when either the route is updated
 * from inactive to active, or when it is created with an active state. If the health check
 * fails, the route transitions the route state to `FAILED`, an error code of
 * `SERVICE_ENDPOINT_HEALTH_CHECK_FAILURE` is provided, and no traffic is sent
 * to the service.
 *
 * For private URLs, a target group is created on the Network Load Balancer and the load
 * balancer target group runs default target health checks. By default, the health check is
 * run against the service endpoint URL. Optionally, the health check can be performed
 * against a different protocol, port, and/or path using the CreateService:UrlEndpoint parameter. All other health check settings for the
 * load balancer use the default values described in the Health
 * checks for your target groups in the Elastic Load Balancing
 * guide. The health check is considered successful if at least one target
 * within the target group transitions to a healthy state.
 *
 * - **Lambda function endpoints**
 *
 * If the service has an Lambda function endpoint, then Refactor Spaces
 * configures the Lambda function's resource policy to allow the application's
 * API Gateway to invoke the function.
 *
 * The Lambda function state is checked. If the function is not active, the
 * function configuration is updated so that Lambda resources are provisioned. If
 * the Lambda state is `Failed`, then the route creation fails. For
 * more information, see the GetFunctionConfiguration's State response parameter in the *Lambda Developer Guide*.
 *
 * A check is performed to determine that a Lambda function with the specified ARN
 * exists. If it does not exist, the health check fails. For public URLs, a connection is
 * opened to the public endpoint. If the URL is not reachable, the health check fails.
 *
 * **Environments without a network bridge**
 *
 * When you create environments without a network bridge (CreateEnvironment:NetworkFabricType is `NONE)` and you use your own
 * networking infrastructure, you need to configure VPC to VPC connectivity between your network and the application proxy VPC. Route
 * creation from the application proxy to service endpoints will fail if your network is not
 * configured to connect to the application proxy VPC. For more information, see Create
 * a route in the *Refactor Spaces User Guide*.
 */
export declare const createRoute: API.OperationMethod<CreateRouteRequest, CreateRouteResponse, CreateRouteError, Credentials | HttpClient.HttpClient>;
export type CreateServiceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Web Services Migration Hub Refactor Spaces service. The account owner of the service is always the
 * environment owner, regardless of which account in the environment creates the service.
 * Services have either a URL endpoint in a virtual private cloud (VPC), or a Lambda
 * function endpoint.
 *
 * If an Amazon Web Services resource is launched in a service VPC, and you want it to be
 * accessible to all of an environment's services with VPCs and routes, apply the
 * `RefactorSpacesSecurityGroup` to the resource. Alternatively, to add more
 * cross-account constraints, apply your own security group.
 */
export declare const createService: API.OperationMethod<CreateServiceRequest, CreateServiceResponse, CreateServiceError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Web Services Migration Hub Refactor Spaces application. Before you can delete an application, you must first
 * delete any services or routes within the application.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Web Services Migration Hub Refactor Spaces environment. Before you can delete an environment, you must first
 * delete any applications and services within the environment.
 */
export declare const deleteEnvironment: API.OperationMethod<DeleteEnvironmentRequest, DeleteEnvironmentResponse, DeleteEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the resource policy set for the environment.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteRouteError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Web Services Migration Hub Refactor Spaces route.
 */
export declare const deleteRoute: API.OperationMethod<DeleteRouteRequest, DeleteRouteResponse, DeleteRouteError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Web Services Migration Hub Refactor Spaces service.
 */
export declare const deleteService: API.OperationMethod<DeleteServiceRequest, DeleteServiceResponse, DeleteServiceError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an Amazon Web Services Migration Hub Refactor Spaces application.
 */
export declare const getApplication: API.OperationMethod<GetApplicationRequest, GetApplicationResponse, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an Amazon Web Services Migration Hub Refactor Spaces environment.
 */
export declare const getEnvironment: API.OperationMethod<GetEnvironmentRequest, GetEnvironmentResponse, GetEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the resource-based permission policy that is set for the given environment.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetRouteError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an Amazon Web Services Migration Hub Refactor Spaces route.
 */
export declare const getRoute: API.OperationMethod<GetRouteRequest, GetRouteResponse, GetRouteError, Credentials | HttpClient.HttpClient>;
export type GetServiceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an Amazon Web Services Migration Hub Refactor Spaces service.
 */
export declare const getService: API.OperationMethod<GetServiceRequest, GetServiceResponse, GetServiceError, Credentials | HttpClient.HttpClient>;
export type ListApplicationsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the Amazon Web Services Migration Hub Refactor Spaces applications within an environment.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationSummary>;
export type ListEnvironmentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists Amazon Web Services Migration Hub Refactor Spaces environments owned by a caller account or shared with the caller
 * account.
 */
export declare const listEnvironments: API.PaginatedOperationMethod<ListEnvironmentsRequest, ListEnvironmentsResponse, ListEnvironmentsError, Credentials | HttpClient.HttpClient, EnvironmentSummary>;
export type ListEnvironmentVpcsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all Amazon Web Services Migration Hub Refactor Spaces service virtual private clouds (VPCs) that are part of the
 * environment.
 */
export declare const listEnvironmentVpcs: API.PaginatedOperationMethod<ListEnvironmentVpcsRequest, ListEnvironmentVpcsResponse, ListEnvironmentVpcsError, Credentials | HttpClient.HttpClient, EnvironmentVpc>;
export type ListRoutesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the Amazon Web Services Migration Hub Refactor Spaces routes within an application.
 */
export declare const listRoutes: API.PaginatedOperationMethod<ListRoutesRequest, ListRoutesResponse, ListRoutesError, Credentials | HttpClient.HttpClient, RouteSummary>;
export type ListServicesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the Amazon Web Services Migration Hub Refactor Spaces services within an application.
 */
export declare const listServices: API.PaginatedOperationMethod<ListServicesRequest, ListServicesResponse, ListServicesError, Credentials | HttpClient.HttpClient, ServiceSummary>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tags of a resource. The caller account must be the same as the resource's
 * `OwnerAccountId`. Listing tags in other accounts is not supported.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = AccessDeniedException | InternalServerException | InvalidResourcePolicyException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Attaches a resource-based permission policy to the Amazon Web Services Migration Hub Refactor Spaces environment. The policy
 * must contain the same actions and condition statements as the
 * `arn:aws:ram::aws:permission/AWSRAMDefaultPermissionRefactorSpacesEnvironment`
 * permission in Resource Access Manager. The policy must not contain new lines or blank lines.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes the tags of a given resource. Tags are metadata which can be used to manage a
 * resource. To tag a resource, the caller account must be the same as the resource's
 * `OwnerAccountId`. Tagging resources in other accounts is not supported.
 *
 * Amazon Web Services Migration Hub Refactor Spaces does not propagate tags to orchestrated resources, such as an
 * environment's transit gateway.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds to or modifies the tags of the given resource. Tags are metadata which can be used to
 * manage a resource. To untag a resource, the caller account must be the same as the resource's
 * `OwnerAccountId`. Untagging resources across accounts is not supported.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateRouteError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an Amazon Web Services Migration Hub Refactor Spaces route.
 */
export declare const updateRoute: API.OperationMethod<UpdateRouteRequest, UpdateRouteResponse, UpdateRouteError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=migration-hub-refactor-spaces.d.ts.map