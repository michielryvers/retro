import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InvalidParameterValueException_base: S.TaggedErrorClass<"InvalidParameterValueException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const NetworkConnectorLimitExceededException_base: S.TaggedErrorClass<"NetworkConnectorLimitExceededException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NetworkConnectorLimitExceededException extends /*@__PURE__*/ NetworkConnectorLimitExceededException_base {
}
declare const OperatorRoleNotAssumable_base: S.TaggedErrorClass<"OperatorRoleNotAssumable", {
    readonly Type: any;
    readonly message: any;
}>;
export declare class OperatorRoleNotAssumable extends /*@__PURE__*/ OperatorRoleNotAssumable_base {
}
declare const ResourceConflictException_base: S.TaggedErrorClass<"ResourceConflictException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceConflictException extends /*@__PURE__*/ ResourceConflictException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceException_base: S.TaggedErrorClass<"ServiceException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceException extends /*@__PURE__*/ ServiceException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly retryAfterSeconds: any;
    readonly Type: any;
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type NetworkConnectorName = string;
export type NetworkConnectorSubnetId = string;
export type NetworkConnectorSubnetIds = string[];
export type NetworkConnectorSecurityGroupId = string;
export type NetworkConnectorSecurityGroupIds = string[];
export type NetworkProtocol = "IPv4" | "DualStack" | (string & {});
export type ComputeResourceType = "MicroVm" | "WebFunction" | (string & {});
export type AssociatedComputeResourceTypesList = ComputeResourceType[];
export interface NetworkConnectorVpcEgressConfiguration {
    SubnetIds?: string[];
    SecurityGroupIds?: string[];
    NetworkProtocol?: NetworkProtocol;
    AssociatedComputeResourceTypes?: ComputeResourceType[];
}
export type NetworkConnectorConfiguration = {
    VpcEgressConfiguration: NetworkConnectorVpcEgressConfiguration;
};
export type NetworkConnectorRoleArn = string;
export type ClientTokenString = string;
export type NetworkConnectorTagKey = string;
export type NetworkConnectorTagValue = string;
export type NetworkConnectorTags = {
    [key: string]: string | undefined;
};
export interface CreateNetworkConnectorRequest {
    Name: string;
    Configuration: NetworkConnectorConfiguration;
    OperatorRole?: string;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type NetworkConnectorArn = string;
export type NetworkConnectorId = string;
export type NetworkConnectorVersion = number;
export type NetworkConnectorState = "PENDING" | "ACTIVE" | "INACTIVE" | "FAILED" | "DELETING" | "DELETE_FAILED" | (string & {});
export interface CreateNetworkConnectorResponse {
    Arn: string;
    Name: string;
    Id: string;
    VersionArn?: string;
    Version?: number;
    Configuration?: NetworkConnectorConfiguration;
    OperatorRole?: string;
    State?: NetworkConnectorState;
}
export type NetworkConnectorIdentifier = string;
export interface DeleteNetworkConnectorRequest {
    Identifier: string;
}
export interface DeleteNetworkConnectorResponse {
    Arn: string;
    Name: string;
    Id: string;
    VersionArn?: string;
    Version?: number;
    Configuration?: NetworkConnectorConfiguration;
    OperatorRole?: string;
    State?: NetworkConnectorState;
}
export interface GetNetworkConnectorRequest {
    Identifier: string;
}
export type NetworkConnectorStateReasonCode = "DisallowedByVpcEncryptionControl" | "Ec2RequestLimitExceeded" | "InsufficientRolePermissions" | "InternalError" | "InvalidSecurityGroup" | "InvalidSubnet" | "SecurityGroupsPerInterfaceLimitExceeded" | "SubnetOutOfIPAddresses" | (string & {});
export type NetworkConnectorLastUpdateStatus = "Successful" | "Failed" | "InProgress" | (string & {});
export type NetworkConnectorLastUpdateStatusReason = string;
export type NetworkConnectorLastUpdateStatusReasonCode = "DisallowedByVpcEncryptionControl" | "Ec2RequestLimitExceeded" | "InsufficientRolePermissions" | "InternalError" | "InvalidSecurityGroup" | "InvalidSubnet" | "SecurityGroupsPerInterfaceLimitExceeded" | "SubnetOutOfIPAddresses" | (string & {});
export type CoreTimestamp = Date;
export interface GetNetworkConnectorResponse {
    Arn: string;
    Name: string;
    Id: string;
    VersionArn?: string;
    Version?: number;
    LatestVersionArn?: string;
    LatestVersion?: number;
    Configuration?: NetworkConnectorConfiguration;
    OperatorRole?: string;
    State?: NetworkConnectorState;
    StateReason?: string;
    StateReasonCode?: NetworkConnectorStateReasonCode;
    LastUpdateStatus?: NetworkConnectorLastUpdateStatus;
    LastUpdateStatusReason?: string;
    LastUpdateStatusReasonCode?: NetworkConnectorLastUpdateStatusReasonCode;
    LastModified?: Date;
}
export type MaxHundredListItems = number;
export interface ListNetworkConnectorsRequest {
    State?: NetworkConnectorState;
    Marker?: string;
    MaxItems?: number;
}
export type NetworkConnectorType = "VPC_EGRESS" | (string & {});
export interface NetworkConnectorSummary {
    Arn: string;
    Name: string;
    Id: string;
    Type: NetworkConnectorType;
    State?: NetworkConnectorState;
    LastModified?: Date;
    LatestVersionArn?: string;
    LatestVersion?: number;
}
export type NetworkConnectorsList = NetworkConnectorSummary[];
export interface ListNetworkConnectorsResponse {
    NetworkConnectors: NetworkConnectorSummary[];
    NextMarker?: string;
}
export interface ListNetworkConnectorVersionsRequest {
    Identifier: string;
    State?: NetworkConnectorState;
    Marker?: string;
    MaxItems?: number;
}
export interface NetworkConnectorVersionSummary {
    Arn: string;
    VersionArn: string;
    Name: string;
    Id: string;
    Version: number;
    State: NetworkConnectorState;
    StateReason?: string;
    StateReasonCode?: NetworkConnectorStateReasonCode;
    LastModified?: Date;
}
export type NetworkConnectorVersionsList = NetworkConnectorVersionSummary[];
export interface ListNetworkConnectorVersionsResponse {
    NetworkConnectorVersions: NetworkConnectorVersionSummary[];
    NextMarker?: string;
}
export interface UpdateNetworkConnectorRequest {
    Identifier: string;
    Configuration?: NetworkConnectorConfiguration;
    OperatorRole?: string;
    ClientToken?: string;
}
export interface UpdateNetworkConnectorResponse {
    Arn: string;
    Name: string;
    Id: string;
    VersionArn?: string;
    Version?: number;
    OperatorRole?: string;
    Configuration?: NetworkConnectorConfiguration;
    State?: NetworkConnectorState;
    LastUpdateStatus?: NetworkConnectorLastUpdateStatus;
    LastUpdateStatusReason?: string;
    LastModified?: Date;
}
export type ThrottleReason = "ConcurrentInvocationLimitExceeded" | "FunctionInvocationRateLimitExceeded" | "ReservedFunctionConcurrentInvocationLimitExceeded" | "ReservedFunctionInvocationRateLimitExceeded" | "CallerRateLimitExceeded" | "ConcurrentSnapshotCreateLimitExceeded" | (string & {});
export type CreateNetworkConnectorError = InvalidParameterValueException | NetworkConnectorLimitExceededException | ResourceConflictException | ServiceException | TooManyRequestsException | OperatorRoleNotAssumable | CommonErrors;
/**
 * Creates a network connector that enables Lambda compute resources to route outbound traffic through your Amazon VPC. The network connector provisions elastic network interfaces (ENIs) in the subnets you specify, providing a managed network path to private resources such as databases, caches, and internal APIs.
 *
 * This operation is asynchronous. The network connector starts in `PENDING` state while ENIs are provisioned in your VPC (provisioning typically takes up to 10 minutes). Use `GetNetworkConnector` to poll the connector state until it reaches `ACTIVE`. Once active, you can attach the connector to supported Lambda compute resources -- such as MicroVMs and WebFunctions -- at run time. For how to attach a connector, see the documentation for the specific compute type.
 *
 * This operation is idempotent when you provide a `ClientToken` -- if you retry a request that completed successfully using the same client token, the operation returns the existing connector without creating a duplicate.
 */
export declare const createNetworkConnector: API.OperationMethod<CreateNetworkConnectorRequest, CreateNetworkConnectorResponse, CreateNetworkConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteNetworkConnectorError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Initiates deletion of a network connector. The connector transitions to `DELETING` state while elastic network interfaces are cleaned up asynchronously. After deletion completes, subsequent calls to `GetNetworkConnector` return `ResourceNotFoundException`.
 *
 * This operation is idempotent -- calling delete on a connector that is already deleting or has been deleted succeeds without error. You can delete connectors in `ACTIVE` or `FAILED` states. Before deleting a connector, ensure that no Lambda compute resources are using it, as they will lose VPC egress connectivity immediately.
 *
 * Deleting with an unqualified identifier removes the connector and all of its versions. To remove a single historical version, supply its version-qualified ARN; the connector and its remaining versions are unaffected. You can't delete the latest version on its own -- delete the connector to remove it.
 */
export declare const deleteNetworkConnector: API.OperationMethod<DeleteNetworkConnectorRequest, DeleteNetworkConnectorResponse, DeleteNetworkConnectorError, Credentials | HttpClient.HttpClient>;
export type GetNetworkConnectorError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the current configuration, state, and metadata of a network connector. The `Identifier` parameter accepts the connector ID, name, or full ARN. Use this operation to poll connector state after creation or update, or to inspect the current VPC configuration and any failure reasons.
 *
 * The response includes the full connector configuration, current state, and -- if the connector has been updated -- the `LastUpdateStatus` and `LastUpdateStatusReasonCode` fields that indicate whether the most recent update succeeded or failed.
 */
export declare const getNetworkConnector: API.OperationMethod<GetNetworkConnectorRequest, GetNetworkConnectorResponse, GetNetworkConnectorError, Credentials | HttpClient.HttpClient>;
export type ListNetworkConnectorsError = InvalidParameterValueException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns a paginated list of network connectors in your account for the current Region. You can optionally filter results by connector state. Use the `Marker` parameter from a previous response to retrieve the next page of results.
 *
 * Each item in the response includes the connector ARN, name, ID, type, current state, and last modified timestamp. To retrieve full configuration details for a specific connector, use `GetNetworkConnector`.
 */
export declare const listNetworkConnectors: API.PaginatedOperationMethod<ListNetworkConnectorsRequest, ListNetworkConnectorsResponse, ListNetworkConnectorsError, Credentials | HttpClient.HttpClient, NetworkConnectorSummary>;
export type ListNetworkConnectorVersionsError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns a paginated list of the versions of a network connector. Each configuration update creates a new immutable version; this operation lists those versions for the connector you specify. You can optionally filter results by version state. Use the `Marker` parameter from a previous response to retrieve the next page of results.
 *
 * Each item in the response includes the version-qualified ARN, version number, current state, and last modified timestamp for that version. To retrieve the current (latest) configuration of the connector, use `GetNetworkConnector`; to inspect a specific version, call `GetNetworkConnector` with a version-qualified identifier.
 */
export declare const listNetworkConnectorVersions: API.PaginatedOperationMethod<ListNetworkConnectorVersionsRequest, ListNetworkConnectorVersionsResponse, ListNetworkConnectorVersionsError, Credentials | HttpClient.HttpClient, NetworkConnectorVersionSummary>;
export type UpdateNetworkConnectorError = InvalidParameterValueException | NetworkConnectorLimitExceededException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | OperatorRoleNotAssumable | CommonErrors;
/**
 * Updates the VPC configuration or operator role of an existing network connector. You can modify the subnet IDs, security group IDs, network protocol, or operator role. The connector must be in `ACTIVE` state to accept updates.
 *
 * This operation is asynchronous. The connector remains in `ACTIVE` state during the update -- existing workloads that reference this connector are not disrupted. Use `GetNetworkConnector` to monitor the `LastUpdateStatus` field, which transitions through `InProgress` to `Successful` or `Failed`. If the update fails, the `LastUpdateStatusReasonCode` field provides a specific error code for troubleshooting. This operation is idempotent when you provide a `ClientToken`.
 *
 * Each successful configuration change creates a new immutable version. A connector can have a limited number of versions; once that limit is reached, further updates fail with `NetworkConnectorLimitExceededException` until you delete older versions.
 */
export declare const updateNetworkConnector: API.OperationMethod<UpdateNetworkConnectorRequest, UpdateNetworkConnectorResponse, UpdateNetworkConnectorError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=lambda-core.d.ts.map