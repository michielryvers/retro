import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type * as stream from "effect/Stream";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import * as T from "../traits.ts";
declare const EngineNotSupportedException_base: S.TaggedErrorClass<"EngineNotSupportedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EngineNotSupportedException extends /*@__PURE__*/ EngineNotSupportedException_base {
}
declare const InvalidLexiconException_base: S.TaggedErrorClass<"InvalidLexiconException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidLexiconException extends /*@__PURE__*/ InvalidLexiconException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidS3BucketException_base: S.TaggedErrorClass<"InvalidS3BucketException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidS3BucketException extends /*@__PURE__*/ InvalidS3BucketException_base {
}
declare const InvalidS3KeyException_base: S.TaggedErrorClass<"InvalidS3KeyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidS3KeyException extends /*@__PURE__*/ InvalidS3KeyException_base {
}
declare const InvalidSampleRateException_base: S.TaggedErrorClass<"InvalidSampleRateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSampleRateException extends /*@__PURE__*/ InvalidSampleRateException_base {
}
declare const InvalidSnsTopicArnException_base: S.TaggedErrorClass<"InvalidSnsTopicArnException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSnsTopicArnException extends /*@__PURE__*/ InvalidSnsTopicArnException_base {
}
declare const InvalidSsmlException_base: S.TaggedErrorClass<"InvalidSsmlException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSsmlException extends /*@__PURE__*/ InvalidSsmlException_base {
}
declare const InvalidTaskIdException_base: S.TaggedErrorClass<"InvalidTaskIdException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTaskIdException extends /*@__PURE__*/ InvalidTaskIdException_base {
}
declare const LanguageNotSupportedException_base: S.TaggedErrorClass<"LanguageNotSupportedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LanguageNotSupportedException extends /*@__PURE__*/ LanguageNotSupportedException_base {
}
declare const LexiconNotFoundException_base: S.TaggedErrorClass<"LexiconNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LexiconNotFoundException extends /*@__PURE__*/ LexiconNotFoundException_base {
}
declare const LexiconSizeExceededException_base: S.TaggedErrorClass<"LexiconSizeExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LexiconSizeExceededException extends /*@__PURE__*/ LexiconSizeExceededException_base {
}
declare const MarksNotSupportedForFormatException_base: S.TaggedErrorClass<"MarksNotSupportedForFormatException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MarksNotSupportedForFormatException extends /*@__PURE__*/ MarksNotSupportedForFormatException_base {
}
declare const MaxLexemeLengthExceededException_base: S.TaggedErrorClass<"MaxLexemeLengthExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MaxLexemeLengthExceededException extends /*@__PURE__*/ MaxLexemeLengthExceededException_base {
}
declare const MaxLexiconsNumberExceededException_base: S.TaggedErrorClass<"MaxLexiconsNumberExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MaxLexiconsNumberExceededException extends /*@__PURE__*/ MaxLexiconsNumberExceededException_base {
}
declare const ServiceFailureException_base: S.TaggedErrorClass<"ServiceFailureException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceFailureException extends /*@__PURE__*/ ServiceFailureException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly quotaCode: any;
    readonly serviceCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const SsmlMarksNotSupportedForTextTypeException_base: S.TaggedErrorClass<"SsmlMarksNotSupportedForTextTypeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SsmlMarksNotSupportedForTextTypeException extends /*@__PURE__*/ SsmlMarksNotSupportedForTextTypeException_base {
}
declare const SynthesisTaskNotFoundException_base: S.TaggedErrorClass<"SynthesisTaskNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SynthesisTaskNotFoundException extends /*@__PURE__*/ SynthesisTaskNotFoundException_base {
}
declare const TextLengthExceededException_base: S.TaggedErrorClass<"TextLengthExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TextLengthExceededException extends /*@__PURE__*/ TextLengthExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly throttlingReasons: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnsupportedPlsAlphabetException_base: S.TaggedErrorClass<"UnsupportedPlsAlphabetException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedPlsAlphabetException extends /*@__PURE__*/ UnsupportedPlsAlphabetException_base {
}
declare const UnsupportedPlsLanguageException_base: S.TaggedErrorClass<"UnsupportedPlsLanguageException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedPlsLanguageException extends /*@__PURE__*/ UnsupportedPlsLanguageException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fields: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type LexiconName = string;
export interface DeleteLexiconInput {
    Name: string;
}
export interface DeleteLexiconOutput {
}
export type Engine = "standard" | "neural" | "long-form" | "generative" | (string & {});
export type LanguageCode = "arb" | "cmn-CN" | "cy-GB" | "da-DK" | "de-DE" | "en-AU" | "en-GB" | "en-GB-WLS" | "en-IN" | "en-US" | "es-ES" | "es-MX" | "es-US" | "fr-CA" | "fr-FR" | "is-IS" | "it-IT" | "ja-JP" | "hi-IN" | "ko-KR" | "nb-NO" | "nl-NL" | "pl-PL" | "pt-BR" | "pt-PT" | "ro-RO" | "ru-RU" | "sv-SE" | "tr-TR" | "en-NZ" | "en-ZA" | "ca-ES" | "de-AT" | "yue-CN" | "ar-AE" | "fi-FI" | "en-IE" | "nl-BE" | "fr-BE" | "cs-CZ" | "de-CH" | "en-SG" | (string & {});
export type IncludeAdditionalLanguageCodes = boolean;
export type NextToken = string;
export interface DescribeVoicesInput {
    Engine?: Engine;
    LanguageCode?: LanguageCode;
    IncludeAdditionalLanguageCodes?: boolean;
    NextToken?: string;
}
export type Gender = "Female" | "Male" | (string & {});
export type VoiceId = "Aditi" | "Amy" | "Astrid" | "Bianca" | "Brian" | "Camila" | "Carla" | "Carmen" | "Celine" | "Chantal" | "Conchita" | "Cristiano" | "Dora" | "Emma" | "Enrique" | "Ewa" | "Filiz" | "Gabrielle" | "Geraint" | "Giorgio" | "Gwyneth" | "Hans" | "Ines" | "Ivy" | "Jacek" | "Jan" | "Joanna" | "Joey" | "Justin" | "Karl" | "Kendra" | "Kevin" | "Kimberly" | "Lea" | "Liv" | "Lotte" | "Lucia" | "Lupe" | "Mads" | "Maja" | "Marlene" | "Mathieu" | "Matthew" | "Maxim" | "Mia" | "Miguel" | "Mizuki" | "Naja" | "Nicole" | "Olivia" | "Penelope" | "Raveena" | "Ricardo" | "Ruben" | "Russell" | "Salli" | "Seoyeon" | "Takumi" | "Tatyana" | "Vicki" | "Vitoria" | "Zeina" | "Zhiyu" | "Aria" | "Ayanda" | "Arlet" | "Hannah" | "Arthur" | "Daniel" | "Liam" | "Pedro" | "Kajal" | "Hiujin" | "Laura" | "Elin" | "Ida" | "Suvi" | "Ola" | "Hala" | "Andres" | "Sergio" | "Remi" | "Adriano" | "Thiago" | "Ruth" | "Stephen" | "Kazuha" | "Tomoko" | "Niamh" | "Sofie" | "Lisa" | "Isabelle" | "Zayd" | "Danielle" | "Gregory" | "Burcu" | "Jitka" | "Sabrina" | "Jasmine" | "Jihye" | "Ambre" | "Beatrice" | "Florian" | "Lennart" | "Lorenzo" | "Tiffany" | (string & {});
export type LanguageName = string;
export type VoiceName = string;
export type LanguageCodeList = LanguageCode[];
export type EngineList = Engine[];
export interface Voice {
    Gender?: Gender;
    Id?: VoiceId;
    LanguageCode?: LanguageCode;
    LanguageName?: string;
    Name?: string;
    AdditionalLanguageCodes?: LanguageCode[];
    SupportedEngines?: Engine[];
}
export type VoiceList = Voice[];
export interface DescribeVoicesOutput {
    Voices?: Voice[];
    NextToken?: string;
}
export interface GetLexiconInput {
    Name: string;
}
export type LexiconContent = string | redacted.Redacted<string>;
export interface Lexicon {
    Content?: string | redacted.Redacted<string>;
    Name?: string;
}
export type Alphabet = string;
export type LastModified = Date;
export type LexiconArn = string;
export type LexemesCount = number;
export type Size = number;
export interface LexiconAttributes {
    Alphabet?: string;
    LanguageCode?: LanguageCode;
    LastModified?: Date;
    LexiconArn?: string;
    LexemesCount?: number;
    Size?: number;
}
export interface GetLexiconOutput {
    Lexicon?: Lexicon;
    LexiconAttributes?: LexiconAttributes;
}
export type TaskId = string;
export interface GetSpeechSynthesisTaskInput {
    TaskId: string;
}
export type TaskStatus = "scheduled" | "inProgress" | "completed" | "failed" | (string & {});
export type TaskStatusReason = string;
export type OutputUri = string;
export type RequestCharacters = number;
export type SnsTopicArn = string;
export type LexiconNameList = string[];
export type OutputFormat = "json" | "mp3" | "ogg_opus" | "ogg_vorbis" | "pcm" | "mulaw" | "alaw" | (string & {});
export type SampleRate = string;
export type SpeechMarkType = "sentence" | "ssml" | "viseme" | "word" | (string & {});
export type SpeechMarkTypeList = SpeechMarkType[];
export type TextType = "ssml" | "text" | (string & {});
export interface SynthesisTask {
    Engine?: Engine;
    TaskId?: string;
    TaskStatus?: TaskStatus;
    TaskStatusReason?: string;
    OutputUri?: string;
    CreationTime?: Date;
    RequestCharacters?: number;
    SnsTopicArn?: string;
    LexiconNames?: string[];
    OutputFormat?: OutputFormat;
    SampleRate?: string;
    SpeechMarkTypes?: SpeechMarkType[];
    TextType?: TextType;
    VoiceId?: VoiceId;
    LanguageCode?: LanguageCode;
}
export interface GetSpeechSynthesisTaskOutput {
    SynthesisTask?: SynthesisTask;
}
export interface ListLexiconsInput {
    NextToken?: string;
}
export interface LexiconDescription {
    Name?: string;
    Attributes?: LexiconAttributes;
}
export type LexiconDescriptionList = LexiconDescription[];
export interface ListLexiconsOutput {
    Lexicons?: LexiconDescription[];
    NextToken?: string;
}
export type MaxResults = number;
export interface ListSpeechSynthesisTasksInput {
    MaxResults?: number;
    NextToken?: string;
    Status?: TaskStatus;
}
export type SynthesisTasks = SynthesisTask[];
export interface ListSpeechSynthesisTasksOutput {
    NextToken?: string;
    SynthesisTasks?: SynthesisTask[];
}
export interface PutLexiconInput {
    Name: string;
    Content: string | redacted.Redacted<string>;
}
export interface PutLexiconOutput {
}
export type Text = string;
export type Force = boolean;
export interface FlushStreamConfiguration {
    Force?: boolean;
}
export interface TextEvent {
    Text: string;
    TextType?: TextType;
    FlushStreamConfiguration?: FlushStreamConfiguration;
}
export interface CloseStreamEvent {
}
export type StartSpeechSynthesisStreamActionStream = {
    TextEvent: TextEvent;
    CloseStreamEvent?: never;
} | {
    TextEvent?: never;
    CloseStreamEvent: CloseStreamEvent;
};
export interface StartSpeechSynthesisStreamInput {
    Engine: Engine;
    LanguageCode?: LanguageCode;
    LexiconNames?: string[];
    OutputFormat: OutputFormat;
    SampleRate?: string;
    VoiceId: VoiceId;
    ActionStream?: stream.Stream<StartSpeechSynthesisStreamActionStream, Error, never>;
}
export type AudioChunk = Uint8Array;
export interface AudioEvent {
    AudioChunk?: Uint8Array;
}
export interface StreamClosedEvent {
    RequestCharacters?: number;
}
export type ErrorMessage = string;
export type ValidationExceptionReason = "unsupportedOperation" | "fieldValidationFailed" | "other" | "invalidInboundEvent" | (string & {});
export type ValidationExceptionFieldName = string;
export type ValidationExceptionFieldMessage = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type QuotaCode = "input-stream-inbound-event-timeout" | "input-stream-timeout" | (string & {});
export type ServiceCode = "polly" | (string & {});
export type AvailabilityErrorMessage = string;
export type CoralAvailabilityThrottlingReason = string;
export type CoralAvailabilityThrottledResource = string;
export interface ThrottlingReason {
    reason?: string;
    resource?: string;
}
export type ThrottlingReasonList = ThrottlingReason[];
export type StartSpeechSynthesisStreamEventStream = {
    AudioEvent: AudioEvent;
    StreamClosedEvent?: never;
    ValidationException?: never;
    ServiceQuotaExceededException?: never;
    ServiceFailureException?: never;
    ThrottlingException?: never;
} | {
    AudioEvent?: never;
    StreamClosedEvent: StreamClosedEvent;
    ValidationException?: never;
    ServiceQuotaExceededException?: never;
    ServiceFailureException?: never;
    ThrottlingException?: never;
} | {
    AudioEvent?: never;
    StreamClosedEvent?: never;
    ValidationException: ValidationException;
    ServiceQuotaExceededException?: never;
    ServiceFailureException?: never;
    ThrottlingException?: never;
} | {
    AudioEvent?: never;
    StreamClosedEvent?: never;
    ValidationException?: never;
    ServiceQuotaExceededException: ServiceQuotaExceededException;
    ServiceFailureException?: never;
    ThrottlingException?: never;
} | {
    AudioEvent?: never;
    StreamClosedEvent?: never;
    ValidationException?: never;
    ServiceQuotaExceededException?: never;
    ServiceFailureException: ServiceFailureException;
    ThrottlingException?: never;
} | {
    AudioEvent?: never;
    StreamClosedEvent?: never;
    ValidationException?: never;
    ServiceQuotaExceededException?: never;
    ServiceFailureException?: never;
    ThrottlingException: ThrottlingException;
};
export interface StartSpeechSynthesisStreamOutput {
    EventStream?: stream.Stream<StartSpeechSynthesisStreamEventStream, Error, never>;
}
export type OutputS3BucketName = string;
export type OutputS3KeyPrefix = string;
export interface StartSpeechSynthesisTaskInput {
    Engine?: Engine;
    LanguageCode?: LanguageCode;
    LexiconNames?: string[];
    OutputFormat: OutputFormat;
    OutputS3BucketName: string;
    OutputS3KeyPrefix?: string;
    SampleRate?: string;
    SnsTopicArn?: string;
    SpeechMarkTypes?: SpeechMarkType[];
    Text: string;
    TextType?: TextType;
    VoiceId: VoiceId;
}
export interface StartSpeechSynthesisTaskOutput {
    SynthesisTask?: SynthesisTask;
}
export interface SynthesizeSpeechInput {
    Engine?: Engine;
    LanguageCode?: LanguageCode;
    LexiconNames?: string[];
    OutputFormat: OutputFormat;
    SampleRate?: string;
    SpeechMarkTypes?: SpeechMarkType[];
    Text: string;
    TextType?: TextType;
    VoiceId: VoiceId;
}
export type ContentType = string;
export interface SynthesizeSpeechOutput {
    AudioStream?: T.StreamingOutputBody;
    ContentType?: string;
    RequestCharacters?: number;
}
export type DeleteLexiconError = LexiconNotFoundException | ServiceFailureException | CommonErrors;
/**
 * Deletes the specified pronunciation lexicon stored in an Amazon Web Services Region. A lexicon which has been deleted is not available for
 * speech synthesis, nor is it possible to retrieve it using either the
 * `GetLexicon` or `ListLexicon` APIs.
 *
 * For more information, see Managing Lexicons.
 */
export declare const deleteLexicon: API.OperationMethod<DeleteLexiconInput, DeleteLexiconOutput, DeleteLexiconError, Credentials | HttpClient.HttpClient>;
export type DescribeVoicesError = InvalidNextTokenException | ServiceFailureException | CommonErrors;
/**
 * Returns the list of voices that are available for use when
 * requesting speech synthesis. Each voice speaks a specified language, is
 * either male or female, and is identified by an ID, which is the ASCII
 * version of the voice name.
 *
 * When synthesizing speech ( `SynthesizeSpeech` ), you
 * provide the voice ID for the voice you want from the list of voices
 * returned by `DescribeVoices`.
 *
 * For example, you want your news reader application to read news in
 * a specific language, but giving a user the option to choose the voice.
 * Using the `DescribeVoices` operation you can provide the user
 * with a list of available voices to select from.
 *
 * You can optionally specify a language code to filter the available
 * voices. For example, if you specify `en-US`, the operation
 * returns a list of all available US English voices.
 *
 * This operation requires permissions to perform the
 * `polly:DescribeVoices` action.
 */
export declare const describeVoices: API.OperationMethod<DescribeVoicesInput, DescribeVoicesOutput, DescribeVoicesError, Credentials | HttpClient.HttpClient>;
export type GetLexiconError = LexiconNotFoundException | ServiceFailureException | CommonErrors;
/**
 * Returns the content of the specified pronunciation lexicon stored
 * in an Amazon Web Services Region. For more information, see Managing Lexicons.
 */
export declare const getLexicon: API.OperationMethod<GetLexiconInput, GetLexiconOutput, GetLexiconError, Credentials | HttpClient.HttpClient>;
export type GetSpeechSynthesisTaskError = InvalidTaskIdException | ServiceFailureException | SynthesisTaskNotFoundException | CommonErrors;
/**
 * Retrieves a specific SpeechSynthesisTask object based on its TaskID.
 * This object contains information about the given speech synthesis task,
 * including the status of the task, and a link to the S3 bucket containing
 * the output of the task.
 */
export declare const getSpeechSynthesisTask: API.OperationMethod<GetSpeechSynthesisTaskInput, GetSpeechSynthesisTaskOutput, GetSpeechSynthesisTaskError, Credentials | HttpClient.HttpClient>;
export type ListLexiconsError = InvalidNextTokenException | ServiceFailureException | CommonErrors;
/**
 * Returns a list of pronunciation lexicons stored in an Amazon Web Services Region. For more information, see Managing Lexicons.
 */
export declare const listLexicons: API.OperationMethod<ListLexiconsInput, ListLexiconsOutput, ListLexiconsError, Credentials | HttpClient.HttpClient>;
export type ListSpeechSynthesisTasksError = InvalidNextTokenException | ServiceFailureException | CommonErrors;
/**
 * Returns a list of SpeechSynthesisTask objects ordered by their
 * creation date. This operation can filter the tasks by their status, for
 * example, allowing users to list only tasks that are completed.
 */
export declare const listSpeechSynthesisTasks: API.PaginatedOperationMethod<ListSpeechSynthesisTasksInput, ListSpeechSynthesisTasksOutput, ListSpeechSynthesisTasksError, Credentials | HttpClient.HttpClient, unknown>;
export type PutLexiconError = InvalidLexiconException | LexiconSizeExceededException | MaxLexemeLengthExceededException | MaxLexiconsNumberExceededException | ServiceFailureException | UnsupportedPlsAlphabetException | UnsupportedPlsLanguageException | CommonErrors;
/**
 * Stores a pronunciation lexicon in an Amazon Web Services Region. If
 * a lexicon with the same name already exists in the region, it is
 * overwritten by the new lexicon. Lexicon operations have eventual
 * consistency, therefore, it might take some time before the lexicon is
 * available to the SynthesizeSpeech operation.
 *
 * For more information, see Managing Lexicons.
 */
export declare const putLexicon: API.OperationMethod<PutLexiconInput, PutLexiconOutput, PutLexiconError, Credentials | HttpClient.HttpClient>;
export type StartSpeechSynthesisStreamError = ServiceFailureException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Synthesizes UTF-8 input, plain text, or SSML over a bidirectional streaming connection.
 * Specify synthesis parameters in HTTP/2 headers, send text incrementally as events on the input stream,
 * and receive synthesized audio as it becomes available.
 *
 * This operation serves as a bidirectional counterpart to `SynthesizeSpeech`:
 *
 * - SynthesizeSpeech
 */
export declare const startSpeechSynthesisStream: API.OperationMethod<StartSpeechSynthesisStreamInput, StartSpeechSynthesisStreamOutput, StartSpeechSynthesisStreamError, Credentials | HttpClient.HttpClient>;
export type StartSpeechSynthesisTaskError = EngineNotSupportedException | InvalidS3BucketException | InvalidS3KeyException | InvalidSampleRateException | InvalidSnsTopicArnException | InvalidSsmlException | LanguageNotSupportedException | LexiconNotFoundException | MarksNotSupportedForFormatException | ServiceFailureException | SsmlMarksNotSupportedForTextTypeException | TextLengthExceededException | CommonErrors;
/**
 * Allows the creation of an asynchronous synthesis task, by starting a
 * new `SpeechSynthesisTask`. This operation requires all the
 * standard information needed for speech synthesis, plus the name of an
 * Amazon S3 bucket for the service to store the output of the synthesis task
 * and two optional parameters (`OutputS3KeyPrefix` and
 * `SnsTopicArn`). Once the synthesis task is created, this
 * operation will return a `SpeechSynthesisTask` object, which
 * will include an identifier of this task as well as the current status. The
 * `SpeechSynthesisTask` object is available for 72 hours after
 * starting the asynchronous synthesis task.
 */
export declare const startSpeechSynthesisTask: API.OperationMethod<StartSpeechSynthesisTaskInput, StartSpeechSynthesisTaskOutput, StartSpeechSynthesisTaskError, Credentials | HttpClient.HttpClient>;
export type SynthesizeSpeechError = EngineNotSupportedException | InvalidSampleRateException | InvalidSsmlException | LanguageNotSupportedException | LexiconNotFoundException | MarksNotSupportedForFormatException | ServiceFailureException | SsmlMarksNotSupportedForTextTypeException | TextLengthExceededException | CommonErrors;
/**
 * Synthesizes UTF-8 input, plain text or SSML, to a stream of bytes.
 * SSML input must be valid, well-formed SSML. Some alphabets might not be
 * available with all the voices (for example, Cyrillic might not be read at
 * all by English voices) unless phoneme mapping is used. For more
 * information, see How it Works.
 */
export declare const synthesizeSpeech: API.OperationMethod<SynthesizeSpeechInput, SynthesizeSpeechOutput, SynthesizeSpeechError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=polly.d.ts.map