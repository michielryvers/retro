import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AttachmentIdNotFound_base: S.TaggedErrorClass<"AttachmentIdNotFound", {
    readonly message: any;
}>;
export declare class AttachmentIdNotFound extends /*@__PURE__*/ AttachmentIdNotFound_base {
}
declare const AttachmentLimitExceeded_base: S.TaggedErrorClass<"AttachmentLimitExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class AttachmentLimitExceeded extends /*@__PURE__*/ AttachmentLimitExceeded_base {
}
declare const AttachmentSetExpired_base: S.TaggedErrorClass<"AttachmentSetExpired", {
    readonly message: any;
}>;
export declare class AttachmentSetExpired extends /*@__PURE__*/ AttachmentSetExpired_base {
}
declare const AttachmentSetIdNotFound_base: S.TaggedErrorClass<"AttachmentSetIdNotFound", {
    readonly message: any;
}>;
export declare class AttachmentSetIdNotFound extends /*@__PURE__*/ AttachmentSetIdNotFound_base {
}
declare const AttachmentSetSizeLimitExceeded_base: S.TaggedErrorClass<"AttachmentSetSizeLimitExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class AttachmentSetSizeLimitExceeded extends /*@__PURE__*/ AttachmentSetSizeLimitExceeded_base {
}
declare const CaseCreationLimitExceeded_base: S.TaggedErrorClass<"CaseCreationLimitExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class CaseCreationLimitExceeded extends /*@__PURE__*/ CaseCreationLimitExceeded_base {
}
declare const CaseIdNotFound_base: S.TaggedErrorClass<"CaseIdNotFound", {
    readonly message: any;
}>;
export declare class CaseIdNotFound extends /*@__PURE__*/ CaseIdNotFound_base {
}
declare const DescribeAttachmentLimitExceeded_base: S.TaggedErrorClass<"DescribeAttachmentLimitExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class DescribeAttachmentLimitExceeded extends /*@__PURE__*/ DescribeAttachmentLimitExceeded_base {
}
declare const DryRunOperationException_base: S.TaggedErrorClass<"DryRunOperationException", {
    readonly message: any;
}>;
export declare class DryRunOperationException extends /*@__PURE__*/ DryRunOperationException_base {
}
declare const InternalServerError_base: S.TaggedErrorClass<"InternalServerError", {
    readonly message: any;
}>;
export declare class InternalServerError extends /*@__PURE__*/ InternalServerError_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly throttlingReasons: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UploadIdNotFound_base: S.TaggedErrorClass<"UploadIdNotFound", {
    readonly message: any;
}>;
export declare class UploadIdNotFound extends /*@__PURE__*/ UploadIdNotFound_base {
}
export type AttachmentSetId = string;
export type FileName = string;
export type Data = Uint8Array;
export interface Attachment {
    fileName?: string;
    data?: Uint8Array;
}
export type Attachments = Attachment[];
export type NullableBooleanType = boolean;
export interface AddAttachmentsToSetRequest {
    attachmentSetId?: string;
    attachments: Attachment[];
    dryRun?: boolean;
}
export type ExpiryTime = string;
export interface AddAttachmentsToSetResponse {
    attachmentSetId?: string;
    expiryTime?: string;
}
export type CaseId = string;
export type CommunicationBody = string;
export type CcEmailAddress = string;
export type CcEmailAddressList = string[];
export type UploadId = string;
export type UploadIds = string[];
export interface AddCommunicationToCaseRequest {
    caseId?: string;
    communicationBody: string;
    ccEmailAddresses?: string[];
    attachmentSetId?: string;
    uploadIds?: string[];
    dryRun?: boolean;
}
export type Result = boolean;
export interface AddCommunicationToCaseResponse {
    result?: boolean;
}
export type FieldIntegerValue = number;
export type ETag = string;
export interface CompletedUpload {
    partIndex: number;
    eTag: string;
}
export type CompletedUploadList = CompletedUpload[];
export interface CompleteAttachmentUploadRequest {
    uploadId: string;
    completedUploads: CompletedUpload[];
    dryRun?: boolean;
}
export type UploadStatus = "attachment-ready" | "attachment-not-ready" | "failed" | (string & {});
export interface CompleteAttachmentUploadResponse {
    uploadStatus: UploadStatus;
}
export type Subject = string;
export type ServiceCode2 = string;
export type SeverityCode = string;
export type CategoryCode = string;
export type Language = string;
export type IssueType = string;
export interface CreateCaseRequest {
    subject: string;
    serviceCode?: string;
    severityCode?: string;
    categoryCode?: string;
    communicationBody: string;
    ccEmailAddresses?: string[];
    language?: string;
    issueType?: string;
    attachmentSetId?: string;
    uploadIds?: string[];
    dryRun?: boolean;
}
export interface CreateCaseResponse {
    caseId?: string;
}
export type AttachmentId = string;
export interface DescribeAttachmentRequest {
    attachmentId: string;
    dryRun?: boolean;
}
export interface DescribeAttachmentResponse {
    attachment?: Attachment;
}
export interface DescribeAttachmentUploadStatusRequest {
    uploadId: string;
    dryRun?: boolean;
}
export interface UploadProgress {
    totalParts?: number;
    completedPartsCount?: number;
}
export interface DescribeAttachmentUploadStatusResponse {
    uploadStatus: UploadStatus;
    fileName: string;
    uploadProgress?: UploadProgress;
}
export type CaseIdList = string[];
export type DisplayId = string;
export type AfterTime = string;
export type BeforeTime = string;
export type IncludeResolvedCases = boolean;
export type NextToken = string;
export type MaxResults = number;
export type IncludeCommunications = boolean;
export interface DescribeCasesRequest {
    caseIdList?: string[];
    displayId?: string;
    afterTime?: string;
    beforeTime?: string;
    includeResolvedCases?: boolean;
    nextToken?: string;
    maxResults?: number;
    language?: string;
    includeCommunications?: boolean;
    dryRun?: boolean;
}
export type Status = string;
export type ServiceCode = string;
export type SubmittedBy = string;
export type TimeCreated = string;
export type ValidatedCommunicationBody = string;
export interface AttachmentDetails {
    attachmentId?: string;
    fileName?: string;
}
export type AttachmentSet = AttachmentDetails[];
export interface Communication {
    caseId?: string;
    body?: string;
    submittedBy?: string;
    timeCreated?: string;
    attachments?: AttachmentDetails[];
    attachmentSet?: AttachmentDetails[];
}
export type CommunicationList = Communication[];
export interface RecentCaseCommunications {
    communications?: Communication[];
    nextToken?: string;
}
export interface CaseDetails {
    caseId?: string;
    displayId?: string;
    subject?: string;
    status?: string;
    serviceCode?: string;
    categoryCode?: string;
    severityCode?: string;
    submittedBy?: string;
    timeCreated?: string;
    recentCommunications?: RecentCaseCommunications;
    ccEmailAddresses?: string[];
    language?: string;
}
export type CaseList = CaseDetails[];
export interface DescribeCasesResponse {
    cases?: CaseDetails[];
    nextToken?: string;
}
export interface DescribeCommunicationsRequest {
    caseId: string;
    beforeTime?: string;
    afterTime?: string;
    nextToken?: string;
    maxResults?: number;
    dryRun?: boolean;
}
export interface DescribeCommunicationsResponse {
    communications?: Communication[];
    nextToken?: string;
}
export interface DescribeCreateCaseOptionsRequest {
    issueType: string;
    serviceCode: string;
    language: string;
    categoryCode: string;
    dryRun?: boolean;
}
export type ValidatedLanguageAvailability = string;
export type Type = string;
export type StartTime = string;
export type EndTime = string;
export interface SupportedHour {
    startTime?: string;
    endTime?: string;
}
export type SupportedHoursList = SupportedHour[];
export type ValidatedDateTime = string;
export interface DateInterval {
    startDateTime?: string;
    endDateTime?: string;
}
export type DatesWithoutSupportList = DateInterval[];
export interface CommunicationTypeOptions {
    type?: string;
    supportedHours?: SupportedHour[];
    datesWithoutSupport?: DateInterval[];
}
export type CommunicationTypeOptionsList = CommunicationTypeOptions[];
export interface DescribeCreateCaseOptionsResponse {
    languageAvailability?: string;
    communicationTypes?: CommunicationTypeOptions[];
}
export type ServiceCodeList = string[];
export interface DescribeServicesRequest {
    serviceCodeList?: string[];
    language?: string;
    dryRun?: boolean;
}
export type ServiceName = string;
export type CategoryName = string;
export interface Category {
    code?: string;
    name?: string;
}
export type CategoryList = Category[];
export interface Service {
    code?: string;
    name?: string;
    categories?: Category[];
}
export type ServiceList = Service[];
export interface DescribeServicesResponse {
    services?: Service[];
}
export interface DescribeSeverityLevelsRequest {
    language?: string;
    dryRun?: boolean;
}
export type SeverityLevelCode = string;
export type SeverityLevelName = string;
export interface SeverityLevel {
    code?: string;
    name?: string;
}
export type SeverityLevelsList = SeverityLevel[];
export interface DescribeSeverityLevelsResponse {
    severityLevels?: SeverityLevel[];
}
export type ValidatedIssueTypeString = string;
export type ValidatedServiceCode = string;
export type ValidatedCategoryCode = string;
export interface DescribeSupportedLanguagesRequest {
    issueType: string;
    serviceCode: string;
    categoryCode: string;
    dryRun?: boolean;
}
export type Code = string;
export type Display = string;
export interface SupportedLanguage {
    code?: string;
    language?: string;
    display?: string;
}
export type SupportedLanguagesList = SupportedLanguage[];
export interface DescribeSupportedLanguagesResponse {
    supportedLanguages?: SupportedLanguage[];
}
export type StringList = string[];
export interface DescribeTrustedAdvisorCheckRefreshStatusesRequest {
    checkIds: string[];
}
export interface TrustedAdvisorCheckRefreshStatus {
    checkId: string;
    status: string;
    millisUntilNextRefreshable: number;
}
export type TrustedAdvisorCheckRefreshStatusList = TrustedAdvisorCheckRefreshStatus[];
export interface DescribeTrustedAdvisorCheckRefreshStatusesResponse {
    statuses: TrustedAdvisorCheckRefreshStatus[];
}
export interface DescribeTrustedAdvisorCheckResultRequest {
    checkId: string;
    language?: string;
}
export interface TrustedAdvisorResourcesSummary {
    resourcesProcessed: number;
    resourcesFlagged: number;
    resourcesIgnored: number;
    resourcesSuppressed: number;
}
export interface TrustedAdvisorCostOptimizingSummary {
    estimatedMonthlySavings: number;
    estimatedPercentMonthlySavings: number;
}
export interface TrustedAdvisorCategorySpecificSummary {
    costOptimizing?: TrustedAdvisorCostOptimizingSummary;
}
export interface TrustedAdvisorResourceDetail {
    status: string;
    region?: string;
    resourceId: string;
    isSuppressed?: boolean;
    metadata: string[];
}
export type TrustedAdvisorResourceDetailList = TrustedAdvisorResourceDetail[];
export interface TrustedAdvisorCheckResult {
    checkId: string;
    timestamp: string;
    status: string;
    resourcesSummary: TrustedAdvisorResourcesSummary;
    categorySpecificSummary: TrustedAdvisorCategorySpecificSummary;
    flaggedResources: TrustedAdvisorResourceDetail[];
}
export interface DescribeTrustedAdvisorCheckResultResponse {
    result?: TrustedAdvisorCheckResult;
}
export interface DescribeTrustedAdvisorChecksRequest {
    language: string;
}
export interface TrustedAdvisorCheckDescription {
    id: string;
    name: string;
    description: string;
    category: string;
    metadata: string[];
}
export type TrustedAdvisorCheckList = TrustedAdvisorCheckDescription[];
export interface DescribeTrustedAdvisorChecksResponse {
    checks: TrustedAdvisorCheckDescription[];
}
export interface DescribeTrustedAdvisorCheckSummariesRequest {
    checkIds: string[];
}
export interface TrustedAdvisorCheckSummary {
    checkId: string;
    timestamp: string;
    status: string;
    hasFlaggedResources?: boolean;
    resourcesSummary: TrustedAdvisorResourcesSummary;
    categorySpecificSummary: TrustedAdvisorCategorySpecificSummary;
}
export type TrustedAdvisorCheckSummaryList = TrustedAdvisorCheckSummary[];
export interface DescribeTrustedAdvisorCheckSummariesResponse {
    summaries: TrustedAdvisorCheckSummary[];
}
export interface GetAttachmentDownloadLinkRequest {
    attachmentId: string;
    dryRun?: boolean;
}
export type HttpsUrl = string;
export interface DownloadUrl {
    url: string;
    expiryDate: string;
}
export interface GetAttachmentDownloadLinkResponse {
    fileName: string;
    downloadUrl: DownloadUrl;
}
export type FileSize = number;
export type StartIndex = number;
export type EndIndex = number;
export interface UploadRange {
    startIndex: number;
    endIndex?: number;
}
export interface GetAttachmentUploadLinksRequest {
    fileName: string;
    fileSizeBytes?: number;
    uploadId?: string;
    uploadRange?: UploadRange;
    dryRun?: boolean;
}
export type PartSizeBytes = number;
export interface UploadUrl {
    url: string;
    partIndex: number;
    expiryDate: string;
}
export type UploadUrlList = UploadUrl[];
export interface GetAttachmentUploadLinksResponse {
    uploadId: string;
    partSizeBytes: number;
    totalParts: number;
    nextIndex?: number;
    uploadUrls: UploadUrl[];
}
export interface RefreshTrustedAdvisorCheckRequest {
    checkId: string;
}
export interface RefreshTrustedAdvisorCheckResponse {
    status: TrustedAdvisorCheckRefreshStatus;
}
export interface ResolveCaseRequest {
    caseId?: string;
    dryRun?: boolean;
}
export type CaseStatus = string;
export interface ResolveCaseResponse {
    initialCaseStatus?: string;
    finalCaseStatus?: string;
}
export type ErrorMessage = string;
export type AvailabilityErrorMessage = string;
export type CoralAvailabilityThrottlingReason = string;
export type CoralAvailabilityThrottledResource = string;
export interface ThrottlingReason {
    reason?: string;
    resource?: string;
}
export type ThrottlingReasonList = ThrottlingReason[];
export type AddAttachmentsToSetError = AttachmentLimitExceeded | AttachmentSetExpired | AttachmentSetIdNotFound | AttachmentSetSizeLimitExceeded | DryRunOperationException | InternalServerError | CommonErrors;
/**
 * Adds one or more attachments to an attachment set.
 *
 * An attachment set is a temporary container for attachments that you add to a case or
 * case communication. The set is available for 1 hour after it's created. The
 * `expiryTime` returned in the response is when the set expires.
 *
 * - You must have an Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan to use the Amazon Web Services Support
 * API. If you're in an Amazon Web Services Region that doesn't offer one of these Amazon Web Services Support plans, or if you haven't transitioned to one of these plans, you can use the Amazon Web Services Support API with a Business, Enterprise On-Ramp, or Enterprise Support plan.
 *
 * - If you call the Amazon Web Services Support API from an account that doesn't have an
 * Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan, the
 * `SubscriptionRequiredException` error message appears. For
 * information about changing your support plan, see Amazon Web Services Support.
 */
export declare const addAttachmentsToSet: API.OperationMethod<AddAttachmentsToSetRequest, AddAttachmentsToSetResponse, AddAttachmentsToSetError, Credentials | HttpClient.HttpClient>;
export type AddCommunicationToCaseError = AttachmentSetExpired | AttachmentSetIdNotFound | CaseIdNotFound | DryRunOperationException | InternalServerError | CommonErrors;
/**
 * Adds additional customer communication to a Amazon Web Services Support case. Use the `caseId`
 * parameter to identify the case to which to add communication. To list a set of
 * email addresses to copy on the communication, use the `ccEmailAddresses`
 * parameter. The `communicationBody` value contains the text of the
 * communication.
 *
 * To attach files larger than 5 MB to the communication, use the `uploadIds` parameter.
 *
 * Amazon Web Services Support automatically redacts sensitive information from support cases to protect your data. The following information is replaced with `[REDACTED_BY_Amazon Web Services]` and is not stored:
 *
 * - Amazon Web Services secret keys - The complete key is replaced. Example: `[REDACTED_BY_Amazon Web Services]`
 *
 * - Private keys - The complete key is replaced. Example: `[REDACTED_BY_Amazon Web Services]`
 *
 * - Credit card numbers - The number is redacted, but the last 4 digits remain. Example: `[REDACTED_BY_Amazon Web Services]-7016`
 *
 * This sensitive information is never required by Amazon Web Services Support.
 *
 * - You must have an Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan to use the Amazon Web Services Support
 * API. If you're in an Amazon Web Services Region that doesn't offer one of these Amazon Web Services Support plans, or if you haven't transitioned to one of these plans, you can use the Amazon Web Services Support API with a Business, Enterprise On-Ramp, or Enterprise Support plan.
 *
 * - If you call the Amazon Web Services Support API from an account that doesn't have an
 * Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan, the
 * `SubscriptionRequiredException` error message appears. For
 * information about changing your support plan, see Amazon Web Services Support.
 */
export declare const addCommunicationToCase: API.OperationMethod<AddCommunicationToCaseRequest, AddCommunicationToCaseResponse, AddCommunicationToCaseError, Credentials | HttpClient.HttpClient>;
export type CompleteAttachmentUploadError = DryRunOperationException | InternalServerError | UploadIdNotFound | CommonErrors;
/**
 * Completes an attachment upload that was started with GetAttachmentUploadLinks. After you upload a part of the file to its
 * presigned Amazon S3 URL, call `CompleteAttachmentUpload` with the
 * `partIndex` and `eTag` of that part. You can include one part per
 * call, or multiple parts in a single call. After `CompleteAttachmentUpload` has
 * been called for every part of the file, the service processes the upload asynchronously. The
 * `attachment-ready` status might not be reflected immediately. Use DescribeAttachmentUploadStatus to poll for the `uploadStatus` to
 * become `attachment-ready` before passing the `uploadId` to CreateCase or AddCommunicationToCase.
 */
export declare const completeAttachmentUpload: API.OperationMethod<CompleteAttachmentUploadRequest, CompleteAttachmentUploadResponse, CompleteAttachmentUploadError, Credentials | HttpClient.HttpClient>;
export type CreateCaseError = AttachmentSetExpired | AttachmentSetIdNotFound | CaseCreationLimitExceeded | DryRunOperationException | InternalServerError | CommonErrors;
/**
 * Creates a case in the Amazon Web Services Support Center. This operation is similar to how you create a case
 * in the Amazon Web Services Support Center Create
 * Case page.
 *
 * The Amazon Web Services Support API doesn't support requesting service limit increases. You can submit a
 * service limit increase in the following ways:
 *
 * - Submit a request from the Amazon Web Services Support Center Create Case page.
 *
 * - Use the Service Quotas RequestServiceQuotaIncrease operation.
 *
 * Amazon Web Services Support automatically redacts sensitive information from support cases to protect your data. The following information is replaced with `[REDACTED_BY_Amazon Web Services]` and is not stored:
 *
 * - Amazon Web Services secret keys - The complete key is replaced. Example: `[REDACTED_BY_Amazon Web Services]`
 *
 * - Private keys - The complete key is replaced. Example: `[REDACTED_BY_Amazon Web Services]`
 *
 * - Credit card numbers - The number is redacted, but the last 4 digits remain. Example: `[REDACTED_BY_Amazon Web Services]-7016`
 *
 * This sensitive information is never required by Amazon Web Services Support.
 *
 * A successful `CreateCase` request returns a Amazon Web Services Support case number. You can use
 * the DescribeCases operation and specify the case number to get
 * existing Amazon Web Services Support cases. After you create a case, use the AddCommunicationToCase operation to add additional communication or
 * attachments to an existing case.
 *
 * The `caseId` is separate from the `displayId` that appears in
 * the Amazon Web Services Support Center. Use the DescribeCases operation to get the `displayId`.
 *
 * - You must have an Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan to use the Amazon Web Services Support
 * API. If you're in an Amazon Web Services Region that doesn't offer one of these Amazon Web Services Support plans, or if you haven't transitioned to one of these plans, you can use the Amazon Web Services Support API with a Business, Enterprise On-Ramp, or Enterprise Support plan.
 *
 * - If you call the Amazon Web Services Support API from an account that doesn't have an
 * Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan, the
 * `SubscriptionRequiredException` error message appears. For
 * information about changing your support plan, see Amazon Web Services Support.
 */
export declare const createCase: API.OperationMethod<CreateCaseRequest, CreateCaseResponse, CreateCaseError, Credentials | HttpClient.HttpClient>;
export type DescribeAttachmentError = AttachmentIdNotFound | DescribeAttachmentLimitExceeded | DryRunOperationException | InternalServerError | CommonErrors;
/**
 * Returns the attachment that has the specified ID. Attachments can include screenshots,
 * error logs, or other files that describe your issue. Attachment IDs are generated by the
 * case management system when you add an attachment to a case or case communication.
 * Attachment IDs are returned in the AttachmentDetails objects that are
 * returned by the DescribeCommunications operation.
 *
 * - You must have an Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan to use the Amazon Web Services Support
 * API. If you're in an Amazon Web Services Region that doesn't offer one of these Amazon Web Services Support plans, or if you haven't transitioned to one of these plans, you can use the Amazon Web Services Support API with a Business, Enterprise On-Ramp, or Enterprise Support plan.
 *
 * - If you call the Amazon Web Services Support API from an account that doesn't have an
 * Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan, the
 * `SubscriptionRequiredException` error message appears. For
 * information about changing your support plan, see Amazon Web Services Support.
 *
 * `DescribeAttachment` can't return attachments larger than 5 MB. If the
 * specified `attachmentId` refers to an attachment larger than 5 MB, the
 * request fails with `InvalidParameterValueException`.
 *
 * To download an attachment of any size, including attachments larger than 5 MB, use
 * GetAttachmentDownloadLink.
 * `GetAttachmentDownloadLink` returns an Amazon S3 presigned URL that you can
 * use to download the attachment directly.
 */
export declare const describeAttachment: API.OperationMethod<DescribeAttachmentRequest, DescribeAttachmentResponse, DescribeAttachmentError, Credentials | HttpClient.HttpClient>;
export type DescribeAttachmentUploadStatusError = DryRunOperationException | InternalServerError | UploadIdNotFound | CommonErrors;
/**
 * Returns the current status, file name, and progress of a multipart attachment upload that
 * was started with GetAttachmentUploadLinks. Use this operation to track
 * where an upload is in the workflow. While parts are still being uploaded and reported through
 * CompleteAttachmentUpload, the `uploadStatus` is
 * `attachment-not-ready` and `uploadProgress` reports the total number
 * of parts and how many have been completed so far. After every part has been reported and the
 * service finishes processing the upload asynchronously, the `uploadStatus` becomes
 * `attachment-ready` and the `uploadId` can be attached to a case
 * through CreateCase or AddCommunicationToCase.
 *
 * - You must have an Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan to use the Amazon Web Services Support
 * API. If you're in an Amazon Web Services Region that doesn't offer one of these Amazon Web Services Support plans, or if you haven't transitioned to one of these plans, you can use the Amazon Web Services Support API with a Business, Enterprise On-Ramp, or Enterprise Support plan.
 *
 * - If you call the Amazon Web Services Support API from an account that doesn't have an
 * Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan, the
 * `SubscriptionRequiredException` error message appears. For
 * information about changing your support plan, see Amazon Web Services Support.
 */
export declare const describeAttachmentUploadStatus: API.OperationMethod<DescribeAttachmentUploadStatusRequest, DescribeAttachmentUploadStatusResponse, DescribeAttachmentUploadStatusError, Credentials | HttpClient.HttpClient>;
export type DescribeCasesError = CaseIdNotFound | DryRunOperationException | InternalServerError | CommonErrors;
/**
 * Returns a list of cases that you specify by passing one or more case IDs. You can use
 * the `afterTime` and `beforeTime` parameters to filter the cases by
 * date. You can set values for the `includeResolvedCases` and
 * `includeCommunications` parameters to specify how much information to
 * return.
 *
 * The response returns the following in JSON format:
 *
 * - One or more CaseDetails data types.
 *
 * - One or more `nextToken` values, which specify where to paginate the
 * returned records represented by the `CaseDetails` objects.
 *
 * Case data is available for 24 months after creation. If a case was created more than
 * 24 months ago, a request might return an error.
 *
 * - You must have an Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan to use the Amazon Web Services Support
 * API. If you're in an Amazon Web Services Region that doesn't offer one of these Amazon Web Services Support plans, or if you haven't transitioned to one of these plans, you can use the Amazon Web Services Support API with a Business, Enterprise On-Ramp, or Enterprise Support plan.
 *
 * - If you call the Amazon Web Services Support API from an account that doesn't have an
 * Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan, the
 * `SubscriptionRequiredException` error message appears. For
 * information about changing your support plan, see Amazon Web Services Support.
 *
 * Each Communication returned by this operation includes
 * attachment information in two fields:
 *
 * - `attachmentSet`: returns only attachments that are 5 MB or
 * smaller. Attachments larger than 5 MB are not included in this field.
 *
 * - `attachments`: returns all attachments regardless of size.
 *
 * Amazon Web Services recommends that you use the `attachments` field and download each
 * attachment with GetAttachmentDownloadLink, which supports
 * attachments of any size. The `attachmentSet` field and DescribeAttachment return only attachments that are 5 MB or
 * smaller.
 */
export declare const describeCases: API.PaginatedOperationMethod<DescribeCasesRequest, DescribeCasesResponse, DescribeCasesError, Credentials | HttpClient.HttpClient, CaseDetails>;
export type DescribeCommunicationsError = CaseIdNotFound | DryRunOperationException | InternalServerError | CommonErrors;
/**
 * Returns communications and attachments for one or more support cases. Use the
 * `afterTime` and `beforeTime` parameters to filter by date. You
 * can use the `caseId` parameter to restrict the results to a specific
 * case.
 *
 * Case data is available for 24 months after creation. If a case was created more than
 * 24 months ago, a request for data might cause an error.
 *
 * You can use the `maxResults` and `nextToken` parameters to
 * control the pagination of the results. Set `maxResults` to the number of
 * cases that you want to display on each page, and use `nextToken` to specify
 * the resumption of pagination.
 *
 * - You must have an Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan to use the Amazon Web Services Support
 * API. If you're in an Amazon Web Services Region that doesn't offer one of these Amazon Web Services Support plans, or if you haven't transitioned to one of these plans, you can use the Amazon Web Services Support API with a Business, Enterprise On-Ramp, or Enterprise Support plan.
 *
 * - If you call the Amazon Web Services Support API from an account that doesn't have an
 * Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan, the
 * `SubscriptionRequiredException` error message appears. For
 * information about changing your support plan, see Amazon Web Services Support.
 *
 * Each Communication returned by this operation includes
 * attachment information in two fields:
 *
 * - `attachmentSet`: returns only attachments that are 5 MB or
 * smaller. Attachments larger than 5 MB are not included in this field.
 *
 * - `attachments`: returns all attachments regardless of size.
 *
 * Amazon Web Services recommends that you use the `attachments` field and download each
 * attachment with GetAttachmentDownloadLink, which supports
 * attachments of any size. The `attachmentSet` field and DescribeAttachment return only attachments that are 5 MB or
 * smaller.
 */
export declare const describeCommunications: API.PaginatedOperationMethod<DescribeCommunicationsRequest, DescribeCommunicationsResponse, DescribeCommunicationsError, Credentials | HttpClient.HttpClient, Communication>;
export type DescribeCreateCaseOptionsError = DryRunOperationException | InternalServerError | ThrottlingException | CommonErrors;
/**
 * Returns a list of CreateCaseOption types along with the
 * corresponding supported hours and language availability. You can specify the `language`
 * `categoryCode`,
 * `issueType` and `serviceCode` used to retrieve the CreateCaseOptions.
 *
 * - You must have an Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan to use the Amazon Web Services Support
 * API. If you're in an Amazon Web Services Region that doesn't offer one of these Amazon Web Services Support plans, or if you haven't transitioned to one of these plans, you can use the Amazon Web Services Support API with a Business, Enterprise On-Ramp, or Enterprise Support plan.
 *
 * - If you call the Amazon Web Services Support API from an account that doesn't have an
 * Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan, the
 * `SubscriptionRequiredException` error message appears. For
 * information about changing your support plan, see Amazon Web Services Support.
 */
export declare const describeCreateCaseOptions: API.OperationMethod<DescribeCreateCaseOptionsRequest, DescribeCreateCaseOptionsResponse, DescribeCreateCaseOptionsError, Credentials | HttpClient.HttpClient>;
export type DescribeServicesError = DryRunOperationException | InternalServerError | CommonErrors;
/**
 * Returns the current list of Amazon Web Services services and a list of service categories for each
 * service. You then use service names and categories in your CreateCase
 * requests. Each Amazon Web Services service has its own set of categories.
 *
 * The service codes and category codes correspond to the values that appear in the
 * **Service** and **Category** lists on the Amazon Web Services Support Center Create Case page. The values in those fields
 * don't necessarily match the service codes and categories returned by the
 * `DescribeServices` operation. Always use the service codes and categories
 * that the `DescribeServices` operation returns, so that you have the most
 * recent set of service and category codes.
 *
 * - You must have an Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan to use the Amazon Web Services Support
 * API. If you're in an Amazon Web Services Region that doesn't offer one of these Amazon Web Services Support plans, or if you haven't transitioned to one of these plans, you can use the Amazon Web Services Support API with a Business, Enterprise On-Ramp, or Enterprise Support plan.
 *
 * - If you call the Amazon Web Services Support API from an account that doesn't have an
 * Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan, the
 * `SubscriptionRequiredException` error message appears. For
 * information about changing your support plan, see Amazon Web Services Support.
 */
export declare const describeServices: API.OperationMethod<DescribeServicesRequest, DescribeServicesResponse, DescribeServicesError, Credentials | HttpClient.HttpClient>;
export type DescribeSeverityLevelsError = DryRunOperationException | InternalServerError | CommonErrors;
/**
 * Returns the list of severity levels that you can assign to a support case. The
 * severity level for a case is also a field in the CaseDetails data type
 * that you include for a CreateCase request.
 *
 * - You must have an Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan to use the Amazon Web Services Support
 * API. If you're in an Amazon Web Services Region that doesn't offer one of these Amazon Web Services Support plans, or if you haven't transitioned to one of these plans, you can use the Amazon Web Services Support API with a Business, Enterprise On-Ramp, or Enterprise Support plan.
 *
 * - If you call the Amazon Web Services Support API from an account that doesn't have an
 * Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan, the
 * `SubscriptionRequiredException` error message appears. For
 * information about changing your support plan, see Amazon Web Services Support.
 */
export declare const describeSeverityLevels: API.OperationMethod<DescribeSeverityLevelsRequest, DescribeSeverityLevelsResponse, DescribeSeverityLevelsError, Credentials | HttpClient.HttpClient>;
export type DescribeSupportedLanguagesError = DryRunOperationException | InternalServerError | ThrottlingException | CommonErrors;
/**
 * Returns a list of supported languages for a specified `categoryCode`,
 * `issueType` and `serviceCode`. The returned supported languages will
 * include a ISO 639-1 code for the `language`, and the language display name.
 *
 * - You must have an Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan to use the Amazon Web Services Support
 * API. If you're in an Amazon Web Services Region that doesn't offer one of these Amazon Web Services Support plans, or if you haven't transitioned to one of these plans, you can use the Amazon Web Services Support API with a Business, Enterprise On-Ramp, or Enterprise Support plan.
 *
 * - If you call the Amazon Web Services Support API from an account that doesn't have an
 * Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan, the
 * `SubscriptionRequiredException` error message appears. For
 * information about changing your support plan, see Amazon Web Services Support.
 */
export declare const describeSupportedLanguages: API.OperationMethod<DescribeSupportedLanguagesRequest, DescribeSupportedLanguagesResponse, DescribeSupportedLanguagesError, Credentials | HttpClient.HttpClient>;
export type DescribeTrustedAdvisorCheckRefreshStatusesError = InternalServerError | ThrottlingException | CommonErrors;
/**
 * Returns the refresh status of the Trusted Advisor checks that have the specified check
 * IDs. You can get the check IDs by calling the DescribeTrustedAdvisorChecks operation.
 *
 * Some checks are refreshed automatically, and you can't return their refresh statuses
 * by using the `DescribeTrustedAdvisorCheckRefreshStatuses` operation. If you
 * call this operation for these checks, you might see an
 * `InvalidParameterValue` error.
 *
 * - You must have an Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan to use the Amazon Web Services Support
 * API. If you're in an Amazon Web Services Region that doesn't offer one of these Amazon Web Services Support plans, or if you haven't transitioned to one of these plans, you can use the Amazon Web Services Support API with a Business, Enterprise On-Ramp, or Enterprise Support plan.
 *
 * - If you call the Amazon Web Services Support API from an account that doesn't have an
 * Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan, the
 * `SubscriptionRequiredException` error message appears. For
 * information about changing your support plan, see Amazon Web Services Support.
 *
 * To call the Trusted Advisor operations in
 * the Amazon Web Services Support API, you must use the US East (N. Virginia) endpoint. Currently, the US West (Oregon) and Europe (Ireland)
 * endpoints don't support the Trusted Advisor operations. For more information, see About the Amazon Web Services Support
 * API in the *Amazon Web Services Support User Guide*.
 */
export declare const describeTrustedAdvisorCheckRefreshStatuses: API.OperationMethod<DescribeTrustedAdvisorCheckRefreshStatusesRequest, DescribeTrustedAdvisorCheckRefreshStatusesResponse, DescribeTrustedAdvisorCheckRefreshStatusesError, Credentials | HttpClient.HttpClient>;
export type DescribeTrustedAdvisorCheckResultError = InternalServerError | ThrottlingException | CommonErrors;
/**
 * Returns the results of the Trusted Advisor check that has the specified check ID. You
 * can get the check IDs by calling the DescribeTrustedAdvisorChecks
 * operation.
 *
 * The response contains a TrustedAdvisorCheckResult object, which
 * contains these three objects:
 *
 * - TrustedAdvisorCategorySpecificSummary
 *
 * - TrustedAdvisorResourceDetail
 *
 * - TrustedAdvisorResourcesSummary
 *
 * In addition, the response contains these fields:
 *
 * - **status** - The alert status of the check
 * can be `ok` (green), `warning` (yellow),
 * `error` (red), or `not_available`.
 *
 * - **timestamp** - The time of the last refresh
 * of the check.
 *
 * - **checkId** - The unique identifier for the
 * check.
 *
 * - You must have an Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan to use the Amazon Web Services Support
 * API. If you're in an Amazon Web Services Region that doesn't offer one of these Amazon Web Services Support plans, or if you haven't transitioned to one of these plans, you can use the Amazon Web Services Support API with a Business, Enterprise On-Ramp, or Enterprise Support plan.
 *
 * - If you call the Amazon Web Services Support API from an account that doesn't have an
 * Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan, the
 * `SubscriptionRequiredException` error message appears. For
 * information about changing your support plan, see Amazon Web Services Support.
 *
 * To call the Trusted Advisor operations in
 * the Amazon Web Services Support API, you must use the US East (N. Virginia) endpoint. Currently, the US West (Oregon) and Europe (Ireland)
 * endpoints don't support the Trusted Advisor operations. For more information, see About the Amazon Web Services Support
 * API in the *Amazon Web Services Support User Guide*.
 */
export declare const describeTrustedAdvisorCheckResult: API.OperationMethod<DescribeTrustedAdvisorCheckResultRequest, DescribeTrustedAdvisorCheckResultResponse, DescribeTrustedAdvisorCheckResultError, Credentials | HttpClient.HttpClient>;
export type DescribeTrustedAdvisorChecksError = InternalServerError | ThrottlingException | CommonErrors;
/**
 * Returns information about all available Trusted Advisor checks, including the name, ID,
 * category, description, and metadata. You must specify a language code.
 *
 * The response contains a TrustedAdvisorCheckDescription object for
 * each check. You must set the Amazon Web Services Region to us-east-1.
 *
 * - You must have a Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan to use the Amazon Web Services Support API.
 *
 * - If you call the Amazon Web Services Support API from an account that doesn't have a
 * Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan, the `SubscriptionRequiredException` error
 * message appears. For information about changing your support plan, see
 * Amazon Web Services Support.
 *
 * - The names and descriptions for Trusted Advisor checks are subject to change. We
 * recommend that you specify the check ID in your code to uniquely identify a
 * check.
 *
 * To call the Trusted Advisor operations in
 * the Amazon Web Services Support API, you must use the US East (N. Virginia) endpoint. Currently, the US West (Oregon) and Europe (Ireland)
 * endpoints don't support the Trusted Advisor operations. For more information, see About the Amazon Web Services Support
 * API in the *Amazon Web Services Support User Guide*.
 */
export declare const describeTrustedAdvisorChecks: API.OperationMethod<DescribeTrustedAdvisorChecksRequest, DescribeTrustedAdvisorChecksResponse, DescribeTrustedAdvisorChecksError, Credentials | HttpClient.HttpClient>;
export type DescribeTrustedAdvisorCheckSummariesError = InternalServerError | ThrottlingException | CommonErrors;
/**
 * Returns the results for the Trusted Advisor check summaries for the check IDs that you
 * specified. You can get the check IDs by calling the DescribeTrustedAdvisorChecks operation.
 *
 * The response contains an array of TrustedAdvisorCheckSummary
 * objects.
 *
 * - You must have an Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan to use the Amazon Web Services Support
 * API. If you're in an Amazon Web Services Region that doesn't offer one of these Amazon Web Services Support plans, or if you haven't transitioned to one of these plans, you can use the Amazon Web Services Support API with a Business, Enterprise On-Ramp, or Enterprise Support plan.
 *
 * - If you call the Amazon Web Services Support API from an account that doesn't have an
 * Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan, the
 * `SubscriptionRequiredException` error message appears. For
 * information about changing your support plan, see Amazon Web Services Support.
 *
 * To call the Trusted Advisor operations in
 * the Amazon Web Services Support API, you must use the US East (N. Virginia) endpoint. Currently, the US West (Oregon) and Europe (Ireland)
 * endpoints don't support the Trusted Advisor operations. For more information, see About the Amazon Web Services Support
 * API in the *Amazon Web Services Support User Guide*.
 *
 * **Understanding the Trusted Advisor Resources processed value**
 *
 * The **Resources processed** value, `resourcesProcessed`, usually shows both flagged resources (those with warnings or errors) and resources in good standing (ok status resources). However, some checks report flagged resources only. To understand what a specific check reports, review the detailed check information in the Trusted Advisor check reference. If you see a **Green** criterion listed in the **Alert criteria**, then the check reports all resources. If there's no **Green** criterion listed in the **Alert criteria**, then the check reports only flagged resources. For example, the Amazon EC2 Reserved Instance optimization check (cX3c2R1chu) doesn't list a **Green** criterion in the **Alert criteria**. So, this check only reports flagged resources.
 */
export declare const describeTrustedAdvisorCheckSummaries: API.OperationMethod<DescribeTrustedAdvisorCheckSummariesRequest, DescribeTrustedAdvisorCheckSummariesResponse, DescribeTrustedAdvisorCheckSummariesError, Credentials | HttpClient.HttpClient>;
export type GetAttachmentDownloadLinkError = AttachmentIdNotFound | DryRunOperationException | InternalServerError | CommonErrors;
/**
 * Returns a presigned download URL for an attachment that is associated with a case
 * communication. The download link works for an attachment of any size, including attachments
 * added through `AddAttachmentsToSet` and attachments uploaded through GetAttachmentUploadLinks. The download URL is time-limited and expires at the
 * date and time indicated in the `downloadUrl` response field. Download the
 * attachment from the URL before it expires.
 *
 * - You must have an Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan to use the Amazon Web Services Support
 * API. If you're in an Amazon Web Services Region that doesn't offer one of these Amazon Web Services Support plans, or if you haven't transitioned to one of these plans, you can use the Amazon Web Services Support API with a Business, Enterprise On-Ramp, or Enterprise Support plan.
 *
 * - If you call the Amazon Web Services Support API from an account that doesn't have an
 * Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan, the
 * `SubscriptionRequiredException` error message appears. For
 * information about changing your support plan, see Amazon Web Services Support.
 */
export declare const getAttachmentDownloadLink: API.OperationMethod<GetAttachmentDownloadLinkRequest, GetAttachmentDownloadLinkResponse, GetAttachmentDownloadLinkError, Credentials | HttpClient.HttpClient>;
export type GetAttachmentUploadLinksError = DryRunOperationException | InternalServerError | UploadIdNotFound | CommonErrors;
/**
 * Returns one or more presigned upload URLs for uploading a large file attachment to a
 * support case by using a multipart upload workflow. The maximum file size that you can upload
 * with this workflow is 150 MB, and parts can be up to 100 MB each. Initiate a new upload by
 * providing `fileName` and `fileSizeBytes`; the response returns a unique
 * `uploadId`, the part size, the total number of parts, and a list of presigned
 * upload URLs for the requested range of parts. A maximum of 10 upload URLs are returned per
 * call. To retrieve more upload URLs for an upload
 * that's already in progress, call `GetAttachmentUploadLinks` again with the existing
 * `uploadId` and a new `uploadRange`.
 *
 * Upload each part to its presigned URL by using HTTP `PUT` and capture the ETag
 * from the response. After you upload all parts, call CompleteAttachmentUpload
 * with the `uploadId` and the list of part indexes and ETags to finalize the upload.
 * You can then attach the upload to a case by passing the `uploadId` in the
 * `uploadIds` parameter of CreateCase or AddCommunicationToCase. To monitor progress before completion, call DescribeAttachmentUploadStatus.
 *
 * - You must have an Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan to use the Amazon Web Services Support
 * API. If you're in an Amazon Web Services Region that doesn't offer one of these Amazon Web Services Support plans, or if you haven't transitioned to one of these plans, you can use the Amazon Web Services Support API with a Business, Enterprise On-Ramp, or Enterprise Support plan.
 *
 * - If you call the Amazon Web Services Support API from an account that doesn't have an
 * Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan, the
 * `SubscriptionRequiredException` error message appears. For
 * information about changing your support plan, see Amazon Web Services Support.
 */
export declare const getAttachmentUploadLinks: API.OperationMethod<GetAttachmentUploadLinksRequest, GetAttachmentUploadLinksResponse, GetAttachmentUploadLinksError, Credentials | HttpClient.HttpClient>;
export type RefreshTrustedAdvisorCheckError = InternalServerError | CommonErrors;
/**
 * Refreshes the Trusted Advisor check that you specify using the check ID. You can get the
 * check IDs by calling the DescribeTrustedAdvisorChecks
 * operation.
 *
 * Some checks are refreshed automatically. If you call the
 * `RefreshTrustedAdvisorCheck` operation to refresh them, you might see
 * the `InvalidParameterValue` error.
 *
 * The response contains a TrustedAdvisorCheckRefreshStatus
 * object.
 *
 * - You must have an Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan to use the Amazon Web Services Support
 * API. If you're in an Amazon Web Services Region that doesn't offer one of these Amazon Web Services Support plans, or if you haven't transitioned to one of these plans, you can use the Amazon Web Services Support API with a Business, Enterprise On-Ramp, or Enterprise Support plan.
 *
 * - If you call the Amazon Web Services Support API from an account that doesn't have an
 * Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan, the
 * `SubscriptionRequiredException` error message appears. For
 * information about changing your support plan, see Amazon Web Services Support.
 *
 * To call the Trusted Advisor operations in
 * the Amazon Web Services Support API, you must use the US East (N. Virginia) endpoint. Currently, the US West (Oregon) and Europe (Ireland)
 * endpoints don't support the Trusted Advisor operations. For more information, see About the Amazon Web Services Support
 * API in the *Amazon Web Services Support User Guide*.
 */
export declare const refreshTrustedAdvisorCheck: API.OperationMethod<RefreshTrustedAdvisorCheckRequest, RefreshTrustedAdvisorCheckResponse, RefreshTrustedAdvisorCheckError, Credentials | HttpClient.HttpClient>;
export type ResolveCaseError = CaseIdNotFound | DryRunOperationException | InternalServerError | CommonErrors;
/**
 * Resolves a support case. This operation takes a `caseId` and returns the
 * initial and final state of the case.
 *
 * - You must have an Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan to use the Amazon Web Services Support
 * API. If you're in an Amazon Web Services Region that doesn't offer one of these Amazon Web Services Support plans, or if you haven't transitioned to one of these plans, you can use the Amazon Web Services Support API with a Business, Enterprise On-Ramp, or Enterprise Support plan.
 *
 * - If you call the Amazon Web Services Support API from an account that doesn't have an
 * Amazon Web Services Business Support+, Amazon Web Services Enterprise Support, or Amazon Web Services Unified Operations plan, the
 * `SubscriptionRequiredException` error message appears. For
 * information about changing your support plan, see Amazon Web Services Support.
 */
export declare const resolveCase: API.OperationMethod<ResolveCaseRequest, ResolveCaseResponse, ResolveCaseError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=support.d.ts.map