import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceType: any;
    readonly resourceId: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ChannelArn = string;
export type NotificationConfigurationArn = string;
export interface AssociateChannelRequest {
    arn: string;
    notificationConfigurationArn: string;
}
export interface AssociateChannelResponse {
}
export type AccountContactType = string;
export type ManagedNotificationConfigurationOsArn = string;
export interface AssociateManagedNotificationAccountContactRequest {
    contactIdentifier: string;
    managedNotificationConfigurationArn: string;
    isSensitiveEventsSubscribed?: boolean;
}
export interface AssociateManagedNotificationAccountContactResponse {
}
export interface AssociateManagedNotificationAdditionalChannelRequest {
    channelArn: string;
    managedNotificationConfigurationArn: string;
    isSensitiveEventsSubscribed?: boolean;
}
export interface AssociateManagedNotificationAdditionalChannelResponse {
}
export type OrganizationalUnitId = string;
export interface AssociateOrganizationalUnitRequest {
    organizationalUnitId: string;
    notificationConfigurationArn: string;
}
export interface AssociateOrganizationalUnitResponse {
}
export type Source = string;
export type EventType = string;
export type EventRuleEventPattern = string;
export type Region = string;
export type Regions = string[];
export interface CreateEventRuleRequest {
    notificationConfigurationArn: string;
    source: string;
    eventType: string;
    eventPattern?: string;
    regions: string[];
}
export type EventRuleArn = string;
export type EventRuleStatus = string;
export type EventRuleStatusReason = string;
export interface EventRuleStatusSummary {
    status: string;
    reason: string;
}
export type StatusSummaryByRegion = {
    [key: string]: EventRuleStatusSummary | undefined;
};
export interface CreateEventRuleResponse {
    arn: string;
    notificationConfigurationArn: string;
    statusSummaryByRegion: {
        [key: string]: EventRuleStatusSummary | undefined;
    };
}
export type NotificationConfigurationName = string;
export type NotificationConfigurationDescription = string;
export type AggregationDuration = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateNotificationConfigurationRequest {
    name: string;
    description: string;
    aggregationDuration?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type NotificationConfigurationStatus = string;
export interface CreateNotificationConfigurationResponse {
    arn: string;
    status: string;
}
export interface DeleteEventRuleRequest {
    arn: string;
}
export interface DeleteEventRuleResponse {
}
export interface DeleteNotificationConfigurationRequest {
    arn: string;
}
export interface DeleteNotificationConfigurationResponse {
}
export interface DeregisterNotificationHubRequest {
    notificationHubRegion: string;
}
export type NotificationHubStatus = string;
export type NotificationHubStatusReason = string;
export interface NotificationHubStatusSummary {
    status: string;
    reason: string;
}
export interface DeregisterNotificationHubResponse {
    notificationHubRegion: string;
    statusSummary: NotificationHubStatusSummary;
}
export interface DisableNotificationsAccessForOrganizationRequest {
}
export interface DisableNotificationsAccessForOrganizationResponse {
}
export interface DisassociateChannelRequest {
    arn: string;
    notificationConfigurationArn: string;
}
export interface DisassociateChannelResponse {
}
export interface DisassociateManagedNotificationAccountContactRequest {
    contactIdentifier: string;
    managedNotificationConfigurationArn: string;
}
export interface DisassociateManagedNotificationAccountContactResponse {
}
export interface DisassociateManagedNotificationAdditionalChannelRequest {
    channelArn: string;
    managedNotificationConfigurationArn: string;
}
export interface DisassociateManagedNotificationAdditionalChannelResponse {
}
export interface DisassociateOrganizationalUnitRequest {
    organizationalUnitId: string;
    notificationConfigurationArn: string;
}
export interface DisassociateOrganizationalUnitResponse {
}
export interface EnableNotificationsAccessForOrganizationRequest {
}
export interface EnableNotificationsAccessForOrganizationResponse {
}
export interface GetEventRuleRequest {
    arn: string;
}
export type CreationTime = Date;
export type ManagedRuleArn = string;
export type ManagedRuleArns = string[];
export interface GetEventRuleResponse {
    arn: string;
    notificationConfigurationArn: string;
    creationTime: Date;
    source: string;
    eventType: string;
    eventPattern: string;
    regions: string[];
    managedRules: string[];
    statusSummaryByRegion: {
        [key: string]: EventRuleStatusSummary | undefined;
    };
}
export type ManagedNotificationChildEventArn = string;
export type LocaleCode = string;
export interface GetManagedNotificationChildEventRequest {
    arn: string;
    locale?: string;
}
export type SchemaVersion = string;
export type NotificationEventId = string;
export type TextPartReference = string;
export interface Dimension {
    name: string;
    value: string;
}
export type Dimensions = Dimension[];
export interface MessageComponents {
    headline?: string;
    paragraphSummary?: string;
    completeDescription?: string;
    markupDescription?: string;
    dimensions?: Dimension[];
}
export type Url = string;
export type NotificationType = string;
export type EventStatus = string;
export type ManagedNotificationEventArn = string;
export type TextPartId = string;
export type TextPartType = string;
export type TextByLocale = {
    [key: string]: string | undefined;
};
export interface TextPartValue {
    type: string;
    displayText?: string;
    textByLocale?: {
        [key: string]: string | undefined;
    };
    url?: string;
}
export type TextParts = {
    [key: string]: TextPartValue | undefined;
};
export interface SummarizationDimensionDetail {
    name: string;
    value: string;
}
export type SummarizationDimensionDetails = SummarizationDimensionDetail[];
export interface AggregationDetail {
    summarizationDimensions?: SummarizationDimensionDetail[];
}
export interface ManagedNotificationChildEvent {
    schemaVersion: string;
    id: string;
    messageComponents: MessageComponents;
    sourceEventDetailUrl?: string;
    sourceEventDetailUrlDisplayText?: string;
    notificationType: string;
    eventStatus?: string;
    aggregateManagedNotificationEventArn: string;
    startTime?: Date;
    endTime?: Date;
    textParts: {
        [key: string]: TextPartValue | undefined;
    };
    organizationalUnitId?: string;
    aggregationDetail?: AggregationDetail;
}
export interface GetManagedNotificationChildEventResponse {
    arn: string;
    managedNotificationConfigurationArn: string;
    creationTime: Date;
    content: ManagedNotificationChildEvent;
}
export interface GetManagedNotificationConfigurationRequest {
    arn: string;
}
export type ManagedNotificationConfigurationName = string;
export type ManagedNotificationConfigurationDescription = string;
export interface GetManagedNotificationConfigurationResponse {
    arn: string;
    name: string;
    description: string;
    category: string;
    subCategory: string;
}
export interface GetManagedNotificationEventRequest {
    arn: string;
    locale?: string;
}
export type AggregationEventType = string;
export interface AggregationKey {
    name: string;
    value: string;
}
export type AggregationKeys = AggregationKey[];
export type SampleAggregationDimensionValues = string[];
export interface SummarizationDimensionOverview {
    name: string;
    count: number;
    sampleValues?: string[];
}
export type SummarizationDimensionOverviews = SummarizationDimensionOverview[];
export interface AggregationSummary {
    eventCount: number;
    aggregatedBy: AggregationKey[];
    aggregatedAccounts: SummarizationDimensionOverview;
    aggregatedRegions: SummarizationDimensionOverview;
    aggregatedOrganizationalUnits?: SummarizationDimensionOverview;
    additionalSummarizationDimensions?: SummarizationDimensionOverview[];
}
export type AttachmentDisplayName = string;
export type SensitiveUrl = string | redacted.Redacted<string>;
export type AttachmentContentType = string;
export interface NotificationEventAttachment {
    displayName: string;
    attachmentDownloadUrl?: string | redacted.Redacted<string>;
    contentType: string;
}
export type NotificationEventAttachmentList = NotificationEventAttachment[];
export interface ManagedNotificationEvent {
    schemaVersion: string;
    id: string;
    messageComponents: MessageComponents;
    sourceEventDetailUrl?: string;
    sourceEventDetailUrlDisplayText?: string;
    notificationType: string;
    eventStatus?: string;
    aggregationEventType?: string;
    aggregationSummary?: AggregationSummary;
    startTime?: Date;
    endTime?: Date;
    textParts: {
        [key: string]: TextPartValue | undefined;
    };
    organizationalUnitId?: string;
    attachments?: NotificationEventAttachment[];
}
export interface GetManagedNotificationEventResponse {
    arn: string;
    managedNotificationConfigurationArn: string;
    creationTime: Date;
    content: ManagedNotificationEvent;
}
export interface GetNotificationConfigurationRequest {
    arn: string;
}
export type NotificationConfigurationSubtype = string;
export interface GetNotificationConfigurationResponse {
    arn: string;
    name: string;
    description: string;
    status: string;
    creationTime: Date;
    aggregationDuration?: string;
    subtype?: string;
}
export type NotificationEventArn = string;
export interface GetNotificationEventRequest {
    arn: string;
    locale?: string;
}
export type AccountId = string;
export type Arn = string;
export type Tags = string[];
export interface Resource {
    id?: string;
    arn?: string;
    detailUrl?: string;
    tags?: string[];
}
export type Resources = Resource[];
export interface SourceEventMetadata {
    eventTypeVersion: string;
    sourceEventId: string;
    eventOriginRegion?: string;
    relatedAccount: string;
    source: string;
    eventOccurrenceTime: Date;
    eventType: string;
    relatedResources: Resource[];
}
export type MediaId = string;
export type MediaElementType = string;
export interface MediaElement {
    mediaId: string;
    type: string;
    url: string;
    caption: string;
}
export type Media = MediaElement[];
export interface NotificationEventSchema {
    schemaVersion: string;
    id: string;
    sourceEventMetadata: SourceEventMetadata;
    messageComponents: MessageComponents;
    sourceEventDetailUrl?: string;
    sourceEventDetailUrlDisplayText?: string;
    notificationType: string;
    eventStatus?: string;
    aggregationEventType?: string;
    aggregateNotificationEventArn?: string;
    aggregationSummary?: AggregationSummary;
    startTime?: Date;
    endTime?: Date;
    textParts: {
        [key: string]: TextPartValue | undefined;
    };
    media: MediaElement[];
    organizationalUnitId?: string;
}
export interface GetNotificationEventResponse {
    arn: string;
    notificationConfigurationArn: string;
    creationTime: Date;
    content: NotificationEventSchema;
}
export interface GetNotificationsAccessForOrganizationRequest {
}
export type AccessStatus = "ENABLED" | "DISABLED" | "PENDING" | "FAILED" | (string & {});
export interface NotificationsAccessForOrganization {
    accessStatus: AccessStatus;
}
export interface GetNotificationsAccessForOrganizationResponse {
    notificationsAccessForOrganization: NotificationsAccessForOrganization;
}
export type NextToken = string;
export interface ListChannelsRequest {
    notificationConfigurationArn: string;
    maxResults?: number;
    nextToken?: string;
}
export type Channels = string[];
export interface ListChannelsResponse {
    nextToken?: string;
    channels: string[];
}
export interface ListEventRulesRequest {
    notificationConfigurationArn: string;
    maxResults?: number;
    nextToken?: string;
}
export interface EventRuleStructure {
    arn: string;
    notificationConfigurationArn: string;
    creationTime: Date;
    source: string;
    eventType: string;
    eventPattern: string;
    regions: string[];
    managedRules: string[];
    statusSummaryByRegion: {
        [key: string]: EventRuleStatusSummary | undefined;
    };
}
export type EventRules = EventRuleStructure[];
export interface ListEventRulesResponse {
    nextToken?: string;
    eventRules: EventRuleStructure[];
}
export interface ListManagedNotificationChannelAssociationsRequest {
    managedNotificationConfigurationArn: string;
    maxResults?: number;
    nextToken?: string;
}
export type ChannelType = "MOBILE" | "CHATBOT" | "EMAIL" | "ACCOUNT_CONTACT" | (string & {});
export type ChannelAssociationOverrideOption = string;
export interface ManagedNotificationChannelAssociationSummary {
    channelIdentifier: string;
    channelType: ChannelType;
    overrideOption?: string;
    isSensitiveEventsSubscribed?: boolean;
}
export type ManagedNotificationChannelAssociations = ManagedNotificationChannelAssociationSummary[];
export interface ListManagedNotificationChannelAssociationsResponse {
    nextToken?: string;
    channelAssociations: ManagedNotificationChannelAssociationSummary[];
}
export interface ListManagedNotificationChildEventsRequest {
    aggregateManagedNotificationEventArn: string;
    startTime?: Date;
    endTime?: Date;
    locale?: string;
    maxResults?: number;
    relatedAccount?: string;
    organizationalUnitId?: string;
    nextToken?: string;
}
export interface ManagedSourceEventMetadataSummary {
    eventOriginRegion?: string;
    source: string;
    eventType: string;
}
export interface MessageComponentsSummary {
    headline: string;
}
export interface ManagedNotificationChildEventSummary {
    schemaVersion: string;
    sourceEventMetadata: ManagedSourceEventMetadataSummary;
    messageComponents: MessageComponentsSummary;
    aggregationDetail: AggregationDetail;
    eventStatus: string;
    notificationType: string;
}
export interface ManagedNotificationChildEventOverview {
    arn: string;
    managedNotificationConfigurationArn: string;
    relatedAccount: string;
    creationTime: Date;
    childEvent: ManagedNotificationChildEventSummary;
    aggregateManagedNotificationEventArn: string;
    organizationalUnitId?: string;
}
export type ManagedNotificationChildEvents = ManagedNotificationChildEventOverview[];
export interface ListManagedNotificationChildEventsResponse {
    nextToken?: string;
    managedNotificationChildEvents: ManagedNotificationChildEventOverview[];
}
export type ChannelIdentifier = string;
export interface ListManagedNotificationConfigurationsRequest {
    channelIdentifier?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface ManagedNotificationConfigurationStructure {
    arn: string;
    name: string;
    description: string;
}
export type ManagedNotificationConfigurations = ManagedNotificationConfigurationStructure[];
export interface ListManagedNotificationConfigurationsResponse {
    nextToken?: string;
    managedNotificationConfigurations: ManagedNotificationConfigurationStructure[];
}
export interface ListManagedNotificationEventsRequest {
    startTime?: Date;
    endTime?: Date;
    locale?: string;
    source?: string;
    maxResults?: number;
    nextToken?: string;
    organizationalUnitId?: string;
    relatedAccount?: string;
    includeSensitiveEvents?: boolean;
}
export interface ManagedNotificationEventSummary {
    schemaVersion: string;
    sourceEventMetadata: ManagedSourceEventMetadataSummary;
    messageComponents: MessageComponentsSummary;
    eventStatus: string;
    notificationType: string;
}
export type AggregatedNotificationRegions = string[];
export interface ManagedNotificationEventOverview {
    arn: string;
    managedNotificationConfigurationArn: string;
    relatedAccount: string;
    creationTime: Date;
    notificationEvent: ManagedNotificationEventSummary;
    aggregationEventType?: string;
    organizationalUnitId?: string;
    aggregationSummary?: AggregationSummary;
    aggregatedNotificationRegions?: string[];
}
export type ManagedNotificationEvents = ManagedNotificationEventOverview[];
export interface ListManagedNotificationEventsResponse {
    nextToken?: string;
    managedNotificationEvents: ManagedNotificationEventOverview[];
}
export type MemberAccountNotificationConfigurationStatus = string;
export interface ListMemberAccountsRequest {
    notificationConfigurationArn: string;
    maxResults?: number;
    nextToken?: string;
    memberAccount?: string;
    status?: string;
    organizationalUnitId?: string;
}
export interface MemberAccount {
    notificationConfigurationArn?: string;
    accountId: string;
    status: string;
    statusReason: string;
    organizationalUnitId: string;
}
export type MemberAccounts = MemberAccount[];
export interface ListMemberAccountsResponse {
    memberAccounts: MemberAccount[];
    nextToken?: string;
}
export interface ListNotificationConfigurationsRequest {
    eventRuleSource?: string;
    channelArn?: string;
    status?: string;
    subtype?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface NotificationConfigurationStructure {
    arn: string;
    name: string;
    description: string;
    status: string;
    creationTime: Date;
    aggregationDuration?: string;
    subtype?: string;
}
export type NotificationConfigurations = NotificationConfigurationStructure[];
export interface ListNotificationConfigurationsResponse {
    nextToken?: string;
    notificationConfigurations: NotificationConfigurationStructure[];
}
export interface ListNotificationEventsRequest {
    startTime?: Date;
    endTime?: Date;
    locale?: string;
    source?: string;
    includeChildEvents?: boolean;
    aggregateNotificationEventArn?: string;
    maxResults?: number;
    nextToken?: string;
    organizationalUnitId?: string;
}
export interface SourceEventMetadataSummary {
    eventOriginRegion?: string;
    source: string;
    eventType: string;
}
export interface NotificationEventSummary {
    schemaVersion: string;
    sourceEventMetadata: SourceEventMetadataSummary;
    messageComponents: MessageComponentsSummary;
    eventStatus: string;
    notificationType: string;
}
export interface NotificationEventOverview {
    arn: string;
    notificationConfigurationArn: string;
    relatedAccount: string;
    creationTime: Date;
    notificationEvent: NotificationEventSummary;
    aggregationEventType?: string;
    aggregateNotificationEventArn?: string;
    aggregationSummary?: AggregationSummary;
    organizationalUnitId?: string;
}
export type NotificationEvents = NotificationEventOverview[];
export interface ListNotificationEventsResponse {
    nextToken?: string;
    notificationEvents: NotificationEventOverview[];
}
export interface ListNotificationHubsRequest {
    maxResults?: number;
    nextToken?: string;
}
export type LastActivationTime = Date;
export interface NotificationHubOverview {
    notificationHubRegion: string;
    statusSummary: NotificationHubStatusSummary;
    creationTime: Date;
    lastActivationTime?: Date;
}
export type NotificationHubs = NotificationHubOverview[];
export interface ListNotificationHubsResponse {
    notificationHubs: NotificationHubOverview[];
    nextToken?: string;
}
export interface ListOrganizationalUnitsRequest {
    notificationConfigurationArn: string;
    maxResults?: number;
    nextToken?: string;
}
export type OrganizationalUnits = string[];
export interface ListOrganizationalUnitsResponse {
    organizationalUnits: string[];
    nextToken?: string;
}
export interface ListTagsForResourceRequest {
    arn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface RegisterNotificationHubRequest {
    notificationHubRegion: string;
}
export interface RegisterNotificationHubResponse {
    notificationHubRegion: string;
    statusSummary: NotificationHubStatusSummary;
    creationTime: Date;
    lastActivationTime?: Date;
}
export interface TagResourceRequest {
    arn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    arn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateEventRuleRequest {
    arn: string;
    eventPattern?: string;
    regions?: string[];
}
export interface UpdateEventRuleResponse {
    arn: string;
    notificationConfigurationArn: string;
    statusSummaryByRegion: {
        [key: string]: EventRuleStatusSummary | undefined;
    };
}
export type ManagedNotificationChannelIdentifier = string;
export interface UpdateManagedNotificationChannelAssociationRequest {
    managedNotificationConfigurationArn: string;
    channelIdentifier: string;
    isSensitiveEventsSubscribed?: boolean;
}
export interface UpdateManagedNotificationChannelAssociationResponse {
}
export interface UpdateNotificationConfigurationRequest {
    arn: string;
    name?: string;
    description?: string;
    aggregationDuration?: string;
}
export interface UpdateNotificationConfigurationResponse {
    arn: string;
}
export type ErrorMessage = string;
export type ResourceId = string;
export type ResourceType = string;
export type ServiceCode = string;
export type QuotaCode = string;
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AssociateChannelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a delivery Channel with a particular `NotificationConfiguration`. Supported Channels include Amazon Q Developer in chat applications, the Console Mobile Application, and emails (notifications-contacts).
 */
export declare const associateChannel: API.OperationMethod<AssociateChannelRequest, AssociateChannelResponse, AssociateChannelError, Credentials | HttpClient.HttpClient>;
export type AssociateManagedNotificationAccountContactError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates an Account Contact with a particular `ManagedNotificationConfiguration`.
 */
export declare const associateManagedNotificationAccountContact: API.OperationMethod<AssociateManagedNotificationAccountContactRequest, AssociateManagedNotificationAccountContactResponse, AssociateManagedNotificationAccountContactError, Credentials | HttpClient.HttpClient>;
export type AssociateManagedNotificationAdditionalChannelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates an additional Channel with a particular `ManagedNotificationConfiguration`.
 *
 * Supported Channels include Amazon Q Developer in chat applications, the Console Mobile Application, and emails (notifications-contacts).
 */
export declare const associateManagedNotificationAdditionalChannel: API.OperationMethod<AssociateManagedNotificationAdditionalChannelRequest, AssociateManagedNotificationAdditionalChannelResponse, AssociateManagedNotificationAdditionalChannelError, Credentials | HttpClient.HttpClient>;
export type AssociateOrganizationalUnitError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates an organizational unit with a notification configuration.
 */
export declare const associateOrganizationalUnit: API.OperationMethod<AssociateOrganizationalUnitRequest, AssociateOrganizationalUnitResponse, AssociateOrganizationalUnitError, Credentials | HttpClient.HttpClient>;
export type CreateEventRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an `EventRule` that is associated with a specified `NotificationConfiguration`.
 */
export declare const createEventRule: API.OperationMethod<CreateEventRuleRequest, CreateEventRuleResponse, CreateEventRuleError, Credentials | HttpClient.HttpClient>;
export type CreateNotificationConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new `NotificationConfiguration`.
 */
export declare const createNotificationConfiguration: API.OperationMethod<CreateNotificationConfigurationRequest, CreateNotificationConfigurationResponse, CreateNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteEventRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an `EventRule`.
 */
export declare const deleteEventRule: API.OperationMethod<DeleteEventRuleRequest, DeleteEventRuleResponse, DeleteEventRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteNotificationConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a `NotificationConfiguration`.
 */
export declare const deleteNotificationConfiguration: API.OperationMethod<DeleteNotificationConfigurationRequest, DeleteNotificationConfigurationResponse, DeleteNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeregisterNotificationHubError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deregisters a `NotificationHub` in the specified Region.
 *
 * You can't deregister the last `NotificationHub` in the account. `NotificationEvents` stored in the deregistered `NotificationHub` are no longer visible. Recreating a new `NotificationHub` in the same Region restores access to those `NotificationEvents`.
 */
export declare const deregisterNotificationHub: API.OperationMethod<DeregisterNotificationHubRequest, DeregisterNotificationHubResponse, DeregisterNotificationHubError, Credentials | HttpClient.HttpClient>;
export type DisableNotificationsAccessForOrganizationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disables service trust between User Notifications and Amazon Web Services Organizations.
 */
export declare const disableNotificationsAccessForOrganization: API.OperationMethod<DisableNotificationsAccessForOrganizationRequest, DisableNotificationsAccessForOrganizationResponse, DisableNotificationsAccessForOrganizationError, Credentials | HttpClient.HttpClient>;
export type DisassociateChannelError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a Channel from a specified `NotificationConfiguration`. Supported Channels include Amazon Q Developer in chat applications, the Console Mobile Application, and emails (notifications-contacts).
 */
export declare const disassociateChannel: API.OperationMethod<DisassociateChannelRequest, DisassociateChannelResponse, DisassociateChannelError, Credentials | HttpClient.HttpClient>;
export type DisassociateManagedNotificationAccountContactError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates an Account Contact with a particular `ManagedNotificationConfiguration`.
 */
export declare const disassociateManagedNotificationAccountContact: API.OperationMethod<DisassociateManagedNotificationAccountContactRequest, DisassociateManagedNotificationAccountContactResponse, DisassociateManagedNotificationAccountContactError, Credentials | HttpClient.HttpClient>;
export type DisassociateManagedNotificationAdditionalChannelError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates an additional Channel from a particular `ManagedNotificationConfiguration`.
 *
 * Supported Channels include Amazon Q Developer in chat applications, the Console Mobile Application, and emails (notifications-contacts).
 */
export declare const disassociateManagedNotificationAdditionalChannel: API.OperationMethod<DisassociateManagedNotificationAdditionalChannelRequest, DisassociateManagedNotificationAdditionalChannelResponse, DisassociateManagedNotificationAdditionalChannelError, Credentials | HttpClient.HttpClient>;
export type DisassociateOrganizationalUnitError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the association between an organizational unit and a notification configuration.
 */
export declare const disassociateOrganizationalUnit: API.OperationMethod<DisassociateOrganizationalUnitRequest, DisassociateOrganizationalUnitResponse, DisassociateOrganizationalUnitError, Credentials | HttpClient.HttpClient>;
export type EnableNotificationsAccessForOrganizationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables service trust between User Notifications and Amazon Web Services Organizations.
 */
export declare const enableNotificationsAccessForOrganization: API.OperationMethod<EnableNotificationsAccessForOrganizationRequest, EnableNotificationsAccessForOrganizationResponse, EnableNotificationsAccessForOrganizationError, Credentials | HttpClient.HttpClient>;
export type GetEventRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a specified `EventRule`.
 */
export declare const getEventRule: API.OperationMethod<GetEventRuleRequest, GetEventRuleResponse, GetEventRuleError, Credentials | HttpClient.HttpClient>;
export type GetManagedNotificationChildEventError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the child event of a specific given `ManagedNotificationEvent`.
 */
export declare const getManagedNotificationChildEvent: API.OperationMethod<GetManagedNotificationChildEventRequest, GetManagedNotificationChildEventResponse, GetManagedNotificationChildEventError, Credentials | HttpClient.HttpClient>;
export type GetManagedNotificationConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a specified `ManagedNotificationConfiguration`.
 */
export declare const getManagedNotificationConfiguration: API.OperationMethod<GetManagedNotificationConfigurationRequest, GetManagedNotificationConfigurationResponse, GetManagedNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetManagedNotificationEventError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a specified `ManagedNotificationEvent`.
 */
export declare const getManagedNotificationEvent: API.OperationMethod<GetManagedNotificationEventRequest, GetManagedNotificationEventResponse, GetManagedNotificationEventError, Credentials | HttpClient.HttpClient>;
export type GetNotificationConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a specified `NotificationConfiguration`.
 */
export declare const getNotificationConfiguration: API.OperationMethod<GetNotificationConfigurationRequest, GetNotificationConfigurationResponse, GetNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetNotificationEventError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a specified `NotificationEvent`.
 *
 * User Notifications stores notifications in the individual Regions you register as notification hubs and the Region of the source event rule. `GetNotificationEvent` only returns notifications stored in the same Region in which the action is called. User Notifications doesn't backfill notifications to new Regions selected as notification hubs. For this reason, we recommend that you make calls in your oldest registered notification hub. For more information, see Notification hubs in the *Amazon Web Services User Notifications User Guide*.
 */
export declare const getNotificationEvent: API.OperationMethod<GetNotificationEventRequest, GetNotificationEventResponse, GetNotificationEventError, Credentials | HttpClient.HttpClient>;
export type GetNotificationsAccessForOrganizationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the AccessStatus of Service Trust Enablement for User Notifications and Amazon Web Services Organizations.
 */
export declare const getNotificationsAccessForOrganization: API.OperationMethod<GetNotificationsAccessForOrganizationRequest, GetNotificationsAccessForOrganizationResponse, GetNotificationsAccessForOrganizationError, Credentials | HttpClient.HttpClient>;
export type ListChannelsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of Channels for a `NotificationConfiguration`.
 */
export declare const listChannels: API.PaginatedOperationMethod<ListChannelsRequest, ListChannelsResponse, ListChannelsError, Credentials | HttpClient.HttpClient, ChannelArn>;
export type ListEventRulesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of `EventRules` according to specified filters, in reverse chronological order (newest first).
 */
export declare const listEventRules: API.PaginatedOperationMethod<ListEventRulesRequest, ListEventRulesResponse, ListEventRulesError, Credentials | HttpClient.HttpClient, EventRuleStructure>;
export type ListManagedNotificationChannelAssociationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of Account contacts and Channels associated with a `ManagedNotificationConfiguration`, in paginated format.
 */
export declare const listManagedNotificationChannelAssociations: API.PaginatedOperationMethod<ListManagedNotificationChannelAssociationsRequest, ListManagedNotificationChannelAssociationsResponse, ListManagedNotificationChannelAssociationsError, Credentials | HttpClient.HttpClient, ManagedNotificationChannelAssociationSummary>;
export type ListManagedNotificationChildEventsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of `ManagedNotificationChildEvents` for a specified aggregate `ManagedNotificationEvent`, ordered by creation time in reverse chronological order (newest first).
 */
export declare const listManagedNotificationChildEvents: API.PaginatedOperationMethod<ListManagedNotificationChildEventsRequest, ListManagedNotificationChildEventsResponse, ListManagedNotificationChildEventsError, Credentials | HttpClient.HttpClient, ManagedNotificationChildEventOverview>;
export type ListManagedNotificationConfigurationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of Managed Notification Configurations according to specified filters, ordered by creation time in reverse chronological order (newest first).
 */
export declare const listManagedNotificationConfigurations: API.PaginatedOperationMethod<ListManagedNotificationConfigurationsRequest, ListManagedNotificationConfigurationsResponse, ListManagedNotificationConfigurationsError, Credentials | HttpClient.HttpClient, ManagedNotificationConfigurationStructure>;
export type ListManagedNotificationEventsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of Managed Notification Events according to specified filters, ordered by creation time in reverse chronological order (newest first).
 */
export declare const listManagedNotificationEvents: API.PaginatedOperationMethod<ListManagedNotificationEventsRequest, ListManagedNotificationEventsResponse, ListManagedNotificationEventsError, Credentials | HttpClient.HttpClient, ManagedNotificationEventOverview>;
export type ListMemberAccountsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of member accounts associated with a notification configuration.
 */
export declare const listMemberAccounts: API.PaginatedOperationMethod<ListMemberAccountsRequest, ListMemberAccountsResponse, ListMemberAccountsError, Credentials | HttpClient.HttpClient, MemberAccount>;
export type ListNotificationConfigurationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of abbreviated `NotificationConfigurations` according to specified filters, in reverse chronological order (newest first).
 */
export declare const listNotificationConfigurations: API.PaginatedOperationMethod<ListNotificationConfigurationsRequest, ListNotificationConfigurationsResponse, ListNotificationConfigurationsError, Credentials | HttpClient.HttpClient, NotificationConfigurationStructure>;
export type ListNotificationEventsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of `NotificationEvents` according to specified filters, in reverse chronological order (newest first).
 *
 * User Notifications stores notifications in the individual Regions you register as notification hubs and the Region of the source event rule. ListNotificationEvents only returns notifications stored in the same Region in which the action is called. User Notifications doesn't backfill notifications to new Regions selected as notification hubs. For this reason, we recommend that you make calls in your oldest registered notification hub. For more information, see Notification hubs in the *Amazon Web Services User Notifications User Guide*.
 */
export declare const listNotificationEvents: API.PaginatedOperationMethod<ListNotificationEventsRequest, ListNotificationEventsResponse, ListNotificationEventsError, Credentials | HttpClient.HttpClient, NotificationEventOverview>;
export type ListNotificationHubsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of `NotificationHubs`.
 */
export declare const listNotificationHubs: API.PaginatedOperationMethod<ListNotificationHubsRequest, ListNotificationHubsResponse, ListNotificationHubsError, Credentials | HttpClient.HttpClient, NotificationHubOverview>;
export type ListOrganizationalUnitsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of organizational units associated with a notification configuration.
 */
export declare const listOrganizationalUnits: API.PaginatedOperationMethod<ListOrganizationalUnitsRequest, ListOrganizationalUnitsResponse, ListOrganizationalUnitsError, Credentials | HttpClient.HttpClient, OrganizationalUnitId>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of tags for a specified Amazon Resource Name (ARN).
 *
 * For more information, see Tagging your Amazon Web Services resources in the *Tagging Amazon Web Services Resources User Guide*.
 *
 * This is only supported for `NotificationConfigurations`.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RegisterNotificationHubError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Registers a `NotificationHub` in the specified Region.
 *
 * There is a maximum of one `NotificationHub` per Region. You can have a maximum of 3 `NotificationHub` resources at a time.
 */
export declare const registerNotificationHub: API.OperationMethod<RegisterNotificationHubRequest, RegisterNotificationHubResponse, RegisterNotificationHubError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Tags the resource with a tag key and value.
 *
 * For more information, see Tagging your Amazon Web Services resources in the *Tagging Amazon Web Services Resources User Guide*.
 *
 * This is only supported for `NotificationConfigurations`.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Untags a resource with a specified Amazon Resource Name (ARN).
 *
 * For more information, see Tagging your Amazon Web Services resources in the *Tagging Amazon Web Services Resources User Guide*.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateEventRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing `EventRule`.
 */
export declare const updateEventRule: API.OperationMethod<UpdateEventRuleRequest, UpdateEventRuleResponse, UpdateEventRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateManagedNotificationChannelAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the `isSensitiveEventsSubscribed` property of a particular ManagedNotification channel association.
 */
export declare const updateManagedNotificationChannelAssociation: API.OperationMethod<UpdateManagedNotificationChannelAssociationRequest, UpdateManagedNotificationChannelAssociationResponse, UpdateManagedNotificationChannelAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateNotificationConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a `NotificationConfiguration`.
 */
export declare const updateNotificationConfiguration: API.OperationMethod<UpdateNotificationConfigurationRequest, UpdateNotificationConfigurationResponse, UpdateNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=notifications.d.ts.map