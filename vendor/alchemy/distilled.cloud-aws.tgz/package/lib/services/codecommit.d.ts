import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ActorDoesNotExistException_base: S.TaggedErrorClass<"ActorDoesNotExistException", {
    readonly message: any;
}>;
export declare class ActorDoesNotExistException extends /*@__PURE__*/ ActorDoesNotExistException_base {
}
declare const ApprovalRuleContentRequiredException_base: S.TaggedErrorClass<"ApprovalRuleContentRequiredException", {
    readonly message: any;
}>;
export declare class ApprovalRuleContentRequiredException extends /*@__PURE__*/ ApprovalRuleContentRequiredException_base {
}
declare const ApprovalRuleDoesNotExistException_base: S.TaggedErrorClass<"ApprovalRuleDoesNotExistException", {
    readonly message: any;
}>;
export declare class ApprovalRuleDoesNotExistException extends /*@__PURE__*/ ApprovalRuleDoesNotExistException_base {
}
declare const ApprovalRuleNameAlreadyExistsException_base: S.TaggedErrorClass<"ApprovalRuleNameAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ApprovalRuleNameAlreadyExistsException extends /*@__PURE__*/ ApprovalRuleNameAlreadyExistsException_base {
}
declare const ApprovalRuleNameRequiredException_base: S.TaggedErrorClass<"ApprovalRuleNameRequiredException", {
    readonly message: any;
}>;
export declare class ApprovalRuleNameRequiredException extends /*@__PURE__*/ ApprovalRuleNameRequiredException_base {
}
declare const ApprovalRuleTemplateContentRequiredException_base: S.TaggedErrorClass<"ApprovalRuleTemplateContentRequiredException", {
    readonly message: any;
}>;
export declare class ApprovalRuleTemplateContentRequiredException extends /*@__PURE__*/ ApprovalRuleTemplateContentRequiredException_base {
}
declare const ApprovalRuleTemplateDoesNotExistException_base: S.TaggedErrorClass<"ApprovalRuleTemplateDoesNotExistException", {
    readonly message: any;
}>;
export declare class ApprovalRuleTemplateDoesNotExistException extends /*@__PURE__*/ ApprovalRuleTemplateDoesNotExistException_base {
}
declare const ApprovalRuleTemplateInUseException_base: S.TaggedErrorClass<"ApprovalRuleTemplateInUseException", {
    readonly message: any;
}>;
export declare class ApprovalRuleTemplateInUseException extends /*@__PURE__*/ ApprovalRuleTemplateInUseException_base {
}
declare const ApprovalRuleTemplateNameAlreadyExistsException_base: S.TaggedErrorClass<"ApprovalRuleTemplateNameAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ApprovalRuleTemplateNameAlreadyExistsException extends /*@__PURE__*/ ApprovalRuleTemplateNameAlreadyExistsException_base {
}
declare const ApprovalRuleTemplateNameRequiredException_base: S.TaggedErrorClass<"ApprovalRuleTemplateNameRequiredException", {
    readonly message: any;
}>;
export declare class ApprovalRuleTemplateNameRequiredException extends /*@__PURE__*/ ApprovalRuleTemplateNameRequiredException_base {
}
declare const ApprovalStateRequiredException_base: S.TaggedErrorClass<"ApprovalStateRequiredException", {
    readonly message: any;
}>;
export declare class ApprovalStateRequiredException extends /*@__PURE__*/ ApprovalStateRequiredException_base {
}
declare const AuthorDoesNotExistException_base: S.TaggedErrorClass<"AuthorDoesNotExistException", {
    readonly message: any;
}>;
export declare class AuthorDoesNotExistException extends /*@__PURE__*/ AuthorDoesNotExistException_base {
}
declare const BeforeCommitIdAndAfterCommitIdAreSameException_base: S.TaggedErrorClass<"BeforeCommitIdAndAfterCommitIdAreSameException", {
    readonly message: any;
}>;
export declare class BeforeCommitIdAndAfterCommitIdAreSameException extends /*@__PURE__*/ BeforeCommitIdAndAfterCommitIdAreSameException_base {
}
declare const BlobIdDoesNotExistException_base: S.TaggedErrorClass<"BlobIdDoesNotExistException", {
    readonly message: any;
}>;
export declare class BlobIdDoesNotExistException extends /*@__PURE__*/ BlobIdDoesNotExistException_base {
}
declare const BlobIdRequiredException_base: S.TaggedErrorClass<"BlobIdRequiredException", {
    readonly message: any;
}>;
export declare class BlobIdRequiredException extends /*@__PURE__*/ BlobIdRequiredException_base {
}
declare const BranchDoesNotExistException_base: S.TaggedErrorClass<"BranchDoesNotExistException", {
    readonly message: any;
}>;
export declare class BranchDoesNotExistException extends /*@__PURE__*/ BranchDoesNotExistException_base {
}
declare const BranchNameExistsException_base: S.TaggedErrorClass<"BranchNameExistsException", {
    readonly message: any;
}>;
export declare class BranchNameExistsException extends /*@__PURE__*/ BranchNameExistsException_base {
}
declare const BranchNameIsTagNameException_base: S.TaggedErrorClass<"BranchNameIsTagNameException", {
    readonly message: any;
}>;
export declare class BranchNameIsTagNameException extends /*@__PURE__*/ BranchNameIsTagNameException_base {
}
declare const BranchNameRequiredException_base: S.TaggedErrorClass<"BranchNameRequiredException", {
    readonly message: any;
}>;
export declare class BranchNameRequiredException extends /*@__PURE__*/ BranchNameRequiredException_base {
}
declare const CannotDeleteApprovalRuleFromTemplateException_base: S.TaggedErrorClass<"CannotDeleteApprovalRuleFromTemplateException", {
    readonly message: any;
}>;
export declare class CannotDeleteApprovalRuleFromTemplateException extends /*@__PURE__*/ CannotDeleteApprovalRuleFromTemplateException_base {
}
declare const CannotModifyApprovalRuleFromTemplateException_base: S.TaggedErrorClass<"CannotModifyApprovalRuleFromTemplateException", {
    readonly message: any;
}>;
export declare class CannotModifyApprovalRuleFromTemplateException extends /*@__PURE__*/ CannotModifyApprovalRuleFromTemplateException_base {
}
declare const ClientRequestTokenRequiredException_base: S.TaggedErrorClass<"ClientRequestTokenRequiredException", {
    readonly message: any;
}>;
export declare class ClientRequestTokenRequiredException extends /*@__PURE__*/ ClientRequestTokenRequiredException_base {
}
declare const CommentContentRequiredException_base: S.TaggedErrorClass<"CommentContentRequiredException", {
    readonly message: any;
}>;
export declare class CommentContentRequiredException extends /*@__PURE__*/ CommentContentRequiredException_base {
}
declare const CommentContentSizeLimitExceededException_base: S.TaggedErrorClass<"CommentContentSizeLimitExceededException", {
    readonly message: any;
}>;
export declare class CommentContentSizeLimitExceededException extends /*@__PURE__*/ CommentContentSizeLimitExceededException_base {
}
declare const CommentDeletedException_base: S.TaggedErrorClass<"CommentDeletedException", {
    readonly message: any;
}>;
export declare class CommentDeletedException extends /*@__PURE__*/ CommentDeletedException_base {
}
declare const CommentDoesNotExistException_base: S.TaggedErrorClass<"CommentDoesNotExistException", {
    readonly message: any;
}>;
export declare class CommentDoesNotExistException extends /*@__PURE__*/ CommentDoesNotExistException_base {
}
declare const CommentIdRequiredException_base: S.TaggedErrorClass<"CommentIdRequiredException", {
    readonly message: any;
}>;
export declare class CommentIdRequiredException extends /*@__PURE__*/ CommentIdRequiredException_base {
}
declare const CommentNotCreatedByCallerException_base: S.TaggedErrorClass<"CommentNotCreatedByCallerException", {
    readonly message: any;
}>;
export declare class CommentNotCreatedByCallerException extends /*@__PURE__*/ CommentNotCreatedByCallerException_base {
}
declare const CommitDoesNotExistException_base: S.TaggedErrorClass<"CommitDoesNotExistException", {
    readonly message: any;
}>;
export declare class CommitDoesNotExistException extends /*@__PURE__*/ CommitDoesNotExistException_base {
}
declare const CommitIdDoesNotExistException_base: S.TaggedErrorClass<"CommitIdDoesNotExistException", {
    readonly message: any;
}>;
export declare class CommitIdDoesNotExistException extends /*@__PURE__*/ CommitIdDoesNotExistException_base {
}
declare const CommitIdRequiredException_base: S.TaggedErrorClass<"CommitIdRequiredException", {
    readonly message: any;
}>;
export declare class CommitIdRequiredException extends /*@__PURE__*/ CommitIdRequiredException_base {
}
declare const CommitIdsLimitExceededException_base: S.TaggedErrorClass<"CommitIdsLimitExceededException", {
    readonly message: any;
}>;
export declare class CommitIdsLimitExceededException extends /*@__PURE__*/ CommitIdsLimitExceededException_base {
}
declare const CommitIdsListRequiredException_base: S.TaggedErrorClass<"CommitIdsListRequiredException", {
    readonly message: any;
}>;
export declare class CommitIdsListRequiredException extends /*@__PURE__*/ CommitIdsListRequiredException_base {
}
declare const CommitMessageLengthExceededException_base: S.TaggedErrorClass<"CommitMessageLengthExceededException", {
    readonly message: any;
}>;
export declare class CommitMessageLengthExceededException extends /*@__PURE__*/ CommitMessageLengthExceededException_base {
}
declare const CommitRequiredException_base: S.TaggedErrorClass<"CommitRequiredException", {
    readonly message: any;
}>;
export declare class CommitRequiredException extends /*@__PURE__*/ CommitRequiredException_base {
}
declare const ConcurrentReferenceUpdateException_base: S.TaggedErrorClass<"ConcurrentReferenceUpdateException", {
    readonly message: any;
}>;
export declare class ConcurrentReferenceUpdateException extends /*@__PURE__*/ ConcurrentReferenceUpdateException_base {
}
declare const DefaultBranchCannotBeDeletedException_base: S.TaggedErrorClass<"DefaultBranchCannotBeDeletedException", {
    readonly message: any;
}>;
export declare class DefaultBranchCannotBeDeletedException extends /*@__PURE__*/ DefaultBranchCannotBeDeletedException_base {
}
declare const DirectoryNameConflictsWithFileNameException_base: S.TaggedErrorClass<"DirectoryNameConflictsWithFileNameException", {
    readonly message: any;
}>;
export declare class DirectoryNameConflictsWithFileNameException extends /*@__PURE__*/ DirectoryNameConflictsWithFileNameException_base {
}
declare const EncryptionIntegrityChecksFailedException_base: S.TaggedErrorClass<"EncryptionIntegrityChecksFailedException", {
    readonly message: any;
}>;
export declare class EncryptionIntegrityChecksFailedException extends /*@__PURE__*/ EncryptionIntegrityChecksFailedException_base {
}
declare const EncryptionKeyAccessDeniedException_base: S.TaggedErrorClass<"EncryptionKeyAccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class EncryptionKeyAccessDeniedException extends /*@__PURE__*/ EncryptionKeyAccessDeniedException_base {
}
declare const EncryptionKeyDisabledException_base: S.TaggedErrorClass<"EncryptionKeyDisabledException", {
    readonly message: any;
}>;
export declare class EncryptionKeyDisabledException extends /*@__PURE__*/ EncryptionKeyDisabledException_base {
}
declare const EncryptionKeyInvalidIdException_base: S.TaggedErrorClass<"EncryptionKeyInvalidIdException", {
    readonly message: any;
}>;
export declare class EncryptionKeyInvalidIdException extends /*@__PURE__*/ EncryptionKeyInvalidIdException_base {
}
declare const EncryptionKeyInvalidUsageException_base: S.TaggedErrorClass<"EncryptionKeyInvalidUsageException", {
    readonly message: any;
}>;
export declare class EncryptionKeyInvalidUsageException extends /*@__PURE__*/ EncryptionKeyInvalidUsageException_base {
}
declare const EncryptionKeyNotFoundException_base: S.TaggedErrorClass<"EncryptionKeyNotFoundException", {
    readonly message: any;
}>;
export declare class EncryptionKeyNotFoundException extends /*@__PURE__*/ EncryptionKeyNotFoundException_base {
}
declare const EncryptionKeyRequiredException_base: S.TaggedErrorClass<"EncryptionKeyRequiredException", {
    readonly message: any;
}>;
export declare class EncryptionKeyRequiredException extends /*@__PURE__*/ EncryptionKeyRequiredException_base {
}
declare const EncryptionKeyUnavailableException_base: S.TaggedErrorClass<"EncryptionKeyUnavailableException", {
    readonly message: any;
}>;
export declare class EncryptionKeyUnavailableException extends /*@__PURE__*/ EncryptionKeyUnavailableException_base {
}
declare const FileContentAndSourceFileSpecifiedException_base: S.TaggedErrorClass<"FileContentAndSourceFileSpecifiedException", {
    readonly message: any;
}>;
export declare class FileContentAndSourceFileSpecifiedException extends /*@__PURE__*/ FileContentAndSourceFileSpecifiedException_base {
}
declare const FileContentRequiredException_base: S.TaggedErrorClass<"FileContentRequiredException", {
    readonly message: any;
}>;
export declare class FileContentRequiredException extends /*@__PURE__*/ FileContentRequiredException_base {
}
declare const FileContentSizeLimitExceededException_base: S.TaggedErrorClass<"FileContentSizeLimitExceededException", {
    readonly message: any;
}>;
export declare class FileContentSizeLimitExceededException extends /*@__PURE__*/ FileContentSizeLimitExceededException_base {
}
declare const FileDoesNotExistException_base: S.TaggedErrorClass<"FileDoesNotExistException", {
    readonly message: any;
}>;
export declare class FileDoesNotExistException extends /*@__PURE__*/ FileDoesNotExistException_base {
}
declare const FileEntryRequiredException_base: S.TaggedErrorClass<"FileEntryRequiredException", {
    readonly message: any;
}>;
export declare class FileEntryRequiredException extends /*@__PURE__*/ FileEntryRequiredException_base {
}
declare const FileModeRequiredException_base: S.TaggedErrorClass<"FileModeRequiredException", {
    readonly message: any;
}>;
export declare class FileModeRequiredException extends /*@__PURE__*/ FileModeRequiredException_base {
}
declare const FileNameConflictsWithDirectoryNameException_base: S.TaggedErrorClass<"FileNameConflictsWithDirectoryNameException", {
    readonly message: any;
}>;
export declare class FileNameConflictsWithDirectoryNameException extends /*@__PURE__*/ FileNameConflictsWithDirectoryNameException_base {
}
declare const FilePathConflictsWithSubmodulePathException_base: S.TaggedErrorClass<"FilePathConflictsWithSubmodulePathException", {
    readonly message: any;
}>;
export declare class FilePathConflictsWithSubmodulePathException extends /*@__PURE__*/ FilePathConflictsWithSubmodulePathException_base {
}
declare const FileTooLargeException_base: S.TaggedErrorClass<"FileTooLargeException", {
    readonly message: any;
}>;
export declare class FileTooLargeException extends /*@__PURE__*/ FileTooLargeException_base {
}
declare const FolderContentSizeLimitExceededException_base: S.TaggedErrorClass<"FolderContentSizeLimitExceededException", {
    readonly message: any;
}>;
export declare class FolderContentSizeLimitExceededException extends /*@__PURE__*/ FolderContentSizeLimitExceededException_base {
}
declare const FolderDoesNotExistException_base: S.TaggedErrorClass<"FolderDoesNotExistException", {
    readonly message: any;
}>;
export declare class FolderDoesNotExistException extends /*@__PURE__*/ FolderDoesNotExistException_base {
}
declare const IdempotencyParameterMismatchException_base: S.TaggedErrorClass<"IdempotencyParameterMismatchException", {
    readonly message: any;
}>;
export declare class IdempotencyParameterMismatchException extends /*@__PURE__*/ IdempotencyParameterMismatchException_base {
}
declare const InvalidActorArnException_base: S.TaggedErrorClass<"InvalidActorArnException", {
    readonly message: any;
}>;
export declare class InvalidActorArnException extends /*@__PURE__*/ InvalidActorArnException_base {
}
declare const InvalidApprovalRuleContentException_base: S.TaggedErrorClass<"InvalidApprovalRuleContentException", {
    readonly message: any;
}>;
export declare class InvalidApprovalRuleContentException extends /*@__PURE__*/ InvalidApprovalRuleContentException_base {
}
declare const InvalidApprovalRuleNameException_base: S.TaggedErrorClass<"InvalidApprovalRuleNameException", {
    readonly message: any;
}>;
export declare class InvalidApprovalRuleNameException extends /*@__PURE__*/ InvalidApprovalRuleNameException_base {
}
declare const InvalidApprovalRuleTemplateContentException_base: S.TaggedErrorClass<"InvalidApprovalRuleTemplateContentException", {
    readonly message: any;
}>;
export declare class InvalidApprovalRuleTemplateContentException extends /*@__PURE__*/ InvalidApprovalRuleTemplateContentException_base {
}
declare const InvalidApprovalRuleTemplateDescriptionException_base: S.TaggedErrorClass<"InvalidApprovalRuleTemplateDescriptionException", {
    readonly message: any;
}>;
export declare class InvalidApprovalRuleTemplateDescriptionException extends /*@__PURE__*/ InvalidApprovalRuleTemplateDescriptionException_base {
}
declare const InvalidApprovalRuleTemplateNameException_base: S.TaggedErrorClass<"InvalidApprovalRuleTemplateNameException", {
    readonly message: any;
}>;
export declare class InvalidApprovalRuleTemplateNameException extends /*@__PURE__*/ InvalidApprovalRuleTemplateNameException_base {
}
declare const InvalidApprovalStateException_base: S.TaggedErrorClass<"InvalidApprovalStateException", {
    readonly message: any;
}>;
export declare class InvalidApprovalStateException extends /*@__PURE__*/ InvalidApprovalStateException_base {
}
declare const InvalidAuthorArnException_base: S.TaggedErrorClass<"InvalidAuthorArnException", {
    readonly message: any;
}>;
export declare class InvalidAuthorArnException extends /*@__PURE__*/ InvalidAuthorArnException_base {
}
declare const InvalidBlobIdException_base: S.TaggedErrorClass<"InvalidBlobIdException", {
    readonly message: any;
}>;
export declare class InvalidBlobIdException extends /*@__PURE__*/ InvalidBlobIdException_base {
}
declare const InvalidBranchNameException_base: S.TaggedErrorClass<"InvalidBranchNameException", {
    readonly message: any;
}>;
export declare class InvalidBranchNameException extends /*@__PURE__*/ InvalidBranchNameException_base {
}
declare const InvalidClientRequestTokenException_base: S.TaggedErrorClass<"InvalidClientRequestTokenException", {
    readonly message: any;
}>;
export declare class InvalidClientRequestTokenException extends /*@__PURE__*/ InvalidClientRequestTokenException_base {
}
declare const InvalidCommentIdException_base: S.TaggedErrorClass<"InvalidCommentIdException", {
    readonly message: any;
}>;
export declare class InvalidCommentIdException extends /*@__PURE__*/ InvalidCommentIdException_base {
}
declare const InvalidCommitException_base: S.TaggedErrorClass<"InvalidCommitException", {
    readonly message: any;
}>;
export declare class InvalidCommitException extends /*@__PURE__*/ InvalidCommitException_base {
}
declare const InvalidCommitIdException_base: S.TaggedErrorClass<"InvalidCommitIdException", {
    readonly message: any;
}>;
export declare class InvalidCommitIdException extends /*@__PURE__*/ InvalidCommitIdException_base {
}
declare const InvalidConflictDetailLevelException_base: S.TaggedErrorClass<"InvalidConflictDetailLevelException", {
    readonly message: any;
}>;
export declare class InvalidConflictDetailLevelException extends /*@__PURE__*/ InvalidConflictDetailLevelException_base {
}
declare const InvalidConflictResolutionException_base: S.TaggedErrorClass<"InvalidConflictResolutionException", {
    readonly message: any;
}>;
export declare class InvalidConflictResolutionException extends /*@__PURE__*/ InvalidConflictResolutionException_base {
}
declare const InvalidConflictResolutionStrategyException_base: S.TaggedErrorClass<"InvalidConflictResolutionStrategyException", {
    readonly message: any;
}>;
export declare class InvalidConflictResolutionStrategyException extends /*@__PURE__*/ InvalidConflictResolutionStrategyException_base {
}
declare const InvalidContinuationTokenException_base: S.TaggedErrorClass<"InvalidContinuationTokenException", {
    readonly message: any;
}>;
export declare class InvalidContinuationTokenException extends /*@__PURE__*/ InvalidContinuationTokenException_base {
}
declare const InvalidDeletionParameterException_base: S.TaggedErrorClass<"InvalidDeletionParameterException", {
    readonly message: any;
}>;
export declare class InvalidDeletionParameterException extends /*@__PURE__*/ InvalidDeletionParameterException_base {
}
declare const InvalidDescriptionException_base: S.TaggedErrorClass<"InvalidDescriptionException", {
    readonly message: any;
}>;
export declare class InvalidDescriptionException extends /*@__PURE__*/ InvalidDescriptionException_base {
}
declare const InvalidDestinationCommitSpecifierException_base: S.TaggedErrorClass<"InvalidDestinationCommitSpecifierException", {
    readonly message: any;
}>;
export declare class InvalidDestinationCommitSpecifierException extends /*@__PURE__*/ InvalidDestinationCommitSpecifierException_base {
}
declare const InvalidEmailException_base: S.TaggedErrorClass<"InvalidEmailException", {
    readonly message: any;
}>;
export declare class InvalidEmailException extends /*@__PURE__*/ InvalidEmailException_base {
}
declare const InvalidFileLocationException_base: S.TaggedErrorClass<"InvalidFileLocationException", {
    readonly message: any;
}>;
export declare class InvalidFileLocationException extends /*@__PURE__*/ InvalidFileLocationException_base {
}
declare const InvalidFileModeException_base: S.TaggedErrorClass<"InvalidFileModeException", {
    readonly message: any;
}>;
export declare class InvalidFileModeException extends /*@__PURE__*/ InvalidFileModeException_base {
}
declare const InvalidFilePositionException_base: S.TaggedErrorClass<"InvalidFilePositionException", {
    readonly message: any;
}>;
export declare class InvalidFilePositionException extends /*@__PURE__*/ InvalidFilePositionException_base {
}
declare const InvalidMaxConflictFilesException_base: S.TaggedErrorClass<"InvalidMaxConflictFilesException", {
    readonly message: any;
}>;
export declare class InvalidMaxConflictFilesException extends /*@__PURE__*/ InvalidMaxConflictFilesException_base {
}
declare const InvalidMaxMergeHunksException_base: S.TaggedErrorClass<"InvalidMaxMergeHunksException", {
    readonly message: any;
}>;
export declare class InvalidMaxMergeHunksException extends /*@__PURE__*/ InvalidMaxMergeHunksException_base {
}
declare const InvalidMaxResultsException_base: S.TaggedErrorClass<"InvalidMaxResultsException", {
    readonly message: any;
}>;
export declare class InvalidMaxResultsException extends /*@__PURE__*/ InvalidMaxResultsException_base {
}
declare const InvalidMergeOptionException_base: S.TaggedErrorClass<"InvalidMergeOptionException", {
    readonly message: any;
}>;
export declare class InvalidMergeOptionException extends /*@__PURE__*/ InvalidMergeOptionException_base {
}
declare const InvalidOrderException_base: S.TaggedErrorClass<"InvalidOrderException", {
    readonly message: any;
}>;
export declare class InvalidOrderException extends /*@__PURE__*/ InvalidOrderException_base {
}
declare const InvalidOverrideStatusException_base: S.TaggedErrorClass<"InvalidOverrideStatusException", {
    readonly message: any;
}>;
export declare class InvalidOverrideStatusException extends /*@__PURE__*/ InvalidOverrideStatusException_base {
}
declare const InvalidParentCommitIdException_base: S.TaggedErrorClass<"InvalidParentCommitIdException", {
    readonly message: any;
}>;
export declare class InvalidParentCommitIdException extends /*@__PURE__*/ InvalidParentCommitIdException_base {
}
declare const InvalidPathException_base: S.TaggedErrorClass<"InvalidPathException", {
    readonly message: any;
}>;
export declare class InvalidPathException extends /*@__PURE__*/ InvalidPathException_base {
}
declare const InvalidPullRequestEventTypeException_base: S.TaggedErrorClass<"InvalidPullRequestEventTypeException", {
    readonly message: any;
}>;
export declare class InvalidPullRequestEventTypeException extends /*@__PURE__*/ InvalidPullRequestEventTypeException_base {
}
declare const InvalidPullRequestIdException_base: S.TaggedErrorClass<"InvalidPullRequestIdException", {
    readonly message: any;
}>;
export declare class InvalidPullRequestIdException extends /*@__PURE__*/ InvalidPullRequestIdException_base {
}
declare const InvalidPullRequestStatusException_base: S.TaggedErrorClass<"InvalidPullRequestStatusException", {
    readonly message: any;
}>;
export declare class InvalidPullRequestStatusException extends /*@__PURE__*/ InvalidPullRequestStatusException_base {
}
declare const InvalidPullRequestStatusUpdateException_base: S.TaggedErrorClass<"InvalidPullRequestStatusUpdateException", {
    readonly message: any;
}>;
export declare class InvalidPullRequestStatusUpdateException extends /*@__PURE__*/ InvalidPullRequestStatusUpdateException_base {
}
declare const InvalidReactionUserArnException_base: S.TaggedErrorClass<"InvalidReactionUserArnException", {
    readonly message: any;
}>;
export declare class InvalidReactionUserArnException extends /*@__PURE__*/ InvalidReactionUserArnException_base {
}
declare const InvalidReactionValueException_base: S.TaggedErrorClass<"InvalidReactionValueException", {
    readonly message: any;
}>;
export declare class InvalidReactionValueException extends /*@__PURE__*/ InvalidReactionValueException_base {
}
declare const InvalidReferenceNameException_base: S.TaggedErrorClass<"InvalidReferenceNameException", {
    readonly message: any;
}>;
export declare class InvalidReferenceNameException extends /*@__PURE__*/ InvalidReferenceNameException_base {
}
declare const InvalidRelativeFileVersionEnumException_base: S.TaggedErrorClass<"InvalidRelativeFileVersionEnumException", {
    readonly message: any;
}>;
export declare class InvalidRelativeFileVersionEnumException extends /*@__PURE__*/ InvalidRelativeFileVersionEnumException_base {
}
declare const InvalidReplacementContentException_base: S.TaggedErrorClass<"InvalidReplacementContentException", {
    readonly message: any;
}>;
export declare class InvalidReplacementContentException extends /*@__PURE__*/ InvalidReplacementContentException_base {
}
declare const InvalidReplacementTypeException_base: S.TaggedErrorClass<"InvalidReplacementTypeException", {
    readonly message: any;
}>;
export declare class InvalidReplacementTypeException extends /*@__PURE__*/ InvalidReplacementTypeException_base {
}
declare const InvalidRepositoryDescriptionException_base: S.TaggedErrorClass<"InvalidRepositoryDescriptionException", {
    readonly message: any;
}>;
export declare class InvalidRepositoryDescriptionException extends /*@__PURE__*/ InvalidRepositoryDescriptionException_base {
}
declare const InvalidRepositoryNameException_base: S.TaggedErrorClass<"InvalidRepositoryNameException", {
    readonly message: any;
}>;
export declare class InvalidRepositoryNameException extends /*@__PURE__*/ InvalidRepositoryNameException_base {
}
declare const InvalidRepositoryTriggerBranchNameException_base: S.TaggedErrorClass<"InvalidRepositoryTriggerBranchNameException", {
    readonly message: any;
}>;
export declare class InvalidRepositoryTriggerBranchNameException extends /*@__PURE__*/ InvalidRepositoryTriggerBranchNameException_base {
}
declare const InvalidRepositoryTriggerCustomDataException_base: S.TaggedErrorClass<"InvalidRepositoryTriggerCustomDataException", {
    readonly message: any;
}>;
export declare class InvalidRepositoryTriggerCustomDataException extends /*@__PURE__*/ InvalidRepositoryTriggerCustomDataException_base {
}
declare const InvalidRepositoryTriggerDestinationArnException_base: S.TaggedErrorClass<"InvalidRepositoryTriggerDestinationArnException", {
    readonly message: any;
}>;
export declare class InvalidRepositoryTriggerDestinationArnException extends /*@__PURE__*/ InvalidRepositoryTriggerDestinationArnException_base {
}
declare const InvalidRepositoryTriggerEventsException_base: S.TaggedErrorClass<"InvalidRepositoryTriggerEventsException", {
    readonly message: any;
}>;
export declare class InvalidRepositoryTriggerEventsException extends /*@__PURE__*/ InvalidRepositoryTriggerEventsException_base {
}
declare const InvalidRepositoryTriggerNameException_base: S.TaggedErrorClass<"InvalidRepositoryTriggerNameException", {
    readonly message: any;
}>;
export declare class InvalidRepositoryTriggerNameException extends /*@__PURE__*/ InvalidRepositoryTriggerNameException_base {
}
declare const InvalidRepositoryTriggerRegionException_base: S.TaggedErrorClass<"InvalidRepositoryTriggerRegionException", {
    readonly message: any;
}>;
export declare class InvalidRepositoryTriggerRegionException extends /*@__PURE__*/ InvalidRepositoryTriggerRegionException_base {
}
declare const InvalidResourceArnException_base: S.TaggedErrorClass<"InvalidResourceArnException", {
    readonly message: any;
}>;
export declare class InvalidResourceArnException extends /*@__PURE__*/ InvalidResourceArnException_base {
}
declare const InvalidRevisionIdException_base: S.TaggedErrorClass<"InvalidRevisionIdException", {
    readonly message: any;
}>;
export declare class InvalidRevisionIdException extends /*@__PURE__*/ InvalidRevisionIdException_base {
}
declare const InvalidRuleContentSha256Exception_base: S.TaggedErrorClass<"InvalidRuleContentSha256Exception", {
    readonly message: any;
}>;
export declare class InvalidRuleContentSha256Exception extends /*@__PURE__*/ InvalidRuleContentSha256Exception_base {
}
declare const InvalidSortByException_base: S.TaggedErrorClass<"InvalidSortByException", {
    readonly message: any;
}>;
export declare class InvalidSortByException extends /*@__PURE__*/ InvalidSortByException_base {
}
declare const InvalidSourceCommitSpecifierException_base: S.TaggedErrorClass<"InvalidSourceCommitSpecifierException", {
    readonly message: any;
}>;
export declare class InvalidSourceCommitSpecifierException extends /*@__PURE__*/ InvalidSourceCommitSpecifierException_base {
}
declare const InvalidSystemTagUsageException_base: S.TaggedErrorClass<"InvalidSystemTagUsageException", {
    readonly message: any;
}>;
export declare class InvalidSystemTagUsageException extends /*@__PURE__*/ InvalidSystemTagUsageException_base {
}
declare const InvalidTagKeysListException_base: S.TaggedErrorClass<"InvalidTagKeysListException", {
    readonly message: any;
}>;
export declare class InvalidTagKeysListException extends /*@__PURE__*/ InvalidTagKeysListException_base {
}
declare const InvalidTagsMapException_base: S.TaggedErrorClass<"InvalidTagsMapException", {
    readonly message: any;
}>;
export declare class InvalidTagsMapException extends /*@__PURE__*/ InvalidTagsMapException_base {
}
declare const InvalidTargetBranchException_base: S.TaggedErrorClass<"InvalidTargetBranchException", {
    readonly message: any;
}>;
export declare class InvalidTargetBranchException extends /*@__PURE__*/ InvalidTargetBranchException_base {
}
declare const InvalidTargetException_base: S.TaggedErrorClass<"InvalidTargetException", {
    readonly message: any;
}>;
export declare class InvalidTargetException extends /*@__PURE__*/ InvalidTargetException_base {
}
declare const InvalidTargetsException_base: S.TaggedErrorClass<"InvalidTargetsException", {
    readonly message: any;
}>;
export declare class InvalidTargetsException extends /*@__PURE__*/ InvalidTargetsException_base {
}
declare const InvalidTitleException_base: S.TaggedErrorClass<"InvalidTitleException", {
    readonly message: any;
}>;
export declare class InvalidTitleException extends /*@__PURE__*/ InvalidTitleException_base {
}
declare const ManualMergeRequiredException_base: S.TaggedErrorClass<"ManualMergeRequiredException", {
    readonly message: any;
}>;
export declare class ManualMergeRequiredException extends /*@__PURE__*/ ManualMergeRequiredException_base {
}
declare const MaximumBranchesExceededException_base: S.TaggedErrorClass<"MaximumBranchesExceededException", {
    readonly message: any;
}>;
export declare class MaximumBranchesExceededException extends /*@__PURE__*/ MaximumBranchesExceededException_base {
}
declare const MaximumConflictResolutionEntriesExceededException_base: S.TaggedErrorClass<"MaximumConflictResolutionEntriesExceededException", {
    readonly message: any;
}>;
export declare class MaximumConflictResolutionEntriesExceededException extends /*@__PURE__*/ MaximumConflictResolutionEntriesExceededException_base {
}
declare const MaximumFileContentToLoadExceededException_base: S.TaggedErrorClass<"MaximumFileContentToLoadExceededException", {
    readonly message: any;
}>;
export declare class MaximumFileContentToLoadExceededException extends /*@__PURE__*/ MaximumFileContentToLoadExceededException_base {
}
declare const MaximumFileEntriesExceededException_base: S.TaggedErrorClass<"MaximumFileEntriesExceededException", {
    readonly message: any;
}>;
export declare class MaximumFileEntriesExceededException extends /*@__PURE__*/ MaximumFileEntriesExceededException_base {
}
declare const MaximumItemsToCompareExceededException_base: S.TaggedErrorClass<"MaximumItemsToCompareExceededException", {
    readonly message: any;
}>;
export declare class MaximumItemsToCompareExceededException extends /*@__PURE__*/ MaximumItemsToCompareExceededException_base {
}
declare const MaximumNumberOfApprovalsExceededException_base: S.TaggedErrorClass<"MaximumNumberOfApprovalsExceededException", {
    readonly message: any;
}>;
export declare class MaximumNumberOfApprovalsExceededException extends /*@__PURE__*/ MaximumNumberOfApprovalsExceededException_base {
}
declare const MaximumOpenPullRequestsExceededException_base: S.TaggedErrorClass<"MaximumOpenPullRequestsExceededException", {
    readonly message: any;
}>;
export declare class MaximumOpenPullRequestsExceededException extends /*@__PURE__*/ MaximumOpenPullRequestsExceededException_base {
}
declare const MaximumRepositoryNamesExceededException_base: S.TaggedErrorClass<"MaximumRepositoryNamesExceededException", {
    readonly message: any;
}>;
export declare class MaximumRepositoryNamesExceededException extends /*@__PURE__*/ MaximumRepositoryNamesExceededException_base {
}
declare const MaximumRepositoryTriggersExceededException_base: S.TaggedErrorClass<"MaximumRepositoryTriggersExceededException", {
    readonly message: any;
}>;
export declare class MaximumRepositoryTriggersExceededException extends /*@__PURE__*/ MaximumRepositoryTriggersExceededException_base {
}
declare const MaximumRuleTemplatesAssociatedWithRepositoryException_base: S.TaggedErrorClass<"MaximumRuleTemplatesAssociatedWithRepositoryException", {
    readonly message: any;
}>;
export declare class MaximumRuleTemplatesAssociatedWithRepositoryException extends /*@__PURE__*/ MaximumRuleTemplatesAssociatedWithRepositoryException_base {
}
declare const MergeOptionRequiredException_base: S.TaggedErrorClass<"MergeOptionRequiredException", {
    readonly message: any;
}>;
export declare class MergeOptionRequiredException extends /*@__PURE__*/ MergeOptionRequiredException_base {
}
declare const MultipleConflictResolutionEntriesException_base: S.TaggedErrorClass<"MultipleConflictResolutionEntriesException", {
    readonly message: any;
}>;
export declare class MultipleConflictResolutionEntriesException extends /*@__PURE__*/ MultipleConflictResolutionEntriesException_base {
}
declare const MultipleRepositoriesInPullRequestException_base: S.TaggedErrorClass<"MultipleRepositoriesInPullRequestException", {
    readonly message: any;
}>;
export declare class MultipleRepositoriesInPullRequestException extends /*@__PURE__*/ MultipleRepositoriesInPullRequestException_base {
}
declare const NameLengthExceededException_base: S.TaggedErrorClass<"NameLengthExceededException", {
    readonly message: any;
}>;
export declare class NameLengthExceededException extends /*@__PURE__*/ NameLengthExceededException_base {
}
declare const NoChangeException_base: S.TaggedErrorClass<"NoChangeException", {
    readonly message: any;
}>;
export declare class NoChangeException extends /*@__PURE__*/ NoChangeException_base {
}
declare const NumberOfRulesExceededException_base: S.TaggedErrorClass<"NumberOfRulesExceededException", {
    readonly message: any;
}>;
export declare class NumberOfRulesExceededException extends /*@__PURE__*/ NumberOfRulesExceededException_base {
}
declare const NumberOfRuleTemplatesExceededException_base: S.TaggedErrorClass<"NumberOfRuleTemplatesExceededException", {
    readonly message: any;
}>;
export declare class NumberOfRuleTemplatesExceededException extends /*@__PURE__*/ NumberOfRuleTemplatesExceededException_base {
}
declare const OperationNotAllowedException_base: S.TaggedErrorClass<"OperationNotAllowedException", {
    readonly message: any;
}>;
export declare class OperationNotAllowedException extends /*@__PURE__*/ OperationNotAllowedException_base {
}
declare const OverrideAlreadySetException_base: S.TaggedErrorClass<"OverrideAlreadySetException", {
    readonly message: any;
}>;
export declare class OverrideAlreadySetException extends /*@__PURE__*/ OverrideAlreadySetException_base {
}
declare const OverrideStatusRequiredException_base: S.TaggedErrorClass<"OverrideStatusRequiredException", {
    readonly message: any;
}>;
export declare class OverrideStatusRequiredException extends /*@__PURE__*/ OverrideStatusRequiredException_base {
}
declare const ParentCommitDoesNotExistException_base: S.TaggedErrorClass<"ParentCommitDoesNotExistException", {
    readonly message: any;
}>;
export declare class ParentCommitDoesNotExistException extends /*@__PURE__*/ ParentCommitDoesNotExistException_base {
}
declare const ParentCommitIdOutdatedException_base: S.TaggedErrorClass<"ParentCommitIdOutdatedException", {
    readonly message: any;
}>;
export declare class ParentCommitIdOutdatedException extends /*@__PURE__*/ ParentCommitIdOutdatedException_base {
}
declare const ParentCommitIdRequiredException_base: S.TaggedErrorClass<"ParentCommitIdRequiredException", {
    readonly message: any;
}>;
export declare class ParentCommitIdRequiredException extends /*@__PURE__*/ ParentCommitIdRequiredException_base {
}
declare const PathDoesNotExistException_base: S.TaggedErrorClass<"PathDoesNotExistException", {
    readonly message: any;
}>;
export declare class PathDoesNotExistException extends /*@__PURE__*/ PathDoesNotExistException_base {
}
declare const PathRequiredException_base: S.TaggedErrorClass<"PathRequiredException", {
    readonly message: any;
}>;
export declare class PathRequiredException extends /*@__PURE__*/ PathRequiredException_base {
}
declare const PullRequestAlreadyClosedException_base: S.TaggedErrorClass<"PullRequestAlreadyClosedException", {
    readonly message: any;
}>;
export declare class PullRequestAlreadyClosedException extends /*@__PURE__*/ PullRequestAlreadyClosedException_base {
}
declare const PullRequestApprovalRulesNotSatisfiedException_base: S.TaggedErrorClass<"PullRequestApprovalRulesNotSatisfiedException", {
    readonly message: any;
}>;
export declare class PullRequestApprovalRulesNotSatisfiedException extends /*@__PURE__*/ PullRequestApprovalRulesNotSatisfiedException_base {
}
declare const PullRequestCannotBeApprovedByAuthorException_base: S.TaggedErrorClass<"PullRequestCannotBeApprovedByAuthorException", {
    readonly message: any;
}>;
export declare class PullRequestCannotBeApprovedByAuthorException extends /*@__PURE__*/ PullRequestCannotBeApprovedByAuthorException_base {
}
declare const PullRequestDoesNotExistException_base: S.TaggedErrorClass<"PullRequestDoesNotExistException", {
    readonly message: any;
}>;
export declare class PullRequestDoesNotExistException extends /*@__PURE__*/ PullRequestDoesNotExistException_base {
}
declare const PullRequestIdRequiredException_base: S.TaggedErrorClass<"PullRequestIdRequiredException", {
    readonly message: any;
}>;
export declare class PullRequestIdRequiredException extends /*@__PURE__*/ PullRequestIdRequiredException_base {
}
declare const PullRequestStatusRequiredException_base: S.TaggedErrorClass<"PullRequestStatusRequiredException", {
    readonly message: any;
}>;
export declare class PullRequestStatusRequiredException extends /*@__PURE__*/ PullRequestStatusRequiredException_base {
}
declare const PutFileEntryConflictException_base: S.TaggedErrorClass<"PutFileEntryConflictException", {
    readonly message: any;
}>;
export declare class PutFileEntryConflictException extends /*@__PURE__*/ PutFileEntryConflictException_base {
}
declare const ReactionLimitExceededException_base: S.TaggedErrorClass<"ReactionLimitExceededException", {
    readonly message: any;
}>;
export declare class ReactionLimitExceededException extends /*@__PURE__*/ ReactionLimitExceededException_base {
}
declare const ReactionValueRequiredException_base: S.TaggedErrorClass<"ReactionValueRequiredException", {
    readonly message: any;
}>;
export declare class ReactionValueRequiredException extends /*@__PURE__*/ ReactionValueRequiredException_base {
}
declare const ReferenceDoesNotExistException_base: S.TaggedErrorClass<"ReferenceDoesNotExistException", {
    readonly message: any;
}>;
export declare class ReferenceDoesNotExistException extends /*@__PURE__*/ ReferenceDoesNotExistException_base {
}
declare const ReferenceNameRequiredException_base: S.TaggedErrorClass<"ReferenceNameRequiredException", {
    readonly message: any;
}>;
export declare class ReferenceNameRequiredException extends /*@__PURE__*/ ReferenceNameRequiredException_base {
}
declare const ReferenceTypeNotSupportedException_base: S.TaggedErrorClass<"ReferenceTypeNotSupportedException", {
    readonly message: any;
}>;
export declare class ReferenceTypeNotSupportedException extends /*@__PURE__*/ ReferenceTypeNotSupportedException_base {
}
declare const ReplacementContentRequiredException_base: S.TaggedErrorClass<"ReplacementContentRequiredException", {
    readonly message: any;
}>;
export declare class ReplacementContentRequiredException extends /*@__PURE__*/ ReplacementContentRequiredException_base {
}
declare const ReplacementTypeRequiredException_base: S.TaggedErrorClass<"ReplacementTypeRequiredException", {
    readonly message: any;
}>;
export declare class ReplacementTypeRequiredException extends /*@__PURE__*/ ReplacementTypeRequiredException_base {
}
declare const RepositoryDoesNotExistException_base: S.TaggedErrorClass<"RepositoryDoesNotExistException", {
    readonly message: any;
}>;
export declare class RepositoryDoesNotExistException extends /*@__PURE__*/ RepositoryDoesNotExistException_base {
}
declare const RepositoryLimitExceededException_base: S.TaggedErrorClass<"RepositoryLimitExceededException", {
    readonly message: any;
}>;
export declare class RepositoryLimitExceededException extends /*@__PURE__*/ RepositoryLimitExceededException_base {
}
declare const RepositoryNameExistsException_base: S.TaggedErrorClass<"RepositoryNameExistsException", {
    readonly message: any;
}>;
export declare class RepositoryNameExistsException extends /*@__PURE__*/ RepositoryNameExistsException_base {
}
declare const RepositoryNameRequiredException_base: S.TaggedErrorClass<"RepositoryNameRequiredException", {
    readonly message: any;
}>;
export declare class RepositoryNameRequiredException extends /*@__PURE__*/ RepositoryNameRequiredException_base {
}
declare const RepositoryNamesRequiredException_base: S.TaggedErrorClass<"RepositoryNamesRequiredException", {
    readonly message: any;
}>;
export declare class RepositoryNamesRequiredException extends /*@__PURE__*/ RepositoryNamesRequiredException_base {
}
declare const RepositoryNotAssociatedWithPullRequestException_base: S.TaggedErrorClass<"RepositoryNotAssociatedWithPullRequestException", {
    readonly message: any;
}>;
export declare class RepositoryNotAssociatedWithPullRequestException extends /*@__PURE__*/ RepositoryNotAssociatedWithPullRequestException_base {
}
declare const RepositoryTriggerBranchNameListRequiredException_base: S.TaggedErrorClass<"RepositoryTriggerBranchNameListRequiredException", {
    readonly message: any;
}>;
export declare class RepositoryTriggerBranchNameListRequiredException extends /*@__PURE__*/ RepositoryTriggerBranchNameListRequiredException_base {
}
declare const RepositoryTriggerDestinationArnRequiredException_base: S.TaggedErrorClass<"RepositoryTriggerDestinationArnRequiredException", {
    readonly message: any;
}>;
export declare class RepositoryTriggerDestinationArnRequiredException extends /*@__PURE__*/ RepositoryTriggerDestinationArnRequiredException_base {
}
declare const RepositoryTriggerEventsListRequiredException_base: S.TaggedErrorClass<"RepositoryTriggerEventsListRequiredException", {
    readonly message: any;
}>;
export declare class RepositoryTriggerEventsListRequiredException extends /*@__PURE__*/ RepositoryTriggerEventsListRequiredException_base {
}
declare const RepositoryTriggerNameRequiredException_base: S.TaggedErrorClass<"RepositoryTriggerNameRequiredException", {
    readonly message: any;
}>;
export declare class RepositoryTriggerNameRequiredException extends /*@__PURE__*/ RepositoryTriggerNameRequiredException_base {
}
declare const RepositoryTriggersListRequiredException_base: S.TaggedErrorClass<"RepositoryTriggersListRequiredException", {
    readonly message: any;
}>;
export declare class RepositoryTriggersListRequiredException extends /*@__PURE__*/ RepositoryTriggersListRequiredException_base {
}
declare const ResourceArnRequiredException_base: S.TaggedErrorClass<"ResourceArnRequiredException", {
    readonly message: any;
}>;
export declare class ResourceArnRequiredException extends /*@__PURE__*/ ResourceArnRequiredException_base {
}
declare const RestrictedSourceFileException_base: S.TaggedErrorClass<"RestrictedSourceFileException", {
    readonly message: any;
}>;
export declare class RestrictedSourceFileException extends /*@__PURE__*/ RestrictedSourceFileException_base {
}
declare const RevisionIdRequiredException_base: S.TaggedErrorClass<"RevisionIdRequiredException", {
    readonly message: any;
}>;
export declare class RevisionIdRequiredException extends /*@__PURE__*/ RevisionIdRequiredException_base {
}
declare const RevisionNotCurrentException_base: S.TaggedErrorClass<"RevisionNotCurrentException", {
    readonly message: any;
}>;
export declare class RevisionNotCurrentException extends /*@__PURE__*/ RevisionNotCurrentException_base {
}
declare const SameFileContentException_base: S.TaggedErrorClass<"SameFileContentException", {
    readonly message: any;
}>;
export declare class SameFileContentException extends /*@__PURE__*/ SameFileContentException_base {
}
declare const SamePathRequestException_base: S.TaggedErrorClass<"SamePathRequestException", {
    readonly message: any;
}>;
export declare class SamePathRequestException extends /*@__PURE__*/ SamePathRequestException_base {
}
declare const SourceAndDestinationAreSameException_base: S.TaggedErrorClass<"SourceAndDestinationAreSameException", {
    readonly message: any;
}>;
export declare class SourceAndDestinationAreSameException extends /*@__PURE__*/ SourceAndDestinationAreSameException_base {
}
declare const SourceFileOrContentRequiredException_base: S.TaggedErrorClass<"SourceFileOrContentRequiredException", {
    readonly message: any;
}>;
export declare class SourceFileOrContentRequiredException extends /*@__PURE__*/ SourceFileOrContentRequiredException_base {
}
declare const TagKeysListRequiredException_base: S.TaggedErrorClass<"TagKeysListRequiredException", {
    readonly message: any;
}>;
export declare class TagKeysListRequiredException extends /*@__PURE__*/ TagKeysListRequiredException_base {
}
declare const TagPolicyException_base: S.TaggedErrorClass<"TagPolicyException", {
    readonly message: any;
}>;
export declare class TagPolicyException extends /*@__PURE__*/ TagPolicyException_base {
}
declare const TagsMapRequiredException_base: S.TaggedErrorClass<"TagsMapRequiredException", {
    readonly message: any;
}>;
export declare class TagsMapRequiredException extends /*@__PURE__*/ TagsMapRequiredException_base {
}
declare const TargetRequiredException_base: S.TaggedErrorClass<"TargetRequiredException", {
    readonly message: any;
}>;
export declare class TargetRequiredException extends /*@__PURE__*/ TargetRequiredException_base {
}
declare const TargetsRequiredException_base: S.TaggedErrorClass<"TargetsRequiredException", {
    readonly message: any;
}>;
export declare class TargetsRequiredException extends /*@__PURE__*/ TargetsRequiredException_base {
}
declare const TipOfSourceReferenceIsDifferentException_base: S.TaggedErrorClass<"TipOfSourceReferenceIsDifferentException", {
    readonly message: any;
}>;
export declare class TipOfSourceReferenceIsDifferentException extends /*@__PURE__*/ TipOfSourceReferenceIsDifferentException_base {
}
declare const TipsDivergenceExceededException_base: S.TaggedErrorClass<"TipsDivergenceExceededException", {
    readonly message: any;
}>;
export declare class TipsDivergenceExceededException extends /*@__PURE__*/ TipsDivergenceExceededException_base {
}
declare const TitleRequiredException_base: S.TaggedErrorClass<"TitleRequiredException", {
    readonly message: any;
}>;
export declare class TitleRequiredException extends /*@__PURE__*/ TitleRequiredException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
}>;
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ApprovalRuleTemplateName = string;
export type RepositoryName = string;
export interface AssociateApprovalRuleTemplateWithRepositoryInput {
    approvalRuleTemplateName: string;
    repositoryName: string;
}
export interface AssociateApprovalRuleTemplateWithRepositoryResponse {
}
export type RepositoryNameList = string[];
export interface BatchAssociateApprovalRuleTemplateWithRepositoriesInput {
    approvalRuleTemplateName: string;
    repositoryNames: string[];
}
export type ErrorCode = string;
export type ErrorMessage = string;
export interface BatchAssociateApprovalRuleTemplateWithRepositoriesError_ {
    repositoryName?: string;
    errorCode?: string;
    errorMessage?: string;
}
export type BatchAssociateApprovalRuleTemplateWithRepositoriesErrorsList = BatchAssociateApprovalRuleTemplateWithRepositoriesError_[];
export interface BatchAssociateApprovalRuleTemplateWithRepositoriesOutput {
    associatedRepositoryNames: string[];
    errors: BatchAssociateApprovalRuleTemplateWithRepositoriesError_[];
}
export type CommitName = string;
export type MergeOptionTypeEnum = "FAST_FORWARD_MERGE" | "SQUASH_MERGE" | "THREE_WAY_MERGE" | (string & {});
export type MaxResults = number;
export type Path = string;
export type FilePaths = string[];
export type ConflictDetailLevelTypeEnum = "FILE_LEVEL" | "LINE_LEVEL" | (string & {});
export type ConflictResolutionStrategyTypeEnum = "NONE" | "ACCEPT_SOURCE" | "ACCEPT_DESTINATION" | "AUTOMERGE" | (string & {});
export type NextToken = string;
export interface BatchDescribeMergeConflictsInput {
    repositoryName: string;
    destinationCommitSpecifier: string;
    sourceCommitSpecifier: string;
    mergeOption: MergeOptionTypeEnum;
    maxMergeHunks?: number;
    maxConflictFiles?: number;
    filePaths?: string[];
    conflictDetailLevel?: ConflictDetailLevelTypeEnum;
    conflictResolutionStrategy?: ConflictResolutionStrategyTypeEnum;
    nextToken?: string;
}
export type FileSize = number;
export interface FileSizes {
    source?: number;
    destination?: number;
    base?: number;
}
export type FileModeTypeEnum = "EXECUTABLE" | "NORMAL" | "SYMLINK" | (string & {});
export interface FileModes {
    source?: FileModeTypeEnum;
    destination?: FileModeTypeEnum;
    base?: FileModeTypeEnum;
}
export type ObjectTypeEnum = "FILE" | "DIRECTORY" | "GIT_LINK" | "SYMBOLIC_LINK" | (string & {});
export interface ObjectTypes {
    source?: ObjectTypeEnum;
    destination?: ObjectTypeEnum;
    base?: ObjectTypeEnum;
}
export type NumberOfConflicts = number;
export type CapitalBoolean = boolean;
export interface IsBinaryFile {
    source?: boolean;
    destination?: boolean;
    base?: boolean;
}
export type IsContentConflict = boolean;
export type IsFileModeConflict = boolean;
export type IsObjectTypeConflict = boolean;
export type ChangeTypeEnum = "A" | "M" | "D" | (string & {});
export interface MergeOperations {
    source?: ChangeTypeEnum;
    destination?: ChangeTypeEnum;
}
export interface ConflictMetadata {
    filePath?: string;
    fileSizes?: FileSizes;
    fileModes?: FileModes;
    objectTypes?: ObjectTypes;
    numberOfConflicts?: number;
    isBinaryFile?: IsBinaryFile;
    contentConflict?: boolean;
    fileModeConflict?: boolean;
    objectTypeConflict?: boolean;
    mergeOperations?: MergeOperations;
}
export type IsHunkConflict = boolean;
export type LineNumber = number;
export type HunkContent = string;
export interface MergeHunkDetail {
    startLine?: number;
    endLine?: number;
    hunkContent?: string;
}
export interface MergeHunk {
    isConflict?: boolean;
    source?: MergeHunkDetail;
    destination?: MergeHunkDetail;
    base?: MergeHunkDetail;
}
export type MergeHunks = MergeHunk[];
export interface Conflict {
    conflictMetadata?: ConflictMetadata;
    mergeHunks?: MergeHunk[];
}
export type Conflicts = Conflict[];
export type ExceptionName = string;
export type Message = string;
export interface BatchDescribeMergeConflictsError_ {
    filePath: string;
    exceptionName: string;
    message: string;
}
export type BatchDescribeMergeConflictsErrors = BatchDescribeMergeConflictsError_[];
export type ObjectId = string;
export interface BatchDescribeMergeConflictsOutput {
    conflicts: Conflict[];
    nextToken?: string;
    errors?: BatchDescribeMergeConflictsError_[];
    destinationCommitId: string;
    sourceCommitId: string;
    baseCommitId?: string;
}
export interface BatchDisassociateApprovalRuleTemplateFromRepositoriesInput {
    approvalRuleTemplateName: string;
    repositoryNames: string[];
}
export interface BatchDisassociateApprovalRuleTemplateFromRepositoriesError_ {
    repositoryName?: string;
    errorCode?: string;
    errorMessage?: string;
}
export type BatchDisassociateApprovalRuleTemplateFromRepositoriesErrorsList = BatchDisassociateApprovalRuleTemplateFromRepositoriesError_[];
export interface BatchDisassociateApprovalRuleTemplateFromRepositoriesOutput {
    disassociatedRepositoryNames: string[];
    errors: BatchDisassociateApprovalRuleTemplateFromRepositoriesError_[];
}
export type CommitIdsInputList = string[];
export interface BatchGetCommitsInput {
    commitIds: string[];
    repositoryName: string;
}
export type ParentList = string[];
export type Name = string;
export type Email = string;
export interface UserInfo {
    name?: string;
    email?: string;
    date?: string;
}
export type AdditionalData = string;
export interface Commit {
    commitId?: string;
    treeId?: string;
    parents?: string[];
    message?: string;
    author?: UserInfo;
    committer?: UserInfo;
    additionalData?: string;
}
export type CommitObjectsList = Commit[];
export interface BatchGetCommitsError_ {
    commitId?: string;
    errorCode?: string;
    errorMessage?: string;
}
export type BatchGetCommitsErrorsList = BatchGetCommitsError_[];
export interface BatchGetCommitsOutput {
    commits?: Commit[];
    errors?: BatchGetCommitsError_[];
}
export interface BatchGetRepositoriesInput {
    repositoryNames: string[];
}
export type AccountId = string;
export type RepositoryId = string;
export type RepositoryDescription = string;
export type BranchName = string;
export type LastModifiedDate = Date;
export type CreationDate = Date;
export type CloneUrlHttp = string;
export type CloneUrlSsh = string;
export type Arn = string;
export type KmsKeyId = string;
export interface RepositoryMetadata {
    accountId?: string;
    repositoryId?: string;
    repositoryName?: string;
    repositoryDescription?: string;
    defaultBranch?: string;
    lastModifiedDate?: Date;
    creationDate?: Date;
    cloneUrlHttp?: string;
    cloneUrlSsh?: string;
    Arn?: string;
    kmsKeyId?: string;
}
export type RepositoryMetadataList = RepositoryMetadata[];
export type RepositoryNotFoundList = string[];
export type BatchGetRepositoriesErrorCodeEnum = "EncryptionIntegrityChecksFailedException" | "EncryptionKeyAccessDeniedException" | "EncryptionKeyDisabledException" | "EncryptionKeyNotFoundException" | "EncryptionKeyUnavailableException" | "RepositoryDoesNotExistException" | (string & {});
export interface BatchGetRepositoriesError_ {
    repositoryId?: string;
    repositoryName?: string;
    errorCode?: BatchGetRepositoriesErrorCodeEnum;
    errorMessage?: string;
}
export type BatchGetRepositoriesErrorsList = BatchGetRepositoriesError_[];
export interface BatchGetRepositoriesOutput {
    repositories?: RepositoryMetadata[];
    repositoriesNotFound?: string[];
    errors?: BatchGetRepositoriesError_[];
}
export type ApprovalRuleTemplateContent = string;
export type ApprovalRuleTemplateDescription = string;
export interface CreateApprovalRuleTemplateInput {
    approvalRuleTemplateName: string;
    approvalRuleTemplateContent: string;
    approvalRuleTemplateDescription?: string;
}
export type ApprovalRuleTemplateId = string;
export type RuleContentSha256 = string;
export interface ApprovalRuleTemplate {
    approvalRuleTemplateId?: string;
    approvalRuleTemplateName?: string;
    approvalRuleTemplateDescription?: string;
    approvalRuleTemplateContent?: string;
    ruleContentSha256?: string;
    lastModifiedDate?: Date;
    creationDate?: Date;
    lastModifiedUser?: string;
}
export interface CreateApprovalRuleTemplateOutput {
    approvalRuleTemplate: ApprovalRuleTemplate;
}
export type CommitId = string;
export interface CreateBranchInput {
    repositoryName: string;
    branchName: string;
    commitId: string;
}
export interface CreateBranchResponse {
}
export type KeepEmptyFolders = boolean;
export type FileContent = Uint8Array;
export type IsMove = boolean;
export interface SourceFileSpecifier {
    filePath: string;
    isMove?: boolean;
}
export interface PutFileEntry {
    filePath: string;
    fileMode?: FileModeTypeEnum;
    fileContent?: Uint8Array;
    sourceFile?: SourceFileSpecifier;
}
export type PutFileEntries = PutFileEntry[];
export interface DeleteFileEntry {
    filePath: string;
}
export type DeleteFileEntries = DeleteFileEntry[];
export interface SetFileModeEntry {
    filePath: string;
    fileMode: FileModeTypeEnum;
}
export type SetFileModeEntries = SetFileModeEntry[];
export interface CreateCommitInput {
    repositoryName: string;
    branchName: string;
    parentCommitId?: string;
    authorName?: string;
    email?: string;
    commitMessage?: string;
    keepEmptyFolders?: boolean;
    putFiles?: PutFileEntry[];
    deleteFiles?: DeleteFileEntry[];
    setFileModes?: SetFileModeEntry[];
}
export interface FileMetadata {
    absolutePath?: string;
    blobId?: string;
    fileMode?: FileModeTypeEnum;
}
export type FilesMetadata = FileMetadata[];
export interface CreateCommitOutput {
    commitId?: string;
    treeId?: string;
    filesAdded?: FileMetadata[];
    filesUpdated?: FileMetadata[];
    filesDeleted?: FileMetadata[];
}
export type Title = string;
export type Description = string;
export type ReferenceName = string;
export interface Target {
    repositoryName: string;
    sourceReference: string;
    destinationReference?: string;
}
export type TargetList = Target[];
export type ClientRequestToken = string;
export interface CreatePullRequestInput {
    title: string;
    description?: string;
    targets: Target[];
    clientRequestToken?: string;
}
export type PullRequestId = string;
export type PullRequestStatusEnum = "OPEN" | "CLOSED" | (string & {});
export type IsMerged = boolean;
export interface MergeMetadata {
    isMerged?: boolean;
    mergedBy?: string;
    mergeCommitId?: string;
    mergeOption?: MergeOptionTypeEnum;
}
export interface PullRequestTarget {
    repositoryName?: string;
    sourceReference?: string;
    destinationReference?: string;
    destinationCommit?: string;
    sourceCommit?: string;
    mergeBase?: string;
    mergeMetadata?: MergeMetadata;
}
export type PullRequestTargetList = PullRequestTarget[];
export type RevisionId = string;
export type ApprovalRuleId = string;
export type ApprovalRuleName = string;
export type ApprovalRuleContent = string;
export interface OriginApprovalRuleTemplate {
    approvalRuleTemplateId?: string;
    approvalRuleTemplateName?: string;
}
export interface ApprovalRule {
    approvalRuleId?: string;
    approvalRuleName?: string;
    approvalRuleContent?: string;
    ruleContentSha256?: string;
    lastModifiedDate?: Date;
    creationDate?: Date;
    lastModifiedUser?: string;
    originApprovalRuleTemplate?: OriginApprovalRuleTemplate;
}
export type ApprovalRulesList = ApprovalRule[];
export interface PullRequest {
    pullRequestId?: string;
    title?: string;
    description?: string;
    lastActivityDate?: Date;
    creationDate?: Date;
    pullRequestStatus?: PullRequestStatusEnum;
    authorArn?: string;
    pullRequestTargets?: PullRequestTarget[];
    clientRequestToken?: string;
    revisionId?: string;
    approvalRules?: ApprovalRule[];
}
export interface CreatePullRequestOutput {
    pullRequest: PullRequest;
}
export interface CreatePullRequestApprovalRuleInput {
    pullRequestId: string;
    approvalRuleName: string;
    approvalRuleContent: string;
}
export interface CreatePullRequestApprovalRuleOutput {
    approvalRule: ApprovalRule;
}
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export interface CreateRepositoryInput {
    repositoryName: string;
    repositoryDescription?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    kmsKeyId?: string;
}
export interface CreateRepositoryOutput {
    repositoryMetadata?: RepositoryMetadata;
}
export type ReplacementTypeEnum = "KEEP_BASE" | "KEEP_SOURCE" | "KEEP_DESTINATION" | "USE_NEW_CONTENT" | (string & {});
export interface ReplaceContentEntry {
    filePath: string;
    replacementType: ReplacementTypeEnum;
    content?: Uint8Array;
    fileMode?: FileModeTypeEnum;
}
export type ReplaceContentEntries = ReplaceContentEntry[];
export interface ConflictResolution {
    replaceContents?: ReplaceContentEntry[];
    deleteFiles?: DeleteFileEntry[];
    setFileModes?: SetFileModeEntry[];
}
export interface CreateUnreferencedMergeCommitInput {
    repositoryName: string;
    sourceCommitSpecifier: string;
    destinationCommitSpecifier: string;
    mergeOption: MergeOptionTypeEnum;
    conflictDetailLevel?: ConflictDetailLevelTypeEnum;
    conflictResolutionStrategy?: ConflictResolutionStrategyTypeEnum;
    authorName?: string;
    email?: string;
    commitMessage?: string;
    keepEmptyFolders?: boolean;
    conflictResolution?: ConflictResolution;
}
export interface CreateUnreferencedMergeCommitOutput {
    commitId?: string;
    treeId?: string;
}
export interface DeleteApprovalRuleTemplateInput {
    approvalRuleTemplateName: string;
}
export interface DeleteApprovalRuleTemplateOutput {
    approvalRuleTemplateId: string;
}
export interface DeleteBranchInput {
    repositoryName: string;
    branchName: string;
}
export interface BranchInfo {
    branchName?: string;
    commitId?: string;
}
export interface DeleteBranchOutput {
    deletedBranch?: BranchInfo;
}
export type CommentId = string;
export interface DeleteCommentContentInput {
    commentId: string;
}
export type Content = string;
export type IsCommentDeleted = boolean;
export type ReactionValue = string;
export type CallerReactions = string[];
export type Count = number;
export type ReactionCountsMap = {
    [key: string]: number | undefined;
};
export interface Comment {
    commentId?: string;
    content?: string;
    inReplyTo?: string;
    creationDate?: Date;
    lastModifiedDate?: Date;
    authorArn?: string;
    deleted?: boolean;
    clientRequestToken?: string;
    callerReactions?: string[];
    reactionCounts?: {
        [key: string]: number | undefined;
    };
}
export interface DeleteCommentContentOutput {
    comment?: Comment;
}
export interface DeleteFileInput {
    repositoryName: string;
    branchName: string;
    filePath: string;
    parentCommitId: string;
    keepEmptyFolders?: boolean;
    commitMessage?: string;
    name?: string;
    email?: string;
}
export interface DeleteFileOutput {
    commitId: string;
    blobId: string;
    treeId: string;
    filePath: string;
}
export interface DeletePullRequestApprovalRuleInput {
    pullRequestId: string;
    approvalRuleName: string;
}
export interface DeletePullRequestApprovalRuleOutput {
    approvalRuleId: string;
}
export interface DeleteRepositoryInput {
    repositoryName: string;
}
export interface DeleteRepositoryOutput {
    repositoryId?: string;
}
export interface DescribeMergeConflictsInput {
    repositoryName: string;
    destinationCommitSpecifier: string;
    sourceCommitSpecifier: string;
    mergeOption: MergeOptionTypeEnum;
    maxMergeHunks?: number;
    filePath: string;
    conflictDetailLevel?: ConflictDetailLevelTypeEnum;
    conflictResolutionStrategy?: ConflictResolutionStrategyTypeEnum;
    nextToken?: string;
}
export interface DescribeMergeConflictsOutput {
    conflictMetadata: ConflictMetadata;
    mergeHunks: MergeHunk[];
    nextToken?: string;
    destinationCommitId: string;
    sourceCommitId: string;
    baseCommitId?: string;
}
export type PullRequestEventType = "PULL_REQUEST_CREATED" | "PULL_REQUEST_STATUS_CHANGED" | "PULL_REQUEST_SOURCE_REFERENCE_UPDATED" | "PULL_REQUEST_MERGE_STATE_CHANGED" | "PULL_REQUEST_APPROVAL_RULE_CREATED" | "PULL_REQUEST_APPROVAL_RULE_UPDATED" | "PULL_REQUEST_APPROVAL_RULE_DELETED" | "PULL_REQUEST_APPROVAL_RULE_OVERRIDDEN" | "PULL_REQUEST_APPROVAL_STATE_CHANGED" | (string & {});
export interface DescribePullRequestEventsInput {
    pullRequestId: string;
    pullRequestEventType?: PullRequestEventType;
    actorArn?: string;
    nextToken?: string;
    maxResults?: number;
}
export type EventDate = Date;
export interface PullRequestCreatedEventMetadata {
    repositoryName?: string;
    sourceCommitId?: string;
    destinationCommitId?: string;
    mergeBase?: string;
}
export interface PullRequestStatusChangedEventMetadata {
    pullRequestStatus?: PullRequestStatusEnum;
}
export interface PullRequestSourceReferenceUpdatedEventMetadata {
    repositoryName?: string;
    beforeCommitId?: string;
    afterCommitId?: string;
    mergeBase?: string;
}
export interface PullRequestMergedStateChangedEventMetadata {
    repositoryName?: string;
    destinationReference?: string;
    mergeMetadata?: MergeMetadata;
}
export interface ApprovalRuleEventMetadata {
    approvalRuleName?: string;
    approvalRuleId?: string;
    approvalRuleContent?: string;
}
export type ApprovalState = "APPROVE" | "REVOKE" | (string & {});
export interface ApprovalStateChangedEventMetadata {
    revisionId?: string;
    approvalStatus?: ApprovalState;
}
export type OverrideStatus = "OVERRIDE" | "REVOKE" | (string & {});
export interface ApprovalRuleOverriddenEventMetadata {
    revisionId?: string;
    overrideStatus?: OverrideStatus;
}
export interface PullRequestEvent {
    pullRequestId?: string;
    eventDate?: Date;
    pullRequestEventType?: PullRequestEventType;
    actorArn?: string;
    pullRequestCreatedEventMetadata?: PullRequestCreatedEventMetadata;
    pullRequestStatusChangedEventMetadata?: PullRequestStatusChangedEventMetadata;
    pullRequestSourceReferenceUpdatedEventMetadata?: PullRequestSourceReferenceUpdatedEventMetadata;
    pullRequestMergedStateChangedEventMetadata?: PullRequestMergedStateChangedEventMetadata;
    approvalRuleEventMetadata?: ApprovalRuleEventMetadata;
    approvalStateChangedEventMetadata?: ApprovalStateChangedEventMetadata;
    approvalRuleOverriddenEventMetadata?: ApprovalRuleOverriddenEventMetadata;
}
export type PullRequestEventList = PullRequestEvent[];
export interface DescribePullRequestEventsOutput {
    pullRequestEvents: PullRequestEvent[];
    nextToken?: string;
}
export interface DisassociateApprovalRuleTemplateFromRepositoryInput {
    approvalRuleTemplateName: string;
    repositoryName: string;
}
export interface DisassociateApprovalRuleTemplateFromRepositoryResponse {
}
export interface EvaluatePullRequestApprovalRulesInput {
    pullRequestId: string;
    revisionId: string;
}
export type Approved = boolean;
export type Overridden = boolean;
export type ApprovalRulesSatisfiedList = string[];
export type ApprovalRulesNotSatisfiedList = string[];
export interface Evaluation {
    approved?: boolean;
    overridden?: boolean;
    approvalRulesSatisfied?: string[];
    approvalRulesNotSatisfied?: string[];
}
export interface EvaluatePullRequestApprovalRulesOutput {
    evaluation: Evaluation;
}
export interface GetApprovalRuleTemplateInput {
    approvalRuleTemplateName: string;
}
export interface GetApprovalRuleTemplateOutput {
    approvalRuleTemplate: ApprovalRuleTemplate;
}
export interface GetBlobInput {
    repositoryName: string;
    blobId: string;
}
export interface GetBlobOutput {
    content: Uint8Array;
}
export type DiffContext = number;
export type IgnoreWhiteSpaces = boolean;
export type Limit = number;
export interface GetBlobDifferencesInput {
    repositoryName: string;
    afterBlobId: string;
    beforeBlobId?: string;
    contextLines?: number;
    ignoreWhitespace?: boolean;
    MaxResults?: number;
    NextToken?: string;
}
export type DiffChangeType = "CONTEXT" | "ADD" | "DELETE" | (string & {});
export type LineContent = string;
export interface DiffChange {
    type?: DiffChangeType;
    beforeLineNumber?: number;
    afterLineNumber?: number;
    content?: string;
}
export type DiffChangeList = DiffChange[];
export interface DiffHunk {
    beforeStartLine?: number;
    beforeLineCount?: number;
    afterStartLine?: number;
    afterLineCount?: number;
    changes?: DiffChange[];
}
export type DiffHunkList = DiffHunk[];
export type ObjectSize = number;
export interface GetBlobDifferencesOutput {
    hunks: DiffHunk[];
    isBinary: boolean;
    beforeBlobSize?: number;
    afterBlobSize: number;
    NextToken?: string;
}
export interface GetBranchInput {
    repositoryName?: string;
    branchName?: string;
}
export interface GetBranchOutput {
    branch?: BranchInfo;
}
export interface GetCommentInput {
    commentId: string;
}
export interface GetCommentOutput {
    comment?: Comment;
}
export interface GetCommentReactionsInput {
    commentId: string;
    reactionUserArn?: string;
    nextToken?: string;
    maxResults?: number;
}
export type ReactionEmoji = string;
export type ReactionShortCode = string;
export type ReactionUnicode = string;
export interface ReactionValueFormats {
    emoji?: string;
    shortCode?: string;
    unicode?: string;
}
export type ReactionUsersList = string[];
export interface ReactionForComment {
    reaction?: ReactionValueFormats;
    reactionUsers?: string[];
    reactionsFromDeletedUsersCount?: number;
}
export type ReactionsForCommentList = ReactionForComment[];
export interface GetCommentReactionsOutput {
    reactionsForComment: ReactionForComment[];
    nextToken?: string;
}
export interface GetCommentsForComparedCommitInput {
    repositoryName: string;
    beforeCommitId?: string;
    afterCommitId: string;
    nextToken?: string;
    maxResults?: number;
}
export type Position = number;
export type RelativeFileVersionEnum = "BEFORE" | "AFTER" | (string & {});
export interface Location {
    filePath?: string;
    filePosition?: number;
    relativeFileVersion?: RelativeFileVersionEnum;
}
export type Comments = Comment[];
export interface CommentsForComparedCommit {
    repositoryName?: string;
    beforeCommitId?: string;
    afterCommitId?: string;
    beforeBlobId?: string;
    afterBlobId?: string;
    location?: Location;
    comments?: Comment[];
}
export type CommentsForComparedCommitData = CommentsForComparedCommit[];
export interface GetCommentsForComparedCommitOutput {
    commentsForComparedCommitData?: CommentsForComparedCommit[];
    nextToken?: string;
}
export interface GetCommentsForPullRequestInput {
    pullRequestId: string;
    repositoryName?: string;
    beforeCommitId?: string;
    afterCommitId?: string;
    nextToken?: string;
    maxResults?: number;
}
export interface CommentsForPullRequest {
    pullRequestId?: string;
    repositoryName?: string;
    beforeCommitId?: string;
    afterCommitId?: string;
    beforeBlobId?: string;
    afterBlobId?: string;
    location?: Location;
    comments?: Comment[];
}
export type CommentsForPullRequestData = CommentsForPullRequest[];
export interface GetCommentsForPullRequestOutput {
    commentsForPullRequestData?: CommentsForPullRequest[];
    nextToken?: string;
}
export interface GetCommitInput {
    repositoryName: string;
    commitId: string;
}
export interface GetCommitOutput {
    commit: Commit;
}
export interface GetDifferencesInput {
    repositoryName: string;
    beforeCommitSpecifier?: string;
    afterCommitSpecifier: string;
    beforePath?: string;
    afterPath?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type Mode = string;
export interface BlobMetadata {
    blobId?: string;
    path?: string;
    mode?: string;
}
export interface Difference {
    beforeBlob?: BlobMetadata;
    afterBlob?: BlobMetadata;
    changeType?: ChangeTypeEnum;
}
export type DifferenceList = Difference[];
export interface GetDifferencesOutput {
    differences?: Difference[];
    NextToken?: string;
}
export interface GetFileInput {
    repositoryName: string;
    commitSpecifier?: string;
    filePath: string;
}
export interface GetFileOutput {
    commitId: string;
    blobId: string;
    filePath: string;
    fileMode: FileModeTypeEnum;
    fileSize: number;
    fileContent: Uint8Array;
}
export interface GetFolderInput {
    repositoryName: string;
    commitSpecifier?: string;
    folderPath: string;
}
export interface Folder {
    treeId?: string;
    absolutePath?: string;
    relativePath?: string;
}
export type FolderList = Folder[];
export interface File {
    blobId?: string;
    absolutePath?: string;
    relativePath?: string;
    fileMode?: FileModeTypeEnum;
}
export type FileList = File[];
export interface SymbolicLink {
    blobId?: string;
    absolutePath?: string;
    relativePath?: string;
    fileMode?: FileModeTypeEnum;
}
export type SymbolicLinkList = SymbolicLink[];
export interface SubModule {
    commitId?: string;
    absolutePath?: string;
    relativePath?: string;
}
export type SubModuleList = SubModule[];
export interface GetFolderOutput {
    commitId: string;
    folderPath: string;
    treeId?: string;
    subFolders?: Folder[];
    files?: File[];
    symbolicLinks?: SymbolicLink[];
    subModules?: SubModule[];
}
export interface GetMergeCommitInput {
    repositoryName: string;
    sourceCommitSpecifier: string;
    destinationCommitSpecifier: string;
    conflictDetailLevel?: ConflictDetailLevelTypeEnum;
    conflictResolutionStrategy?: ConflictResolutionStrategyTypeEnum;
}
export interface GetMergeCommitOutput {
    sourceCommitId?: string;
    destinationCommitId?: string;
    baseCommitId?: string;
    mergedCommitId?: string;
}
export interface GetMergeConflictsInput {
    repositoryName: string;
    destinationCommitSpecifier: string;
    sourceCommitSpecifier: string;
    mergeOption: MergeOptionTypeEnum;
    conflictDetailLevel?: ConflictDetailLevelTypeEnum;
    maxConflictFiles?: number;
    conflictResolutionStrategy?: ConflictResolutionStrategyTypeEnum;
    nextToken?: string;
}
export type IsMergeable = boolean;
export type ConflictMetadataList = ConflictMetadata[];
export interface GetMergeConflictsOutput {
    mergeable: boolean;
    destinationCommitId: string;
    sourceCommitId: string;
    baseCommitId?: string;
    conflictMetadataList: ConflictMetadata[];
    nextToken?: string;
}
export interface GetMergeOptionsInput {
    repositoryName: string;
    sourceCommitSpecifier: string;
    destinationCommitSpecifier: string;
    conflictDetailLevel?: ConflictDetailLevelTypeEnum;
    conflictResolutionStrategy?: ConflictResolutionStrategyTypeEnum;
}
export type MergeOptions = MergeOptionTypeEnum[];
export interface GetMergeOptionsOutput {
    mergeOptions: MergeOptionTypeEnum[];
    sourceCommitId: string;
    destinationCommitId: string;
    baseCommitId: string;
}
export interface GetPullRequestInput {
    pullRequestId: string;
}
export interface GetPullRequestOutput {
    pullRequest: PullRequest;
}
export interface GetPullRequestApprovalStatesInput {
    pullRequestId: string;
    revisionId: string;
}
export interface Approval {
    userArn?: string;
    approvalState?: ApprovalState;
}
export type ApprovalList = Approval[];
export interface GetPullRequestApprovalStatesOutput {
    approvals?: Approval[];
}
export interface GetPullRequestOverrideStateInput {
    pullRequestId: string;
    revisionId: string;
}
export interface GetPullRequestOverrideStateOutput {
    overridden?: boolean;
    overrider?: string;
}
export interface GetRepositoryInput {
    repositoryName: string;
}
export interface GetRepositoryOutput {
    repositoryMetadata?: RepositoryMetadata;
}
export interface GetRepositoryTriggersInput {
    repositoryName: string;
}
export type RepositoryTriggersConfigurationId = string;
export type RepositoryTriggerName = string;
export type RepositoryTriggerCustomData = string;
export type BranchNameList = string[];
export type RepositoryTriggerEventEnum = "all" | "updateReference" | "createReference" | "deleteReference" | (string & {});
export type RepositoryTriggerEventList = RepositoryTriggerEventEnum[];
export interface RepositoryTrigger {
    name: string;
    destinationArn: string;
    customData?: string;
    branches?: string[];
    events: RepositoryTriggerEventEnum[];
}
export type RepositoryTriggersList = RepositoryTrigger[];
export interface GetRepositoryTriggersOutput {
    configurationId?: string;
    triggers?: RepositoryTrigger[];
}
export interface ListApprovalRuleTemplatesInput {
    nextToken?: string;
    maxResults?: number;
}
export type ApprovalRuleTemplateNameList = string[];
export interface ListApprovalRuleTemplatesOutput {
    approvalRuleTemplateNames?: string[];
    nextToken?: string;
}
export interface ListAssociatedApprovalRuleTemplatesForRepositoryInput {
    repositoryName: string;
    nextToken?: string;
    maxResults?: number;
}
export interface ListAssociatedApprovalRuleTemplatesForRepositoryOutput {
    approvalRuleTemplateNames?: string[];
    nextToken?: string;
}
export interface ListBranchesInput {
    repositoryName: string;
    nextToken?: string;
}
export interface ListBranchesOutput {
    branches?: string[];
    nextToken?: string;
}
export interface ListFileCommitHistoryRequest {
    repositoryName: string;
    commitSpecifier?: string;
    filePath: string;
    maxResults?: number;
    nextToken?: string;
}
export type RevisionChildren = string[];
export interface FileVersion {
    commit?: Commit;
    blobId?: string;
    path?: string;
    revisionChildren?: string[];
}
export type RevisionDag = FileVersion[];
export interface ListFileCommitHistoryResponse {
    revisionDag: FileVersion[];
    nextToken?: string;
}
export interface ListPullRequestsInput {
    repositoryName: string;
    authorArn?: string;
    pullRequestStatus?: PullRequestStatusEnum;
    nextToken?: string;
    maxResults?: number;
}
export type PullRequestIdList = string[];
export interface ListPullRequestsOutput {
    pullRequestIds: string[];
    nextToken?: string;
}
export type SortByEnum = "repositoryName" | "lastModifiedDate" | (string & {});
export type OrderEnum = "ascending" | "descending" | (string & {});
export interface ListRepositoriesInput {
    nextToken?: string;
    sortBy?: SortByEnum;
    order?: OrderEnum;
}
export interface RepositoryNameIdPair {
    repositoryName?: string;
    repositoryId?: string;
}
export type RepositoryNameIdPairList = RepositoryNameIdPair[];
export interface ListRepositoriesOutput {
    repositories?: RepositoryNameIdPair[];
    nextToken?: string;
}
export interface ListRepositoriesForApprovalRuleTemplateInput {
    approvalRuleTemplateName: string;
    nextToken?: string;
    maxResults?: number;
}
export interface ListRepositoriesForApprovalRuleTemplateOutput {
    repositoryNames?: string[];
    nextToken?: string;
}
export type ResourceArn = string;
export interface ListTagsForResourceInput {
    resourceArn: string;
    nextToken?: string;
}
export interface ListTagsForResourceOutput {
    tags?: {
        [key: string]: string | undefined;
    };
    nextToken?: string;
}
export interface MergeBranchesByFastForwardInput {
    repositoryName: string;
    sourceCommitSpecifier: string;
    destinationCommitSpecifier: string;
    targetBranch?: string;
}
export interface MergeBranchesByFastForwardOutput {
    commitId?: string;
    treeId?: string;
}
export interface MergeBranchesBySquashInput {
    repositoryName: string;
    sourceCommitSpecifier: string;
    destinationCommitSpecifier: string;
    targetBranch?: string;
    conflictDetailLevel?: ConflictDetailLevelTypeEnum;
    conflictResolutionStrategy?: ConflictResolutionStrategyTypeEnum;
    authorName?: string;
    email?: string;
    commitMessage?: string;
    keepEmptyFolders?: boolean;
    conflictResolution?: ConflictResolution;
}
export interface MergeBranchesBySquashOutput {
    commitId?: string;
    treeId?: string;
}
export interface MergeBranchesByThreeWayInput {
    repositoryName: string;
    sourceCommitSpecifier: string;
    destinationCommitSpecifier: string;
    targetBranch?: string;
    conflictDetailLevel?: ConflictDetailLevelTypeEnum;
    conflictResolutionStrategy?: ConflictResolutionStrategyTypeEnum;
    authorName?: string;
    email?: string;
    commitMessage?: string;
    keepEmptyFolders?: boolean;
    conflictResolution?: ConflictResolution;
}
export interface MergeBranchesByThreeWayOutput {
    commitId?: string;
    treeId?: string;
}
export interface MergePullRequestByFastForwardInput {
    pullRequestId: string;
    repositoryName: string;
    sourceCommitId?: string;
}
export interface MergePullRequestByFastForwardOutput {
    pullRequest?: PullRequest;
}
export interface MergePullRequestBySquashInput {
    pullRequestId: string;
    repositoryName: string;
    sourceCommitId?: string;
    conflictDetailLevel?: ConflictDetailLevelTypeEnum;
    conflictResolutionStrategy?: ConflictResolutionStrategyTypeEnum;
    commitMessage?: string;
    authorName?: string;
    email?: string;
    keepEmptyFolders?: boolean;
    conflictResolution?: ConflictResolution;
}
export interface MergePullRequestBySquashOutput {
    pullRequest?: PullRequest;
}
export interface MergePullRequestByThreeWayInput {
    pullRequestId: string;
    repositoryName: string;
    sourceCommitId?: string;
    conflictDetailLevel?: ConflictDetailLevelTypeEnum;
    conflictResolutionStrategy?: ConflictResolutionStrategyTypeEnum;
    commitMessage?: string;
    authorName?: string;
    email?: string;
    keepEmptyFolders?: boolean;
    conflictResolution?: ConflictResolution;
}
export interface MergePullRequestByThreeWayOutput {
    pullRequest?: PullRequest;
}
export interface OverridePullRequestApprovalRulesInput {
    pullRequestId: string;
    revisionId: string;
    overrideStatus: OverrideStatus;
}
export interface OverridePullRequestApprovalRulesResponse {
}
export interface PostCommentForComparedCommitInput {
    repositoryName: string;
    beforeCommitId?: string;
    afterCommitId: string;
    location?: Location;
    content: string;
    clientRequestToken?: string;
}
export interface PostCommentForComparedCommitOutput {
    repositoryName?: string;
    beforeCommitId?: string;
    afterCommitId?: string;
    beforeBlobId?: string;
    afterBlobId?: string;
    location?: Location;
    comment?: Comment;
}
export interface PostCommentForPullRequestInput {
    pullRequestId: string;
    repositoryName: string;
    beforeCommitId: string;
    afterCommitId: string;
    location?: Location;
    content: string;
    clientRequestToken?: string;
}
export interface PostCommentForPullRequestOutput {
    repositoryName?: string;
    pullRequestId?: string;
    beforeCommitId?: string;
    afterCommitId?: string;
    beforeBlobId?: string;
    afterBlobId?: string;
    location?: Location;
    comment?: Comment;
}
export interface PostCommentReplyInput {
    inReplyTo: string;
    clientRequestToken?: string;
    content: string;
}
export interface PostCommentReplyOutput {
    comment?: Comment;
}
export interface PutCommentReactionInput {
    commentId: string;
    reactionValue: string;
}
export interface PutCommentReactionResponse {
}
export interface PutFileInput {
    repositoryName: string;
    branchName: string;
    fileContent: Uint8Array;
    filePath: string;
    fileMode?: FileModeTypeEnum;
    parentCommitId?: string;
    commitMessage?: string;
    name?: string;
    email?: string;
}
export interface PutFileOutput {
    commitId: string;
    blobId: string;
    treeId: string;
}
export interface PutRepositoryTriggersInput {
    repositoryName: string;
    triggers: RepositoryTrigger[];
}
export interface PutRepositoryTriggersOutput {
    configurationId?: string;
}
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export interface TestRepositoryTriggersInput {
    repositoryName: string;
    triggers: RepositoryTrigger[];
}
export type RepositoryTriggerNameList = string[];
export type RepositoryTriggerExecutionFailureMessage = string;
export interface RepositoryTriggerExecutionFailure {
    trigger?: string;
    failureMessage?: string;
}
export type RepositoryTriggerExecutionFailureList = RepositoryTriggerExecutionFailure[];
export interface TestRepositoryTriggersOutput {
    successfulExecutions?: string[];
    failedExecutions?: RepositoryTriggerExecutionFailure[];
}
export type TagKeysList = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateApprovalRuleTemplateContentInput {
    approvalRuleTemplateName: string;
    newRuleContent: string;
    existingRuleContentSha256?: string;
}
export interface UpdateApprovalRuleTemplateContentOutput {
    approvalRuleTemplate: ApprovalRuleTemplate;
}
export interface UpdateApprovalRuleTemplateDescriptionInput {
    approvalRuleTemplateName: string;
    approvalRuleTemplateDescription: string;
}
export interface UpdateApprovalRuleTemplateDescriptionOutput {
    approvalRuleTemplate: ApprovalRuleTemplate;
}
export interface UpdateApprovalRuleTemplateNameInput {
    oldApprovalRuleTemplateName: string;
    newApprovalRuleTemplateName: string;
}
export interface UpdateApprovalRuleTemplateNameOutput {
    approvalRuleTemplate: ApprovalRuleTemplate;
}
export interface UpdateCommentInput {
    commentId: string;
    content: string;
}
export interface UpdateCommentOutput {
    comment?: Comment;
}
export interface UpdateDefaultBranchInput {
    repositoryName: string;
    defaultBranchName: string;
}
export interface UpdateDefaultBranchResponse {
}
export interface UpdatePullRequestApprovalRuleContentInput {
    pullRequestId: string;
    approvalRuleName: string;
    existingRuleContentSha256?: string;
    newRuleContent: string;
}
export interface UpdatePullRequestApprovalRuleContentOutput {
    approvalRule: ApprovalRule;
}
export interface UpdatePullRequestApprovalStateInput {
    pullRequestId: string;
    revisionId: string;
    approvalState: ApprovalState;
}
export interface UpdatePullRequestApprovalStateResponse {
}
export interface UpdatePullRequestDescriptionInput {
    pullRequestId: string;
    description: string;
}
export interface UpdatePullRequestDescriptionOutput {
    pullRequest: PullRequest;
}
export interface UpdatePullRequestStatusInput {
    pullRequestId: string;
    pullRequestStatus: PullRequestStatusEnum;
}
export interface UpdatePullRequestStatusOutput {
    pullRequest: PullRequest;
}
export interface UpdatePullRequestTitleInput {
    pullRequestId: string;
    title: string;
}
export interface UpdatePullRequestTitleOutput {
    pullRequest: PullRequest;
}
export interface UpdateRepositoryDescriptionInput {
    repositoryName: string;
    repositoryDescription?: string;
}
export interface UpdateRepositoryDescriptionResponse {
}
export interface UpdateRepositoryEncryptionKeyInput {
    repositoryName: string;
    kmsKeyId: string;
}
export interface UpdateRepositoryEncryptionKeyOutput {
    repositoryId?: string;
    kmsKeyId?: string;
    originalKmsKeyId?: string;
}
export interface UpdateRepositoryNameInput {
    oldName: string;
    newName: string;
}
export interface UpdateRepositoryNameResponse {
}
export type AssociateApprovalRuleTemplateWithRepositoryError = ApprovalRuleTemplateDoesNotExistException | ApprovalRuleTemplateNameRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidApprovalRuleTemplateNameException | InvalidRepositoryNameException | MaximumRuleTemplatesAssociatedWithRepositoryException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Creates an association between an approval rule template and a specified repository.
 * Then, the next time a pull request is created in the repository where the destination
 * reference (if specified) matches the destination reference (branch) for the pull
 * request, an approval rule that matches the template conditions is automatically created
 * for that pull request. If no destination references are specified in the template, an
 * approval rule that matches the template contents is created for all pull requests in
 * that repository.
 */
export declare const associateApprovalRuleTemplateWithRepository: API.OperationMethod<AssociateApprovalRuleTemplateWithRepositoryInput, AssociateApprovalRuleTemplateWithRepositoryResponse, AssociateApprovalRuleTemplateWithRepositoryError, Credentials | HttpClient.HttpClient>;
export type BatchAssociateApprovalRuleTemplateWithRepositoriesError = ApprovalRuleTemplateDoesNotExistException | ApprovalRuleTemplateNameRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidApprovalRuleTemplateNameException | MaximumRepositoryNamesExceededException | RepositoryNamesRequiredException | CommonErrors;
/**
 * Creates an association between an approval rule template and one or more specified repositories.
 */
export declare const batchAssociateApprovalRuleTemplateWithRepositories: API.OperationMethod<BatchAssociateApprovalRuleTemplateWithRepositoriesInput, BatchAssociateApprovalRuleTemplateWithRepositoriesOutput, BatchAssociateApprovalRuleTemplateWithRepositoriesError, Credentials | HttpClient.HttpClient>;
export type BatchDescribeMergeConflictsError = CommitDoesNotExistException | CommitRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommitException | InvalidConflictDetailLevelException | InvalidConflictResolutionStrategyException | InvalidContinuationTokenException | InvalidMaxConflictFilesException | InvalidMaxMergeHunksException | InvalidMergeOptionException | InvalidRepositoryNameException | MaximumFileContentToLoadExceededException | MaximumItemsToCompareExceededException | MergeOptionRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | TipsDivergenceExceededException | CommonErrors;
/**
 * Returns information about one or more merge conflicts in the attempted merge of two commit specifiers using the squash or three-way merge strategy.
 */
export declare const batchDescribeMergeConflicts: API.OperationMethod<BatchDescribeMergeConflictsInput, BatchDescribeMergeConflictsOutput, BatchDescribeMergeConflictsError, Credentials | HttpClient.HttpClient>;
export type BatchDisassociateApprovalRuleTemplateFromRepositoriesError = ApprovalRuleTemplateDoesNotExistException | ApprovalRuleTemplateNameRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidApprovalRuleTemplateNameException | MaximumRepositoryNamesExceededException | RepositoryNamesRequiredException | CommonErrors;
/**
 * Removes the association between an approval rule template and one or more specified repositories.
 */
export declare const batchDisassociateApprovalRuleTemplateFromRepositories: API.OperationMethod<BatchDisassociateApprovalRuleTemplateFromRepositoriesInput, BatchDisassociateApprovalRuleTemplateFromRepositoriesOutput, BatchDisassociateApprovalRuleTemplateFromRepositoriesError, Credentials | HttpClient.HttpClient>;
export type BatchGetCommitsError = CommitIdsLimitExceededException | CommitIdsListRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns information about the contents of one or more commits in a repository.
 */
export declare const batchGetCommits: API.OperationMethod<BatchGetCommitsInput, BatchGetCommitsOutput, BatchGetCommitsError, Credentials | HttpClient.HttpClient>;
export type BatchGetRepositoriesError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidRepositoryNameException | MaximumRepositoryNamesExceededException | RepositoryNamesRequiredException | CommonErrors;
/**
 * Returns information about one or more repositories.
 *
 * The description field for a repository accepts all HTML characters and all valid
 * Unicode characters. Applications that do not HTML-encode the description and display
 * it in a webpage can expose users to potentially malicious code. Make sure that you
 * HTML-encode the description field in any application that uses this API to display
 * the repository description on a webpage.
 */
export declare const batchGetRepositories: API.OperationMethod<BatchGetRepositoriesInput, BatchGetRepositoriesOutput, BatchGetRepositoriesError, Credentials | HttpClient.HttpClient>;
export type CreateApprovalRuleTemplateError = ApprovalRuleTemplateContentRequiredException | ApprovalRuleTemplateNameAlreadyExistsException | ApprovalRuleTemplateNameRequiredException | InvalidApprovalRuleTemplateContentException | InvalidApprovalRuleTemplateDescriptionException | InvalidApprovalRuleTemplateNameException | NumberOfRuleTemplatesExceededException | CommonErrors;
/**
 * Creates a template for approval rules that can then be associated with one or more
 * repositories in your Amazon Web Services account. When you associate a template with a repository,
 * CodeCommit creates an approval rule that matches the conditions of the template for all
 * pull requests that meet the conditions of the template. For more information, see
 * AssociateApprovalRuleTemplateWithRepository.
 */
export declare const createApprovalRuleTemplate: API.OperationMethod<CreateApprovalRuleTemplateInput, CreateApprovalRuleTemplateOutput, CreateApprovalRuleTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateBranchError = BranchNameExistsException | BranchNameRequiredException | CommitDoesNotExistException | CommitIdRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidBranchNameException | InvalidCommitIdException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Creates a branch in a repository and points the branch to a commit.
 *
 * Calling the create branch operation does not set a repository's default branch. To do this, call the update default branch operation.
 */
export declare const createBranch: API.OperationMethod<CreateBranchInput, CreateBranchResponse, CreateBranchError, Credentials | HttpClient.HttpClient>;
export type CreateCommitError = BranchDoesNotExistException | BranchNameIsTagNameException | BranchNameRequiredException | CommitMessageLengthExceededException | DirectoryNameConflictsWithFileNameException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileContentAndSourceFileSpecifiedException | FileContentSizeLimitExceededException | FileDoesNotExistException | FileEntryRequiredException | FileModeRequiredException | FileNameConflictsWithDirectoryNameException | FilePathConflictsWithSubmodulePathException | FolderContentSizeLimitExceededException | InvalidBranchNameException | InvalidDeletionParameterException | InvalidEmailException | InvalidFileModeException | InvalidParentCommitIdException | InvalidPathException | InvalidRepositoryNameException | MaximumFileEntriesExceededException | NameLengthExceededException | NoChangeException | ParentCommitDoesNotExistException | ParentCommitIdOutdatedException | ParentCommitIdRequiredException | PathRequiredException | PutFileEntryConflictException | RepositoryDoesNotExistException | RepositoryNameRequiredException | RestrictedSourceFileException | SamePathRequestException | SourceFileOrContentRequiredException | CommonErrors;
/**
 * Creates a commit for a repository on the tip of a specified branch.
 */
export declare const createCommit: API.OperationMethod<CreateCommitInput, CreateCommitOutput, CreateCommitError, Credentials | HttpClient.HttpClient>;
export type CreatePullRequestError = ClientRequestTokenRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | IdempotencyParameterMismatchException | InvalidClientRequestTokenException | InvalidDescriptionException | InvalidReferenceNameException | InvalidRepositoryNameException | InvalidTargetException | InvalidTargetsException | InvalidTitleException | MaximumOpenPullRequestsExceededException | MultipleRepositoriesInPullRequestException | ReferenceDoesNotExistException | ReferenceNameRequiredException | ReferenceTypeNotSupportedException | RepositoryDoesNotExistException | RepositoryNameRequiredException | SourceAndDestinationAreSameException | TargetRequiredException | TargetsRequiredException | TitleRequiredException | CommonErrors;
/**
 * Creates a pull request in the specified repository.
 */
export declare const createPullRequest: API.OperationMethod<CreatePullRequestInput, CreatePullRequestOutput, CreatePullRequestError, Credentials | HttpClient.HttpClient>;
export type CreatePullRequestApprovalRuleError = ApprovalRuleContentRequiredException | ApprovalRuleNameAlreadyExistsException | ApprovalRuleNameRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidApprovalRuleContentException | InvalidApprovalRuleNameException | InvalidPullRequestIdException | NumberOfRulesExceededException | PullRequestAlreadyClosedException | PullRequestDoesNotExistException | PullRequestIdRequiredException | CommonErrors;
/**
 * Creates an approval rule for a pull request.
 */
export declare const createPullRequestApprovalRule: API.OperationMethod<CreatePullRequestApprovalRuleInput, CreatePullRequestApprovalRuleOutput, CreatePullRequestApprovalRuleError, Credentials | HttpClient.HttpClient>;
export type CreateRepositoryError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyInvalidIdException | EncryptionKeyInvalidUsageException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidRepositoryDescriptionException | InvalidRepositoryNameException | InvalidSystemTagUsageException | InvalidTagsMapException | OperationNotAllowedException | RepositoryLimitExceededException | RepositoryNameExistsException | RepositoryNameRequiredException | TagPolicyException | TooManyTagsException | CommonErrors;
/**
 * Creates a new, empty repository.
 */
export declare const createRepository: API.OperationMethod<CreateRepositoryInput, CreateRepositoryOutput, CreateRepositoryError, Credentials | HttpClient.HttpClient>;
export type CreateUnreferencedMergeCommitError = CommitDoesNotExistException | CommitMessageLengthExceededException | CommitRequiredException | ConcurrentReferenceUpdateException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileContentSizeLimitExceededException | FileModeRequiredException | FolderContentSizeLimitExceededException | InvalidCommitException | InvalidConflictDetailLevelException | InvalidConflictResolutionException | InvalidConflictResolutionStrategyException | InvalidEmailException | InvalidFileModeException | InvalidMergeOptionException | InvalidPathException | InvalidReplacementContentException | InvalidReplacementTypeException | InvalidRepositoryNameException | ManualMergeRequiredException | MaximumConflictResolutionEntriesExceededException | MaximumFileContentToLoadExceededException | MaximumItemsToCompareExceededException | MergeOptionRequiredException | MultipleConflictResolutionEntriesException | NameLengthExceededException | PathRequiredException | ReplacementContentRequiredException | ReplacementTypeRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | TipsDivergenceExceededException | CommonErrors;
/**
 * Creates an unreferenced commit that represents the result of merging two branches
 * using a specified merge strategy. This can help you determine the outcome of a potential
 * merge. This API cannot be used with the fast-forward merge strategy because that
 * strategy does not create a merge commit.
 *
 * This unreferenced merge commit
 * can only be accessed using the GetCommit API or through git commands such as git fetch. To retrieve this commit, you must specify its commit ID or otherwise reference it.
 */
export declare const createUnreferencedMergeCommit: API.OperationMethod<CreateUnreferencedMergeCommitInput, CreateUnreferencedMergeCommitOutput, CreateUnreferencedMergeCommitError, Credentials | HttpClient.HttpClient>;
export type DeleteApprovalRuleTemplateError = ApprovalRuleTemplateInUseException | ApprovalRuleTemplateNameRequiredException | InvalidApprovalRuleTemplateNameException | CommonErrors;
/**
 * Deletes a specified approval rule template. Deleting a template does not remove approval rules on pull requests already created with the template.
 */
export declare const deleteApprovalRuleTemplate: API.OperationMethod<DeleteApprovalRuleTemplateInput, DeleteApprovalRuleTemplateOutput, DeleteApprovalRuleTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteBranchError = BranchNameRequiredException | DefaultBranchCannotBeDeletedException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidBranchNameException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Deletes a branch from a repository, unless that branch is the default branch for the repository.
 */
export declare const deleteBranch: API.OperationMethod<DeleteBranchInput, DeleteBranchOutput, DeleteBranchError, Credentials | HttpClient.HttpClient>;
export type DeleteCommentContentError = CommentDeletedException | CommentDoesNotExistException | CommentIdRequiredException | InvalidCommentIdException | CommonErrors;
/**
 * Deletes the content of a comment made on a change, file, or commit in a repository.
 */
export declare const deleteCommentContent: API.OperationMethod<DeleteCommentContentInput, DeleteCommentContentOutput, DeleteCommentContentError, Credentials | HttpClient.HttpClient>;
export type DeleteFileError = BranchDoesNotExistException | BranchNameIsTagNameException | BranchNameRequiredException | CommitMessageLengthExceededException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileDoesNotExistException | InvalidBranchNameException | InvalidEmailException | InvalidParentCommitIdException | InvalidPathException | InvalidRepositoryNameException | NameLengthExceededException | ParentCommitDoesNotExistException | ParentCommitIdOutdatedException | ParentCommitIdRequiredException | PathRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Deletes a specified file from a specified branch. A commit is created on the branch
 * that contains the revision. The file still exists in the commits earlier to the commit
 * that contains the deletion.
 */
export declare const deleteFile: API.OperationMethod<DeleteFileInput, DeleteFileOutput, DeleteFileError, Credentials | HttpClient.HttpClient>;
export type DeletePullRequestApprovalRuleError = ApprovalRuleNameRequiredException | CannotDeleteApprovalRuleFromTemplateException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidApprovalRuleNameException | InvalidPullRequestIdException | PullRequestAlreadyClosedException | PullRequestDoesNotExistException | PullRequestIdRequiredException | CommonErrors;
/**
 * Deletes an approval rule from a specified pull request. Approval rules can be deleted from a pull request only if the pull request is open, and if the
 * approval rule was created specifically for a pull request and not generated from an approval rule template associated with the repository where the
 * pull request was created. You cannot delete an approval rule from a merged or closed pull request.
 */
export declare const deletePullRequestApprovalRule: API.OperationMethod<DeletePullRequestApprovalRuleInput, DeletePullRequestApprovalRuleOutput, DeletePullRequestApprovalRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteRepositoryError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidRepositoryNameException | RepositoryNameRequiredException | CommonErrors;
/**
 * Deletes a repository. If a specified repository was already deleted, a null repository
 * ID is returned.
 *
 * Deleting a repository also deletes all associated objects and metadata. After a repository is
 * deleted, all future push calls to the deleted repository fail.
 */
export declare const deleteRepository: API.OperationMethod<DeleteRepositoryInput, DeleteRepositoryOutput, DeleteRepositoryError, Credentials | HttpClient.HttpClient>;
export type DescribeMergeConflictsError = CommitDoesNotExistException | CommitRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileDoesNotExistException | InvalidCommitException | InvalidConflictDetailLevelException | InvalidConflictResolutionStrategyException | InvalidContinuationTokenException | InvalidMaxMergeHunksException | InvalidMergeOptionException | InvalidPathException | InvalidRepositoryNameException | MaximumFileContentToLoadExceededException | MaximumItemsToCompareExceededException | MergeOptionRequiredException | PathRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | TipsDivergenceExceededException | CommonErrors;
/**
 * Returns information about one or more merge conflicts in the attempted merge of two
 * commit specifiers using the squash or three-way merge strategy. If the merge option for
 * the attempted merge is specified as FAST_FORWARD_MERGE, an exception is thrown.
 */
export declare const describeMergeConflicts: API.PaginatedOperationMethod<DescribeMergeConflictsInput, DescribeMergeConflictsOutput, DescribeMergeConflictsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribePullRequestEventsError = ActorDoesNotExistException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidActorArnException | InvalidContinuationTokenException | InvalidMaxResultsException | InvalidPullRequestEventTypeException | InvalidPullRequestIdException | PullRequestDoesNotExistException | PullRequestIdRequiredException | CommonErrors;
/**
 * Returns information about one or more pull request events.
 */
export declare const describePullRequestEvents: API.PaginatedOperationMethod<DescribePullRequestEventsInput, DescribePullRequestEventsOutput, DescribePullRequestEventsError, Credentials | HttpClient.HttpClient, unknown>;
export type DisassociateApprovalRuleTemplateFromRepositoryError = ApprovalRuleTemplateDoesNotExistException | ApprovalRuleTemplateNameRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidApprovalRuleTemplateNameException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Removes the association between a template and a repository so that approval rules
 * based on the template are not automatically created when pull requests are created in
 * the specified repository. This does not delete any approval rules previously created for
 * pull requests through the template association.
 */
export declare const disassociateApprovalRuleTemplateFromRepository: API.OperationMethod<DisassociateApprovalRuleTemplateFromRepositoryInput, DisassociateApprovalRuleTemplateFromRepositoryResponse, DisassociateApprovalRuleTemplateFromRepositoryError, Credentials | HttpClient.HttpClient>;
export type EvaluatePullRequestApprovalRulesError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidPullRequestIdException | InvalidRevisionIdException | PullRequestDoesNotExistException | PullRequestIdRequiredException | RevisionIdRequiredException | RevisionNotCurrentException | CommonErrors;
/**
 * Evaluates whether a pull request has met all the conditions specified in its associated approval rules.
 */
export declare const evaluatePullRequestApprovalRules: API.OperationMethod<EvaluatePullRequestApprovalRulesInput, EvaluatePullRequestApprovalRulesOutput, EvaluatePullRequestApprovalRulesError, Credentials | HttpClient.HttpClient>;
export type GetApprovalRuleTemplateError = ApprovalRuleTemplateDoesNotExistException | ApprovalRuleTemplateNameRequiredException | InvalidApprovalRuleTemplateNameException | CommonErrors;
/**
 * Returns information about a specified approval rule template.
 */
export declare const getApprovalRuleTemplate: API.OperationMethod<GetApprovalRuleTemplateInput, GetApprovalRuleTemplateOutput, GetApprovalRuleTemplateError, Credentials | HttpClient.HttpClient>;
export type GetBlobError = BlobIdDoesNotExistException | BlobIdRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileTooLargeException | InvalidBlobIdException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns the base-64 encoded content of an individual blob in a repository.
 */
export declare const getBlob: API.OperationMethod<GetBlobInput, GetBlobOutput, GetBlobError, Credentials | HttpClient.HttpClient>;
export type GetBlobDifferencesError = BlobIdDoesNotExistException | BlobIdRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileTooLargeException | InvalidBlobIdException | InvalidContinuationTokenException | InvalidMaxResultsException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | ValidationException | CommonErrors;
/**
 * Returns a structured, line-level diff between two blob versions in a repository. The
 * diff is returned as an ordered list of hunks, where each hunk represents a contiguous
 * run of changed lines together with any surrounding unchanged context lines.
 *
 * Results are paginated. Use `MaxResults` and `NextToken` to
 * retrieve additional pages.
 *
 * For the typical usage workflow, see GetDifferences.
 */
export declare const getBlobDifferences: API.PaginatedOperationMethod<GetBlobDifferencesInput, GetBlobDifferencesOutput, GetBlobDifferencesError, Credentials | HttpClient.HttpClient, DiffHunk>;
export type GetBranchError = BranchDoesNotExistException | BranchNameRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidBranchNameException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns information about a repository branch, including its name and the last commit ID.
 */
export declare const getBranch: API.OperationMethod<GetBranchInput, GetBranchOutput, GetBranchError, Credentials | HttpClient.HttpClient>;
export type GetCommentError = CommentDeletedException | CommentDoesNotExistException | CommentIdRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommentIdException | CommonErrors;
/**
 * Returns the content of a comment made on a change, file, or commit in a repository.
 *
 * Reaction counts might include numbers from user identities who were deleted after the reaction was made. For a count of
 * reactions from active identities, use GetCommentReactions.
 */
export declare const getComment: API.OperationMethod<GetCommentInput, GetCommentOutput, GetCommentError, Credentials | HttpClient.HttpClient>;
export type GetCommentReactionsError = CommentDeletedException | CommentDoesNotExistException | CommentIdRequiredException | InvalidCommentIdException | InvalidContinuationTokenException | InvalidMaxResultsException | InvalidReactionUserArnException | CommonErrors;
/**
 * Returns information about reactions to a specified comment ID. Reactions from users who have been deleted will not be included in the count.
 */
export declare const getCommentReactions: API.PaginatedOperationMethod<GetCommentReactionsInput, GetCommentReactionsOutput, GetCommentReactionsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetCommentsForComparedCommitError = CommitDoesNotExistException | CommitIdRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommitIdException | InvalidContinuationTokenException | InvalidMaxResultsException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns information about comments made on the comparison between two commits.
 *
 * Reaction counts might include numbers from user identities who were deleted after the reaction was made. For a count of
 * reactions from active identities, use GetCommentReactions.
 */
export declare const getCommentsForComparedCommit: API.PaginatedOperationMethod<GetCommentsForComparedCommitInput, GetCommentsForComparedCommitOutput, GetCommentsForComparedCommitError, Credentials | HttpClient.HttpClient, unknown>;
export type GetCommentsForPullRequestError = CommitDoesNotExistException | CommitIdRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommitIdException | InvalidContinuationTokenException | InvalidMaxResultsException | InvalidPullRequestIdException | InvalidRepositoryNameException | PullRequestDoesNotExistException | PullRequestIdRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | RepositoryNotAssociatedWithPullRequestException | CommonErrors;
/**
 * Returns comments made on a pull request.
 *
 * Reaction counts might include numbers from user identities who were deleted after the reaction was made. For a count of
 * reactions from active identities, use GetCommentReactions.
 */
export declare const getCommentsForPullRequest: API.PaginatedOperationMethod<GetCommentsForPullRequestInput, GetCommentsForPullRequestOutput, GetCommentsForPullRequestError, Credentials | HttpClient.HttpClient, unknown>;
export type GetCommitError = CommitIdDoesNotExistException | CommitIdRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommitIdException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns information about a commit, including commit message and committer information.
 */
export declare const getCommit: API.OperationMethod<GetCommitInput, GetCommitOutput, GetCommitError, Credentials | HttpClient.HttpClient>;
export type GetDifferencesError = CommitDoesNotExistException | CommitRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommitException | InvalidCommitIdException | InvalidContinuationTokenException | InvalidMaxResultsException | InvalidPathException | InvalidRepositoryNameException | PathDoesNotExistException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns information about the differences in a valid commit specifier (such as a
 * branch, tag, HEAD, commit ID, or other fully qualified reference). Results can be
 * limited to a specified path.
 *
 * For line-level diff details, pass the `beforeBlob.blobId` and
 * `afterBlob.blobId` values from a `Difference` object to GetBlobDifferences.
 */
export declare const getDifferences: API.PaginatedOperationMethod<GetDifferencesInput, GetDifferencesOutput, GetDifferencesError, Credentials | HttpClient.HttpClient, unknown>;
export type GetFileError = CommitDoesNotExistException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileDoesNotExistException | FileTooLargeException | InvalidCommitException | InvalidPathException | InvalidRepositoryNameException | PathRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns the base-64 encoded contents of a specified file and its metadata.
 */
export declare const getFile: API.OperationMethod<GetFileInput, GetFileOutput, GetFileError, Credentials | HttpClient.HttpClient>;
export type GetFolderError = CommitDoesNotExistException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FolderDoesNotExistException | InvalidCommitException | InvalidPathException | InvalidRepositoryNameException | PathRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns the contents of a specified folder in a repository.
 */
export declare const getFolder: API.OperationMethod<GetFolderInput, GetFolderOutput, GetFolderError, Credentials | HttpClient.HttpClient>;
export type GetMergeCommitError = CommitDoesNotExistException | CommitRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommitException | InvalidConflictDetailLevelException | InvalidConflictResolutionStrategyException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns information about a specified merge commit.
 */
export declare const getMergeCommit: API.OperationMethod<GetMergeCommitInput, GetMergeCommitOutput, GetMergeCommitError, Credentials | HttpClient.HttpClient>;
export type GetMergeConflictsError = CommitDoesNotExistException | CommitRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommitException | InvalidConflictDetailLevelException | InvalidConflictResolutionStrategyException | InvalidContinuationTokenException | InvalidDestinationCommitSpecifierException | InvalidMaxConflictFilesException | InvalidMergeOptionException | InvalidRepositoryNameException | InvalidSourceCommitSpecifierException | MaximumFileContentToLoadExceededException | MaximumItemsToCompareExceededException | MergeOptionRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | TipsDivergenceExceededException | CommonErrors;
/**
 * Returns information about merge conflicts between the before and after commit IDs for a pull request in a repository.
 */
export declare const getMergeConflicts: API.PaginatedOperationMethod<GetMergeConflictsInput, GetMergeConflictsOutput, GetMergeConflictsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetMergeOptionsError = CommitDoesNotExistException | CommitRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommitException | InvalidConflictDetailLevelException | InvalidConflictResolutionStrategyException | InvalidRepositoryNameException | MaximumFileContentToLoadExceededException | MaximumItemsToCompareExceededException | RepositoryDoesNotExistException | RepositoryNameRequiredException | TipsDivergenceExceededException | CommonErrors;
/**
 * Returns information about the merge options available for merging two specified
 * branches. For details about why a merge option is not available, use GetMergeConflicts
 * or DescribeMergeConflicts.
 */
export declare const getMergeOptions: API.OperationMethod<GetMergeOptionsInput, GetMergeOptionsOutput, GetMergeOptionsError, Credentials | HttpClient.HttpClient>;
export type GetPullRequestError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidPullRequestIdException | PullRequestDoesNotExistException | PullRequestIdRequiredException | CommonErrors;
/**
 * Gets information about a pull request in a specified repository.
 */
export declare const getPullRequest: API.OperationMethod<GetPullRequestInput, GetPullRequestOutput, GetPullRequestError, Credentials | HttpClient.HttpClient>;
export type GetPullRequestApprovalStatesError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidPullRequestIdException | InvalidRevisionIdException | PullRequestDoesNotExistException | PullRequestIdRequiredException | RevisionIdRequiredException | CommonErrors;
/**
 * Gets information about the approval states for a specified pull request. Approval states only apply to pull requests that have one or more
 * approval rules applied to them.
 */
export declare const getPullRequestApprovalStates: API.OperationMethod<GetPullRequestApprovalStatesInput, GetPullRequestApprovalStatesOutput, GetPullRequestApprovalStatesError, Credentials | HttpClient.HttpClient>;
export type GetPullRequestOverrideStateError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidPullRequestIdException | InvalidRevisionIdException | PullRequestDoesNotExistException | PullRequestIdRequiredException | RevisionIdRequiredException | CommonErrors;
/**
 * Returns information about whether approval rules have been set aside (overridden) for a
 * pull request, and if so, the Amazon Resource Name (ARN) of the user or identity that overrode the rules and their requirements for the pull request.
 */
export declare const getPullRequestOverrideState: API.OperationMethod<GetPullRequestOverrideStateInput, GetPullRequestOverrideStateOutput, GetPullRequestOverrideStateError, Credentials | HttpClient.HttpClient>;
export type GetRepositoryError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns information about a repository.
 *
 * The description field for a repository accepts all HTML characters and all valid
 * Unicode characters. Applications that do not HTML-encode the description and display
 * it in a webpage can expose users to potentially malicious code. Make sure that you
 * HTML-encode the description field in any application that uses this API to display
 * the repository description on a webpage.
 */
export declare const getRepository: API.OperationMethod<GetRepositoryInput, GetRepositoryOutput, GetRepositoryError, Credentials | HttpClient.HttpClient>;
export type GetRepositoryTriggersError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Gets information about triggers configured for a repository.
 */
export declare const getRepositoryTriggers: API.OperationMethod<GetRepositoryTriggersInput, GetRepositoryTriggersOutput, GetRepositoryTriggersError, Credentials | HttpClient.HttpClient>;
export type ListApprovalRuleTemplatesError = InvalidContinuationTokenException | InvalidMaxResultsException | CommonErrors;
/**
 * Lists all approval rule templates in the specified Amazon Web Services Region in your Amazon Web Services account. If
 * an Amazon Web Services Region is not specified, the Amazon Web Services Region where you are signed in is used.
 */
export declare const listApprovalRuleTemplates: API.PaginatedOperationMethod<ListApprovalRuleTemplatesInput, ListApprovalRuleTemplatesOutput, ListApprovalRuleTemplatesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAssociatedApprovalRuleTemplatesForRepositoryError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidContinuationTokenException | InvalidMaxResultsException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Lists all approval rule templates that are associated with a specified repository.
 */
export declare const listAssociatedApprovalRuleTemplatesForRepository: API.PaginatedOperationMethod<ListAssociatedApprovalRuleTemplatesForRepositoryInput, ListAssociatedApprovalRuleTemplatesForRepositoryOutput, ListAssociatedApprovalRuleTemplatesForRepositoryError, Credentials | HttpClient.HttpClient, unknown>;
export type ListBranchesError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidContinuationTokenException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Gets information about one or more branches in a repository.
 */
export declare const listBranches: API.PaginatedOperationMethod<ListBranchesInput, ListBranchesOutput, ListBranchesError, Credentials | HttpClient.HttpClient, BranchName>;
export type ListFileCommitHistoryError = CommitDoesNotExistException | CommitRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommitException | InvalidContinuationTokenException | InvalidMaxResultsException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | TipsDivergenceExceededException | CommonErrors;
/**
 * Retrieves a list of commits and changes to a specified file.
 */
export declare const listFileCommitHistory: API.PaginatedOperationMethod<ListFileCommitHistoryRequest, ListFileCommitHistoryResponse, ListFileCommitHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPullRequestsError = AuthorDoesNotExistException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidAuthorArnException | InvalidContinuationTokenException | InvalidMaxResultsException | InvalidPullRequestStatusException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Returns a list of pull requests for a specified repository. The return list can be refined by pull request
 * status or pull request author ARN.
 */
export declare const listPullRequests: API.PaginatedOperationMethod<ListPullRequestsInput, ListPullRequestsOutput, ListPullRequestsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRepositoriesError = InvalidContinuationTokenException | InvalidOrderException | InvalidSortByException | CommonErrors;
/**
 * Gets information about one or more repositories.
 */
export declare const listRepositories: API.PaginatedOperationMethod<ListRepositoriesInput, ListRepositoriesOutput, ListRepositoriesError, Credentials | HttpClient.HttpClient, RepositoryNameIdPair>;
export type ListRepositoriesForApprovalRuleTemplateError = ApprovalRuleTemplateDoesNotExistException | ApprovalRuleTemplateNameRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidApprovalRuleTemplateNameException | InvalidContinuationTokenException | InvalidMaxResultsException | CommonErrors;
/**
 * Lists all repositories associated with the specified approval rule template.
 */
export declare const listRepositoriesForApprovalRuleTemplate: API.PaginatedOperationMethod<ListRepositoriesForApprovalRuleTemplateInput, ListRepositoriesForApprovalRuleTemplateOutput, ListRepositoriesForApprovalRuleTemplateError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InvalidRepositoryNameException | InvalidResourceArnException | RepositoryDoesNotExistException | ResourceArnRequiredException | CommonErrors;
/**
 * Gets information about Amazon Web Servicestags for a specified Amazon Resource Name (ARN) in CodeCommit. For a list of valid resources in CodeCommit, see CodeCommit Resources and Operations in the CodeCommit User
 * Guide.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type MergeBranchesByFastForwardError = BranchDoesNotExistException | BranchNameIsTagNameException | BranchNameRequiredException | CommitDoesNotExistException | CommitRequiredException | ConcurrentReferenceUpdateException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidBranchNameException | InvalidCommitException | InvalidRepositoryNameException | InvalidTargetBranchException | ManualMergeRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | TipsDivergenceExceededException | CommonErrors;
/**
 * Merges two branches using the fast-forward merge strategy.
 */
export declare const mergeBranchesByFastForward: API.OperationMethod<MergeBranchesByFastForwardInput, MergeBranchesByFastForwardOutput, MergeBranchesByFastForwardError, Credentials | HttpClient.HttpClient>;
export type MergeBranchesBySquashError = BranchDoesNotExistException | BranchNameIsTagNameException | BranchNameRequiredException | CommitDoesNotExistException | CommitMessageLengthExceededException | CommitRequiredException | ConcurrentReferenceUpdateException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileContentSizeLimitExceededException | FileModeRequiredException | FolderContentSizeLimitExceededException | InvalidBranchNameException | InvalidCommitException | InvalidConflictDetailLevelException | InvalidConflictResolutionException | InvalidConflictResolutionStrategyException | InvalidEmailException | InvalidFileModeException | InvalidPathException | InvalidReplacementContentException | InvalidReplacementTypeException | InvalidRepositoryNameException | InvalidTargetBranchException | ManualMergeRequiredException | MaximumConflictResolutionEntriesExceededException | MaximumFileContentToLoadExceededException | MaximumItemsToCompareExceededException | MultipleConflictResolutionEntriesException | NameLengthExceededException | PathRequiredException | ReplacementContentRequiredException | ReplacementTypeRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | TipsDivergenceExceededException | CommonErrors;
/**
 * Merges two branches using the squash merge strategy.
 */
export declare const mergeBranchesBySquash: API.OperationMethod<MergeBranchesBySquashInput, MergeBranchesBySquashOutput, MergeBranchesBySquashError, Credentials | HttpClient.HttpClient>;
export type MergeBranchesByThreeWayError = BranchDoesNotExistException | BranchNameIsTagNameException | BranchNameRequiredException | CommitDoesNotExistException | CommitMessageLengthExceededException | CommitRequiredException | ConcurrentReferenceUpdateException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileContentSizeLimitExceededException | FileModeRequiredException | FolderContentSizeLimitExceededException | InvalidBranchNameException | InvalidCommitException | InvalidConflictDetailLevelException | InvalidConflictResolutionException | InvalidConflictResolutionStrategyException | InvalidEmailException | InvalidFileModeException | InvalidPathException | InvalidReplacementContentException | InvalidReplacementTypeException | InvalidRepositoryNameException | InvalidTargetBranchException | ManualMergeRequiredException | MaximumConflictResolutionEntriesExceededException | MaximumFileContentToLoadExceededException | MaximumItemsToCompareExceededException | MultipleConflictResolutionEntriesException | NameLengthExceededException | PathRequiredException | ReplacementContentRequiredException | ReplacementTypeRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | TipsDivergenceExceededException | CommonErrors;
/**
 * Merges two specified branches using the three-way merge strategy.
 */
export declare const mergeBranchesByThreeWay: API.OperationMethod<MergeBranchesByThreeWayInput, MergeBranchesByThreeWayOutput, MergeBranchesByThreeWayError, Credentials | HttpClient.HttpClient>;
export type MergePullRequestByFastForwardError = ConcurrentReferenceUpdateException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidCommitIdException | InvalidPullRequestIdException | InvalidRepositoryNameException | ManualMergeRequiredException | PullRequestAlreadyClosedException | PullRequestApprovalRulesNotSatisfiedException | PullRequestDoesNotExistException | PullRequestIdRequiredException | ReferenceDoesNotExistException | RepositoryDoesNotExistException | RepositoryNameRequiredException | RepositoryNotAssociatedWithPullRequestException | TipOfSourceReferenceIsDifferentException | CommonErrors;
/**
 * Attempts to merge the source commit of a pull request into the specified destination
 * branch for that pull request at the specified commit using the fast-forward merge strategy. If the merge is successful, it closes the pull request.
 */
export declare const mergePullRequestByFastForward: API.OperationMethod<MergePullRequestByFastForwardInput, MergePullRequestByFastForwardOutput, MergePullRequestByFastForwardError, Credentials | HttpClient.HttpClient>;
export type MergePullRequestBySquashError = CommitMessageLengthExceededException | ConcurrentReferenceUpdateException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileContentSizeLimitExceededException | FolderContentSizeLimitExceededException | InvalidCommitIdException | InvalidConflictDetailLevelException | InvalidConflictResolutionException | InvalidConflictResolutionStrategyException | InvalidEmailException | InvalidFileModeException | InvalidPathException | InvalidPullRequestIdException | InvalidReplacementContentException | InvalidReplacementTypeException | InvalidRepositoryNameException | ManualMergeRequiredException | MaximumConflictResolutionEntriesExceededException | MaximumFileContentToLoadExceededException | MaximumItemsToCompareExceededException | MultipleConflictResolutionEntriesException | NameLengthExceededException | PathRequiredException | PullRequestAlreadyClosedException | PullRequestApprovalRulesNotSatisfiedException | PullRequestDoesNotExistException | PullRequestIdRequiredException | ReplacementContentRequiredException | ReplacementTypeRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | RepositoryNotAssociatedWithPullRequestException | TipOfSourceReferenceIsDifferentException | TipsDivergenceExceededException | CommonErrors;
/**
 * Attempts to merge the source commit of a pull request into the specified destination
 * branch for that pull request at the specified commit using the squash merge strategy. If the merge is successful, it closes the pull request.
 */
export declare const mergePullRequestBySquash: API.OperationMethod<MergePullRequestBySquashInput, MergePullRequestBySquashOutput, MergePullRequestBySquashError, Credentials | HttpClient.HttpClient>;
export type MergePullRequestByThreeWayError = CommitMessageLengthExceededException | ConcurrentReferenceUpdateException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileContentSizeLimitExceededException | FolderContentSizeLimitExceededException | InvalidCommitIdException | InvalidConflictDetailLevelException | InvalidConflictResolutionException | InvalidConflictResolutionStrategyException | InvalidEmailException | InvalidFileModeException | InvalidPathException | InvalidPullRequestIdException | InvalidReplacementContentException | InvalidReplacementTypeException | InvalidRepositoryNameException | ManualMergeRequiredException | MaximumConflictResolutionEntriesExceededException | MaximumFileContentToLoadExceededException | MaximumItemsToCompareExceededException | MultipleConflictResolutionEntriesException | NameLengthExceededException | PathRequiredException | PullRequestAlreadyClosedException | PullRequestApprovalRulesNotSatisfiedException | PullRequestDoesNotExistException | PullRequestIdRequiredException | ReplacementContentRequiredException | ReplacementTypeRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | RepositoryNotAssociatedWithPullRequestException | TipOfSourceReferenceIsDifferentException | TipsDivergenceExceededException | CommonErrors;
/**
 * Attempts to merge the source commit of a pull request into the specified destination
 * branch for that pull request at the specified commit using the three-way merge strategy. If the merge is successful, it closes the pull request.
 */
export declare const mergePullRequestByThreeWay: API.OperationMethod<MergePullRequestByThreeWayInput, MergePullRequestByThreeWayOutput, MergePullRequestByThreeWayError, Credentials | HttpClient.HttpClient>;
export type OverridePullRequestApprovalRulesError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidOverrideStatusException | InvalidPullRequestIdException | InvalidRevisionIdException | OverrideAlreadySetException | OverrideStatusRequiredException | PullRequestAlreadyClosedException | PullRequestDoesNotExistException | PullRequestIdRequiredException | RevisionIdRequiredException | RevisionNotCurrentException | CommonErrors;
/**
 * Sets aside (overrides) all approval rule requirements for a specified pull request.
 */
export declare const overridePullRequestApprovalRules: API.OperationMethod<OverridePullRequestApprovalRulesInput, OverridePullRequestApprovalRulesResponse, OverridePullRequestApprovalRulesError, Credentials | HttpClient.HttpClient>;
export type PostCommentForComparedCommitError = BeforeCommitIdAndAfterCommitIdAreSameException | ClientRequestTokenRequiredException | CommentContentRequiredException | CommentContentSizeLimitExceededException | CommitDoesNotExistException | CommitIdRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | IdempotencyParameterMismatchException | InvalidClientRequestTokenException | InvalidCommitIdException | InvalidFileLocationException | InvalidFilePositionException | InvalidPathException | InvalidRelativeFileVersionEnumException | InvalidRepositoryNameException | PathDoesNotExistException | PathRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Posts a comment on the comparison between two commits.
 */
export declare const postCommentForComparedCommit: API.OperationMethod<PostCommentForComparedCommitInput, PostCommentForComparedCommitOutput, PostCommentForComparedCommitError, Credentials | HttpClient.HttpClient>;
export type PostCommentForPullRequestError = BeforeCommitIdAndAfterCommitIdAreSameException | ClientRequestTokenRequiredException | CommentContentRequiredException | CommentContentSizeLimitExceededException | CommitDoesNotExistException | CommitIdRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | IdempotencyParameterMismatchException | InvalidClientRequestTokenException | InvalidCommitIdException | InvalidFileLocationException | InvalidFilePositionException | InvalidPathException | InvalidPullRequestIdException | InvalidRelativeFileVersionEnumException | InvalidRepositoryNameException | PathDoesNotExistException | PathRequiredException | PullRequestDoesNotExistException | PullRequestIdRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | RepositoryNotAssociatedWithPullRequestException | CommonErrors;
/**
 * Posts a comment on a pull request.
 */
export declare const postCommentForPullRequest: API.OperationMethod<PostCommentForPullRequestInput, PostCommentForPullRequestOutput, PostCommentForPullRequestError, Credentials | HttpClient.HttpClient>;
export type PostCommentReplyError = ClientRequestTokenRequiredException | CommentContentRequiredException | CommentContentSizeLimitExceededException | CommentDoesNotExistException | CommentIdRequiredException | IdempotencyParameterMismatchException | InvalidClientRequestTokenException | InvalidCommentIdException | CommonErrors;
/**
 * Posts a comment in reply to an existing comment on a comparison between commits or a pull request.
 */
export declare const postCommentReply: API.OperationMethod<PostCommentReplyInput, PostCommentReplyOutput, PostCommentReplyError, Credentials | HttpClient.HttpClient>;
export type PutCommentReactionError = CommentDeletedException | CommentDoesNotExistException | CommentIdRequiredException | InvalidCommentIdException | InvalidReactionValueException | ReactionLimitExceededException | ReactionValueRequiredException | CommonErrors;
/**
 * Adds or updates a reaction to a specified comment for the user whose identity is used to make the request. You can only add or
 * update a reaction for yourself. You cannot add, modify, or delete a reaction for another user.
 */
export declare const putCommentReaction: API.OperationMethod<PutCommentReactionInput, PutCommentReactionResponse, PutCommentReactionError, Credentials | HttpClient.HttpClient>;
export type PutFileError = BranchDoesNotExistException | BranchNameIsTagNameException | BranchNameRequiredException | CommitMessageLengthExceededException | DirectoryNameConflictsWithFileNameException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | FileContentRequiredException | FileContentSizeLimitExceededException | FileNameConflictsWithDirectoryNameException | FilePathConflictsWithSubmodulePathException | FolderContentSizeLimitExceededException | InvalidBranchNameException | InvalidDeletionParameterException | InvalidEmailException | InvalidFileModeException | InvalidParentCommitIdException | InvalidPathException | InvalidRepositoryNameException | NameLengthExceededException | ParentCommitDoesNotExistException | ParentCommitIdOutdatedException | ParentCommitIdRequiredException | PathRequiredException | RepositoryDoesNotExistException | RepositoryNameRequiredException | SameFileContentException | CommonErrors;
/**
 * Adds or updates a file in a branch in an CodeCommit repository, and generates a commit for the addition in the specified branch.
 */
export declare const putFile: API.OperationMethod<PutFileInput, PutFileOutput, PutFileError, Credentials | HttpClient.HttpClient>;
export type PutRepositoryTriggersError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidRepositoryNameException | InvalidRepositoryTriggerBranchNameException | InvalidRepositoryTriggerCustomDataException | InvalidRepositoryTriggerDestinationArnException | InvalidRepositoryTriggerEventsException | InvalidRepositoryTriggerNameException | InvalidRepositoryTriggerRegionException | MaximumBranchesExceededException | MaximumRepositoryTriggersExceededException | RepositoryDoesNotExistException | RepositoryNameRequiredException | RepositoryTriggerBranchNameListRequiredException | RepositoryTriggerDestinationArnRequiredException | RepositoryTriggerEventsListRequiredException | RepositoryTriggerNameRequiredException | RepositoryTriggersListRequiredException | CommonErrors;
/**
 * Replaces all triggers for a repository. Used to create or delete triggers.
 */
export declare const putRepositoryTriggers: API.OperationMethod<PutRepositoryTriggersInput, PutRepositoryTriggersOutput, PutRepositoryTriggersError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidRepositoryNameException | InvalidResourceArnException | InvalidSystemTagUsageException | InvalidTagsMapException | RepositoryDoesNotExistException | ResourceArnRequiredException | TagPolicyException | TagsMapRequiredException | TooManyTagsException | CommonErrors;
/**
 * Adds or updates tags for a resource in CodeCommit. For a list of valid resources
 * in CodeCommit, see CodeCommit Resources and Operations in the CodeCommit User
 * Guide.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestRepositoryTriggersError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidRepositoryNameException | InvalidRepositoryTriggerBranchNameException | InvalidRepositoryTriggerCustomDataException | InvalidRepositoryTriggerDestinationArnException | InvalidRepositoryTriggerEventsException | InvalidRepositoryTriggerNameException | InvalidRepositoryTriggerRegionException | MaximumBranchesExceededException | MaximumRepositoryTriggersExceededException | RepositoryDoesNotExistException | RepositoryNameRequiredException | RepositoryTriggerBranchNameListRequiredException | RepositoryTriggerDestinationArnRequiredException | RepositoryTriggerEventsListRequiredException | RepositoryTriggerNameRequiredException | RepositoryTriggersListRequiredException | CommonErrors;
/**
 * Tests the functionality of repository triggers by sending information to the trigger
 * target. If real data is available in the repository, the test sends data from the last
 * commit. If no data is available, sample data is generated.
 */
export declare const testRepositoryTriggers: API.OperationMethod<TestRepositoryTriggersInput, TestRepositoryTriggersOutput, TestRepositoryTriggersError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InvalidRepositoryNameException | InvalidResourceArnException | InvalidSystemTagUsageException | InvalidTagKeysListException | RepositoryDoesNotExistException | ResourceArnRequiredException | TagKeysListRequiredException | TagPolicyException | TooManyTagsException | CommonErrors;
/**
 * Removes tags for a resource in CodeCommit. For a list of valid resources in CodeCommit, see CodeCommit Resources and Operations in the CodeCommit User
 * Guide.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApprovalRuleTemplateContentError = ApprovalRuleTemplateContentRequiredException | ApprovalRuleTemplateDoesNotExistException | ApprovalRuleTemplateNameRequiredException | InvalidApprovalRuleTemplateContentException | InvalidApprovalRuleTemplateNameException | InvalidRuleContentSha256Exception | CommonErrors;
/**
 * Updates the content of an approval rule template. You can change the number of
 * required approvals, the membership of the approval rule, and whether an approval pool is
 * defined.
 */
export declare const updateApprovalRuleTemplateContent: API.OperationMethod<UpdateApprovalRuleTemplateContentInput, UpdateApprovalRuleTemplateContentOutput, UpdateApprovalRuleTemplateContentError, Credentials | HttpClient.HttpClient>;
export type UpdateApprovalRuleTemplateDescriptionError = ApprovalRuleTemplateDoesNotExistException | ApprovalRuleTemplateNameRequiredException | InvalidApprovalRuleTemplateDescriptionException | InvalidApprovalRuleTemplateNameException | CommonErrors;
/**
 * Updates the description for a specified approval rule template.
 */
export declare const updateApprovalRuleTemplateDescription: API.OperationMethod<UpdateApprovalRuleTemplateDescriptionInput, UpdateApprovalRuleTemplateDescriptionOutput, UpdateApprovalRuleTemplateDescriptionError, Credentials | HttpClient.HttpClient>;
export type UpdateApprovalRuleTemplateNameError = ApprovalRuleTemplateDoesNotExistException | ApprovalRuleTemplateNameAlreadyExistsException | ApprovalRuleTemplateNameRequiredException | InvalidApprovalRuleTemplateNameException | CommonErrors;
/**
 * Updates the name of a specified approval rule template.
 */
export declare const updateApprovalRuleTemplateName: API.OperationMethod<UpdateApprovalRuleTemplateNameInput, UpdateApprovalRuleTemplateNameOutput, UpdateApprovalRuleTemplateNameError, Credentials | HttpClient.HttpClient>;
export type UpdateCommentError = CommentContentRequiredException | CommentContentSizeLimitExceededException | CommentDeletedException | CommentDoesNotExistException | CommentIdRequiredException | CommentNotCreatedByCallerException | InvalidCommentIdException | CommonErrors;
/**
 * Replaces the contents of a comment.
 */
export declare const updateComment: API.OperationMethod<UpdateCommentInput, UpdateCommentOutput, UpdateCommentError, Credentials | HttpClient.HttpClient>;
export type UpdateDefaultBranchError = BranchDoesNotExistException | BranchNameRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidBranchNameException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Sets or changes the default branch name for the specified repository.
 *
 * If you use this operation to change the default branch name to the current default branch name, a success message is returned even though the default branch did not change.
 */
export declare const updateDefaultBranch: API.OperationMethod<UpdateDefaultBranchInput, UpdateDefaultBranchResponse, UpdateDefaultBranchError, Credentials | HttpClient.HttpClient>;
export type UpdatePullRequestApprovalRuleContentError = ApprovalRuleContentRequiredException | ApprovalRuleDoesNotExistException | ApprovalRuleNameRequiredException | CannotModifyApprovalRuleFromTemplateException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidApprovalRuleContentException | InvalidApprovalRuleNameException | InvalidPullRequestIdException | InvalidRuleContentSha256Exception | PullRequestAlreadyClosedException | PullRequestDoesNotExistException | PullRequestIdRequiredException | CommonErrors;
/**
 * Updates the structure of an approval rule created specifically for a pull request. For example, you can change the number of required approvers and
 * the approval pool for approvers.
 */
export declare const updatePullRequestApprovalRuleContent: API.OperationMethod<UpdatePullRequestApprovalRuleContentInput, UpdatePullRequestApprovalRuleContentOutput, UpdatePullRequestApprovalRuleContentError, Credentials | HttpClient.HttpClient>;
export type UpdatePullRequestApprovalStateError = ApprovalStateRequiredException | EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidApprovalStateException | InvalidPullRequestIdException | InvalidRevisionIdException | MaximumNumberOfApprovalsExceededException | PullRequestAlreadyClosedException | PullRequestCannotBeApprovedByAuthorException | PullRequestDoesNotExistException | PullRequestIdRequiredException | RevisionIdRequiredException | RevisionNotCurrentException | CommonErrors;
/**
 * Updates the state of a user's approval on a pull request. The user is derived from the signed-in account when the request is made.
 */
export declare const updatePullRequestApprovalState: API.OperationMethod<UpdatePullRequestApprovalStateInput, UpdatePullRequestApprovalStateResponse, UpdatePullRequestApprovalStateError, Credentials | HttpClient.HttpClient>;
export type UpdatePullRequestDescriptionError = InvalidDescriptionException | InvalidPullRequestIdException | PullRequestAlreadyClosedException | PullRequestDoesNotExistException | PullRequestIdRequiredException | CommonErrors;
/**
 * Replaces the contents of the description of a pull request.
 */
export declare const updatePullRequestDescription: API.OperationMethod<UpdatePullRequestDescriptionInput, UpdatePullRequestDescriptionOutput, UpdatePullRequestDescriptionError, Credentials | HttpClient.HttpClient>;
export type UpdatePullRequestStatusError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidPullRequestIdException | InvalidPullRequestStatusException | InvalidPullRequestStatusUpdateException | PullRequestDoesNotExistException | PullRequestIdRequiredException | PullRequestStatusRequiredException | CommonErrors;
/**
 * Updates the status of a pull request.
 */
export declare const updatePullRequestStatus: API.OperationMethod<UpdatePullRequestStatusInput, UpdatePullRequestStatusOutput, UpdatePullRequestStatusError, Credentials | HttpClient.HttpClient>;
export type UpdatePullRequestTitleError = InvalidPullRequestIdException | InvalidTitleException | PullRequestAlreadyClosedException | PullRequestDoesNotExistException | PullRequestIdRequiredException | TitleRequiredException | CommonErrors;
/**
 * Replaces the title of a pull request.
 */
export declare const updatePullRequestTitle: API.OperationMethod<UpdatePullRequestTitleInput, UpdatePullRequestTitleOutput, UpdatePullRequestTitleError, Credentials | HttpClient.HttpClient>;
export type UpdateRepositoryDescriptionError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyNotFoundException | EncryptionKeyUnavailableException | InvalidRepositoryDescriptionException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Sets or changes the comment or description for a repository.
 *
 * The description field for a repository accepts all HTML characters and all valid
 * Unicode characters. Applications that do not HTML-encode the description and display
 * it in a webpage can expose users to potentially malicious code. Make sure that you
 * HTML-encode the description field in any application that uses this API to display
 * the repository description on a webpage.
 */
export declare const updateRepositoryDescription: API.OperationMethod<UpdateRepositoryDescriptionInput, UpdateRepositoryDescriptionResponse, UpdateRepositoryDescriptionError, Credentials | HttpClient.HttpClient>;
export type UpdateRepositoryEncryptionKeyError = EncryptionIntegrityChecksFailedException | EncryptionKeyAccessDeniedException | EncryptionKeyDisabledException | EncryptionKeyInvalidIdException | EncryptionKeyInvalidUsageException | EncryptionKeyNotFoundException | EncryptionKeyRequiredException | EncryptionKeyUnavailableException | InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameRequiredException | CommonErrors;
/**
 * Updates the Key Management Service encryption key used to encrypt and decrypt a CodeCommit repository.
 */
export declare const updateRepositoryEncryptionKey: API.OperationMethod<UpdateRepositoryEncryptionKeyInput, UpdateRepositoryEncryptionKeyOutput, UpdateRepositoryEncryptionKeyError, Credentials | HttpClient.HttpClient>;
export type UpdateRepositoryNameError = InvalidRepositoryNameException | RepositoryDoesNotExistException | RepositoryNameExistsException | RepositoryNameRequiredException | CommonErrors;
/**
 * Renames a repository. The repository name must be unique across the calling Amazon Web Services account.
 * Repository names are limited to 100 alphanumeric, dash, and underscore
 * characters, and cannot include certain characters. The suffix .git is prohibited. For
 * more information about the limits on repository names, see Quotas in the CodeCommit
 * User Guide.
 */
export declare const updateRepositoryName: API.OperationMethod<UpdateRepositoryNameInput, UpdateRepositoryNameResponse, UpdateRepositoryNameError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=codecommit.d.ts.map