import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type IdempotencyToken = string;
export type AddonSubscriptionId = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface CreateAddonInstanceRequest {
    ClientToken?: string;
    AddonSubscriptionId: string;
    Tags?: Tag[];
}
export type AddonInstanceId = string;
export interface CreateAddonInstanceResponse {
    AddonInstanceId: string;
}
export type AddonName = string;
export interface CreateAddonSubscriptionRequest {
    ClientToken?: string;
    AddonName: string;
    Tags?: Tag[];
}
export interface CreateAddonSubscriptionResponse {
    AddonSubscriptionId: string;
}
export type AddressListName = string;
export interface CreateAddressListRequest {
    ClientToken?: string;
    AddressListName: string;
    Tags?: Tag[];
}
export type AddressListId = string;
export interface CreateAddressListResponse {
    AddressListId: string;
}
export type JobName = string;
export type ImportDataType = "CSV" | "JSON" | (string & {});
export interface ImportDataFormat {
    ImportDataType: ImportDataType;
}
export interface CreateAddressListImportJobRequest {
    ClientToken?: string;
    AddressListId: string;
    Name: string;
    ImportDataFormat: ImportDataFormat;
}
export type JobId = string;
export type PreSignedUrl = string | redacted.Redacted<string>;
export interface CreateAddressListImportJobResponse {
    JobId: string;
    PreSignedUrl: string | redacted.Redacted<string>;
}
export type ArchiveNameString = string;
export type RetentionPeriod = "THREE_MONTHS" | "SIX_MONTHS" | "NINE_MONTHS" | "ONE_YEAR" | "EIGHTEEN_MONTHS" | "TWO_YEARS" | "THIRTY_MONTHS" | "THREE_YEARS" | "FOUR_YEARS" | "FIVE_YEARS" | "SIX_YEARS" | "SEVEN_YEARS" | "EIGHT_YEARS" | "NINE_YEARS" | "TEN_YEARS" | "PERMANENT" | (string & {});
export type ArchiveRetention = {
    RetentionPeriod: RetentionPeriod;
};
export type KmsKeyArn = string;
export interface CreateArchiveRequest {
    ClientToken?: string;
    ArchiveName: string;
    Retention?: ArchiveRetention;
    KmsKeyArn?: string;
    Tags?: Tag[];
}
export type ArchiveIdString = string;
export interface CreateArchiveResponse {
    ArchiveId: string;
}
export type IngressPointName = string;
export type IngressPointType = "OPEN" | "AUTH" | "MTLS" | (string & {});
export type RuleSetId = string;
export type TrafficPolicyId = string;
export type SmtpPassword = string | redacted.Redacted<string>;
export type SecretArn = string;
export type CAContent = string | redacted.Redacted<string>;
export type CrlContent = string | redacted.Redacted<string>;
export interface TrustStore {
    CAContent: string | redacted.Redacted<string>;
    CrlContent?: string | redacted.Redacted<string>;
    KmsKeyArn?: string;
}
export interface TlsAuthConfiguration {
    TrustStore?: TrustStore;
}
export type IngressPointConfiguration = {
    SmtpPassword: string | redacted.Redacted<string>;
    SecretArn?: never;
    TlsAuthConfiguration?: never;
} | {
    SmtpPassword?: never;
    SecretArn: string;
    TlsAuthConfiguration?: never;
} | {
    SmtpPassword?: never;
    SecretArn?: never;
    TlsAuthConfiguration: TlsAuthConfiguration;
};
export type IpType = "IPV4" | "DUAL_STACK" | (string & {});
export interface PublicNetworkConfiguration {
    IpType: IpType;
}
export type VpcEndpointId = string;
export interface PrivateNetworkConfiguration {
    VpcEndpointId: string;
}
export type NetworkConfiguration = {
    PublicNetworkConfiguration: PublicNetworkConfiguration;
    PrivateNetworkConfiguration?: never;
} | {
    PublicNetworkConfiguration?: never;
    PrivateNetworkConfiguration: PrivateNetworkConfiguration;
};
export type TlsPolicy = "REQUIRED" | "OPTIONAL" | "FIPS" | (string & {});
export interface CreateIngressPointRequest {
    ClientToken?: string;
    IngressPointName: string;
    Type: IngressPointType;
    RuleSetId: string;
    TrafficPolicyId: string;
    IngressPointConfiguration?: IngressPointConfiguration;
    NetworkConfiguration?: NetworkConfiguration;
    TlsPolicy?: TlsPolicy;
    Tags?: Tag[];
}
export type IngressPointId = string;
export interface CreateIngressPointResponse {
    IngressPointId: string;
}
export type RelayName = string;
export type RelayServerName = string;
export type RelayServerPort = number;
export interface NoAuthentication {
}
export type RelayAuthentication = {
    SecretArn: string;
    NoAuthentication?: never;
} | {
    SecretArn?: never;
    NoAuthentication: NoAuthentication;
};
export interface CreateRelayRequest {
    ClientToken?: string;
    RelayName: string;
    ServerName: string;
    ServerPort: number;
    Authentication: RelayAuthentication;
    Tags?: Tag[];
}
export type RelayId = string;
export interface CreateRelayResponse {
    RelayId: string;
}
export type RuleSetName = string;
export type RuleName = string;
export type RuleBooleanEmailAttribute = "READ_RECEIPT_REQUESTED" | "TLS" | "TLS_WRAPPED" | (string & {});
export type AnalyzerArn = string;
export type ResultField = string;
export interface Analysis {
    Analyzer: string;
    ResultField: string;
}
export type RuleAddressListEmailAttribute = "RECIPIENT" | "MAIL_FROM" | "SENDER" | "FROM" | "TO" | "CC" | (string & {});
export type AddressListArn = string;
export type RuleAddressListArnList = string[];
export interface RuleIsInAddressList {
    Attribute: RuleAddressListEmailAttribute;
    AddressLists: string[];
}
export type RuleBooleanToEvaluate = {
    Attribute: RuleBooleanEmailAttribute;
    Analysis?: never;
    IsInAddressList?: never;
} | {
    Attribute?: never;
    Analysis: Analysis;
    IsInAddressList?: never;
} | {
    Attribute?: never;
    Analysis?: never;
    IsInAddressList: RuleIsInAddressList;
};
export type RuleBooleanOperator = "IS_TRUE" | "IS_FALSE" | (string & {});
export interface RuleBooleanExpression {
    Evaluate: RuleBooleanToEvaluate;
    Operator: RuleBooleanOperator;
}
export type RuleStringEmailAttribute = "MAIL_FROM" | "HELO" | "RECIPIENT" | "SENDER" | "FROM" | "SUBJECT" | "TO" | "CC" | (string & {});
export type MimeHeaderAttribute = string;
export type RuleClientCertificateAttribute = "CN" | "SAN_RFC822_NAME" | "SAN_DNS_NAME" | "SAN_DIRECTORY_NAME" | "SAN_UNIFORM_RESOURCE_IDENTIFIER" | "SAN_IP_ADDRESS" | "SAN_REGISTERED_ID" | "SERIAL_NUMBER" | (string & {});
export type RuleStringToEvaluate = {
    Attribute: RuleStringEmailAttribute;
    MimeHeaderAttribute?: never;
    Analysis?: never;
    ClientCertificateAttribute?: never;
} | {
    Attribute?: never;
    MimeHeaderAttribute: string;
    Analysis?: never;
    ClientCertificateAttribute?: never;
} | {
    Attribute?: never;
    MimeHeaderAttribute?: never;
    Analysis: Analysis;
    ClientCertificateAttribute?: never;
} | {
    Attribute?: never;
    MimeHeaderAttribute?: never;
    Analysis?: never;
    ClientCertificateAttribute: RuleClientCertificateAttribute;
};
export type RuleStringOperator = "EQUALS" | "NOT_EQUALS" | "STARTS_WITH" | "ENDS_WITH" | "CONTAINS" | (string & {});
export type RuleStringValue = string | redacted.Redacted<string>;
export type RuleStringList = (string | redacted.Redacted<string>)[];
export interface RuleStringExpression {
    Evaluate: RuleStringToEvaluate;
    Operator: RuleStringOperator;
    Values: (string | redacted.Redacted<string>)[];
}
export type RuleNumberEmailAttribute = "MESSAGE_SIZE" | (string & {});
export type RuleNumberToEvaluate = {
    Attribute: RuleNumberEmailAttribute;
};
export type RuleNumberOperator = "EQUALS" | "NOT_EQUALS" | "LESS_THAN" | "GREATER_THAN" | "LESS_THAN_OR_EQUAL" | "GREATER_THAN_OR_EQUAL" | (string & {});
export interface RuleNumberExpression {
    Evaluate: RuleNumberToEvaluate;
    Operator: RuleNumberOperator;
    Value: number;
}
export type RuleIpEmailAttribute = "SOURCE_IP" | (string & {});
export type RuleIpToEvaluate = {
    Attribute: RuleIpEmailAttribute;
};
export type RuleIpOperator = "CIDR_MATCHES" | "NOT_CIDR_MATCHES" | (string & {});
export type RuleIpStringValue = string;
export type RuleIpValueList = string[];
export interface RuleIpExpression {
    Evaluate: RuleIpToEvaluate;
    Operator: RuleIpOperator;
    Values: string[];
}
export type RuleVerdictAttribute = "SPF" | "DKIM" | (string & {});
export type RuleVerdictToEvaluate = {
    Attribute: RuleVerdictAttribute;
    Analysis?: never;
} | {
    Attribute?: never;
    Analysis: Analysis;
};
export type RuleVerdictOperator = "EQUALS" | "NOT_EQUALS" | (string & {});
export type RuleVerdict = "PASS" | "FAIL" | "GRAY" | "PROCESSING_FAILED" | (string & {});
export type RuleVerdictValueList = RuleVerdict[];
export interface RuleVerdictExpression {
    Evaluate: RuleVerdictToEvaluate;
    Operator: RuleVerdictOperator;
    Values: RuleVerdict[];
}
export type RuleDmarcOperator = "EQUALS" | "NOT_EQUALS" | (string & {});
export type RuleDmarcPolicy = "NONE" | "QUARANTINE" | "REJECT" | (string & {});
export type RuleDmarcValueList = RuleDmarcPolicy[];
export interface RuleDmarcExpression {
    Operator: RuleDmarcOperator;
    Values: RuleDmarcPolicy[];
}
export type RuleCondition = {
    BooleanExpression: RuleBooleanExpression;
    StringExpression?: never;
    NumberExpression?: never;
    IpExpression?: never;
    VerdictExpression?: never;
    DmarcExpression?: never;
} | {
    BooleanExpression?: never;
    StringExpression: RuleStringExpression;
    NumberExpression?: never;
    IpExpression?: never;
    VerdictExpression?: never;
    DmarcExpression?: never;
} | {
    BooleanExpression?: never;
    StringExpression?: never;
    NumberExpression: RuleNumberExpression;
    IpExpression?: never;
    VerdictExpression?: never;
    DmarcExpression?: never;
} | {
    BooleanExpression?: never;
    StringExpression?: never;
    NumberExpression?: never;
    IpExpression: RuleIpExpression;
    VerdictExpression?: never;
    DmarcExpression?: never;
} | {
    BooleanExpression?: never;
    StringExpression?: never;
    NumberExpression?: never;
    IpExpression?: never;
    VerdictExpression: RuleVerdictExpression;
    DmarcExpression?: never;
} | {
    BooleanExpression?: never;
    StringExpression?: never;
    NumberExpression?: never;
    IpExpression?: never;
    VerdictExpression?: never;
    DmarcExpression: RuleDmarcExpression;
};
export type RuleConditions = RuleCondition[];
export interface DropAction {
}
export type ActionFailurePolicy = "CONTINUE" | "DROP" | (string & {});
export type IdOrArn = string;
export type MailFrom = "REPLACE" | "PRESERVE" | (string & {});
export interface RelayAction {
    ActionFailurePolicy?: ActionFailurePolicy;
    Relay: string;
    MailFrom?: MailFrom;
}
export type NameOrArn = string;
export interface ArchiveAction {
    ActionFailurePolicy?: ActionFailurePolicy;
    TargetArchive: string;
}
export type IamRoleArn = string;
export type S3Bucket = string;
export type S3Prefix = string;
export type KmsKeyId = string;
export interface S3Action {
    ActionFailurePolicy?: ActionFailurePolicy;
    RoleArn: string;
    S3Bucket: string;
    S3Prefix?: string;
    S3SseKmsKeyId?: string;
}
export interface SendAction {
    ActionFailurePolicy?: ActionFailurePolicy;
    RoleArn: string;
}
export type HeaderName = string;
export type HeaderValue = string;
export interface AddHeaderAction {
    HeaderName: string;
    HeaderValue: string;
}
export type EmailAddress = string | redacted.Redacted<string>;
export type Recipients = (string | redacted.Redacted<string>)[];
export interface ReplaceRecipientAction {
    ReplaceWith?: (string | redacted.Redacted<string>)[];
}
export interface DeliverToMailboxAction {
    ActionFailurePolicy?: ActionFailurePolicy;
    MailboxArn: string;
    RoleArn: string;
}
export type QBusinessApplicationId = string;
export type QBusinessIndexId = string;
export interface DeliverToQBusinessAction {
    ActionFailurePolicy?: ActionFailurePolicy;
    ApplicationId: string;
    IndexId: string;
    RoleArn: string;
}
export type SnsTopicArn = string;
export type SnsNotificationEncoding = "UTF-8" | "BASE64" | (string & {});
export type SnsNotificationPayloadType = "HEADERS" | "CONTENT" | (string & {});
export interface SnsAction {
    ActionFailurePolicy?: ActionFailurePolicy;
    TopicArn: string;
    RoleArn: string;
    Encoding?: SnsNotificationEncoding;
    PayloadType?: SnsNotificationPayloadType;
}
export type StatusCode = string;
export type SmtpReplyCode = string;
export type DiagnosticMessage = string | redacted.Redacted<string>;
export type BounceMessage = string | redacted.Redacted<string>;
export interface BounceAction {
    ActionFailurePolicy?: ActionFailurePolicy;
    RoleArn: string;
    Sender: string | redacted.Redacted<string>;
    StatusCode: string;
    SmtpReplyCode: string;
    DiagnosticMessage: string | redacted.Redacted<string>;
    Message?: string | redacted.Redacted<string>;
}
export type LambdaFunctionArn = string;
export type LambdaInvocationType = "EVENT" | "REQUEST_RESPONSE" | (string & {});
export type LambdaRetryTimeMinutes = number;
export interface InvokeLambdaAction {
    ActionFailurePolicy?: ActionFailurePolicy;
    FunctionArn: string;
    InvocationType: LambdaInvocationType;
    RoleArn: string;
    RetryTimeMinutes?: number;
}
export type RuleAction = {
    Drop: DropAction;
    Relay?: never;
    Archive?: never;
    WriteToS3?: never;
    Send?: never;
    AddHeader?: never;
    ReplaceRecipient?: never;
    DeliverToMailbox?: never;
    DeliverToQBusiness?: never;
    PublishToSns?: never;
    Bounce?: never;
    InvokeLambda?: never;
} | {
    Drop?: never;
    Relay: RelayAction;
    Archive?: never;
    WriteToS3?: never;
    Send?: never;
    AddHeader?: never;
    ReplaceRecipient?: never;
    DeliverToMailbox?: never;
    DeliverToQBusiness?: never;
    PublishToSns?: never;
    Bounce?: never;
    InvokeLambda?: never;
} | {
    Drop?: never;
    Relay?: never;
    Archive: ArchiveAction;
    WriteToS3?: never;
    Send?: never;
    AddHeader?: never;
    ReplaceRecipient?: never;
    DeliverToMailbox?: never;
    DeliverToQBusiness?: never;
    PublishToSns?: never;
    Bounce?: never;
    InvokeLambda?: never;
} | {
    Drop?: never;
    Relay?: never;
    Archive?: never;
    WriteToS3: S3Action;
    Send?: never;
    AddHeader?: never;
    ReplaceRecipient?: never;
    DeliverToMailbox?: never;
    DeliverToQBusiness?: never;
    PublishToSns?: never;
    Bounce?: never;
    InvokeLambda?: never;
} | {
    Drop?: never;
    Relay?: never;
    Archive?: never;
    WriteToS3?: never;
    Send: SendAction;
    AddHeader?: never;
    ReplaceRecipient?: never;
    DeliverToMailbox?: never;
    DeliverToQBusiness?: never;
    PublishToSns?: never;
    Bounce?: never;
    InvokeLambda?: never;
} | {
    Drop?: never;
    Relay?: never;
    Archive?: never;
    WriteToS3?: never;
    Send?: never;
    AddHeader: AddHeaderAction;
    ReplaceRecipient?: never;
    DeliverToMailbox?: never;
    DeliverToQBusiness?: never;
    PublishToSns?: never;
    Bounce?: never;
    InvokeLambda?: never;
} | {
    Drop?: never;
    Relay?: never;
    Archive?: never;
    WriteToS3?: never;
    Send?: never;
    AddHeader?: never;
    ReplaceRecipient: ReplaceRecipientAction;
    DeliverToMailbox?: never;
    DeliverToQBusiness?: never;
    PublishToSns?: never;
    Bounce?: never;
    InvokeLambda?: never;
} | {
    Drop?: never;
    Relay?: never;
    Archive?: never;
    WriteToS3?: never;
    Send?: never;
    AddHeader?: never;
    ReplaceRecipient?: never;
    DeliverToMailbox: DeliverToMailboxAction;
    DeliverToQBusiness?: never;
    PublishToSns?: never;
    Bounce?: never;
    InvokeLambda?: never;
} | {
    Drop?: never;
    Relay?: never;
    Archive?: never;
    WriteToS3?: never;
    Send?: never;
    AddHeader?: never;
    ReplaceRecipient?: never;
    DeliverToMailbox?: never;
    DeliverToQBusiness: DeliverToQBusinessAction;
    PublishToSns?: never;
    Bounce?: never;
    InvokeLambda?: never;
} | {
    Drop?: never;
    Relay?: never;
    Archive?: never;
    WriteToS3?: never;
    Send?: never;
    AddHeader?: never;
    ReplaceRecipient?: never;
    DeliverToMailbox?: never;
    DeliverToQBusiness?: never;
    PublishToSns: SnsAction;
    Bounce?: never;
    InvokeLambda?: never;
} | {
    Drop?: never;
    Relay?: never;
    Archive?: never;
    WriteToS3?: never;
    Send?: never;
    AddHeader?: never;
    ReplaceRecipient?: never;
    DeliverToMailbox?: never;
    DeliverToQBusiness?: never;
    PublishToSns?: never;
    Bounce: BounceAction;
    InvokeLambda?: never;
} | {
    Drop?: never;
    Relay?: never;
    Archive?: never;
    WriteToS3?: never;
    Send?: never;
    AddHeader?: never;
    ReplaceRecipient?: never;
    DeliverToMailbox?: never;
    DeliverToQBusiness?: never;
    PublishToSns?: never;
    Bounce?: never;
    InvokeLambda: InvokeLambdaAction;
};
export type RuleActions = RuleAction[];
export interface Rule {
    Name?: string;
    Conditions?: RuleCondition[];
    Unless?: RuleCondition[];
    Actions: RuleAction[];
}
export type Rules = Rule[];
export interface CreateRuleSetRequest {
    ClientToken?: string;
    RuleSetName: string;
    Rules: Rule[];
    Tags?: Tag[];
}
export interface CreateRuleSetResponse {
    RuleSetId: string;
}
export type TrafficPolicyName = string;
export type IngressStringEmailAttribute = "RECIPIENT" | (string & {});
export interface IngressAnalysis {
    Analyzer: string;
    ResultField: string;
}
export type IngressStringToEvaluate = {
    Attribute: IngressStringEmailAttribute;
    Analysis?: never;
} | {
    Attribute?: never;
    Analysis: IngressAnalysis;
};
export type IngressStringOperator = "EQUALS" | "NOT_EQUALS" | "STARTS_WITH" | "ENDS_WITH" | "CONTAINS" | (string & {});
export type StringList = string[];
export interface IngressStringExpression {
    Evaluate: IngressStringToEvaluate;
    Operator: IngressStringOperator;
    Values: string[];
}
export type IngressIpv4Attribute = "SENDER_IP" | (string & {});
export type IngressIpToEvaluate = {
    Attribute: IngressIpv4Attribute;
};
export type IngressIpOperator = "CIDR_MATCHES" | "NOT_CIDR_MATCHES" | (string & {});
export type Ipv4Cidr = string;
export type Ipv4Cidrs = string[];
export interface IngressIpv4Expression {
    Evaluate: IngressIpToEvaluate;
    Operator: IngressIpOperator;
    Values: string[];
}
export type IngressIpv6Attribute = "SENDER_IPV6" | (string & {});
export type IngressIpv6ToEvaluate = {
    Attribute: IngressIpv6Attribute;
};
export type Ipv6Cidr = string;
export type Ipv6Cidrs = string[];
export interface IngressIpv6Expression {
    Evaluate: IngressIpv6ToEvaluate;
    Operator: IngressIpOperator;
    Values: string[];
}
export type IngressTlsAttribute = "TLS_PROTOCOL" | (string & {});
export type IngressTlsProtocolToEvaluate = {
    Attribute: IngressTlsAttribute;
};
export type IngressTlsProtocolOperator = "MINIMUM_TLS_VERSION" | "IS" | (string & {});
export type IngressTlsProtocolAttribute = "TLS1_2" | "TLS1_3" | (string & {});
export interface IngressTlsProtocolExpression {
    Evaluate: IngressTlsProtocolToEvaluate;
    Operator: IngressTlsProtocolOperator;
    Value: IngressTlsProtocolAttribute;
}
export type IngressAddressListEmailAttribute = "RECIPIENT" | (string & {});
export type IngressAddressListArnList = string[];
export interface IngressIsInAddressList {
    Attribute: IngressAddressListEmailAttribute;
    AddressLists: string[];
}
export type IngressBooleanToEvaluate = {
    Analysis: IngressAnalysis;
    IsInAddressList?: never;
} | {
    Analysis?: never;
    IsInAddressList: IngressIsInAddressList;
};
export type IngressBooleanOperator = "IS_TRUE" | "IS_FALSE" | (string & {});
export interface IngressBooleanExpression {
    Evaluate: IngressBooleanToEvaluate;
    Operator: IngressBooleanOperator;
}
export type PolicyCondition = {
    StringExpression: IngressStringExpression;
    IpExpression?: never;
    Ipv6Expression?: never;
    TlsExpression?: never;
    BooleanExpression?: never;
} | {
    StringExpression?: never;
    IpExpression: IngressIpv4Expression;
    Ipv6Expression?: never;
    TlsExpression?: never;
    BooleanExpression?: never;
} | {
    StringExpression?: never;
    IpExpression?: never;
    Ipv6Expression: IngressIpv6Expression;
    TlsExpression?: never;
    BooleanExpression?: never;
} | {
    StringExpression?: never;
    IpExpression?: never;
    Ipv6Expression?: never;
    TlsExpression: IngressTlsProtocolExpression;
    BooleanExpression?: never;
} | {
    StringExpression?: never;
    IpExpression?: never;
    Ipv6Expression?: never;
    TlsExpression?: never;
    BooleanExpression: IngressBooleanExpression;
};
export type PolicyConditions = PolicyCondition[];
export type AcceptAction = "ALLOW" | "DENY" | (string & {});
export interface PolicyStatement {
    Conditions: PolicyCondition[];
    Action: AcceptAction;
}
export type PolicyStatementList = PolicyStatement[];
export type MaxMessageSizeBytes = number;
export interface CreateTrafficPolicyRequest {
    ClientToken?: string;
    TrafficPolicyName: string;
    PolicyStatements: PolicyStatement[];
    DefaultAction: AcceptAction;
    MaxMessageSizeBytes?: number;
    Tags?: Tag[];
}
export interface CreateTrafficPolicyResponse {
    TrafficPolicyId: string;
}
export interface DeleteAddonInstanceRequest {
    AddonInstanceId: string;
}
export interface DeleteAddonInstanceResponse {
}
export interface DeleteAddonSubscriptionRequest {
    AddonSubscriptionId: string;
}
export interface DeleteAddonSubscriptionResponse {
}
export interface DeleteAddressListRequest {
    AddressListId: string;
}
export interface DeleteAddressListResponse {
}
export interface DeleteArchiveRequest {
    ArchiveId: string;
}
export interface DeleteArchiveResponse {
}
export interface DeleteIngressPointRequest {
    IngressPointId: string;
}
export interface DeleteIngressPointResponse {
}
export interface DeleteRelayRequest {
    RelayId: string;
}
export interface DeleteRelayResponse {
}
export interface DeleteRuleSetRequest {
    RuleSetId: string;
}
export interface DeleteRuleSetResponse {
}
export interface DeleteTrafficPolicyRequest {
    TrafficPolicyId: string;
}
export interface DeleteTrafficPolicyResponse {
}
export type Address = string | redacted.Redacted<string>;
export interface DeregisterMemberFromAddressListRequest {
    AddressListId: string;
    Address: string | redacted.Redacted<string>;
}
export interface DeregisterMemberFromAddressListResponse {
}
export interface GetAddonInstanceRequest {
    AddonInstanceId: string;
}
export type AddonInstanceArn = string;
export interface GetAddonInstanceResponse {
    AddonSubscriptionId?: string;
    AddonName?: string;
    AddonInstanceArn?: string;
    CreatedTimestamp?: Date;
}
export interface GetAddonSubscriptionRequest {
    AddonSubscriptionId: string;
}
export type AddonSubscriptionArn = string;
export interface GetAddonSubscriptionResponse {
    AddonName?: string;
    AddonSubscriptionArn?: string;
    CreatedTimestamp?: Date;
}
export interface GetAddressListRequest {
    AddressListId: string;
}
export interface GetAddressListResponse {
    AddressListId: string;
    AddressListArn: string;
    AddressListName: string;
    CreatedTimestamp: Date;
    LastUpdatedTimestamp: Date;
}
export interface GetAddressListImportJobRequest {
    JobId: string;
}
export type ImportJobStatus = "CREATED" | "PROCESSING" | "COMPLETED" | "FAILED" | "STOPPED" | (string & {});
export type JobItemsCount = number;
export type ErrorMessage = string;
export interface GetAddressListImportJobResponse {
    JobId: string;
    Name: string;
    Status: ImportJobStatus;
    PreSignedUrl: string | redacted.Redacted<string>;
    ImportedItemsCount?: number;
    FailedItemsCount?: number;
    ImportDataFormat: ImportDataFormat;
    AddressListId: string;
    CreatedTimestamp: Date;
    StartTimestamp?: Date;
    CompletedTimestamp?: Date;
    Error?: string;
}
export interface GetArchiveRequest {
    ArchiveId: string;
}
export type ArchiveArn = string;
export type ArchiveState = "ACTIVE" | "PENDING_DELETION" | (string & {});
export interface GetArchiveResponse {
    ArchiveId: string;
    ArchiveName: string;
    ArchiveArn: string;
    ArchiveState: ArchiveState;
    Retention: ArchiveRetention;
    CreatedTimestamp?: Date;
    LastUpdatedTimestamp?: Date;
    KmsKeyArn?: string;
}
export type ExportId = string;
export interface GetArchiveExportRequest {
    ExportId: string;
}
export type ArchiveId = string;
export type ArchiveStringEmailAttribute = "TO" | "FROM" | "CC" | "SUBJECT" | "ENVELOPE_TO" | "ENVELOPE_FROM" | (string & {});
export type ArchiveStringToEvaluate = {
    Attribute: ArchiveStringEmailAttribute;
};
export type ArchiveStringOperator = "CONTAINS" | (string & {});
export type StringValue = string;
export type StringValueList = string[];
export interface ArchiveStringExpression {
    Evaluate: ArchiveStringToEvaluate;
    Operator: ArchiveStringOperator;
    Values: string[];
}
export type ArchiveBooleanEmailAttribute = "HAS_ATTACHMENTS" | (string & {});
export type ArchiveBooleanToEvaluate = {
    Attribute: ArchiveBooleanEmailAttribute;
};
export type ArchiveBooleanOperator = "IS_TRUE" | "IS_FALSE" | (string & {});
export interface ArchiveBooleanExpression {
    Evaluate: ArchiveBooleanToEvaluate;
    Operator: ArchiveBooleanOperator;
}
export type ArchiveFilterCondition = {
    StringExpression: ArchiveStringExpression;
    BooleanExpression?: never;
} | {
    StringExpression?: never;
    BooleanExpression: ArchiveBooleanExpression;
};
export type ArchiveFilterConditions = ArchiveFilterCondition[];
export interface ArchiveFilters {
    Include?: ArchiveFilterCondition[];
    Unless?: ArchiveFilterCondition[];
}
export type ExportMaxResults = number;
export type S3Location = string;
export interface S3ExportDestinationConfiguration {
    S3Location?: string;
}
export type ExportDestinationConfiguration = {
    S3: S3ExportDestinationConfiguration;
};
export type ExportState = "QUEUED" | "PREPROCESSING" | "PROCESSING" | "COMPLETED" | "FAILED" | "CANCELLED" | (string & {});
export interface ExportStatus {
    SubmissionTimestamp?: Date;
    CompletionTimestamp?: Date;
    State?: ExportState;
    ErrorMessage?: string;
}
export interface GetArchiveExportResponse {
    ArchiveId?: string;
    Filters?: ArchiveFilters;
    FromTimestamp?: Date;
    ToTimestamp?: Date;
    MaxResults?: number;
    ExportDestinationConfiguration?: ExportDestinationConfiguration;
    Status?: ExportStatus;
}
export type ArchivedMessageId = string;
export interface GetArchiveMessageRequest {
    ArchivedMessageId: string;
}
export type S3PresignedURL = string;
export type SenderIpAddress = string | redacted.Redacted<string>;
export interface Metadata {
    Timestamp?: Date;
    IngressPointId?: string;
    TrafficPolicyId?: string;
    RuleSetId?: string;
    SenderHostname?: string;
    SenderIpAddress?: string | redacted.Redacted<string>;
    TlsCipherSuite?: string;
    TlsProtocol?: string;
    SendingMethod?: string;
    SourceIdentity?: string;
    SendingPool?: string;
    ConfigurationSet?: string;
    SourceArn?: string;
}
export interface Envelope {
    Helo?: string;
    From?: string;
    To?: string[];
}
export interface GetArchiveMessageResponse {
    MessageDownloadLink?: string;
    Metadata?: Metadata;
    Envelope?: Envelope;
}
export interface GetArchiveMessageContentRequest {
    ArchivedMessageId: string;
}
export interface MessageBody {
    Text?: string;
    Html?: string;
    MessageMalformed?: boolean;
}
export interface GetArchiveMessageContentResponse {
    Body?: MessageBody;
}
export type SearchId = string;
export interface GetArchiveSearchRequest {
    SearchId: string;
}
export type SearchMaxResults = number;
export type SearchState = "QUEUED" | "RUNNING" | "COMPLETED" | "FAILED" | "CANCELLED" | (string & {});
export interface SearchStatus {
    SubmissionTimestamp?: Date;
    CompletionTimestamp?: Date;
    State?: SearchState;
    ErrorMessage?: string;
}
export interface GetArchiveSearchResponse {
    ArchiveId?: string;
    Filters?: ArchiveFilters;
    FromTimestamp?: Date;
    ToTimestamp?: Date;
    MaxResults?: number;
    Status?: SearchStatus;
}
export interface GetArchiveSearchResultsRequest {
    SearchId: string;
}
export type EmailReceivedHeadersList = string[];
export interface Row {
    ArchivedMessageId?: string;
    ReceivedTimestamp?: Date;
    Date?: string;
    To?: string;
    From?: string;
    Cc?: string;
    Subject?: string;
    MessageId?: string;
    HasAttachments?: boolean;
    ReceivedHeaders?: string[];
    InReplyTo?: string;
    XMailer?: string;
    XOriginalMailer?: string;
    XPriority?: string;
    IngressPointId?: string;
    SenderHostname?: string;
    SenderIpAddress?: string | redacted.Redacted<string>;
    Envelope?: Envelope;
    SourceArn?: string;
}
export type RowsList = Row[];
export interface GetArchiveSearchResultsResponse {
    Rows?: Row[];
}
export type TrustStoreResponseOption = "EXCLUDE" | "INCLUDE" | (string & {});
export interface GetIngressPointRequest {
    IngressPointId: string;
    IncludeTrustStoreContents?: TrustStoreResponseOption;
}
export type IngressPointArn = string;
export type IngressPointStatus = "PROVISIONING" | "DEPROVISIONING" | "UPDATING" | "ACTIVE" | "CLOSED" | "FAILED" | "ASSOCIATED_VPC_ENDPOINT_DOES_NOT_EXIST" | (string & {});
export type IngressPointARecord = string;
export interface IngressPointPasswordConfiguration {
    SmtpPasswordVersion?: string;
    PreviousSmtpPasswordVersion?: string;
    PreviousSmtpPasswordExpiryTimestamp?: Date;
}
export interface IngressPointAuthConfiguration {
    IngressPointPasswordConfiguration?: IngressPointPasswordConfiguration;
    SecretArn?: string;
    TlsAuthConfiguration?: TlsAuthConfiguration;
}
export interface GetIngressPointResponse {
    IngressPointId: string;
    IngressPointName: string;
    IngressPointArn?: string;
    Status?: IngressPointStatus;
    Type?: IngressPointType;
    ARecord?: string;
    RuleSetId?: string;
    TrafficPolicyId?: string;
    IngressPointAuthConfiguration?: IngressPointAuthConfiguration;
    NetworkConfiguration?: NetworkConfiguration;
    TlsPolicy?: TlsPolicy;
    CreatedTimestamp?: Date;
    LastUpdatedTimestamp?: Date;
}
export interface GetMemberOfAddressListRequest {
    AddressListId: string;
    Address: string | redacted.Redacted<string>;
}
export interface GetMemberOfAddressListResponse {
    Address: string | redacted.Redacted<string>;
    CreatedTimestamp: Date;
}
export interface GetRelayRequest {
    RelayId: string;
}
export type RelayArn = string;
export interface GetRelayResponse {
    RelayId: string;
    RelayArn?: string;
    RelayName?: string;
    ServerName?: string;
    ServerPort?: number;
    Authentication?: RelayAuthentication;
    CreatedTimestamp?: Date;
    LastModifiedTimestamp?: Date;
}
export interface GetRuleSetRequest {
    RuleSetId: string;
}
export type RuleSetArn = string;
export interface GetRuleSetResponse {
    RuleSetId: string;
    RuleSetArn: string;
    RuleSetName: string;
    CreatedDate: Date;
    LastModificationDate: Date;
    Rules: Rule[];
}
export interface GetTrafficPolicyRequest {
    TrafficPolicyId: string;
}
export type TrafficPolicyArn = string;
export interface GetTrafficPolicyResponse {
    TrafficPolicyName: string;
    TrafficPolicyId: string;
    TrafficPolicyArn?: string;
    PolicyStatements?: PolicyStatement[];
    MaxMessageSizeBytes?: number;
    DefaultAction?: AcceptAction;
    CreatedTimestamp?: Date;
    LastUpdatedTimestamp?: Date;
}
export type PaginationToken = string;
export type PageSize = number;
export interface ListAddonInstancesRequest {
    NextToken?: string;
    PageSize?: number;
}
export interface AddonInstance {
    AddonInstanceId?: string;
    AddonSubscriptionId?: string;
    AddonName?: string;
    AddonInstanceArn?: string;
    CreatedTimestamp?: Date;
}
export type AddonInstances = AddonInstance[];
export interface ListAddonInstancesResponse {
    AddonInstances?: AddonInstance[];
    NextToken?: string;
}
export interface ListAddonSubscriptionsRequest {
    NextToken?: string;
    PageSize?: number;
}
export interface AddonSubscription {
    AddonSubscriptionId?: string;
    AddonName?: string;
    AddonSubscriptionArn?: string;
    CreatedTimestamp?: Date;
}
export type AddonSubscriptions = AddonSubscription[];
export interface ListAddonSubscriptionsResponse {
    AddonSubscriptions?: AddonSubscription[];
    NextToken?: string;
}
export interface ListAddressListImportJobsRequest {
    AddressListId: string;
    NextToken?: string;
    PageSize?: number;
}
export interface ImportJob {
    JobId: string;
    Name: string;
    Status: ImportJobStatus;
    PreSignedUrl: string | redacted.Redacted<string>;
    ImportedItemsCount?: number;
    FailedItemsCount?: number;
    ImportDataFormat: ImportDataFormat;
    AddressListId: string;
    CreatedTimestamp: Date;
    StartTimestamp?: Date;
    CompletedTimestamp?: Date;
    Error?: string;
}
export type ImportJobs = ImportJob[];
export interface ListAddressListImportJobsResponse {
    ImportJobs: ImportJob[];
    NextToken?: string;
}
export interface ListAddressListsRequest {
    NextToken?: string;
    PageSize?: number;
}
export interface AddressList {
    AddressListId: string;
    AddressListArn: string;
    AddressListName: string;
    CreatedTimestamp: Date;
    LastUpdatedTimestamp: Date;
}
export type AddressLists = AddressList[];
export interface ListAddressListsResponse {
    AddressLists: AddressList[];
    NextToken?: string;
}
export interface ListArchiveExportsRequest {
    ArchiveId: string;
    NextToken?: string;
    PageSize?: number;
}
export interface ExportSummary {
    ExportId?: string;
    Status?: ExportStatus;
}
export type ExportSummaryList = ExportSummary[];
export interface ListArchiveExportsResponse {
    Exports?: ExportSummary[];
    NextToken?: string;
}
export interface ListArchivesRequest {
    NextToken?: string;
    PageSize?: number;
}
export interface Archive {
    ArchiveId: string;
    ArchiveName?: string;
    ArchiveState?: ArchiveState;
    LastUpdatedTimestamp?: Date;
}
export type ArchivesList = Archive[];
export interface ListArchivesResponse {
    Archives: Archive[];
    NextToken?: string;
}
export interface ListArchiveSearchesRequest {
    ArchiveId: string;
    NextToken?: string;
    PageSize?: number;
}
export interface SearchSummary {
    SearchId?: string;
    Status?: SearchStatus;
}
export type SearchSummaryList = SearchSummary[];
export interface ListArchiveSearchesResponse {
    Searches?: SearchSummary[];
    NextToken?: string;
}
export interface ListIngressPointsRequest {
    PageSize?: number;
    NextToken?: string;
}
export interface IngressPoint {
    IngressPointName: string;
    IngressPointId: string;
    Status: IngressPointStatus;
    Type: IngressPointType;
    ARecord?: string;
}
export type IngressPointsList = IngressPoint[];
export interface ListIngressPointsResponse {
    IngressPoints?: IngressPoint[];
    NextToken?: string;
}
export type AddressPrefix = string | redacted.Redacted<string>;
export interface AddressFilter {
    AddressPrefix?: string | redacted.Redacted<string>;
}
export type AddressPageSize = number;
export interface ListMembersOfAddressListRequest {
    AddressListId: string;
    Filter?: AddressFilter;
    NextToken?: string;
    PageSize?: number;
}
export interface SavedAddress {
    Address: string | redacted.Redacted<string>;
    CreatedTimestamp: Date;
}
export type SavedAddresses = SavedAddress[];
export interface ListMembersOfAddressListResponse {
    Addresses: SavedAddress[];
    NextToken?: string;
}
export interface ListRelaysRequest {
    PageSize?: number;
    NextToken?: string;
}
export interface Relay {
    RelayId?: string;
    RelayName?: string;
    LastModifiedTimestamp?: Date;
}
export type Relays = Relay[];
export interface ListRelaysResponse {
    Relays: Relay[];
    NextToken?: string;
}
export interface ListRuleSetsRequest {
    NextToken?: string;
    PageSize?: number;
}
export interface RuleSet {
    RuleSetId?: string;
    RuleSetName?: string;
    LastModificationDate?: Date;
}
export type RuleSets = RuleSet[];
export interface ListRuleSetsResponse {
    RuleSets: RuleSet[];
    NextToken?: string;
}
export type TaggableResourceArn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags: Tag[];
}
export interface ListTrafficPoliciesRequest {
    PageSize?: number;
    NextToken?: string;
}
export interface TrafficPolicy {
    TrafficPolicyName: string;
    TrafficPolicyId: string;
    DefaultAction: AcceptAction;
}
export type TrafficPolicyList = TrafficPolicy[];
export interface ListTrafficPoliciesResponse {
    TrafficPolicies?: TrafficPolicy[];
    NextToken?: string;
}
export interface RegisterMemberToAddressListRequest {
    AddressListId: string;
    Address: string | redacted.Redacted<string>;
}
export interface RegisterMemberToAddressListResponse {
}
export interface StartAddressListImportJobRequest {
    JobId: string;
}
export interface StartAddressListImportJobResponse {
}
export interface StartArchiveExportRequest {
    ArchiveId: string;
    Filters?: ArchiveFilters;
    FromTimestamp: Date;
    ToTimestamp: Date;
    MaxResults?: number;
    ExportDestinationConfiguration: ExportDestinationConfiguration;
    IncludeMetadata?: boolean;
}
export interface StartArchiveExportResponse {
    ExportId?: string;
}
export interface StartArchiveSearchRequest {
    ArchiveId: string;
    Filters?: ArchiveFilters;
    FromTimestamp: Date;
    ToTimestamp: Date;
    MaxResults: number;
}
export interface StartArchiveSearchResponse {
    SearchId?: string;
}
export interface StopAddressListImportJobRequest {
    JobId: string;
}
export interface StopAddressListImportJobResponse {
}
export interface StopArchiveExportRequest {
    ExportId: string;
}
export interface StopArchiveExportResponse {
}
export interface StopArchiveSearchRequest {
    SearchId: string;
}
export interface StopArchiveSearchResponse {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateArchiveRequest {
    ArchiveId: string;
    ArchiveName?: string;
    Retention?: ArchiveRetention;
}
export interface UpdateArchiveResponse {
}
export type IngressPointStatusToUpdate = "ACTIVE" | "CLOSED" | (string & {});
export interface UpdateIngressPointRequest {
    IngressPointId: string;
    IngressPointName?: string;
    StatusToUpdate?: IngressPointStatusToUpdate;
    RuleSetId?: string;
    TrafficPolicyId?: string;
    IngressPointConfiguration?: IngressPointConfiguration;
    TlsPolicy?: TlsPolicy;
}
export interface UpdateIngressPointResponse {
}
export interface UpdateRelayRequest {
    RelayId: string;
    RelayName?: string;
    ServerName?: string;
    ServerPort?: number;
    Authentication?: RelayAuthentication;
}
export interface UpdateRelayResponse {
}
export interface UpdateRuleSetRequest {
    RuleSetId: string;
    RuleSetName?: string;
    Rules?: Rule[];
}
export interface UpdateRuleSetResponse {
}
export interface UpdateTrafficPolicyRequest {
    TrafficPolicyId: string;
    TrafficPolicyName?: string;
    PolicyStatements?: PolicyStatement[];
    DefaultAction?: AcceptAction;
    MaxMessageSizeBytes?: number;
}
export interface UpdateTrafficPolicyResponse {
}
export type CreateAddonInstanceError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates an Add On instance for the subscription indicated in the request. The resulting Amazon Resource Name (ARN) can be used in a conditional statement for a rule set or traffic policy.
 */
export declare const createAddonInstance: API.OperationMethod<CreateAddonInstanceRequest, CreateAddonInstanceResponse, CreateAddonInstanceError, Credentials | HttpClient.HttpClient>;
export type CreateAddonSubscriptionError = ConflictException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a subscription for an Add On representing the acceptance of its terms of use and additional pricing. The subscription can then be used to create an instance for use in rule sets or traffic policies.
 */
export declare const createAddonSubscription: API.OperationMethod<CreateAddonSubscriptionRequest, CreateAddonSubscriptionResponse, CreateAddonSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateAddressListError = AccessDeniedException | ConflictException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new address list.
 */
export declare const createAddressList: API.OperationMethod<CreateAddressListRequest, CreateAddressListResponse, CreateAddressListError, Credentials | HttpClient.HttpClient>;
export type CreateAddressListImportJobError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an import job for an address list.
 */
export declare const createAddressListImportJob: API.OperationMethod<CreateAddressListImportJobRequest, CreateAddressListImportJobResponse, CreateAddressListImportJobError, Credentials | HttpClient.HttpClient>;
export type CreateArchiveError = AccessDeniedException | ConflictException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new email archive resource for storing and retaining emails.
 */
export declare const createArchive: API.OperationMethod<CreateArchiveRequest, CreateArchiveResponse, CreateArchiveError, Credentials | HttpClient.HttpClient>;
export type CreateIngressPointError = ConflictException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Provision a new ingress endpoint resource.
 */
export declare const createIngressPoint: API.OperationMethod<CreateIngressPointRequest, CreateIngressPointResponse, CreateIngressPointError, Credentials | HttpClient.HttpClient>;
export type CreateRelayError = ConflictException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a relay resource which can be used in rules to relay incoming emails to defined relay destinations.
 */
export declare const createRelay: API.OperationMethod<CreateRelayRequest, CreateRelayResponse, CreateRelayError, Credentials | HttpClient.HttpClient>;
export type CreateRuleSetError = ConflictException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Provision a new rule set.
 */
export declare const createRuleSet: API.OperationMethod<CreateRuleSetRequest, CreateRuleSetResponse, CreateRuleSetError, Credentials | HttpClient.HttpClient>;
export type CreateTrafficPolicyError = ConflictException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Provision a new traffic policy resource.
 */
export declare const createTrafficPolicy: API.OperationMethod<CreateTrafficPolicyRequest, CreateTrafficPolicyResponse, CreateTrafficPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteAddonInstanceError = ConflictException | ValidationException | CommonErrors;
/**
 * Deletes an Add On instance.
 */
export declare const deleteAddonInstance: API.OperationMethod<DeleteAddonInstanceRequest, DeleteAddonInstanceResponse, DeleteAddonInstanceError, Credentials | HttpClient.HttpClient>;
export type DeleteAddonSubscriptionError = ConflictException | ValidationException | CommonErrors;
/**
 * Deletes an Add On subscription.
 */
export declare const deleteAddonSubscription: API.OperationMethod<DeleteAddonSubscriptionRequest, DeleteAddonSubscriptionResponse, DeleteAddonSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteAddressListError = AccessDeniedException | ConflictException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an address list.
 */
export declare const deleteAddressList: API.OperationMethod<DeleteAddressListRequest, DeleteAddressListResponse, DeleteAddressListError, Credentials | HttpClient.HttpClient>;
export type DeleteArchiveError = AccessDeniedException | ConflictException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initiates deletion of an email archive. This changes the archive state to pending deletion. In this state, no new emails can be added, and existing archived emails become inaccessible (search, export, download). The archive and all of its contents will be permanently deleted 30 days after entering the pending deletion state, regardless of the configured retention period.
 */
export declare const deleteArchive: API.OperationMethod<DeleteArchiveRequest, DeleteArchiveResponse, DeleteArchiveError, Credentials | HttpClient.HttpClient>;
export type DeleteIngressPointError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Delete an ingress endpoint resource.
 */
export declare const deleteIngressPoint: API.OperationMethod<DeleteIngressPointRequest, DeleteIngressPointResponse, DeleteIngressPointError, Credentials | HttpClient.HttpClient>;
export type DeleteRelayError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an existing relay resource.
 */
export declare const deleteRelay: API.OperationMethod<DeleteRelayRequest, DeleteRelayResponse, DeleteRelayError, Credentials | HttpClient.HttpClient>;
export type DeleteRuleSetError = ConflictException | ValidationException | CommonErrors;
/**
 * Delete a rule set.
 */
export declare const deleteRuleSet: API.OperationMethod<DeleteRuleSetRequest, DeleteRuleSetResponse, DeleteRuleSetError, Credentials | HttpClient.HttpClient>;
export type DeleteTrafficPolicyError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Delete a traffic policy resource.
 */
export declare const deleteTrafficPolicy: API.OperationMethod<DeleteTrafficPolicyRequest, DeleteTrafficPolicyResponse, DeleteTrafficPolicyError, Credentials | HttpClient.HttpClient>;
export type DeregisterMemberFromAddressListError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a member from an address list.
 */
export declare const deregisterMemberFromAddressList: API.OperationMethod<DeregisterMemberFromAddressListRequest, DeregisterMemberFromAddressListResponse, DeregisterMemberFromAddressListError, Credentials | HttpClient.HttpClient>;
export type GetAddonInstanceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets detailed information about an Add On instance.
 */
export declare const getAddonInstance: API.OperationMethod<GetAddonInstanceRequest, GetAddonInstanceResponse, GetAddonInstanceError, Credentials | HttpClient.HttpClient>;
export type GetAddonSubscriptionError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets detailed information about an Add On subscription.
 */
export declare const getAddonSubscription: API.OperationMethod<GetAddonSubscriptionRequest, GetAddonSubscriptionResponse, GetAddonSubscriptionError, Credentials | HttpClient.HttpClient>;
export type GetAddressListError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Fetch attributes of an address list.
 */
export declare const getAddressList: API.OperationMethod<GetAddressListRequest, GetAddressListResponse, GetAddressListError, Credentials | HttpClient.HttpClient>;
export type GetAddressListImportJobError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Fetch attributes of an import job.
 */
export declare const getAddressListImportJob: API.OperationMethod<GetAddressListImportJobRequest, GetAddressListImportJobResponse, GetAddressListImportJobError, Credentials | HttpClient.HttpClient>;
export type GetArchiveError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the full details and current state of a specified email archive.
 */
export declare const getArchive: API.OperationMethod<GetArchiveRequest, GetArchiveResponse, GetArchiveError, Credentials | HttpClient.HttpClient>;
export type GetArchiveExportError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details and current status of a specific email archive export job.
 */
export declare const getArchiveExport: API.OperationMethod<GetArchiveExportRequest, GetArchiveExportResponse, GetArchiveExportError, Credentials | HttpClient.HttpClient>;
export type GetArchiveMessageError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a pre-signed URL that provides temporary download access to the specific email message stored in the archive.
 */
export declare const getArchiveMessage: API.OperationMethod<GetArchiveMessageRequest, GetArchiveMessageResponse, GetArchiveMessageError, Credentials | HttpClient.HttpClient>;
export type GetArchiveMessageContentError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the textual content of a specific email message stored in the archive. Attachments are not included.
 */
export declare const getArchiveMessageContent: API.OperationMethod<GetArchiveMessageContentRequest, GetArchiveMessageContentResponse, GetArchiveMessageContentError, Credentials | HttpClient.HttpClient>;
export type GetArchiveSearchError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details and current status of a specific email archive search job.
 */
export declare const getArchiveSearch: API.OperationMethod<GetArchiveSearchRequest, GetArchiveSearchResponse, GetArchiveSearchError, Credentials | HttpClient.HttpClient>;
export type GetArchiveSearchResultsError = AccessDeniedException | ConflictException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the results of a completed email archive search job.
 */
export declare const getArchiveSearchResults: API.OperationMethod<GetArchiveSearchResultsRequest, GetArchiveSearchResultsResponse, GetArchiveSearchResultsError, Credentials | HttpClient.HttpClient>;
export type GetIngressPointError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Fetch ingress endpoint resource attributes.
 */
export declare const getIngressPoint: API.OperationMethod<GetIngressPointRequest, GetIngressPointResponse, GetIngressPointError, Credentials | HttpClient.HttpClient>;
export type GetMemberOfAddressListError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Fetch attributes of a member in an address list.
 */
export declare const getMemberOfAddressList: API.OperationMethod<GetMemberOfAddressListRequest, GetMemberOfAddressListResponse, GetMemberOfAddressListError, Credentials | HttpClient.HttpClient>;
export type GetRelayError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Fetch the relay resource and it's attributes.
 */
export declare const getRelay: API.OperationMethod<GetRelayRequest, GetRelayResponse, GetRelayError, Credentials | HttpClient.HttpClient>;
export type GetRuleSetError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Fetch attributes of a rule set.
 */
export declare const getRuleSet: API.OperationMethod<GetRuleSetRequest, GetRuleSetResponse, GetRuleSetError, Credentials | HttpClient.HttpClient>;
export type GetTrafficPolicyError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Fetch attributes of a traffic policy resource.
 */
export declare const getTrafficPolicy: API.OperationMethod<GetTrafficPolicyRequest, GetTrafficPolicyResponse, GetTrafficPolicyError, Credentials | HttpClient.HttpClient>;
export type ListAddonInstancesError = ValidationException | CommonErrors;
/**
 * Lists all Add On instances in your account.
 */
export declare const listAddonInstances: API.PaginatedOperationMethod<ListAddonInstancesRequest, ListAddonInstancesResponse, ListAddonInstancesError, Credentials | HttpClient.HttpClient, AddonInstance>;
export type ListAddonSubscriptionsError = ValidationException | CommonErrors;
/**
 * Lists all Add On subscriptions in your account.
 */
export declare const listAddonSubscriptions: API.PaginatedOperationMethod<ListAddonSubscriptionsRequest, ListAddonSubscriptionsResponse, ListAddonSubscriptionsError, Credentials | HttpClient.HttpClient, AddonSubscription>;
export type ListAddressListImportJobsError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists jobs for an address list.
 */
export declare const listAddressListImportJobs: API.PaginatedOperationMethod<ListAddressListImportJobsRequest, ListAddressListImportJobsResponse, ListAddressListImportJobsError, Credentials | HttpClient.HttpClient, ImportJob>;
export type ListAddressListsError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists address lists for this account.
 */
export declare const listAddressLists: API.PaginatedOperationMethod<ListAddressListsRequest, ListAddressListsResponse, ListAddressListsError, Credentials | HttpClient.HttpClient, AddressList>;
export type ListArchiveExportsError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of email archive export jobs.
 */
export declare const listArchiveExports: API.PaginatedOperationMethod<ListArchiveExportsRequest, ListArchiveExportsResponse, ListArchiveExportsError, Credentials | HttpClient.HttpClient, ExportSummary>;
export type ListArchivesError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all email archives in your account.
 */
export declare const listArchives: API.PaginatedOperationMethod<ListArchivesRequest, ListArchivesResponse, ListArchivesError, Credentials | HttpClient.HttpClient, Archive>;
export type ListArchiveSearchesError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of email archive search jobs.
 */
export declare const listArchiveSearches: API.PaginatedOperationMethod<ListArchiveSearchesRequest, ListArchiveSearchesResponse, ListArchiveSearchesError, Credentials | HttpClient.HttpClient, SearchSummary>;
export type ListIngressPointsError = ValidationException | CommonErrors;
/**
 * List all ingress endpoint resources.
 */
export declare const listIngressPoints: API.PaginatedOperationMethod<ListIngressPointsRequest, ListIngressPointsResponse, ListIngressPointsError, Credentials | HttpClient.HttpClient, IngressPoint>;
export type ListMembersOfAddressListError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists members of an address list.
 */
export declare const listMembersOfAddressList: API.PaginatedOperationMethod<ListMembersOfAddressListRequest, ListMembersOfAddressListResponse, ListMembersOfAddressListError, Credentials | HttpClient.HttpClient, SavedAddress>;
export type ListRelaysError = ValidationException | CommonErrors;
/**
 * Lists all the existing relay resources.
 */
export declare const listRelays: API.PaginatedOperationMethod<ListRelaysRequest, ListRelaysResponse, ListRelaysError, Credentials | HttpClient.HttpClient, Relay>;
export type ListRuleSetsError = ValidationException | CommonErrors;
/**
 * List rule sets for this account.
 */
export declare const listRuleSets: API.PaginatedOperationMethod<ListRuleSetsRequest, ListRuleSetsResponse, ListRuleSetsError, Credentials | HttpClient.HttpClient, RuleSet>;
export type ListTagsForResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the list of tags (keys and values) assigned to the resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTrafficPoliciesError = ValidationException | CommonErrors;
/**
 * List traffic policy resources.
 */
export declare const listTrafficPolicies: API.PaginatedOperationMethod<ListTrafficPoliciesRequest, ListTrafficPoliciesResponse, ListTrafficPoliciesError, Credentials | HttpClient.HttpClient, TrafficPolicy>;
export type RegisterMemberToAddressListError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a member to an address list.
 */
export declare const registerMemberToAddressList: API.OperationMethod<RegisterMemberToAddressListRequest, RegisterMemberToAddressListResponse, RegisterMemberToAddressListError, Credentials | HttpClient.HttpClient>;
export type StartAddressListImportJobError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts an import job for an address list.
 */
export declare const startAddressListImportJob: API.OperationMethod<StartAddressListImportJobRequest, StartAddressListImportJobResponse, StartAddressListImportJobError, Credentials | HttpClient.HttpClient>;
export type StartArchiveExportError = AccessDeniedException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initiates an export of emails from the specified archive.
 */
export declare const startArchiveExport: API.OperationMethod<StartArchiveExportRequest, StartArchiveExportResponse, StartArchiveExportError, Credentials | HttpClient.HttpClient>;
export type StartArchiveSearchError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initiates a search across emails in the specified archive.
 */
export declare const startArchiveSearch: API.OperationMethod<StartArchiveSearchRequest, StartArchiveSearchResponse, StartArchiveSearchError, Credentials | HttpClient.HttpClient>;
export type StopAddressListImportJobError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops an ongoing import job for an address list.
 */
export declare const stopAddressListImportJob: API.OperationMethod<StopAddressListImportJobRequest, StopAddressListImportJobResponse, StopAddressListImportJobError, Credentials | HttpClient.HttpClient>;
export type StopArchiveExportError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops an in-progress export of emails from an archive.
 */
export declare const stopArchiveExport: API.OperationMethod<StopArchiveExportRequest, StopArchiveExportResponse, StopArchiveExportError, Credentials | HttpClient.HttpClient>;
export type StopArchiveSearchError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops an in-progress archive search job.
 */
export declare const stopArchiveSearch: API.OperationMethod<StopArchiveSearchRequest, StopArchiveSearchResponse, StopArchiveSearchError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Adds one or more tags (keys and values) to a specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Remove one or more tags (keys and values) from a specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateArchiveError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the attributes of an existing email archive.
 */
export declare const updateArchive: API.OperationMethod<UpdateArchiveRequest, UpdateArchiveResponse, UpdateArchiveError, Credentials | HttpClient.HttpClient>;
export type UpdateIngressPointError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Update attributes of a provisioned ingress endpoint resource.
 */
export declare const updateIngressPoint: API.OperationMethod<UpdateIngressPointRequest, UpdateIngressPointResponse, UpdateIngressPointError, Credentials | HttpClient.HttpClient>;
export type UpdateRelayError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the attributes of an existing relay resource.
 */
export declare const updateRelay: API.OperationMethod<UpdateRelayRequest, UpdateRelayResponse, UpdateRelayError, Credentials | HttpClient.HttpClient>;
export type UpdateRuleSetError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Update attributes of an already provisioned rule set.
 */
export declare const updateRuleSet: API.OperationMethod<UpdateRuleSetRequest, UpdateRuleSetResponse, UpdateRuleSetError, Credentials | HttpClient.HttpClient>;
export type UpdateTrafficPolicyError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Update attributes of an already provisioned traffic policy resource.
 */
export declare const updateTrafficPolicy: API.OperationMethod<UpdateTrafficPolicyRequest, UpdateTrafficPolicyResponse, UpdateTrafficPolicyError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=mailmanager.d.ts.map