import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ResourceLimitExceededException_base: S.TaggedErrorClass<"ResourceLimitExceededException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceLimitExceededException extends /*@__PURE__*/ ResourceLimitExceededException_base {
}
declare const ServiceFailureException_base: S.TaggedErrorClass<"ServiceFailureException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceFailureException extends /*@__PURE__*/ ServiceFailureException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottledClientException_base: S.TaggedErrorClass<"ThrottledClientException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottledClientException extends /*@__PURE__*/ ThrottledClientException_base {
}
declare const UnauthorizedClientException_base: S.TaggedErrorClass<"UnauthorizedClientException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedClientException extends /*@__PURE__*/ UnauthorizedClientException_base {
}
declare const UnprocessableEntityException_base: S.TaggedErrorClass<"UnprocessableEntityException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableEntityException extends /*@__PURE__*/ UnprocessableEntityException_base {
}
export type E164PhoneNumber = string | redacted.Redacted<string>;
export interface AssociatePhoneNumberWithUserRequest {
    AccountId: string;
    UserId: string;
    E164PhoneNumber: string | redacted.Redacted<string>;
}
export interface AssociatePhoneNumberWithUserResponse {
}
export type NonEmptyString = string;
export interface SigninDelegateGroup {
    GroupName?: string;
}
export type SigninDelegateGroupList = SigninDelegateGroup[];
export interface AssociateSigninDelegateGroupsWithAccountRequest {
    AccountId: string;
    SigninDelegateGroups: SigninDelegateGroup[];
}
export interface AssociateSigninDelegateGroupsWithAccountResponse {
}
export type RoomMembershipRole = "Administrator" | "Member" | (string & {});
export interface MembershipItem {
    MemberId?: string;
    Role?: RoomMembershipRole;
}
export type MembershipItemList = MembershipItem[];
export interface BatchCreateRoomMembershipRequest {
    AccountId: string;
    RoomId: string;
    MembershipItemList: MembershipItem[];
}
export type ErrorCode = "BadRequest" | "Conflict" | "Forbidden" | "NotFound" | "PreconditionFailed" | "ResourceLimitExceeded" | "ServiceFailure" | "AccessDenied" | "ServiceUnavailable" | "Throttled" | "Throttling" | "Unauthorized" | "Unprocessable" | "VoiceConnectorGroupAssociationsExist" | "PhoneNumberAssociationsExist" | (string & {});
export interface MemberError {
    MemberId?: string;
    ErrorCode?: ErrorCode;
    ErrorMessage?: string;
}
export type MemberErrorList = MemberError[];
export interface BatchCreateRoomMembershipResponse {
    Errors?: MemberError[];
}
export type NonEmptyStringList = string[];
export interface BatchDeletePhoneNumberRequest {
    PhoneNumberIds: string[];
}
export interface PhoneNumberError {
    PhoneNumberId?: string;
    ErrorCode?: ErrorCode;
    ErrorMessage?: string;
}
export type PhoneNumberErrorList = PhoneNumberError[];
export interface BatchDeletePhoneNumberResponse {
    PhoneNumberErrors?: PhoneNumberError[];
}
export type UserIdList = string[];
export interface BatchSuspendUserRequest {
    AccountId: string;
    UserIdList: string[];
}
export interface UserError {
    UserId?: string;
    ErrorCode?: ErrorCode;
    ErrorMessage?: string;
}
export type UserErrorList = UserError[];
export interface BatchSuspendUserResponse {
    UserErrors?: UserError[];
}
export interface BatchUnsuspendUserRequest {
    AccountId: string;
    UserIdList: string[];
}
export interface BatchUnsuspendUserResponse {
    UserErrors?: UserError[];
}
export type PhoneNumberProductType = "BusinessCalling" | "VoiceConnector" | "SipMediaApplicationDialIn" | (string & {});
export type CallingName = string | redacted.Redacted<string>;
export interface UpdatePhoneNumberRequestItem {
    PhoneNumberId: string;
    ProductType?: PhoneNumberProductType;
    CallingName?: string | redacted.Redacted<string>;
}
export type UpdatePhoneNumberRequestItemList = UpdatePhoneNumberRequestItem[];
export interface BatchUpdatePhoneNumberRequest {
    UpdatePhoneNumberRequestItems: UpdatePhoneNumberRequestItem[];
}
export interface BatchUpdatePhoneNumberResponse {
    PhoneNumberErrors?: PhoneNumberError[];
}
export type License = "Basic" | "Plus" | "Pro" | "ProTrial" | (string & {});
export type UserType = "PrivateUser" | "SharedDevice" | (string & {});
export type SensitiveString = string | redacted.Redacted<string>;
export interface AlexaForBusinessMetadata {
    IsAlexaForBusinessEnabled?: boolean;
    AlexaForBusinessRoomArn?: string | redacted.Redacted<string>;
}
export interface UpdateUserRequestItem {
    UserId: string;
    LicenseType?: License;
    UserType?: UserType;
    AlexaForBusinessMetadata?: AlexaForBusinessMetadata;
}
export type UpdateUserRequestItemList = UpdateUserRequestItem[];
export interface BatchUpdateUserRequest {
    AccountId: string;
    UpdateUserRequestItems: UpdateUserRequestItem[];
}
export interface BatchUpdateUserResponse {
    UserErrors?: UserError[];
}
export type AccountName = string;
export interface CreateAccountRequest {
    Name: string;
}
export type AccountType = "Team" | "EnterpriseDirectory" | "EnterpriseLWA" | "EnterpriseOIDC" | (string & {});
export type Iso8601Timestamp = Date;
export type LicenseList = License[];
export type AccountStatus = "Suspended" | "Active" | (string & {});
export interface Account {
    AwsAccountId: string;
    AccountId: string;
    Name: string;
    AccountType?: AccountType;
    CreatedTimestamp?: Date;
    DefaultLicense?: License;
    SupportedLicenses?: License[];
    AccountStatus?: AccountStatus;
    SigninDelegateGroups?: SigninDelegateGroup[];
}
export interface CreateAccountResponse {
    Account?: Account;
}
export interface CreateBotRequest {
    AccountId: string;
    DisplayName: string | redacted.Redacted<string>;
    Domain?: string;
}
export type BotType = "ChatBot" | (string & {});
export interface Bot {
    BotId?: string;
    UserId?: string;
    DisplayName?: string | redacted.Redacted<string>;
    BotType?: BotType;
    Disabled?: boolean;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    BotEmail?: string | redacted.Redacted<string>;
    SecurityToken?: string | redacted.Redacted<string>;
}
export interface CreateBotResponse {
    Bot?: Bot;
}
export type GuidString = string;
export type JoinTokenString = string | redacted.Redacted<string>;
export interface CreateMeetingDialOutRequest {
    MeetingId: string;
    FromPhoneNumber: string | redacted.Redacted<string>;
    ToPhoneNumber: string | redacted.Redacted<string>;
    JoinToken: string | redacted.Redacted<string>;
}
export interface CreateMeetingDialOutResponse {
    TransactionId?: string;
}
export type E164PhoneNumberList = (string | redacted.Redacted<string>)[];
export interface CreatePhoneNumberOrderRequest {
    ProductType: PhoneNumberProductType;
    E164PhoneNumbers: (string | redacted.Redacted<string>)[];
}
export type PhoneNumberOrderStatus = "Processing" | "Successful" | "Failed" | "Partial" | (string & {});
export type OrderedPhoneNumberStatus = "Processing" | "Acquired" | "Failed" | (string & {});
export interface OrderedPhoneNumber {
    E164PhoneNumber?: string | redacted.Redacted<string>;
    Status?: OrderedPhoneNumberStatus;
}
export type OrderedPhoneNumberList = OrderedPhoneNumber[];
export interface PhoneNumberOrder {
    PhoneNumberOrderId?: string;
    ProductType?: PhoneNumberProductType;
    Status?: PhoneNumberOrderStatus;
    OrderedPhoneNumbers?: OrderedPhoneNumber[];
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
}
export interface CreatePhoneNumberOrderResponse {
    PhoneNumberOrder?: PhoneNumberOrder;
}
export type ClientRequestToken = string | redacted.Redacted<string>;
export interface CreateRoomRequest {
    AccountId: string;
    Name: string | redacted.Redacted<string>;
    ClientRequestToken?: string | redacted.Redacted<string>;
}
export interface Room {
    RoomId?: string;
    Name?: string | redacted.Redacted<string>;
    AccountId?: string;
    CreatedBy?: string;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
}
export interface CreateRoomResponse {
    Room?: Room;
}
export interface CreateRoomMembershipRequest {
    AccountId: string;
    RoomId: string;
    MemberId: string;
    Role?: RoomMembershipRole;
}
export type MemberType = "User" | "Bot" | "Webhook" | (string & {});
export interface Member {
    MemberId?: string;
    MemberType?: MemberType;
    Email?: string | redacted.Redacted<string>;
    FullName?: string | redacted.Redacted<string>;
    AccountId?: string;
}
export interface RoomMembership {
    RoomId?: string;
    Member?: Member;
    Role?: RoomMembershipRole;
    InvitedBy?: string;
    UpdatedTimestamp?: Date;
}
export interface CreateRoomMembershipResponse {
    RoomMembership?: RoomMembership;
}
export type EmailAddress = string | redacted.Redacted<string>;
export interface CreateUserRequest {
    AccountId: string;
    Username?: string;
    Email?: string | redacted.Redacted<string>;
    UserType?: UserType;
}
export type RegistrationStatus = "Unregistered" | "Registered" | "Suspended" | (string & {});
export type InviteStatus = "Pending" | "Accepted" | "Failed" | (string & {});
export interface User {
    UserId: string;
    AccountId?: string;
    PrimaryEmail?: string | redacted.Redacted<string>;
    PrimaryProvisionedNumber?: string | redacted.Redacted<string>;
    DisplayName?: string | redacted.Redacted<string>;
    LicenseType?: License;
    UserType?: UserType;
    UserRegistrationStatus?: RegistrationStatus;
    UserInvitationStatus?: InviteStatus;
    RegisteredOn?: Date;
    InvitedOn?: Date;
    AlexaForBusinessMetadata?: AlexaForBusinessMetadata;
    PersonalPIN?: string;
}
export interface CreateUserResponse {
    User?: User;
}
export interface DeleteAccountRequest {
    AccountId: string;
}
export interface DeleteAccountResponse {
}
export interface DeleteEventsConfigurationRequest {
    AccountId: string;
    BotId: string;
}
export interface DeleteEventsConfigurationResponse {
}
export interface DeletePhoneNumberRequest {
    PhoneNumberId: string;
}
export interface DeletePhoneNumberResponse {
}
export interface DeleteRoomRequest {
    AccountId: string;
    RoomId: string;
}
export interface DeleteRoomResponse {
}
export interface DeleteRoomMembershipRequest {
    AccountId: string;
    RoomId: string;
    MemberId: string;
}
export interface DeleteRoomMembershipResponse {
}
export interface DisassociatePhoneNumberFromUserRequest {
    AccountId: string;
    UserId: string;
}
export interface DisassociatePhoneNumberFromUserResponse {
}
export interface DisassociateSigninDelegateGroupsFromAccountRequest {
    AccountId: string;
    GroupNames: string[];
}
export interface DisassociateSigninDelegateGroupsFromAccountResponse {
}
export interface GetAccountRequest {
    AccountId: string;
}
export interface GetAccountResponse {
    Account?: Account;
}
export interface GetAccountSettingsRequest {
    AccountId: string;
}
export interface AccountSettings {
    DisableRemoteControl?: boolean;
    EnableDialOut?: boolean;
}
export interface GetAccountSettingsResponse {
    AccountSettings?: AccountSettings;
}
export interface GetBotRequest {
    AccountId: string;
    BotId: string;
}
export interface GetBotResponse {
    Bot?: Bot;
}
export interface GetEventsConfigurationRequest {
    AccountId: string;
    BotId: string;
}
export interface EventsConfiguration {
    BotId?: string;
    OutboundEventsHTTPSEndpoint?: string | redacted.Redacted<string>;
    LambdaFunctionArn?: string | redacted.Redacted<string>;
}
export interface GetEventsConfigurationResponse {
    EventsConfiguration?: EventsConfiguration;
}
export interface GetGlobalSettingsRequest {
}
export interface BusinessCallingSettings {
    CdrBucket?: string;
}
export interface VoiceConnectorSettings {
    CdrBucket?: string;
}
export interface GetGlobalSettingsResponse {
    BusinessCalling?: BusinessCallingSettings;
    VoiceConnector?: VoiceConnectorSettings;
}
export interface GetPhoneNumberRequest {
    PhoneNumberId: string;
}
export type Alpha2CountryCode = string;
export type PhoneNumberType = "Local" | "TollFree" | (string & {});
export type PhoneNumberStatus = "AcquireInProgress" | "AcquireFailed" | "Unassigned" | "Assigned" | "ReleaseInProgress" | "DeleteInProgress" | "ReleaseFailed" | "DeleteFailed" | (string & {});
export interface PhoneNumberCapabilities {
    InboundCall?: boolean;
    OutboundCall?: boolean;
    InboundSMS?: boolean;
    OutboundSMS?: boolean;
    InboundMMS?: boolean;
    OutboundMMS?: boolean;
}
export type PhoneNumberAssociationName = "AccountId" | "UserId" | "VoiceConnectorId" | "VoiceConnectorGroupId" | "SipRuleId" | (string & {});
export interface PhoneNumberAssociation {
    Value?: string;
    Name?: PhoneNumberAssociationName;
    AssociatedTimestamp?: Date;
}
export type PhoneNumberAssociationList = PhoneNumberAssociation[];
export type CallingNameStatus = "Unassigned" | "UpdateInProgress" | "UpdateSucceeded" | "UpdateFailed" | (string & {});
export interface PhoneNumber {
    PhoneNumberId?: string;
    E164PhoneNumber?: string | redacted.Redacted<string>;
    Country?: string;
    Type?: PhoneNumberType;
    ProductType?: PhoneNumberProductType;
    Status?: PhoneNumberStatus;
    Capabilities?: PhoneNumberCapabilities;
    Associations?: PhoneNumberAssociation[];
    CallingName?: string | redacted.Redacted<string>;
    CallingNameStatus?: CallingNameStatus;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    DeletionTimestamp?: Date;
}
export interface GetPhoneNumberResponse {
    PhoneNumber?: PhoneNumber;
}
export interface GetPhoneNumberOrderRequest {
    PhoneNumberOrderId: string;
}
export interface GetPhoneNumberOrderResponse {
    PhoneNumberOrder?: PhoneNumberOrder;
}
export interface GetPhoneNumberSettingsRequest {
}
export interface GetPhoneNumberSettingsResponse {
    CallingName?: string | redacted.Redacted<string>;
    CallingNameUpdatedTimestamp?: Date;
}
export interface GetRetentionSettingsRequest {
    AccountId: string;
}
export type RetentionDays = number;
export interface RoomRetentionSettings {
    RetentionDays?: number;
}
export interface ConversationRetentionSettings {
    RetentionDays?: number;
}
export interface RetentionSettings {
    RoomRetentionSettings?: RoomRetentionSettings;
    ConversationRetentionSettings?: ConversationRetentionSettings;
}
export interface GetRetentionSettingsResponse {
    RetentionSettings?: RetentionSettings;
    InitiateDeletionTimestamp?: Date;
}
export interface GetRoomRequest {
    AccountId: string;
    RoomId: string;
}
export interface GetRoomResponse {
    Room?: Room;
}
export interface GetUserRequest {
    AccountId: string;
    UserId: string;
}
export interface GetUserResponse {
    User?: User;
}
export interface GetUserSettingsRequest {
    AccountId: string;
    UserId: string;
}
export interface TelephonySettings {
    InboundCalling: boolean;
    OutboundCalling: boolean;
    SMS: boolean;
}
export interface UserSettings {
    Telephony: TelephonySettings;
}
export interface GetUserSettingsResponse {
    UserSettings?: UserSettings;
}
export type UserEmailList = (string | redacted.Redacted<string>)[];
export interface InviteUsersRequest {
    AccountId: string;
    UserEmailList: (string | redacted.Redacted<string>)[];
    UserType?: UserType;
}
export type EmailStatus = "NotSent" | "Sent" | "Failed" | (string & {});
export interface Invite {
    InviteId?: string;
    Status?: InviteStatus;
    EmailAddress?: string | redacted.Redacted<string>;
    EmailStatus?: EmailStatus;
}
export type InviteList = Invite[];
export interface InviteUsersResponse {
    Invites?: Invite[];
}
export type ProfileServiceMaxResults = number;
export interface ListAccountsRequest {
    Name?: string;
    UserEmail?: string | redacted.Redacted<string>;
    NextToken?: string;
    MaxResults?: number;
}
export type AccountList = Account[];
export interface ListAccountsResponse {
    Accounts?: Account[];
    NextToken?: string;
}
export type ResultMax = number;
export interface ListBotsRequest {
    AccountId: string;
    MaxResults?: number;
    NextToken?: string;
}
export type BotList = Bot[];
export interface ListBotsResponse {
    Bots?: Bot[];
    NextToken?: string;
}
export interface ListPhoneNumberOrdersRequest {
    NextToken?: string;
    MaxResults?: number;
}
export type PhoneNumberOrderList = PhoneNumberOrder[];
export interface ListPhoneNumberOrdersResponse {
    PhoneNumberOrders?: PhoneNumberOrder[];
    NextToken?: string;
}
export interface ListPhoneNumbersRequest {
    Status?: PhoneNumberStatus;
    ProductType?: PhoneNumberProductType;
    FilterName?: PhoneNumberAssociationName;
    FilterValue?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type PhoneNumberList = PhoneNumber[];
export interface ListPhoneNumbersResponse {
    PhoneNumbers?: PhoneNumber[];
    NextToken?: string;
}
export interface ListRoomMembershipsRequest {
    AccountId: string;
    RoomId: string;
    MaxResults?: number;
    NextToken?: string;
}
export type RoomMembershipList = RoomMembership[];
export interface ListRoomMembershipsResponse {
    RoomMemberships?: RoomMembership[];
    NextToken?: string;
}
export interface ListRoomsRequest {
    AccountId: string;
    MemberId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type RoomList = Room[];
export interface ListRoomsResponse {
    Rooms?: Room[];
    NextToken?: string;
}
export interface ListSupportedPhoneNumberCountriesRequest {
    ProductType: PhoneNumberProductType;
}
export type PhoneNumberTypeList = PhoneNumberType[];
export interface PhoneNumberCountry {
    CountryCode?: string;
    SupportedPhoneNumberTypes?: PhoneNumberType[];
}
export type PhoneNumberCountriesList = PhoneNumberCountry[];
export interface ListSupportedPhoneNumberCountriesResponse {
    PhoneNumberCountries?: PhoneNumberCountry[];
}
export interface ListUsersRequest {
    AccountId: string;
    UserEmail?: string | redacted.Redacted<string>;
    UserType?: UserType;
    MaxResults?: number;
    NextToken?: string;
}
export type UserList = User[];
export interface ListUsersResponse {
    Users?: User[];
    NextToken?: string;
}
export interface LogoutUserRequest {
    AccountId: string;
    UserId: string;
}
export interface LogoutUserResponse {
}
export interface PutEventsConfigurationRequest {
    AccountId: string;
    BotId: string;
    OutboundEventsHTTPSEndpoint?: string | redacted.Redacted<string>;
    LambdaFunctionArn?: string | redacted.Redacted<string>;
}
export interface PutEventsConfigurationResponse {
    EventsConfiguration?: EventsConfiguration;
}
export interface PutRetentionSettingsRequest {
    AccountId: string;
    RetentionSettings: RetentionSettings;
}
export interface PutRetentionSettingsResponse {
    RetentionSettings?: RetentionSettings;
    InitiateDeletionTimestamp?: Date;
}
export interface RedactConversationMessageRequest {
    AccountId: string;
    ConversationId: string;
    MessageId: string;
}
export interface RedactConversationMessageResponse {
}
export interface RedactRoomMessageRequest {
    AccountId: string;
    RoomId: string;
    MessageId: string;
}
export interface RedactRoomMessageResponse {
}
export interface RegenerateSecurityTokenRequest {
    AccountId: string;
    BotId: string;
}
export interface RegenerateSecurityTokenResponse {
    Bot?: Bot;
}
export interface ResetPersonalPINRequest {
    AccountId: string;
    UserId: string;
}
export interface ResetPersonalPINResponse {
    User?: User;
}
export interface RestorePhoneNumberRequest {
    PhoneNumberId: string;
}
export interface RestorePhoneNumberResponse {
    PhoneNumber?: PhoneNumber;
}
export type TollFreePrefix = string;
export type PhoneNumberMaxResults = number;
export interface SearchAvailablePhoneNumbersRequest {
    AreaCode?: string;
    City?: string;
    Country?: string;
    State?: string;
    TollFreePrefix?: string;
    PhoneNumberType?: PhoneNumberType;
    MaxResults?: number;
    NextToken?: string;
}
export interface SearchAvailablePhoneNumbersResponse {
    E164PhoneNumbers?: (string | redacted.Redacted<string>)[];
    NextToken?: string;
}
export interface UpdateAccountRequest {
    AccountId: string;
    Name?: string;
    DefaultLicense?: License;
}
export interface UpdateAccountResponse {
    Account?: Account;
}
export interface UpdateAccountSettingsRequest {
    AccountId: string;
    AccountSettings: AccountSettings;
}
export interface UpdateAccountSettingsResponse {
}
export interface UpdateBotRequest {
    AccountId: string;
    BotId: string;
    Disabled?: boolean;
}
export interface UpdateBotResponse {
    Bot?: Bot;
}
export interface UpdateGlobalSettingsRequest {
    BusinessCalling?: BusinessCallingSettings;
    VoiceConnector?: VoiceConnectorSettings;
}
export interface UpdateGlobalSettingsResponse {
}
export interface UpdatePhoneNumberRequest {
    PhoneNumberId: string;
    ProductType?: PhoneNumberProductType;
    CallingName?: string | redacted.Redacted<string>;
}
export interface UpdatePhoneNumberResponse {
    PhoneNumber?: PhoneNumber;
}
export interface UpdatePhoneNumberSettingsRequest {
    CallingName: string | redacted.Redacted<string>;
}
export interface UpdatePhoneNumberSettingsResponse {
}
export interface UpdateRoomRequest {
    AccountId: string;
    RoomId: string;
    Name?: string | redacted.Redacted<string>;
}
export interface UpdateRoomResponse {
    Room?: Room;
}
export interface UpdateRoomMembershipRequest {
    AccountId: string;
    RoomId: string;
    MemberId: string;
    Role?: RoomMembershipRole;
}
export interface UpdateRoomMembershipResponse {
    RoomMembership?: RoomMembership;
}
export interface UpdateUserRequest {
    AccountId: string;
    UserId: string;
    LicenseType?: License;
    UserType?: UserType;
    AlexaForBusinessMetadata?: AlexaForBusinessMetadata;
}
export interface UpdateUserResponse {
    User?: User;
}
export interface UpdateUserSettingsRequest {
    AccountId: string;
    UserId: string;
    UserSettings: UserSettings;
}
export interface UpdateUserSettingsResponse {
}
export type AssociatePhoneNumberWithUserError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Associates a phone number with the specified Amazon Chime user.
 */
export declare const associatePhoneNumberWithUser: API.OperationMethod<AssociatePhoneNumberWithUserRequest, AssociatePhoneNumberWithUserResponse, AssociatePhoneNumberWithUserError, Credentials | HttpClient.HttpClient>;
export type AssociateSigninDelegateGroupsWithAccountError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Associates the specified sign-in delegate groups with the specified Amazon Chime account.
 */
export declare const associateSigninDelegateGroupsWithAccount: API.OperationMethod<AssociateSigninDelegateGroupsWithAccountRequest, AssociateSigninDelegateGroupsWithAccountResponse, AssociateSigninDelegateGroupsWithAccountError, Credentials | HttpClient.HttpClient>;
export type BatchCreateRoomMembershipError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Adds up to 50 members to a chat room in an Amazon Chime Enterprise account. Members can be users or bots. The member role designates whether the member is a
 * chat room administrator or a general chat room member.
 */
export declare const batchCreateRoomMembership: API.OperationMethod<BatchCreateRoomMembershipRequest, BatchCreateRoomMembershipResponse, BatchCreateRoomMembershipError, Credentials | HttpClient.HttpClient>;
export type BatchDeletePhoneNumberError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Moves phone numbers into the
 * **Deletion queue**. Phone numbers must be disassociated from any users or Amazon Chime Voice Connectors before they can be deleted.
 *
 * Phone numbers remain in the
 * **Deletion queue** for 7 days before they are deleted permanently.
 */
export declare const batchDeletePhoneNumber: API.OperationMethod<BatchDeletePhoneNumberRequest, BatchDeletePhoneNumberResponse, BatchDeletePhoneNumberError, Credentials | HttpClient.HttpClient>;
export type BatchSuspendUserError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Suspends up to 50 users from a `Team` or `EnterpriseLWA` Amazon Chime
 * account. For more information about different account types, see Managing Your Amazon Chime Accounts in the Amazon Chime Administration
 * Guide.
 *
 * Users suspended from a `Team` account are disassociated from the account,but they
 * can continue to use Amazon Chime as free users. To remove the suspension from suspended
 * `Team` account users, invite them to the `Team` account again.
 * You can use the InviteUsers action to do so.
 *
 * Users suspended from an `EnterpriseLWA` account are immediately signed out of
 * Amazon Chime and can no longer sign in. To remove the suspension from suspended `EnterpriseLWA` account users, use the
 * BatchUnsuspendUser action.
 *
 * To sign out users without suspending them, use the
 * LogoutUser action.
 */
export declare const batchSuspendUser: API.OperationMethod<BatchSuspendUserRequest, BatchSuspendUserResponse, BatchSuspendUserError, Credentials | HttpClient.HttpClient>;
export type BatchUnsuspendUserError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Removes the suspension from up to 50 previously suspended users for the specified Amazon
 * Chime `EnterpriseLWA` account. Only users on `EnterpriseLWA`
 * accounts can be unsuspended using this action. For more information about different account types, see
 *
 * Managing Your Amazon Chime Accounts
 * in the account types, in the *Amazon Chime Administration Guide*.
 *
 * Previously suspended users who are unsuspended using this action are returned to
 * `Registered`
 * status. Users who are not previously suspended are ignored.
 */
export declare const batchUnsuspendUser: API.OperationMethod<BatchUnsuspendUserRequest, BatchUnsuspendUserResponse, BatchUnsuspendUserError, Credentials | HttpClient.HttpClient>;
export type BatchUpdatePhoneNumberError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates phone number product types or calling names. You can update one attribute at a time for each `UpdatePhoneNumberRequestItem`. For example, you can update the product type or the calling name.
 *
 * For toll-free numbers, you cannot use the Amazon Chime Business Calling product type. For numbers outside the U.S., you must use the Amazon Chime SIP Media Application Dial-In product type.
 *
 * Updates to outbound calling names can take up to 72 hours to complete. Pending updates to outbound calling names must be complete before you can request another update.
 */
export declare const batchUpdatePhoneNumber: API.OperationMethod<BatchUpdatePhoneNumberRequest, BatchUpdatePhoneNumberResponse, BatchUpdatePhoneNumberError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateUserError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates user details within the UpdateUserRequestItem object for up to 20 users for the specified Amazon Chime account. Currently, only `LicenseType` updates are supported for this action.
 */
export declare const batchUpdateUser: API.OperationMethod<BatchUpdateUserRequest, BatchUpdateUserResponse, BatchUpdateUserError, Credentials | HttpClient.HttpClient>;
export type CreateAccountError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates an Amazon Chime account under the administrator's AWS account. Only `Team`
 * account types are currently supported for this action. For more information about different account types, see
 * Managing Your Amazon Chime Accounts in the Amazon Chime
 * Administration Guide.
 */
export declare const createAccount: API.OperationMethod<CreateAccountRequest, CreateAccountResponse, CreateAccountError, Credentials | HttpClient.HttpClient>;
export type CreateBotError = BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a bot for an Amazon Chime Enterprise account.
 */
export declare const createBot: API.OperationMethod<CreateBotRequest, CreateBotResponse, CreateBotError, Credentials | HttpClient.HttpClient>;
export type CreateMeetingDialOutError = AccessDeniedException | BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Uses the join token and call metadata in a meeting request (From number, To number, and so forth) to initiate an outbound call to a public
 * switched telephone network (PSTN) and join them into a Chime meeting. Also ensures that the From number belongs to the customer.
 *
 * To play welcome audio or implement an interactive voice response (IVR), use the
 * `CreateSipMediaApplicationCall` action with the corresponding SIP media application ID.
 *
 * **This API is not available in a dedicated namespace.**
 */
export declare const createMeetingDialOut: API.OperationMethod<CreateMeetingDialOutRequest, CreateMeetingDialOutResponse, CreateMeetingDialOutError, Credentials | HttpClient.HttpClient>;
export type CreatePhoneNumberOrderError = AccessDeniedException | BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates an order for phone numbers to be provisioned. For toll-free numbers, you cannot use the Amazon Chime Business Calling product type.
 * For numbers outside the U.S., you must use the Amazon Chime SIP Media Application Dial-In product type.
 */
export declare const createPhoneNumberOrder: API.OperationMethod<CreatePhoneNumberOrderRequest, CreatePhoneNumberOrderResponse, CreatePhoneNumberOrderError, Credentials | HttpClient.HttpClient>;
export type CreateRoomError = BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a chat room for the specified Amazon Chime Enterprise account.
 */
export declare const createRoom: API.OperationMethod<CreateRoomRequest, CreateRoomResponse, CreateRoomError, Credentials | HttpClient.HttpClient>;
export type CreateRoomMembershipError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Adds a member to a chat room in an Amazon Chime Enterprise account. A member can be either a user or a bot. The member role designates whether the member is a chat room administrator or a general chat room member.
 */
export declare const createRoomMembership: API.OperationMethod<CreateRoomMembershipRequest, CreateRoomMembershipResponse, CreateRoomMembershipError, Credentials | HttpClient.HttpClient>;
export type CreateUserError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a user under the specified Amazon Chime account.
 */
export declare const createUser: API.OperationMethod<CreateUserRequest, CreateUserResponse, CreateUserError, Credentials | HttpClient.HttpClient>;
export type DeleteAccountError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | UnprocessableEntityException | CommonErrors;
/**
 * Deletes the specified Amazon Chime account. You must suspend all users before deleting
 * `Team` account. You can use the BatchSuspendUser action
 * to dodo.
 *
 * For `EnterpriseLWA` and `EnterpriseAD` accounts, you must release the
 * claimed domains for your Amazon Chime account before deletion. As soon as you release
 * the domain, all users under that account are suspended.
 *
 * Deleted accounts appear in your `Disabled` accounts list for 90 days. To restore
 * deleted account from your `Disabled` accounts list, you must contact AWS
 * Support.
 *
 * After 90 days, deleted accounts are permanently removed from your
 * `Disabled` accounts list.
 */
export declare const deleteAccount: API.OperationMethod<DeleteAccountRequest, DeleteAccountResponse, DeleteAccountError, Credentials | HttpClient.HttpClient>;
export type DeleteEventsConfigurationError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the events configuration that allows a bot to receive outgoing events.
 */
export declare const deleteEventsConfiguration: API.OperationMethod<DeleteEventsConfigurationRequest, DeleteEventsConfigurationResponse, DeleteEventsConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeletePhoneNumberError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Moves the specified phone number into the **Deletion queue**. A
 * phone number must be disassociated from any users or Amazon Chime Voice Connectors
 * before it can be deleted.
 *
 * Deleted phone numbers remain in the
 * **Deletion queue**
 * for 7 days before they are deleted permanently.
 */
export declare const deletePhoneNumber: API.OperationMethod<DeletePhoneNumberRequest, DeletePhoneNumberResponse, DeletePhoneNumberError, Credentials | HttpClient.HttpClient>;
export type DeleteRoomError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes a chat room in an Amazon Chime Enterprise account.
 */
export declare const deleteRoom: API.OperationMethod<DeleteRoomRequest, DeleteRoomResponse, DeleteRoomError, Credentials | HttpClient.HttpClient>;
export type DeleteRoomMembershipError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Removes a member from a chat room in an Amazon Chime Enterprise account.
 */
export declare const deleteRoomMembership: API.OperationMethod<DeleteRoomMembershipRequest, DeleteRoomMembershipResponse, DeleteRoomMembershipError, Credentials | HttpClient.HttpClient>;
export type DisassociatePhoneNumberFromUserError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Disassociates the primary provisioned phone number from the specified Amazon Chime user.
 */
export declare const disassociatePhoneNumberFromUser: API.OperationMethod<DisassociatePhoneNumberFromUserRequest, DisassociatePhoneNumberFromUserResponse, DisassociatePhoneNumberFromUserError, Credentials | HttpClient.HttpClient>;
export type DisassociateSigninDelegateGroupsFromAccountError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Disassociates the specified sign-in delegate groups from the specified Amazon Chime account.
 */
export declare const disassociateSigninDelegateGroupsFromAccount: API.OperationMethod<DisassociateSigninDelegateGroupsFromAccountRequest, DisassociateSigninDelegateGroupsFromAccountResponse, DisassociateSigninDelegateGroupsFromAccountError, Credentials | HttpClient.HttpClient>;
export type GetAccountError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves details for the specified Amazon Chime account, such as account type and supported
 * licenses.
 */
export declare const getAccount: API.OperationMethod<GetAccountRequest, GetAccountResponse, GetAccountError, Credentials | HttpClient.HttpClient>;
export type GetAccountSettingsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves account settings for the specified Amazon Chime account ID, such as remote control
 * and dialout settings. For more information about these settings, see
 * Use the Policies Page in the *Amazon Chime Administration Guide*.
 */
export declare const getAccountSettings: API.OperationMethod<GetAccountSettingsRequest, GetAccountSettingsResponse, GetAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type GetBotError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves details for the specified bot, such as bot email address, bot type, status, and display name.
 */
export declare const getBot: API.OperationMethod<GetBotRequest, GetBotResponse, GetBotError, Credentials | HttpClient.HttpClient>;
export type GetEventsConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | UnauthorizedClientException | CommonErrors;
/**
 * Gets details for an events configuration that allows a bot to receive outgoing events, such as an HTTPS endpoint or Lambda function ARN.
 */
export declare const getEventsConfiguration: API.OperationMethod<GetEventsConfigurationRequest, GetEventsConfigurationResponse, GetEventsConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetGlobalSettingsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves global settings for the administrator's AWS account, such as Amazon Chime Business
 * Calling and Amazon Chime Voice Connector settings.
 */
export declare const getGlobalSettings: API.OperationMethod<GetGlobalSettingsRequest, GetGlobalSettingsResponse, GetGlobalSettingsError, Credentials | HttpClient.HttpClient>;
export type GetPhoneNumberError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves details for the specified phone number ID, such as associations, capabilities, and product type.
 */
export declare const getPhoneNumber: API.OperationMethod<GetPhoneNumberRequest, GetPhoneNumberResponse, GetPhoneNumberError, Credentials | HttpClient.HttpClient>;
export type GetPhoneNumberOrderError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves details for the specified phone number order, such as the order creation timestamp, phone
 * numbers in E.164 format, product type, and order status.
 */
export declare const getPhoneNumberOrder: API.OperationMethod<GetPhoneNumberOrderRequest, GetPhoneNumberOrderResponse, GetPhoneNumberOrderError, Credentials | HttpClient.HttpClient>;
export type GetPhoneNumberSettingsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the phone number settings for the administrator's AWS account, such as the default outbound calling name.
 */
export declare const getPhoneNumberSettings: API.OperationMethod<GetPhoneNumberSettingsRequest, GetPhoneNumberSettingsResponse, GetPhoneNumberSettingsError, Credentials | HttpClient.HttpClient>;
export type GetRetentionSettingsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Gets the retention settings for the specified Amazon Chime Enterprise account. For more information about retention settings, see
 * Managing Chat Retention Policies in the *Amazon Chime Administration Guide*.
 */
export declare const getRetentionSettings: API.OperationMethod<GetRetentionSettingsRequest, GetRetentionSettingsResponse, GetRetentionSettingsError, Credentials | HttpClient.HttpClient>;
export type GetRoomError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves room details, such as the room name, for a room in an Amazon Chime Enterprise account.
 */
export declare const getRoom: API.OperationMethod<GetRoomRequest, GetRoomResponse, GetRoomError, Credentials | HttpClient.HttpClient>;
export type GetUserError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves details for the specified user ID, such as primary email address, license type,and personal meeting PIN.
 *
 * To retrieve user details with an email address instead of a user ID, use the
 * ListUsers action, and then filter by email address.
 */
export declare const getUser: API.OperationMethod<GetUserRequest, GetUserResponse, GetUserError, Credentials | HttpClient.HttpClient>;
export type GetUserSettingsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves settings for the specified user ID, such as any associated phone number settings.
 */
export declare const getUserSettings: API.OperationMethod<GetUserSettingsRequest, GetUserSettingsResponse, GetUserSettingsError, Credentials | HttpClient.HttpClient>;
export type InviteUsersError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Sends email to a maximum of 50 users, inviting them to the specified Amazon Chime
 * `Team` account. Only `Team` account types are currently
 * supported for this action.
 */
export declare const inviteUsers: API.OperationMethod<InviteUsersRequest, InviteUsersResponse, InviteUsersError, Credentials | HttpClient.HttpClient>;
export type ListAccountsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the Amazon Chime accounts under the administrator's AWS account. You can filter accounts
 * by account name prefix. To find out which Amazon Chime account a user belongs to, you can
 * filter by the user's email address, which returns one account result.
 */
export declare const listAccounts: API.PaginatedOperationMethod<ListAccountsRequest, ListAccountsResponse, ListAccountsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListBotsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the bots associated with the administrator's Amazon Chime Enterprise account ID.
 */
export declare const listBots: API.PaginatedOperationMethod<ListBotsRequest, ListBotsResponse, ListBotsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPhoneNumberOrdersError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the phone number orders for the administrator's Amazon Chime account.
 */
export declare const listPhoneNumberOrders: API.PaginatedOperationMethod<ListPhoneNumberOrdersRequest, ListPhoneNumberOrdersResponse, ListPhoneNumberOrdersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPhoneNumbersError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the phone numbers for the specified Amazon Chime account, Amazon Chime user, Amazon Chime Voice Connector, or Amazon Chime Voice Connector group.
 */
export declare const listPhoneNumbers: API.PaginatedOperationMethod<ListPhoneNumbersRequest, ListPhoneNumbersResponse, ListPhoneNumbersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRoomMembershipsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the membership details for the specified room in an Amazon Chime Enterprise account,
 * such as the members' IDs, email addresses, and names.
 */
export declare const listRoomMemberships: API.PaginatedOperationMethod<ListRoomMembershipsRequest, ListRoomMembershipsResponse, ListRoomMembershipsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRoomsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the room details for the specified Amazon Chime Enterprise account. Optionally, filter the results by a member ID (user ID or bot ID) to see a list of rooms that the member belongs to.
 */
export declare const listRooms: API.PaginatedOperationMethod<ListRoomsRequest, ListRoomsResponse, ListRoomsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSupportedPhoneNumberCountriesError = AccessDeniedException | BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists supported phone number countries.
 */
export declare const listSupportedPhoneNumberCountries: API.OperationMethod<ListSupportedPhoneNumberCountriesRequest, ListSupportedPhoneNumberCountriesResponse, ListSupportedPhoneNumberCountriesError, Credentials | HttpClient.HttpClient>;
export type ListUsersError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the users that belong to the specified Amazon Chime account. You can specify an email
 * address to list only the user that the email address belongs to.
 */
export declare const listUsers: API.PaginatedOperationMethod<ListUsersRequest, ListUsersResponse, ListUsersError, Credentials | HttpClient.HttpClient, unknown>;
export type LogoutUserError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Logs out the specified user from all of the devices they are currently logged into.
 */
export declare const logoutUser: API.OperationMethod<LogoutUserRequest, LogoutUserResponse, LogoutUserError, Credentials | HttpClient.HttpClient>;
export type PutEventsConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | UnauthorizedClientException | CommonErrors;
/**
 * Creates an events configuration that allows a bot to receive outgoing events sent by Amazon
 * Chime. Choose either an HTTPS endpoint or a Lambda function ARN. For more information,
 * see Bot.
 */
export declare const putEventsConfiguration: API.OperationMethod<PutEventsConfigurationRequest, PutEventsConfigurationResponse, PutEventsConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutRetentionSettingsError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Puts retention settings for the specified Amazon Chime Enterprise account. We recommend using AWS CloudTrail to monitor usage of this API for your account. For more information, see
 * Logging Amazon Chime API Calls with AWS CloudTrail
 * in the *Amazon Chime Administration Guide*.
 *
 * To turn off existing retention settings, remove the number of days from the corresponding
 * **RetentionDays**
 * field in the
 * **RetentionSettings**
 * object. For more information about retention settings, see
 * Managing Chat Retention Policies
 * in the *Amazon Chime Administration Guide*.
 */
export declare const putRetentionSettings: API.OperationMethod<PutRetentionSettingsRequest, PutRetentionSettingsResponse, PutRetentionSettingsError, Credentials | HttpClient.HttpClient>;
export type RedactConversationMessageError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Redacts the specified message from the specified Amazon Chime conversation.
 */
export declare const redactConversationMessage: API.OperationMethod<RedactConversationMessageRequest, RedactConversationMessageResponse, RedactConversationMessageError, Credentials | HttpClient.HttpClient>;
export type RedactRoomMessageError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Redacts the specified message from the specified Amazon Chime channel.
 */
export declare const redactRoomMessage: API.OperationMethod<RedactRoomMessageRequest, RedactRoomMessageResponse, RedactRoomMessageError, Credentials | HttpClient.HttpClient>;
export type RegenerateSecurityTokenError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Regenerates the security token for a bot.
 */
export declare const regenerateSecurityToken: API.OperationMethod<RegenerateSecurityTokenRequest, RegenerateSecurityTokenResponse, RegenerateSecurityTokenError, Credentials | HttpClient.HttpClient>;
export type ResetPersonalPINError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Resets the personal meeting PIN for the specified user on an Amazon Chime account. Returns
 * the User object with the updated personal meeting PIN.
 */
export declare const resetPersonalPIN: API.OperationMethod<ResetPersonalPINRequest, ResetPersonalPINResponse, ResetPersonalPINError, Credentials | HttpClient.HttpClient>;
export type RestorePhoneNumberError = BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Moves a phone number from the **Deletion queue** back into the
 * phone number **Inventory**.
 */
export declare const restorePhoneNumber: API.OperationMethod<RestorePhoneNumberRequest, RestorePhoneNumberResponse, RestorePhoneNumberError, Credentials | HttpClient.HttpClient>;
export type SearchAvailablePhoneNumbersError = AccessDeniedException | BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Searches for phone numbers that can be ordered. For US numbers, provide at least one of
 * the following search filters: `AreaCode`, `City`,
 * `State`, or `TollFreePrefix`. If you provide
 * `City`, you must also provide `State`. Numbers outside the US only
 * support the `PhoneNumberType` filter, which you must use.
 */
export declare const searchAvailablePhoneNumbers: API.PaginatedOperationMethod<SearchAvailablePhoneNumbersRequest, SearchAvailablePhoneNumbersResponse, SearchAvailablePhoneNumbersError, Credentials | HttpClient.HttpClient, unknown>;
export type UpdateAccountError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates account details for the specified Amazon Chime account. Currently, only account name and default license updates are supported for this action.
 */
export declare const updateAccount: API.OperationMethod<UpdateAccountRequest, UpdateAccountResponse, UpdateAccountError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountSettingsError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the settings for the specified Amazon Chime account. You can update settings for
 * remote control of shared screens, or for the dial-out option. For more information about
 * these settings, see Use
 * the Policies Page in the Amazon Chime Administration
 * Guide.
 */
export declare const updateAccountSettings: API.OperationMethod<UpdateAccountSettingsRequest, UpdateAccountSettingsResponse, UpdateAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateBotError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the status of the specified bot, such as starting or stopping the bot from running in your Amazon Chime Enterprise account.
 */
export declare const updateBot: API.OperationMethod<UpdateBotRequest, UpdateBotResponse, UpdateBotError, Credentials | HttpClient.HttpClient>;
export type UpdateGlobalSettingsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates global settings for the administrator's AWS account, such as Amazon Chime Business Calling and Amazon Chime Voice Connector settings.
 */
export declare const updateGlobalSettings: API.OperationMethod<UpdateGlobalSettingsRequest, UpdateGlobalSettingsResponse, UpdateGlobalSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdatePhoneNumberError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates phone number details, such as product type or calling name, for the specified phone number ID. You can update one phone number detail at a time. For example, you can update either the product type or the calling name in one action.
 *
 * For toll-free numbers, you cannot use the Amazon Chime Business Calling product type. For numbers outside the U.S., you must use the Amazon Chime SIP Media Application Dial-In product type.
 *
 * Updates to outbound calling names can take 72 hours to complete. Pending updates to outbound calling names must be complete before you can request another update.
 */
export declare const updatePhoneNumber: API.OperationMethod<UpdatePhoneNumberRequest, UpdatePhoneNumberResponse, UpdatePhoneNumberError, Credentials | HttpClient.HttpClient>;
export type UpdatePhoneNumberSettingsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the phone number settings for the administrator's AWS account, such as the default
 * outbound calling name. You can update the default outbound calling name once every seven
 * days. Outbound calling names can take up to 72 hours to update.
 */
export declare const updatePhoneNumberSettings: API.OperationMethod<UpdatePhoneNumberSettingsRequest, UpdatePhoneNumberSettingsResponse, UpdatePhoneNumberSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateRoomError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates room details, such as the room name, for a room in an Amazon Chime Enterprise account.
 */
export declare const updateRoom: API.OperationMethod<UpdateRoomRequest, UpdateRoomResponse, UpdateRoomError, Credentials | HttpClient.HttpClient>;
export type UpdateRoomMembershipError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates room membership details, such as the member role, for a room in an Amazon Chime
 * Enterprise account. The member role designates whether the member is a chat room
 * administrator or a general chat room member. The member role can be updated only for
 * user IDs.
 */
export declare const updateRoomMembership: API.OperationMethod<UpdateRoomMembershipRequest, UpdateRoomMembershipResponse, UpdateRoomMembershipError, Credentials | HttpClient.HttpClient>;
export type UpdateUserError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates user details for a specified user ID. Currently, only `LicenseType` updates are supported for this action.
 */
export declare const updateUser: API.OperationMethod<UpdateUserRequest, UpdateUserResponse, UpdateUserError, Credentials | HttpClient.HttpClient>;
export type UpdateUserSettingsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the settings for the specified user, such as phone number settings.
 */
export declare const updateUserSettings: API.OperationMethod<UpdateUserSettingsRequest, UpdateUserSettingsResponse, UpdateUserSettingsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=chime.d.ts.map