import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
    readonly FieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SensitiveString = string | redacted.Redacted<string>;
export type Position = number[];
export type BoundingBox = number[];
export type DistanceMeters = number;
export interface FilterCircle {
    Center: number[];
    Radius: number;
}
export type CountryCode = string | redacted.Redacted<string>;
export type CountryCodeList = (string | redacted.Redacted<string>)[];
export type AutocompleteFilterPlaceType = "Locality" | "PostalCode" | "Street" | "Intersection" | "PointAddress" | "InterpolatedAddress" | "Country" | "Region" | (string & {});
export type AutocompleteFilterPlaceTypeList = AutocompleteFilterPlaceType[];
export interface AutocompleteFilter {
    BoundingBox?: number[];
    Circle?: FilterCircle;
    IncludeCountries?: (string | redacted.Redacted<string>)[];
    IncludePlaceTypes?: AutocompleteFilterPlaceType[];
}
export type PostalCodeMode = "MergeAllSpannedLocalities" | "EnumerateSpannedLocalities" | "EnumerateSpannedDistricts" | (string & {});
export type AutocompleteAdditionalFeature = "Core" | (string & {});
export type AutocompleteAdditionalFeatureList = AutocompleteAdditionalFeature[];
export type LanguageTag = string;
export type AutocompleteIntendedUse = "SingleUse" | (string & {});
export type ApiKey = string | redacted.Redacted<string>;
export interface AutocompleteRequest {
    QueryText: string | redacted.Redacted<string>;
    MaxResults?: number;
    BiasPosition?: number[];
    Filter?: AutocompleteFilter;
    PostalCodeMode?: PostalCodeMode;
    AdditionalFeatures?: AutocompleteAdditionalFeature[];
    Language?: string;
    PoliticalView?: string | redacted.Redacted<string>;
    IntendedUse?: AutocompleteIntendedUse;
    Key?: string | redacted.Redacted<string>;
}
export type PlaceType = "Country" | "Region" | "SubRegion" | "Locality" | "District" | "SubDistrict" | "PostalCode" | "Block" | "SubBlock" | "Intersection" | "Street" | "PointOfInterest" | "PointAddress" | "InterpolatedAddress" | "SecondaryAddress" | "InferredSecondaryAddress" | (string & {});
export type CountryCode2 = string | redacted.Redacted<string>;
export type CountryCode3 = string | redacted.Redacted<string>;
export interface Country {
    Code2?: string | redacted.Redacted<string>;
    Code3?: string | redacted.Redacted<string>;
    Name?: string | redacted.Redacted<string>;
}
export interface Region {
    Code?: string | redacted.Redacted<string>;
    Name?: string | redacted.Redacted<string>;
}
export interface SubRegion {
    Code?: string | redacted.Redacted<string>;
    Name?: string | redacted.Redacted<string>;
}
export type IntersectionStreet = string;
export type IntersectionStreetList = string[];
export type TypePlacement = "BeforeBaseName" | "AfterBaseName" | (string & {});
export type TypeSeparator = string;
export interface StreetComponents {
    BaseName?: string | redacted.Redacted<string>;
    Type?: string | redacted.Redacted<string>;
    TypePlacement?: TypePlacement;
    TypeSeparator?: string;
    Prefix?: string | redacted.Redacted<string>;
    Suffix?: string | redacted.Redacted<string>;
    Direction?: string | redacted.Redacted<string>;
    Language?: string;
}
export type StreetComponentsList = StreetComponents[];
export interface SecondaryAddressComponent {
    Number: string | redacted.Redacted<string>;
    Designator?: string | redacted.Redacted<string>;
}
export type SecondaryAddressComponentList = SecondaryAddressComponent[];
export interface Address {
    Label?: string | redacted.Redacted<string>;
    Country?: Country;
    Region?: Region;
    SubRegion?: SubRegion;
    Locality?: string | redacted.Redacted<string>;
    District?: string | redacted.Redacted<string>;
    SubDistrict?: string | redacted.Redacted<string>;
    PostalCode?: string | redacted.Redacted<string>;
    Block?: string | redacted.Redacted<string>;
    SubBlock?: string | redacted.Redacted<string>;
    Intersection?: string[];
    Street?: string | redacted.Redacted<string>;
    StreetComponents?: StreetComponents[];
    AddressNumber?: string | redacted.Redacted<string>;
    Building?: string | redacted.Redacted<string>;
    SecondaryAddressComponents?: SecondaryAddressComponent[];
}
export interface Highlight {
    StartIndex?: number;
    EndIndex?: number;
    Value?: string | redacted.Redacted<string>;
}
export type HighlightList = Highlight[];
export interface CountryHighlights {
    Code?: Highlight[];
    Name?: Highlight[];
}
export interface RegionHighlights {
    Code?: Highlight[];
    Name?: Highlight[];
}
export interface SubRegionHighlights {
    Code?: Highlight[];
    Name?: Highlight[];
}
export type IntersectionHighlightsList = Highlight[][];
export interface AutocompleteAddressHighlights {
    Label?: Highlight[];
    Country?: CountryHighlights;
    Region?: RegionHighlights;
    SubRegion?: SubRegionHighlights;
    Locality?: Highlight[];
    District?: Highlight[];
    SubDistrict?: Highlight[];
    Street?: Highlight[];
    Block?: Highlight[];
    SubBlock?: Highlight[];
    Intersection?: Highlight[][];
    PostalCode?: Highlight[];
    AddressNumber?: Highlight[];
    Building?: Highlight[];
}
export interface AutocompleteHighlights {
    Title?: Highlight[];
    Address?: AutocompleteAddressHighlights;
}
export type SensitiveBoolean = boolean;
export interface AutocompleteResultItem {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    Address?: Address;
    Distance?: number;
    Language?: string;
    PoliticalView?: string | redacted.Redacted<string>;
    Highlights?: AutocompleteHighlights;
    EstimatedPointAddress?: boolean;
}
export type AutocompleteResultItemList = AutocompleteResultItem[];
export interface AutocompleteResponse {
    PricingBucket: string;
    ResultItems?: AutocompleteResultItem[];
}
export interface GeocodeQueryComponents {
    Country?: string | redacted.Redacted<string>;
    Region?: string | redacted.Redacted<string>;
    SubRegion?: string | redacted.Redacted<string>;
    Locality?: string | redacted.Redacted<string>;
    District?: string | redacted.Redacted<string>;
    Street?: string | redacted.Redacted<string>;
    AddressNumber?: string | redacted.Redacted<string>;
    PostalCode?: string | redacted.Redacted<string>;
}
export type GeocodeFilterPlaceType = "Locality" | "PostalCode" | "Intersection" | "Street" | "PointAddress" | "InterpolatedAddress" | "SecondaryAddress" | "PointOfInterest" | "Country" | "Region" | (string & {});
export type GeocodeFilterPlaceTypeList = GeocodeFilterPlaceType[];
export interface GeocodeFilter {
    IncludeCountries?: (string | redacted.Redacted<string>)[];
    IncludePlaceTypes?: GeocodeFilterPlaceType[];
}
export type GeocodeAdditionalFeature = "TimeZone" | "Access" | "SecondaryAddresses" | "Intersections" | (string & {});
export type GeocodeAdditionalFeatureList = GeocodeAdditionalFeature[];
export type GeocodeIntendedUse = "SingleUse" | "Storage" | (string & {});
export type AddressTranslationComponent = "District" | "Locality" | "Region" | "SubRegion" | (string & {});
export type AddressTranslationComponentList = AddressTranslationComponent[];
export type GeocodeAddressNamesMode = "Matched" | "Administrative" | (string & {});
export interface GeocodeRequest {
    QueryText?: string | redacted.Redacted<string>;
    QueryComponents?: GeocodeQueryComponents;
    MaxResults?: number;
    BiasPosition?: number[];
    Filter?: GeocodeFilter;
    AdditionalFeatures?: GeocodeAdditionalFeature[];
    Language?: string;
    PoliticalView?: string | redacted.Redacted<string>;
    IntendedUse?: GeocodeIntendedUse;
    Key?: string | redacted.Redacted<string>;
    PostalCodeMode?: PostalCodeMode;
    AddressTranslations?: AddressTranslationComponent[];
    AddressNamesMode?: GeocodeAddressNamesMode;
}
export type PostalAuthority = "Usps" | (string & {});
export type PostalCodeType = "UspsZip" | "UspsZipPlus4" | (string & {});
export type ZipClassificationCode = "Military" | "PostOfficeBoxes" | "Unique" | (string & {});
export interface UspsZip {
    ZipClassificationCode?: ZipClassificationCode;
}
export type RecordTypeCode = "Firm" | "General" | "HighRise" | "PostOfficeBox" | "Rural" | "Street" | (string & {});
export interface UspsZipPlus4 {
    RecordTypeCode?: RecordTypeCode;
}
export interface PostalCodeDetails {
    PostalCode?: string | redacted.Redacted<string>;
    PostalAuthority?: PostalAuthority;
    PostalCodeType?: PostalCodeType;
    UspsZip?: UspsZip;
    UspsZipPlus4?: UspsZipPlus4;
}
export type PostalCodeDetailsList = PostalCodeDetails[];
export interface Category {
    Id: string | redacted.Redacted<string>;
    Name: string | redacted.Redacted<string>;
    LocalizedName?: string | redacted.Redacted<string>;
    Primary?: boolean;
}
export type CategoryList = Category[];
export interface FoodType {
    LocalizedName: string | redacted.Redacted<string>;
    Id?: string | redacted.Redacted<string>;
    Primary?: boolean;
}
export type FoodTypeList = FoodType[];
export type AccessPointType = "Delivery" | "Emergency" | "Entrance" | "Loading" | "Other" | "Parking" | "Taxi" | (string & {});
export interface AccessPoint {
    Position?: number[];
    Type?: AccessPointType;
    Primary?: boolean;
    Label?: string | redacted.Redacted<string>;
}
export type AccessPointList = AccessPoint[];
export type DurationSeconds = number;
export interface TimeZone {
    Name: string | redacted.Redacted<string>;
    Offset?: string | redacted.Redacted<string>;
    OffsetSeconds?: number;
}
export type MatchScore = number;
export type MatchScoreList = number[];
export interface SecondaryAddressComponentMatchScore {
    Number?: number;
}
export type SecondaryAddressComponentMatchScoreList = SecondaryAddressComponentMatchScore[];
export interface AddressComponentMatchScores {
    Country?: number;
    Region?: number;
    SubRegion?: number;
    Locality?: number;
    District?: number;
    SubDistrict?: number;
    PostalCode?: number;
    Block?: number;
    SubBlock?: number;
    Intersection?: number[];
    AddressNumber?: number;
    Building?: number;
    SecondaryAddressComponents?: SecondaryAddressComponentMatchScore[];
}
export interface ComponentMatchScores {
    Title?: number;
    Address?: AddressComponentMatchScores;
}
export interface MatchScoreDetails {
    Overall?: number;
    Components?: ComponentMatchScores;
}
export interface ParsedQueryComponent {
    StartIndex?: number;
    EndIndex?: number;
    Value?: string | redacted.Redacted<string>;
    QueryComponent?: string | redacted.Redacted<string>;
}
export type ParsedQueryComponentList = ParsedQueryComponent[];
export interface ParsedQuerySecondaryAddressComponent {
    StartIndex: number;
    EndIndex: number;
    Value: string | redacted.Redacted<string>;
    Number: string | redacted.Redacted<string>;
    Designator: string | redacted.Redacted<string>;
}
export type ParsedQuerySecondaryAddressComponentList = ParsedQuerySecondaryAddressComponent[];
export interface GeocodeParsedQueryAddressComponents {
    Country?: ParsedQueryComponent[];
    Region?: ParsedQueryComponent[];
    SubRegion?: ParsedQueryComponent[];
    Locality?: ParsedQueryComponent[];
    District?: ParsedQueryComponent[];
    SubDistrict?: ParsedQueryComponent[];
    PostalCode?: ParsedQueryComponent[];
    Block?: ParsedQueryComponent[];
    SubBlock?: ParsedQueryComponent[];
    Street?: ParsedQueryComponent[];
    AddressNumber?: ParsedQueryComponent[];
    Building?: ParsedQueryComponent[];
    SecondaryAddressComponents?: ParsedQuerySecondaryAddressComponent[];
    OtherComponents?: ParsedQueryComponent[];
}
export interface GeocodeParsedQuery {
    Title?: ParsedQueryComponent[];
    Address?: GeocodeParsedQueryAddressComponents;
}
export interface Intersection {
    PlaceId: string | redacted.Redacted<string>;
    Title: string | redacted.Redacted<string>;
    Address?: Address;
    Position?: number[];
    Distance?: number;
    RouteDistance?: number;
    MapView?: number[];
    AccessPoints?: AccessPoint[];
}
export type IntersectionList = Intersection[];
export interface RelatedPlace {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    Address?: Address;
    Position?: number[];
    AccessPoints?: AccessPoint[];
}
export type RelatedPlaceList = RelatedPlace[];
export type TranslationNameType = "Abbreviation" | "AreaCode" | "BaseName" | "Exonym" | "Shortened" | "Synonym" | (string & {});
export interface TranslationName {
    Value: string | redacted.Redacted<string>;
    Language?: string;
    Type: TranslationNameType;
    Primary?: boolean;
    Transliterated?: boolean;
}
export type TranslationNameList = TranslationName[];
export type AdminNamesPreference = "Alternative" | "Primary" | (string & {});
export interface AdminNames {
    Names: TranslationName[];
    Preference?: AdminNamesPreference;
}
export type AdminNamesList = AdminNames[];
export interface TranslationDetails {
    Locality?: AdminNames[];
    Region?: AdminNames[];
    District?: AdminNames[];
    SubRegion?: AdminNames[];
}
export interface GeocodeResultItem {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    Address?: Address;
    AddressNumberCorrected?: boolean;
    PostalCodeDetails?: PostalCodeDetails[];
    Position?: number[];
    Distance?: number;
    MapView?: number[];
    Categories?: Category[];
    FoodTypes?: FoodType[];
    AccessPoints?: AccessPoint[];
    TimeZone?: TimeZone;
    PoliticalView?: string | redacted.Redacted<string>;
    MatchScores?: MatchScoreDetails;
    ParsedQuery?: GeocodeParsedQuery;
    Intersections?: Intersection[];
    MainAddress?: RelatedPlace;
    SecondaryAddresses?: RelatedPlace[];
    Translations?: TranslationDetails;
    EstimatedPointAddress?: boolean;
}
export type GeocodeResultItemList = GeocodeResultItem[];
export interface GeocodeResponse {
    PricingBucket: string;
    ResultItems?: GeocodeResultItem[];
}
export type GetPlaceAdditionalFeature = "TimeZone" | "Phonemes" | "Access" | "Contact" | "SecondaryAddresses" | "CrossReferences" | (string & {});
export type GetPlaceAdditionalFeatureList = GetPlaceAdditionalFeature[];
export type GetPlaceIntendedUse = "SingleUse" | "Storage" | (string & {});
export type GetPlaceAddressNamesMode = "Administrative" | (string & {});
export interface GetPlaceRequest {
    PlaceId: string | redacted.Redacted<string>;
    AdditionalFeatures?: GetPlaceAdditionalFeature[];
    Language?: string;
    PoliticalView?: string | redacted.Redacted<string>;
    IntendedUse?: GetPlaceIntendedUse;
    Key?: string | redacted.Redacted<string>;
    AddressNamesMode?: GetPlaceAddressNamesMode;
}
export interface BusinessChain {
    Name?: string | redacted.Redacted<string>;
    Id?: string | redacted.Redacted<string>;
}
export type BusinessChainList = BusinessChain[];
export interface ContactDetails {
    Label?: string | redacted.Redacted<string>;
    Value?: string | redacted.Redacted<string>;
    Categories?: Category[];
}
export type ContactDetailsList = ContactDetails[];
export interface Contacts {
    Phones?: ContactDetails[];
    Faxes?: ContactDetails[];
    Websites?: ContactDetails[];
    Emails?: ContactDetails[];
}
export type OpeningHoursDisplay = string | redacted.Redacted<string>;
export type OpeningHoursDisplayList = (string | redacted.Redacted<string>)[];
export interface OpeningHoursComponents {
    OpenTime?: string | redacted.Redacted<string>;
    OpenDuration?: string | redacted.Redacted<string>;
    Recurrence?: string | redacted.Redacted<string>;
}
export type OpeningHoursComponentsList = OpeningHoursComponents[];
export interface OpeningHours {
    Display?: (string | redacted.Redacted<string>)[];
    OpenNow?: boolean;
    Components?: OpeningHoursComponents[];
    Categories?: Category[];
}
export type OpeningHoursList = OpeningHours[];
export interface AccessRestriction {
    Restricted?: boolean;
    Categories?: Category[];
}
export type AccessRestrictionList = AccessRestriction[];
export interface PhonemeTranscription {
    Value?: string | redacted.Redacted<string>;
    Language?: string;
    Preferred?: boolean;
}
export type PhonemeTranscriptionList = PhonemeTranscription[];
export interface AddressComponentPhonemes {
    Country?: PhonemeTranscription[];
    Region?: PhonemeTranscription[];
    SubRegion?: PhonemeTranscription[];
    Locality?: PhonemeTranscription[];
    District?: PhonemeTranscription[];
    SubDistrict?: PhonemeTranscription[];
    Block?: PhonemeTranscription[];
    SubBlock?: PhonemeTranscription[];
    Street?: PhonemeTranscription[];
}
export interface PhonemeDetails {
    Title?: PhonemeTranscription[];
    Address?: AddressComponentPhonemes;
}
export type PlaceAttribute = "DriveThrough" | (string & {});
export type PlaceAttributeList = PlaceAttribute[];
export interface CrossReference {
    Source: string | redacted.Redacted<string>;
    SourcePlaceId: string | redacted.Redacted<string>;
    SourceCategories?: Category[];
}
export type CrossReferenceList = CrossReference[];
export interface GetPlaceResponse {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    PricingBucket: string;
    Address?: Address;
    AddressNumberCorrected?: boolean;
    PostalCodeDetails?: PostalCodeDetails[];
    Position?: number[];
    MapView?: number[];
    Categories?: Category[];
    FoodTypes?: FoodType[];
    BusinessChains?: BusinessChain[];
    Contacts?: Contacts;
    OpeningHours?: OpeningHours[];
    AccessPoints?: AccessPoint[];
    AccessRestrictions?: AccessRestriction[];
    TimeZone?: TimeZone;
    PoliticalView?: string | redacted.Redacted<string>;
    Phonemes?: PhonemeDetails;
    MainAddress?: RelatedPlace;
    SecondaryAddresses?: RelatedPlace[];
    PlaceAttributes?: PlaceAttribute[];
    EstimatedPointAddress?: boolean;
    CrossReferences?: CrossReference[];
}
export type ReverseGeocodeFilterPlaceType = "Locality" | "Intersection" | "Street" | "PointAddress" | "InterpolatedAddress" | "SecondaryAddress" | "PointOfInterest" | (string & {});
export type ReverseGeocodeFilterPlaceTypeList = ReverseGeocodeFilterPlaceType[];
export interface ReverseGeocodeFilter {
    IncludePlaceTypes?: ReverseGeocodeFilterPlaceType[];
}
export type ReverseGeocodeAdditionalFeature = "TimeZone" | "Access" | "Intersections" | (string & {});
export type ReverseGeocodeAdditionalFeatureList = ReverseGeocodeAdditionalFeature[];
export type ReverseGeocodeIntendedUse = "SingleUse" | "Storage" | (string & {});
export type Heading = number;
export type ReverseGeocodeAddressNamesMode = "Administrative" | (string & {});
export interface ReverseGeocodeRequest {
    QueryPosition: number[];
    QueryRadius?: number;
    MaxResults?: number;
    Filter?: ReverseGeocodeFilter;
    AdditionalFeatures?: ReverseGeocodeAdditionalFeature[];
    Language?: string;
    PoliticalView?: string | redacted.Redacted<string>;
    IntendedUse?: ReverseGeocodeIntendedUse;
    Key?: string | redacted.Redacted<string>;
    Heading?: number;
    AddressNamesMode?: ReverseGeocodeAddressNamesMode;
}
export interface ReverseGeocodeResultItem {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    Address?: Address;
    AddressNumberCorrected?: boolean;
    PostalCodeDetails?: PostalCodeDetails[];
    Position?: number[];
    Distance?: number;
    MapView?: number[];
    Categories?: Category[];
    FoodTypes?: FoodType[];
    AccessPoints?: AccessPoint[];
    TimeZone?: TimeZone;
    PoliticalView?: string | redacted.Redacted<string>;
    Intersections?: Intersection[];
    MainAddress?: RelatedPlace;
    EstimatedPointAddress?: boolean;
}
export type ReverseGeocodeResultItemList = ReverseGeocodeResultItem[];
export interface ReverseGeocodeResponse {
    PricingBucket: string;
    ResultItems?: ReverseGeocodeResultItem[];
}
export type FilterCategoryList = (string | redacted.Redacted<string>)[];
export type FilterBusinessChainList = (string | redacted.Redacted<string>)[];
export type FilterFoodTypeList = (string | redacted.Redacted<string>)[];
export interface SearchNearbyFilter {
    BoundingBox?: number[];
    IncludeCountries?: (string | redacted.Redacted<string>)[];
    IncludeCategories?: (string | redacted.Redacted<string>)[];
    ExcludeCategories?: (string | redacted.Redacted<string>)[];
    IncludeBusinessChains?: (string | redacted.Redacted<string>)[];
    ExcludeBusinessChains?: (string | redacted.Redacted<string>)[];
    IncludeFoodTypes?: (string | redacted.Redacted<string>)[];
    ExcludeFoodTypes?: (string | redacted.Redacted<string>)[];
}
export type SearchNearbyAdditionalFeature = "TimeZone" | "Phonemes" | "Access" | "Contact" | "CrossReferences" | (string & {});
export type SearchNearbyAdditionalFeatureList = SearchNearbyAdditionalFeature[];
export type SearchNearbyIntendedUse = "SingleUse" | "Storage" | (string & {});
export type Token = string;
export interface SearchNearbyRequest {
    QueryPosition: number[];
    QueryRadius?: number;
    MaxResults?: number;
    Filter?: SearchNearbyFilter;
    AdditionalFeatures?: SearchNearbyAdditionalFeature[];
    Language?: string;
    PoliticalView?: string | redacted.Redacted<string>;
    IntendedUse?: SearchNearbyIntendedUse;
    NextToken?: string;
    Key?: string | redacted.Redacted<string>;
}
export interface SearchNearbyResultItem {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    Address?: Address;
    AddressNumberCorrected?: boolean;
    Position?: number[];
    Distance?: number;
    MapView?: number[];
    Categories?: Category[];
    FoodTypes?: FoodType[];
    BusinessChains?: BusinessChain[];
    Contacts?: Contacts;
    OpeningHours?: OpeningHours[];
    AccessPoints?: AccessPoint[];
    AccessRestrictions?: AccessRestriction[];
    TimeZone?: TimeZone;
    PoliticalView?: string | redacted.Redacted<string>;
    Phonemes?: PhonemeDetails;
    PlaceAttributes?: PlaceAttribute[];
    CrossReferences?: CrossReference[];
}
export type SearchNearbyResultItemList = SearchNearbyResultItem[];
export interface SearchNearbyResponse {
    PricingBucket: string;
    ResultItems?: SearchNearbyResultItem[];
    NextToken?: string;
}
export interface SearchTextFilter {
    BoundingBox?: number[];
    Circle?: FilterCircle;
    IncludeCountries?: (string | redacted.Redacted<string>)[];
}
export type SearchTextAdditionalFeature = "TimeZone" | "Phonemes" | "Access" | "Contact" | "CrossReferences" | (string & {});
export type SearchTextAdditionalFeatureList = SearchTextAdditionalFeature[];
export type SearchTextIntendedUse = "SingleUse" | "Storage" | (string & {});
export type SearchTextTravelMode = "Car" | "Scooter" | "Truck" | (string & {});
export interface SearchTextRequest {
    QueryText?: string | redacted.Redacted<string>;
    QueryId?: string | redacted.Redacted<string>;
    MaxResults?: number;
    BiasPosition?: number[];
    Filter?: SearchTextFilter;
    AdditionalFeatures?: SearchTextAdditionalFeature[];
    Language?: string;
    PoliticalView?: string | redacted.Redacted<string>;
    IntendedUse?: SearchTextIntendedUse;
    NextToken?: string;
    TravelMode?: SearchTextTravelMode;
    Key?: string | redacted.Redacted<string>;
}
export interface SearchTextResultItem {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    Address?: Address;
    AddressNumberCorrected?: boolean;
    Position?: number[];
    Distance?: number;
    MapView?: number[];
    Categories?: Category[];
    FoodTypes?: FoodType[];
    BusinessChains?: BusinessChain[];
    Contacts?: Contacts;
    OpeningHours?: OpeningHours[];
    AccessPoints?: AccessPoint[];
    AccessRestrictions?: AccessRestriction[];
    TimeZone?: TimeZone;
    PoliticalView?: string | redacted.Redacted<string>;
    Phonemes?: PhonemeDetails;
    PlaceAttributes?: PlaceAttribute[];
    CrossReferences?: CrossReference[];
}
export type SearchTextResultItemList = SearchTextResultItem[];
export interface SearchTextResponse {
    PricingBucket: string;
    ResultItems?: SearchTextResultItem[];
    NextToken?: string;
}
export interface SuggestFilter {
    BoundingBox?: number[];
    Circle?: FilterCircle;
    IncludeCountries?: (string | redacted.Redacted<string>)[];
}
export type SuggestAdditionalFeature = "Core" | "TimeZone" | "Phonemes" | "Access" | "CrossReferences" | (string & {});
export type SuggestAdditionalFeatureList = SuggestAdditionalFeature[];
export type SuggestIntendedUse = "SingleUse" | (string & {});
export type SuggestTravelMode = "Car" | "Scooter" | "Truck" | (string & {});
export interface SuggestRequest {
    QueryText: string | redacted.Redacted<string>;
    MaxResults?: number;
    MaxQueryRefinements?: number;
    BiasPosition?: number[];
    Filter?: SuggestFilter;
    AdditionalFeatures?: SuggestAdditionalFeature[];
    Language?: string;
    PoliticalView?: string | redacted.Redacted<string>;
    IntendedUse?: SuggestIntendedUse;
    TravelMode?: SuggestTravelMode;
    Key?: string | redacted.Redacted<string>;
}
export type SuggestResultItemType = "Place" | "Query" | (string & {});
export interface SuggestPlaceResult {
    PlaceId?: string | redacted.Redacted<string>;
    PlaceType?: PlaceType;
    Address?: Address;
    Position?: number[];
    Distance?: number;
    MapView?: number[];
    Categories?: Category[];
    FoodTypes?: FoodType[];
    BusinessChains?: BusinessChain[];
    AccessPoints?: AccessPoint[];
    AccessRestrictions?: AccessRestriction[];
    TimeZone?: TimeZone;
    PoliticalView?: string | redacted.Redacted<string>;
    Phonemes?: PhonemeDetails;
    PlaceAttributes?: PlaceAttribute[];
    CrossReferences?: CrossReference[];
}
export type QueryType = "Category" | "BusinessChain" | (string & {});
export interface SuggestQueryResult {
    QueryId?: string | redacted.Redacted<string>;
    QueryType?: QueryType;
}
export interface SuggestAddressHighlights {
    Label?: Highlight[];
}
export interface SuggestHighlights {
    Title?: Highlight[];
    Address?: SuggestAddressHighlights;
}
export interface SuggestResultItem {
    Title: string | redacted.Redacted<string>;
    SuggestResultItemType: SuggestResultItemType;
    Place?: SuggestPlaceResult;
    Query?: SuggestQueryResult;
    Highlights?: SuggestHighlights;
}
export type SuggestResultItemList = SuggestResultItem[];
export interface QueryRefinement {
    RefinedTerm: string | redacted.Redacted<string>;
    OriginalTerm: string | redacted.Redacted<string>;
    StartIndex: number;
    EndIndex: number;
}
export type QueryRefinementList = QueryRefinement[];
export interface SuggestResponse {
    PricingBucket: string;
    ResultItems?: SuggestResultItem[];
    QueryRefinements?: QueryRefinement[];
}
export type ValidationExceptionReason = "UnknownOperation" | "Missing" | "CannotParse" | "FieldValidationFailed" | "Other" | "UnknownField" | (string & {});
export interface ValidationExceptionField {
    Name: string;
    Message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AutocompleteError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `Autocomplete` completes potential places and addresses as the user types, based on the partial input. The API enhances the efficiency and accuracy of address by completing query based on a few entered keystrokes. It helps you by completing partial queries with valid address completion. Also, the API supports the filtering of results based on geographic location, country, or specific place types, and can be tailored using optional parameters like language and political views. Not supported in `ap-southeast-1` and `ap-southeast-5` regions for GrabMaps customers.
 *
 * For more information, see Autocomplete in the *Amazon Location Service Developer Guide*.
 */
export declare const autocomplete: API.OperationMethod<AutocompleteRequest, AutocompleteResponse, AutocompleteError, Credentials | HttpClient.HttpClient>;
export type GeocodeError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `Geocode` converts a textual address or place into geographic coordinates. You can obtain geographic coordinates, address component, and other related information. It supports flexible queries, including free-form text or structured queries with components like street names, postal codes, and regions. The Geocode API can also provide additional features such as time zone information and the inclusion of political views. Not supported in `ap-southeast-1` and `ap-southeast-5` regions for GrabMaps customers.
 *
 * For more information, see Geocode in the *Amazon Location Service Developer Guide*.
 */
export declare const geocode: API.OperationMethod<GeocodeRequest, GeocodeResponse, GeocodeError, Credentials | HttpClient.HttpClient>;
export type GetPlaceError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `GetPlace` finds a place by its unique ID. A `PlaceId` is returned by other place operations.
 *
 * For more information, see GetPlace in the *Amazon Location Service Developer Guide*.
 */
export declare const getPlace: API.OperationMethod<GetPlaceRequest, GetPlaceResponse, GetPlaceError, Credentials | HttpClient.HttpClient>;
export type ReverseGeocodeError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `ReverseGeocode` converts geographic coordinates into a human-readable address or place. You can obtain address component, and other related information such as place type, category, street information. The Reverse Geocode API supports filtering to on place type so that you can refine result based on your need. Also, The Reverse Geocode API can also provide additional features such as time zone information and the inclusion of political views.
 *
 * For more information, see Reverse Geocode in the *Amazon Location Service Developer Guide*.
 */
export declare const reverseGeocode: API.OperationMethod<ReverseGeocodeRequest, ReverseGeocodeResponse, ReverseGeocodeError, Credentials | HttpClient.HttpClient>;
export type SearchNearbyError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `SearchNearby` queries for points of interest within a radius from a central coordinates, returning place results with optional filters such as categories, business chains, food types and more. The API returns details such as a place name, address, phone, category, food type, contact, opening hours. Also, the API can return phonemes, time zones and more based on requested parameters. Not supported in `ap-southeast-1` and `ap-southeast-5` regions for GrabMaps customers.
 *
 * For more information, see Search Nearby in the *Amazon Location Service Developer Guide*.
 */
export declare const searchNearby: API.OperationMethod<SearchNearbyRequest, SearchNearbyResponse, SearchNearbyError, Credentials | HttpClient.HttpClient>;
export type SearchTextError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `SearchText` searches for geocode and place information. You can then complete a follow-up query suggested from the `Suggest` API via a query id.
 *
 * For more information, see Search Text in the *Amazon Location Service Developer Guide*.
 */
export declare const searchText: API.OperationMethod<SearchTextRequest, SearchTextResponse, SearchTextError, Credentials | HttpClient.HttpClient>;
export type SuggestError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `Suggest` provides intelligent predictions or recommendations based on the user's input or context, such as relevant places, points of interest, query terms or search category. It is designed to help users find places or point of interests candidates or identify a follow on query based on incomplete or misspelled queries. It returns a list of possible matches or refinements that can be used to formulate a more accurate query. Users can select the most appropriate suggestion and use it for further searching. The API provides options for filtering results by location and other attributes, and allows for additional features like phonemes and timezones. The response includes refined query terms and detailed place information.
 *
 * For more information, see Suggest in the *Amazon Location Service Developer Guide*.
 */
export declare const suggest: API.OperationMethod<SuggestRequest, SuggestResponse, SuggestError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=geo-places.d.ts.map