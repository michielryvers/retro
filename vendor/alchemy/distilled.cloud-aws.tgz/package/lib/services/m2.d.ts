import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ExecutionTimeoutException_base: S.TaggedErrorClass<"ExecutionTimeoutException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ExecutionTimeoutException extends /*@__PURE__*/ ExecutionTimeoutException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Identifier = string;
export type AuthSecretsManagerArn = string;
export interface CancelBatchJobExecutionRequest {
    applicationId: string;
    executionId: string;
    authSecretsManagerArn?: string;
}
export interface CancelBatchJobExecutionResponse {
}
export type EntityName = string;
export type EntityDescription = string;
export type EngineType = string;
export type String2000 = string;
export type StringFree65000 = string;
export type Definition = {
    s3Location: string;
    content?: never;
} | {
    s3Location?: never;
    content: string;
};
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type ClientToken = string;
export type Arn = string;
export interface CreateApplicationRequest {
    name: string;
    description?: string;
    engineType: string;
    definition: Definition;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
    kmsKeyId?: string;
    roleArn?: string;
}
export type Version = number;
export interface CreateApplicationResponse {
    applicationArn: string;
    applicationId: string;
    applicationVersion: number;
}
export type String200 = string;
export type ExternalLocation = {
    s3Location: string;
};
export interface DataSetExportItem {
    datasetName: string;
    externalLocation: ExternalLocation;
}
export type DataSetExportList = DataSetExportItem[];
export type DataSetExportConfig = {
    s3Location: string;
    dataSets?: never;
} | {
    s3Location?: never;
    dataSets: DataSetExportItem[];
};
export type KMSKeyId = string;
export interface CreateDataSetExportTaskRequest {
    applicationId: string;
    exportConfig: DataSetExportConfig;
    clientToken?: string;
    kmsKeyId?: string;
}
export interface CreateDataSetExportTaskResponse {
    taskId: string;
}
export interface PrimaryKey {
    name?: string;
    offset: number;
    length: number;
}
export interface AlternateKey {
    name?: string;
    offset: number;
    length: number;
    allowDuplicates?: boolean;
}
export type AlternateKeyList = AlternateKey[];
export interface VsamAttributes {
    format: string;
    encoding?: string;
    compressed?: boolean;
    primaryKey?: PrimaryKey;
    alternateKeys?: AlternateKey[];
}
export interface GdgAttributes {
    limit?: number;
    rollDisposition?: string;
}
export type String20 = string;
export type String20List = string[];
export interface PoAttributes {
    format: string;
    encoding?: string;
    memberFileExtensions: string[];
}
export interface PsAttributes {
    format: string;
    encoding?: string;
}
export type DatasetOrgAttributes = {
    vsam: VsamAttributes;
    gdg?: never;
    po?: never;
    ps?: never;
} | {
    vsam?: never;
    gdg: GdgAttributes;
    po?: never;
    ps?: never;
} | {
    vsam?: never;
    gdg?: never;
    po: PoAttributes;
    ps?: never;
} | {
    vsam?: never;
    gdg?: never;
    po?: never;
    ps: PsAttributes;
};
export interface RecordLength {
    min: number;
    max: number;
}
export interface DataSet {
    storageType?: string;
    datasetName: string;
    datasetOrg: DatasetOrgAttributes;
    relativePath?: string;
    recordLength: RecordLength;
}
export interface DataSetImportItem {
    dataSet: DataSet;
    externalLocation: ExternalLocation;
}
export type DataSetImportList = DataSetImportItem[];
export type DataSetImportConfig = {
    s3Location: string;
    dataSets?: never;
} | {
    s3Location?: never;
    dataSets: DataSetImportItem[];
};
export interface CreateDataSetImportTaskRequest {
    applicationId: string;
    importConfig: DataSetImportConfig;
    clientToken?: string;
}
export interface CreateDataSetImportTaskResponse {
    taskId: string;
}
export interface CreateDeploymentRequest {
    environmentId: string;
    applicationId: string;
    applicationVersion: number;
    clientToken?: string;
}
export interface CreateDeploymentResponse {
    deploymentId: string;
}
export type EngineVersion = string;
export type String50 = string;
export type String50List = string[];
export interface EfsStorageConfiguration {
    fileSystemId: string;
    mountPoint: string;
}
export interface FsxStorageConfiguration {
    fileSystemId: string;
    mountPoint: string;
}
export type StorageConfiguration = {
    efs: EfsStorageConfiguration;
    fsx?: never;
} | {
    efs?: never;
    fsx: FsxStorageConfiguration;
};
export type StorageConfigurationList = StorageConfiguration[];
export type CapacityValue = number;
export interface HighAvailabilityConfig {
    desiredCapacity: number;
}
export type NetworkType = string;
export interface CreateEnvironmentRequest {
    name: string;
    instanceType: string;
    description?: string;
    engineType: string;
    engineVersion?: string;
    subnetIds?: string[];
    securityGroupIds?: string[];
    storageConfigurations?: StorageConfiguration[];
    publiclyAccessible?: boolean;
    highAvailabilityConfig?: HighAvailabilityConfig;
    tags?: {
        [key: string]: string | undefined;
    };
    preferredMaintenanceWindow?: string;
    networkType?: string;
    clientToken?: string;
    kmsKeyId?: string;
}
export interface CreateEnvironmentResponse {
    environmentId: string;
}
export interface DeleteApplicationRequest {
    applicationId: string;
}
export interface DeleteApplicationResponse {
}
export interface DeleteApplicationFromEnvironmentRequest {
    applicationId: string;
    environmentId: string;
}
export interface DeleteApplicationFromEnvironmentResponse {
}
export interface DeleteEnvironmentRequest {
    environmentId: string;
}
export interface DeleteEnvironmentResponse {
}
export interface GetApplicationRequest {
    applicationId: string;
}
export type ApplicationLifecycle = string;
export type ApplicationVersionLifecycle = string;
export interface ApplicationVersionSummary {
    applicationVersion: number;
    status: string;
    statusReason?: string;
    creationTime: Date;
}
export type DeploymentLifecycle = string;
export interface DeployedVersionSummary {
    applicationVersion: number;
    status: string;
    statusReason?: string;
}
export type LogGroupIdentifier = string;
export interface LogGroupSummary {
    logType: string;
    logGroupName: string;
}
export type LogGroupSummaries = LogGroupSummary[];
export type ArnList = string[];
export type PortList = number[];
export type String100 = string;
export interface GetApplicationResponse {
    name: string;
    description?: string;
    applicationId: string;
    applicationArn: string;
    status: string;
    latestVersion: ApplicationVersionSummary;
    deployedVersion?: DeployedVersionSummary;
    engineType: string;
    logGroups?: LogGroupSummary[];
    creationTime: Date;
    lastStartTime?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    environmentId?: string;
    targetGroupArns?: string[];
    listenerArns?: string[];
    listenerPorts?: number[];
    loadBalancerDnsName?: string;
    statusReason?: string;
    kmsKeyId?: string;
    roleArn?: string;
}
export interface GetApplicationVersionRequest {
    applicationId: string;
    applicationVersion: number;
}
export interface GetApplicationVersionResponse {
    name: string;
    applicationVersion: number;
    description?: string;
    definitionContent: string;
    status: string;
    creationTime: Date;
    statusReason?: string;
}
export interface GetBatchJobExecutionRequest {
    applicationId: string;
    executionId: string;
}
export type BatchJobType = string;
export type BatchJobExecutionStatus = string;
export interface FileBatchJobIdentifier {
    fileName: string;
    folderPath?: string;
}
export interface ScriptBatchJobIdentifier {
    scriptName: string;
}
export type JobIdentifier = {
    fileName: string;
    scriptName?: never;
} | {
    fileName?: never;
    scriptName: string;
};
export interface S3BatchJobIdentifier {
    bucket: string;
    keyPrefix?: string;
    identifier: JobIdentifier;
}
export interface JobStepRestartMarker {
    fromStep: string;
    fromProcStep?: string;
    toStep?: string;
    toProcStep?: string;
    stepCheckpoint?: number;
    skip?: boolean;
}
export interface RestartBatchJobIdentifier {
    executionId: string;
    jobStepRestartMarker: JobStepRestartMarker;
}
export type BatchJobIdentifier = {
    fileBatchJobIdentifier: FileBatchJobIdentifier;
    scriptBatchJobIdentifier?: never;
    s3BatchJobIdentifier?: never;
    restartBatchJobIdentifier?: never;
} | {
    fileBatchJobIdentifier?: never;
    scriptBatchJobIdentifier: ScriptBatchJobIdentifier;
    s3BatchJobIdentifier?: never;
    restartBatchJobIdentifier?: never;
} | {
    fileBatchJobIdentifier?: never;
    scriptBatchJobIdentifier?: never;
    s3BatchJobIdentifier: S3BatchJobIdentifier;
    restartBatchJobIdentifier?: never;
} | {
    fileBatchJobIdentifier?: never;
    scriptBatchJobIdentifier?: never;
    s3BatchJobIdentifier?: never;
    restartBatchJobIdentifier: RestartBatchJobIdentifier;
};
export interface GetBatchJobExecutionResponse {
    executionId: string;
    applicationId: string;
    jobId?: string;
    jobName?: string;
    jobUser?: string;
    jobType?: string;
    status: string;
    startTime: Date;
    endTime?: Date;
    statusReason?: string;
    returnCode?: string;
    batchJobIdentifier?: BatchJobIdentifier;
    jobStepRestartMarker?: JobStepRestartMarker;
}
export interface GetDataSetDetailsRequest {
    applicationId: string;
    dataSetName: string;
}
export interface VsamDetailAttributes {
    encoding?: string;
    recordFormat?: string;
    compressed?: boolean;
    cacheAtStartup?: boolean;
    primaryKey?: PrimaryKey;
    alternateKeys?: AlternateKey[];
}
export interface GdgDetailAttributes {
    limit?: number;
    rollDisposition?: string;
}
export interface PoDetailAttributes {
    format: string;
    encoding: string;
}
export interface PsDetailAttributes {
    format: string;
    encoding: string;
}
export type DatasetDetailOrgAttributes = {
    vsam: VsamDetailAttributes;
    gdg?: never;
    po?: never;
    ps?: never;
} | {
    vsam?: never;
    gdg: GdgDetailAttributes;
    po?: never;
    ps?: never;
} | {
    vsam?: never;
    gdg?: never;
    po: PoDetailAttributes;
    ps?: never;
} | {
    vsam?: never;
    gdg?: never;
    po?: never;
    ps: PsDetailAttributes;
};
export interface GetDataSetDetailsResponse {
    dataSetName: string;
    dataSetOrg?: DatasetDetailOrgAttributes;
    recordLength?: number;
    location?: string;
    blocksize?: number;
    creationTime?: Date;
    lastUpdatedTime?: Date;
    lastReferencedTime?: Date;
    fileSize?: number;
}
export interface GetDataSetExportTaskRequest {
    applicationId: string;
    taskId: string;
}
export type DataSetTaskLifecycle = string;
export interface DataSetExportSummary {
    total: number;
    succeeded: number;
    failed: number;
    pending: number;
    inProgress: number;
}
export interface GetDataSetExportTaskResponse {
    taskId: string;
    status: string;
    summary?: DataSetExportSummary;
    statusReason?: string;
    kmsKeyArn?: string;
}
export interface GetDataSetImportTaskRequest {
    applicationId: string;
    taskId: string;
}
export interface DataSetImportSummary {
    total: number;
    succeeded: number;
    failed: number;
    pending: number;
    inProgress: number;
}
export interface GetDataSetImportTaskResponse {
    taskId: string;
    status: string;
    summary?: DataSetImportSummary;
}
export interface GetDeploymentRequest {
    deploymentId: string;
    applicationId: string;
}
export interface GetDeploymentResponse {
    deploymentId: string;
    applicationId: string;
    environmentId: string;
    applicationVersion: number;
    status: string;
    creationTime: Date;
    statusReason?: string;
}
export interface GetEnvironmentRequest {
    environmentId: string;
}
export type EnvironmentLifecycle = string;
export interface MaintenanceSchedule {
    startTime?: Date;
    endTime?: Date;
}
export interface PendingMaintenance {
    schedule?: MaintenanceSchedule;
    engineVersion?: string;
}
export interface GetEnvironmentResponse {
    name: string;
    description?: string;
    environmentArn: string;
    environmentId: string;
    instanceType: string;
    status: string;
    engineType: string;
    engineVersion: string;
    vpcId: string;
    subnetIds: string[];
    securityGroupIds: string[];
    creationTime: Date;
    storageConfigurations?: StorageConfiguration[];
    tags?: {
        [key: string]: string | undefined;
    };
    highAvailabilityConfig?: HighAvailabilityConfig;
    publiclyAccessible?: boolean;
    actualCapacity?: number;
    loadBalancerArn?: string;
    statusReason?: string;
    preferredMaintenanceWindow?: string;
    pendingMaintenance?: PendingMaintenance;
    kmsKeyId?: string;
    networkType?: string;
}
export interface GetSignedBluinsightsUrlRequest {
}
export interface GetSignedBluinsightsUrlResponse {
    signedBiUrl: string;
}
export type NextToken = string;
export type MaxResults = number;
export type EntityNameList = string[];
export interface ListApplicationsRequest {
    nextToken?: string;
    maxResults?: number;
    names?: string[];
    environmentId?: string;
}
export type ApplicationDeploymentLifecycle = string;
export interface ApplicationSummary {
    name: string;
    description?: string;
    applicationId: string;
    applicationArn: string;
    applicationVersion: number;
    status: string;
    engineType: string;
    creationTime: Date;
    environmentId?: string;
    lastStartTime?: Date;
    versionStatus?: string;
    deploymentStatus?: string;
    roleArn?: string;
}
export type ApplicationSummaryList = ApplicationSummary[];
export interface ListApplicationsResponse {
    applications: ApplicationSummary[];
    nextToken?: string;
}
export interface ListApplicationVersionsRequest {
    nextToken?: string;
    maxResults?: number;
    applicationId: string;
}
export type ApplicationVersionSummaryList = ApplicationVersionSummary[];
export interface ListApplicationVersionsResponse {
    applicationVersions: ApplicationVersionSummary[];
    nextToken?: string;
}
export interface ListBatchJobDefinitionsRequest {
    nextToken?: string;
    maxResults?: number;
    applicationId: string;
    prefix?: string;
}
export interface FileBatchJobDefinition {
    fileName: string;
    folderPath?: string;
}
export interface ScriptBatchJobDefinition {
    scriptName: string;
}
export type BatchJobDefinition = {
    fileBatchJobDefinition: FileBatchJobDefinition;
    scriptBatchJobDefinition?: never;
} | {
    fileBatchJobDefinition?: never;
    scriptBatchJobDefinition: ScriptBatchJobDefinition;
};
export type BatchJobDefinitions = BatchJobDefinition[];
export interface ListBatchJobDefinitionsResponse {
    batchJobDefinitions: BatchJobDefinition[];
    nextToken?: string;
}
export type IdentifierList = string[];
export interface ListBatchJobExecutionsRequest {
    nextToken?: string;
    maxResults?: number;
    applicationId: string;
    executionIds?: string[];
    jobName?: string;
    status?: string;
    startedAfter?: Date;
    startedBefore?: Date;
}
export interface BatchJobExecutionSummary {
    executionId: string;
    applicationId: string;
    jobId?: string;
    jobName?: string;
    jobType?: string;
    status: string;
    startTime: Date;
    endTime?: Date;
    returnCode?: string;
    batchJobIdentifier?: BatchJobIdentifier;
}
export type BatchJobExecutionSummaryList = BatchJobExecutionSummary[];
export interface ListBatchJobExecutionsResponse {
    batchJobExecutions: BatchJobExecutionSummary[];
    nextToken?: string;
}
export interface ListBatchJobRestartPointsRequest {
    applicationId: string;
    executionId: string;
    authSecretsManagerArn?: string;
}
export interface JobStep {
    stepNumber?: number;
    stepName?: string;
    procStepNumber?: number;
    procStepName?: string;
    stepCondCode?: string;
    stepRestartable?: boolean;
    stepCheckpoint?: number;
    stepCheckpointStatus?: string;
    stepCheckpointTime?: Date;
}
export type BatchJobStepList = JobStep[];
export interface ListBatchJobRestartPointsResponse {
    batchJobSteps?: JobStep[];
}
export interface ListDataSetExportHistoryRequest {
    nextToken?: string;
    maxResults?: number;
    applicationId: string;
}
export interface DataSetExportTask {
    taskId: string;
    status: string;
    summary: DataSetExportSummary;
    statusReason?: string;
}
export type DataSetExportTaskList = DataSetExportTask[];
export interface ListDataSetExportHistoryResponse {
    dataSetExportTasks: DataSetExportTask[];
    nextToken?: string;
}
export interface ListDataSetImportHistoryRequest {
    nextToken?: string;
    maxResults?: number;
    applicationId: string;
}
export interface DataSetImportTask {
    taskId: string;
    status: string;
    summary: DataSetImportSummary;
    statusReason?: string;
}
export type DataSetImportTaskList = DataSetImportTask[];
export interface ListDataSetImportHistoryResponse {
    dataSetImportTasks: DataSetImportTask[];
    nextToken?: string;
}
export interface ListDataSetsRequest {
    applicationId: string;
    nextToken?: string;
    maxResults?: number;
    prefix?: string;
    nameFilter?: string;
}
export interface DataSetSummary {
    dataSetName: string;
    dataSetOrg?: string;
    format?: string;
    creationTime?: Date;
    lastUpdatedTime?: Date;
    lastReferencedTime?: Date;
}
export type DataSetsSummaryList = DataSetSummary[];
export interface ListDataSetsResponse {
    dataSets: DataSetSummary[];
    nextToken?: string;
}
export interface ListDeploymentsRequest {
    nextToken?: string;
    maxResults?: number;
    applicationId: string;
}
export interface DeploymentSummary {
    deploymentId: string;
    applicationId: string;
    environmentId: string;
    applicationVersion: number;
    status: string;
    creationTime: Date;
    statusReason?: string;
}
export type DeploymentList = DeploymentSummary[];
export interface ListDeploymentsResponse {
    deployments: DeploymentSummary[];
    nextToken?: string;
}
export interface ListEngineVersionsRequest {
    engineType?: string;
    nextToken?: string;
    maxResults?: number;
}
export interface EngineVersionsSummary {
    engineType: string;
    engineVersion: string;
}
export type EngineVersionsSummaryList = EngineVersionsSummary[];
export interface ListEngineVersionsResponse {
    engineVersions: EngineVersionsSummary[];
    nextToken?: string;
}
export interface ListEnvironmentsRequest {
    nextToken?: string;
    maxResults?: number;
    names?: string[];
    engineType?: string;
}
export interface EnvironmentSummary {
    name: string;
    environmentArn: string;
    environmentId: string;
    instanceType: string;
    status: string;
    engineType: string;
    engineVersion: string;
    creationTime: Date;
    networkType?: string;
}
export type EnvironmentSummaryList = EnvironmentSummary[];
export interface ListEnvironmentsResponse {
    environments: EnvironmentSummary[];
    nextToken?: string;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags: {
        [key: string]: string | undefined;
    };
}
export interface StartApplicationRequest {
    applicationId: string;
}
export interface StartApplicationResponse {
}
export type BatchParamKey = string;
export type BatchParamValue = string;
export type BatchJobParametersMap = {
    [key: string]: string | undefined;
};
export interface StartBatchJobRequest {
    applicationId: string;
    batchJobIdentifier: BatchJobIdentifier;
    jobParams?: {
        [key: string]: string | undefined;
    };
    authSecretsManagerArn?: string;
}
export interface StartBatchJobResponse {
    executionId: string;
}
export interface StopApplicationRequest {
    applicationId: string;
    forceStop?: boolean;
}
export interface StopApplicationResponse {
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateApplicationRequest {
    applicationId: string;
    description?: string;
    currentApplicationVersion: number;
    definition?: Definition;
}
export interface UpdateApplicationResponse {
    applicationVersion: number;
}
export interface UpdateEnvironmentRequest {
    environmentId: string;
    desiredCapacity?: number;
    instanceType?: string;
    engineVersion?: string;
    preferredMaintenanceWindow?: string;
    applyDuringMaintenanceWindow?: boolean;
    forceUpdate?: boolean;
}
export interface UpdateEnvironmentResponse {
    environmentId: string;
}
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type CancelBatchJobExecutionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels the running of a specific batch job execution.
 */
export declare const cancelBatchJobExecution: API.OperationMethod<CancelBatchJobExecutionRequest, CancelBatchJobExecutionResponse, CancelBatchJobExecutionError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new application with given parameters. Requires an existing runtime
 * environment and application definition file.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateDataSetExportTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a data set export task for a specific application.
 */
export declare const createDataSetExportTask: API.OperationMethod<CreateDataSetExportTaskRequest, CreateDataSetExportTaskResponse, CreateDataSetExportTaskError, Credentials | HttpClient.HttpClient>;
export type CreateDataSetImportTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a data set import task for a specific application.
 */
export declare const createDataSetImportTask: API.OperationMethod<CreateDataSetImportTaskRequest, CreateDataSetImportTaskResponse, CreateDataSetImportTaskError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates and starts a deployment to deploy an application into a runtime
 * environment.
 */
export declare const createDeployment: API.OperationMethod<CreateDeploymentRequest, CreateDeploymentResponse, CreateDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a runtime environment for a given runtime engine.
 */
export declare const createEnvironment: API.OperationMethod<CreateEnvironmentRequest, CreateEnvironmentResponse, CreateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specific application. You cannot delete a running application.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationFromEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specific application from the specific runtime environment where it was
 * previously deployed. You cannot delete a runtime environment using DeleteEnvironment if any
 * application has ever been deployed to it. This API removes the association of the
 * application with the runtime environment so you can delete the environment smoothly.
 */
export declare const deleteApplicationFromEnvironment: API.OperationMethod<DeleteApplicationFromEnvironmentRequest, DeleteApplicationFromEnvironmentResponse, DeleteApplicationFromEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specific runtime environment. The environment cannot contain deployed
 * applications. If it does, you must delete those applications before you delete the
 * environment.
 */
export declare const deleteEnvironment: API.OperationMethod<DeleteEnvironmentRequest, DeleteEnvironmentResponse, DeleteEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the details of a specific application.
 */
export declare const getApplication: API.OperationMethod<GetApplicationRequest, GetApplicationResponse, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetApplicationVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details about a specific version of a specific application.
 */
export declare const getApplicationVersion: API.OperationMethod<GetApplicationVersionRequest, GetApplicationVersionResponse, GetApplicationVersionError, Credentials | HttpClient.HttpClient>;
export type GetBatchJobExecutionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of a specific batch job execution for a specific application.
 */
export declare const getBatchJobExecution: API.OperationMethod<GetBatchJobExecutionRequest, GetBatchJobExecutionResponse, GetBatchJobExecutionError, Credentials | HttpClient.HttpClient>;
export type GetDataSetDetailsError = AccessDeniedException | ConflictException | ExecutionTimeoutException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of a specific data set.
 */
export declare const getDataSetDetails: API.OperationMethod<GetDataSetDetailsRequest, GetDataSetDetailsResponse, GetDataSetDetailsError, Credentials | HttpClient.HttpClient>;
export type GetDataSetExportTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the status of a data set import task initiated with the CreateDataSetExportTask operation.
 */
export declare const getDataSetExportTask: API.OperationMethod<GetDataSetExportTaskRequest, GetDataSetExportTaskResponse, GetDataSetExportTaskError, Credentials | HttpClient.HttpClient>;
export type GetDataSetImportTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the status of a data set import task initiated with the CreateDataSetImportTask operation.
 */
export declare const getDataSetImportTask: API.OperationMethod<GetDataSetImportTaskRequest, GetDataSetImportTaskResponse, GetDataSetImportTaskError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets details of a specific deployment with a given deployment identifier.
 */
export declare const getDeployment: API.OperationMethod<GetDeploymentRequest, GetDeploymentResponse, GetDeploymentError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes a specific runtime environment.
 */
export declare const getEnvironment: API.OperationMethod<GetEnvironmentRequest, GetEnvironmentResponse, GetEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetSignedBluinsightsUrlError = AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Gets a single sign-on URL that can be used to connect to AWS Blu Insights.
 */
export declare const getSignedBluinsightsUrl: API.OperationMethod<GetSignedBluinsightsUrlRequest, GetSignedBluinsightsUrlResponse, GetSignedBluinsightsUrlError, Credentials | HttpClient.HttpClient>;
export type ListApplicationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the applications associated with a specific Amazon Web Services account. You can provide the
 * unique identifier of a specific runtime environment in a query parameter to see all
 * applications associated with that environment.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationSummary>;
export type ListApplicationVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the application versions for a specific application.
 */
export declare const listApplicationVersions: API.PaginatedOperationMethod<ListApplicationVersionsRequest, ListApplicationVersionsResponse, ListApplicationVersionsError, Credentials | HttpClient.HttpClient, ApplicationVersionSummary>;
export type ListBatchJobDefinitionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the available batch job definitions based on the batch job resources uploaded
 * during the application creation. You can use the batch job definitions in the list to start
 * a batch job.
 */
export declare const listBatchJobDefinitions: API.PaginatedOperationMethod<ListBatchJobDefinitionsRequest, ListBatchJobDefinitionsResponse, ListBatchJobDefinitionsError, Credentials | HttpClient.HttpClient, BatchJobDefinition>;
export type ListBatchJobExecutionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists historical, current, and scheduled batch job executions for a specific
 * application.
 */
export declare const listBatchJobExecutions: API.PaginatedOperationMethod<ListBatchJobExecutionsRequest, ListBatchJobExecutionsResponse, ListBatchJobExecutionsError, Credentials | HttpClient.HttpClient, BatchJobExecutionSummary>;
export type ListBatchJobRestartPointsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the job steps for a JCL file to restart a batch job. This is only applicable for Micro Focus engine with versions 8.0.6 and above.
 */
export declare const listBatchJobRestartPoints: API.OperationMethod<ListBatchJobRestartPointsRequest, ListBatchJobRestartPointsResponse, ListBatchJobRestartPointsError, Credentials | HttpClient.HttpClient>;
export type ListDataSetExportHistoryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the data set exports for the specified application.
 */
export declare const listDataSetExportHistory: API.PaginatedOperationMethod<ListDataSetExportHistoryRequest, ListDataSetExportHistoryResponse, ListDataSetExportHistoryError, Credentials | HttpClient.HttpClient, DataSetExportTask>;
export type ListDataSetImportHistoryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the data set imports for the specified application.
 */
export declare const listDataSetImportHistory: API.PaginatedOperationMethod<ListDataSetImportHistoryRequest, ListDataSetImportHistoryResponse, ListDataSetImportHistoryError, Credentials | HttpClient.HttpClient, DataSetImportTask>;
export type ListDataSetsError = AccessDeniedException | ConflictException | ExecutionTimeoutException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the data sets imported for a specific application. In Amazon Web Services Mainframe Modernization, data sets are
 * associated with applications deployed on runtime environments. This is known as importing
 * data sets. Currently, Amazon Web Services Mainframe Modernization can import data sets into catalogs using CreateDataSetImportTask.
 */
export declare const listDataSets: API.PaginatedOperationMethod<ListDataSetsRequest, ListDataSetsResponse, ListDataSetsError, Credentials | HttpClient.HttpClient, DataSetSummary>;
export type ListDeploymentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all deployments of a specific application. A deployment is a
 * combination of a specific application and a specific version of that application. Each
 * deployment is mapped to a particular application version.
 */
export declare const listDeployments: API.PaginatedOperationMethod<ListDeploymentsRequest, ListDeploymentsResponse, ListDeploymentsError, Credentials | HttpClient.HttpClient, DeploymentSummary>;
export type ListEngineVersionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the available engine versions.
 */
export declare const listEngineVersions: API.PaginatedOperationMethod<ListEngineVersionsRequest, ListEngineVersionsResponse, ListEngineVersionsError, Credentials | HttpClient.HttpClient, EngineVersionsSummary>;
export type ListEnvironmentsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the runtime environments.
 */
export declare const listEnvironments: API.PaginatedOperationMethod<ListEnvironmentsRequest, ListEnvironmentsResponse, ListEnvironmentsError, Credentials | HttpClient.HttpClient, EnvironmentSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts an application that is currently stopped.
 */
export declare const startApplication: API.OperationMethod<StartApplicationRequest, StartApplicationResponse, StartApplicationError, Credentials | HttpClient.HttpClient>;
export type StartBatchJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a batch job and returns the unique identifier of this execution of the batch job.
 * The associated application must be running in order to start the batch job.
 */
export declare const startBatchJob: API.OperationMethod<StartBatchJobRequest, StartBatchJobResponse, StartBatchJobError, Credentials | HttpClient.HttpClient>;
export type StopApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a running application.
 */
export declare const stopApplication: API.OperationMethod<StopApplicationRequest, StopApplicationResponse, StopApplicationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds one or more tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an application and creates a new version.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration details for a specific runtime environment.
 */
export declare const updateEnvironment: API.OperationMethod<UpdateEnvironmentRequest, UpdateEnvironmentResponse, UpdateEnvironmentError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=m2.d.ts.map