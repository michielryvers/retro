import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BaseException_base: S.TaggedErrorClass<"BaseException", {
    readonly message: any;
}>;
export declare class BaseException extends /*@__PURE__*/ BaseException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DependencyFailureException_base: S.TaggedErrorClass<"DependencyFailureException", {
    readonly message: any;
}>;
export declare class DependencyFailureException extends /*@__PURE__*/ DependencyFailureException_base {
}
declare const DisabledOperationException_base: S.TaggedErrorClass<"DisabledOperationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DisabledOperationException extends /*@__PURE__*/ DisabledOperationException_base {
}
declare const InternalException_base: S.TaggedErrorClass<"InternalException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalException extends /*@__PURE__*/ InternalException_base {
}
declare const InvalidPaginationTokenException_base: S.TaggedErrorClass<"InvalidPaginationTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidPaginationTokenException extends /*@__PURE__*/ InvalidPaginationTokenException_base {
}
declare const InvalidTypeException_base: S.TaggedErrorClass<"InvalidTypeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidTypeException extends /*@__PURE__*/ InvalidTypeException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const SlotNotAvailableException_base: S.TaggedErrorClass<"SlotNotAvailableException", {
    readonly SlotSuggestions: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class SlotNotAvailableException extends /*@__PURE__*/ SlotNotAvailableException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ConnectionId = string;
export interface AcceptInboundConnectionRequest {
    ConnectionId: string;
}
export type OwnerId = string;
export type DomainName = string;
export type Region = string;
export interface AWSDomainInformation {
    OwnerId?: string;
    DomainName: string;
    Region?: string;
}
export interface DomainInformationContainer {
    AWSDomainInformation?: AWSDomainInformation;
}
export type InboundConnectionStatusCode = "PENDING_ACCEPTANCE" | "APPROVED" | "PROVISIONING" | "ACTIVE" | "REJECTING" | "REJECTED" | "DELETING" | "DELETED" | (string & {});
export type ConnectionStatusMessage = string;
export interface InboundConnectionStatus {
    StatusCode?: InboundConnectionStatusCode;
    Message?: string;
}
export type ConnectionMode = "DIRECT" | "VPC_ENDPOINT" | (string & {});
export interface InboundConnection {
    LocalDomainInfo?: DomainInformationContainer;
    RemoteDomainInfo?: DomainInformationContainer;
    ConnectionId?: string;
    ConnectionStatus?: InboundConnectionStatus;
    ConnectionMode?: ConnectionMode;
}
export interface AcceptInboundConnectionResponse {
    Connection?: InboundConnection;
}
export type DataSourceName = string;
export type RoleArn = string;
export interface S3GlueDataCatalog {
    RoleArn?: string;
}
export type DataSourceType = {
    S3GlueDataCatalog: S3GlueDataCatalog;
};
export type DataSourceDescription = string;
export interface AddDataSourceRequest {
    DomainName: string;
    Name: string;
    DataSourceType: DataSourceType;
    Description?: string;
}
export interface AddDataSourceResponse {
    Message?: string;
}
export type DirectQueryDataSourceName = string;
export type DirectQueryDataSourceRoleArn = string;
export interface CloudWatchDirectQueryDataSource {
    RoleArn: string;
}
export interface SecurityLakeDirectQueryDataSource {
    RoleArn: string;
}
export type AMPWorkspaceArn = string;
export interface PrometheusDirectQueryDataSource {
    RoleArn: string;
    WorkspaceArn: string;
}
export type DirectQueryDataSourceType = {
    CloudWatchLog: CloudWatchDirectQueryDataSource;
    SecurityLake?: never;
    Prometheus?: never;
} | {
    CloudWatchLog?: never;
    SecurityLake: SecurityLakeDirectQueryDataSource;
    Prometheus?: never;
} | {
    CloudWatchLog?: never;
    SecurityLake?: never;
    Prometheus: PrometheusDirectQueryDataSource;
};
export type DirectQueryDataSourceDescription = string;
export type ARN = string;
export type DirectQueryOpenSearchARNList = string[];
export type PolicyDocument = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface AddDirectQueryDataSourceRequest {
    DataSourceName: string;
    DataSourceType: DirectQueryDataSourceType;
    Description?: string;
    OpenSearchArns?: string[];
    DataSourceAccessPolicy?: string;
    TagList?: Tag[];
}
export interface AddDirectQueryDataSourceResponse {
    DataSourceArn?: string;
}
export interface AddTagsRequest {
    ARN: string;
    TagList: Tag[];
}
export interface AddTagsResponse {
}
export type PackageID = string;
export type PackageIDList = string[];
export interface KeyStoreAccessOption {
    KeyAccessRoleArn?: string;
    KeyStoreAccessEnabled: boolean;
}
export interface PackageAssociationConfiguration {
    KeyStoreAccessOption?: KeyStoreAccessOption;
}
export interface AssociatePackageRequest {
    PackageID: string;
    DomainName: string;
    PrerequisitePackageIDList?: string[];
    AssociationConfiguration?: PackageAssociationConfiguration;
}
export type PackageName = string;
export type PackageType = "TXT-DICTIONARY" | "ZIP-PLUGIN" | "PACKAGE-LICENSE" | "PACKAGE-CONFIG" | (string & {});
export type LastUpdated = Date;
export type DomainPackageStatus = "ASSOCIATING" | "ASSOCIATION_FAILED" | "ACTIVE" | "DISSOCIATING" | "DISSOCIATION_FAILED" | (string & {});
export type PackageVersion = string;
export type ReferencePath = string;
export type ErrorType = string;
export type ErrorMessage = string;
export interface ErrorDetails {
    ErrorType?: string;
    ErrorMessage?: string;
}
export interface DomainPackageDetails {
    PackageID?: string;
    PackageName?: string;
    PackageType?: PackageType;
    LastUpdated?: Date;
    DomainName?: string;
    DomainPackageStatus?: DomainPackageStatus;
    PackageVersion?: string;
    PrerequisitePackageIDList?: string[];
    ReferencePath?: string;
    ErrorDetails?: ErrorDetails;
    AssociationConfiguration?: PackageAssociationConfiguration;
}
export interface AssociatePackageResponse {
    DomainPackageDetails?: DomainPackageDetails;
}
export interface PackageDetailsForAssociation {
    PackageID: string;
    PrerequisitePackageIDList?: string[];
    AssociationConfiguration?: PackageAssociationConfiguration;
}
export type PackageDetailsForAssociationList = PackageDetailsForAssociation[];
export interface AssociatePackagesRequest {
    PackageList: PackageDetailsForAssociation[];
    DomainName: string;
}
export type DomainPackageDetailsList = DomainPackageDetails[];
export interface AssociatePackagesResponse {
    DomainPackageDetailsList?: DomainPackageDetails[];
}
export type Id = string;
export interface WorkspaceConfigurationInput {
    name: string;
    workspaceType: string;
}
export type ClientToken = string;
export interface AttachDataSourceRequest {
    id: string;
    dataSourceArn: string;
    workspaceId?: string;
    workspaceConfiguration?: WorkspaceConfigurationInput;
    clientToken?: string;
}
export type DataSourceAttachmentStatus = "PENDING" | "ATTACHED" | "FAILED" | (string & {});
export interface AttachDataSourceResponse {
    attachmentId?: string;
    id?: string;
    arn?: string;
    dataSourceArn?: string;
    status?: DataSourceAttachmentStatus;
}
export type AWSAccount = string;
export type AWSServicePrincipal = "application.opensearchservice.amazonaws.com" | (string & {});
export type RegionsList = string[];
export interface ServiceOptions {
    SupportedRegions?: string[];
}
export interface AuthorizeVpcEndpointAccessRequest {
    DomainName: string;
    Account?: string;
    Service?: AWSServicePrincipal;
    ServiceOptions?: ServiceOptions;
}
export type PrincipalType = "AWS_ACCOUNT" | "AWS_SERVICE" | (string & {});
export interface AuthorizedPrincipal {
    PrincipalType?: PrincipalType;
    Principal?: string;
    ServiceOptions?: ServiceOptions;
}
export interface AuthorizeVpcEndpointAccessResponse {
    AuthorizedPrincipal: AuthorizedPrincipal;
}
export type DryRun = boolean;
export interface CancelDomainConfigChangeRequest {
    DomainName: string;
    DryRun?: boolean;
}
export type GUID = string;
export type GUIDList = string[];
export interface CancelledChangeProperty {
    PropertyName?: string;
    CancelledValue?: string;
    ActiveValue?: string;
}
export type CancelledChangePropertyList = CancelledChangeProperty[];
export interface CancelDomainConfigChangeResponse {
    CancelledChangeIds?: string[];
    CancelledChangeProperties?: CancelledChangeProperty[];
    DryRun?: boolean;
}
export interface CancelServiceSoftwareUpdateRequest {
    DomainName: string;
}
export type DeploymentStatus = "PENDING_UPDATE" | "IN_PROGRESS" | "COMPLETED" | "NOT_ELIGIBLE" | "ELIGIBLE" | (string & {});
export type DeploymentCloseDateTimeStamp = Date;
export interface ServiceSoftwareOptions {
    CurrentVersion?: string;
    NewVersion?: string;
    UpdateAvailable?: boolean;
    Cancellable?: boolean;
    UpdateStatus?: DeploymentStatus;
    Description?: string;
    AutomatedUpdateDate?: Date;
    OptionalDeployment?: boolean;
}
export interface CancelServiceSoftwareUpdateResponse {
    ServiceSoftwareOptions?: ServiceSoftwareOptions;
}
export type ApplicationName = string;
export interface DataSource {
    dataSourceArn?: string;
    dataSourceDescription?: string;
    iamRoleForDataSourceArn?: string;
}
export type DataSources = DataSource[];
export interface IamIdentityCenterOptionsInput {
    enabled?: boolean;
    iamIdentityCenterInstanceArn?: string;
    iamRoleForIdentityCenterApplicationArn?: string;
}
export type AppConfigType = "opensearchDashboards.dashboardAdmin.users" | "opensearchDashboards.dashboardAdmin.groups" | (string & {});
export type AppConfigValue = string;
export interface AppConfig {
    key?: AppConfigType;
    value?: string;
}
export type AppConfigs = AppConfig[];
export type KmsKeyArn = string;
export interface CreateApplicationRequest {
    clientToken?: string;
    name: string;
    dataSources?: DataSource[];
    iamIdentityCenterOptions?: IamIdentityCenterOptionsInput;
    appConfigs?: AppConfig[];
    tagList?: Tag[];
    kmsKeyArn?: string;
}
export interface IamIdentityCenterOptions {
    enabled?: boolean;
    iamIdentityCenterInstanceArn?: string;
    iamRoleForIdentityCenterApplicationArn?: string;
    iamIdentityCenterApplicationArn?: string;
}
export interface CreateApplicationResponse {
    id?: string;
    name?: string;
    arn?: string;
    dataSources?: DataSource[];
    iamIdentityCenterOptions?: IamIdentityCenterOptions;
    appConfigs?: AppConfig[];
    tagList?: Tag[];
    createdAt?: Date;
    kmsKeyArn?: string;
}
export type VersionString = string;
export type OpenSearchPartitionInstanceType = "m3.medium.search" | "m3.large.search" | "m3.xlarge.search" | "m3.2xlarge.search" | "m4.large.search" | "m4.xlarge.search" | "m4.2xlarge.search" | "m4.4xlarge.search" | "m4.10xlarge.search" | "m5.large.search" | "m5.xlarge.search" | "m5.2xlarge.search" | "m5.4xlarge.search" | "m5.12xlarge.search" | "m5.24xlarge.search" | "r5.large.search" | "r5.xlarge.search" | "r5.2xlarge.search" | "r5.4xlarge.search" | "r5.12xlarge.search" | "r5.24xlarge.search" | "c5.large.search" | "c5.xlarge.search" | "c5.2xlarge.search" | "c5.4xlarge.search" | "c5.9xlarge.search" | "c5.18xlarge.search" | "t3.nano.search" | "t3.micro.search" | "t3.small.search" | "t3.medium.search" | "t3.large.search" | "t3.xlarge.search" | "t3.2xlarge.search" | "or1.medium.search" | "or1.large.search" | "or1.xlarge.search" | "or1.2xlarge.search" | "or1.4xlarge.search" | "or1.8xlarge.search" | "or1.12xlarge.search" | "or1.16xlarge.search" | "ultrawarm1.medium.search" | "ultrawarm1.large.search" | "ultrawarm1.xlarge.search" | "t2.micro.search" | "t2.small.search" | "t2.medium.search" | "r3.large.search" | "r3.xlarge.search" | "r3.2xlarge.search" | "r3.4xlarge.search" | "r3.8xlarge.search" | "i2.xlarge.search" | "i2.2xlarge.search" | "d2.xlarge.search" | "d2.2xlarge.search" | "d2.4xlarge.search" | "d2.8xlarge.search" | "c4.large.search" | "c4.xlarge.search" | "c4.2xlarge.search" | "c4.4xlarge.search" | "c4.8xlarge.search" | "r4.large.search" | "r4.xlarge.search" | "r4.2xlarge.search" | "r4.4xlarge.search" | "r4.8xlarge.search" | "r4.16xlarge.search" | "i3.large.search" | "i3.xlarge.search" | "i3.2xlarge.search" | "i3.4xlarge.search" | "i3.8xlarge.search" | "i3.16xlarge.search" | "r6g.large.search" | "r6g.xlarge.search" | "r6g.2xlarge.search" | "r6g.4xlarge.search" | "r6g.8xlarge.search" | "r6g.12xlarge.search" | "m6g.large.search" | "m6g.xlarge.search" | "m6g.2xlarge.search" | "m6g.4xlarge.search" | "m6g.8xlarge.search" | "m6g.12xlarge.search" | "c6g.large.search" | "c6g.xlarge.search" | "c6g.2xlarge.search" | "c6g.4xlarge.search" | "c6g.8xlarge.search" | "c6g.12xlarge.search" | "r6gd.large.search" | "r6gd.xlarge.search" | "r6gd.2xlarge.search" | "r6gd.4xlarge.search" | "r6gd.8xlarge.search" | "r6gd.12xlarge.search" | "r6gd.16xlarge.search" | "t4g.small.search" | "t4g.medium.search" | (string & {});
export type IntegerClass = number;
export interface ZoneAwarenessConfig {
    AvailabilityZoneCount?: number;
}
export type OpenSearchWarmPartitionInstanceType = "ultrawarm1.medium.search" | "ultrawarm1.large.search" | "ultrawarm1.xlarge.search" | (string & {});
export interface ColdStorageOptions {
    Enabled: boolean;
}
export type NodeOptionsNodeType = "coordinator" | (string & {});
export interface NodeConfig {
    Enabled?: boolean;
    Type?: OpenSearchPartitionInstanceType;
    Count?: number;
}
export interface NodeOption {
    NodeType?: NodeOptionsNodeType;
    NodeConfig?: NodeConfig;
}
export type NodeOptionsList = NodeOption[];
export interface ClusterConfig {
    InstanceType?: OpenSearchPartitionInstanceType;
    InstanceCount?: number;
    DedicatedMasterEnabled?: boolean;
    ZoneAwarenessEnabled?: boolean;
    ZoneAwarenessConfig?: ZoneAwarenessConfig;
    DedicatedMasterType?: OpenSearchPartitionInstanceType;
    DedicatedMasterCount?: number;
    WarmEnabled?: boolean;
    WarmType?: OpenSearchWarmPartitionInstanceType;
    WarmCount?: number;
    ColdStorageOptions?: ColdStorageOptions;
    MultiAZWithStandbyEnabled?: boolean;
    NodeOptions?: NodeOption[];
}
export type VolumeType = "standard" | "gp2" | "io1" | "gp3" | (string & {});
export interface EBSOptions {
    EBSEnabled?: boolean;
    VolumeType?: VolumeType;
    VolumeSize?: number;
    Iops?: number;
    Throughput?: number;
}
export type IPAddressType = "ipv4" | "dualstack" | (string & {});
export interface SnapshotOptions {
    AutomatedSnapshotStartHour?: number;
}
export type StringList = string[];
export interface VPCOptions {
    SubnetIds?: string[];
    SecurityGroupIds?: string[];
    EgressEnabled?: boolean;
}
export type UserPoolId = string;
export type IdentityPoolId = string;
export interface CognitoOptions {
    Enabled?: boolean;
    UserPoolId?: string;
    IdentityPoolId?: string;
    RoleArn?: string;
}
export type KmsKeyId = string;
export interface EncryptionAtRestOptions {
    Enabled?: boolean;
    KmsKeyId?: string;
}
export interface NodeToNodeEncryptionOptions {
    Enabled?: boolean;
}
export type AdvancedOptions = {
    [key: string]: string | undefined;
};
export type LogType = "INDEX_SLOW_LOGS" | "SEARCH_SLOW_LOGS" | "ES_APPLICATION_LOGS" | "AUDIT_LOGS" | (string & {});
export type CloudWatchLogsLogGroupArn = string;
export interface LogPublishingOption {
    CloudWatchLogsLogGroupArn?: string;
    Enabled?: boolean;
}
export type LogPublishingOptions = {
    [key in LogType]?: LogPublishingOption;
};
export type TLSSecurityPolicy = "Policy-Min-TLS-1-0-2019-07" | "Policy-Min-TLS-1-2-2019-07" | "Policy-Min-TLS-1-2-PFS-2023-10" | "Policy-Min-TLS-1-2-RFC9151-FIPS-2024-08" | (string & {});
export type DomainNameFqdn = string;
export interface DomainEndpointOptions {
    EnforceHTTPS?: boolean;
    TLSSecurityPolicy?: TLSSecurityPolicy;
    CustomEndpointEnabled?: boolean;
    CustomEndpoint?: string;
    CustomEndpointCertificateArn?: string;
}
export type Username = string | redacted.Redacted<string>;
export type Password = string | redacted.Redacted<string>;
export interface MasterUserOptions {
    MasterUserARN?: string;
    MasterUserName?: string | redacted.Redacted<string>;
    MasterUserPassword?: string | redacted.Redacted<string>;
}
export type SAMLMetadata = string;
export type SAMLEntityId = string;
export interface SAMLIdp {
    MetadataContent: string;
    EntityId: string;
}
export type BackendRole = string;
export interface SAMLOptionsInput {
    Enabled?: boolean;
    Idp?: SAMLIdp;
    MasterUserName?: string | redacted.Redacted<string>;
    MasterBackendRole?: string;
    SubjectKey?: string;
    RolesKey?: string;
    SessionTimeoutMinutes?: number;
}
export type SubjectKey = string;
export type RolesKey = string;
export type JwksUrl = string;
export interface JWTOptionsInput {
    Enabled?: boolean;
    SubjectKey?: string;
    RolesKey?: string;
    JwksUrl?: string;
    PublicKey?: string;
}
export type IAMFederationSubjectKey = string;
export type IAMFederationRolesKey = string;
export interface IAMFederationOptionsInput {
    Enabled?: boolean;
    SubjectKey?: string;
    RolesKey?: string;
}
export interface AdvancedSecurityOptionsInput {
    Enabled?: boolean;
    InternalUserDatabaseEnabled?: boolean;
    MasterUserOptions?: MasterUserOptions;
    SAMLOptions?: SAMLOptionsInput;
    JWTOptions?: JWTOptionsInput;
    IAMFederationOptions?: IAMFederationOptionsInput;
    AnonymousAuthEnabled?: boolean;
}
export type IdentityCenterInstanceARN = string;
export type SubjectKeyIdCOption = "UserName" | "UserId" | "Email" | (string & {});
export type RolesKeyIdCOption = "GroupName" | "GroupId" | (string & {});
export interface IdentityCenterOptionsInput {
    EnabledAPIAccess?: boolean;
    IdentityCenterInstanceARN?: string;
    IdentityCenterInstanceRegion?: string;
    SubjectKey?: SubjectKeyIdCOption;
    RolesKey?: RolesKeyIdCOption;
}
export type AutoTuneDesiredState = "ENABLED" | "DISABLED" | (string & {});
export type StartAt = Date;
export type DurationValue = number;
export type TimeUnit = "HOURS" | (string & {});
export interface Duration {
    Value?: number;
    Unit?: TimeUnit;
}
export interface AutoTuneMaintenanceSchedule {
    StartAt?: Date;
    Duration?: Duration;
    CronExpressionForRecurrence?: string;
}
export type AutoTuneMaintenanceScheduleList = AutoTuneMaintenanceSchedule[];
export interface AutoTuneOptionsInput {
    DesiredState?: AutoTuneDesiredState;
    MaintenanceSchedules?: AutoTuneMaintenanceSchedule[];
    UseOffPeakWindow?: boolean;
}
export type StartTimeHours = number;
export type StartTimeMinutes = number;
export interface WindowStartTime {
    Hours: number;
    Minutes: number;
}
export interface OffPeakWindow {
    WindowStartTime?: WindowStartTime;
}
export interface OffPeakWindowOptions {
    Enabled?: boolean;
    OffPeakWindow?: OffPeakWindow;
}
export interface SoftwareUpdateOptions {
    AutoSoftwareUpdateEnabled?: boolean;
    UseLatestServiceSoftwareForBlueGreen?: boolean;
}
export type NaturalLanguageQueryGenerationDesiredState = "ENABLED" | "DISABLED" | (string & {});
export interface NaturalLanguageQueryGenerationOptionsInput {
    DesiredState?: NaturalLanguageQueryGenerationDesiredState;
}
export interface S3VectorsEngine {
    Enabled?: boolean;
}
export interface ServerlessVectorAcceleration {
    Enabled?: boolean;
}
export interface AIMLOptionsInput {
    NaturalLanguageQueryGenerationOptions?: NaturalLanguageQueryGenerationOptionsInput;
    S3VectorsEngine?: S3VectorsEngine;
    ServerlessVectorAcceleration?: ServerlessVectorAcceleration;
}
export type DeploymentStrategy = "Default" | "CapacityOptimized" | (string & {});
export interface DeploymentStrategyOptions {
    DeploymentStrategy: DeploymentStrategy;
}
export interface AutomatedSnapshotPauseRequestOptions {
    Enabled: boolean;
    StartTime?: Date;
    EndTime?: Date;
}
export type DomainUseCase = "SEARCH" | "VECTOR" | "OBSERVABILITY" | "MIXED" | (string & {});
export type EngineMode = "GENERAL" | "OPTIMIZED" | (string & {});
export interface CreateDomainRequest {
    DomainName: string;
    EngineVersion?: string;
    ClusterConfig?: ClusterConfig;
    EBSOptions?: EBSOptions;
    AccessPolicies?: string;
    IPAddressType?: IPAddressType;
    SnapshotOptions?: SnapshotOptions;
    VPCOptions?: VPCOptions;
    CognitoOptions?: CognitoOptions;
    EncryptionAtRestOptions?: EncryptionAtRestOptions;
    NodeToNodeEncryptionOptions?: NodeToNodeEncryptionOptions;
    AdvancedOptions?: {
        [key: string]: string | undefined;
    };
    LogPublishingOptions?: {
        [key: string]: LogPublishingOption | undefined;
    };
    DomainEndpointOptions?: DomainEndpointOptions;
    AdvancedSecurityOptions?: AdvancedSecurityOptionsInput;
    IdentityCenterOptions?: IdentityCenterOptionsInput;
    TagList?: Tag[];
    AutoTuneOptions?: AutoTuneOptionsInput;
    OffPeakWindowOptions?: OffPeakWindowOptions;
    SoftwareUpdateOptions?: SoftwareUpdateOptions;
    AIMLOptions?: AIMLOptionsInput;
    DeploymentStrategyOptions?: DeploymentStrategyOptions;
    AutomatedSnapshotPauseOptions?: AutomatedSnapshotPauseRequestOptions;
    UseCase?: DomainUseCase;
    EngineMode?: EngineMode;
}
export type DomainId = string;
export type ServiceUrl = string;
export type EndpointsMap = {
    [key: string]: string | undefined;
};
export type HostedZoneId = string;
export interface VPCDerivedInfo {
    VPCId?: string;
    SubnetIds?: string[];
    AvailabilityZones?: string[];
    SecurityGroupIds?: string[];
    EgressEnabled?: boolean;
}
export interface SAMLOptionsOutput {
    Enabled?: boolean;
    Idp?: SAMLIdp;
    SubjectKey?: string;
    RolesKey?: string;
    SessionTimeoutMinutes?: number;
}
export interface JWTOptionsOutput {
    Enabled?: boolean;
    SubjectKey?: string;
    RolesKey?: string;
    JwksUrl?: string;
    PublicKey?: string;
}
export interface IAMFederationOptionsOutput {
    Enabled?: boolean;
    SubjectKey?: string;
    RolesKey?: string;
}
export type DisableTimestamp = Date;
export interface AdvancedSecurityOptions {
    Enabled?: boolean;
    InternalUserDatabaseEnabled?: boolean;
    SAMLOptions?: SAMLOptionsOutput;
    JWTOptions?: JWTOptionsOutput;
    IAMFederationOptions?: IAMFederationOptionsOutput;
    AnonymousAuthDisableDate?: Date;
    AnonymousAuthEnabled?: boolean;
}
export type IdentityCenterApplicationARN = string;
export type IdentityStoreId = string;
export interface IdentityCenterOptions {
    EnabledAPIAccess?: boolean;
    IdentityCenterInstanceARN?: string;
    IdentityCenterInstanceRegion?: string;
    SubjectKey?: SubjectKeyIdCOption;
    RolesKey?: RolesKeyIdCOption;
    IdentityCenterApplicationARN?: string;
    IdentityStoreId?: string;
}
export type AutoTuneState = "ENABLED" | "DISABLED" | "ENABLE_IN_PROGRESS" | "DISABLE_IN_PROGRESS" | "DISABLED_AND_ROLLBACK_SCHEDULED" | "DISABLED_AND_ROLLBACK_IN_PROGRESS" | "DISABLED_AND_ROLLBACK_COMPLETE" | "DISABLED_AND_ROLLBACK_ERROR" | "ERROR" | (string & {});
export interface AutoTuneOptionsOutput {
    State?: AutoTuneState;
    ErrorMessage?: string;
    UseOffPeakWindow?: boolean;
}
export type Message = string;
export type ConfigChangeStatus = "Pending" | "Initializing" | "Validating" | "ValidationFailed" | "ApplyingChanges" | "Completed" | "PendingUserInput" | "Cancelled" | (string & {});
export type InitiatedBy = "CUSTOMER" | "SERVICE" | (string & {});
export type UpdateTimestamp = Date;
export interface ChangeProgressDetails {
    ChangeId?: string;
    Message?: string;
    ConfigChangeStatus?: ConfigChangeStatus;
    InitiatedBy?: InitiatedBy;
    StartTime?: Date;
    LastUpdatedTime?: Date;
}
export type DomainProcessingStatusType = "Creating" | "Active" | "Modifying" | "UpgradingEngineVersion" | "UpdatingServiceSoftware" | "Isolated" | "Deleting" | (string & {});
export type PropertyValueType = "PLAIN_TEXT" | "STRINGIFIED_JSON" | (string & {});
export interface ModifyingProperties {
    Name?: string;
    ActiveValue?: string;
    PendingValue?: string;
    ValueType?: PropertyValueType;
}
export type ModifyingPropertiesList = ModifyingProperties[];
export type NaturalLanguageQueryGenerationCurrentState = "NOT_ENABLED" | "ENABLE_COMPLETE" | "ENABLE_IN_PROGRESS" | "ENABLE_FAILED" | "DISABLE_COMPLETE" | "DISABLE_IN_PROGRESS" | "DISABLE_FAILED" | (string & {});
export interface NaturalLanguageQueryGenerationOptionsOutput {
    DesiredState?: NaturalLanguageQueryGenerationDesiredState;
    CurrentState?: NaturalLanguageQueryGenerationCurrentState;
}
export interface AIMLOptionsOutput {
    NaturalLanguageQueryGenerationOptions?: NaturalLanguageQueryGenerationOptionsOutput;
    S3VectorsEngine?: S3VectorsEngine;
    ServerlessVectorAcceleration?: ServerlessVectorAcceleration;
}
export type PauseState = "Active" | "Completed" | "Scheduled" | "Disabled" | (string & {});
export interface AutomatedSnapshotPauseOptions {
    Enabled: boolean;
    StartTime?: Date;
    EndTime?: Date;
    State?: PauseState;
}
export interface DomainStatus {
    DomainId: string;
    DomainName: string;
    ARN: string;
    Created?: boolean;
    Deleted?: boolean;
    Endpoint?: string;
    EndpointV2?: string;
    Endpoints?: {
        [key: string]: string | undefined;
    };
    DomainEndpointV2HostedZoneId?: string;
    Processing?: boolean;
    UpgradeProcessing?: boolean;
    EngineVersion?: string;
    ClusterConfig: ClusterConfig;
    EBSOptions?: EBSOptions;
    AccessPolicies?: string;
    IPAddressType?: IPAddressType;
    SnapshotOptions?: SnapshotOptions;
    VPCOptions?: VPCDerivedInfo;
    CognitoOptions?: CognitoOptions;
    EncryptionAtRestOptions?: EncryptionAtRestOptions;
    NodeToNodeEncryptionOptions?: NodeToNodeEncryptionOptions;
    AdvancedOptions?: {
        [key: string]: string | undefined;
    };
    LogPublishingOptions?: {
        [key: string]: LogPublishingOption | undefined;
    };
    ServiceSoftwareOptions?: ServiceSoftwareOptions;
    DomainEndpointOptions?: DomainEndpointOptions;
    AdvancedSecurityOptions?: AdvancedSecurityOptions;
    IdentityCenterOptions?: IdentityCenterOptions;
    AutoTuneOptions?: AutoTuneOptionsOutput;
    ChangeProgressDetails?: ChangeProgressDetails;
    OffPeakWindowOptions?: OffPeakWindowOptions;
    SoftwareUpdateOptions?: SoftwareUpdateOptions;
    DomainProcessingStatus?: DomainProcessingStatusType;
    ModifyingProperties?: ModifyingProperties[];
    AIMLOptions?: AIMLOptionsOutput;
    DeploymentStrategyOptions?: DeploymentStrategyOptions;
    AutomatedSnapshotPauseOptions?: AutomatedSnapshotPauseOptions;
    UseCase?: DomainUseCase;
    EngineMode?: EngineMode;
}
export interface CreateDomainResponse {
    DomainStatus?: DomainStatus;
}
export type IndexName = string;
export type IndexSchema = unknown;
export interface CreateIndexRequest {
    DomainName: string;
    IndexName: string;
    IndexSchema: any;
}
export type IndexStatus = "CREATED" | "UPDATED" | "DELETED" | (string & {});
export interface CreateIndexResponse {
    Status: IndexStatus;
}
export type ConnectionAlias = string;
export type Endpoint = string;
export type SkipUnavailableStatus = "ENABLED" | "DISABLED" | (string & {});
export interface CrossClusterSearchConnectionProperties {
    SkipUnavailable?: SkipUnavailableStatus;
}
export interface ConnectionProperties {
    Endpoint?: string;
    CrossClusterSearch?: CrossClusterSearchConnectionProperties;
}
export interface CreateOutboundConnectionRequest {
    LocalDomainInfo: DomainInformationContainer;
    RemoteDomainInfo: DomainInformationContainer;
    ConnectionAlias: string;
    ConnectionMode?: ConnectionMode;
    ConnectionProperties?: ConnectionProperties;
}
export type OutboundConnectionStatusCode = "VALIDATING" | "VALIDATION_FAILED" | "PENDING_ACCEPTANCE" | "APPROVED" | "PROVISIONING" | "ACTIVE" | "REJECTING" | "REJECTED" | "DELETING" | "DELETED" | (string & {});
export interface OutboundConnectionStatus {
    StatusCode?: OutboundConnectionStatusCode;
    Message?: string;
}
export interface CreateOutboundConnectionResponse {
    LocalDomainInfo?: DomainInformationContainer;
    RemoteDomainInfo?: DomainInformationContainer;
    ConnectionAlias?: string;
    ConnectionStatus?: OutboundConnectionStatus;
    ConnectionId?: string;
    ConnectionMode?: ConnectionMode;
    ConnectionProperties?: ConnectionProperties;
}
export type PackageDescription = string;
export type S3BucketName = string;
export type S3Key = string;
export interface PackageSource {
    S3BucketName?: string;
    S3Key?: string;
}
export type RequirementLevel = "REQUIRED" | "OPTIONAL" | "NONE" | (string & {});
export type LicenseFilepath = string;
export interface PackageConfiguration {
    LicenseRequirement: RequirementLevel;
    LicenseFilepath?: string;
    ConfigurationRequirement: RequirementLevel;
    RequiresRestartForConfigurationUpdate?: boolean;
}
export type EngineVersion = string;
export interface PackageVendingOptions {
    VendingEnabled: boolean;
}
export interface PackageEncryptionOptions {
    KmsKeyIdentifier?: string;
    EncryptionEnabled: boolean;
}
export interface CreatePackageRequest {
    PackageName: string;
    PackageType: PackageType;
    PackageDescription?: string;
    PackageSource: PackageSource;
    PackageConfiguration?: PackageConfiguration;
    EngineVersion?: string;
    PackageVendingOptions?: PackageVendingOptions;
    PackageEncryptionOptions?: PackageEncryptionOptions;
}
export type PackageStatus = "COPYING" | "COPY_FAILED" | "VALIDATING" | "VALIDATION_FAILED" | "AVAILABLE" | "DELETING" | "DELETED" | "DELETE_FAILED" | (string & {});
export type CreatedAt = Date;
export type PluginName = string;
export type PluginDescription = string;
export type PluginVersion = string;
export type PluginClassName = string;
export type UncompressedPluginSizeInBytes = number;
export interface PluginProperties {
    Name?: string;
    Description?: string;
    Version?: string;
    ClassName?: string;
    UncompressedSizeInBytes?: number;
}
export type PackageUser = string;
export type PackageUserList = string[];
export type PackageOwner = string;
export interface PackageDetails {
    PackageID?: string;
    PackageName?: string;
    PackageType?: PackageType;
    PackageDescription?: string;
    PackageStatus?: PackageStatus;
    CreatedAt?: Date;
    LastUpdatedAt?: Date;
    AvailablePackageVersion?: string;
    ErrorDetails?: ErrorDetails;
    EngineVersion?: string;
    AvailablePluginProperties?: PluginProperties;
    AvailablePackageConfiguration?: PackageConfiguration;
    AllowListedUserList?: string[];
    PackageOwner?: string;
    PackageVendingOptions?: PackageVendingOptions;
    PackageEncryptionOptions?: PackageEncryptionOptions;
}
export interface CreatePackageResponse {
    PackageDetails?: PackageDetails;
}
export type DomainArn = string;
export interface CreateVpcEndpointRequest {
    DomainArn: string;
    VpcOptions: VPCOptions;
    ClientToken?: string;
}
export type VpcEndpointId = string;
export type VpcEndpointStatus = "CREATING" | "CREATE_FAILED" | "ACTIVE" | "UPDATING" | "UPDATE_FAILED" | "DELETING" | "DELETE_FAILED" | (string & {});
export interface VpcEndpoint {
    VpcEndpointId?: string;
    VpcEndpointOwner?: string;
    DomainArn?: string;
    VpcOptions?: VPCDerivedInfo;
    Status?: VpcEndpointStatus;
    Endpoint?: string;
}
export interface CreateVpcEndpointResponse {
    VpcEndpoint: VpcEndpoint;
}
export interface DeleteApplicationRequest {
    id: string;
}
export interface DeleteApplicationResponse {
}
export interface DeleteDataSourceRequest {
    DomainName: string;
    Name: string;
}
export interface DeleteDataSourceResponse {
    Message?: string;
}
export interface DeleteDirectQueryDataSourceRequest {
    DataSourceName: string;
}
export interface DeleteDirectQueryDataSourceResponse {
}
export interface DeleteDomainRequest {
    DomainName: string;
}
export interface DeleteDomainResponse {
    DomainStatus?: DomainStatus;
}
export interface DeleteInboundConnectionRequest {
    ConnectionId: string;
}
export interface DeleteInboundConnectionResponse {
    Connection?: InboundConnection;
}
export interface DeleteIndexRequest {
    DomainName: string;
    IndexName: string;
}
export interface DeleteIndexResponse {
    Status: IndexStatus;
}
export interface DeleteOutboundConnectionRequest {
    ConnectionId: string;
}
export interface OutboundConnection {
    LocalDomainInfo?: DomainInformationContainer;
    RemoteDomainInfo?: DomainInformationContainer;
    ConnectionId?: string;
    ConnectionAlias?: string;
    ConnectionStatus?: OutboundConnectionStatus;
    ConnectionMode?: ConnectionMode;
    ConnectionProperties?: ConnectionProperties;
}
export interface DeleteOutboundConnectionResponse {
    Connection?: OutboundConnection;
}
export interface DeletePackageRequest {
    PackageID: string;
}
export interface DeletePackageResponse {
    PackageDetails?: PackageDetails;
}
export interface DeleteVpcEndpointRequest {
    VpcEndpointId: string;
}
export interface VpcEndpointSummary {
    VpcEndpointId?: string;
    VpcEndpointOwner?: string;
    DomainArn?: string;
    Status?: VpcEndpointStatus;
}
export interface DeleteVpcEndpointResponse {
    VpcEndpointSummary: VpcEndpointSummary;
}
export type ApplicationId = string;
export type CapabilityName = string;
export interface DeregisterCapabilityRequest {
    applicationId: string;
    capabilityName: string;
}
export type CapabilityStatus = "creating" | "create_failed" | "active" | "updating" | "update_failed" | "deleting" | "delete_failed" | (string & {});
export interface DeregisterCapabilityResponse {
    status?: CapabilityStatus;
}
export interface DescribeDataSourceAttachmentRequest {
    id: string;
    dataSourceArn: string;
}
export interface DescribeDataSourceAttachmentResponse {
    attachmentId?: string;
    id?: string;
    arn?: string;
    dataSourceArn?: string;
    status?: DataSourceAttachmentStatus;
}
export interface DescribeDomainRequest {
    DomainName: string;
}
export interface DescribeDomainResponse {
    DomainStatus: DomainStatus;
}
export type MaxResults = number;
export type NextToken = string;
export interface DescribeDomainAutoTunesRequest {
    DomainName: string;
    MaxResults?: number;
    NextToken?: string;
}
export type AutoTuneType = "SCHEDULED_ACTION" | (string & {});
export type AutoTuneDate = Date;
export type ScheduledAutoTuneActionType = "JVM_HEAP_SIZE_TUNING" | "JVM_YOUNG_GEN_TUNING" | (string & {});
export type ScheduledAutoTuneDescription = string;
export type ScheduledAutoTuneSeverityType = "LOW" | "MEDIUM" | "HIGH" | (string & {});
export interface ScheduledAutoTuneDetails {
    Date?: Date;
    ActionType?: ScheduledAutoTuneActionType;
    Action?: string;
    Severity?: ScheduledAutoTuneSeverityType;
}
export interface AutoTuneDetails {
    ScheduledAutoTuneDetails?: ScheduledAutoTuneDetails;
}
export interface AutoTune {
    AutoTuneType?: AutoTuneType;
    AutoTuneDetails?: AutoTuneDetails;
}
export type AutoTuneList = AutoTune[];
export interface DescribeDomainAutoTunesResponse {
    AutoTunes?: AutoTune[];
    NextToken?: string;
}
export interface DescribeDomainChangeProgressRequest {
    DomainName: string;
    ChangeId?: string;
}
export type OverallChangeStatus = "PENDING" | "PROCESSING" | "COMPLETED" | "FAILED" | (string & {});
export type TotalNumberOfStages = number;
export type ChangeProgressStageName = string;
export type ChangeProgressStageStatus = string;
export type Description = string;
export interface ChangeProgressStage {
    Name?: string;
    Status?: string;
    Description?: string;
    LastUpdated?: Date;
}
export type ChangeProgressStageList = ChangeProgressStage[];
export type ValidationFailureSeverity = "Critical" | "Warning" | (string & {});
export interface ValidationFailure {
    Code?: string;
    Message?: string;
    Severity?: ValidationFailureSeverity;
}
export type ValidationFailures = ValidationFailure[];
export type AcceptedWarningsList = string[];
export interface ChangeProgressStatusDetails {
    ChangeId?: string;
    StartTime?: Date;
    Status?: OverallChangeStatus;
    PendingProperties?: string[];
    CompletedProperties?: string[];
    TotalNumberOfStages?: number;
    ChangeProgressStages?: ChangeProgressStage[];
    LastUpdatedTime?: Date;
    ConfigChangeStatus?: ConfigChangeStatus;
    InitiatedBy?: InitiatedBy;
    ValidationFailures?: ValidationFailure[];
    AcceptedWarnings?: string[];
}
export interface DescribeDomainChangeProgressResponse {
    ChangeProgressStatus?: ChangeProgressStatusDetails;
}
export interface DescribeDomainConfigRequest {
    DomainName: string;
}
export type UIntValue = number;
export type OptionState = "RequiresIndexDocuments" | "Processing" | "Active" | (string & {});
export interface OptionStatus {
    CreationDate: Date;
    UpdateDate: Date;
    UpdateVersion?: number;
    State: OptionState;
    PendingDeletion?: boolean;
}
export interface VersionStatus {
    Options: string;
    Status: OptionStatus;
}
export interface ClusterConfigStatus {
    Options: ClusterConfig;
    Status: OptionStatus;
}
export interface EBSOptionsStatus {
    Options: EBSOptions;
    Status: OptionStatus;
}
export interface AccessPoliciesStatus {
    Options: string;
    Status: OptionStatus;
}
export interface IPAddressTypeStatus {
    Options: IPAddressType;
    Status: OptionStatus;
}
export interface SnapshotOptionsStatus {
    Options: SnapshotOptions;
    Status: OptionStatus;
}
export interface VPCDerivedInfoStatus {
    Options: VPCDerivedInfo;
    Status: OptionStatus;
}
export interface CognitoOptionsStatus {
    Options: CognitoOptions;
    Status: OptionStatus;
}
export interface EncryptionAtRestOptionsStatus {
    Options: EncryptionAtRestOptions;
    Status: OptionStatus;
}
export interface NodeToNodeEncryptionOptionsStatus {
    Options: NodeToNodeEncryptionOptions;
    Status: OptionStatus;
}
export interface AdvancedOptionsStatus {
    Options: {
        [key: string]: string | undefined;
    };
    Status: OptionStatus;
}
export interface LogPublishingOptionsStatus {
    Options?: {
        [key: string]: LogPublishingOption | undefined;
    };
    Status?: OptionStatus;
}
export interface DomainEndpointOptionsStatus {
    Options: DomainEndpointOptions;
    Status: OptionStatus;
}
export interface AdvancedSecurityOptionsStatus {
    Options: AdvancedSecurityOptions;
    Status: OptionStatus;
}
export interface IdentityCenterOptionsStatus {
    Options: IdentityCenterOptions;
    Status: OptionStatus;
}
export type RollbackOnDisable = "NO_ROLLBACK" | "DEFAULT_ROLLBACK" | (string & {});
export interface AutoTuneOptions {
    DesiredState?: AutoTuneDesiredState;
    RollbackOnDisable?: RollbackOnDisable;
    MaintenanceSchedules?: AutoTuneMaintenanceSchedule[];
    UseOffPeakWindow?: boolean;
}
export interface AutoTuneStatus {
    CreationDate: Date;
    UpdateDate: Date;
    UpdateVersion?: number;
    State: AutoTuneState;
    ErrorMessage?: string;
    PendingDeletion?: boolean;
}
export interface AutoTuneOptionsStatus {
    Options?: AutoTuneOptions;
    Status?: AutoTuneStatus;
}
export interface OffPeakWindowOptionsStatus {
    Options?: OffPeakWindowOptions;
    Status?: OptionStatus;
}
export interface SoftwareUpdateOptionsStatus {
    Options?: SoftwareUpdateOptions;
    Status?: OptionStatus;
}
export interface AIMLOptionsStatus {
    Options?: AIMLOptionsOutput;
    Status?: OptionStatus;
}
export interface DeploymentStrategyOptionsStatus {
    Options: DeploymentStrategyOptions;
    Status: OptionStatus;
}
export interface AutomatedSnapshotPauseOptionsStatus {
    Options: AutomatedSnapshotPauseOptions;
    Status: OptionStatus;
}
export interface UseCaseStatus {
    Options: DomainUseCase;
    Status: OptionStatus;
}
export interface EngineModeStatus {
    Options: EngineMode;
    Status: OptionStatus;
}
export interface DomainConfig {
    EngineVersion?: VersionStatus;
    ClusterConfig?: ClusterConfigStatus;
    EBSOptions?: EBSOptionsStatus;
    AccessPolicies?: AccessPoliciesStatus;
    IPAddressType?: IPAddressTypeStatus;
    SnapshotOptions?: SnapshotOptionsStatus;
    VPCOptions?: VPCDerivedInfoStatus;
    CognitoOptions?: CognitoOptionsStatus;
    EncryptionAtRestOptions?: EncryptionAtRestOptionsStatus;
    NodeToNodeEncryptionOptions?: NodeToNodeEncryptionOptionsStatus;
    AdvancedOptions?: AdvancedOptionsStatus;
    LogPublishingOptions?: LogPublishingOptionsStatus;
    DomainEndpointOptions?: DomainEndpointOptionsStatus;
    AdvancedSecurityOptions?: AdvancedSecurityOptionsStatus;
    IdentityCenterOptions?: IdentityCenterOptionsStatus;
    AutoTuneOptions?: AutoTuneOptionsStatus;
    ChangeProgressDetails?: ChangeProgressDetails;
    OffPeakWindowOptions?: OffPeakWindowOptionsStatus;
    SoftwareUpdateOptions?: SoftwareUpdateOptionsStatus;
    ModifyingProperties?: ModifyingProperties[];
    AIMLOptions?: AIMLOptionsStatus;
    DeploymentStrategyOptions?: DeploymentStrategyOptionsStatus;
    AutomatedSnapshotPauseOptions?: AutomatedSnapshotPauseOptionsStatus;
    UseCase?: UseCaseStatus;
    EngineMode?: EngineModeStatus;
}
export interface DescribeDomainConfigResponse {
    DomainConfig: DomainConfig;
}
export interface DescribeDomainHealthRequest {
    DomainName: string;
}
export type DomainState = "Active" | "Processing" | "NotAvailable" | (string & {});
export type NumberOfAZs = string;
export type NumberOfNodes = string;
export type MasterNodeStatus = "Available" | "UnAvailable" | (string & {});
export type DomainHealth = "Red" | "Yellow" | "Green" | "NotAvailable" | (string & {});
export type NumberOfShards = string;
export type AvailabilityZone = string;
export type ZoneStatus = "Active" | "StandBy" | "NotAvailable" | (string & {});
export interface AvailabilityZoneInfo {
    AvailabilityZoneName?: string;
    ZoneStatus?: ZoneStatus;
    ConfiguredDataNodeCount?: string;
    AvailableDataNodeCount?: string;
    TotalShards?: string;
    TotalUnAssignedShards?: string;
}
export type AvailabilityZoneInfoList = AvailabilityZoneInfo[];
export interface EnvironmentInfo {
    AvailabilityZoneInformation?: AvailabilityZoneInfo[];
}
export type EnvironmentInfoList = EnvironmentInfo[];
export interface DescribeDomainHealthResponse {
    DomainState?: DomainState;
    AvailabilityZoneCount?: string;
    ActiveAvailabilityZoneCount?: string;
    StandByAvailabilityZoneCount?: string;
    DataNodeCount?: string;
    DedicatedMaster?: boolean;
    MasterEligibleNodeCount?: string;
    WarmNodeCount?: string;
    MasterNode?: MasterNodeStatus;
    ClusterHealth?: DomainHealth;
    TotalShards?: string;
    TotalUnAssignedShards?: string;
    EnvironmentInformation?: EnvironmentInfo[];
}
export interface DescribeDomainNodesRequest {
    DomainName: string;
}
export type NodeId = string;
export type NodeType = "Data" | "Ultrawarm" | "Master" | "Warm" | (string & {});
export type NodeStatus = "Active" | "StandBy" | "NotAvailable" | (string & {});
export type StorageTypeName = string;
export type VolumeSize = string;
export interface DomainNodesStatus {
    NodeId?: string;
    NodeType?: NodeType;
    AvailabilityZone?: string;
    InstanceType?: OpenSearchPartitionInstanceType;
    NodeStatus?: NodeStatus;
    StorageType?: string;
    StorageVolumeType?: VolumeType;
    StorageSize?: string;
}
export type DomainNodesStatusList = DomainNodesStatus[];
export interface DescribeDomainNodesResponse {
    DomainNodesStatusList?: DomainNodesStatus[];
}
export type DomainNameList = string[];
export interface DescribeDomainsRequest {
    DomainNames: string[];
}
export type DomainStatusList = DomainStatus[];
export interface DescribeDomainsResponse {
    DomainStatusList: DomainStatus[];
}
export interface DescribeDryRunProgressRequest {
    DomainName: string;
    DryRunId?: string;
    LoadDryRunConfig?: boolean;
}
export interface DryRunProgressStatus {
    DryRunId: string;
    DryRunStatus: string;
    CreationDate: string;
    UpdateDate: string;
    ValidationFailures?: ValidationFailure[];
    AcceptedWarnings?: string[];
}
export type DeploymentType = string;
export interface DryRunResults {
    DeploymentType?: string;
    Message?: string;
}
export interface DescribeDryRunProgressResponse {
    DryRunProgressStatus?: DryRunProgressStatus;
    DryRunConfig?: DomainStatus;
    DryRunResults?: DryRunResults;
}
export type NonEmptyString = string;
export type ValueStringList = string[];
export interface Filter {
    Name?: string;
    Values?: string[];
}
export type FilterList = Filter[];
export interface DescribeInboundConnectionsRequest {
    Filters?: Filter[];
    MaxResults?: number;
    NextToken?: string;
}
export type InboundConnections = InboundConnection[];
export interface DescribeInboundConnectionsResponse {
    Connections?: InboundConnection[];
    NextToken?: string;
}
export type InsightEntityType = "Account" | "DomainName" | (string & {});
export type InsightEntityValue = string;
export interface InsightEntity {
    Type: InsightEntityType;
    Value?: string;
}
export interface DescribeInsightDetailsRequest {
    Entity: InsightEntity;
    InsightId: string;
    ShowHtmlContent?: boolean;
}
export type InsightFieldType = "text" | "metric" | (string & {});
export interface InsightField {
    Name: string;
    Type: InsightFieldType;
    Value: string;
}
export type InsightFieldList = InsightField[];
export interface DescribeInsightDetailsResponse {
    Fields: InsightField[];
}
export interface DescribeInstanceTypeLimitsRequest {
    DomainName?: string;
    InstanceType: OpenSearchPartitionInstanceType;
    EngineVersion: string;
}
export type InstanceRole = string;
export type StorageSubTypeName = string;
export type LimitName = string;
export type LimitValue = string;
export type LimitValueList = string[];
export interface StorageTypeLimit {
    LimitName?: string;
    LimitValues?: string[];
}
export type StorageTypeLimitList = StorageTypeLimit[];
export interface StorageType {
    StorageTypeName?: string;
    StorageSubTypeName?: string;
    StorageTypeLimits?: StorageTypeLimit[];
}
export type StorageTypeList = StorageType[];
export type MinimumInstanceCount = number;
export type MaximumInstanceCount = number;
export interface InstanceCountLimits {
    MinimumInstanceCount?: number;
    MaximumInstanceCount?: number;
}
export interface InstanceLimits {
    InstanceCountLimits?: InstanceCountLimits;
}
export interface AdditionalLimit {
    LimitName?: string;
    LimitValues?: string[];
}
export type AdditionalLimitList = AdditionalLimit[];
export interface Limits {
    StorageTypes?: StorageType[];
    InstanceLimits?: InstanceLimits;
    AdditionalLimits?: AdditionalLimit[];
}
export type LimitsByRole = {
    [key: string]: Limits | undefined;
};
export interface DescribeInstanceTypeLimitsResponse {
    LimitsByRole?: {
        [key: string]: Limits | undefined;
    };
}
export interface DescribeOutboundConnectionsRequest {
    Filters?: Filter[];
    MaxResults?: number;
    NextToken?: string;
}
export type OutboundConnections = OutboundConnection[];
export interface DescribeOutboundConnectionsResponse {
    Connections?: OutboundConnection[];
    NextToken?: string;
}
export type DescribePackagesFilterName = "PackageID" | "PackageName" | "PackageStatus" | "PackageType" | "EngineVersion" | "PackageOwner" | (string & {});
export type DescribePackagesFilterValue = string;
export type DescribePackagesFilterValues = string[];
export interface DescribePackagesFilter {
    Name?: DescribePackagesFilterName;
    Value?: string[];
}
export type DescribePackagesFilterList = DescribePackagesFilter[];
export interface DescribePackagesRequest {
    Filters?: DescribePackagesFilter[];
    MaxResults?: number;
    NextToken?: string;
}
export type PackageDetailsList = PackageDetails[];
export interface DescribePackagesResponse {
    PackageDetailsList?: PackageDetails[];
    NextToken?: string;
}
export interface DescribeReservedInstanceOfferingsRequest {
    ReservedInstanceOfferingId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type ReservedInstancePaymentOption = "ALL_UPFRONT" | "PARTIAL_UPFRONT" | "NO_UPFRONT" | (string & {});
export interface RecurringCharge {
    RecurringChargeAmount?: number;
    RecurringChargeFrequency?: string;
}
export type RecurringChargeList = RecurringCharge[];
export interface ReservedInstanceOffering {
    ReservedInstanceOfferingId?: string;
    InstanceType?: OpenSearchPartitionInstanceType;
    Duration?: number;
    FixedPrice?: number;
    UsagePrice?: number;
    CurrencyCode?: string;
    PaymentOption?: ReservedInstancePaymentOption;
    RecurringCharges?: RecurringCharge[];
}
export type ReservedInstanceOfferingList = ReservedInstanceOffering[];
export interface DescribeReservedInstanceOfferingsResponse {
    NextToken?: string;
    ReservedInstanceOfferings?: ReservedInstanceOffering[];
}
export interface DescribeReservedInstancesRequest {
    ReservedInstanceId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type ReservationToken = string;
export interface ReservedInstance {
    ReservationName?: string;
    ReservedInstanceId?: string;
    BillingSubscriptionId?: number;
    ReservedInstanceOfferingId?: string;
    InstanceType?: OpenSearchPartitionInstanceType;
    StartTime?: Date;
    Duration?: number;
    FixedPrice?: number;
    UsagePrice?: number;
    CurrencyCode?: string;
    InstanceCount?: number;
    State?: string;
    PaymentOption?: ReservedInstancePaymentOption;
    RecurringCharges?: RecurringCharge[];
}
export type ReservedInstanceList = ReservedInstance[];
export interface DescribeReservedInstancesResponse {
    NextToken?: string;
    ReservedInstances?: ReservedInstance[];
}
export type VpcEndpointIdList = string[];
export interface DescribeVpcEndpointsRequest {
    VpcEndpointIds: string[];
}
export type VpcEndpoints = VpcEndpoint[];
export type VpcEndpointErrorCode = "ENDPOINT_NOT_FOUND" | "SERVER_ERROR" | (string & {});
export interface VpcEndpointError {
    VpcEndpointId?: string;
    ErrorCode?: VpcEndpointErrorCode;
    ErrorMessage?: string;
}
export type VpcEndpointErrorList = VpcEndpointError[];
export interface DescribeVpcEndpointsResponse {
    VpcEndpoints: VpcEndpoint[];
    VpcEndpointErrors: VpcEndpointError[];
}
export interface DetachDataSourceRequest {
    id: string;
    dataSourceArn: string;
}
export interface DetachDataSourceResponse {
    id?: string;
    arn?: string;
    dataSourceArn?: string;
}
export interface DissociatePackageRequest {
    PackageID: string;
    DomainName: string;
}
export interface DissociatePackageResponse {
    DomainPackageDetails?: DomainPackageDetails;
}
export interface DissociatePackagesRequest {
    PackageList: string[];
    DomainName: string;
}
export interface DissociatePackagesResponse {
    DomainPackageDetailsList?: DomainPackageDetails[];
}
export interface GetApplicationRequest {
    id: string;
}
export type ApplicationStatus = "CREATING" | "UPDATING" | "DELETING" | "ACTIVE" | "FAILED" | (string & {});
export interface GetApplicationResponse {
    id?: string;
    arn?: string;
    name?: string;
    endpoint?: string;
    status?: ApplicationStatus;
    iamIdentityCenterOptions?: IamIdentityCenterOptions;
    dataSources?: DataSource[];
    appConfigs?: AppConfig[];
    createdAt?: Date;
    lastUpdatedAt?: Date;
    kmsKeyArn?: string;
}
export interface GetCapabilityRequest {
    applicationId: string;
    capabilityName: string;
}
export interface AIConfig {
}
export type CapabilityExtendedResponseConfig = {
    aiConfig: AIConfig;
};
export type CapabilityFailureReason = "KMS_KEY_INSUFFICIENT_PERMISSION" | (string & {});
export type CapabilityFailureDetails = string;
export interface CapabilityFailure {
    reason?: CapabilityFailureReason;
    details?: string;
}
export type CapabilityFailures = CapabilityFailure[];
export interface GetCapabilityResponse {
    capabilityName?: string;
    applicationId?: string;
    status?: CapabilityStatus;
    capabilityConfig?: CapabilityExtendedResponseConfig;
    failures?: CapabilityFailure[];
}
export interface GetCompatibleVersionsRequest {
    DomainName?: string;
}
export type VersionList = string[];
export interface CompatibleVersionsMap {
    SourceVersion?: string;
    TargetVersions?: string[];
}
export type CompatibleVersionsList = CompatibleVersionsMap[];
export interface GetCompatibleVersionsResponse {
    CompatibleVersions?: CompatibleVersionsMap[];
}
export interface GetDataSourceRequest {
    DomainName: string;
    Name: string;
}
export type DataSourceStatus = "ACTIVE" | "DISABLED" | (string & {});
export interface GetDataSourceResponse {
    DataSourceType?: DataSourceType;
    Name?: string;
    Description?: string;
    Status?: DataSourceStatus;
}
export interface GetDefaultApplicationSettingRequest {
}
export interface GetDefaultApplicationSettingResponse {
    applicationArn?: string;
}
export interface GetDirectQueryDataSourceRequest {
    DataSourceName: string;
}
export interface GetDirectQueryDataSourceResponse {
    DataSourceName?: string;
    DataSourceType?: DirectQueryDataSourceType;
    Description?: string;
    OpenSearchArns?: string[];
    DataSourceAccessPolicy?: string;
    DataSourceArn?: string;
}
export type RequestId = string;
export interface GetDomainMaintenanceStatusRequest {
    DomainName: string;
    MaintenanceId: string;
}
export type MaintenanceStatus = "PENDING" | "IN_PROGRESS" | "COMPLETED" | "FAILED" | "TIMED_OUT" | (string & {});
export type MaintenanceStatusMessage = string;
export type MaintenanceType = "REBOOT_NODE" | "RESTART_SEARCH_PROCESS" | "RESTART_DASHBOARD" | (string & {});
export interface GetDomainMaintenanceStatusResponse {
    Status?: MaintenanceStatus;
    StatusMessage?: string;
    NodeId?: string;
    Action?: MaintenanceType;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export interface GetIndexRequest {
    DomainName: string;
    IndexName: string;
}
export interface GetIndexResponse {
    IndexSchema: any;
}
export interface GetMigrationRequest {
    migrationId: string;
}
export interface MigrationSource {
    datasourceArn: string;
}
export interface MigrationError {
    code?: string;
    message?: string;
}
export interface GetMigrationResponse {
    migrationId?: string;
    status?: string;
    applicationId?: string;
    source?: MigrationSource;
    exportedCount?: number;
    importedCount?: number;
    error?: MigrationError;
    createdAt?: Date;
    updatedAt?: Date;
}
export interface GetPackageVersionHistoryRequest {
    PackageID: string;
    MaxResults?: number;
    NextToken?: string;
}
export type CommitMessage = string;
export interface PackageVersionHistory {
    PackageVersion?: string;
    CommitMessage?: string;
    CreatedAt?: Date;
    PluginProperties?: PluginProperties;
    PackageConfiguration?: PackageConfiguration;
}
export type PackageVersionHistoryList = PackageVersionHistory[];
export interface GetPackageVersionHistoryResponse {
    PackageID?: string;
    PackageVersionHistoryList?: PackageVersionHistory[];
    NextToken?: string;
}
export interface GetUpgradeHistoryRequest {
    DomainName: string;
    MaxResults?: number;
    NextToken?: string;
}
export type UpgradeName = string;
export type StartTimestamp = Date;
export type UpgradeStatus = "IN_PROGRESS" | "SUCCEEDED" | "SUCCEEDED_WITH_ISSUES" | "FAILED" | (string & {});
export type UpgradeStep = "PRE_UPGRADE_CHECK" | "SNAPSHOT" | "UPGRADE" | (string & {});
export type Issue = string;
export type Issues = string[];
export interface UpgradeStepItem {
    UpgradeStep?: UpgradeStep;
    UpgradeStepStatus?: UpgradeStatus;
    Issues?: string[];
    ProgressPercent?: number;
}
export type UpgradeStepsList = UpgradeStepItem[];
export interface UpgradeHistory {
    UpgradeName?: string;
    StartTimestamp?: Date;
    UpgradeStatus?: UpgradeStatus;
    StepsList?: UpgradeStepItem[];
}
export type UpgradeHistoryList = UpgradeHistory[];
export interface GetUpgradeHistoryResponse {
    UpgradeHistories?: UpgradeHistory[];
    NextToken?: string;
}
export interface GetUpgradeStatusRequest {
    DomainName: string;
}
export interface GetUpgradeStatusResponse {
    UpgradeStep?: UpgradeStep;
    StepStatus?: UpgradeStatus;
    UpgradeName?: string;
}
export type InsightFeedbackEntityType = "DomainName" | (string & {});
export interface InsightFeedbackEntity {
    Type: InsightFeedbackEntityType;
    Value: string;
}
export type InsightFeedbackThumbs = "Up" | "Down" | (string & {});
export type InsightFeedbackText = string;
export interface InsightFeedbackRequest {
    Entity: InsightFeedbackEntity;
    InsightId: string;
    Thumbs: InsightFeedbackThumbs;
    FeedbackText?: string;
}
export type InsightResponseStatus = "SUCCESS" | "ERROR" | (string & {});
export interface InsightFeedbackResponse {
    Status?: InsightResponseStatus;
}
export type ApplicationStatuses = ApplicationStatus[];
export interface ListApplicationsRequest {
    nextToken?: string;
    statuses?: ApplicationStatus[];
    maxResults?: number;
}
export interface ApplicationSummary {
    id?: string;
    arn?: string;
    name?: string;
    endpoint?: string;
    status?: ApplicationStatus;
    createdAt?: Date;
    lastUpdatedAt?: Date;
}
export type ApplicationSummaries = ApplicationSummary[];
export interface ListApplicationsResponse {
    ApplicationSummaries?: ApplicationSummary[];
    nextToken?: string;
}
export interface ListDataSourceAttachmentsRequest {
    id: string;
    nextToken?: string;
    maxResults?: number;
}
export interface DataSourceAttachmentSummary {
    attachmentId?: string;
    dataSourceArn?: string;
    status?: DataSourceAttachmentStatus;
}
export type DataSourceAttachmentSummaryList = DataSourceAttachmentSummary[];
export interface ListDataSourceAttachmentsResponse {
    attachments?: DataSourceAttachmentSummary[];
    nextToken?: string;
}
export interface ListDataSourcesRequest {
    DomainName: string;
}
export interface DataSourceDetails {
    DataSourceType?: DataSourceType;
    Name?: string;
    Description?: string;
    Status?: DataSourceStatus;
}
export type DataSourceList = DataSourceDetails[];
export interface ListDataSourcesResponse {
    DataSources?: DataSourceDetails[];
}
export interface ListDirectQueryDataSourcesRequest {
    NextToken?: string;
}
export interface DirectQueryDataSource {
    DataSourceName?: string;
    DataSourceType?: DirectQueryDataSourceType;
    Description?: string;
    OpenSearchArns?: string[];
    DataSourceArn?: string;
    TagList?: Tag[];
}
export type DirectQueryDataSourceList = DirectQueryDataSource[];
export interface ListDirectQueryDataSourcesResponse {
    NextToken?: string;
    DirectQueryDataSources?: DirectQueryDataSource[];
}
export interface ListDomainMaintenancesRequest {
    DomainName: string;
    Action?: MaintenanceType;
    Status?: MaintenanceStatus;
    MaxResults?: number;
    NextToken?: string;
}
export interface DomainMaintenanceDetails {
    MaintenanceId?: string;
    DomainName?: string;
    Action?: MaintenanceType;
    NodeId?: string;
    Status?: MaintenanceStatus;
    StatusMessage?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export type DomainMaintenanceList = DomainMaintenanceDetails[];
export interface ListDomainMaintenancesResponse {
    DomainMaintenances?: DomainMaintenanceDetails[];
    NextToken?: string;
}
export type EngineType = "OpenSearch" | "Elasticsearch" | (string & {});
export interface ListDomainNamesRequest {
    EngineType?: EngineType;
}
export interface DomainInfo {
    DomainName?: string;
    EngineType?: EngineType;
}
export type DomainInfoList = DomainInfo[];
export interface ListDomainNamesResponse {
    DomainNames?: DomainInfo[];
}
export interface ListDomainsForPackageRequest {
    PackageID: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface ListDomainsForPackageResponse {
    DomainPackageDetailsList?: DomainPackageDetails[];
    NextToken?: string;
}
export interface InsightTimeRange {
    From: number;
    To: number;
}
export type InsightSortOrder = "ASC" | "DESC" | (string & {});
export type InsightPageSize = number;
export interface ListInsightsRequest {
    Entity: InsightEntity;
    TimeRange?: InsightTimeRange;
    SortOrder?: InsightSortOrder;
    MaxResults?: number;
    NextToken?: string;
}
export type InsightType = "EVENT" | "RECOMMENDATION" | (string & {});
export type InsightPriorityLevel = "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | (string & {});
export type InsightStatus = "ACTIVE" | "RESOLVED" | "DISMISSED" | (string & {});
export interface Insight {
    InsightId?: string;
    DisplayName?: string;
    Type?: InsightType;
    Priority?: InsightPriorityLevel;
    Status?: InsightStatus;
    CreationTime?: Date;
    UpdateTime?: Date;
    IsExperimental?: boolean;
}
export type InsightList = Insight[];
export interface ListInsightsResponse {
    Insights?: Insight[];
    NextToken?: string;
}
export type InstanceTypeString = string;
export interface ListInstanceTypeDetailsRequest {
    EngineVersion: string;
    DomainName?: string;
    MaxResults?: number;
    NextToken?: string;
    RetrieveAZs?: boolean;
    InstanceType?: string;
}
export type InstanceRoleList = string[];
export type AvailabilityZoneList = string[];
export interface InstanceTypeDetails {
    InstanceType?: OpenSearchPartitionInstanceType;
    EncryptionEnabled?: boolean;
    CognitoEnabled?: boolean;
    AppLogsEnabled?: boolean;
    AdvancedSecurityEnabled?: boolean;
    WarmEnabled?: boolean;
    InstanceRole?: string[];
    AvailabilityZones?: string[];
}
export type InstanceTypeDetailsList = InstanceTypeDetails[];
export interface ListInstanceTypeDetailsResponse {
    InstanceTypeDetails?: InstanceTypeDetails[];
    NextToken?: string;
}
export interface ListMigrationsRequest {
    applicationId: string;
    status?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface MigrationSummary {
    migrationId?: string;
    status?: string;
    applicationId?: string;
    source?: MigrationSource;
    exportedCount?: number;
    importedCount?: number;
    error?: MigrationError;
    createdAt?: Date;
    updatedAt?: Date;
}
export type MigrationSummaryList = MigrationSummary[];
export interface ListMigrationsResponse {
    migrations?: MigrationSummary[];
    nextToken?: string;
}
export interface ListPackagesForDomainRequest {
    DomainName: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface ListPackagesForDomainResponse {
    DomainPackageDetailsList?: DomainPackageDetails[];
    NextToken?: string;
}
export interface ListScheduledActionsRequest {
    DomainName: string;
    MaxResults?: number;
    NextToken?: string;
}
export type ActionType = "SERVICE_SOFTWARE_UPDATE" | "JVM_HEAP_SIZE_TUNING" | "JVM_YOUNG_GEN_TUNING" | (string & {});
export type ActionSeverity = "HIGH" | "MEDIUM" | "LOW" | (string & {});
export type ScheduledBy = "CUSTOMER" | "SYSTEM" | (string & {});
export type ActionStatus = "PENDING_UPDATE" | "IN_PROGRESS" | "FAILED" | "COMPLETED" | "NOT_ELIGIBLE" | "ELIGIBLE" | (string & {});
export interface ScheduledAction {
    Id: string;
    Type: ActionType;
    Severity: ActionSeverity;
    ScheduledTime: number;
    Description?: string;
    ScheduledBy?: ScheduledBy;
    Status?: ActionStatus;
    Mandatory?: boolean;
    Cancellable?: boolean;
}
export type ScheduledActionsList = ScheduledAction[];
export interface ListScheduledActionsResponse {
    ScheduledActions?: ScheduledAction[];
    NextToken?: string;
}
export interface ListTagsRequest {
    ARN: string;
}
export interface ListTagsResponse {
    TagList?: Tag[];
}
export interface ListVersionsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface ListVersionsResponse {
    Versions?: string[];
    NextToken?: string;
}
export interface ListVpcEndpointAccessRequest {
    DomainName: string;
    NextToken?: string;
}
export type AuthorizedPrincipalList = AuthorizedPrincipal[];
export interface ListVpcEndpointAccessResponse {
    AuthorizedPrincipalList: AuthorizedPrincipal[];
    NextToken: string;
}
export interface ListVpcEndpointsRequest {
    NextToken?: string;
}
export type VpcEndpointSummaryList = VpcEndpointSummary[];
export interface ListVpcEndpointsResponse {
    VpcEndpointSummaryList: VpcEndpointSummary[];
    NextToken: string;
}
export interface ListVpcEndpointsForDomainRequest {
    DomainName: string;
    NextToken?: string;
}
export interface ListVpcEndpointsForDomainResponse {
    VpcEndpointSummaryList: VpcEndpointSummary[];
    NextToken: string;
}
export type InstanceCount = number;
export interface PurchaseReservedInstanceOfferingRequest {
    ReservedInstanceOfferingId: string;
    ReservationName: string;
    InstanceCount?: number;
}
export interface PurchaseReservedInstanceOfferingResponse {
    ReservedInstanceId?: string;
    ReservationName?: string;
}
export interface PutDefaultApplicationSettingRequest {
    applicationArn: string;
    setAsDefault: boolean;
}
export interface PutDefaultApplicationSettingResponse {
    applicationArn?: string;
}
export type CapabilityBaseRequestConfig = {
    aiConfig: AIConfig;
};
export interface RegisterCapabilityRequest {
    applicationId: string;
    capabilityName: string;
    capabilityConfig: CapabilityBaseRequestConfig;
}
export type CapabilityBaseResponseConfig = {
    aiConfig: AIConfig;
};
export interface RegisterCapabilityResponse {
    capabilityName?: string;
    applicationId?: string;
    status?: CapabilityStatus;
    capabilityConfig?: CapabilityBaseResponseConfig;
}
export interface RejectInboundConnectionRequest {
    ConnectionId: string;
}
export interface RejectInboundConnectionResponse {
    Connection?: InboundConnection;
}
export interface RemoveTagsRequest {
    ARN: string;
    TagKeys: string[];
}
export interface RemoveTagsResponse {
}
export interface RevokeVpcEndpointAccessRequest {
    DomainName: string;
    Account?: string;
    Service?: AWSServicePrincipal;
    ServiceOptions?: ServiceOptions;
}
export interface RevokeVpcEndpointAccessResponse {
}
export interface RollbackServiceSoftwareUpdateRequest {
    DomainName: string;
}
export interface RollbackServiceSoftwareOptions {
    CurrentVersion?: string;
    NewVersion?: string;
    RollbackAvailable?: boolean;
    Description?: string;
}
export interface RollbackServiceSoftwareUpdateResponse {
    RollbackServiceSoftwareOptions?: RollbackServiceSoftwareOptions;
}
export interface StartDomainMaintenanceRequest {
    DomainName: string;
    Action: MaintenanceType;
    NodeId?: string;
}
export interface StartDomainMaintenanceResponse {
    MaintenanceId?: string;
}
export interface MigrationWorkspace {
    workspaceId?: string;
    createWorkspace?: boolean;
    name?: string;
    type?: string;
}
export interface SavedObjectIdentifier {
    type: string;
    id: string;
}
export type SavedObjectIdentifierList = SavedObjectIdentifier[];
export interface ExportOptions {
    types?: string[];
    objects?: SavedObjectIdentifier[];
    includeReferencesDeep?: boolean;
}
export interface MigrationOptions {
    source: MigrationSource;
    workspace: MigrationWorkspace;
    exportOptions?: ExportOptions;
    conflictResolution?: string;
}
export interface StartMigrationRequest {
    applicationId: string;
    migrationOptions: MigrationOptions;
    clientToken?: string;
}
export interface StartMigrationResponse {
    migrationId?: string;
    status?: string;
}
export type ScheduleAt = "NOW" | "TIMESTAMP" | "OFF_PEAK_WINDOW" | (string & {});
export interface StartServiceSoftwareUpdateRequest {
    DomainName: string;
    ScheduleAt?: ScheduleAt;
    DesiredStartTime?: number;
}
export interface StartServiceSoftwareUpdateResponse {
    ServiceSoftwareOptions?: ServiceSoftwareOptions;
}
export interface UpdateApplicationRequest {
    id: string;
    dataSources?: DataSource[];
    appConfigs?: AppConfig[];
    iamIdentityCenterOptions?: IamIdentityCenterOptionsInput;
}
export interface UpdateApplicationResponse {
    id?: string;
    name?: string;
    arn?: string;
    dataSources?: DataSource[];
    iamIdentityCenterOptions?: IamIdentityCenterOptions;
    appConfigs?: AppConfig[];
    createdAt?: Date;
    lastUpdatedAt?: Date;
}
export interface UpdateDataSourceRequest {
    DomainName: string;
    Name: string;
    DataSourceType: DataSourceType;
    Description?: string;
    Status?: DataSourceStatus;
}
export interface UpdateDataSourceResponse {
    Message?: string;
}
export interface UpdateDirectQueryDataSourceRequest {
    DataSourceName: string;
    DataSourceType: DirectQueryDataSourceType;
    Description?: string;
    OpenSearchArns?: string[];
    DataSourceAccessPolicy?: string;
}
export interface UpdateDirectQueryDataSourceResponse {
    DataSourceArn?: string;
}
export type DryRunMode = "Basic" | "Verbose" | (string & {});
export interface UpdateDomainConfigRequest {
    DomainName: string;
    ClusterConfig?: ClusterConfig;
    EBSOptions?: EBSOptions;
    SnapshotOptions?: SnapshotOptions;
    VPCOptions?: VPCOptions;
    CognitoOptions?: CognitoOptions;
    AdvancedOptions?: {
        [key: string]: string | undefined;
    };
    AccessPolicies?: string;
    IPAddressType?: IPAddressType;
    LogPublishingOptions?: {
        [key: string]: LogPublishingOption | undefined;
    };
    EncryptionAtRestOptions?: EncryptionAtRestOptions;
    DomainEndpointOptions?: DomainEndpointOptions;
    NodeToNodeEncryptionOptions?: NodeToNodeEncryptionOptions;
    AdvancedSecurityOptions?: AdvancedSecurityOptionsInput;
    IdentityCenterOptions?: IdentityCenterOptionsInput;
    AutoTuneOptions?: AutoTuneOptions;
    DryRun?: boolean;
    DryRunMode?: DryRunMode;
    OffPeakWindowOptions?: OffPeakWindowOptions;
    SoftwareUpdateOptions?: SoftwareUpdateOptions;
    AIMLOptions?: AIMLOptionsInput;
    DeploymentStrategyOptions?: DeploymentStrategyOptions;
    AutomatedSnapshotPauseOptions?: AutomatedSnapshotPauseRequestOptions;
    UseCase?: DomainUseCase;
    EngineMode?: EngineMode;
    AcceptedWarnings?: string[];
}
export interface UpdateDomainConfigResponse {
    DomainConfig: DomainConfig;
    DryRunResults?: DryRunResults;
    DryRunProgressStatus?: DryRunProgressStatus;
}
export interface UpdateIndexRequest {
    DomainName: string;
    IndexName: string;
    IndexSchema: any;
}
export interface UpdateIndexResponse {
    Status: IndexStatus;
}
export interface UpdatePackageRequest {
    PackageID: string;
    PackageSource: PackageSource;
    PackageDescription?: string;
    CommitMessage?: string;
    PackageConfiguration?: PackageConfiguration;
    PackageEncryptionOptions?: PackageEncryptionOptions;
}
export interface UpdatePackageResponse {
    PackageDetails?: PackageDetails;
}
export type PackageScopeOperationEnum = "ADD" | "OVERRIDE" | "REMOVE" | (string & {});
export interface UpdatePackageScopeRequest {
    PackageID: string;
    Operation: PackageScopeOperationEnum;
    PackageUserList: string[];
}
export interface UpdatePackageScopeResponse {
    PackageID?: string;
    Operation?: PackageScopeOperationEnum;
    PackageUserList?: string[];
}
export interface UpdateScheduledActionRequest {
    DomainName: string;
    ActionID: string;
    ActionType: ActionType;
    ScheduleAt: ScheduleAt;
    DesiredStartTime?: number;
}
export interface UpdateScheduledActionResponse {
    ScheduledAction?: ScheduledAction;
}
export interface UpdateVpcEndpointRequest {
    VpcEndpointId: string;
    VpcOptions: VPCOptions;
}
export interface UpdateVpcEndpointResponse {
    VpcEndpoint: VpcEndpoint;
}
export interface UpgradeDomainRequest {
    DomainName: string;
    TargetVersion: string;
    PerformCheckOnly?: boolean;
    AdvancedOptions?: {
        [key: string]: string | undefined;
    };
}
export interface UpgradeDomainResponse {
    UpgradeId?: string;
    DomainName?: string;
    TargetVersion?: string;
    PerformCheckOnly?: boolean;
    AdvancedOptions?: {
        [key: string]: string | undefined;
    };
    ChangeProgressDetails?: ChangeProgressDetails;
}
export type SlotList = number[];
export type AcceptInboundConnectionError = DisabledOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Allows the destination Amazon OpenSearch Service domain owner to accept an inbound
 * cross-cluster search connection request. For more information, see Cross-cluster search for Amazon OpenSearch Service.
 */
export declare const acceptInboundConnection: API.OperationMethod<AcceptInboundConnectionRequest, AcceptInboundConnectionResponse, AcceptInboundConnectionError, Credentials | HttpClient.HttpClient>;
export type AddDataSourceError = BaseException | DependencyFailureException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates a new direct-query data source to the specified domain. For more information,
 * see Creating Amazon OpenSearch Service data source integrations with Amazon
 * S3.
 */
export declare const addDataSource: API.OperationMethod<AddDataSourceRequest, AddDataSourceResponse, AddDataSourceError, Credentials | HttpClient.HttpClient>;
export type AddDirectQueryDataSourceError = BaseException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds a new data source in Amazon OpenSearch Service so that you can perform direct
 * queries on external data.
 */
export declare const addDirectQueryDataSource: API.OperationMethod<AddDirectQueryDataSourceRequest, AddDirectQueryDataSourceResponse, AddDirectQueryDataSourceError, Credentials | HttpClient.HttpClient>;
export type AddTagsError = BaseException | InternalException | LimitExceededException | ValidationException | CommonErrors;
/**
 * Attaches tags to an existing Amazon OpenSearch Service domain, data source, or
 * application.
 *
 * Tags are a set of case-sensitive key-value pairs. A domain, data source, or
 * application can have up to 10 tags. For more information, see Tagging Amazon OpenSearch Service resources.
 */
export declare const addTags: API.OperationMethod<AddTagsRequest, AddTagsResponse, AddTagsError, Credentials | HttpClient.HttpClient>;
export type AssociatePackageError = AccessDeniedException | BaseException | ConflictException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Associates a package with an Amazon OpenSearch Service domain. For more information,
 * see Custom packages
 * for Amazon OpenSearch Service.
 */
export declare const associatePackage: API.OperationMethod<AssociatePackageRequest, AssociatePackageResponse, AssociatePackageError, Credentials | HttpClient.HttpClient>;
export type AssociatePackagesError = BaseException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Operation in the Amazon OpenSearch Service API for associating multiple packages with
 * a domain simultaneously.
 */
export declare const associatePackages: API.OperationMethod<AssociatePackagesRequest, AssociatePackagesResponse, AssociatePackagesError, Credentials | HttpClient.HttpClient>;
export type AttachDataSourceError = AccessDeniedException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Attaches a data source to an OpenSearch application. The data source must be an Amazon OpenSearch Service domain. If both the application and the data source are active, the attachment completes immediately with a status of `ATTACHED`. Otherwise, the operation returns `PENDING` and completes the attachment automatically once both become active. If the attachment cannot be completed, its status becomes `FAILED`. This operation is idempotent: If the data source is already attached or pending, the operation returns the existing attachment.
 */
export declare const attachDataSource: API.OperationMethod<AttachDataSourceRequest, AttachDataSourceResponse, AttachDataSourceError, Credentials | HttpClient.HttpClient>;
export type AuthorizeVpcEndpointAccessError = BaseException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Provides access to an Amazon OpenSearch Service domain through the use of an interface
 * VPC endpoint.
 */
export declare const authorizeVpcEndpointAccess: API.OperationMethod<AuthorizeVpcEndpointAccessRequest, AuthorizeVpcEndpointAccessResponse, AuthorizeVpcEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type CancelDomainConfigChangeError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Cancels a pending configuration change on an Amazon OpenSearch Service domain.
 */
export declare const cancelDomainConfigChange: API.OperationMethod<CancelDomainConfigChangeRequest, CancelDomainConfigChangeResponse, CancelDomainConfigChangeError, Credentials | HttpClient.HttpClient>;
export type CancelServiceSoftwareUpdateError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Cancels a scheduled service software update for an Amazon OpenSearch Service domain.
 * You can only perform this operation before the `AutomatedUpdateDate` and when
 * the domain's `UpdateStatus` is `PENDING_UPDATE`. For more
 * information, see Service
 * software updates in Amazon OpenSearch Service.
 */
export declare const cancelServiceSoftwareUpdate: API.OperationMethod<CancelServiceSoftwareUpdateRequest, CancelServiceSoftwareUpdateResponse, CancelServiceSoftwareUpdateError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = AccessDeniedException | BaseException | ConflictException | DisabledOperationException | InternalException | ValidationException | CommonErrors;
/**
 * Creates an OpenSearch UI application. For more information, see Using the OpenSearch user interface in Amazon OpenSearch Service.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateDomainError = BaseException | DisabledOperationException | InternalException | InvalidTypeException | LimitExceededException | ResourceAlreadyExistsException | ValidationException | CommonErrors;
/**
 * Creates an Amazon OpenSearch Service domain. For more information, see Creating and
 * managing Amazon OpenSearch Service domains.
 */
export declare const createDomain: API.OperationMethod<CreateDomainRequest, CreateDomainResponse, CreateDomainError, Credentials | HttpClient.HttpClient>;
export type CreateIndexError = AccessDeniedException | DependencyFailureException | DisabledOperationException | InternalException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an OpenSearch index with optional automatic semantic enrichment for specified text fields. Automatic semantic enrichment enables semantic search capabilities without requiring machine learning expertise, improving search relevance by up to 20% by understanding search intent and contextual meaning beyond keyword matching. The semantic enrichment process has zero impact on search latency as sparse encodings are stored directly within the index during indexing. For more information, see Automatic semantic enrichment.
 */
export declare const createIndex: API.OperationMethod<CreateIndexRequest, CreateIndexResponse, CreateIndexError, Credentials | HttpClient.HttpClient>;
export type CreateOutboundConnectionError = DisabledOperationException | InternalException | LimitExceededException | ResourceAlreadyExistsException | CommonErrors;
/**
 * Creates a new cross-cluster search connection from a source Amazon OpenSearch Service domain
 * to a destination domain. For more information, see Cross-cluster search
 * for Amazon OpenSearch Service.
 */
export declare const createOutboundConnection: API.OperationMethod<CreateOutboundConnectionRequest, CreateOutboundConnectionResponse, CreateOutboundConnectionError, Credentials | HttpClient.HttpClient>;
export type CreatePackageError = AccessDeniedException | BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceAlreadyExistsException | ValidationException | CommonErrors;
/**
 * Creates a package for use with Amazon OpenSearch Service domains. For more
 * information, see Custom packages
 * for Amazon OpenSearch Service.
 */
export declare const createPackage: API.OperationMethod<CreatePackageRequest, CreatePackageResponse, CreatePackageError, Credentials | HttpClient.HttpClient>;
export type CreateVpcEndpointError = BaseException | ConflictException | DisabledOperationException | InternalException | LimitExceededException | ValidationException | CommonErrors;
/**
 * Creates an Amazon OpenSearch Service-managed VPC endpoint.
 */
export declare const createVpcEndpoint: API.OperationMethod<CreateVpcEndpointRequest, CreateVpcEndpointResponse, CreateVpcEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = AccessDeniedException | BaseException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a specified OpenSearch application.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteDataSourceError = BaseException | DependencyFailureException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a direct-query data source. For more information, see Deleting
 * an Amazon OpenSearch Service data source with Amazon S3.
 */
export declare const deleteDataSource: API.OperationMethod<DeleteDataSourceRequest, DeleteDataSourceResponse, DeleteDataSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteDirectQueryDataSourceError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a previously configured direct query data source from Amazon OpenSearch
 * Service.
 */
export declare const deleteDirectQueryDataSource: API.OperationMethod<DeleteDirectQueryDataSourceRequest, DeleteDirectQueryDataSourceResponse, DeleteDirectQueryDataSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon OpenSearch Service domain and all of its data. You can't recover a
 * domain after you delete it.
 */
export declare const deleteDomain: API.OperationMethod<DeleteDomainRequest, DeleteDomainResponse, DeleteDomainError, Credentials | HttpClient.HttpClient>;
export type DeleteInboundConnectionError = DisabledOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Allows the destination Amazon OpenSearch Service domain owner to delete an existing
 * inbound cross-cluster search connection. For more information, see Cross-cluster search for Amazon OpenSearch Service.
 */
export declare const deleteInboundConnection: API.OperationMethod<DeleteInboundConnectionRequest, DeleteInboundConnectionResponse, DeleteInboundConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteIndexError = AccessDeniedException | DependencyFailureException | DisabledOperationException | InternalException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an OpenSearch index. This operation permanently removes the index and cannot be undone.
 */
export declare const deleteIndex: API.OperationMethod<DeleteIndexRequest, DeleteIndexResponse, DeleteIndexError, Credentials | HttpClient.HttpClient>;
export type DeleteOutboundConnectionError = DisabledOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Allows the source Amazon OpenSearch Service domain owner to delete an existing
 * outbound cross-cluster search connection. For more information, see Cross-cluster search for Amazon OpenSearch Service.
 */
export declare const deleteOutboundConnection: API.OperationMethod<DeleteOutboundConnectionRequest, DeleteOutboundConnectionResponse, DeleteOutboundConnectionError, Credentials | HttpClient.HttpClient>;
export type DeletePackageError = AccessDeniedException | BaseException | ConflictException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon OpenSearch Service package. For more information, see Custom packages
 * for Amazon OpenSearch Service.
 */
export declare const deletePackage: API.OperationMethod<DeletePackageRequest, DeletePackageResponse, DeletePackageError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcEndpointError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an Amazon OpenSearch Service-managed interface VPC endpoint.
 */
export declare const deleteVpcEndpoint: API.OperationMethod<DeleteVpcEndpointRequest, DeleteVpcEndpointResponse, DeleteVpcEndpointError, Credentials | HttpClient.HttpClient>;
export type DeregisterCapabilityError = AccessDeniedException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deregisters a capability from an OpenSearch UI application. This operation removes the capability and its associated configuration.
 */
export declare const deregisterCapability: API.OperationMethod<DeregisterCapabilityRequest, DeregisterCapabilityResponse, DeregisterCapabilityError, Credentials | HttpClient.HttpClient>;
export type DescribeDataSourceAttachmentError = AccessDeniedException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the current status and details of a specific data source attachment for an OpenSearch application. Throws a `ResourceNotFoundException` if no attachment record exists for the specified application and data source combination.
 */
export declare const describeDataSourceAttachment: API.OperationMethod<DescribeDataSourceAttachmentRequest, DescribeDataSourceAttachmentResponse, DescribeDataSourceAttachmentError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the domain configuration for the specified Amazon OpenSearch Service domain,
 * including the domain ID, domain service endpoint, and domain ARN.
 */
export declare const describeDomain: API.OperationMethod<DescribeDomainRequest, DescribeDomainResponse, DescribeDomainError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainAutoTunesError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the list of optimizations that Auto-Tune has made to an Amazon OpenSearch
 * Service domain. For more information, see Auto-Tune for Amazon
 * OpenSearch Service.
 */
export declare const describeDomainAutoTunes: API.PaginatedOperationMethod<DescribeDomainAutoTunesRequest, DescribeDomainAutoTunesResponse, DescribeDomainAutoTunesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeDomainChangeProgressError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about the current blue/green deployment happening on an Amazon
 * OpenSearch Service domain. For more information, see Making configuration changes in Amazon OpenSearch Service.
 */
export declare const describeDomainChangeProgress: API.OperationMethod<DescribeDomainChangeProgressRequest, DescribeDomainChangeProgressResponse, DescribeDomainChangeProgressError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainConfigError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the configuration of an Amazon OpenSearch Service domain.
 */
export declare const describeDomainConfig: API.OperationMethod<DescribeDomainConfigRequest, DescribeDomainConfigResponse, DescribeDomainConfigError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainHealthError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about domain and node health, the standby Availability Zone,
 * number of nodes per Availability Zone, and shard count per node.
 */
export declare const describeDomainHealth: API.OperationMethod<DescribeDomainHealthRequest, DescribeDomainHealthResponse, DescribeDomainHealthError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainNodesError = BaseException | DependencyFailureException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about domain and nodes, including data nodes, master nodes,
 * ultrawarm nodes, Availability Zone(s), standby nodes, node configurations, and node
 * states.
 */
export declare const describeDomainNodes: API.OperationMethod<DescribeDomainNodesRequest, DescribeDomainNodesResponse, DescribeDomainNodesError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainsError = BaseException | InternalException | ValidationException | CommonErrors;
/**
 * Returns domain configuration information about the specified Amazon OpenSearch Service
 * domains.
 */
export declare const describeDomains: API.OperationMethod<DescribeDomainsRequest, DescribeDomainsResponse, DescribeDomainsError, Credentials | HttpClient.HttpClient>;
export type DescribeDryRunProgressError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the progress of a pre-update dry run analysis on an Amazon OpenSearch
 * Service domain. For more information, see Determining whether a change will cause a blue/green deployment.
 */
export declare const describeDryRunProgress: API.OperationMethod<DescribeDryRunProgressRequest, DescribeDryRunProgressResponse, DescribeDryRunProgressError, Credentials | HttpClient.HttpClient>;
export type DescribeInboundConnectionsError = DisabledOperationException | InvalidPaginationTokenException | CommonErrors;
/**
 * Lists all the inbound cross-cluster search connections for a destination (remote)
 * Amazon OpenSearch Service domain. For more information, see Cross-cluster search for Amazon OpenSearch Service.
 */
export declare const describeInboundConnections: API.PaginatedOperationMethod<DescribeInboundConnectionsRequest, DescribeInboundConnectionsResponse, DescribeInboundConnectionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeInsightDetailsError = BaseException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the details of an existing insight for an Amazon OpenSearch Service domain.
 * Returns detailed fields associated with the specified insight, such as text descriptions
 * and metric data.
 */
export declare const describeInsightDetails: API.OperationMethod<DescribeInsightDetailsRequest, DescribeInsightDetailsResponse, DescribeInsightDetailsError, Credentials | HttpClient.HttpClient>;
export type DescribeInstanceTypeLimitsError = BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the instance count, storage, and master node limits for a given OpenSearch
 * or Elasticsearch version and instance type.
 */
export declare const describeInstanceTypeLimits: API.OperationMethod<DescribeInstanceTypeLimitsRequest, DescribeInstanceTypeLimitsResponse, DescribeInstanceTypeLimitsError, Credentials | HttpClient.HttpClient>;
export type DescribeOutboundConnectionsError = DisabledOperationException | InvalidPaginationTokenException | CommonErrors;
/**
 * Lists all the outbound cross-cluster connections for a local (source) Amazon
 * OpenSearch Service domain. For more information, see Cross-cluster search for Amazon OpenSearch Service.
 */
export declare const describeOutboundConnections: API.PaginatedOperationMethod<DescribeOutboundConnectionsRequest, DescribeOutboundConnectionsResponse, DescribeOutboundConnectionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribePackagesError = AccessDeniedException | BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes all packages available to OpenSearch Service. For more information, see
 * Custom packages
 * for Amazon OpenSearch Service.
 */
export declare const describePackages: API.PaginatedOperationMethod<DescribePackagesRequest, DescribePackagesResponse, DescribePackagesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReservedInstanceOfferingsError = DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the available Amazon OpenSearch Service Reserved Instance offerings for a
 * given Region. For more information, see Reserved Instances in Amazon
 * OpenSearch Service.
 */
export declare const describeReservedInstanceOfferings: API.PaginatedOperationMethod<DescribeReservedInstanceOfferingsRequest, DescribeReservedInstanceOfferingsResponse, DescribeReservedInstanceOfferingsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReservedInstancesError = DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the Amazon OpenSearch Service instances that you have reserved in a given
 * Region. For more information, see Reserved Instances in Amazon
 * OpenSearch Service.
 */
export declare const describeReservedInstances: API.PaginatedOperationMethod<DescribeReservedInstancesRequest, DescribeReservedInstancesResponse, DescribeReservedInstancesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeVpcEndpointsError = BaseException | DisabledOperationException | InternalException | ValidationException | CommonErrors;
/**
 * Describes one or more Amazon OpenSearch Service-managed VPC endpoints.
 */
export declare const describeVpcEndpoints: API.OperationMethod<DescribeVpcEndpointsRequest, DescribeVpcEndpointsResponse, DescribeVpcEndpointsError, Credentials | HttpClient.HttpClient>;
export type DetachDataSourceError = AccessDeniedException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a data source from an OpenSearch application. The application must be in the `ACTIVE` state. This operation removes the data source saved object from the application and deletes the attachment record. Throws a `ConflictException` if the specified data source has a `PENDING` attachment, and a `ResourceNotFoundException` if the data source is not currently attached to the application.
 */
export declare const detachDataSource: API.OperationMethod<DetachDataSourceRequest, DetachDataSourceResponse, DetachDataSourceError, Credentials | HttpClient.HttpClient>;
export type DissociatePackageError = AccessDeniedException | BaseException | ConflictException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a package from the specified Amazon OpenSearch Service domain. The package
 * can't be in use with any OpenSearch index for the dissociation to succeed. The package
 * is still available in OpenSearch Service for association later. For more information,
 * see Custom packages
 * for Amazon OpenSearch Service.
 */
export declare const dissociatePackage: API.OperationMethod<DissociatePackageRequest, DissociatePackageResponse, DissociatePackageError, Credentials | HttpClient.HttpClient>;
export type DissociatePackagesError = BaseException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Dissociates multiple packages from a domain simultaneously.
 */
export declare const dissociatePackages: API.OperationMethod<DissociatePackagesRequest, DissociatePackagesResponse, DissociatePackagesError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = AccessDeniedException | BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the configuration and status of an existing OpenSearch application.
 */
export declare const getApplication: API.OperationMethod<GetApplicationRequest, GetApplicationResponse, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetCapabilityError = AccessDeniedException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves information about a registered capability for an OpenSearch UI application, including its configuration and current status.
 */
export declare const getCapability: API.OperationMethod<GetCapabilityRequest, GetCapabilityResponse, GetCapabilityError, Credentials | HttpClient.HttpClient>;
export type GetCompatibleVersionsError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a map of OpenSearch or Elasticsearch versions and the versions you can upgrade
 * them to.
 */
export declare const getCompatibleVersions: API.OperationMethod<GetCompatibleVersionsRequest, GetCompatibleVersionsResponse, GetCompatibleVersionsError, Credentials | HttpClient.HttpClient>;
export type GetDataSourceError = BaseException | DependencyFailureException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves information about a direct query data source.
 */
export declare const getDataSource: API.OperationMethod<GetDataSourceRequest, GetDataSourceResponse, GetDataSourceError, Credentials | HttpClient.HttpClient>;
export type GetDefaultApplicationSettingError = AccessDeniedException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets the ARN of the current default application.
 *
 * If the default application isn't set, the operation returns a resource not found
 * error.
 */
export declare const getDefaultApplicationSetting: API.OperationMethod<GetDefaultApplicationSettingRequest, GetDefaultApplicationSettingResponse, GetDefaultApplicationSettingError, Credentials | HttpClient.HttpClient>;
export type GetDirectQueryDataSourceError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns detailed configuration information for a specific direct query data source in
 * Amazon OpenSearch Service.
 */
export declare const getDirectQueryDataSource: API.OperationMethod<GetDirectQueryDataSourceRequest, GetDirectQueryDataSourceResponse, GetDirectQueryDataSourceError, Credentials | HttpClient.HttpClient>;
export type GetDomainMaintenanceStatusError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * The status of the maintenance action.
 */
export declare const getDomainMaintenanceStatus: API.OperationMethod<GetDomainMaintenanceStatusRequest, GetDomainMaintenanceStatusResponse, GetDomainMaintenanceStatusError, Credentials | HttpClient.HttpClient>;
export type GetIndexError = AccessDeniedException | DependencyFailureException | DisabledOperationException | InternalException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an OpenSearch index including its schema and semantic enrichment configuration. Use this operation to view the current index structure and semantic search settings.
 */
export declare const getIndex: API.OperationMethod<GetIndexRequest, GetIndexResponse, GetIndexError, Credentials | HttpClient.HttpClient>;
export type GetMigrationError = AccessDeniedException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the current status and progress of a migration job, including the number of exported and imported objects and error details if the migration failed.
 */
export declare const getMigration: API.OperationMethod<GetMigrationRequest, GetMigrationResponse, GetMigrationError, Credentials | HttpClient.HttpClient>;
export type GetPackageVersionHistoryError = AccessDeniedException | BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of Amazon OpenSearch Service package versions, along with their creation
 * time, commit message, and plugin properties (if the package is a zip plugin package). For more
 * information, see Custom packages for Amazon
 * OpenSearch Service.
 */
export declare const getPackageVersionHistory: API.PaginatedOperationMethod<GetPackageVersionHistoryRequest, GetPackageVersionHistoryResponse, GetPackageVersionHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type GetUpgradeHistoryError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the complete history of the last 10 upgrades performed on an Amazon OpenSearch
 * Service domain.
 */
export declare const getUpgradeHistory: API.PaginatedOperationMethod<GetUpgradeHistoryRequest, GetUpgradeHistoryResponse, GetUpgradeHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type GetUpgradeStatusError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the most recent status of the last upgrade or upgrade eligibility check performed on
 * an Amazon OpenSearch Service domain.
 */
export declare const getUpgradeStatus: API.OperationMethod<GetUpgradeStatusRequest, GetUpgradeStatusResponse, GetUpgradeStatusError, Credentials | HttpClient.HttpClient>;
export type InsightFeedbackError = BaseException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Submits feedback for an existing insight in an Amazon OpenSearch Service domain.
 * Allows users to provide a thumbs up or thumbs down rating and optional text feedback
 * for a specific insight.
 */
export declare const insightFeedback: API.OperationMethod<InsightFeedbackRequest, InsightFeedbackResponse, InsightFeedbackError, Credentials | HttpClient.HttpClient>;
export type ListApplicationsError = AccessDeniedException | BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all OpenSearch applications under your account.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationSummary>;
export type ListDataSourceAttachmentsError = AccessDeniedException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of all data source attachments for an OpenSearch application, including attachments in all states (`PENDING`, `ATTACHED`, and `FAILED`).
 */
export declare const listDataSourceAttachments: API.OperationMethod<ListDataSourceAttachmentsRequest, ListDataSourceAttachmentsResponse, ListDataSourceAttachmentsError, Credentials | HttpClient.HttpClient>;
export type ListDataSourcesError = BaseException | DependencyFailureException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists direct-query data sources for a specific domain. For more information, see For
 * more information, see Working with
 * Amazon OpenSearch Service direct queries with Amazon S3.
 */
export declare const listDataSources: API.OperationMethod<ListDataSourcesRequest, ListDataSourcesResponse, ListDataSourcesError, Credentials | HttpClient.HttpClient>;
export type ListDirectQueryDataSourcesError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists an inventory of all the direct query data sources that you have configured
 * within Amazon OpenSearch Service.
 */
export declare const listDirectQueryDataSources: API.OperationMethod<ListDirectQueryDataSourcesRequest, ListDirectQueryDataSourcesResponse, ListDirectQueryDataSourcesError, Credentials | HttpClient.HttpClient>;
export type ListDomainMaintenancesError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * A list of maintenance actions for the domain.
 */
export declare const listDomainMaintenances: API.PaginatedOperationMethod<ListDomainMaintenancesRequest, ListDomainMaintenancesResponse, ListDomainMaintenancesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDomainNamesError = BaseException | ValidationException | CommonErrors;
/**
 * Returns the names of all Amazon OpenSearch Service domains owned by the current user
 * in the active Region.
 */
export declare const listDomainNames: API.OperationMethod<ListDomainNamesRequest, ListDomainNamesResponse, ListDomainNamesError, Credentials | HttpClient.HttpClient>;
export type ListDomainsForPackageError = AccessDeniedException | BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all Amazon OpenSearch Service domains associated with a given package. For more
 * information, see Custom packages
 * for Amazon OpenSearch Service.
 */
export declare const listDomainsForPackage: API.PaginatedOperationMethod<ListDomainsForPackageRequest, ListDomainsForPackageResponse, ListDomainsForPackageError, Credentials | HttpClient.HttpClient, unknown>;
export type ListInsightsError = BaseException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists insights for an Amazon OpenSearch Service domain or Amazon Web Services account.
 * Returns a paginated list of insights based on the specified entity, filters, time range,
 * and sort order.
 */
export declare const listInsights: API.OperationMethod<ListInsightsRequest, ListInsightsResponse, ListInsightsError, Credentials | HttpClient.HttpClient>;
export type ListInstanceTypeDetailsError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all instance types and available features for a given OpenSearch or
 * Elasticsearch version.
 */
export declare const listInstanceTypeDetails: API.PaginatedOperationMethod<ListInstanceTypeDetailsRequest, ListInstanceTypeDetailsResponse, ListInstanceTypeDetailsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMigrationsError = AccessDeniedException | DisabledOperationException | InternalException | ValidationException | CommonErrors;
/**
 * Lists migration jobs for an Amazon OpenSearch Service application. You can filter results by migration status. Use pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listMigrations: API.OperationMethod<ListMigrationsRequest, ListMigrationsResponse, ListMigrationsError, Credentials | HttpClient.HttpClient>;
export type ListPackagesForDomainError = AccessDeniedException | BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all packages associated with an Amazon OpenSearch Service domain. For more
 * information, see Custom packages
 * for Amazon OpenSearch Service.
 */
export declare const listPackagesForDomain: API.PaginatedOperationMethod<ListPackagesForDomainRequest, ListPackagesForDomainResponse, ListPackagesForDomainError, Credentials | HttpClient.HttpClient, unknown>;
export type ListScheduledActionsError = BaseException | InternalException | InvalidPaginationTokenException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a list of configuration changes that are scheduled for a domain. These
 * changes can be service
 * software updates or blue/green Auto-Tune enhancements.
 */
export declare const listScheduledActions: API.PaginatedOperationMethod<ListScheduledActionsRequest, ListScheduledActionsResponse, ListScheduledActionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns all resource tags for an Amazon OpenSearch Service domain, data source, or
 * application. For more information, see Tagging Amazon OpenSearch Service resources.
 */
export declare const listTags: API.OperationMethod<ListTagsRequest, ListTagsResponse, ListTagsError, Credentials | HttpClient.HttpClient>;
export type ListVersionsError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all versions of OpenSearch and Elasticsearch that Amazon OpenSearch Service
 * supports.
 */
export declare const listVersions: API.PaginatedOperationMethod<ListVersionsRequest, ListVersionsResponse, ListVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListVpcEndpointAccessError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about each Amazon Web Services principal that is allowed to
 * access a given Amazon OpenSearch Service domain through the use of an interface VPC
 * endpoint.
 */
export declare const listVpcEndpointAccess: API.OperationMethod<ListVpcEndpointAccessRequest, ListVpcEndpointAccessResponse, ListVpcEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type ListVpcEndpointsError = BaseException | DisabledOperationException | InternalException | CommonErrors;
/**
 * Retrieves all Amazon OpenSearch Service-managed VPC endpoints in the current Amazon Web Services account and Region.
 */
export declare const listVpcEndpoints: API.OperationMethod<ListVpcEndpointsRequest, ListVpcEndpointsResponse, ListVpcEndpointsError, Credentials | HttpClient.HttpClient>;
export type ListVpcEndpointsForDomainError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves all Amazon OpenSearch Service-managed VPC endpoints associated with a
 * particular domain.
 */
export declare const listVpcEndpointsForDomain: API.OperationMethod<ListVpcEndpointsForDomainRequest, ListVpcEndpointsForDomainResponse, ListVpcEndpointsForDomainError, Credentials | HttpClient.HttpClient>;
export type PurchaseReservedInstanceOfferingError = DisabledOperationException | InternalException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Allows you to purchase Amazon OpenSearch Service Reserved Instances.
 */
export declare const purchaseReservedInstanceOffering: API.OperationMethod<PurchaseReservedInstanceOfferingRequest, PurchaseReservedInstanceOfferingResponse, PurchaseReservedInstanceOfferingError, Credentials | HttpClient.HttpClient>;
export type PutDefaultApplicationSettingError = AccessDeniedException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Sets the default application to the application with the specified ARN.
 *
 * To remove the default application, use the `GetDefaultApplicationSetting`
 * operation to get the current default and then call the
 * `PutDefaultApplicationSetting` with the current applications ARN and the
 * `setAsDefault` parameter set to `false`.
 */
export declare const putDefaultApplicationSetting: API.OperationMethod<PutDefaultApplicationSettingRequest, PutDefaultApplicationSettingResponse, PutDefaultApplicationSettingError, Credentials | HttpClient.HttpClient>;
export type RegisterCapabilityError = AccessDeniedException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Registers a capability for an OpenSearch UI application. Use this operation to enable specific capabilities, such as AI features, for a given application. The capability configuration defines the type and settings of the capability to register. For more information about the AI features, see Agentic AI for OpenSearch UI.
 */
export declare const registerCapability: API.OperationMethod<RegisterCapabilityRequest, RegisterCapabilityResponse, RegisterCapabilityError, Credentials | HttpClient.HttpClient>;
export type RejectInboundConnectionError = DisabledOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Allows the remote Amazon OpenSearch Service domain owner to reject an inbound
 * cross-cluster connection request.
 */
export declare const rejectInboundConnection: API.OperationMethod<RejectInboundConnectionRequest, RejectInboundConnectionResponse, RejectInboundConnectionError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsError = BaseException | InternalException | ValidationException | CommonErrors;
/**
 * Removes the specified set of tags from an Amazon OpenSearch Service domain, data
 * source, or application. For more information, see Tagging Amazon OpenSearch Service resources.
 */
export declare const removeTags: API.OperationMethod<RemoveTagsRequest, RemoveTagsResponse, RemoveTagsError, Credentials | HttpClient.HttpClient>;
export type RevokeVpcEndpointAccessError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Revokes access to an Amazon OpenSearch Service domain that was provided through an
 * interface VPC endpoint.
 */
export declare const revokeVpcEndpointAccess: API.OperationMethod<RevokeVpcEndpointAccessRequest, RevokeVpcEndpointAccessResponse, RevokeVpcEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type RollbackServiceSoftwareUpdateError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Rolls back a service software update for a domain to the previous version. For more
 * information, see Service
 * software updates in Amazon OpenSearch Service.
 */
export declare const rollbackServiceSoftwareUpdate: API.OperationMethod<RollbackServiceSoftwareUpdateRequest, RollbackServiceSoftwareUpdateResponse, RollbackServiceSoftwareUpdateError, Credentials | HttpClient.HttpClient>;
export type StartDomainMaintenanceError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Starts the node maintenance process on the data node. These processes can include a
 * node reboot, an Opensearch or Elasticsearch process restart, or a Dashboard or Kibana
 * restart.
 */
export declare const startDomainMaintenance: API.OperationMethod<StartDomainMaintenanceRequest, StartDomainMaintenanceResponse, StartDomainMaintenanceError, Credentials | HttpClient.HttpClient>;
export type StartMigrationError = AccessDeniedException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Initiates a migration job to migrate saved objects from a data source to an Amazon OpenSearch Service application workspace. Saved objects include dashboards, visualizations, index patterns, and searches. You can specify export filters to control the scope of the migration and a conflict resolution strategy for handling existing objects in the target workspace.
 */
export declare const startMigration: API.OperationMethod<StartMigrationRequest, StartMigrationResponse, StartMigrationError, Credentials | HttpClient.HttpClient>;
export type StartServiceSoftwareUpdateError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Schedules a service software update for an Amazon OpenSearch Service domain. For more
 * information, see Service
 * software updates in Amazon OpenSearch Service.
 */
export declare const startServiceSoftwareUpdate: API.OperationMethod<StartServiceSoftwareUpdateRequest, StartServiceSoftwareUpdateResponse, StartServiceSoftwareUpdateError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = AccessDeniedException | BaseException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the configuration and settings of an existing OpenSearch application.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateDataSourceError = BaseException | DependencyFailureException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a direct-query data source. For more information, see Working
 * with Amazon OpenSearch Service data source integrations with Amazon
 * S3.
 */
export declare const updateDataSource: API.OperationMethod<UpdateDataSourceRequest, UpdateDataSourceResponse, UpdateDataSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDirectQueryDataSourceError = BaseException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the configuration or properties of an existing direct query data source in
 * Amazon OpenSearch Service.
 */
export declare const updateDirectQueryDataSource: API.OperationMethod<UpdateDirectQueryDataSourceRequest, UpdateDirectQueryDataSourceResponse, UpdateDirectQueryDataSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainConfigError = BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Modifies the cluster configuration of the specified Amazon OpenSearch Service
 * domain.
 */
export declare const updateDomainConfig: API.OperationMethod<UpdateDomainConfigRequest, UpdateDomainConfigResponse, UpdateDomainConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateIndexError = AccessDeniedException | DependencyFailureException | DisabledOperationException | InternalException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing OpenSearch index schema and semantic enrichment configuration. This operation allows modification of field mappings and semantic search settings for text fields. Changes to semantic enrichment configuration will apply to newly ingested documents.
 */
export declare const updateIndex: API.OperationMethod<UpdateIndexRequest, UpdateIndexResponse, UpdateIndexError, Credentials | HttpClient.HttpClient>;
export type UpdatePackageError = AccessDeniedException | BaseException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a package for use with Amazon OpenSearch Service domains. For more
 * information, see Custom packages
 * for Amazon OpenSearch Service.
 */
export declare const updatePackage: API.OperationMethod<UpdatePackageRequest, UpdatePackageResponse, UpdatePackageError, Credentials | HttpClient.HttpClient>;
export type UpdatePackageScopeError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the scope of a package. Scope of the package defines users who can view and
 * associate a package.
 */
export declare const updatePackageScope: API.OperationMethod<UpdatePackageScopeRequest, UpdatePackageScopeResponse, UpdatePackageScopeError, Credentials | HttpClient.HttpClient>;
export type UpdateScheduledActionError = BaseException | ConflictException | InternalException | LimitExceededException | ResourceNotFoundException | SlotNotAvailableException | ValidationException | CommonErrors;
/**
 * Reschedules a planned domain configuration change for a later time. This change can be
 * a scheduled service
 * software update or a blue/green Auto-Tune enhancement.
 */
export declare const updateScheduledAction: API.OperationMethod<UpdateScheduledActionRequest, UpdateScheduledActionResponse, UpdateScheduledActionError, Credentials | HttpClient.HttpClient>;
export type UpdateVpcEndpointError = BaseException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Modifies an Amazon OpenSearch Service-managed interface VPC endpoint.
 */
export declare const updateVpcEndpoint: API.OperationMethod<UpdateVpcEndpointRequest, UpdateVpcEndpointResponse, UpdateVpcEndpointError, Credentials | HttpClient.HttpClient>;
export type UpgradeDomainError = BaseException | DisabledOperationException | InternalException | ResourceAlreadyExistsException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Allows you to either upgrade your Amazon OpenSearch Service domain or perform an
 * upgrade eligibility check to a compatible version of OpenSearch or Elasticsearch.
 */
export declare const upgradeDomain: API.OperationMethod<UpgradeDomainRequest, UpgradeDomainResponse, UpgradeDomainError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=opensearch.d.ts.map