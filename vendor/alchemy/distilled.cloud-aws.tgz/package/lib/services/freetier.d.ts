import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ActivityId = string;
export type LanguageCode = "en-US" | "en-GB" | "id-ID" | "de-DE" | "es-ES" | "fr-FR" | "ja-JP" | "it-IT" | "pt-PT" | "ko-KR" | "zh-CN" | "zh-TW" | "tr-TR" | (string & {});
export interface GetAccountActivityRequest {
    activityId: string;
    languageCode?: LanguageCode;
}
export type ActivityStatus = "NOT_STARTED" | "IN_PROGRESS" | "COMPLETED" | "EXPIRING" | (string & {});
export type CurrencyCode = "USD" | (string & {});
export interface MonetaryAmount {
    amount: number;
    unit: CurrencyCode;
}
export type ActivityReward = {
    credit: MonetaryAmount;
};
export interface GetAccountActivityResponse {
    activityId: string;
    title: string;
    description: string;
    status: ActivityStatus;
    instructionsUrl: string;
    reward: ActivityReward;
    estimatedTimeToCompleteInMinutes?: number;
    expiresAt?: Date;
    startedAt?: Date;
    completedAt?: Date;
}
export interface GetAccountPlanStateRequest {
}
export type AccountId = string;
export type AccountPlanType = "FREE" | "PAID" | (string & {});
export type AccountPlanStatus = "NOT_STARTED" | "ACTIVE" | "EXPIRED" | (string & {});
export interface GetAccountPlanStateResponse {
    accountId: string;
    accountPlanType: AccountPlanType;
    accountPlanStatus: AccountPlanStatus;
    accountPlanRemainingCredits?: MonetaryAmount;
    accountPlanExpirationDate?: Date;
}
export type Expressions = Expression[];
export type Dimension = "SERVICE" | "OPERATION" | "USAGE_TYPE" | "REGION" | "FREE_TIER_TYPE" | "DESCRIPTION" | "USAGE_PERCENTAGE" | (string & {});
export type Value = string;
export type Values = string[];
export type MatchOption = "EQUALS" | "STARTS_WITH" | "ENDS_WITH" | "CONTAINS" | "GREATER_THAN_OR_EQUAL" | (string & {});
export type MatchOptions = MatchOption[];
export interface DimensionValues {
    Key: Dimension;
    Values: string[];
    MatchOptions: MatchOption[];
}
export interface Expression {
    Or?: Expression[];
    And?: Expression[];
    Not?: Expression;
    Dimensions?: DimensionValues;
}
export type MaxResults = number;
export type NextPageToken = string;
export interface GetFreeTierUsageRequest {
    filter?: Expression;
    maxResults?: number;
    nextToken?: string;
}
export interface FreeTierUsage {
    service?: string;
    operation?: string;
    usageType?: string;
    region?: string;
    actualUsageAmount?: number;
    forecastedUsageAmount?: number;
    limit?: number;
    unit?: string;
    description?: string;
    freeTierType?: string;
}
export type FreeTierUsages = FreeTierUsage[];
export interface GetFreeTierUsageResponse {
    freeTierUsages: FreeTierUsage[];
    nextToken?: string;
}
export type FilterActivityStatuses = ActivityStatus[];
export interface ListAccountActivitiesRequest {
    filterActivityStatuses?: ActivityStatus[];
    nextToken?: string;
    maxResults?: number;
    languageCode?: LanguageCode;
}
export interface ActivitySummary {
    activityId: string;
    title: string;
    reward: ActivityReward;
    status: ActivityStatus;
}
export type Activities = ActivitySummary[];
export interface ListAccountActivitiesResponse {
    activities: ActivitySummary[];
    nextToken?: string;
}
export interface UpgradeAccountPlanRequest {
    accountPlanType: AccountPlanType;
}
export interface UpgradeAccountPlanResponse {
    accountId: string;
    accountPlanType: AccountPlanType;
    accountPlanStatus: AccountPlanStatus;
}
export type GetAccountActivityError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a specific activity record that is available to the customer.
 */
export declare const getAccountActivity: API.OperationMethod<GetAccountActivityRequest, GetAccountActivityResponse, GetAccountActivityError, Credentials | HttpClient.HttpClient>;
export type GetAccountPlanStateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This returns all of the information related to the state of the account plan related to Free Tier.
 */
export declare const getAccountPlanState: API.OperationMethod<GetAccountPlanStateRequest, GetAccountPlanStateResponse, GetAccountPlanStateError, Credentials | HttpClient.HttpClient>;
export type GetFreeTierUsageError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all Free Tier usage objects that match your filters.
 */
export declare const getFreeTierUsage: API.PaginatedOperationMethod<GetFreeTierUsageRequest, GetFreeTierUsageResponse, GetFreeTierUsageError, Credentials | HttpClient.HttpClient, FreeTierUsage>;
export type ListAccountActivitiesError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of activities that are available. This operation supports pagination and filtering by status.
 */
export declare const listAccountActivities: API.PaginatedOperationMethod<ListAccountActivitiesRequest, ListAccountActivitiesResponse, ListAccountActivitiesError, Credentials | HttpClient.HttpClient, ActivitySummary>;
export type UpgradeAccountPlanError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The account plan type for the Amazon Web Services account.
 */
export declare const upgradeAccountPlan: API.OperationMethod<UpgradeAccountPlanRequest, UpgradeAccountPlanResponse, UpgradeAccountPlanError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=freetier.d.ts.map