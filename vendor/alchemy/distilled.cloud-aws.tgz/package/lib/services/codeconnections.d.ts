import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConditionalCheckFailedException_base: S.TaggedErrorClass<"ConditionalCheckFailedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConditionalCheckFailedException extends /*@__PURE__*/ ConditionalCheckFailedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidInputException_base: S.TaggedErrorClass<"InvalidInputException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceUnavailableException_base: S.TaggedErrorClass<"ResourceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceUnavailableException extends /*@__PURE__*/ ResourceUnavailableException_base {
}
declare const RetryLatestCommitFailedException_base: S.TaggedErrorClass<"RetryLatestCommitFailedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class RetryLatestCommitFailedException extends /*@__PURE__*/ RetryLatestCommitFailedException_base {
}
declare const SyncBlockerDoesNotExistException_base: S.TaggedErrorClass<"SyncBlockerDoesNotExistException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SyncBlockerDoesNotExistException extends /*@__PURE__*/ SyncBlockerDoesNotExistException_base {
}
declare const SyncConfigurationStillExistsException_base: S.TaggedErrorClass<"SyncConfigurationStillExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class SyncConfigurationStillExistsException extends /*@__PURE__*/ SyncConfigurationStillExistsException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnsupportedOperationException_base: S.TaggedErrorClass<"UnsupportedOperationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
declare const UnsupportedProviderTypeException_base: S.TaggedErrorClass<"UnsupportedProviderTypeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedProviderTypeException extends /*@__PURE__*/ UnsupportedProviderTypeException_base {
}
declare const UpdateOutOfSyncException_base: S.TaggedErrorClass<"UpdateOutOfSyncException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class UpdateOutOfSyncException extends /*@__PURE__*/ UpdateOutOfSyncException_base {
}
export type ProviderType = "Bitbucket" | "GitHub" | "GitHubEnterpriseServer" | "GitLab" | "GitLabSelfManaged" | "AzureDevOps" | (string & {});
export type ConnectionName = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export type HostArn = string;
export interface CreateConnectionInput {
    ProviderType?: ProviderType;
    ConnectionName: string;
    Tags?: Tag[];
    HostArn?: string;
}
export type ConnectionArn = string;
export interface CreateConnectionOutput {
    ConnectionArn: string;
    Tags?: Tag[];
}
export type HostName = string;
export type Url = string;
export type VpcId = string;
export type SubnetId = string;
export type SubnetIds = string[];
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export type TlsCertificate = string;
export interface VpcConfiguration {
    VpcId: string;
    SubnetIds: string[];
    SecurityGroupIds: string[];
    TlsCertificate?: string;
}
export interface CreateHostInput {
    Name: string;
    ProviderType: ProviderType;
    ProviderEndpoint: string;
    VpcConfiguration?: VpcConfiguration;
    Tags?: Tag[];
}
export interface CreateHostOutput {
    HostArn?: string;
    Tags?: Tag[];
}
export type OwnerId = string;
export type RepositoryName = string;
export type KmsKeyArn = string;
export interface CreateRepositoryLinkInput {
    ConnectionArn: string;
    OwnerId: string;
    RepositoryName: string;
    EncryptionKeyArn?: string;
    Tags?: Tag[];
}
export type RepositoryLinkArn = string;
export type RepositoryLinkId = string;
export interface RepositoryLinkInfo {
    ConnectionArn: string;
    EncryptionKeyArn?: string;
    OwnerId: string;
    ProviderType: ProviderType;
    RepositoryLinkArn: string;
    RepositoryLinkId: string;
    RepositoryName: string;
}
export interface CreateRepositoryLinkOutput {
    RepositoryLinkInfo: RepositoryLinkInfo;
}
export type BranchName = string;
export type DeploymentFilePath = string;
export type ResourceName = string;
export type IamRoleArn = string;
export type SyncConfigurationType = "CFN_STACK_SYNC" | (string & {});
export type PublishDeploymentStatus = "ENABLED" | "DISABLED" | (string & {});
export type TriggerResourceUpdateOn = "ANY_CHANGE" | "FILE_CHANGE" | (string & {});
export type PullRequestComment = "ENABLED" | "DISABLED" | (string & {});
export interface CreateSyncConfigurationInput {
    Branch: string;
    ConfigFile: string;
    RepositoryLinkId: string;
    ResourceName: string;
    RoleArn: string;
    SyncType: SyncConfigurationType;
    PublishDeploymentStatus?: PublishDeploymentStatus;
    TriggerResourceUpdateOn?: TriggerResourceUpdateOn;
    PullRequestComment?: PullRequestComment;
}
export interface SyncConfiguration {
    Branch: string;
    ConfigFile?: string;
    OwnerId: string;
    ProviderType: ProviderType;
    RepositoryLinkId: string;
    RepositoryName: string;
    ResourceName: string;
    RoleArn: string;
    SyncType: SyncConfigurationType;
    PublishDeploymentStatus?: PublishDeploymentStatus;
    TriggerResourceUpdateOn?: TriggerResourceUpdateOn;
    PullRequestComment?: PullRequestComment;
}
export interface CreateSyncConfigurationOutput {
    SyncConfiguration: SyncConfiguration;
}
export interface DeleteConnectionInput {
    ConnectionArn: string;
}
export interface DeleteConnectionOutput {
}
export interface DeleteHostInput {
    HostArn: string;
}
export interface DeleteHostOutput {
}
export interface DeleteRepositoryLinkInput {
    RepositoryLinkId: string;
}
export interface DeleteRepositoryLinkOutput {
}
export interface DeleteSyncConfigurationInput {
    SyncType: SyncConfigurationType;
    ResourceName: string;
}
export interface DeleteSyncConfigurationOutput {
}
export interface GetConnectionInput {
    ConnectionArn: string;
}
export type AccountId = string;
export type ConnectionStatus = "PENDING" | "AVAILABLE" | "ERROR" | (string & {});
export interface Connection {
    ConnectionName?: string;
    ConnectionArn?: string;
    ProviderType?: ProviderType;
    OwnerAccountId?: string;
    ConnectionStatus?: ConnectionStatus;
    HostArn?: string;
}
export interface GetConnectionOutput {
    Connection?: Connection;
}
export interface GetHostInput {
    HostArn: string;
}
export type HostStatus = string;
export interface GetHostOutput {
    Name?: string;
    Status?: string;
    ProviderType?: ProviderType;
    ProviderEndpoint?: string;
    VpcConfiguration?: VpcConfiguration;
}
export interface GetRepositoryLinkInput {
    RepositoryLinkId: string;
}
export interface GetRepositoryLinkOutput {
    RepositoryLinkInfo: RepositoryLinkInfo;
}
export interface GetRepositorySyncStatusInput {
    Branch: string;
    RepositoryLinkId: string;
    SyncType: SyncConfigurationType;
}
export type RepositorySyncStatus = "FAILED" | "INITIATED" | "IN_PROGRESS" | "SUCCEEDED" | "QUEUED" | (string & {});
export type Event = string;
export type ExternalId = string;
export type Type = string;
export interface RepositorySyncEvent {
    Event: string;
    ExternalId?: string;
    Time: Date;
    Type: string;
}
export type RepositorySyncEventList = RepositorySyncEvent[];
export interface RepositorySyncAttempt {
    StartedAt: Date;
    Status: RepositorySyncStatus;
    Events: RepositorySyncEvent[];
}
export interface GetRepositorySyncStatusOutput {
    LatestSync: RepositorySyncAttempt;
}
export interface GetResourceSyncStatusInput {
    ResourceName: string;
    SyncType: SyncConfigurationType;
}
export type Directory = string;
export type SHA = string;
export interface Revision {
    Branch: string;
    Directory: string;
    OwnerId: string;
    RepositoryName: string;
    ProviderType: ProviderType;
    Sha: string;
}
export interface ResourceSyncEvent {
    Event: string;
    ExternalId?: string;
    Time: Date;
    Type: string;
}
export type ResourceSyncEventList = ResourceSyncEvent[];
export type ResourceSyncStatus = "FAILED" | "INITIATED" | "IN_PROGRESS" | "SUCCEEDED" | (string & {});
export type Target = string;
export interface ResourceSyncAttempt {
    Events: ResourceSyncEvent[];
    InitialRevision: Revision;
    StartedAt: Date;
    Status: ResourceSyncStatus;
    TargetRevision: Revision;
    Target: string;
}
export interface GetResourceSyncStatusOutput {
    DesiredState?: Revision;
    LatestSuccessfulSync?: ResourceSyncAttempt;
    LatestSync: ResourceSyncAttempt;
}
export interface GetSyncBlockerSummaryInput {
    SyncType: SyncConfigurationType;
    ResourceName: string;
}
export type Id = string;
export type BlockerType = "AUTOMATED" | (string & {});
export type BlockerStatus = "ACTIVE" | "RESOLVED" | (string & {});
export type CreatedReason = string;
export type SyncBlockerContextKey = string;
export type SyncBlockerContextValue = string;
export interface SyncBlockerContext {
    Key: string;
    Value: string;
}
export type SyncBlockerContextList = SyncBlockerContext[];
export type ResolvedReason = string;
export interface SyncBlocker {
    Id: string;
    Type: BlockerType;
    Status: BlockerStatus;
    CreatedReason: string;
    CreatedAt: Date;
    Contexts?: SyncBlockerContext[];
    ResolvedReason?: string;
    ResolvedAt?: Date;
}
export type LatestSyncBlockerList = SyncBlocker[];
export interface SyncBlockerSummary {
    ResourceName: string;
    ParentResourceName?: string;
    LatestBlockers?: SyncBlocker[];
}
export interface GetSyncBlockerSummaryOutput {
    SyncBlockerSummary: SyncBlockerSummary;
}
export interface GetSyncConfigurationInput {
    SyncType: SyncConfigurationType;
    ResourceName: string;
}
export interface GetSyncConfigurationOutput {
    SyncConfiguration: SyncConfiguration;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListConnectionsInput {
    ProviderTypeFilter?: ProviderType;
    HostArnFilter?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type ConnectionList = Connection[];
export interface ListConnectionsOutput {
    Connections?: Connection[];
    NextToken?: string;
}
export interface ListHostsInput {
    MaxResults?: number;
    NextToken?: string;
}
export type HostStatusMessage = string;
export interface Host {
    Name?: string;
    HostArn?: string;
    ProviderType?: ProviderType;
    ProviderEndpoint?: string;
    VpcConfiguration?: VpcConfiguration;
    Status?: string;
    StatusMessage?: string;
}
export type HostList = Host[];
export interface ListHostsOutput {
    Hosts?: Host[];
    NextToken?: string;
}
export type SharpNextToken = string;
export interface ListRepositoryLinksInput {
    MaxResults?: number;
    NextToken?: string;
}
export type RepositoryLinkList = RepositoryLinkInfo[];
export interface ListRepositoryLinksOutput {
    RepositoryLinks: RepositoryLinkInfo[];
    NextToken?: string;
}
export interface ListRepositorySyncDefinitionsInput {
    RepositoryLinkId: string;
    SyncType: SyncConfigurationType;
}
export type Parent = string;
export interface RepositorySyncDefinition {
    Branch: string;
    Directory: string;
    Parent: string;
    Target: string;
}
export type RepositorySyncDefinitionList = RepositorySyncDefinition[];
export interface ListRepositorySyncDefinitionsOutput {
    RepositorySyncDefinitions: RepositorySyncDefinition[];
    NextToken?: string;
}
export interface ListSyncConfigurationsInput {
    MaxResults?: number;
    NextToken?: string;
    RepositoryLinkId: string;
    SyncType: SyncConfigurationType;
}
export type SyncConfigurationList = SyncConfiguration[];
export interface ListSyncConfigurationsOutput {
    SyncConfigurations: SyncConfiguration[];
    NextToken?: string;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceInput {
    ResourceArn: string;
}
export interface ListTagsForResourceOutput {
    Tags?: Tag[];
}
export interface TagResourceInput {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateHostInput {
    HostArn: string;
    ProviderEndpoint?: string;
    VpcConfiguration?: VpcConfiguration;
}
export interface UpdateHostOutput {
}
export interface UpdateRepositoryLinkInput {
    ConnectionArn?: string;
    EncryptionKeyArn?: string;
    RepositoryLinkId: string;
}
export interface UpdateRepositoryLinkOutput {
    RepositoryLinkInfo: RepositoryLinkInfo;
}
export interface UpdateSyncBlockerInput {
    Id: string;
    SyncType: SyncConfigurationType;
    ResourceName: string;
    ResolvedReason: string;
}
export interface UpdateSyncBlockerOutput {
    ResourceName: string;
    ParentResourceName?: string;
    SyncBlocker: SyncBlocker;
}
export interface UpdateSyncConfigurationInput {
    Branch?: string;
    ConfigFile?: string;
    RepositoryLinkId?: string;
    ResourceName: string;
    RoleArn?: string;
    SyncType: SyncConfigurationType;
    PublishDeploymentStatus?: PublishDeploymentStatus;
    TriggerResourceUpdateOn?: TriggerResourceUpdateOn;
    PullRequestComment?: PullRequestComment;
}
export interface UpdateSyncConfigurationOutput {
    SyncConfiguration: SyncConfiguration;
}
export type ErrorMessage = string;
export type CreateConnectionError = LimitExceededException | ResourceNotFoundException | ResourceUnavailableException | CommonErrors;
/**
 * Creates a connection that can then be given to other Amazon Web Services services like CodePipeline so
 * that it can access third-party code repositories. The connection is in pending status until
 * the third-party connection handshake is completed from the console.
 */
export declare const createConnection: API.OperationMethod<CreateConnectionInput, CreateConnectionOutput, CreateConnectionError, Credentials | HttpClient.HttpClient>;
export type CreateHostError = LimitExceededException | CommonErrors;
/**
 * Creates a resource that represents the infrastructure where a third-party provider is
 * installed. The host is used when you create connections to an installed third-party provider
 * type, such as GitHub Enterprise Server. You create one host for all connections to that
 * provider.
 *
 * A host created through the CLI or the SDK is in `PENDING` status by
 * default. You can make its status `AVAILABLE` by setting up the host in the console.
 */
export declare const createHost: API.OperationMethod<CreateHostInput, CreateHostOutput, CreateHostError, Credentials | HttpClient.HttpClient>;
export type CreateRepositoryLinkError = AccessDeniedException | ConcurrentModificationException | InternalServerException | InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ThrottlingException | CommonErrors;
/**
 * Creates a link to a specified external Git repository. A repository link allows Git sync to monitor and sync changes to files in a specified Git repository.
 */
export declare const createRepositoryLink: API.OperationMethod<CreateRepositoryLinkInput, CreateRepositoryLinkOutput, CreateRepositoryLinkError, Credentials | HttpClient.HttpClient>;
export type CreateSyncConfigurationError = AccessDeniedException | ConcurrentModificationException | InternalServerException | InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ThrottlingException | CommonErrors;
/**
 * Creates a sync configuration which allows Amazon Web Services to sync content from a Git
 * repository to update a specified Amazon Web Services resource. Parameters for the sync
 * configuration are determined by the sync type.
 */
export declare const createSyncConfiguration: API.OperationMethod<CreateSyncConfigurationInput, CreateSyncConfigurationOutput, CreateSyncConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionError = ResourceNotFoundException | CommonErrors;
/**
 * The connection to be deleted.
 */
export declare const deleteConnection: API.OperationMethod<DeleteConnectionInput, DeleteConnectionOutput, DeleteConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteHostError = ResourceNotFoundException | ResourceUnavailableException | CommonErrors;
/**
 * The host to be deleted. Before you delete a host, all connections associated to the host must be deleted.
 *
 * A host cannot be deleted if it is in the VPC_CONFIG_INITIALIZING or VPC_CONFIG_DELETING state.
 */
export declare const deleteHost: API.OperationMethod<DeleteHostInput, DeleteHostOutput, DeleteHostError, Credentials | HttpClient.HttpClient>;
export type DeleteRepositoryLinkError = AccessDeniedException | ConcurrentModificationException | InternalServerException | InvalidInputException | ResourceNotFoundException | SyncConfigurationStillExistsException | ThrottlingException | UnsupportedProviderTypeException | CommonErrors;
/**
 * Deletes the association between your connection and a specified external Git repository.
 */
export declare const deleteRepositoryLink: API.OperationMethod<DeleteRepositoryLinkInput, DeleteRepositoryLinkOutput, DeleteRepositoryLinkError, Credentials | HttpClient.HttpClient>;
export type DeleteSyncConfigurationError = AccessDeniedException | ConcurrentModificationException | InternalServerException | InvalidInputException | LimitExceededException | ThrottlingException | CommonErrors;
/**
 * Deletes the sync configuration for a specified repository and connection.
 */
export declare const deleteSyncConfiguration: API.OperationMethod<DeleteSyncConfigurationInput, DeleteSyncConfigurationOutput, DeleteSyncConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetConnectionError = ResourceNotFoundException | ResourceUnavailableException | CommonErrors;
/**
 * Returns the connection ARN and details such as status, owner, and provider type.
 */
export declare const getConnection: API.OperationMethod<GetConnectionInput, GetConnectionOutput, GetConnectionError, Credentials | HttpClient.HttpClient>;
export type GetHostError = ResourceNotFoundException | ResourceUnavailableException | CommonErrors;
/**
 * Returns the host ARN and details such as status, provider type, endpoint, and, if
 * applicable, the VPC configuration.
 */
export declare const getHost: API.OperationMethod<GetHostInput, GetHostOutput, GetHostError, Credentials | HttpClient.HttpClient>;
export type GetRepositoryLinkError = AccessDeniedException | ConcurrentModificationException | InternalServerException | InvalidInputException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns details about a repository link. A repository link allows Git sync to monitor
 * and sync changes from files in a specified Git repository.
 */
export declare const getRepositoryLink: API.OperationMethod<GetRepositoryLinkInput, GetRepositoryLinkOutput, GetRepositoryLinkError, Credentials | HttpClient.HttpClient>;
export type GetRepositorySyncStatusError = AccessDeniedException | InternalServerException | InvalidInputException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns details about the sync status for a repository. A repository sync uses Git sync
 * to push and pull changes from your remote repository.
 */
export declare const getRepositorySyncStatus: API.OperationMethod<GetRepositorySyncStatusInput, GetRepositorySyncStatusOutput, GetRepositorySyncStatusError, Credentials | HttpClient.HttpClient>;
export type GetResourceSyncStatusError = AccessDeniedException | InternalServerException | InvalidInputException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns the status of the sync with the Git repository for a specific Amazon Web Services
 * resource.
 */
export declare const getResourceSyncStatus: API.OperationMethod<GetResourceSyncStatusInput, GetResourceSyncStatusOutput, GetResourceSyncStatusError, Credentials | HttpClient.HttpClient>;
export type GetSyncBlockerSummaryError = AccessDeniedException | InternalServerException | InvalidInputException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of the most recent sync blockers.
 */
export declare const getSyncBlockerSummary: API.OperationMethod<GetSyncBlockerSummaryInput, GetSyncBlockerSummaryOutput, GetSyncBlockerSummaryError, Credentials | HttpClient.HttpClient>;
export type GetSyncConfigurationError = AccessDeniedException | InternalServerException | InvalidInputException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns details about a sync configuration, including the sync type and resource name. A sync configuration allows the configuration to sync (push and pull) changes from the remote repository for a specified branch in a Git repository.
 */
export declare const getSyncConfiguration: API.OperationMethod<GetSyncConfigurationInput, GetSyncConfigurationOutput, GetSyncConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListConnectionsError = ResourceNotFoundException | CommonErrors;
/**
 * Lists the connections associated with your account.
 */
export declare const listConnections: API.PaginatedOperationMethod<ListConnectionsInput, ListConnectionsOutput, ListConnectionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListHostsError = CommonErrors;
/**
 * Lists the hosts associated with your account.
 */
export declare const listHosts: API.PaginatedOperationMethod<ListHostsInput, ListHostsOutput, ListHostsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRepositoryLinksError = AccessDeniedException | ConcurrentModificationException | InternalServerException | InvalidInputException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the repository links created for connections in your account.
 */
export declare const listRepositoryLinks: API.PaginatedOperationMethod<ListRepositoryLinksInput, ListRepositoryLinksOutput, ListRepositoryLinksError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRepositorySyncDefinitionsError = AccessDeniedException | InternalServerException | InvalidInputException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the repository sync definitions for repository links in your account.
 */
export declare const listRepositorySyncDefinitions: API.OperationMethod<ListRepositorySyncDefinitionsInput, ListRepositorySyncDefinitionsOutput, ListRepositorySyncDefinitionsError, Credentials | HttpClient.HttpClient>;
export type ListSyncConfigurationsError = AccessDeniedException | InternalServerException | InvalidInputException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of sync configurations for a specified repository.
 */
export declare const listSyncConfigurations: API.PaginatedOperationMethod<ListSyncConfigurationsInput, ListSyncConfigurationsOutput, ListSyncConfigurationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Gets the set of key-value pairs (metadata) that are used to manage the resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Adds to or modifies the tags of the given resource. Tags are metadata that can be used
 * to manage a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Removes tags from an Amazon Web Services resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateHostError = ConflictException | ResourceNotFoundException | ResourceUnavailableException | UnsupportedOperationException | CommonErrors;
/**
 * Updates a specified host with the provided configurations.
 */
export declare const updateHost: API.OperationMethod<UpdateHostInput, UpdateHostOutput, UpdateHostError, Credentials | HttpClient.HttpClient>;
export type UpdateRepositoryLinkError = AccessDeniedException | ConditionalCheckFailedException | InternalServerException | InvalidInputException | ResourceNotFoundException | ThrottlingException | UpdateOutOfSyncException | CommonErrors;
/**
 * Updates the association between your connection and a specified external Git repository.
 * A repository link allows Git sync to monitor and sync changes to files in a specified Git
 * repository.
 */
export declare const updateRepositoryLink: API.OperationMethod<UpdateRepositoryLinkInput, UpdateRepositoryLinkOutput, UpdateRepositoryLinkError, Credentials | HttpClient.HttpClient>;
export type UpdateSyncBlockerError = AccessDeniedException | InternalServerException | InvalidInputException | ResourceNotFoundException | RetryLatestCommitFailedException | SyncBlockerDoesNotExistException | ThrottlingException | CommonErrors;
/**
 * Allows you to update the status of a sync blocker, resolving the blocker and allowing syncing to continue.
 */
export declare const updateSyncBlocker: API.OperationMethod<UpdateSyncBlockerInput, UpdateSyncBlockerOutput, UpdateSyncBlockerError, Credentials | HttpClient.HttpClient>;
export type UpdateSyncConfigurationError = AccessDeniedException | ConcurrentModificationException | InternalServerException | InvalidInputException | ResourceNotFoundException | ThrottlingException | UpdateOutOfSyncException | CommonErrors;
/**
 * Updates the sync configuration for your connection and a specified external Git repository.
 */
export declare const updateSyncConfiguration: API.OperationMethod<UpdateSyncConfigurationInput, UpdateSyncConfigurationOutput, UpdateSyncConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=codeconnections.d.ts.map