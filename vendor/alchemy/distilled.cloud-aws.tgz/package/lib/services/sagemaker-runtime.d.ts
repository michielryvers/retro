import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type * as stream from "effect/Stream";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import * as T from "../traits.ts";
declare const InternalDependencyException_base: S.TaggedErrorClass<"InternalDependencyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalDependencyException extends /*@__PURE__*/ InternalDependencyException_base {
}
declare const InternalFailure_base: S.TaggedErrorClass<"InternalFailure", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalFailure extends /*@__PURE__*/ InternalFailure_base {
}
declare const InternalStreamFailure_base: S.TaggedErrorClass<"InternalStreamFailure", {
    readonly message: any;
}>;
export declare class InternalStreamFailure extends /*@__PURE__*/ InternalStreamFailure_base {
}
declare const ModelError_base: S.TaggedErrorClass<"ModelError", {
    readonly message: any;
    readonly OriginalStatusCode: any;
    readonly OriginalMessage: any;
    readonly LogStreamArn: any;
}>;
export declare class ModelError extends /*@__PURE__*/ ModelError_base {
}
declare const ModelNotReadyException_base: S.TaggedErrorClass<"ModelNotReadyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ModelNotReadyException extends /*@__PURE__*/ ModelNotReadyException_base {
}
declare const ModelStreamError_base: S.TaggedErrorClass<"ModelStreamError", {
    readonly message: any;
    readonly ErrorCode: any;
}>;
export declare class ModelStreamError extends /*@__PURE__*/ ModelStreamError_base {
}
declare const ServiceUnavailable_base: S.TaggedErrorClass<"ServiceUnavailable", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailable extends /*@__PURE__*/ ServiceUnavailable_base {
}
declare const ValidationError_base: S.TaggedErrorClass<"ValidationError", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationError extends /*@__PURE__*/ ValidationError_base {
}
export type EndpointName = string;
export type Header = string;
export type CustomAttributesHeader = string | redacted.Redacted<string>;
export type TargetModelHeader = string;
export type TargetVariantHeader = string;
export type TargetContainerHostnameHeader = string;
export type InferenceId = string;
export type EnableExplanationsHeader = string;
export type InferenceComponentHeader = string;
export type SessionIdOrNewSessionConstantHeader = string;
export type PrefixAwareIdHeader = string;
export interface InvokeEndpointInput {
    EndpointName: string;
    Body?: T.StreamingInputBody;
    ContentType?: string;
    Accept?: string;
    CustomAttributes?: string | redacted.Redacted<string>;
    TargetModel?: string;
    TargetVariant?: string;
    TargetContainerHostname?: string;
    InferenceId?: string;
    EnableExplanations?: string;
    InferenceComponentName?: string;
    SessionId?: string;
    PrefixAwareId?: string;
}
export type NewSessionResponseHeader = string;
export type SessionIdHeader = string;
export interface InvokeEndpointOutput {
    Body: T.StreamingOutputBody;
    ContentType?: string;
    InvokedProductionVariant?: string;
    CustomAttributes?: string | redacted.Redacted<string>;
    NewSessionId?: string;
    ClosedSessionId?: string;
}
export type InputLocationHeader = string;
export type S3OutputPathExtensionHeader = string;
export type FilenameHeader = string;
export type RequestTTLSecondsHeader = number;
export type InvocationTimeoutSecondsHeader = number;
export interface InvokeEndpointAsyncInput {
    EndpointName: string;
    ContentType?: string;
    Accept?: string;
    CustomAttributes?: string | redacted.Redacted<string>;
    InferenceId?: string;
    InputLocation?: string;
    S3OutputPathExtension?: string;
    Filename?: string;
    RequestTTLSeconds?: number;
    InvocationTimeoutSeconds?: number;
    Body?: T.StreamingInputBody;
}
export interface InvokeEndpointAsyncOutput {
    InferenceId?: string;
    OutputLocation?: string;
    FailureLocation?: string;
}
export interface InvokeEndpointWithResponseStreamInput {
    EndpointName: string;
    Body?: T.StreamingInputBody;
    ContentType?: string;
    Accept?: string;
    CustomAttributes?: string | redacted.Redacted<string>;
    TargetVariant?: string;
    TargetContainerHostname?: string;
    InferenceId?: string;
    InferenceComponentName?: string;
    SessionId?: string;
    PrefixAwareId?: string;
}
export type PartBlob = Uint8Array | redacted.Redacted<Uint8Array>;
export interface PayloadPart {
    Bytes?: Uint8Array | redacted.Redacted<Uint8Array>;
}
export type Message = string;
export type ErrorCode = string;
export type ResponseStream = {
    PayloadPart: PayloadPart;
    ModelStreamError?: never;
    InternalStreamFailure?: never;
} | {
    PayloadPart?: never;
    ModelStreamError: ModelStreamError;
    InternalStreamFailure?: never;
} | {
    PayloadPart?: never;
    ModelStreamError?: never;
    InternalStreamFailure: InternalStreamFailure;
};
export interface InvokeEndpointWithResponseStreamOutput {
    Body: stream.Stream<ResponseStream, Error, never>;
    ContentType?: string;
    InvokedProductionVariant?: string;
    CustomAttributes?: string | redacted.Redacted<string>;
}
export type StatusCode = number;
export type LogStreamArn = string;
export type InvokeEndpointError = InternalDependencyException | InternalFailure | ModelError | ModelNotReadyException | ServiceUnavailable | ValidationError | CommonErrors;
/**
 * After you deploy a model into production using Amazon SageMaker AI hosting services,
 * your client applications use this API to get inferences from the model hosted at the
 * specified endpoint.
 *
 * For an overview of Amazon SageMaker AI, see How It Works.
 *
 * Amazon SageMaker AI strips all POST headers except those supported by the API. Amazon SageMaker AI might add
 * additional headers. You should not rely on the behavior of headers outside those
 * enumerated in the request syntax.
 *
 * Calls to `InvokeEndpoint` are authenticated by using Amazon Web Services
 * Signature Version 4. For information, see Authenticating
 * Requests (Amazon Web Services Signature Version 4) in the *Amazon S3 API Reference*.
 *
 * A customer's model containers must respond to requests within 60 seconds. The model
 * itself can have a maximum processing time of 60 seconds before responding to
 * invocations. If your model is going to take 50-60 seconds of processing time, the SDK
 * socket timeout should be set to be 70 seconds.
 *
 * Endpoints are scoped to an individual account, and are not public. The URL does
 * not contain the account ID, but Amazon SageMaker AI determines the account ID from
 * the authentication token that is supplied by the caller.
 */
export declare const invokeEndpoint: API.OperationMethod<InvokeEndpointInput, InvokeEndpointOutput, InvokeEndpointError, Credentials | HttpClient.HttpClient>;
export type InvokeEndpointAsyncError = InternalFailure | ServiceUnavailable | ValidationError | CommonErrors;
/**
 * After you deploy a model into production using Amazon SageMaker AI hosting services,
 * your client applications use this API to get inferences from the model hosted at the
 * specified endpoint in an asynchronous manner.
 *
 * Inference requests sent to this API are enqueued for asynchronous processing. The
 * processing of the inference request may or may not complete before you receive a
 * response from this API. The response from this API will not contain the result of the
 * inference request but contain information about where you can locate it.
 *
 * Amazon SageMaker AI strips all POST headers except those supported by the API. Amazon SageMaker AI might add
 * additional headers. You should not rely on the behavior of headers outside those
 * enumerated in the request syntax.
 *
 * Calls to `InvokeEndpointAsync` are authenticated by using Amazon Web Services Signature Version 4. For information, see Authenticating
 * Requests (Amazon Web Services Signature Version 4) in the *Amazon S3 API Reference*.
 */
export declare const invokeEndpointAsync: API.OperationMethod<InvokeEndpointAsyncInput, InvokeEndpointAsyncOutput, InvokeEndpointAsyncError, Credentials | HttpClient.HttpClient>;
export type InvokeEndpointWithResponseStreamError = InternalFailure | InternalStreamFailure | ModelError | ModelStreamError | ServiceUnavailable | ValidationError | CommonErrors;
/**
 * Invokes a model at the specified endpoint to return the inference response as a
 * stream. The inference stream provides the response payload incrementally as a series of
 * parts. Before you can get an inference stream, you must have access to a model that's
 * deployed using Amazon SageMaker AI hosting services, and the container for that model
 * must support inference streaming.
 *
 * For more information that can help you use this API, see the following sections in the
 * *Amazon SageMaker AI Developer Guide*:
 *
 * - For information about how to add streaming support to a model, see How Containers Serve Requests.
 *
 * - For information about how to process the streaming response, see Invoke real-time endpoints.
 *
 * Before you can use this operation, your IAM permissions must allow the
 * `sagemaker:InvokeEndpoint` action. For more information about Amazon SageMaker AI actions for IAM policies, see Actions, resources, and condition keys for Amazon SageMaker AI in the IAM Service Authorization
 * Reference.
 *
 * Amazon SageMaker AI strips all POST headers except those supported by the API. Amazon SageMaker AI might add
 * additional headers. You should not rely on the behavior of headers outside those
 * enumerated in the request syntax.
 *
 * Calls to `InvokeEndpointWithResponseStream` are authenticated by using
 * Amazon Web Services Signature Version 4. For information, see Authenticating Requests (Amazon Web Services Signature Version 4) in the
 * *Amazon S3 API Reference*.
 */
export declare const invokeEndpointWithResponseStream: API.OperationMethod<InvokeEndpointWithResponseStreamInput, InvokeEndpointWithResponseStreamOutput, InvokeEndpointWithResponseStreamError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=sagemaker-runtime.d.ts.map