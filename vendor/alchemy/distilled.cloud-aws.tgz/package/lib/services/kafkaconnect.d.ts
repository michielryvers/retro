import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
export type __integerMin1Max8 = number;
export type __integerMin1Max100 = number;
export interface ScaleInPolicy {
    cpuUtilizationPercentage: number;
}
export interface ScaleOutPolicy {
    cpuUtilizationPercentage: number;
}
export interface AutoScaling {
    maxWorkerCount: number;
    mcuCount: number;
    minWorkerCount: number;
    scaleInPolicy?: ScaleInPolicy;
    scaleOutPolicy?: ScaleOutPolicy;
    maxAutoscalingTaskCount?: number;
}
export interface ProvisionedCapacity {
    mcuCount: number;
    workerCount: number;
}
export interface Capacity {
    autoScaling?: AutoScaling;
    provisionedCapacity?: ProvisionedCapacity;
}
export type ConnectorConfiguration = {
    [key: string]: string | undefined;
};
export type __stringMax1024 = string;
export type __stringMin1Max128 = string;
export type __listOf__string = string[];
export interface Vpc {
    securityGroups?: string[];
    subnets: string[];
}
export interface ApacheKafkaCluster {
    bootstrapServers: string;
    vpc: Vpc;
}
export interface KafkaCluster {
    apacheKafkaCluster: ApacheKafkaCluster;
}
export type KafkaClusterClientAuthenticationType = string;
export interface KafkaClusterClientAuthentication {
    authenticationType: string;
}
export type KafkaClusterEncryptionInTransitType = string;
export interface KafkaClusterEncryptionInTransit {
    encryptionType: string;
}
export interface CloudWatchLogsLogDelivery {
    enabled: boolean;
    logGroup?: string;
}
export interface FirehoseLogDelivery {
    deliveryStream?: string;
    enabled: boolean;
}
export interface S3LogDelivery {
    bucket?: string;
    enabled: boolean;
    prefix?: string;
}
export interface WorkerLogDelivery {
    cloudWatchLogs?: CloudWatchLogsLogDelivery;
    firehose?: FirehoseLogDelivery;
    s3?: S3LogDelivery;
}
export interface LogDelivery {
    workerLogDelivery: WorkerLogDelivery;
}
export type NetworkType = string;
export type __longMin1 = number;
export interface CustomPlugin {
    customPluginArn: string;
    revision: number;
}
export interface Plugin {
    customPlugin: CustomPlugin;
}
export type __listOfPlugin = Plugin[];
export interface WorkerConfiguration {
    revision: number;
    workerConfigurationArn: string;
}
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export interface CreateConnectorRequest {
    capacity: Capacity;
    connectorConfiguration: {
        [key: string]: string | undefined;
    };
    connectorDescription?: string;
    connectorName: string;
    kafkaCluster: KafkaCluster;
    kafkaClusterClientAuthentication: KafkaClusterClientAuthentication;
    kafkaClusterEncryptionInTransit: KafkaClusterEncryptionInTransit;
    kafkaConnectVersion: string;
    logDelivery?: LogDelivery;
    networkType?: string;
    plugins: Plugin[];
    serviceExecutionRoleArn: string;
    workerConfiguration?: WorkerConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type ConnectorState = string;
export interface CreateConnectorResponse {
    connectorArn?: string;
    connectorName?: string;
    connectorState?: string;
}
export type CustomPluginContentType = string;
export interface S3Location {
    bucketArn: string;
    fileKey: string;
    objectVersion?: string;
}
export interface CustomPluginLocation {
    s3Location: S3Location;
}
export interface CreateCustomPluginRequest {
    contentType: string;
    description?: string;
    location: CustomPluginLocation;
    name: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type CustomPluginState = string;
export interface CreateCustomPluginResponse {
    customPluginArn?: string;
    customPluginState?: string;
    name?: string;
    revision?: number;
}
export type __sensitiveString = string | redacted.Redacted<string>;
export interface CreateWorkerConfigurationRequest {
    description?: string;
    name: string;
    propertiesFileContent: string | redacted.Redacted<string>;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type __timestampIso8601 = Date;
export interface WorkerConfigurationRevisionSummary {
    creationTime?: Date;
    description?: string;
    revision?: number;
}
export type WorkerConfigurationState = string;
export interface CreateWorkerConfigurationResponse {
    creationTime?: Date;
    latestRevision?: WorkerConfigurationRevisionSummary;
    name?: string;
    workerConfigurationArn?: string;
    workerConfigurationState?: string;
}
export interface DeleteConnectorRequest {
    connectorArn: string;
    currentVersion?: string;
}
export interface DeleteConnectorResponse {
    connectorArn?: string;
    connectorState?: string;
}
export interface DeleteCustomPluginRequest {
    customPluginArn: string;
}
export interface DeleteCustomPluginResponse {
    customPluginArn?: string;
    customPluginState?: string;
}
export interface DeleteWorkerConfigurationRequest {
    workerConfigurationArn: string;
}
export interface DeleteWorkerConfigurationResponse {
    workerConfigurationArn?: string;
    workerConfigurationState?: string;
}
export interface DescribeConnectorRequest {
    connectorArn: string;
}
export interface ScaleInPolicyDescription {
    cpuUtilizationPercentage?: number;
}
export interface ScaleOutPolicyDescription {
    cpuUtilizationPercentage?: number;
}
export interface AutoScalingDescription {
    maxWorkerCount?: number;
    mcuCount?: number;
    minWorkerCount?: number;
    scaleInPolicy?: ScaleInPolicyDescription;
    scaleOutPolicy?: ScaleOutPolicyDescription;
    maxAutoscalingTaskCount?: number;
}
export interface ProvisionedCapacityDescription {
    mcuCount?: number;
    workerCount?: number;
}
export interface CapacityDescription {
    autoScaling?: AutoScalingDescription;
    provisionedCapacity?: ProvisionedCapacityDescription;
}
export interface VpcDescription {
    securityGroups?: string[];
    subnets?: string[];
}
export interface ApacheKafkaClusterDescription {
    bootstrapServers?: string;
    vpc?: VpcDescription;
}
export interface KafkaClusterDescription {
    apacheKafkaCluster?: ApacheKafkaClusterDescription;
}
export interface KafkaClusterClientAuthenticationDescription {
    authenticationType?: string;
}
export interface KafkaClusterEncryptionInTransitDescription {
    encryptionType?: string;
}
export interface CloudWatchLogsLogDeliveryDescription {
    enabled?: boolean;
    logGroup?: string;
}
export interface FirehoseLogDeliveryDescription {
    deliveryStream?: string;
    enabled?: boolean;
}
export interface S3LogDeliveryDescription {
    bucket?: string;
    enabled?: boolean;
    prefix?: string;
}
export interface WorkerLogDeliveryDescription {
    cloudWatchLogs?: CloudWatchLogsLogDeliveryDescription;
    firehose?: FirehoseLogDeliveryDescription;
    s3?: S3LogDeliveryDescription;
}
export interface LogDeliveryDescription {
    workerLogDelivery?: WorkerLogDeliveryDescription;
}
export interface CustomPluginDescription {
    customPluginArn?: string;
    revision?: number;
}
export interface PluginDescription {
    customPlugin?: CustomPluginDescription;
}
export type __listOfPluginDescription = PluginDescription[];
export interface WorkerConfigurationDescription {
    revision?: number;
    workerConfigurationArn?: string;
}
export interface StateDescription {
    code?: string;
    message?: string;
}
export interface DescribeConnectorResponse {
    capacity?: CapacityDescription;
    connectorArn?: string;
    connectorConfiguration?: {
        [key: string]: string | undefined;
    };
    connectorDescription?: string;
    connectorName?: string;
    connectorState?: string;
    creationTime?: Date;
    currentVersion?: string;
    kafkaCluster?: KafkaClusterDescription;
    kafkaClusterClientAuthentication?: KafkaClusterClientAuthenticationDescription;
    kafkaClusterEncryptionInTransit?: KafkaClusterEncryptionInTransitDescription;
    kafkaConnectVersion?: string;
    logDelivery?: LogDeliveryDescription;
    networkType?: string;
    plugins?: PluginDescription[];
    serviceExecutionRoleArn?: string;
    workerConfiguration?: WorkerConfigurationDescription;
    stateDescription?: StateDescription;
}
export interface DescribeConnectorOperationRequest {
    connectorOperationArn: string;
}
export type ConnectorOperationState = string;
export type ConnectorOperationType = string;
export type ConnectorOperationStepType = string;
export type ConnectorOperationStepState = string;
export interface ConnectorOperationStep {
    stepType?: string;
    stepState?: string;
}
export type __listOfConnectorOperationStep = ConnectorOperationStep[];
export interface WorkerSetting {
    capacity?: CapacityDescription;
}
export interface DescribeConnectorOperationResponse {
    connectorArn?: string;
    connectorOperationArn?: string;
    connectorOperationState?: string;
    connectorOperationType?: string;
    operationSteps?: ConnectorOperationStep[];
    originWorkerSetting?: WorkerSetting;
    originConnectorConfiguration?: {
        [key: string]: string | undefined;
    };
    targetWorkerSetting?: WorkerSetting;
    targetConnectorConfiguration?: {
        [key: string]: string | undefined;
    };
    errorInfo?: StateDescription;
    creationTime?: Date;
    endTime?: Date;
}
export interface DescribeCustomPluginRequest {
    customPluginArn: string;
}
export interface CustomPluginFileDescription {
    fileMd5?: string;
    fileSize?: number;
}
export interface S3LocationDescription {
    bucketArn?: string;
    fileKey?: string;
    objectVersion?: string;
}
export interface CustomPluginLocationDescription {
    s3Location?: S3LocationDescription;
}
export interface CustomPluginRevisionSummary {
    contentType?: string;
    creationTime?: Date;
    description?: string;
    fileDescription?: CustomPluginFileDescription;
    location?: CustomPluginLocationDescription;
    revision?: number;
}
export interface DescribeCustomPluginResponse {
    creationTime?: Date;
    customPluginArn?: string;
    customPluginState?: string;
    description?: string;
    latestRevision?: CustomPluginRevisionSummary;
    name?: string;
    stateDescription?: StateDescription;
}
export interface DescribeWorkerConfigurationRequest {
    workerConfigurationArn: string;
}
export interface WorkerConfigurationRevisionDescription {
    creationTime?: Date;
    description?: string;
    propertiesFileContent?: string | redacted.Redacted<string>;
    revision?: number;
}
export interface DescribeWorkerConfigurationResponse {
    creationTime?: Date;
    description?: string;
    latestRevision?: WorkerConfigurationRevisionDescription;
    name?: string;
    workerConfigurationArn?: string;
    workerConfigurationState?: string;
}
export type MaxResults = number;
export interface ListConnectorOperationsRequest {
    connectorArn: string;
    maxResults?: number;
    nextToken?: string;
}
export interface ConnectorOperationSummary {
    connectorOperationArn?: string;
    connectorOperationType?: string;
    connectorOperationState?: string;
    creationTime?: Date;
    endTime?: Date;
}
export type __listOfConnectorOperationSummary = ConnectorOperationSummary[];
export interface ListConnectorOperationsResponse {
    connectorOperations?: ConnectorOperationSummary[];
    nextToken?: string;
}
export interface ListConnectorsRequest {
    connectorNamePrefix?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface ConnectorSummary {
    capacity?: CapacityDescription;
    connectorArn?: string;
    connectorDescription?: string;
    connectorName?: string;
    connectorState?: string;
    creationTime?: Date;
    currentVersion?: string;
    kafkaCluster?: KafkaClusterDescription;
    kafkaClusterClientAuthentication?: KafkaClusterClientAuthenticationDescription;
    kafkaClusterEncryptionInTransit?: KafkaClusterEncryptionInTransitDescription;
    kafkaConnectVersion?: string;
    logDelivery?: LogDeliveryDescription;
    networkType?: string;
    plugins?: PluginDescription[];
    serviceExecutionRoleArn?: string;
    workerConfiguration?: WorkerConfigurationDescription;
}
export type __listOfConnectorSummary = ConnectorSummary[];
export interface ListConnectorsResponse {
    connectors?: ConnectorSummary[];
    nextToken?: string;
}
export interface ListCustomPluginsRequest {
    maxResults?: number;
    nextToken?: string;
    namePrefix?: string;
}
export interface CustomPluginSummary {
    creationTime?: Date;
    customPluginArn?: string;
    customPluginState?: string;
    description?: string;
    latestRevision?: CustomPluginRevisionSummary;
    name?: string;
}
export type __listOfCustomPluginSummary = CustomPluginSummary[];
export interface ListCustomPluginsResponse {
    customPlugins?: CustomPluginSummary[];
    nextToken?: string;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListWorkerConfigurationsRequest {
    maxResults?: number;
    nextToken?: string;
    namePrefix?: string;
}
export interface WorkerConfigurationSummary {
    creationTime?: Date;
    description?: string;
    latestRevision?: WorkerConfigurationRevisionSummary;
    name?: string;
    workerConfigurationArn?: string;
    workerConfigurationState?: string;
}
export type __listOfWorkerConfigurationSummary = WorkerConfigurationSummary[];
export interface ListWorkerConfigurationsResponse {
    nextToken?: string;
    workerConfigurations?: WorkerConfigurationSummary[];
}
export interface RestartConnectorRequest {
    connectorArn: string;
    onlyFailedTasks?: boolean;
}
export interface RestartConnectorResponse {
    connectorArn?: string;
    connectorOperationArn?: string;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface ScaleInPolicyUpdate {
    cpuUtilizationPercentage: number;
}
export interface ScaleOutPolicyUpdate {
    cpuUtilizationPercentage: number;
}
export interface AutoScalingUpdate {
    maxWorkerCount: number;
    mcuCount: number;
    minWorkerCount: number;
    scaleInPolicy: ScaleInPolicyUpdate;
    scaleOutPolicy: ScaleOutPolicyUpdate;
    maxAutoscalingTaskCount?: number;
}
export interface ProvisionedCapacityUpdate {
    mcuCount: number;
    workerCount: number;
}
export interface CapacityUpdate {
    autoScaling?: AutoScalingUpdate;
    provisionedCapacity?: ProvisionedCapacityUpdate;
}
export type ConnectorConfigurationUpdate = {
    [key: string]: string | undefined;
};
export interface UpdateConnectorRequest {
    capacity?: CapacityUpdate;
    connectorConfiguration?: {
        [key: string]: string | undefined;
    };
    connectorArn: string;
    currentVersion: string;
}
export interface UpdateConnectorResponse {
    connectorArn?: string;
    connectorState?: string;
    connectorOperationArn?: string;
}
export type CreateConnectorError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a connector using the specified properties.
 */
export declare const createConnector: API.OperationMethod<CreateConnectorRequest, CreateConnectorResponse, CreateConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateCustomPluginError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a custom plugin using the specified properties.
 */
export declare const createCustomPlugin: API.OperationMethod<CreateCustomPluginRequest, CreateCustomPluginResponse, CreateCustomPluginError, Credentials | HttpClient.HttpClient>;
export type CreateWorkerConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a worker configuration using the specified properties.
 */
export declare const createWorkerConfiguration: API.OperationMethod<CreateWorkerConfigurationRequest, CreateWorkerConfigurationResponse, CreateWorkerConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the specified connector.
 */
export declare const deleteConnector: API.OperationMethod<DeleteConnectorRequest, DeleteConnectorResponse, DeleteConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomPluginError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a custom plugin.
 */
export declare const deleteCustomPlugin: API.OperationMethod<DeleteCustomPluginRequest, DeleteCustomPluginResponse, DeleteCustomPluginError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkerConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the specified worker configuration.
 */
export declare const deleteWorkerConfiguration: API.OperationMethod<DeleteWorkerConfigurationRequest, DeleteWorkerConfigurationResponse, DeleteWorkerConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectorError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns summary information about the connector.
 */
export declare const describeConnector: API.OperationMethod<DescribeConnectorRequest, DescribeConnectorResponse, DescribeConnectorError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectorOperationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns information about the specified connector's operations.
 */
export declare const describeConnectorOperation: API.OperationMethod<DescribeConnectorOperationRequest, DescribeConnectorOperationResponse, DescribeConnectorOperationError, Credentials | HttpClient.HttpClient>;
export type DescribeCustomPluginError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * A summary description of the custom plugin.
 */
export declare const describeCustomPlugin: API.OperationMethod<DescribeCustomPluginRequest, DescribeCustomPluginResponse, DescribeCustomPluginError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkerConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns information about a worker configuration.
 */
export declare const describeWorkerConfiguration: API.OperationMethod<DescribeWorkerConfigurationRequest, DescribeWorkerConfigurationResponse, DescribeWorkerConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListConnectorOperationsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Lists information about a connector's operation(s).
 */
export declare const listConnectorOperations: API.PaginatedOperationMethod<ListConnectorOperationsRequest, ListConnectorOperationsResponse, ListConnectorOperationsError, Credentials | HttpClient.HttpClient, ConnectorOperationSummary>;
export type ListConnectorsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the connectors in this account and Region. The list is limited to connectors whose name starts with the specified prefix. The response also includes a description of each of the listed connectors.
 */
export declare const listConnectors: API.PaginatedOperationMethod<ListConnectorsRequest, ListConnectorsResponse, ListConnectorsError, Credentials | HttpClient.HttpClient, ConnectorSummary>;
export type ListCustomPluginsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all of the custom plugins in this account and Region.
 */
export declare const listCustomPlugins: API.PaginatedOperationMethod<ListCustomPluginsRequest, ListCustomPluginsResponse, ListCustomPluginsError, Credentials | HttpClient.HttpClient, CustomPluginSummary>;
export type ListTagsForResourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Lists all the tags attached to the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWorkerConfigurationsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all of the worker configurations in this account and Region.
 */
export declare const listWorkerConfigurations: API.PaginatedOperationMethod<ListWorkerConfigurationsRequest, ListWorkerConfigurationsResponse, ListWorkerConfigurationsError, Credentials | HttpClient.HttpClient, WorkerConfigurationSummary>;
export type RestartConnectorError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Restarts the specified connector. By default, this operation restarts the connector and all of its tasks. This operation is asynchronous and returns a connector operation ARN that you can pass to `DescribeConnectorOperation` to track the state of the restart.
 */
export declare const restartConnector: API.OperationMethod<RestartConnectorRequest, RestartConnectorResponse, RestartConnectorError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Attaches tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Removes tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates the specified connector. For request body, specify only one parameter: either `capacity` or `connectorConfiguration`.
 */
export declare const updateConnector: API.OperationMethod<UpdateConnectorRequest, UpdateConnectorResponse, UpdateConnectorError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=kafkaconnect.d.ts.map