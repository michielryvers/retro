import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AuthorizationNotFoundFault_base: S.TaggedErrorClass<"AuthorizationNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AuthorizationNotFoundFault extends /*@__PURE__*/ AuthorizationNotFoundFault_base {
}
declare const CertificateNotFoundFault_base: S.TaggedErrorClass<"CertificateNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CertificateNotFoundFault extends /*@__PURE__*/ CertificateNotFoundFault_base {
}
declare const DBClusterAlreadyExistsFault_base: S.TaggedErrorClass<"DBClusterAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBClusterAlreadyExistsFault extends /*@__PURE__*/ DBClusterAlreadyExistsFault_base {
}
declare const DBClusterNotFoundFault_base: S.TaggedErrorClass<"DBClusterNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterNotFoundFault extends /*@__PURE__*/ DBClusterNotFoundFault_base {
}
declare const DBClusterParameterGroupNotFoundFault_base: S.TaggedErrorClass<"DBClusterParameterGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterParameterGroupNotFoundFault extends /*@__PURE__*/ DBClusterParameterGroupNotFoundFault_base {
}
declare const DBClusterQuotaExceededFault_base: S.TaggedErrorClass<"DBClusterQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class DBClusterQuotaExceededFault extends /*@__PURE__*/ DBClusterQuotaExceededFault_base {
}
declare const DBClusterSnapshotAlreadyExistsFault_base: S.TaggedErrorClass<"DBClusterSnapshotAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBClusterSnapshotAlreadyExistsFault extends /*@__PURE__*/ DBClusterSnapshotAlreadyExistsFault_base {
}
declare const DBClusterSnapshotNotFoundFault_base: S.TaggedErrorClass<"DBClusterSnapshotNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterSnapshotNotFoundFault extends /*@__PURE__*/ DBClusterSnapshotNotFoundFault_base {
}
declare const DBInstanceAlreadyExistsFault_base: S.TaggedErrorClass<"DBInstanceAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBInstanceAlreadyExistsFault extends /*@__PURE__*/ DBInstanceAlreadyExistsFault_base {
}
declare const DBInstanceNotFoundFault_base: S.TaggedErrorClass<"DBInstanceNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBInstanceNotFoundFault extends /*@__PURE__*/ DBInstanceNotFoundFault_base {
}
declare const DBParameterGroupAlreadyExistsFault_base: S.TaggedErrorClass<"DBParameterGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBParameterGroupAlreadyExistsFault extends /*@__PURE__*/ DBParameterGroupAlreadyExistsFault_base {
}
declare const DBParameterGroupNotFoundFault_base: S.TaggedErrorClass<"DBParameterGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBParameterGroupNotFoundFault extends /*@__PURE__*/ DBParameterGroupNotFoundFault_base {
}
declare const DBParameterGroupQuotaExceededFault_base: S.TaggedErrorClass<"DBParameterGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBParameterGroupQuotaExceededFault extends /*@__PURE__*/ DBParameterGroupQuotaExceededFault_base {
}
declare const DBSecurityGroupNotFoundFault_base: S.TaggedErrorClass<"DBSecurityGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSecurityGroupNotFoundFault extends /*@__PURE__*/ DBSecurityGroupNotFoundFault_base {
}
declare const DBSnapshotAlreadyExistsFault_base: S.TaggedErrorClass<"DBSnapshotAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBSnapshotAlreadyExistsFault extends /*@__PURE__*/ DBSnapshotAlreadyExistsFault_base {
}
declare const DBSnapshotNotFoundFault_base: S.TaggedErrorClass<"DBSnapshotNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSnapshotNotFoundFault extends /*@__PURE__*/ DBSnapshotNotFoundFault_base {
}
declare const DBSubnetGroupAlreadyExistsFault_base: S.TaggedErrorClass<"DBSubnetGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBSubnetGroupAlreadyExistsFault extends /*@__PURE__*/ DBSubnetGroupAlreadyExistsFault_base {
}
declare const DBSubnetGroupDoesNotCoverEnoughAZs_base: S.TaggedErrorClass<"DBSubnetGroupDoesNotCoverEnoughAZs", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSubnetGroupDoesNotCoverEnoughAZs extends /*@__PURE__*/ DBSubnetGroupDoesNotCoverEnoughAZs_base {
}
declare const DBSubnetGroupNotFoundFault_base: S.TaggedErrorClass<"DBSubnetGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSubnetGroupNotFoundFault extends /*@__PURE__*/ DBSubnetGroupNotFoundFault_base {
}
declare const DBSubnetGroupQuotaExceededFault_base: S.TaggedErrorClass<"DBSubnetGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSubnetGroupQuotaExceededFault extends /*@__PURE__*/ DBSubnetGroupQuotaExceededFault_base {
}
declare const DBSubnetQuotaExceededFault_base: S.TaggedErrorClass<"DBSubnetQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSubnetQuotaExceededFault extends /*@__PURE__*/ DBSubnetQuotaExceededFault_base {
}
declare const DBUpgradeDependencyFailureFault_base: S.TaggedErrorClass<"DBUpgradeDependencyFailureFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBUpgradeDependencyFailureFault extends /*@__PURE__*/ DBUpgradeDependencyFailureFault_base {
}
declare const EventSubscriptionQuotaExceededFault_base: S.TaggedErrorClass<"EventSubscriptionQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EventSubscriptionQuotaExceededFault extends /*@__PURE__*/ EventSubscriptionQuotaExceededFault_base {
}
declare const GlobalClusterAlreadyExistsFault_base: S.TaggedErrorClass<"GlobalClusterAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class GlobalClusterAlreadyExistsFault extends /*@__PURE__*/ GlobalClusterAlreadyExistsFault_base {
}
declare const GlobalClusterNotFoundFault_base: S.TaggedErrorClass<"GlobalClusterNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GlobalClusterNotFoundFault extends /*@__PURE__*/ GlobalClusterNotFoundFault_base {
}
declare const GlobalClusterQuotaExceededFault_base: S.TaggedErrorClass<"GlobalClusterQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GlobalClusterQuotaExceededFault extends /*@__PURE__*/ GlobalClusterQuotaExceededFault_base {
}
declare const InstanceQuotaExceededFault_base: S.TaggedErrorClass<"InstanceQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InstanceQuotaExceededFault extends /*@__PURE__*/ InstanceQuotaExceededFault_base {
}
declare const InsufficientDBClusterCapacityFault_base: S.TaggedErrorClass<"InsufficientDBClusterCapacityFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class InsufficientDBClusterCapacityFault extends /*@__PURE__*/ InsufficientDBClusterCapacityFault_base {
}
declare const InsufficientDBInstanceCapacityFault_base: S.TaggedErrorClass<"InsufficientDBInstanceCapacityFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientDBInstanceCapacityFault extends /*@__PURE__*/ InsufficientDBInstanceCapacityFault_base {
}
declare const InsufficientStorageClusterCapacityFault_base: S.TaggedErrorClass<"InsufficientStorageClusterCapacityFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientStorageClusterCapacityFault extends /*@__PURE__*/ InsufficientStorageClusterCapacityFault_base {
}
declare const InvalidDBClusterSnapshotStateFault_base: S.TaggedErrorClass<"InvalidDBClusterSnapshotStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBClusterSnapshotStateFault extends /*@__PURE__*/ InvalidDBClusterSnapshotStateFault_base {
}
declare const InvalidDBClusterStateFault_base: S.TaggedErrorClass<"InvalidDBClusterStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBClusterStateFault extends /*@__PURE__*/ InvalidDBClusterStateFault_base {
}
declare const InvalidDBInstanceStateFault_base: S.TaggedErrorClass<"InvalidDBInstanceStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBInstanceStateFault extends /*@__PURE__*/ InvalidDBInstanceStateFault_base {
}
declare const InvalidDBParameterGroupStateFault_base: S.TaggedErrorClass<"InvalidDBParameterGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBParameterGroupStateFault extends /*@__PURE__*/ InvalidDBParameterGroupStateFault_base {
}
declare const InvalidDBSecurityGroupStateFault_base: S.TaggedErrorClass<"InvalidDBSecurityGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBSecurityGroupStateFault extends /*@__PURE__*/ InvalidDBSecurityGroupStateFault_base {
}
declare const InvalidDBSnapshotStateFault_base: S.TaggedErrorClass<"InvalidDBSnapshotStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBSnapshotStateFault extends /*@__PURE__*/ InvalidDBSnapshotStateFault_base {
}
declare const InvalidDBSubnetGroupStateFault_base: S.TaggedErrorClass<"InvalidDBSubnetGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBSubnetGroupStateFault extends /*@__PURE__*/ InvalidDBSubnetGroupStateFault_base {
}
declare const InvalidDBSubnetStateFault_base: S.TaggedErrorClass<"InvalidDBSubnetStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBSubnetStateFault extends /*@__PURE__*/ InvalidDBSubnetStateFault_base {
}
declare const InvalidEventSubscriptionStateFault_base: S.TaggedErrorClass<"InvalidEventSubscriptionStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEventSubscriptionStateFault extends /*@__PURE__*/ InvalidEventSubscriptionStateFault_base {
}
declare const InvalidGlobalClusterStateFault_base: S.TaggedErrorClass<"InvalidGlobalClusterStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidGlobalClusterStateFault extends /*@__PURE__*/ InvalidGlobalClusterStateFault_base {
}
declare const InvalidRestoreFault_base: S.TaggedErrorClass<"InvalidRestoreFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRestoreFault extends /*@__PURE__*/ InvalidRestoreFault_base {
}
declare const InvalidSubnet_base: S.TaggedErrorClass<"InvalidSubnet", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSubnet extends /*@__PURE__*/ InvalidSubnet_base {
}
declare const InvalidVPCNetworkStateFault_base: S.TaggedErrorClass<"InvalidVPCNetworkStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidVPCNetworkStateFault extends /*@__PURE__*/ InvalidVPCNetworkStateFault_base {
}
declare const KMSKeyNotAccessibleFault_base: S.TaggedErrorClass<"KMSKeyNotAccessibleFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KMSKeyNotAccessibleFault extends /*@__PURE__*/ KMSKeyNotAccessibleFault_base {
}
declare const NetworkTypeNotSupported_base: S.TaggedErrorClass<"NetworkTypeNotSupported", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NetworkTypeNotSupported extends /*@__PURE__*/ NetworkTypeNotSupported_base {
}
declare const ResourceNotFoundFault_base: S.TaggedErrorClass<"ResourceNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundFault extends /*@__PURE__*/ ResourceNotFoundFault_base {
}
declare const SharedSnapshotQuotaExceededFault_base: S.TaggedErrorClass<"SharedSnapshotQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SharedSnapshotQuotaExceededFault extends /*@__PURE__*/ SharedSnapshotQuotaExceededFault_base {
}
declare const SnapshotQuotaExceededFault_base: S.TaggedErrorClass<"SnapshotQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotQuotaExceededFault extends /*@__PURE__*/ SnapshotQuotaExceededFault_base {
}
declare const SNSInvalidTopicFault_base: S.TaggedErrorClass<"SNSInvalidTopicFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SNSInvalidTopicFault extends /*@__PURE__*/ SNSInvalidTopicFault_base {
}
declare const SNSNoAuthorizationFault_base: S.TaggedErrorClass<"SNSNoAuthorizationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SNSNoAuthorizationFault extends /*@__PURE__*/ SNSNoAuthorizationFault_base {
}
declare const SNSTopicArnNotFoundFault_base: S.TaggedErrorClass<"SNSTopicArnNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SNSTopicArnNotFoundFault extends /*@__PURE__*/ SNSTopicArnNotFoundFault_base {
}
declare const SourceNotFoundFault_base: S.TaggedErrorClass<"SourceNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SourceNotFoundFault extends /*@__PURE__*/ SourceNotFoundFault_base {
}
declare const StorageQuotaExceededFault_base: S.TaggedErrorClass<"StorageQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StorageQuotaExceededFault extends /*@__PURE__*/ StorageQuotaExceededFault_base {
}
declare const StorageTypeNotSupportedFault_base: S.TaggedErrorClass<"StorageTypeNotSupportedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StorageTypeNotSupportedFault extends /*@__PURE__*/ StorageTypeNotSupportedFault_base {
}
declare const SubnetAlreadyInUse_base: S.TaggedErrorClass<"SubnetAlreadyInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class SubnetAlreadyInUse extends /*@__PURE__*/ SubnetAlreadyInUse_base {
}
declare const SubscriptionAlreadyExistFault_base: S.TaggedErrorClass<"SubscriptionAlreadyExistFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubscriptionAlreadyExistFault extends /*@__PURE__*/ SubscriptionAlreadyExistFault_base {
}
declare const SubscriptionCategoryNotFoundFault_base: S.TaggedErrorClass<"SubscriptionCategoryNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubscriptionCategoryNotFoundFault extends /*@__PURE__*/ SubscriptionCategoryNotFoundFault_base {
}
declare const SubscriptionNotFoundFault_base: S.TaggedErrorClass<"SubscriptionNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubscriptionNotFoundFault extends /*@__PURE__*/ SubscriptionNotFoundFault_base {
}
export interface AddSourceIdentifierToSubscriptionMessage {
    SubscriptionName?: string;
    SourceIdentifier?: string;
}
export type SourceIdsList = string[];
export type EventCategoriesList = string[];
export interface EventSubscription {
    CustomerAwsId?: string;
    CustSubscriptionId?: string;
    SnsTopicArn?: string;
    Status?: string;
    SubscriptionCreationTime?: string;
    SourceType?: string;
    SourceIdsList?: string[];
    EventCategoriesList?: string[];
    Enabled?: boolean;
    EventSubscriptionArn?: string;
}
export interface AddSourceIdentifierToSubscriptionResult {
    EventSubscription?: EventSubscription;
}
export interface Tag {
    Key?: string;
    Value?: string;
}
export type TagList = Tag[];
export interface AddTagsToResourceMessage {
    ResourceName?: string;
    Tags?: Tag[];
}
export interface AddTagsToResourceResponse {
}
export interface ApplyPendingMaintenanceActionMessage {
    ResourceIdentifier?: string;
    ApplyAction?: string;
    OptInType?: string;
}
export interface PendingMaintenanceAction {
    Action?: string;
    AutoAppliedAfterDate?: Date;
    ForcedApplyDate?: Date;
    OptInStatus?: string;
    CurrentApplyDate?: Date;
    Description?: string;
}
export type PendingMaintenanceActionDetails = PendingMaintenanceAction[];
export interface ResourcePendingMaintenanceActions {
    ResourceIdentifier?: string;
    PendingMaintenanceActionDetails?: PendingMaintenanceAction[];
}
export interface ApplyPendingMaintenanceActionResult {
    ResourcePendingMaintenanceActions?: ResourcePendingMaintenanceActions;
}
export interface CopyDBClusterParameterGroupMessage {
    SourceDBClusterParameterGroupIdentifier?: string;
    TargetDBClusterParameterGroupIdentifier?: string;
    TargetDBClusterParameterGroupDescription?: string;
    Tags?: Tag[];
}
export interface DBClusterParameterGroup {
    DBClusterParameterGroupName?: string;
    DBParameterGroupFamily?: string;
    Description?: string;
    DBClusterParameterGroupArn?: string;
}
export interface CopyDBClusterParameterGroupResult {
    DBClusterParameterGroup?: DBClusterParameterGroup;
}
export interface CopyDBClusterSnapshotMessage {
    SourceDBClusterSnapshotIdentifier?: string;
    TargetDBClusterSnapshotIdentifier?: string;
    KmsKeyId?: string;
    PreSignedUrl?: string;
    CopyTags?: boolean;
    Tags?: Tag[];
}
export type AvailabilityZones = string[];
export interface DBClusterSnapshot {
    AvailabilityZones?: string[];
    DBClusterSnapshotIdentifier?: string;
    DBClusterIdentifier?: string;
    SnapshotCreateTime?: Date;
    Engine?: string;
    Status?: string;
    Port?: number;
    VpcId?: string;
    ClusterCreateTime?: Date;
    MasterUsername?: string;
    EngineVersion?: string;
    SnapshotType?: string;
    PercentProgress?: number;
    StorageEncrypted?: boolean;
    KmsKeyId?: string;
    DBClusterSnapshotArn?: string;
    SourceDBClusterSnapshotArn?: string;
    StorageType?: string;
}
export interface CopyDBClusterSnapshotResult {
    DBClusterSnapshot?: DBClusterSnapshot;
}
export type VpcSecurityGroupIdList = string[];
export type LogTypeList = string[];
export type GlobalClusterIdentifier = string;
export interface ServerlessV2ScalingConfiguration {
    MinCapacity?: number;
    MaxCapacity?: number;
}
export interface CreateDBClusterMessage {
    AvailabilityZones?: string[];
    BackupRetentionPeriod?: number;
    DBClusterIdentifier?: string;
    DBClusterParameterGroupName?: string;
    VpcSecurityGroupIds?: string[];
    DBSubnetGroupName?: string;
    Engine?: string;
    EngineVersion?: string;
    Port?: number;
    MasterUsername?: string;
    MasterUserPassword?: string | redacted.Redacted<string>;
    PreferredBackupWindow?: string;
    PreferredMaintenanceWindow?: string;
    Tags?: Tag[];
    StorageEncrypted?: boolean;
    KmsKeyId?: string;
    PreSignedUrl?: string;
    EnableCloudwatchLogsExports?: string[];
    DeletionProtection?: boolean;
    GlobalClusterIdentifier?: string;
    StorageType?: string;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfiguration;
    ManageMasterUserPassword?: boolean;
    MasterUserSecretKmsKeyId?: string;
    NetworkType?: string;
    CopyTagsToSnapshot?: boolean;
}
export type ReadReplicaIdentifierList = string[];
export interface DBClusterMember {
    DBInstanceIdentifier?: string;
    IsClusterWriter?: boolean;
    DBClusterParameterGroupStatus?: string;
    PromotionTier?: number;
}
export type DBClusterMemberList = DBClusterMember[];
export interface VpcSecurityGroupMembership {
    VpcSecurityGroupId?: string;
    Status?: string;
}
export type VpcSecurityGroupMembershipList = VpcSecurityGroupMembership[];
export interface DBClusterRole {
    RoleArn?: string;
    Status?: string;
}
export type DBClusterRoles = DBClusterRole[];
export interface ServerlessV2ScalingConfigurationInfo {
    MinCapacity?: number;
    MaxCapacity?: number;
}
export interface ClusterMasterUserSecret {
    SecretArn?: string;
    SecretStatus?: string;
    KmsKeyId?: string;
}
export interface DBCluster {
    AvailabilityZones?: string[];
    BackupRetentionPeriod?: number;
    DBClusterIdentifier?: string;
    DBClusterParameterGroup?: string;
    DBSubnetGroup?: string;
    Status?: string;
    PercentProgress?: string;
    EarliestRestorableTime?: Date;
    Endpoint?: string;
    ReaderEndpoint?: string;
    MultiAZ?: boolean;
    Engine?: string;
    EngineVersion?: string;
    LatestRestorableTime?: Date;
    Port?: number;
    MasterUsername?: string;
    PreferredBackupWindow?: string;
    PreferredMaintenanceWindow?: string;
    ReplicationSourceIdentifier?: string;
    ReadReplicaIdentifiers?: string[];
    DBClusterMembers?: DBClusterMember[];
    VpcSecurityGroups?: VpcSecurityGroupMembership[];
    HostedZoneId?: string;
    StorageEncrypted?: boolean;
    KmsKeyId?: string;
    DbClusterResourceId?: string;
    DBClusterArn?: string;
    AssociatedRoles?: DBClusterRole[];
    CloneGroupId?: string;
    ClusterCreateTime?: Date;
    EnabledCloudwatchLogsExports?: string[];
    DeletionProtection?: boolean;
    IOOptimizedNextAllowedModificationTime?: Date;
    StorageType?: string;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfigurationInfo;
    MasterUserSecret?: ClusterMasterUserSecret;
    NetworkType?: string;
    CopyTagsToSnapshot?: boolean;
}
export interface CreateDBClusterResult {
    DBCluster?: DBCluster;
}
export interface CreateDBClusterParameterGroupMessage {
    DBClusterParameterGroupName?: string;
    DBParameterGroupFamily?: string;
    Description?: string;
    Tags?: Tag[];
}
export interface CreateDBClusterParameterGroupResult {
    DBClusterParameterGroup?: DBClusterParameterGroup;
}
export interface CreateDBClusterSnapshotMessage {
    DBClusterSnapshotIdentifier?: string;
    DBClusterIdentifier?: string;
    Tags?: Tag[];
}
export interface CreateDBClusterSnapshotResult {
    DBClusterSnapshot?: DBClusterSnapshot;
}
export interface CreateDBInstanceMessage {
    DBInstanceIdentifier?: string;
    DBInstanceClass?: string;
    Engine?: string;
    AvailabilityZone?: string;
    PreferredMaintenanceWindow?: string;
    AutoMinorVersionUpgrade?: boolean;
    Tags?: Tag[];
    DBClusterIdentifier?: string;
    CopyTagsToSnapshot?: boolean;
    PromotionTier?: number;
    EnablePerformanceInsights?: boolean;
    PerformanceInsightsKMSKeyId?: string;
    CACertificateIdentifier?: string;
}
export interface Endpoint {
    Address?: string;
    Port?: number;
    HostedZoneId?: string;
}
export interface AvailabilityZone {
    Name?: string;
}
export interface Subnet {
    SubnetIdentifier?: string;
    SubnetAvailabilityZone?: AvailabilityZone;
    SubnetStatus?: string;
}
export type SubnetList = Subnet[];
export type NetworkTypeList = string[];
export interface DBSubnetGroup {
    DBSubnetGroupName?: string;
    DBSubnetGroupDescription?: string;
    VpcId?: string;
    SubnetGroupStatus?: string;
    Subnets?: Subnet[];
    DBSubnetGroupArn?: string;
    SupportedNetworkTypes?: string[];
}
export interface PendingCloudwatchLogsExports {
    LogTypesToEnable?: string[];
    LogTypesToDisable?: string[];
}
export interface PendingModifiedValues {
    DBInstanceClass?: string;
    AllocatedStorage?: number;
    MasterUserPassword?: string | redacted.Redacted<string>;
    Port?: number;
    BackupRetentionPeriod?: number;
    MultiAZ?: boolean;
    EngineVersion?: string;
    LicenseModel?: string;
    Iops?: number;
    DBInstanceIdentifier?: string;
    StorageType?: string;
    CACertificateIdentifier?: string;
    DBSubnetGroupName?: string;
    PendingCloudwatchLogsExports?: PendingCloudwatchLogsExports;
}
export interface DBInstanceStatusInfo {
    StatusType?: string;
    Normal?: boolean;
    Status?: string;
    Message?: string;
}
export type DBInstanceStatusInfoList = DBInstanceStatusInfo[];
export interface CertificateDetails {
    CAIdentifier?: string;
    ValidTill?: Date;
}
export interface DBInstance {
    DBInstanceIdentifier?: string;
    DBInstanceClass?: string;
    Engine?: string;
    DBInstanceStatus?: string;
    Endpoint?: Endpoint;
    InstanceCreateTime?: Date;
    PreferredBackupWindow?: string;
    BackupRetentionPeriod?: number;
    VpcSecurityGroups?: VpcSecurityGroupMembership[];
    AvailabilityZone?: string;
    DBSubnetGroup?: DBSubnetGroup;
    PreferredMaintenanceWindow?: string;
    PendingModifiedValues?: PendingModifiedValues;
    LatestRestorableTime?: Date;
    EngineVersion?: string;
    AutoMinorVersionUpgrade?: boolean;
    PubliclyAccessible?: boolean;
    StatusInfos?: DBInstanceStatusInfo[];
    DBClusterIdentifier?: string;
    StorageEncrypted?: boolean;
    KmsKeyId?: string;
    DbiResourceId?: string;
    CACertificateIdentifier?: string;
    CopyTagsToSnapshot?: boolean;
    PromotionTier?: number;
    DBInstanceArn?: string;
    EnabledCloudwatchLogsExports?: string[];
    CertificateDetails?: CertificateDetails;
    PerformanceInsightsEnabled?: boolean;
    PerformanceInsightsKMSKeyId?: string;
}
export interface CreateDBInstanceResult {
    DBInstance?: DBInstance;
}
export type SubnetIdentifierList = string[];
export interface CreateDBSubnetGroupMessage {
    DBSubnetGroupName?: string;
    DBSubnetGroupDescription?: string;
    SubnetIds?: string[];
    Tags?: Tag[];
}
export interface CreateDBSubnetGroupResult {
    DBSubnetGroup?: DBSubnetGroup;
}
export interface CreateEventSubscriptionMessage {
    SubscriptionName?: string;
    SnsTopicArn?: string;
    SourceType?: string;
    EventCategories?: string[];
    SourceIds?: string[];
    Enabled?: boolean;
    Tags?: Tag[];
}
export interface CreateEventSubscriptionResult {
    EventSubscription?: EventSubscription;
}
export interface CreateGlobalClusterMessage {
    GlobalClusterIdentifier?: string;
    SourceDBClusterIdentifier?: string;
    Engine?: string;
    EngineVersion?: string;
    DeletionProtection?: boolean;
    DatabaseName?: string;
    StorageEncrypted?: boolean;
}
export type ReadersArnList = string[];
export type GlobalClusterMemberSynchronizationStatus = "connected" | "pending-resync" | (string & {});
export interface GlobalClusterMember {
    DBClusterArn?: string;
    Readers?: string[];
    IsWriter?: boolean;
    SynchronizationStatus?: GlobalClusterMemberSynchronizationStatus;
}
export type GlobalClusterMemberList = GlobalClusterMember[];
export type FailoverStatus = "pending" | "failing-over" | "cancelling" | (string & {});
export interface FailoverState {
    Status?: FailoverStatus;
    FromDbClusterArn?: string;
    ToDbClusterArn?: string;
    IsDataLossAllowed?: boolean;
}
export interface GlobalCluster {
    GlobalClusterIdentifier?: string;
    GlobalClusterResourceId?: string;
    GlobalClusterArn?: string;
    Status?: string;
    Engine?: string;
    EngineVersion?: string;
    DatabaseName?: string;
    StorageEncrypted?: boolean;
    DeletionProtection?: boolean;
    GlobalClusterMembers?: GlobalClusterMember[];
    FailoverState?: FailoverState;
    TagList?: Tag[];
}
export interface CreateGlobalClusterResult {
    GlobalCluster?: GlobalCluster;
}
export interface DeleteDBClusterMessage {
    DBClusterIdentifier?: string;
    SkipFinalSnapshot?: boolean;
    FinalDBSnapshotIdentifier?: string;
}
export interface DeleteDBClusterResult {
    DBCluster?: DBCluster;
}
export interface DeleteDBClusterParameterGroupMessage {
    DBClusterParameterGroupName?: string;
}
export interface DeleteDBClusterParameterGroupResponse {
}
export interface DeleteDBClusterSnapshotMessage {
    DBClusterSnapshotIdentifier?: string;
}
export interface DeleteDBClusterSnapshotResult {
    DBClusterSnapshot?: DBClusterSnapshot;
}
export interface DeleteDBInstanceMessage {
    DBInstanceIdentifier?: string;
}
export interface DeleteDBInstanceResult {
    DBInstance?: DBInstance;
}
export interface DeleteDBSubnetGroupMessage {
    DBSubnetGroupName?: string;
}
export interface DeleteDBSubnetGroupResponse {
}
export interface DeleteEventSubscriptionMessage {
    SubscriptionName?: string;
}
export interface DeleteEventSubscriptionResult {
    EventSubscription?: EventSubscription;
}
export interface DeleteGlobalClusterMessage {
    GlobalClusterIdentifier?: string;
}
export interface DeleteGlobalClusterResult {
    GlobalCluster?: GlobalCluster;
}
export type FilterValueList = string[];
export interface Filter {
    Name?: string;
    Values?: string[];
}
export type FilterList = Filter[];
export interface DescribeCertificatesMessage {
    CertificateIdentifier?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export interface Certificate {
    CertificateIdentifier?: string;
    CertificateType?: string;
    Thumbprint?: string;
    ValidFrom?: Date;
    ValidTill?: Date;
    CertificateArn?: string;
}
export type CertificateList = Certificate[];
export interface CertificateMessage {
    Certificates?: Certificate[];
    Marker?: string;
}
export interface DescribeDBClusterParameterGroupsMessage {
    DBClusterParameterGroupName?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type DBClusterParameterGroupList = DBClusterParameterGroup[];
export interface DBClusterParameterGroupsMessage {
    Marker?: string;
    DBClusterParameterGroups?: DBClusterParameterGroup[];
}
export interface DescribeDBClusterParametersMessage {
    DBClusterParameterGroupName?: string;
    Source?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type ApplyMethod = "immediate" | "pending-reboot" | (string & {});
export interface Parameter {
    ParameterName?: string;
    ParameterValue?: string;
    Description?: string;
    Source?: string;
    ApplyType?: string;
    DataType?: string;
    AllowedValues?: string;
    IsModifiable?: boolean;
    MinimumEngineVersion?: string;
    ApplyMethod?: ApplyMethod;
}
export type ParametersList = Parameter[];
export interface DBClusterParameterGroupDetails {
    Parameters?: Parameter[];
    Marker?: string;
}
export interface DescribeDBClustersMessage {
    DBClusterIdentifier?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type DBClusterList = DBCluster[];
export interface DBClusterMessage {
    Marker?: string;
    DBClusters?: DBCluster[];
}
export interface DescribeDBClusterSnapshotAttributesMessage {
    DBClusterSnapshotIdentifier?: string;
}
export type AttributeValueList = string[];
export interface DBClusterSnapshotAttribute {
    AttributeName?: string;
    AttributeValues?: string[];
}
export type DBClusterSnapshotAttributeList = DBClusterSnapshotAttribute[];
export interface DBClusterSnapshotAttributesResult {
    DBClusterSnapshotIdentifier?: string;
    DBClusterSnapshotAttributes?: DBClusterSnapshotAttribute[];
}
export interface DescribeDBClusterSnapshotAttributesResult {
    DBClusterSnapshotAttributesResult?: DBClusterSnapshotAttributesResult;
}
export interface DescribeDBClusterSnapshotsMessage {
    DBClusterIdentifier?: string;
    DBClusterSnapshotIdentifier?: string;
    SnapshotType?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
    IncludeShared?: boolean;
    IncludePublic?: boolean;
}
export type DBClusterSnapshotList = DBClusterSnapshot[];
export interface DBClusterSnapshotMessage {
    Marker?: string;
    DBClusterSnapshots?: DBClusterSnapshot[];
}
export interface DescribeDBEngineVersionsMessage {
    Engine?: string;
    EngineVersion?: string;
    DBParameterGroupFamily?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
    DefaultOnly?: boolean;
    ListSupportedCharacterSets?: boolean;
    ListSupportedTimezones?: boolean;
}
export interface UpgradeTarget {
    Engine?: string;
    EngineVersion?: string;
    Description?: string;
    AutoUpgrade?: boolean;
    IsMajorVersionUpgrade?: boolean;
}
export type ValidUpgradeTargetList = UpgradeTarget[];
export type CACertificateIdentifiersList = string[];
export interface ServerlessV2FeaturesSupport {
    MinCapacity?: number;
    MaxCapacity?: number;
}
export interface DBEngineVersion {
    Engine?: string;
    EngineVersion?: string;
    DBParameterGroupFamily?: string;
    DBEngineDescription?: string;
    DBEngineVersionDescription?: string;
    ValidUpgradeTarget?: UpgradeTarget[];
    ExportableLogTypes?: string[];
    SupportsLogExportsToCloudwatchLogs?: boolean;
    SupportedCACertificateIdentifiers?: string[];
    SupportsCertificateRotationWithoutRestart?: boolean;
    ServerlessV2FeaturesSupport?: ServerlessV2FeaturesSupport;
}
export type DBEngineVersionList = DBEngineVersion[];
export interface DBEngineVersionMessage {
    Marker?: string;
    DBEngineVersions?: DBEngineVersion[];
}
export interface DescribeDBInstancesMessage {
    DBInstanceIdentifier?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type DBInstanceList = DBInstance[];
export interface DBInstanceMessage {
    Marker?: string;
    DBInstances?: DBInstance[];
}
export interface DescribeDBSubnetGroupsMessage {
    DBSubnetGroupName?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type DBSubnetGroups = DBSubnetGroup[];
export interface DBSubnetGroupMessage {
    Marker?: string;
    DBSubnetGroups?: DBSubnetGroup[];
}
export interface DescribeEngineDefaultClusterParametersMessage {
    DBParameterGroupFamily?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export interface EngineDefaults {
    DBParameterGroupFamily?: string;
    Marker?: string;
    Parameters?: Parameter[];
}
export interface DescribeEngineDefaultClusterParametersResult {
    EngineDefaults?: EngineDefaults;
}
export interface DescribeEventCategoriesMessage {
    SourceType?: string;
    Filters?: Filter[];
}
export interface EventCategoriesMap {
    SourceType?: string;
    EventCategories?: string[];
}
export type EventCategoriesMapList = EventCategoriesMap[];
export interface EventCategoriesMessage {
    EventCategoriesMapList?: EventCategoriesMap[];
}
export type SourceType = "db-instance" | "db-parameter-group" | "db-security-group" | "db-snapshot" | "db-cluster" | "db-cluster-snapshot" | (string & {});
export interface DescribeEventsMessage {
    SourceIdentifier?: string;
    SourceType?: SourceType;
    StartTime?: Date;
    EndTime?: Date;
    Duration?: number;
    EventCategories?: string[];
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export interface Event {
    SourceIdentifier?: string;
    SourceType?: SourceType;
    Message?: string;
    EventCategories?: string[];
    Date?: Date;
    SourceArn?: string;
}
export type EventList = Event[];
export interface EventsMessage {
    Marker?: string;
    Events?: Event[];
}
export interface DescribeEventSubscriptionsMessage {
    SubscriptionName?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type EventSubscriptionsList = EventSubscription[];
export interface EventSubscriptionsMessage {
    Marker?: string;
    EventSubscriptionsList?: EventSubscription[];
}
export interface DescribeGlobalClustersMessage {
    GlobalClusterIdentifier?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type GlobalClusterList = GlobalCluster[];
export interface GlobalClustersMessage {
    Marker?: string;
    GlobalClusters?: GlobalCluster[];
}
export interface DescribeOrderableDBInstanceOptionsMessage {
    Engine?: string;
    EngineVersion?: string;
    DBInstanceClass?: string;
    LicenseModel?: string;
    Vpc?: boolean;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type AvailabilityZoneList = AvailabilityZone[];
export interface OrderableDBInstanceOption {
    Engine?: string;
    EngineVersion?: string;
    DBInstanceClass?: string;
    LicenseModel?: string;
    AvailabilityZones?: AvailabilityZone[];
    Vpc?: boolean;
    StorageType?: string;
}
export type OrderableDBInstanceOptionsList = OrderableDBInstanceOption[];
export interface OrderableDBInstanceOptionsMessage {
    OrderableDBInstanceOptions?: OrderableDBInstanceOption[];
    Marker?: string;
}
export interface DescribePendingMaintenanceActionsMessage {
    ResourceIdentifier?: string;
    Filters?: Filter[];
    Marker?: string;
    MaxRecords?: number;
}
export type PendingMaintenanceActions = ResourcePendingMaintenanceActions[];
export interface PendingMaintenanceActionsMessage {
    PendingMaintenanceActions?: ResourcePendingMaintenanceActions[];
    Marker?: string;
}
export interface FailoverDBClusterMessage {
    DBClusterIdentifier?: string;
    TargetDBInstanceIdentifier?: string;
}
export interface FailoverDBClusterResult {
    DBCluster?: DBCluster;
}
export type DBClusterIdentifier = string;
export interface FailoverGlobalClusterMessage {
    GlobalClusterIdentifier?: string;
    TargetDbClusterIdentifier?: string;
    AllowDataLoss?: boolean;
    Switchover?: boolean;
}
export interface FailoverGlobalClusterResult {
    GlobalCluster?: GlobalCluster;
}
export interface ListTagsForResourceMessage {
    ResourceName?: string;
    Filters?: Filter[];
}
export interface TagListMessage {
    TagList?: Tag[];
}
export interface CloudwatchLogsExportConfiguration {
    EnableLogTypes?: string[];
    DisableLogTypes?: string[];
}
export interface ModifyDBClusterMessage {
    DBClusterIdentifier?: string;
    NewDBClusterIdentifier?: string;
    ApplyImmediately?: boolean;
    BackupRetentionPeriod?: number;
    DBClusterParameterGroupName?: string;
    VpcSecurityGroupIds?: string[];
    Port?: number;
    MasterUserPassword?: string | redacted.Redacted<string>;
    PreferredBackupWindow?: string;
    PreferredMaintenanceWindow?: string;
    CloudwatchLogsExportConfiguration?: CloudwatchLogsExportConfiguration;
    EngineVersion?: string;
    AllowMajorVersionUpgrade?: boolean;
    DeletionProtection?: boolean;
    StorageType?: string;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfiguration;
    ManageMasterUserPassword?: boolean;
    MasterUserSecretKmsKeyId?: string;
    RotateMasterUserPassword?: boolean;
    NetworkType?: string;
    CopyTagsToSnapshot?: boolean;
}
export interface ModifyDBClusterResult {
    DBCluster?: DBCluster;
}
export interface ModifyDBClusterParameterGroupMessage {
    DBClusterParameterGroupName?: string;
    Parameters?: Parameter[];
}
export interface DBClusterParameterGroupNameMessage {
    DBClusterParameterGroupName?: string;
}
export interface ModifyDBClusterSnapshotAttributeMessage {
    DBClusterSnapshotIdentifier?: string;
    AttributeName?: string;
    ValuesToAdd?: string[];
    ValuesToRemove?: string[];
}
export interface ModifyDBClusterSnapshotAttributeResult {
    DBClusterSnapshotAttributesResult?: DBClusterSnapshotAttributesResult;
}
export interface ModifyDBInstanceMessage {
    DBInstanceIdentifier?: string;
    DBInstanceClass?: string;
    ApplyImmediately?: boolean;
    PreferredMaintenanceWindow?: string;
    AutoMinorVersionUpgrade?: boolean;
    NewDBInstanceIdentifier?: string;
    CACertificateIdentifier?: string;
    CopyTagsToSnapshot?: boolean;
    PromotionTier?: number;
    EnablePerformanceInsights?: boolean;
    PerformanceInsightsKMSKeyId?: string;
    CertificateRotationRestart?: boolean;
}
export interface ModifyDBInstanceResult {
    DBInstance?: DBInstance;
}
export interface ModifyDBSubnetGroupMessage {
    DBSubnetGroupName?: string;
    DBSubnetGroupDescription?: string;
    SubnetIds?: string[];
}
export interface ModifyDBSubnetGroupResult {
    DBSubnetGroup?: DBSubnetGroup;
}
export interface ModifyEventSubscriptionMessage {
    SubscriptionName?: string;
    SnsTopicArn?: string;
    SourceType?: string;
    EventCategories?: string[];
    Enabled?: boolean;
}
export interface ModifyEventSubscriptionResult {
    EventSubscription?: EventSubscription;
}
export interface ModifyGlobalClusterMessage {
    GlobalClusterIdentifier?: string;
    NewGlobalClusterIdentifier?: string;
    DeletionProtection?: boolean;
}
export interface ModifyGlobalClusterResult {
    GlobalCluster?: GlobalCluster;
}
export interface RebootDBInstanceMessage {
    DBInstanceIdentifier?: string;
    ForceFailover?: boolean;
}
export interface RebootDBInstanceResult {
    DBInstance?: DBInstance;
}
export interface RemoveFromGlobalClusterMessage {
    GlobalClusterIdentifier?: string;
    DbClusterIdentifier?: string;
}
export interface RemoveFromGlobalClusterResult {
    GlobalCluster?: GlobalCluster;
}
export interface RemoveSourceIdentifierFromSubscriptionMessage {
    SubscriptionName?: string;
    SourceIdentifier?: string;
}
export interface RemoveSourceIdentifierFromSubscriptionResult {
    EventSubscription?: EventSubscription;
}
export type KeyList = string[];
export interface RemoveTagsFromResourceMessage {
    ResourceName?: string;
    TagKeys?: string[];
}
export interface RemoveTagsFromResourceResponse {
}
export interface ResetDBClusterParameterGroupMessage {
    DBClusterParameterGroupName?: string;
    ResetAllParameters?: boolean;
    Parameters?: Parameter[];
}
export interface RestoreDBClusterFromSnapshotMessage {
    AvailabilityZones?: string[];
    DBClusterIdentifier?: string;
    SnapshotIdentifier?: string;
    Engine?: string;
    EngineVersion?: string;
    Port?: number;
    DBSubnetGroupName?: string;
    VpcSecurityGroupIds?: string[];
    Tags?: Tag[];
    KmsKeyId?: string;
    EnableCloudwatchLogsExports?: string[];
    DeletionProtection?: boolean;
    DBClusterParameterGroupName?: string;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfiguration;
    StorageType?: string;
    NetworkType?: string;
    CopyTagsToSnapshot?: boolean;
}
export interface RestoreDBClusterFromSnapshotResult {
    DBCluster?: DBCluster;
}
export interface RestoreDBClusterToPointInTimeMessage {
    DBClusterIdentifier?: string;
    RestoreType?: string;
    SourceDBClusterIdentifier?: string;
    RestoreToTime?: Date;
    UseLatestRestorableTime?: boolean;
    Port?: number;
    DBSubnetGroupName?: string;
    VpcSecurityGroupIds?: string[];
    Tags?: Tag[];
    KmsKeyId?: string;
    EnableCloudwatchLogsExports?: string[];
    DeletionProtection?: boolean;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfiguration;
    StorageType?: string;
    NetworkType?: string;
    CopyTagsToSnapshot?: boolean;
}
export interface RestoreDBClusterToPointInTimeResult {
    DBCluster?: DBCluster;
}
export interface StartDBClusterMessage {
    DBClusterIdentifier?: string;
}
export interface StartDBClusterResult {
    DBCluster?: DBCluster;
}
export interface StopDBClusterMessage {
    DBClusterIdentifier?: string;
}
export interface StopDBClusterResult {
    DBCluster?: DBCluster;
}
export interface SwitchoverGlobalClusterMessage {
    GlobalClusterIdentifier?: string;
    TargetDbClusterIdentifier?: string;
}
export interface SwitchoverGlobalClusterResult {
    GlobalCluster?: GlobalCluster;
}
export type ExceptionMessage = string;
export type AddSourceIdentifierToSubscriptionError = SourceNotFoundFault | SubscriptionNotFoundFault | CommonErrors;
/**
 * Adds a source identifier to an existing event notification
 * subscription.
 */
export declare const addSourceIdentifierToSubscription: API.OperationMethod<AddSourceIdentifierToSubscriptionMessage, AddSourceIdentifierToSubscriptionResult, AddSourceIdentifierToSubscriptionError, Credentials | HttpClient.HttpClient>;
export type AddTagsToResourceError = DBClusterNotFoundFault | DBInstanceNotFoundFault | DBSnapshotNotFoundFault | CommonErrors;
/**
 * Adds metadata tags to an Amazon DocumentDB resource. You can use these tags
 * with cost allocation reporting to track costs that are associated
 * with Amazon DocumentDB resources or in a `Condition` statement in
 * an Identity and Access Management (IAM) policy for Amazon DocumentDB.
 */
export declare const addTagsToResource: API.OperationMethod<AddTagsToResourceMessage, AddTagsToResourceResponse, AddTagsToResourceError, Credentials | HttpClient.HttpClient>;
export type ApplyPendingMaintenanceActionError = InvalidDBClusterStateFault | InvalidDBInstanceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Applies a pending maintenance action to a resource (for example,
 * to an Amazon DocumentDB instance).
 */
export declare const applyPendingMaintenanceAction: API.OperationMethod<ApplyPendingMaintenanceActionMessage, ApplyPendingMaintenanceActionResult, ApplyPendingMaintenanceActionError, Credentials | HttpClient.HttpClient>;
export type CopyDBClusterParameterGroupError = DBParameterGroupAlreadyExistsFault | DBParameterGroupNotFoundFault | DBParameterGroupQuotaExceededFault | CommonErrors;
/**
 * Copies the specified cluster parameter group.
 */
export declare const copyDBClusterParameterGroup: API.OperationMethod<CopyDBClusterParameterGroupMessage, CopyDBClusterParameterGroupResult, CopyDBClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type CopyDBClusterSnapshotError = DBClusterSnapshotAlreadyExistsFault | DBClusterSnapshotNotFoundFault | InvalidDBClusterSnapshotStateFault | InvalidDBClusterStateFault | KMSKeyNotAccessibleFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Copies a snapshot of a cluster.
 *
 * To copy a cluster snapshot from a shared manual cluster snapshot,
 * `SourceDBClusterSnapshotIdentifier` must be the Amazon
 * Resource Name (ARN) of the shared cluster snapshot. You can only
 * copy a shared DB cluster snapshot, whether encrypted or not, in the
 * same Amazon Web Services Region.
 *
 * To cancel the copy operation after it is in progress, delete the
 * target cluster snapshot identified by
 * `TargetDBClusterSnapshotIdentifier` while that cluster
 * snapshot is in the *copying* status.
 */
export declare const copyDBClusterSnapshot: API.OperationMethod<CopyDBClusterSnapshotMessage, CopyDBClusterSnapshotResult, CopyDBClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateDBClusterError = DBClusterAlreadyExistsFault | DBClusterNotFoundFault | DBClusterParameterGroupNotFoundFault | DBClusterQuotaExceededFault | DBInstanceNotFoundFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | GlobalClusterNotFoundFault | InsufficientStorageClusterCapacityFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidDBSubnetGroupStateFault | InvalidGlobalClusterStateFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | StorageQuotaExceededFault | CommonErrors;
/**
 * Creates a new Amazon DocumentDB cluster.
 */
export declare const createDBCluster: API.OperationMethod<CreateDBClusterMessage, CreateDBClusterResult, CreateDBClusterError, Credentials | HttpClient.HttpClient>;
export type CreateDBClusterParameterGroupError = DBParameterGroupAlreadyExistsFault | DBParameterGroupQuotaExceededFault | CommonErrors;
/**
 * Creates a new cluster parameter group.
 *
 * Parameters in a cluster parameter group apply to all of the
 * instances in a cluster.
 *
 * A cluster parameter group is initially created with the default
 * parameters for the database engine used by instances in the cluster.
 * In Amazon DocumentDB, you cannot make modifications directly to the
 * `default.docdb3.6` cluster parameter group. If your
 * Amazon DocumentDB cluster is using the default cluster parameter group and you
 * want to modify a value in it, you must first
 * create a new parameter group
 * or
 * copy an existing parameter group,
 * modify it, and then apply the modified parameter group to your
 * cluster. For the new cluster parameter group and associated settings
 * to take effect, you must then reboot the instances in the cluster
 * without failover. For more information,
 * see
 * Modifying Amazon DocumentDB Cluster Parameter Groups.
 */
export declare const createDBClusterParameterGroup: API.OperationMethod<CreateDBClusterParameterGroupMessage, CreateDBClusterParameterGroupResult, CreateDBClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type CreateDBClusterSnapshotError = DBClusterNotFoundFault | DBClusterSnapshotAlreadyExistsFault | InvalidDBClusterSnapshotStateFault | InvalidDBClusterStateFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Creates a snapshot of a cluster.
 */
export declare const createDBClusterSnapshot: API.OperationMethod<CreateDBClusterSnapshotMessage, CreateDBClusterSnapshotResult, CreateDBClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateDBInstanceError = AuthorizationNotFoundFault | DBClusterNotFoundFault | DBInstanceAlreadyExistsFault | DBParameterGroupNotFoundFault | DBSecurityGroupNotFoundFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | InstanceQuotaExceededFault | InsufficientDBInstanceCapacityFault | InvalidDBClusterStateFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | CommonErrors;
/**
 * Creates a new instance.
 */
export declare const createDBInstance: API.OperationMethod<CreateDBInstanceMessage, CreateDBInstanceResult, CreateDBInstanceError, Credentials | HttpClient.HttpClient>;
export type CreateDBSubnetGroupError = DBSubnetGroupAlreadyExistsFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupQuotaExceededFault | DBSubnetQuotaExceededFault | InvalidSubnet | CommonErrors;
/**
 * Creates a new subnet group. subnet groups must contain at least one subnet in at
 * least two Availability Zones in the Amazon Web Services Region.
 */
export declare const createDBSubnetGroup: API.OperationMethod<CreateDBSubnetGroupMessage, CreateDBSubnetGroupResult, CreateDBSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type CreateEventSubscriptionError = EventSubscriptionQuotaExceededFault | SNSInvalidTopicFault | SNSNoAuthorizationFault | SNSTopicArnNotFoundFault | SourceNotFoundFault | SubscriptionAlreadyExistFault | SubscriptionCategoryNotFoundFault | CommonErrors;
/**
 * Creates an Amazon DocumentDB event notification subscription. This action requires a topic Amazon Resource Name (ARN) created by using the Amazon DocumentDB console, the Amazon SNS console, or the Amazon SNS API. To obtain an ARN with Amazon SNS, you must create a topic in Amazon SNS and subscribe to the topic. The ARN is displayed in the Amazon SNS console.
 *
 * You can specify the type of source (`SourceType`) that you want to be notified of. You can also provide a list of Amazon DocumentDB sources (`SourceIds`) that trigger the events, and you can provide a list of event categories (`EventCategories`) for events that you want to be notified of. For example, you can specify `SourceType = db-instance`, `SourceIds = mydbinstance1, mydbinstance2` and `EventCategories = Availability, Backup`.
 *
 * If you specify both the `SourceType` and `SourceIds` (such as `SourceType = db-instance` and `SourceIdentifier = myDBInstance1`), you are notified of all the `db-instance` events for the specified source. If you specify a `SourceType` but do not specify a `SourceIdentifier`, you receive notice of the events for that source type for all your Amazon DocumentDB sources. If you do not specify either the `SourceType` or the `SourceIdentifier`, you are notified of events generated from all Amazon DocumentDB sources belonging to your customer account.
 */
export declare const createEventSubscription: API.OperationMethod<CreateEventSubscriptionMessage, CreateEventSubscriptionResult, CreateEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateGlobalClusterError = DBClusterNotFoundFault | GlobalClusterAlreadyExistsFault | GlobalClusterQuotaExceededFault | InvalidDBClusterStateFault | CommonErrors;
/**
 * Creates an Amazon DocumentDB global cluster that can span multiple multiple Amazon Web Services Regions.
 * The global cluster contains one primary cluster with read-write capability, and up-to 10 read-only secondary clusters. Global clusters uses storage-based fast replication across regions with latencies less than one second, using dedicated infrastructure with no impact to your workload's performance.
 *
 * You can create a global cluster that is initially empty, and then add a primary and a secondary to it.
 * Or you can specify an existing cluster during the create operation, and this cluster becomes the primary of the global cluster.
 *
 * This action only applies to Amazon DocumentDB clusters.
 */
export declare const createGlobalCluster: API.OperationMethod<CreateGlobalClusterMessage, CreateGlobalClusterResult, CreateGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteDBClusterError = DBClusterNotFoundFault | DBClusterSnapshotAlreadyExistsFault | InvalidDBClusterSnapshotStateFault | InvalidDBClusterStateFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Deletes a previously provisioned cluster. When you delete a cluster, all automated backups for that cluster are deleted and can't be recovered. Manual DB cluster snapshots of the specified cluster are not deleted.
 */
export declare const deleteDBCluster: API.OperationMethod<DeleteDBClusterMessage, DeleteDBClusterResult, DeleteDBClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteDBClusterParameterGroupError = DBParameterGroupNotFoundFault | InvalidDBParameterGroupStateFault | CommonErrors;
/**
 * Deletes a specified cluster parameter group. The cluster parameter group to be deleted can't be associated with any clusters.
 */
export declare const deleteDBClusterParameterGroup: API.OperationMethod<DeleteDBClusterParameterGroupMessage, DeleteDBClusterParameterGroupResponse, DeleteDBClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteDBClusterSnapshotError = DBClusterSnapshotNotFoundFault | InvalidDBClusterSnapshotStateFault | CommonErrors;
/**
 * Deletes a cluster snapshot. If the snapshot is being copied, the copy operation is terminated.
 *
 * The cluster snapshot must be in the `available` state to be deleted.
 */
export declare const deleteDBClusterSnapshot: API.OperationMethod<DeleteDBClusterSnapshotMessage, DeleteDBClusterSnapshotResult, DeleteDBClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteDBInstanceError = DBInstanceNotFoundFault | DBSnapshotAlreadyExistsFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Deletes a previously provisioned instance.
 */
export declare const deleteDBInstance: API.OperationMethod<DeleteDBInstanceMessage, DeleteDBInstanceResult, DeleteDBInstanceError, Credentials | HttpClient.HttpClient>;
export type DeleteDBSubnetGroupError = DBSubnetGroupNotFoundFault | InvalidDBSubnetGroupStateFault | InvalidDBSubnetStateFault | CommonErrors;
/**
 * Deletes a subnet group.
 *
 * The specified database subnet group must not be associated with any DB
 * instances.
 */
export declare const deleteDBSubnetGroup: API.OperationMethod<DeleteDBSubnetGroupMessage, DeleteDBSubnetGroupResponse, DeleteDBSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteEventSubscriptionError = InvalidEventSubscriptionStateFault | SubscriptionNotFoundFault | CommonErrors;
/**
 * Deletes an Amazon DocumentDB event notification subscription.
 */
export declare const deleteEventSubscription: API.OperationMethod<DeleteEventSubscriptionMessage, DeleteEventSubscriptionResult, DeleteEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteGlobalClusterError = GlobalClusterNotFoundFault | InvalidGlobalClusterStateFault | CommonErrors;
/**
 * Deletes a global cluster. The primary and secondary clusters must already be detached or deleted before attempting to delete a global cluster.
 *
 * This action only applies to Amazon DocumentDB clusters.
 */
export declare const deleteGlobalCluster: API.OperationMethod<DeleteGlobalClusterMessage, DeleteGlobalClusterResult, DeleteGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type DescribeCertificatesError = CertificateNotFoundFault | CommonErrors;
/**
 * Returns a list of certificate authority (CA) certificates provided by Amazon DocumentDB for this Amazon Web Services account.
 */
export declare const describeCertificates: API.PaginatedOperationMethod<DescribeCertificatesMessage, CertificateMessage, DescribeCertificatesError, Credentials | HttpClient.HttpClient, Certificate>;
export type DescribeDBClusterParameterGroupsError = DBParameterGroupNotFoundFault | CommonErrors;
/**
 * Returns a list of `DBClusterParameterGroup` descriptions. If a `DBClusterParameterGroupName` parameter is specified, the list contains only the description of the specified cluster parameter group.
 */
export declare const describeDBClusterParameterGroups: API.PaginatedOperationMethod<DescribeDBClusterParameterGroupsMessage, DBClusterParameterGroupsMessage, DescribeDBClusterParameterGroupsError, Credentials | HttpClient.HttpClient, DBClusterParameterGroup>;
export type DescribeDBClusterParametersError = DBParameterGroupNotFoundFault | CommonErrors;
/**
 * Returns the detailed parameter list for a particular cluster parameter
 * group.
 */
export declare const describeDBClusterParameters: API.PaginatedOperationMethod<DescribeDBClusterParametersMessage, DBClusterParameterGroupDetails, DescribeDBClusterParametersError, Credentials | HttpClient.HttpClient, Parameter>;
export type DescribeDBClustersError = DBClusterNotFoundFault | CommonErrors;
/**
 * Returns information about provisioned Amazon DocumentDB clusters. This API
 * operation supports pagination. For certain management features
 * such as cluster and instance lifecycle management, Amazon DocumentDB leverages
 * operational technology that is shared with Amazon RDS and Amazon
 * Neptune. Use the `filterName=engine,Values=docdb` filter
 * parameter to return only Amazon DocumentDB clusters.
 */
export declare const describeDBClusters: API.PaginatedOperationMethod<DescribeDBClustersMessage, DBClusterMessage, DescribeDBClustersError, Credentials | HttpClient.HttpClient, DBCluster>;
export type DescribeDBClusterSnapshotAttributesError = DBClusterSnapshotNotFoundFault | CommonErrors;
/**
 * Returns a list of cluster snapshot attribute names and values for a manual DB
 * cluster snapshot.
 *
 * When you share snapshots with other Amazon Web Services accounts,
 * `DescribeDBClusterSnapshotAttributes` returns the `restore` attribute and a list of IDs for the Amazon Web Services accounts that are authorized to copy or restore the manual cluster snapshot. If `all` is included in the list of values for the `restore` attribute, then the manual cluster snapshot is public and can be copied or restored by all Amazon Web Services accounts.
 */
export declare const describeDBClusterSnapshotAttributes: API.OperationMethod<DescribeDBClusterSnapshotAttributesMessage, DescribeDBClusterSnapshotAttributesResult, DescribeDBClusterSnapshotAttributesError, Credentials | HttpClient.HttpClient>;
export type DescribeDBClusterSnapshotsError = DBClusterSnapshotNotFoundFault | CommonErrors;
/**
 * Returns information about cluster snapshots. This API operation supports pagination.
 */
export declare const describeDBClusterSnapshots: API.PaginatedOperationMethod<DescribeDBClusterSnapshotsMessage, DBClusterSnapshotMessage, DescribeDBClusterSnapshotsError, Credentials | HttpClient.HttpClient, DBClusterSnapshot>;
export type DescribeDBEngineVersionsError = CommonErrors;
/**
 * Returns a list of the available engines.
 */
export declare const describeDBEngineVersions: API.PaginatedOperationMethod<DescribeDBEngineVersionsMessage, DBEngineVersionMessage, DescribeDBEngineVersionsError, Credentials | HttpClient.HttpClient, DBEngineVersion>;
export type DescribeDBInstancesError = DBInstanceNotFoundFault | CommonErrors;
/**
 * Returns information about provisioned Amazon DocumentDB instances. This API supports pagination.
 */
export declare const describeDBInstances: API.PaginatedOperationMethod<DescribeDBInstancesMessage, DBInstanceMessage, DescribeDBInstancesError, Credentials | HttpClient.HttpClient, DBInstance>;
export type DescribeDBSubnetGroupsError = DBSubnetGroupNotFoundFault | CommonErrors;
/**
 * Returns a list of `DBSubnetGroup` descriptions. If a
 * `DBSubnetGroupName` is specified, the list will contain only the descriptions of the specified `DBSubnetGroup`.
 */
export declare const describeDBSubnetGroups: API.PaginatedOperationMethod<DescribeDBSubnetGroupsMessage, DBSubnetGroupMessage, DescribeDBSubnetGroupsError, Credentials | HttpClient.HttpClient, DBSubnetGroup>;
export type DescribeEngineDefaultClusterParametersError = CommonErrors;
/**
 * Returns the default engine and system parameter information for the cluster database
 * engine.
 */
export declare const describeEngineDefaultClusterParameters: API.OperationMethod<DescribeEngineDefaultClusterParametersMessage, DescribeEngineDefaultClusterParametersResult, DescribeEngineDefaultClusterParametersError, Credentials | HttpClient.HttpClient>;
export type DescribeEventCategoriesError = CommonErrors;
/**
 * Displays a list of categories for all event source types, or, if specified, for a
 * specified source type.
 */
export declare const describeEventCategories: API.OperationMethod<DescribeEventCategoriesMessage, EventCategoriesMessage, DescribeEventCategoriesError, Credentials | HttpClient.HttpClient>;
export type DescribeEventsError = CommonErrors;
/**
 * Returns events related to instances, security groups, snapshots, and DB parameter groups for the past 14 days. You can obtain events specific to a particular DB instance, security group, snapshot, or parameter group by providing the name as a parameter. By default, the events of the past hour are returned.
 */
export declare const describeEvents: API.PaginatedOperationMethod<DescribeEventsMessage, EventsMessage, DescribeEventsError, Credentials | HttpClient.HttpClient, Event>;
export type DescribeEventSubscriptionsError = SubscriptionNotFoundFault | CommonErrors;
/**
 * Lists all the subscription descriptions for a customer account. The description for a subscription includes `SubscriptionName`, `SNSTopicARN`, `CustomerID`, `SourceType`, `SourceID`, `CreationTime`, and `Status`.
 *
 * If you specify a `SubscriptionName`, lists the description for that subscription.
 */
export declare const describeEventSubscriptions: API.PaginatedOperationMethod<DescribeEventSubscriptionsMessage, EventSubscriptionsMessage, DescribeEventSubscriptionsError, Credentials | HttpClient.HttpClient, EventSubscription>;
export type DescribeGlobalClustersError = GlobalClusterNotFoundFault | CommonErrors;
/**
 * Returns information about Amazon DocumentDB global clusters. This API supports pagination.
 *
 * This action only applies to Amazon DocumentDB clusters.
 */
export declare const describeGlobalClusters: API.PaginatedOperationMethod<DescribeGlobalClustersMessage, GlobalClustersMessage, DescribeGlobalClustersError, Credentials | HttpClient.HttpClient, GlobalCluster>;
export type DescribeOrderableDBInstanceOptionsError = CommonErrors;
/**
 * Returns a list of orderable instance options for the specified engine.
 */
export declare const describeOrderableDBInstanceOptions: API.PaginatedOperationMethod<DescribeOrderableDBInstanceOptionsMessage, OrderableDBInstanceOptionsMessage, DescribeOrderableDBInstanceOptionsError, Credentials | HttpClient.HttpClient, OrderableDBInstanceOption>;
export type DescribePendingMaintenanceActionsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns a list of resources (for example, instances) that have at least one pending
 * maintenance action.
 */
export declare const describePendingMaintenanceActions: API.PaginatedOperationMethod<DescribePendingMaintenanceActionsMessage, PendingMaintenanceActionsMessage, DescribePendingMaintenanceActionsError, Credentials | HttpClient.HttpClient, ResourcePendingMaintenanceActions>;
export type FailoverDBClusterError = DBClusterNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Forces a failover for a cluster.
 *
 * A failover for a cluster promotes one of the Amazon DocumentDB replicas (read-only instances) in the cluster to be the primary instance (the cluster writer).
 *
 * If the primary instance fails, Amazon DocumentDB automatically fails over to an Amazon DocumentDB replica, if one exists. You can force a failover when you want to simulate a failure of a primary instance for testing.
 */
export declare const failoverDBCluster: API.OperationMethod<FailoverDBClusterMessage, FailoverDBClusterResult, FailoverDBClusterError, Credentials | HttpClient.HttpClient>;
export type FailoverGlobalClusterError = DBClusterNotFoundFault | GlobalClusterNotFoundFault | InvalidDBClusterStateFault | InvalidGlobalClusterStateFault | CommonErrors;
/**
 * Promotes the specified secondary DB cluster to be the primary DB cluster in the global cluster when failing over a global cluster occurs.
 *
 * Use this operation to respond to an unplanned event, such as a regional disaster in the primary region.
 * Failing over can result in a loss of write transaction data that wasn't replicated to the chosen secondary before the failover event occurred.
 * However, the recovery process that promotes a DB instance on the chosen seconday DB cluster to be the primary writer DB instance guarantees that the data is in a transactionally consistent state.
 */
export declare const failoverGlobalCluster: API.OperationMethod<FailoverGlobalClusterMessage, FailoverGlobalClusterResult, FailoverGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = DBClusterNotFoundFault | DBInstanceNotFoundFault | DBSnapshotNotFoundFault | CommonErrors;
/**
 * Lists all tags on an Amazon DocumentDB resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceMessage, TagListMessage, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ModifyDBClusterError = DBClusterAlreadyExistsFault | DBClusterNotFoundFault | DBClusterParameterGroupNotFoundFault | DBSubnetGroupNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidDBSecurityGroupStateFault | InvalidDBSubnetGroupStateFault | InvalidSubnet | InvalidVPCNetworkStateFault | NetworkTypeNotSupported | StorageQuotaExceededFault | CommonErrors;
/**
 * Modifies a setting for an Amazon DocumentDB cluster. You can change one or more database
 * configuration parameters by specifying these parameters and the new values in the
 * request.
 */
export declare const modifyDBCluster: API.OperationMethod<ModifyDBClusterMessage, ModifyDBClusterResult, ModifyDBClusterError, Credentials | HttpClient.HttpClient>;
export type ModifyDBClusterParameterGroupError = DBParameterGroupNotFoundFault | InvalidDBParameterGroupStateFault | CommonErrors;
/**
 * Modifies the parameters of a cluster parameter group. To modify more than one
 * parameter, submit a list of the following: `ParameterName`,
 * `ParameterValue`, and `ApplyMethod`. A maximum of 20
 * parameters can be modified in a single request.
 *
 * Changes to dynamic parameters are applied immediately. Changes to static
 * parameters require a reboot or maintenance window
 *
 * before the change can take effect.
 *
 * After you create a cluster parameter group, you should wait at least 5 minutes
 * before creating your first cluster that uses that cluster parameter group as
 * the default parameter group. This allows Amazon DocumentDB to fully complete the create action
 * before the parameter group is used as the default for a new cluster. This step is
 * especially important for parameters that are critical when creating the default
 * database for a cluster, such as the character set for the default database
 * defined by the `character_set_database` parameter.
 */
export declare const modifyDBClusterParameterGroup: API.OperationMethod<ModifyDBClusterParameterGroupMessage, DBClusterParameterGroupNameMessage, ModifyDBClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyDBClusterSnapshotAttributeError = DBClusterSnapshotNotFoundFault | InvalidDBClusterSnapshotStateFault | SharedSnapshotQuotaExceededFault | CommonErrors;
/**
 * Adds an attribute and values to, or removes an attribute and values from, a manual cluster snapshot.
 *
 * To share a manual cluster snapshot with other Amazon Web Services accounts, specify `restore` as the `AttributeName`, and use the `ValuesToAdd` parameter to add a list of IDs of the Amazon Web Services accounts that are authorized to restore the manual cluster snapshot. Use the value `all` to make the manual cluster snapshot public, which means that it can be copied or restored by all Amazon Web Services accounts. Do not add the `all` value for any manual cluster snapshots that contain private information that you don't want available to all Amazon Web Services accounts. If a manual cluster snapshot is encrypted, it can be shared, but only by specifying a list of authorized Amazon Web Services account IDs for the `ValuesToAdd` parameter. You can't use `all` as a value for that parameter in this case.
 */
export declare const modifyDBClusterSnapshotAttribute: API.OperationMethod<ModifyDBClusterSnapshotAttributeMessage, ModifyDBClusterSnapshotAttributeResult, ModifyDBClusterSnapshotAttributeError, Credentials | HttpClient.HttpClient>;
export type ModifyDBInstanceError = AuthorizationNotFoundFault | CertificateNotFoundFault | DBInstanceAlreadyExistsFault | DBInstanceNotFoundFault | DBParameterGroupNotFoundFault | DBSecurityGroupNotFoundFault | DBUpgradeDependencyFailureFault | InsufficientDBInstanceCapacityFault | InvalidDBInstanceStateFault | InvalidDBSecurityGroupStateFault | InvalidVPCNetworkStateFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | CommonErrors;
/**
 * Modifies settings for an instance. You can change one or more database configuration parameters by specifying these parameters and the new values in the request.
 */
export declare const modifyDBInstance: API.OperationMethod<ModifyDBInstanceMessage, ModifyDBInstanceResult, ModifyDBInstanceError, Credentials | HttpClient.HttpClient>;
export type ModifyDBSubnetGroupError = DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | DBSubnetQuotaExceededFault | InvalidSubnet | SubnetAlreadyInUse | CommonErrors;
/**
 * Modifies an existing subnet group. subnet groups must contain at least one subnet in at least two Availability Zones in the Amazon Web Services Region.
 */
export declare const modifyDBSubnetGroup: API.OperationMethod<ModifyDBSubnetGroupMessage, ModifyDBSubnetGroupResult, ModifyDBSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyEventSubscriptionError = EventSubscriptionQuotaExceededFault | SNSInvalidTopicFault | SNSNoAuthorizationFault | SNSTopicArnNotFoundFault | SubscriptionCategoryNotFoundFault | SubscriptionNotFoundFault | CommonErrors;
/**
 * Modifies an existing Amazon DocumentDB event notification subscription.
 */
export declare const modifyEventSubscription: API.OperationMethod<ModifyEventSubscriptionMessage, ModifyEventSubscriptionResult, ModifyEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type ModifyGlobalClusterError = GlobalClusterNotFoundFault | InvalidGlobalClusterStateFault | CommonErrors;
/**
 * Modify a setting for an Amazon DocumentDB global cluster. You can change one or more configuration parameters (for example: deletion protection), or the global cluster identifier by specifying these parameters and the new values in the request.
 *
 * This action only applies to Amazon DocumentDB clusters.
 */
export declare const modifyGlobalCluster: API.OperationMethod<ModifyGlobalClusterMessage, ModifyGlobalClusterResult, ModifyGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type RebootDBInstanceError = DBInstanceNotFoundFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * You might need to reboot your instance, usually for maintenance reasons. For
 * example, if you make certain changes, or if you change the cluster parameter group
 * that is associated with the instance, you must reboot the instance for the changes to
 * take effect.
 *
 * Rebooting an instance restarts the database engine service. Rebooting an instance
 * results in a momentary outage, during which the instance status is set to
 * *rebooting*.
 */
export declare const rebootDBInstance: API.OperationMethod<RebootDBInstanceMessage, RebootDBInstanceResult, RebootDBInstanceError, Credentials | HttpClient.HttpClient>;
export type RemoveFromGlobalClusterError = DBClusterNotFoundFault | GlobalClusterNotFoundFault | InvalidGlobalClusterStateFault | CommonErrors;
/**
 * Detaches an Amazon DocumentDB secondary cluster from a global cluster. The cluster becomes a standalone cluster with read-write capability instead of being read-only and receiving data from a primary in a different region.
 *
 * This action only applies to Amazon DocumentDB clusters.
 */
export declare const removeFromGlobalCluster: API.OperationMethod<RemoveFromGlobalClusterMessage, RemoveFromGlobalClusterResult, RemoveFromGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type RemoveSourceIdentifierFromSubscriptionError = SourceNotFoundFault | SubscriptionNotFoundFault | CommonErrors;
/**
 * Removes a source identifier from an existing Amazon DocumentDB event notification
 * subscription.
 */
export declare const removeSourceIdentifierFromSubscription: API.OperationMethod<RemoveSourceIdentifierFromSubscriptionMessage, RemoveSourceIdentifierFromSubscriptionResult, RemoveSourceIdentifierFromSubscriptionError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsFromResourceError = DBClusterNotFoundFault | DBInstanceNotFoundFault | DBSnapshotNotFoundFault | CommonErrors;
/**
 * Removes metadata tags from an Amazon DocumentDB resource.
 */
export declare const removeTagsFromResource: API.OperationMethod<RemoveTagsFromResourceMessage, RemoveTagsFromResourceResponse, RemoveTagsFromResourceError, Credentials | HttpClient.HttpClient>;
export type ResetDBClusterParameterGroupError = DBParameterGroupNotFoundFault | InvalidDBParameterGroupStateFault | CommonErrors;
/**
 * Modifies the parameters of a cluster parameter group to the default value. To
 * reset specific parameters, submit a list of the following: `ParameterName`
 * and `ApplyMethod`. To reset the entire cluster parameter group, specify
 * the `DBClusterParameterGroupName` and `ResetAllParameters`
 * parameters.
 *
 * When you reset the entire group, dynamic parameters are updated immediately and
 * static parameters are set to `pending-reboot` to take effect on the next DB
 * instance reboot.
 */
export declare const resetDBClusterParameterGroup: API.OperationMethod<ResetDBClusterParameterGroupMessage, DBClusterParameterGroupNameMessage, ResetDBClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type RestoreDBClusterFromSnapshotError = DBClusterAlreadyExistsFault | DBClusterQuotaExceededFault | DBClusterSnapshotNotFoundFault | DBSnapshotNotFoundFault | DBSubnetGroupNotFoundFault | InsufficientDBClusterCapacityFault | InsufficientStorageClusterCapacityFault | InvalidDBClusterSnapshotStateFault | InvalidDBSnapshotStateFault | InvalidRestoreFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | StorageQuotaExceededFault | CommonErrors;
/**
 * Creates a new cluster from a snapshot or cluster snapshot.
 *
 * If a snapshot is specified, the target cluster is created from the source DB snapshot with a default configuration and default security group.
 *
 * If a cluster snapshot is specified, the target cluster is created from the source cluster restore point with the same configuration as the original source DB cluster, except that the new cluster is created with the default security group.
 */
export declare const restoreDBClusterFromSnapshot: API.OperationMethod<RestoreDBClusterFromSnapshotMessage, RestoreDBClusterFromSnapshotResult, RestoreDBClusterFromSnapshotError, Credentials | HttpClient.HttpClient>;
export type RestoreDBClusterToPointInTimeError = DBClusterAlreadyExistsFault | DBClusterNotFoundFault | DBClusterQuotaExceededFault | DBClusterSnapshotNotFoundFault | DBSubnetGroupNotFoundFault | InsufficientDBClusterCapacityFault | InsufficientStorageClusterCapacityFault | InvalidDBClusterSnapshotStateFault | InvalidDBClusterStateFault | InvalidDBSnapshotStateFault | InvalidRestoreFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | StorageQuotaExceededFault | CommonErrors;
/**
 * Restores a cluster to an arbitrary point in time. Users can restore to any point in
 * time before `LatestRestorableTime` for up to
 * `BackupRetentionPeriod` days. The target cluster is created from the
 * source cluster with the same configuration as the original cluster, except that
 * the new cluster is created with the default security group.
 */
export declare const restoreDBClusterToPointInTime: API.OperationMethod<RestoreDBClusterToPointInTimeMessage, RestoreDBClusterToPointInTimeResult, RestoreDBClusterToPointInTimeError, Credentials | HttpClient.HttpClient>;
export type StartDBClusterError = DBClusterNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Restarts the stopped cluster that is specified by `DBClusterIdentifier`.
 * For more information, see Stopping and
 * Starting an Amazon DocumentDB Cluster.
 */
export declare const startDBCluster: API.OperationMethod<StartDBClusterMessage, StartDBClusterResult, StartDBClusterError, Credentials | HttpClient.HttpClient>;
export type StopDBClusterError = DBClusterNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Stops the running cluster that is specified by `DBClusterIdentifier`. The
 * cluster must be in the *available* state. For more information, see
 * Stopping and
 * Starting an Amazon DocumentDB Cluster.
 */
export declare const stopDBCluster: API.OperationMethod<StopDBClusterMessage, StopDBClusterResult, StopDBClusterError, Credentials | HttpClient.HttpClient>;
export type SwitchoverGlobalClusterError = DBClusterNotFoundFault | GlobalClusterNotFoundFault | InvalidDBClusterStateFault | InvalidGlobalClusterStateFault | CommonErrors;
/**
 * Switches over the specified secondary Amazon DocumentDB cluster to be the new primary Amazon DocumentDB cluster in the global database cluster.
 */
export declare const switchoverGlobalCluster: API.OperationMethod<SwitchoverGlobalClusterMessage, SwitchoverGlobalClusterResult, SwitchoverGlobalClusterError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=docdb.d.ts.map