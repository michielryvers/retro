import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedByMetaException_base: S.TaggedErrorClass<"AccessDeniedByMetaException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedByMetaException extends /*@__PURE__*/ AccessDeniedByMetaException_base {
}
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DependencyException_base: S.TaggedErrorClass<"DependencyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class DependencyException extends /*@__PURE__*/ DependencyException_base {
}
declare const InternalServiceException_base: S.TaggedErrorClass<"InternalServiceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServiceException extends /*@__PURE__*/ InternalServiceException_base {
}
declare const InvalidParametersException_base: S.TaggedErrorClass<"InvalidParametersException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParametersException extends /*@__PURE__*/ InvalidParametersException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottledRequestException_base: S.TaggedErrorClass<"ThrottledRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottledRequestException extends /*@__PURE__*/ ThrottledRequestException_base {
}
export interface WhatsAppSignupCallback {
    accessToken: string | redacted.Redacted<string>;
    callbackUrl?: string;
}
export type AssociateInProgressToken = string | redacted.Redacted<string>;
export type WhatsAppPhoneNumber = string;
export type TwoFactorPin = string | redacted.Redacted<string>;
export type IsoCountryCode = string;
export interface Tag {
    key: string;
    value?: string;
}
export type TagList = Tag[];
export interface WabaPhoneNumberSetupFinalization {
    id: string;
    twoFactorPin: string | redacted.Redacted<string>;
    dataLocalizationRegion?: string;
    tags?: Tag[];
}
export type WabaPhoneNumberSetupFinalizationList = WabaPhoneNumberSetupFinalization[];
export type LinkedWhatsAppBusinessAccountId = string;
export type WhatsAppBusinessAccountId = string;
export type EventDestinationArn = string;
export type RoleArn = string;
export interface WhatsAppBusinessAccountEventDestination {
    eventDestinationArn: string;
    roleArn?: string;
}
export type WhatsAppBusinessAccountEventDestinations = WhatsAppBusinessAccountEventDestination[];
export interface WabaSetupFinalization {
    id?: string;
    eventDestinations?: WhatsAppBusinessAccountEventDestination[];
    tags?: Tag[];
}
export interface WhatsAppSetupFinalization {
    associateInProgressToken: string | redacted.Redacted<string>;
    phoneNumbers: WabaPhoneNumberSetupFinalization[];
    phoneNumberParent?: string;
    waba?: WabaSetupFinalization;
}
export interface AssociateWhatsAppBusinessAccountInput {
    signupCallback?: WhatsAppSignupCallback;
    setupFinalization?: WhatsAppSetupFinalization;
}
export type WhatsAppBusinessAccountName = string;
export type RegistrationStatus = "COMPLETE" | "INCOMPLETE" | (string & {});
export type LinkedWhatsAppPhoneNumberArn = string;
export type PhoneNumber = string;
export type WhatsAppPhoneNumberId = string;
export type WhatsAppPhoneNumberName = string;
export type WhatsAppDisplayPhoneNumber = string;
export type WhatsAppPhoneNumberQualityRating = string;
export interface WhatsAppPhoneNumberDetail {
    arn: string;
    phoneNumber: string;
    phoneNumberId: string;
    metaPhoneNumberId: string;
    displayPhoneNumberName: string;
    displayPhoneNumber: string;
    qualityRating: string;
    dataLocalizationRegion?: string;
}
export type WhatsAppPhoneNumberDetailList = WhatsAppPhoneNumberDetail[];
export interface LinkedWhatsAppBusinessAccountIdMetaData {
    accountName?: string;
    registrationStatus?: RegistrationStatus;
    unregisteredWhatsAppPhoneNumbers?: WhatsAppPhoneNumberDetail[];
    wabaId?: string;
}
export type LinkedAccountWithIncompleteSetup = {
    [key: string]: LinkedWhatsAppBusinessAccountIdMetaData | undefined;
};
export interface WhatsAppSignupCallbackResult {
    associateInProgressToken?: string | redacted.Redacted<string>;
    linkedAccountsWithIncompleteSetup?: {
        [key: string]: LinkedWhatsAppBusinessAccountIdMetaData | undefined;
    };
}
export interface AssociateWhatsAppBusinessAccountOutput {
    signupCallbackResult?: WhatsAppSignupCallbackResult;
    statusCode?: number;
    linkedWhatsAppBusinessAccountId?: string;
}
export interface CreateWhatsAppDatasetInput {
    id: string;
}
export type WhatsAppDatasetId = string;
export interface CreateWhatsAppDatasetOutput {
    datasetId: string;
}
export type MetaFlowName = string;
export type MetaFlowCategory = "SIGN_UP" | "SIGN_IN" | "APPOINTMENT_BOOKING" | "LEAD_GENERATION" | "SHOPPING" | "CONTACT_US" | "CUSTOMER_SUPPORT" | "SURVEY" | "OTHER" | (string & {});
export type MetaFlowCategoryList = MetaFlowCategory[];
export type MetaFlowJsonBlob = Uint8Array;
export type MetaFlowId = string;
export type MetaFlowEndpointUri = string;
export interface CreateWhatsAppFlowInput {
    id: string;
    flowName: string;
    categories: MetaFlowCategory[];
    flowJson?: Uint8Array;
    publish?: boolean;
    cloneFlowId?: string;
    endpointUri?: string;
}
export type MetaFlowValidationError = string;
export type ValidationErrorList = string[];
export interface CreateWhatsAppFlowOutput {
    flowId?: string;
    validationErrors?: string[];
}
export type MetaTemplateDefinition = Uint8Array;
export interface CreateWhatsAppMessageTemplateInput {
    templateDefinition: Uint8Array;
    id: string;
}
export type MetaTemplateId = string;
export type MetaTemplateCategory = string;
export interface CreateWhatsAppMessageTemplateOutput {
    metaTemplateId?: string;
    templateStatus?: string;
    category?: string;
}
export type MetaTemplateName = string;
export type MetaTemplateLanguage = string;
export type ButtonType = string;
export type MetaUrlWithSuffixExample = {
    [key: string]: string | undefined;
};
export type OtpType = string;
export type ZeroTapTermsAccepted = boolean;
export type SupportedApp = {
    [key: string]: string | undefined;
};
export type SupportedApps = {
    [key: string]: string | undefined;
}[];
export interface LibraryTemplateButtonInput {
    type?: string;
    phoneNumber?: string;
    url?: {
        [key: string]: string | undefined;
    };
    otpType?: string;
    zeroTapTermsAccepted?: boolean;
    supportedApps?: {
        [key: string]: string | undefined;
    }[];
}
export type MetaLibraryTemplateButtonInputs = LibraryTemplateButtonInput[];
export type AddContactNumber = boolean;
export type AddLearnMoreLink = boolean;
export type AddSecurityRecommendation = boolean;
export type AddTrackPackageLink = boolean;
export type CodeExpirationMinutes = number;
export interface LibraryTemplateBodyInputs {
    addContactNumber?: boolean;
    addLearnMoreLink?: boolean;
    addSecurityRecommendation?: boolean;
    addTrackPackageLink?: boolean;
    codeExpirationMinutes?: number;
}
export interface MetaLibraryTemplate {
    templateName: string;
    libraryTemplateName: string;
    templateCategory: string;
    templateLanguage: string;
    libraryTemplateButtonInputs?: LibraryTemplateButtonInput[];
    libraryTemplateBodyInputs?: LibraryTemplateBodyInputs;
}
export interface CreateWhatsAppMessageTemplateFromLibraryInput {
    metaLibraryTemplate: MetaLibraryTemplate;
    id: string;
}
export interface CreateWhatsAppMessageTemplateFromLibraryOutput {
    metaTemplateId?: string;
    templateStatus?: string;
    category?: string;
}
export interface S3File {
    bucketName: string;
    key: string;
}
export interface CreateWhatsAppMessageTemplateMediaInput {
    id: string;
    sourceS3File?: S3File;
}
export interface CreateWhatsAppMessageTemplateMediaOutput {
    metaHeaderHandle?: string;
}
export interface DeleteWhatsAppFlowInput {
    id: string;
    flowId: string;
}
export interface DeleteWhatsAppFlowOutput {
}
export type WhatsAppMediaId = string;
export interface DeleteWhatsAppMessageMediaInput {
    mediaId: string;
    originationPhoneNumberId: string;
}
export interface DeleteWhatsAppMessageMediaOutput {
    success?: boolean;
}
export type DeleteAllLanguages = boolean;
export interface DeleteWhatsAppMessageTemplateInput {
    metaTemplateId?: string;
    deleteAllLanguages?: boolean;
    id: string;
    templateName: string;
}
export interface DeleteWhatsAppMessageTemplateOutput {
}
export interface DeprecateWhatsAppFlowInput {
    id: string;
    flowId: string;
}
export interface DeprecateWhatsAppFlowOutput {
}
export interface DisassociateWhatsAppBusinessAccountInput {
    id: string;
}
export interface DisassociateWhatsAppBusinessAccountOutput {
}
export interface GetLinkedWhatsAppBusinessAccountInput {
    id: string;
}
export type LinkedWhatsAppBusinessAccountArn = string;
export type WhatsAppBusinessAccountLinkDate = Date;
export type WhatsAppBusinessAccountMarketingMessagesOnboardingStatus = string;
export interface WhatsAppPhoneNumberSummary {
    arn: string;
    phoneNumber: string;
    phoneNumberId: string;
    metaPhoneNumberId: string;
    displayPhoneNumberName: string;
    displayPhoneNumber: string;
    qualityRating: string;
    dataLocalizationRegion?: string;
}
export type WhatsAppPhoneNumberSummaryList = WhatsAppPhoneNumberSummary[];
export interface LinkedWhatsAppBusinessAccount {
    arn: string;
    id: string;
    wabaId: string;
    registrationStatus: RegistrationStatus;
    linkDate: Date;
    wabaName: string;
    eventDestinations: WhatsAppBusinessAccountEventDestination[];
    marketingMessagesOnboardingStatus?: string;
    datasetId?: string;
    phoneNumbers: WhatsAppPhoneNumberSummary[];
}
export interface GetLinkedWhatsAppBusinessAccountOutput {
    account?: LinkedWhatsAppBusinessAccount;
}
export interface GetLinkedWhatsAppBusinessAccountPhoneNumberInput {
    id: string;
}
export type IanaTimezone = string;
export type WhatsAppDayOfWeek = "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | "SUNDAY" | (string & {});
export interface WhatsAppTimeOfDay {
    hours: number;
    minutes: number;
}
export interface WhatsAppWeeklyOperatingHoursEntry {
    dayOfWeek: WhatsAppDayOfWeek;
    openTime: WhatsAppTimeOfDay;
    closeTime: WhatsAppTimeOfDay;
}
export type WhatsAppWeeklyOperatingHoursList = WhatsAppWeeklyOperatingHoursEntry[];
export type WhatsAppDate = string;
export interface WhatsAppHolidayScheduleEntry {
    date: string;
    startTime: WhatsAppTimeOfDay;
    endTime: WhatsAppTimeOfDay;
}
export type WhatsAppHolidayScheduleList = WhatsAppHolidayScheduleEntry[];
export interface WhatsAppCallHours {
    enabled: boolean;
    timezone: string;
    weeklyOperatingHours: WhatsAppWeeklyOperatingHoursEntry[];
    holidaySchedule?: WhatsAppHolidayScheduleEntry[];
}
export type WhatsAppCallIconVisibility = string;
export type WhatsAppCallbackPermissionStatus = string;
export interface WhatsAppCallSettings {
    callEnabled: boolean;
    callHours?: WhatsAppCallHours;
    callIconVisibility?: string;
    callbackPermissionStatus?: string;
}
export interface GetLinkedWhatsAppBusinessAccountPhoneNumberOutput {
    phoneNumber?: WhatsAppPhoneNumberDetail;
    linkedWhatsAppBusinessAccountId?: string;
    callSettings?: WhatsAppCallSettings;
}
export interface GetWhatsAppBusinessPublicKeyInput {
    originationPhoneNumberId: string;
}
export type BusinessPublicKeyPem = string;
export type BusinessPublicKeySignatureStatus = string;
export interface GetWhatsAppBusinessPublicKeyOutput {
    businessPublicKey?: string;
    businessPublicKeySignatureStatus?: string;
}
export type WhatsAppDestinationPhoneNumber = string | redacted.Redacted<string>;
export type WhatsAppBusinessScopedUserId = string | redacted.Redacted<string>;
export interface GetWhatsAppCallPermissionInput {
    originationPhoneNumberId: string;
    destinationPhoneNumber?: string | redacted.Redacted<string>;
    endUserBsuid?: string | redacted.Redacted<string>;
}
export type WhatsAppCallPermissionStatus = string;
export interface WhatsAppCallPermission {
    status: string;
    expirationTime?: Date;
}
export type WhatsAppCallPermissionActionName = string;
export type Iso8601Duration = string;
export interface WhatsAppCallPermissionLimit {
    timePeriod: string;
    maxAllowed: number;
    currentUsage: number;
    limitExpirationTime?: Date;
}
export type WhatsAppCallPermissionLimitList = WhatsAppCallPermissionLimit[];
export interface WhatsAppCallPermissionAction {
    actionName: string;
    canPerformAction: boolean;
    limits: WhatsAppCallPermissionLimit[];
}
export type WhatsAppCallPermissionActionList = WhatsAppCallPermissionAction[];
export interface GetWhatsAppCallPermissionOutput {
    permission: WhatsAppCallPermission;
    actions: WhatsAppCallPermissionAction[];
}
export interface GetWhatsAppFlowInput {
    id: string;
    flowId: string;
}
export type MetaFlowStatus = string;
export type MetaFlowJsonVersion = string;
export type MetaFlowDataApiVersion = string;
export type MetaFlowPreviewUrl = string;
export type MetaFlowTimestamp = string;
export interface MetaFlowPreviewInfo {
    previewUrl: string;
    expiresAt: string;
}
export type MetaFlowWabaCurrency = string;
export type MetaFlowWabaTimezoneId = string;
export type MetaFlowWabaTemplateNamespace = string;
export interface MetaFlowWhatsAppBusinessAccountInfo {
    id: string;
    name: string;
    currency?: string;
    timezoneId?: string;
    messageTemplateNamespace?: string;
}
export type MetaFlowApplicationLink = string;
export type MetaFlowApplicationName = string;
export type MetaFlowApplicationId = string;
export interface MetaFlowApplicationInfo {
    link?: string;
    name: string;
    id: string;
}
export type MetaFlowHealthStatusAvailability = string;
export type MetaFlowHealthEntityType = string;
export interface MetaFlowHealthEntity {
    entityType: string;
    id: string;
    canSendMessage: string;
}
export type MetaFlowHealthEntityList = MetaFlowHealthEntity[];
export interface MetaFlowHealthStatus {
    canSendMessage: string;
    entities?: MetaFlowHealthEntity[];
}
export interface GetWhatsAppFlowOutput {
    flowId: string;
    flowName: string;
    flowStatus: string;
    categories?: MetaFlowCategory[];
    validationErrors?: string[];
    jsonVersion?: string;
    dataApiVersion?: string;
    endpointUri?: string;
    preview?: MetaFlowPreviewInfo;
    whatsAppBusinessAccount?: MetaFlowWhatsAppBusinessAccountInfo;
    application?: MetaFlowApplicationInfo;
    healthStatus?: MetaFlowHealthStatus;
}
export interface GetWhatsAppFlowPreviewInput {
    id: string;
    flowId: string;
    invalidate?: boolean;
}
export interface GetWhatsAppFlowPreviewOutput {
    flowId: string;
    preview: MetaFlowPreviewInfo;
}
export type Headers = {
    [key: string]: string | undefined;
};
export interface S3PresignedUrl {
    url: string;
    headers: {
        [key: string]: string | undefined;
    };
}
export interface GetWhatsAppMessageMediaInput {
    mediaId: string;
    originationPhoneNumberId: string;
    metadataOnly?: boolean;
    destinationS3PresignedUrl?: S3PresignedUrl;
    destinationS3File?: S3File;
}
export interface GetWhatsAppMessageMediaOutput {
    mimeType?: string;
    fileSize?: number;
}
export interface GetWhatsAppMessageTemplateInput {
    metaTemplateId?: string;
    id: string;
    templateName?: string;
    templateLanguageCode?: string;
}
export type MetaTemplate = string;
export interface GetWhatsAppMessageTemplateOutput {
    template?: string;
}
export type NextToken = string;
export type MaxResults = number;
export interface ListLinkedWhatsAppBusinessAccountsInput {
    nextToken?: string;
    maxResults?: number;
}
export interface LinkedWhatsAppBusinessAccountSummary {
    arn: string;
    id: string;
    wabaId: string;
    registrationStatus: RegistrationStatus;
    linkDate: Date;
    wabaName: string;
    eventDestinations: WhatsAppBusinessAccountEventDestination[];
    marketingMessagesOnboardingStatus?: string;
    datasetId?: string;
}
export type LinkedWhatsAppBusinessAccountSummaryList = LinkedWhatsAppBusinessAccountSummary[];
export interface ListLinkedWhatsAppBusinessAccountsOutput {
    linkedAccounts?: LinkedWhatsAppBusinessAccountSummary[];
    nextToken?: string;
}
export type Arn = string;
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    statusCode?: number;
    tags?: Tag[];
}
export interface ListWhatsAppFlowAssetsInput {
    id: string;
    flowId: string;
    nextToken?: string;
    maxResults?: number;
}
export type MetaFlowAssetName = string;
export type MetaFlowAssetType = string;
export type MetaFlowAssetDownloadUrl = string;
export interface MetaFlowAsset {
    name: string;
    assetType: string;
    downloadUrl: string;
}
export type MetaFlowAssetList = MetaFlowAsset[];
export interface ListWhatsAppFlowAssetsOutput {
    flowAssets: MetaFlowAsset[];
    nextToken?: string;
}
export interface ListWhatsAppFlowsInput {
    id: string;
    nextToken?: string;
    maxResults?: number;
}
export interface MetaFlowSummary {
    flowId: string;
    flowName: string;
    flowStatus: string;
    flowCategories: MetaFlowCategory[];
    validationErrors: string[];
}
export type MetaFlowSummaryList = MetaFlowSummary[];
export interface ListWhatsAppFlowsOutput {
    flows: MetaFlowSummary[];
    nextToken?: string;
}
export interface ListWhatsAppMessageTemplatesInput {
    id: string;
    nextToken?: string;
    maxResults?: number;
}
export type MetaTemplateStatus = string;
export type MetaTemplateQualityScore = string;
export interface TemplateSummary {
    templateName?: string;
    metaTemplateId?: string;
    templateStatus?: string;
    templateQualityScore?: string;
    templateLanguage?: string;
    templateCategory?: string;
}
export type TemplateSummaryList = TemplateSummary[];
export interface ListWhatsAppMessageTemplatesOutput {
    templates?: TemplateSummary[];
    nextToken?: string;
}
export type Filter = {
    [key: string]: string | undefined;
};
export interface ListWhatsAppTemplateLibraryInput {
    nextToken?: string;
    maxResults?: number;
    id: string;
    filters?: {
        [key: string]: string | undefined;
    };
}
export type MetaTemplateTopic = string;
export type MetaTemplateUseCase = string;
export type MetaIndustry = string;
export type MetaIndustries = string[];
export type MetaTemplateHeader = string;
export type MetaTemplateBody = string;
export type MetaText = string;
export type MetaUrl = string;
export interface LibraryTemplateButtonList {
    type?: string;
    text?: string;
    phoneNumber?: string;
    url?: string;
    otpType?: string;
    zeroTapTermsAccepted?: boolean;
    supportedApps?: {
        [key: string]: string | undefined;
    }[];
}
export type MetaLibraryTemplateButtonList = LibraryTemplateButtonList[];
export type MetaTemplateBodyExampleParams = string[];
export interface MetaLibraryTemplateDefinition {
    templateName?: string;
    templateLanguage?: string;
    templateCategory?: string;
    templateTopic?: string;
    templateUseCase?: string;
    templateIndustry?: string[];
    templateHeader?: string;
    templateBody?: string;
    templateButtons?: LibraryTemplateButtonList[];
    templateId?: string;
    templateBodyExampleParams?: string[];
}
export type MetaLibraryTemplatesList = MetaLibraryTemplateDefinition[];
export interface ListWhatsAppTemplateLibraryOutput {
    metaLibraryTemplates?: MetaLibraryTemplateDefinition[];
    nextToken?: string;
}
export interface PostWhatsAppMessageMediaInput {
    originationPhoneNumberId: string;
    sourceS3PresignedUrl?: S3PresignedUrl;
    sourceS3File?: S3File;
}
export interface PostWhatsAppMessageMediaOutput {
    mediaId?: string;
}
export interface PublishWhatsAppFlowInput {
    id: string;
    flowId: string;
}
export interface PublishWhatsAppFlowOutput {
}
export interface PutWhatsAppBusinessAccountEventDestinationsInput {
    id: string;
    eventDestinations: WhatsAppBusinessAccountEventDestination[];
}
export interface PutWhatsAppBusinessAccountEventDestinationsOutput {
}
export type KmsKeyArn = string;
export interface PutWhatsAppBusinessPublicKeyInput {
    originationPhoneNumberId: string;
    businessPublicKey?: string;
    kmsKeyArn?: string;
}
export interface PutWhatsAppBusinessPublicKeyOutput {
}
export type WhatsAppCallEventBlob = Uint8Array | redacted.Redacted<Uint8Array>;
export interface SendWhatsAppCallEventInput {
    originationPhoneNumberId: string;
    metaApiVersion: string;
    callEvent: Uint8Array | redacted.Redacted<Uint8Array>;
}
export interface SendWhatsAppCallEventOutput {
    callId: string;
}
export type WhatsAppConversionEventBlob = Uint8Array | redacted.Redacted<Uint8Array>;
export interface SendWhatsAppConversionEventInput {
    id: string;
    datasetId: string;
    eventData: Uint8Array | redacted.Redacted<Uint8Array>;
}
export interface SendWhatsAppConversionEventOutput {
    requestId: string;
}
export type WhatsAppMessageBlob = Uint8Array | redacted.Redacted<Uint8Array>;
export interface SendWhatsAppMessageInput {
    originationPhoneNumberId: string;
    message: Uint8Array | redacted.Redacted<Uint8Array>;
    metaApiVersion: string;
}
export interface SendWhatsAppMessageOutput {
    messageId?: string;
}
export interface TagResourceInput {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceOutput {
    statusCode?: number;
}
export type StringList = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
    statusCode?: number;
}
export interface UpdateLinkedWhatsAppBusinessAccountPhoneNumberInput {
    id: string;
    callSettings: WhatsAppCallSettings;
}
export interface UpdateLinkedWhatsAppBusinessAccountPhoneNumberOutput {
    phoneNumberId: string;
}
export interface UpdateWhatsAppFlowInput {
    id: string;
    flowId: string;
    flowName?: string;
    categories?: MetaFlowCategory[];
    endpointUri?: string;
    metaAppId?: string;
}
export interface UpdateWhatsAppFlowOutput {
}
export interface UpdateWhatsAppFlowAssetsInput {
    id: string;
    flowId: string;
    flowJson: Uint8Array;
}
export interface UpdateWhatsAppFlowAssetsOutput {
    validationErrors?: string[];
}
export type MetaParameterFormat = string;
export type MetaTemplateComponents = Uint8Array;
export type MetaTemplateCtaLinkTrackingOptedOut = boolean;
export interface UpdateWhatsAppMessageTemplateInput {
    id: string;
    metaTemplateId?: string;
    templateName?: string;
    templateLanguageCode?: string;
    parameterFormat?: string;
    templateCategory?: string;
    templateComponents?: Uint8Array;
    ctaUrlLinkTrackingOptedOut?: boolean;
}
export interface UpdateWhatsAppMessageTemplateOutput {
}
export type ErrorMessage = string;
export type AssociateWhatsAppBusinessAccountError = DependencyException | InvalidParametersException | LimitExceededException | ThrottledRequestException | CommonErrors;
/**
 * This is only used through the Amazon Web Services console during sign-up to associate your WhatsApp Business Account to your Amazon Web Services account.
 */
export declare const associateWhatsAppBusinessAccount: API.OperationMethod<AssociateWhatsAppBusinessAccountInput, AssociateWhatsAppBusinessAccountOutput, AssociateWhatsAppBusinessAccountError, Credentials | HttpClient.HttpClient>;
export type CreateWhatsAppDatasetError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Creates a Meta Conversions API dataset for a WhatsApp Business Account.
 */
export declare const createWhatsAppDataset: API.OperationMethod<CreateWhatsAppDatasetInput, CreateWhatsAppDatasetOutput, CreateWhatsAppDatasetError, Credentials | HttpClient.HttpClient>;
export type CreateWhatsAppFlowError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Creates a new WhatsApp Flow. Flows enable businesses to create rich, interactive forms and experiences
 * that users can complete without leaving WhatsApp. The Flow is created in DRAFT status. If `publish`
 * is set to `true` and a valid `flowJson` is provided, the Flow is published immediately.
 */
export declare const createWhatsAppFlow: API.OperationMethod<CreateWhatsAppFlowInput, CreateWhatsAppFlowOutput, CreateWhatsAppFlowError, Credentials | HttpClient.HttpClient>;
export type CreateWhatsAppMessageTemplateError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Creates a new WhatsApp message template from a custom definition.
 *
 * Amazon Web Services End User Messaging Social does not store any WhatsApp message template content.
 */
export declare const createWhatsAppMessageTemplate: API.OperationMethod<CreateWhatsAppMessageTemplateInput, CreateWhatsAppMessageTemplateOutput, CreateWhatsAppMessageTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateWhatsAppMessageTemplateFromLibraryError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Creates a new WhatsApp message template using a template from Meta's template library.
 */
export declare const createWhatsAppMessageTemplateFromLibrary: API.OperationMethod<CreateWhatsAppMessageTemplateFromLibraryInput, CreateWhatsAppMessageTemplateFromLibraryOutput, CreateWhatsAppMessageTemplateFromLibraryError, Credentials | HttpClient.HttpClient>;
export type CreateWhatsAppMessageTemplateMediaError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Uploads media for use in a WhatsApp message template.
 */
export declare const createWhatsAppMessageTemplateMedia: API.OperationMethod<CreateWhatsAppMessageTemplateMediaInput, CreateWhatsAppMessageTemplateMediaOutput, CreateWhatsAppMessageTemplateMediaError, Credentials | HttpClient.HttpClient>;
export type DeleteWhatsAppFlowError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Deletes a WhatsApp Flow permanently. Only Flows in DRAFT status can be deleted. Published or deprecated Flows cannot be deleted.
 */
export declare const deleteWhatsAppFlow: API.OperationMethod<DeleteWhatsAppFlowInput, DeleteWhatsAppFlowOutput, DeleteWhatsAppFlowError, Credentials | HttpClient.HttpClient>;
export type DeleteWhatsAppMessageMediaError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Delete a media object from the WhatsApp service. If the object is still in an Amazon S3 bucket you should delete it from there too.
 */
export declare const deleteWhatsAppMessageMedia: API.OperationMethod<DeleteWhatsAppMessageMediaInput, DeleteWhatsAppMessageMediaOutput, DeleteWhatsAppMessageMediaError, Credentials | HttpClient.HttpClient>;
export type DeleteWhatsAppMessageTemplateError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Deletes a WhatsApp message template.
 */
export declare const deleteWhatsAppMessageTemplate: API.OperationMethod<DeleteWhatsAppMessageTemplateInput, DeleteWhatsAppMessageTemplateOutput, DeleteWhatsAppMessageTemplateError, Credentials | HttpClient.HttpClient>;
export type DeprecateWhatsAppFlowError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Deprecates a published WhatsApp Flow, marking it as no longer recommended for use. The Flow must be in PUBLISHED status. This is an irreversible operation.
 */
export declare const deprecateWhatsAppFlow: API.OperationMethod<DeprecateWhatsAppFlowInput, DeprecateWhatsAppFlowOutput, DeprecateWhatsAppFlowError, Credentials | HttpClient.HttpClient>;
export type DisassociateWhatsAppBusinessAccountError = DependencyException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Disassociate a WhatsApp Business Account (WABA) from your Amazon Web Services account.
 */
export declare const disassociateWhatsAppBusinessAccount: API.OperationMethod<DisassociateWhatsAppBusinessAccountInput, DisassociateWhatsAppBusinessAccountOutput, DisassociateWhatsAppBusinessAccountError, Credentials | HttpClient.HttpClient>;
export type GetLinkedWhatsAppBusinessAccountError = DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Get the details of your linked WhatsApp Business Account.
 */
export declare const getLinkedWhatsAppBusinessAccount: API.OperationMethod<GetLinkedWhatsAppBusinessAccountInput, GetLinkedWhatsAppBusinessAccountOutput, GetLinkedWhatsAppBusinessAccountError, Credentials | HttpClient.HttpClient>;
export type GetLinkedWhatsAppBusinessAccountPhoneNumberError = DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Retrieve the WABA account id and phone number details of a WhatsApp business account phone number.
 */
export declare const getLinkedWhatsAppBusinessAccountPhoneNumber: API.OperationMethod<GetLinkedWhatsAppBusinessAccountPhoneNumberInput, GetLinkedWhatsAppBusinessAccountPhoneNumberOutput, GetLinkedWhatsAppBusinessAccountPhoneNumberError, Credentials | HttpClient.HttpClient>;
export type GetWhatsAppBusinessPublicKeyError = AccessDeniedByMetaException | AccessDeniedException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Retrieves the business public key for a phone number and its signature status.
 */
export declare const getWhatsAppBusinessPublicKey: API.OperationMethod<GetWhatsAppBusinessPublicKeyInput, GetWhatsAppBusinessPublicKeyOutput, GetWhatsAppBusinessPublicKeyError, Credentials | HttpClient.HttpClient>;
export type GetWhatsAppCallPermissionError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Retrieves the current calling permission for a WhatsApp end user, along with the calling actions the business is allowed to take with that user. Provide the destination phone number or the business-scoped user ID to identify the end user.
 */
export declare const getWhatsAppCallPermission: API.OperationMethod<GetWhatsAppCallPermissionInput, GetWhatsAppCallPermissionOutput, GetWhatsAppCallPermissionError, Credentials | HttpClient.HttpClient>;
export type GetWhatsAppFlowError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Retrieves the metadata and status of a WhatsApp Flow, including validation errors, preview information, and health status.
 */
export declare const getWhatsAppFlow: API.OperationMethod<GetWhatsAppFlowInput, GetWhatsAppFlowOutput, GetWhatsAppFlowError, Credentials | HttpClient.HttpClient>;
export type GetWhatsAppFlowPreviewError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Generates a web preview URL for testing a WhatsApp Flow before publishing. Preview URLs expire in 30 days and can be shared with stakeholders for review.
 */
export declare const getWhatsAppFlowPreview: API.OperationMethod<GetWhatsAppFlowPreviewInput, GetWhatsAppFlowPreviewOutput, GetWhatsAppFlowPreviewError, Credentials | HttpClient.HttpClient>;
export type GetWhatsAppMessageMediaError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Get a media file from the WhatsApp service. On successful completion the media file is
 * retrieved from Meta and stored in the specified Amazon S3 bucket. Use either
 * `destinationS3File` or `destinationS3PresignedUrl` for the
 * destination. If both are used then an `InvalidParameterException` is
 * returned.
 */
export declare const getWhatsAppMessageMedia: API.OperationMethod<GetWhatsAppMessageMediaInput, GetWhatsAppMessageMediaOutput, GetWhatsAppMessageMediaError, Credentials | HttpClient.HttpClient>;
export type GetWhatsAppMessageTemplateError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Retrieves a specific WhatsApp message template.
 */
export declare const getWhatsAppMessageTemplate: API.OperationMethod<GetWhatsAppMessageTemplateInput, GetWhatsAppMessageTemplateOutput, GetWhatsAppMessageTemplateError, Credentials | HttpClient.HttpClient>;
export type ListLinkedWhatsAppBusinessAccountsError = InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * List all WhatsApp Business Accounts linked to your Amazon Web Services account.
 */
export declare const listLinkedWhatsAppBusinessAccounts: API.PaginatedOperationMethod<ListLinkedWhatsAppBusinessAccountsInput, ListLinkedWhatsAppBusinessAccountsOutput, ListLinkedWhatsAppBusinessAccountsError, Credentials | HttpClient.HttpClient, LinkedWhatsAppBusinessAccountSummary>;
export type ListTagsForResourceError = InternalServiceException | InvalidParametersException | ThrottledRequestException | CommonErrors;
/**
 * List all tags associated with a resource, such as a phone number or WABA.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWhatsAppFlowAssetsError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Lists the assets (Flow JSON definition) of a WhatsApp Flow with presigned download URLs. Download URLs are generated by Meta and expire after a short period.
 */
export declare const listWhatsAppFlowAssets: API.PaginatedOperationMethod<ListWhatsAppFlowAssetsInput, ListWhatsAppFlowAssetsOutput, ListWhatsAppFlowAssetsError, Credentials | HttpClient.HttpClient, MetaFlowAsset>;
export type ListWhatsAppFlowsError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Lists all WhatsApp Flows for a WhatsApp Business Account. Returns summary information including Flow ID, name, status, and categories.
 */
export declare const listWhatsAppFlows: API.PaginatedOperationMethod<ListWhatsAppFlowsInput, ListWhatsAppFlowsOutput, ListWhatsAppFlowsError, Credentials | HttpClient.HttpClient, MetaFlowSummary>;
export type ListWhatsAppMessageTemplatesError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Lists WhatsApp message templates for a specific WhatsApp Business Account.
 */
export declare const listWhatsAppMessageTemplates: API.PaginatedOperationMethod<ListWhatsAppMessageTemplatesInput, ListWhatsAppMessageTemplatesOutput, ListWhatsAppMessageTemplatesError, Credentials | HttpClient.HttpClient, TemplateSummary>;
export type ListWhatsAppTemplateLibraryError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Lists templates available in Meta's template library for WhatsApp messaging.
 */
export declare const listWhatsAppTemplateLibrary: API.PaginatedOperationMethod<ListWhatsAppTemplateLibraryInput, ListWhatsAppTemplateLibraryOutput, ListWhatsAppTemplateLibraryError, Credentials | HttpClient.HttpClient, MetaLibraryTemplateDefinition>;
export type PostWhatsAppMessageMediaError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Upload a media file to the WhatsApp service. Only the specified
 * `originationPhoneNumberId` has the permissions to send the media file when
 * using SendWhatsAppMessage. You must use either `sourceS3File`
 * or `sourceS3PresignedUrl` for the source. If both or neither are specified then an
 * `InvalidParameterException` is returned.
 */
export declare const postWhatsAppMessageMedia: API.OperationMethod<PostWhatsAppMessageMediaInput, PostWhatsAppMessageMediaOutput, PostWhatsAppMessageMediaError, Credentials | HttpClient.HttpClient>;
export type PublishWhatsAppFlowError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Publishes a WhatsApp Flow, making it available for use in template messages. The Flow must be in DRAFT status with valid Flow JSON that passes Meta's validation. This is an irreversible operation.
 */
export declare const publishWhatsAppFlow: API.OperationMethod<PublishWhatsAppFlowInput, PublishWhatsAppFlowOutput, PublishWhatsAppFlowError, Credentials | HttpClient.HttpClient>;
export type PutWhatsAppBusinessAccountEventDestinationsError = InternalServiceException | InvalidParametersException | ThrottledRequestException | CommonErrors;
/**
 * Add an event destination to log event data from WhatsApp for a WhatsApp Business Account (WABA). A WABA can only have one event destination at a time. All resources associated with the WABA use the same event destination.
 */
export declare const putWhatsAppBusinessAccountEventDestinations: API.OperationMethod<PutWhatsAppBusinessAccountEventDestinationsInput, PutWhatsAppBusinessAccountEventDestinationsOutput, PutWhatsAppBusinessAccountEventDestinationsError, Credentials | HttpClient.HttpClient>;
export type PutWhatsAppBusinessPublicKeyError = AccessDeniedByMetaException | AccessDeniedException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Sets the business public key used to encrypt the data exchanged with the endpoint of a data exchange Flow.
 */
export declare const putWhatsAppBusinessPublicKey: API.OperationMethod<PutWhatsAppBusinessPublicKeyInput, PutWhatsAppBusinessPublicKeyOutput, PutWhatsAppBusinessPublicKeyError, Credentials | HttpClient.HttpClient>;
export type SendWhatsAppCallEventError = AccessDeniedByMetaException | ConflictException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Sends a WhatsApp calling event, such as connecting or terminating a call, for a business phone number. This operation passes the event through to Meta. To use this operation, the origination phone number must belong to a WhatsApp Business Account that is linked to your Amazon Web Services account.
 */
export declare const sendWhatsAppCallEvent: API.OperationMethod<SendWhatsAppCallEventInput, SendWhatsAppCallEventOutput, SendWhatsAppCallEventError, Credentials | HttpClient.HttpClient>;
export type SendWhatsAppConversionEventError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Sends a conversion event to Meta's Conversions API for the specified WhatsApp Business Account dataset.
 */
export declare const sendWhatsAppConversionEvent: API.OperationMethod<SendWhatsAppConversionEventInput, SendWhatsAppConversionEventOutput, SendWhatsAppConversionEventError, Credentials | HttpClient.HttpClient>;
export type SendWhatsAppMessageError = DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | AccessDeniedByMetaException | CommonErrors;
/**
 * Send a WhatsApp message. For examples of sending a message using the Amazon Web Services
 * CLI, see Sending messages in the
 *
 * *Amazon Web Services End User Messaging Social User Guide*
 * .
 */
export declare const sendWhatsAppMessage: API.OperationMethod<SendWhatsAppMessageInput, SendWhatsAppMessageOutput, SendWhatsAppMessageError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServiceException | InvalidParametersException | ThrottledRequestException | CommonErrors;
/**
 * Adds or overwrites only the specified tags for the specified resource. When you specify
 * an existing tag key, the value is overwritten with the new value.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServiceException | InvalidParametersException | ThrottledRequestException | CommonErrors;
/**
 * Removes the specified tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateLinkedWhatsAppBusinessAccountPhoneNumberError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Updates the calling settings for a linked WhatsApp business phone number, such as whether calling is enabled and the hours during which the business accepts calls.
 */
export declare const updateLinkedWhatsAppBusinessAccountPhoneNumber: API.OperationMethod<UpdateLinkedWhatsAppBusinessAccountPhoneNumberInput, UpdateLinkedWhatsAppBusinessAccountPhoneNumberOutput, UpdateLinkedWhatsAppBusinessAccountPhoneNumberError, Credentials | HttpClient.HttpClient>;
export type UpdateWhatsAppFlowError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Updates the metadata of a WhatsApp Flow, such as its name or categories. This does not update the Flow JSON definition. Use UpdateWhatsAppFlowAssets to update the Flow JSON.
 */
export declare const updateWhatsAppFlow: API.OperationMethod<UpdateWhatsAppFlowInput, UpdateWhatsAppFlowOutput, UpdateWhatsAppFlowError, Credentials | HttpClient.HttpClient>;
export type UpdateWhatsAppFlowAssetsError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Updates the Flow JSON definition (assets) of a WhatsApp Flow. Updating a published Flow's assets reverts it to DRAFT status, requiring re-publishing.
 */
export declare const updateWhatsAppFlowAssets: API.OperationMethod<UpdateWhatsAppFlowAssetsInput, UpdateWhatsAppFlowAssetsOutput, UpdateWhatsAppFlowAssetsError, Credentials | HttpClient.HttpClient>;
export type UpdateWhatsAppMessageTemplateError = AccessDeniedByMetaException | DependencyException | InternalServiceException | InvalidParametersException | ResourceNotFoundException | ThrottledRequestException | CommonErrors;
/**
 * Updates an existing WhatsApp message template.
 */
export declare const updateWhatsAppMessageTemplate: API.OperationMethod<UpdateWhatsAppMessageTemplateInput, UpdateWhatsAppMessageTemplateOutput, UpdateWhatsAppMessageTemplateError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=socialmessaging.d.ts.map