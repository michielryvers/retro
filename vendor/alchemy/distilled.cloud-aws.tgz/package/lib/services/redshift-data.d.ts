import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ActiveSessionsExceededException_base: S.TaggedErrorClass<"ActiveSessionsExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ActiveSessionsExceededException extends /*@__PURE__*/ ActiveSessionsExceededException_base {
}
declare const ActiveStatementsExceededException_base: S.TaggedErrorClass<"ActiveStatementsExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ActiveStatementsExceededException extends /*@__PURE__*/ ActiveStatementsExceededException_base {
}
declare const ActiveWaitingRequestsExceededException_base: S.TaggedErrorClass<"ActiveWaitingRequestsExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ActiveWaitingRequestsExceededException extends /*@__PURE__*/ ActiveWaitingRequestsExceededException_base {
}
declare const BatchExecuteStatementException_base: S.TaggedErrorClass<"BatchExecuteStatementException", {
    readonly message: any;
    readonly StatementId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class BatchExecuteStatementException extends /*@__PURE__*/ BatchExecuteStatementException_base {
}
declare const DatabaseConnectionException_base: S.TaggedErrorClass<"DatabaseConnectionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class DatabaseConnectionException extends /*@__PURE__*/ DatabaseConnectionException_base {
}
declare const ExecuteStatementException_base: S.TaggedErrorClass<"ExecuteStatementException", {
    readonly message: any;
    readonly StatementId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ExecuteStatementException extends /*@__PURE__*/ ExecuteStatementException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const QueryTimeoutException_base: S.TaggedErrorClass<"QueryTimeoutException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class QueryTimeoutException extends /*@__PURE__*/ QueryTimeoutException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type StatementString = string;
export type SqlList = string[];
export type ClusterIdentifierString = string;
export type SecretArn = string;
export type StatementNameString = string;
export type ParameterName = string;
export type ParameterValue = string;
export interface SqlParameter {
    name: string;
    value: string;
}
export type SqlParametersList = SqlParameter[];
export type WorkgroupNameString = string;
export type ClientToken = string;
export type ResultFormatString = string;
export type SessionAliveSeconds = number;
export type UUID = string;
export type ExecutionMode = string;
export type WaitTimeSeconds = number;
export interface BatchExecuteStatementInput {
    Sqls: string[];
    ClusterIdentifier?: string;
    SecretArn?: string;
    DbUser?: string;
    Database?: string;
    WithEvent?: boolean;
    StatementName?: string;
    Parameters?: SqlParameter[];
    WorkgroupName?: string;
    ClientToken?: string;
    ResultFormat?: string;
    SessionKeepAliveSeconds?: number;
    SessionId?: string;
    ExecutionMode?: string;
    WaitTimeSeconds?: number;
}
export type DbGroupList = string[];
export type StatementStatusString = string;
export type BoxedLong = number;
export type BoxedBoolean = boolean;
export interface BatchExecuteStatementOutput {
    Id?: string;
    CreatedAt?: Date;
    ClusterIdentifier?: string;
    DbUser?: string;
    DbGroups?: string[];
    Database?: string;
    SecretArn?: string;
    WorkgroupName?: string;
    SessionId?: string;
    Status?: string;
    RedshiftPid?: number;
    HasResultSet?: boolean;
}
export interface CancelStatementRequest {
    Id: string;
}
export interface CancelStatementResponse {
    Status?: boolean;
}
export interface DescribeStatementRequest {
    Id: string;
    WaitTimeSeconds?: number;
}
export type StatusString = string;
export interface SubStatementData {
    Id: string;
    Duration?: number;
    Error?: string;
    Status?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    QueryString?: string;
    ResultRows?: number;
    ResultSize?: number;
    RedshiftQueryId?: number;
    HasResultSet?: boolean;
}
export type SubStatementList = SubStatementData[];
export interface DescribeStatementResponse {
    Id: string;
    SecretArn?: string;
    DbUser?: string;
    Database?: string;
    ClusterIdentifier?: string;
    Duration?: number;
    Error?: string;
    Status?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    RedshiftPid?: number;
    HasResultSet?: boolean;
    QueryString?: string;
    ResultRows?: number;
    ResultSize?: number;
    RedshiftQueryId?: number;
    QueryParameters?: SqlParameter[];
    SubStatements?: SubStatementData[];
    WorkgroupName?: string;
    ResultFormat?: string;
    SessionId?: string;
    ExecutionMode?: string;
}
export type PageSize = number;
export interface DescribeTableRequest {
    ClusterIdentifier?: string;
    SecretArn?: string;
    DbUser?: string;
    Database: string;
    ConnectedDatabase?: string;
    Schema?: string;
    Table?: string;
    NextToken?: string;
    MaxResults?: number;
    WorkgroupName?: string;
}
export interface ColumnMetadata {
    isCaseSensitive?: boolean;
    isCurrency?: boolean;
    isSigned?: boolean;
    label?: string;
    name?: string;
    nullable?: number;
    precision?: number;
    scale?: number;
    schemaName?: string;
    tableName?: string;
    typeName?: string;
    length?: number;
    columnDefault?: string;
}
export type ColumnList = ColumnMetadata[];
export interface DescribeTableResponse {
    TableName?: string;
    ColumnList?: ColumnMetadata[];
    NextToken?: string;
}
export interface ExecuteStatementInput {
    Sql: string;
    ClusterIdentifier?: string;
    SecretArn?: string;
    DbUser?: string;
    Database?: string;
    WithEvent?: boolean;
    StatementName?: string;
    Parameters?: SqlParameter[];
    WorkgroupName?: string;
    ClientToken?: string;
    ResultFormat?: string;
    SessionKeepAliveSeconds?: number;
    SessionId?: string;
    WaitTimeSeconds?: number;
}
export interface ExecuteStatementOutput {
    Id?: string;
    CreatedAt?: Date;
    ClusterIdentifier?: string;
    DbUser?: string;
    DbGroups?: string[];
    Database?: string;
    SecretArn?: string;
    WorkgroupName?: string;
    SessionId?: string;
    Status?: string;
    RedshiftPid?: number;
    HasResultSet?: boolean;
}
export interface GetStatementResultRequest {
    Id: string;
    NextToken?: string;
    WaitTimeSeconds?: number;
}
export type BoxedDouble = number;
export type Field = {
    isNull: boolean;
    booleanValue?: never;
    longValue?: never;
    doubleValue?: never;
    stringValue?: never;
    blobValue?: never;
} | {
    isNull?: never;
    booleanValue: boolean;
    longValue?: never;
    doubleValue?: never;
    stringValue?: never;
    blobValue?: never;
} | {
    isNull?: never;
    booleanValue?: never;
    longValue: number;
    doubleValue?: never;
    stringValue?: never;
    blobValue?: never;
} | {
    isNull?: never;
    booleanValue?: never;
    longValue?: never;
    doubleValue: number;
    stringValue?: never;
    blobValue?: never;
} | {
    isNull?: never;
    booleanValue?: never;
    longValue?: never;
    doubleValue?: never;
    stringValue: string;
    blobValue?: never;
} | {
    isNull?: never;
    booleanValue?: never;
    longValue?: never;
    doubleValue?: never;
    stringValue?: never;
    blobValue: Uint8Array;
};
export type FieldList = Field[];
export type SqlRecords = Field[][];
export type ColumnMetadataList = ColumnMetadata[];
export interface GetStatementResultResponse {
    Records: Field[][];
    ColumnMetadata?: ColumnMetadata[];
    TotalNumRows?: number;
    NextToken?: string;
}
export interface GetStatementResultV2Request {
    Id: string;
    NextToken?: string;
    WaitTimeSeconds?: number;
}
export type QueryRecords = {
    CSVRecords: string;
};
export type FormattedSqlRecords = QueryRecords[];
export interface GetStatementResultV2Response {
    Records: QueryRecords[];
    ColumnMetadata?: ColumnMetadata[];
    TotalNumRows?: number;
    ResultFormat?: string;
    NextToken?: string;
}
export interface ListDatabasesRequest {
    ClusterIdentifier?: string;
    Database?: string;
    SecretArn?: string;
    DbUser?: string;
    NextToken?: string;
    MaxResults?: number;
    WorkgroupName?: string;
}
export type DatabaseList = string[];
export interface ListDatabasesResponse {
    Databases?: string[];
    NextToken?: string;
}
export interface ListSchemasRequest {
    ClusterIdentifier?: string;
    SecretArn?: string;
    DbUser?: string;
    Database: string;
    ConnectedDatabase?: string;
    SchemaPattern?: string;
    NextToken?: string;
    MaxResults?: number;
    WorkgroupName?: string;
}
export type SchemaList = string[];
export interface ListSchemasResponse {
    Schemas?: string[];
    NextToken?: string;
}
export type ListStatementsLimit = number;
export type SessionStatusString = string;
export interface ListSessionsRequest {
    NextToken?: string;
    MaxResults?: number;
    SessionId?: string;
    Status?: string;
    RoleLevel?: boolean;
    ClusterIdentifier?: string;
    WorkgroupName?: string;
    Database?: string;
}
export interface SessionData {
    SessionId: string;
    Status: string;
    CreatedAt: Date;
    UpdatedAt?: Date;
    Database?: string;
    DbUser?: string;
    ClusterIdentifier?: string;
    WorkgroupName?: string;
    SessionAliveSeconds?: number;
    SessionTtl?: Date;
    CurrentStatementId?: string;
}
export type SessionList = SessionData[];
export interface ListSessionsResponse {
    Sessions: SessionData[];
    NextToken?: string;
}
export interface ListStatementsRequest {
    NextToken?: string;
    MaxResults?: number;
    StatementName?: string;
    Status?: string;
    RoleLevel?: boolean;
    Database?: string;
    ClusterIdentifier?: string;
    WorkgroupName?: string;
}
export type StatementStringList = string[];
export interface StatementData {
    Id: string;
    QueryString?: string;
    QueryStrings?: string[];
    SecretArn?: string;
    Status?: string;
    StatementName?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    QueryParameters?: SqlParameter[];
    IsBatchStatement?: boolean;
    ResultFormat?: string;
    SessionId?: string;
}
export type StatementList = StatementData[];
export interface ListStatementsResponse {
    Statements: StatementData[];
    NextToken?: string;
}
export interface ListTablesRequest {
    ClusterIdentifier?: string;
    SecretArn?: string;
    DbUser?: string;
    Database: string;
    ConnectedDatabase?: string;
    SchemaPattern?: string;
    TablePattern?: string;
    NextToken?: string;
    MaxResults?: number;
    WorkgroupName?: string;
}
export interface TableMember {
    name?: string;
    type?: string;
    schema?: string;
}
export type TableList = TableMember[];
export interface ListTablesResponse {
    Tables?: TableMember[];
    NextToken?: string;
}
export type BatchExecuteStatementError = ActiveSessionsExceededException | ActiveStatementsExceededException | BatchExecuteStatementException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Runs one or more SQL statements, which can be data manipulation language (DML) or data definition language (DDL). Depending on the authorization method, use one of the following combinations of request parameters:
 *
 * - Secrets Manager - when connecting to a cluster, provide the `secret-arn` of a secret stored in Secrets Manager which has `username` and `password`. The specified secret contains credentials to connect to the `database` you specify. When you are connecting to a cluster, you also supply the database name, If you provide a cluster identifier (`dbClusterIdentifier`), it must match the cluster identifier stored in the secret. When you are connecting to a serverless workgroup, you also supply the database name.
 *
 * - Temporary credentials - when connecting to your data warehouse, choose one of the following options:
 *
 * - When connecting to a serverless workgroup, specify the workgroup name and database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift-serverless:GetCredentials` operation is required.
 *
 * - When connecting to a cluster as an IAM identity, specify the cluster identifier and the database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift:GetClusterCredentialsWithIAM` operation is required.
 *
 * - When connecting to a cluster as a database user, specify the cluster identifier, the database name, and the database user name. Also, permission to call the `redshift:GetClusterCredentials` operation is required.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const batchExecuteStatement: API.OperationMethod<BatchExecuteStatementInput, BatchExecuteStatementOutput, BatchExecuteStatementError, Credentials | HttpClient.HttpClient>;
export type CancelStatementError = DatabaseConnectionException | InternalServerException | QueryTimeoutException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Cancels a running query. To be canceled, a query must be running.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const cancelStatement: API.OperationMethod<CancelStatementRequest, CancelStatementResponse, CancelStatementError, Credentials | HttpClient.HttpClient>;
export type DescribeStatementError = ActiveWaitingRequestsExceededException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the details about a specific instance when a query was run by the Amazon Redshift Data API. The information includes when the query started, when it finished, the query status, the number of rows returned, and the SQL statement.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const describeStatement: API.OperationMethod<DescribeStatementRequest, DescribeStatementResponse, DescribeStatementError, Credentials | HttpClient.HttpClient>;
export type DescribeTableError = DatabaseConnectionException | InternalServerException | QueryTimeoutException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the detailed information about a table from metadata in the cluster. The information includes its columns. A token is returned to page through the column list. Depending on the authorization method, use one of the following combinations of request parameters:
 *
 * - Secrets Manager - when connecting to a cluster, provide the `secret-arn` of a secret stored in Secrets Manager which has `username` and `password`. The specified secret contains credentials to connect to the `database` you specify. When you are connecting to a cluster, you also supply the database name, If you provide a cluster identifier (`dbClusterIdentifier`), it must match the cluster identifier stored in the secret. When you are connecting to a serverless workgroup, you also supply the database name.
 *
 * - Temporary credentials - when connecting to your data warehouse, choose one of the following options:
 *
 * - When connecting to a serverless workgroup, specify the workgroup name and database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift-serverless:GetCredentials` operation is required.
 *
 * - When connecting to a cluster as an IAM identity, specify the cluster identifier and the database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift:GetClusterCredentialsWithIAM` operation is required.
 *
 * - When connecting to a cluster as a database user, specify the cluster identifier, the database name, and the database user name. Also, permission to call the `redshift:GetClusterCredentials` operation is required.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const describeTable: API.PaginatedOperationMethod<DescribeTableRequest, DescribeTableResponse, DescribeTableError, Credentials | HttpClient.HttpClient, ColumnMetadata>;
export type ExecuteStatementError = ActiveSessionsExceededException | ActiveStatementsExceededException | ExecuteStatementException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Runs an SQL statement, which can be data manipulation language (DML) or data definition language (DDL). This statement must be a single SQL statement. Depending on the authorization method, use one of the following combinations of request parameters:
 *
 * - Secrets Manager - when connecting to a cluster, provide the `secret-arn` of a secret stored in Secrets Manager which has `username` and `password`. The specified secret contains credentials to connect to the `database` you specify. When you are connecting to a cluster, you also supply the database name, If you provide a cluster identifier (`dbClusterIdentifier`), it must match the cluster identifier stored in the secret. When you are connecting to a serverless workgroup, you also supply the database name.
 *
 * - Temporary credentials - when connecting to your data warehouse, choose one of the following options:
 *
 * - When connecting to a serverless workgroup, specify the workgroup name and database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift-serverless:GetCredentials` operation is required.
 *
 * - When connecting to a cluster as an IAM identity, specify the cluster identifier and the database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift:GetClusterCredentialsWithIAM` operation is required.
 *
 * - When connecting to a cluster as a database user, specify the cluster identifier, the database name, and the database user name. Also, permission to call the `redshift:GetClusterCredentials` operation is required.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const executeStatement: API.OperationMethod<ExecuteStatementInput, ExecuteStatementOutput, ExecuteStatementError, Credentials | HttpClient.HttpClient>;
export type GetStatementResultError = ActiveWaitingRequestsExceededException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Fetches the temporarily cached result of an SQL statement in JSON format. The `ExecuteStatement` or `BatchExecuteStatement` operation that ran the SQL statement must have specified `ResultFormat` as `JSON` , or let the format default to JSON. A token is returned to page through the statement results.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const getStatementResult: API.PaginatedOperationMethod<GetStatementResultRequest, GetStatementResultResponse, GetStatementResultError, Credentials | HttpClient.HttpClient, Field[]>;
export type GetStatementResultV2Error = ActiveWaitingRequestsExceededException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Fetches the temporarily cached result of an SQL statement in CSV format. The `ExecuteStatement` or `BatchExecuteStatement` operation that ran the SQL statement must have specified `ResultFormat` as `CSV`. A token is returned to page through the statement results.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const getStatementResultV2: API.PaginatedOperationMethod<GetStatementResultV2Request, GetStatementResultV2Response, GetStatementResultV2Error, Credentials | HttpClient.HttpClient, QueryRecords>;
export type ListDatabasesError = DatabaseConnectionException | InternalServerException | QueryTimeoutException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List the databases in a cluster. A token is returned to page through the database list. Depending on the authorization method, use one of the following combinations of request parameters:
 *
 * - Secrets Manager - when connecting to a cluster, provide the `secret-arn` of a secret stored in Secrets Manager which has `username` and `password`. The specified secret contains credentials to connect to the `database` you specify. When you are connecting to a cluster, you also supply the database name, If you provide a cluster identifier (`dbClusterIdentifier`), it must match the cluster identifier stored in the secret. When you are connecting to a serverless workgroup, you also supply the database name.
 *
 * - Temporary credentials - when connecting to your data warehouse, choose one of the following options:
 *
 * - When connecting to a serverless workgroup, specify the workgroup name and database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift-serverless:GetCredentials` operation is required.
 *
 * - When connecting to a cluster as an IAM identity, specify the cluster identifier and the database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift:GetClusterCredentialsWithIAM` operation is required.
 *
 * - When connecting to a cluster as a database user, specify the cluster identifier, the database name, and the database user name. Also, permission to call the `redshift:GetClusterCredentials` operation is required.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const listDatabases: API.PaginatedOperationMethod<ListDatabasesRequest, ListDatabasesResponse, ListDatabasesError, Credentials | HttpClient.HttpClient, string>;
export type ListSchemasError = DatabaseConnectionException | InternalServerException | QueryTimeoutException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the schemas in a database. A token is returned to page through the schema list. Depending on the authorization method, use one of the following combinations of request parameters:
 *
 * - Secrets Manager - when connecting to a cluster, provide the `secret-arn` of a secret stored in Secrets Manager which has `username` and `password`. The specified secret contains credentials to connect to the `database` you specify. When you are connecting to a cluster, you also supply the database name, If you provide a cluster identifier (`dbClusterIdentifier`), it must match the cluster identifier stored in the secret. When you are connecting to a serverless workgroup, you also supply the database name.
 *
 * - Temporary credentials - when connecting to your data warehouse, choose one of the following options:
 *
 * - When connecting to a serverless workgroup, specify the workgroup name and database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift-serverless:GetCredentials` operation is required.
 *
 * - When connecting to a cluster as an IAM identity, specify the cluster identifier and the database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift:GetClusterCredentialsWithIAM` operation is required.
 *
 * - When connecting to a cluster as a database user, specify the cluster identifier, the database name, and the database user name. Also, permission to call the `redshift:GetClusterCredentials` operation is required.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const listSchemas: API.PaginatedOperationMethod<ListSchemasRequest, ListSchemasResponse, ListSchemasError, Credentials | HttpClient.HttpClient, string>;
export type ListSessionsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the sessions that the caller created in the last 24 hours. By default, only sessions with a status of `AVAILABLE` or `BUSY` are returned. You can filter the results by session status, compute target (cluster or serverless workgroup), or database. To retrieve the metadata for a single session, provide the `SessionId` parameter. Use `NextToken` to page through the session list.
 *
 * Returns only the sessions that the caller created. When identity-enhanced role sessions are used, you must provide either the `ClusterIdentifier` or `WorkgroupName` parameter to ensure that the IAM Identity Center user can only access the Amazon Redshift IAM Identity Center applications they are assigned. For more information, see Trusted identity propagation overview.
 */
export declare const listSessions: API.PaginatedOperationMethod<ListSessionsRequest, ListSessionsResponse, ListSessionsError, Credentials | HttpClient.HttpClient, SessionData>;
export type ListStatementsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List of SQL statements. By default, only finished statements are shown. A token is returned to page through the statement list.
 *
 * When you use identity-enhanced role sessions to list statements, you must provide either the `cluster-identifier` or `workgroup-name` parameter. This ensures that the IdC user can only access the Amazon Redshift IdC applications they are assigned. For more information, see Trusted identity propagation overview.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const listStatements: API.PaginatedOperationMethod<ListStatementsRequest, ListStatementsResponse, ListStatementsError, Credentials | HttpClient.HttpClient, StatementData>;
export type ListTablesError = DatabaseConnectionException | InternalServerException | QueryTimeoutException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List the tables in a database. If neither `SchemaPattern` nor `TablePattern` are specified, then all tables in the database are returned. A token is returned to page through the table list. Depending on the authorization method, use one of the following combinations of request parameters:
 *
 * - Secrets Manager - when connecting to a cluster, provide the `secret-arn` of a secret stored in Secrets Manager which has `username` and `password`. The specified secret contains credentials to connect to the `database` you specify. When you are connecting to a cluster, you also supply the database name, If you provide a cluster identifier (`dbClusterIdentifier`), it must match the cluster identifier stored in the secret. When you are connecting to a serverless workgroup, you also supply the database name.
 *
 * - Temporary credentials - when connecting to your data warehouse, choose one of the following options:
 *
 * - When connecting to a serverless workgroup, specify the workgroup name and database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift-serverless:GetCredentials` operation is required.
 *
 * - When connecting to a cluster as an IAM identity, specify the cluster identifier and the database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift:GetClusterCredentialsWithIAM` operation is required.
 *
 * - When connecting to a cluster as a database user, specify the cluster identifier, the database name, and the database user name. Also, permission to call the `redshift:GetClusterCredentials` operation is required.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const listTables: API.PaginatedOperationMethod<ListTablesRequest, ListTablesResponse, ListTablesError, Credentials | HttpClient.HttpClient, TableMember>;
export {};
//# sourceMappingURL=redshift-data.d.ts.map