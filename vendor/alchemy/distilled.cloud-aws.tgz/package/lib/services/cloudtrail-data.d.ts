import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ChannelInsufficientPermission_base: S.TaggedErrorClass<"ChannelInsufficientPermission", {
    readonly message: any;
}>;
export declare class ChannelInsufficientPermission extends /*@__PURE__*/ ChannelInsufficientPermission_base {
}
declare const ChannelNotFound_base: S.TaggedErrorClass<"ChannelNotFound", {
    readonly message: any;
}>;
export declare class ChannelNotFound extends /*@__PURE__*/ ChannelNotFound_base {
}
declare const ChannelUnsupportedSchema_base: S.TaggedErrorClass<"ChannelUnsupportedSchema", {
    readonly message: any;
}>;
export declare class ChannelUnsupportedSchema extends /*@__PURE__*/ ChannelUnsupportedSchema_base {
}
declare const DuplicatedAuditEventId_base: S.TaggedErrorClass<"DuplicatedAuditEventId", {
    readonly message: any;
}>;
export declare class DuplicatedAuditEventId extends /*@__PURE__*/ DuplicatedAuditEventId_base {
}
declare const InvalidChannelARN_base: S.TaggedErrorClass<"InvalidChannelARN", {
    readonly message: any;
}>;
export declare class InvalidChannelARN extends /*@__PURE__*/ InvalidChannelARN_base {
}
declare const UnsupportedOperationException_base: S.TaggedErrorClass<"UnsupportedOperationException", {
    readonly message: any;
}>;
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
export type Uuid = string;
export interface AuditEvent {
    id: string;
    eventData: string;
    eventDataChecksum?: string;
}
export type AuditEvents = AuditEvent[];
export type ChannelArn = string;
export type ExternalId = string;
export interface PutAuditEventsRequest {
    auditEvents: AuditEvent[];
    channelArn: string;
    externalId?: string;
}
export interface AuditEventResultEntry {
    id: string;
    eventID: string;
}
export type AuditEventResultEntries = AuditEventResultEntry[];
export type ErrorCode = string;
export type ErrorMessage = string;
export interface ResultErrorEntry {
    id: string;
    errorCode: string;
    errorMessage: string;
}
export type ResultErrorEntries = ResultErrorEntry[];
export interface PutAuditEventsResponse {
    successful: AuditEventResultEntry[];
    failed: ResultErrorEntry[];
}
export type PutAuditEventsError = ChannelInsufficientPermission | ChannelNotFound | ChannelUnsupportedSchema | DuplicatedAuditEventId | InvalidChannelARN | UnsupportedOperationException | CommonErrors;
/**
 * Ingests your application events into CloudTrail Lake. A required parameter,
 * `auditEvents`, accepts the JSON records (also called
 * *payload*) of events that you want CloudTrail to ingest. You
 * can add up to 100 of these events (or up to 1 MB) per `PutAuditEvents`
 * request.
 */
export declare const putAuditEvents: API.OperationMethod<PutAuditEventsRequest, PutAuditEventsResponse, PutAuditEventsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cloudtrail-data.d.ts.map