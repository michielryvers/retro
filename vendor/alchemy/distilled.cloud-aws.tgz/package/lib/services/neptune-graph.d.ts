import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import * as T from "../traits.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnprocessableException_base: S.TaggedErrorClass<"UnprocessableException", {
    readonly message: any;
    readonly reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableException extends /*@__PURE__*/ UnprocessableException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ExportTaskId = string;
export interface CancelExportTaskInput {
    taskIdentifier: string;
}
export type GraphId = string;
export type RoleArn = string;
export type ExportTaskStatus = "INITIALIZING" | "EXPORTING" | "SUCCEEDED" | "FAILED" | "CANCELLING" | "CANCELLED" | "DELETED" | (string & {});
export type ExportFormat = "PARQUET" | "CSV" | (string & {});
export type KmsKeyArn = string;
export type ParquetType = "COLUMNAR" | (string & {});
export interface CancelExportTaskOutput {
    graphId: string;
    roleArn: string;
    taskId: string;
    status: ExportTaskStatus;
    format: ExportFormat;
    destination: string;
    kmsKeyIdentifier: string;
    parquetType?: ParquetType;
    statusReason?: string;
}
export type TaskId = string;
export interface CancelImportTaskInput {
    taskIdentifier: string;
}
export type Format = "CSV" | "OPEN_CYPHER" | "PARQUET" | "NTRIPLES" | (string & {});
export type ImportTaskStatus = "INITIALIZING" | "EXPORTING" | "ANALYZING_DATA" | "IMPORTING" | "REPROVISIONING" | "ROLLING_BACK" | "SUCCEEDED" | "FAILED" | "CANCELLING" | "CANCELLED" | "DELETED" | (string & {});
export interface CancelImportTaskOutput {
    graphId?: string;
    taskId: string;
    source: string;
    format?: Format;
    parquetType?: ParquetType;
    roleArn: string;
    status: ImportTaskStatus;
}
export type GraphIdentifier = string;
export interface CancelQueryInput {
    graphIdentifier: string;
    queryId: string;
}
export interface CancelQueryResponse {
}
export type GraphName = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type VectorSearchDimension = number;
export interface VectorSearchConfiguration {
    dimension: number;
}
export type ReplicaCount = number;
export type ProvisionedMemory = number;
export interface CreateGraphInput {
    graphName: string;
    tags?: {
        [key: string]: string | undefined;
    };
    publicConnectivity?: boolean;
    kmsKeyIdentifier?: string;
    vectorSearchConfiguration?: VectorSearchConfiguration;
    replicaCount?: number;
    deletionProtection?: boolean;
    provisionedMemory: number;
}
export type GraphStatus = "CREATING" | "AVAILABLE" | "DELETING" | "RESETTING" | "UPDATING" | "SNAPSHOTTING" | "FAILED" | "IMPORTING" | "STARTING" | "STOPPING" | "STOPPED" | (string & {});
export type SnapshotId = string;
export interface CreateGraphOutput {
    id: string;
    name: string;
    arn: string;
    status?: GraphStatus;
    statusReason?: string;
    createTime?: Date;
    provisionedMemory?: number;
    endpoint?: string;
    publicConnectivity?: boolean;
    vectorSearchConfiguration?: VectorSearchConfiguration;
    replicaCount?: number;
    kmsKeyIdentifier?: string;
    sourceSnapshotId?: string;
    deletionProtection?: boolean;
    buildNumber?: string;
}
export type SnapshotName = string;
export interface CreateGraphSnapshotInput {
    graphIdentifier: string;
    snapshotName: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type SnapshotStatus = "CREATING" | "AVAILABLE" | "DELETING" | "FAILED" | (string & {});
export interface CreateGraphSnapshotOutput {
    id: string;
    name: string;
    arn: string;
    sourceGraphId?: string;
    snapshotCreateTime?: Date;
    status?: SnapshotStatus;
    kmsKeyIdentifier?: string;
}
export interface NeptuneImportOptions {
    s3ExportPath: string;
    s3ExportKmsKeyId: string;
    preserveDefaultVertexLabels?: boolean;
    preserveEdgeIds?: boolean;
}
export type ImportOptions = {
    neptune: NeptuneImportOptions;
};
export type BlankNodeHandling = "convertToIri" | (string & {});
export interface CreateGraphUsingImportTaskInput {
    graphName: string;
    tags?: {
        [key: string]: string | undefined;
    };
    publicConnectivity?: boolean;
    kmsKeyIdentifier?: string;
    vectorSearchConfiguration?: VectorSearchConfiguration;
    replicaCount?: number;
    deletionProtection?: boolean;
    importOptions?: ImportOptions;
    maxProvisionedMemory?: number;
    minProvisionedMemory?: number;
    failOnError?: boolean;
    source: string;
    format?: Format;
    parquetType?: ParquetType;
    blankNodeHandling?: BlankNodeHandling;
    roleArn: string;
}
export interface CreateGraphUsingImportTaskOutput {
    graphId?: string;
    taskId: string;
    source: string;
    format?: Format;
    parquetType?: ParquetType;
    roleArn: string;
    status: ImportTaskStatus;
    importOptions?: ImportOptions;
}
export type VpcId = string;
export type SubnetId = string;
export type SubnetIds = string[];
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export interface CreatePrivateGraphEndpointInput {
    graphIdentifier: string;
    vpcId?: string;
    subnetIds?: string[];
    vpcSecurityGroupIds?: string[];
}
export type PrivateGraphEndpointStatus = "CREATING" | "AVAILABLE" | "DELETING" | "FAILED" | (string & {});
export type VpcEndpointId = string;
export interface CreatePrivateGraphEndpointOutput {
    vpcId: string;
    subnetIds: string[];
    status: PrivateGraphEndpointStatus;
    vpcEndpointId?: string;
}
export interface DeleteGraphInput {
    graphIdentifier: string;
    skipSnapshot: boolean;
}
export interface DeleteGraphOutput {
    id: string;
    name: string;
    arn: string;
    status?: GraphStatus;
    statusReason?: string;
    createTime?: Date;
    provisionedMemory?: number;
    endpoint?: string;
    publicConnectivity?: boolean;
    vectorSearchConfiguration?: VectorSearchConfiguration;
    replicaCount?: number;
    kmsKeyIdentifier?: string;
    sourceSnapshotId?: string;
    deletionProtection?: boolean;
    buildNumber?: string;
}
export type SnapshotIdentifier = string;
export interface DeleteGraphSnapshotInput {
    snapshotIdentifier: string;
}
export interface DeleteGraphSnapshotOutput {
    id: string;
    name: string;
    arn: string;
    sourceGraphId?: string;
    snapshotCreateTime?: Date;
    status?: SnapshotStatus;
    kmsKeyIdentifier?: string;
}
export interface DeletePrivateGraphEndpointInput {
    graphIdentifier: string;
    vpcId: string;
}
export interface DeletePrivateGraphEndpointOutput {
    vpcId: string;
    subnetIds: string[];
    status: PrivateGraphEndpointStatus;
    vpcEndpointId?: string;
}
export type QueryLanguage = "OPEN_CYPHER" | (string & {});
export type DocumentValuedMap = {
    [key: string]: any | undefined;
};
export type PlanCacheType = "ENABLED" | "DISABLED" | "AUTO" | (string & {});
export type ExplainMode = "STATIC" | "DETAILS" | (string & {});
export interface ExecuteQueryInput {
    graphIdentifier: string;
    queryString: string;
    language: QueryLanguage;
    parameters?: {
        [key: string]: any | undefined;
    };
    planCache?: PlanCacheType;
    explainMode?: ExplainMode;
    queryTimeoutMilliseconds?: number;
}
export interface ExecuteQueryOutput {
    payload: T.StreamingOutputBody;
}
export interface GetExportTaskInput {
    taskIdentifier: string;
}
export interface ExportTaskDetails {
    startTime: Date;
    timeElapsedSeconds: number;
    progressPercentage: number;
    numVerticesWritten?: number;
    numEdgesWritten?: number;
}
export type ExportFilterLabel = string;
export type ExportFilterOutputPropertyName = string;
export type ExportFilterOutputDataType = string;
export type ExportFilterSourcePropertyName = string;
export type MultiValueHandlingType = "TO_LIST" | "PICK_FIRST" | (string & {});
export interface ExportFilterPropertyAttributes {
    outputType?: string;
    sourcePropertyName?: string;
    multiValueHandling?: MultiValueHandlingType;
}
export type ExportFilterPropertyMap = {
    [key: string]: ExportFilterPropertyAttributes | undefined;
};
export interface ExportFilterElement {
    properties?: {
        [key: string]: ExportFilterPropertyAttributes | undefined;
    };
}
export type ExportFilterPerLabelMap = {
    [key: string]: ExportFilterElement | undefined;
};
export interface ExportFilter {
    vertexFilter?: {
        [key: string]: ExportFilterElement | undefined;
    };
    edgeFilter?: {
        [key: string]: ExportFilterElement | undefined;
    };
}
export interface GetExportTaskOutput {
    graphId: string;
    roleArn: string;
    taskId: string;
    status: ExportTaskStatus;
    format: ExportFormat;
    destination: string;
    kmsKeyIdentifier: string;
    parquetType?: ParquetType;
    statusReason?: string;
    exportTaskDetails?: ExportTaskDetails;
    exportFilter?: ExportFilter;
}
export interface GetGraphInput {
    graphIdentifier: string;
}
export interface GetGraphOutput {
    id: string;
    name: string;
    arn: string;
    status?: GraphStatus;
    statusReason?: string;
    createTime?: Date;
    provisionedMemory?: number;
    endpoint?: string;
    publicConnectivity?: boolean;
    vectorSearchConfiguration?: VectorSearchConfiguration;
    replicaCount?: number;
    kmsKeyIdentifier?: string;
    sourceSnapshotId?: string;
    deletionProtection?: boolean;
    buildNumber?: string;
}
export interface GetGraphSnapshotInput {
    snapshotIdentifier: string;
}
export interface GetGraphSnapshotOutput {
    id: string;
    name: string;
    arn: string;
    sourceGraphId?: string;
    snapshotCreateTime?: Date;
    status?: SnapshotStatus;
    kmsKeyIdentifier?: string;
}
export type GraphSummaryMode = "BASIC" | "DETAILED" | (string & {});
export interface GetGraphSummaryInput {
    graphIdentifier: string;
    mode?: GraphSummaryMode;
}
export type NodeLabels = string[];
export type EdgeLabels = string[];
export type LongValuedMap = {
    [key: string]: number | undefined;
};
export type LongValuedMapList = {
    [key: string]: number | undefined;
}[];
export type NodeProperties = string[];
export type OutgoingEdgeLabels = string[];
export interface NodeStructure {
    count?: number;
    nodeProperties?: string[];
    distinctOutgoingEdgeLabels?: string[];
}
export type NodeStructures = NodeStructure[];
export type EdgeProperties = string[];
export interface EdgeStructure {
    count?: number;
    edgeProperties?: string[];
}
export type EdgeStructures = EdgeStructure[];
export interface GraphDataSummary {
    numNodes?: number;
    numEdges?: number;
    numNodeLabels?: number;
    numEdgeLabels?: number;
    nodeLabels?: string[];
    edgeLabels?: string[];
    numNodeProperties?: number;
    numEdgeProperties?: number;
    nodeProperties?: {
        [key: string]: number | undefined;
    }[];
    edgeProperties?: {
        [key: string]: number | undefined;
    }[];
    totalNodePropertyValues?: number;
    totalEdgePropertyValues?: number;
    nodeStructures?: NodeStructure[];
    edgeStructures?: EdgeStructure[];
}
export interface GetGraphSummaryOutput {
    version?: string;
    lastStatisticsComputationTime?: Date;
    graphSummary?: GraphDataSummary;
}
export interface GetImportTaskInput {
    taskIdentifier: string;
}
export interface ImportTaskDetails {
    status: string;
    startTime: Date;
    timeElapsedSeconds: number;
    progressPercentage: number;
    errorCount: number;
    errorDetails?: string;
    statementCount: number;
    dictionaryEntryCount: number;
}
export interface GetImportTaskOutput {
    graphId?: string;
    taskId: string;
    source: string;
    format?: Format;
    parquetType?: ParquetType;
    roleArn: string;
    status: ImportTaskStatus;
    importOptions?: ImportOptions;
    importTaskDetails?: ImportTaskDetails;
    attemptNumber?: number;
    statusReason?: string;
}
export interface GetPrivateGraphEndpointInput {
    graphIdentifier: string;
    vpcId: string;
}
export interface GetPrivateGraphEndpointOutput {
    vpcId: string;
    subnetIds: string[];
    status: PrivateGraphEndpointStatus;
    vpcEndpointId?: string;
}
export interface GetQueryInput {
    graphIdentifier: string;
    queryId: string;
}
export type QueryState = "RUNNING" | "WAITING" | "CANCELLING" | (string & {});
export interface GetQueryOutput {
    id?: string;
    queryString?: string;
    waited?: number;
    elapsed?: number;
    state?: QueryState;
}
export type PaginationToken = string;
export type MaxResults = number;
export interface ListExportTasksInput {
    graphIdentifier?: string;
    nextToken?: string;
    maxResults?: number;
}
export interface ExportTaskSummary {
    graphId: string;
    roleArn: string;
    taskId: string;
    status: ExportTaskStatus;
    format: ExportFormat;
    destination: string;
    kmsKeyIdentifier: string;
    parquetType?: ParquetType;
    statusReason?: string;
}
export type ExportTaskSummaryList = ExportTaskSummary[];
export interface ListExportTasksOutput {
    tasks: ExportTaskSummary[];
    nextToken?: string;
}
export interface ListGraphsInput {
    nextToken?: string;
    maxResults?: number;
}
export interface GraphSummary {
    id: string;
    name: string;
    arn: string;
    status?: GraphStatus;
    provisionedMemory?: number;
    publicConnectivity?: boolean;
    endpoint?: string;
    replicaCount?: number;
    kmsKeyIdentifier?: string;
    deletionProtection?: boolean;
}
export type GraphSummaryList = GraphSummary[];
export interface ListGraphsOutput {
    graphs: GraphSummary[];
    nextToken?: string;
}
export interface ListGraphSnapshotsInput {
    graphIdentifier?: string;
    nextToken?: string;
    maxResults?: number;
}
export interface GraphSnapshotSummary {
    id: string;
    name: string;
    arn: string;
    sourceGraphId?: string;
    snapshotCreateTime?: Date;
    status?: SnapshotStatus;
    kmsKeyIdentifier?: string;
}
export type GraphSnapshotSummaryList = GraphSnapshotSummary[];
export interface ListGraphSnapshotsOutput {
    graphSnapshots: GraphSnapshotSummary[];
    nextToken?: string;
}
export interface ListImportTasksInput {
    graphIdentifier?: string;
    nextToken?: string;
    maxResults?: number;
}
export interface ImportTaskSummary {
    graphId?: string;
    taskId: string;
    source: string;
    format?: Format;
    parquetType?: ParquetType;
    roleArn: string;
    status: ImportTaskStatus;
}
export type ImportTaskSummaryList = ImportTaskSummary[];
export interface ListImportTasksOutput {
    tasks: ImportTaskSummary[];
    nextToken?: string;
}
export interface ListPrivateGraphEndpointsInput {
    graphIdentifier: string;
    nextToken?: string;
    maxResults?: number;
}
export interface PrivateGraphEndpointSummary {
    vpcId: string;
    subnetIds: string[];
    status: PrivateGraphEndpointStatus;
    vpcEndpointId?: string;
}
export type PrivateGraphEndpointSummaryList = PrivateGraphEndpointSummary[];
export interface ListPrivateGraphEndpointsOutput {
    privateGraphEndpoints: PrivateGraphEndpointSummary[];
    nextToken?: string;
}
export type QueryStateInput = "ALL" | "RUNNING" | "WAITING" | "CANCELLING" | (string & {});
export interface ListQueriesInput {
    graphIdentifier: string;
    maxResults: number;
    state?: QueryStateInput;
}
export interface QuerySummary {
    id?: string;
    queryString?: string;
    waited?: number;
    elapsed?: number;
    state?: QueryState;
}
export type QuerySummaryList = QuerySummary[];
export interface ListQueriesOutput {
    queries: QuerySummary[];
}
export type Arn = string;
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface ResetGraphInput {
    graphIdentifier: string;
    skipSnapshot: boolean;
}
export interface ResetGraphOutput {
    id: string;
    name: string;
    arn: string;
    status?: GraphStatus;
    statusReason?: string;
    createTime?: Date;
    provisionedMemory?: number;
    endpoint?: string;
    publicConnectivity?: boolean;
    vectorSearchConfiguration?: VectorSearchConfiguration;
    replicaCount?: number;
    kmsKeyIdentifier?: string;
    sourceSnapshotId?: string;
    deletionProtection?: boolean;
    buildNumber?: string;
}
export interface RestoreGraphFromSnapshotInput {
    snapshotIdentifier: string;
    graphName: string;
    provisionedMemory?: number;
    deletionProtection?: boolean;
    tags?: {
        [key: string]: string | undefined;
    };
    replicaCount?: number;
    publicConnectivity?: boolean;
}
export interface RestoreGraphFromSnapshotOutput {
    id: string;
    name: string;
    arn: string;
    status?: GraphStatus;
    statusReason?: string;
    createTime?: Date;
    provisionedMemory?: number;
    endpoint?: string;
    publicConnectivity?: boolean;
    vectorSearchConfiguration?: VectorSearchConfiguration;
    replicaCount?: number;
    kmsKeyIdentifier?: string;
    sourceSnapshotId?: string;
    deletionProtection?: boolean;
    buildNumber?: string;
}
export interface StartExportTaskInput {
    graphIdentifier: string;
    roleArn: string;
    format: ExportFormat;
    destination: string;
    kmsKeyIdentifier: string;
    parquetType?: ParquetType;
    exportFilter?: ExportFilter;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface StartExportTaskOutput {
    graphId: string;
    roleArn: string;
    taskId: string;
    status: ExportTaskStatus;
    format: ExportFormat;
    destination: string;
    kmsKeyIdentifier: string;
    parquetType?: ParquetType;
    statusReason?: string;
    exportFilter?: ExportFilter;
}
export interface StartGraphInput {
    graphIdentifier: string;
}
export interface StartGraphOutput {
    id: string;
    name: string;
    arn: string;
    status?: GraphStatus;
    statusReason?: string;
    createTime?: Date;
    provisionedMemory?: number;
    endpoint?: string;
    publicConnectivity?: boolean;
    vectorSearchConfiguration?: VectorSearchConfiguration;
    replicaCount?: number;
    kmsKeyIdentifier?: string;
    sourceSnapshotId?: string;
    deletionProtection?: boolean;
    buildNumber?: string;
}
export interface StartImportTaskInput {
    importOptions?: ImportOptions;
    failOnError?: boolean;
    source: string;
    format?: Format;
    parquetType?: ParquetType;
    blankNodeHandling?: BlankNodeHandling;
    graphIdentifier: string;
    roleArn: string;
}
export interface StartImportTaskOutput {
    graphId?: string;
    taskId: string;
    source: string;
    format?: Format;
    parquetType?: ParquetType;
    roleArn: string;
    status: ImportTaskStatus;
    importOptions?: ImportOptions;
}
export interface StopGraphInput {
    graphIdentifier: string;
}
export interface StopGraphOutput {
    id: string;
    name: string;
    arn: string;
    status?: GraphStatus;
    statusReason?: string;
    createTime?: Date;
    provisionedMemory?: number;
    endpoint?: string;
    publicConnectivity?: boolean;
    vectorSearchConfiguration?: VectorSearchConfiguration;
    replicaCount?: number;
    kmsKeyIdentifier?: string;
    sourceSnapshotId?: string;
    deletionProtection?: boolean;
    buildNumber?: string;
}
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateGraphInput {
    graphIdentifier: string;
    publicConnectivity?: boolean;
    provisionedMemory?: number;
    deletionProtection?: boolean;
}
export interface UpdateGraphOutput {
    id: string;
    name: string;
    arn: string;
    status?: GraphStatus;
    statusReason?: string;
    createTime?: Date;
    provisionedMemory?: number;
    endpoint?: string;
    publicConnectivity?: boolean;
    vectorSearchConfiguration?: VectorSearchConfiguration;
    replicaCount?: number;
    kmsKeyIdentifier?: string;
    sourceSnapshotId?: string;
    deletionProtection?: boolean;
    buildNumber?: string;
}
export type ConflictExceptionReason = "CONCURRENT_MODIFICATION" | (string & {});
export type ValidationExceptionReason = "CONSTRAINT_VIOLATION" | "ILLEGAL_ARGUMENT" | "MALFORMED_QUERY" | "QUERY_CANCELLED" | "QUERY_TOO_LARGE" | "UNSUPPORTED_OPERATION" | "BAD_REQUEST" | (string & {});
export type UnprocessableExceptionReason = "QUERY_TIMEOUT" | "INTERNAL_LIMIT_EXCEEDED" | "MEMORY_LIMIT_EXCEEDED" | "STORAGE_LIMIT_EXCEEDED" | "PARTITION_FULL" | (string & {});
export type CancelExportTaskError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancel the specified export task.
 */
export declare const cancelExportTask: API.OperationMethod<CancelExportTaskInput, CancelExportTaskOutput, CancelExportTaskError, Credentials | HttpClient.HttpClient>;
export type CancelImportTaskError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified import task.
 */
export declare const cancelImportTask: API.OperationMethod<CancelImportTaskInput, CancelImportTaskOutput, CancelImportTaskError, Credentials | HttpClient.HttpClient>;
export type CancelQueryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels a specified query.
 */
export declare const cancelQuery: API.OperationMethod<CancelQueryInput, CancelQueryResponse, CancelQueryError, Credentials | HttpClient.HttpClient>;
export type CreateGraphError = ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Neptune Analytics graph.
 */
export declare const createGraph: API.OperationMethod<CreateGraphInput, CreateGraphOutput, CreateGraphError, Credentials | HttpClient.HttpClient>;
export type CreateGraphSnapshotError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a snapshot of the specific graph.
 */
export declare const createGraphSnapshot: API.OperationMethod<CreateGraphSnapshotInput, CreateGraphSnapshotOutput, CreateGraphSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateGraphUsingImportTaskError = ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Neptune Analytics graph and imports data into it, either from Amazon Simple Storage Service (S3) or from a Neptune database or a Neptune database snapshot.
 *
 * The data can be loaded from files in S3 that in either the Gremlin CSV format or the openCypher load format.
 */
export declare const createGraphUsingImportTask: API.OperationMethod<CreateGraphUsingImportTaskInput, CreateGraphUsingImportTaskOutput, CreateGraphUsingImportTaskError, Credentials | HttpClient.HttpClient>;
export type CreatePrivateGraphEndpointError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a private graph endpoint to allow private access to the graph from within a VPC. You can attach security groups to the private graph endpoint.
 *
 * VPC endpoint charges apply.
 */
export declare const createPrivateGraphEndpoint: API.OperationMethod<CreatePrivateGraphEndpointInput, CreatePrivateGraphEndpointOutput, CreatePrivateGraphEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteGraphError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified graph. Graphs cannot be deleted if delete-protection is enabled.
 */
export declare const deleteGraph: API.OperationMethod<DeleteGraphInput, DeleteGraphOutput, DeleteGraphError, Credentials | HttpClient.HttpClient>;
export type DeleteGraphSnapshotError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified graph snapshot.
 */
export declare const deleteGraphSnapshot: API.OperationMethod<DeleteGraphSnapshotInput, DeleteGraphSnapshotOutput, DeleteGraphSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeletePrivateGraphEndpointError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a private graph endpoint.
 */
export declare const deletePrivateGraphEndpoint: API.OperationMethod<DeletePrivateGraphEndpointInput, DeletePrivateGraphEndpointOutput, DeletePrivateGraphEndpointError, Credentials | HttpClient.HttpClient>;
export type ExecuteQueryError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | UnprocessableException | ValidationException | CommonErrors;
/**
 * Execute an openCypher query.
 *
 * When invoking this operation in a Neptune Analytics cluster, the IAM user or role making the request must have a policy attached that allows one of the following IAM actions in that cluster, depending on the query:
 *
 * - neptune-graph:ReadDataViaQuery
 *
 * - neptune-graph:WriteDataViaQuery
 *
 * - neptune-graph:DeleteDataViaQuery
 */
export declare const executeQuery: API.OperationMethod<ExecuteQueryInput, ExecuteQueryOutput, ExecuteQueryError, Credentials | HttpClient.HttpClient>;
export type GetExportTaskError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a specified export task.
 */
export declare const getExportTask: API.OperationMethod<GetExportTaskInput, GetExportTaskOutput, GetExportTaskError, Credentials | HttpClient.HttpClient>;
export type GetGraphError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a specified graph.
 */
export declare const getGraph: API.OperationMethod<GetGraphInput, GetGraphOutput, GetGraphError, Credentials | HttpClient.HttpClient>;
export type GetGraphSnapshotError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a specified graph snapshot.
 */
export declare const getGraphSnapshot: API.OperationMethod<GetGraphSnapshotInput, GetGraphSnapshotOutput, GetGraphSnapshotError, Credentials | HttpClient.HttpClient>;
export type GetGraphSummaryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a graph summary for a property graph.
 */
export declare const getGraphSummary: API.OperationMethod<GetGraphSummaryInput, GetGraphSummaryOutput, GetGraphSummaryError, Credentials | HttpClient.HttpClient>;
export type GetImportTaskError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a specified import task.
 */
export declare const getImportTask: API.OperationMethod<GetImportTaskInput, GetImportTaskOutput, GetImportTaskError, Credentials | HttpClient.HttpClient>;
export type GetPrivateGraphEndpointError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a specified private endpoint.
 */
export declare const getPrivateGraphEndpoint: API.OperationMethod<GetPrivateGraphEndpointInput, GetPrivateGraphEndpointOutput, GetPrivateGraphEndpointError, Credentials | HttpClient.HttpClient>;
export type GetQueryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the status of a specified query.
 *
 * When invoking this operation in a Neptune Analytics cluster, the IAM user or role making the request must have the `neptune-graph:GetQueryStatus` IAM action attached.
 */
export declare const getQuery: API.OperationMethod<GetQueryInput, GetQueryOutput, GetQueryError, Credentials | HttpClient.HttpClient>;
export type ListExportTasksError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of export tasks.
 */
export declare const listExportTasks: API.PaginatedOperationMethod<ListExportTasksInput, ListExportTasksOutput, ListExportTasksError, Credentials | HttpClient.HttpClient, ExportTaskSummary>;
export type ListGraphsError = InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists available Neptune Analytics graphs.
 */
export declare const listGraphs: API.PaginatedOperationMethod<ListGraphsInput, ListGraphsOutput, ListGraphsError, Credentials | HttpClient.HttpClient, GraphSummary>;
export type ListGraphSnapshotsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists available snapshots of a specified Neptune Analytics graph.
 */
export declare const listGraphSnapshots: API.PaginatedOperationMethod<ListGraphSnapshotsInput, ListGraphSnapshotsOutput, ListGraphSnapshotsError, Credentials | HttpClient.HttpClient, GraphSnapshotSummary>;
export type ListImportTasksError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists import tasks.
 */
export declare const listImportTasks: API.PaginatedOperationMethod<ListImportTasksInput, ListImportTasksOutput, ListImportTasksError, Credentials | HttpClient.HttpClient, ImportTaskSummary>;
export type ListPrivateGraphEndpointsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists private endpoints for a specified Neptune Analytics graph.
 */
export declare const listPrivateGraphEndpoints: API.PaginatedOperationMethod<ListPrivateGraphEndpointsInput, ListPrivateGraphEndpointsOutput, ListPrivateGraphEndpointsError, Credentials | HttpClient.HttpClient, PrivateGraphEndpointSummary>;
export type ListQueriesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists active openCypher queries.
 */
export declare const listQueries: API.OperationMethod<ListQueriesInput, ListQueriesOutput, ListQueriesError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists tags associated with a specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ResetGraphError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Empties the data from a specified Neptune Analytics graph.
 */
export declare const resetGraph: API.OperationMethod<ResetGraphInput, ResetGraphOutput, ResetGraphError, Credentials | HttpClient.HttpClient>;
export type RestoreGraphFromSnapshotError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Restores a graph from a snapshot.
 */
export declare const restoreGraphFromSnapshot: API.OperationMethod<RestoreGraphFromSnapshotInput, RestoreGraphFromSnapshotOutput, RestoreGraphFromSnapshotError, Credentials | HttpClient.HttpClient>;
export type StartExportTaskError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Export data from an existing Neptune Analytics graph to Amazon S3. The graph state should be `AVAILABLE`.
 */
export declare const startExportTask: API.OperationMethod<StartExportTaskInput, StartExportTaskOutput, StartExportTaskError, Credentials | HttpClient.HttpClient>;
export type StartGraphError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the specific graph.
 */
export declare const startGraph: API.OperationMethod<StartGraphInput, StartGraphOutput, StartGraphError, Credentials | HttpClient.HttpClient>;
export type StartImportTaskError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Import data into existing Neptune Analytics graph from Amazon Simple Storage Service (S3). The graph needs to be empty and in the AVAILABLE state.
 */
export declare const startImportTask: API.OperationMethod<StartImportTaskInput, StartImportTaskOutput, StartImportTaskError, Credentials | HttpClient.HttpClient>;
export type StopGraphError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops the specific graph.
 */
export declare const stopGraph: API.OperationMethod<StopGraphInput, StopGraphOutput, StopGraphError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the specified tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateGraphError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of a specified Neptune Analytics graph
 */
export declare const updateGraph: API.OperationMethod<UpdateGraphInput, UpdateGraphOutput, UpdateGraphError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=neptune-graph.d.ts.map