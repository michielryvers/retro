import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import * as T from "../traits.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AlreadyExistsException_base: S.TaggedErrorClass<"AlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AlreadyExistsException extends /*@__PURE__*/ AlreadyExistsException_base {
}
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}>;
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}>;
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const EntityNotFoundException_base: S.TaggedErrorClass<"EntityNotFoundException", {
    readonly message: any;
}>;
export declare class EntityNotFoundException extends /*@__PURE__*/ EntityNotFoundException_base {
}
declare const ExpiredException_base: S.TaggedErrorClass<"ExpiredException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ExpiredException extends /*@__PURE__*/ ExpiredException_base {
}
declare const GlueEncryptionException_base: S.TaggedErrorClass<"GlueEncryptionException", {
    readonly message: any;
}>;
export declare class GlueEncryptionException extends /*@__PURE__*/ GlueEncryptionException_base {
}
declare const InternalServiceException_base: S.TaggedErrorClass<"InternalServiceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServiceException extends /*@__PURE__*/ InternalServiceException_base {
}
declare const InvalidInputException_base: S.TaggedErrorClass<"InvalidInputException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const InvalidLakeFormationPrincipal_base: S.TaggedErrorClass<"InvalidLakeFormationPrincipal", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InvalidLakeFormationPrincipal extends /*@__PURE__*/ InvalidLakeFormationPrincipal_base {
}
declare const LastServiceLinkedRoleRegistration_base: S.TaggedErrorClass<"LastServiceLinkedRoleRegistration", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class LastServiceLinkedRoleRegistration extends /*@__PURE__*/ LastServiceLinkedRoleRegistration_base {
}
declare const OperationTimeoutException_base: S.TaggedErrorClass<"OperationTimeoutException", {
    readonly message: any;
}>;
export declare class OperationTimeoutException extends /*@__PURE__*/ OperationTimeoutException_base {
}
declare const PermissionTypeMismatchException_base: S.TaggedErrorClass<"PermissionTypeMismatchException", {
    readonly message: any;
}>;
export declare class PermissionTypeMismatchException extends /*@__PURE__*/ PermissionTypeMismatchException_base {
}
declare const ResourceNotReadyException_base: S.TaggedErrorClass<"ResourceNotReadyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotReadyException extends /*@__PURE__*/ ResourceNotReadyException_base {
}
declare const ResourceNumberLimitExceededException_base: S.TaggedErrorClass<"ResourceNumberLimitExceededException", {
    readonly message: any;
}>;
export declare class ResourceNumberLimitExceededException extends /*@__PURE__*/ ResourceNumberLimitExceededException_base {
}
declare const StatisticsNotReadyYetException_base: S.TaggedErrorClass<"StatisticsNotReadyYetException", {
    readonly message: any;
}>;
export declare class StatisticsNotReadyYetException extends /*@__PURE__*/ StatisticsNotReadyYetException_base {
}
declare const ThrottledException_base: S.TaggedErrorClass<"ThrottledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottledException extends /*@__PURE__*/ ThrottledException_base {
}
declare const TransactionCanceledException_base: S.TaggedErrorClass<"TransactionCanceledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TransactionCanceledException extends /*@__PURE__*/ TransactionCanceledException_base {
}
declare const TransactionCommitInProgressException_base: S.TaggedErrorClass<"TransactionCommitInProgressException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TransactionCommitInProgressException extends /*@__PURE__*/ TransactionCommitInProgressException_base {
}
declare const TransactionCommittedException_base: S.TaggedErrorClass<"TransactionCommittedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TransactionCommittedException extends /*@__PURE__*/ TransactionCommittedException_base {
}
declare const WorkUnitsNotReadyYetException_base: S.TaggedErrorClass<"WorkUnitsNotReadyYetException", {
    readonly message: any;
}>;
export declare class WorkUnitsNotReadyYetException extends /*@__PURE__*/ WorkUnitsNotReadyYetException_base {
}
export type CatalogIdString = string;
export interface CatalogResource {
    Id?: string;
}
export type NameString = string;
export interface DatabaseResource {
    CatalogId?: string;
    Name: string;
}
export interface TableWildcard {
}
export interface TableResource {
    CatalogId?: string;
    DatabaseName: string;
    Name?: string;
    TableWildcard?: TableWildcard;
}
export type ColumnNames = string[];
export interface ColumnWildcard {
    ExcludedColumnNames?: string[];
}
export interface TableWithColumnsResource {
    CatalogId?: string;
    DatabaseName: string;
    Name: string;
    ColumnNames?: string[];
    ColumnWildcard?: ColumnWildcard;
}
export type ResourceArnString = string;
export interface DataLocationResource {
    CatalogId?: string;
    ResourceArn: string;
}
export interface DataCellsFilterResource {
    TableCatalogId?: string;
    DatabaseName?: string;
    TableName?: string;
    Name?: string;
}
export type LFTagValue = string;
export type TagValueList = string[];
export interface LFTagKeyResource {
    CatalogId?: string;
    TagKey: string;
    TagValues: string[];
}
export type ResourceType = "DATABASE" | "TABLE" | (string & {});
export type LFTagKey = string;
export interface LFTag {
    TagKey: string;
    TagValues: string[];
}
export type Expression = LFTag[];
export interface LFTagPolicyResource {
    CatalogId?: string;
    ResourceType: ResourceType;
    Expression?: LFTag[];
    ExpressionName?: string;
}
export interface LFTagExpressionResource {
    CatalogId?: string;
    Name: string;
}
export interface Resource {
    Catalog?: CatalogResource;
    Database?: DatabaseResource;
    Table?: TableResource;
    TableWithColumns?: TableWithColumnsResource;
    DataLocation?: DataLocationResource;
    DataCellsFilter?: DataCellsFilterResource;
    LFTag?: LFTagKeyResource;
    LFTagPolicy?: LFTagPolicyResource;
    LFTagExpression?: LFTagExpressionResource;
}
export interface LFTagPair {
    CatalogId?: string;
    TagKey: string;
    TagValues: string[];
}
export type LFTagsList = LFTagPair[];
export interface AddLFTagsToResourceRequest {
    CatalogId?: string;
    Resource: Resource;
    LFTags: LFTagPair[];
}
export type DescriptionString = string;
export interface ErrorDetail {
    ErrorCode?: string;
    ErrorMessage?: string;
}
export interface LFTagError {
    LFTag?: LFTagPair;
    Error?: ErrorDetail;
}
export type LFTagErrors = LFTagError[];
export interface AddLFTagsToResourceResponse {
    Failures?: LFTagError[];
}
export type SAMLAssertionString = string;
export type IAMRoleArn = string;
export type IAMSAMLProviderArn = string;
export type CredentialTimeoutDurationSecondInteger = number;
export interface AssumeDecoratedRoleWithSAMLRequest {
    SAMLAssertion: string;
    RoleArn: string;
    PrincipalArn: string;
    DurationSeconds?: number;
}
export type AccessKeyIdString = string;
export type SecretAccessKeyString = string;
export type SessionTokenString = string;
export type ExpirationTimestamp = Date;
export interface AssumeDecoratedRoleWithSAMLResponse {
    AccessKeyId?: string;
    SecretAccessKey?: string | redacted.Redacted<string>;
    SessionToken?: string | redacted.Redacted<string>;
    Expiration?: Date;
}
export type Identifier = string;
export type DataLakePrincipalString = string;
export interface DataLakePrincipal {
    DataLakePrincipalIdentifier?: string;
}
export type Permission = "ALL" | "SELECT" | "ALTER" | "DROP" | "DELETE" | "INSERT" | "DESCRIBE" | "CREATE_DATABASE" | "CREATE_TABLE" | "DATA_LOCATION_ACCESS" | "CREATE_LF_TAG" | "ASSOCIATE" | "GRANT_WITH_LF_TAG_EXPRESSION" | "CREATE_LF_TAG_EXPRESSION" | "CREATE_CATALOG" | "SUPER_USER" | (string & {});
export type PermissionList = Permission[];
export type ExpressionString = string;
export interface Condition {
    Expression?: string;
}
export interface BatchPermissionsRequestEntry {
    Id: string;
    Principal?: DataLakePrincipal;
    Resource?: Resource;
    Permissions?: Permission[];
    Condition?: Condition;
    PermissionsWithGrantOption?: Permission[];
}
export type BatchPermissionsRequestEntryList = BatchPermissionsRequestEntry[];
export interface BatchGrantPermissionsRequest {
    CatalogId?: string;
    Entries: BatchPermissionsRequestEntry[];
}
export interface BatchPermissionsFailureEntry {
    RequestEntry?: BatchPermissionsRequestEntry;
    Error?: ErrorDetail;
}
export type BatchPermissionsFailureList = BatchPermissionsFailureEntry[];
export interface BatchGrantPermissionsResponse {
    Failures?: BatchPermissionsFailureEntry[];
}
export interface BatchRevokePermissionsRequest {
    CatalogId?: string;
    Entries: BatchPermissionsRequestEntry[];
}
export interface BatchRevokePermissionsResponse {
    Failures?: BatchPermissionsFailureEntry[];
}
export type TransactionIdString = string;
export interface CancelTransactionRequest {
    TransactionId: string;
}
export interface CancelTransactionResponse {
}
export interface CommitTransactionRequest {
    TransactionId: string;
}
export type TransactionStatus = "ACTIVE" | "COMMITTED" | "ABORTED" | "COMMIT_IN_PROGRESS" | (string & {});
export interface CommitTransactionResponse {
    TransactionStatus?: TransactionStatus;
}
export type PredicateString = string;
export interface AllRowsWildcard {
}
export interface RowFilter {
    FilterExpression?: string;
    AllRowsWildcard?: AllRowsWildcard;
}
export type VersionString = string;
export interface DataCellsFilter {
    TableCatalogId: string;
    DatabaseName: string;
    TableName: string;
    Name: string;
    RowFilter?: RowFilter;
    ColumnNames?: string[];
    ColumnWildcard?: ColumnWildcard;
    VersionId?: string;
}
export interface CreateDataCellsFilterRequest {
    TableData: DataCellsFilter;
}
export interface CreateDataCellsFilterResponse {
}
export type IdentityCenterInstanceArn = string;
export type EnableStatus = "ENABLED" | "DISABLED" | (string & {});
export type ScopeTarget = string;
export type ScopeTargets = string[];
export interface ExternalFilteringConfiguration {
    Status: EnableStatus;
    AuthorizedTargets: string[];
}
export type DataLakePrincipalList = DataLakePrincipal[];
export type ServiceAuthorization = "ENABLED" | "DISABLED" | (string & {});
export interface RedshiftConnect {
    Authorization: ServiceAuthorization;
}
export type RedshiftScopeUnion = {
    RedshiftConnect: RedshiftConnect;
};
export type RedshiftServiceIntegrations = RedshiftScopeUnion[];
export type ServiceIntegrationUnion = {
    Redshift: RedshiftScopeUnion[];
};
export type ServiceIntegrationList = ServiceIntegrationUnion[];
export interface CreateLakeFormationIdentityCenterConfigurationRequest {
    CatalogId?: string;
    InstanceArn?: string;
    ExternalFiltering?: ExternalFilteringConfiguration;
    ShareRecipients?: DataLakePrincipal[];
    ServiceIntegrations?: ServiceIntegrationUnion[];
}
export type ApplicationArn = string;
export interface CreateLakeFormationIdentityCenterConfigurationResponse {
    ApplicationArn?: string;
}
export interface CreateLakeFormationOptInRequest {
    Principal: DataLakePrincipal;
    Resource: Resource;
    Condition?: Condition;
}
export interface CreateLakeFormationOptInResponse {
}
export interface CreateLFTagRequest {
    CatalogId?: string;
    TagKey: string;
    TagValues: string[];
}
export interface CreateLFTagResponse {
}
export interface CreateLFTagExpressionRequest {
    Name: string;
    Description?: string;
    CatalogId?: string;
    Expression: LFTag[];
}
export interface CreateLFTagExpressionResponse {
}
export interface DeleteDataCellsFilterRequest {
    TableCatalogId?: string;
    DatabaseName?: string;
    TableName?: string;
    Name?: string;
}
export interface DeleteDataCellsFilterResponse {
}
export interface DeleteLakeFormationIdentityCenterConfigurationRequest {
    CatalogId?: string;
}
export interface DeleteLakeFormationIdentityCenterConfigurationResponse {
}
export interface DeleteLakeFormationOptInRequest {
    Principal: DataLakePrincipal;
    Resource: Resource;
    Condition?: Condition;
}
export interface DeleteLakeFormationOptInResponse {
}
export interface DeleteLFTagRequest {
    CatalogId?: string;
    TagKey: string;
}
export interface DeleteLFTagResponse {
}
export interface DeleteLFTagExpressionRequest {
    Name: string;
    CatalogId?: string;
}
export interface DeleteLFTagExpressionResponse {
}
export type URI = string;
export type ETagString = string;
export interface VirtualObject {
    Uri: string;
    ETag?: string;
}
export type VirtualObjectList = VirtualObject[];
export interface DeleteObjectsOnCancelRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    TransactionId: string;
    Objects: VirtualObject[];
}
export interface DeleteObjectsOnCancelResponse {
}
export interface DeregisterResourceRequest {
    ResourceArn: string;
}
export interface DeregisterResourceResponse {
}
export interface DescribeLakeFormationIdentityCenterConfigurationRequest {
    CatalogId?: string;
}
export type RAMResourceShareArn = string;
export interface DescribeLakeFormationIdentityCenterConfigurationResponse {
    CatalogId?: string;
    InstanceArn?: string;
    ApplicationArn?: string;
    ExternalFiltering?: ExternalFilteringConfiguration;
    ShareRecipients?: DataLakePrincipal[];
    ServiceIntegrations?: ServiceIntegrationUnion[];
    ResourceShare?: string;
}
export interface DescribeResourceRequest {
    ResourceArn: string;
}
export type LastModifiedTimestamp = Date;
export type VerificationStatus = "VERIFIED" | "VERIFICATION_FAILED" | "NOT_VERIFIED" | (string & {});
export type AccountIdString = string;
export interface ResourceInfo {
    ResourceArn?: string;
    RoleArn?: string;
    LastModified?: Date;
    WithFederation?: boolean;
    HybridAccessEnabled?: boolean;
    WithPrivilegedAccess?: boolean;
    VerificationStatus?: VerificationStatus;
    ExpectedResourceOwnerAccount?: string;
}
export interface DescribeResourceResponse {
    ResourceInfo?: ResourceInfo;
}
export interface DescribeTransactionRequest {
    TransactionId: string;
}
export interface TransactionDescription {
    TransactionId?: string;
    TransactionStatus?: TransactionStatus;
    TransactionStartTime?: Date;
    TransactionEndTime?: Date;
}
export interface DescribeTransactionResponse {
    TransactionDescription?: TransactionDescription;
}
export interface ExtendTransactionRequest {
    TransactionId?: string;
}
export interface ExtendTransactionResponse {
}
export interface GetDataCellsFilterRequest {
    TableCatalogId: string;
    DatabaseName: string;
    TableName: string;
    Name: string;
}
export interface GetDataCellsFilterResponse {
    DataCellsFilter?: DataCellsFilter;
}
export interface GetDataLakePrincipalRequest {
}
export type IdentityString = string;
export interface GetDataLakePrincipalResponse {
    Identity?: string;
}
export interface GetDataLakeSettingsRequest {
    CatalogId?: string;
}
export interface PrincipalPermissions {
    Principal?: DataLakePrincipal;
    Permissions?: Permission[];
}
export type PrincipalPermissionsList = PrincipalPermissions[];
export type KeyString = string;
export type ParametersMapValue = string;
export type ParametersMap = {
    [key: string]: string | undefined;
};
export type TrustedResourceOwners = string[];
export type AuthorizedSessionTagValueList = string[];
export interface DataLakeSettings {
    DataLakeAdmins?: DataLakePrincipal[];
    ReadOnlyAdmins?: DataLakePrincipal[];
    CreateDatabaseDefaultPermissions?: PrincipalPermissions[];
    CreateTableDefaultPermissions?: PrincipalPermissions[];
    Parameters?: {
        [key: string]: string | undefined;
    };
    TrustedResourceOwners?: string[];
    AllowExternalDataFiltering?: boolean;
    AllowFullTableExternalDataAccess?: boolean;
    ExternalDataFilteringAllowList?: DataLakePrincipal[];
    AuthorizedSessionTagValueList?: string[];
}
export interface GetDataLakeSettingsResponse {
    DataLakeSettings?: DataLakeSettings;
}
export type Token = string;
export type PageSize = number;
export interface GetEffectivePermissionsForPathRequest {
    CatalogId?: string;
    ResourceArn: string;
    NextToken?: string;
    MaxResults?: number;
}
export type ResourceShareList = string[];
export interface DetailsMap {
    ResourceShare?: string[];
}
export interface PrincipalResourcePermissions {
    Principal?: DataLakePrincipal;
    Resource?: Resource;
    Condition?: Condition;
    Permissions?: Permission[];
    PermissionsWithGrantOption?: Permission[];
    AdditionalDetails?: DetailsMap;
    LastUpdated?: Date;
    LastUpdatedBy?: string;
}
export type PrincipalResourcePermissionsList = PrincipalResourcePermissions[];
export interface GetEffectivePermissionsForPathResponse {
    Permissions?: PrincipalResourcePermissions[];
    NextToken?: string;
}
export interface GetLFTagRequest {
    CatalogId?: string;
    TagKey: string;
}
export interface GetLFTagResponse {
    CatalogId?: string;
    TagKey?: string;
    TagValues?: string[];
}
export interface GetLFTagExpressionRequest {
    Name: string;
    CatalogId?: string;
}
export interface GetLFTagExpressionResponse {
    Name?: string;
    Description?: string;
    CatalogId?: string;
    Expression?: LFTag[];
}
export type GetQueryStateRequestQueryIdString = string;
export interface GetQueryStateRequest {
    QueryId: string;
}
export type ErrorMessageString = string;
export type QueryStateString = "PENDING" | "WORKUNITS_AVAILABLE" | "ERROR" | "FINISHED" | "EXPIRED" | (string & {});
export interface GetQueryStateResponse {
    Error?: string;
    State: QueryStateString;
}
export type GetQueryStatisticsRequestQueryIdString = string;
export interface GetQueryStatisticsRequest {
    QueryId: string;
}
export type NumberOfMilliseconds = number;
export type NumberOfBytes = number;
export type NumberOfItems = number;
export interface ExecutionStatistics {
    AverageExecutionTimeMillis?: number;
    DataScannedBytes?: number;
    WorkUnitsExecutedCount?: number;
}
export interface PlanningStatistics {
    EstimatedDataToScanBytes?: number;
    PlanningTimeMillis?: number;
    QueueTimeMillis?: number;
    WorkUnitsGeneratedCount?: number;
}
export interface GetQueryStatisticsResponse {
    ExecutionStatistics?: ExecutionStatistics;
    PlanningStatistics?: PlanningStatistics;
    QuerySubmissionTime?: Date;
}
export type BooleanNullable = boolean;
export interface GetResourceLFTagsRequest {
    CatalogId?: string;
    Resource: Resource;
    ShowAssignedLFTags?: boolean;
}
export interface ColumnLFTag {
    Name?: string;
    LFTags?: LFTagPair[];
}
export type ColumnLFTagsList = ColumnLFTag[];
export interface GetResourceLFTagsResponse {
    LFTagOnDatabase?: LFTagPair[];
    LFTagsOnTable?: LFTagPair[];
    LFTagsOnColumns?: ColumnLFTag[];
}
export type TokenString = string;
export interface GetTableObjectsRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    TransactionId?: string;
    QueryAsOfTime?: Date;
    PartitionPredicate?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type PartitionValueString = string;
export type PartitionValuesList = string[];
export type ObjectSize = number;
export interface TableObject {
    Uri?: string;
    ETag?: string;
    Size?: number;
}
export type TableObjectList = TableObject[];
export interface PartitionObjects {
    PartitionValues?: string[];
    Objects?: TableObject[];
}
export type PartitionedTableObjectsList = PartitionObjects[];
export interface GetTableObjectsResponse {
    Objects?: PartitionObjects[];
    NextToken?: string;
}
export type AuditContextString = string;
export interface AuditContext {
    AdditionalAuditContext?: string;
}
export type PathString = string;
export type PathStringList = string[];
export type CredentialsScope = "READ" | "READWRITE" | (string & {});
export interface GetTemporaryDataLocationCredentialsRequest {
    DurationSeconds?: number;
    AuditContext?: AuditContext;
    DataLocations?: string[];
    CredentialsScope?: CredentialsScope;
}
export interface TemporaryCredentials {
    AccessKeyId?: string;
    SecretAccessKey?: string | redacted.Redacted<string>;
    SessionToken?: string | redacted.Redacted<string>;
    Expiration?: Date;
}
export interface GetTemporaryDataLocationCredentialsResponse {
    Credentials?: TemporaryCredentials;
    AccessibleDataLocations?: string[];
    CredentialsScope?: CredentialsScope;
}
export type ValueString = string;
export type ValueStringList = string[];
export interface PartitionValueList {
    Values: string[];
}
export type PermissionType = "COLUMN_PERMISSION" | "CELL_FILTER_PERMISSION" | "NESTED_PERMISSION" | "NESTED_CELL_PERMISSION" | (string & {});
export type PermissionTypeList = PermissionType[];
export interface GetTemporaryGluePartitionCredentialsRequest {
    TableArn: string;
    Partition: PartitionValueList;
    Permissions?: Permission[];
    DurationSeconds?: number;
    AuditContext?: AuditContext;
    SupportedPermissionTypes?: PermissionType[];
}
export interface GetTemporaryGluePartitionCredentialsResponse {
    AccessKeyId?: string;
    SecretAccessKey?: string | redacted.Redacted<string>;
    SessionToken?: string | redacted.Redacted<string>;
    Expiration?: Date;
}
export type HashString = string;
export type NullableString = string;
export type ContextKey = string;
export type ContextValue = string;
export type AdditionalContextMap = {
    [key: string]: string | undefined;
};
export interface QuerySessionContext {
    QueryId?: string;
    QueryStartTime?: Date;
    ClusterId?: string;
    QueryAuthorizationId?: string;
    AdditionalContext?: {
        [key: string]: string | undefined;
    };
}
export interface GetTemporaryGlueTableCredentialsRequest {
    TableArn: string;
    Permissions?: Permission[];
    DurationSeconds?: number;
    AuditContext?: AuditContext;
    SupportedPermissionTypes?: PermissionType[];
    S3Path?: string;
    QuerySessionContext?: QuerySessionContext;
}
export interface GetTemporaryGlueTableCredentialsResponse {
    AccessKeyId?: string;
    SecretAccessKey?: string | redacted.Redacted<string>;
    SessionToken?: string | redacted.Redacted<string>;
    Expiration?: Date;
    VendedS3Path?: string[];
}
export type GetWorkUnitResultsRequestQueryIdString = string;
export type GetWorkUnitResultsRequestWorkUnitIdLong = number;
export type SyntheticGetWorkUnitResultsRequestWorkUnitTokenString = string | redacted.Redacted<string>;
export interface GetWorkUnitResultsRequest {
    QueryId: string;
    WorkUnitId: number;
    WorkUnitToken: string | redacted.Redacted<string>;
}
export interface GetWorkUnitResultsResponse {
    ResultStream?: T.StreamingOutputBody;
}
export type GetWorkUnitsRequestQueryIdString = string;
export interface GetWorkUnitsRequest {
    NextToken?: string;
    PageSize?: number;
    QueryId: string;
}
export type QueryIdString = string;
export type WorkUnitIdLong = number;
export type WorkUnitTokenString = string;
export interface WorkUnitRange {
    WorkUnitIdMax: number;
    WorkUnitIdMin: number;
    WorkUnitToken: string;
}
export type WorkUnitRangeList = WorkUnitRange[];
export interface GetWorkUnitsResponse {
    NextToken?: string;
    QueryId: string;
    WorkUnitRanges: WorkUnitRange[];
}
export interface GrantPermissionsRequest {
    CatalogId?: string;
    Principal: DataLakePrincipal;
    Resource: Resource;
    Permissions: Permission[];
    Condition?: Condition;
    PermissionsWithGrantOption?: Permission[];
}
export interface GrantPermissionsResponse {
}
export interface ListDataCellsFilterRequest {
    Table?: TableResource;
    NextToken?: string;
    MaxResults?: number;
}
export type DataCellsFilterList = DataCellsFilter[];
export interface ListDataCellsFilterResponse {
    DataCellsFilters?: DataCellsFilter[];
    NextToken?: string;
}
export interface ListLakeFormationOptInsRequest {
    Principal?: DataLakePrincipal;
    Resource?: Resource;
    MaxResults?: number;
    NextToken?: string;
}
export interface LakeFormationOptInsInfo {
    Resource?: Resource;
    Principal?: DataLakePrincipal;
    Condition?: Condition;
    LastModified?: Date;
    LastUpdatedBy?: string;
}
export type LakeFormationOptInsInfoList = LakeFormationOptInsInfo[];
export interface ListLakeFormationOptInsResponse {
    LakeFormationOptInsInfoList?: LakeFormationOptInsInfo[];
    NextToken?: string;
}
export interface ListLFTagExpressionsRequest {
    CatalogId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface LFTagExpression {
    Name?: string;
    Description?: string;
    CatalogId?: string;
    Expression?: LFTag[];
}
export type LFTagExpressionsList = LFTagExpression[];
export interface ListLFTagExpressionsResponse {
    LFTagExpressions?: LFTagExpression[];
    NextToken?: string;
}
export type ResourceShareType = "FOREIGN" | "ALL" | (string & {});
export interface ListLFTagsRequest {
    CatalogId?: string;
    ResourceShareType?: ResourceShareType;
    MaxResults?: number;
    NextToken?: string;
}
export interface ListLFTagsResponse {
    LFTags?: LFTagPair[];
    NextToken?: string;
}
export type DataLakeResourceType = "CATALOG" | "DATABASE" | "TABLE" | "DATA_LOCATION" | "LF_TAG" | "LF_TAG_POLICY" | "LF_TAG_POLICY_DATABASE" | "LF_TAG_POLICY_TABLE" | "LF_NAMED_TAG_EXPRESSION" | (string & {});
export type TrueFalseString = string;
export interface ListPermissionsRequest {
    CatalogId?: string;
    Principal?: DataLakePrincipal;
    ResourceType?: DataLakeResourceType;
    Resource?: Resource;
    NextToken?: string;
    MaxResults?: number;
    IncludeRelated?: string;
}
export interface ListPermissionsResponse {
    PrincipalResourcePermissions?: PrincipalResourcePermissions[];
    NextToken?: string;
}
export type FieldNameString = "RESOURCE_ARN" | "ROLE_ARN" | "LAST_MODIFIED" | (string & {});
export type ComparisonOperator = "EQ" | "NE" | "LE" | "LT" | "GE" | "GT" | "CONTAINS" | "NOT_CONTAINS" | "BEGINS_WITH" | "IN" | "BETWEEN" | (string & {});
export type StringValue = string;
export type StringValueList = string[];
export interface FilterCondition {
    Field?: FieldNameString;
    ComparisonOperator?: ComparisonOperator;
    StringValueList?: string[];
}
export type FilterConditionList = FilterCondition[];
export interface ListResourcesRequest {
    FilterConditionList?: FilterCondition[];
    MaxResults?: number;
    NextToken?: string;
}
export type ResourceInfoList = ResourceInfo[];
export interface ListResourcesResponse {
    ResourceInfoList?: ResourceInfo[];
    NextToken?: string;
}
export type OptimizerType = "COMPACTION" | "GARBAGE_COLLECTION" | "ALL" | (string & {});
export interface ListTableStorageOptimizersRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    StorageOptimizerType?: OptimizerType;
    MaxResults?: number;
    NextToken?: string;
}
export type StorageOptimizerConfigKey = string;
export type StorageOptimizerConfigValue = string;
export type StorageOptimizerConfig = {
    [key: string]: string | undefined;
};
export type MessageString = string;
export interface StorageOptimizer {
    StorageOptimizerType?: OptimizerType;
    Config?: {
        [key: string]: string | undefined;
    };
    ErrorMessage?: string;
    Warnings?: string;
    LastRunDetails?: string;
}
export type StorageOptimizerList = StorageOptimizer[];
export interface ListTableStorageOptimizersResponse {
    StorageOptimizerList?: StorageOptimizer[];
    NextToken?: string;
}
export type TransactionStatusFilter = "ALL" | "COMPLETED" | "ACTIVE" | "COMMITTED" | "ABORTED" | (string & {});
export interface ListTransactionsRequest {
    CatalogId?: string;
    StatusFilter?: TransactionStatusFilter;
    MaxResults?: number;
    NextToken?: string;
}
export type TransactionDescriptionList = TransactionDescription[];
export interface ListTransactionsResponse {
    Transactions?: TransactionDescription[];
    NextToken?: string;
}
export interface PutDataLakeSettingsRequest {
    CatalogId?: string;
    DataLakeSettings: DataLakeSettings;
}
export interface PutDataLakeSettingsResponse {
}
export interface RegisterResourceRequest {
    ResourceArn: string;
    UseServiceLinkedRole?: boolean;
    RoleArn?: string;
    WithFederation?: boolean;
    HybridAccessEnabled?: boolean;
    WithPrivilegedAccess?: boolean;
    ExpectedResourceOwnerAccount?: string;
}
export interface RegisterResourceResponse {
}
export interface RemoveLFTagsFromResourceRequest {
    CatalogId?: string;
    Resource: Resource;
    LFTags: LFTagPair[];
}
export interface RemoveLFTagsFromResourceResponse {
    Failures?: LFTagError[];
}
export interface RevokePermissionsRequest {
    CatalogId?: string;
    Principal: DataLakePrincipal;
    Resource: Resource;
    Permissions: Permission[];
    Condition?: Condition;
    PermissionsWithGrantOption?: Permission[];
}
export interface RevokePermissionsResponse {
}
export type SearchPageSize = number;
export interface SearchDatabasesByLFTagsRequest {
    NextToken?: string;
    MaxResults?: number;
    CatalogId?: string;
    Expression: LFTag[];
}
export interface TaggedDatabase {
    Database?: DatabaseResource;
    LFTags?: LFTagPair[];
}
export type DatabaseLFTagsList = TaggedDatabase[];
export interface SearchDatabasesByLFTagsResponse {
    NextToken?: string;
    DatabaseList?: TaggedDatabase[];
}
export interface SearchTablesByLFTagsRequest {
    NextToken?: string;
    MaxResults?: number;
    CatalogId?: string;
    Expression: LFTag[];
}
export interface TaggedTable {
    Table?: TableResource;
    LFTagOnDatabase?: LFTagPair[];
    LFTagsOnTable?: LFTagPair[];
    LFTagsOnColumns?: ColumnLFTag[];
}
export type TableLFTagsList = TaggedTable[];
export interface SearchTablesByLFTagsResponse {
    NextToken?: string;
    TableList?: TaggedTable[];
}
export type QueryPlanningContextDatabaseNameString = string;
export type QueryParameterMap = {
    [key: string]: string | undefined;
};
export interface QueryPlanningContext {
    CatalogId?: string;
    DatabaseName: string;
    QueryAsOfTime?: Date;
    QueryParameters?: {
        [key: string]: string | undefined;
    };
    TransactionId?: string;
}
export type SyntheticStartQueryPlanningRequestQueryString = string | redacted.Redacted<string>;
export interface StartQueryPlanningRequest {
    QueryPlanningContext: QueryPlanningContext;
    QueryString: string | redacted.Redacted<string>;
}
export interface StartQueryPlanningResponse {
    QueryId: string;
}
export type TransactionType = "READ_AND_WRITE" | "READ_ONLY" | (string & {});
export interface StartTransactionRequest {
    TransactionType?: TransactionType;
}
export interface StartTransactionResponse {
    TransactionId?: string;
}
export interface UpdateDataCellsFilterRequest {
    TableData: DataCellsFilter;
}
export interface UpdateDataCellsFilterResponse {
}
export type ApplicationStatus = "ENABLED" | "DISABLED" | (string & {});
export interface UpdateLakeFormationIdentityCenterConfigurationRequest {
    CatalogId?: string;
    ShareRecipients?: DataLakePrincipal[];
    ServiceIntegrations?: ServiceIntegrationUnion[];
    ApplicationStatus?: ApplicationStatus;
    ExternalFiltering?: ExternalFilteringConfiguration;
}
export interface UpdateLakeFormationIdentityCenterConfigurationResponse {
}
export interface UpdateLFTagRequest {
    CatalogId?: string;
    TagKey: string;
    TagValuesToDelete?: string[];
    TagValuesToAdd?: string[];
}
export interface UpdateLFTagResponse {
}
export interface UpdateLFTagExpressionRequest {
    Name: string;
    Description?: string;
    CatalogId?: string;
    Expression: LFTag[];
}
export interface UpdateLFTagExpressionResponse {
}
export interface UpdateResourceRequest {
    RoleArn: string;
    ResourceArn: string;
    WithFederation?: boolean;
    HybridAccessEnabled?: boolean;
    ExpectedResourceOwnerAccount?: string;
}
export interface UpdateResourceResponse {
}
export interface AddObjectInput {
    Uri: string;
    ETag: string;
    Size: number;
    PartitionValues?: string[];
}
export interface DeleteObjectInput {
    Uri: string;
    ETag?: string;
    PartitionValues?: string[];
}
export interface WriteOperation {
    AddObject?: AddObjectInput;
    DeleteObject?: DeleteObjectInput;
}
export type WriteOperationList = WriteOperation[];
export interface UpdateTableObjectsRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    TransactionId?: string;
    WriteOperations: WriteOperation[];
}
export interface UpdateTableObjectsResponse {
}
export type StorageOptimizerConfigMap = {
    [key in OptimizerType]?: {
        [key: string]: string | undefined;
    };
};
export interface UpdateTableStorageOptimizerRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    StorageOptimizerConfig: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
}
export type Result = string;
export interface UpdateTableStorageOptimizerResponse {
    Result?: string;
}
export type AddLFTagsToResourceError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Attaches one or more LF-tags to an existing resource.
 */
export declare const addLFTagsToResource: API.OperationMethod<AddLFTagsToResourceRequest, AddLFTagsToResourceResponse, AddLFTagsToResourceError, Credentials | HttpClient.HttpClient>;
export type AssumeDecoratedRoleWithSAMLError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Allows a caller to assume an IAM role decorated as the SAML user specified in the SAML assertion included in the request. This decoration allows Lake Formation to enforce access policies against the SAML users and groups. This API operation requires SAML federation setup in the caller's account as it can only be called with valid SAML assertions.
 * Lake Formation does not scope down the permission of the assumed role. All permissions attached to the role via the SAML federation setup will be included in the role session.
 *
 * This decorated role is expected to access data in Amazon S3 by getting temporary access from Lake Formation which is authorized via the virtual API `GetDataAccess`.
 * Therefore, all SAML roles that can be assumed via `AssumeDecoratedRoleWithSAML` must at a minimum include `lakeformation:GetDataAccess` in their role policies.
 * A typical IAM policy attached to such a role would include the following actions:
 *
 * - glue:*Database*
 *
 * - glue:*Table*
 *
 * - glue:*Partition*
 *
 * - glue:*UserDefinedFunction*
 *
 * - lakeformation:GetDataAccess
 */
export declare const assumeDecoratedRoleWithSAML: API.OperationMethod<AssumeDecoratedRoleWithSAMLRequest, AssumeDecoratedRoleWithSAMLResponse, AssumeDecoratedRoleWithSAMLError, Credentials | HttpClient.HttpClient>;
export type BatchGrantPermissionsError = InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Batch operation to grant permissions to the principal.
 */
export declare const batchGrantPermissions: API.OperationMethod<BatchGrantPermissionsRequest, BatchGrantPermissionsResponse, BatchGrantPermissionsError, Credentials | HttpClient.HttpClient>;
export type BatchRevokePermissionsError = InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Batch operation to revoke permissions from the principal.
 */
export declare const batchRevokePermissions: API.OperationMethod<BatchRevokePermissionsRequest, BatchRevokePermissionsResponse, BatchRevokePermissionsError, Credentials | HttpClient.HttpClient>;
export type CancelTransactionError = ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | TransactionCommitInProgressException | TransactionCommittedException | CommonErrors;
/**
 * Attempts to cancel the specified transaction. Returns an exception if the transaction was previously committed.
 */
export declare const cancelTransaction: API.OperationMethod<CancelTransactionRequest, CancelTransactionResponse, CancelTransactionError, Credentials | HttpClient.HttpClient>;
export type CommitTransactionError = ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | TransactionCanceledException | CommonErrors;
/**
 * Attempts to commit the specified transaction. Returns an exception if the transaction was previously aborted. This API action is idempotent if called multiple times for the same transaction.
 */
export declare const commitTransaction: API.OperationMethod<CommitTransactionRequest, CommitTransactionResponse, CommitTransactionError, Credentials | HttpClient.HttpClient>;
export type CreateDataCellsFilterError = AccessDeniedException | AlreadyExistsException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a data cell filter to allow one to grant access to certain columns on certain rows.
 */
export declare const createDataCellsFilter: API.OperationMethod<CreateDataCellsFilterRequest, CreateDataCellsFilterResponse, CreateDataCellsFilterError, Credentials | HttpClient.HttpClient>;
export type CreateLakeFormationIdentityCenterConfigurationError = AccessDeniedException | AlreadyExistsException | ConcurrentModificationException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Creates an IAM Identity Center connection with Lake Formation to allow IAM Identity Center users and groups to access Data Catalog resources.
 */
export declare const createLakeFormationIdentityCenterConfiguration: API.OperationMethod<CreateLakeFormationIdentityCenterConfigurationRequest, CreateLakeFormationIdentityCenterConfigurationResponse, CreateLakeFormationIdentityCenterConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateLakeFormationOptInError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | InvalidLakeFormationPrincipal | CommonErrors;
/**
 * Enforce Lake Formation permissions for the given databases, tables, and principals.
 */
export declare const createLakeFormationOptIn: API.OperationMethod<CreateLakeFormationOptInRequest, CreateLakeFormationOptInResponse, CreateLakeFormationOptInError, Credentials | HttpClient.HttpClient>;
export type CreateLFTagError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates an LF-tag with the specified name and values.
 */
export declare const createLFTag: API.OperationMethod<CreateLFTagRequest, CreateLFTagResponse, CreateLFTagError, Credentials | HttpClient.HttpClient>;
export type CreateLFTagExpressionError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new LF-Tag expression with the provided name, description, catalog ID, and
 * expression body. This call fails if a LF-Tag expression with the same name already exists in
 * the caller's account or if the underlying LF-Tags don't exist. To call this API operation,
 * caller needs the following Lake Formation permissions:
 *
 * `CREATE_LF_TAG_EXPRESSION` on the root catalog resource.
 *
 * `GRANT_WITH_LF_TAG_EXPRESSION` on all underlying LF-Tag key:value pairs
 * included in the expression.
 */
export declare const createLFTagExpression: API.OperationMethod<CreateLFTagExpressionRequest, CreateLFTagExpressionResponse, CreateLFTagExpressionError, Credentials | HttpClient.HttpClient>;
export type DeleteDataCellsFilterError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a data cell filter.
 */
export declare const deleteDataCellsFilter: API.OperationMethod<DeleteDataCellsFilterRequest, DeleteDataCellsFilterResponse, DeleteDataCellsFilterError, Credentials | HttpClient.HttpClient>;
export type DeleteLakeFormationIdentityCenterConfigurationError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes an IAM Identity Center connection with Lake Formation.
 */
export declare const deleteLakeFormationIdentityCenterConfiguration: API.OperationMethod<DeleteLakeFormationIdentityCenterConfigurationRequest, DeleteLakeFormationIdentityCenterConfigurationResponse, DeleteLakeFormationIdentityCenterConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteLakeFormationOptInError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | InvalidLakeFormationPrincipal | CommonErrors;
/**
 * Remove the Lake Formation permissions enforcement of the given databases, tables, and principals.
 */
export declare const deleteLakeFormationOptIn: API.OperationMethod<DeleteLakeFormationOptInRequest, DeleteLakeFormationOptInResponse, DeleteLakeFormationOptInError, Credentials | HttpClient.HttpClient>;
export type DeleteLFTagError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes an LF-tag by its key name. The operation fails if the specified tag key doesn't
 * exist. When you delete an LF-Tag:
 *
 * - The associated LF-Tag policy becomes invalid.
 *
 * - Resources that had this tag assigned will no longer have the tag policy applied to
 * them.
 */
export declare const deleteLFTag: API.OperationMethod<DeleteLFTagRequest, DeleteLFTagResponse, DeleteLFTagError, Credentials | HttpClient.HttpClient>;
export type DeleteLFTagExpressionError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes the LF-Tag expression. The caller must be a data lake admin or have `DROP` permissions on the LF-Tag expression.
 * Deleting a LF-Tag expression will also delete all `LFTagPolicy` permissions referencing the LF-Tag expression.
 */
export declare const deleteLFTagExpression: API.OperationMethod<DeleteLFTagExpressionRequest, DeleteLFTagExpressionResponse, DeleteLFTagExpressionError, Credentials | HttpClient.HttpClient>;
export type DeleteObjectsOnCancelError = ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNotReadyException | TransactionCanceledException | TransactionCommittedException | CommonErrors;
/**
 * For a specific governed table, provides a list of Amazon S3 objects that will be written during the current transaction and that can be automatically deleted
 * if the transaction is canceled. Without this call, no Amazon S3 objects are automatically deleted when a transaction cancels.
 *
 * The Glue ETL library function `write_dynamic_frame.from_catalog()` includes an option to automatically
 * call `DeleteObjectsOnCancel` before writes. For more information, see
 * Rolling Back Amazon S3 Writes.
 */
export declare const deleteObjectsOnCancel: API.OperationMethod<DeleteObjectsOnCancelRequest, DeleteObjectsOnCancelResponse, DeleteObjectsOnCancelError, Credentials | HttpClient.HttpClient>;
export type DeregisterResourceError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | LastServiceLinkedRoleRegistration | CommonErrors;
/**
 * Deregisters the resource as managed by the Data Catalog.
 *
 * When you deregister a path, Lake Formation removes the path from the inline policy attached to your service-linked role.
 */
export declare const deregisterResource: API.OperationMethod<DeregisterResourceRequest, DeregisterResourceResponse, DeregisterResourceError, Credentials | HttpClient.HttpClient>;
export type DescribeLakeFormationIdentityCenterConfigurationError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the instance ARN and application ARN for the connection.
 */
export declare const describeLakeFormationIdentityCenterConfiguration: API.OperationMethod<DescribeLakeFormationIdentityCenterConfigurationRequest, DescribeLakeFormationIdentityCenterConfigurationResponse, DescribeLakeFormationIdentityCenterConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeResourceError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the current data access role for the given resource registered in Lake Formation.
 */
export declare const describeResource: API.OperationMethod<DescribeResourceRequest, DescribeResourceResponse, DescribeResourceError, Credentials | HttpClient.HttpClient>;
export type DescribeTransactionError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns the details of a single transaction.
 */
export declare const describeTransaction: API.OperationMethod<DescribeTransactionRequest, DescribeTransactionResponse, DescribeTransactionError, Credentials | HttpClient.HttpClient>;
export type ExtendTransactionError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | TransactionCanceledException | TransactionCommitInProgressException | TransactionCommittedException | CommonErrors;
/**
 * Indicates to the service that the specified transaction is still active and should not be treated as idle and aborted.
 *
 * Write transactions that remain idle for a long period are automatically aborted unless explicitly extended.
 */
export declare const extendTransaction: API.OperationMethod<ExtendTransactionRequest, ExtendTransactionResponse, ExtendTransactionError, Credentials | HttpClient.HttpClient>;
export type GetDataCellsFilterError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns a data cells filter.
 */
export declare const getDataCellsFilter: API.OperationMethod<GetDataCellsFilterRequest, GetDataCellsFilterResponse, GetDataCellsFilterError, Credentials | HttpClient.HttpClient>;
export type GetDataLakePrincipalError = AccessDeniedException | InternalServiceException | OperationTimeoutException | CommonErrors;
/**
 * Returns the identity of the invoking principal.
 */
export declare const getDataLakePrincipal: API.OperationMethod<GetDataLakePrincipalRequest, GetDataLakePrincipalResponse, GetDataLakePrincipalError, Credentials | HttpClient.HttpClient>;
export type GetDataLakeSettingsError = EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Retrieves the list of the data lake administrators of a Lake Formation-managed data lake.
 */
export declare const getDataLakeSettings: API.OperationMethod<GetDataLakeSettingsRequest, GetDataLakeSettingsResponse, GetDataLakeSettingsError, Credentials | HttpClient.HttpClient>;
export type GetEffectivePermissionsForPathError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns the Lake Formation permissions for a specified table or database resource located
 * at a path in Amazon S3. `GetEffectivePermissionsForPath` will not return databases and tables if the catalog is encrypted.
 */
export declare const getEffectivePermissionsForPath: API.PaginatedOperationMethod<GetEffectivePermissionsForPathRequest, GetEffectivePermissionsForPathResponse, GetEffectivePermissionsForPathError, Credentials | HttpClient.HttpClient, unknown>;
export type GetLFTagError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns an LF-tag definition.
 */
export declare const getLFTag: API.OperationMethod<GetLFTagRequest, GetLFTagResponse, GetLFTagError, Credentials | HttpClient.HttpClient>;
export type GetLFTagExpressionError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns the details about the LF-Tag expression. The caller must be a data lake admin or must have `DESCRIBE` permission on the LF-Tag expression resource.
 */
export declare const getLFTagExpression: API.OperationMethod<GetLFTagExpressionRequest, GetLFTagExpressionResponse, GetLFTagExpressionError, Credentials | HttpClient.HttpClient>;
export type GetQueryStateError = AccessDeniedException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Returns the state of a query previously submitted. Clients are expected to poll `GetQueryState` to monitor the current state of the planning before retrieving the work units. A query state is only visible to the principal that made the initial call to `StartQueryPlanning`.
 */
export declare const getQueryState: API.OperationMethod<GetQueryStateRequest, GetQueryStateResponse, GetQueryStateError, Credentials | HttpClient.HttpClient>;
export type GetQueryStatisticsError = AccessDeniedException | ExpiredException | InternalServiceException | InvalidInputException | StatisticsNotReadyYetException | ThrottledException | CommonErrors;
/**
 * Retrieves statistics on the planning and execution of a query.
 */
export declare const getQueryStatistics: API.OperationMethod<GetQueryStatisticsRequest, GetQueryStatisticsResponse, GetQueryStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetResourceLFTagsError = AccessDeniedException | EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns the LF-tags applied to a resource.
 */
export declare const getResourceLFTags: API.OperationMethod<GetResourceLFTagsRequest, GetResourceLFTagsResponse, GetResourceLFTagsError, Credentials | HttpClient.HttpClient>;
export type GetTableObjectsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNotReadyException | TransactionCanceledException | TransactionCommittedException | CommonErrors;
/**
 * Returns the set of Amazon S3 objects that make up the specified governed table. A transaction ID or timestamp can be specified for time-travel queries.
 */
export declare const getTableObjects: API.PaginatedOperationMethod<GetTableObjectsRequest, GetTableObjectsResponse, GetTableObjectsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetTemporaryDataLocationCredentialsError = AccessDeniedException | ConflictException | EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Allows a user or application in a secure environment to access data in a specific Amazon S3 location registered with Lake Formation by providing temporary scoped credentials that are limited to the requested data location and
 * the caller's authorized access level.
 *
 * `GetDataAccess` is logged in CloudTrail whenever a principal requests temporary data location credentials to access data in a data lake location that is registered with Lake Formation.
 *
 * The API operation returns an error in the following scenarios:
 *
 * - The data location is not registered with Lake Formation.
 *
 * - No Glue table is associated with the data location.
 *
 * - The caller doesn't have required permissions on the associated table. The caller must have
 * `SELECT` or `SUPER` permissions on the associated table, and
 * credential vending for full table access must be enabled in the data lake settings.
 *
 * For more information, see Application integration for full table access.
 *
 * - The data location is in a different Amazon Web Services Region. Lake Formation doesn't
 * support cross-Region access when vending credentials for a data location. Lake Formation only supports Amazon S3 paths registered within the same Region as the API
 * call.
 */
export declare const getTemporaryDataLocationCredentials: API.OperationMethod<GetTemporaryDataLocationCredentialsRequest, GetTemporaryDataLocationCredentialsResponse, GetTemporaryDataLocationCredentialsError, Credentials | HttpClient.HttpClient>;
export type GetTemporaryGluePartitionCredentialsError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | PermissionTypeMismatchException | CommonErrors;
/**
 * This API is identical to `GetTemporaryTableCredentials` except that this is used when the target Data Catalog resource is of type Partition. Lake Formation restricts the permission of the vended credentials with the same scope down policy which restricts access to a single Amazon S3 prefix.
 */
export declare const getTemporaryGluePartitionCredentials: API.OperationMethod<GetTemporaryGluePartitionCredentialsRequest, GetTemporaryGluePartitionCredentialsResponse, GetTemporaryGluePartitionCredentialsError, Credentials | HttpClient.HttpClient>;
export type GetTemporaryGlueTableCredentialsError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | PermissionTypeMismatchException | CommonErrors;
/**
 * Allows a caller in a secure environment to assume a role with permission to access Amazon S3. In order to vend such credentials, Lake Formation assumes the role associated with a registered location, for example an Amazon S3 bucket, with a scope down policy which restricts the access to a single prefix.
 *
 * To call this API, the role that the service assumes must have `lakeformation:GetDataAccess` permission on the resource.
 */
export declare const getTemporaryGlueTableCredentials: API.OperationMethod<GetTemporaryGlueTableCredentialsRequest, GetTemporaryGlueTableCredentialsResponse, GetTemporaryGlueTableCredentialsError, Credentials | HttpClient.HttpClient>;
export type GetWorkUnitResultsError = AccessDeniedException | ExpiredException | InternalServiceException | InvalidInputException | ThrottledException | CommonErrors;
/**
 * Returns the work units resulting from the query. Work units can be executed in any order and in parallel.
 */
export declare const getWorkUnitResults: API.OperationMethod<GetWorkUnitResultsRequest, GetWorkUnitResultsResponse, GetWorkUnitResultsError, Credentials | HttpClient.HttpClient>;
export type GetWorkUnitsError = AccessDeniedException | ExpiredException | InternalServiceException | InvalidInputException | WorkUnitsNotReadyYetException | CommonErrors;
/**
 * Retrieves the work units generated by the `StartQueryPlanning` operation.
 */
export declare const getWorkUnits: API.PaginatedOperationMethod<GetWorkUnitsRequest, GetWorkUnitsResponse, GetWorkUnitsError, Credentials | HttpClient.HttpClient, WorkUnitRange>;
export type GrantPermissionsError = ConcurrentModificationException | EntityNotFoundException | InvalidInputException | InvalidLakeFormationPrincipal | CommonErrors;
/**
 * Grants permissions to the principal to access metadata in the Data Catalog and data organized in underlying data storage such as Amazon S3.
 *
 * For information about permissions, see Security and Access Control to Metadata and Data.
 */
export declare const grantPermissions: API.OperationMethod<GrantPermissionsRequest, GrantPermissionsResponse, GrantPermissionsError, Credentials | HttpClient.HttpClient>;
export type ListDataCellsFilterError = AccessDeniedException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Lists all the data cell filters on a table.
 */
export declare const listDataCellsFilter: API.PaginatedOperationMethod<ListDataCellsFilterRequest, ListDataCellsFilterResponse, ListDataCellsFilterError, Credentials | HttpClient.HttpClient, DataCellsFilter>;
export type ListLakeFormationOptInsError = AccessDeniedException | InternalServiceException | InvalidInputException | OperationTimeoutException | EntityNotFoundException | InvalidLakeFormationPrincipal | CommonErrors;
/**
 * Retrieve the current list of resources and principals that are opt in to enforce Lake Formation permissions.
 */
export declare const listLakeFormationOptIns: API.PaginatedOperationMethod<ListLakeFormationOptInsRequest, ListLakeFormationOptInsResponse, ListLakeFormationOptInsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListLFTagExpressionsError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns the LF-Tag expressions in caller's account filtered based on caller's permissions. Data Lake and read only admins implicitly can see all tag expressions in their account, else caller needs DESCRIBE permissions on tag expression.
 */
export declare const listLFTagExpressions: API.PaginatedOperationMethod<ListLFTagExpressionsRequest, ListLFTagExpressionsResponse, ListLFTagExpressionsError, Credentials | HttpClient.HttpClient, LFTagExpression>;
export type ListLFTagsError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Lists LF-tags that the requester has permission to view.
 */
export declare const listLFTags: API.PaginatedOperationMethod<ListLFTagsRequest, ListLFTagsResponse, ListLFTagsError, Credentials | HttpClient.HttpClient, LFTagPair>;
export type ListPermissionsError = InternalServiceException | InvalidInputException | OperationTimeoutException | InvalidLakeFormationPrincipal | CommonErrors;
/**
 * Returns a list of the principal permissions on the resource, filtered by the permissions of the caller. For example, if you are granted an ALTER permission, you are able to see only the principal permissions for ALTER.
 *
 * This operation returns only those permissions that have been explicitly granted. If both
 * `Principal` and `Resource` parameters are provided, the response
 * returns effective permissions rather than the explicitly granted permissions.
 *
 * For information about permissions, see Security and Access Control to Metadata and Data.
 */
export declare const listPermissions: API.PaginatedOperationMethod<ListPermissionsRequest, ListPermissionsResponse, ListPermissionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListResourcesError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Lists the resources registered to be managed by the Data Catalog.
 */
export declare const listResources: API.PaginatedOperationMethod<ListResourcesRequest, ListResourcesResponse, ListResourcesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTableStorageOptimizersError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Returns the configuration of all storage optimizers associated with a specified table.
 */
export declare const listTableStorageOptimizers: API.PaginatedOperationMethod<ListTableStorageOptimizersRequest, ListTableStorageOptimizersResponse, ListTableStorageOptimizersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTransactionsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns metadata about transactions and their status. To prevent the response from growing indefinitely, only uncommitted transactions and those available for time-travel queries are returned.
 *
 * This operation can help you identify uncommitted transactions or to get information about transactions.
 */
export declare const listTransactions: API.PaginatedOperationMethod<ListTransactionsRequest, ListTransactionsResponse, ListTransactionsError, Credentials | HttpClient.HttpClient, unknown>;
export type PutDataLakeSettingsError = InternalServiceException | InvalidInputException | InvalidLakeFormationPrincipal | CommonErrors;
/**
 * Sets the list of data lake administrators who have admin privileges on all resources managed by Lake Formation. For more information on admin privileges, see Granting Lake Formation Permissions.
 *
 * This API replaces the current list of data lake admins with the new list being passed. To add an admin, fetch the current list and add the new admin to that list and pass that list in this API.
 */
export declare const putDataLakeSettings: API.OperationMethod<PutDataLakeSettingsRequest, PutDataLakeSettingsResponse, PutDataLakeSettingsError, Credentials | HttpClient.HttpClient>;
export type RegisterResourceError = AccessDeniedException | AlreadyExistsException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Registers the resource as managed by the Data Catalog.
 *
 * To add or update data, Lake Formation needs read/write access to the chosen data location. Choose a role that you know has permission to do this, or choose the AWSServiceRoleForLakeFormationDataAccess service-linked role. When you register the first Amazon S3 path, the service-linked role and a new inline policy are created on your behalf. Lake Formation adds the first path to the inline policy and attaches it to the service-linked role. When you register subsequent paths, Lake Formation adds the path to the existing policy.
 *
 * The following request registers a new location and gives Lake Formation permission to use the service-linked role to access that location.
 *
 * ResourceArn = arn:aws:s3:::my-bucket/
 * UseServiceLinkedRole = true
 *
 * If `UseServiceLinkedRole` is not set to true, you must provide or set the `RoleArn`:
 *
 * `arn:aws:iam::12345:role/my-data-access-role`
 */
export declare const registerResource: API.OperationMethod<RegisterResourceRequest, RegisterResourceResponse, RegisterResourceError, Credentials | HttpClient.HttpClient>;
export type RemoveLFTagsFromResourceError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Removes an LF-tag from the resource. Only database, table, or tableWithColumns resource are allowed. To tag columns, use the column inclusion list in `tableWithColumns` to specify column input.
 */
export declare const removeLFTagsFromResource: API.OperationMethod<RemoveLFTagsFromResourceRequest, RemoveLFTagsFromResourceResponse, RemoveLFTagsFromResourceError, Credentials | HttpClient.HttpClient>;
export type RevokePermissionsError = ConcurrentModificationException | EntityNotFoundException | InvalidInputException | InvalidLakeFormationPrincipal | CommonErrors;
/**
 * Revokes permissions to the principal to access metadata in the Data Catalog and data organized in underlying data storage such as Amazon S3.
 */
export declare const revokePermissions: API.OperationMethod<RevokePermissionsRequest, RevokePermissionsResponse, RevokePermissionsError, Credentials | HttpClient.HttpClient>;
export type SearchDatabasesByLFTagsError = AccessDeniedException | EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * This operation allows a search on `DATABASE` resources by `TagCondition`. This operation is used by admins who want to grant user permissions on certain `TagConditions`. Before making a grant, the admin can use `SearchDatabasesByTags` to find all resources where the given `TagConditions` are valid to verify whether the returned resources can be shared.
 */
export declare const searchDatabasesByLFTags: API.PaginatedOperationMethod<SearchDatabasesByLFTagsRequest, SearchDatabasesByLFTagsResponse, SearchDatabasesByLFTagsError, Credentials | HttpClient.HttpClient, TaggedDatabase>;
export type SearchTablesByLFTagsError = AccessDeniedException | EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * This operation allows a search on `TABLE` resources by `LFTag`s. This will be used by admins who want to grant user permissions on certain LF-tags. Before making a grant, the admin can use `SearchTablesByLFTags` to find all resources where the given `LFTag`s are valid to verify whether the returned resources can be shared.
 */
export declare const searchTablesByLFTags: API.PaginatedOperationMethod<SearchTablesByLFTagsRequest, SearchTablesByLFTagsResponse, SearchTablesByLFTagsError, Credentials | HttpClient.HttpClient, TaggedTable>;
export type StartQueryPlanningError = AccessDeniedException | InternalServiceException | InvalidInputException | ThrottledException | CommonErrors;
/**
 * Submits a request to process a query statement.
 *
 * This operation generates work units that can be retrieved with the `GetWorkUnits` operation as soon as the query state is WORKUNITS_AVAILABLE or FINISHED.
 */
export declare const startQueryPlanning: API.OperationMethod<StartQueryPlanningRequest, StartQueryPlanningResponse, StartQueryPlanningError, Credentials | HttpClient.HttpClient>;
export type StartTransactionError = InternalServiceException | OperationTimeoutException | CommonErrors;
/**
 * Starts a new transaction and returns its transaction ID. Transaction IDs are opaque objects that you can use to identify a transaction.
 */
export declare const startTransaction: API.OperationMethod<StartTransactionRequest, StartTransactionResponse, StartTransactionError, Credentials | HttpClient.HttpClient>;
export type UpdateDataCellsFilterError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates a data cell filter.
 */
export declare const updateDataCellsFilter: API.OperationMethod<UpdateDataCellsFilterRequest, UpdateDataCellsFilterResponse, UpdateDataCellsFilterError, Credentials | HttpClient.HttpClient>;
export type UpdateLakeFormationIdentityCenterConfigurationError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates the IAM Identity Center connection parameters.
 */
export declare const updateLakeFormationIdentityCenterConfiguration: API.OperationMethod<UpdateLakeFormationIdentityCenterConfigurationRequest, UpdateLakeFormationIdentityCenterConfigurationResponse, UpdateLakeFormationIdentityCenterConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateLFTagError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates the list of possible values for the specified LF-tag key. If the LF-tag does not exist, the operation throws an EntityNotFoundException. The values in the delete key values will be deleted from list of possible values. If any value in the delete key values is attached to a resource, then API errors out with a 400 Exception - "Update not allowed". Untag the attribute before deleting the LF-tag key's value.
 */
export declare const updateLFTag: API.OperationMethod<UpdateLFTagRequest, UpdateLFTagResponse, UpdateLFTagError, Credentials | HttpClient.HttpClient>;
export type UpdateLFTagExpressionError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Updates the name of the LF-Tag expression to the new description and expression body provided.
 * Updating a LF-Tag expression immediately changes the permission boundaries of all existing `LFTagPolicy` permission grants that reference the given LF-Tag expression.
 */
export declare const updateLFTagExpression: API.OperationMethod<UpdateLFTagExpressionRequest, UpdateLFTagExpressionResponse, UpdateLFTagExpressionError, Credentials | HttpClient.HttpClient>;
export type UpdateResourceError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates the data access role used for vending access to the given (registered) resource in Lake Formation.
 */
export declare const updateResource: API.OperationMethod<UpdateResourceRequest, UpdateResourceResponse, UpdateResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateTableObjectsError = ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNotReadyException | TransactionCanceledException | TransactionCommitInProgressException | TransactionCommittedException | CommonErrors;
/**
 * Updates the manifest of Amazon S3 objects that make up the specified governed table.
 */
export declare const updateTableObjects: API.OperationMethod<UpdateTableObjectsRequest, UpdateTableObjectsResponse, UpdateTableObjectsError, Credentials | HttpClient.HttpClient>;
export type UpdateTableStorageOptimizerError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Updates the configuration of the storage optimizers for a table.
 */
export declare const updateTableStorageOptimizer: API.OperationMethod<UpdateTableStorageOptimizerRequest, UpdateTableStorageOptimizerResponse, UpdateTableStorageOptimizerError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=lakeformation.d.ts.map