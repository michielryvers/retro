import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConcurrentUpdateException_base: S.TaggedErrorClass<"ConcurrentUpdateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ConcurrentUpdateException extends /*@__PURE__*/ ConcurrentUpdateException_base {
}
declare const FailedResourceAccessException_base: S.TaggedErrorClass<"FailedResourceAccessException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class FailedResourceAccessException extends /*@__PURE__*/ FailedResourceAccessException_base {
}
declare const InternalServiceException_base: S.TaggedErrorClass<"InternalServiceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServiceException extends /*@__PURE__*/ InternalServiceException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ObjectNotFoundException_base: S.TaggedErrorClass<"ObjectNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ObjectNotFoundException extends /*@__PURE__*/ ObjectNotFoundException_base {
}
declare const PredictiveScalingForecastNotSupported_base: S.TaggedErrorClass<"PredictiveScalingForecastNotSupported", {
    readonly message: any;
}>;
export declare class PredictiveScalingForecastNotSupported extends /*@__PURE__*/ PredictiveScalingForecastNotSupported_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
    readonly ResourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ResourceIdMaxLen1600 = string;
export type ServiceNamespace = "ecs" | "elasticmapreduce" | "ec2" | "appstream" | "dynamodb" | "rds" | "sagemaker" | "custom-resource" | "comprehend" | "lambda" | "cassandra" | "kafka" | "elasticache" | "neptune" | "workspaces" | (string & {});
export type ScalableDimension = "ecs:service:DesiredCount" | "ec2:spot-fleet-request:TargetCapacity" | "elasticmapreduce:instancegroup:InstanceCount" | "appstream:fleet:DesiredCapacity" | "dynamodb:table:ReadCapacityUnits" | "dynamodb:table:WriteCapacityUnits" | "dynamodb:index:ReadCapacityUnits" | "dynamodb:index:WriteCapacityUnits" | "rds:cluster:ReadReplicaCount" | "sagemaker:variant:DesiredInstanceCount" | "custom-resource:ResourceType:Property" | "comprehend:document-classifier-endpoint:DesiredInferenceUnits" | "comprehend:entity-recognizer-endpoint:DesiredInferenceUnits" | "lambda:function:ProvisionedConcurrency" | "cassandra:table:ReadCapacityUnits" | "cassandra:table:WriteCapacityUnits" | "kafka:broker-storage:VolumeSize" | "elasticache:cache-cluster:Nodes" | "elasticache:replication-group:NodeGroups" | "elasticache:replication-group:Replicas" | "neptune:cluster:ReadReplicaCount" | "sagemaker:variant:DesiredProvisionedConcurrency" | "sagemaker:inference-component:DesiredCopyCount" | "workspaces:workspacespool:DesiredUserSessions" | (string & {});
export interface DeleteScalingPolicyRequest {
    PolicyName: string;
    ServiceNamespace: ServiceNamespace;
    ResourceId: string;
    ScalableDimension: ScalableDimension;
}
export interface DeleteScalingPolicyResponse {
}
export interface DeleteScheduledActionRequest {
    ServiceNamespace: ServiceNamespace;
    ScheduledActionName: string;
    ResourceId: string;
    ScalableDimension: ScalableDimension;
}
export interface DeleteScheduledActionResponse {
}
export interface DeregisterScalableTargetRequest {
    ServiceNamespace: ServiceNamespace;
    ResourceId: string;
    ScalableDimension: ScalableDimension;
}
export interface DeregisterScalableTargetResponse {
}
export type ResourceIdsMaxLen1600 = string[];
export type MaxResults = number;
export type XmlString = string;
export interface DescribeScalableTargetsRequest {
    ServiceNamespace: ServiceNamespace;
    ResourceIds?: string[];
    ScalableDimension?: ScalableDimension;
    MaxResults?: number;
    NextToken?: string;
}
export type ResourceCapacity = number;
export type ScalingSuspended = boolean;
export interface SuspendedState {
    DynamicScalingInSuspended?: boolean;
    DynamicScalingOutSuspended?: boolean;
    ScheduledScalingSuspended?: boolean;
}
export interface ScalableTarget {
    ServiceNamespace: ServiceNamespace;
    ResourceId: string;
    ScalableDimension: ScalableDimension;
    MinCapacity: number;
    MaxCapacity: number;
    PredictedCapacity?: number;
    RoleARN: string;
    CreationTime: Date;
    SuspendedState?: SuspendedState;
    ScalableTargetARN?: string;
}
export type ScalableTargets = ScalableTarget[];
export interface DescribeScalableTargetsResponse {
    ScalableTargets?: ScalableTarget[];
    NextToken?: string;
}
export type IncludeNotScaledActivities = boolean;
export interface DescribeScalingActivitiesRequest {
    ServiceNamespace: ServiceNamespace;
    ResourceId?: string;
    ScalableDimension?: ScalableDimension;
    MaxResults?: number;
    NextToken?: string;
    IncludeNotScaledActivities?: boolean;
}
export type ResourceId = string;
export type ScalingActivityStatusCode = "Pending" | "InProgress" | "Successful" | "Overridden" | "Unfulfilled" | "Failed" | (string & {});
export interface NotScaledReason {
    Code: string;
    MaxCapacity?: number;
    MinCapacity?: number;
    CurrentCapacity?: number;
}
export type NotScaledReasons = NotScaledReason[];
export interface ScalingActivity {
    ActivityId: string;
    ServiceNamespace: ServiceNamespace;
    ResourceId: string;
    ScalableDimension: ScalableDimension;
    Description: string;
    Cause: string;
    StartTime: Date;
    EndTime?: Date;
    StatusCode: ScalingActivityStatusCode;
    StatusMessage?: string;
    Details?: string;
    NotScaledReasons?: NotScaledReason[];
}
export type ScalingActivities = ScalingActivity[];
export interface DescribeScalingActivitiesResponse {
    ScalingActivities?: ScalingActivity[];
    NextToken?: string;
}
export interface DescribeScalingPoliciesRequest {
    PolicyNames?: string[];
    ServiceNamespace: ServiceNamespace;
    ResourceId?: string;
    ScalableDimension?: ScalableDimension;
    MaxResults?: number;
    NextToken?: string;
}
export type PolicyName = string;
export type PolicyType = "StepScaling" | "TargetTrackingScaling" | "PredictiveScaling" | (string & {});
export type AdjustmentType = "ChangeInCapacity" | "PercentChangeInCapacity" | "ExactCapacity" | (string & {});
export type MetricScale = number;
export type ScalingAdjustment = number;
export interface StepAdjustment {
    MetricIntervalLowerBound?: number;
    MetricIntervalUpperBound?: number;
    ScalingAdjustment: number;
}
export type StepAdjustments = StepAdjustment[];
export type MinAdjustmentMagnitude = number;
export type Cooldown = number;
export type MetricAggregationType = "Average" | "Minimum" | "Maximum" | (string & {});
export interface StepScalingPolicyConfiguration {
    AdjustmentType?: AdjustmentType;
    StepAdjustments?: StepAdjustment[];
    MinAdjustmentMagnitude?: number;
    Cooldown?: number;
    MetricAggregationType?: MetricAggregationType;
}
export type MetricType = "DynamoDBReadCapacityUtilization" | "DynamoDBWriteCapacityUtilization" | "ALBRequestCountPerTarget" | "RDSReaderAverageCPUUtilization" | "RDSReaderAverageDatabaseConnections" | "EC2SpotFleetRequestAverageCPUUtilization" | "EC2SpotFleetRequestAverageNetworkIn" | "EC2SpotFleetRequestAverageNetworkOut" | "SageMakerVariantInvocationsPerInstance" | "ECSServiceAverageCPUUtilization" | "ECSServiceAverageMemoryUtilization" | "AppStreamAverageCapacityUtilization" | "ComprehendInferenceUtilization" | "LambdaProvisionedConcurrencyUtilization" | "CassandraReadCapacityUtilization" | "CassandraWriteCapacityUtilization" | "KafkaBrokerStorageUtilization" | "ElastiCacheEngineCPUUtilization" | "ElastiCacheDatabaseMemoryUsagePercentage" | "ElastiCachePrimaryEngineCPUUtilization" | "ElastiCacheReplicaEngineCPUUtilization" | "ElastiCacheDatabaseMemoryUsageCountedForEvictPercentage" | "NeptuneReaderAverageCPUUtilization" | "SageMakerVariantProvisionedConcurrencyUtilization" | "ElastiCacheDatabaseCapacityUsageCountedForEvictPercentage" | "SageMakerInferenceComponentInvocationsPerCopy" | "WorkSpacesAverageUserSessionsCapacityUtilization" | "SageMakerInferenceComponentConcurrentRequestsPerCopyHighResolution" | "SageMakerVariantConcurrentRequestsPerModelHighResolution" | "ECSServiceAverageCPUUtilizationHighResolution" | "ECSServiceAverageMemoryUtilizationHighResolution" | (string & {});
export type ResourceLabel = string;
export interface PredefinedMetricSpecification {
    PredefinedMetricType: MetricType;
    ResourceLabel?: string;
}
export type MetricName = string;
export type MetricNamespace = string;
export type MetricDimensionName = string;
export type MetricDimensionValue = string;
export interface MetricDimension {
    Name: string;
    Value: string;
}
export type MetricDimensions = MetricDimension[];
export type MetricStatistic = "Average" | "Minimum" | "Maximum" | "SampleCount" | "Sum" | (string & {});
export type MetricUnit = string;
export type Expression = string;
export type Id = string;
export type TargetTrackingMetricDimensionName = string;
export type TargetTrackingMetricDimensionValue = string;
export interface TargetTrackingMetricDimension {
    Name: string;
    Value: string;
}
export type TargetTrackingMetricDimensions = TargetTrackingMetricDimension[];
export type TargetTrackingMetricName = string;
export type TargetTrackingMetricNamespace = string;
export interface TargetTrackingMetric {
    Dimensions?: TargetTrackingMetricDimension[];
    MetricName?: string;
    Namespace?: string;
}
export type TargetTrackingMetricUnit = string;
export interface TargetTrackingMetricStat {
    Metric: TargetTrackingMetric;
    Stat: string;
    Unit?: string;
}
export type ReturnData = boolean;
export interface TargetTrackingMetricDataQuery {
    Expression?: string;
    Id: string;
    Label?: string;
    MetricStat?: TargetTrackingMetricStat;
    ReturnData?: boolean;
}
export type TargetTrackingMetricDataQueries = TargetTrackingMetricDataQuery[];
export interface CustomizedMetricSpecification {
    MetricName?: string;
    Namespace?: string;
    Dimensions?: MetricDimension[];
    Statistic?: MetricStatistic;
    Unit?: string;
    Metrics?: TargetTrackingMetricDataQuery[];
}
export type DisableScaleIn = boolean;
export interface TargetTrackingScalingPolicyConfiguration {
    TargetValue: number;
    PredefinedMetricSpecification?: PredefinedMetricSpecification;
    CustomizedMetricSpecification?: CustomizedMetricSpecification;
    ScaleOutCooldown?: number;
    ScaleInCooldown?: number;
    DisableScaleIn?: boolean;
}
export type PredictiveScalingMetricType = string;
export interface PredictiveScalingPredefinedMetricPairSpecification {
    PredefinedMetricType: string;
    ResourceLabel?: string;
}
export interface PredictiveScalingPredefinedScalingMetricSpecification {
    PredefinedMetricType: string;
    ResourceLabel?: string;
}
export interface PredictiveScalingPredefinedLoadMetricSpecification {
    PredefinedMetricType: string;
    ResourceLabel?: string;
}
export type PredictiveScalingMetricDimensionName = string;
export type PredictiveScalingMetricDimensionValue = string;
export interface PredictiveScalingMetricDimension {
    Name: string;
    Value: string;
}
export type PredictiveScalingMetricDimensions = PredictiveScalingMetricDimension[];
export type PredictiveScalingMetricName = string;
export type PredictiveScalingMetricNamespace = string;
export interface PredictiveScalingMetric {
    Dimensions?: PredictiveScalingMetricDimension[];
    MetricName?: string;
    Namespace?: string;
}
export type PredictiveScalingMetricUnit = string;
export interface PredictiveScalingMetricStat {
    Metric: PredictiveScalingMetric;
    Stat: string;
    Unit?: string;
}
export interface PredictiveScalingMetricDataQuery {
    Id: string;
    Expression?: string;
    MetricStat?: PredictiveScalingMetricStat;
    Label?: string;
    ReturnData?: boolean;
}
export type PredictiveScalingMetricDataQueries = PredictiveScalingMetricDataQuery[];
export interface PredictiveScalingCustomizedMetricSpecification {
    MetricDataQueries: PredictiveScalingMetricDataQuery[];
}
export interface PredictiveScalingMetricSpecification {
    TargetValue: number;
    PredefinedMetricPairSpecification?: PredictiveScalingPredefinedMetricPairSpecification;
    PredefinedScalingMetricSpecification?: PredictiveScalingPredefinedScalingMetricSpecification;
    PredefinedLoadMetricSpecification?: PredictiveScalingPredefinedLoadMetricSpecification;
    CustomizedScalingMetricSpecification?: PredictiveScalingCustomizedMetricSpecification;
    CustomizedLoadMetricSpecification?: PredictiveScalingCustomizedMetricSpecification;
    CustomizedCapacityMetricSpecification?: PredictiveScalingCustomizedMetricSpecification;
}
export type PredictiveScalingMetricSpecifications = PredictiveScalingMetricSpecification[];
export type PredictiveScalingMode = "ForecastOnly" | "ForecastAndScale" | (string & {});
export type PredictiveScalingSchedulingBufferTime = number;
export type PredictiveScalingMaxCapacityBreachBehavior = "HonorMaxCapacity" | "IncreaseMaxCapacity" | (string & {});
export type PredictiveScalingMaxCapacityBuffer = number;
export interface PredictiveScalingPolicyConfiguration {
    MetricSpecifications: PredictiveScalingMetricSpecification[];
    Mode?: PredictiveScalingMode;
    SchedulingBufferTime?: number;
    MaxCapacityBreachBehavior?: PredictiveScalingMaxCapacityBreachBehavior;
    MaxCapacityBuffer?: number;
}
export interface Alarm {
    AlarmName: string;
    AlarmARN: string;
}
export type Alarms = Alarm[];
export interface ScalingPolicy {
    PolicyARN: string;
    PolicyName: string;
    ServiceNamespace: ServiceNamespace;
    ResourceId: string;
    ScalableDimension: ScalableDimension;
    PolicyType: PolicyType;
    StepScalingPolicyConfiguration?: StepScalingPolicyConfiguration;
    TargetTrackingScalingPolicyConfiguration?: TargetTrackingScalingPolicyConfiguration;
    PredictiveScalingPolicyConfiguration?: PredictiveScalingPolicyConfiguration;
    Alarms?: Alarm[];
    CreationTime: Date;
}
export type ScalingPolicies = ScalingPolicy[];
export interface DescribeScalingPoliciesResponse {
    ScalingPolicies?: ScalingPolicy[];
    NextToken?: string;
}
export interface DescribeScheduledActionsRequest {
    ScheduledActionNames?: string[];
    ServiceNamespace: ServiceNamespace;
    ResourceId?: string;
    ScalableDimension?: ScalableDimension;
    MaxResults?: number;
    NextToken?: string;
}
export type ScheduledActionName = string;
export interface ScalableTargetAction {
    MinCapacity?: number;
    MaxCapacity?: number;
}
export interface ScheduledAction {
    ScheduledActionName: string;
    ScheduledActionARN: string;
    ServiceNamespace: ServiceNamespace;
    Schedule: string;
    Timezone?: string;
    ResourceId: string;
    ScalableDimension: ScalableDimension;
    StartTime?: Date;
    EndTime?: Date;
    ScalableTargetAction?: ScalableTargetAction;
    CreationTime: Date;
}
export type ScheduledActions = ScheduledAction[];
export interface DescribeScheduledActionsResponse {
    ScheduledActions?: ScheduledAction[];
    NextToken?: string;
}
export interface GetPredictiveScalingForecastRequest {
    ServiceNamespace: ServiceNamespace;
    ResourceId: string;
    ScalableDimension: ScalableDimension;
    PolicyName: string;
    StartTime: Date;
    EndTime: Date;
}
export type PredictiveScalingForecastTimestamps = Date[];
export type PredictiveScalingForecastValues = number[];
export interface LoadForecast {
    Timestamps: Date[];
    Values: number[];
    MetricSpecification: PredictiveScalingMetricSpecification;
}
export type LoadForecasts = LoadForecast[];
export interface CapacityForecast {
    Timestamps: Date[];
    Values: number[];
}
export interface GetPredictiveScalingForecastResponse {
    LoadForecast?: LoadForecast[];
    CapacityForecast?: CapacityForecast;
    UpdateTime?: Date;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface PutScalingPolicyRequest {
    PolicyName: string;
    ServiceNamespace: ServiceNamespace;
    ResourceId: string;
    ScalableDimension: ScalableDimension;
    PolicyType?: PolicyType;
    StepScalingPolicyConfiguration?: StepScalingPolicyConfiguration;
    TargetTrackingScalingPolicyConfiguration?: TargetTrackingScalingPolicyConfiguration;
    PredictiveScalingPolicyConfiguration?: PredictiveScalingPolicyConfiguration;
}
export interface PutScalingPolicyResponse {
    PolicyARN: string;
    Alarms?: Alarm[];
}
export interface PutScheduledActionRequest {
    ServiceNamespace: ServiceNamespace;
    Schedule?: string;
    Timezone?: string;
    ScheduledActionName: string;
    ResourceId: string;
    ScalableDimension: ScalableDimension;
    StartTime?: Date;
    EndTime?: Date;
    ScalableTargetAction?: ScalableTargetAction;
}
export interface PutScheduledActionResponse {
}
export interface RegisterScalableTargetRequest {
    ServiceNamespace: ServiceNamespace;
    ResourceId: string;
    ScalableDimension: ScalableDimension;
    MinCapacity?: number;
    MaxCapacity?: number;
    RoleARN?: string;
    SuspendedState?: SuspendedState;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface RegisterScalableTargetResponse {
    ScalableTargetARN?: string;
}
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export type ErrorMessage = string;
export type ExceptionMessage = string;
export type DeleteScalingPolicyError = ConcurrentUpdateException | InternalServiceException | ObjectNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the specified scaling policy for an Application Auto Scaling scalable target.
 *
 * Deleting a step scaling policy deletes the underlying alarm action, but does not delete
 * the CloudWatch alarm associated with the scaling policy, even if it no longer has an associated
 * action.
 *
 * For more information, see Delete a step scaling policy and Delete a target tracking scaling policy in the
 * *Application Auto Scaling User Guide*.
 */
export declare const deleteScalingPolicy: API.OperationMethod<DeleteScalingPolicyRequest, DeleteScalingPolicyResponse, DeleteScalingPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteScheduledActionError = ConcurrentUpdateException | InternalServiceException | ObjectNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the specified scheduled action for an Application Auto Scaling scalable target.
 *
 * For more information, see Delete a scheduled action in the *Application Auto Scaling User Guide*.
 */
export declare const deleteScheduledAction: API.OperationMethod<DeleteScheduledActionRequest, DeleteScheduledActionResponse, DeleteScheduledActionError, Credentials | HttpClient.HttpClient>;
export type DeregisterScalableTargetError = ConcurrentUpdateException | InternalServiceException | ObjectNotFoundException | ValidationException | CommonErrors;
/**
 * Deregisters an Application Auto Scaling scalable target when you have finished using it. To see which
 * resources have been registered, use DescribeScalableTargets.
 *
 * Deregistering a scalable target deletes the scaling policies and the scheduled
 * actions that are associated with it.
 */
export declare const deregisterScalableTarget: API.OperationMethod<DeregisterScalableTargetRequest, DeregisterScalableTargetResponse, DeregisterScalableTargetError, Credentials | HttpClient.HttpClient>;
export type DescribeScalableTargetsError = ConcurrentUpdateException | InternalServiceException | InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Gets information about the scalable targets in the specified namespace.
 *
 * You can filter the results using `ResourceIds` and
 * `ScalableDimension`.
 */
export declare const describeScalableTargets: API.PaginatedOperationMethod<DescribeScalableTargetsRequest, DescribeScalableTargetsResponse, DescribeScalableTargetsError, Credentials | HttpClient.HttpClient, ScalableTarget>;
export type DescribeScalingActivitiesError = ConcurrentUpdateException | InternalServiceException | InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Provides descriptive information about the scaling activities in the specified namespace
 * from the previous six weeks.
 *
 * You can filter the results using `ResourceId` and
 * `ScalableDimension`.
 *
 * For information about viewing scaling activities using the Amazon Web Services CLI, see Scaling activities for Application Auto Scaling.
 */
export declare const describeScalingActivities: API.PaginatedOperationMethod<DescribeScalingActivitiesRequest, DescribeScalingActivitiesResponse, DescribeScalingActivitiesError, Credentials | HttpClient.HttpClient, ScalingActivity>;
export type DescribeScalingPoliciesError = ConcurrentUpdateException | FailedResourceAccessException | InternalServiceException | InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Describes the Application Auto Scaling scaling policies for the specified service namespace.
 *
 * You can filter the results using `ResourceId`,
 * `ScalableDimension`, and `PolicyNames`.
 *
 * For more information, see Target tracking scaling policies and Step scaling policies in the *Application Auto Scaling User Guide*.
 */
export declare const describeScalingPolicies: API.PaginatedOperationMethod<DescribeScalingPoliciesRequest, DescribeScalingPoliciesResponse, DescribeScalingPoliciesError, Credentials | HttpClient.HttpClient, ScalingPolicy>;
export type DescribeScheduledActionsError = ConcurrentUpdateException | InternalServiceException | InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Describes the Application Auto Scaling scheduled actions for the specified service namespace.
 *
 * You can filter the results using the `ResourceId`,
 * `ScalableDimension`, and `ScheduledActionNames` parameters.
 *
 * For more information, see Scheduled scaling in the *Application Auto Scaling User Guide*.
 */
export declare const describeScheduledActions: API.PaginatedOperationMethod<DescribeScheduledActionsRequest, DescribeScheduledActionsResponse, DescribeScheduledActionsError, Credentials | HttpClient.HttpClient, ScheduledAction>;
export type GetPredictiveScalingForecastError = InternalServiceException | ValidationException | PredictiveScalingForecastNotSupported | CommonErrors;
/**
 * Retrieves the forecast data for a predictive scaling policy.
 *
 * Load forecasts are predictions of the hourly load values using historical load data
 * from CloudWatch and an analysis of historical trends. Capacity forecasts are represented as
 * predicted values for the minimum capacity that is needed on an hourly basis, based on
 * the hourly load forecast.
 *
 * A minimum of 24 hours of data is required to create the initial forecasts. However,
 * having a full 14 days of historical data results in more accurate forecasts.
 */
export declare const getPredictiveScalingForecast: API.OperationMethod<GetPredictiveScalingForecastRequest, GetPredictiveScalingForecastResponse, GetPredictiveScalingForecastError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Returns all the tags on the specified Application Auto Scaling scalable target.
 *
 * For general information about tags, including the format and syntax, see Tagging your Amazon Web Services
 * resources in the *Amazon Web Services General Reference*.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutScalingPolicyError = ConcurrentUpdateException | FailedResourceAccessException | InternalServiceException | LimitExceededException | ObjectNotFoundException | ValidationException | CommonErrors;
/**
 * Creates or updates a scaling policy for an Application Auto Scaling scalable target.
 *
 * Each scalable target is identified by a service namespace, resource ID, and scalable
 * dimension. A scaling policy applies to the scalable target identified by those three
 * attributes. You cannot create a scaling policy until you have registered the resource as a
 * scalable target.
 *
 * Multiple scaling policies can be in force at the same time for the same scalable target.
 * You can have one or more target tracking scaling policies, one or more step scaling
 * policies, or both. However, there is a chance that multiple policies could conflict,
 * instructing the scalable target to scale out or in at the same time. Application Auto Scaling gives
 * precedence to the policy that provides the largest capacity for both scale out and scale
 * in. For example, if one policy increases capacity by 3, another policy increases capacity
 * by 200 percent, and the current capacity is 10, Application Auto Scaling uses the policy with the highest
 * calculated capacity (200% of 10 = 20) and scales out to 30.
 *
 * We recommend caution, however, when using target tracking scaling policies with step
 * scaling policies because conflicts between these policies can cause undesirable behavior.
 * For example, if the step scaling policy initiates a scale-in activity before the target
 * tracking policy is ready to scale in, the scale-in activity will not be blocked. After the
 * scale-in activity completes, the target tracking policy could instruct the scalable target
 * to scale out again.
 *
 * For more information, see Target tracking scaling policies, Step scaling policies, and Predictive scaling policies
 * in the *Application Auto Scaling User Guide*.
 *
 * If a scalable target is deregistered, the scalable target is no longer available to
 * use scaling policies. Any scaling policies that were specified for the scalable target
 * are deleted.
 */
export declare const putScalingPolicy: API.OperationMethod<PutScalingPolicyRequest, PutScalingPolicyResponse, PutScalingPolicyError, Credentials | HttpClient.HttpClient>;
export type PutScheduledActionError = ConcurrentUpdateException | InternalServiceException | LimitExceededException | ObjectNotFoundException | ValidationException | CommonErrors;
/**
 * Creates or updates a scheduled action for an Application Auto Scaling scalable target.
 *
 * Each scalable target is identified by a service namespace, resource ID, and scalable
 * dimension. A scheduled action applies to the scalable target identified by those three
 * attributes. You cannot create a scheduled action until you have registered the resource as
 * a scalable target.
 *
 * When you specify start and end times with a recurring schedule using a cron expression
 * or rates, they form the boundaries for when the recurring action starts and stops.
 *
 * To update a scheduled action, specify the parameters that you want to change. If you
 * don't specify start and end times, the old values are deleted.
 *
 * For more information, see Scheduled scaling in the *Application Auto Scaling User Guide*.
 *
 * If a scalable target is deregistered, the scalable target is no longer available to
 * run scheduled actions. Any scheduled actions that were specified for the scalable target
 * are deleted.
 */
export declare const putScheduledAction: API.OperationMethod<PutScheduledActionRequest, PutScheduledActionResponse, PutScheduledActionError, Credentials | HttpClient.HttpClient>;
export type RegisterScalableTargetError = ConcurrentUpdateException | InternalServiceException | LimitExceededException | ValidationException | CommonErrors;
/**
 * Registers or updates a scalable target, which is the resource that you want to
 * scale.
 *
 * Scalable targets are uniquely identified by the combination of resource ID, scalable
 * dimension, and namespace, which represents some capacity dimension of the underlying
 * service.
 *
 * When you register a new scalable target, you must specify values for the minimum and
 * maximum capacity. If the specified resource is not active in the target service, this
 * operation does not change the resource's current capacity. Otherwise, it changes the
 * resource's current capacity to a value that is inside of this range.
 *
 * If you add a scaling policy, current capacity is adjustable within the specified range
 * when scaling starts. Application Auto Scaling scaling policies will not scale capacity to values that are
 * outside of the minimum and maximum range.
 *
 * After you register a scalable target, you do not need to register it again to use other
 * Application Auto Scaling operations. To see which resources have been registered, use DescribeScalableTargets. You can also view the scaling policies for a service
 * namespace by using DescribeScalableTargets. If you no longer need a scalable target, you can
 * deregister it by using DeregisterScalableTarget.
 *
 * To update a scalable target, specify the parameters that you want to change. Include the
 * parameters that identify the scalable target: resource ID, scalable dimension, and
 * namespace. Any parameters that you don't specify are not changed by this update request.
 *
 * If you call the `RegisterScalableTarget` API operation to create a
 * scalable target, there might be a brief delay until the operation achieves eventual
 * consistency. You might become aware of this brief delay if you get unexpected
 * errors when performing sequential operations. The typical strategy is to retry the
 * request, and some Amazon Web Services SDKs include automatic backoff and retry logic.
 *
 * If you call the `RegisterScalableTarget` API operation to update an
 * existing scalable target, Application Auto Scaling retrieves the current capacity of the resource. If
 * it's below the minimum capacity or above the maximum capacity, Application Auto Scaling adjusts the
 * capacity of the scalable target to place it within these bounds, even if you don't
 * include the `MinCapacity` or `MaxCapacity` request
 * parameters.
 */
export declare const registerScalableTarget: API.OperationMethod<RegisterScalableTargetRequest, RegisterScalableTargetResponse, RegisterScalableTargetError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Adds or edits tags on an Application Auto Scaling scalable target.
 *
 * Each tag consists of a tag key and a tag value, which are both case-sensitive strings.
 * To add a tag, specify a new tag key and a tag value. To edit a tag, specify an existing tag
 * key and a new tag value.
 *
 * You can use this operation to tag an Application Auto Scaling scalable target, but you cannot tag a
 * scaling policy or scheduled action.
 *
 * You can also add tags to an Application Auto Scaling scalable target while creating it
 * (`RegisterScalableTarget`).
 *
 * For general information about tags, including the format and syntax, see Tagging your Amazon Web Services
 * resources in the *Amazon Web Services General Reference*.
 *
 * Use tags to control access to a scalable target. For more information, see Tagging support
 * for Application Auto Scaling in the *Application Auto Scaling User Guide*.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes tags from an Application Auto Scaling scalable target. To delete a tag, specify the tag key and
 * the Application Auto Scaling scalable target.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=application-auto-scaling.d.ts.map