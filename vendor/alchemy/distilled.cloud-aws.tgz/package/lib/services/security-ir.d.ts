import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type MembershipId = string;
export type AWSAccountId = string;
export type AWSAccountIds = string[];
export interface BatchGetMemberAccountDetailsRequest {
    membershipId: string;
    accountIds: string[];
}
export type MembershipAccountRelationshipStatus = "Associated" | "Disassociated" | "Unassociated" | (string & {});
export type MembershipAccountRelationshipType = "Organization" | "Unrelated" | (string & {});
export interface GetMembershipAccountDetailItem {
    accountId?: string;
    relationshipStatus?: MembershipAccountRelationshipStatus;
    relationshipType?: MembershipAccountRelationshipType;
}
export type GetMembershipAccountDetailItems = GetMembershipAccountDetailItem[];
export interface GetMembershipAccountDetailError {
    accountId: string;
    error: string;
    message: string;
}
export type GetMembershipAccountDetailErrors = GetMembershipAccountDetailError[];
export interface BatchGetMemberAccountDetailsResponse {
    items?: GetMembershipAccountDetailItem[];
    errors?: GetMembershipAccountDetailError[];
}
export interface CancelMembershipRequest {
    membershipId: string;
}
export interface CancelMembershipResponse {
    membershipId: string;
}
export type CaseId = string;
export interface CloseCaseRequest {
    caseId: string;
}
export type CaseStatus = "Submitted" | "Acknowledged" | "Detection and Analysis" | "Containment, Eradication and Recovery" | "Post-incident Activities" | "Ready to Close" | "Closed" | (string & {});
export interface CloseCaseResponse {
    caseStatus?: CaseStatus;
    closedDate?: Date;
}
export type ResolverType = "AWS" | "Self" | (string & {});
export type CaseTitle = string | redacted.Redacted<string>;
export type CaseDescription = string | redacted.Redacted<string>;
export type EngagementType = "Security Incident" | "Investigation" | (string & {});
export type ImpactedAccounts = string[];
export type EmailAddress = string | redacted.Redacted<string>;
export type PersonName = string | redacted.Redacted<string>;
export type JobTitle = string | redacted.Redacted<string>;
export interface Watcher {
    email: string | redacted.Redacted<string>;
    name?: string | redacted.Redacted<string>;
    jobTitle?: string | redacted.Redacted<string>;
}
export type Watchers = Watcher[];
export type IPAddress = string | redacted.Redacted<string>;
export type UserAgent = string;
export interface ThreatActorIp {
    ipAddress: string | redacted.Redacted<string>;
    userAgent?: string;
}
export type ThreatActorIpList = ThreatActorIp[];
export type AwsService = string;
export type ImpactedServicesList = string[];
export type AwsRegion = "af-south-1" | "ap-east-1" | "ap-east-2" | "ap-northeast-1" | "ap-northeast-2" | "ap-northeast-3" | "ap-south-1" | "ap-south-2" | "ap-southeast-1" | "ap-southeast-2" | "ap-southeast-3" | "ap-southeast-4" | "ap-southeast-5" | "ap-southeast-6" | "ap-southeast-7" | "ca-central-1" | "ca-west-1" | "cn-north-1" | "cn-northwest-1" | "eu-central-1" | "eu-central-2" | "eu-north-1" | "eu-south-1" | "eu-south-2" | "eu-west-1" | "eu-west-2" | "eu-west-3" | "il-central-1" | "me-central-1" | "me-south-1" | "mx-central-1" | "sa-east-1" | "us-east-1" | "us-east-2" | "us-west-1" | "us-west-2" | (string & {});
export interface ImpactedAwsRegion {
    region: AwsRegion;
}
export type ImpactedAwsRegionList = ImpactedAwsRegion[];
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateCaseRequest {
    clientToken?: string;
    resolverType: ResolverType;
    title: string | redacted.Redacted<string>;
    description: string | redacted.Redacted<string>;
    engagementType: EngagementType;
    reportedIncidentStartDate: Date;
    impactedAccounts: string[];
    watchers: Watcher[];
    threatActorIpAddresses?: ThreatActorIp[];
    impactedServices?: string[];
    impactedAwsRegions?: ImpactedAwsRegion[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateCaseResponse {
    caseId: string;
}
export type CommentBody = string | redacted.Redacted<string>;
export interface CreateCaseCommentRequest {
    caseId: string;
    clientToken?: string;
    body: string | redacted.Redacted<string>;
}
export type CommentId = string;
export interface CreateCaseCommentResponse {
    commentId: string;
}
export type MembershipName = string | redacted.Redacted<string>;
export type IncidentResponderName = string | redacted.Redacted<string>;
export type CommunicationType = "Case Created" | "Case Updated" | "Case Acknowledged" | "Case Closed" | "Case Updated To Service Managed" | "Case Status Updated" | "Case Pending Customer Action Reminder" | "Case Attachment Url Uploaded" | "Case Comment Added" | "Case Comment Updated" | "Membership Created" | "Membership Updated" | "Membership Cancelled" | "Register Delegated Administrator" | "Deregister Delegated Administrator" | "Disable AWS Service Access" | (string & {});
export type CommunicationPreferences = CommunicationType[];
export interface IncidentResponder {
    name: string | redacted.Redacted<string>;
    jobTitle: string | redacted.Redacted<string>;
    email: string | redacted.Redacted<string>;
    communicationPreferences?: CommunicationType[];
}
export type IncidentResponseTeam = IncidentResponder[];
export type OptInFeatureName = "Triage" | (string & {});
export interface OptInFeature {
    featureName: OptInFeatureName;
    isEnabled: boolean;
}
export type OptInFeatures = OptInFeature[];
export interface CreateMembershipRequest {
    clientToken?: string;
    membershipName: string | redacted.Redacted<string>;
    incidentResponseTeam: IncidentResponder[];
    optInFeatures?: OptInFeature[];
    tags?: {
        [key: string]: string | undefined;
    };
    coverEntireOrganization?: boolean;
}
export interface CreateMembershipResponse {
    membershipId: string;
}
export interface GetCaseRequest {
    caseId: string;
}
export type CaseArn = string;
export type PendingAction = "Customer" | "None" | (string & {});
export type ClosureCode = "Investigation Completed" | "Not Resolved" | "False Positive" | "Duplicate" | (string & {});
export type AttachmentId = string;
export type FileName = string | redacted.Redacted<string>;
export type CaseAttachmentStatus = "Verified" | "Failed" | "Pending" | (string & {});
export type PrincipalId = string;
export interface CaseAttachmentAttributes {
    attachmentId: string;
    fileName: string | redacted.Redacted<string>;
    attachmentStatus: CaseAttachmentStatus;
    creator: string;
    createdDate: Date;
}
export type CaseAttachmentsList = CaseAttachmentAttributes[];
export interface CaseMetadataEntry {
    key: string;
    value: string;
}
export type CaseMetadata = CaseMetadataEntry[];
export interface GetCaseResponse {
    title?: string | redacted.Redacted<string>;
    caseArn?: string;
    description?: string | redacted.Redacted<string>;
    caseStatus?: CaseStatus;
    engagementType?: EngagementType;
    reportedIncidentStartDate?: Date;
    actualIncidentStartDate?: Date;
    impactedAwsRegions?: ImpactedAwsRegion[];
    threatActorIpAddresses?: ThreatActorIp[];
    pendingAction?: PendingAction;
    impactedAccounts?: string[];
    watchers?: Watcher[];
    createdDate?: Date;
    lastUpdatedDate?: Date;
    closureCode?: ClosureCode;
    resolverType?: ResolverType;
    impactedServices?: string[];
    caseAttachments?: CaseAttachmentAttributes[];
    closedDate?: Date;
    caseMetadata?: CaseMetadataEntry[];
}
export interface GetCaseAttachmentDownloadUrlRequest {
    caseId: string;
    attachmentId: string;
}
export type Url = string | redacted.Redacted<string>;
export interface GetCaseAttachmentDownloadUrlResponse {
    attachmentPresignedUrl: string | redacted.Redacted<string>;
}
export type ContentLength = number;
export interface GetCaseAttachmentUploadUrlRequest {
    caseId: string;
    fileName: string | redacted.Redacted<string>;
    contentLength: number;
    clientToken?: string;
}
export interface GetCaseAttachmentUploadUrlResponse {
    attachmentPresignedUrl: string | redacted.Redacted<string>;
}
export interface GetMembershipRequest {
    membershipId: string;
}
export type MembershipArn = string;
export type MembershipStatus = "Active" | "Cancelled" | "Terminated" | (string & {});
export type CustomerType = "Standalone" | "Organization" | (string & {});
export type OrganizationalUnitId = string;
export type OrganizationalUnits = string[];
export interface MembershipAccountsConfigurations {
    coverEntireOrganization?: boolean;
    organizationalUnits?: string[];
}
export interface GetMembershipResponse {
    membershipId: string;
    accountId?: string;
    region?: AwsRegion;
    membershipName?: string | redacted.Redacted<string>;
    membershipArn?: string;
    membershipStatus?: MembershipStatus;
    membershipActivationTimestamp?: Date;
    membershipDeactivationTimestamp?: Date;
    customerType?: CustomerType;
    numberOfAccountsCovered?: number;
    incidentResponseTeam?: IncidentResponder[];
    optInFeatures?: OptInFeature[];
    membershipAccountsConfigurations?: MembershipAccountsConfigurations;
}
export interface ListCaseEditsRequest {
    nextToken?: string;
    maxResults?: number;
    caseId: string;
}
export type CaseEditAction = string;
export type CaseEditMessage = string;
export interface CaseEditItem {
    eventTimestamp?: Date;
    principal?: string;
    action?: string;
    message?: string;
}
export type CaseEditItems = CaseEditItem[];
export interface ListCaseEditsResponse {
    nextToken?: string;
    items?: CaseEditItem[];
    total?: number;
}
export interface ListCasesRequest {
    nextToken?: string;
    maxResults?: number;
}
export interface ListCasesItem {
    caseId: string;
    lastUpdatedDate?: Date;
    title?: string | redacted.Redacted<string>;
    caseArn?: string;
    engagementType?: EngagementType;
    caseStatus?: CaseStatus;
    createdDate?: Date;
    closedDate?: Date;
    resolverType?: ResolverType;
    pendingAction?: PendingAction;
}
export type ListCasesItems = ListCasesItem[];
export interface ListCasesResponse {
    nextToken?: string;
    items?: ListCasesItem[];
    total?: number;
}
export interface ListCommentsRequest {
    nextToken?: string;
    maxResults?: number;
    caseId: string;
}
export interface ListCommentsItem {
    commentId: string;
    createdDate?: Date;
    lastUpdatedDate?: Date;
    creator?: string;
    lastUpdatedBy?: string;
    body?: string | redacted.Redacted<string>;
}
export type ListCommentsItems = ListCommentsItem[];
export interface ListCommentsResponse {
    nextToken?: string;
    items?: ListCommentsItem[];
    total?: number;
}
export interface ListInvestigationsRequest {
    nextToken?: string;
    maxResults?: number;
    caseId: string;
}
export type InvestigationId = string;
export type ActionType = "Evidence" | "Investigation" | "Summarization" | (string & {});
export type InvestigationTitle = string;
export type InvestigationContent = string;
export type ExecutionStatus = "Pending" | "InProgress" | "Waiting" | "Completed" | "Failed" | "Cancelled" | (string & {});
export type UsefulnessRating = "USEFUL" | "NOT_USEFUL" | (string & {});
export type FeedbackComment = string;
export interface InvestigationFeedback {
    usefulness?: UsefulnessRating;
    comment?: string;
    submittedAt?: Date;
}
export interface InvestigationAction {
    investigationId: string;
    actionType: ActionType;
    title: string;
    content: string;
    status: ExecutionStatus;
    lastUpdated: Date;
    feedback?: InvestigationFeedback;
}
export type InvestigationActionList = InvestigationAction[];
export interface ListInvestigationsResponse {
    nextToken?: string;
    investigationActions: InvestigationAction[];
}
export interface ListMembershipsRequest {
    nextToken?: string;
    maxResults?: number;
}
export interface ListMembershipItem {
    membershipId: string;
    accountId?: string;
    region?: AwsRegion;
    membershipArn?: string;
    membershipStatus?: MembershipStatus;
}
export type ListMembershipItems = ListMembershipItem[];
export interface ListMembershipsResponse {
    nextToken?: string;
    items?: ListMembershipItem[];
}
export type Arn = string;
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags: {
        [key: string]: string | undefined;
    };
}
export type ResultId = string;
export interface SendFeedbackRequest {
    caseId: string;
    resultId: string;
    usefulness: UsefulnessRating;
    comment?: string;
}
export interface SendFeedbackResponse {
}
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type TagKeys = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateCaseRequest {
    caseId: string;
    title?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    reportedIncidentStartDate?: Date;
    actualIncidentStartDate?: Date;
    engagementType?: EngagementType;
    watchersToAdd?: Watcher[];
    watchersToDelete?: Watcher[];
    threatActorIpAddressesToAdd?: ThreatActorIp[];
    threatActorIpAddressesToDelete?: ThreatActorIp[];
    impactedServicesToAdd?: string[];
    impactedServicesToDelete?: string[];
    impactedAwsRegionsToAdd?: ImpactedAwsRegion[];
    impactedAwsRegionsToDelete?: ImpactedAwsRegion[];
    impactedAccountsToAdd?: string[];
    impactedAccountsToDelete?: string[];
    caseMetadata?: CaseMetadataEntry[];
}
export interface UpdateCaseResponse {
}
export interface UpdateCaseCommentRequest {
    caseId: string;
    commentId: string;
    body: string | redacted.Redacted<string>;
}
export interface UpdateCaseCommentResponse {
    commentId: string;
    body?: string | redacted.Redacted<string>;
}
export type SelfManagedCaseStatus = "Submitted" | "Detection and Analysis" | "Containment, Eradication and Recovery" | "Post-incident Activities" | (string & {});
export interface UpdateCaseStatusRequest {
    caseId: string;
    caseStatus: SelfManagedCaseStatus;
}
export interface UpdateCaseStatusResponse {
    caseStatus?: SelfManagedCaseStatus;
}
export interface MembershipAccountsConfigurationsUpdate {
    coverEntireOrganization?: boolean;
    organizationalUnitsToAdd?: string[];
    organizationalUnitsToRemove?: string[];
}
export interface UpdateMembershipRequest {
    membershipId: string;
    membershipName?: string | redacted.Redacted<string>;
    incidentResponseTeam?: IncidentResponder[];
    optInFeatures?: OptInFeature[];
    membershipAccountsConfigurationsUpdate?: MembershipAccountsConfigurationsUpdate;
    undoMembershipCancellation?: boolean;
}
export interface UpdateMembershipResponse {
}
export interface UpdateResolverTypeRequest {
    caseId: string;
    resolverType: ResolverType;
}
export interface UpdateResolverTypeResponse {
    caseId: string;
    caseStatus?: CaseStatus;
    resolverType?: ResolverType;
}
export type ValidationExceptionReason = "UNKNOWN_OPERATION" | "CANNOT_PARSE" | "FIELD_VALIDATION_FAILED" | "OTHER" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type BatchGetMemberAccountDetailsError = CommonErrors;
/**
 * Provides information on whether the supplied account IDs are associated with a membership.
 *
 * AWS account ID's may appear less than 12 characters and need to be zero-prepended. An example would be `123123123` which is nine digits, and with zero-prepend would be `000123123123`. Not zero-prepending to 12 digits could result in errors.
 */
export declare const batchGetMemberAccountDetails: API.OperationMethod<BatchGetMemberAccountDetailsRequest, BatchGetMemberAccountDetailsResponse, BatchGetMemberAccountDetailsError, Credentials | HttpClient.HttpClient>;
export type CancelMembershipError = CommonErrors;
/**
 * Cancels an existing membership.
 */
export declare const cancelMembership: API.OperationMethod<CancelMembershipRequest, CancelMembershipResponse, CancelMembershipError, Credentials | HttpClient.HttpClient>;
export type CloseCaseError = CommonErrors;
/**
 * Closes an existing case.
 */
export declare const closeCase: API.OperationMethod<CloseCaseRequest, CloseCaseResponse, CloseCaseError, Credentials | HttpClient.HttpClient>;
export type CreateCaseError = CommonErrors;
/**
 * Creates a new case.
 */
export declare const createCase: API.OperationMethod<CreateCaseRequest, CreateCaseResponse, CreateCaseError, Credentials | HttpClient.HttpClient>;
export type CreateCaseCommentError = CommonErrors;
/**
 * Adds a comment to an existing case.
 */
export declare const createCaseComment: API.OperationMethod<CreateCaseCommentRequest, CreateCaseCommentResponse, CreateCaseCommentError, Credentials | HttpClient.HttpClient>;
export type CreateMembershipError = CommonErrors;
/**
 * Creates a new membership.
 */
export declare const createMembership: API.OperationMethod<CreateMembershipRequest, CreateMembershipResponse, CreateMembershipError, Credentials | HttpClient.HttpClient>;
export type GetCaseError = CommonErrors;
/**
 * Returns the attributes of a case.
 */
export declare const getCase: API.OperationMethod<GetCaseRequest, GetCaseResponse, GetCaseError, Credentials | HttpClient.HttpClient>;
export type GetCaseAttachmentDownloadUrlError = CommonErrors;
/**
 * Returns a Pre-Signed URL for uploading attachments into a case.
 */
export declare const getCaseAttachmentDownloadUrl: API.OperationMethod<GetCaseAttachmentDownloadUrlRequest, GetCaseAttachmentDownloadUrlResponse, GetCaseAttachmentDownloadUrlError, Credentials | HttpClient.HttpClient>;
export type GetCaseAttachmentUploadUrlError = CommonErrors;
/**
 * Uploads an attachment to a case.
 */
export declare const getCaseAttachmentUploadUrl: API.OperationMethod<GetCaseAttachmentUploadUrlRequest, GetCaseAttachmentUploadUrlResponse, GetCaseAttachmentUploadUrlError, Credentials | HttpClient.HttpClient>;
export type GetMembershipError = CommonErrors;
/**
 * Returns the attributes of a membership.
 */
export declare const getMembership: API.OperationMethod<GetMembershipRequest, GetMembershipResponse, GetMembershipError, Credentials | HttpClient.HttpClient>;
export type ListCaseEditsError = CommonErrors;
/**
 * Views the case history for edits made to a designated case.
 */
export declare const listCaseEdits: API.PaginatedOperationMethod<ListCaseEditsRequest, ListCaseEditsResponse, ListCaseEditsError, Credentials | HttpClient.HttpClient, CaseEditItem>;
export type ListCasesError = CommonErrors;
/**
 * Lists all cases the requester has access to.
 */
export declare const listCases: API.PaginatedOperationMethod<ListCasesRequest, ListCasesResponse, ListCasesError, Credentials | HttpClient.HttpClient, ListCasesItem>;
export type ListCommentsError = CommonErrors;
/**
 * Returns comments for a designated case.
 */
export declare const listComments: API.PaginatedOperationMethod<ListCommentsRequest, ListCommentsResponse, ListCommentsError, Credentials | HttpClient.HttpClient, ListCommentsItem>;
export type ListInvestigationsError = CommonErrors;
/**
 * Investigation performed by an agent for a security incident...
 */
export declare const listInvestigations: API.PaginatedOperationMethod<ListInvestigationsRequest, ListInvestigationsResponse, ListInvestigationsError, Credentials | HttpClient.HttpClient, InvestigationAction>;
export type ListMembershipsError = CommonErrors;
/**
 * Returns the memberships that the calling principal can access.
 */
export declare const listMemberships: API.PaginatedOperationMethod<ListMembershipsRequest, ListMembershipsResponse, ListMembershipsError, Credentials | HttpClient.HttpClient, ListMembershipItem>;
export type ListTagsForResourceError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns currently configured tags on a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type SendFeedbackError = CommonErrors;
/**
 * Send feedback based on response investigation action
 */
export declare const sendFeedback: API.OperationMethod<SendFeedbackRequest, SendFeedbackResponse, SendFeedbackError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds a tag(s) to a designated resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a tag(s) from a designate resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCaseError = CommonErrors;
/**
 * Updates an existing case.
 */
export declare const updateCase: API.OperationMethod<UpdateCaseRequest, UpdateCaseResponse, UpdateCaseError, Credentials | HttpClient.HttpClient>;
export type UpdateCaseCommentError = CommonErrors;
/**
 * Updates an existing case comment.
 */
export declare const updateCaseComment: API.OperationMethod<UpdateCaseCommentRequest, UpdateCaseCommentResponse, UpdateCaseCommentError, Credentials | HttpClient.HttpClient>;
export type UpdateCaseStatusError = CommonErrors;
/**
 * Updates the state transitions for a designated cases.
 *
 * **Self-managed**: the following states are available for self-managed cases.
 *
 * - Submitted -> Detection and Analysis
 *
 * - Detection and Analysis -> Containment, Eradication, and Recovery
 *
 * - Detection and Analysis -> Post-incident Activities
 *
 * - Containment, Eradication, and Recovery -> Detection and Analysis
 *
 * - Containment, Eradication, and Recovery -> Post-incident Activities
 *
 * - Post-incident Activities -> Containment, Eradication, and Recovery
 *
 * - Post-incident Activities -> Detection and Analysis
 *
 * - Any -> Closed
 *
 * **AWS supported**: You must use the `CloseCase` API to close.
 */
export declare const updateCaseStatus: API.OperationMethod<UpdateCaseStatusRequest, UpdateCaseStatusResponse, UpdateCaseStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateMembershipError = CommonErrors;
/**
 * Updates membership configuration.
 */
export declare const updateMembership: API.OperationMethod<UpdateMembershipRequest, UpdateMembershipResponse, UpdateMembershipError, Credentials | HttpClient.HttpClient>;
export type UpdateResolverTypeError = CommonErrors;
/**
 * Updates the resolver type for a case.
 *
 * This is a one-way action and cannot be reversed.
 */
export declare const updateResolverType: API.OperationMethod<UpdateResolverTypeRequest, UpdateResolverTypeResponse, UpdateResolverTypeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=security-ir.d.ts.map