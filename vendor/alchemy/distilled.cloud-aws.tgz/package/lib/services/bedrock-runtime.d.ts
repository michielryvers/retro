import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type * as stream from "effect/Stream";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import * as T from "../traits.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ModelErrorException_base: S.TaggedErrorClass<"ModelErrorException", {
    readonly message: any;
    readonly originalStatusCode: any;
    readonly resourceName: any;
}>;
export declare class ModelErrorException extends /*@__PURE__*/ ModelErrorException_base {
}
declare const ModelNotReadyException_base: S.TaggedErrorClass<"ModelNotReadyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ModelNotReadyException extends /*@__PURE__*/ ModelNotReadyException_base {
}
declare const ModelStreamErrorException_base: S.TaggedErrorClass<"ModelStreamErrorException", {
    readonly message: any;
    readonly originalStatusCode: any;
    readonly originalMessage: any;
}>;
export declare class ModelStreamErrorException extends /*@__PURE__*/ ModelStreamErrorException_base {
}
declare const ModelTimeoutException_base: S.TaggedErrorClass<"ModelTimeoutException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class ModelTimeoutException extends /*@__PURE__*/ ModelTimeoutException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type GuardrailIdentifier = string;
export type GuardrailVersion = string;
export type GuardrailContentSource = "INPUT" | "OUTPUT" | (string & {});
export type GuardrailContentQualifier = "grounding_source" | "query" | "guard_content" | (string & {});
export type GuardrailContentQualifierList = GuardrailContentQualifier[];
export interface GuardrailTextBlock {
    text: string;
    qualifiers?: GuardrailContentQualifier[];
}
export type GuardrailImageFormat = "png" | "jpeg" | (string & {});
export type GuardrailImageSource = {
    bytes: Uint8Array;
};
export interface GuardrailImageBlock {
    format: GuardrailImageFormat;
    source: GuardrailImageSource;
}
export type GuardrailContentBlock = {
    text: GuardrailTextBlock;
    image?: never;
} | {
    text?: never;
    image: GuardrailImageBlock;
};
export type GuardrailContentBlockList = GuardrailContentBlock[];
export type GuardrailOutputScope = "INTERVENTIONS" | "FULL" | (string & {});
export interface ApplyGuardrailRequest {
    guardrailIdentifier: string;
    guardrailVersion: string;
    source: GuardrailContentSource;
    content: GuardrailContentBlock[];
    outputScope?: GuardrailOutputScope;
}
export type GuardrailTopicPolicyUnitsProcessed = number;
export type GuardrailContentPolicyUnitsProcessed = number;
export type GuardrailWordPolicyUnitsProcessed = number;
export type GuardrailSensitiveInformationPolicyUnitsProcessed = number;
export type GuardrailSensitiveInformationPolicyFreeUnitsProcessed = number;
export type GuardrailContextualGroundingPolicyUnitsProcessed = number;
export type GuardrailContentPolicyImageUnitsProcessed = number;
export type GuardrailAutomatedReasoningPolicyUnitsProcessed = number;
export type GuardrailAutomatedReasoningPoliciesProcessed = number;
export interface GuardrailUsage {
    topicPolicyUnits: number;
    contentPolicyUnits: number;
    wordPolicyUnits: number;
    sensitiveInformationPolicyUnits: number;
    sensitiveInformationPolicyFreeUnits: number;
    contextualGroundingPolicyUnits: number;
    contentPolicyImageUnits?: number;
    automatedReasoningPolicyUnits?: number;
    automatedReasoningPolicies?: number;
}
export type GuardrailAction = "NONE" | "GUARDRAIL_INTERVENED" | (string & {});
export type GuardrailOutputText = string;
export interface GuardrailOutputContent {
    text?: string;
}
export type GuardrailOutputContentList = GuardrailOutputContent[];
export type GuardrailTopicType = "DENY" | (string & {});
export type GuardrailTopicPolicyAction = "BLOCKED" | "NONE" | (string & {});
export interface GuardrailTopic {
    name: string;
    type: GuardrailTopicType;
    action: GuardrailTopicPolicyAction;
    detected?: boolean;
}
export type GuardrailTopicList = GuardrailTopic[];
export interface GuardrailTopicPolicyAssessment {
    topics: GuardrailTopic[];
}
export type GuardrailContentFilterType = "INSULTS" | "HATE" | "SEXUAL" | "VIOLENCE" | "MISCONDUCT" | "PROMPT_ATTACK" | (string & {});
export type GuardrailContentFilterConfidence = "NONE" | "LOW" | "MEDIUM" | "HIGH" | (string & {});
export type GuardrailContentFilterStrength = "NONE" | "LOW" | "MEDIUM" | "HIGH" | (string & {});
export type GuardrailContentPolicyAction = "BLOCKED" | "NONE" | (string & {});
export interface GuardrailContentFilter {
    type: GuardrailContentFilterType;
    confidence: GuardrailContentFilterConfidence;
    filterStrength?: GuardrailContentFilterStrength;
    action: GuardrailContentPolicyAction;
    detected?: boolean;
}
export type GuardrailContentFilterList = GuardrailContentFilter[];
export interface GuardrailContentPolicyAssessment {
    filters: GuardrailContentFilter[];
}
export type GuardrailWordPolicyAction = "BLOCKED" | "NONE" | (string & {});
export interface GuardrailCustomWord {
    match: string;
    action: GuardrailWordPolicyAction;
    detected?: boolean;
}
export type GuardrailCustomWordList = GuardrailCustomWord[];
export type GuardrailManagedWordType = "PROFANITY" | (string & {});
export interface GuardrailManagedWord {
    match: string;
    type: GuardrailManagedWordType;
    action: GuardrailWordPolicyAction;
    detected?: boolean;
}
export type GuardrailManagedWordList = GuardrailManagedWord[];
export interface GuardrailWordPolicyAssessment {
    customWords: GuardrailCustomWord[];
    managedWordLists: GuardrailManagedWord[];
}
export type GuardrailPiiEntityType = "ADDRESS" | "AGE" | "AWS_ACCESS_KEY" | "AWS_SECRET_KEY" | "CA_HEALTH_NUMBER" | "CA_SOCIAL_INSURANCE_NUMBER" | "CREDIT_DEBIT_CARD_CVV" | "CREDIT_DEBIT_CARD_EXPIRY" | "CREDIT_DEBIT_CARD_NUMBER" | "DRIVER_ID" | "EMAIL" | "INTERNATIONAL_BANK_ACCOUNT_NUMBER" | "IP_ADDRESS" | "LICENSE_PLATE" | "MAC_ADDRESS" | "NAME" | "PASSWORD" | "PHONE" | "PIN" | "SWIFT_CODE" | "UK_NATIONAL_HEALTH_SERVICE_NUMBER" | "UK_NATIONAL_INSURANCE_NUMBER" | "UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER" | "URL" | "USERNAME" | "US_BANK_ACCOUNT_NUMBER" | "US_BANK_ROUTING_NUMBER" | "US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER" | "US_PASSPORT_NUMBER" | "US_SOCIAL_SECURITY_NUMBER" | "VEHICLE_IDENTIFICATION_NUMBER" | (string & {});
export type GuardrailSensitiveInformationPolicyAction = "ANONYMIZED" | "BLOCKED" | "NONE" | (string & {});
export interface GuardrailPiiEntityFilter {
    match: string;
    type: GuardrailPiiEntityType;
    action: GuardrailSensitiveInformationPolicyAction;
    detected?: boolean;
}
export type GuardrailPiiEntityFilterList = GuardrailPiiEntityFilter[];
export interface GuardrailRegexFilter {
    name?: string;
    match?: string;
    regex?: string;
    action: GuardrailSensitiveInformationPolicyAction;
    detected?: boolean;
}
export type GuardrailRegexFilterList = GuardrailRegexFilter[];
export interface GuardrailSensitiveInformationPolicyAssessment {
    piiEntities: GuardrailPiiEntityFilter[];
    regexes: GuardrailRegexFilter[];
}
export type GuardrailContextualGroundingFilterType = "GROUNDING" | "RELEVANCE" | (string & {});
export type GuardrailContextualGroundingPolicyAction = "BLOCKED" | "NONE" | (string & {});
export interface GuardrailContextualGroundingFilter {
    type: GuardrailContextualGroundingFilterType;
    threshold: number;
    score: number;
    action: GuardrailContextualGroundingPolicyAction;
    detected?: boolean;
}
export type GuardrailContextualGroundingFilters = GuardrailContextualGroundingFilter[];
export interface GuardrailContextualGroundingPolicyAssessment {
    filters?: GuardrailContextualGroundingFilter[];
}
export type GuardrailAutomatedReasoningStatementLogicContent = string | redacted.Redacted<string>;
export type GuardrailAutomatedReasoningStatementNaturalLanguageContent = string | redacted.Redacted<string>;
export interface GuardrailAutomatedReasoningStatement {
    logic?: string | redacted.Redacted<string>;
    naturalLanguage?: string | redacted.Redacted<string>;
}
export type GuardrailAutomatedReasoningStatementList = GuardrailAutomatedReasoningStatement[];
export interface GuardrailAutomatedReasoningInputTextReference {
    text?: string | redacted.Redacted<string>;
}
export type GuardrailAutomatedReasoningInputTextReferenceList = GuardrailAutomatedReasoningInputTextReference[];
export type GuardrailAutomatedReasoningTranslationConfidence = number;
export interface GuardrailAutomatedReasoningTranslation {
    premises?: GuardrailAutomatedReasoningStatement[];
    claims?: GuardrailAutomatedReasoningStatement[];
    untranslatedPremises?: GuardrailAutomatedReasoningInputTextReference[];
    untranslatedClaims?: GuardrailAutomatedReasoningInputTextReference[];
    confidence?: number;
}
export interface GuardrailAutomatedReasoningScenario {
    statements?: GuardrailAutomatedReasoningStatement[];
}
export type AutomatedReasoningRuleIdentifier = string;
export type GuardrailAutomatedReasoningPolicyVersionArn = string;
export interface GuardrailAutomatedReasoningRule {
    identifier?: string;
    policyVersionArn?: string;
}
export type GuardrailAutomatedReasoningRuleList = GuardrailAutomatedReasoningRule[];
export type GuardrailAutomatedReasoningLogicWarningType = "ALWAYS_FALSE" | "ALWAYS_TRUE" | (string & {});
export interface GuardrailAutomatedReasoningLogicWarning {
    type?: GuardrailAutomatedReasoningLogicWarningType;
    premises?: GuardrailAutomatedReasoningStatement[];
    claims?: GuardrailAutomatedReasoningStatement[];
}
export interface GuardrailAutomatedReasoningValidFinding {
    translation?: GuardrailAutomatedReasoningTranslation;
    claimsTrueScenario?: GuardrailAutomatedReasoningScenario;
    supportingRules?: GuardrailAutomatedReasoningRule[];
    logicWarning?: GuardrailAutomatedReasoningLogicWarning;
}
export interface GuardrailAutomatedReasoningInvalidFinding {
    translation?: GuardrailAutomatedReasoningTranslation;
    contradictingRules?: GuardrailAutomatedReasoningRule[];
    logicWarning?: GuardrailAutomatedReasoningLogicWarning;
}
export interface GuardrailAutomatedReasoningSatisfiableFinding {
    translation?: GuardrailAutomatedReasoningTranslation;
    claimsTrueScenario?: GuardrailAutomatedReasoningScenario;
    claimsFalseScenario?: GuardrailAutomatedReasoningScenario;
    logicWarning?: GuardrailAutomatedReasoningLogicWarning;
}
export interface GuardrailAutomatedReasoningImpossibleFinding {
    translation?: GuardrailAutomatedReasoningTranslation;
    contradictingRules?: GuardrailAutomatedReasoningRule[];
    logicWarning?: GuardrailAutomatedReasoningLogicWarning;
}
export type GuardrailAutomatedReasoningTranslationList = GuardrailAutomatedReasoningTranslation[];
export interface GuardrailAutomatedReasoningTranslationOption {
    translations?: GuardrailAutomatedReasoningTranslation[];
}
export type GuardrailAutomatedReasoningTranslationOptionList = GuardrailAutomatedReasoningTranslationOption[];
export type GuardrailAutomatedReasoningDifferenceScenarioList = GuardrailAutomatedReasoningScenario[];
export interface GuardrailAutomatedReasoningTranslationAmbiguousFinding {
    options?: GuardrailAutomatedReasoningTranslationOption[];
    differenceScenarios?: GuardrailAutomatedReasoningScenario[];
}
export interface GuardrailAutomatedReasoningTooComplexFinding {
}
export interface GuardrailAutomatedReasoningNoTranslationsFinding {
}
export type GuardrailAutomatedReasoningFinding = {
    valid: GuardrailAutomatedReasoningValidFinding;
    invalid?: never;
    satisfiable?: never;
    impossible?: never;
    translationAmbiguous?: never;
    tooComplex?: never;
    noTranslations?: never;
} | {
    valid?: never;
    invalid: GuardrailAutomatedReasoningInvalidFinding;
    satisfiable?: never;
    impossible?: never;
    translationAmbiguous?: never;
    tooComplex?: never;
    noTranslations?: never;
} | {
    valid?: never;
    invalid?: never;
    satisfiable: GuardrailAutomatedReasoningSatisfiableFinding;
    impossible?: never;
    translationAmbiguous?: never;
    tooComplex?: never;
    noTranslations?: never;
} | {
    valid?: never;
    invalid?: never;
    satisfiable?: never;
    impossible: GuardrailAutomatedReasoningImpossibleFinding;
    translationAmbiguous?: never;
    tooComplex?: never;
    noTranslations?: never;
} | {
    valid?: never;
    invalid?: never;
    satisfiable?: never;
    impossible?: never;
    translationAmbiguous: GuardrailAutomatedReasoningTranslationAmbiguousFinding;
    tooComplex?: never;
    noTranslations?: never;
} | {
    valid?: never;
    invalid?: never;
    satisfiable?: never;
    impossible?: never;
    translationAmbiguous?: never;
    tooComplex: GuardrailAutomatedReasoningTooComplexFinding;
    noTranslations?: never;
} | {
    valid?: never;
    invalid?: never;
    satisfiable?: never;
    impossible?: never;
    translationAmbiguous?: never;
    tooComplex?: never;
    noTranslations: GuardrailAutomatedReasoningNoTranslationsFinding;
};
export type GuardrailAutomatedReasoningFindingList = GuardrailAutomatedReasoningFinding[];
export interface GuardrailAutomatedReasoningPolicyAssessment {
    findings?: GuardrailAutomatedReasoningFinding[];
}
export type GuardrailProcessingLatency = number;
export type TextCharactersGuarded = number;
export type TextCharactersTotal = number;
export interface GuardrailTextCharactersCoverage {
    guarded?: number;
    total?: number;
}
export type ImagesGuarded = number;
export type ImagesTotal = number;
export interface GuardrailImageCoverage {
    guarded?: number;
    total?: number;
}
export interface GuardrailCoverage {
    textCharacters?: GuardrailTextCharactersCoverage;
    images?: GuardrailImageCoverage;
}
export interface GuardrailInvocationMetrics {
    guardrailProcessingLatency?: number;
    usage?: GuardrailUsage;
    guardrailCoverage?: GuardrailCoverage;
}
export type GuardrailId = string;
export type GuardrailArn = string;
export type GuardrailOrigin = "REQUEST" | "ACCOUNT_ENFORCED" | "ORGANIZATION_ENFORCED" | (string & {});
export type GuardrailOriginList = GuardrailOrigin[];
export type GuardrailOwnership = "SELF" | "CROSS_ACCOUNT" | (string & {});
export interface AppliedGuardrailDetails {
    guardrailId?: string;
    guardrailVersion?: string;
    guardrailArn?: string;
    guardrailOrigin?: GuardrailOrigin[];
    guardrailOwnership?: GuardrailOwnership;
}
export interface GuardrailAssessment {
    topicPolicy?: GuardrailTopicPolicyAssessment;
    contentPolicy?: GuardrailContentPolicyAssessment;
    wordPolicy?: GuardrailWordPolicyAssessment;
    sensitiveInformationPolicy?: GuardrailSensitiveInformationPolicyAssessment;
    contextualGroundingPolicy?: GuardrailContextualGroundingPolicyAssessment;
    automatedReasoningPolicy?: GuardrailAutomatedReasoningPolicyAssessment;
    invocationMetrics?: GuardrailInvocationMetrics;
    appliedGuardrailDetails?: AppliedGuardrailDetails;
}
export type GuardrailAssessmentList = GuardrailAssessment[];
export interface ApplyGuardrailResponse {
    usage: GuardrailUsage;
    action: GuardrailAction;
    actionReason?: string;
    outputs: GuardrailOutputContent[];
    assessments: GuardrailAssessment[];
    guardrailCoverage?: GuardrailCoverage;
}
export type ConversationalModelId = string;
export type ConversationRole = "user" | "assistant" | "system" | (string & {});
export type ImageFormat = "png" | "jpeg" | "gif" | "webp" | (string & {});
export type S3Uri = string;
export type AccountId = string;
export interface S3Location {
    uri: string;
    bucketOwner?: string;
}
export type ImageSource = {
    bytes: Uint8Array;
    s3Location?: never;
} | {
    bytes?: never;
    s3Location: S3Location;
};
export interface ErrorBlock {
    message?: string;
}
export interface ImageBlock {
    format: ImageFormat;
    source: ImageSource;
    error?: ErrorBlock;
}
export type DocumentFormat = "pdf" | "csv" | "doc" | "docx" | "xls" | "xlsx" | "html" | "txt" | "md" | (string & {});
export type DocumentContentBlock = {
    text: string;
};
export type DocumentContentBlocks = DocumentContentBlock[];
export type DocumentSource = {
    bytes: Uint8Array;
    s3Location?: never;
    text?: never;
    content?: never;
} | {
    bytes?: never;
    s3Location: S3Location;
    text?: never;
    content?: never;
} | {
    bytes?: never;
    s3Location?: never;
    text: string;
    content?: never;
} | {
    bytes?: never;
    s3Location?: never;
    text?: never;
    content: DocumentContentBlock[];
};
export interface CitationsConfig {
    enabled: boolean;
}
export interface DocumentBlock {
    format?: DocumentFormat;
    name: string;
    source: DocumentSource;
    context?: string;
    citations?: CitationsConfig;
}
export type VideoFormat = "mkv" | "mov" | "mp4" | "webm" | "flv" | "mpeg" | "mpg" | "wmv" | "three_gp" | (string & {});
export type VideoSource = {
    bytes: Uint8Array;
    s3Location?: never;
} | {
    bytes?: never;
    s3Location: S3Location;
};
export interface VideoBlock {
    format: VideoFormat;
    source: VideoSource;
}
export type AudioFormat = "mp3" | "opus" | "wav" | "aac" | "flac" | "mp4" | "ogg" | "mkv" | "mka" | "x-aac" | "m4a" | "mpeg" | "mpga" | "pcm" | "webm" | (string & {});
export type AudioSource = {
    bytes: Uint8Array;
    s3Location?: never;
} | {
    bytes?: never;
    s3Location: S3Location;
};
export interface AudioBlock {
    format: AudioFormat;
    source: AudioSource;
    error?: ErrorBlock;
}
export type ToolUseId = string;
export type ToolName = string;
export type ToolUseType = "server_tool_use" | (string & {});
export interface ToolUseBlock {
    toolUseId: string;
    name: string;
    input: any;
    type?: ToolUseType;
}
export interface SearchResultContentBlock {
    text: string;
}
export type SearchResultContentBlocks = SearchResultContentBlock[];
export interface SearchResultBlock {
    source: string;
    title: string;
    content: SearchResultContentBlock[];
    citations?: CitationsConfig;
}
export type ToolResultContentBlock = {
    json: any;
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    searchResult?: never;
} | {
    json?: never;
    text: string;
    image?: never;
    document?: never;
    video?: never;
    searchResult?: never;
} | {
    json?: never;
    text?: never;
    image: ImageBlock;
    document?: never;
    video?: never;
    searchResult?: never;
} | {
    json?: never;
    text?: never;
    image?: never;
    document: DocumentBlock;
    video?: never;
    searchResult?: never;
} | {
    json?: never;
    text?: never;
    image?: never;
    document?: never;
    video: VideoBlock;
    searchResult?: never;
} | {
    json?: never;
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    searchResult: SearchResultBlock;
};
export type ToolResultContentBlocks = ToolResultContentBlock[];
export type ToolResultStatus = "success" | "error" | (string & {});
export interface ToolResultBlock {
    toolUseId: string;
    content: ToolResultContentBlock[];
    status?: ToolResultStatus;
    type?: string;
}
export type GuardrailConverseContentQualifier = "grounding_source" | "query" | "guard_content" | (string & {});
export type GuardrailConverseContentQualifierList = GuardrailConverseContentQualifier[];
export interface GuardrailConverseTextBlock {
    text: string;
    qualifiers?: GuardrailConverseContentQualifier[];
}
export type GuardrailConverseImageFormat = "png" | "jpeg" | (string & {});
export type GuardrailConverseImageSource = {
    bytes: Uint8Array;
};
export interface GuardrailConverseImageBlock {
    format: GuardrailConverseImageFormat;
    source: GuardrailConverseImageSource;
}
export type GuardrailConverseContentBlock = {
    text: GuardrailConverseTextBlock;
    image?: never;
} | {
    text?: never;
    image: GuardrailConverseImageBlock;
};
export type CachePointType = "default" | (string & {});
export type CacheTTL = "5m" | "1h" | (string & {});
export interface CachePointBlock {
    type: CachePointType;
    ttl?: CacheTTL;
}
export interface ReasoningTextBlock {
    text: string;
    signature?: string;
}
export type ReasoningContentBlock = {
    reasoningText: ReasoningTextBlock;
    redactedContent?: never;
} | {
    reasoningText?: never;
    redactedContent: Uint8Array;
};
export type CitationGeneratedContent = {
    text: string;
};
export type CitationGeneratedContentList = CitationGeneratedContent[];
export type CitationSourceContent = {
    text: string;
};
export type CitationSourceContentList = CitationSourceContent[];
export interface WebLocation {
    url?: string;
    domain?: string;
}
export interface DocumentCharLocation {
    documentIndex?: number;
    start?: number;
    end?: number;
}
export interface DocumentPageLocation {
    documentIndex?: number;
    start?: number;
    end?: number;
}
export interface DocumentChunkLocation {
    documentIndex?: number;
    start?: number;
    end?: number;
}
export interface SearchResultLocation {
    searchResultIndex?: number;
    start?: number;
    end?: number;
}
export type CitationLocation = {
    web: WebLocation;
    documentChar?: never;
    documentPage?: never;
    documentChunk?: never;
    searchResultLocation?: never;
} | {
    web?: never;
    documentChar: DocumentCharLocation;
    documentPage?: never;
    documentChunk?: never;
    searchResultLocation?: never;
} | {
    web?: never;
    documentChar?: never;
    documentPage: DocumentPageLocation;
    documentChunk?: never;
    searchResultLocation?: never;
} | {
    web?: never;
    documentChar?: never;
    documentPage?: never;
    documentChunk: DocumentChunkLocation;
    searchResultLocation?: never;
} | {
    web?: never;
    documentChar?: never;
    documentPage?: never;
    documentChunk?: never;
    searchResultLocation: SearchResultLocation;
};
export interface Citation {
    title?: string;
    source?: string;
    sourceContent?: CitationSourceContent[];
    location?: CitationLocation;
}
export type Citations = Citation[];
export interface CitationsContentBlock {
    content?: CitationGeneratedContent[];
    citations?: Citation[];
}
export interface ToolReference {
    type?: string;
    name?: string;
    serverName?: string;
}
export interface ToolAdditionBlock {
    tool: ToolReference;
}
export interface ToolRemovalBlock {
    tool: ToolReference;
}
export type ContentBlock = {
    text: string;
    image?: never;
    document?: never;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image: ImageBlock;
    document?: never;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document: DocumentBlock;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video: VideoBlock;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    audio: AudioBlock;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    audio?: never;
    toolUse: ToolUseBlock;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult: ToolResultBlock;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent: GuardrailConverseContentBlock;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint: CachePointBlock;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent: ReasoningContentBlock;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent: CitationsContentBlock;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult: SearchResultBlock;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition: ToolAdditionBlock;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval: ToolRemovalBlock;
};
export type ContentBlocks = ContentBlock[];
export interface Message {
    role: ConversationRole;
    content: ContentBlock[];
}
export type Messages = Message[];
export type NonEmptyString = string;
export type SystemContentBlock = {
    text: string;
    guardContent?: never;
    cachePoint?: never;
} | {
    text?: never;
    guardContent: GuardrailConverseContentBlock;
    cachePoint?: never;
} | {
    text?: never;
    guardContent?: never;
    cachePoint: CachePointBlock;
};
export type SystemContentBlocks = SystemContentBlock[];
export type NonEmptyStringList = string[];
export interface InferenceConfiguration {
    maxTokens?: number;
    temperature?: number;
    topP?: number;
    stopSequences?: string[];
}
export type ToolInputSchema = {
    json: any;
};
export interface ToolSpecification {
    name: string;
    description?: string;
    inputSchema: ToolInputSchema;
    strict?: boolean;
}
export interface SystemTool {
    name: string;
}
export type Tool = {
    toolSpec: ToolSpecification;
    systemTool?: never;
    cachePoint?: never;
} | {
    toolSpec?: never;
    systemTool: SystemTool;
    cachePoint?: never;
} | {
    toolSpec?: never;
    systemTool?: never;
    cachePoint: CachePointBlock;
};
export type Tools = Tool[];
export interface AutoToolChoice {
}
export interface AnyToolChoice {
}
export interface SpecificToolChoice {
    name: string;
}
export type ToolChoice = {
    auto: AutoToolChoice;
    any?: never;
    tool?: never;
} | {
    auto?: never;
    any: AnyToolChoice;
    tool?: never;
} | {
    auto?: never;
    any?: never;
    tool: SpecificToolChoice;
};
export interface ToolConfiguration {
    tools: Tool[];
    toolChoice?: ToolChoice;
}
export type GuardrailTrace = "enabled" | "disabled" | "enabled_full" | (string & {});
export interface GuardrailConfiguration {
    guardrailIdentifier?: string;
    guardrailVersion?: string;
    trace?: GuardrailTrace;
}
export type PromptVariableValues = {
    text: string;
};
export type PromptVariableMap = {
    [key: string]: PromptVariableValues | undefined;
};
export type AdditionalModelResponseFieldPaths = string[];
export type RequestMetadata = {
    [key: string]: string | undefined;
};
export type PerformanceConfigLatency = "standard" | "optimized" | (string & {});
export interface PerformanceConfiguration {
    latency?: PerformanceConfigLatency;
}
export type ServiceTierType = "priority" | "default" | "flex" | "reserved" | (string & {});
export interface ServiceTier {
    type: ServiceTierType;
}
export type OutputFormatType = "json_schema" | (string & {});
export interface JsonSchemaDefinition {
    schema: string;
    name?: string;
    description?: string;
}
export type OutputFormatStructure = {
    jsonSchema: JsonSchemaDefinition;
};
export interface OutputFormat {
    type: OutputFormatType;
    structure: OutputFormatStructure;
}
export interface OutputConfig {
    textFormat?: OutputFormat;
    effort?: string;
}
export interface ConverseRequest {
    modelId: string;
    messages?: Message[];
    system?: SystemContentBlock[];
    inferenceConfig?: InferenceConfiguration;
    toolConfig?: ToolConfiguration;
    guardrailConfig?: GuardrailConfiguration;
    additionalModelRequestFields?: any;
    promptVariables?: {
        [key: string]: PromptVariableValues | undefined;
    };
    additionalModelResponseFieldPaths?: string[];
    requestMetadata?: {
        [key: string]: string | undefined;
    };
    performanceConfig?: PerformanceConfiguration;
    serviceTier?: ServiceTier;
    outputConfig?: OutputConfig;
}
export type ConverseOutput = {
    message: Message;
};
export type StopReason = "end_turn" | "tool_use" | "max_tokens" | "stop_sequence" | "guardrail_intervened" | "content_filtered" | "malformed_model_output" | "malformed_tool_use" | "model_context_window_exceeded" | (string & {});
export interface CacheDetail {
    ttl: CacheTTL;
    inputTokens: number;
}
export type CacheDetailsList = CacheDetail[];
export interface TokenUsage {
    inputTokens: number;
    outputTokens: number;
    totalTokens: number;
    cacheReadInputTokens?: number;
    cacheWriteInputTokens?: number;
    cacheDetails?: CacheDetail[];
}
export interface ConverseMetrics {
    latencyMs: number;
}
export type ModelOutputs = string[];
export type GuardrailAssessmentMap = {
    [key: string]: GuardrailAssessment | undefined;
};
export type GuardrailAssessmentListMap = {
    [key: string]: GuardrailAssessment[] | undefined;
};
export interface GuardrailTraceAssessment {
    modelOutput?: string[];
    inputAssessment?: {
        [key: string]: GuardrailAssessment | undefined;
    };
    outputAssessments?: {
        [key: string]: GuardrailAssessment[] | undefined;
    };
    actionReason?: string;
}
export type InvokedModelId = string;
export interface PromptRouterTrace {
    invokedModelId?: string;
}
export interface ConverseTrace {
    guardrail?: GuardrailTraceAssessment;
    promptRouter?: PromptRouterTrace;
}
export interface ConverseResponse {
    output: ConverseOutput;
    stopReason: StopReason;
    usage: TokenUsage;
    metrics: ConverseMetrics;
    additionalModelResponseFields?: any;
    trace?: ConverseTrace;
    performanceConfig?: PerformanceConfiguration;
    serviceTier?: ServiceTier;
}
export type GuardrailStreamProcessingMode = "sync" | "async" | (string & {});
export interface GuardrailStreamConfiguration {
    guardrailIdentifier?: string;
    guardrailVersion?: string;
    trace?: GuardrailTrace;
    streamProcessingMode?: GuardrailStreamProcessingMode;
}
export interface ConverseStreamRequest {
    modelId: string;
    messages?: Message[];
    system?: SystemContentBlock[];
    inferenceConfig?: InferenceConfiguration;
    toolConfig?: ToolConfiguration;
    guardrailConfig?: GuardrailStreamConfiguration;
    additionalModelRequestFields?: any;
    promptVariables?: {
        [key: string]: PromptVariableValues | undefined;
    };
    additionalModelResponseFieldPaths?: string[];
    requestMetadata?: {
        [key: string]: string | undefined;
    };
    performanceConfig?: PerformanceConfiguration;
    serviceTier?: ServiceTier;
    outputConfig?: OutputConfig;
}
export interface MessageStartEvent {
    role: ConversationRole;
}
export interface ToolUseBlockStart {
    toolUseId: string;
    name: string;
    type?: ToolUseType;
}
export interface ToolResultBlockStart {
    toolUseId: string;
    type?: string;
    status?: ToolResultStatus;
}
export interface ImageBlockStart {
    format: ImageFormat;
}
export type ContentBlockStart = {
    toolUse: ToolUseBlockStart;
    toolResult?: never;
    image?: never;
} | {
    toolUse?: never;
    toolResult: ToolResultBlockStart;
    image?: never;
} | {
    toolUse?: never;
    toolResult?: never;
    image: ImageBlockStart;
};
export type NonNegativeInteger = number;
export interface ContentBlockStartEvent {
    start: ContentBlockStart;
    contentBlockIndex: number;
}
export interface ToolUseBlockDelta {
    input: string;
}
export type ToolResultBlockDelta = {
    text: string;
    json?: never;
} | {
    text?: never;
    json: any;
};
export type ToolResultBlocksDelta = ToolResultBlockDelta[];
export type ReasoningContentBlockDelta = {
    text: string;
    redactedContent?: never;
    signature?: never;
} | {
    text?: never;
    redactedContent: Uint8Array;
    signature?: never;
} | {
    text?: never;
    redactedContent?: never;
    signature: string;
};
export interface CitationSourceContentDelta {
    text?: string;
}
export type CitationSourceContentListDelta = CitationSourceContentDelta[];
export interface CitationsDelta {
    title?: string;
    source?: string;
    sourceContent?: CitationSourceContentDelta[];
    location?: CitationLocation;
}
export interface ImageBlockDelta {
    source?: ImageSource;
    error?: ErrorBlock;
}
export type ContentBlockDelta = {
    text: string;
    toolUse?: never;
    toolResult?: never;
    reasoningContent?: never;
    citation?: never;
    image?: never;
} | {
    text?: never;
    toolUse: ToolUseBlockDelta;
    toolResult?: never;
    reasoningContent?: never;
    citation?: never;
    image?: never;
} | {
    text?: never;
    toolUse?: never;
    toolResult: ToolResultBlockDelta[];
    reasoningContent?: never;
    citation?: never;
    image?: never;
} | {
    text?: never;
    toolUse?: never;
    toolResult?: never;
    reasoningContent: ReasoningContentBlockDelta;
    citation?: never;
    image?: never;
} | {
    text?: never;
    toolUse?: never;
    toolResult?: never;
    reasoningContent?: never;
    citation: CitationsDelta;
    image?: never;
} | {
    text?: never;
    toolUse?: never;
    toolResult?: never;
    reasoningContent?: never;
    citation?: never;
    image: ImageBlockDelta;
};
export interface ContentBlockDeltaEvent {
    delta: ContentBlockDelta;
    contentBlockIndex: number;
}
export interface ContentBlockStopEvent {
    contentBlockIndex: number;
}
export interface MessageStopEvent {
    stopReason: StopReason;
    additionalModelResponseFields?: any;
}
export interface ConverseStreamMetrics {
    latencyMs: number;
}
export interface ConverseStreamTrace {
    guardrail?: GuardrailTraceAssessment;
    promptRouter?: PromptRouterTrace;
}
export interface ConverseStreamMetadataEvent {
    usage: TokenUsage;
    metrics: ConverseStreamMetrics;
    trace?: ConverseStreamTrace;
    performanceConfig?: PerformanceConfiguration;
    serviceTier?: ServiceTier;
}
export type NonBlankString = string;
export type StatusCode = number;
export type ConverseStreamOutput = {
    messageStart: MessageStartEvent;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    serviceUnavailableException?: never;
} | {
    messageStart?: never;
    contentBlockStart: ContentBlockStartEvent;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    serviceUnavailableException?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta: ContentBlockDeltaEvent;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    serviceUnavailableException?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop: ContentBlockStopEvent;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    serviceUnavailableException?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop: MessageStopEvent;
    metadata?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    serviceUnavailableException?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata: ConverseStreamMetadataEvent;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    serviceUnavailableException?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException: InternalServerException;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    serviceUnavailableException?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    modelStreamErrorException: ModelStreamErrorException;
    validationException?: never;
    throttlingException?: never;
    serviceUnavailableException?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException: ValidationException;
    throttlingException?: never;
    serviceUnavailableException?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException: ThrottlingException;
    serviceUnavailableException?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    serviceUnavailableException: ServiceUnavailableException;
};
export interface ConverseStreamResponse {
    stream?: stream.Stream<ConverseStreamOutput, Error, never>;
}
export type FoundationModelVersionIdentifier = string;
export type Body = Uint8Array | redacted.Redacted<Uint8Array>;
export interface InvokeModelTokensRequest {
    body: Uint8Array | redacted.Redacted<Uint8Array>;
}
export interface ConverseTokensRequest {
    messages?: Message[];
    system?: SystemContentBlock[];
    toolConfig?: ToolConfiguration;
    additionalModelRequestFields?: any;
}
export type CountTokensInput = {
    invokeModel: InvokeModelTokensRequest;
    converse?: never;
} | {
    invokeModel?: never;
    converse: ConverseTokensRequest;
};
export interface CountTokensRequest {
    modelId: string;
    input: CountTokensInput;
}
export interface CountTokensResponse {
    inputTokens: number;
}
export type InvocationArn = string;
export interface GetAsyncInvokeRequest {
    invocationArn: string;
}
export type AsyncInvokeArn = string;
export type AsyncInvokeIdempotencyToken = string;
export type AsyncInvokeStatus = "InProgress" | "Completed" | "Failed" | (string & {});
export type AsyncInvokeMessage = string | redacted.Redacted<string>;
export type KmsKeyId = string;
export interface AsyncInvokeS3OutputDataConfig {
    s3Uri: string;
    kmsKeyId?: string;
    bucketOwner?: string;
}
export type AsyncInvokeOutputDataConfig = {
    s3OutputDataConfig: AsyncInvokeS3OutputDataConfig;
};
export interface GetAsyncInvokeResponse {
    invocationArn: string;
    modelArn: string;
    clientRequestToken?: string;
    status: AsyncInvokeStatus;
    failureMessage?: string | redacted.Redacted<string>;
    submitTime: Date;
    lastModifiedTime?: Date;
    endTime?: Date;
    outputDataConfig: AsyncInvokeOutputDataConfig;
}
export type GuardrailChecksRole = "user" | "assistant" | "system" | (string & {});
export type GuardrailChecksTextContent = string | redacted.Redacted<string>;
export type GuardrailChecksContentBlock = {
    text: string | redacted.Redacted<string>;
};
export type GuardrailChecksContentBlockList = GuardrailChecksContentBlock[];
export interface GuardrailChecksMessage {
    role: GuardrailChecksRole;
    content: GuardrailChecksContentBlock[];
}
export type GuardrailChecksMessageList = GuardrailChecksMessage[];
export type GuardrailChecksContentFilterCategory = "VIOLENCE" | "HATE" | "SEXUAL" | "MISCONDUCT" | "INSULTS" | (string & {});
export interface GuardrailChecksContentFilterCategoryConfig {
    category: GuardrailChecksContentFilterCategory;
}
export type GuardrailChecksContentFilterCategoryConfigList = GuardrailChecksContentFilterCategoryConfig[];
export interface GuardrailChecksContentFilterConfig {
    categories: GuardrailChecksContentFilterCategoryConfig[];
}
export type GuardrailChecksPromptAttackCategory = "JAILBREAK" | "PROMPT_INJECTION" | "PROMPT_LEAKAGE" | (string & {});
export interface GuardrailChecksPromptAttackCategoryConfig {
    category: GuardrailChecksPromptAttackCategory;
}
export type GuardrailChecksPromptAttackCategoryConfigList = GuardrailChecksPromptAttackCategoryConfig[];
export interface GuardrailChecksPromptAttackConfig {
    categories: GuardrailChecksPromptAttackCategoryConfig[];
}
export type GuardrailChecksSensitiveInformationEntityType = "ADDRESS" | "AGE" | "AWS_ACCESS_KEY" | "AWS_SECRET_KEY" | "CA_HEALTH_NUMBER" | "CA_SOCIAL_INSURANCE_NUMBER" | "CREDIT_DEBIT_CARD_CVV" | "CREDIT_DEBIT_CARD_EXPIRY" | "CREDIT_DEBIT_CARD_NUMBER" | "DRIVER_ID" | "EMAIL" | "INTERNATIONAL_BANK_ACCOUNT_NUMBER" | "IP_ADDRESS" | "LICENSE_PLATE" | "MAC_ADDRESS" | "NAME" | "PASSWORD" | "PHONE" | "PIN" | "SWIFT_CODE" | "UK_NATIONAL_HEALTH_SERVICE_NUMBER" | "UK_NATIONAL_INSURANCE_NUMBER" | "UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER" | "URL" | "USERNAME" | "US_BANK_ACCOUNT_NUMBER" | "US_BANK_ROUTING_NUMBER" | "US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER" | "US_PASSPORT_NUMBER" | "US_SOCIAL_SECURITY_NUMBER" | "VEHICLE_IDENTIFICATION_NUMBER" | (string & {});
export interface GuardrailChecksSensitiveInformationEntityConfig {
    type: GuardrailChecksSensitiveInformationEntityType;
}
export type GuardrailChecksSensitiveInformationEntityConfigList = GuardrailChecksSensitiveInformationEntityConfig[];
export interface GuardrailChecksSensitiveInformationConfig {
    entities: GuardrailChecksSensitiveInformationEntityConfig[];
}
export interface GuardrailChecksConfig {
    contentFilter?: GuardrailChecksContentFilterConfig;
    promptAttack?: GuardrailChecksPromptAttackConfig;
    sensitiveInformation?: GuardrailChecksSensitiveInformationConfig;
}
export interface InvokeGuardrailChecksRequest {
    messages: GuardrailChecksMessage[];
    checks: GuardrailChecksConfig;
}
export interface GuardrailChecksContentFilterResultEntry {
    category: GuardrailChecksContentFilterCategory;
    severityScore: number;
}
export type GuardrailChecksContentFilterResultList = GuardrailChecksContentFilterResultEntry[];
export interface GuardrailChecksContentFilterResult {
    results: GuardrailChecksContentFilterResultEntry[];
}
export interface GuardrailChecksPromptAttackResultEntry {
    category: GuardrailChecksPromptAttackCategory;
    severityScore: number;
}
export type GuardrailChecksPromptAttackResultList = GuardrailChecksPromptAttackResultEntry[];
export interface GuardrailChecksPromptAttackResult {
    results: GuardrailChecksPromptAttackResultEntry[];
}
export interface GuardrailChecksSensitiveInformationResultEntry {
    type: GuardrailChecksSensitiveInformationEntityType;
    confidenceScore: number;
    beginOffset: number;
    endOffset: number;
    messageIndex: number;
    contentIndex: number;
}
export type GuardrailChecksSensitiveInformationResultList = GuardrailChecksSensitiveInformationResultEntry[];
export interface GuardrailChecksSensitiveInformationResult {
    results: GuardrailChecksSensitiveInformationResultEntry[];
    truncated?: boolean;
}
export interface GuardrailChecksResults {
    contentFilter?: GuardrailChecksContentFilterResult;
    promptAttack?: GuardrailChecksPromptAttackResult;
    sensitiveInformation?: GuardrailChecksSensitiveInformationResult;
}
export interface GuardrailChecksContentFilterUsage {
    textUnits: number;
}
export interface GuardrailChecksPromptAttackUsage {
    textUnits: number;
}
export interface GuardrailChecksSensitiveInformationUsage {
    textUnits: number;
}
export interface GuardrailChecksUsageResults {
    contentFilter?: GuardrailChecksContentFilterUsage;
    promptAttack?: GuardrailChecksPromptAttackUsage;
    sensitiveInformation?: GuardrailChecksSensitiveInformationUsage;
}
export interface InvokeGuardrailChecksResponse {
    results: GuardrailChecksResults;
    usage: GuardrailChecksUsageResults;
}
export type MimeType = string;
export type InvokeModelIdentifier = string;
export type Trace = "ENABLED" | "DISABLED" | "ENABLED_FULL" | (string & {});
export type RequestMetadataJson = string | redacted.Redacted<string>;
export interface InvokeModelRequest {
    body?: T.StreamingInputBody;
    contentType?: string;
    accept?: string;
    modelId: string;
    trace?: Trace;
    guardrailIdentifier?: string;
    guardrailVersion?: string;
    performanceConfigLatency?: PerformanceConfigLatency;
    serviceTier?: ServiceTierType;
    requestMetadata?: string | redacted.Redacted<string>;
}
export interface InvokeModelResponse {
    body: T.StreamingOutputBody;
    contentType: string;
    performanceConfigLatency?: PerformanceConfigLatency;
    serviceTier?: ServiceTierType;
}
export type PartBody = Uint8Array | redacted.Redacted<Uint8Array>;
export interface BidirectionalInputPayloadPart {
    bytes?: Uint8Array | redacted.Redacted<Uint8Array>;
}
export type InvokeModelWithBidirectionalStreamInput = {
    chunk: BidirectionalInputPayloadPart;
};
export interface InvokeModelWithBidirectionalStreamRequest {
    modelId: string;
    body: stream.Stream<InvokeModelWithBidirectionalStreamInput, Error, never>;
}
export interface BidirectionalOutputPayloadPart {
    bytes?: Uint8Array | redacted.Redacted<Uint8Array>;
}
export type InvokeModelWithBidirectionalStreamOutput = {
    chunk: BidirectionalOutputPayloadPart;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    modelTimeoutException?: never;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException: InternalServerException;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    modelTimeoutException?: never;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException?: never;
    modelStreamErrorException: ModelStreamErrorException;
    validationException?: never;
    throttlingException?: never;
    modelTimeoutException?: never;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException: ValidationException;
    throttlingException?: never;
    modelTimeoutException?: never;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException: ThrottlingException;
    modelTimeoutException?: never;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    modelTimeoutException: ModelTimeoutException;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    modelTimeoutException?: never;
    serviceUnavailableException: ServiceUnavailableException;
};
export interface InvokeModelWithBidirectionalStreamResponse {
    body: stream.Stream<InvokeModelWithBidirectionalStreamOutput, Error, never>;
}
export interface InvokeModelWithResponseStreamRequest {
    body?: T.StreamingInputBody;
    contentType?: string;
    accept?: string;
    modelId: string;
    trace?: Trace;
    guardrailIdentifier?: string;
    guardrailVersion?: string;
    performanceConfigLatency?: PerformanceConfigLatency;
    serviceTier?: ServiceTierType;
    requestMetadata?: string | redacted.Redacted<string>;
}
export interface PayloadPart {
    bytes?: Uint8Array | redacted.Redacted<Uint8Array>;
}
export type ResponseStream = {
    chunk: PayloadPart;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    modelTimeoutException?: never;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException: InternalServerException;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    modelTimeoutException?: never;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException?: never;
    modelStreamErrorException: ModelStreamErrorException;
    validationException?: never;
    throttlingException?: never;
    modelTimeoutException?: never;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException: ValidationException;
    throttlingException?: never;
    modelTimeoutException?: never;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException: ThrottlingException;
    modelTimeoutException?: never;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    modelTimeoutException: ModelTimeoutException;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    modelTimeoutException?: never;
    serviceUnavailableException: ServiceUnavailableException;
};
export interface InvokeModelWithResponseStreamResponse {
    body: stream.Stream<ResponseStream, Error, never>;
    contentType: string;
    performanceConfigLatency?: PerformanceConfigLatency;
    serviceTier?: ServiceTierType;
}
export type MaxResults = number;
export type PaginationToken = string;
export type SortAsyncInvocationBy = "SubmissionTime" | (string & {});
export type SortOrder = "Ascending" | "Descending" | (string & {});
export interface ListAsyncInvokesRequest {
    submitTimeAfter?: Date;
    submitTimeBefore?: Date;
    statusEquals?: AsyncInvokeStatus;
    maxResults?: number;
    nextToken?: string;
    sortBy?: SortAsyncInvocationBy;
    sortOrder?: SortOrder;
}
export interface AsyncInvokeSummary {
    invocationArn: string;
    modelArn: string;
    clientRequestToken?: string;
    status?: AsyncInvokeStatus;
    failureMessage?: string | redacted.Redacted<string>;
    submitTime: Date;
    lastModifiedTime?: Date;
    endTime?: Date;
    outputDataConfig: AsyncInvokeOutputDataConfig;
}
export type AsyncInvokeSummaries = AsyncInvokeSummary[];
export interface ListAsyncInvokesResponse {
    nextToken?: string;
    asyncInvokeSummaries?: AsyncInvokeSummary[];
}
export type AsyncInvokeIdentifier = string;
export type ModelInputPayload = unknown;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagList = Tag[];
export interface StartAsyncInvokeRequest {
    clientRequestToken?: string;
    modelId: string;
    modelInput: any;
    outputDataConfig: AsyncInvokeOutputDataConfig;
    tags?: Tag[];
}
export interface StartAsyncInvokeResponse {
    invocationArn: string;
}
export type ApplyGuardrailError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The action to apply a guardrail.
 *
 * For troubleshooting some of the common errors you might encounter when using the `ApplyGuardrail` API, see Troubleshooting Amazon Bedrock API Error Codes in the Amazon Bedrock User Guide
 */
export declare const applyGuardrail: API.OperationMethod<ApplyGuardrailRequest, ApplyGuardrailResponse, ApplyGuardrailError, Credentials | HttpClient.HttpClient>;
export type ConverseError = AccessDeniedException | InternalServerException | ModelErrorException | ModelNotReadyException | ModelTimeoutException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends messages to the specified Amazon Bedrock model. `Converse` provides a consistent interface that works with all models that support messages. This allows you to write code once and use it with different models. If a model has unique inference parameters, you can also pass those unique parameters to the model.
 *
 * Amazon Bedrock doesn't store any text, images, or documents that you provide as content. The data is only used to generate the response.
 *
 * You can submit a prompt by including it in the `messages` field, specifying the `modelId` of a foundation model or inference profile to run inference on it, and including any other fields that are relevant to your use case.
 *
 * You can also submit a prompt from Prompt management by specifying the ARN of the prompt version and including a map of variables to values in the `promptVariables` field. You can append more messages to the prompt by using the `messages` field. If you use a prompt from Prompt management, you can't include the following fields in the request: `additionalModelRequestFields`, `inferenceConfig`, `system`, or `toolConfig`. Instead, these fields must be defined through Prompt management. For more information, see Use a prompt from Prompt management.
 *
 * For information about the Converse API, see *Use the Converse API* in the *Amazon Bedrock User Guide*. To use a guardrail, see *Use a guardrail with the Converse API* in the *Amazon Bedrock User Guide*. To use a tool with a model, see *Tool use (Function calling)* in the *Amazon Bedrock User Guide*
 *
 * For example code, see *Converse API examples* in the *Amazon Bedrock User Guide*.
 *
 * This operation requires permission for the `bedrock:InvokeModel` action.
 *
 * To deny all inference access to resources that you specify in the modelId field, you need to deny access to the `bedrock:InvokeModel` and `bedrock:InvokeModelWithResponseStream` actions. Doing this also denies access to the resource through the base inference actions (InvokeModel and InvokeModelWithResponseStream). For more information see Deny access for inference on specific models.
 *
 * For troubleshooting some of the common errors you might encounter when using the `Converse` API, see Troubleshooting Amazon Bedrock API Error Codes in the Amazon Bedrock User Guide
 */
export declare const converse: API.OperationMethod<ConverseRequest, ConverseResponse, ConverseError, Credentials | HttpClient.HttpClient>;
export type ConverseStreamError = AccessDeniedException | InternalServerException | ModelErrorException | ModelNotReadyException | ModelTimeoutException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends messages to the specified Amazon Bedrock model and returns the response in a stream. `ConverseStream` provides a consistent API that works with all Amazon Bedrock models that support messages. This allows you to write code once and use it with different models. Should a model have unique inference parameters, you can also pass those unique parameters to the model.
 *
 * To find out if a model supports streaming, call GetFoundationModel and check the `responseStreamingSupported` field in the response.
 *
 * The CLI doesn't support streaming operations in Amazon Bedrock, including `ConverseStream`.
 *
 * Amazon Bedrock doesn't store any text, images, or documents that you provide as content. The data is only used to generate the response.
 *
 * You can submit a prompt by including it in the `messages` field, specifying the `modelId` of a foundation model or inference profile to run inference on it, and including any other fields that are relevant to your use case.
 *
 * You can also submit a prompt from Prompt management by specifying the ARN of the prompt version and including a map of variables to values in the `promptVariables` field. You can append more messages to the prompt by using the `messages` field. If you use a prompt from Prompt management, you can't include the following fields in the request: `additionalModelRequestFields`, `inferenceConfig`, `system`, or `toolConfig`. Instead, these fields must be defined through Prompt management. For more information, see Use a prompt from Prompt management.
 *
 * For information about the Converse API, see *Use the Converse API* in the *Amazon Bedrock User Guide*. To use a guardrail, see *Use a guardrail with the Converse API* in the *Amazon Bedrock User Guide*. To use a tool with a model, see *Tool use (Function calling)* in the *Amazon Bedrock User Guide*
 *
 * For example code, see *Conversation streaming example* in the *Amazon Bedrock User Guide*.
 *
 * This operation requires permission for the `bedrock:InvokeModelWithResponseStream` action.
 *
 * To deny all inference access to resources that you specify in the modelId field, you need to deny access to the `bedrock:InvokeModel` and `bedrock:InvokeModelWithResponseStream` actions. Doing this also denies access to the resource through the base inference actions (InvokeModel and InvokeModelWithResponseStream). For more information see Deny access for inference on specific models.
 *
 * For troubleshooting some of the common errors you might encounter when using the `ConverseStream` API, see Troubleshooting Amazon Bedrock API Error Codes in the Amazon Bedrock User Guide
 */
export declare const converseStream: API.OperationMethod<ConverseStreamRequest, ConverseStreamResponse, ConverseStreamError, Credentials | HttpClient.HttpClient>;
export type CountTokensError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the token count for a given inference request. This operation helps you estimate token usage before sending requests to foundation models by returning the token count that would be used if the same input were sent to the model in an inference request.
 *
 * Token counting is model-specific because different models use different tokenization strategies. The token count returned by this operation will match the token count that would be charged if the same input were sent to the model in an `InvokeModel` or `Converse` request.
 *
 * You can use this operation to:
 *
 * - Estimate costs before sending inference requests.
 *
 * - Optimize prompts to fit within token limits.
 *
 * - Plan for token usage in your applications.
 *
 * This operation accepts the same input formats as `InvokeModel` and `Converse`, allowing you to count tokens for both raw text inputs and structured conversation formats.
 *
 * The following operations are related to `CountTokens`:
 *
 * - InvokeModel - Sends inference requests to foundation models
 *
 * - Converse - Sends conversation-based inference requests to foundation models
 */
export declare const countTokens: API.OperationMethod<CountTokensRequest, CountTokensResponse, CountTokensError, Credentials | HttpClient.HttpClient>;
export type GetAsyncInvokeError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieve information about an asynchronous invocation.
 */
export declare const getAsyncInvoke: API.OperationMethod<GetAsyncInvokeRequest, GetAsyncInvokeResponse, GetAsyncInvokeError, Credentials | HttpClient.HttpClient>;
export type InvokeGuardrailChecksError = AccessDeniedException | InternalServerException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Evaluates messages against inline guardrail checks. You specify the check configurations directly in the request, and Amazon Bedrock returns per-check results with severity or confidence scores.
 */
export declare const invokeGuardrailChecks: API.OperationMethod<InvokeGuardrailChecksRequest, InvokeGuardrailChecksResponse, InvokeGuardrailChecksError, Credentials | HttpClient.HttpClient>;
export type InvokeModelError = AccessDeniedException | InternalServerException | ModelErrorException | ModelNotReadyException | ModelTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Invokes the specified Amazon Bedrock model to run inference using the prompt and inference parameters provided in the request body. You use model inference to generate text, images, and embeddings.
 *
 * For example code, see *Invoke model code examples* in the *Amazon Bedrock User Guide*.
 *
 * This operation requires permission for the `bedrock:InvokeModel` action.
 *
 * To deny all inference access to resources that you specify in the modelId field, you need to deny access to the `bedrock:InvokeModel` and `bedrock:InvokeModelWithResponseStream` actions. Doing this also denies access to the resource through the Converse API actions (Converse and ConverseStream). For more information see Deny access for inference on specific models.
 *
 * For troubleshooting some of the common errors you might encounter when using the `InvokeModel` API, see Troubleshooting Amazon Bedrock API Error Codes in the Amazon Bedrock User Guide
 */
export declare const invokeModel: API.OperationMethod<InvokeModelRequest, InvokeModelResponse, InvokeModelError, Credentials | HttpClient.HttpClient>;
export type InvokeModelWithBidirectionalStreamError = AccessDeniedException | InternalServerException | ModelErrorException | ModelNotReadyException | ModelStreamErrorException | ModelTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Invoke the specified Amazon Bedrock model to run inference using the bidirectional stream. The response is returned in a stream that remains open for 8 minutes. A single session can contain multiple prompts and responses from the model. The prompts to the model are provided as audio files and the model's responses are spoken back to the user and transcribed.
 *
 * It is possible for users to interrupt the model's response with a new prompt, which will halt the response speech. The model will retain contextual awareness of the conversation while pivoting to respond to the new prompt.
 */
export declare const invokeModelWithBidirectionalStream: API.OperationMethod<InvokeModelWithBidirectionalStreamRequest, InvokeModelWithBidirectionalStreamResponse, InvokeModelWithBidirectionalStreamError, Credentials | HttpClient.HttpClient>;
export type InvokeModelWithResponseStreamError = AccessDeniedException | InternalServerException | ModelErrorException | ModelNotReadyException | ModelStreamErrorException | ModelTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Invoke the specified Amazon Bedrock model to run inference using the prompt and inference parameters provided in the request body. The response is returned in a stream.
 *
 * To see if a model supports streaming, call GetFoundationModel and check the `responseStreamingSupported` field in the response.
 *
 * The CLI doesn't support streaming operations in Amazon Bedrock, including `InvokeModelWithResponseStream`.
 *
 * For example code, see *Invoke model with streaming code example* in the *Amazon Bedrock User Guide*.
 *
 * This operation requires permissions to perform the `bedrock:InvokeModelWithResponseStream` action.
 *
 * To deny all inference access to resources that you specify in the modelId field, you need to deny access to the `bedrock:InvokeModel` and `bedrock:InvokeModelWithResponseStream` actions. Doing this also denies access to the resource through the Converse API actions (Converse and ConverseStream). For more information see Deny access for inference on specific models.
 *
 * For troubleshooting some of the common errors you might encounter when using the `InvokeModelWithResponseStream` API, see Troubleshooting Amazon Bedrock API Error Codes in the Amazon Bedrock User Guide
 */
export declare const invokeModelWithResponseStream: API.OperationMethod<InvokeModelWithResponseStreamRequest, InvokeModelWithResponseStreamResponse, InvokeModelWithResponseStreamError, Credentials | HttpClient.HttpClient>;
export type ListAsyncInvokesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists asynchronous invocations.
 */
export declare const listAsyncInvokes: API.PaginatedOperationMethod<ListAsyncInvokesRequest, ListAsyncInvokesResponse, ListAsyncInvokesError, Credentials | HttpClient.HttpClient, AsyncInvokeSummary>;
export type StartAsyncInvokeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts an asynchronous invocation.
 *
 * This operation requires permission for the `bedrock:InvokeModel` action.
 *
 * To deny all inference access to resources that you specify in the modelId field, you need to deny access to the `bedrock:InvokeModel` and `bedrock:InvokeModelWithResponseStream` actions. Doing this also denies access to the resource through the Converse API actions (Converse and ConverseStream). For more information see Deny access for inference on specific models.
 */
export declare const startAsyncInvoke: API.OperationMethod<StartAsyncInvokeRequest, StartAsyncInvokeResponse, StartAsyncInvokeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bedrock-runtime.d.ts.map