import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly errorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly errorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly errorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly errorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceUnavailableException_base: S.TaggedErrorClass<"ResourceUnavailableException", {
    readonly message: any;
    readonly errorType: any;
}>;
export declare class ResourceUnavailableException extends /*@__PURE__*/ ResourceUnavailableException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
    readonly errorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: S.Schema<string | redacted.Redacted<string>>;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type AccountId = string;
export type PrimaryEmailAddress = string | redacted.Redacted<string>;
export type Otp = string | redacted.Redacted<string>;
export interface AcceptPrimaryEmailUpdateRequest {
    AccountId: string;
    PrimaryEmail: string | redacted.Redacted<string>;
    Otp: string | redacted.Redacted<string>;
}
export type PrimaryEmailUpdateStatus = string;
export interface AcceptPrimaryEmailUpdateResponse {
    Status?: string;
}
export type AlternateContactType = string;
export interface DeleteAlternateContactRequest {
    AlternateContactType: string;
    AccountId?: string;
}
export interface DeleteAlternateContactResponse {
}
export type RegionName = string;
export interface DisableRegionRequest {
    AccountId?: string;
    RegionName: string;
}
export interface DisableRegionResponse {
}
export interface EnableRegionRequest {
    AccountId?: string;
    RegionName: string;
}
export interface EnableRegionResponse {
}
export interface GetAccountInformationRequest {
    AccountId?: string;
}
export type AccountName = string | redacted.Redacted<string>;
export type AccountCreatedDate = Date;
export type AccountState = string;
export interface GetAccountInformationResponse {
    AccountId?: string;
    AccountName?: string | redacted.Redacted<string>;
    AccountCreatedDate?: Date;
    AccountState?: string;
}
export interface GetAlternateContactRequest {
    AlternateContactType: string;
    AccountId?: string;
}
export type Name = string | redacted.Redacted<string>;
export type Title = string | redacted.Redacted<string>;
export type EmailAddress = string | redacted.Redacted<string>;
export type PhoneNumber = string | redacted.Redacted<string>;
export interface AlternateContact {
    Name?: string | redacted.Redacted<string>;
    Title?: string | redacted.Redacted<string>;
    EmailAddress?: string | redacted.Redacted<string>;
    PhoneNumber?: string | redacted.Redacted<string>;
    AlternateContactType?: string;
}
export interface GetAlternateContactResponse {
    AlternateContact?: AlternateContact;
}
export interface GetContactInformationRequest {
    AccountId?: string;
}
export type FullName = string | redacted.Redacted<string>;
export type AddressLine = string | redacted.Redacted<string>;
export type City = string | redacted.Redacted<string>;
export type StateOrRegion = string | redacted.Redacted<string>;
export type DistrictOrCounty = string | redacted.Redacted<string>;
export type PostalCode = string | redacted.Redacted<string>;
export type CountryCode = string | redacted.Redacted<string>;
export type ContactInformationPhoneNumber = string | redacted.Redacted<string>;
export type CompanyName = string | redacted.Redacted<string>;
export type WebsiteUrl = string | redacted.Redacted<string>;
export interface ContactInformation {
    FullName: string | redacted.Redacted<string>;
    AddressLine1: string | redacted.Redacted<string>;
    AddressLine2?: string | redacted.Redacted<string>;
    AddressLine3?: string | redacted.Redacted<string>;
    City: string | redacted.Redacted<string>;
    StateOrRegion?: string | redacted.Redacted<string>;
    DistrictOrCounty?: string | redacted.Redacted<string>;
    PostalCode: string | redacted.Redacted<string>;
    CountryCode: string | redacted.Redacted<string>;
    PhoneNumber: string | redacted.Redacted<string>;
    CompanyName?: string | redacted.Redacted<string>;
    WebsiteUrl?: string | redacted.Redacted<string>;
}
export type PhoneNumberVerificationStatus = string;
export interface GetContactInformationResponse {
    ContactInformation?: ContactInformation;
    VerificationStatus?: string;
}
export interface GetGovCloudAccountInformationRequest {
    StandardAccountId?: string;
}
export type AwsAccountState = string;
export interface GetGovCloudAccountInformationResponse {
    GovCloudAccountId: string;
    AccountState: string;
}
export interface GetPrimaryEmailRequest {
    AccountId: string;
}
export interface GetPrimaryEmailResponse {
    PrimaryEmail?: string | redacted.Redacted<string>;
}
export interface GetPrimaryEmailUpdateStatusRequest {
    AccountId?: string;
}
export interface GetPrimaryEmailUpdateStatusResponse {
    Status: string;
    UpdatedAt?: Date;
}
export interface GetRegionOptStatusRequest {
    AccountId?: string;
    RegionName: string;
}
export type RegionOptStatus = string;
export interface GetRegionOptStatusResponse {
    RegionName?: string;
    RegionOptStatus?: string;
}
export type RegionOptStatusList = string[];
export interface ListRegionsRequest {
    AccountId?: string;
    MaxResults?: number;
    NextToken?: string;
    RegionOptStatusContains?: string[];
}
export interface Region {
    RegionName?: string;
    RegionOptStatus?: string;
}
export type RegionOptList = Region[];
export interface ListRegionsResponse {
    NextToken?: string;
    Regions?: Region[];
}
export interface PutAccountNameRequest {
    AccountName: string | redacted.Redacted<string>;
    AccountId?: string;
}
export interface PutAccountNameResponse {
}
export interface PutAlternateContactRequest {
    Name: string | redacted.Redacted<string>;
    Title: string | redacted.Redacted<string>;
    EmailAddress: string | redacted.Redacted<string>;
    PhoneNumber: string | redacted.Redacted<string>;
    AlternateContactType: string;
    AccountId?: string;
}
export interface PutAlternateContactResponse {
}
export interface PutContactInformationRequest {
    ContactInformation: ContactInformation;
    AccountId?: string;
}
export interface PutContactInformationResponse {
}
export interface SendPhoneNumberVerificationRequest {
    AccountId?: string;
}
export interface SendPhoneNumberVerificationResponse {
    Status?: string;
}
export interface StartPrimaryEmailUpdateRequest {
    AccountId: string;
    PrimaryEmail: string | redacted.Redacted<string>;
}
export interface StartPrimaryEmailUpdateResponse {
    Status?: string;
}
export interface VerifyPhoneNumberRequest {
    AccountId?: string;
    Otp: string | redacted.Redacted<string>;
}
export interface VerifyPhoneNumberResponse {
    Status?: string;
}
export type SensitiveString = string | redacted.Redacted<string>;
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    name: string;
    message: string | redacted.Redacted<string>;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AcceptPrimaryEmailUpdateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Accepts the request that originated from StartPrimaryEmailUpdate to update the primary email address (also known as the root user email address) for the specified account.
 */
export declare const acceptPrimaryEmailUpdate: API.OperationMethod<AcceptPrimaryEmailUpdateRequest, AcceptPrimaryEmailUpdateResponse, AcceptPrimaryEmailUpdateError, Credentials | HttpClient.HttpClient>;
export type DeleteAlternateContactError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Deletes the specified alternate contact from an Amazon Web Services account.
 *
 * For complete details about how to use the alternate contact operations, see Update the alternate contacts for your Amazon Web Services account.
 *
 * Before you can update the alternate contact information for an Amazon Web Services account that is managed by Organizations, you must first enable integration between Amazon Web Services Account Management and Organizations. For more information, see Enable trusted access for Amazon Web Services Account Management.
 */
export declare const deleteAlternateContact: API.OperationMethod<DeleteAlternateContactRequest, DeleteAlternateContactResponse, DeleteAlternateContactError, Credentials | HttpClient.HttpClient>;
export type DisableRegionError = AccessDeniedException | ConflictException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Disables (opts-out) a particular Region for an account.
 *
 * The act of disabling a Region will remove all IAM access to any resources that reside in that Region.
 */
export declare const disableRegion: API.OperationMethod<DisableRegionRequest, DisableRegionResponse, DisableRegionError, Credentials | HttpClient.HttpClient>;
export type EnableRegionError = AccessDeniedException | ConflictException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Enables (opts-in) a particular Region for an account.
 */
export declare const enableRegion: API.OperationMethod<EnableRegionRequest, EnableRegionResponse, EnableRegionError, Credentials | HttpClient.HttpClient>;
export type GetAccountInformationError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified account including its account name, account ID, account creation date and time, and account state. To use this API, an IAM user or role must have the `account:GetAccountInformation` IAM permission.
 */
export declare const getAccountInformation: API.OperationMethod<GetAccountInformationRequest, GetAccountInformationResponse, GetAccountInformationError, Credentials | HttpClient.HttpClient>;
export type GetAlternateContactError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Retrieves the specified alternate contact attached to an Amazon Web Services account.
 *
 * For complete details about how to use the alternate contact operations, see Update the alternate contacts for your Amazon Web Services account.
 *
 * Before you can update the alternate contact information for an Amazon Web Services account that is managed by Organizations, you must first enable integration between Amazon Web Services Account Management and Organizations. For more information, see Enable trusted access for Amazon Web Services Account Management.
 */
export declare const getAlternateContact: API.OperationMethod<GetAlternateContactRequest, GetAlternateContactResponse, GetAlternateContactError, Credentials | HttpClient.HttpClient>;
export type GetContactInformationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Retrieves the primary contact information of an Amazon Web Services account.
 *
 * For complete details about how to use the primary contact operations, see Update the primary contact for your Amazon Web Services account.
 */
export declare const getContactInformation: API.OperationMethod<GetContactInformationRequest, GetContactInformationResponse, GetContactInformationError, Credentials | HttpClient.HttpClient>;
export type GetGovCloudAccountInformationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ResourceUnavailableException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Retrieves information about the GovCloud account linked to the specified standard account (if it exists) including the GovCloud account ID and state. To use this API, an IAM user or role must have the `account:GetGovCloudAccountInformation` IAM permission.
 */
export declare const getGovCloudAccountInformation: API.OperationMethod<GetGovCloudAccountInformationRequest, GetGovCloudAccountInformationResponse, GetGovCloudAccountInformationError, Credentials | HttpClient.HttpClient>;
export type GetPrimaryEmailError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Retrieves the primary email address for the specified account.
 */
export declare const getPrimaryEmail: API.OperationMethod<GetPrimaryEmailRequest, GetPrimaryEmailResponse, GetPrimaryEmailError, Credentials | HttpClient.HttpClient>;
export type GetPrimaryEmailUpdateStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Retrieves the status of the most recent primary email update for the specified account. For complete details about how to update the primary email address, see Update the primary email address for your AWS account.
 */
export declare const getPrimaryEmailUpdateStatus: API.OperationMethod<GetPrimaryEmailUpdateStatusRequest, GetPrimaryEmailUpdateStatusResponse, GetPrimaryEmailUpdateStatusError, Credentials | HttpClient.HttpClient>;
export type GetRegionOptStatusError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Retrieves the opt-in status of a particular Region.
 */
export declare const getRegionOptStatus: API.OperationMethod<GetRegionOptStatusRequest, GetRegionOptStatusResponse, GetRegionOptStatusError, Credentials | HttpClient.HttpClient>;
export type ListRegionsError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Lists all the Regions for a given account and their respective opt-in statuses. Optionally, this list can be filtered by the `region-opt-status-contains` parameter.
 */
export declare const listRegions: API.PaginatedOperationMethod<ListRegionsRequest, ListRegionsResponse, ListRegionsError, Credentials | HttpClient.HttpClient, Region>;
export type PutAccountNameError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Updates the account name of the specified account. To use this API, IAM principals must have the `account:PutAccountName` IAM permission.
 */
export declare const putAccountName: API.OperationMethod<PutAccountNameRequest, PutAccountNameResponse, PutAccountNameError, Credentials | HttpClient.HttpClient>;
export type PutAlternateContactError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Modifies the specified alternate contact attached to an Amazon Web Services account.
 *
 * For complete details about how to use the alternate contact operations, see Update the alternate contacts for your Amazon Web Services account.
 *
 * Before you can update the alternate contact information for an Amazon Web Services account that is managed by Organizations, you must first enable integration between Amazon Web Services Account Management and Organizations. For more information, see Enable trusted access for Amazon Web Services Account Management.
 */
export declare const putAlternateContact: API.OperationMethod<PutAlternateContactRequest, PutAlternateContactResponse, PutAlternateContactError, Credentials | HttpClient.HttpClient>;
export type PutContactInformationError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Updates the primary contact information of an Amazon Web Services account.
 *
 * For complete details about how to use the primary contact operations, see Update the primary contact for your Amazon Web Services account.
 */
export declare const putContactInformation: API.OperationMethod<PutContactInformationRequest, PutContactInformationResponse, PutContactInformationError, Credentials | HttpClient.HttpClient>;
export type SendPhoneNumberVerificationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Sends a one-time passcode to the phone number in the primary contact information of an Amazon Web Services account. Use VerifyPhoneNumber to submit the passcode and complete the verification.
 *
 * For complete details about how to use the primary contact operations, see Update the primary contact for your Amazon Web Services account.
 */
export declare const sendPhoneNumberVerification: API.OperationMethod<SendPhoneNumberVerificationRequest, SendPhoneNumberVerificationResponse, SendPhoneNumberVerificationError, Credentials | HttpClient.HttpClient>;
export type StartPrimaryEmailUpdateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Starts the process to update the primary email address for the specified account.
 */
export declare const startPrimaryEmailUpdate: API.OperationMethod<StartPrimaryEmailUpdateRequest, StartPrimaryEmailUpdateResponse, StartPrimaryEmailUpdateError, Credentials | HttpClient.HttpClient>;
export type VerifyPhoneNumberError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Verifies the phone number in the primary contact information of an Amazon Web Services account by submitting the one-time passcode that SendPhoneNumberVerification sent to that phone number.
 *
 * For complete details about how to use the primary contact operations, see Update the primary contact for your Amazon Web Services account.
 */
export declare const verifyPhoneNumber: API.OperationMethod<VerifyPhoneNumberRequest, VerifyPhoneNumberResponse, VerifyPhoneNumberError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=account.d.ts.map