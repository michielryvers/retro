import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type RegistryIdentifier = string;
export type RecordIdentifier = string;
export type RegistryRecordIdList = string[];
export interface RegistryRecordsEntry {
    registryId: string;
    recordIds: string[];
}
export type RegistryRecordsEntryList = RegistryRecordsEntry[];
export interface BatchGetDiscoverableRegistryRecordRequest {
    entries: RegistryRecordsEntry[];
}
export type RegistryArn = string;
export type RegistryRecordArn = string;
export type RegistryRecordId = string;
export type RegistryRecordName = string;
export type Description = string | redacted.Redacted<string>;
export type RegistryRecordDisplayName = string;
export type RecordType = "MCP" | "AGENT" | "CUSTOM" | "SKILL" | "GATEWAY" | (string & {});
export type DescriptorData = string | redacted.Redacted<string>;
export type DataSchemaVersion = string;
export interface McpToolsDescriptor {
    data?: string | redacted.Redacted<string>;
    dataSchemaVersion?: string;
}
export interface McpServerAdditionalData {
    tools?: McpToolsDescriptor;
}
export type DescriptorSourceUrl = string;
export interface DescriptorSourceFromUrl {
    url: string;
}
export interface DescriptorSource {
    fromUrl?: DescriptorSourceFromUrl;
}
export interface McpServerDescriptor {
    data?: string | redacted.Redacted<string>;
    dataSchemaVersion?: string;
    additionalData?: McpServerAdditionalData;
    source?: DescriptorSource;
}
export interface A2aAgentCardDescriptor {
    data?: string | redacted.Redacted<string>;
    dataSchemaVersion?: string;
    source?: DescriptorSource;
}
export interface AgentSkillsMdDescriptor {
    data?: string | redacted.Redacted<string>;
    dataSchemaVersion?: string;
    source?: DescriptorSource;
}
export interface AgentSkillsAdditionalData {
    skillMd?: AgentSkillsMdDescriptor;
}
export interface AgentSkillsDefinitionDescriptor {
    data?: string | redacted.Redacted<string>;
    dataSchemaVersion?: string;
    additionalData?: AgentSkillsAdditionalData;
}
export interface CustomDescriptor {
    data?: string | redacted.Redacted<string>;
}
export interface HttpDescriptor {
    source?: DescriptorSource;
}
export interface AgUiDescriptor {
    source?: DescriptorSource;
}
export interface Descriptors {
    mcpServer?: McpServerDescriptor;
    a2aAgentCard?: A2aAgentCardDescriptor;
    agentSkillsDefinition?: AgentSkillsDefinitionDescriptor;
    custom?: CustomDescriptor;
    http?: HttpDescriptor;
    agui?: AgUiDescriptor;
}
export type RegistryRecordVersion = string;
export type RegistryRecordStatus = "DRAFT" | "PENDING_APPROVAL" | "APPROVED" | "REJECTED" | "DEPRECATED" | "CREATING" | "UPDATING" | "CREATE_FAILED" | "UPDATE_FAILED" | (string & {});
export type CustomMetadataDocument = unknown;
export interface RegistryRecordSummary {
    registryArn: string;
    recordArn: string;
    recordId: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    displayName?: string;
    recordType: RecordType;
    descriptors: Descriptors;
    recordVersion: string;
    status: RegistryRecordStatus;
    createdAt: Date;
    updatedAt: Date;
    customMetadata?: any;
}
export type RegistryRecordSummaryList = RegistryRecordSummary[];
export type BatchGetDiscoverableRegistryRecordErrorCode = "RESOURCE_NOT_FOUND" | "ACCESS_DENIED" | "INTERNAL_ERROR" | (string & {});
export interface BatchGetDiscoverableRegistryRecordError_ {
    registryId: string;
    recordId: string;
    errorCode: BatchGetDiscoverableRegistryRecordErrorCode;
    message?: string;
}
export type BatchGetDiscoverableRegistryRecordErrorList = BatchGetDiscoverableRegistryRecordError_[];
export interface BatchGetDiscoverableRegistryRecordResponse {
    registryRecords: RegistryRecordSummary[];
    errors: BatchGetDiscoverableRegistryRecordError_[];
}
export type RegistryRecordFilterName = "recordType" | "descriptorType" | (string & {});
export type FilterValue = string;
export type DiscoverableFilterValues = string[];
export interface RegistryRecordFilter {
    name: RegistryRecordFilterName;
    values: string[];
}
export type RegistryRecordFilterList = RegistryRecordFilter[];
export interface ListDiscoverableRegistryRecordsRequest {
    registryId: string;
    maxResults?: number;
    nextToken?: string;
    filters?: RegistryRecordFilter[];
}
export type DescriptorTypeList = string[];
export interface DiscoverableRegistryRecordSummary {
    registryArn: string;
    recordArn: string;
    recordId: string;
    name: string;
    description?: string | redacted.Redacted<string>;
    displayName?: string;
    recordType: RecordType;
    recordVersion: string;
    status: RegistryRecordStatus;
    createdAt: Date;
    updatedAt: Date;
    descriptorTypes?: string[];
}
export type DiscoverableRegistryRecordSummaryList = DiscoverableRegistryRecordSummary[];
export interface ListDiscoverableRegistryRecordsResponse {
    registryRecords: DiscoverableRegistryRecordSummary[];
    nextToken?: string;
}
export type SearchQuery = string | redacted.Redacted<string>;
export type RegistryIdList = string[];
export type MetadataFilterExpression = unknown;
export interface SearchDiscoverableRegistryRecordsRequest {
    searchQuery: string | redacted.Redacted<string>;
    registryIds: string[];
    maxResults?: number;
    filters?: any;
}
export interface SearchDiscoverableRegistryRecordsResponse {
    registryRecords: RegistryRecordSummary[];
}
export type NonBlankString = string;
export type ValidationExceptionReason = "CannotParse" | "FieldValidationFailed" | "IdempotentParameterMismatchException" | "EventInOtherSession" | "ResourceConflict" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type BatchGetDiscoverableRegistryRecordError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves multiple discoverable registry records by ID from a single registry. Records that cannot be retrieved are reported individually in the `errors` list rather than failing the entire request.
 */
export declare const batchGetDiscoverableRegistryRecord: API.OperationMethod<BatchGetDiscoverableRegistryRecordRequest, BatchGetDiscoverableRegistryRecordResponse, BatchGetDiscoverableRegistryRecordError, Credentials | HttpClient.HttpClient>;
export type ListDiscoverableRegistryRecordsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists the discoverable registry records in a registry. You can optionally filter and paginate the results.
 */
export declare const listDiscoverableRegistryRecords: API.PaginatedOperationMethod<ListDiscoverableRegistryRecordsRequest, ListDiscoverableRegistryRecordsResponse, ListDiscoverableRegistryRecordsError, Credentials | HttpClient.HttpClient, DiscoverableRegistryRecordSummary>;
export type SearchDiscoverableRegistryRecordsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Searches the discoverable registry records in a registry using a natural language query. Returns metadata for the matching records ordered by relevance.
 */
export declare const searchDiscoverableRegistryRecords: API.OperationMethod<SearchDiscoverableRegistryRecordsRequest, SearchDiscoverableRegistryRecordsResponse, SearchDiscoverableRegistryRecordsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=agent-registry.d.ts.map