import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ApplicationSpecifier = string;
export type AttributeGroupSpecifier = string;
export interface AssociateAttributeGroupRequest {
    application: string;
    attributeGroup: string;
}
export type ApplicationArn = string;
export type AttributeGroupArn = string;
export interface AssociateAttributeGroupResponse {
    applicationArn?: string;
    attributeGroupArn?: string;
}
export type ResourceType = "CFN_STACK" | "RESOURCE_TAG_VALUE" | (string & {});
export type ResourceSpecifier = string;
export type AssociationOption = "APPLY_APPLICATION_TAG" | "SKIP_APPLICATION_TAG" | (string & {});
export type Options = AssociationOption[];
export interface AssociateResourceRequest {
    application: string;
    resourceType: ResourceType;
    resource: string;
    options?: AssociationOption[];
}
export type Arn = string;
export interface AssociateResourceResponse {
    applicationArn?: string;
    resourceArn?: string;
    options?: AssociationOption[];
}
export type Name = string;
export type Description = string;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export type ClientToken = string;
export interface CreateApplicationRequest {
    name: string;
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
}
export type ApplicationId = string;
export type ApplicationTagDefinition = {
    [key: string]: string | undefined;
};
export interface Application {
    id?: string;
    arn?: string;
    name?: string;
    description?: string;
    creationTime?: Date;
    lastUpdateTime?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    applicationTag?: {
        [key: string]: string | undefined;
    };
}
export interface CreateApplicationResponse {
    application?: Application;
}
export type Attributes = string;
export interface CreateAttributeGroupRequest {
    name: string;
    description?: string;
    attributes: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
}
export type AttributeGroupId = string;
export interface AttributeGroup {
    id?: string;
    arn?: string;
    name?: string;
    description?: string;
    creationTime?: Date;
    lastUpdateTime?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateAttributeGroupResponse {
    attributeGroup?: AttributeGroup;
}
export interface DeleteApplicationRequest {
    application: string;
}
export interface ApplicationSummary {
    id?: string;
    arn?: string;
    name?: string;
    description?: string;
    creationTime?: Date;
    lastUpdateTime?: Date;
}
export interface DeleteApplicationResponse {
    application?: ApplicationSummary;
}
export interface DeleteAttributeGroupRequest {
    attributeGroup: string;
}
export type CreatedBy = string;
export interface AttributeGroupSummary {
    id?: string;
    arn?: string;
    name?: string;
    description?: string;
    creationTime?: Date;
    lastUpdateTime?: Date;
    createdBy?: string;
}
export interface DeleteAttributeGroupResponse {
    attributeGroup?: AttributeGroupSummary;
}
export interface DisassociateAttributeGroupRequest {
    application: string;
    attributeGroup: string;
}
export interface DisassociateAttributeGroupResponse {
    applicationArn?: string;
    attributeGroupArn?: string;
}
export interface DisassociateResourceRequest {
    application: string;
    resourceType: ResourceType;
    resource: string;
}
export interface DisassociateResourceResponse {
    applicationArn?: string;
    resourceArn?: string;
}
export interface GetApplicationRequest {
    application: string;
}
export type AssociationCount = number;
export type ResourceGroupState = "CREATING" | "CREATE_COMPLETE" | "CREATE_FAILED" | "UPDATING" | "UPDATE_COMPLETE" | "UPDATE_FAILED" | (string & {});
export interface ResourceGroup {
    state?: ResourceGroupState;
    arn?: string;
    errorMessage?: string;
}
export interface Integrations {
    resourceGroup?: ResourceGroup;
    applicationTagResourceGroup?: ResourceGroup;
}
export interface GetApplicationResponse {
    id?: string;
    arn?: string;
    name?: string;
    description?: string;
    creationTime?: Date;
    lastUpdateTime?: Date;
    associatedResourceCount?: number;
    tags?: {
        [key: string]: string | undefined;
    };
    integrations?: Integrations;
    applicationTag?: {
        [key: string]: string | undefined;
    };
}
export type NextToken = string;
export type ResourceItemStatus = "SUCCESS" | "FAILED" | "IN_PROGRESS" | "SKIPPED" | (string & {});
export type GetAssociatedResourceFilter = ResourceItemStatus[];
export type MaxResults = number;
export interface GetAssociatedResourceRequest {
    application: string;
    resourceType: ResourceType;
    resource: string;
    nextToken?: string;
    resourceTagStatus?: ResourceItemStatus[];
    maxResults?: number;
}
export interface ResourceIntegrations {
    resourceGroup?: ResourceGroup;
}
export interface Resource {
    name?: string;
    arn?: string;
    associationTime?: Date;
    integrations?: ResourceIntegrations;
}
export type ApplicationTagStatus = "IN_PROGRESS" | "SUCCESS" | "FAILURE" | (string & {});
export type ResourcesListItemErrorMessage = string;
export type ResourceItemType = string;
export interface ResourcesListItem {
    resourceArn?: string;
    errorMessage?: string;
    status?: string;
    resourceType?: string;
}
export type ResourcesList = ResourcesListItem[];
export interface ApplicationTagResult {
    applicationTagStatus?: ApplicationTagStatus;
    errorMessage?: string;
    resources?: ResourcesListItem[];
    nextToken?: string;
}
export interface GetAssociatedResourceResponse {
    resource?: Resource;
    options?: AssociationOption[];
    applicationTagResult?: ApplicationTagResult;
}
export interface GetAttributeGroupRequest {
    attributeGroup: string;
}
export interface GetAttributeGroupResponse {
    id?: string;
    arn?: string;
    name?: string;
    description?: string;
    attributes?: string;
    creationTime?: Date;
    lastUpdateTime?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    createdBy?: string;
}
export interface GetConfigurationRequest {
}
export type TagKeyConfig = string;
export interface TagQueryConfiguration {
    tagKey?: string;
}
export interface AppRegistryConfiguration {
    tagQueryConfiguration?: TagQueryConfiguration;
}
export interface GetConfigurationResponse {
    configuration?: AppRegistryConfiguration;
}
export interface ListApplicationsRequest {
    nextToken?: string;
    maxResults?: number;
}
export type ApplicationSummaries = ApplicationSummary[];
export interface ListApplicationsResponse {
    applications?: ApplicationSummary[];
    nextToken?: string;
}
export interface ListAssociatedAttributeGroupsRequest {
    application: string;
    nextToken?: string;
    maxResults?: number;
}
export type AttributeGroupIds = string[];
export interface ListAssociatedAttributeGroupsResponse {
    attributeGroups?: string[];
    nextToken?: string;
}
export interface ListAssociatedResourcesRequest {
    application: string;
    nextToken?: string;
    maxResults?: number;
}
export interface ResourceDetails {
    tagValue?: string;
}
export interface ResourceInfo {
    name?: string;
    arn?: string;
    resourceType?: ResourceType;
    resourceDetails?: ResourceDetails;
    options?: AssociationOption[];
}
export type Resources = ResourceInfo[];
export interface ListAssociatedResourcesResponse {
    resources?: ResourceInfo[];
    nextToken?: string;
}
export interface ListAttributeGroupsRequest {
    nextToken?: string;
    maxResults?: number;
}
export type AttributeGroupSummaries = AttributeGroupSummary[];
export interface ListAttributeGroupsResponse {
    attributeGroups?: AttributeGroupSummary[];
    nextToken?: string;
}
export interface ListAttributeGroupsForApplicationRequest {
    application: string;
    nextToken?: string;
    maxResults?: number;
}
export interface AttributeGroupDetails {
    id?: string;
    arn?: string;
    name?: string;
    createdBy?: string;
}
export type AttributeGroupDetailsList = AttributeGroupDetails[];
export interface ListAttributeGroupsForApplicationResponse {
    attributeGroupsDetails?: AttributeGroupDetails[];
    nextToken?: string;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface PutConfigurationRequest {
    configuration: AppRegistryConfiguration;
}
export interface PutConfigurationResponse {
}
export interface SyncResourceRequest {
    resourceType: ResourceType;
    resource: string;
}
export type SyncAction = "START_SYNC" | "NO_ACTION" | (string & {});
export interface SyncResourceResponse {
    applicationArn?: string;
    resourceArn?: string;
    actionTaken?: SyncAction;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateApplicationRequest {
    application: string;
    name?: string;
    description?: string;
}
export interface UpdateApplicationResponse {
    application?: Application;
}
export interface UpdateAttributeGroupRequest {
    attributeGroup: string;
    name?: string;
    description?: string;
    attributes?: string;
}
export interface UpdateAttributeGroupResponse {
    attributeGroup?: AttributeGroup;
}
export type AssociateAttributeGroupError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Associates an attribute group with an application to augment the application's metadata
 * with the group's attributes. This feature enables applications to be described with
 * user-defined details that are machine-readable, such as third-party integrations.
 */
export declare const associateAttributeGroup: API.OperationMethod<AssociateAttributeGroupRequest, AssociateAttributeGroupResponse, AssociateAttributeGroupError, Credentials | HttpClient.HttpClient>;
export type AssociateResourceError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a resource with an application.
 * The resource can be specified by its ARN or name.
 * The application can be specified by ARN, ID, or name.
 *
 * **Minimum permissions**
 *
 * You must have the following permissions to associate a resource using the `OPTIONS` parameter set to `APPLY_APPLICATION_TAG`.
 *
 * - `tag:GetResources`
 *
 * - `tag:TagResources`
 *
 * You must also have these additional permissions if you don't use the `AWSServiceCatalogAppRegistryFullAccess` policy.
 * For more information, see AWSServiceCatalogAppRegistryFullAccess in the AppRegistry Administrator Guide.
 *
 * - `resource-groups:AssociateResource`
 *
 * - `cloudformation:UpdateStack`
 *
 * - `cloudformation:DescribeStacks`
 *
 * In addition, you must have the tagging permission defined by the Amazon Web Services service that creates the resource.
 * For more information, see TagResources in the *Resource Groups Tagging API Reference*.
 */
export declare const associateResource: API.OperationMethod<AssociateResourceRequest, AssociateResourceResponse, AssociateResourceError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new application that is the top-level node in a hierarchy of related cloud resource abstractions.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateAttributeGroupError = ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a new attribute group as a container for user-defined attributes. This feature
 * enables users to have full control over their cloud application's metadata in a rich
 * machine-readable format to facilitate integration with automated workflows and third-party
 * tools.
 */
export declare const createAttributeGroup: API.OperationMethod<CreateAttributeGroupRequest, CreateAttributeGroupResponse, CreateAttributeGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an application that is specified either by its application ID, name, or ARN. All associated attribute groups and resources must be disassociated from it before deleting an application.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteAttributeGroupError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an attribute group, specified either by its attribute group ID, name, or ARN.
 */
export declare const deleteAttributeGroup: API.OperationMethod<DeleteAttributeGroupRequest, DeleteAttributeGroupResponse, DeleteAttributeGroupError, Credentials | HttpClient.HttpClient>;
export type DisassociateAttributeGroupError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Disassociates an attribute group from an application to remove the extra attributes contained in the attribute group from the application's metadata. This operation reverts `AssociateAttributeGroup`.
 */
export declare const disassociateAttributeGroup: API.OperationMethod<DisassociateAttributeGroupRequest, DisassociateAttributeGroupResponse, DisassociateAttributeGroupError, Credentials | HttpClient.HttpClient>;
export type DisassociateResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a resource from application.
 * Both the resource and the application can be specified either by ID or name.
 *
 * **Minimum permissions**
 *
 * You must have the following permissions to remove a resource that's been associated with an application using the `APPLY_APPLICATION_TAG` option for AssociateResource.
 *
 * - `tag:GetResources`
 *
 * - `tag:UntagResources`
 *
 * You must also have the following permissions if you don't use the `AWSServiceCatalogAppRegistryFullAccess` policy.
 * For more information, see AWSServiceCatalogAppRegistryFullAccess in the AppRegistry Administrator Guide.
 *
 * - `resource-groups:DisassociateResource`
 *
 * - `cloudformation:UpdateStack`
 *
 * - `cloudformation:DescribeStacks`
 *
 * In addition, you must have the tagging permission defined by the Amazon Web Services service that creates the resource.
 * For more information, see UntagResources in the *Resource Groups Tagging API Reference*.
 */
export declare const disassociateResource: API.OperationMethod<DisassociateResourceRequest, DisassociateResourceResponse, DisassociateResourceError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves metadata information
 * about one
 * of your applications.
 * The application can be specified
 * by its ARN, ID, or name
 * (which is unique
 * within one account
 * in one region
 * at a given point
 * in time).
 * Specify
 * by ARN or ID
 * in automated workflows
 * if you want
 * to make sure
 * that the exact same application is returned or a `ResourceNotFoundException` is thrown,
 * avoiding the ABA addressing problem.
 */
export declare const getApplication: API.OperationMethod<GetApplicationRequest, GetApplicationResponse, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetAssociatedResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets the resource associated with the application.
 */
export declare const getAssociatedResource: API.OperationMethod<GetAssociatedResourceRequest, GetAssociatedResourceResponse, GetAssociatedResourceError, Credentials | HttpClient.HttpClient>;
export type GetAttributeGroupError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves an attribute group
 * by its ARN, ID, or name.
 * The attribute group can be specified
 * by its ARN, ID, or name.
 */
export declare const getAttributeGroup: API.OperationMethod<GetAttributeGroupRequest, GetAttributeGroupResponse, GetAttributeGroupError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationError = InternalServerException | CommonErrors;
/**
 * Retrieves a `TagKey` configuration
 * from an account.
 */
export declare const getConfiguration: API.OperationMethod<GetConfigurationRequest, GetConfigurationResponse, GetConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListApplicationsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Retrieves a list of all of your applications. Results are paginated.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationSummary>;
export type ListAssociatedAttributeGroupsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all attribute groups that are associated with specified application. Results are paginated.
 */
export declare const listAssociatedAttributeGroups: API.PaginatedOperationMethod<ListAssociatedAttributeGroupsRequest, ListAssociatedAttributeGroupsResponse, ListAssociatedAttributeGroupsError, Credentials | HttpClient.HttpClient, AttributeGroupId>;
export type ListAssociatedResourcesError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all
 * of the resources
 * that are associated
 * with the specified application.
 * Results are paginated.
 *
 * If you share an application,
 * and a consumer account associates a tag query
 * to the application,
 * all of the users
 * who can access the application
 * can also view the tag values
 * in all accounts
 * that are associated
 * with it
 * using this API.
 */
export declare const listAssociatedResources: API.PaginatedOperationMethod<ListAssociatedResourcesRequest, ListAssociatedResourcesResponse, ListAssociatedResourcesError, Credentials | HttpClient.HttpClient, ResourceInfo>;
export type ListAttributeGroupsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists all attribute groups which you have access to. Results are paginated.
 */
export declare const listAttributeGroups: API.PaginatedOperationMethod<ListAttributeGroupsRequest, ListAttributeGroupsResponse, ListAttributeGroupsError, Credentials | HttpClient.HttpClient, AttributeGroupSummary>;
export type ListAttributeGroupsForApplicationError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the details of all attribute groups associated with a specific application. The results display in pages.
 */
export declare const listAttributeGroupsForApplication: API.PaginatedOperationMethod<ListAttributeGroupsForApplicationRequest, ListAttributeGroupsForApplicationResponse, ListAttributeGroupsForApplicationError, Credentials | HttpClient.HttpClient, AttributeGroupDetails>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all of the tags on the resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutConfigurationError = ConflictException | InternalServerException | ValidationException | CommonErrors;
/**
 * Associates a `TagKey` configuration
 * to an account.
 */
export declare const putConfiguration: API.OperationMethod<PutConfigurationRequest, PutConfigurationResponse, PutConfigurationError, Credentials | HttpClient.HttpClient>;
export type SyncResourceError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Syncs the resource with current AppRegistry records.
 *
 * Specifically, the resource's AppRegistry system tags sync with its associated application. We remove the resource's AppRegistry system tags if it does not associate with the application. The caller must have permissions to read and update the resource.
 */
export declare const syncResource: API.OperationMethod<SyncResourceRequest, SyncResourceResponse, SyncResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified resource.
 *
 * Each tag consists of a key and an optional value. If a tag with the same key is already associated with the resource, this action updates its value.
 *
 * This operation returns an empty response if the call was successful.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes tags from a resource.
 *
 * This operation returns an empty response if the call was successful.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing application with new attributes.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateAttributeGroupError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates an existing attribute group with new details.
 */
export declare const updateAttributeGroup: API.OperationMethod<UpdateAttributeGroupRequest, UpdateAttributeGroupResponse, UpdateAttributeGroupError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=service-catalog-appregistry.d.ts.map