import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
    readonly reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type WorkflowDefinitionName = string;
export type UuidString = string;
export type Task = string | redacted.Redacted<string>;
export type ToolName = string;
export type ToolDescription = string | redacted.Redacted<string>;
export type ToolInputSchemaDocument = unknown;
export type ToolInputSchema = {
    json: any;
};
export interface ToolSpec {
    name: string;
    description: string | redacted.Redacted<string>;
    inputSchema: ToolInputSchema;
}
export type ToolSpecs = ToolSpec[];
export type ClientToken = string;
export interface CreateActRequest {
    workflowDefinitionName: string;
    workflowRunId: string;
    sessionId: string;
    task: string | redacted.Redacted<string>;
    toolSpecs?: ToolSpec[];
    clientToken?: string;
}
export type ActStatus = "RUNNING" | "PENDING_CLIENT_ACTION" | "PENDING_HUMAN_ACTION" | "SUCCEEDED" | "FAILED" | "TIMED_OUT" | (string & {});
export interface CreateActResponse {
    actId: string;
    status: ActStatus;
}
export interface CreateSessionRequest {
    workflowDefinitionName: string;
    workflowRunId: string;
    clientToken?: string;
}
export interface CreateSessionResponse {
    sessionId: string;
}
export type WorkflowDescription = string | redacted.Redacted<string>;
export type S3BucketName = string;
export type S3KeyPrefix = string;
export interface WorkflowExportConfig {
    s3BucketName: string;
    s3KeyPrefix?: string;
}
export interface CreateWorkflowDefinitionRequest {
    name: string;
    description?: string | redacted.Redacted<string>;
    exportConfig?: WorkflowExportConfig;
    clientToken?: string;
}
export type WorkflowDefinitionStatus = "ACTIVE" | "DELETING" | (string & {});
export interface CreateWorkflowDefinitionResponse {
    status: WorkflowDefinitionStatus;
}
export type ModelId = string;
export type CloudWatchLogGroupName = string;
export type NonBlankString = string;
export interface ClientInfo {
    compatibilityVersion: number;
    sdkVersion?: string;
}
export interface CreateWorkflowRunRequest {
    workflowDefinitionName: string;
    modelId: string;
    clientToken?: string;
    logGroupName?: string;
    clientInfo: ClientInfo;
}
export type WorkflowRunStatus = "RUNNING" | "SUCCEEDED" | "FAILED" | "TIMED_OUT" | "DELETING" | (string & {});
export interface CreateWorkflowRunResponse {
    workflowRunId: string;
    status: WorkflowRunStatus;
}
export interface DeleteWorkflowDefinitionRequest {
    workflowDefinitionName: string;
}
export interface DeleteWorkflowDefinitionResponse {
    status: WorkflowDefinitionStatus;
}
export interface DeleteWorkflowRunRequest {
    workflowDefinitionName: string;
    workflowRunId: string;
}
export interface DeleteWorkflowRunResponse {
    status: WorkflowRunStatus;
}
export interface GetWorkflowDefinitionRequest {
    workflowDefinitionName: string;
}
export type WorkflowDefinitionArn = string;
export interface GetWorkflowDefinitionResponse {
    name: string;
    arn: string;
    createdAt: Date;
    description?: string | redacted.Redacted<string>;
    exportConfig?: WorkflowExportConfig;
    status: WorkflowDefinitionStatus;
}
export interface GetWorkflowRunRequest {
    workflowDefinitionName: string;
    workflowRunId: string;
}
export type WorkflowRunArn = string;
export interface GetWorkflowRunResponse {
    workflowRunArn: string;
    workflowRunId: string;
    status: WorkflowRunStatus;
    startedAt: Date;
    endedAt?: Date;
    modelId: string;
    logGroupName?: string;
}
export type CallId = string;
export type CallResultContent = {
    text: string;
};
export type CallResultContents = CallResultContent[];
export interface CallResult {
    callId?: string;
    content: CallResultContent[];
}
export type CallResults = CallResult[];
export interface InvokeActStepRequest {
    workflowDefinitionName: string;
    workflowRunId: string;
    sessionId: string;
    actId: string;
    callResults: CallResult[];
    previousStepId?: string;
}
export type SensitiveDocument = unknown;
export interface Call {
    callId: string;
    input: any;
    name: string;
}
export type Calls = Call[];
export interface InvokeActStepResponse {
    calls: Call[];
    stepId: string;
}
export type MaxResults = number;
export type NextToken = string;
export type SortOrder = "Ascending" | "Descending" | (string & {});
export interface ListActsRequest {
    workflowDefinitionName: string;
    workflowRunId?: string;
    sessionId?: string;
    maxResults?: number;
    nextToken?: string;
    sortOrder?: SortOrder;
}
export type TraceLocationType = "S3" | (string & {});
export interface TraceLocation {
    locationType: TraceLocationType;
    location: string;
}
export interface ActSummary {
    workflowRunId: string;
    sessionId: string;
    actId: string;
    status: ActStatus;
    startedAt: Date;
    endedAt?: Date;
    traceLocation?: TraceLocation;
}
export type ActSummaries = ActSummary[];
export interface ListActsResponse {
    actSummaries: ActSummary[];
    nextToken?: string;
}
export interface ListModelsRequest {
    clientCompatibilityVersion: number;
}
export type ModelStatus = "ACTIVE" | "LEGACY" | "DEPRECATED" | "PREVIEW" | (string & {});
export interface ModelLifecycle {
    status: ModelStatus;
}
export interface ModelSummary {
    modelId: string;
    modelLifecycle: ModelLifecycle;
    minimumCompatibilityVersion: number;
}
export type ModelSummaries = ModelSummary[];
export interface ModelAlias {
    aliasName: string;
    latestModelId: string;
    resolvedModelId?: string;
}
export type ModelAliases = ModelAlias[];
export type ModelIdList = string[];
export interface CompatibilityInformation {
    clientCompatibilityVersion: number;
    supportedModelIds: string[];
    message?: string;
}
export interface ListModelsResponse {
    modelSummaries: ModelSummary[];
    modelAliases: ModelAlias[];
    compatibilityInformation: CompatibilityInformation;
}
export interface ListSessionsRequest {
    workflowDefinitionName: string;
    workflowRunId: string;
    maxResults?: number;
    nextToken?: string;
    sortOrder?: SortOrder;
}
export interface SessionSummary {
    sessionId: string;
}
export type SessionSummaries = SessionSummary[];
export interface ListSessionsResponse {
    sessionSummaries: SessionSummary[];
    nextToken?: string;
}
export interface ListWorkflowDefinitionsRequest {
    maxResults?: number;
    nextToken?: string;
    sortOrder?: SortOrder;
}
export interface WorkflowDefinitionSummary {
    workflowDefinitionArn: string;
    workflowDefinitionName: string;
    createdAt: Date;
    status: WorkflowDefinitionStatus;
}
export type WorkflowDefinitionSummaries = WorkflowDefinitionSummary[];
export interface ListWorkflowDefinitionsResponse {
    workflowDefinitionSummaries: WorkflowDefinitionSummary[];
    nextToken?: string;
}
export interface ListWorkflowRunsRequest {
    workflowDefinitionName: string;
    maxResults?: number;
    nextToken?: string;
    sortOrder?: SortOrder;
}
export interface WorkflowRunSummary {
    workflowRunArn: string;
    workflowRunId: string;
    status: WorkflowRunStatus;
    startedAt: Date;
    endedAt?: Date;
    traceLocation?: TraceLocation;
}
export type WorkflowRunSummaries = WorkflowRunSummary[];
export interface ListWorkflowRunsResponse {
    workflowRunSummaries: WorkflowRunSummary[];
    nextToken?: string;
}
export type SensitiveString = string | redacted.Redacted<string>;
export interface ActError {
    message: string | redacted.Redacted<string>;
    type?: string;
}
export interface UpdateActRequest {
    workflowDefinitionName: string;
    workflowRunId: string;
    sessionId: string;
    actId: string;
    status: ActStatus;
    error?: ActError;
}
export interface UpdateActResponse {
}
export interface UpdateWorkflowRunRequest {
    workflowDefinitionName: string;
    workflowRunId: string;
    status: WorkflowRunStatus;
}
export interface UpdateWorkflowRunResponse {
}
export type InternalServerExceptionReason = "InvalidModelGeneration" | "RequestTokenLimitExceeded" | (string & {});
export type ValidationExceptionReason = "FieldValidationFailed" | "InvalidStatus" | "GuardrailIntervened" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type CreateActError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new AI task (act) within a session that can interact with tools and perform specific actions.
 */
export declare const createAct: API.OperationMethod<CreateActRequest, CreateActResponse, CreateActError, Credentials | HttpClient.HttpClient>;
export type CreateSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new session context within a workflow run to manage conversation state and acts.
 */
export declare const createSession: API.OperationMethod<CreateSessionRequest, CreateSessionResponse, CreateSessionError, Credentials | HttpClient.HttpClient>;
export type CreateWorkflowDefinitionError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new workflow definition template that can be used to execute multiple workflow runs.
 */
export declare const createWorkflowDefinition: API.OperationMethod<CreateWorkflowDefinitionRequest, CreateWorkflowDefinitionResponse, CreateWorkflowDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateWorkflowRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new execution instance of a workflow definition with specified parameters.
 */
export declare const createWorkflowRun: API.OperationMethod<CreateWorkflowRunRequest, CreateWorkflowRunResponse, CreateWorkflowRunError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkflowDefinitionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a workflow definition and all associated resources. This operation cannot be undone.
 */
export declare const deleteWorkflowDefinition: API.OperationMethod<DeleteWorkflowDefinitionRequest, DeleteWorkflowDefinitionResponse, DeleteWorkflowDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkflowRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Terminates and cleans up a workflow run, stopping all associated acts and sessions.
 */
export declare const deleteWorkflowRun: API.OperationMethod<DeleteWorkflowRunRequest, DeleteWorkflowRunResponse, DeleteWorkflowRunError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowDefinitionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details and configuration of a specific workflow definition.
 */
export declare const getWorkflowDefinition: API.OperationMethod<GetWorkflowDefinitionRequest, GetWorkflowDefinitionResponse, GetWorkflowDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the current state, configuration, and execution details of a workflow run.
 */
export declare const getWorkflowRun: API.OperationMethod<GetWorkflowRunRequest, GetWorkflowRunResponse, GetWorkflowRunError, Credentials | HttpClient.HttpClient>;
export type InvokeActStepError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Executes the next step of an act, processing tool call results and returning new tool calls if needed.
 */
export declare const invokeActStep: API.OperationMethod<InvokeActStepRequest, InvokeActStepResponse, InvokeActStepError, Credentials | HttpClient.HttpClient>;
export type ListActsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all acts within a specific session with their current status and execution details.
 */
export declare const listActs: API.PaginatedOperationMethod<ListActsRequest, ListActsResponse, ListActsError, Credentials | HttpClient.HttpClient, ActSummary>;
export type ListModelsError = AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Lists all available AI models that can be used for workflow execution, including their status and compatibility information.
 */
export declare const listModels: API.OperationMethod<ListModelsRequest, ListModelsResponse, ListModelsError, Credentials | HttpClient.HttpClient>;
export type ListSessionsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all sessions within a specific workflow run.
 */
export declare const listSessions: API.PaginatedOperationMethod<ListSessionsRequest, ListSessionsResponse, ListSessionsError, Credentials | HttpClient.HttpClient, SessionSummary>;
export type ListWorkflowDefinitionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all workflow definitions in your account with optional filtering and pagination.
 */
export declare const listWorkflowDefinitions: API.PaginatedOperationMethod<ListWorkflowDefinitionsRequest, ListWorkflowDefinitionsResponse, ListWorkflowDefinitionsError, Credentials | HttpClient.HttpClient, WorkflowDefinitionSummary>;
export type ListWorkflowRunsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all workflow runs for a specific workflow definition with optional filtering and pagination.
 */
export declare const listWorkflowRuns: API.PaginatedOperationMethod<ListWorkflowRunsRequest, ListWorkflowRunsResponse, ListWorkflowRunsError, Credentials | HttpClient.HttpClient, WorkflowRunSummary>;
export type UpdateActError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing act's configuration, status, or error information.
 */
export declare const updateAct: API.OperationMethod<UpdateActRequest, UpdateActResponse, UpdateActError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkflowRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration or state of an active workflow run.
 */
export declare const updateWorkflowRun: API.OperationMethod<UpdateWorkflowRunRequest, UpdateWorkflowRunResponse, UpdateWorkflowRunError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=nova-act.d.ts.map