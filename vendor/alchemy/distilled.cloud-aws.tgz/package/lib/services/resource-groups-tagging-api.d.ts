import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}>;
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConstraintViolationException_base: S.TaggedErrorClass<"ConstraintViolationException", {
    readonly message: any;
}>;
export declare class ConstraintViolationException extends /*@__PURE__*/ ConstraintViolationException_base {
}
declare const InternalServiceException_base: S.TaggedErrorClass<"InternalServiceException", {
    readonly message: any;
}>;
export declare class InternalServiceException extends /*@__PURE__*/ InternalServiceException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}>;
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const PaginationTokenExpiredException_base: S.TaggedErrorClass<"PaginationTokenExpiredException", {
    readonly message: any;
}>;
export declare class PaginationTokenExpiredException extends /*@__PURE__*/ PaginationTokenExpiredException_base {
}
declare const ThrottledException_base: S.TaggedErrorClass<"ThrottledException", {
    readonly message: any;
}>;
export declare class ThrottledException extends /*@__PURE__*/ ThrottledException_base {
}
export interface DescribeReportCreationInput {
}
export type Status = string;
export type S3Location = string;
export type StartDate = string;
export type ErrorMessage = string;
export interface DescribeReportCreationOutput {
    Status?: string;
    S3Location?: string;
    StartDate?: string;
    ErrorMessage?: string;
}
export type TargetId = string;
export type TargetIdFilterList = string[];
export type Region = string;
export type RegionFilterList = string[];
export type AmazonResourceType = string;
export type ResourceTypeFilterList = string[];
export type TagKey = string;
export type TagKeyFilterList = string[];
export type GroupByAttribute = "TARGET_ID" | "REGION" | "RESOURCE_TYPE" | (string & {});
export type GroupBy = GroupByAttribute[];
export type MaxResultsGetComplianceSummary = number;
export type PaginationToken = string;
export interface GetComplianceSummaryInput {
    TargetIdFilters?: string[];
    RegionFilters?: string[];
    ResourceTypeFilters?: string[];
    TagKeyFilters?: string[];
    GroupBy?: GroupByAttribute[];
    MaxResults?: number;
    PaginationToken?: string;
}
export type LastUpdated = string;
export type TargetIdType = "ACCOUNT" | "OU" | "ROOT" | (string & {});
export type NonCompliantResources = number;
export interface Summary {
    LastUpdated?: string;
    TargetId?: string;
    TargetIdType?: TargetIdType;
    Region?: string;
    ResourceType?: string;
    NonCompliantResources?: number;
}
export type SummaryList = Summary[];
export interface GetComplianceSummaryOutput {
    SummaryList?: Summary[];
    PaginationToken?: string;
}
export type TagValue = string;
export type TagValueList = string[];
export interface TagFilter {
    Key?: string;
    Values?: string[];
}
export type TagFilterList = TagFilter[];
export type ResourcesPerPage = number;
export type TagsPerPage = number;
export type IncludeComplianceDetails = boolean;
export type ExcludeCompliantResources = boolean;
export type ResourceARN = string;
export type ResourceARNListForGet = string[];
export interface GetResourcesInput {
    PaginationToken?: string;
    TagFilters?: TagFilter[];
    ResourcesPerPage?: number;
    TagsPerPage?: number;
    ResourceTypeFilters?: string[];
    IncludeComplianceDetails?: boolean;
    ExcludeCompliantResources?: boolean;
    ResourceARNList?: string[];
}
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export type TagKeyList = string[];
export type ComplianceStatus = boolean;
export interface ComplianceDetails {
    NoncompliantKeys?: string[];
    KeysWithNoncompliantValues?: string[];
    MissingTagKeys?: string[];
    ComplianceStatus?: boolean;
}
export interface ResourceTagMapping {
    ResourceARN?: string;
    Tags?: Tag[];
    ComplianceDetails?: ComplianceDetails;
}
export type ResourceTagMappingList = ResourceTagMapping[];
export interface GetResourcesOutput {
    PaginationToken?: string;
    ResourceTagMappingList?: ResourceTagMapping[];
}
export interface GetTagKeysInput {
    PaginationToken?: string;
}
export interface GetTagKeysOutput {
    PaginationToken?: string;
    TagKeys?: string[];
}
export interface GetTagValuesInput {
    PaginationToken?: string;
    Key: string;
}
export type TagValuesOutputList = string[];
export interface GetTagValuesOutput {
    PaginationToken?: string;
    TagValues?: string[];
}
export type MaxResultsForListRequiredTags = number;
export interface ListRequiredTagsInput {
    NextToken?: string;
    MaxResults?: number;
}
export type ResourceType = string;
export type CloudFormationResourceType = string;
export type CloudFormationResourceTypes = string[];
export type ReportingTagKeys = string[];
export interface RequiredTag {
    ResourceType?: string;
    CloudFormationResourceTypes?: string[];
    ReportingTagKeys?: string[];
}
export type RequiredTagsForListRequiredTags = RequiredTag[];
export interface ListRequiredTagsOutput {
    RequiredTags?: RequiredTag[];
    NextToken?: string;
}
export type S3Bucket = string;
export interface StartReportCreationInput {
    S3Bucket: string;
}
export interface StartReportCreationOutput {
}
export type ResourceARNListForTagUntag = string[];
export type TagMap = {
    [key: string]: string | undefined;
};
export interface TagResourcesInput {
    ResourceARNList: string[];
    Tags: {
        [key: string]: string | undefined;
    };
}
export type StatusCode = number;
export type ErrorCode = "InternalServiceException" | "InvalidParameterException" | (string & {});
export interface FailureInfo {
    StatusCode?: number;
    ErrorCode?: ErrorCode;
    ErrorMessage?: string;
}
export type FailedResourcesMap = {
    [key: string]: FailureInfo | undefined;
};
export interface TagResourcesOutput {
    FailedResourcesMap?: {
        [key: string]: FailureInfo | undefined;
    };
}
export type TagKeyListForUntag = string[];
export interface UntagResourcesInput {
    ResourceARNList: string[];
    TagKeys: string[];
}
export interface UntagResourcesOutput {
    FailedResourcesMap?: {
        [key: string]: FailureInfo | undefined;
    };
}
export type ExceptionMessage = string;
export type DescribeReportCreationError = ConstraintViolationException | InternalServiceException | InvalidParameterException | ThrottledException | CommonErrors;
/**
 * Describes the status of the `StartReportCreation` operation.
 *
 * You can call this operation only from the organization's
 * management account and from the us-east-1 Region.
 */
export declare const describeReportCreation: API.OperationMethod<DescribeReportCreationInput, DescribeReportCreationOutput, DescribeReportCreationError, Credentials | HttpClient.HttpClient>;
export type GetComplianceSummaryError = ConstraintViolationException | InternalServiceException | InvalidParameterException | ThrottledException | CommonErrors;
/**
 * Returns a table that shows counts of resources that are noncompliant with their tag
 * policies.
 *
 * For more information on tag policies, see Tag Policies in
 * the *Organizations User Guide.*
 *
 * You can call this operation only from the organization's
 * management account and from the us-east-1 Region.
 *
 * This operation supports pagination, where the response can be sent in
 * multiple pages. You should check the `PaginationToken` response parameter to determine
 * if there are additional results available to return. Repeat the query, passing the
 * `PaginationToken` response parameter value as an input to the next request until you
 * recieve a `null` value. A null value for `PaginationToken` indicates that
 * there are no more results waiting to be returned.
 */
export declare const getComplianceSummary: API.PaginatedOperationMethod<GetComplianceSummaryInput, GetComplianceSummaryOutput, GetComplianceSummaryError, Credentials | HttpClient.HttpClient, Summary>;
export type GetResourcesError = InternalServiceException | InvalidParameterException | PaginationTokenExpiredException | ThrottledException | CommonErrors;
/**
 * Returns all the tagged or previously tagged resources that are located in the
 * specified Amazon Web Services Region for the account.
 *
 * Depending on what information you want returned, you can also specify the
 * following:
 *
 * - *Filters* that specify what tags and resource types you
 * want returned. The response includes all tags that are associated with the
 * requested resources.
 *
 * - Information about compliance with the account's effective tag policy. For more
 * information on tag policies, see Tag
 * Policies in the *Organizations User Guide.*
 *
 * This operation supports pagination, where the response can be sent in
 * multiple pages. You should check the `PaginationToken` response parameter to determine
 * if there are additional results available to return. Repeat the query, passing the
 * `PaginationToken` response parameter value as an input to the next request until you
 * recieve a `null` value. A null value for `PaginationToken` indicates that
 * there are no more results waiting to be returned.
 *
 * `GetResources` does not return untagged resources.
 *
 * To find untagged resources in your account, use Amazon Web Services Resource Explorer with a
 * query that uses `tag:none`. For more information, see Search query syntax reference for Resource Explorer.
 */
export declare const getResources: API.PaginatedOperationMethod<GetResourcesInput, GetResourcesOutput, GetResourcesError, Credentials | HttpClient.HttpClient, ResourceTagMapping>;
export type GetTagKeysError = InternalServiceException | InvalidParameterException | PaginationTokenExpiredException | ThrottledException | CommonErrors;
/**
 * Returns all tag keys currently in use in the specified Amazon Web Services Region for the calling
 * account.
 *
 * This operation supports pagination, where the response can be sent in
 * multiple pages. You should check the `PaginationToken` response parameter to determine
 * if there are additional results available to return. Repeat the query, passing the
 * `PaginationToken` response parameter value as an input to the next request until you
 * recieve a `null` value. A null value for `PaginationToken` indicates that
 * there are no more results waiting to be returned.
 */
export declare const getTagKeys: API.PaginatedOperationMethod<GetTagKeysInput, GetTagKeysOutput, GetTagKeysError, Credentials | HttpClient.HttpClient, TagKey>;
export type GetTagValuesError = InternalServiceException | InvalidParameterException | PaginationTokenExpiredException | ThrottledException | CommonErrors;
/**
 * Returns all tag values for the specified key that are used in the specified Amazon Web Services
 * Region for the calling account.
 *
 * This operation supports pagination, where the response can be sent in
 * multiple pages. You should check the `PaginationToken` response parameter to determine
 * if there are additional results available to return. Repeat the query, passing the
 * `PaginationToken` response parameter value as an input to the next request until you
 * recieve a `null` value. A null value for `PaginationToken` indicates that
 * there are no more results waiting to be returned.
 */
export declare const getTagValues: API.PaginatedOperationMethod<GetTagValuesInput, GetTagValuesOutput, GetTagValuesError, Credentials | HttpClient.HttpClient, TagValue>;
export type ListRequiredTagsError = InternalServiceException | InvalidParameterException | PaginationTokenExpiredException | ThrottledException | CommonErrors;
/**
 * Lists the required tags for supported resource types in an Amazon Web Services account.
 */
export declare const listRequiredTags: API.PaginatedOperationMethod<ListRequiredTagsInput, ListRequiredTagsOutput, ListRequiredTagsError, Credentials | HttpClient.HttpClient, RequiredTag>;
export type StartReportCreationError = ConcurrentModificationException | ConstraintViolationException | InternalServiceException | InvalidParameterException | ThrottledException | CommonErrors;
/**
 * Generates a report that lists all tagged resources in the accounts across your
 * organization and tells whether each resource is compliant with the effective tag policy.
 * Compliance data is refreshed daily. The report is generated asynchronously.
 *
 * The generated report is saved to the following location:
 *
 * `s3://amzn-s3-demo-bucket/AwsTagPolicies/o-exampleorgid/YYYY-MM-ddTHH:mm:ssZ/report.csv`
 *
 * For more information about evaluating resource compliance with tag policies, including
 * the required permissions, review Permissions for evaluating organization-wide compliance in the
 * *Tagging Amazon Web Services Resources and Tag Editor* user guide.
 *
 * You can call this operation only from the organization's
 * management account and from the us-east-1 Region.
 *
 * If the account associated with the identity used to call
 * `StartReportCreation` is different from the account that owns the Amazon S3
 * bucket, there must be a bucket policy attached to the bucket to provide access. For more
 * information, review Amazon S3 bucket
 * policy for report storage in the Tagging Amazon Web Services Resources and Tag
 * Editor user guide.
 */
export declare const startReportCreation: API.OperationMethod<StartReportCreationInput, StartReportCreationOutput, StartReportCreationError, Credentials | HttpClient.HttpClient>;
export type TagResourcesError = InternalServiceException | InvalidParameterException | ThrottledException | CommonErrors;
/**
 * Applies one or more tags to the specified resources. Note the following:
 *
 * - Not all resources can have tags. For a list of services with resources that
 * support tagging using this operation, see Services that support the
 * Resource Groups Tagging API. If the resource doesn't yet support
 * this operation, the resource's service might support tagging using its own API
 * operations. For more information, refer to the documentation for that
 * service.
 *
 * - Each resource can have up to 50 tags. For other limits, see Tag Naming and Usage Conventions in the Amazon Web Services General
 * Reference.
 *
 * - You can only tag resources that are located in the specified Amazon Web Services Region for
 * the Amazon Web Services account.
 *
 * - To add tags to a resource, you need the necessary permissions for the service
 * that the resource belongs to as well as permissions for adding tags. For more
 * information, see the documentation for each service.
 *
 * - When you use the Amazon Web Services Resource
 * Groups Tagging API to update tags for Amazon Web Services CloudFormation stack
 * sets, Amazon Web Services calls the Amazon Web Services
 * CloudFormation `UpdateStack`
 * operation. This operation
 * may initiate additional resource property updates in addition to the desired tag
 * updates. To avoid unexpected resource updates, Amazon Web Services recommends that you only
 * apply or update tags to your CloudFormation stack sets using Amazon Web Services
 * CloudFormation.
 *
 * Do not store personally identifiable information (PII) or other confidential or
 * sensitive information in tags. We use tags to provide you with billing and
 * administration services. Tags are not intended to be used for private or sensitive
 * data.
 *
 * **Minimum permissions**
 *
 * In addition to the `tag:TagResources` permission required by this
 * operation, you must also have the tagging permission defined by the service that created
 * the resource. For example, to tag an Amazon EC2 instance using the `TagResources`
 * operation, you must have both of the following permissions:
 *
 * - `tag:TagResources`
 *
 * - `ec2:CreateTags`
 *
 * In addition, some services might have specific requirements for tagging some types
 * of resources. For example, to tag an Amazon S3 bucket, you must also have the
 * `s3:GetBucketTagging` permission. If the expected minimum permissions
 * don't work, check the documentation for that service's tagging APIs for more
 * information.
 */
export declare const tagResources: API.OperationMethod<TagResourcesInput, TagResourcesOutput, TagResourcesError, Credentials | HttpClient.HttpClient>;
export type UntagResourcesError = InternalServiceException | InvalidParameterException | ThrottledException | CommonErrors;
/**
 * Removes the specified tags from the specified resources. When you specify a tag key,
 * the action removes both that key and its associated value. The operation succeeds even
 * if you attempt to remove tags from a resource that were already removed. Note the
 * following:
 *
 * - To remove tags from a resource, you need the necessary permissions for the
 * service that the resource belongs to as well as permissions for removing tags.
 * For more information, see the documentation for the service whose resource you
 * want to untag.
 *
 * - You can only tag resources that are located in the specified Amazon Web Services Region for
 * the calling Amazon Web Services account.
 *
 * **Minimum permissions**
 *
 * In addition to the `tag:UntagResources` permission required by this
 * operation, you must also have the remove tags permission defined by the service that
 * created the resource. For example, to remove the tags from an Amazon EC2 instance using the
 * `UntagResources` operation, you must have both of the following
 * permissions:
 *
 * - `tag:UntagResources`
 *
 * - `ec2:DeleteTags`
 *
 * In addition, some services might have specific requirements for untagging some
 * types of resources. For example, to untag Amazon Web Services Glue Connection, you must also have the
 * `glue:GetConnection` permission. If the expected minimum permissions
 * don't work, check the documentation for that service's tagging APIs for more
 * information.
 */
export declare const untagResources: API.OperationMethod<UntagResourcesInput, UntagResourcesOutput, UntagResourcesError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=resource-groups-tagging-api.d.ts.map