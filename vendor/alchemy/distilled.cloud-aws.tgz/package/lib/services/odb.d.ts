import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export interface AcceptMarketplaceRegistrationInput {
    marketplaceRegistrationToken: string;
}
export interface AcceptMarketplaceRegistrationOutput {
}
export type RoleArn = string;
export type SupportedAwsIntegration = "KmsTde" | (string & {});
export type Arn = string;
export interface AssociateIamRoleToResourceInput {
    iamRoleArn: string;
    awsIntegration: SupportedAwsIntegration;
    resourceArn: string;
}
export interface AssociateIamRoleToResourceOutput {
}
export type ResourceIdOrArn = string;
export interface AssociateVirtualMachinesToExadbVmClusterInput {
    exadbVmClusterId: string;
    desiredNodeCount: number;
}
export type ResourceStatus = "AVAILABLE" | "FAILED" | "PROVISIONING" | "TERMINATED" | "TERMINATING" | "UPDATING" | "MAINTENANCE_IN_PROGRESS" | (string & {});
export interface AssociateVirtualMachinesToExadbVmClusterOutput {
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    exadbVmClusterId: string;
}
export type ResourceDisplayName = string;
export type SensitiveString = string | redacted.Redacted<string>;
export type DbWorkload = "OLTP" | "AJD" | "APEX" | "LH" | (string & {});
export type LicenseModel = "BRING_YOUR_OWN_LICENSE" | "LICENSE_INCLUDED" | (string & {});
export type DatabaseEdition = "STANDARD_EDITION" | "ENTERPRISE_EDITION" | (string & {});
export type StandbyAllowlistedIpsSource = "PRIMARY" | "SEPARATE" | "NOT_APPLICABLE" | (string & {});
export type AutonomousMaintenanceScheduleType = "EARLY" | "REGULAR" | (string & {});
export interface CustomerContact {
    email?: string | redacted.Redacted<string>;
}
export type CustomerContacts = CustomerContact[];
export interface ResourcePoolSummary {
    isDisabled?: boolean;
    poolSize?: number;
    poolStorageSizeInTBs?: number;
    availableStorageCapacityInTBs?: number;
    totalComputeCapacity?: number;
    availableComputeCapacity?: number;
}
export type DayOfWeekName = "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | "SUNDAY" | (string & {});
export interface DayOfWeek {
    name?: DayOfWeekName;
}
export interface ScheduledOperationDetails {
    dayOfWeek: DayOfWeek;
    scheduledStartTime?: string;
    scheduledStopTime?: string;
}
export type ScheduledOperationDetailsList = ScheduledOperationDetails[];
export type StringList = string[];
export interface TransportableTablespace {
    ttsBundleUrl?: string;
}
export interface DatabaseTool {
    isEnabled?: boolean;
    name?: string;
    computeCount?: number;
    maxIdleTimeInMinutes?: number;
}
export type DatabaseToolList = DatabaseTool[];
export type SourceType = "NONE" | "DATABASE" | "BACKUP_FROM_ID" | "BACKUP_FROM_TIMESTAMP" | "CROSS_REGION_DATAGUARD" | "CROSS_REGION_DISASTER_RECOVERY" | "CLONE_TO_REFRESHABLE" | (string & {});
export type CloneType = "FULL" | "METADATA" | "PARTIAL" | (string & {});
export interface DatabaseCloneConfiguration {
    sourceAutonomousDatabaseId: string;
    cloneType: CloneType;
}
export type IntegerList = number[];
export interface RestoreFromBackupConfiguration {
    autonomousDatabaseBackupId: string;
    cloneType: CloneType;
    cloneTableSpaceList?: number[];
}
export interface PointInTimeRestoreConfiguration {
    sourceAutonomousDatabaseId: string;
    cloneType: CloneType;
    timestamp?: Date;
    useLatestAvailableBackupTimestamp?: boolean;
    cloneTableSpaceList?: number[];
}
export interface CrossRegionDataGuardConfiguration {
    sourceAutonomousDatabaseArn: string;
}
export type DisasterRecoveryType = "ADG" | "BACKUP_BASED" | (string & {});
export interface CrossRegionDisasterRecoveryConfiguration {
    sourceAutonomousDatabaseArn: string;
    remoteDisasterRecoveryType: DisasterRecoveryType;
    isReplicateAutomaticBackups?: boolean;
}
export type RefreshableMode = "AUTOMATIC" | "MANUAL" | (string & {});
export type OpenMode = "READ_ONLY" | "READ_WRITE" | (string & {});
export interface CloneToRefreshableConfiguration {
    sourceAutonomousDatabaseId: string;
    refreshableMode?: RefreshableMode;
    autoRefreshFrequencyInSeconds?: number;
    autoRefreshPointLagInSeconds?: number;
    timeOfAutoRefreshStart?: Date;
    openMode?: OpenMode;
    cloneType?: CloneType;
}
export type SourceConfiguration = {
    databaseClone: DatabaseCloneConfiguration;
    restoreFromBackup?: never;
    pointInTimeRestore?: never;
    crossRegionDataGuard?: never;
    crossRegionDisasterRecovery?: never;
    cloneToRefreshable?: never;
} | {
    databaseClone?: never;
    restoreFromBackup: RestoreFromBackupConfiguration;
    pointInTimeRestore?: never;
    crossRegionDataGuard?: never;
    crossRegionDisasterRecovery?: never;
    cloneToRefreshable?: never;
} | {
    databaseClone?: never;
    restoreFromBackup?: never;
    pointInTimeRestore: PointInTimeRestoreConfiguration;
    crossRegionDataGuard?: never;
    crossRegionDisasterRecovery?: never;
    cloneToRefreshable?: never;
} | {
    databaseClone?: never;
    restoreFromBackup?: never;
    pointInTimeRestore?: never;
    crossRegionDataGuard: CrossRegionDataGuardConfiguration;
    crossRegionDisasterRecovery?: never;
    cloneToRefreshable?: never;
} | {
    databaseClone?: never;
    restoreFromBackup?: never;
    pointInTimeRestore?: never;
    crossRegionDataGuard?: never;
    crossRegionDisasterRecovery: CrossRegionDisasterRecoveryConfiguration;
    cloneToRefreshable?: never;
} | {
    databaseClone?: never;
    restoreFromBackup?: never;
    pointInTimeRestore?: never;
    crossRegionDataGuard?: never;
    crossRegionDisasterRecovery?: never;
    cloneToRefreshable: CloneToRefreshableConfiguration;
};
export type EncryptionKeyProviderInput = "ORACLE_MANAGED" | "AWS_KMS" | (string & {});
export type ExternalIdType = "database_ocid" | "compartment_ocid" | "tenant_ocid" | (string & {});
export type KmsKeyIdOrArn = string;
export interface AwsEncryptionKeyConfigurationInput {
    iamRoleArn?: string;
    externalIdType?: ExternalIdType;
    kmsKeyId?: string;
}
export type EncryptionKeyConfigurationInput = {
    awsEncryptionKey: AwsEncryptionKeyConfigurationInput;
};
export type AdminPasswordSource = "CUSTOMER_MANAGED_AWS_SECRET" | "API_REQUEST_PARAMETER" | (string & {});
export type SecretIdOrArn = string;
export interface CustomerManagedAwsSecretConfigurationInput {
    secretId?: string;
    iamRoleArn?: string;
    externalIdType?: ExternalIdType;
}
export type AdminPasswordSourceConfigurationInput = {
    customerManagedAwsSecret: CustomerManagedAwsSecretConfigurationInput;
};
export type GeneralInputString = string;
export type TagKey = string;
export type TagValue = string;
export type RequestTagMap = {
    [key: string]: string | undefined;
};
export interface CreateAutonomousDatabaseInput {
    odbNetworkId?: string;
    displayName?: string;
    dbName?: string;
    adminPassword?: string | redacted.Redacted<string>;
    computeCount?: number;
    dataStorageSizeInTBs?: number;
    dataStorageSizeInGBs?: number;
    dbWorkload?: DbWorkload;
    isAutoScalingEnabled?: boolean;
    isAutoScalingForStorageEnabled?: boolean;
    licenseModel?: LicenseModel;
    characterSet?: string;
    ncharacterSet?: string;
    dbVersion?: string;
    databaseEdition?: DatabaseEdition;
    standbyAllowlistedIpsSource?: StandbyAllowlistedIpsSource;
    autonomousMaintenanceScheduleType?: AutonomousMaintenanceScheduleType;
    backupRetentionPeriodInDays?: number;
    byolComputeCountLimit?: number;
    cpuCoreCount?: number;
    customerContactsToSendToOCI?: CustomerContact[];
    privateEndpointIp?: string;
    privateEndpointLabel?: string;
    resourcePoolLeaderId?: string;
    resourcePoolSummary?: ResourcePoolSummary;
    scheduledOperations?: ScheduledOperationDetails[];
    standbyAllowlistedIps?: string[];
    allowlistedIps?: string[];
    transportableTablespace?: TransportableTablespace;
    isBackupRetentionLocked?: boolean;
    isLocalDataGuardEnabled?: boolean;
    isMtlsConnectionRequired?: boolean;
    dbToolsDetails?: DatabaseTool[];
    source?: SourceType;
    sourceConfiguration?: SourceConfiguration;
    encryptionKeyProvider?: EncryptionKeyProviderInput;
    encryptionKeyConfiguration?: EncryptionKeyConfigurationInput;
    adminPasswordSource?: AdminPasswordSource;
    adminPasswordSourceConfiguration?: AdminPasswordSourceConfigurationInput;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type AutonomousDatabaseResourceStatus = "AVAILABLE" | "FAILED" | "PROVISIONING" | "TERMINATED" | "TERMINATING" | "UPDATING" | "MAINTENANCE_IN_PROGRESS" | "STOPPING" | "STOPPED" | "STARTING" | "UNAVAILABLE" | "RESTORE_IN_PROGRESS" | "RESTORE_FAILED" | "BACKUP_IN_PROGRESS" | "SCALE_IN_PROGRESS" | "AVAILABLE_NEEDS_ATTENTION" | "RESTARTING" | "RECREATING" | "ROLE_CHANGE_IN_PROGRESS" | "UPGRADING" | "INACCESSIBLE" | "STANDBY" | (string & {});
export interface CreateAutonomousDatabaseOutput {
    autonomousDatabaseId: string;
    displayName?: string;
    status?: AutonomousDatabaseResourceStatus;
    statusReason?: string;
}
export interface CreateAutonomousDatabaseBackupInput {
    autonomousDatabaseId: string;
    displayName?: string;
    retentionPeriodInDays?: number;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateAutonomousDatabaseBackupOutput {
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    autonomousDatabaseBackupId: string;
}
export type WalletType = "REGIONAL" | "INSTANCE" | (string & {});
export type WalletPasswordSource = "CUSTOMER_MANAGED_AWS_SECRET" | "API_REQUEST_PARAMETER" | (string & {});
export type WalletPasswordSourceConfigurationInput = {
    customerManagedAwsSecret: CustomerManagedAwsSecretConfigurationInput;
};
export interface CreateAutonomousDatabaseWalletInput {
    autonomousDatabaseId: string;
    walletType?: WalletType;
    password?: string | redacted.Redacted<string>;
    passwordSource?: WalletPasswordSource;
    passwordSourceConfiguration?: WalletPasswordSourceConfigurationInput;
    clientToken?: string;
}
export type AutonomousDatabaseWalletFile = Uint8Array | redacted.Redacted<Uint8Array>;
export interface CreateAutonomousDatabaseWalletOutput {
    autonomousDatabaseWalletFile: Uint8Array | redacted.Redacted<Uint8Array>;
}
export type DaysOfWeek = DayOfWeek[];
export type HoursOfDay = number[];
export type MonthName = "JANUARY" | "FEBRUARY" | "MARCH" | "APRIL" | "MAY" | "JUNE" | "JULY" | "AUGUST" | "SEPTEMBER" | "OCTOBER" | "NOVEMBER" | "DECEMBER" | (string & {});
export interface Month {
    name?: MonthName;
}
export type Months = Month[];
export type PatchingModeType = "ROLLING" | "NONROLLING" | (string & {});
export type PreferenceType = "NO_PREFERENCE" | "CUSTOM_PREFERENCE" | (string & {});
export type WeeksOfMonth = number[];
export interface MaintenanceWindow {
    customActionTimeoutInMins?: number;
    daysOfWeek?: DayOfWeek[];
    hoursOfDay?: number[];
    isCustomActionTimeoutEnabled?: boolean;
    leadTimeInWeeks?: number;
    months?: Month[];
    patchingMode?: PatchingModeType;
    preference?: PreferenceType;
    skipRu?: boolean;
    weeksOfMonth?: number[];
}
export interface CreateCloudAutonomousVmClusterInput {
    cloudExadataInfrastructureId: string;
    odbNetworkId: string;
    displayName: string;
    clientToken?: string;
    autonomousDataStorageSizeInTBs: number;
    cpuCoreCountPerNode: number;
    dbServers?: string[];
    description?: string;
    isMtlsEnabledVmCluster?: boolean;
    licenseModel?: LicenseModel;
    maintenanceWindow?: MaintenanceWindow;
    memoryPerOracleComputeUnitInGBs: number;
    scanListenerPortNonTls?: number;
    scanListenerPortTls?: number;
    tags?: {
        [key: string]: string | undefined;
    };
    timeZone?: string;
    totalContainerDatabases: number;
}
export interface CreateCloudAutonomousVmClusterOutput {
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    cloudAutonomousVmClusterId: string;
}
export interface CreateCloudExadataInfrastructureInput {
    displayName: string;
    shape: string;
    availabilityZone?: string;
    availabilityZoneId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    computeCount: number;
    customerContactsToSendToOCI?: CustomerContact[];
    maintenanceWindow?: MaintenanceWindow;
    storageCount: number;
    clientToken?: string;
    databaseServerType?: string;
    storageServerType?: string;
}
export interface CreateCloudExadataInfrastructureOutput {
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    cloudExadataInfrastructureId: string;
}
export type Hostname = string;
export type ClusterName = string;
export interface DataCollectionOptions {
    isDiagnosticsEventsEnabled?: boolean;
    isHealthMonitoringEnabled?: boolean;
    isIncidentLogsEnabled?: boolean;
}
export interface CreateCloudVmClusterInput {
    cloudExadataInfrastructureId: string;
    cpuCoreCount: number;
    displayName: string;
    giVersion: string;
    hostname: string;
    sshPublicKeys: string[];
    odbNetworkId: string;
    clusterName?: string;
    dataCollectionOptions?: DataCollectionOptions;
    dataStorageSizeInTBs?: number;
    dbNodeStorageSizeInGBs?: number;
    dbServers?: string[];
    tags?: {
        [key: string]: string | undefined;
    };
    isLocalBackupEnabled?: boolean;
    isSparseDiskgroupEnabled?: boolean;
    licenseModel?: LicenseModel;
    memorySizeInGBs?: number;
    systemVersion?: string;
    timeZone?: string;
    clientToken?: string;
    scanListenerPortTcp?: number;
}
export interface CreateCloudVmClusterOutput {
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    cloudVmClusterId: string;
}
export type ShapeAttribute = "SMART_STORAGE" | "BLOCK_STORAGE" | (string & {});
export interface CreateExadbVmClusterInput {
    displayName: string;
    enabledEcpuCount: number;
    exascaleDbStorageVaultId: string;
    gridImageId: string;
    hostname: string;
    nodeCount: number;
    odbNetworkId: string;
    shape: string;
    sshPublicKeys: string[];
    totalEcpuCount: number;
    vmFileSystemStorageTotalSizeInGBs: number;
    clusterName?: string;
    dataCollectionOptions?: DataCollectionOptions;
    licenseModel?: LicenseModel;
    scanListenerPortTcp?: number;
    scanListenerPortTcpSsl?: number;
    shapeAttribute?: ShapeAttribute;
    systemVersion?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    timeZone?: string;
    clientToken?: string;
}
export interface CreateExadbVmClusterOutput {
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    exadbVmClusterId: string;
}
export interface CreateExascaleDbStorageVaultInput {
    displayName: string;
    highCapacityDatabaseStorageTotalSizeInGBs: number;
    additionalFlashCacheInPercent?: number;
    autoscaleLimitInGBs?: number;
    availabilityZoneId?: string;
    availabilityZone?: string;
    description?: string;
    isAutoscaleEnabled?: boolean;
    tags?: {
        [key: string]: string | undefined;
    };
    timeZone?: string;
    clientToken?: string;
}
export interface CreateExascaleDbStorageVaultOutput {
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    exascaleDbStorageVaultId: string;
}
export type Access = "ENABLED" | "DISABLED" | (string & {});
export type PolicyDocument = string;
export interface CreateOdbNetworkInput {
    displayName: string;
    availabilityZone?: string;
    availabilityZoneId?: string;
    clientSubnetCidr: string;
    backupSubnetCidr?: string;
    customDomainName?: string;
    defaultDnsPrefix?: string;
    clientToken?: string;
    s3Access?: Access;
    zeroEtlAccess?: Access;
    stsAccess?: Access;
    kmsAccess?: Access;
    s3PolicyDocument?: string;
    stsPolicyDocument?: string;
    kmsPolicyDocument?: string;
    crossRegionS3RestoreSourcesToEnable?: string[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateOdbNetworkOutput {
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    odbNetworkId: string;
}
export type PeeredCidr = string;
export type PeeredCidrList = string[];
export type PeerNetworkRouteTableId = string;
export type PeerNetworkRouteTableIdList = string[];
export interface CreateOdbPeeringConnectionInput {
    odbNetworkId: string;
    peerNetworkId: string;
    displayName?: string;
    peerNetworkCidrsToBeAdded?: string[];
    peerNetworkRouteTableIds?: string[];
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateOdbPeeringConnectionOutput {
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    odbPeeringConnectionId: string;
}
export interface DeleteAutonomousDatabaseInput {
    autonomousDatabaseId: string;
}
export interface DeleteAutonomousDatabaseOutput {
}
export type ResourceId = string;
export interface DeleteAutonomousDatabaseBackupInput {
    autonomousDatabaseBackupId: string;
}
export interface DeleteAutonomousDatabaseBackupOutput {
}
export interface DeleteCloudAutonomousVmClusterInput {
    cloudAutonomousVmClusterId: string;
}
export interface DeleteCloudAutonomousVmClusterOutput {
}
export interface DeleteCloudExadataInfrastructureInput {
    cloudExadataInfrastructureId: string;
}
export interface DeleteCloudExadataInfrastructureOutput {
}
export interface DeleteCloudVmClusterInput {
    cloudVmClusterId: string;
}
export interface DeleteCloudVmClusterOutput {
}
export interface DeleteExadbVmClusterInput {
    exadbVmClusterId: string;
}
export interface DeleteExadbVmClusterOutput {
}
export interface DeleteExascaleDbStorageVaultInput {
    exascaleDbStorageVaultId: string;
}
export interface DeleteExascaleDbStorageVaultOutput {
}
export interface DeleteOdbNetworkInput {
    odbNetworkId: string;
    deleteAssociatedResources: boolean;
}
export interface DeleteOdbNetworkOutput {
}
export interface DeleteOdbPeeringConnectionInput {
    odbPeeringConnectionId: string;
}
export interface DeleteOdbPeeringConnectionOutput {
}
export interface DisassociateIamRoleFromResourceInput {
    iamRoleArn: string;
    awsIntegration: SupportedAwsIntegration;
    resourceArn: string;
}
export interface DisassociateIamRoleFromResourceOutput {
}
export type ResourceIdList = string[];
export interface DisassociateVirtualMachinesFromExadbVmClusterInput {
    exadbVmClusterId: string;
    dbNodeIds: string[];
}
export interface DisassociateVirtualMachinesFromExadbVmClusterOutput {
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    exadbVmClusterId: string;
}
export type ResourceArn = string;
export interface FailoverAutonomousDatabaseInput {
    autonomousDatabaseId: string;
    peerDbArn?: string;
}
export interface FailoverAutonomousDatabaseOutput {
    autonomousDatabaseId: string;
    displayName?: string;
    status?: AutonomousDatabaseResourceStatus;
    statusReason?: string;
}
export interface GetAutonomousDatabaseInput {
    autonomousDatabaseId: string;
}
export type DatabaseType = "REGULAR" | "CLONE" | (string & {});
export type PermissionLevel = "RESTRICTED" | "UNRESTRICTED" | (string & {});
export type NetServicesArchitecture = "DEDICATED" | "SHARED" | (string & {});
export type DatabaseConnectionStringMap = {
    [key: string]: string | undefined;
};
export interface DatabaseConnectionStringProfile {
    consumerGroup?: string;
    displayName?: string;
    hostFormat?: string;
    isRegional?: boolean;
    protocol?: string;
    sessionMode?: string;
    syntaxFormat?: string;
    tlsAuthentication?: string;
    value?: string;
}
export type DatabaseConnectionStringProfileList = DatabaseConnectionStringProfile[];
export interface AutonomousDatabaseConnectionStrings {
    allConnectionStrings?: {
        [key: string]: string | undefined;
    };
    dedicated?: string;
    high?: string;
    medium?: string;
    low?: string;
    profiles?: DatabaseConnectionStringProfile[];
}
export interface AutonomousDatabaseApex {
    apexVersion?: string;
    ordsVersion?: string;
}
export interface DatabaseStandbySummary {
    availabilityDomain?: string;
    lagTimeInSeconds?: number;
    status?: AutonomousDatabaseResourceStatus;
    statusReason?: string;
    maintenanceTargetComponent?: string;
    timeDataGuardRoleChanged?: Date;
    timeDisasterRecoveryRoleChanged?: Date;
    timeMaintenanceBegin?: Date;
    timeMaintenanceEnd?: Date;
}
export type DataSafeStatus = "REGISTERING" | "REGISTERED" | "DEREGISTERING" | "NOT_REGISTERED" | "FAILED" | (string & {});
export type DatabaseManagementStatus = "ENABLING" | "ENABLED" | "DISABLING" | "NOT_ENABLED" | "FAILED_ENABLING" | "FAILED_DISABLING" | (string & {});
export type OperationsInsightsStatus = "ENABLING" | "ENABLED" | "DISABLING" | "NOT_ENABLED" | "FAILED_ENABLING" | "FAILED_DISABLING" | (string & {});
export interface AutonomousDatabaseConnectionUrls {
    apexUrl?: string;
    databaseTransformsUrl?: string;
    graphStudioUrl?: string;
    machineLearningNotebookUrl?: string;
    machineLearningUserManagementUrl?: string;
    mongoDbUrl?: string;
    ordsUrl?: string;
    spatialStudioUrl?: string;
    sqlDevWebUrl?: string;
}
export type ComputeModel = "ECPU" | "OCPU" | (string & {});
export type DataGuardRole = "PRIMARY" | "STANDBY" | "DISABLED_STANDBY" | "BACKUP_COPY" | "SNAPSHOT_STANDBY" | (string & {});
export interface DisasterRecoveryConfiguration {
    disasterRecoveryType?: DisasterRecoveryType;
    isReplicateAutomaticBackups?: boolean;
    isSnapshotStandby?: boolean;
    timeSnapshotStandbyEnabledTill?: Date;
}
export type RefreshableStatus = "REFRESHING" | "NOT_REFRESHING" | (string & {});
export type RepeatCadence = "ONE_TIME" | "WEEKLY" | "MONTHLY" | "YEARLY" | (string & {});
export interface LongTermBackupSchedule {
    isDisabled?: boolean;
    repeatCadence?: RepeatCadence;
    retentionPeriodInDays?: number;
    timeOfBackup?: Date;
}
export type EncryptionKeyProvider = "ORACLE_MANAGED" | "AWS_KMS" | "OKV" | "OCI" | (string & {});
export interface AwsEncryptionKeyConfiguration {
    iamRoleArn?: string;
    externalIdType?: ExternalIdType;
    kmsKeyId?: string;
}
export interface OciEncryptionKeyConfiguration {
    kmsKeyId: string;
    vaultId: string;
}
export interface OkvEncryptionKeyConfiguration {
    certificateDirectoryName: string;
    certificateId?: string;
    directoryName: string;
    okvKmsKey: string;
    okvUri: string;
}
export type EncryptionKeyConfiguration = {
    awsEncryptionKey: AwsEncryptionKeyConfiguration;
    ociEncryptionKey?: never;
    okvEncryptionKey?: never;
} | {
    awsEncryptionKey?: never;
    ociEncryptionKey: OciEncryptionKeyConfiguration;
    okvEncryptionKey?: never;
} | {
    awsEncryptionKey?: never;
    ociEncryptionKey?: never;
    okvEncryptionKey: OkvEncryptionKeyConfiguration;
};
export interface EncryptionSummary {
    encryptionKeyProvider?: EncryptionKeyProvider;
    encryptionKeyConfiguration?: EncryptionKeyConfiguration;
}
export interface CustomerManagedAwsSecretConfiguration {
    iamRoleArn?: string;
    secretId?: string;
    externalIdType?: ExternalIdType;
}
export type AdminPasswordSourceConfiguration = {
    customerManagedAwsSecret: CustomerManagedAwsSecretConfiguration;
};
export interface AdminPasswordSourceSummary {
    adminPasswordSource?: AdminPasswordSource;
    adminPasswordSourceConfiguration?: AdminPasswordSourceConfiguration;
}
export interface AutonomousDatabase {
    autonomousDatabaseId?: string;
    autonomousDatabaseArn?: string;
    ociResourceAnchorName?: string;
    percentProgress?: number;
    ocid?: string;
    ociUrl?: string;
    displayName?: string;
    dbName?: string;
    sourceId?: string;
    status?: AutonomousDatabaseResourceStatus;
    statusReason?: string;
    databaseType?: DatabaseType;
    dbVersion?: string;
    dbWorkload?: DbWorkload;
    characterSet?: string;
    ncharacterSet?: string;
    databaseEdition?: DatabaseEdition;
    licenseModel?: LicenseModel;
    openMode?: OpenMode;
    permissionLevel?: PermissionLevel;
    isMtlsConnectionRequired?: boolean;
    autonomousMaintenanceScheduleType?: AutonomousMaintenanceScheduleType;
    netServicesArchitecture?: NetServicesArchitecture;
    availableUpgradeVersions?: string[];
    byolComputeCountLimit?: number;
    connectionStringDetails?: AutonomousDatabaseConnectionStrings;
    serviceConsoleUrl?: string;
    sqlWebDeveloperUrl?: string;
    customerContacts?: CustomerContact[];
    apexDetails?: AutonomousDatabaseApex;
    standbyDb?: DatabaseStandbySummary;
    localStandbyDb?: DatabaseStandbySummary;
    dataSafeStatus?: DataSafeStatus;
    databaseManagementStatus?: DatabaseManagementStatus;
    operationsInsightsStatus?: OperationsInsightsStatus;
    availabilityZone?: string;
    availabilityZoneId?: string;
    maintenanceTargetComponent?: string;
    connectionUrls?: AutonomousDatabaseConnectionUrls;
    dbToolsDetails?: DatabaseTool[];
    scheduledOperations?: ScheduledOperationDetails[];
    resourcePoolLeaderId?: string;
    computeCount?: number;
    computeModel?: ComputeModel;
    cpuCoreCount?: number;
    memoryPerOracleComputeUnitInGBs?: number;
    provisionableCpus?: number[];
    isAutoScalingEnabled?: boolean;
    dataStorageSizeInTBs?: number;
    dataStorageSizeInGBs?: number;
    usedDataStorageSizeInTBs?: number;
    usedDataStorageSizeInGBs?: number;
    actualUsedDataStorageSizeInTBs?: number;
    allocatedStorageSizeInTBs?: number;
    inMemoryAreaInGBs?: number;
    isAutoScalingForStorageEnabled?: boolean;
    odbNetworkId?: string;
    odbNetworkArn?: string;
    privateEndpoint?: string;
    privateEndpointIp?: string;
    privateEndpointLabel?: string;
    allowlistedIps?: string[];
    standbyAllowlistedIps?: string[];
    standbyAllowlistedIpsSource?: StandbyAllowlistedIpsSource;
    isLocalDataGuardEnabled?: boolean;
    isRemoteDataGuardEnabled?: boolean;
    localDisasterRecoveryType?: DisasterRecoveryType;
    role?: DataGuardRole;
    peerDbIds?: string[];
    failedDataRecoveryInSeconds?: number;
    localAdgAutoFailoverMaxDataLossLimit?: number;
    remoteDisasterRecoveryConfiguration?: DisasterRecoveryConfiguration;
    isRefreshableClone?: boolean;
    refreshableMode?: RefreshableMode;
    refreshableStatus?: RefreshableStatus;
    autoRefreshFrequencyInSeconds?: number;
    autoRefreshPointLagInSeconds?: number;
    isReconnectCloneEnabled?: boolean;
    cloneTableSpaceList?: number[];
    backupRetentionPeriodInDays?: number;
    longTermBackupSchedule?: LongTermBackupSchedule;
    isBackupRetentionLocked?: boolean;
    totalBackupStorageSizeInGBs?: number;
    resourcePoolSummary?: ResourcePoolSummary;
    encryptionSummary?: EncryptionSummary;
    createdAt?: Date;
    timeOfLastBackup?: Date;
    timeMaintenanceBegin?: Date;
    timeMaintenanceEnd?: Date;
    timeLocalDataGuardEnabled?: Date;
    timeDataGuardRoleChanged?: Date;
    timeOfLastSwitchover?: Date;
    timeOfLastFailover?: Date;
    timeOfLastRefresh?: Date;
    timeOfLastRefreshPoint?: Date;
    timeOfNextRefresh?: Date;
    timeOfAutoRefreshStart?: Date;
    timeDeletionOfFreeAutonomousDatabase?: Date;
    timeReclamationOfFreeAutonomousDatabase?: Date;
    timeDisasterRecoveryRoleChanged?: Date;
    timeUntilReconnectCloneEnabled?: Date;
    nextLongTermBackupTimeStamp?: Date;
    timeUndeleted?: Date;
    adminPasswordSourceSummary?: AdminPasswordSourceSummary;
}
export interface GetAutonomousDatabaseOutput {
    autonomousDatabase: AutonomousDatabase;
}
export interface GetAutonomousDatabaseBackupInput {
    autonomousDatabaseBackupId: string;
}
export type AutonomousDatabaseBackupStatus = "ACTIVE" | "CREATING" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export type AutonomousDatabaseBackupType = "INCREMENTAL" | "FULL" | "LONGTERM" | "VIRTUAL_FULL" | "CUMULATIVE_INCREMENTAL" | "ROLL_FORWARD_IMAGE_COPY" | (string & {});
export interface AutonomousDatabaseBackup {
    autonomousDatabaseBackupId?: string;
    autonomousDatabaseBackupArn?: string;
    autonomousDatabaseId?: string;
    ocid?: string;
    displayName?: string;
    dbVersion?: string;
    status?: AutonomousDatabaseBackupStatus;
    statusReason?: string;
    isAutomatic?: boolean;
    retentionPeriodInDays?: number;
    sizeInTBs?: number;
    timeAvailableTill?: Date;
    timeStarted?: Date;
    timeEnded?: Date;
    type?: AutonomousDatabaseBackupType;
}
export interface GetAutonomousDatabaseBackupOutput {
    autonomousDatabaseBackup?: AutonomousDatabaseBackup;
}
export interface GetAutonomousDatabaseWalletDetailsInput {
    autonomousDatabaseId: string;
}
export type AutonomousDatabaseWalletStatus = "ACTIVE" | "UPDATING" | (string & {});
export type WalletPasswordSourceConfiguration = {
    customerManagedAwsSecret: CustomerManagedAwsSecretConfiguration;
};
export interface WalletPasswordSourceSummary {
    passwordSource?: WalletPasswordSource;
    passwordSourceConfiguration?: WalletPasswordSourceConfiguration;
}
export interface AutonomousDatabaseWalletDetails {
    status?: AutonomousDatabaseWalletStatus;
    timeRotated?: Date;
    passwordSourceSummary?: WalletPasswordSourceSummary;
}
export interface GetAutonomousDatabaseWalletDetailsOutput {
    autonomousDatabaseWalletDetails: AutonomousDatabaseWalletDetails;
}
export interface GetCloudAutonomousVmClusterInput {
    cloudAutonomousVmClusterId: string;
}
export type IamRoleStatus = "ASSOCIATING" | "DISASSOCIATING" | "FAILED" | "CONNECTED" | "DISCONNECTED" | "PARTIALLY_CONNECTED" | "UNKNOWN" | (string & {});
export interface IamRole {
    iamRoleArn?: string;
    status?: IamRoleStatus;
    statusReason?: string;
    awsIntegration?: SupportedAwsIntegration;
}
export type IamRoleList = IamRole[];
export interface CloudAutonomousVmCluster {
    cloudAutonomousVmClusterId: string;
    cloudAutonomousVmClusterArn?: string;
    odbNetworkId?: string;
    odbNetworkArn?: string;
    ociResourceAnchorName?: string;
    percentProgress?: number;
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    cloudExadataInfrastructureId?: string;
    cloudExadataInfrastructureArn?: string;
    autonomousDataStoragePercentage?: number;
    autonomousDataStorageSizeInTBs?: number;
    availableAutonomousDataStorageSizeInTBs?: number;
    availableContainerDatabases?: number;
    availableCpus?: number;
    computeModel?: ComputeModel;
    cpuCoreCount?: number;
    cpuCoreCountPerNode?: number;
    cpuPercentage?: number;
    dataStorageSizeInGBs?: number;
    dataStorageSizeInTBs?: number;
    dbNodeStorageSizeInGBs?: number;
    dbServers?: string[];
    description?: string;
    domain?: string;
    exadataStorageInTBsLowestScaledValue?: number;
    hostname?: string;
    ocid?: string;
    ociUrl?: string;
    isMtlsEnabledVmCluster?: boolean;
    licenseModel?: LicenseModel;
    maintenanceWindow?: MaintenanceWindow;
    maxAcdsLowestScaledValue?: number;
    memoryPerOracleComputeUnitInGBs?: number;
    memorySizeInGBs?: number;
    nodeCount?: number;
    nonProvisionableAutonomousContainerDatabases?: number;
    provisionableAutonomousContainerDatabases?: number;
    provisionedAutonomousContainerDatabases?: number;
    provisionedCpus?: number;
    reclaimableCpus?: number;
    reservedCpus?: number;
    scanListenerPortNonTls?: number;
    scanListenerPortTls?: number;
    shape?: string;
    createdAt?: Date;
    timeDatabaseSslCertificateExpires?: Date;
    timeOrdsCertificateExpires?: Date;
    timeZone?: string;
    totalContainerDatabases?: number;
    iamRoles?: IamRole[];
}
export interface GetCloudAutonomousVmClusterOutput {
    cloudAutonomousVmCluster?: CloudAutonomousVmCluster;
}
export interface GetCloudExadataInfrastructureInput {
    cloudExadataInfrastructureId: string;
}
export interface CloudExadataInfrastructure {
    cloudExadataInfrastructureId: string;
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    cloudExadataInfrastructureArn?: string;
    activatedStorageCount?: number;
    additionalStorageCount?: number;
    availableStorageSizeInGBs?: number;
    availabilityZone?: string;
    availabilityZoneId?: string;
    computeCount?: number;
    cpuCount?: number;
    customerContactsToSendToOCI?: CustomerContact[];
    dataStorageSizeInTBs?: number;
    dbNodeStorageSizeInGBs?: number;
    dbServerVersion?: string;
    lastMaintenanceRunId?: string;
    maintenanceWindow?: MaintenanceWindow;
    maxCpuCount?: number;
    maxDataStorageInTBs?: number;
    maxDbNodeStorageSizeInGBs?: number;
    maxMemoryInGBs?: number;
    memorySizeInGBs?: number;
    monthlyDbServerVersion?: string;
    monthlyStorageServerVersion?: string;
    nextMaintenanceRunId?: string;
    ociResourceAnchorName?: string;
    ociUrl?: string;
    ocid?: string;
    shape?: string;
    storageCount?: number;
    storageServerVersion?: string;
    createdAt?: Date;
    totalStorageSizeInGBs?: number;
    percentProgress?: number;
    databaseServerType?: string;
    storageServerType?: string;
    computeModel?: ComputeModel;
}
export interface GetCloudExadataInfrastructureOutput {
    cloudExadataInfrastructure?: CloudExadataInfrastructure;
}
export interface GetCloudExadataInfrastructureUnallocatedResourcesInput {
    cloudExadataInfrastructureId: string;
    dbServers?: string[];
}
export interface CloudAutonomousVmClusterResourceDetails {
    cloudAutonomousVmClusterId?: string;
    unallocatedAdbStorageInTBs?: number;
}
export type CloudAutonomousVmClusterResourceDetailsList = CloudAutonomousVmClusterResourceDetails[];
export interface CloudExadataInfrastructureUnallocatedResources {
    cloudAutonomousVmClusters?: CloudAutonomousVmClusterResourceDetails[];
    cloudExadataInfrastructureDisplayName?: string;
    exadataStorageInTBs?: number;
    cloudExadataInfrastructureId?: string;
    localStorageInGBs?: number;
    memoryInGBs?: number;
    ocpus?: number;
}
export interface GetCloudExadataInfrastructureUnallocatedResourcesOutput {
    cloudExadataInfrastructureUnallocatedResources?: CloudExadataInfrastructureUnallocatedResources;
}
export interface GetCloudVmClusterInput {
    cloudVmClusterId: string;
}
export type DiskRedundancy = "HIGH" | "NORMAL" | (string & {});
export interface DbIormConfig {
    dbName?: string;
    flashCacheLimit?: string;
    share?: number;
}
export type DbIormConfigList = DbIormConfig[];
export type IormLifecycleState = "BOOTSTRAPPING" | "DISABLED" | "ENABLED" | "FAILED" | "UPDATING" | (string & {});
export type Objective = "AUTO" | "BALANCED" | "BASIC" | "HIGH_THROUGHPUT" | "LOW_LATENCY" | (string & {});
export interface ExadataIormConfig {
    dbPlans?: DbIormConfig[];
    lifecycleDetails?: string;
    lifecycleState?: IormLifecycleState;
    objective?: Objective;
}
export type SensitiveStringList = (string | redacted.Redacted<string>)[];
export interface CloudVmCluster {
    cloudVmClusterId: string;
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    cloudVmClusterArn?: string;
    cloudExadataInfrastructureId?: string;
    cloudExadataInfrastructureArn?: string;
    clusterName?: string;
    cpuCoreCount?: number;
    dataCollectionOptions?: DataCollectionOptions;
    dataStorageSizeInTBs?: number;
    dbNodeStorageSizeInGBs?: number;
    dbServers?: string[];
    diskRedundancy?: DiskRedundancy;
    giVersion?: string;
    hostname?: string;
    iormConfigCache?: ExadataIormConfig;
    isLocalBackupEnabled?: boolean;
    isSparseDiskgroupEnabled?: boolean;
    lastUpdateHistoryEntryId?: string;
    licenseModel?: LicenseModel;
    listenerPort?: number;
    memorySizeInGBs?: number;
    nodeCount?: number;
    ocid?: string;
    ociResourceAnchorName?: string;
    ociUrl?: string;
    domain?: string;
    scanDnsName?: string;
    scanDnsRecordId?: string;
    scanIpIds?: string[];
    shape?: string;
    sshPublicKeys?: (string | redacted.Redacted<string>)[];
    storageSizeInGBs?: number;
    systemVersion?: string;
    createdAt?: Date;
    timeZone?: string;
    vipIds?: string[];
    odbNetworkId?: string;
    odbNetworkArn?: string;
    percentProgress?: number;
    computeModel?: ComputeModel;
    iamRoles?: IamRole[];
}
export interface GetCloudVmClusterOutput {
    cloudVmCluster?: CloudVmCluster;
}
export interface GetDbNodeInput {
    cloudVmClusterId?: string;
    exadbVmClusterId?: string;
    dbNodeId: string;
}
export type DbNodeResourceStatus = "AVAILABLE" | "FAILED" | "PROVISIONING" | "TERMINATED" | "TERMINATING" | "UPDATING" | "STOPPING" | "STOPPED" | "STARTING" | (string & {});
export type DbNodeMaintenanceType = "VMDB_REBOOT_MIGRATION" | (string & {});
export interface DbNode {
    dbNodeId?: string;
    dbNodeArn?: string;
    status?: DbNodeResourceStatus;
    statusReason?: string;
    additionalDetails?: string;
    backupIpId?: string;
    backupVnic2Id?: string;
    backupVnicId?: string;
    cpuCoreCount?: number;
    dbNodeStorageSizeInGBs?: number;
    dbServerId?: string;
    dbSystemId?: string;
    faultDomain?: string;
    hostIpId?: string;
    hostname?: string;
    ocid?: string;
    ociResourceAnchorName?: string;
    maintenanceType?: DbNodeMaintenanceType;
    memorySizeInGBs?: number;
    softwareStorageSizeInGB?: number;
    createdAt?: Date;
    timeMaintenanceWindowEnd?: string;
    timeMaintenanceWindowStart?: string;
    totalCpuCoreCount?: number;
    vnic2Id?: string;
    vnicId?: string;
    privateIpAddress?: string;
    floatingIpAddress?: string;
}
export interface GetDbNodeOutput {
    dbNode?: DbNode;
}
export interface GetDbServerInput {
    cloudExadataInfrastructureId: string;
    dbServerId: string;
}
export type DbServerPatchingStatus = "COMPLETE" | "FAILED" | "MAINTENANCE_IN_PROGRESS" | "SCHEDULED" | (string & {});
export interface DbServerPatchingDetails {
    estimatedPatchDuration?: number;
    patchingStatus?: DbServerPatchingStatus;
    timePatchingEnded?: string;
    timePatchingStarted?: string;
}
export interface DbServer {
    dbServerId?: string;
    status?: ResourceStatus;
    statusReason?: string;
    cpuCoreCount?: number;
    dbNodeStorageSizeInGBs?: number;
    dbServerPatchingDetails?: DbServerPatchingDetails;
    displayName?: string;
    exadataInfrastructureId?: string;
    ocid?: string;
    ociResourceAnchorName?: string;
    maxCpuCount?: number;
    maxDbNodeStorageInGBs?: number;
    maxMemoryInGBs?: number;
    memorySizeInGBs?: number;
    shape?: string;
    createdAt?: Date;
    vmClusterIds?: string[];
    computeModel?: ComputeModel;
    autonomousVmClusterIds?: string[];
    autonomousVirtualMachineIds?: string[];
}
export interface GetDbServerOutput {
    dbServer?: DbServer;
}
export interface GetExadbVmClusterInput {
    exadbVmClusterId: string;
}
export type GridImageType = "RELEASE_UPDATE" | "CUSTOM_IMAGE" | (string & {});
export interface ExadbVmClusterStorageDetails {
    totalSizeInGBs?: number;
}
export interface ExadbVmCluster {
    exadbVmClusterId: string;
    clusterName?: string;
    createdAt?: Date;
    dataCollectionOptions?: DataCollectionOptions;
    displayName?: string;
    domain?: string;
    enabledEcpuCount?: number;
    exadbVmClusterArn?: string;
    exascaleDbStorageVaultArn?: string;
    exascaleDbStorageVaultId?: string;
    giVersion?: string;
    gridImageId?: string;
    gridImageType?: GridImageType;
    hostname?: string;
    iamRoles?: IamRole[];
    iormConfigCache?: ExadataIormConfig;
    lastUpdateHistoryEntryId?: string;
    licenseModel?: LicenseModel;
    listenerPort?: number;
    memorySizeInGBs?: number;
    nodeCount?: number;
    ocid?: string;
    ociResourceAnchorName?: string;
    ociUrl?: string;
    odbNetworkArn?: string;
    odbNetworkId?: string;
    percentProgress?: number;
    scanDnsName?: string;
    scanDnsRecordId?: string;
    scanIpIds?: string[];
    scanListenerPortTcp?: number;
    scanListenerPortTcpSsl?: number;
    shape?: string;
    shapeAttribute?: ShapeAttribute;
    snapshotFileSystemStorage?: ExadbVmClusterStorageDetails;
    sshPublicKeys?: string[];
    status?: ResourceStatus;
    statusReason?: string;
    systemVersion?: string;
    timeZone?: string;
    totalEcpuCount?: number;
    totalFileSystemStorage?: ExadbVmClusterStorageDetails;
    vipIds?: string[];
    vmFileSystemStorage?: ExadbVmClusterStorageDetails;
}
export interface GetExadbVmClusterOutput {
    exadbVmCluster: ExadbVmCluster;
}
export interface GetExascaleDbStorageVaultInput {
    exascaleDbStorageVaultId: string;
}
export type ShapeAttributeList = ShapeAttribute[];
export type ResourceArnList = string[];
export interface ExascaleDbStorageDetails {
    availableSizeInGBs?: number;
    totalSizeInGBs?: number;
}
export interface ExascaleDbStorageVault {
    exascaleDbStorageVaultId: string;
    additionalFlashCacheInPercent?: number;
    attachedShapeAttributes?: ShapeAttribute[];
    autoscaleLimitInGBs?: number;
    availabilityZone?: string;
    availabilityZoneId?: string;
    createdAt?: Date;
    description?: string;
    displayName?: string;
    vmClusterArns?: string[];
    vmClusterCount?: number;
    vmClusterIds?: string[];
    exascaleDbStorageVaultArn?: string;
    highCapacityDatabaseStorage?: ExascaleDbStorageDetails;
    isAutoscaleEnabled?: boolean;
    ocid?: string;
    ociResourceAnchorName?: string;
    ociUrl?: string;
    percentProgress?: number;
    status?: ResourceStatus;
    statusReason?: string;
    timeZone?: string;
}
export interface GetExascaleDbStorageVaultOutput {
    exascaleDbStorageVault: ExascaleDbStorageVault;
}
export interface GetOciOnboardingStatusInput {
}
export type OciOnboardingStatus = "NOT_STARTED" | "PENDING_LINK_GENERATION" | "PENDING_CUSTOMER_ACTION" | "PENDING_INITIALIZATION" | "ACTIVATING" | "ACTIVE_IN_HOME_REGION" | "ACTIVE" | "ACTIVE_LIMITED" | "FAILED" | "PUBLIC_OFFER_UNSUPPORTED" | "SUSPENDED" | "CANCELED" | (string & {});
export interface OciIdentityDomain {
    ociIdentityDomainId?: string;
    ociIdentityDomainResourceUrl?: string;
    ociIdentityDomainUrl?: string;
    status?: ResourceStatus;
    statusReason?: string;
    accountSetupCloudFormationUrl?: string;
}
export type OciAwsIntegration = "KmsTde" | "SecretsManager" | (string & {});
export type OciIamRoleStatus = "PROVISIONING" | "AVAILABLE" | "PROVISION_FAILED" | "TERMINATING" | "TERMINATE_FAILED" | (string & {});
export interface OciIamRole {
    iamRoleArn?: string;
    awsIntegration?: OciAwsIntegration;
    status?: OciIamRoleStatus;
    statusReason?: string;
}
export type OciIamRoleList = OciIamRole[];
export interface SubscriptionError {
    errorMessage?: string;
}
export type SubscriptionErrors = SubscriptionError[];
export interface GetOciOnboardingStatusOutput {
    status?: OciOnboardingStatus;
    existingTenancyActivationLink?: string;
    newTenancyActivationLink?: string;
    ociIdentityDomain?: OciIdentityDomain;
    autonomousDatabaseOciIntegrationIamRoles?: OciIamRole[];
    linkedOciTenancyId?: string;
    linkedOciCompartmentId?: string;
    subscriptionErrors?: SubscriptionError[];
}
export interface GetOdbNetworkInput {
    odbNetworkId: string;
}
export interface OciDnsForwardingConfig {
    domainName?: string;
    ociDnsListenerIp?: string;
}
export type OciDnsForwardingConfigList = OciDnsForwardingConfig[];
export type VpcEndpointType = "SERVICENETWORK" | (string & {});
export interface ServiceNetworkEndpoint {
    vpcEndpointId?: string;
    vpcEndpointType?: VpcEndpointType;
}
export type ManagedResourceStatus = "ENABLED" | "ENABLING" | "DISABLED" | "DISABLING" | (string & {});
export interface ManagedS3BackupAccess {
    status?: ManagedResourceStatus;
    ipv4Addresses?: string[];
}
export interface ZeroEtlAccess {
    status?: ManagedResourceStatus;
    cidr?: string;
}
export interface S3Access {
    status?: ManagedResourceStatus;
    ipv4Addresses?: string[];
    domainName?: string;
    s3PolicyDocument?: string;
}
export interface StsAccess {
    status?: ManagedResourceStatus;
    ipv4Addresses?: string[];
    domainName?: string;
    stsPolicyDocument?: string;
}
export interface KmsAccess {
    status?: ManagedResourceStatus;
    ipv4Addresses?: string[];
    domainName?: string;
    kmsPolicyDocument?: string;
}
export interface CrossRegionS3RestoreSourcesAccess {
    region?: string;
    ipv4Addresses?: string[];
    status?: ManagedResourceStatus;
}
export type CrossRegionS3RestoreSourcesAccessList = CrossRegionS3RestoreSourcesAccess[];
export interface ManagedServices {
    serviceNetworkArn?: string;
    resourceGatewayArn?: string;
    managedServicesIpv4Cidrs?: string[];
    serviceNetworkEndpoint?: ServiceNetworkEndpoint;
    managedS3BackupAccess?: ManagedS3BackupAccess;
    zeroEtlAccess?: ZeroEtlAccess;
    s3Access?: S3Access;
    stsAccess?: StsAccess;
    kmsAccess?: KmsAccess;
    crossRegionS3RestoreSourcesAccess?: CrossRegionS3RestoreSourcesAccess[];
}
export interface OdbNetwork {
    odbNetworkId: string;
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    odbNetworkArn?: string;
    availabilityZone?: string;
    availabilityZoneId?: string;
    clientSubnetCidr?: string;
    backupSubnetCidr?: string;
    customDomainName?: string;
    defaultDnsPrefix?: string;
    peeredCidrs?: string[];
    ociNetworkAnchorId?: string;
    ociNetworkAnchorUrl?: string;
    ociResourceAnchorName?: string;
    ociVcnId?: string;
    ociVcnUrl?: string;
    ociDnsForwardingConfigs?: OciDnsForwardingConfig[];
    createdAt?: Date;
    percentProgress?: number;
    managedServices?: ManagedServices;
    ec2PlacementGroupIds?: string[];
}
export interface GetOdbNetworkOutput {
    odbNetwork?: OdbNetwork;
}
export interface GetOdbPeeringConnectionInput {
    odbPeeringConnectionId: string;
}
export interface OdbPeeringConnection {
    odbPeeringConnectionId: string;
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    odbPeeringConnectionArn?: string;
    odbNetworkArn?: string;
    peerNetworkArn?: string;
    odbPeeringConnectionType?: string;
    peerNetworkCidrs?: string[];
    createdAt?: Date;
    percentProgress?: number;
}
export interface GetOdbPeeringConnectionOutput {
    odbPeeringConnection?: OdbPeeringConnection;
}
export interface InitializeServiceInput {
    ociIdentityDomain?: boolean;
    autonomousDatabaseOciAwsSecretsManagerIntegration?: Access;
}
export interface InitializeServiceOutput {
}
export interface ListAutonomousDatabaseBackupsInput {
    maxResults?: number;
    nextToken?: string;
    autonomousDatabaseId: string;
    status?: AutonomousDatabaseBackupStatus;
    type?: AutonomousDatabaseBackupType;
}
export interface AutonomousDatabaseBackupSummary {
    autonomousDatabaseBackupId?: string;
    autonomousDatabaseBackupArn?: string;
    autonomousDatabaseId?: string;
    ocid?: string;
    displayName?: string;
    dbVersion?: string;
    status?: AutonomousDatabaseBackupStatus;
    statusReason?: string;
    isAutomatic?: boolean;
    retentionPeriodInDays?: number;
    sizeInTBs?: number;
    timeAvailableTill?: Date;
    timeStarted?: Date;
    timeEnded?: Date;
    type?: AutonomousDatabaseBackupType;
}
export type AutonomousDatabaseBackupList = AutonomousDatabaseBackupSummary[];
export interface ListAutonomousDatabaseBackupsOutput {
    nextToken?: string;
    autonomousDatabaseBackups: AutonomousDatabaseBackupSummary[];
}
export type CharacterSetType = "DATABASE" | "NATIONAL" | (string & {});
export interface ListAutonomousDatabaseCharacterSetsInput {
    maxResults?: number;
    nextToken?: string;
    characterSetType?: CharacterSetType;
}
export interface AutonomousDatabaseCharacterSetSummary {
    characterSet?: string;
}
export type AutonomousDatabaseCharacterSetList = AutonomousDatabaseCharacterSetSummary[];
export interface ListAutonomousDatabaseCharacterSetsOutput {
    nextToken?: string;
    autonomousDatabaseCharacterSets: AutonomousDatabaseCharacterSetSummary[];
}
export interface ListAutonomousDatabaseClonesInput {
    maxResults?: number;
    nextToken?: string;
    autonomousDatabaseId: string;
}
export interface AutonomousDatabaseSummary {
    autonomousDatabaseId?: string;
    autonomousDatabaseArn?: string;
    ociResourceAnchorName?: string;
    percentProgress?: number;
    ocid?: string;
    ociUrl?: string;
    displayName?: string;
    dbName?: string;
    sourceId?: string;
    status?: AutonomousDatabaseResourceStatus;
    statusReason?: string;
    databaseType?: DatabaseType;
    dbVersion?: string;
    dbWorkload?: DbWorkload;
    characterSet?: string;
    ncharacterSet?: string;
    databaseEdition?: DatabaseEdition;
    licenseModel?: LicenseModel;
    openMode?: OpenMode;
    permissionLevel?: PermissionLevel;
    isMtlsConnectionRequired?: boolean;
    autonomousMaintenanceScheduleType?: AutonomousMaintenanceScheduleType;
    netServicesArchitecture?: NetServicesArchitecture;
    availableUpgradeVersions?: string[];
    byolComputeCountLimit?: number;
    connectionStringDetails?: AutonomousDatabaseConnectionStrings;
    serviceConsoleUrl?: string;
    sqlWebDeveloperUrl?: string;
    customerContacts?: CustomerContact[];
    apexDetails?: AutonomousDatabaseApex;
    standbyDb?: DatabaseStandbySummary;
    localStandbyDb?: DatabaseStandbySummary;
    dataSafeStatus?: DataSafeStatus;
    databaseManagementStatus?: DatabaseManagementStatus;
    operationsInsightsStatus?: OperationsInsightsStatus;
    availabilityZone?: string;
    availabilityZoneId?: string;
    maintenanceTargetComponent?: string;
    connectionUrls?: AutonomousDatabaseConnectionUrls;
    dbToolsDetails?: DatabaseTool[];
    scheduledOperations?: ScheduledOperationDetails[];
    resourcePoolLeaderId?: string;
    computeCount?: number;
    computeModel?: ComputeModel;
    cpuCoreCount?: number;
    memoryPerOracleComputeUnitInGBs?: number;
    provisionableCpus?: number[];
    isAutoScalingEnabled?: boolean;
    dataStorageSizeInTBs?: number;
    dataStorageSizeInGBs?: number;
    usedDataStorageSizeInTBs?: number;
    usedDataStorageSizeInGBs?: number;
    actualUsedDataStorageSizeInTBs?: number;
    allocatedStorageSizeInTBs?: number;
    inMemoryAreaInGBs?: number;
    isAutoScalingForStorageEnabled?: boolean;
    odbNetworkId?: string;
    odbNetworkArn?: string;
    privateEndpoint?: string;
    privateEndpointIp?: string;
    privateEndpointLabel?: string;
    allowlistedIps?: string[];
    standbyAllowlistedIps?: string[];
    standbyAllowlistedIpsSource?: StandbyAllowlistedIpsSource;
    isLocalDataGuardEnabled?: boolean;
    isRemoteDataGuardEnabled?: boolean;
    localDisasterRecoveryType?: DisasterRecoveryType;
    role?: DataGuardRole;
    peerDbIds?: string[];
    failedDataRecoveryInSeconds?: number;
    localAdgAutoFailoverMaxDataLossLimit?: number;
    remoteDisasterRecoveryConfiguration?: DisasterRecoveryConfiguration;
    isRefreshableClone?: boolean;
    refreshableMode?: RefreshableMode;
    refreshableStatus?: RefreshableStatus;
    autoRefreshFrequencyInSeconds?: number;
    autoRefreshPointLagInSeconds?: number;
    isReconnectCloneEnabled?: boolean;
    cloneTableSpaceList?: number[];
    backupRetentionPeriodInDays?: number;
    longTermBackupSchedule?: LongTermBackupSchedule;
    isBackupRetentionLocked?: boolean;
    totalBackupStorageSizeInGBs?: number;
    resourcePoolSummary?: ResourcePoolSummary;
    encryptionSummary?: EncryptionSummary;
    createdAt?: Date;
    timeOfLastBackup?: Date;
    timeMaintenanceBegin?: Date;
    timeMaintenanceEnd?: Date;
    timeLocalDataGuardEnabled?: Date;
    timeDataGuardRoleChanged?: Date;
    timeOfLastSwitchover?: Date;
    timeOfLastFailover?: Date;
    timeOfLastRefresh?: Date;
    timeOfLastRefreshPoint?: Date;
    timeOfNextRefresh?: Date;
    timeOfAutoRefreshStart?: Date;
    timeDeletionOfFreeAutonomousDatabase?: Date;
    timeReclamationOfFreeAutonomousDatabase?: Date;
    timeDisasterRecoveryRoleChanged?: Date;
    timeUntilReconnectCloneEnabled?: Date;
    nextLongTermBackupTimeStamp?: Date;
    timeUndeleted?: Date;
    adminPasswordSourceSummary?: AdminPasswordSourceSummary;
}
export type AutonomousDatabaseList = AutonomousDatabaseSummary[];
export interface ListAutonomousDatabaseClonesOutput {
    nextToken?: string;
    autonomousDatabaseClones: AutonomousDatabaseSummary[];
}
export interface ListAutonomousDatabasePeersInput {
    maxResults?: number;
    nextToken?: string;
    autonomousDatabaseId: string;
}
export interface AutonomousDatabasePeerSummary {
    autonomousDatabaseId?: string;
    autonomousDatabaseArn?: string;
    ocid?: string;
    region?: string;
}
export type AutonomousDatabasePeerList = AutonomousDatabasePeerSummary[];
export interface ListAutonomousDatabasePeersOutput {
    nextToken?: string;
    autonomousDatabasePeers: AutonomousDatabasePeerSummary[];
}
export interface ListAutonomousDatabasesInput {
    maxResults?: number;
    nextToken?: string;
}
export interface ListAutonomousDatabasesOutput {
    nextToken?: string;
    autonomousDatabases: AutonomousDatabaseSummary[];
}
export interface ListAutonomousDatabaseVersionsInput {
    maxResults?: number;
    nextToken?: string;
    dbWorkload?: DbWorkload;
}
export interface AutonomousDatabaseVersionSummary {
    dbWorkload?: DbWorkload;
    details?: string;
    version?: string;
}
export type AutonomousDatabaseVersionList = AutonomousDatabaseVersionSummary[];
export interface ListAutonomousDatabaseVersionsOutput {
    nextToken?: string;
    autonomousDatabaseVersions: AutonomousDatabaseVersionSummary[];
}
export interface ListAutonomousVirtualMachinesInput {
    maxResults?: number;
    nextToken?: string;
    cloudAutonomousVmClusterId: string;
}
export interface AutonomousVirtualMachineSummary {
    autonomousVirtualMachineId?: string;
    status?: ResourceStatus;
    statusReason?: string;
    vmName?: string;
    dbServerId?: string;
    dbServerDisplayName?: string;
    cpuCoreCount?: number;
    memorySizeInGBs?: number;
    dbNodeStorageSizeInGBs?: number;
    clientIpAddress?: string;
    cloudAutonomousVmClusterId?: string;
    ocid?: string;
    ociResourceAnchorName?: string;
}
export type AutonomousVirtualMachineList = AutonomousVirtualMachineSummary[];
export interface ListAutonomousVirtualMachinesOutput {
    nextToken?: string;
    autonomousVirtualMachines: AutonomousVirtualMachineSummary[];
}
export interface ListCloudAutonomousVmClustersInput {
    maxResults?: number;
    nextToken?: string;
    cloudExadataInfrastructureId?: string;
}
export interface CloudAutonomousVmClusterSummary {
    cloudAutonomousVmClusterId: string;
    cloudAutonomousVmClusterArn?: string;
    odbNetworkId?: string;
    odbNetworkArn?: string;
    ociResourceAnchorName?: string;
    percentProgress?: number;
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    cloudExadataInfrastructureId?: string;
    cloudExadataInfrastructureArn?: string;
    autonomousDataStoragePercentage?: number;
    autonomousDataStorageSizeInTBs?: number;
    availableAutonomousDataStorageSizeInTBs?: number;
    availableContainerDatabases?: number;
    availableCpus?: number;
    computeModel?: ComputeModel;
    cpuCoreCount?: number;
    cpuCoreCountPerNode?: number;
    cpuPercentage?: number;
    dataStorageSizeInGBs?: number;
    dataStorageSizeInTBs?: number;
    dbNodeStorageSizeInGBs?: number;
    dbServers?: string[];
    description?: string;
    domain?: string;
    exadataStorageInTBsLowestScaledValue?: number;
    hostname?: string;
    ocid?: string;
    ociUrl?: string;
    isMtlsEnabledVmCluster?: boolean;
    licenseModel?: LicenseModel;
    maintenanceWindow?: MaintenanceWindow;
    maxAcdsLowestScaledValue?: number;
    memoryPerOracleComputeUnitInGBs?: number;
    memorySizeInGBs?: number;
    nodeCount?: number;
    nonProvisionableAutonomousContainerDatabases?: number;
    provisionableAutonomousContainerDatabases?: number;
    provisionedAutonomousContainerDatabases?: number;
    provisionedCpus?: number;
    reclaimableCpus?: number;
    reservedCpus?: number;
    scanListenerPortNonTls?: number;
    scanListenerPortTls?: number;
    shape?: string;
    createdAt?: Date;
    timeDatabaseSslCertificateExpires?: Date;
    timeOrdsCertificateExpires?: Date;
    timeZone?: string;
    totalContainerDatabases?: number;
    iamRoles?: IamRole[];
}
export type CloudAutonomousVmClusterList = CloudAutonomousVmClusterSummary[];
export interface ListCloudAutonomousVmClustersOutput {
    nextToken?: string;
    cloudAutonomousVmClusters: CloudAutonomousVmClusterSummary[];
}
export interface ListCloudExadataInfrastructuresInput {
    maxResults?: number;
    nextToken?: string;
}
export interface CloudExadataInfrastructureSummary {
    cloudExadataInfrastructureId: string;
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    cloudExadataInfrastructureArn?: string;
    activatedStorageCount?: number;
    additionalStorageCount?: number;
    availableStorageSizeInGBs?: number;
    availabilityZone?: string;
    availabilityZoneId?: string;
    computeCount?: number;
    cpuCount?: number;
    customerContactsToSendToOCI?: CustomerContact[];
    dataStorageSizeInTBs?: number;
    dbNodeStorageSizeInGBs?: number;
    dbServerVersion?: string;
    lastMaintenanceRunId?: string;
    maintenanceWindow?: MaintenanceWindow;
    maxCpuCount?: number;
    maxDataStorageInTBs?: number;
    maxDbNodeStorageSizeInGBs?: number;
    maxMemoryInGBs?: number;
    memorySizeInGBs?: number;
    monthlyDbServerVersion?: string;
    monthlyStorageServerVersion?: string;
    nextMaintenanceRunId?: string;
    ociResourceAnchorName?: string;
    ociUrl?: string;
    ocid?: string;
    shape?: string;
    storageCount?: number;
    storageServerVersion?: string;
    createdAt?: Date;
    totalStorageSizeInGBs?: number;
    percentProgress?: number;
    databaseServerType?: string;
    storageServerType?: string;
    computeModel?: ComputeModel;
}
export type CloudExadataInfrastructureList = CloudExadataInfrastructureSummary[];
export interface ListCloudExadataInfrastructuresOutput {
    nextToken?: string;
    cloudExadataInfrastructures: CloudExadataInfrastructureSummary[];
}
export interface ListCloudVmClustersInput {
    maxResults?: number;
    nextToken?: string;
    cloudExadataInfrastructureId?: string;
}
export interface CloudVmClusterSummary {
    cloudVmClusterId: string;
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    cloudVmClusterArn?: string;
    cloudExadataInfrastructureId?: string;
    cloudExadataInfrastructureArn?: string;
    clusterName?: string;
    cpuCoreCount?: number;
    dataCollectionOptions?: DataCollectionOptions;
    dataStorageSizeInTBs?: number;
    dbNodeStorageSizeInGBs?: number;
    dbServers?: string[];
    diskRedundancy?: DiskRedundancy;
    giVersion?: string;
    hostname?: string;
    iormConfigCache?: ExadataIormConfig;
    isLocalBackupEnabled?: boolean;
    isSparseDiskgroupEnabled?: boolean;
    lastUpdateHistoryEntryId?: string;
    licenseModel?: LicenseModel;
    listenerPort?: number;
    memorySizeInGBs?: number;
    nodeCount?: number;
    ocid?: string;
    ociResourceAnchorName?: string;
    ociUrl?: string;
    domain?: string;
    scanDnsName?: string;
    scanDnsRecordId?: string;
    scanIpIds?: string[];
    shape?: string;
    sshPublicKeys?: (string | redacted.Redacted<string>)[];
    storageSizeInGBs?: number;
    systemVersion?: string;
    createdAt?: Date;
    timeZone?: string;
    vipIds?: string[];
    odbNetworkId?: string;
    odbNetworkArn?: string;
    percentProgress?: number;
    computeModel?: ComputeModel;
    iamRoles?: IamRole[];
}
export type CloudVmClusterList = CloudVmClusterSummary[];
export interface ListCloudVmClustersOutput {
    nextToken?: string;
    cloudVmClusters: CloudVmClusterSummary[];
}
export interface ListDbNodesInput {
    maxResults?: number;
    nextToken?: string;
    cloudVmClusterId?: string;
    exadbVmClusterId?: string;
}
export interface DbNodeSummary {
    dbNodeId?: string;
    dbNodeArn?: string;
    status?: DbNodeResourceStatus;
    statusReason?: string;
    additionalDetails?: string;
    backupIpId?: string;
    backupVnic2Id?: string;
    backupVnicId?: string;
    cpuCoreCount?: number;
    dbNodeStorageSizeInGBs?: number;
    dbServerId?: string;
    dbSystemId?: string;
    faultDomain?: string;
    hostIpId?: string;
    hostname?: string;
    ocid?: string;
    ociResourceAnchorName?: string;
    maintenanceType?: DbNodeMaintenanceType;
    memorySizeInGBs?: number;
    softwareStorageSizeInGB?: number;
    createdAt?: Date;
    timeMaintenanceWindowEnd?: string;
    timeMaintenanceWindowStart?: string;
    totalCpuCoreCount?: number;
    vnic2Id?: string;
    vnicId?: string;
}
export type DbNodeList = DbNodeSummary[];
export interface ListDbNodesOutput {
    nextToken?: string;
    dbNodes: DbNodeSummary[];
}
export interface ListDbServersInput {
    cloudExadataInfrastructureId: string;
    maxResults?: number;
    nextToken?: string;
}
export interface DbServerSummary {
    dbServerId?: string;
    status?: ResourceStatus;
    statusReason?: string;
    cpuCoreCount?: number;
    dbNodeStorageSizeInGBs?: number;
    dbServerPatchingDetails?: DbServerPatchingDetails;
    displayName?: string;
    exadataInfrastructureId?: string;
    ocid?: string;
    ociResourceAnchorName?: string;
    maxCpuCount?: number;
    maxDbNodeStorageInGBs?: number;
    maxMemoryInGBs?: number;
    memorySizeInGBs?: number;
    shape?: string;
    createdAt?: Date;
    vmClusterIds?: string[];
    computeModel?: ComputeModel;
    autonomousVmClusterIds?: string[];
    autonomousVirtualMachineIds?: string[];
}
export type DbServerList = DbServerSummary[];
export interface ListDbServersOutput {
    nextToken?: string;
    dbServers: DbServerSummary[];
}
export interface ListDbSystemShapesInput {
    maxResults?: number;
    nextToken?: string;
    availabilityZone?: string;
    availabilityZoneId?: string;
    shapeFamily?: string;
}
export type ShapeType = "AMD" | "INTEL" | "INTEL_FLEX_X9" | "AMPERE_FLEX_A1" | (string & {});
export interface DbSystemShapeSummary {
    availableCoreCount?: number;
    availableCoreCountPerNode?: number;
    availableDataStorageInTBs?: number;
    availableDataStoragePerServerInTBs?: number;
    availableDbNodePerNodeInGBs?: number;
    availableDbNodeStorageInGBs?: number;
    availableMemoryInGBs?: number;
    availableMemoryPerNodeInGBs?: number;
    coreCountIncrement?: number;
    maxStorageCount?: number;
    maximumNodeCount?: number;
    minCoreCountPerNode?: number;
    minDataStorageInTBs?: number;
    minDbNodeStoragePerNodeInGBs?: number;
    minMemoryPerNodeInGBs?: number;
    minStorageCount?: number;
    minimumCoreCount?: number;
    minimumNodeCount?: number;
    runtimeMinimumCoreCount?: number;
    shapeFamily?: string;
    shapeType?: ShapeType;
    shapeAttributes?: ShapeAttribute[];
    name?: string;
    computeModel?: ComputeModel;
    areServerTypesSupported?: boolean;
}
export type DbSystemShapeList = DbSystemShapeSummary[];
export interface ListDbSystemShapesOutput {
    nextToken?: string;
    dbSystemShapes: DbSystemShapeSummary[];
}
export interface ListExadbVmClustersInput {
    exascaleDbStorageVaultId?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface ExadbVmClusterSummary {
    exadbVmClusterId: string;
    clusterName?: string;
    createdAt?: Date;
    dataCollectionOptions?: DataCollectionOptions;
    displayName?: string;
    domain?: string;
    enabledEcpuCount?: number;
    exadbVmClusterArn?: string;
    exascaleDbStorageVaultArn?: string;
    exascaleDbStorageVaultId?: string;
    giVersion?: string;
    gridImageId?: string;
    gridImageType?: GridImageType;
    hostname?: string;
    iamRoles?: IamRole[];
    iormConfigCache?: ExadataIormConfig;
    lastUpdateHistoryEntryId?: string;
    licenseModel?: LicenseModel;
    listenerPort?: number;
    memorySizeInGBs?: number;
    nodeCount?: number;
    ocid?: string;
    ociResourceAnchorName?: string;
    ociUrl?: string;
    odbNetworkArn?: string;
    odbNetworkId?: string;
    percentProgress?: number;
    scanDnsName?: string;
    scanDnsRecordId?: string;
    scanIpIds?: string[];
    scanListenerPortTcp?: number;
    scanListenerPortTcpSsl?: number;
    shape?: string;
    shapeAttribute?: ShapeAttribute;
    snapshotFileSystemStorage?: ExadbVmClusterStorageDetails;
    sshPublicKeys?: string[];
    status?: ResourceStatus;
    statusReason?: string;
    systemVersion?: string;
    timeZone?: string;
    totalEcpuCount?: number;
    totalFileSystemStorage?: ExadbVmClusterStorageDetails;
    vipIds?: string[];
    vmFileSystemStorage?: ExadbVmClusterStorageDetails;
}
export type ExadbVmClusterList = ExadbVmClusterSummary[];
export interface ListExadbVmClustersOutput {
    nextToken?: string;
    exadbVmClusters: ExadbVmClusterSummary[];
}
export interface ListExascaleDbStorageVaultsInput {
    maxResults?: number;
    nextToken?: string;
}
export interface ExascaleDbStorageVaultSummary {
    exascaleDbStorageVaultId: string;
    additionalFlashCacheInPercent?: number;
    attachedShapeAttributes?: ShapeAttribute[];
    autoscaleLimitInGBs?: number;
    availabilityZone?: string;
    availabilityZoneId?: string;
    createdAt?: Date;
    description?: string;
    displayName?: string;
    vmClusterArns?: string[];
    vmClusterCount?: number;
    vmClusterIds?: string[];
    exascaleDbStorageVaultArn?: string;
    highCapacityDatabaseStorage?: ExascaleDbStorageDetails;
    isAutoscaleEnabled?: boolean;
    ocid?: string;
    ociResourceAnchorName?: string;
    ociUrl?: string;
    percentProgress?: number;
    status?: ResourceStatus;
    statusReason?: string;
    timeZone?: string;
}
export type ExascaleDbStorageVaultList = ExascaleDbStorageVaultSummary[];
export interface ListExascaleDbStorageVaultsOutput {
    nextToken?: string;
    exascaleDbStorageVaults: ExascaleDbStorageVaultSummary[];
}
export interface ListFlexComponentsInput {
    maxResults?: number;
    nextToken?: string;
    shape?: string;
}
export type HardwareType = "COMPUTE" | "CELL" | (string & {});
export interface FlexComponentSummary {
    availableCoreCount?: number;
    availableDbStorageInGBs?: number;
    availableLocalStorageInGBs?: number;
    availableMemoryInGBs?: number;
    computeModel?: ComputeModel;
    descriptionSummary?: string;
    hardwareType?: HardwareType;
    minimumCoreCount?: number;
    name?: string;
    runtimeMinimumCoreCount?: number;
    shape?: string;
}
export type FlexComponentList = FlexComponentSummary[];
export interface ListFlexComponentsOutput {
    nextToken?: string;
    flexComponents: FlexComponentSummary[];
}
export interface ListGiMinorVersionsInput {
    giVersion: string;
    maxResults?: number;
    nextToken?: string;
    shapeFamily?: string;
    availabilityZone?: string;
    availabilityZoneId?: string;
}
export interface GiMinorVersionSummary {
    version: string;
    gridImageId?: string;
}
export type GiMinorVersionList = GiMinorVersionSummary[];
export interface ListGiMinorVersionsOutput {
    nextToken?: string;
    giMinorVersions: GiMinorVersionSummary[];
}
export interface ListGiVersionsInput {
    maxResults?: number;
    nextToken?: string;
    shape?: string;
}
export interface GiVersionSummary {
    version?: string;
}
export type GiVersionList = GiVersionSummary[];
export interface ListGiVersionsOutput {
    nextToken?: string;
    giVersions: GiVersionSummary[];
}
export interface ListOdbNetworksInput {
    maxResults?: number;
    nextToken?: string;
}
export interface OdbNetworkSummary {
    odbNetworkId: string;
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    odbNetworkArn?: string;
    availabilityZone?: string;
    availabilityZoneId?: string;
    clientSubnetCidr?: string;
    backupSubnetCidr?: string;
    customDomainName?: string;
    defaultDnsPrefix?: string;
    peeredCidrs?: string[];
    ociNetworkAnchorId?: string;
    ociNetworkAnchorUrl?: string;
    ociResourceAnchorName?: string;
    ociVcnId?: string;
    ociVcnUrl?: string;
    ociDnsForwardingConfigs?: OciDnsForwardingConfig[];
    createdAt?: Date;
    percentProgress?: number;
    managedServices?: ManagedServices;
    ec2PlacementGroupIds?: string[];
}
export type OdbNetworkList = OdbNetworkSummary[];
export interface ListOdbNetworksOutput {
    nextToken?: string;
    odbNetworks: OdbNetworkSummary[];
}
export interface ListOdbPeeringConnectionsInput {
    maxResults?: number;
    nextToken?: string;
    odbNetworkId?: string;
}
export interface OdbPeeringConnectionSummary {
    odbPeeringConnectionId: string;
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    odbPeeringConnectionArn?: string;
    odbNetworkArn?: string;
    peerNetworkArn?: string;
    odbPeeringConnectionType?: string;
    peerNetworkCidrs?: string[];
    createdAt?: Date;
    percentProgress?: number;
}
export type OdbPeeringConnectionList = OdbPeeringConnectionSummary[];
export interface ListOdbPeeringConnectionsOutput {
    nextToken?: string;
    odbPeeringConnections: OdbPeeringConnectionSummary[];
}
export interface ListSystemVersionsInput {
    maxResults?: number;
    nextToken?: string;
    giVersion: string;
    shape: string;
}
export interface SystemVersionSummary {
    giVersion?: string;
    shape?: string;
    systemVersions?: string[];
}
export type SystemVersionList = SystemVersionSummary[];
export interface ListSystemVersionsOutput {
    nextToken?: string;
    systemVersions: SystemVersionSummary[];
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export type ResponseTagMap = {
    [key: string]: string | undefined;
};
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface RebootAutonomousDatabaseInput {
    autonomousDatabaseId: string;
    isOnlineReboot?: boolean;
}
export interface RebootAutonomousDatabaseOutput {
    autonomousDatabaseId: string;
    displayName?: string;
    status?: AutonomousDatabaseResourceStatus;
    statusReason?: string;
}
export interface RebootDbNodeInput {
    cloudVmClusterId?: string;
    exadbVmClusterId?: string;
    dbNodeId: string;
}
export interface RebootDbNodeOutput {
    dbNodeId: string;
    status?: DbNodeResourceStatus;
    statusReason?: string;
}
export interface RestoreAutonomousDatabaseInput {
    autonomousDatabaseId: string;
    timestamp: Date;
}
export interface RestoreAutonomousDatabaseOutput {
    autonomousDatabaseId: string;
    displayName?: string;
    status?: AutonomousDatabaseResourceStatus;
    statusReason?: string;
}
export interface ShrinkAutonomousDatabaseInput {
    autonomousDatabaseId: string;
}
export interface ShrinkAutonomousDatabaseOutput {
    autonomousDatabaseId: string;
    displayName?: string;
    status?: AutonomousDatabaseResourceStatus;
    statusReason?: string;
}
export interface StartAutonomousDatabaseInput {
    autonomousDatabaseId: string;
}
export interface StartAutonomousDatabaseOutput {
    autonomousDatabaseId: string;
    displayName?: string;
    status?: AutonomousDatabaseResourceStatus;
    statusReason?: string;
}
export interface StartDbNodeInput {
    cloudVmClusterId?: string;
    exadbVmClusterId?: string;
    dbNodeId: string;
}
export interface StartDbNodeOutput {
    dbNodeId: string;
    status?: DbNodeResourceStatus;
    statusReason?: string;
}
export interface StopAutonomousDatabaseInput {
    autonomousDatabaseId: string;
}
export interface StopAutonomousDatabaseOutput {
    autonomousDatabaseId: string;
    displayName?: string;
    status?: AutonomousDatabaseResourceStatus;
    statusReason?: string;
}
export interface StopDbNodeInput {
    cloudVmClusterId?: string;
    exadbVmClusterId?: string;
    dbNodeId: string;
}
export interface StopDbNodeOutput {
    dbNodeId: string;
    status?: DbNodeResourceStatus;
    statusReason?: string;
}
export interface SwitchoverAutonomousDatabaseInput {
    autonomousDatabaseId: string;
    peerDbArn?: string;
}
export interface SwitchoverAutonomousDatabaseOutput {
    autonomousDatabaseId: string;
    displayName?: string;
    status?: AutonomousDatabaseResourceStatus;
    statusReason?: string;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAutonomousDatabaseInput {
    autonomousDatabaseId: string;
    adminPassword?: string | redacted.Redacted<string>;
    computeCount?: number;
    cpuCoreCount?: number;
    dataStorageSizeInTBs?: number;
    dataStorageSizeInGBs?: number;
    displayName?: string;
    dbName?: string;
    dbVersion?: string;
    dbWorkload?: DbWorkload;
    dbToolsDetails?: DatabaseTool[];
    databaseEdition?: DatabaseEdition;
    licenseModel?: LicenseModel;
    isAutoScalingEnabled?: boolean;
    isAutoScalingForStorageEnabled?: boolean;
    isBackupRetentionLocked?: boolean;
    isLocalDataGuardEnabled?: boolean;
    isMtlsConnectionRequired?: boolean;
    isRefreshableClone?: boolean;
    isDisconnectPeer?: boolean;
    backupRetentionPeriodInDays?: number;
    byolComputeCountLimit?: number;
    localAdgAutoFailoverMaxDataLossLimit?: number;
    autonomousMaintenanceScheduleType?: AutonomousMaintenanceScheduleType;
    customerContactsToSendToOCI?: CustomerContact[];
    scheduledOperations?: ScheduledOperationDetails[];
    longTermBackupSchedule?: LongTermBackupSchedule;
    openMode?: OpenMode;
    permissionLevel?: PermissionLevel;
    refreshableMode?: RefreshableMode;
    privateEndpointIp?: string;
    privateEndpointLabel?: string;
    peerDbId?: string;
    resourcePoolLeaderId?: string;
    resourcePoolSummary?: ResourcePoolSummary;
    standbyAllowlistedIpsSource?: StandbyAllowlistedIpsSource;
    standbyAllowlistedIps?: string[];
    allowlistedIps?: string[];
    autoRefreshFrequencyInSeconds?: number;
    autoRefreshPointLagInSeconds?: number;
    timeOfAutoRefreshStart?: Date;
    encryptionKeyProvider?: EncryptionKeyProviderInput;
    encryptionKeyConfiguration?: EncryptionKeyConfigurationInput;
    adminPasswordSource?: AdminPasswordSource;
    adminPasswordSourceConfiguration?: AdminPasswordSourceConfigurationInput;
}
export interface UpdateAutonomousDatabaseOutput {
    autonomousDatabaseId: string;
    displayName?: string;
    status?: AutonomousDatabaseResourceStatus;
    statusReason?: string;
}
export interface UpdateAutonomousDatabaseBackupInput {
    autonomousDatabaseBackupId: string;
    retentionPeriodInDays?: number;
}
export interface UpdateAutonomousDatabaseBackupOutput {
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    autonomousDatabaseBackupId: string;
}
export interface UpdateCloudExadataInfrastructureInput {
    cloudExadataInfrastructureId: string;
    maintenanceWindow?: MaintenanceWindow;
}
export interface UpdateCloudExadataInfrastructureOutput {
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    cloudExadataInfrastructureId: string;
}
export type UpdateAction = "ROLLING_APPLY" | "NON_ROLLING_APPLY" | "PRECHECK" | "ROLLBACK" | (string & {});
export interface UpdateExadbVmClusterInput {
    exadbVmClusterId: string;
    dataCollectionOptions?: DataCollectionOptions;
    displayName?: string;
    enabledEcpuCount?: number;
    gridImageId?: string;
    licenseModel?: LicenseModel;
    sshPublicKeys?: string[];
    systemVersion?: string;
    totalEcpuCount?: number;
    updateAction?: UpdateAction;
    vmFileSystemStorageTotalSizeInGBs?: number;
}
export interface UpdateExadbVmClusterOutput {
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    exadbVmClusterId: string;
}
export interface UpdateExascaleDbStorageVaultInput {
    exascaleDbStorageVaultId: string;
    additionalFlashCacheInPercent?: number;
    autoscaleLimitInGBs?: number;
    description?: string;
    displayName?: string;
    highCapacityDatabaseStorageTotalSizeInGBs?: number;
    isAutoscaleEnabled?: boolean;
}
export interface UpdateExascaleDbStorageVaultOutput {
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    exascaleDbStorageVaultId: string;
}
export interface UpdateOdbNetworkInput {
    odbNetworkId: string;
    displayName?: string;
    peeredCidrsToBeAdded?: string[];
    peeredCidrsToBeRemoved?: string[];
    s3Access?: Access;
    zeroEtlAccess?: Access;
    stsAccess?: Access;
    kmsAccess?: Access;
    s3PolicyDocument?: string;
    stsPolicyDocument?: string;
    kmsPolicyDocument?: string;
    crossRegionS3RestoreSourcesToEnable?: string[];
    crossRegionS3RestoreSourcesToDisable?: string[];
}
export interface UpdateOdbNetworkOutput {
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    odbNetworkId: string;
}
export interface UpdateOdbPeeringConnectionInput {
    odbPeeringConnectionId: string;
    displayName?: string;
    peerNetworkCidrsToBeAdded?: string[];
    peerNetworkCidrsToBeRemoved?: string[];
}
export interface UpdateOdbPeeringConnectionOutput {
    displayName?: string;
    status?: ResourceStatus;
    statusReason?: string;
    odbPeeringConnectionId: string;
}
export type ValidationExceptionReason = "unknownOperation" | "cannotParse" | "fieldValidationFailed" | "other" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AcceptMarketplaceRegistrationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Registers the Amazon Web Services Marketplace token for your Amazon Web Services account to activate your Oracle Database@Amazon Web Services subscription.
 */
export declare const acceptMarketplaceRegistration: API.OperationMethod<AcceptMarketplaceRegistrationInput, AcceptMarketplaceRegistrationOutput, AcceptMarketplaceRegistrationError, Credentials | HttpClient.HttpClient>;
export type AssociateIamRoleToResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates an Amazon Web Services Identity and Access Management (IAM) service role with a specified resource to enable Amazon Web Services service integration.
 */
export declare const associateIamRoleToResource: API.OperationMethod<AssociateIamRoleToResourceInput, AssociateIamRoleToResourceOutput, AssociateIamRoleToResourceError, Credentials | HttpClient.HttpClient>;
export type AssociateVirtualMachinesToExadbVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds virtual machines to the specified Exascale VM cluster.
 */
export declare const associateVirtualMachinesToExadbVmCluster: API.OperationMethod<AssociateVirtualMachinesToExadbVmClusterInput, AssociateVirtualMachinesToExadbVmClusterOutput, AssociateVirtualMachinesToExadbVmClusterError, Credentials | HttpClient.HttpClient>;
export type CreateAutonomousDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Autonomous Database.
 */
export declare const createAutonomousDatabase: API.OperationMethod<CreateAutonomousDatabaseInput, CreateAutonomousDatabaseOutput, CreateAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type CreateAutonomousDatabaseBackupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new backup of the specified Autonomous Database.
 */
export declare const createAutonomousDatabaseBackup: API.OperationMethod<CreateAutonomousDatabaseBackupInput, CreateAutonomousDatabaseBackupOutput, CreateAutonomousDatabaseBackupError, Credentials | HttpClient.HttpClient>;
export type CreateAutonomousDatabaseWalletError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new wallet for the specified Autonomous Database.
 */
export declare const createAutonomousDatabaseWallet: API.OperationMethod<CreateAutonomousDatabaseWalletInput, CreateAutonomousDatabaseWalletOutput, CreateAutonomousDatabaseWalletError, Credentials | HttpClient.HttpClient>;
export type CreateCloudAutonomousVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Autonomous VM cluster in the specified Exadata infrastructure.
 */
export declare const createCloudAutonomousVmCluster: API.OperationMethod<CreateCloudAutonomousVmClusterInput, CreateCloudAutonomousVmClusterOutput, CreateCloudAutonomousVmClusterError, Credentials | HttpClient.HttpClient>;
export type CreateCloudExadataInfrastructureError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Exadata infrastructure.
 */
export declare const createCloudExadataInfrastructure: API.OperationMethod<CreateCloudExadataInfrastructureInput, CreateCloudExadataInfrastructureOutput, CreateCloudExadataInfrastructureError, Credentials | HttpClient.HttpClient>;
export type CreateCloudVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a VM cluster on the specified Exadata infrastructure.
 */
export declare const createCloudVmCluster: API.OperationMethod<CreateCloudVmClusterInput, CreateCloudVmClusterOutput, CreateCloudVmClusterError, Credentials | HttpClient.HttpClient>;
export type CreateExadbVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Exascale VM cluster.
 */
export declare const createExadbVmCluster: API.OperationMethod<CreateExadbVmClusterInput, CreateExadbVmClusterOutput, CreateExadbVmClusterError, Credentials | HttpClient.HttpClient>;
export type CreateExascaleDbStorageVaultError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Exascale storage vault.
 */
export declare const createExascaleDbStorageVault: API.OperationMethod<CreateExascaleDbStorageVaultInput, CreateExascaleDbStorageVaultOutput, CreateExascaleDbStorageVaultError, Credentials | HttpClient.HttpClient>;
export type CreateOdbNetworkError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an ODB network.
 */
export declare const createOdbNetwork: API.OperationMethod<CreateOdbNetworkInput, CreateOdbNetworkOutput, CreateOdbNetworkError, Credentials | HttpClient.HttpClient>;
export type CreateOdbPeeringConnectionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a peering connection between an ODB network and a VPC.
 *
 * A peering connection enables private connectivity between the networks for application-tier communication.
 */
export declare const createOdbPeeringConnection: API.OperationMethod<CreateOdbPeeringConnectionInput, CreateOdbPeeringConnectionOutput, CreateOdbPeeringConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteAutonomousDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified Autonomous Database.
 */
export declare const deleteAutonomousDatabase: API.OperationMethod<DeleteAutonomousDatabaseInput, DeleteAutonomousDatabaseOutput, DeleteAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type DeleteAutonomousDatabaseBackupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified Autonomous Database backup.
 */
export declare const deleteAutonomousDatabaseBackup: API.OperationMethod<DeleteAutonomousDatabaseBackupInput, DeleteAutonomousDatabaseBackupOutput, DeleteAutonomousDatabaseBackupError, Credentials | HttpClient.HttpClient>;
export type DeleteCloudAutonomousVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an Autonomous VM cluster.
 */
export declare const deleteCloudAutonomousVmCluster: API.OperationMethod<DeleteCloudAutonomousVmClusterInput, DeleteCloudAutonomousVmClusterOutput, DeleteCloudAutonomousVmClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteCloudExadataInfrastructureError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified Exadata infrastructure. Before you use this operation, make sure to delete all of the VM clusters that are hosted on this Exadata infrastructure.
 */
export declare const deleteCloudExadataInfrastructure: API.OperationMethod<DeleteCloudExadataInfrastructureInput, DeleteCloudExadataInfrastructureOutput, DeleteCloudExadataInfrastructureError, Credentials | HttpClient.HttpClient>;
export type DeleteCloudVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the specified VM cluster.
 */
export declare const deleteCloudVmCluster: API.OperationMethod<DeleteCloudVmClusterInput, DeleteCloudVmClusterOutput, DeleteCloudVmClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteExadbVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified Exascale VM cluster.
 */
export declare const deleteExadbVmCluster: API.OperationMethod<DeleteExadbVmClusterInput, DeleteExadbVmClusterOutput, DeleteExadbVmClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteExascaleDbStorageVaultError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified Exascale storage vault.
 */
export declare const deleteExascaleDbStorageVault: API.OperationMethod<DeleteExascaleDbStorageVaultInput, DeleteExascaleDbStorageVaultOutput, DeleteExascaleDbStorageVaultError, Credentials | HttpClient.HttpClient>;
export type DeleteOdbNetworkError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified ODB network.
 */
export declare const deleteOdbNetwork: API.OperationMethod<DeleteOdbNetworkInput, DeleteOdbNetworkOutput, DeleteOdbNetworkError, Credentials | HttpClient.HttpClient>;
export type DeleteOdbPeeringConnectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an ODB peering connection.
 *
 * When you delete an ODB peering connection, the underlying VPC peering connection is also deleted.
 */
export declare const deleteOdbPeeringConnection: API.OperationMethod<DeleteOdbPeeringConnectionInput, DeleteOdbPeeringConnectionOutput, DeleteOdbPeeringConnectionError, Credentials | HttpClient.HttpClient>;
export type DisassociateIamRoleFromResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates an Amazon Web Services Identity and Access Management (IAM) service role from a specified resource to disable Amazon Web Services service integration.
 */
export declare const disassociateIamRoleFromResource: API.OperationMethod<DisassociateIamRoleFromResourceInput, DisassociateIamRoleFromResourceOutput, DisassociateIamRoleFromResourceError, Credentials | HttpClient.HttpClient>;
export type DisassociateVirtualMachinesFromExadbVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes virtual machines from the specified Exascale VM cluster.
 */
export declare const disassociateVirtualMachinesFromExadbVmCluster: API.OperationMethod<DisassociateVirtualMachinesFromExadbVmClusterInput, DisassociateVirtualMachinesFromExadbVmClusterOutput, DisassociateVirtualMachinesFromExadbVmClusterError, Credentials | HttpClient.HttpClient>;
export type FailoverAutonomousDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initiates a failover of the specified Autonomous Database to a standby peer database.
 */
export declare const failoverAutonomousDatabase: API.OperationMethod<FailoverAutonomousDatabaseInput, FailoverAutonomousDatabaseOutput, FailoverAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type GetAutonomousDatabaseError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a specific Autonomous Database.
 */
export declare const getAutonomousDatabase: API.OperationMethod<GetAutonomousDatabaseInput, GetAutonomousDatabaseOutput, GetAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type GetAutonomousDatabaseBackupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a specific Autonomous Database backup.
 */
export declare const getAutonomousDatabaseBackup: API.OperationMethod<GetAutonomousDatabaseBackupInput, GetAutonomousDatabaseBackupOutput, GetAutonomousDatabaseBackupError, Credentials | HttpClient.HttpClient>;
export type GetAutonomousDatabaseWalletDetailsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the wallet details for the specified Autonomous Database.
 */
export declare const getAutonomousDatabaseWalletDetails: API.OperationMethod<GetAutonomousDatabaseWalletDetailsInput, GetAutonomousDatabaseWalletDetailsOutput, GetAutonomousDatabaseWalletDetailsError, Credentials | HttpClient.HttpClient>;
export type GetCloudAutonomousVmClusterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a specific Autonomous VM cluster.
 */
export declare const getCloudAutonomousVmCluster: API.OperationMethod<GetCloudAutonomousVmClusterInput, GetCloudAutonomousVmClusterOutput, GetCloudAutonomousVmClusterError, Credentials | HttpClient.HttpClient>;
export type GetCloudExadataInfrastructureError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the specified Exadata infrastructure.
 */
export declare const getCloudExadataInfrastructure: API.OperationMethod<GetCloudExadataInfrastructureInput, GetCloudExadataInfrastructureOutput, GetCloudExadataInfrastructureError, Credentials | HttpClient.HttpClient>;
export type GetCloudExadataInfrastructureUnallocatedResourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about unallocated resources in a specified Cloud Exadata Infrastructure.
 */
export declare const getCloudExadataInfrastructureUnallocatedResources: API.OperationMethod<GetCloudExadataInfrastructureUnallocatedResourcesInput, GetCloudExadataInfrastructureUnallocatedResourcesOutput, GetCloudExadataInfrastructureUnallocatedResourcesError, Credentials | HttpClient.HttpClient>;
export type GetCloudVmClusterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the specified VM cluster.
 */
export declare const getCloudVmCluster: API.OperationMethod<GetCloudVmClusterInput, GetCloudVmClusterOutput, GetCloudVmClusterError, Credentials | HttpClient.HttpClient>;
export type GetDbNodeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the specified DB node.
 */
export declare const getDbNode: API.OperationMethod<GetDbNodeInput, GetDbNodeOutput, GetDbNodeError, Credentials | HttpClient.HttpClient>;
export type GetDbServerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the specified database server.
 */
export declare const getDbServer: API.OperationMethod<GetDbServerInput, GetDbServerOutput, GetDbServerError, Credentials | HttpClient.HttpClient>;
export type GetExadbVmClusterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the specified Exascale VM cluster.
 */
export declare const getExadbVmCluster: API.OperationMethod<GetExadbVmClusterInput, GetExadbVmClusterOutput, GetExadbVmClusterError, Credentials | HttpClient.HttpClient>;
export type GetExascaleDbStorageVaultError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the specified Exascale storage vault.
 */
export declare const getExascaleDbStorageVault: API.OperationMethod<GetExascaleDbStorageVaultInput, GetExascaleDbStorageVaultOutput, GetExascaleDbStorageVaultError, Credentials | HttpClient.HttpClient>;
export type GetOciOnboardingStatusError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the tenancy activation link and onboarding status for your Amazon Web Services account.
 */
export declare const getOciOnboardingStatus: API.OperationMethod<GetOciOnboardingStatusInput, GetOciOnboardingStatusOutput, GetOciOnboardingStatusError, Credentials | HttpClient.HttpClient>;
export type GetOdbNetworkError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the specified ODB network.
 */
export declare const getOdbNetwork: API.OperationMethod<GetOdbNetworkInput, GetOdbNetworkOutput, GetOdbNetworkError, Credentials | HttpClient.HttpClient>;
export type GetOdbPeeringConnectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an ODB peering connection.
 */
export declare const getOdbPeeringConnection: API.OperationMethod<GetOdbPeeringConnectionInput, GetOdbPeeringConnectionOutput, GetOdbPeeringConnectionError, Credentials | HttpClient.HttpClient>;
export type InitializeServiceError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initializes the ODB service for the first time in an account.
 */
export declare const initializeService: API.OperationMethod<InitializeServiceInput, InitializeServiceOutput, InitializeServiceError, Credentials | HttpClient.HttpClient>;
export type ListAutonomousDatabaseBackupsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the backups of the specified Autonomous Database.
 */
export declare const listAutonomousDatabaseBackups: API.PaginatedOperationMethod<ListAutonomousDatabaseBackupsInput, ListAutonomousDatabaseBackupsOutput, ListAutonomousDatabaseBackupsError, Credentials | HttpClient.HttpClient, AutonomousDatabaseBackupSummary>;
export type ListAutonomousDatabaseCharacterSetsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the available character sets for Autonomous Databases.
 */
export declare const listAutonomousDatabaseCharacterSets: API.PaginatedOperationMethod<ListAutonomousDatabaseCharacterSetsInput, ListAutonomousDatabaseCharacterSetsOutput, ListAutonomousDatabaseCharacterSetsError, Credentials | HttpClient.HttpClient, AutonomousDatabaseCharacterSetSummary>;
export type ListAutonomousDatabaseClonesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the clones of the specified Autonomous Database.
 */
export declare const listAutonomousDatabaseClones: API.PaginatedOperationMethod<ListAutonomousDatabaseClonesInput, ListAutonomousDatabaseClonesOutput, ListAutonomousDatabaseClonesError, Credentials | HttpClient.HttpClient, AutonomousDatabaseSummary>;
export type ListAutonomousDatabasePeersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the peer databases of the specified Autonomous Database.
 */
export declare const listAutonomousDatabasePeers: API.PaginatedOperationMethod<ListAutonomousDatabasePeersInput, ListAutonomousDatabasePeersOutput, ListAutonomousDatabasePeersError, Credentials | HttpClient.HttpClient, AutonomousDatabasePeerSummary>;
export type ListAutonomousDatabasesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the Autonomous Databases owned by your Amazon Web Services account in the current Amazon Web Services Region.
 */
export declare const listAutonomousDatabases: API.PaginatedOperationMethod<ListAutonomousDatabasesInput, ListAutonomousDatabasesOutput, ListAutonomousDatabasesError, Credentials | HttpClient.HttpClient, AutonomousDatabaseSummary>;
export type ListAutonomousDatabaseVersionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the available Oracle Database software versions for Autonomous Databases.
 */
export declare const listAutonomousDatabaseVersions: API.PaginatedOperationMethod<ListAutonomousDatabaseVersionsInput, ListAutonomousDatabaseVersionsOutput, ListAutonomousDatabaseVersionsError, Credentials | HttpClient.HttpClient, AutonomousDatabaseVersionSummary>;
export type ListAutonomousVirtualMachinesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all Autonomous VMs in an Autonomous VM cluster.
 */
export declare const listAutonomousVirtualMachines: API.PaginatedOperationMethod<ListAutonomousVirtualMachinesInput, ListAutonomousVirtualMachinesOutput, ListAutonomousVirtualMachinesError, Credentials | HttpClient.HttpClient, AutonomousVirtualMachineSummary>;
export type ListCloudAutonomousVmClustersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all Autonomous VM clusters in a specified Cloud Exadata infrastructure.
 */
export declare const listCloudAutonomousVmClusters: API.PaginatedOperationMethod<ListCloudAutonomousVmClustersInput, ListCloudAutonomousVmClustersOutput, ListCloudAutonomousVmClustersError, Credentials | HttpClient.HttpClient, CloudAutonomousVmClusterSummary>;
export type ListCloudExadataInfrastructuresError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the Exadata infrastructures owned by your Amazon Web Services account.
 */
export declare const listCloudExadataInfrastructures: API.PaginatedOperationMethod<ListCloudExadataInfrastructuresInput, ListCloudExadataInfrastructuresOutput, ListCloudExadataInfrastructuresError, Credentials | HttpClient.HttpClient, CloudExadataInfrastructureSummary>;
export type ListCloudVmClustersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the VM clusters owned by your Amazon Web Services account or only the ones on the specified Exadata infrastructure.
 */
export declare const listCloudVmClusters: API.PaginatedOperationMethod<ListCloudVmClustersInput, ListCloudVmClustersOutput, ListCloudVmClustersError, Credentials | HttpClient.HttpClient, CloudVmClusterSummary>;
export type ListDbNodesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the DB nodes for the specified VM cluster.
 */
export declare const listDbNodes: API.PaginatedOperationMethod<ListDbNodesInput, ListDbNodesOutput, ListDbNodesError, Credentials | HttpClient.HttpClient, DbNodeSummary>;
export type ListDbServersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the database servers that belong to the specified Exadata infrastructure.
 */
export declare const listDbServers: API.PaginatedOperationMethod<ListDbServersInput, ListDbServersOutput, ListDbServersError, Credentials | HttpClient.HttpClient, DbServerSummary>;
export type ListDbSystemShapesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the shapes that are available for an Exadata infrastructure.
 */
export declare const listDbSystemShapes: API.PaginatedOperationMethod<ListDbSystemShapesInput, ListDbSystemShapesOutput, ListDbSystemShapesError, Credentials | HttpClient.HttpClient, DbSystemShapeSummary>;
export type ListExadbVmClustersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the Exascale VM clusters owned by your Amazon Web Services account.
 */
export declare const listExadbVmClusters: API.PaginatedOperationMethod<ListExadbVmClustersInput, ListExadbVmClustersOutput, ListExadbVmClustersError, Credentials | HttpClient.HttpClient, ExadbVmClusterSummary>;
export type ListExascaleDbStorageVaultsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the Exascale storage vaults owned by your Amazon Web Services account.
 */
export declare const listExascaleDbStorageVaults: API.PaginatedOperationMethod<ListExascaleDbStorageVaultsInput, ListExascaleDbStorageVaultsOutput, ListExascaleDbStorageVaultsError, Credentials | HttpClient.HttpClient, ExascaleDbStorageVaultSummary>;
export type ListFlexComponentsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the flex components that are available for an Exadata infrastructure.
 */
export declare const listFlexComponents: API.PaginatedOperationMethod<ListFlexComponentsInput, ListFlexComponentsOutput, ListFlexComponentsError, Credentials | HttpClient.HttpClient, FlexComponentSummary>;
export type ListGiMinorVersionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the Oracle Grid Infrastructure (GI) minor versions for the specified major version.
 */
export declare const listGiMinorVersions: API.PaginatedOperationMethod<ListGiMinorVersionsInput, ListGiMinorVersionsOutput, ListGiMinorVersionsError, Credentials | HttpClient.HttpClient, GiMinorVersionSummary>;
export type ListGiVersionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about Oracle Grid Infrastructure (GI) software versions that are available for a VM cluster for the specified shape.
 */
export declare const listGiVersions: API.PaginatedOperationMethod<ListGiVersionsInput, ListGiVersionsOutput, ListGiVersionsError, Credentials | HttpClient.HttpClient, GiVersionSummary>;
export type ListOdbNetworksError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the ODB networks owned by your Amazon Web Services account.
 */
export declare const listOdbNetworks: API.PaginatedOperationMethod<ListOdbNetworksInput, ListOdbNetworksOutput, ListOdbNetworksError, Credentials | HttpClient.HttpClient, OdbNetworkSummary>;
export type ListOdbPeeringConnectionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all ODB peering connections or those associated with a specific ODB network.
 */
export declare const listOdbPeeringConnections: API.PaginatedOperationMethod<ListOdbPeeringConnectionsInput, ListOdbPeeringConnectionsOutput, ListOdbPeeringConnectionsError, Credentials | HttpClient.HttpClient, OdbPeeringConnectionSummary>;
export type ListSystemVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the system versions that are available for a VM cluster for the specified `giVersion` and `shape`.
 */
export declare const listSystemVersions: API.PaginatedOperationMethod<ListSystemVersionsInput, ListSystemVersionsOutput, ListSystemVersionsError, Credentials | HttpClient.HttpClient, SystemVersionSummary>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Returns information about the tags applied to this resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RebootAutonomousDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Reboots the specified Autonomous Database.
 */
export declare const rebootAutonomousDatabase: API.OperationMethod<RebootAutonomousDatabaseInput, RebootAutonomousDatabaseOutput, RebootAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type RebootDbNodeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Reboots the specified DB node in a VM cluster.
 */
export declare const rebootDbNode: API.OperationMethod<RebootDbNodeInput, RebootDbNodeOutput, RebootDbNodeError, Credentials | HttpClient.HttpClient>;
export type RestoreAutonomousDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Restores the specified Autonomous Database to a point in time.
 */
export declare const restoreAutonomousDatabase: API.OperationMethod<RestoreAutonomousDatabaseInput, RestoreAutonomousDatabaseOutput, RestoreAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type ShrinkAutonomousDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Shrinks the storage of the specified Autonomous Database to reclaim unused space.
 */
export declare const shrinkAutonomousDatabase: API.OperationMethod<ShrinkAutonomousDatabaseInput, ShrinkAutonomousDatabaseOutput, ShrinkAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type StartAutonomousDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the specified Autonomous Database.
 */
export declare const startAutonomousDatabase: API.OperationMethod<StartAutonomousDatabaseInput, StartAutonomousDatabaseOutput, StartAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type StartDbNodeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the specified DB node in a VM cluster.
 */
export declare const startDbNode: API.OperationMethod<StartDbNodeInput, StartDbNodeOutput, StartDbNodeError, Credentials | HttpClient.HttpClient>;
export type StopAutonomousDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops the specified Autonomous Database.
 */
export declare const stopAutonomousDatabase: API.OperationMethod<StopAutonomousDatabaseInput, StopAutonomousDatabaseOutput, StopAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type StopDbNodeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops the specified DB node in a VM cluster.
 */
export declare const stopDbNode: API.OperationMethod<StopDbNodeInput, StopDbNodeOutput, StopDbNodeError, Credentials | HttpClient.HttpClient>;
export type SwitchoverAutonomousDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Performs a switchover of the specified Autonomous Database to a standby peer database.
 */
export declare const switchoverAutonomousDatabase: API.OperationMethod<SwitchoverAutonomousDatabaseInput, SwitchoverAutonomousDatabaseOutput, SwitchoverAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Applies tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Removes tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAutonomousDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the properties of an Autonomous Database.
 */
export declare const updateAutonomousDatabase: API.OperationMethod<UpdateAutonomousDatabaseInput, UpdateAutonomousDatabaseOutput, UpdateAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type UpdateAutonomousDatabaseBackupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the properties of an Autonomous Database backup.
 */
export declare const updateAutonomousDatabaseBackup: API.OperationMethod<UpdateAutonomousDatabaseBackupInput, UpdateAutonomousDatabaseBackupOutput, UpdateAutonomousDatabaseBackupError, Credentials | HttpClient.HttpClient>;
export type UpdateCloudExadataInfrastructureError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the properties of an Exadata infrastructure resource.
 */
export declare const updateCloudExadataInfrastructure: API.OperationMethod<UpdateCloudExadataInfrastructureInput, UpdateCloudExadataInfrastructureOutput, UpdateCloudExadataInfrastructureError, Credentials | HttpClient.HttpClient>;
export type UpdateExadbVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified Exascale VM cluster.
 */
export declare const updateExadbVmCluster: API.OperationMethod<UpdateExadbVmClusterInput, UpdateExadbVmClusterOutput, UpdateExadbVmClusterError, Credentials | HttpClient.HttpClient>;
export type UpdateExascaleDbStorageVaultError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified Exascale storage vault.
 */
export declare const updateExascaleDbStorageVault: API.OperationMethod<UpdateExascaleDbStorageVaultInput, UpdateExascaleDbStorageVaultOutput, UpdateExascaleDbStorageVaultError, Credentials | HttpClient.HttpClient>;
export type UpdateOdbNetworkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates properties of a specified ODB network.
 */
export declare const updateOdbNetwork: API.OperationMethod<UpdateOdbNetworkInput, UpdateOdbNetworkOutput, UpdateOdbNetworkError, Credentials | HttpClient.HttpClient>;
export type UpdateOdbPeeringConnectionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies the settings of an Oracle Database@Amazon Web Services peering connection. You can update the display name and add or remove CIDR blocks from the peering connection.
 */
export declare const updateOdbPeeringConnection: API.OperationMethod<UpdateOdbPeeringConnectionInput, UpdateOdbPeeringConnectionOutput, UpdateOdbPeeringConnectionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=odb.d.ts.map