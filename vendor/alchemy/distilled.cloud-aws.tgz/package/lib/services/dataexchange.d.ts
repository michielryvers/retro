import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceLimitExceededException_base: S.TaggedErrorClass<"ServiceLimitExceededException", {
    readonly LimitName: any;
    readonly LimitValue: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceLimitExceededException extends /*@__PURE__*/ ServiceLimitExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly ExceptionCause: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DataGrantArn = string;
export interface AcceptDataGrantRequest {
    DataGrantArn: string;
}
export type DataGrantName = string;
export type SenderPrincipal = string;
export type ReceiverPrincipal = string;
export type DataGrantDescription = string;
export type DataGrantAcceptanceState = string;
export type GrantDistributionScope = string;
export type Id = string;
export type Arn = string;
export interface AcceptDataGrantResponse {
    Name: string;
    SenderPrincipal?: string;
    ReceiverPrincipal: string;
    Description?: string;
    AcceptanceState: string;
    AcceptedAt?: Date;
    EndsAt?: Date;
    GrantDistributionScope: string;
    DataSetId: string;
    Id: string;
    Arn: string;
    CreatedAt: Date;
    UpdatedAt: Date;
}
export interface CancelJobRequest {
    JobId: string;
}
export interface CancelJobResponse {
}
export type Description = string;
export type MapOf__string = {
    [key: string]: string | undefined;
};
export interface CreateDataGrantRequest {
    Name: string;
    GrantDistributionScope: string;
    ReceiverPrincipal: string;
    SourceDataSetId: string;
    EndsAt?: Date;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateDataGrantResponse {
    Name: string;
    SenderPrincipal: string;
    ReceiverPrincipal: string;
    Description?: string;
    AcceptanceState: string;
    AcceptedAt?: Date;
    EndsAt?: Date;
    GrantDistributionScope: string;
    DataSetId: string;
    SourceDataSetId: string;
    Id: string;
    Arn: string;
    CreatedAt: Date;
    UpdatedAt: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type AssetType = string;
export type Name = string;
export interface CreateDataSetRequest {
    AssetType: string;
    Description: string;
    Name: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type Origin = string;
export interface OriginDetails {
    ProductId?: string;
    DataGrantId?: string;
}
export interface CreateDataSetResponse {
    Arn?: string;
    AssetType?: string;
    CreatedAt?: Date;
    Description?: string;
    Id?: string;
    Name?: string;
    Origin?: string;
    OriginDetails?: OriginDetails;
    SourceId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    UpdatedAt?: Date;
}
export type ServerSideEncryptionTypes = string;
export interface ExportServerSideEncryption {
    KmsKeyArn?: string;
    Type: string;
}
export interface AutoExportRevisionDestinationEntry {
    Bucket: string;
    KeyPattern?: string;
}
export interface AutoExportRevisionToS3RequestDetails {
    Encryption?: ExportServerSideEncryption;
    RevisionDestination: AutoExportRevisionDestinationEntry;
}
export interface Action {
    ExportRevisionToS3?: AutoExportRevisionToS3RequestDetails;
}
export interface RevisionPublished {
    DataSetId: string;
}
export interface Event {
    RevisionPublished?: RevisionPublished;
}
export interface CreateEventActionRequest {
    Action: Action;
    Event: Event;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateEventActionResponse {
    Action?: Action;
    Arn?: string;
    CreatedAt?: Date;
    Event?: Event;
    Id?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    UpdatedAt?: Date;
}
export interface Tag {
    Key: string;
    Value: string;
}
export type ListOfTag = Tag[];
export interface AssetConfiguration {
    Tags?: Tag[];
}
export interface ExportAssetToSignedUrlRequestDetails {
    AssetId: string;
    DataSetId: string;
    RevisionId: string;
}
export interface AssetDestinationEntry {
    AssetId: string;
    Bucket: string;
    Key?: string;
}
export type ListOfAssetDestinationEntry = AssetDestinationEntry[];
export interface ExportAssetsToS3RequestDetails {
    AssetDestinations: AssetDestinationEntry[];
    DataSetId: string;
    Encryption?: ExportServerSideEncryption;
    RevisionId: string;
}
export interface RevisionDestinationEntry {
    Bucket: string;
    KeyPattern?: string;
    RevisionId: string;
}
export type ListOfRevisionDestinationEntry = RevisionDestinationEntry[];
export interface ExportRevisionsToS3RequestDetails {
    DataSetId: string;
    Encryption?: ExportServerSideEncryption;
    RevisionDestinations: RevisionDestinationEntry[];
}
export type AssetName = string;
export type __stringMin24Max24PatternAZaZ094AZaZ092AZaZ093 = string;
export interface ImportAssetFromSignedUrlRequestDetails {
    AssetName: string;
    DataSetId: string;
    Md5Hash: string;
    RevisionId: string;
}
export interface AssetSourceEntry {
    Bucket: string;
    Key: string;
}
export type ListOfAssetSourceEntry = AssetSourceEntry[];
export interface ImportAssetsFromS3RequestDetails {
    AssetSources: AssetSourceEntry[];
    DataSetId: string;
    RevisionId: string;
}
export interface RedshiftDataShareAssetSourceEntry {
    DataShareArn: string;
}
export type ListOfRedshiftDataShareAssetSourceEntry = RedshiftDataShareAssetSourceEntry[];
export interface ImportAssetsFromRedshiftDataSharesRequestDetails {
    AssetSources: RedshiftDataShareAssetSourceEntry[];
    DataSetId: string;
    RevisionId: string;
}
export type ApiDescription = string;
export type ProtocolType = string;
export interface ImportAssetFromApiGatewayApiRequestDetails {
    ApiDescription?: string;
    ApiId: string;
    ApiKey?: string | redacted.Redacted<string>;
    ApiName: string;
    ApiSpecificationMd5Hash: string;
    DataSetId: string;
    ProtocolType: string;
    RevisionId: string;
    Stage: string;
}
export type ListOf__string = string[];
export type KmsKeyArn = string;
export interface KmsKeyToGrant {
    KmsKeyArn: string;
}
export type ListOfKmsKeysToGrant = KmsKeyToGrant[];
export interface S3DataAccessAssetSourceEntry {
    Bucket: string;
    KeyPrefixes?: string[];
    Keys?: string[];
    KmsKeysToGrant?: KmsKeyToGrant[];
}
export interface CreateS3DataAccessFromS3BucketRequestDetails {
    AssetSource: S3DataAccessAssetSourceEntry;
    DataSetId: string;
    RevisionId: string;
}
export type AwsAccountId = string;
export type ListOfLFTagValues = string[];
export interface LFTag {
    TagKey: string;
    TagValues: string[];
}
export type ListOfLFTags = LFTag[];
export type DatabaseLFTagPolicyPermission = string;
export type ListOfDatabaseLFTagPolicyPermissions = string[];
export interface DatabaseLFTagPolicyAndPermissions {
    Expression: LFTag[];
    Permissions: string[];
}
export type TableTagPolicyLFPermission = string;
export type ListOfTableTagPolicyLFPermissions = string[];
export interface TableLFTagPolicyAndPermissions {
    Expression: LFTag[];
    Permissions: string[];
}
export type RoleArn = string;
export interface ImportAssetsFromLakeFormationTagPolicyRequestDetails {
    CatalogId: string;
    Database?: DatabaseLFTagPolicyAndPermissions;
    Table?: TableLFTagPolicyAndPermissions;
    RoleArn: string;
    DataSetId: string;
    RevisionId: string;
}
export interface RequestDetails {
    ExportAssetToSignedUrl?: ExportAssetToSignedUrlRequestDetails;
    ExportAssetsToS3?: ExportAssetsToS3RequestDetails;
    ExportRevisionsToS3?: ExportRevisionsToS3RequestDetails;
    ImportAssetFromSignedUrl?: ImportAssetFromSignedUrlRequestDetails;
    ImportAssetsFromS3?: ImportAssetsFromS3RequestDetails;
    ImportAssetsFromRedshiftDataShares?: ImportAssetsFromRedshiftDataSharesRequestDetails;
    ImportAssetFromApiGatewayApi?: ImportAssetFromApiGatewayApiRequestDetails;
    CreateS3DataAccessFromS3Bucket?: CreateS3DataAccessFromS3BucketRequestDetails;
    ImportAssetsFromLakeFormationTagPolicy?: ImportAssetsFromLakeFormationTagPolicyRequestDetails;
}
export type Type = string;
export interface CreateJobRequest {
    AssetConfiguration?: AssetConfiguration;
    Details: RequestDetails;
    Type: string;
}
export interface ExportAssetToSignedUrlResponseDetails {
    AssetId: string;
    DataSetId: string;
    RevisionId: string;
    SignedUrl?: string;
    SignedUrlExpiresAt?: Date;
}
export interface ExportAssetsToS3ResponseDetails {
    AssetDestinations: AssetDestinationEntry[];
    DataSetId: string;
    Encryption?: ExportServerSideEncryption;
    RevisionId: string;
}
export interface ExportRevisionsToS3ResponseDetails {
    DataSetId: string;
    Encryption?: ExportServerSideEncryption;
    RevisionDestinations: RevisionDestinationEntry[];
    EventActionArn?: string;
}
export interface ImportAssetFromSignedUrlResponseDetails {
    AssetName: string;
    DataSetId: string;
    Md5Hash?: string;
    RevisionId: string;
    SignedUrl?: string;
    SignedUrlExpiresAt?: Date;
}
export interface ImportAssetsFromS3ResponseDetails {
    AssetSources: AssetSourceEntry[];
    DataSetId: string;
    RevisionId: string;
}
export interface ImportAssetsFromRedshiftDataSharesResponseDetails {
    AssetSources: RedshiftDataShareAssetSourceEntry[];
    DataSetId: string;
    RevisionId: string;
}
export interface ImportAssetFromApiGatewayApiResponseDetails {
    ApiDescription?: string;
    ApiId: string;
    ApiKey?: string | redacted.Redacted<string>;
    ApiName: string;
    ApiSpecificationMd5Hash: string;
    ApiSpecificationUploadUrl: string;
    ApiSpecificationUploadUrlExpiresAt: Date;
    DataSetId: string;
    ProtocolType: string;
    RevisionId: string;
    Stage: string;
}
export interface CreateS3DataAccessFromS3BucketResponseDetails {
    AssetSource: S3DataAccessAssetSourceEntry;
    DataSetId: string;
    RevisionId: string;
}
export interface ImportAssetsFromLakeFormationTagPolicyResponseDetails {
    CatalogId: string;
    Database?: DatabaseLFTagPolicyAndPermissions;
    Table?: TableLFTagPolicyAndPermissions;
    RoleArn: string;
    DataSetId: string;
    RevisionId: string;
}
export interface ResponseDetails {
    ExportAssetToSignedUrl?: ExportAssetToSignedUrlResponseDetails;
    ExportAssetsToS3?: ExportAssetsToS3ResponseDetails;
    ExportRevisionsToS3?: ExportRevisionsToS3ResponseDetails;
    ImportAssetFromSignedUrl?: ImportAssetFromSignedUrlResponseDetails;
    ImportAssetsFromS3?: ImportAssetsFromS3ResponseDetails;
    ImportAssetsFromRedshiftDataShares?: ImportAssetsFromRedshiftDataSharesResponseDetails;
    ImportAssetFromApiGatewayApi?: ImportAssetFromApiGatewayApiResponseDetails;
    CreateS3DataAccessFromS3Bucket?: CreateS3DataAccessFromS3BucketResponseDetails;
    ImportAssetsFromLakeFormationTagPolicy?: ImportAssetsFromLakeFormationTagPolicyResponseDetails;
}
export type Code = string;
export interface ImportAssetFromSignedUrlJobErrorDetails {
    AssetName: string;
}
export interface Details {
    ImportAssetFromSignedUrlJobErrorDetails?: ImportAssetFromSignedUrlJobErrorDetails;
    ImportAssetsFromS3JobErrorDetails?: AssetSourceEntry[];
}
export type JobErrorLimitName = string;
export type JobErrorResourceTypes = string;
export interface JobError {
    Code: string;
    Details?: Details;
    LimitName?: string;
    LimitValue?: number;
    Message: string;
    ResourceId?: string;
    ResourceType?: string;
}
export type ListOfJobError = JobError[];
export type State = string;
export interface CreateJobResponse {
    Arn?: string;
    AssetConfiguration?: AssetConfiguration;
    CreatedAt?: Date;
    Details?: ResponseDetails;
    Errors?: JobError[];
    Id?: string;
    State?: string;
    Type?: string;
    UpdatedAt?: Date;
}
export type __stringMin0Max16384 = string;
export interface CreateRevisionRequest {
    Comment?: string;
    DataSetId: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __stringMin10Max512 = string;
export interface CreateRevisionResponse {
    Arn?: string;
    Comment?: string;
    CreatedAt?: Date;
    DataSetId?: string;
    Finalized?: boolean;
    Id?: string;
    SourceId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    UpdatedAt?: Date;
    RevocationComment?: string;
    Revoked?: boolean;
    RevokedAt?: Date;
}
export interface DeleteAssetRequest {
    AssetId: string;
    DataSetId: string;
    RevisionId: string;
}
export interface DeleteAssetResponse {
}
export type DataGrantId = string;
export interface DeleteDataGrantRequest {
    DataGrantId: string;
}
export interface DeleteDataGrantResponse {
}
export interface DeleteDataSetRequest {
    DataSetId: string;
}
export interface DeleteDataSetResponse {
}
export interface DeleteEventActionRequest {
    EventActionId: string;
}
export interface DeleteEventActionResponse {
}
export interface DeleteRevisionRequest {
    DataSetId: string;
    RevisionId: string;
}
export interface DeleteRevisionResponse {
}
export interface GetAssetRequest {
    AssetId: string;
    DataSetId: string;
    RevisionId: string;
}
export type __doubleMin0 = number;
export interface S3SnapshotAsset {
    Size: number;
}
export interface RedshiftDataShareAsset {
    Arn: string;
}
export interface ApiGatewayApiAsset {
    ApiDescription?: string;
    ApiEndpoint?: string;
    ApiId?: string;
    ApiKey?: string | redacted.Redacted<string>;
    ApiName?: string;
    ApiSpecificationDownloadUrl?: string;
    ApiSpecificationDownloadUrlExpiresAt?: Date;
    ProtocolType?: string;
    Stage?: string;
}
export interface S3DataAccessAsset {
    Bucket: string;
    KeyPrefixes?: string[];
    Keys?: string[];
    S3AccessPointAlias?: string;
    S3AccessPointArn?: string;
    KmsKeysToGrant?: KmsKeyToGrant[];
}
export type LFResourceType = string;
export interface DatabaseLFTagPolicy {
    Expression: LFTag[];
}
export interface TableLFTagPolicy {
    Expression: LFTag[];
}
export interface LFResourceDetails {
    Database?: DatabaseLFTagPolicy;
    Table?: TableLFTagPolicy;
}
export interface LFTagPolicyDetails {
    CatalogId: string;
    ResourceType: string;
    ResourceDetails: LFResourceDetails;
}
export interface LakeFormationDataPermissionDetails {
    LFTagPolicy?: LFTagPolicyDetails;
}
export type LakeFormationDataPermissionType = string;
export type LFPermission = string;
export type ListOfLFPermissions = string[];
export interface LakeFormationDataPermissionAsset {
    LakeFormationDataPermissionDetails: LakeFormationDataPermissionDetails;
    LakeFormationDataPermissionType: string;
    Permissions: string[];
    RoleArn?: string;
}
export interface AssetDetails {
    S3SnapshotAsset?: S3SnapshotAsset;
    RedshiftDataShareAsset?: RedshiftDataShareAsset;
    ApiGatewayApiAsset?: ApiGatewayApiAsset;
    S3DataAccessAsset?: S3DataAccessAsset;
    LakeFormationDataPermissionAsset?: LakeFormationDataPermissionAsset;
}
export interface GetAssetResponse {
    Arn?: string;
    AssetDetails?: AssetDetails;
    AssetType?: string;
    CreatedAt?: Date;
    DataSetId?: string;
    Id?: string;
    Name?: string;
    RevisionId?: string;
    SourceId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    UpdatedAt?: Date;
}
export interface GetDataGrantRequest {
    DataGrantId: string;
}
export interface GetDataGrantResponse {
    Name: string;
    SenderPrincipal: string;
    ReceiverPrincipal: string;
    Description?: string;
    AcceptanceState: string;
    AcceptedAt?: Date;
    EndsAt?: Date;
    GrantDistributionScope: string;
    DataSetId: string;
    SourceDataSetId: string;
    Id: string;
    Arn: string;
    CreatedAt: Date;
    UpdatedAt: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetDataSetRequest {
    DataSetId: string;
}
export interface GetDataSetResponse {
    Arn?: string;
    AssetType?: string;
    CreatedAt?: Date;
    Description?: string;
    Id?: string;
    Name?: string;
    Origin?: string;
    OriginDetails?: OriginDetails;
    SourceId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    UpdatedAt?: Date;
}
export interface GetEventActionRequest {
    EventActionId: string;
}
export interface GetEventActionResponse {
    Action?: Action;
    Arn?: string;
    CreatedAt?: Date;
    Event?: Event;
    Id?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    UpdatedAt?: Date;
}
export interface GetJobRequest {
    JobId: string;
}
export interface GetJobResponse {
    Arn?: string;
    AssetConfiguration?: AssetConfiguration;
    CreatedAt?: Date;
    Details?: ResponseDetails;
    Errors?: JobError[];
    Id?: string;
    State?: string;
    Type?: string;
    UpdatedAt?: Date;
}
export interface GetReceivedDataGrantRequest {
    DataGrantArn: string;
}
export interface GetReceivedDataGrantResponse {
    Name: string;
    SenderPrincipal?: string;
    ReceiverPrincipal: string;
    Description?: string;
    AcceptanceState: string;
    AcceptedAt?: Date;
    EndsAt?: Date;
    GrantDistributionScope: string;
    DataSetId: string;
    Id: string;
    Arn: string;
    CreatedAt: Date;
    UpdatedAt: Date;
}
export interface GetRevisionRequest {
    DataSetId: string;
    RevisionId: string;
}
export interface GetRevisionResponse {
    Arn?: string;
    Comment?: string;
    CreatedAt?: Date;
    DataSetId?: string;
    Finalized?: boolean;
    Id?: string;
    SourceId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    UpdatedAt?: Date;
    RevocationComment?: string;
    Revoked?: boolean;
    RevokedAt?: Date;
}
export type MaxResults = number;
export interface ListDataGrantsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface DataGrantSummaryEntry {
    Name: string;
    SenderPrincipal: string;
    ReceiverPrincipal: string;
    AcceptanceState: string;
    AcceptedAt?: Date;
    EndsAt?: Date;
    DataSetId: string;
    SourceDataSetId: string;
    Id: string;
    Arn: string;
    CreatedAt: Date;
    UpdatedAt: Date;
}
export type ListOfDataGrantSummaryEntry = DataGrantSummaryEntry[];
export type NextToken = string;
export interface ListDataGrantsResponse {
    DataGrantSummaries?: DataGrantSummaryEntry[];
    NextToken?: string;
}
export interface ListDataSetRevisionsRequest {
    DataSetId: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface RevisionEntry {
    Arn: string;
    Comment?: string;
    CreatedAt: Date;
    DataSetId: string;
    Finalized?: boolean;
    Id: string;
    SourceId?: string;
    UpdatedAt: Date;
    RevocationComment?: string;
    Revoked?: boolean;
    RevokedAt?: Date;
}
export type ListOfRevisionEntry = RevisionEntry[];
export interface ListDataSetRevisionsResponse {
    NextToken?: string;
    Revisions?: RevisionEntry[];
}
export interface ListDataSetsRequest {
    MaxResults?: number;
    NextToken?: string;
    Origin?: string;
}
export interface DataSetEntry {
    Arn: string;
    AssetType: string;
    CreatedAt: Date;
    Description: string;
    Id: string;
    Name: string;
    Origin: string;
    OriginDetails?: OriginDetails;
    SourceId?: string;
    UpdatedAt: Date;
}
export type ListOfDataSetEntry = DataSetEntry[];
export interface ListDataSetsResponse {
    DataSets?: DataSetEntry[];
    NextToken?: string;
}
export interface ListEventActionsRequest {
    EventSourceId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface EventActionEntry {
    Action: Action;
    Arn: string;
    CreatedAt: Date;
    Event: Event;
    Id: string;
    UpdatedAt: Date;
}
export type ListOfEventActionEntry = EventActionEntry[];
export interface ListEventActionsResponse {
    EventActions?: EventActionEntry[];
    NextToken?: string;
}
export interface ListJobsRequest {
    DataSetId?: string;
    MaxResults?: number;
    NextToken?: string;
    RevisionId?: string;
}
export interface JobEntry {
    Arn: string;
    AssetConfiguration?: AssetConfiguration;
    CreatedAt: Date;
    Details: ResponseDetails;
    Errors?: JobError[];
    Id: string;
    State: string;
    Type: string;
    UpdatedAt: Date;
}
export type ListOfJobEntry = JobEntry[];
export interface ListJobsResponse {
    Jobs?: JobEntry[];
    NextToken?: string;
}
export type AcceptanceStateFilterValue = string;
export type AcceptanceStateFilterValues = string[];
export interface ListReceivedDataGrantsRequest {
    MaxResults?: number;
    NextToken?: string;
    AcceptanceState?: string[];
}
export interface ReceivedDataGrantSummariesEntry {
    Name: string;
    SenderPrincipal: string;
    ReceiverPrincipal: string;
    AcceptanceState: string;
    AcceptedAt?: Date;
    EndsAt?: Date;
    DataSetId: string;
    Id: string;
    Arn: string;
    CreatedAt: Date;
    UpdatedAt: Date;
}
export type ListOfReceivedDataGrantSummariesEntry = ReceivedDataGrantSummariesEntry[];
export interface ListReceivedDataGrantsResponse {
    DataGrantSummaries?: ReceivedDataGrantSummariesEntry[];
    NextToken?: string;
}
export interface ListRevisionAssetsRequest {
    DataSetId: string;
    MaxResults?: number;
    NextToken?: string;
    RevisionId: string;
}
export interface AssetEntry {
    Arn: string;
    AssetDetails: AssetDetails;
    AssetType: string;
    CreatedAt: Date;
    DataSetId: string;
    Id: string;
    Name: string;
    RevisionId: string;
    SourceId?: string;
    UpdatedAt: Date;
}
export type ListOfAssetEntry = AssetEntry[];
export interface ListRevisionAssetsResponse {
    Assets?: AssetEntry[];
    NextToken?: string;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface RevokeRevisionRequest {
    DataSetId: string;
    RevisionId: string;
    RevocationComment: string;
}
export interface RevokeRevisionResponse {
    Arn?: string;
    Comment?: string;
    CreatedAt?: Date;
    DataSetId?: string;
    Finalized?: boolean;
    Id?: string;
    SourceId?: string;
    UpdatedAt?: Date;
    RevocationComment?: string;
    Revoked?: boolean;
    RevokedAt?: Date;
}
export interface SendApiAssetRequest {
    Body?: string;
    QueryStringParameters?: {
        [key: string]: string | undefined;
    };
    AssetId: string;
    DataSetId: string;
    RequestHeaders?: {
        [key: string]: string | undefined;
    };
    Method?: string;
    Path?: string;
    RevisionId: string;
}
export interface SendApiAssetResponse {
    Body?: string;
    ResponseHeaders?: {
        [key: string]: string | undefined;
    };
}
export interface LakeFormationTagPolicyDetails {
    Database?: string;
    Table?: string;
}
export type ListOfLakeFormationTagPolicies = LakeFormationTagPolicyDetails[];
export interface RedshiftDataShareDetails {
    Arn: string;
    Database: string;
    Function?: string;
    Table?: string;
    Schema?: string;
    View?: string;
}
export type ListOfRedshiftDataShares = RedshiftDataShareDetails[];
export interface S3DataAccessDetails {
    KeyPrefixes?: string[];
    Keys?: string[];
}
export type ListOfS3DataAccesses = S3DataAccessDetails[];
export interface ScopeDetails {
    LakeFormationTagPolicies?: LakeFormationTagPolicyDetails[];
    RedshiftDataShares?: RedshiftDataShareDetails[];
    S3DataAccesses?: S3DataAccessDetails[];
}
export type ClientToken = string;
export type __stringMin0Max4096 = string;
export interface DataUpdateRequestDetails {
    DataUpdatedAt?: Date;
}
export interface DeprecationRequestDetails {
    DeprecationAt: Date;
}
export type SchemaChangeType = string;
export interface SchemaChangeDetails {
    Name: string;
    Type: string;
    Description?: string;
}
export type ListOfSchemaChangeDetails = SchemaChangeDetails[];
export interface SchemaChangeRequestDetails {
    Changes?: SchemaChangeDetails[];
    SchemaChangeAt: Date;
}
export interface NotificationDetails {
    DataUpdate?: DataUpdateRequestDetails;
    Deprecation?: DeprecationRequestDetails;
    SchemaChange?: SchemaChangeRequestDetails;
}
export type NotificationType = string;
export interface SendDataSetNotificationRequest {
    Scope?: ScopeDetails;
    ClientToken?: string;
    Comment?: string;
    DataSetId: string;
    Details?: NotificationDetails;
    Type: string;
}
export interface SendDataSetNotificationResponse {
}
export interface StartJobRequest {
    JobId: string;
}
export interface StartJobResponse {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAssetRequest {
    AssetId: string;
    DataSetId: string;
    Name: string;
    RevisionId: string;
}
export interface UpdateAssetResponse {
    Arn?: string;
    AssetDetails?: AssetDetails;
    AssetType?: string;
    CreatedAt?: Date;
    DataSetId?: string;
    Id?: string;
    Name?: string;
    RevisionId?: string;
    SourceId?: string;
    UpdatedAt?: Date;
}
export interface UpdateDataSetRequest {
    DataSetId: string;
    Description?: string;
    Name?: string;
}
export interface UpdateDataSetResponse {
    Arn?: string;
    AssetType?: string;
    CreatedAt?: Date;
    Description?: string;
    Id?: string;
    Name?: string;
    Origin?: string;
    OriginDetails?: OriginDetails;
    SourceId?: string;
    UpdatedAt?: Date;
}
export interface UpdateEventActionRequest {
    Action?: Action;
    EventActionId: string;
}
export interface UpdateEventActionResponse {
    Action?: Action;
    Arn?: string;
    CreatedAt?: Date;
    Event?: Event;
    Id?: string;
    UpdatedAt?: Date;
}
export interface UpdateRevisionRequest {
    Comment?: string;
    DataSetId: string;
    Finalized?: boolean;
    RevisionId: string;
}
export interface UpdateRevisionResponse {
    Arn?: string;
    Comment?: string;
    CreatedAt?: Date;
    DataSetId?: string;
    Finalized?: boolean;
    Id?: string;
    SourceId?: string;
    UpdatedAt?: Date;
    RevocationComment?: string;
    Revoked?: boolean;
    RevokedAt?: Date;
}
export type ResourceType = string;
export type ExceptionCause = string;
export type LimitName = string;
export type AcceptDataGrantError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation accepts a data grant.
 */
export declare const acceptDataGrant: API.OperationMethod<AcceptDataGrantRequest, AcceptDataGrantResponse, AcceptDataGrantError, Credentials | HttpClient.HttpClient>;
export type CancelJobError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation cancels a job. Jobs can be cancelled only when they are in the WAITING state.
 */
export declare const cancelJob: API.OperationMethod<CancelJobRequest, CancelJobResponse, CancelJobError, Credentials | HttpClient.HttpClient>;
export type CreateDataGrantError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceLimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation creates a data grant.
 */
export declare const createDataGrant: API.OperationMethod<CreateDataGrantRequest, CreateDataGrantResponse, CreateDataGrantError, Credentials | HttpClient.HttpClient>;
export type CreateDataSetError = AccessDeniedException | InternalServerException | ServiceLimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation creates a data set.
 */
export declare const createDataSet: API.OperationMethod<CreateDataSetRequest, CreateDataSetResponse, CreateDataSetError, Credentials | HttpClient.HttpClient>;
export type CreateEventActionError = AccessDeniedException | InternalServerException | ServiceLimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation creates an event action.
 */
export declare const createEventAction: API.OperationMethod<CreateEventActionRequest, CreateEventActionResponse, CreateEventActionError, Credentials | HttpClient.HttpClient>;
export type CreateJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation creates a job.
 */
export declare const createJob: API.OperationMethod<CreateJobRequest, CreateJobResponse, CreateJobError, Credentials | HttpClient.HttpClient>;
export type CreateRevisionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation creates a revision for a data set.
 */
export declare const createRevision: API.OperationMethod<CreateRevisionRequest, CreateRevisionResponse, CreateRevisionError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation deletes an asset.
 */
export declare const deleteAsset: API.OperationMethod<DeleteAssetRequest, DeleteAssetResponse, DeleteAssetError, Credentials | HttpClient.HttpClient>;
export type DeleteDataGrantError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation deletes a data grant.
 */
export declare const deleteDataGrant: API.OperationMethod<DeleteDataGrantRequest, DeleteDataGrantResponse, DeleteDataGrantError, Credentials | HttpClient.HttpClient>;
export type DeleteDataSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation deletes a data set.
 */
export declare const deleteDataSet: API.OperationMethod<DeleteDataSetRequest, DeleteDataSetResponse, DeleteDataSetError, Credentials | HttpClient.HttpClient>;
export type DeleteEventActionError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation deletes the event action.
 */
export declare const deleteEventAction: API.OperationMethod<DeleteEventActionRequest, DeleteEventActionResponse, DeleteEventActionError, Credentials | HttpClient.HttpClient>;
export type DeleteRevisionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation deletes a revision.
 */
export declare const deleteRevision: API.OperationMethod<DeleteRevisionRequest, DeleteRevisionResponse, DeleteRevisionError, Credentials | HttpClient.HttpClient>;
export type GetAssetError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about an asset.
 */
export declare const getAsset: API.OperationMethod<GetAssetRequest, GetAssetResponse, GetAssetError, Credentials | HttpClient.HttpClient>;
export type GetDataGrantError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about a data grant.
 */
export declare const getDataGrant: API.OperationMethod<GetDataGrantRequest, GetDataGrantResponse, GetDataGrantError, Credentials | HttpClient.HttpClient>;
export type GetDataSetError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about a data set.
 */
export declare const getDataSet: API.OperationMethod<GetDataSetRequest, GetDataSetResponse, GetDataSetError, Credentials | HttpClient.HttpClient>;
export type GetEventActionError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation retrieves information about an event action.
 */
export declare const getEventAction: API.OperationMethod<GetEventActionRequest, GetEventActionResponse, GetEventActionError, Credentials | HttpClient.HttpClient>;
export type GetJobError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about a job.
 */
export declare const getJob: API.OperationMethod<GetJobRequest, GetJobResponse, GetJobError, Credentials | HttpClient.HttpClient>;
export type GetReceivedDataGrantError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about a received data grant.
 */
export declare const getReceivedDataGrant: API.OperationMethod<GetReceivedDataGrantRequest, GetReceivedDataGrantResponse, GetReceivedDataGrantError, Credentials | HttpClient.HttpClient>;
export type GetRevisionError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about a revision.
 */
export declare const getRevision: API.OperationMethod<GetRevisionRequest, GetRevisionResponse, GetRevisionError, Credentials | HttpClient.HttpClient>;
export type ListDataGrantsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about all data grants.
 */
export declare const listDataGrants: API.PaginatedOperationMethod<ListDataGrantsRequest, ListDataGrantsResponse, ListDataGrantsError, Credentials | HttpClient.HttpClient, DataGrantSummaryEntry>;
export type ListDataSetRevisionsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation lists a data set's revisions sorted by CreatedAt in descending order.
 */
export declare const listDataSetRevisions: API.PaginatedOperationMethod<ListDataSetRevisionsRequest, ListDataSetRevisionsResponse, ListDataSetRevisionsError, Credentials | HttpClient.HttpClient, RevisionEntry>;
export type ListDataSetsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation lists your data sets. When listing by origin OWNED, results are sorted by CreatedAt in descending order. When listing by origin ENTITLED, there is no order.
 */
export declare const listDataSets: API.PaginatedOperationMethod<ListDataSetsRequest, ListDataSetsResponse, ListDataSetsError, Credentials | HttpClient.HttpClient, DataSetEntry>;
export type ListEventActionsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation lists your event actions.
 */
export declare const listEventActions: API.PaginatedOperationMethod<ListEventActionsRequest, ListEventActionsResponse, ListEventActionsError, Credentials | HttpClient.HttpClient, EventActionEntry>;
export type ListJobsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation lists your jobs sorted by CreatedAt in descending order.
 */
export declare const listJobs: API.PaginatedOperationMethod<ListJobsRequest, ListJobsResponse, ListJobsError, Credentials | HttpClient.HttpClient, JobEntry>;
export type ListReceivedDataGrantsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about all received data grants.
 */
export declare const listReceivedDataGrants: API.PaginatedOperationMethod<ListReceivedDataGrantsRequest, ListReceivedDataGrantsResponse, ListReceivedDataGrantsError, Credentials | HttpClient.HttpClient, ReceivedDataGrantSummariesEntry>;
export type ListRevisionAssetsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation lists a revision's assets sorted alphabetically in descending order.
 */
export declare const listRevisionAssets: API.PaginatedOperationMethod<ListRevisionAssetsRequest, ListRevisionAssetsResponse, ListRevisionAssetsError, Credentials | HttpClient.HttpClient, AssetEntry>;
export type ListTagsForResourceError = CommonErrors;
/**
 * This operation lists the tags on the resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RevokeRevisionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation revokes subscribers' access to a revision.
 */
export declare const revokeRevision: API.OperationMethod<RevokeRevisionRequest, RevokeRevisionResponse, RevokeRevisionError, Credentials | HttpClient.HttpClient>;
export type SendApiAssetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation invokes an API Gateway API asset. The request is proxied to the provider's API Gateway API.
 */
export declare const sendApiAsset: API.OperationMethod<SendApiAssetRequest, SendApiAssetResponse, SendApiAssetError, Credentials | HttpClient.HttpClient>;
export type SendDataSetNotificationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The type of event associated with the data set.
 */
export declare const sendDataSetNotification: API.OperationMethod<SendDataSetNotificationRequest, SendDataSetNotificationResponse, SendDataSetNotificationError, Credentials | HttpClient.HttpClient>;
export type StartJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation starts a job.
 */
export declare const startJob: API.OperationMethod<StartJobRequest, StartJobResponse, StartJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = CommonErrors;
/**
 * This operation tags a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = CommonErrors;
/**
 * This operation removes one or more tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation updates an asset.
 */
export declare const updateAsset: API.OperationMethod<UpdateAssetRequest, UpdateAssetResponse, UpdateAssetError, Credentials | HttpClient.HttpClient>;
export type UpdateDataSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation updates a data set.
 */
export declare const updateDataSet: API.OperationMethod<UpdateDataSetRequest, UpdateDataSetResponse, UpdateDataSetError, Credentials | HttpClient.HttpClient>;
export type UpdateEventActionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation updates the event action.
 */
export declare const updateEventAction: API.OperationMethod<UpdateEventActionRequest, UpdateEventActionResponse, UpdateEventActionError, Credentials | HttpClient.HttpClient>;
export type UpdateRevisionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation updates a revision.
 */
export declare const updateRevision: API.OperationMethod<UpdateRevisionRequest, UpdateRevisionResponse, UpdateRevisionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=dataexchange.d.ts.map