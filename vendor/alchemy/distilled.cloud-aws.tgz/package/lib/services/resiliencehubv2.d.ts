import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Arn = string;
export type AssertionText = string;
export type ClientToken = string;
export interface CreateAssertionRequest {
    serviceArn: string;
    text: string;
    clientToken?: string;
}
export type Uuid = string;
export type AssertionSource = "AI_GENERATED" | "USER" | (string & {});
export interface Assertion {
    serviceArn: string;
    assertionId: string;
    text: string;
    source: AssertionSource;
    createdAt?: Date;
    updatedAt?: Date;
}
export interface CreateAssertionResponse {
    assertion: Assertion;
}
export type TagKey = string;
export type TagValue = string;
export type TagValueList = string[];
export interface ResourceTag {
    key: string;
    values: string[];
}
export type ResourceTagList = ResourceTag[];
export type S3Url = string;
export type EksNamespace = string;
export type EksNamespaceList = string[];
export type EksLabelKey = string;
export type EksLabelValue = string;
export type EksLabelMap = {
    [key: string]: string | undefined;
};
export type EksLabelSelectorOperator = "IN" | "NOT_IN" | "EXISTS" | "DOES_NOT_EXIST" | (string & {});
export type EksLabelValueList = string[];
export interface EksLabelSelectorRequirement {
    key: string;
    operator: EksLabelSelectorOperator;
    values?: string[];
}
export type EksLabelSelectorRequirementList = EksLabelSelectorRequirement[];
export interface EksLabelSelector {
    matchLabels?: {
        [key: string]: string | undefined;
    };
    matchExpressions?: EksLabelSelectorRequirement[];
}
export interface EksSource {
    clusterArn: string;
    namespaces: string[];
    labelSelector?: EksLabelSelector;
}
export type ResourceConfiguration = {
    resourceTags: ResourceTag[];
    cfnStackArn?: never;
    tfStateFileUrl?: never;
    eks?: never;
    designFileS3Url?: never;
} | {
    resourceTags?: never;
    cfnStackArn: string;
    tfStateFileUrl?: never;
    eks?: never;
    designFileS3Url?: never;
} | {
    resourceTags?: never;
    cfnStackArn?: never;
    tfStateFileUrl: string;
    eks?: never;
    designFileS3Url?: never;
} | {
    resourceTags?: never;
    cfnStackArn?: never;
    tfStateFileUrl?: never;
    eks: EksSource;
    designFileS3Url?: never;
} | {
    resourceTags?: never;
    cfnStackArn?: never;
    tfStateFileUrl?: never;
    eks?: never;
    designFileS3Url: string;
};
export interface CreateInputSourceRequest {
    serviceArn: string;
    resourceConfiguration: ResourceConfiguration;
    clientToken?: string;
}
export type InputSourceId = string;
export interface CreateInputSourceResponse {
    serviceArn: string;
    inputSourceId: string;
}
export type EntityName = string;
export type LongDescription = string;
export interface AvailabilitySlo {
    target?: number;
}
export type MultiAzDisasterRecoveryApproach = "ACTIVE_ACTIVE" | "HOT_STANDBY" | "WARM_STANDBY" | "PILOT_LIGHT" | "BACKUP_AND_RESTORE" | (string & {});
export interface MultiAzTargets {
    rtoInMinutes?: number;
    rpoInMinutes?: number;
    disasterRecoveryApproach?: MultiAzDisasterRecoveryApproach;
}
export type MultiRegionDisasterRecoveryApproach = "ACTIVE_ACTIVE" | "HOT_STANDBY" | "WARM_STANDBY" | "PILOT_LIGHT" | "BACKUP_AND_RESTORE" | (string & {});
export interface MultiRegionTargets {
    rtoInMinutes?: number;
    rpoInMinutes?: number;
    disasterRecoveryApproach?: MultiRegionDisasterRecoveryApproach;
}
export interface DataRecoveryTargets {
    timeBetweenBackupsInMinutes?: number;
}
export type KmsKeyId = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreatePolicyRequest {
    name: string;
    description?: string;
    availabilitySlo?: AvailabilitySlo;
    multiAz?: MultiAzTargets;
    multiRegion?: MultiRegionTargets;
    dataRecovery?: DataRecoveryTargets;
    sharingEnabled?: boolean;
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export type OrganizationId = string;
export interface Policy {
    policyArn: string;
    name: string;
    description?: string;
    availabilitySlo?: AvailabilitySlo;
    multiAz?: MultiAzTargets;
    multiRegion?: MultiRegionTargets;
    dataRecovery?: DataRecoveryTargets;
    sharingEnabled?: boolean;
    organizationId?: string;
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    associatedServiceCount?: number;
    createdAt?: Date;
    updatedAt?: Date;
}
export interface CreatePolicyResponse {
    policy: Policy;
}
export type ReportType = "FAILURE_MODE" | "TESTING" | (string & {});
export interface CreateReportRequest {
    serviceArn: string;
    reportType: ReportType;
    clientToken?: string;
}
export type ReportGenerationStatus = "PENDING" | "SUCCEEDED" | "FAILED" | (string & {});
export type TestRunId = string;
export type ServiceOwnedArn = string;
export interface S3ReportOutput {
    s3ObjectKey: string;
}
export type ReportGenerationErrorCode = "INSUFFICIENT_PERMISSIONS" | "CONFIGURATION_ERROR" | "INTERNAL_ERROR" | (string & {});
export interface FailedReportOutput {
    errorCode: ReportGenerationErrorCode;
    errorMessage?: string;
}
export type ReportOutput = {
    s3ReportOutput: S3ReportOutput;
    failedReportOutput?: never;
} | {
    s3ReportOutput?: never;
    failedReportOutput: FailedReportOutput;
};
export interface ReportGenerationResult {
    reportType: ReportType;
    status: ReportGenerationStatus;
    serviceArn?: string;
    assessmentId?: string;
    testRunId?: string;
    testTemplateArn?: string;
    createdAt?: Date;
    reportOutput?: ReportOutput;
}
export interface CreateReportResponse {
    reportGenerationResult: ReportGenerationResult;
}
export type UserJourneyId = string;
export type UserJourneyIdList = string[];
export interface AssociatedSystem {
    systemArn: string;
    systemName?: string;
    userJourneyIds?: string[];
}
export type AssociatedSystemList = AssociatedSystem[];
export type AwsRegion = string;
export type RegionList = string[];
export type IamRoleName = string;
export type IamRoleArn = string;
export interface CrossAccountRole {
    crossAccountRoleArn: string;
    externalId?: string;
}
export type CrossAccountRoleList = CrossAccountRole[];
export interface PermissionModel {
    invokerRoleName: string;
    crossAccountRoles?: CrossAccountRole[];
}
export type DependencyDiscoveryInput = "ENABLED" | "DISABLED" | (string & {});
export type S3BucketPath = string;
export type AwsAccountId = string;
export interface S3ReportOutputConfiguration {
    bucketPath: string;
    bucketOwner: string;
}
export type ReportOutputConfiguration = {
    s3: S3ReportOutputConfiguration;
};
export type ReportOutputConfigurationList = ReportOutputConfiguration[];
export interface ServiceReportConfiguration {
    reportOutputs: ReportOutputConfiguration[];
}
export interface CreateServiceRequest {
    name: string;
    description?: string;
    associatedSystems?: AssociatedSystem[];
    policyArn?: string;
    regions: string[];
    permissionModel: PermissionModel;
    dependencyDiscovery?: DependencyDiscoveryInput;
    reportConfiguration?: ServiceReportConfiguration;
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export type DependencyDiscoveryStatus = "ENABLED" | "INITIALIZING" | "DISABLED" | (string & {});
export interface DependencyDiscoveryConfig {
    status: DependencyDiscoveryStatus;
    updatedAt?: Date;
    eligibleResourceCount?: number;
    message?: string;
}
export type PolicyValueSource = "SELF" | "CROSS_ACCOUNT" | (string & {});
export interface SloSource {
    value?: number;
    policyName?: string;
    source?: PolicyValueSource;
}
export interface TargetSource {
    value?: number;
    policyName?: string;
    source?: PolicyValueSource;
}
export interface DisasterRecoverySource {
    value?: string;
    policyName?: string;
    source?: PolicyValueSource;
}
export interface EffectivePolicyValues {
    availabilitySlo?: SloSource;
    multiAzRto?: TargetSource;
    multiAzRpo?: TargetSource;
    multiAzDrApproach?: DisasterRecoverySource;
    multiRegionRto?: TargetSource;
    multiRegionRpo?: TargetSource;
    multiRegionDrApproach?: DisasterRecoverySource;
    dataRecoveryTimeBetweenBackups?: TargetSource;
}
export type AchievabilityStatus = "ACHIEVABLE" | "NOT_ACHIEVABLE" | (string & {});
export interface Achievability {
    availabilitySlo?: AchievabilityStatus;
    multiAzRtoRpo?: AchievabilityStatus;
    multiRegionRtoRpo?: AchievabilityStatus;
    dataRecoveryTimeBetweenBackups?: AchievabilityStatus;
}
export type CostCurrency = "USD" | (string & {});
export interface AssessmentCost {
    amount?: number;
    currency?: CostCurrency;
}
export type ResourceDiscoveryRunStatus = "RUNNING" | "SUCCEEDED" | "FAILED" | "COMPLETED_WITH_FAILURES" | "NOT_STARTED" | (string & {});
export type ResourceDiscoveryErrorCode = "INVALID_PERMISSIONS" | "STACK_NOT_FOUND" | "CLUSTER_NOT_FOUND" | "STATE_FILE_NOT_FOUND" | "ACCESS_DENIED" | "UNSUPPORTED_CLUSTER" | "INTERNAL_ERROR" | (string & {});
export interface ResourceDiscoveryStatus {
    status?: ResourceDiscoveryRunStatus;
    lastRunAt?: Date;
    errorCode?: ResourceDiscoveryErrorCode;
    errorMessage?: string;
}
export type AssessmentStatus = "NOT_STARTED" | "PENDING" | "IN_PROGRESS" | "FAILED" | "SUCCESS" | (string & {});
export type OuId = string;
export type AccountId = string;
export interface Service {
    serviceArn: string;
    name: string;
    description?: string;
    associatedSystems?: AssociatedSystem[];
    policyArn?: string;
    regions?: string[];
    permissionModel?: PermissionModel;
    dependencyDiscovery?: DependencyDiscoveryConfig;
    effectivePolicyValues?: EffectivePolicyValues;
    achievability?: Achievability;
    reportConfiguration?: ServiceReportConfiguration;
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    estimatedAssessmentCost?: AssessmentCost;
    resourceDiscovery?: ResourceDiscoveryStatus;
    assessmentStatus?: AssessmentStatus;
    rerunAssessment?: boolean;
    openFindingsCount?: number;
    resolvedFindingsCount?: number;
    organizationId?: string;
    ouId?: string;
    accountId?: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export interface CreateServiceResponse {
    service: Service;
}
export type EntityLabel = string;
export type EntityDescription = string;
export type ServiceFunctionCriticality = "PRIMARY" | "SUPPLEMENTAL" | (string & {});
export interface CreateServiceFunctionRequest {
    name: string;
    serviceArn: string;
    description?: string;
    criticality: ServiceFunctionCriticality;
    clientToken?: string;
}
export type EntityId = string;
export type ServiceFunctionSource = "AI_GENERATED" | "USER" | (string & {});
export interface ServiceFunction {
    serviceArn: string;
    serviceFunctionId: string;
    name: string;
    description?: string;
    criticality: ServiceFunctionCriticality;
    resourceCount?: number;
    source?: ServiceFunctionSource;
    createdAt?: Date;
    updatedAt?: Date;
}
export interface CreateServiceFunctionResponse {
    serviceFunction: ServiceFunction;
}
export type ResourceList = string[];
export interface CreateServiceFunctionResourcesRequest {
    serviceArn: string;
    serviceFunctionId: string;
    resources: string[];
}
export interface CreateServiceFunctionResourcesResponse {
    serviceArn?: string;
    serviceFunctionId?: string;
    resources?: string[];
}
export interface CreateSystemRequest {
    name: string;
    description?: string;
    sharingEnabled?: boolean;
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export type SystemId = string;
export interface System {
    systemArn: string;
    systemId: string;
    name: string;
    description?: string;
    sharingEnabled?: boolean;
    tags?: {
        [key: string]: string | undefined;
    };
    kmsKeyId?: string;
    organizationId?: string;
    ouId?: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export interface CreateSystemResponse {
    system: System;
}
export interface LoggingConfiguration {
    s3BucketName?: string;
    cloudWatchLogGroupArn?: string;
    logSchemaVersion?: string;
}
export type StopConditionSource = "aws:cloudwatch:alarm" | "none" | (string & {});
export interface StopCondition {
    source: StopConditionSource;
    value: string;
}
export type StopConditionList = StopCondition[];
export type ParameterKey = string;
export type ParameterValue = string;
export type StringList = string[];
export type TestParameters = {
    [key: string]: string[] | undefined;
};
export interface CreateTestRequest {
    serviceArn: string;
    testTemplateArn: string;
    loggingConfiguration?: LoggingConfiguration;
    stopConditions?: StopCondition[];
    roleName?: string;
    parameters?: {
        [key: string]: string[] | undefined;
    };
}
export type TestId = string;
export interface TestAction {
    actionId: string;
    description?: string;
    resourceType: string;
}
export type TestActionList = TestAction[];
export interface Test {
    testId: string;
    testTemplateArn: string;
    serviceArn: string;
    name: string;
    actions?: TestAction[];
    loggingConfiguration?: LoggingConfiguration;
    stopConditions?: StopCondition[];
    roleName?: string;
    parameters?: {
        [key: string]: string[] | undefined;
    };
    totalTestRuns: number;
    successfulTestRuns: number;
    creationTime: Date;
}
export interface CreateTestResponse {
    test: Test;
}
export interface CreateUserJourneyRequest {
    systemArn: string;
    name: string;
    description?: string;
    policyArn?: string;
    clientToken?: string;
}
export interface UserJourney {
    userJourneyId: string;
    name: string;
    description?: string;
    policyArn?: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export interface CreateUserJourneyResponse {
    userJourney: UserJourney;
}
export interface DeleteAssertionRequest {
    serviceArn: string;
    assertionId: string;
}
export interface DeleteAssertionResponse {
    assertionId?: string;
}
export interface DeleteInputSourceRequest {
    serviceArn: string;
    inputSourceId: string;
}
export interface DeleteInputSourceResponse {
    serviceArn: string;
    inputSourceId: string;
}
export interface DeletePolicyRequest {
    policyArn: string;
}
export interface DeletePolicyResponse {
    policyArn: string;
}
export interface DeleteServiceRequest {
    serviceArn: string;
}
export interface DeleteServiceResponse {
    serviceArn: string;
}
export interface DeleteServiceFunctionRequest {
    serviceArn: string;
    serviceFunctionId: string;
}
export interface DeleteServiceFunctionResponse {
    serviceFunctionId?: string;
}
export interface DeleteServiceFunctionResourcesRequest {
    serviceArn: string;
    serviceFunctionId: string;
    resources: string[];
}
export interface DeleteServiceFunctionResourcesResponse {
    serviceArn?: string;
    serviceFunctionId?: string;
    resources?: string[];
}
export interface DeleteSystemRequest {
    systemArn: string;
}
export interface DeleteSystemResponse {
    systemArn: string;
}
export interface DeleteTestRequest {
    testId: string;
    serviceArn: string;
}
export interface DeleteTestResponse {
    testId: string;
}
export type CloudWatchAlarmArn = string;
export interface SuccessCriteriaAlarmInput {
    alarmArn: string;
}
export interface ObservabilityAlarmInput {
    alarmArn: string;
}
export type TestSourceInput = {
    successCriteriaAlarm: SuccessCriteriaAlarmInput;
    observabilityAlarm?: never;
} | {
    successCriteriaAlarm?: never;
    observabilityAlarm: ObservabilityAlarmInput;
};
export type TestSourceInputList = TestSourceInput[];
export interface DeleteTestSourcesRequest {
    testId: string;
    serviceArn: string;
    testSources: TestSourceInput[];
}
export interface DeleteTestSourcesResponse {
}
export interface DeleteUserJourneyRequest {
    systemArn: string;
    userJourneyId: string;
}
export interface DeleteUserJourneyResponse {
    userJourneyId: string;
}
export interface GetDependencyInsightsRequest {
    serviceArn: string;
}
export type InsightsCategory = "CROSS_REGION" | "NEW_DEPENDENCY" | "THIRD_PARTY" | "UNEVEN_USAGE" | "AWS_SERVICE" | (string & {});
export interface DependencyInsight {
    category: InsightsCategory;
    description: string;
}
export type DependencyInsightsList = DependencyInsight[];
export type DependencyInsightsStatus = "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export type DependencyInsightsErrorCode = "INSUFFICIENT_DATA" | "LLM_GENERATION_FAILED" | "INTERNAL_ERROR" | (string & {});
export interface GetDependencyInsightsResponse {
    overview?: string;
    insights?: DependencyInsight[];
    status: DependencyInsightsStatus;
    createdAt?: Date;
    errorCode?: DependencyInsightsErrorCode;
    errorMessage?: string;
}
export interface GetFailureModeFindingRequest {
    findingId: string;
    serviceArn: string;
}
export type FailureCategory = "SHARED_FATE" | "EXCESSIVE_LOAD" | "EXCESSIVE_LATENCY" | "MISCONFIGURATION_AND_BUGS" | "SINGLE_POINT_OF_FAILURE" | (string & {});
export type FindingStatus = "OPEN" | "RESOLVED" | "IRRELEVANT" | (string & {});
export type FindingSeverity = "LOW" | "MEDIUM" | "HIGH" | (string & {});
export type FunctionsList = string[];
export type PolicyComponent = "AVAILABILITY_SLO" | "MULTI_AZ_DISASTER_RECOVERY" | "MULTI_REGION_DISASTER_RECOVERY" | "DATA_RECOVERY" | (string & {});
export type SuggestedChangesList = string[];
export interface InfrastructureAndCodeRecommendation {
    suggestedChanges?: string[];
}
export type InfrastructureAndCodeRecommendationsList = InfrastructureAndCodeRecommendation[];
export interface ObservabilityRecommendation {
    suggestedChanges?: string[];
}
export type ObservabilityRecommendationsList = ObservabilityRecommendation[];
export interface TestingRecommendation {
    suggestedChanges?: string[];
}
export type TestingRecommendationsList = TestingRecommendation[];
export interface Finding {
    findingId?: string;
    name?: string;
    description?: string;
    failureCategory?: FailureCategory;
    status?: FindingStatus;
    reasoning?: string;
    comment?: string;
    severity?: FindingSeverity;
    serviceFunctions?: string[];
    policyComponent?: PolicyComponent;
    infrastructureAndCodeRecommendations?: InfrastructureAndCodeRecommendation[];
    observabilityRecommendations?: ObservabilityRecommendation[];
    testingRecommendations?: TestingRecommendation[];
    updatedAt?: Date;
}
export interface GetFailureModeFindingResponse {
    finding?: Finding;
}
export interface GetPolicyRequest {
    policyArn: string;
}
export interface GetPolicyResponse {
    policy: Policy;
}
export interface GetServiceRequest {
    serviceArn: string;
}
export interface GetServiceResponse {
    service: Service;
}
export interface GetSystemRequest {
    systemArn: string;
}
export interface GetSystemResponse {
    system: System;
}
export interface GetTestRequest {
    testId: string;
    serviceArn: string;
}
export interface GetTestResponse {
    test: Test;
}
export interface GetTestRunRequest {
    testRunId: string;
    serviceArn: string;
}
export type TestRunStatus = "INITIALIZING" | "RUNNING" | "STOPPING" | "PASSED" | "FAILED" | "STOPPED" | "ERROR" | (string & {});
export interface ExperimentDetails {
    experimentArn: string;
    details?: string;
}
export type ExperimentDetailsList = ExperimentDetails[];
export interface TestRunReportConfiguration {
    reportOutput: ReportOutputConfiguration[];
}
export interface TestRunPolicySnapshot {
    policyArn?: string;
    name?: string;
    availabilitySlo?: AvailabilitySlo;
    multiAz?: MultiAzTargets;
    multiRegion?: MultiRegionTargets;
    dataRecovery?: DataRecoveryTargets;
}
export type RegionSwitchExecutionId = string;
export type AccountTargeting = "SINGLE_ACCOUNT" | "MULTI_ACCOUNT" | (string & {});
export interface TestRun {
    testRunId: string;
    testId: string;
    status: TestRunStatus;
    serviceArn?: string;
    startedAt: Date;
    endedAt?: Date;
    experiments?: ExperimentDetails[];
    eventCount?: number;
    parameters?: {
        [key: string]: string[] | undefined;
    };
    errorMessage?: string;
    stopConditions?: StopCondition[];
    loggingConfiguration?: LoggingConfiguration;
    roleName?: string;
    testTemplateArn: string;
    reportConfiguration?: TestRunReportConfiguration;
    policy?: TestRunPolicySnapshot;
    reportOutput?: ReportGenerationResult;
    regionSwitchPlanArn?: string;
    regionSwitchExecutionId?: string;
    permissionModel?: PermissionModel;
    regions?: string[];
    accountTargeting?: AccountTargeting;
}
export interface GetTestRunResponse {
    testRun: TestRun;
}
export interface GetTestTemplateRequest {
    testTemplateArn: string;
}
export type ParameterType = "STRING" | "STRING_LIST" | "INTEGER" | (string & {});
export interface TestTemplateParameter {
    name: string;
    description?: string;
    type: ParameterType;
    required: boolean;
    defaultValue?: string;
    maxValues?: number;
}
export type TestTemplateParameterList = TestTemplateParameter[];
export interface TestTemplate {
    testTemplateArn: string;
    name: string;
    description?: string;
    parameters?: TestTemplateParameter[];
    actions?: TestAction[];
}
export interface GetTestTemplateResponse {
    testTemplate: TestTemplate;
}
export interface GetUserJourneyRequest {
    systemArn: string;
    userJourneyId: string;
}
export interface GetUserJourneyResponse {
    userJourney: UserJourney;
}
export interface ImportAppRequest {
    v1AppArn: string;
    policyArn?: string;
    kmsKeyId?: string;
    skipManuallyAddedResources?: boolean;
    associatedSystems?: AssociatedSystem[];
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export interface ImportAppResponse {
    service: Service;
}
export interface ImportPolicyRequest {
    v1PolicyArn: string;
    kmsKeyId?: string;
    availabilitySlo?: AvailabilitySlo;
    multiAzDisasterRecoveryApproach?: MultiAzDisasterRecoveryApproach;
    multiRegionDisasterRecoveryApproach?: MultiRegionDisasterRecoveryApproach;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export interface ImportPolicyResponse {
    policy: Policy;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListAssertionsRequest {
    serviceArn: string;
    source?: AssertionSource;
    maxResults?: number;
    nextToken?: string;
}
export type AssertionList = Assertion[];
export interface ListAssertionsResponse {
    assertions: Assertion[];
    nextToken?: string;
}
export type QueryGranularity = "HOURLY" | "DAILY" | (string & {});
export interface ListDependenciesRequest {
    serviceArn?: string;
    queryRangeStartTime?: Date;
    queryRangeEndTime?: Date;
    queryRangeGranularity?: QueryGranularity;
    maxResults?: number;
    nextToken?: string;
}
export interface QueryDataPoint {
    timestamp: Date;
    queryCount: number;
}
export type QueryDataPointList = QueryDataPoint[];
export interface QueryRange {
    startTime: Date;
    endTime: Date;
    granularity: QueryGranularity;
    dataPoints: QueryDataPoint[];
}
export type DependencyCriticality = "HARD" | "SOFT" | "UNKNOWN" | (string & {});
export interface DependencySummary {
    dependencyId: string;
    serviceArn: string;
    dependencyName: string;
    dnsName: string;
    location: string;
    lastDetectedTime: Date;
    sourceRegions: string[];
    provider?: string;
    queryRange: QueryRange;
    criticality: DependencyCriticality;
    comment?: string;
}
export type DependencySummaryList = DependencySummary[];
export interface ListDependenciesResponse {
    dependencySummaries: DependencySummary[];
    nextToken?: string;
}
export type AssessmentStatusList = AssessmentStatus[];
export type AssessmentSortField = "STARTED_AT" | (string & {});
export type SortOrder = "ASC" | "DESC" | (string & {});
export interface ListFailureModeAssessmentsRequest {
    serviceArn: string;
    assessmentStatuses?: AssessmentStatus[];
    startedAfter?: Date;
    endedBefore?: Date;
    sortBy?: AssessmentSortField;
    sortOrder?: SortOrder;
    maxResults?: number;
    nextToken?: string;
}
export type AssessmentStep = "TOPOLOGY_GENERATION" | "INPUT_VALIDATION" | "DESIGN_ANALYSIS" | "TOPOLOGY_ENHANCEMENT" | "SERVICE_FUNCTION_GENERATION" | "POLICY_VALIDATION" | "RESILIENCE_ASSESSMENT" | "FAILURE_MODE_FINDINGS_CONSOLIDATION" | "FAILURE_MODE_FINDINGS_ENRICHMENT" | (string & {});
export type AssessmentErrorCode = "INVALID_PERMISSIONS" | "CMK_ACCESS_DENIED" | "AGENT_ERROR" | "INTERNAL_ERROR" | "DESIGN_FILE_ACCESS_DENIED" | (string & {});
export interface AssessmentSummary {
    assessmentId: string;
    serviceArn: string;
    assessmentStatus?: AssessmentStatus;
    assessmentStep?: AssessmentStep;
    totalFindings?: number;
    startedAt?: Date;
    endedAt?: Date;
    errorMessage?: string;
    errorCode?: AssessmentErrorCode;
    assessmentCost?: AssessmentCost;
    billableAssessmentUnitCount?: number;
    achievability?: Achievability;
}
export type AssessmentSummaryList = AssessmentSummary[];
export interface ListFailureModeAssessmentsResponse {
    assessmentSummaries: AssessmentSummary[];
    nextToken?: string;
}
export interface ListFailureModeFindingsRequest {
    serviceArn: string;
    severity?: FindingSeverity;
    failureCategory?: FailureCategory;
    status?: FindingStatus;
    maxResults?: number;
    nextToken?: string;
}
export interface FindingSummary {
    serviceArn?: string;
    findingId?: string;
    name?: string;
    description?: string;
    failureCategory?: FailureCategory;
    severity?: FindingSeverity;
    status?: FindingStatus;
    policyComponent?: PolicyComponent;
    updatedAt?: Date;
}
export type FindingsList = FindingSummary[];
export interface ListFailureModeFindingsResponse {
    findingsSummary: FindingSummary[];
    nextToken?: string;
}
export type InputSourceType = "CFN_STACK" | "TAGS" | "EKS" | "TERRAFORM" | "DESIGN_FILE" | "MONITORING" | (string & {});
export interface ListInputSourcesRequest {
    serviceArn: string;
    type?: InputSourceType;
    maxResults?: number;
    nextToken?: string;
}
export interface InputSourceSummary {
    inputSourceId: string;
    type?: InputSourceType;
    resourceTags?: ResourceTag[];
    cfnStackArn?: string;
    tfStateFileUrl?: string;
    eks?: EksSource;
    designFileS3Url?: string;
    createdAt?: Date;
}
export type InputSourceSummaryList = InputSourceSummary[];
export interface ListInputSourcesResponse {
    inputSourceSummaries: InputSourceSummary[];
    nextToken?: string;
}
export interface ListPoliciesRequest {
    accountId?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface PolicySummary {
    policyArn: string;
    name: string;
    availabilitySlo?: AvailabilitySlo;
    multiAz?: MultiAzTargets;
    multiRegion?: MultiRegionTargets;
    dataRecovery?: DataRecoveryTargets;
    sharingEnabled?: boolean;
    organizationId?: string;
    associatedServiceCount?: number;
    createdAt?: Date;
    updatedAt?: Date;
}
export type PolicySummaryList = PolicySummary[];
export interface ListPoliciesResponse {
    policySummaries: PolicySummary[];
    nextToken?: string;
}
export type PolicyEventType = "POLICY_ATTACHED_TO_SERVICE" | "POLICY_DETACHED_FROM_SERVICE" | "POLICY_SHARING_REVOKED" | "POLICY_DELETED" | (string & {});
export type PolicyEventTypeList = PolicyEventType[];
export interface ListPolicyEventsRequest {
    policyArn: string;
    eventTypes?: PolicyEventType[];
    startTime?: Date;
    endTime?: Date;
    maxResults?: number;
    nextToken?: string;
}
export type ActorType = "USER" | "SYSTEM" | (string & {});
export interface EventActor {
    type: ActorType;
    principalId: string;
    accountId?: string;
    userName?: string;
}
export interface PolicyAttachedToServiceMetadata {
    serviceArn?: string;
    accountId?: string;
}
export interface PolicyDetachedFromServiceMetadata {
    serviceArn?: string;
    accountId?: string;
}
export interface PolicySharingRevokedMetadata {
    affectedServiceCount?: number;
}
export interface PolicyDeletedMetadata {
    affectedServiceCount?: number;
}
export type PolicyEventMetadata = {
    policyAttachedToService: PolicyAttachedToServiceMetadata;
    policyDetachedFromService?: never;
    policySharingRevoked?: never;
    policyDeleted?: never;
} | {
    policyAttachedToService?: never;
    policyDetachedFromService: PolicyDetachedFromServiceMetadata;
    policySharingRevoked?: never;
    policyDeleted?: never;
} | {
    policyAttachedToService?: never;
    policyDetachedFromService?: never;
    policySharingRevoked: PolicySharingRevokedMetadata;
    policyDeleted?: never;
} | {
    policyAttachedToService?: never;
    policyDetachedFromService?: never;
    policySharingRevoked?: never;
    policyDeleted: PolicyDeletedMetadata;
};
export interface PolicyEventDetails {
    title: string;
    description: string;
    eventMetadata?: PolicyEventMetadata;
}
export interface PolicyEvent {
    eventId: string;
    timestamp: Date;
    eventType: PolicyEventType;
    policyArn: string;
    actor: EventActor;
    eventDetails: PolicyEventDetails;
}
export type PolicyEventList = PolicyEvent[];
export interface ListPolicyEventsResponse {
    events: PolicyEvent[];
    nextToken?: string;
}
export interface ListReportsRequest {
    serviceArn?: string;
    reportType?: ReportType;
    testRunId?: string;
    maxResults?: number;
    nextToken?: string;
}
export type ReportGenerationResultList = ReportGenerationResult[];
export interface ListReportsResponse {
    reportGenerationResults: ReportGenerationResult[];
    nextToken?: string;
}
export interface ListResolvedTestRunTargetResourcesRequest {
    testRunId: string;
    serviceArn: string;
    maxResults?: number;
    nextToken?: string;
}
export type ResolvedTargetInformationKey = string;
export type ResolvedTargetInformationValue = string;
export type ResolvedTargetInformation = {
    [key: string]: string | undefined;
};
export interface ResolvedTargetResource {
    resourceType: string;
    targetName: string;
    targetInformation: {
        [key: string]: string | undefined;
    };
}
export type ResolvedTargetResourceList = ResolvedTargetResource[];
export interface ListResolvedTestRunTargetResourcesResponse {
    resolvedTargetResources: ResolvedTargetResource[];
    nextToken?: string;
}
export type ResourceTypeFilter = string;
export type ResourceTypeFilterList = string[];
export interface ListResourcesRequest {
    serviceArn: string;
    serviceFunctionId?: string;
    awsRegion?: string;
    resourceTypes?: string[];
    billable?: boolean;
    maxResults?: number;
    nextToken?: string;
}
export interface InputSource {
    identifier: string;
    type: InputSourceType;
}
export interface Resource {
    identifier: string;
    awsRegion?: string;
    awsAccountId?: string;
    resourceType?: string;
}
export interface ServiceResource {
    resourceIdentifier: string;
    inputSource?: InputSource;
    resource: Resource;
}
export type ServiceResourceList = ServiceResource[];
export interface ListResourcesResponse {
    serviceFunctionId?: string;
    serviceResources?: ServiceResource[];
    nextToken?: string;
}
export type ServiceEventType = "SERVICE_CREATED" | "SERVICE_DELETED" | "SERVICE_SYSTEM_ASSOCIATED" | "SERVICE_SYSTEM_DISASSOCIATED" | "SERVICE_RESOURCES_ASSOCIATED" | "SERVICE_RESOURCES_DISASSOCIATED" | "SERVICE_WORKFLOW_UPDATED" | "SERVICE_INPUT_SOURCES_UPDATED" | "SERVICE_POLICY_ASSOCIATED" | "SERVICE_POLICY_DISASSOCIATED" | "SERVICE_FUNCTION_CREATED" | "SERVICE_FUNCTION_UPDATED" | "SERVICE_FUNCTION_DELETED" | "SERVICE_FUNCTION_RESOURCES_ADDED" | "SERVICE_FUNCTION_RESOURCES_REMOVED" | "SERVICE_ACHIEVABILITY_UPDATED" | "ASSERTION_CREATED" | "ASSERTION_UPDATED" | "ASSERTION_DELETED" | (string & {});
export type ServiceEventTypeList = ServiceEventType[];
export interface ListServiceEventsRequest {
    serviceArn: string;
    eventTypes?: ServiceEventType[];
    startTime?: Date;
    endTime?: Date;
    maxResults?: number;
    nextToken?: string;
}
export interface ServiceCreatedMetadata {
}
export interface ServiceDeletedMetadata {
}
export interface ServiceSystemAssociatedMetadata {
    systemName?: string;
    systemArn?: string;
}
export interface ServiceSystemDisassociatedMetadata {
    systemId?: string;
    systemName?: string;
    systemArn?: string;
}
export type ResourceTypeList = string[];
export interface ServiceResourcesAssociatedMetadata {
    resourceCount?: number;
    resourceTypes?: string[];
}
export interface ServiceResourcesDisassociatedMetadata {
    resourceCount?: number;
    resourceTypes?: string[];
}
export interface ServiceWorkflowUpdatedMetadata {
    serviceFunctionId?: string;
    serviceFunctionName?: string;
}
export interface ServiceInputSourcesUpdatedMetadata {
}
export interface ServicePolicyAssociatedMetadata {
    policyName?: string;
    policyArn?: string;
    policyOwnerAccountId?: string;
    policySource?: PolicyValueSource;
}
export type PolicyDisassociationReason = "REPLACED_BY_UPDATE" | "SHARING_REVOKED" | "POLICY_DELETED" | (string & {});
export interface ServicePolicyDisassociatedMetadata {
    policyName?: string;
    policyArn?: string;
    policyOwnerAccountId?: string;
    policySource?: PolicyValueSource;
    reason?: PolicyDisassociationReason;
}
export interface ServiceFunctionCreatedMetadata {
    serviceFunctionId?: string;
    serviceFunctionName?: string;
}
export type ArnList = string[];
export interface ServiceFunctionUpdatedMetadata {
    serviceFunctionId?: string;
    serviceFunctionName?: string;
    resourcesAdded?: string[];
    resourcesRemoved?: string[];
}
export interface ServiceFunctionDeletedMetadata {
    serviceFunctionId?: string;
    serviceFunctionName?: string;
}
export interface ServiceFunctionResourcesAddedMetadata {
    serviceFunctionId?: string;
    serviceFunctionName?: string;
    resourcesAdded?: string[];
}
export interface ServiceFunctionResourcesRemovedMetadata {
    serviceFunctionId?: string;
    serviceFunctionName?: string;
    resourcesRemoved?: string[];
}
export interface ServiceAchievabilityUpdatedMetadata {
    assessmentId?: string;
    availabilitySlo?: string;
    multiAzRtoRpo?: string;
    multiRegionRtoRpo?: string;
}
export interface AssertionCreatedMetadata {
    assertionId?: string;
    assertionName?: string;
}
export interface AssertionUpdatedMetadata {
    assertionId?: string;
    assertionName?: string;
}
export interface AssertionDeletedMetadata {
    assertionId?: string;
    assertionName?: string;
}
export type ServiceEventMetadata = {
    serviceCreated: ServiceCreatedMetadata;
    serviceDeleted?: never;
    serviceSystemAssociated?: never;
    serviceSystemDisassociated?: never;
    serviceResourcesAssociated?: never;
    serviceResourcesDisassociated?: never;
    serviceWorkflowUpdated?: never;
    serviceInputSourcesUpdated?: never;
    servicePolicyAssociated?: never;
    servicePolicyDisassociated?: never;
    serviceFunctionCreated?: never;
    serviceFunctionUpdated?: never;
    serviceFunctionDeleted?: never;
    serviceFunctionResourcesAdded?: never;
    serviceFunctionResourcesRemoved?: never;
    serviceAchievabilityUpdated?: never;
    assertionCreated?: never;
    assertionUpdated?: never;
    assertionDeleted?: never;
} | {
    serviceCreated?: never;
    serviceDeleted: ServiceDeletedMetadata;
    serviceSystemAssociated?: never;
    serviceSystemDisassociated?: never;
    serviceResourcesAssociated?: never;
    serviceResourcesDisassociated?: never;
    serviceWorkflowUpdated?: never;
    serviceInputSourcesUpdated?: never;
    servicePolicyAssociated?: never;
    servicePolicyDisassociated?: never;
    serviceFunctionCreated?: never;
    serviceFunctionUpdated?: never;
    serviceFunctionDeleted?: never;
    serviceFunctionResourcesAdded?: never;
    serviceFunctionResourcesRemoved?: never;
    serviceAchievabilityUpdated?: never;
    assertionCreated?: never;
    assertionUpdated?: never;
    assertionDeleted?: never;
} | {
    serviceCreated?: never;
    serviceDeleted?: never;
    serviceSystemAssociated: ServiceSystemAssociatedMetadata;
    serviceSystemDisassociated?: never;
    serviceResourcesAssociated?: never;
    serviceResourcesDisassociated?: never;
    serviceWorkflowUpdated?: never;
    serviceInputSourcesUpdated?: never;
    servicePolicyAssociated?: never;
    servicePolicyDisassociated?: never;
    serviceFunctionCreated?: never;
    serviceFunctionUpdated?: never;
    serviceFunctionDeleted?: never;
    serviceFunctionResourcesAdded?: never;
    serviceFunctionResourcesRemoved?: never;
    serviceAchievabilityUpdated?: never;
    assertionCreated?: never;
    assertionUpdated?: never;
    assertionDeleted?: never;
} | {
    serviceCreated?: never;
    serviceDeleted?: never;
    serviceSystemAssociated?: never;
    serviceSystemDisassociated: ServiceSystemDisassociatedMetadata;
    serviceResourcesAssociated?: never;
    serviceResourcesDisassociated?: never;
    serviceWorkflowUpdated?: never;
    serviceInputSourcesUpdated?: never;
    servicePolicyAssociated?: never;
    servicePolicyDisassociated?: never;
    serviceFunctionCreated?: never;
    serviceFunctionUpdated?: never;
    serviceFunctionDeleted?: never;
    serviceFunctionResourcesAdded?: never;
    serviceFunctionResourcesRemoved?: never;
    serviceAchievabilityUpdated?: never;
    assertionCreated?: never;
    assertionUpdated?: never;
    assertionDeleted?: never;
} | {
    serviceCreated?: never;
    serviceDeleted?: never;
    serviceSystemAssociated?: never;
    serviceSystemDisassociated?: never;
    serviceResourcesAssociated: ServiceResourcesAssociatedMetadata;
    serviceResourcesDisassociated?: never;
    serviceWorkflowUpdated?: never;
    serviceInputSourcesUpdated?: never;
    servicePolicyAssociated?: never;
    servicePolicyDisassociated?: never;
    serviceFunctionCreated?: never;
    serviceFunctionUpdated?: never;
    serviceFunctionDeleted?: never;
    serviceFunctionResourcesAdded?: never;
    serviceFunctionResourcesRemoved?: never;
    serviceAchievabilityUpdated?: never;
    assertionCreated?: never;
    assertionUpdated?: never;
    assertionDeleted?: never;
} | {
    serviceCreated?: never;
    serviceDeleted?: never;
    serviceSystemAssociated?: never;
    serviceSystemDisassociated?: never;
    serviceResourcesAssociated?: never;
    serviceResourcesDisassociated: ServiceResourcesDisassociatedMetadata;
    serviceWorkflowUpdated?: never;
    serviceInputSourcesUpdated?: never;
    servicePolicyAssociated?: never;
    servicePolicyDisassociated?: never;
    serviceFunctionCreated?: never;
    serviceFunctionUpdated?: never;
    serviceFunctionDeleted?: never;
    serviceFunctionResourcesAdded?: never;
    serviceFunctionResourcesRemoved?: never;
    serviceAchievabilityUpdated?: never;
    assertionCreated?: never;
    assertionUpdated?: never;
    assertionDeleted?: never;
} | {
    serviceCreated?: never;
    serviceDeleted?: never;
    serviceSystemAssociated?: never;
    serviceSystemDisassociated?: never;
    serviceResourcesAssociated?: never;
    serviceResourcesDisassociated?: never;
    serviceWorkflowUpdated: ServiceWorkflowUpdatedMetadata;
    serviceInputSourcesUpdated?: never;
    servicePolicyAssociated?: never;
    servicePolicyDisassociated?: never;
    serviceFunctionCreated?: never;
    serviceFunctionUpdated?: never;
    serviceFunctionDeleted?: never;
    serviceFunctionResourcesAdded?: never;
    serviceFunctionResourcesRemoved?: never;
    serviceAchievabilityUpdated?: never;
    assertionCreated?: never;
    assertionUpdated?: never;
    assertionDeleted?: never;
} | {
    serviceCreated?: never;
    serviceDeleted?: never;
    serviceSystemAssociated?: never;
    serviceSystemDisassociated?: never;
    serviceResourcesAssociated?: never;
    serviceResourcesDisassociated?: never;
    serviceWorkflowUpdated?: never;
    serviceInputSourcesUpdated: ServiceInputSourcesUpdatedMetadata;
    servicePolicyAssociated?: never;
    servicePolicyDisassociated?: never;
    serviceFunctionCreated?: never;
    serviceFunctionUpdated?: never;
    serviceFunctionDeleted?: never;
    serviceFunctionResourcesAdded?: never;
    serviceFunctionResourcesRemoved?: never;
    serviceAchievabilityUpdated?: never;
    assertionCreated?: never;
    assertionUpdated?: never;
    assertionDeleted?: never;
} | {
    serviceCreated?: never;
    serviceDeleted?: never;
    serviceSystemAssociated?: never;
    serviceSystemDisassociated?: never;
    serviceResourcesAssociated?: never;
    serviceResourcesDisassociated?: never;
    serviceWorkflowUpdated?: never;
    serviceInputSourcesUpdated?: never;
    servicePolicyAssociated: ServicePolicyAssociatedMetadata;
    servicePolicyDisassociated?: never;
    serviceFunctionCreated?: never;
    serviceFunctionUpdated?: never;
    serviceFunctionDeleted?: never;
    serviceFunctionResourcesAdded?: never;
    serviceFunctionResourcesRemoved?: never;
    serviceAchievabilityUpdated?: never;
    assertionCreated?: never;
    assertionUpdated?: never;
    assertionDeleted?: never;
} | {
    serviceCreated?: never;
    serviceDeleted?: never;
    serviceSystemAssociated?: never;
    serviceSystemDisassociated?: never;
    serviceResourcesAssociated?: never;
    serviceResourcesDisassociated?: never;
    serviceWorkflowUpdated?: never;
    serviceInputSourcesUpdated?: never;
    servicePolicyAssociated?: never;
    servicePolicyDisassociated: ServicePolicyDisassociatedMetadata;
    serviceFunctionCreated?: never;
    serviceFunctionUpdated?: never;
    serviceFunctionDeleted?: never;
    serviceFunctionResourcesAdded?: never;
    serviceFunctionResourcesRemoved?: never;
    serviceAchievabilityUpdated?: never;
    assertionCreated?: never;
    assertionUpdated?: never;
    assertionDeleted?: never;
} | {
    serviceCreated?: never;
    serviceDeleted?: never;
    serviceSystemAssociated?: never;
    serviceSystemDisassociated?: never;
    serviceResourcesAssociated?: never;
    serviceResourcesDisassociated?: never;
    serviceWorkflowUpdated?: never;
    serviceInputSourcesUpdated?: never;
    servicePolicyAssociated?: never;
    servicePolicyDisassociated?: never;
    serviceFunctionCreated: ServiceFunctionCreatedMetadata;
    serviceFunctionUpdated?: never;
    serviceFunctionDeleted?: never;
    serviceFunctionResourcesAdded?: never;
    serviceFunctionResourcesRemoved?: never;
    serviceAchievabilityUpdated?: never;
    assertionCreated?: never;
    assertionUpdated?: never;
    assertionDeleted?: never;
} | {
    serviceCreated?: never;
    serviceDeleted?: never;
    serviceSystemAssociated?: never;
    serviceSystemDisassociated?: never;
    serviceResourcesAssociated?: never;
    serviceResourcesDisassociated?: never;
    serviceWorkflowUpdated?: never;
    serviceInputSourcesUpdated?: never;
    servicePolicyAssociated?: never;
    servicePolicyDisassociated?: never;
    serviceFunctionCreated?: never;
    serviceFunctionUpdated: ServiceFunctionUpdatedMetadata;
    serviceFunctionDeleted?: never;
    serviceFunctionResourcesAdded?: never;
    serviceFunctionResourcesRemoved?: never;
    serviceAchievabilityUpdated?: never;
    assertionCreated?: never;
    assertionUpdated?: never;
    assertionDeleted?: never;
} | {
    serviceCreated?: never;
    serviceDeleted?: never;
    serviceSystemAssociated?: never;
    serviceSystemDisassociated?: never;
    serviceResourcesAssociated?: never;
    serviceResourcesDisassociated?: never;
    serviceWorkflowUpdated?: never;
    serviceInputSourcesUpdated?: never;
    servicePolicyAssociated?: never;
    servicePolicyDisassociated?: never;
    serviceFunctionCreated?: never;
    serviceFunctionUpdated?: never;
    serviceFunctionDeleted: ServiceFunctionDeletedMetadata;
    serviceFunctionResourcesAdded?: never;
    serviceFunctionResourcesRemoved?: never;
    serviceAchievabilityUpdated?: never;
    assertionCreated?: never;
    assertionUpdated?: never;
    assertionDeleted?: never;
} | {
    serviceCreated?: never;
    serviceDeleted?: never;
    serviceSystemAssociated?: never;
    serviceSystemDisassociated?: never;
    serviceResourcesAssociated?: never;
    serviceResourcesDisassociated?: never;
    serviceWorkflowUpdated?: never;
    serviceInputSourcesUpdated?: never;
    servicePolicyAssociated?: never;
    servicePolicyDisassociated?: never;
    serviceFunctionCreated?: never;
    serviceFunctionUpdated?: never;
    serviceFunctionDeleted?: never;
    serviceFunctionResourcesAdded: ServiceFunctionResourcesAddedMetadata;
    serviceFunctionResourcesRemoved?: never;
    serviceAchievabilityUpdated?: never;
    assertionCreated?: never;
    assertionUpdated?: never;
    assertionDeleted?: never;
} | {
    serviceCreated?: never;
    serviceDeleted?: never;
    serviceSystemAssociated?: never;
    serviceSystemDisassociated?: never;
    serviceResourcesAssociated?: never;
    serviceResourcesDisassociated?: never;
    serviceWorkflowUpdated?: never;
    serviceInputSourcesUpdated?: never;
    servicePolicyAssociated?: never;
    servicePolicyDisassociated?: never;
    serviceFunctionCreated?: never;
    serviceFunctionUpdated?: never;
    serviceFunctionDeleted?: never;
    serviceFunctionResourcesAdded?: never;
    serviceFunctionResourcesRemoved: ServiceFunctionResourcesRemovedMetadata;
    serviceAchievabilityUpdated?: never;
    assertionCreated?: never;
    assertionUpdated?: never;
    assertionDeleted?: never;
} | {
    serviceCreated?: never;
    serviceDeleted?: never;
    serviceSystemAssociated?: never;
    serviceSystemDisassociated?: never;
    serviceResourcesAssociated?: never;
    serviceResourcesDisassociated?: never;
    serviceWorkflowUpdated?: never;
    serviceInputSourcesUpdated?: never;
    servicePolicyAssociated?: never;
    servicePolicyDisassociated?: never;
    serviceFunctionCreated?: never;
    serviceFunctionUpdated?: never;
    serviceFunctionDeleted?: never;
    serviceFunctionResourcesAdded?: never;
    serviceFunctionResourcesRemoved?: never;
    serviceAchievabilityUpdated: ServiceAchievabilityUpdatedMetadata;
    assertionCreated?: never;
    assertionUpdated?: never;
    assertionDeleted?: never;
} | {
    serviceCreated?: never;
    serviceDeleted?: never;
    serviceSystemAssociated?: never;
    serviceSystemDisassociated?: never;
    serviceResourcesAssociated?: never;
    serviceResourcesDisassociated?: never;
    serviceWorkflowUpdated?: never;
    serviceInputSourcesUpdated?: never;
    servicePolicyAssociated?: never;
    servicePolicyDisassociated?: never;
    serviceFunctionCreated?: never;
    serviceFunctionUpdated?: never;
    serviceFunctionDeleted?: never;
    serviceFunctionResourcesAdded?: never;
    serviceFunctionResourcesRemoved?: never;
    serviceAchievabilityUpdated?: never;
    assertionCreated: AssertionCreatedMetadata;
    assertionUpdated?: never;
    assertionDeleted?: never;
} | {
    serviceCreated?: never;
    serviceDeleted?: never;
    serviceSystemAssociated?: never;
    serviceSystemDisassociated?: never;
    serviceResourcesAssociated?: never;
    serviceResourcesDisassociated?: never;
    serviceWorkflowUpdated?: never;
    serviceInputSourcesUpdated?: never;
    servicePolicyAssociated?: never;
    servicePolicyDisassociated?: never;
    serviceFunctionCreated?: never;
    serviceFunctionUpdated?: never;
    serviceFunctionDeleted?: never;
    serviceFunctionResourcesAdded?: never;
    serviceFunctionResourcesRemoved?: never;
    serviceAchievabilityUpdated?: never;
    assertionCreated?: never;
    assertionUpdated: AssertionUpdatedMetadata;
    assertionDeleted?: never;
} | {
    serviceCreated?: never;
    serviceDeleted?: never;
    serviceSystemAssociated?: never;
    serviceSystemDisassociated?: never;
    serviceResourcesAssociated?: never;
    serviceResourcesDisassociated?: never;
    serviceWorkflowUpdated?: never;
    serviceInputSourcesUpdated?: never;
    servicePolicyAssociated?: never;
    servicePolicyDisassociated?: never;
    serviceFunctionCreated?: never;
    serviceFunctionUpdated?: never;
    serviceFunctionDeleted?: never;
    serviceFunctionResourcesAdded?: never;
    serviceFunctionResourcesRemoved?: never;
    serviceAchievabilityUpdated?: never;
    assertionCreated?: never;
    assertionUpdated?: never;
    assertionDeleted: AssertionDeletedMetadata;
};
export interface ServiceEventDetails {
    title: string;
    description: string;
    eventMetadata?: ServiceEventMetadata;
}
export interface ServiceEvent {
    eventId: string;
    timestamp: Date;
    eventType: ServiceEventType;
    serviceArn: string;
    actor: EventActor;
    eventDetails: ServiceEventDetails;
}
export type ServiceEventList = ServiceEvent[];
export interface ListServiceEventsResponse {
    events: ServiceEvent[];
    nextToken?: string;
}
export interface ListServiceFunctionsRequest {
    serviceArn: string;
    maxResults?: number;
    nextToken?: string;
}
export type ServiceFunctionList = ServiceFunction[];
export interface ListServiceFunctionsResponse {
    serviceFunctions: ServiceFunction[];
    nextToken?: string;
}
export interface ListServicesRequest {
    systemArn?: string;
    userJourneyId?: string;
    ouId?: string;
    accountId?: string;
    assessmentStatus?: AssessmentStatus;
    policyArn?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface ServiceSummary {
    serviceArn: string;
    name: string;
    associatedSystems?: AssociatedSystem[];
    regions?: string[];
    policyArn?: string;
    assessmentStatus?: AssessmentStatus;
    openFindingsCount?: number;
    resolvedFindingsCount?: number;
    dependencyDiscovery?: DependencyDiscoveryConfig;
    achievability?: Achievability;
    organizationId?: string;
    ouId?: string;
    accountId?: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export type ServiceSummaryList = ServiceSummary[];
export interface ListServicesResponse {
    serviceSummaries: ServiceSummary[];
    nextToken?: string;
}
export interface ListServiceTopologyEdgesRequest {
    serviceArn: string;
    maxResults?: number;
    nextToken?: string;
}
export type TopologyType = "CONTAINMENT" | "DATA_FLOW" | "OBSERVABILITY" | "PERMISSIONS" | (string & {});
export interface EdgePropertySummary {
    topologyType?: TopologyType;
    label?: string;
}
export type EdgePropertyList = EdgePropertySummary[];
export interface ServiceTopologyEdgeSummary {
    sourceResourceIdentifier: string;
    destinationResourceIdentifier: string;
    sourceRegion?: string;
    destinationRegion?: string;
    sourceAccount?: string;
    destinationAccount?: string;
    properties?: EdgePropertySummary[];
}
export type ServiceTopologyEdgeSummaryList = ServiceTopologyEdgeSummary[];
export interface ListServiceTopologyEdgesResponse {
    serviceTopologyEdgeSummaries?: ServiceTopologyEdgeSummary[];
    nextToken?: string;
}
export type SystemEventType = "SYSTEM_CREATED" | "SYSTEM_DELETED" | "SYSTEM_USER_JOURNEY_CREATED" | "SYSTEM_USER_JOURNEY_UPDATED" | "SYSTEM_USER_JOURNEY_DELETED" | "SYSTEM_SERVICE_ASSOCIATED" | "SYSTEM_SERVICE_DISASSOCIATED" | "SYSTEM_POLICY_ASSOCIATED" | "SYSTEM_POLICY_DISASSOCIATED" | (string & {});
export type SystemEventTypeList = SystemEventType[];
export interface ListSystemEventsRequest {
    systemArn: string;
    eventTypes?: SystemEventType[];
    startTime?: Date;
    endTime?: Date;
    maxResults?: number;
    nextToken?: string;
}
export interface SystemCreatedMetadata {
}
export interface SystemDeletedMetadata {
}
export interface ServiceReference {
    serviceId?: string;
    serviceName?: string;
}
export type ServiceReferenceList = ServiceReference[];
export interface SystemUserJourneyCreatedMetadata {
    userJourneyName?: string;
    associatedServices?: ServiceReference[];
}
export interface StringChange {
    oldValue?: string;
    newValue?: string;
}
export interface ServiceReferenceChanges {
    added?: ServiceReference[];
    removed?: ServiceReference[];
}
export interface UserJourneyChanges {
    journeyDescription?: StringChange;
    associatedServices?: ServiceReferenceChanges;
}
export interface SystemUserJourneyUpdatedMetadata {
    userJourneyName?: string;
    changes?: UserJourneyChanges;
}
export interface SystemUserJourneyDeletedMetadata {
    userJourneyName?: string;
    associatedServicesAtDeletion?: ServiceReference[];
}
export type UserJourneyNameList = string[];
export interface SystemServiceAssociatedMetadata {
    serviceName?: string;
    serviceArn?: string;
    userJourneys?: string[];
}
export interface SystemServiceDisassociatedMetadata {
    serviceName?: string;
    serviceArn?: string;
    userJourneysAffected?: string[];
    comment?: string;
}
export interface SystemPolicyAssociatedMetadata {
    policyName?: string;
    policyArn?: string;
}
export interface SystemPolicyDisassociatedMetadata {
    policyName?: string;
    policyArn?: string;
}
export type SystemEventMetadata = {
    systemCreated: SystemCreatedMetadata;
    systemDeleted?: never;
    systemUserJourneyCreated?: never;
    systemUserJourneyUpdated?: never;
    systemUserJourneyDeleted?: never;
    systemServiceAssociated?: never;
    systemServiceDisassociated?: never;
    systemPolicyAssociated?: never;
    systemPolicyDisassociated?: never;
} | {
    systemCreated?: never;
    systemDeleted: SystemDeletedMetadata;
    systemUserJourneyCreated?: never;
    systemUserJourneyUpdated?: never;
    systemUserJourneyDeleted?: never;
    systemServiceAssociated?: never;
    systemServiceDisassociated?: never;
    systemPolicyAssociated?: never;
    systemPolicyDisassociated?: never;
} | {
    systemCreated?: never;
    systemDeleted?: never;
    systemUserJourneyCreated: SystemUserJourneyCreatedMetadata;
    systemUserJourneyUpdated?: never;
    systemUserJourneyDeleted?: never;
    systemServiceAssociated?: never;
    systemServiceDisassociated?: never;
    systemPolicyAssociated?: never;
    systemPolicyDisassociated?: never;
} | {
    systemCreated?: never;
    systemDeleted?: never;
    systemUserJourneyCreated?: never;
    systemUserJourneyUpdated: SystemUserJourneyUpdatedMetadata;
    systemUserJourneyDeleted?: never;
    systemServiceAssociated?: never;
    systemServiceDisassociated?: never;
    systemPolicyAssociated?: never;
    systemPolicyDisassociated?: never;
} | {
    systemCreated?: never;
    systemDeleted?: never;
    systemUserJourneyCreated?: never;
    systemUserJourneyUpdated?: never;
    systemUserJourneyDeleted: SystemUserJourneyDeletedMetadata;
    systemServiceAssociated?: never;
    systemServiceDisassociated?: never;
    systemPolicyAssociated?: never;
    systemPolicyDisassociated?: never;
} | {
    systemCreated?: never;
    systemDeleted?: never;
    systemUserJourneyCreated?: never;
    systemUserJourneyUpdated?: never;
    systemUserJourneyDeleted?: never;
    systemServiceAssociated: SystemServiceAssociatedMetadata;
    systemServiceDisassociated?: never;
    systemPolicyAssociated?: never;
    systemPolicyDisassociated?: never;
} | {
    systemCreated?: never;
    systemDeleted?: never;
    systemUserJourneyCreated?: never;
    systemUserJourneyUpdated?: never;
    systemUserJourneyDeleted?: never;
    systemServiceAssociated?: never;
    systemServiceDisassociated: SystemServiceDisassociatedMetadata;
    systemPolicyAssociated?: never;
    systemPolicyDisassociated?: never;
} | {
    systemCreated?: never;
    systemDeleted?: never;
    systemUserJourneyCreated?: never;
    systemUserJourneyUpdated?: never;
    systemUserJourneyDeleted?: never;
    systemServiceAssociated?: never;
    systemServiceDisassociated?: never;
    systemPolicyAssociated: SystemPolicyAssociatedMetadata;
    systemPolicyDisassociated?: never;
} | {
    systemCreated?: never;
    systemDeleted?: never;
    systemUserJourneyCreated?: never;
    systemUserJourneyUpdated?: never;
    systemUserJourneyDeleted?: never;
    systemServiceAssociated?: never;
    systemServiceDisassociated?: never;
    systemPolicyAssociated?: never;
    systemPolicyDisassociated: SystemPolicyDisassociatedMetadata;
};
export interface SystemEventDetails {
    title: string;
    description: string;
    eventMetadata?: SystemEventMetadata;
}
export interface SystemEvent {
    eventId: string;
    timestamp: Date;
    eventType: SystemEventType;
    systemArn: string;
    actor: EventActor;
    eventDetails: SystemEventDetails;
}
export type SystemEventList = SystemEvent[];
export interface ListSystemEventsResponse {
    events: SystemEvent[];
    nextToken?: string;
}
export interface ListSystemsRequest {
    ouId?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface SystemSummary {
    systemId: string;
    name: string;
    systemArn?: string;
    userJourneysCount?: number;
    servicesCount?: number;
    organizationId?: string;
    ouId?: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export type SystemSummaryList = SystemSummary[];
export interface ListSystemsResponse {
    systemSummaries: SystemSummary[];
    nextToken?: string;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListTestRunDependenciesRequest {
    testRunId: string;
    serviceArn: string;
    maxResults?: number;
    nextToken?: string;
}
export type TestRunDependencySource = "DISCOVERED" | "MANUAL" | (string & {});
export interface TestRunDependencySummary {
    dependencyId?: string;
    dependencyName: string;
    dnsName: string;
    criticality: DependencyCriticality;
    source: TestRunDependencySource;
    location?: string;
    sourceRegions?: string[];
    provider?: string;
}
export type TestRunDependencySummaryList = TestRunDependencySummary[];
export interface ListTestRunDependenciesResponse {
    dependencies: TestRunDependencySummary[];
    nextToken?: string;
}
export interface ListTestRunEventsRequest {
    testRunId: string;
    serviceArn: string;
    startedAt?: Date;
    endedAt?: Date;
    maxResults?: number;
    nextToken?: string;
}
export type TestRunEventAttributeKey = string;
export type TestRunEventAttributeValue = string;
export type TestRunEventAttributes = {
    [key: string]: string | undefined;
};
export interface TestRunEvent {
    eventId: string;
    eventType: string;
    message: string;
    timestamp: Date;
    attributes?: {
        [key: string]: string | undefined;
    };
}
export type TestRunEventList = TestRunEvent[];
export interface ListTestRunEventsResponse {
    events: TestRunEvent[];
    nextToken?: string;
}
export interface ListTestRunsRequest {
    serviceArn: string;
    testId?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface TestRunSummary {
    testRunId: string;
    status: TestRunStatus;
    startedAt: Date;
    endedAt?: Date;
    testTemplateArn: string;
    serviceArn?: string;
    errorMessage?: string;
    accountTargeting?: AccountTargeting;
}
export type TestRunSummaryList = TestRunSummary[];
export interface ListTestRunsResponse {
    testRuns: TestRunSummary[];
    nextToken?: string;
}
export type TestRunSourceArn = string;
export interface ListTestRunSourceEventsRequest {
    testRunId: string;
    serviceArn: string;
    sourceArn: string;
    maxResults?: number;
    nextToken?: string;
}
export type TestRunSourceEventType = "ALARM" | (string & {});
export type AlarmState = "OK" | "ALARM" | "INSUFFICIENT_DATA" | (string & {});
export interface AlarmStateChangeDetail {
    state: AlarmState;
    previousState?: AlarmState;
    reason?: string;
}
export type TestRunSourceEventErrorCode = "ACCESS_DENIED" | "INTERNAL_ERROR" | (string & {});
export interface TestRunSourceEventError {
    errorCode: TestRunSourceEventErrorCode;
    errorMessage: string;
}
export type TestRunSourceEventDetail = {
    alarmStateChange: AlarmStateChangeDetail;
    error?: never;
} | {
    alarmStateChange?: never;
    error: TestRunSourceEventError;
};
export interface TestRunSourceEvent {
    timestamp: Date;
    sourceArn: string;
    eventType: TestRunSourceEventType;
    detail: TestRunSourceEventDetail;
}
export type TestRunSourceEventList = TestRunSourceEvent[];
export interface ListTestRunSourceEventsResponse {
    testRunSourceEvents: TestRunSourceEvent[];
    nextToken?: string;
}
export type TestRunSourceType = "SUCCESS_CRITERIA" | "OBSERVABILITY" | (string & {});
export interface ListTestRunSourcesRequest {
    testRunId: string;
    serviceArn: string;
    type?: TestRunSourceType;
    maxResults?: number;
    nextToken?: string;
}
export type TestSourceOutcome = "PASSED" | "FAILED" | "ERROR" | (string & {});
export interface TestRunSuccessCriteriaAlarmSummary {
    alarmArn: string;
    alarmName: string;
    region: string;
    accountId: string;
    outcome?: TestSourceOutcome;
    outcomeReason?: string;
}
export interface TestRunObservabilityAlarmSummary {
    alarmArn: string;
    alarmName: string;
    region: string;
    accountId: string;
}
export type TestRunSourceSummary = {
    successCriteriaAlarm: TestRunSuccessCriteriaAlarmSummary;
    observabilityAlarm?: never;
} | {
    successCriteriaAlarm?: never;
    observabilityAlarm: TestRunObservabilityAlarmSummary;
};
export type TestRunSourceSummaryList = TestRunSourceSummary[];
export interface ListTestRunSourcesResponse {
    testRunSources: TestRunSourceSummary[];
    nextToken?: string;
}
export interface ListTestsRequest {
    serviceArn: string;
    maxResults?: number;
    nextToken?: string;
}
export interface TestSummary {
    testId: string;
    testTemplateArn: string;
    serviceArn: string;
    totalTestRuns: number;
    successfulTestRuns: number;
    creationTime: Date;
}
export type TestSummaryList = TestSummary[];
export interface ListTestsResponse {
    tests: TestSummary[];
    nextToken?: string;
}
export type TestSourceType = "SUCCESS_CRITERIA" | "OBSERVABILITY" | (string & {});
export interface ListTestSourcesRequest {
    testId: string;
    serviceArn: string;
    type?: TestSourceType;
    maxResults?: number;
    nextToken?: string;
}
export interface SuccessCriteriaAlarmSummary {
    alarmArn: string;
    alarmName: string;
    region: string;
    accountId: string;
    createdAt?: Date;
}
export interface ObservabilityAlarmSummary {
    alarmArn: string;
    alarmName: string;
    region: string;
    accountId: string;
    createdAt?: Date;
}
export type TestSourceSummary = {
    successCriteriaAlarm: SuccessCriteriaAlarmSummary;
    observabilityAlarm?: never;
} | {
    successCriteriaAlarm?: never;
    observabilityAlarm: ObservabilityAlarmSummary;
};
export type TestSourceSummaryList = TestSourceSummary[];
export interface ListTestSourcesResponse {
    testSources: TestSourceSummary[];
    nextToken?: string;
}
export interface ListTestTemplatesRequest {
}
export interface TestTemplateSummary {
    testTemplateArn: string;
    name: string;
    description: string;
}
export type TestTemplateSummaryList = TestTemplateSummary[];
export interface ListTestTemplatesResponse {
    testTemplates: TestTemplateSummary[];
}
export interface ListUserJourneysRequest {
    systemArn: string;
    maxResults?: number;
    nextToken?: string;
}
export interface UserJourneySummary {
    userJourneyId: string;
    name: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export type UserJourneySummaryList = UserJourneySummary[];
export interface ListUserJourneysResponse {
    userJourneySummaries: UserJourneySummary[];
    nextToken?: string;
}
export interface PutTestSourcesRequest {
    testId: string;
    serviceArn: string;
    testSources: TestSourceInput[];
}
export interface PutTestSourcesResponse {
}
export interface StartDependencyInsightsRequest {
    serviceArn: string;
    clientToken?: string;
}
export interface StartDependencyInsightsResponse {
    status: DependencyInsightsStatus;
}
export interface StartFailureModeAssessmentRequest {
    serviceArn: string;
    clientToken?: string;
}
export interface StartFailureModeAssessmentResponse {
    assessmentId?: string;
    serviceArn?: string;
    assessmentStatus?: AssessmentStatus;
    startedAt?: Date;
}
export interface StartTestRunRequest {
    testId: string;
    serviceArn: string;
}
export type ExperimentArnList = string[];
export interface StartTestRunResponse {
    testRunId: string;
    status: TestRunStatus;
    experimentArns: string[];
}
export interface StopTestRunRequest {
    testRunId: string;
    serviceArn: string;
}
export interface StopTestRunResponse {
    testRunId: string;
    status: TestRunStatus;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAssertionRequest {
    serviceArn: string;
    assertionId: string;
    text?: string;
}
export interface UpdateAssertionResponse {
    assertion: Assertion;
}
export interface UpdateDependencyRequest {
    serviceArn: string;
    dependencyId: string;
    criticality?: DependencyCriticality;
    comment?: string;
}
export interface UpdateDependencyResponse {
    dependencyId: string;
    dependencyName: string;
    location: string;
    criticality: DependencyCriticality;
    comment?: string;
    provider?: string;
    updatedAt: Date;
}
export interface UpdateFailureModeFindingRequest {
    findingId: string;
    status: FindingStatus;
    serviceArn: string;
    comment?: string;
}
export interface UpdateFailureModeFindingResponse {
    finding?: Finding;
}
export interface UpdatePolicyRequest {
    policyArn: string;
    description?: string;
    availabilitySlo?: AvailabilitySlo;
    multiAz?: MultiAzTargets;
    multiRegion?: MultiRegionTargets;
    dataRecovery?: DataRecoveryTargets;
    sharingEnabled?: boolean;
}
export interface UpdatePolicyResponse {
    policy: Policy;
}
export interface UpdateServiceRequest {
    serviceArn: string;
    description?: string;
    associatedSystems?: AssociatedSystem[];
    policyArn?: string;
    regions?: string[];
    permissionModel?: PermissionModel;
    dependencyDiscovery?: DependencyDiscoveryInput;
    reportConfiguration?: ServiceReportConfiguration;
}
export interface UpdateServiceResponse {
    service: Service;
}
export interface UpdateServiceFunctionRequest {
    serviceArn: string;
    serviceFunctionId: string;
    name?: string;
    description?: string;
    criticality?: ServiceFunctionCriticality;
}
export interface UpdateServiceFunctionResponse {
    serviceFunction: ServiceFunction;
}
export interface UpdateSystemRequest {
    systemArn: string;
    description?: string;
    sharingEnabled?: boolean;
}
export interface UpdateSystemResponse {
    system: System;
}
export interface UpdateTestRequest {
    testId: string;
    serviceArn: string;
    loggingConfiguration?: LoggingConfiguration;
    stopConditions?: StopCondition[];
    roleName?: string;
    parameters?: {
        [key: string]: string[] | undefined;
    };
}
export interface UpdateTestResponse {
    test: Test;
}
export interface UpdateUserJourneyRequest {
    systemArn: string;
    userJourneyId: string;
    name?: string;
    description?: string;
    policyArn?: string;
}
export interface UpdateUserJourneyResponse {
    userJourney: UserJourney;
}
export type ValidationExceptionReason = "INVALID_FIELD_VALUE" | "DUPLICATE_VALUE" | "MISSING_REQUIRED_FIELD" | "OTHER" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type CreateAssertionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a resilience assertion for a service.
 */
export declare const createAssertion: API.OperationMethod<CreateAssertionRequest, CreateAssertionResponse, CreateAssertionError, Credentials | HttpClient.HttpClient>;
export type CreateInputSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates an input source for a service.
 */
export declare const createInputSource: API.OperationMethod<CreateInputSourceRequest, CreateInputSourceResponse, CreateInputSourceError, Credentials | HttpClient.HttpClient>;
export type CreatePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a resilience policy that defines availability and disaster recovery requirements.
 */
export declare const createPolicy: API.OperationMethod<CreatePolicyRequest, CreatePolicyResponse, CreatePolicyError, Credentials | HttpClient.HttpClient>;
export type CreateReportError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * On-demand report creation. Idempotent -- duplicate requests with same clientToken return existing result.
 */
export declare const createReport: API.OperationMethod<CreateReportRequest, CreateReportResponse, CreateReportError, Credentials | HttpClient.HttpClient>;
export type CreateServiceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a service.
 */
export declare const createService: API.OperationMethod<CreateServiceRequest, CreateServiceResponse, CreateServiceError, Credentials | HttpClient.HttpClient>;
export type CreateServiceFunctionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a service function within a service.
 */
export declare const createServiceFunction: API.OperationMethod<CreateServiceFunctionRequest, CreateServiceFunctionResponse, CreateServiceFunctionError, Credentials | HttpClient.HttpClient>;
export type CreateServiceFunctionResourcesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Associates resources with a service function.
 */
export declare const createServiceFunctionResources: API.OperationMethod<CreateServiceFunctionResourcesRequest, CreateServiceFunctionResourcesResponse, CreateServiceFunctionResourcesError, Credentials | HttpClient.HttpClient>;
export type CreateSystemError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a system that represents a logical grouping of services.
 */
export declare const createSystem: API.OperationMethod<CreateSystemRequest, CreateSystemResponse, CreateSystemError, Credentials | HttpClient.HttpClient>;
export type CreateTestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates a test for a service by configuring a test template. Each service has one test per template.
 */
export declare const createTest: API.OperationMethod<CreateTestRequest, CreateTestResponse, CreateTestError, Credentials | HttpClient.HttpClient>;
export type CreateUserJourneyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a user journey within a system.
 */
export declare const createUserJourney: API.OperationMethod<CreateUserJourneyRequest, CreateUserJourneyResponse, CreateUserJourneyError, Credentials | HttpClient.HttpClient>;
export type DeleteAssertionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a resilience assertion from a service.
 */
export declare const deleteAssertion: API.OperationMethod<DeleteAssertionRequest, DeleteAssertionResponse, DeleteAssertionError, Credentials | HttpClient.HttpClient>;
export type DeleteInputSourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an input source.
 */
export declare const deleteInputSource: API.OperationMethod<DeleteInputSourceRequest, DeleteInputSourceResponse, DeleteInputSourceError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a resilience policy.
 */
export declare const deletePolicy: API.OperationMethod<DeletePolicyRequest, DeletePolicyResponse, DeletePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a service.
 */
export declare const deleteService: API.OperationMethod<DeleteServiceRequest, DeleteServiceResponse, DeleteServiceError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceFunctionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a service function.
 */
export declare const deleteServiceFunction: API.OperationMethod<DeleteServiceFunctionRequest, DeleteServiceFunctionResponse, DeleteServiceFunctionError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceFunctionResourcesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes resources from a service function.
 */
export declare const deleteServiceFunctionResources: API.OperationMethod<DeleteServiceFunctionResourcesRequest, DeleteServiceFunctionResourcesResponse, DeleteServiceFunctionResourcesError, Credentials | HttpClient.HttpClient>;
export type DeleteSystemError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a system.
 */
export declare const deleteSystem: API.OperationMethod<DeleteSystemRequest, DeleteSystemResponse, DeleteSystemError, Credentials | HttpClient.HttpClient>;
export type DeleteTestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a test.
 */
export declare const deleteTest: API.OperationMethod<DeleteTestRequest, DeleteTestResponse, DeleteTestError, Credentials | HttpClient.HttpClient>;
export type DeleteTestSourcesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes monitoring sources from a test. The operation is transactional and idempotent -- removing a source that is not attached is a no-op.
 */
export declare const deleteTestSources: API.OperationMethod<DeleteTestSourcesRequest, DeleteTestSourcesResponse, DeleteTestSourcesError, Credentials | HttpClient.HttpClient>;
export type DeleteUserJourneyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a user journey.
 */
export declare const deleteUserJourney: API.OperationMethod<DeleteUserJourneyRequest, DeleteUserJourneyResponse, DeleteUserJourneyError, Credentials | HttpClient.HttpClient>;
export type GetDependencyInsightsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the dependency insights generated for a service. The response reports the current generation status; insights are populated once generation has completed. If generation failed, the response includes an error code, whose possible values are listed under the response's errorCode field, and a message describing the cause. To use this operation, you must have the `resiliencehub:GetDependencyInsights` permission on the service.
 */
export declare const getDependencyInsights: API.OperationMethod<GetDependencyInsightsRequest, GetDependencyInsightsResponse, GetDependencyInsightsError, Credentials | HttpClient.HttpClient>;
export type GetFailureModeFindingError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a finding by findingId.
 */
export declare const getFailureModeFinding: API.OperationMethod<GetFailureModeFindingRequest, GetFailureModeFindingResponse, GetFailureModeFindingError, Credentials | HttpClient.HttpClient>;
export type GetPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a resilience policy by ARN.
 */
export declare const getPolicy: API.OperationMethod<GetPolicyRequest, GetPolicyResponse, GetPolicyError, Credentials | HttpClient.HttpClient>;
export type GetServiceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a service by ARN.
 */
export declare const getService: API.OperationMethod<GetServiceRequest, GetServiceResponse, GetServiceError, Credentials | HttpClient.HttpClient>;
export type GetSystemError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a system by ARN.
 */
export declare const getSystem: API.OperationMethod<GetSystemRequest, GetSystemResponse, GetSystemError, Credentials | HttpClient.HttpClient>;
export type GetTestError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a test by ID.
 */
export declare const getTest: API.OperationMethod<GetTestRequest, GetTestResponse, GetTestError, Credentials | HttpClient.HttpClient>;
export type GetTestRunError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a test run by ID, including its status, results, and the configuration snapshotted when the run started.
 */
export declare const getTestRun: API.OperationMethod<GetTestRunRequest, GetTestRunResponse, GetTestRunError, Credentials | HttpClient.HttpClient>;
export type GetTestTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a resilience test template by ARN, including the parameters it accepts and the fault actions it runs.
 */
export declare const getTestTemplate: API.OperationMethod<GetTestTemplateRequest, GetTestTemplateResponse, GetTestTemplateError, Credentials | HttpClient.HttpClient>;
export type GetUserJourneyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a user journey.
 */
export declare const getUserJourney: API.OperationMethod<GetUserJourneyRequest, GetUserJourneyResponse, GetUserJourneyError, Credentials | HttpClient.HttpClient>;
export type ImportAppError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Imports a V1 app into the V2 resource model, creating a service with the same name.
 */
export declare const importApp: API.OperationMethod<ImportAppRequest, ImportAppResponse, ImportAppError, Credentials | HttpClient.HttpClient>;
export type ImportPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Imports a V1 policy into V2, mapping RTO/RPO values from V1 scenarios.
 */
export declare const importPolicy: API.OperationMethod<ImportPolicyRequest, ImportPolicyResponse, ImportPolicyError, Credentials | HttpClient.HttpClient>;
export type ListAssertionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists resilience assertions for a service.
 */
export declare const listAssertions: API.PaginatedOperationMethod<ListAssertionsRequest, ListAssertionsResponse, ListAssertionsError, Credentials | HttpClient.HttpClient, Assertion>;
export type ListDependenciesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists dependencies discovered for services.
 */
export declare const listDependencies: API.PaginatedOperationMethod<ListDependenciesRequest, ListDependenciesResponse, ListDependenciesError, Credentials | HttpClient.HttpClient, DependencySummary>;
export type ListFailureModeAssessmentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists failure mode assessments.
 */
export declare const listFailureModeAssessments: API.PaginatedOperationMethod<ListFailureModeAssessmentsRequest, ListFailureModeAssessmentsResponse, ListFailureModeAssessmentsError, Credentials | HttpClient.HttpClient, AssessmentSummary>;
export type ListFailureModeFindingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List findings.
 */
export declare const listFailureModeFindings: API.PaginatedOperationMethod<ListFailureModeFindingsRequest, ListFailureModeFindingsResponse, ListFailureModeFindingsError, Credentials | HttpClient.HttpClient, FindingSummary>;
export type ListInputSourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists input sources for a service.
 */
export declare const listInputSources: API.PaginatedOperationMethod<ListInputSourcesRequest, ListInputSourcesResponse, ListInputSourcesError, Credentials | HttpClient.HttpClient, InputSourceSummary>;
export type ListPoliciesError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Lists resilience policies.
 */
export declare const listPolicies: API.PaginatedOperationMethod<ListPoliciesRequest, ListPoliciesResponse, ListPoliciesError, Credentials | HttpClient.HttpClient, PolicySummary>;
export type ListPolicyEventsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists events for a resilience policy, including services that started or stopped using it, changes to cross-account sharing, and deletion of the policy.
 */
export declare const listPolicyEvents: API.PaginatedOperationMethod<ListPolicyEventsRequest, ListPolicyEventsResponse, ListPolicyEventsError, Credentials | HttpClient.HttpClient, PolicyEvent>;
export type ListReportsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List reports for a service, or all reports owned by the account if serviceArn is not provided.
 */
export declare const listReports: API.PaginatedOperationMethod<ListReportsRequest, ListReportsResponse, ListReportsError, Credentials | HttpClient.HttpClient, ReportGenerationResult>;
export type ListResolvedTestRunTargetResourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the AWS resources that AWS Fault Injection Service (AWS FIS) resolved as targets for a test run.
 */
export declare const listResolvedTestRunTargetResources: API.PaginatedOperationMethod<ListResolvedTestRunTargetResourcesRequest, ListResolvedTestRunTargetResourcesResponse, ListResolvedTestRunTargetResourcesError, Credentials | HttpClient.HttpClient, ResolvedTargetResource>;
export type ListResourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List resources.
 */
export declare const listResources: API.PaginatedOperationMethod<ListResourcesRequest, ListResourcesResponse, ListResourcesError, Credentials | HttpClient.HttpClient, ServiceResource>;
export type ListServiceEventsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists events for a service.
 */
export declare const listServiceEvents: API.PaginatedOperationMethod<ListServiceEventsRequest, ListServiceEventsResponse, ListServiceEventsError, Credentials | HttpClient.HttpClient, ServiceEvent>;
export type ListServiceFunctionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists service functions for a service.
 */
export declare const listServiceFunctions: API.PaginatedOperationMethod<ListServiceFunctionsRequest, ListServiceFunctionsResponse, ListServiceFunctionsError, Credentials | HttpClient.HttpClient, ServiceFunction>;
export type ListServicesError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Lists services.
 */
export declare const listServices: API.PaginatedOperationMethod<ListServicesRequest, ListServicesResponse, ListServicesError, Credentials | HttpClient.HttpClient, ServiceSummary>;
export type ListServiceTopologyEdgesError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Lists topology edges for a service.
 */
export declare const listServiceTopologyEdges: API.PaginatedOperationMethod<ListServiceTopologyEdgesRequest, ListServiceTopologyEdgesResponse, ListServiceTopologyEdgesError, Credentials | HttpClient.HttpClient, ServiceTopologyEdgeSummary>;
export type ListSystemEventsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists events for a system.
 */
export declare const listSystemEvents: API.PaginatedOperationMethod<ListSystemEventsRequest, ListSystemEventsResponse, ListSystemEventsError, Credentials | HttpClient.HttpClient, SystemEvent>;
export type ListSystemsError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Lists systems.
 */
export declare const listSystems: API.PaginatedOperationMethod<ListSystemsRequest, ListSystemsResponse, ListSystemsError, Credentials | HttpClient.HttpClient, SystemSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTestRunDependenciesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the dependencies that a test run blocked. Each dependency reflects the discovered classification captured when the run started, so results do not change if a dependency is reclassified after the run.
 */
export declare const listTestRunDependencies: API.PaginatedOperationMethod<ListTestRunDependenciesRequest, ListTestRunDependenciesResponse, ListTestRunDependenciesError, Credentials | HttpClient.HttpClient, TestRunDependencySummary>;
export type ListTestRunEventsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the events in a test run's timeline.
 */
export declare const listTestRunEvents: API.PaginatedOperationMethod<ListTestRunEventsRequest, ListTestRunEventsResponse, ListTestRunEventsError, Credentials | HttpClient.HttpClient, TestRunEvent>;
export type ListTestRunsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the runs of a test, or all test runs for a service.
 */
export declare const listTestRuns: API.PaginatedOperationMethod<ListTestRunsRequest, ListTestRunsResponse, ListTestRunsError, Credentials | HttpClient.HttpClient, TestRunSummary>;
export type ListTestRunSourceEventsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the state-change events observed for a test run monitoring source. Events are returned for one source per call, in chronological order.
 */
export declare const listTestRunSourceEvents: API.PaginatedOperationMethod<ListTestRunSourceEventsRequest, ListTestRunSourceEventsResponse, ListTestRunSourceEventsError, Credentials | HttpClient.HttpClient, TestRunSourceEvent>;
export type ListTestRunSourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the monitoring source snapshots captured for a test run, optionally filtered by type.
 */
export declare const listTestRunSources: API.PaginatedOperationMethod<ListTestRunSourcesRequest, ListTestRunSourcesResponse, ListTestRunSourcesError, Credentials | HttpClient.HttpClient, TestRunSourceSummary>;
export type ListTestsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tests configured for a service.
 */
export declare const listTests: API.PaginatedOperationMethod<ListTestsRequest, ListTestsResponse, ListTestsError, Credentials | HttpClient.HttpClient, TestSummary>;
export type ListTestSourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the monitoring sources attached to a test, optionally filtered by type.
 */
export declare const listTestSources: API.PaginatedOperationMethod<ListTestSourcesRequest, ListTestSourcesResponse, ListTestSourcesError, Credentials | HttpClient.HttpClient, TestSourceSummary>;
export type ListTestTemplatesError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Lists the available resilience test templates. A test template is a pre-configured, AWS recommended test that defines which resilience capability to validate.
 */
export declare const listTestTemplates: API.OperationMethod<ListTestTemplatesRequest, ListTestTemplatesResponse, ListTestTemplatesError, Credentials | HttpClient.HttpClient>;
export type ListUserJourneysError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists user journeys for a system.
 */
export declare const listUserJourneys: API.PaginatedOperationMethod<ListUserJourneysRequest, ListUserJourneysResponse, ListUserJourneysError, Credentials | HttpClient.HttpClient, UserJourneySummary>;
export type PutTestSourcesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Adds or updates the monitoring sources on a test. The operation is transactional -- either every source is written or the call fails and nothing is written.
 */
export declare const putTestSources: API.OperationMethod<PutTestSourcesRequest, PutTestSourcesResponse, PutTestSourcesError, Credentials | HttpClient.HttpClient>;
export type StartDependencyInsightsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts generating dependency insights for a service. Generation runs asynchronously; the response returns the initial status, and you retrieve the results with GetDependencyInsights. To use this operation, you must have the `resiliencehub:StartDependencyInsights` permission on the service.
 */
export declare const startDependencyInsights: API.OperationMethod<StartDependencyInsightsRequest, StartDependencyInsightsResponse, StartDependencyInsightsError, Credentials | HttpClient.HttpClient>;
export type StartFailureModeAssessmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a failure mode assessment.
 */
export declare const startFailureModeAssessment: API.OperationMethod<StartFailureModeAssessmentRequest, StartFailureModeAssessmentResponse, StartFailureModeAssessmentError, Credentials | HttpClient.HttpClient>;
export type StartTestRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Starts a run of a test. Each run scopes to the current resources in the service and produces a pass or fail outcome.
 */
export declare const startTestRun: API.OperationMethod<StartTestRunRequest, StartTestRunResponse, StartTestRunError, Credentials | HttpClient.HttpClient>;
export type StopTestRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Stops an in-progress test run.
 */
export declare const stopTestRun: API.OperationMethod<StopTestRunRequest, StopTestRunResponse, StopTestRunError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAssertionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a resilience assertion.
 */
export declare const updateAssertion: API.OperationMethod<UpdateAssertionRequest, UpdateAssertionResponse, UpdateAssertionError, Credentials | HttpClient.HttpClient>;
export type UpdateDependencyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a dependency classification.
 */
export declare const updateDependency: API.OperationMethod<UpdateDependencyRequest, UpdateDependencyResponse, UpdateDependencyError, Credentials | HttpClient.HttpClient>;
export type UpdateFailureModeFindingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates an existing finding.
 */
export declare const updateFailureModeFinding: API.OperationMethod<UpdateFailureModeFindingRequest, UpdateFailureModeFindingResponse, UpdateFailureModeFindingError, Credentials | HttpClient.HttpClient>;
export type UpdatePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates an existing resilience policy.
 */
export declare const updatePolicy: API.OperationMethod<UpdatePolicyRequest, UpdatePolicyResponse, UpdatePolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Updates an existing service.
 */
export declare const updateService: API.OperationMethod<UpdateServiceRequest, UpdateServiceResponse, UpdateServiceError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceFunctionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a service function.
 */
export declare const updateServiceFunction: API.OperationMethod<UpdateServiceFunctionRequest, UpdateServiceFunctionResponse, UpdateServiceFunctionError, Credentials | HttpClient.HttpClient>;
export type UpdateSystemError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates an existing system.
 */
export declare const updateSystem: API.OperationMethod<UpdateSystemRequest, UpdateSystemResponse, UpdateSystemError, Credentials | HttpClient.HttpClient>;
export type UpdateTestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the configuration of an existing test.
 */
export declare const updateTest: API.OperationMethod<UpdateTestRequest, UpdateTestResponse, UpdateTestError, Credentials | HttpClient.HttpClient>;
export type UpdateUserJourneyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates an existing user journey.
 */
export declare const updateUserJourney: API.OperationMethod<UpdateUserJourneyRequest, UpdateUserJourneyResponse, UpdateUserJourneyError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=resiliencehubv2.d.ts.map