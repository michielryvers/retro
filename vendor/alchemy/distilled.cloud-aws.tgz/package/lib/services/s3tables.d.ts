import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const MethodNotAllowedException_base: S.TaggedErrorClass<"MethodNotAllowedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MethodNotAllowedException extends /*@__PURE__*/ MethodNotAllowedException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type TableBucketARN = string;
export type NamespaceName = string;
export type NamespaceList = string[];
export interface CreateNamespaceRequest {
    tableBucketARN: string;
    namespace: string[];
}
export interface CreateNamespaceResponse {
    tableBucketARN: string;
    namespace: string[];
}
export type TableName = string;
export type OpenTableFormat = "ICEBERG" | (string & {});
export interface SchemaField {
    id?: number;
    name: string;
    type: string;
    required?: boolean;
}
export type SchemaFieldList = SchemaField[];
export interface IcebergSchema {
    fields: SchemaField[];
}
export type SchemaV2FieldType = "struct" | (string & {});
export interface SchemaV2Field {
    id: number;
    name: string;
    type: any;
    required: boolean;
    doc?: string;
}
export type SchemaV2FieldList = SchemaV2Field[];
export type IntegerList = number[];
export interface IcebergSchemaV2 {
    type: SchemaV2FieldType;
    fields: SchemaV2Field[];
    schemaId?: number;
    identifierFieldIds?: number[];
}
export interface IcebergPartitionField {
    sourceId: number;
    transform: string;
    name: string;
    fieldId?: number;
}
export type IcebergPartitionFieldList = IcebergPartitionField[];
export interface IcebergPartitionSpec {
    fields: IcebergPartitionField[];
    specId?: number;
}
export type IcebergSortDirection = "asc" | "desc" | (string & {});
export type IcebergNullOrder = "nulls-first" | "nulls-last" | (string & {});
export interface IcebergSortField {
    sourceId: number;
    transform: string;
    direction: IcebergSortDirection;
    nullOrder: IcebergNullOrder;
}
export type IcebergSortFieldList = IcebergSortField[];
export interface IcebergSortOrder {
    orderId: number;
    fields: IcebergSortField[];
}
export type TableProperties = {
    [key: string]: string | undefined;
};
export interface IcebergMetadata {
    schema?: IcebergSchema;
    schemaV2?: IcebergSchemaV2;
    partitionSpec?: IcebergPartitionSpec;
    writeOrder?: IcebergSortOrder;
    properties?: {
        [key: string]: string | undefined;
    };
}
export type TableMetadata = {
    iceberg: IcebergMetadata;
};
export type SSEAlgorithm = "AES256" | "aws:kms" | (string & {});
export interface EncryptionConfiguration {
    sseAlgorithm: SSEAlgorithm;
    kmsKeyArn?: string;
}
export type StorageClass = "STANDARD" | "INTELLIGENT_TIERING" | (string & {});
export interface StorageClassConfiguration {
    storageClass: StorageClass;
}
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export interface CreateTableRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
    format: OpenTableFormat;
    metadata?: TableMetadata;
    encryptionConfiguration?: EncryptionConfiguration;
    storageClassConfiguration?: StorageClassConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type TableARN = string;
export type VersionToken = string;
export interface CreateTableResponse {
    tableARN: string;
    versionToken: string;
}
export type TableBucketName = string;
export interface CreateTableBucketRequest {
    name: string;
    encryptionConfiguration?: EncryptionConfiguration;
    storageClassConfiguration?: StorageClassConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateTableBucketResponse {
    arn: string;
}
export interface DeleteNamespaceRequest {
    tableBucketARN: string;
    namespace: string;
}
export interface DeleteNamespaceResponse {
}
export interface DeleteTableRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
    versionToken?: string;
}
export interface DeleteTableResponse {
}
export interface DeleteTableBucketRequest {
    tableBucketARN: string;
}
export interface DeleteTableBucketResponse {
}
export interface DeleteTableBucketEncryptionRequest {
    tableBucketARN: string;
}
export interface DeleteTableBucketEncryptionResponse {
}
export interface DeleteTableBucketMetricsConfigurationRequest {
    tableBucketARN: string;
}
export interface DeleteTableBucketMetricsConfigurationResponse {
}
export interface DeleteTableBucketPolicyRequest {
    tableBucketARN: string;
}
export interface DeleteTableBucketPolicyResponse {
}
export interface DeleteTableBucketReplicationRequest {
    tableBucketARN: string;
    versionToken?: string;
}
export interface DeleteTableBucketReplicationResponse {
}
export interface DeleteTablePolicyRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
}
export interface DeleteTablePolicyResponse {
}
export interface DeleteTableReplicationRequest {
    tableArn: string;
    versionToken: string;
}
export interface DeleteTableReplicationResponse {
}
export interface GetNamespaceRequest {
    tableBucketARN: string;
    namespace: string;
}
export type AccountId = string;
export type NamespaceId = string;
export type TableBucketId = string;
export interface GetNamespaceResponse {
    namespace: string[];
    createdAt: Date;
    createdBy: string;
    ownerAccountId: string;
    namespaceId?: string;
    tableBucketId?: string;
}
export interface GetTableRequest {
    tableBucketARN?: string;
    namespace?: string;
    name?: string;
    tableArn?: string;
}
export type TableType = "customer" | "aws" | (string & {});
export type MetadataLocation = string;
export type WarehouseLocation = string;
export interface ReplicationInformation {
    sourceTableARN: string;
}
export interface ManagedTableInformation {
    replicationInformation?: ReplicationInformation;
}
export interface GetTableResponse {
    name: string;
    type: TableType;
    tableARN: string;
    namespace: string[];
    namespaceId?: string;
    versionToken: string;
    metadataLocation?: string;
    warehouseLocation: string;
    createdAt: Date;
    createdBy: string;
    managedByService?: string;
    modifiedAt: Date;
    modifiedBy?: string;
    ownerAccountId: string;
    format: OpenTableFormat;
    tableBucketId?: string;
    managedTableInformation?: ManagedTableInformation;
}
export interface GetTableBucketRequest {
    tableBucketARN: string;
}
export type TableBucketType = "customer" | "aws" | (string & {});
export interface GetTableBucketResponse {
    arn: string;
    name: string;
    ownerAccountId: string;
    createdAt: Date;
    tableBucketId?: string;
    type?: TableBucketType;
}
export interface GetTableBucketEncryptionRequest {
    tableBucketARN: string;
}
export interface GetTableBucketEncryptionResponse {
    encryptionConfiguration: EncryptionConfiguration;
}
export interface GetTableBucketMaintenanceConfigurationRequest {
    tableBucketARN: string;
}
export type TableBucketMaintenanceType = "icebergUnreferencedFileRemoval" | (string & {});
export type MaintenanceStatus = "enabled" | "disabled" | (string & {});
export type PositiveInteger = number;
export interface IcebergUnreferencedFileRemovalSettings {
    unreferencedDays?: number;
    nonCurrentDays?: number;
}
export type TableBucketMaintenanceSettings = {
    icebergUnreferencedFileRemoval: IcebergUnreferencedFileRemovalSettings;
};
export interface TableBucketMaintenanceConfigurationValue {
    status?: MaintenanceStatus;
    settings?: TableBucketMaintenanceSettings;
}
export type TableBucketMaintenanceConfiguration = {
    [key in TableBucketMaintenanceType]?: TableBucketMaintenanceConfigurationValue;
};
export interface GetTableBucketMaintenanceConfigurationResponse {
    tableBucketARN: string;
    configuration: {
        [key: string]: TableBucketMaintenanceConfigurationValue | undefined;
    };
}
export interface GetTableBucketMetricsConfigurationRequest {
    tableBucketARN: string;
}
export interface GetTableBucketMetricsConfigurationResponse {
    tableBucketARN: string;
    id?: string;
}
export interface GetTableBucketPolicyRequest {
    tableBucketARN: string;
}
export type ResourcePolicy = string;
export interface GetTableBucketPolicyResponse {
    resourcePolicy: string;
}
export interface GetTableBucketReplicationRequest {
    tableBucketARN: string;
}
export type IAMRole = string;
export interface ReplicationDestination {
    destinationTableBucketARN: string;
}
export type ReplicationDestinations = ReplicationDestination[];
export interface TableBucketReplicationRule {
    destinations: ReplicationDestination[];
}
export type TableBucketReplicationRules = TableBucketReplicationRule[];
export interface TableBucketReplicationConfiguration {
    role: string;
    rules: TableBucketReplicationRule[];
}
export interface GetTableBucketReplicationResponse {
    versionToken: string;
    configuration: TableBucketReplicationConfiguration;
}
export interface GetTableBucketStorageClassRequest {
    tableBucketARN: string;
}
export interface GetTableBucketStorageClassResponse {
    storageClassConfiguration: StorageClassConfiguration;
}
export interface GetTableEncryptionRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
}
export interface GetTableEncryptionResponse {
    encryptionConfiguration: EncryptionConfiguration;
}
export interface GetTableMaintenanceConfigurationRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
}
export type TableMaintenanceType = "icebergCompaction" | "icebergSnapshotManagement" | (string & {});
export type IcebergCompactionStrategy = "auto" | "binpack" | "sort" | "z-order" | (string & {});
export interface IcebergCompactionSettings {
    targetFileSizeMB?: number;
    strategy?: IcebergCompactionStrategy;
}
export interface IcebergSnapshotManagementSettings {
    minSnapshotsToKeep?: number;
    maxSnapshotAgeHours?: number;
}
export type TableMaintenanceSettings = {
    icebergCompaction: IcebergCompactionSettings;
    icebergSnapshotManagement?: never;
} | {
    icebergCompaction?: never;
    icebergSnapshotManagement: IcebergSnapshotManagementSettings;
};
export interface TableMaintenanceConfigurationValue {
    status?: MaintenanceStatus;
    settings?: TableMaintenanceSettings;
}
export type TableMaintenanceConfiguration = {
    [key in TableMaintenanceType]?: TableMaintenanceConfigurationValue;
};
export interface GetTableMaintenanceConfigurationResponse {
    tableARN: string;
    configuration: {
        [key: string]: TableMaintenanceConfigurationValue | undefined;
    };
}
export interface GetTableMaintenanceJobStatusRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
}
export type TableMaintenanceJobType = "icebergCompaction" | "icebergSnapshotManagement" | "icebergUnreferencedFileRemoval" | (string & {});
export type JobStatus = "Not_Yet_Run" | "Successful" | "Failed" | "Disabled" | (string & {});
export interface TableMaintenanceJobStatusValue {
    status: JobStatus;
    lastRunTimestamp?: Date;
    failureMessage?: string;
}
export type TableMaintenanceJobStatus = {
    [key in TableMaintenanceJobType]?: TableMaintenanceJobStatusValue;
};
export interface GetTableMaintenanceJobStatusResponse {
    tableARN: string;
    status: {
        [key: string]: TableMaintenanceJobStatusValue | undefined;
    };
}
export interface GetTableMetadataLocationRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
}
export interface GetTableMetadataLocationResponse {
    versionToken: string;
    metadataLocation?: string;
    warehouseLocation: string;
}
export interface GetTablePolicyRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
}
export interface GetTablePolicyResponse {
    resourcePolicy: string;
}
export interface GetTableRecordExpirationConfigurationRequest {
    tableArn: string;
}
export type TableRecordExpirationStatus = "enabled" | "disabled" | (string & {});
export interface TableRecordExpirationSettings {
    days?: number;
}
export interface TableRecordExpirationConfigurationValue {
    status?: TableRecordExpirationStatus;
    settings?: TableRecordExpirationSettings;
}
export interface GetTableRecordExpirationConfigurationResponse {
    configuration: TableRecordExpirationConfigurationValue;
}
export interface GetTableRecordExpirationJobStatusRequest {
    tableArn: string;
}
export type TableRecordExpirationJobStatus = "NotYetRun" | "Successful" | "Failed" | "Disabled" | (string & {});
export interface TableRecordExpirationJobMetrics {
    deletedDataFiles?: number;
    deletedRecords?: number;
    removedFilesSize?: number;
}
export interface GetTableRecordExpirationJobStatusResponse {
    status: TableRecordExpirationJobStatus;
    lastRunTimestamp?: Date;
    failureMessage?: string;
    metrics?: TableRecordExpirationJobMetrics;
}
export interface GetTableReplicationRequest {
    tableArn: string;
}
export interface TableReplicationRule {
    destinations: ReplicationDestination[];
}
export type TableReplicationRules = TableReplicationRule[];
export interface TableReplicationConfiguration {
    role: string;
    rules: TableReplicationRule[];
}
export interface GetTableReplicationResponse {
    versionToken: string;
    configuration: TableReplicationConfiguration;
}
export interface GetTableReplicationStatusRequest {
    tableArn: string;
}
export type ReplicationStatus = "pending" | "completed" | "failed" | (string & {});
export interface LastSuccessfulReplicatedUpdate {
    metadataLocation: string;
    timestamp: Date;
}
export interface ReplicationDestinationStatusModel {
    replicationStatus: ReplicationStatus;
    destinationTableBucketArn: string;
    destinationTableArn?: string;
    lastSuccessfulReplicatedUpdate?: LastSuccessfulReplicatedUpdate;
    failureMessage?: string;
}
export type ReplicationDestinationStatuses = ReplicationDestinationStatusModel[];
export interface GetTableReplicationStatusResponse {
    sourceTableArn: string;
    destinations: ReplicationDestinationStatusModel[];
}
export interface GetTableStorageClassRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
}
export interface GetTableStorageClassResponse {
    storageClassConfiguration: StorageClassConfiguration;
}
export type NextToken = string;
export type ListNamespacesLimit = number;
export interface ListNamespacesRequest {
    tableBucketARN: string;
    prefix?: string;
    continuationToken?: string;
    maxNamespaces?: number;
}
export interface NamespaceSummary {
    namespace: string[];
    createdAt: Date;
    createdBy: string;
    ownerAccountId: string;
    namespaceId?: string;
    tableBucketId?: string;
}
export type NamespaceSummaryList = NamespaceSummary[];
export interface ListNamespacesResponse {
    namespaces: NamespaceSummary[];
    continuationToken?: string;
}
export type ListTableBucketsLimit = number;
export interface ListTableBucketsRequest {
    prefix?: string;
    continuationToken?: string;
    maxBuckets?: number;
    type?: TableBucketType;
}
export interface TableBucketSummary {
    arn: string;
    name: string;
    ownerAccountId: string;
    createdAt: Date;
    tableBucketId?: string;
    type?: TableBucketType;
}
export type TableBucketSummaryList = TableBucketSummary[];
export interface ListTableBucketsResponse {
    tableBuckets: TableBucketSummary[];
    continuationToken?: string;
}
export type ListTablesLimit = number;
export interface ListTablesRequest {
    tableBucketARN: string;
    namespace?: string;
    prefix?: string;
    continuationToken?: string;
    maxTables?: number;
}
export interface TableSummary {
    namespace: string[];
    name: string;
    type: TableType;
    tableARN: string;
    createdAt: Date;
    modifiedAt: Date;
    managedByService?: string;
    namespaceId?: string;
    tableBucketId?: string;
}
export type TableSummaryList = TableSummary[];
export interface ListTablesResponse {
    tables: TableSummary[];
    continuationToken?: string;
}
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface PutTableBucketEncryptionRequest {
    tableBucketARN: string;
    encryptionConfiguration: EncryptionConfiguration;
}
export interface PutTableBucketEncryptionResponse {
}
export interface PutTableBucketMaintenanceConfigurationRequest {
    tableBucketARN: string;
    type: TableBucketMaintenanceType;
    value: TableBucketMaintenanceConfigurationValue;
}
export interface PutTableBucketMaintenanceConfigurationResponse {
}
export interface PutTableBucketMetricsConfigurationRequest {
    tableBucketARN: string;
}
export interface PutTableBucketMetricsConfigurationResponse {
}
export interface PutTableBucketPolicyRequest {
    tableBucketARN: string;
    resourcePolicy: string;
}
export interface PutTableBucketPolicyResponse {
}
export interface PutTableBucketReplicationRequest {
    tableBucketARN: string;
    versionToken?: string;
    configuration: TableBucketReplicationConfiguration;
}
export interface PutTableBucketReplicationResponse {
    versionToken: string;
    status: string;
}
export interface PutTableBucketStorageClassRequest {
    tableBucketARN: string;
    storageClassConfiguration: StorageClassConfiguration;
}
export interface PutTableBucketStorageClassResponse {
}
export interface PutTableMaintenanceConfigurationRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
    type: TableMaintenanceType;
    value: TableMaintenanceConfigurationValue;
}
export interface PutTableMaintenanceConfigurationResponse {
}
export interface PutTablePolicyRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
    resourcePolicy: string;
}
export interface PutTablePolicyResponse {
}
export interface PutTableRecordExpirationConfigurationRequest {
    tableArn: string;
    value: TableRecordExpirationConfigurationValue;
}
export interface PutTableRecordExpirationConfigurationResponse {
}
export interface PutTableReplicationRequest {
    tableArn: string;
    versionToken?: string;
    configuration: TableReplicationConfiguration;
}
export interface PutTableReplicationResponse {
    versionToken: string;
    status: string;
}
export interface RenameTableRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
    newNamespaceName?: string;
    newName?: string;
    versionToken?: string;
}
export interface RenameTableResponse {
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateTableMetadataLocationRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
    versionToken: string;
    metadataLocation: string;
}
export interface UpdateTableMetadataLocationResponse {
    name: string;
    tableARN: string;
    namespace: string[];
    versionToken: string;
    metadataLocation: string;
}
export type ErrorMessage = string;
export type CreateNamespaceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a namespace. A namespace is a logical grouping of tables within your table bucket, which you can use to organize tables. For more information, see Create a namespace in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:CreateNamespace` permission to use this operation.
 */
export declare const createNamespace: API.OperationMethod<CreateNamespaceRequest, CreateNamespaceResponse, CreateNamespaceError, Credentials | HttpClient.HttpClient>;
export type CreateTableError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new table associated with the given namespace in a table bucket. For more information, see Creating an Amazon S3 table in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * - You must have the `s3tables:CreateTable` permission to use this operation.
 *
 * - If you use this operation with the optional `metadata` request parameter you must have the `s3tables:PutTableData` permission.
 *
 * - If you use this operation with the optional `encryptionConfiguration` request parameter you must have the `s3tables:PutTableEncryption` permission.
 *
 * - If you use this operation with the `storageClassConfiguration` request parameter, you must have the `s3tables:PutTableStorageClass` permission.
 *
 * - To create a table with tags, you must have the `s3tables:TagResource` permission in addition to `s3tables:CreateTable` permission.
 *
 * Additionally, If you choose SSE-KMS encryption you must grant the S3 Tables maintenance principal access to your KMS key. For more information, see Permissions requirements for S3 Tables SSE-KMS encryption.
 */
export declare const createTable: API.OperationMethod<CreateTableRequest, CreateTableResponse, CreateTableError, Credentials | HttpClient.HttpClient>;
export type CreateTableBucketError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a table bucket. For more information, see Creating a table bucket in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * - You must have the `s3tables:CreateTableBucket` permission to use this operation.
 *
 * - If you use this operation with the optional `encryptionConfiguration` parameter you must have the `s3tables:PutTableBucketEncryption` permission.
 *
 * - If you use this operation with the `storageClassConfiguration` request parameter, you must have the `s3tables:PutTableBucketStorageClass` permission.
 *
 * - To create a table bucket with tags, you must have the `s3tables:TagResource` permission in addition to `s3tables:CreateTableBucket` permission.
 */
export declare const createTableBucket: API.OperationMethod<CreateTableBucketRequest, CreateTableBucketResponse, CreateTableBucketError, Credentials | HttpClient.HttpClient>;
export type DeleteNamespaceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a namespace. For more information, see Delete a namespace in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:DeleteNamespace` permission to use this operation.
 */
export declare const deleteNamespace: API.OperationMethod<DeleteNamespaceRequest, DeleteNamespaceResponse, DeleteNamespaceError, Credentials | HttpClient.HttpClient>;
export type DeleteTableError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a table. For more information, see Deleting an Amazon S3 table in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:DeleteTable` permission to use this operation.
 */
export declare const deleteTable: API.OperationMethod<DeleteTableRequest, DeleteTableResponse, DeleteTableError, Credentials | HttpClient.HttpClient>;
export type DeleteTableBucketError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a table bucket. For more information, see Deleting a table bucket in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:DeleteTableBucket` permission to use this operation.
 */
export declare const deleteTableBucket: API.OperationMethod<DeleteTableBucketRequest, DeleteTableBucketResponse, DeleteTableBucketError, Credentials | HttpClient.HttpClient>;
export type DeleteTableBucketEncryptionError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the encryption configuration for a table bucket.
 *
 * ### Permissions
 *
 * You must have the `s3tables:DeleteTableBucketEncryption` permission to use this operation.
 */
export declare const deleteTableBucketEncryption: API.OperationMethod<DeleteTableBucketEncryptionRequest, DeleteTableBucketEncryptionResponse, DeleteTableBucketEncryptionError, Credentials | HttpClient.HttpClient>;
export type DeleteTableBucketMetricsConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the metrics configuration for a table bucket.
 *
 * ### Permissions
 *
 * You must have the `s3tables:DeleteTableBucketMetricsConfiguration` permission to use this operation.
 */
export declare const deleteTableBucketMetricsConfiguration: API.OperationMethod<DeleteTableBucketMetricsConfigurationRequest, DeleteTableBucketMetricsConfigurationResponse, DeleteTableBucketMetricsConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteTableBucketPolicyError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a table bucket policy. For more information, see Deleting a table bucket policy in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:DeleteTableBucketPolicy` permission to use this operation.
 */
export declare const deleteTableBucketPolicy: API.OperationMethod<DeleteTableBucketPolicyRequest, DeleteTableBucketPolicyResponse, DeleteTableBucketPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteTableBucketReplicationError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the replication configuration for a table bucket. After deletion, new table updates will no longer be replicated to destination buckets, though existing replicated tables will remain in destination buckets.
 *
 * ### Permissions
 *
 * You must have the `s3tables:DeleteTableBucketReplication` permission to use this operation.
 */
export declare const deleteTableBucketReplication: API.OperationMethod<DeleteTableBucketReplicationRequest, DeleteTableBucketReplicationResponse, DeleteTableBucketReplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteTablePolicyError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a table policy. For more information, see Deleting a table policy in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:DeleteTablePolicy` permission to use this operation.
 */
export declare const deleteTablePolicy: API.OperationMethod<DeleteTablePolicyRequest, DeleteTablePolicyResponse, DeleteTablePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteTableReplicationError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the replication configuration for a specific table. After deletion, new updates to this table will no longer be replicated to destination tables, though existing replicated copies will remain in destination buckets.
 *
 * ### Permissions
 *
 * You must have the `s3tables:DeleteTableReplication` permission to use this operation.
 */
export declare const deleteTableReplication: API.OperationMethod<DeleteTableReplicationRequest, DeleteTableReplicationResponse, DeleteTableReplicationError, Credentials | HttpClient.HttpClient>;
export type GetNamespaceError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details about a namespace. For more information, see Table namespaces in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetNamespace` permission to use this operation.
 */
export declare const getNamespace: API.OperationMethod<GetNamespaceRequest, GetNamespaceResponse, GetNamespaceError, Credentials | HttpClient.HttpClient>;
export type GetTableError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details about a table. For more information, see S3 Tables in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTable` permission to use this operation.
 */
export declare const getTable: API.OperationMethod<GetTableRequest, GetTableResponse, GetTableError, Credentials | HttpClient.HttpClient>;
export type GetTableBucketError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details on a table bucket. For more information, see Viewing details about an Amazon S3 table bucket in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableBucket` permission to use this operation.
 */
export declare const getTableBucket: API.OperationMethod<GetTableBucketRequest, GetTableBucketResponse, GetTableBucketError, Credentials | HttpClient.HttpClient>;
export type GetTableBucketEncryptionError = AccessDeniedException | BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the encryption configuration for a table bucket.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableBucketEncryption` permission to use this operation.
 */
export declare const getTableBucketEncryption: API.OperationMethod<GetTableBucketEncryptionRequest, GetTableBucketEncryptionResponse, GetTableBucketEncryptionError, Credentials | HttpClient.HttpClient>;
export type GetTableBucketMaintenanceConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details about a maintenance configuration for a given table bucket. For more information, see Amazon S3 table bucket maintenance in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableBucketMaintenanceConfiguration` permission to use this operation.
 */
export declare const getTableBucketMaintenanceConfiguration: API.OperationMethod<GetTableBucketMaintenanceConfigurationRequest, GetTableBucketMaintenanceConfigurationResponse, GetTableBucketMaintenanceConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetTableBucketMetricsConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the metrics configuration for a table bucket.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableBucketMetricsConfiguration` permission to use this operation.
 */
export declare const getTableBucketMetricsConfiguration: API.OperationMethod<GetTableBucketMetricsConfigurationRequest, GetTableBucketMetricsConfigurationResponse, GetTableBucketMetricsConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetTableBucketPolicyError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details about a table bucket policy. For more information, see Viewing a table bucket policy in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableBucketPolicy` permission to use this operation.
 */
export declare const getTableBucketPolicy: API.OperationMethod<GetTableBucketPolicyRequest, GetTableBucketPolicyResponse, GetTableBucketPolicyError, Credentials | HttpClient.HttpClient>;
export type GetTableBucketReplicationError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the replication configuration for a table bucket.This operation returns the IAM role, `versionToken`, and replication rules that define how tables in this bucket are replicated to other buckets.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableBucketReplication` permission to use this operation.
 */
export declare const getTableBucketReplication: API.OperationMethod<GetTableBucketReplicationRequest, GetTableBucketReplicationResponse, GetTableBucketReplicationError, Credentials | HttpClient.HttpClient>;
export type GetTableBucketStorageClassError = AccessDeniedException | BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the storage class configuration for a specific table. This allows you to view the storage class settings that apply to an individual table, which may differ from the table bucket's default configuration.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableBucketStorageClass` permission to use this operation.
 */
export declare const getTableBucketStorageClass: API.OperationMethod<GetTableBucketStorageClassRequest, GetTableBucketStorageClassResponse, GetTableBucketStorageClassError, Credentials | HttpClient.HttpClient>;
export type GetTableEncryptionError = AccessDeniedException | BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the encryption configuration for a table.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableEncryption` permission to use this operation.
 */
export declare const getTableEncryption: API.OperationMethod<GetTableEncryptionRequest, GetTableEncryptionResponse, GetTableEncryptionError, Credentials | HttpClient.HttpClient>;
export type GetTableMaintenanceConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details about the maintenance configuration of a table. For more information, see S3 Tables maintenance in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * - You must have the `s3tables:GetTableMaintenanceConfiguration` permission to use this operation.
 *
 * - You must have the `s3tables:GetTableData` permission to use set the compaction strategy to `sort` or `zorder`.
 */
export declare const getTableMaintenanceConfiguration: API.OperationMethod<GetTableMaintenanceConfigurationRequest, GetTableMaintenanceConfigurationResponse, GetTableMaintenanceConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetTableMaintenanceJobStatusError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the status of a maintenance job for a table. For more information, see S3 Tables maintenance in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableMaintenanceJobStatus` permission to use this operation.
 */
export declare const getTableMaintenanceJobStatus: API.OperationMethod<GetTableMaintenanceJobStatusRequest, GetTableMaintenanceJobStatusResponse, GetTableMaintenanceJobStatusError, Credentials | HttpClient.HttpClient>;
export type GetTableMetadataLocationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the location of the table metadata.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableMetadataLocation` permission to use this operation.
 */
export declare const getTableMetadataLocation: API.OperationMethod<GetTableMetadataLocationRequest, GetTableMetadataLocationResponse, GetTableMetadataLocationError, Credentials | HttpClient.HttpClient>;
export type GetTablePolicyError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details about a table policy. For more information, see Viewing a table policy in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTablePolicy` permission to use this operation.
 */
export declare const getTablePolicy: API.OperationMethod<GetTablePolicyRequest, GetTablePolicyResponse, GetTablePolicyError, Credentials | HttpClient.HttpClient>;
export type GetTableRecordExpirationConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the expiration configuration settings for records in a table, and the status of the configuration. If the status of the configuration is `enabled`, records expire and are automatically removed from the table after the specified number of days.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableRecordExpirationConfiguration` permission to use this operation.
 */
export declare const getTableRecordExpirationConfiguration: API.OperationMethod<GetTableRecordExpirationConfigurationRequest, GetTableRecordExpirationConfigurationResponse, GetTableRecordExpirationConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetTableRecordExpirationJobStatusError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the status, metrics, and details of the latest record expiration job for a table. This includes when the job ran, and whether it succeeded or failed. If the job ran successfully, this also includes statistics about the records that were removed.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableRecordExpirationJobStatus` permission to use this operation.
 */
export declare const getTableRecordExpirationJobStatus: API.OperationMethod<GetTableRecordExpirationJobStatusRequest, GetTableRecordExpirationJobStatusResponse, GetTableRecordExpirationJobStatusError, Credentials | HttpClient.HttpClient>;
export type GetTableReplicationError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the replication configuration for a specific table.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableReplication` permission to use this operation.
 */
export declare const getTableReplication: API.OperationMethod<GetTableReplicationRequest, GetTableReplicationResponse, GetTableReplicationError, Credentials | HttpClient.HttpClient>;
export type GetTableReplicationStatusError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the replication status for a table, including the status of replication to each destination. This operation provides visibility into replication health and progress.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableReplicationStatus` permission to use this operation.
 */
export declare const getTableReplicationStatus: API.OperationMethod<GetTableReplicationStatusRequest, GetTableReplicationStatusResponse, GetTableReplicationStatusError, Credentials | HttpClient.HttpClient>;
export type GetTableStorageClassError = AccessDeniedException | BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the storage class configuration for a specific table. This allows you to view the storage class settings that apply to an individual table, which may differ from the table bucket's default configuration.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableStorageClass` permission to use this operation.
 */
export declare const getTableStorageClass: API.OperationMethod<GetTableStorageClassRequest, GetTableStorageClassResponse, GetTableStorageClassError, Credentials | HttpClient.HttpClient>;
export type ListNamespacesError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists the namespaces within a table bucket. For more information, see Table namespaces in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:ListNamespaces` permission to use this operation.
 */
export declare const listNamespaces: API.PaginatedOperationMethod<ListNamespacesRequest, ListNamespacesResponse, ListNamespacesError, Credentials | HttpClient.HttpClient, NamespaceSummary>;
export type ListTableBucketsError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists table buckets for your account. For more information, see S3 Table buckets in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:ListTableBuckets` permission to use this operation.
 */
export declare const listTableBuckets: API.PaginatedOperationMethod<ListTableBucketsRequest, ListTableBucketsResponse, ListTableBucketsError, Credentials | HttpClient.HttpClient, TableBucketSummary>;
export type ListTablesError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * List tables in the given table bucket. For more information, see S3 Tables in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:ListTables` permission to use this operation.
 */
export declare const listTables: API.PaginatedOperationMethod<ListTablesRequest, ListTablesResponse, ListTablesError, Credentials | HttpClient.HttpClient, TableSummary>;
export type ListTagsForResourceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists all of the tags applied to a specified Amazon S3 Tables resource. Each tag is a label consisting of a key and value pair. Tags can help you organize, track costs for, and control access to resources.
 *
 * For a list of S3 resources that support tagging, see Managing tags for Amazon S3 resources.
 *
 * ### Permissions
 *
 * For tables and table buckets, you must have the `s3tables:ListTagsForResource` permission to use this operation.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutTableBucketEncryptionError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Sets the encryption configuration for a table bucket.
 *
 * ### Permissions
 *
 * You must have the `s3tables:PutTableBucketEncryption` permission to use this operation.
 *
 * If you choose SSE-KMS encryption you must grant the S3 Tables maintenance principal access to your KMS key. For more information, see Permissions requirements for S3 Tables SSE-KMS encryption in the *Amazon Simple Storage Service User Guide*.
 */
export declare const putTableBucketEncryption: API.OperationMethod<PutTableBucketEncryptionRequest, PutTableBucketEncryptionResponse, PutTableBucketEncryptionError, Credentials | HttpClient.HttpClient>;
export type PutTableBucketMaintenanceConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new maintenance configuration or replaces an existing maintenance configuration for a table bucket. For more information, see Amazon S3 table bucket maintenance in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:PutTableBucketMaintenanceConfiguration` permission to use this operation.
 */
export declare const putTableBucketMaintenanceConfiguration: API.OperationMethod<PutTableBucketMaintenanceConfigurationRequest, PutTableBucketMaintenanceConfigurationResponse, PutTableBucketMaintenanceConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutTableBucketMetricsConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Sets the metrics configuration for a table bucket.
 *
 * ### Permissions
 *
 * You must have the `s3tables:PutTableBucketMetricsConfiguration` permission to use this operation.
 */
export declare const putTableBucketMetricsConfiguration: API.OperationMethod<PutTableBucketMetricsConfigurationRequest, PutTableBucketMetricsConfigurationResponse, PutTableBucketMetricsConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutTableBucketPolicyError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new table bucket policy or replaces an existing table bucket policy for a table bucket. For more information, see Adding a table bucket policy in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:PutTableBucketPolicy` permission to use this operation.
 */
export declare const putTableBucketPolicy: API.OperationMethod<PutTableBucketPolicyRequest, PutTableBucketPolicyResponse, PutTableBucketPolicyError, Credentials | HttpClient.HttpClient>;
export type PutTableBucketReplicationError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates or updates the replication configuration for a table bucket. This operation defines how tables in the source bucket are replicated to destination buckets. Replication helps ensure data availability and disaster recovery across regions or accounts.
 *
 * ### Permissions
 *
 * - You must have the `s3tables:PutTableBucketReplication` permission to use this operation. The IAM role specified in the configuration must have permissions to read from the source bucket and write permissions to all destination buckets.
 *
 * - You must also have the following permissions:
 *
 * - `s3tables:GetTable` permission on the source table.
 *
 * - `s3tables:ListTables` permission on the bucket containing the table.
 *
 * - `s3tables:CreateTable` permission for the destination.
 *
 * - `s3tables:CreateNamespace` permission for the destination.
 *
 * - `s3tables:GetTableMaintenanceConfig` permission for the source bucket.
 *
 * - `s3tables:PutTableMaintenanceConfig` permission for the destination bucket.
 *
 * - You must have `iam:PassRole` permission with condition allowing roles to be passed to `replication.s3tables.amazonaws.com`.
 */
export declare const putTableBucketReplication: API.OperationMethod<PutTableBucketReplicationRequest, PutTableBucketReplicationResponse, PutTableBucketReplicationError, Credentials | HttpClient.HttpClient>;
export type PutTableBucketStorageClassError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Sets or updates the storage class configuration for a table bucket. This configuration serves as the default storage class for all new tables created in the bucket, allowing you to optimize storage costs at the bucket level.
 *
 * ### Permissions
 *
 * You must have the `s3tables:PutTableBucketStorageClass` permission to use this operation.
 */
export declare const putTableBucketStorageClass: API.OperationMethod<PutTableBucketStorageClassRequest, PutTableBucketStorageClassResponse, PutTableBucketStorageClassError, Credentials | HttpClient.HttpClient>;
export type PutTableMaintenanceConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new maintenance configuration or replaces an existing maintenance configuration for a table. For more information, see S3 Tables maintenance in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:PutTableMaintenanceConfiguration` permission to use this operation.
 */
export declare const putTableMaintenanceConfiguration: API.OperationMethod<PutTableMaintenanceConfigurationRequest, PutTableMaintenanceConfigurationResponse, PutTableMaintenanceConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutTablePolicyError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new table policy or replaces an existing table policy for a table. For more information, see Adding a table policy in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:PutTablePolicy` permission to use this operation.
 */
export declare const putTablePolicy: API.OperationMethod<PutTablePolicyRequest, PutTablePolicyResponse, PutTablePolicyError, Credentials | HttpClient.HttpClient>;
export type PutTableRecordExpirationConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates or updates the expiration configuration settings for records in a table, including the status of the configuration. If you enable record expiration for a table, records expire and are automatically removed from the table after the number of days that you specify.
 *
 * ### Permissions
 *
 * You must have the `s3tables:PutTableRecordExpirationConfiguration` permission to use this operation.
 */
export declare const putTableRecordExpirationConfiguration: API.OperationMethod<PutTableRecordExpirationConfigurationRequest, PutTableRecordExpirationConfigurationResponse, PutTableRecordExpirationConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutTableReplicationError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates or updates the replication configuration for a specific table. This operation allows you to define table-level replication independently of bucket-level replication, providing granular control over which tables are replicated and where.
 *
 * ### Permissions
 *
 * - You must have the `s3tables:PutTableReplication` permission to use this operation. The IAM role specified in the configuration must have permissions to read from the source table and write to all destination tables.
 *
 * - You must also have the following permissions:
 *
 * - `s3tables:GetTable` permission on the source table being replicated.
 *
 * - `s3tables:CreateTable` permission for the destination.
 *
 * - `s3tables:CreateNamespace` permission for the destination.
 *
 * - `s3tables:GetTableMaintenanceConfig` permission for the source table.
 *
 * - `s3tables:PutTableMaintenanceConfig` permission for the destination table.
 *
 * - You must have `iam:PassRole` permission with condition allowing roles to be passed to `replication.s3tables.amazonaws.com`.
 */
export declare const putTableReplication: API.OperationMethod<PutTableReplicationRequest, PutTableReplicationResponse, PutTableReplicationError, Credentials | HttpClient.HttpClient>;
export type RenameTableError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Renames a table or a namespace. For more information, see S3 Tables in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:RenameTable` permission to use this operation.
 */
export declare const renameTable: API.OperationMethod<RenameTableRequest, RenameTableResponse, RenameTableError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Applies one or more user-defined tags to an Amazon S3 Tables resource or updates existing tags. Each tag is a label consisting of a key and value pair. Tags can help you organize, track costs for, and control access to your resources. You can add up to 50 tags for each S3 resource.
 *
 * For a list of S3 resources that support tagging, see Managing tags for Amazon S3 resources.
 *
 * ### Permissions
 *
 * For tables and table buckets, you must have the `s3tables:TagResource` permission to use this operation.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes the specified user-defined tags from an Amazon S3 Tables resource. You can pass one or more tag keys.
 *
 * For a list of S3 resources that support tagging, see Managing tags for Amazon S3 resources.
 *
 * ### Permissions
 *
 * For tables and table buckets, you must have the `s3tables:UntagResource` permission to use this operation.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateTableMetadataLocationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the metadata location for a table. The metadata location of a table must be an S3 URI that begins with the table's warehouse location. The metadata location for an Apache Iceberg table must end with `.metadata.json`, or if the metadata file is Gzip-compressed, `.metadata.json.gz`.
 *
 * ### Permissions
 *
 * You must have the `s3tables:UpdateTableMetadataLocation` permission to use this operation.
 */
export declare const updateTableMetadataLocation: API.OperationMethod<UpdateTableMetadataLocationRequest, UpdateTableMetadataLocationResponse, UpdateTableMetadataLocationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=s3tables.d.ts.map