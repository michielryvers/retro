import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ClientToken = string;
export interface DeleteConnectionRecordingPreferencesRequest {
    ClientToken?: string;
}
export interface DeleteConnectionRecordingPreferencesResponse {
    ClientToken?: string;
}
export interface GetConnectionRecordingPreferencesRequest {
}
export type AccountId = string;
export type BucketName = string;
export interface S3Bucket {
    BucketOwner: string;
    BucketName: string;
}
export type S3Buckets = S3Bucket[];
export interface RecordingDestinations {
    S3Buckets: S3Bucket[];
}
export interface ConnectionRecordingPreferences {
    RecordingDestinations: RecordingDestinations;
    KMSKeyArn: string;
}
export interface GetConnectionRecordingPreferencesResponse {
    ClientToken?: string;
    ConnectionRecordingPreferences?: ConnectionRecordingPreferences;
}
export interface UpdateConnectionRecordingPreferencesRequest {
    ConnectionRecordingPreferences: ConnectionRecordingPreferences;
    ClientToken?: string;
}
export interface UpdateConnectionRecordingPreferencesResponse {
    ClientToken?: string;
    ConnectionRecordingPreferences?: ConnectionRecordingPreferences;
}
export type ErrorMessage = string;
export type DeleteConnectionRecordingPreferencesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the preferences for recording RDP connections.
 */
export declare const deleteConnectionRecordingPreferences: API.OperationMethod<DeleteConnectionRecordingPreferencesRequest, DeleteConnectionRecordingPreferencesResponse, DeleteConnectionRecordingPreferencesError, Credentials | HttpClient.HttpClient>;
export type GetConnectionRecordingPreferencesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the preferences specified for recording RDP connections in the requesting Amazon Web Services account and Amazon Web Services Region.
 */
export declare const getConnectionRecordingPreferences: API.OperationMethod<GetConnectionRecordingPreferencesRequest, GetConnectionRecordingPreferencesResponse, GetConnectionRecordingPreferencesError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectionRecordingPreferencesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the preferences for recording RDP connections.
 */
export declare const updateConnectionRecordingPreferences: API.OperationMethod<UpdateConnectionRecordingPreferencesRequest, UpdateConnectionRecordingPreferencesResponse, UpdateConnectionRecordingPreferencesError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ssm-guiconnect.d.ts.map