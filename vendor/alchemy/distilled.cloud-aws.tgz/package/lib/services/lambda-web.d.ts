import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ExecutionRoleNotAssumable_base: S.TaggedErrorClass<"ExecutionRoleNotAssumable", {
    readonly message: any;
}>;
export declare class ExecutionRoleNotAssumable extends /*@__PURE__*/ ExecutionRoleNotAssumable_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type FunctionName = string;
export type Description = string;
export type KmsKeyArn = string;
export interface S3Object {
    bucket: string;
    key: string;
    versionId?: string;
}
export interface CodeConfig {
    s3Object: S3Object;
}
export interface RuntimeConfig {
    runtime: string;
}
export interface BuildConfig {
    codeConfig: CodeConfig;
    runtimeConfig: RuntimeConfig;
}
export type RoleArn = string;
export type EnvironmentVariables = {
    [key: string]: string | undefined;
};
export type ApplicationLogLevel = "TRACE" | "DEBUG" | "INFO" | "WARN" | "ERROR" | "FATAL" | (string & {});
export type SystemLogLevel = "DEBUG" | "INFO" | "WARN" | (string & {});
export interface LoggingConfig {
    logGroup?: string;
    applicationLogLevel?: ApplicationLogLevel;
    systemLogLevel?: SystemLogLevel;
}
export interface TelemetryConfig {
    loggingConfig?: LoggingConfig;
}
export interface ServiceConfig {
    executionRoleArn: string;
    timeoutSeconds?: number;
    egressNetworkConnectorArn?: string;
    maxConcurrencyPerEnvironment?: number;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    telemetryConfig?: TelemetryConfig;
}
export interface RevisionConfig {
    description?: string;
    kmsKeyArn?: string;
    buildConfig: BuildConfig;
    serviceConfig: ServiceConfig;
}
export type EndpointName = string;
export type EndpointType = "HomeRegion" | "MultiRegion" | "PerRegion" | (string & {});
export type AuthType = "ApplicationManaged" | "IamAuth" | (string & {});
export type AutoDeploymentMode = "LatestRevision" | "Disabled" | (string & {});
export type Region = string;
export type RegionList = string[];
export interface ScalingConfig {
    maxEnvironments?: number;
}
export interface ThrottleConfig {
    rateLimit?: number;
}
export interface EndpointConfig {
    endpointName: string;
    description?: string;
    endpointType: EndpointType;
    authType: AuthType;
    autoDeploymentMode?: AutoDeploymentMode;
    regions?: string[];
    scalingConfig?: ScalingConfig;
    throttleConfig?: ThrottleConfig;
}
export type TagKey = string;
export type Tags = {
    [key: string]: string | undefined;
};
export interface CreateWebFunctionRequest {
    functionName: string;
    revisionConfig?: RevisionConfig;
    endpointConfig?: EndpointConfig;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type FunctionArn = string;
export type FunctionState = "Pending" | "Active" | "Failed" | "Deleting" | (string & {});
export type RevisionArn = string;
export type RevisionId = string;
export type RevisionState = "Pending" | "Active" | "Failed" | (string & {});
export interface FunctionRevisionSummary {
    revisionArn: string;
    revisionId: string;
    description?: string;
    state: RevisionState;
    stateReason: string;
    createdAt: Date;
}
export type EndpointArn = string;
export type DomainName = string;
export interface RevisionWeight {
    revisionId: string;
    weight: number;
}
export type RevisionWeightList = RevisionWeight[];
export type EndpointState = "Pending" | "Active" | "Failed" | "Deleting" | (string & {});
export type EndpointUpdateStatus = "InProgress" | "Successful" | "Failed" | (string & {});
export interface FunctionEndpointSummary {
    endpointArn: string;
    endpointName: string;
    description?: string;
    endpointType: EndpointType;
    domainName: string;
    authType: AuthType;
    autoDeploymentMode: AutoDeploymentMode;
    revisionWeights: RevisionWeight[];
    regions: string[];
    scalingConfig?: ScalingConfig;
    throttleConfig?: ThrottleConfig;
    state: EndpointState;
    stateReason: string;
    updateStatus?: EndpointUpdateStatus;
    updateStatusReason?: string;
    createdAt: Date;
    updatedAt: Date;
}
export interface CreateWebFunctionResponse {
    functionName: string;
    functionArn: string;
    state: FunctionState;
    stateReason: string;
    createdAt: Date;
    updatedAt: Date;
    revision?: FunctionRevisionSummary;
    endpoint?: FunctionEndpointSummary;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateWebFunctionEndpointRequest {
    functionName: string;
    endpointName: string;
    description?: string;
    endpointType: EndpointType;
    authType: AuthType;
    autoDeploymentMode?: AutoDeploymentMode;
    revisionWeights?: RevisionWeight[];
    regions?: string[];
    scalingConfig?: ScalingConfig;
    throttleConfig?: ThrottleConfig;
}
export interface RegionalEndpoint {
    domainName?: string;
    authType: AuthType;
    revisionWeights: RevisionWeight[];
    scalingConfig?: ScalingConfig;
    throttleConfig?: ThrottleConfig;
    state: EndpointState;
    stateReason: string;
    updateStatus?: EndpointUpdateStatus;
    updateStatusReason?: string;
}
export type RegionalEndpoints = {
    [key: string]: RegionalEndpoint | undefined;
};
export interface CreateWebFunctionEndpointResponse {
    functionArn: string;
    endpointArn: string;
    endpointName: string;
    description?: string;
    endpointType: EndpointType;
    domainName: string;
    authType: AuthType;
    autoDeploymentMode: AutoDeploymentMode;
    revisionWeights: RevisionWeight[];
    regions: string[];
    scalingConfig?: ScalingConfig;
    throttleConfig?: ThrottleConfig;
    state: EndpointState;
    stateReason: string;
    updateStatus?: EndpointUpdateStatus;
    updateStatusReason?: string;
    regionalEndpoints: {
        [key: string]: RegionalEndpoint | undefined;
    };
    createdAt: Date;
    updatedAt: Date;
}
export interface CreateWebFunctionRevisionRequest {
    functionName: string;
    description?: string;
    kmsKeyArn?: string;
    buildConfig: BuildConfig;
    serviceConfig: ServiceConfig;
}
export interface RevisionError {
    attribute: string;
    errorCode: string;
    errorMessage: string;
}
export type RevisionErrors = RevisionError[];
export interface CreateWebFunctionRevisionResponse {
    functionArn: string;
    revisionArn: string;
    revisionId: string;
    description?: string;
    kmsKeyArn?: string;
    buildConfig: BuildConfig;
    serviceConfig: ServiceConfig;
    state: RevisionState;
    stateReason: string;
    errors?: RevisionError[];
    createdAt: Date;
}
export type ResourceArn = string;
export type PolicyRevisionId = string;
export interface DeleteResourcePolicyRequest {
    resourceArn: string;
    revisionId?: string;
}
export interface DeleteResourcePolicyResponse {
}
export interface DeleteWebFunctionRequest {
    functionName: string;
}
export interface DeleteWebFunctionResponse {
}
export interface DeleteWebFunctionEndpointRequest {
    functionName: string;
    endpointName: string;
}
export interface DeleteWebFunctionEndpointResponse {
}
export interface DeleteWebFunctionRevisionRequest {
    functionName: string;
    revisionId: string;
}
export interface DeleteWebFunctionRevisionResponse {
}
export interface GetResourcePolicyRequest {
    resourceArn: string;
}
export type ResourcePolicy = string;
export interface GetResourcePolicyResponse {
    policy: string;
    revisionId: string;
}
export interface GetWebAccountSettingsRequest {
}
export interface AccountQuotas {
    maxTotalArmVCpus: number;
    maxTotalRateLimit: number;
    maxRevisionsPerFunction: number;
    maxEndpointsPerFunction: number;
}
export interface AccountUsage {
    functionCount: number;
}
export interface GetWebAccountSettingsResponse {
    accountQuotas: AccountQuotas;
    accountUsage: AccountUsage;
}
export interface GetWebFunctionRequest {
    functionName: string;
}
export interface GetWebFunctionResponse {
    functionName: string;
    functionArn: string;
    state: FunctionState;
    stateReason: string;
    createdAt: Date;
    updatedAt: Date;
}
export interface GetWebFunctionEndpointRequest {
    functionName: string;
    endpointName: string;
}
export interface GetWebFunctionEndpointResponse {
    functionArn: string;
    endpointArn: string;
    endpointName: string;
    description?: string;
    endpointType: EndpointType;
    domainName: string;
    authType: AuthType;
    autoDeploymentMode: AutoDeploymentMode;
    revisionWeights: RevisionWeight[];
    regions: string[];
    scalingConfig?: ScalingConfig;
    throttleConfig?: ThrottleConfig;
    state: EndpointState;
    stateReason: string;
    updateStatus?: EndpointUpdateStatus;
    updateStatusReason?: string;
    regionalEndpoints: {
        [key: string]: RegionalEndpoint | undefined;
    };
    createdAt: Date;
    updatedAt: Date;
}
export interface GetWebFunctionRevisionRequest {
    functionName: string;
    revisionId: string;
}
export interface GetWebFunctionRevisionResponse {
    functionArn: string;
    revisionArn: string;
    revisionId: string;
    description?: string;
    kmsKeyArn?: string;
    buildConfig: BuildConfig;
    serviceConfig: ServiceConfig;
    state: RevisionState;
    stateReason: string;
    errors?: RevisionError[];
    createdAt: Date;
}
export interface ListTagsRequest {
    resource: string;
}
export interface ListTagsResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export type FilterValueList = string[];
export interface Filter {
    name: string;
    values: string[];
}
export type FilterList = Filter[];
export type MaxResults = number;
export type NextToken = string;
export interface ListWebFunctionEndpointsRequest {
    functionName: string;
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export type FunctionEndpointSummaryList = FunctionEndpointSummary[];
export interface ListWebFunctionEndpointsResponse {
    endpoints: FunctionEndpointSummary[];
    nextToken?: string;
}
export interface ListWebFunctionRevisionsRequest {
    functionName: string;
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export type FunctionRevisionSummaryList = FunctionRevisionSummary[];
export interface ListWebFunctionRevisionsResponse {
    revisions: FunctionRevisionSummary[];
    nextToken?: string;
}
export interface ListWebFunctionsRequest {
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export interface FunctionSummary {
    functionName: string;
    functionArn: string;
    state: FunctionState;
    stateReason: string;
    createdAt: Date;
    updatedAt: Date;
}
export type FunctionSummaryList = FunctionSummary[];
export interface ListWebFunctionsResponse {
    functions: FunctionSummary[];
    nextToken?: string;
}
export interface PutResourcePolicyRequest {
    resourceArn: string;
    policy: string;
    revisionId?: string;
}
export interface PutResourcePolicyResponse {
    policy: string;
    revisionId: string;
}
export interface TagResourceRequest {
    resource: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resource: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateWebFunctionEndpointRequest {
    functionName: string;
    endpointName: string;
    description?: string;
    authType?: AuthType;
    autoDeploymentMode?: AutoDeploymentMode;
    revisionWeights?: RevisionWeight[];
    scalingConfig?: ScalingConfig;
    throttleConfig?: ThrottleConfig;
}
export interface UpdateWebFunctionEndpointResponse {
    functionArn: string;
    endpointArn: string;
    endpointName: string;
    description?: string;
    endpointType: EndpointType;
    domainName: string;
    authType: AuthType;
    autoDeploymentMode: AutoDeploymentMode;
    revisionWeights: RevisionWeight[];
    regions: string[];
    scalingConfig?: ScalingConfig;
    throttleConfig?: ThrottleConfig;
    state: EndpointState;
    stateReason: string;
    updateStatus?: EndpointUpdateStatus;
    updateStatusReason?: string;
    regionalEndpoints: {
        [key: string]: RegionalEndpoint | undefined;
    };
    createdAt: Date;
    updatedAt: Date;
}
export type CreateWebFunctionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | ExecutionRoleNotAssumable | CommonErrors;
/**
 * Creates a web function with an initial revision and endpoint. To create a web function, you provide the function name, revision configuration (code and service settings), and endpoint configuration.
 *
 * To use this operation, you must have the `CreateWebFunction` permission on the web function. You don't need separate permissions for the initial revision or endpoint.
 */
export declare const createWebFunction: API.OperationMethod<CreateWebFunctionRequest, CreateWebFunctionResponse, CreateWebFunctionError, Credentials | HttpClient.HttpClient>;
export type CreateWebFunctionEndpointError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an endpoint for a web function. An endpoint exposes the web function over HTTPS and routes traffic to one or more revisions.
 *
 * To use this operation, you must have the `CreateWebFunctionEndpoint` permission on the web function, not on the endpoint being created.
 */
export declare const createWebFunctionEndpoint: API.OperationMethod<CreateWebFunctionEndpointRequest, CreateWebFunctionEndpointResponse, CreateWebFunctionEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateWebFunctionRevisionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | ExecutionRoleNotAssumable | CommonErrors;
/**
 * Creates an immutable revision for a web function. A revision represents a specific version of the function code and configuration.
 *
 * To use this operation, you must have the `CreateWebFunctionRevision` permission on the web function, not on the revision being created.
 */
export declare const createWebFunctionRevision: API.OperationMethod<CreateWebFunctionRevisionRequest, CreateWebFunctionRevisionResponse, CreateWebFunctionRevisionError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the resource-based policy from a web function.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteWebFunctionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a web function and all of its associated revisions and endpoints.
 *
 * To use this operation, you must have the `DeleteWebFunction` permission on the web function. You don't need the `DeleteWebFunctionRevision` or `DeleteWebFunctionEndpoint` permission.
 */
export declare const deleteWebFunction: API.OperationMethod<DeleteWebFunctionRequest, DeleteWebFunctionResponse, DeleteWebFunctionError, Credentials | HttpClient.HttpClient>;
export type DeleteWebFunctionEndpointError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a web function endpoint.
 */
export declare const deleteWebFunctionEndpoint: API.OperationMethod<DeleteWebFunctionEndpointRequest, DeleteWebFunctionEndpointResponse, DeleteWebFunctionEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteWebFunctionRevisionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a web function revision. You cannot delete a revision that is currently serving traffic on an endpoint.
 */
export declare const deleteWebFunctionRevision: API.OperationMethod<DeleteWebFunctionRevisionRequest, DeleteWebFunctionRevisionResponse, DeleteWebFunctionRevisionError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the resource-based policy attached to a web function.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetWebAccountSettingsError = AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Retrieves details about your AWS Lambda Web Functions account settings for the current AWS Region, including the quotas that apply to web functions and your current usage.
 */
export declare const getWebAccountSettings: API.OperationMethod<GetWebAccountSettingsRequest, GetWebAccountSettingsResponse, GetWebAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type GetWebFunctionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about a web function, including its current state and configuration.
 */
export declare const getWebFunction: API.OperationMethod<GetWebFunctionRequest, GetWebFunctionResponse, GetWebFunctionError, Credentials | HttpClient.HttpClient>;
export type GetWebFunctionEndpointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about a web function endpoint, including its current state, configuration, and domain name.
 */
export declare const getWebFunctionEndpoint: API.OperationMethod<GetWebFunctionEndpointRequest, GetWebFunctionEndpointResponse, GetWebFunctionEndpointError, Credentials | HttpClient.HttpClient>;
export type GetWebFunctionRevisionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about a web function revision, including its state and configuration.
 */
export declare const getWebFunctionRevision: API.OperationMethod<GetWebFunctionRevisionRequest, GetWebFunctionRevisionResponse, GetWebFunctionRevisionError, Credentials | HttpClient.HttpClient>;
export type ListTagsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of tags applied to a web function.
 */
export declare const listTags: API.OperationMethod<ListTagsRequest, ListTagsResponse, ListTagsError, Credentials | HttpClient.HttpClient>;
export type ListWebFunctionEndpointsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists endpoints for a web function. Use pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listWebFunctionEndpoints: API.PaginatedOperationMethod<ListWebFunctionEndpointsRequest, ListWebFunctionEndpointsResponse, ListWebFunctionEndpointsError, Credentials | HttpClient.HttpClient, FunctionEndpointSummary>;
export type ListWebFunctionRevisionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists revisions for a web function. Use pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listWebFunctionRevisions: API.PaginatedOperationMethod<ListWebFunctionRevisionsRequest, ListWebFunctionRevisionsResponse, ListWebFunctionRevisionsError, Credentials | HttpClient.HttpClient, FunctionRevisionSummary>;
export type ListWebFunctionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists web functions in your account. Use pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listWebFunctions: API.PaginatedOperationMethod<ListWebFunctionsRequest, ListWebFunctionsResponse, ListWebFunctionsError, Credentials | HttpClient.HttpClient, FunctionSummary>;
export type PutResourcePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds or updates a resource-based policy on a web function. A resource-based policy grants permissions to other AWS accounts or services to perform actions on the web function.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds tags to a web function. If a tag key already exists, the existing value is overwritten with the new value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes tags from a web function.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateWebFunctionEndpointError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of a web function endpoint. You can modify the authorization type, auto-deployment mode, revision weights, scaling, and throttling settings.
 */
export declare const updateWebFunctionEndpoint: API.OperationMethod<UpdateWebFunctionEndpointRequest, UpdateWebFunctionEndpointResponse, UpdateWebFunctionEndpointError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=lambda-web.d.ts.map