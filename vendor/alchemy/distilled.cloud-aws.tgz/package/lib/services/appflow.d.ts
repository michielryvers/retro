import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ConnectorAuthenticationException_base: S.TaggedErrorClass<"ConnectorAuthenticationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ConnectorAuthenticationException extends /*@__PURE__*/ ConnectorAuthenticationException_base {
}
declare const ConnectorServerException_base: S.TaggedErrorClass<"ConnectorServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConnectorServerException extends /*@__PURE__*/ ConnectorServerException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnsupportedOperationException_base: S.TaggedErrorClass<"UnsupportedOperationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type FlowName = string;
export type ExecutionId = string;
export type ExecutionIds = string[];
export interface CancelFlowExecutionsRequest {
    flowName: string;
    executionIds?: string[];
}
export interface CancelFlowExecutionsResponse {
    invalidExecutions?: string[];
}
export type ConnectorProfileName = string;
export type KMSArn = string;
export type ConnectorType = "Salesforce" | "Singular" | "Slack" | "Redshift" | "S3" | "Marketo" | "Googleanalytics" | "Zendesk" | "Servicenow" | "Datadog" | "Trendmicro" | "Snowflake" | "Dynatrace" | "Infornexus" | "Amplitude" | "Veeva" | "EventBridge" | "LookoutMetrics" | "Upsolver" | "Honeycode" | "CustomerProfiles" | "SAPOData" | "CustomConnector" | "Pardot" | (string & {});
export type ConnectorLabel = string;
export type ConnectionMode = "Public" | "Private" | (string & {});
export interface AmplitudeConnectorProfileProperties {
}
export type InstanceUrl = string;
export interface DatadogConnectorProfileProperties {
    instanceUrl: string;
}
export interface DynatraceConnectorProfileProperties {
    instanceUrl: string;
}
export interface GoogleAnalyticsConnectorProfileProperties {
}
export interface HoneycodeConnectorProfileProperties {
}
export interface InforNexusConnectorProfileProperties {
    instanceUrl: string;
}
export interface MarketoConnectorProfileProperties {
    instanceUrl: string;
}
export type DatabaseUrl = string;
export type BucketName = string;
export type BucketPrefix = string;
export type RoleArn = string;
export type DataApiRoleArn = string;
export type ClusterIdentifier = string;
export type WorkgroupName = string;
export type DatabaseName = string;
export interface RedshiftConnectorProfileProperties {
    databaseUrl?: string;
    bucketName: string;
    bucketPrefix?: string;
    roleArn: string;
    dataApiRoleArn?: string;
    isRedshiftServerless?: boolean;
    clusterIdentifier?: string;
    workgroupName?: string;
    databaseName?: string;
}
export interface SalesforceConnectorProfileProperties {
    instanceUrl?: string;
    isSandboxEnvironment?: boolean;
    usePrivateLinkForMetadataAndAuthorization?: boolean;
}
export interface ServiceNowConnectorProfileProperties {
    instanceUrl: string;
}
export interface SingularConnectorProfileProperties {
}
export interface SlackConnectorProfileProperties {
    instanceUrl: string;
}
export type Warehouse = string;
export type Stage = string;
export type PrivateLinkServiceName = string;
export type AccountName = string;
export type Region = string;
export interface SnowflakeConnectorProfileProperties {
    warehouse: string;
    stage: string;
    bucketName: string;
    bucketPrefix?: string;
    privateLinkServiceName?: string;
    accountName?: string;
    region?: string;
}
export interface TrendmicroConnectorProfileProperties {
}
export interface VeevaConnectorProfileProperties {
    instanceUrl: string;
}
export interface ZendeskConnectorProfileProperties {
    instanceUrl: string;
}
export type ApplicationHostUrl = string;
export type ApplicationServicePath = string;
export type PortNumber = number;
export type ClientNumber = string;
export type LogonLanguage = string;
export type TokenUrl = string;
export type AuthCodeUrl = string;
export type OAuthScope = string;
export type OAuthScopeList = string[];
export interface OAuthProperties {
    tokenUrl: string;
    authCodeUrl: string;
    oAuthScopes: string[];
}
export interface SAPODataConnectorProfileProperties {
    applicationHostUrl: string;
    applicationServicePath: string;
    portNumber: number;
    clientNumber: string;
    logonLanguage?: string;
    privateLinkServiceName?: string;
    oAuthProperties?: OAuthProperties;
    disableSSO?: boolean;
}
export type ProfilePropertyKey = string;
export type ProfilePropertyValue = string;
export type ProfilePropertiesMap = {
    [key: string]: string | undefined;
};
export type OAuth2GrantType = "CLIENT_CREDENTIALS" | "AUTHORIZATION_CODE" | "JWT_BEARER" | (string & {});
export type CustomPropertyKey = string;
export type CustomPropertyValue = string;
export type TokenUrlCustomProperties = {
    [key: string]: string | undefined;
};
export interface OAuth2Properties {
    tokenUrl: string;
    oAuth2GrantType: OAuth2GrantType;
    tokenUrlCustomProperties?: {
        [key: string]: string | undefined;
    };
}
export interface CustomConnectorProfileProperties {
    profileProperties?: {
        [key: string]: string | undefined;
    };
    oAuth2Properties?: OAuth2Properties;
}
export type BusinessUnitId = string;
export interface PardotConnectorProfileProperties {
    instanceUrl?: string;
    isSandboxEnvironment?: boolean;
    businessUnitId?: string;
}
export interface ConnectorProfileProperties {
    Amplitude?: AmplitudeConnectorProfileProperties;
    Datadog?: DatadogConnectorProfileProperties;
    Dynatrace?: DynatraceConnectorProfileProperties;
    GoogleAnalytics?: GoogleAnalyticsConnectorProfileProperties;
    Honeycode?: HoneycodeConnectorProfileProperties;
    InforNexus?: InforNexusConnectorProfileProperties;
    Marketo?: MarketoConnectorProfileProperties;
    Redshift?: RedshiftConnectorProfileProperties;
    Salesforce?: SalesforceConnectorProfileProperties;
    ServiceNow?: ServiceNowConnectorProfileProperties;
    Singular?: SingularConnectorProfileProperties;
    Slack?: SlackConnectorProfileProperties;
    Snowflake?: SnowflakeConnectorProfileProperties;
    Trendmicro?: TrendmicroConnectorProfileProperties;
    Veeva?: VeevaConnectorProfileProperties;
    Zendesk?: ZendeskConnectorProfileProperties;
    SAPOData?: SAPODataConnectorProfileProperties;
    CustomConnector?: CustomConnectorProfileProperties;
    Pardot?: PardotConnectorProfileProperties;
}
export type ApiKey = string | redacted.Redacted<string>;
export type SecretKey = string | redacted.Redacted<string>;
export interface AmplitudeConnectorProfileCredentials {
    apiKey: string | redacted.Redacted<string>;
    secretKey: string | redacted.Redacted<string>;
}
export type ApplicationKey = string;
export interface DatadogConnectorProfileCredentials {
    apiKey: string | redacted.Redacted<string>;
    applicationKey: string | redacted.Redacted<string>;
}
export type ApiToken = string;
export interface DynatraceConnectorProfileCredentials {
    apiToken: string | redacted.Redacted<string>;
}
export type ClientId = string;
export type ClientSecret = string | redacted.Redacted<string>;
export type AccessToken = string | redacted.Redacted<string>;
export type RefreshToken = string;
export type AuthCode = string;
export type RedirectUri = string;
export type CodeVerifier = string | redacted.Redacted<string>;
export interface ConnectorOAuthRequest {
    authCode?: string;
    redirectUri?: string;
    codeVerifier?: string | redacted.Redacted<string>;
}
export interface GoogleAnalyticsConnectorProfileCredentials {
    clientId: string;
    clientSecret: string | redacted.Redacted<string>;
    accessToken?: string | redacted.Redacted<string>;
    refreshToken?: string | redacted.Redacted<string>;
    oAuthRequest?: ConnectorOAuthRequest;
}
export interface HoneycodeConnectorProfileCredentials {
    accessToken?: string | redacted.Redacted<string>;
    refreshToken?: string | redacted.Redacted<string>;
    oAuthRequest?: ConnectorOAuthRequest;
}
export type AccessKeyId = string | redacted.Redacted<string>;
export type Username = string;
export type Key = string;
export interface InforNexusConnectorProfileCredentials {
    accessKeyId: string | redacted.Redacted<string>;
    userId: string;
    secretAccessKey: string | redacted.Redacted<string>;
    datakey: string | redacted.Redacted<string>;
}
export interface MarketoConnectorProfileCredentials {
    clientId: string;
    clientSecret: string | redacted.Redacted<string>;
    accessToken?: string | redacted.Redacted<string>;
    oAuthRequest?: ConnectorOAuthRequest;
}
export type Password = string | redacted.Redacted<string>;
export interface RedshiftConnectorProfileCredentials {
    username?: string;
    password?: string | redacted.Redacted<string>;
}
export type ClientCredentialsArn = string | redacted.Redacted<string>;
export type JwtToken = string | redacted.Redacted<string>;
export interface SalesforceConnectorProfileCredentials {
    accessToken?: string | redacted.Redacted<string>;
    refreshToken?: string | redacted.Redacted<string>;
    oAuthRequest?: ConnectorOAuthRequest;
    clientCredentialsArn?: string | redacted.Redacted<string>;
    oAuth2GrantType?: OAuth2GrantType;
    jwtToken?: string | redacted.Redacted<string>;
}
export interface OAuth2Credentials {
    clientId?: string;
    clientSecret?: string | redacted.Redacted<string>;
    accessToken?: string | redacted.Redacted<string>;
    refreshToken?: string | redacted.Redacted<string>;
    oAuthRequest?: ConnectorOAuthRequest;
}
export interface ServiceNowConnectorProfileCredentials {
    username?: string;
    password?: string | redacted.Redacted<string>;
    oAuth2Credentials?: OAuth2Credentials;
}
export interface SingularConnectorProfileCredentials {
    apiKey: string | redacted.Redacted<string>;
}
export interface SlackConnectorProfileCredentials {
    clientId: string;
    clientSecret: string | redacted.Redacted<string>;
    accessToken?: string | redacted.Redacted<string>;
    oAuthRequest?: ConnectorOAuthRequest;
}
export type PrivateKey = string | redacted.Redacted<string>;
export interface SnowflakeConnectorProfileCredentials {
    username: string;
    password?: string | redacted.Redacted<string>;
    privateKey?: string | redacted.Redacted<string>;
}
export type ApiSecretKey = string | redacted.Redacted<string>;
export interface TrendmicroConnectorProfileCredentials {
    apiSecretKey: string | redacted.Redacted<string>;
}
export interface VeevaConnectorProfileCredentials {
    username: string;
    password: string | redacted.Redacted<string>;
}
export interface ZendeskConnectorProfileCredentials {
    clientId: string;
    clientSecret: string | redacted.Redacted<string>;
    accessToken?: string | redacted.Redacted<string>;
    oAuthRequest?: ConnectorOAuthRequest;
}
export interface BasicAuthCredentials {
    username: string;
    password: string | redacted.Redacted<string>;
}
export interface OAuthCredentials {
    clientId: string;
    clientSecret: string | redacted.Redacted<string>;
    accessToken?: string | redacted.Redacted<string>;
    refreshToken?: string | redacted.Redacted<string>;
    oAuthRequest?: ConnectorOAuthRequest;
}
export interface SAPODataConnectorProfileCredentials {
    basicAuthCredentials?: BasicAuthCredentials;
    oAuthCredentials?: OAuthCredentials;
}
export type AuthenticationType = "OAUTH2" | "APIKEY" | "BASIC" | "CUSTOM" | (string & {});
export interface ApiKeyCredentials {
    apiKey: string | redacted.Redacted<string>;
    apiSecretKey?: string | redacted.Redacted<string>;
}
export type CustomAuthenticationType = string;
export type CredentialsMapKey = string | redacted.Redacted<string>;
export type CredentialsMapValue = string | redacted.Redacted<string>;
export type CredentialsMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export interface CustomAuthCredentials {
    customAuthenticationType: string;
    credentialsMap?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export interface CustomConnectorProfileCredentials {
    authenticationType: AuthenticationType;
    basic?: BasicAuthCredentials;
    oauth2?: OAuth2Credentials;
    apiKey?: ApiKeyCredentials;
    custom?: CustomAuthCredentials;
}
export interface PardotConnectorProfileCredentials {
    accessToken?: string | redacted.Redacted<string>;
    refreshToken?: string | redacted.Redacted<string>;
    oAuthRequest?: ConnectorOAuthRequest;
    clientCredentialsArn?: string | redacted.Redacted<string>;
}
export interface ConnectorProfileCredentials {
    Amplitude?: AmplitudeConnectorProfileCredentials;
    Datadog?: DatadogConnectorProfileCredentials;
    Dynatrace?: DynatraceConnectorProfileCredentials;
    GoogleAnalytics?: GoogleAnalyticsConnectorProfileCredentials;
    Honeycode?: HoneycodeConnectorProfileCredentials;
    InforNexus?: InforNexusConnectorProfileCredentials;
    Marketo?: MarketoConnectorProfileCredentials;
    Redshift?: RedshiftConnectorProfileCredentials;
    Salesforce?: SalesforceConnectorProfileCredentials;
    ServiceNow?: ServiceNowConnectorProfileCredentials;
    Singular?: SingularConnectorProfileCredentials;
    Slack?: SlackConnectorProfileCredentials;
    Snowflake?: SnowflakeConnectorProfileCredentials;
    Trendmicro?: TrendmicroConnectorProfileCredentials;
    Veeva?: VeevaConnectorProfileCredentials;
    Zendesk?: ZendeskConnectorProfileCredentials;
    SAPOData?: SAPODataConnectorProfileCredentials;
    CustomConnector?: CustomConnectorProfileCredentials;
    Pardot?: PardotConnectorProfileCredentials;
}
export interface ConnectorProfileConfig {
    connectorProfileProperties: ConnectorProfileProperties;
    connectorProfileCredentials?: ConnectorProfileCredentials;
}
export type ClientToken = string;
export interface CreateConnectorProfileRequest {
    connectorProfileName: string;
    kmsArn?: string;
    connectorType: ConnectorType;
    connectorLabel?: string;
    connectionMode: ConnectionMode;
    connectorProfileConfig: ConnectorProfileConfig;
    clientToken?: string;
}
export type ConnectorProfileArn = string;
export interface CreateConnectorProfileResponse {
    connectorProfileArn?: string;
}
export type FlowDescription = string;
export type TriggerType = "Scheduled" | "Event" | "OnDemand" | (string & {});
export type ScheduleExpression = string;
export type DataPullMode = "Incremental" | "Complete" | (string & {});
export type Timezone = string;
export type ScheduleOffset = number;
export type FlowErrorDeactivationThreshold = number;
export interface ScheduledTriggerProperties {
    scheduleExpression: string;
    dataPullMode?: DataPullMode;
    scheduleStartTime?: Date;
    scheduleEndTime?: Date;
    timezone?: string;
    scheduleOffset?: number;
    firstExecutionFrom?: Date;
    flowErrorDeactivationThreshold?: number;
}
export interface TriggerProperties {
    Scheduled?: ScheduledTriggerProperties;
}
export interface TriggerConfig {
    triggerType: TriggerType;
    triggerProperties?: TriggerProperties;
}
export type ApiVersion = string;
export interface AmplitudeSourceProperties {
    object: string;
}
export interface DatadogSourceProperties {
    object: string;
}
export interface DynatraceSourceProperties {
    object: string;
}
export interface GoogleAnalyticsSourceProperties {
    object: string;
}
export interface InforNexusSourceProperties {
    object: string;
}
export interface MarketoSourceProperties {
    object: string;
}
export type S3InputFileType = "CSV" | "JSON" | (string & {});
export interface S3InputFormatConfig {
    s3InputFileType?: S3InputFileType;
}
export interface S3SourceProperties {
    bucketName: string;
    bucketPrefix?: string;
    s3InputFormatConfig?: S3InputFormatConfig;
}
export type SalesforceDataTransferApi = "AUTOMATIC" | "BULKV2" | "REST_SYNC" | (string & {});
export interface SalesforceSourceProperties {
    object: string;
    enableDynamicFieldUpdate?: boolean;
    includeDeletedRecords?: boolean;
    dataTransferApi?: SalesforceDataTransferApi;
}
export interface ServiceNowSourceProperties {
    object: string;
}
export interface SingularSourceProperties {
    object: string;
}
export interface SlackSourceProperties {
    object: string;
}
export interface TrendmicroSourceProperties {
    object: string;
}
export type DocumentType = string;
export interface VeevaSourceProperties {
    object: string;
    documentType?: string;
    includeSourceFiles?: boolean;
    includeRenditions?: boolean;
    includeAllVersions?: boolean;
}
export interface ZendeskSourceProperties {
    object: string;
}
export type SAPODataMaxParallelism = number;
export interface SAPODataParallelismConfig {
    maxParallelism: number;
}
export type SAPODataMaxPageSize = number;
export interface SAPODataPaginationConfig {
    maxPageSize: number;
}
export interface SAPODataSourceProperties {
    objectPath?: string;
    parallelismConfig?: SAPODataParallelismConfig;
    paginationConfig?: SAPODataPaginationConfig;
}
export type EntityName = string;
export type CustomProperties = {
    [key: string]: string | undefined;
};
export type DataTransferApiTypeName = string;
export type DataTransferApiType = "SYNC" | "ASYNC" | "AUTOMATIC" | (string & {});
export interface DataTransferApi {
    Name?: string;
    Type?: DataTransferApiType;
}
export interface CustomConnectorSourceProperties {
    entityName: string;
    customProperties?: {
        [key: string]: string | undefined;
    };
    dataTransferApi?: DataTransferApi;
}
export interface PardotSourceProperties {
    object: string;
}
export interface SourceConnectorProperties {
    Amplitude?: AmplitudeSourceProperties;
    Datadog?: DatadogSourceProperties;
    Dynatrace?: DynatraceSourceProperties;
    GoogleAnalytics?: GoogleAnalyticsSourceProperties;
    InforNexus?: InforNexusSourceProperties;
    Marketo?: MarketoSourceProperties;
    S3?: S3SourceProperties;
    Salesforce?: SalesforceSourceProperties;
    ServiceNow?: ServiceNowSourceProperties;
    Singular?: SingularSourceProperties;
    Slack?: SlackSourceProperties;
    Trendmicro?: TrendmicroSourceProperties;
    Veeva?: VeevaSourceProperties;
    Zendesk?: ZendeskSourceProperties;
    SAPOData?: SAPODataSourceProperties;
    CustomConnector?: CustomConnectorSourceProperties;
    Pardot?: PardotSourceProperties;
}
export type DatetimeTypeFieldName = string;
export interface IncrementalPullConfig {
    datetimeTypeFieldName?: string;
}
export interface SourceFlowConfig {
    connectorType: ConnectorType;
    apiVersion?: string;
    connectorProfileName?: string;
    sourceConnectorProperties: SourceConnectorProperties;
    incrementalPullConfig?: IncrementalPullConfig;
}
export interface ErrorHandlingConfig {
    failOnFirstDestinationError?: boolean;
    bucketPrefix?: string;
    bucketName?: string;
}
export interface RedshiftDestinationProperties {
    object: string;
    intermediateBucketName: string;
    bucketPrefix?: string;
    errorHandlingConfig?: ErrorHandlingConfig;
}
export type FileType = "CSV" | "JSON" | "PARQUET" | (string & {});
export type PrefixType = "FILENAME" | "PATH" | "PATH_AND_FILENAME" | (string & {});
export type PrefixFormat = "YEAR" | "MONTH" | "DAY" | "HOUR" | "MINUTE" | (string & {});
export type PathPrefix = "EXECUTION_ID" | "SCHEMA_VERSION" | (string & {});
export type PathPrefixHierarchy = PathPrefix[];
export interface PrefixConfig {
    prefixType?: PrefixType;
    prefixFormat?: PrefixFormat;
    pathPrefixHierarchy?: PathPrefix[];
}
export type AggregationType = "None" | "SingleFile" | (string & {});
export interface AggregationConfig {
    aggregationType?: AggregationType;
    targetFileSize?: number;
}
export type JavaBoolean = boolean;
export interface S3OutputFormatConfig {
    fileType?: FileType;
    prefixConfig?: PrefixConfig;
    aggregationConfig?: AggregationConfig;
    preserveSourceDataTyping?: boolean;
}
export interface S3DestinationProperties {
    bucketName: string;
    bucketPrefix?: string;
    s3OutputFormatConfig?: S3OutputFormatConfig;
}
export type Name = string;
export type IdFieldNameList = string[];
export type WriteOperationType = "INSERT" | "UPSERT" | "UPDATE" | "DELETE" | (string & {});
export interface SalesforceDestinationProperties {
    object: string;
    idFieldNames?: string[];
    errorHandlingConfig?: ErrorHandlingConfig;
    writeOperationType?: WriteOperationType;
    dataTransferApi?: SalesforceDataTransferApi;
}
export interface SnowflakeDestinationProperties {
    object: string;
    intermediateBucketName: string;
    bucketPrefix?: string;
    errorHandlingConfig?: ErrorHandlingConfig;
}
export interface EventBridgeDestinationProperties {
    object: string;
    errorHandlingConfig?: ErrorHandlingConfig;
}
export interface LookoutMetricsDestinationProperties {
}
export type UpsolverBucketName = string;
export interface UpsolverS3OutputFormatConfig {
    fileType?: FileType;
    prefixConfig: PrefixConfig;
    aggregationConfig?: AggregationConfig;
}
export interface UpsolverDestinationProperties {
    bucketName: string;
    bucketPrefix?: string;
    s3OutputFormatConfig: UpsolverS3OutputFormatConfig;
}
export interface HoneycodeDestinationProperties {
    object: string;
    errorHandlingConfig?: ErrorHandlingConfig;
}
export type DomainName = string;
export type ObjectTypeName = string;
export interface CustomerProfilesDestinationProperties {
    domainName: string;
    objectTypeName?: string;
}
export interface ZendeskDestinationProperties {
    object: string;
    idFieldNames?: string[];
    errorHandlingConfig?: ErrorHandlingConfig;
    writeOperationType?: WriteOperationType;
}
export interface MarketoDestinationProperties {
    object: string;
    errorHandlingConfig?: ErrorHandlingConfig;
}
export interface CustomConnectorDestinationProperties {
    entityName: string;
    errorHandlingConfig?: ErrorHandlingConfig;
    writeOperationType?: WriteOperationType;
    idFieldNames?: string[];
    customProperties?: {
        [key: string]: string | undefined;
    };
}
export interface SuccessResponseHandlingConfig {
    bucketPrefix?: string;
    bucketName?: string;
}
export interface SAPODataDestinationProperties {
    objectPath: string;
    successResponseHandlingConfig?: SuccessResponseHandlingConfig;
    idFieldNames?: string[];
    errorHandlingConfig?: ErrorHandlingConfig;
    writeOperationType?: WriteOperationType;
}
export interface DestinationConnectorProperties {
    Redshift?: RedshiftDestinationProperties;
    S3?: S3DestinationProperties;
    Salesforce?: SalesforceDestinationProperties;
    Snowflake?: SnowflakeDestinationProperties;
    EventBridge?: EventBridgeDestinationProperties;
    LookoutMetrics?: LookoutMetricsDestinationProperties;
    Upsolver?: UpsolverDestinationProperties;
    Honeycode?: HoneycodeDestinationProperties;
    CustomerProfiles?: CustomerProfilesDestinationProperties;
    Zendesk?: ZendeskDestinationProperties;
    Marketo?: MarketoDestinationProperties;
    CustomConnector?: CustomConnectorDestinationProperties;
    SAPOData?: SAPODataDestinationProperties;
}
export interface DestinationFlowConfig {
    connectorType: ConnectorType;
    apiVersion?: string;
    connectorProfileName?: string;
    destinationConnectorProperties: DestinationConnectorProperties;
}
export type DestinationFlowConfigList = DestinationFlowConfig[];
export type SourceFields = string[];
export type AmplitudeConnectorOperator = "BETWEEN" | (string & {});
export type DatadogConnectorOperator = "PROJECTION" | "BETWEEN" | "EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type DynatraceConnectorOperator = "PROJECTION" | "BETWEEN" | "EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type GoogleAnalyticsConnectorOperator = "PROJECTION" | "BETWEEN" | (string & {});
export type InforNexusConnectorOperator = "PROJECTION" | "BETWEEN" | "EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type MarketoConnectorOperator = "PROJECTION" | "LESS_THAN" | "GREATER_THAN" | "BETWEEN" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type S3ConnectorOperator = "PROJECTION" | "LESS_THAN" | "GREATER_THAN" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type SalesforceConnectorOperator = "PROJECTION" | "LESS_THAN" | "CONTAINS" | "GREATER_THAN" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type ServiceNowConnectorOperator = "PROJECTION" | "CONTAINS" | "LESS_THAN" | "GREATER_THAN" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type SingularConnectorOperator = "PROJECTION" | "EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type SlackConnectorOperator = "PROJECTION" | "LESS_THAN" | "GREATER_THAN" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type TrendmicroConnectorOperator = "PROJECTION" | "EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type VeevaConnectorOperator = "PROJECTION" | "LESS_THAN" | "GREATER_THAN" | "CONTAINS" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type ZendeskConnectorOperator = "PROJECTION" | "GREATER_THAN" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type SAPODataConnectorOperator = "PROJECTION" | "LESS_THAN" | "CONTAINS" | "GREATER_THAN" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type Operator = "PROJECTION" | "LESS_THAN" | "GREATER_THAN" | "CONTAINS" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type PardotConnectorOperator = "PROJECTION" | "EQUAL_TO" | "NO_OP" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | (string & {});
export interface ConnectorOperator {
    Amplitude?: AmplitudeConnectorOperator;
    Datadog?: DatadogConnectorOperator;
    Dynatrace?: DynatraceConnectorOperator;
    GoogleAnalytics?: GoogleAnalyticsConnectorOperator;
    InforNexus?: InforNexusConnectorOperator;
    Marketo?: MarketoConnectorOperator;
    S3?: S3ConnectorOperator;
    Salesforce?: SalesforceConnectorOperator;
    ServiceNow?: ServiceNowConnectorOperator;
    Singular?: SingularConnectorOperator;
    Slack?: SlackConnectorOperator;
    Trendmicro?: TrendmicroConnectorOperator;
    Veeva?: VeevaConnectorOperator;
    Zendesk?: ZendeskConnectorOperator;
    SAPOData?: SAPODataConnectorOperator;
    CustomConnector?: Operator;
    Pardot?: PardotConnectorOperator;
}
export type DestinationField = string;
export type TaskType = "Arithmetic" | "Filter" | "Map" | "Map_all" | "Mask" | "Merge" | "Passthrough" | "Truncate" | "Validate" | "Partition" | (string & {});
export type OperatorPropertiesKeys = "VALUE" | "VALUES" | "DATA_TYPE" | "UPPER_BOUND" | "LOWER_BOUND" | "SOURCE_DATA_TYPE" | "DESTINATION_DATA_TYPE" | "VALIDATION_ACTION" | "MASK_VALUE" | "MASK_LENGTH" | "TRUNCATE_LENGTH" | "MATH_OPERATION_FIELDS_ORDER" | "CONCAT_FORMAT" | "SUBFIELD_CATEGORY_MAP" | "EXCLUDE_SOURCE_FIELDS_LIST" | "INCLUDE_NEW_FIELDS" | "ORDERED_PARTITION_KEYS_LIST" | (string & {});
export type Property = string;
export type TaskPropertiesMap = {
    [key in OperatorPropertiesKeys]?: string;
};
export interface Task {
    sourceFields: string[];
    connectorOperator?: ConnectorOperator;
    destinationField?: string;
    taskType: TaskType;
    taskProperties?: {
        [key: string]: string | undefined;
    };
}
export type Tasks = Task[];
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type GlueDataCatalogIAMRole = string;
export type GlueDataCatalogDatabaseName = string;
export type GlueDataCatalogTablePrefix = string;
export interface GlueDataCatalogConfig {
    roleArn: string;
    databaseName: string;
    tablePrefix: string;
}
export interface MetadataCatalogConfig {
    glueDataCatalog?: GlueDataCatalogConfig;
}
export interface CreateFlowRequest {
    flowName: string;
    description?: string;
    kmsArn?: string;
    triggerConfig: TriggerConfig;
    sourceFlowConfig: SourceFlowConfig;
    destinationFlowConfigList: DestinationFlowConfig[];
    tasks: Task[];
    tags?: {
        [key: string]: string | undefined;
    };
    metadataCatalogConfig?: MetadataCatalogConfig;
    clientToken?: string;
}
export type FlowArn = string;
export type FlowStatus = "Active" | "Deprecated" | "Deleted" | "Draft" | "Errored" | "Suspended" | (string & {});
export interface CreateFlowResponse {
    flowArn?: string;
    flowStatus?: FlowStatus;
}
export interface DeleteConnectorProfileRequest {
    connectorProfileName: string;
    forceDelete?: boolean;
}
export interface DeleteConnectorProfileResponse {
}
export interface DeleteFlowRequest {
    flowName: string;
    forceDelete?: boolean;
}
export interface DeleteFlowResponse {
}
export interface DescribeConnectorRequest {
    connectorType: ConnectorType;
    connectorLabel?: string;
}
export type ConnectorTypeList = ConnectorType[];
export type ScheduleFrequencyType = "BYMINUTE" | "HOURLY" | "DAILY" | "WEEKLY" | "MONTHLY" | "ONCE" | (string & {});
export type SchedulingFrequencyTypeList = ScheduleFrequencyType[];
export type TriggerTypeList = TriggerType[];
export interface AmplitudeMetadata {
}
export interface DatadogMetadata {
}
export interface DynatraceMetadata {
}
export interface GoogleAnalyticsMetadata {
    oAuthScopes?: string[];
}
export interface InforNexusMetadata {
}
export interface MarketoMetadata {
}
export interface RedshiftMetadata {
}
export interface S3Metadata {
}
export type SalesforceDataTransferApiList = SalesforceDataTransferApi[];
export type OAuth2GrantTypeSupportedList = OAuth2GrantType[];
export interface SalesforceMetadata {
    oAuthScopes?: string[];
    dataTransferApis?: SalesforceDataTransferApi[];
    oauth2GrantTypesSupported?: OAuth2GrantType[];
}
export interface ServiceNowMetadata {
}
export interface SingularMetadata {
}
export interface SlackMetadata {
    oAuthScopes?: string[];
}
export type RegionList = string[];
export interface SnowflakeMetadata {
    supportedRegions?: string[];
}
export interface TrendmicroMetadata {
}
export interface VeevaMetadata {
}
export interface ZendeskMetadata {
    oAuthScopes?: string[];
}
export interface EventBridgeMetadata {
}
export interface UpsolverMetadata {
}
export interface CustomerProfilesMetadata {
}
export interface HoneycodeMetadata {
    oAuthScopes?: string[];
}
export interface SAPODataMetadata {
}
export interface PardotMetadata {
}
export interface ConnectorMetadata {
    Amplitude?: AmplitudeMetadata;
    Datadog?: DatadogMetadata;
    Dynatrace?: DynatraceMetadata;
    GoogleAnalytics?: GoogleAnalyticsMetadata;
    InforNexus?: InforNexusMetadata;
    Marketo?: MarketoMetadata;
    Redshift?: RedshiftMetadata;
    S3?: S3Metadata;
    Salesforce?: SalesforceMetadata;
    ServiceNow?: ServiceNowMetadata;
    Singular?: SingularMetadata;
    Slack?: SlackMetadata;
    Snowflake?: SnowflakeMetadata;
    Trendmicro?: TrendmicroMetadata;
    Veeva?: VeevaMetadata;
    Zendesk?: ZendeskMetadata;
    EventBridge?: EventBridgeMetadata;
    Upsolver?: UpsolverMetadata;
    CustomerProfiles?: CustomerProfilesMetadata;
    Honeycode?: HoneycodeMetadata;
    SAPOData?: SAPODataMetadata;
    Pardot?: PardotMetadata;
}
export type ConnectorDescription = string;
export type ConnectorOwner = string;
export type ConnectorName = string;
export type ConnectorVersion = string;
export type ARN = string;
export type ConnectorMode = string;
export type ConnectorModeList = string[];
export type TokenUrlList = string[];
export type AuthCodeUrlList = string[];
export type Label = string;
export type Description = string;
export type ConnectorSuppliedValue = string;
export type ConnectorSuppliedValueList = string[];
export type OAuth2CustomPropType = "TOKEN_URL" | "AUTH_URL" | (string & {});
export interface OAuth2CustomParameter {
    key?: string;
    isRequired?: boolean;
    label?: string;
    description?: string;
    isSensitiveField?: boolean;
    connectorSuppliedValues?: string[];
    type?: OAuth2CustomPropType;
}
export type OAuth2CustomPropertiesList = OAuth2CustomParameter[];
export interface OAuth2Defaults {
    oauthScopes?: string[];
    tokenUrls?: string[];
    authCodeUrls?: string[];
    oauth2GrantTypesSupported?: OAuth2GrantType[];
    oauth2CustomProperties?: OAuth2CustomParameter[];
}
export interface AuthParameter {
    key?: string;
    isRequired?: boolean;
    label?: string;
    description?: string;
    isSensitiveField?: boolean;
    connectorSuppliedValues?: string[];
}
export type AuthParameterList = AuthParameter[];
export interface CustomAuthConfig {
    customAuthenticationType?: string;
    authParameters?: AuthParameter[];
}
export type CustomAuthConfigList = CustomAuthConfig[];
export interface AuthenticationConfig {
    isBasicAuthSupported?: boolean;
    isApiKeyAuthSupported?: boolean;
    isOAuth2Supported?: boolean;
    isCustomAuthSupported?: boolean;
    oAuth2Defaults?: OAuth2Defaults;
    customAuthConfigs?: CustomAuthConfig[];
}
export type ConnectorRuntimeSettingDataType = string;
export type ConnectorRuntimeSettingScope = string;
export type ConnectorSuppliedValueOptionList = string[];
export interface ConnectorRuntimeSetting {
    key?: string;
    dataType?: string;
    isRequired?: boolean;
    label?: string;
    description?: string;
    scope?: string;
    connectorSuppliedValueOptions?: string[];
}
export type ConnectorRuntimeSettingList = ConnectorRuntimeSetting[];
export type SupportedApiVersion = string;
export type SupportedApiVersionList = string[];
export type Operators = "PROJECTION" | "LESS_THAN" | "GREATER_THAN" | "CONTAINS" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type SupportedOperatorList = Operators[];
export type SupportedWriteOperationList = WriteOperationType[];
export type ConnectorProvisioningType = "LAMBDA" | (string & {});
export interface LambdaConnectorProvisioningConfig {
    lambdaArn: string;
}
export interface ConnectorProvisioningConfig {
    lambda?: LambdaConnectorProvisioningConfig;
}
export type LogoURL = string;
export type RegisteredBy = string;
export type SupportedDataTransferType = "RECORD" | "FILE" | (string & {});
export type SupportedDataTransferTypeList = SupportedDataTransferType[];
export type SupportedDataTransferApis = DataTransferApi[];
export interface ConnectorConfiguration {
    canUseAsSource?: boolean;
    canUseAsDestination?: boolean;
    supportedDestinationConnectors?: ConnectorType[];
    supportedSchedulingFrequencies?: ScheduleFrequencyType[];
    isPrivateLinkEnabled?: boolean;
    isPrivateLinkEndpointUrlRequired?: boolean;
    supportedTriggerTypes?: TriggerType[];
    connectorMetadata?: ConnectorMetadata;
    connectorType?: ConnectorType;
    connectorLabel?: string;
    connectorDescription?: string;
    connectorOwner?: string;
    connectorName?: string;
    connectorVersion?: string;
    connectorArn?: string;
    connectorModes?: string[];
    authenticationConfig?: AuthenticationConfig;
    connectorRuntimeSettings?: ConnectorRuntimeSetting[];
    supportedApiVersions?: string[];
    supportedOperators?: Operators[];
    supportedWriteOperations?: WriteOperationType[];
    connectorProvisioningType?: ConnectorProvisioningType;
    connectorProvisioningConfig?: ConnectorProvisioningConfig;
    logoURL?: string;
    registeredAt?: Date;
    registeredBy?: string;
    supportedDataTransferTypes?: SupportedDataTransferType[];
    supportedDataTransferApis?: DataTransferApi[];
}
export interface DescribeConnectorResponse {
    connectorConfiguration?: ConnectorConfiguration;
}
export interface DescribeConnectorEntityRequest {
    connectorEntityName: string;
    connectorType?: ConnectorType;
    connectorProfileName?: string;
    apiVersion?: string;
}
export type Identifier = string;
export type FieldType = string;
export type FilterOperatorList = Operator[];
export type Value = string;
export type SupportedValueList = string[];
export interface Range {
    maximum?: number;
    minimum?: number;
}
export interface FieldTypeDetails {
    fieldType: string;
    filterOperators: Operator[];
    supportedValues?: string[];
    valueRegexPattern?: string;
    supportedDateFormat?: string;
    fieldValueRange?: Range;
    fieldLengthRange?: Range;
}
export interface SupportedFieldTypeDetails {
    v1: FieldTypeDetails;
}
export interface SourceFieldProperties {
    isRetrievable?: boolean;
    isQueryable?: boolean;
    isTimestampFieldForIncrementalQueries?: boolean;
}
export interface DestinationFieldProperties {
    isCreatable?: boolean;
    isNullable?: boolean;
    isUpsertable?: boolean;
    isUpdatable?: boolean;
    isDefaultedOnCreate?: boolean;
    supportedWriteOperations?: WriteOperationType[];
}
export interface ConnectorEntityField {
    identifier: string;
    parentIdentifier?: string;
    label?: string;
    isPrimaryKey?: boolean;
    defaultValue?: string;
    isDeprecated?: boolean;
    supportedFieldTypeDetails?: SupportedFieldTypeDetails;
    description?: string;
    sourceProperties?: SourceFieldProperties;
    destinationProperties?: DestinationFieldProperties;
    customProperties?: {
        [key: string]: string | undefined;
    };
}
export type ConnectorEntityFieldList = ConnectorEntityField[];
export interface DescribeConnectorEntityResponse {
    connectorEntityFields: ConnectorEntityField[];
}
export type ConnectorProfileNameList = string[];
export type MaxResults = number;
export type NextToken = string;
export interface DescribeConnectorProfilesRequest {
    connectorProfileNames?: string[];
    connectorType?: ConnectorType;
    connectorLabel?: string;
    maxResults?: number;
    nextToken?: string;
}
export type PrivateConnectionProvisioningStatus = "FAILED" | "PENDING" | "CREATED" | (string & {});
export type PrivateConnectionProvisioningFailureMessage = string;
export type PrivateConnectionProvisioningFailureCause = "CONNECTOR_AUTHENTICATION" | "CONNECTOR_SERVER" | "INTERNAL_SERVER" | "ACCESS_DENIED" | "VALIDATION" | (string & {});
export interface PrivateConnectionProvisioningState {
    status?: PrivateConnectionProvisioningStatus;
    failureMessage?: string;
    failureCause?: PrivateConnectionProvisioningFailureCause;
}
export interface ConnectorProfile {
    connectorProfileArn?: string;
    connectorProfileName?: string;
    connectorType?: ConnectorType;
    connectorLabel?: string;
    connectionMode?: ConnectionMode;
    credentialsArn?: string;
    connectorProfileProperties?: ConnectorProfileProperties;
    createdAt?: Date;
    lastUpdatedAt?: Date;
    privateConnectionProvisioningState?: PrivateConnectionProvisioningState;
}
export type ConnectorProfileDetailList = ConnectorProfile[];
export interface DescribeConnectorProfilesResponse {
    connectorProfileDetails?: ConnectorProfile[];
    nextToken?: string;
}
export interface DescribeConnectorsRequest {
    connectorTypes?: ConnectorType[];
    maxResults?: number;
    nextToken?: string;
}
export type ConnectorConfigurationsMap = {
    [key in ConnectorType]?: ConnectorConfiguration;
};
export type ApplicationType = string;
export interface ConnectorDetail {
    connectorDescription?: string;
    connectorName?: string;
    connectorOwner?: string;
    connectorVersion?: string;
    applicationType?: string;
    connectorType?: ConnectorType;
    connectorLabel?: string;
    registeredAt?: Date;
    registeredBy?: string;
    connectorProvisioningType?: ConnectorProvisioningType;
    connectorModes?: string[];
    supportedDataTransferTypes?: SupportedDataTransferType[];
}
export type ConnectorList = ConnectorDetail[];
export interface DescribeConnectorsResponse {
    connectorConfigurations?: {
        [key: string]: ConnectorConfiguration | undefined;
    };
    connectors?: ConnectorDetail[];
    nextToken?: string;
}
export interface DescribeFlowRequest {
    flowName: string;
}
export type FlowStatusMessage = string;
export type MostRecentExecutionMessage = string;
export type ExecutionStatus = "InProgress" | "Successful" | "Error" | "CancelStarted" | "Canceled" | (string & {});
export interface ExecutionDetails {
    mostRecentExecutionMessage?: string;
    mostRecentExecutionTime?: Date;
    mostRecentExecutionStatus?: ExecutionStatus;
}
export type CreatedBy = string;
export type UpdatedBy = string;
export type CatalogType = "GLUE" | (string & {});
export interface RegistrationOutput {
    message?: string;
    result?: string;
    status?: ExecutionStatus;
}
export interface MetadataCatalogDetail {
    catalogType?: CatalogType;
    tableName?: string;
    tableRegistrationOutput?: RegistrationOutput;
    partitionRegistrationOutput?: RegistrationOutput;
}
export type MetadataCatalogDetails = MetadataCatalogDetail[];
export interface DescribeFlowResponse {
    flowArn?: string;
    description?: string;
    flowName?: string;
    kmsArn?: string;
    flowStatus?: FlowStatus;
    flowStatusMessage?: string;
    sourceFlowConfig?: SourceFlowConfig;
    destinationFlowConfigList?: DestinationFlowConfig[];
    lastRunExecutionDetails?: ExecutionDetails;
    triggerConfig?: TriggerConfig;
    tasks?: Task[];
    createdAt?: Date;
    lastUpdatedAt?: Date;
    createdBy?: string;
    lastUpdatedBy?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    metadataCatalogConfig?: MetadataCatalogConfig;
    lastRunMetadataCatalogDetails?: MetadataCatalogDetail[];
    schemaVersion?: number;
}
export interface DescribeFlowExecutionRecordsRequest {
    flowName: string;
    maxResults?: number;
    nextToken?: string;
}
export type ExecutionMessage = string;
export interface ErrorInfo {
    putFailuresCount?: number;
    executionMessage?: string;
}
export interface ExecutionResult {
    errorInfo?: ErrorInfo;
    bytesProcessed?: number;
    bytesWritten?: number;
    recordsProcessed?: number;
    numParallelProcesses?: number;
    maxPageSize?: number;
}
export interface ExecutionRecord {
    executionId?: string;
    executionStatus?: ExecutionStatus;
    executionResult?: ExecutionResult;
    startedAt?: Date;
    lastUpdatedAt?: Date;
    dataPullStartTime?: Date;
    dataPullEndTime?: Date;
    metadataCatalogDetails?: MetadataCatalogDetail[];
}
export type FlowExecutionList = ExecutionRecord[];
export interface DescribeFlowExecutionRecordsResponse {
    flowExecutions?: ExecutionRecord[];
    nextToken?: string;
}
export type EntitiesPath = string;
export type ListEntitiesMaxResults = number;
export interface ListConnectorEntitiesRequest {
    connectorProfileName?: string;
    connectorType?: ConnectorType;
    entitiesPath?: string;
    apiVersion?: string;
    maxResults?: number;
    nextToken?: string;
}
export type Group = string;
export interface ConnectorEntity {
    name: string;
    label?: string;
    hasNestedEntities?: boolean;
}
export type ConnectorEntityList = ConnectorEntity[];
export type ConnectorEntityMap = {
    [key: string]: ConnectorEntity[] | undefined;
};
export interface ListConnectorEntitiesResponse {
    connectorEntityMap: {
        [key: string]: ConnectorEntity[] | undefined;
    };
    nextToken?: string;
}
export interface ListConnectorsRequest {
    maxResults?: number;
    nextToken?: string;
}
export interface ListConnectorsResponse {
    connectors?: ConnectorDetail[];
    nextToken?: string;
}
export interface ListFlowsRequest {
    maxResults?: number;
    nextToken?: string;
}
export interface FlowDefinition {
    flowArn?: string;
    description?: string;
    flowName?: string;
    flowStatus?: FlowStatus;
    sourceConnectorType?: ConnectorType;
    sourceConnectorLabel?: string;
    destinationConnectorType?: ConnectorType;
    destinationConnectorLabel?: string;
    triggerType?: TriggerType;
    createdAt?: Date;
    lastUpdatedAt?: Date;
    createdBy?: string;
    lastUpdatedBy?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    lastRunExecutionDetails?: ExecutionDetails;
}
export type FlowList = FlowDefinition[];
export interface ListFlowsResponse {
    flows?: FlowDefinition[];
    nextToken?: string;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface RegisterConnectorRequest {
    connectorLabel?: string;
    description?: string;
    connectorProvisioningType?: ConnectorProvisioningType;
    connectorProvisioningConfig?: ConnectorProvisioningConfig;
    clientToken?: string;
}
export interface RegisterConnectorResponse {
    connectorArn?: string;
}
export interface ResetConnectorMetadataCacheRequest {
    connectorProfileName?: string;
    connectorType?: ConnectorType;
    connectorEntityName?: string;
    entitiesPath?: string;
    apiVersion?: string;
}
export interface ResetConnectorMetadataCacheResponse {
}
export interface StartFlowRequest {
    flowName: string;
    clientToken?: string;
}
export interface StartFlowResponse {
    flowArn?: string;
    flowStatus?: FlowStatus;
    executionId?: string;
}
export interface StopFlowRequest {
    flowName: string;
}
export interface StopFlowResponse {
    flowArn?: string;
    flowStatus?: FlowStatus;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export interface UnregisterConnectorRequest {
    connectorLabel: string;
    forceDelete?: boolean;
}
export interface UnregisterConnectorResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateConnectorProfileRequest {
    connectorProfileName: string;
    connectionMode: ConnectionMode;
    connectorProfileConfig: ConnectorProfileConfig;
    clientToken?: string;
}
export interface UpdateConnectorProfileResponse {
    connectorProfileArn?: string;
}
export interface UpdateConnectorRegistrationRequest {
    connectorLabel: string;
    description?: string;
    connectorProvisioningConfig?: ConnectorProvisioningConfig;
    clientToken?: string;
}
export interface UpdateConnectorRegistrationResponse {
    connectorArn?: string;
}
export interface UpdateFlowRequest {
    flowName: string;
    description?: string;
    triggerConfig: TriggerConfig;
    sourceFlowConfig: SourceFlowConfig;
    destinationFlowConfigList: DestinationFlowConfig[];
    tasks: Task[];
    metadataCatalogConfig?: MetadataCatalogConfig;
    clientToken?: string;
}
export interface UpdateFlowResponse {
    flowStatus?: FlowStatus;
}
export type ErrorMessage = string;
export type CancelFlowExecutionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels active runs for a flow.
 *
 * You can cancel all of the active runs for a flow, or you can cancel specific runs by
 * providing their IDs.
 *
 * You can cancel a flow run only when the run is in progress. You can't cancel a run that
 * has already completed or failed. You also can't cancel a run that's scheduled to occur but
 * hasn't started yet. To prevent a scheduled run, you can deactivate the flow with the
 * `StopFlow` action.
 *
 * You cannot resume a run after you cancel it.
 *
 * When you send your request, the status for each run becomes `CancelStarted`.
 * When the cancellation completes, the status becomes `Canceled`.
 *
 * When you cancel a run, you still incur charges for any data that the run already
 * processed before the cancellation. If the run had already written some data to the flow
 * destination, then that data remains in the destination. If you configured the flow to use a
 * batch API (such as the Salesforce Bulk API 2.0), then the run will finish reading or writing
 * its entire batch of data after the cancellation. For these operations, the data processing
 * charges for Amazon AppFlow apply. For the pricing information, see Amazon AppFlow pricing.
 */
export declare const cancelFlowExecutions: API.OperationMethod<CancelFlowExecutionsRequest, CancelFlowExecutionsResponse, CancelFlowExecutionsError, Credentials | HttpClient.HttpClient>;
export type CreateConnectorProfileError = ConflictException | ConnectorAuthenticationException | InternalServerException | ServiceQuotaExceededException | ValidationException | ConnectorServerException | CommonErrors;
/**
 * Creates a new connector profile associated with your Amazon Web Services account. There is
 * a soft quota of 100 connector profiles per Amazon Web Services account. If you need more
 * connector profiles than this quota allows, you can submit a request to the Amazon AppFlow
 * team through the Amazon AppFlow support channel. In each connector profile that you
 * create, you can provide the credentials and properties for only one connector.
 */
export declare const createConnectorProfile: API.OperationMethod<CreateConnectorProfileRequest, CreateConnectorProfileResponse, CreateConnectorProfileError, Credentials | HttpClient.HttpClient>;
export type CreateFlowError = AccessDeniedException | ConflictException | ConnectorAuthenticationException | ConnectorServerException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Enables your application to create a new flow using Amazon AppFlow. You must create
 * a connector profile before calling this API. Please note that the Request Syntax below shows
 * syntax for multiple destinations, however, you can only transfer data to one item in this list
 * at a time. Amazon AppFlow does not currently support flows to multiple destinations at
 * once.
 */
export declare const createFlow: API.OperationMethod<CreateFlowRequest, CreateFlowResponse, CreateFlowError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorProfileError = ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Enables you to delete an existing connector profile.
 */
export declare const deleteConnectorProfile: API.OperationMethod<DeleteConnectorProfileRequest, DeleteConnectorProfileResponse, DeleteConnectorProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteFlowError = ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Enables your application to delete an existing flow. Before deleting the flow, Amazon AppFlow validates the request by checking the flow configuration and status. You can
 * delete flows one at a time.
 */
export declare const deleteFlow: API.OperationMethod<DeleteFlowRequest, DeleteFlowResponse, DeleteFlowError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectorError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the given custom connector registered in your Amazon Web Services account. This
 * API can be used for custom connectors that are registered in your account and also for Amazon
 * authored connectors.
 */
export declare const describeConnector: API.OperationMethod<DescribeConnectorRequest, DescribeConnectorResponse, DescribeConnectorError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectorEntityError = ConnectorAuthenticationException | ConnectorServerException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Provides details regarding the entity used with the connector, with a description of the
 * data model for each field in that entity.
 */
export declare const describeConnectorEntity: API.OperationMethod<DescribeConnectorEntityRequest, DescribeConnectorEntityResponse, DescribeConnectorEntityError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectorProfilesError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of `connector-profile` details matching the provided
 * `connector-profile` names and `connector-types`. Both input lists are
 * optional, and you can use them to filter the result.
 *
 * If no names or `connector-types` are provided, returns all connector profiles
 * in a paginated form. If there is no match, this operation returns an empty list.
 */
export declare const describeConnectorProfiles: API.PaginatedOperationMethod<DescribeConnectorProfilesRequest, DescribeConnectorProfilesResponse, DescribeConnectorProfilesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeConnectorsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Describes the connectors vended by Amazon AppFlow for specified connector types. If
 * you don't specify a connector type, this operation describes all connectors vended by Amazon AppFlow. If there are more connectors than can be returned in one page, the response
 * contains a `nextToken` object, which can be be passed in to the next call to the
 * `DescribeConnectors` API operation to retrieve the next page.
 */
export declare const describeConnectors: API.PaginatedOperationMethod<DescribeConnectorsRequest, DescribeConnectorsResponse, DescribeConnectorsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeFlowError = InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Provides a description of the specified flow.
 */
export declare const describeFlow: API.OperationMethod<DescribeFlowRequest, DescribeFlowResponse, DescribeFlowError, Credentials | HttpClient.HttpClient>;
export type DescribeFlowExecutionRecordsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Fetches the execution history of the flow.
 */
export declare const describeFlowExecutionRecords: API.PaginatedOperationMethod<DescribeFlowExecutionRecordsRequest, DescribeFlowExecutionRecordsResponse, DescribeFlowExecutionRecordsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListConnectorEntitiesError = ConnectorAuthenticationException | ConnectorServerException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the list of available connector entities supported by Amazon AppFlow. For
 * example, you can query Salesforce for *Account* and
 * *Opportunity* entities, or query ServiceNow for the
 * *Incident* entity.
 */
export declare const listConnectorEntities: API.OperationMethod<ListConnectorEntitiesRequest, ListConnectorEntitiesResponse, ListConnectorEntitiesError, Credentials | HttpClient.HttpClient>;
export type ListConnectorsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns the list of all registered custom connectors in your Amazon Web Services account.
 * This API lists only custom connectors registered in this account, not the Amazon Web Services
 * authored connectors.
 */
export declare const listConnectors: API.PaginatedOperationMethod<ListConnectorsRequest, ListConnectorsResponse, ListConnectorsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFlowsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists all of the flows associated with your account.
 */
export declare const listFlows: API.PaginatedOperationMethod<ListFlowsRequest, ListFlowsResponse, ListFlowsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the tags that are associated with a specified flow.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RegisterConnectorError = AccessDeniedException | ConflictException | ConnectorAuthenticationException | ConnectorServerException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Registers a new custom connector with your Amazon Web Services account. Before you can
 * register the connector, you must deploy the associated AWS lambda function in your
 * account.
 */
export declare const registerConnector: API.OperationMethod<RegisterConnectorRequest, RegisterConnectorResponse, RegisterConnectorError, Credentials | HttpClient.HttpClient>;
export type ResetConnectorMetadataCacheError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Resets metadata about your connector entities that Amazon AppFlow stored in its
 * cache. Use this action when you want Amazon AppFlow to return the latest information
 * about the data that you have in a source application.
 *
 * Amazon AppFlow returns metadata about your entities when you use the
 * ListConnectorEntities or DescribeConnectorEntities actions. Following these actions, Amazon AppFlow caches the metadata to reduce the number of API requests that it must send to
 * the source application. Amazon AppFlow automatically resets the cache once every hour,
 * but you can use this action when you want to get the latest metadata right away.
 */
export declare const resetConnectorMetadataCache: API.OperationMethod<ResetConnectorMetadataCacheRequest, ResetConnectorMetadataCacheResponse, ResetConnectorMetadataCacheError, Credentials | HttpClient.HttpClient>;
export type StartFlowError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Activates an existing flow. For on-demand flows, this operation runs the flow
 * immediately. For schedule and event-triggered flows, this operation activates the flow.
 */
export declare const startFlow: API.OperationMethod<StartFlowRequest, StartFlowResponse, StartFlowError, Credentials | HttpClient.HttpClient>;
export type StopFlowError = ConflictException | InternalServerException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Deactivates the existing flow. For on-demand flows, this operation returns an
 * `unsupportedOperationException` error message. For schedule and event-triggered
 * flows, this operation deactivates the flow.
 */
export declare const stopFlow: API.OperationMethod<StopFlowRequest, StopFlowResponse, StopFlowError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Applies a tag to the specified flow.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UnregisterConnectorError = ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Unregisters the custom connector registered in your account that matches the connector
 * label provided in the request.
 */
export declare const unregisterConnector: API.OperationMethod<UnregisterConnectorRequest, UnregisterConnectorResponse, UnregisterConnectorError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a tag from the specified flow.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorProfileError = ConflictException | ConnectorAuthenticationException | InternalServerException | ResourceNotFoundException | ValidationException | ConnectorServerException | CommonErrors;
/**
 * Updates a given connector profile associated with your account.
 */
export declare const updateConnectorProfile: API.OperationMethod<UpdateConnectorProfileRequest, UpdateConnectorProfileResponse, UpdateConnectorProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorRegistrationError = AccessDeniedException | ConflictException | ConnectorAuthenticationException | ConnectorServerException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a custom connector that you've previously registered. This operation updates the
 * connector with one of the following:
 *
 * - The latest version of the AWS Lambda function that's assigned to the connector
 *
 * - A new AWS Lambda function that you specify
 */
export declare const updateConnectorRegistration: API.OperationMethod<UpdateConnectorRegistrationRequest, UpdateConnectorRegistrationResponse, UpdateConnectorRegistrationError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowError = AccessDeniedException | ConflictException | ConnectorAuthenticationException | ConnectorServerException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Updates an existing flow.
 */
export declare const updateFlow: API.OperationMethod<UpdateFlowRequest, UpdateFlowResponse, UpdateFlowError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=appflow.d.ts.map