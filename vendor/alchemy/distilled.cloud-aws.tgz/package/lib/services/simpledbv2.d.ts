import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidParameterCombinationException_base: S.TaggedErrorClass<"InvalidParameterCombinationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterCombinationException extends /*@__PURE__*/ InvalidParameterCombinationException_base {
}
declare const InvalidParameterValueException_base: S.TaggedErrorClass<"InvalidParameterValueException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const NoSuchDomainException_base: S.TaggedErrorClass<"NoSuchDomainException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchDomainException extends /*@__PURE__*/ NoSuchDomainException_base {
}
declare const NoSuchExportException_base: S.TaggedErrorClass<"NoSuchExportException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchExportException extends /*@__PURE__*/ NoSuchExportException_base {
}
declare const NumberExportsLimitExceeded_base: S.TaggedErrorClass<"NumberExportsLimitExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class NumberExportsLimitExceeded extends /*@__PURE__*/ NumberExportsLimitExceeded_base {
}
export type ExportArn = string;
export interface GetExportRequest {
    exportArn: string;
}
export type IdempotencyToken = string;
export type ExportStatus = "PENDING" | "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | (string & {});
export type DomainName = string;
export type RequestedAt = Date;
export type S3BucketName = string;
export type S3KeyPrefix = string;
export type S3SseAlgorithm = "AES256" | "KMS" | (string & {});
export type S3SseKmsKeyId = string;
export type AwsAccountId = string;
export type FailureCode = string;
export type FailureMessage = string;
export type ExportManifestSummary = string;
export type ItemsCount = number;
export type ExportDataCutoffTime = Date;
export interface GetExportResponse {
    exportArn: string;
    clientToken: string;
    exportStatus: ExportStatus;
    domainName: string;
    requestedAt: Date;
    s3Bucket: string;
    s3KeyPrefix?: string;
    s3SseAlgorithm?: S3SseAlgorithm;
    s3SseKmsKeyId?: string;
    s3BucketOwner?: string;
    failureCode?: string;
    failureMessage?: string;
    exportManifest?: string;
    itemsCount?: number;
    exportDataCutoffTime?: Date;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListExportsRequest {
    domainName?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface ExportSummary {
    exportArn: string;
    exportStatus: ExportStatus;
    requestedAt: Date;
    domainName: string;
}
export type ExportSummaries = ExportSummary[];
export interface ListExportsResponse {
    exportSummaries: ExportSummary[];
    nextToken?: string;
}
export interface StartDomainExportRequest {
    clientToken?: string;
    domainName: string;
    s3Bucket: string;
    s3KeyPrefix?: string;
    s3SseAlgorithm?: S3SseAlgorithm;
    s3SseKmsKeyId?: string;
    s3BucketOwner?: string;
}
export interface StartDomainExportResponse {
    clientToken: string;
    exportArn: string;
    requestedAt: Date;
}
export type GetExportError = InvalidParameterValueException | NoSuchExportException | CommonErrors;
/**
 * Returns information for an existing domain export.
 */
export declare const getExport: API.OperationMethod<GetExportRequest, GetExportResponse, GetExportError, Credentials | HttpClient.HttpClient>;
export type ListExportsError = InvalidNextTokenException | InvalidParameterValueException | NoSuchDomainException | CommonErrors;
/**
 * Lists all exports that were created. The results are paginated and can be filtered by domain name.
 */
export declare const listExports: API.PaginatedOperationMethod<ListExportsRequest, ListExportsResponse, ListExportsError, Credentials | HttpClient.HttpClient, ExportSummary>;
export type StartDomainExportError = ConflictException | InvalidParameterCombinationException | InvalidParameterValueException | NoSuchDomainException | NumberExportsLimitExceeded | CommonErrors;
/**
 * Initiates the export of a SimpleDB domain to an S3 bucket.
 */
export declare const startDomainExport: API.OperationMethod<StartDomainExportRequest, StartDomainExportResponse, StartDomainExportError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=simpledbv2.d.ts.map