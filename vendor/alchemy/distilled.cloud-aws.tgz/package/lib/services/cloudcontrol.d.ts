import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AlreadyExistsException_base: S.TaggedErrorClass<"AlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AlreadyExistsException extends /*@__PURE__*/ AlreadyExistsException_base {
}
declare const ClientTokenConflictException_base: S.TaggedErrorClass<"ClientTokenConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ClientTokenConflictException extends /*@__PURE__*/ ClientTokenConflictException_base {
}
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConcurrentOperationException_base: S.TaggedErrorClass<"ConcurrentOperationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConcurrentOperationException extends /*@__PURE__*/ ConcurrentOperationException_base {
}
declare const GeneralServiceException_base: S.TaggedErrorClass<"GeneralServiceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GeneralServiceException extends /*@__PURE__*/ GeneralServiceException_base {
}
declare const HandlerFailureException_base: S.TaggedErrorClass<"HandlerFailureException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class HandlerFailureException extends /*@__PURE__*/ HandlerFailureException_base {
}
declare const HandlerInternalFailureException_base: S.TaggedErrorClass<"HandlerInternalFailureException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class HandlerInternalFailureException extends /*@__PURE__*/ HandlerInternalFailureException_base {
}
declare const InvalidCredentialsException_base: S.TaggedErrorClass<"InvalidCredentialsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class InvalidCredentialsException extends /*@__PURE__*/ InvalidCredentialsException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const NetworkFailureException_base: S.TaggedErrorClass<"NetworkFailureException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class NetworkFailureException extends /*@__PURE__*/ NetworkFailureException_base {
}
declare const NotStabilizedException_base: S.TaggedErrorClass<"NotStabilizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotStabilizedException extends /*@__PURE__*/ NotStabilizedException_base {
}
declare const NotUpdatableException_base: S.TaggedErrorClass<"NotUpdatableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotUpdatableException extends /*@__PURE__*/ NotUpdatableException_base {
}
declare const PrivateTypeException_base: S.TaggedErrorClass<"PrivateTypeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PrivateTypeException extends /*@__PURE__*/ PrivateTypeException_base {
}
declare const RequestTokenNotFoundException_base: S.TaggedErrorClass<"RequestTokenNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RequestTokenNotFoundException extends /*@__PURE__*/ RequestTokenNotFoundException_base {
}
declare const ResourceConflictException_base: S.TaggedErrorClass<"ResourceConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceConflictException extends /*@__PURE__*/ ResourceConflictException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceInternalErrorException_base: S.TaggedErrorClass<"ServiceInternalErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceInternalErrorException extends /*@__PURE__*/ ServiceInternalErrorException_base {
}
declare const ServiceLimitExceededException_base: S.TaggedErrorClass<"ServiceLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceLimitExceededException extends /*@__PURE__*/ ServiceLimitExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TypeNotFoundException_base: S.TaggedErrorClass<"TypeNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TypeNotFoundException extends /*@__PURE__*/ TypeNotFoundException_base {
}
declare const UnsupportedActionException_base: S.TaggedErrorClass<"UnsupportedActionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedActionException extends /*@__PURE__*/ UnsupportedActionException_base {
}
export type RequestToken = string;
export interface CancelResourceRequestInput {
    RequestToken: string;
}
export type TypeName = string;
export type Identifier = string;
export type Operation = string;
export type OperationStatus = string;
export type Properties = string | redacted.Redacted<string>;
export type StatusMessage = string;
export type HandlerErrorCode = string;
export interface ProgressEvent {
    TypeName?: string;
    Identifier?: string;
    RequestToken?: string;
    HooksRequestToken?: string;
    Operation?: string;
    OperationStatus?: string;
    EventTime?: Date;
    ResourceModel?: string | redacted.Redacted<string>;
    StatusMessage?: string;
    ErrorCode?: string;
    RetryAfter?: Date;
}
export interface CancelResourceRequestOutput {
    ProgressEvent?: ProgressEvent;
}
export type TypeVersionId = string;
export type RoleArn = string;
export type ClientToken = string;
export interface CreateResourceInput {
    TypeName: string;
    TypeVersionId?: string;
    RoleArn?: string;
    ClientToken?: string;
    DesiredState: string | redacted.Redacted<string>;
}
export interface CreateResourceOutput {
    ProgressEvent?: ProgressEvent;
}
export interface DeleteResourceInput {
    TypeName: string;
    TypeVersionId?: string;
    RoleArn?: string;
    ClientToken?: string;
    Identifier: string;
}
export interface DeleteResourceOutput {
    ProgressEvent?: ProgressEvent;
}
export interface GetResourceInput {
    TypeName: string;
    TypeVersionId?: string;
    RoleArn?: string;
    Identifier: string;
}
export interface ResourceDescription {
    Identifier?: string;
    Properties?: string | redacted.Redacted<string>;
}
export interface GetResourceOutput {
    TypeName?: string;
    ResourceDescription?: ResourceDescription;
}
export interface GetResourceRequestStatusInput {
    RequestToken: string;
}
export type HookTypeArn = string;
export type HookInvocationPoint = string;
export type HookStatus = string;
export type HookFailureMode = string;
export interface HookProgressEvent {
    HookTypeName?: string;
    HookTypeVersionId?: string;
    HookTypeArn?: string;
    InvocationPoint?: string;
    HookStatus?: string;
    HookEventTime?: Date;
    HookStatusMessage?: string;
    FailureMode?: string;
}
export type HooksProgressEvent = HookProgressEvent[];
export interface GetResourceRequestStatusOutput {
    ProgressEvent?: ProgressEvent;
    HooksProgressEvent?: HookProgressEvent[];
}
export type MaxResults = number;
export type NextToken = string;
export type Operations = string[];
export type OperationStatuses = string[];
export interface ResourceRequestStatusFilter {
    Operations?: string[];
    OperationStatuses?: string[];
}
export interface ListResourceRequestsInput {
    MaxResults?: number;
    NextToken?: string;
    ResourceRequestStatusFilter?: ResourceRequestStatusFilter;
}
export type ResourceRequestStatusSummaries = ProgressEvent[];
export interface ListResourceRequestsOutput {
    ResourceRequestStatusSummaries?: ProgressEvent[];
    NextToken?: string;
}
export type HandlerNextToken = string;
export interface ListResourcesInput {
    TypeName: string;
    TypeVersionId?: string;
    RoleArn?: string;
    NextToken?: string;
    MaxResults?: number;
    ResourceModel?: string | redacted.Redacted<string>;
}
export type ResourceDescriptions = ResourceDescription[];
export interface ListResourcesOutput {
    TypeName?: string;
    ResourceDescriptions?: ResourceDescription[];
    NextToken?: string;
}
export type PatchDocument = string | redacted.Redacted<string>;
export interface UpdateResourceInput {
    TypeName: string;
    TypeVersionId?: string;
    RoleArn?: string;
    ClientToken?: string;
    Identifier: string;
    PatchDocument: string | redacted.Redacted<string>;
}
export interface UpdateResourceOutput {
    ProgressEvent?: ProgressEvent;
}
export type ErrorMessage = string;
export type CancelResourceRequestError = ConcurrentModificationException | RequestTokenNotFoundException | CommonErrors;
/**
 * Cancels the specified resource operation request. For more information, see Canceling resource operation requests in the
 * *Amazon Web Services Cloud Control API User Guide*.
 *
 * Only resource operations requests with a status of `PENDING` or
 * `IN_PROGRESS` can be canceled.
 */
export declare const cancelResourceRequest: API.OperationMethod<CancelResourceRequestInput, CancelResourceRequestOutput, CancelResourceRequestError, Credentials | HttpClient.HttpClient>;
export type CreateResourceError = AlreadyExistsException | ClientTokenConflictException | ConcurrentOperationException | GeneralServiceException | HandlerFailureException | HandlerInternalFailureException | InvalidCredentialsException | InvalidRequestException | NetworkFailureException | NotStabilizedException | NotUpdatableException | PrivateTypeException | ResourceConflictException | ResourceNotFoundException | ServiceInternalErrorException | ServiceLimitExceededException | ThrottlingException | TypeNotFoundException | UnsupportedActionException | CommonErrors;
/**
 * Creates the specified resource. For more information, see Creating a
 * resource in the *Amazon Web Services Cloud Control API User Guide*.
 *
 * After you have initiated a resource creation request, you can monitor the progress of your
 * request by calling GetResourceRequestStatus using the `RequestToken` of the
 * `ProgressEvent` type returned by `CreateResource`.
 */
export declare const createResource: API.OperationMethod<CreateResourceInput, CreateResourceOutput, CreateResourceError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceError = AlreadyExistsException | ClientTokenConflictException | ConcurrentOperationException | GeneralServiceException | HandlerFailureException | HandlerInternalFailureException | InvalidCredentialsException | InvalidRequestException | NetworkFailureException | NotStabilizedException | NotUpdatableException | PrivateTypeException | ResourceConflictException | ResourceNotFoundException | ServiceInternalErrorException | ServiceLimitExceededException | ThrottlingException | TypeNotFoundException | UnsupportedActionException | CommonErrors;
/**
 * Deletes the specified resource. For details, see Deleting a
 * resource in the *Amazon Web Services Cloud Control API User Guide*.
 *
 * After you have initiated a resource deletion request, you can monitor the progress of your
 * request by calling GetResourceRequestStatus using the `RequestToken` of the
 * `ProgressEvent` returned by `DeleteResource`.
 */
export declare const deleteResource: API.OperationMethod<DeleteResourceInput, DeleteResourceOutput, DeleteResourceError, Credentials | HttpClient.HttpClient>;
export type GetResourceError = AlreadyExistsException | GeneralServiceException | HandlerFailureException | HandlerInternalFailureException | InvalidCredentialsException | InvalidRequestException | NetworkFailureException | NotStabilizedException | NotUpdatableException | PrivateTypeException | ResourceConflictException | ResourceNotFoundException | ServiceInternalErrorException | ServiceLimitExceededException | ThrottlingException | TypeNotFoundException | UnsupportedActionException | CommonErrors;
/**
 * Returns information about the current state of the specified resource. For details, see
 * Reading a resource's current state.
 *
 * You can use this action to return information about an existing resource in your account
 * and Amazon Web Services Region, whether those resources were provisioned using Cloud Control API.
 */
export declare const getResource: API.OperationMethod<GetResourceInput, GetResourceOutput, GetResourceError, Credentials | HttpClient.HttpClient>;
export type GetResourceRequestStatusError = RequestTokenNotFoundException | CommonErrors;
/**
 * Returns the current status of a resource operation request. For more information, see
 * Tracking the progress of resource operation requests in the
 * *Amazon Web Services Cloud Control API User Guide*.
 */
export declare const getResourceRequestStatus: API.OperationMethod<GetResourceRequestStatusInput, GetResourceRequestStatusOutput, GetResourceRequestStatusError, Credentials | HttpClient.HttpClient>;
export type ListResourceRequestsError = CommonErrors;
/**
 * Returns existing resource operation requests. This includes requests of all status types.
 * For more information, see Listing active resource operation requests in the
 * *Amazon Web Services Cloud Control API User Guide*.
 *
 * Resource operation requests expire after 7 days.
 */
export declare const listResourceRequests: API.PaginatedOperationMethod<ListResourceRequestsInput, ListResourceRequestsOutput, ListResourceRequestsError, Credentials | HttpClient.HttpClient, ProgressEvent>;
export type ListResourcesError = AlreadyExistsException | GeneralServiceException | HandlerFailureException | HandlerInternalFailureException | InvalidCredentialsException | InvalidRequestException | NetworkFailureException | NotStabilizedException | NotUpdatableException | PrivateTypeException | ResourceConflictException | ResourceNotFoundException | ServiceInternalErrorException | ServiceLimitExceededException | ThrottlingException | TypeNotFoundException | UnsupportedActionException | CommonErrors;
/**
 * Returns information about the specified resources. For more information, see Discovering resources in the *Amazon Web Services Cloud Control API User Guide*.
 *
 * You can use this action to return information about existing resources in your account and
 * Amazon Web Services Region, whether those resources were provisioned using Cloud Control API.
 */
export declare const listResources: API.PaginatedOperationMethod<ListResourcesInput, ListResourcesOutput, ListResourcesError, Credentials | HttpClient.HttpClient, ResourceDescription>;
export type UpdateResourceError = AlreadyExistsException | ClientTokenConflictException | ConcurrentOperationException | GeneralServiceException | HandlerFailureException | HandlerInternalFailureException | InvalidCredentialsException | InvalidRequestException | NetworkFailureException | NotStabilizedException | NotUpdatableException | PrivateTypeException | ResourceConflictException | ResourceNotFoundException | ServiceInternalErrorException | ServiceLimitExceededException | ThrottlingException | TypeNotFoundException | UnsupportedActionException | CommonErrors;
/**
 * Updates the specified property values in the resource.
 *
 * You specify your resource property updates as a list of patch operations contained in a
 * JSON patch document that adheres to the
 * RFC 6902 - JavaScript Object
 * Notation (JSON) Patch
 * standard.
 *
 * For details on how Cloud Control API performs resource update operations, see Updating a resource in the *Amazon Web Services Cloud Control API User Guide*.
 *
 * After you have initiated a resource update request, you can monitor the progress of your
 * request by calling GetResourceRequestStatus using the `RequestToken` of the
 * `ProgressEvent` returned by `UpdateResource`.
 *
 * For more information about the properties of a specific resource, refer to the related
 * topic for the resource in the Resource and property types reference in the *CloudFormation Users Guide*.
 */
export declare const updateResource: API.OperationMethod<UpdateResourceInput, UpdateResourceOutput, UpdateResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cloudcontrol.d.ts.map