import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import * as T from "../traits.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const BulkLoadIdNotFoundException_base: S.TaggedErrorClass<"BulkLoadIdNotFoundException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class BulkLoadIdNotFoundException extends /*@__PURE__*/ BulkLoadIdNotFoundException_base {
}
declare const CancelledByUserException_base: S.TaggedErrorClass<"CancelledByUserException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class CancelledByUserException extends /*@__PURE__*/ CancelledByUserException_base {
}
declare const ClientTimeoutException_base: S.TaggedErrorClass<"ClientTimeoutException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ClientTimeoutException extends /*@__PURE__*/ ClientTimeoutException_base {
}
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConstraintViolationException_base: S.TaggedErrorClass<"ConstraintViolationException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ConstraintViolationException extends /*@__PURE__*/ ConstraintViolationException_base {
}
declare const ExpiredStreamException_base: S.TaggedErrorClass<"ExpiredStreamException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ExpiredStreamException extends /*@__PURE__*/ ExpiredStreamException_base {
}
declare const FailureByQueryException_base: S.TaggedErrorClass<"FailureByQueryException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class FailureByQueryException extends /*@__PURE__*/ FailureByQueryException_base {
}
declare const IllegalArgumentException_base: S.TaggedErrorClass<"IllegalArgumentException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IllegalArgumentException extends /*@__PURE__*/ IllegalArgumentException_base {
}
declare const InternalFailureException_base: S.TaggedErrorClass<"InternalFailureException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const InvalidArgumentException_base: S.TaggedErrorClass<"InvalidArgumentException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidArgumentException extends /*@__PURE__*/ InvalidArgumentException_base {
}
declare const InvalidNumericDataException_base: S.TaggedErrorClass<"InvalidNumericDataException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNumericDataException extends /*@__PURE__*/ InvalidNumericDataException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const LoadUrlAccessDeniedException_base: S.TaggedErrorClass<"LoadUrlAccessDeniedException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class LoadUrlAccessDeniedException extends /*@__PURE__*/ LoadUrlAccessDeniedException_base {
}
declare const MalformedQueryException_base: S.TaggedErrorClass<"MalformedQueryException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MalformedQueryException extends /*@__PURE__*/ MalformedQueryException_base {
}
declare const MemoryLimitExceededException_base: S.TaggedErrorClass<"MemoryLimitExceededException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class MemoryLimitExceededException extends /*@__PURE__*/ MemoryLimitExceededException_base {
}
declare const MethodNotAllowedException_base: S.TaggedErrorClass<"MethodNotAllowedException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MethodNotAllowedException extends /*@__PURE__*/ MethodNotAllowedException_base {
}
declare const MissingParameterException_base: S.TaggedErrorClass<"MissingParameterException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MissingParameterException extends /*@__PURE__*/ MissingParameterException_base {
}
declare const MLResourceNotFoundException_base: S.TaggedErrorClass<"MLResourceNotFoundException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MLResourceNotFoundException extends /*@__PURE__*/ MLResourceNotFoundException_base {
}
declare const ParsingException_base: S.TaggedErrorClass<"ParsingException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ParsingException extends /*@__PURE__*/ ParsingException_base {
}
declare const PreconditionsFailedException_base: S.TaggedErrorClass<"PreconditionsFailedException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PreconditionsFailedException extends /*@__PURE__*/ PreconditionsFailedException_base {
}
declare const QueryLimitExceededException_base: S.TaggedErrorClass<"QueryLimitExceededException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class QueryLimitExceededException extends /*@__PURE__*/ QueryLimitExceededException_base {
}
declare const QueryLimitException_base: S.TaggedErrorClass<"QueryLimitException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class QueryLimitException extends /*@__PURE__*/ QueryLimitException_base {
}
declare const QueryTooLargeException_base: S.TaggedErrorClass<"QueryTooLargeException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class QueryTooLargeException extends /*@__PURE__*/ QueryTooLargeException_base {
}
declare const ReadOnlyViolationException_base: S.TaggedErrorClass<"ReadOnlyViolationException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReadOnlyViolationException extends /*@__PURE__*/ ReadOnlyViolationException_base {
}
declare const S3Exception_base: S.TaggedErrorClass<"S3Exception", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class S3Exception extends /*@__PURE__*/ S3Exception_base {
}
declare const ServerShutdownException_base: S.TaggedErrorClass<"ServerShutdownException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServerShutdownException extends /*@__PURE__*/ ServerShutdownException_base {
}
declare const StatisticsNotAvailableException_base: S.TaggedErrorClass<"StatisticsNotAvailableException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StatisticsNotAvailableException extends /*@__PURE__*/ StatisticsNotAvailableException_base {
}
declare const StreamRecordsNotFoundException_base: S.TaggedErrorClass<"StreamRecordsNotFoundException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StreamRecordsNotFoundException extends /*@__PURE__*/ StreamRecordsNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TimeLimitExceededException_base: S.TaggedErrorClass<"TimeLimitExceededException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TimeLimitExceededException extends /*@__PURE__*/ TimeLimitExceededException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnsupportedOperationException_base: S.TaggedErrorClass<"UnsupportedOperationException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
export interface CancelGremlinQueryInput {
    queryId: string;
}
export interface CancelGremlinQueryOutput {
    status?: string;
}
export interface CancelLoaderJobInput {
    loadId: string;
}
export interface CancelLoaderJobOutput {
    status?: string;
}
export interface CancelMLDataProcessingJobInput {
    id: string;
    neptuneIamRoleArn?: string;
    clean?: boolean;
}
export interface CancelMLDataProcessingJobOutput {
    status?: string;
}
export interface CancelMLModelTrainingJobInput {
    id: string;
    neptuneIamRoleArn?: string;
    clean?: boolean;
}
export interface CancelMLModelTrainingJobOutput {
    status?: string;
}
export interface CancelMLModelTransformJobInput {
    id: string;
    neptuneIamRoleArn?: string;
    clean?: boolean;
}
export interface CancelMLModelTransformJobOutput {
    status?: string;
}
export interface CancelOpenCypherQueryInput {
    queryId: string;
    silent?: boolean;
}
export interface CancelOpenCypherQueryOutput {
    status?: string;
    payload?: boolean;
}
export interface CreateMLEndpointInput {
    id?: string;
    mlModelTrainingJobId?: string;
    mlModelTransformJobId?: string;
    update?: boolean;
    neptuneIamRoleArn?: string;
    modelName?: string;
    instanceType?: string;
    instanceCount?: number;
    volumeEncryptionKMSKey?: string;
}
export interface CreateMLEndpointOutput {
    id?: string;
    arn?: string;
    creationTimeInMillis?: number;
}
export interface DeleteMLEndpointInput {
    id: string;
    neptuneIamRoleArn?: string;
    clean?: boolean;
}
export interface DeleteMLEndpointOutput {
    status?: string;
}
export interface DeletePropertygraphStatisticsRequest {
}
export interface DeleteStatisticsValueMap {
    active?: boolean;
    statisticsId?: string;
}
export interface DeletePropertygraphStatisticsOutput {
    statusCode?: number;
    status?: string;
    payload?: DeleteStatisticsValueMap;
}
export interface DeleteSparqlStatisticsRequest {
}
export interface DeleteSparqlStatisticsOutput {
    statusCode?: number;
    status?: string;
    payload?: DeleteStatisticsValueMap;
}
export type Action = "initiateDatabaseReset" | "performDatabaseReset" | (string & {});
export interface ExecuteFastResetInput {
    action: Action;
    token?: string;
}
export interface FastResetToken {
    token?: string;
}
export interface ExecuteFastResetOutput {
    status: string;
    payload?: FastResetToken;
}
export interface ExecuteGremlinExplainQueryInput {
    gremlinQuery: string;
}
export interface ExecuteGremlinExplainQueryOutput {
    output?: T.StreamingOutputBody;
}
export interface ExecuteGremlinProfileQueryInput {
    gremlinQuery: string;
    results?: boolean;
    chop?: number;
    serializer?: string;
    indexOps?: boolean;
}
export interface ExecuteGremlinProfileQueryOutput {
    output?: T.StreamingOutputBody;
}
export interface ExecuteGremlinQueryInput {
    gremlinQuery: string;
    serializer?: string;
}
export interface GremlinQueryStatusAttributes {
    message?: string;
    code?: number;
    attributes?: any;
}
export interface ExecuteGremlinQueryOutput {
    requestId?: string;
    status?: GremlinQueryStatusAttributes;
    result?: any;
    meta?: any;
}
export type OpenCypherExplainMode = "static" | "dynamic" | "details" | (string & {});
export interface ExecuteOpenCypherExplainQueryInput {
    openCypherQuery: string;
    parameters?: string;
    explainMode: OpenCypherExplainMode;
}
export interface ExecuteOpenCypherExplainQueryOutput {
    results: Uint8Array;
}
export interface ExecuteOpenCypherQueryInput {
    openCypherQuery: string;
    parameters?: string;
}
export interface ExecuteOpenCypherQueryOutput {
    results: any;
}
export interface GetEngineStatusRequest {
}
export interface QueryLanguageVersion {
    version: string;
}
export type StringValuedMap = {
    [key: string]: string | undefined;
};
export type DocumentValuedMap = {
    [key: string]: any | undefined;
};
export interface GetEngineStatusOutput {
    status?: string;
    startTime?: string;
    dbEngineVersion?: string;
    role?: string;
    dfeQueryEngine?: string;
    gremlin?: QueryLanguageVersion;
    sparql?: QueryLanguageVersion;
    opencypher?: QueryLanguageVersion;
    labMode?: {
        [key: string]: string | undefined;
    };
    rollingBackTrxCount?: number;
    rollingBackTrxEarliestStartTime?: string;
    features?: {
        [key: string]: any | undefined;
    };
    settings?: {
        [key: string]: string | undefined;
    };
}
export interface GetGremlinQueryStatusInput {
    queryId: string;
}
export interface QueryEvalStats {
    waited?: number;
    elapsed?: number;
    cancelled?: boolean;
    subqueries?: any;
}
export interface GetGremlinQueryStatusOutput {
    queryId?: string;
    queryString?: string;
    queryEvalStats?: QueryEvalStats;
}
export type PositiveInteger = number;
export interface GetLoaderJobStatusInput {
    loadId: string;
    details?: boolean;
    errors?: boolean;
    page?: number;
    errorsPerPage?: number;
}
export interface GetLoaderJobStatusOutput {
    status: string;
    payload: any;
}
export interface GetMLDataProcessingJobInput {
    id: string;
    neptuneIamRoleArn?: string;
}
export interface MlResourceDefinition {
    name?: string;
    arn?: string;
    status?: string;
    outputLocation?: string;
    failureReason?: string;
    cloudwatchLogUrl?: string;
}
export interface GetMLDataProcessingJobOutput {
    status?: string;
    id?: string;
    processingJob?: MlResourceDefinition;
}
export interface GetMLEndpointInput {
    id: string;
    neptuneIamRoleArn?: string;
}
export interface MlConfigDefinition {
    name?: string;
    arn?: string;
}
export interface GetMLEndpointOutput {
    status?: string;
    id?: string;
    endpoint?: MlResourceDefinition;
    endpointConfig?: MlConfigDefinition;
}
export interface GetMLModelTrainingJobInput {
    id: string;
    neptuneIamRoleArn?: string;
}
export type MlModels = MlConfigDefinition[];
export interface GetMLModelTrainingJobOutput {
    status?: string;
    id?: string;
    processingJob?: MlResourceDefinition;
    hpoJob?: MlResourceDefinition;
    modelTransformJob?: MlResourceDefinition;
    mlModels?: MlConfigDefinition[];
}
export interface GetMLModelTransformJobInput {
    id: string;
    neptuneIamRoleArn?: string;
}
export type Models = MlConfigDefinition[];
export interface GetMLModelTransformJobOutput {
    status?: string;
    id?: string;
    baseProcessingJob?: MlResourceDefinition;
    remoteModelTransformJob?: MlResourceDefinition;
    models?: MlConfigDefinition[];
}
export interface GetOpenCypherQueryStatusInput {
    queryId: string;
}
export interface GetOpenCypherQueryStatusOutput {
    queryId?: string;
    queryString?: string;
    queryEvalStats?: QueryEvalStats;
}
export interface GetPropertygraphStatisticsRequest {
}
export interface StatisticsSummary {
    signatureCount?: number;
    instanceCount?: number;
    predicateCount?: number;
}
export interface Statistics {
    autoCompute?: boolean;
    active?: boolean;
    statisticsId?: string;
    date?: Date;
    note?: string;
    signatureInfo?: StatisticsSummary;
}
export interface GetPropertygraphStatisticsOutput {
    status: string;
    payload: Statistics;
}
export type IteratorType = "AT_SEQUENCE_NUMBER" | "AFTER_SEQUENCE_NUMBER" | "TRIM_HORIZON" | "LATEST" | (string & {});
export type Encoding = "gzip" | (string & {});
export interface GetPropertygraphStreamInput {
    limit?: number;
    iteratorType?: IteratorType;
    commitNum?: number;
    opNum?: number;
    encoding?: Encoding;
}
export interface PropertygraphData {
    id: string;
    type: string;
    key: string;
    value: any;
    from?: string;
    to?: string;
}
export interface PropertygraphRecord {
    commitTimestampInMillis: number;
    eventId: {
        [key: string]: string | undefined;
    };
    data: PropertygraphData;
    op: string;
    isLastOp?: boolean;
}
export type PropertygraphRecordsList = PropertygraphRecord[];
export interface GetPropertygraphStreamOutput {
    lastEventId: {
        [key: string]: string | undefined;
    };
    lastTrxTimestampInMillis: number;
    format: string;
    records: PropertygraphRecord[];
    totalRecords: number;
}
export type GraphSummaryType = "basic" | "detailed" | (string & {});
export interface GetPropertygraphSummaryInput {
    mode?: GraphSummaryType;
}
export type NodeLabels = string[];
export type EdgeLabels = string[];
export type LongValuedMap = {
    [key: string]: number | undefined;
};
export type LongValuedMapList = {
    [key: string]: number | undefined;
}[];
export type NodeProperties = string[];
export type OutgoingEdgeLabels = string[];
export interface NodeStructure {
    count?: number;
    nodeProperties?: string[];
    distinctOutgoingEdgeLabels?: string[];
}
export type NodeStructures = NodeStructure[];
export type EdgeProperties = string[];
export interface EdgeStructure {
    count?: number;
    edgeProperties?: string[];
}
export type EdgeStructures = EdgeStructure[];
export interface PropertygraphSummary {
    numNodes?: number;
    numEdges?: number;
    numNodeLabels?: number;
    numEdgeLabels?: number;
    nodeLabels?: string[];
    edgeLabels?: string[];
    numNodeProperties?: number;
    numEdgeProperties?: number;
    nodeProperties?: {
        [key: string]: number | undefined;
    }[];
    edgeProperties?: {
        [key: string]: number | undefined;
    }[];
    totalNodePropertyValues?: number;
    totalEdgePropertyValues?: number;
    nodeStructures?: NodeStructure[];
    edgeStructures?: EdgeStructure[];
}
export interface PropertygraphSummaryValueMap {
    version?: string;
    lastStatisticsComputationTime?: Date;
    graphSummary?: PropertygraphSummary;
}
export interface GetPropertygraphSummaryOutput {
    statusCode?: number;
    payload?: PropertygraphSummaryValueMap;
}
export interface GetRDFGraphSummaryInput {
    mode?: GraphSummaryType;
}
export type Classes = string[];
export type Predicates = string[];
export interface SubjectStructure {
    count?: number;
    predicates?: string[];
}
export type SubjectStructures = SubjectStructure[];
export interface RDFGraphSummary {
    numDistinctSubjects?: number;
    numDistinctPredicates?: number;
    numQuads?: number;
    numClasses?: number;
    classes?: string[];
    predicates?: {
        [key: string]: number | undefined;
    }[];
    subjectStructures?: SubjectStructure[];
}
export interface RDFGraphSummaryValueMap {
    version?: string;
    lastStatisticsComputationTime?: Date;
    graphSummary?: RDFGraphSummary;
}
export interface GetRDFGraphSummaryOutput {
    statusCode?: number;
    payload?: RDFGraphSummaryValueMap;
}
export interface GetSparqlStatisticsRequest {
}
export interface GetSparqlStatisticsOutput {
    status: string;
    payload: Statistics;
}
export interface GetSparqlStreamInput {
    limit?: number;
    iteratorType?: IteratorType;
    commitNum?: number;
    opNum?: number;
    encoding?: Encoding;
}
export interface SparqlData {
    stmt: string;
}
export interface SparqlRecord {
    commitTimestampInMillis: number;
    eventId: {
        [key: string]: string | undefined;
    };
    data: SparqlData;
    op: string;
    isLastOp?: boolean;
}
export type SparqlRecordsList = SparqlRecord[];
export interface GetSparqlStreamOutput {
    lastEventId: {
        [key: string]: string | undefined;
    };
    lastTrxTimestampInMillis: number;
    format: string;
    records: SparqlRecord[];
    totalRecords: number;
}
export interface ListGremlinQueriesInput {
    includeWaiting?: boolean;
}
export interface GremlinQueryStatus {
    queryId?: string;
    queryString?: string;
    queryEvalStats?: QueryEvalStats;
}
export type GremlinQueries = GremlinQueryStatus[];
export interface ListGremlinQueriesOutput {
    acceptedQueryCount?: number;
    runningQueryCount?: number;
    queries?: GremlinQueryStatus[];
}
export interface ListLoaderJobsInput {
    limit?: number;
    includeQueuedLoads?: boolean;
}
export type StringList = string[];
export interface LoaderIdResult {
    loadIds?: string[];
}
export interface ListLoaderJobsOutput {
    status: string;
    payload: LoaderIdResult;
}
export interface ListMLDataProcessingJobsInput {
    maxItems?: number;
    neptuneIamRoleArn?: string;
}
export interface ListMLDataProcessingJobsOutput {
    ids?: string[];
}
export interface ListMLEndpointsInput {
    maxItems?: number;
    neptuneIamRoleArn?: string;
}
export interface ListMLEndpointsOutput {
    ids?: string[];
}
export interface ListMLModelTrainingJobsInput {
    maxItems?: number;
    neptuneIamRoleArn?: string;
}
export interface ListMLModelTrainingJobsOutput {
    ids?: string[];
}
export interface ListMLModelTransformJobsInput {
    maxItems?: number;
    neptuneIamRoleArn?: string;
}
export interface ListMLModelTransformJobsOutput {
    ids?: string[];
}
export interface ListOpenCypherQueriesInput {
    includeWaiting?: boolean;
}
export type OpenCypherQueries = GremlinQueryStatus[];
export interface ListOpenCypherQueriesOutput {
    acceptedQueryCount?: number;
    runningQueryCount?: number;
    queries?: GremlinQueryStatus[];
}
export type StatisticsAutoGenerationMode = "disableAutoCompute" | "enableAutoCompute" | "refresh" | (string & {});
export interface ManagePropertygraphStatisticsInput {
    mode?: StatisticsAutoGenerationMode;
}
export interface RefreshStatisticsIdMap {
    statisticsId?: string;
}
export interface ManagePropertygraphStatisticsOutput {
    status: string;
    payload?: RefreshStatisticsIdMap;
}
export interface ManageSparqlStatisticsInput {
    mode?: StatisticsAutoGenerationMode;
}
export interface ManageSparqlStatisticsOutput {
    status: string;
    payload?: RefreshStatisticsIdMap;
}
export type Format = "csv" | "opencypher" | "ntriples" | "nquads" | "rdfxml" | "turtle" | (string & {});
export type S3BucketRegion = "us-east-1" | "us-east-2" | "us-west-1" | "us-west-2" | "ca-central-1" | "sa-east-1" | "eu-north-1" | "eu-west-1" | "eu-west-2" | "eu-west-3" | "eu-central-1" | "me-south-1" | "af-south-1" | "ap-east-1" | "ap-northeast-1" | "ap-northeast-2" | "ap-southeast-1" | "ap-southeast-2" | "ap-south-1" | "cn-north-1" | "cn-northwest-1" | "us-gov-west-1" | "us-gov-east-1" | "ca-west-1" | "eu-south-2" | "il-central-1" | "me-central-1" | "ap-northeast-3" | "ap-southeast-3" | "ap-southeast-4" | "ap-southeast-5" | "ap-southeast-7" | "mx-central-1" | "ap-east-2" | "ap-south-2" | "eu-central-2" | (string & {});
export type Mode = "RESUME" | "NEW" | "AUTO" | (string & {});
export type Parallelism = "LOW" | "MEDIUM" | "HIGH" | "OVERSUBSCRIBE" | (string & {});
export interface StartLoaderJobInput {
    source: string;
    format: Format;
    s3BucketRegion: S3BucketRegion;
    iamRoleArn: string;
    mode?: Mode;
    failOnError?: boolean;
    parallelism?: Parallelism;
    parserConfiguration?: {
        [key: string]: string | undefined;
    };
    updateSingleCardinalityProperties?: boolean;
    queueRequest?: boolean;
    dependencies?: string[];
    userProvidedEdgeIds?: boolean;
    edgeOnlyLoad?: boolean;
}
export interface StartLoaderJobOutput {
    status: string;
    payload: {
        [key: string]: string | undefined;
    };
}
export interface StartMLDataProcessingJobInput {
    id?: string;
    previousDataProcessingJobId?: string;
    inputDataS3Location: string;
    processedDataS3Location: string;
    sagemakerIamRoleArn?: string;
    neptuneIamRoleArn?: string;
    processingInstanceType?: string;
    processingInstanceVolumeSizeInGB?: number;
    processingTimeOutInSeconds?: number;
    modelType?: string;
    configFileName?: string;
    subnets?: string[];
    securityGroupIds?: string[];
    volumeEncryptionKMSKey?: string;
    s3OutputEncryptionKMSKey?: string;
}
export interface StartMLDataProcessingJobOutput {
    id?: string;
    arn?: string;
    creationTimeInMillis?: number;
}
export interface CustomModelTrainingParameters {
    sourceS3DirectoryPath: string;
    trainingEntryPointScript?: string;
    transformEntryPointScript?: string;
}
export interface StartMLModelTrainingJobInput {
    id?: string;
    previousModelTrainingJobId?: string;
    dataProcessingJobId: string;
    trainModelS3Location: string;
    sagemakerIamRoleArn?: string;
    neptuneIamRoleArn?: string;
    baseProcessingInstanceType?: string;
    trainingInstanceType?: string;
    trainingInstanceVolumeSizeInGB?: number;
    trainingTimeOutInSeconds?: number;
    maxHPONumberOfTrainingJobs?: number;
    maxHPOParallelTrainingJobs?: number;
    subnets?: string[];
    securityGroupIds?: string[];
    volumeEncryptionKMSKey?: string;
    s3OutputEncryptionKMSKey?: string;
    enableManagedSpotTraining?: boolean;
    customModelTrainingParameters?: CustomModelTrainingParameters;
}
export interface StartMLModelTrainingJobOutput {
    id?: string;
    arn?: string;
    creationTimeInMillis?: number;
}
export interface CustomModelTransformParameters {
    sourceS3DirectoryPath: string;
    transformEntryPointScript?: string;
}
export interface StartMLModelTransformJobInput {
    id?: string;
    dataProcessingJobId?: string;
    mlModelTrainingJobId?: string;
    trainingJobName?: string;
    modelTransformOutputS3Location: string;
    sagemakerIamRoleArn?: string;
    neptuneIamRoleArn?: string;
    customModelTransformParameters?: CustomModelTransformParameters;
    baseProcessingInstanceType?: string;
    baseProcessingInstanceVolumeSizeInGB?: number;
    subnets?: string[];
    securityGroupIds?: string[];
    volumeEncryptionKMSKey?: string;
    s3OutputEncryptionKMSKey?: string;
}
export interface StartMLModelTransformJobOutput {
    id?: string;
    arn?: string;
    creationTimeInMillis?: number;
}
export type CancelGremlinQueryError = BadRequestException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | ParsingException | PreconditionsFailedException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Cancels a Gremlin query. See Gremlin query cancellation for more information.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:CancelQuery IAM action in that cluster.
 */
export declare const cancelGremlinQuery: API.OperationMethod<CancelGremlinQueryInput, CancelGremlinQueryOutput, CancelGremlinQueryError, Credentials | HttpClient.HttpClient>;
export type CancelLoaderJobError = BadRequestException | BulkLoadIdNotFoundException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InternalFailureException | InvalidArgumentException | InvalidParameterException | LoadUrlAccessDeniedException | MissingParameterException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Cancels a specified load job. This is an HTTP `DELETE` request. See Neptune Loader Get-Status API for more information.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:CancelLoaderJob IAM action in that cluster..
 */
export declare const cancelLoaderJob: API.OperationMethod<CancelLoaderJobInput, CancelLoaderJobOutput, CancelLoaderJobError, Credentials | HttpClient.HttpClient>;
export type CancelMLDataProcessingJobError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Cancels a Neptune ML data processing job. See The `dataprocessing` command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:CancelMLDataProcessingJob IAM action in that cluster.
 */
export declare const cancelMLDataProcessingJob: API.OperationMethod<CancelMLDataProcessingJobInput, CancelMLDataProcessingJobOutput, CancelMLDataProcessingJobError, Credentials | HttpClient.HttpClient>;
export type CancelMLModelTrainingJobError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Cancels a Neptune ML model training job. See Model training using the `modeltraining` command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:CancelMLModelTrainingJob IAM action in that cluster.
 */
export declare const cancelMLModelTrainingJob: API.OperationMethod<CancelMLModelTrainingJobInput, CancelMLModelTrainingJobOutput, CancelMLModelTrainingJobError, Credentials | HttpClient.HttpClient>;
export type CancelMLModelTransformJobError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Cancels a specified model transform job. See Use a trained model to generate new model artifacts.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:CancelMLModelTransformJob IAM action in that cluster.
 */
export declare const cancelMLModelTransformJob: API.OperationMethod<CancelMLModelTransformJobInput, CancelMLModelTransformJobOutput, CancelMLModelTransformJobError, Credentials | HttpClient.HttpClient>;
export type CancelOpenCypherQueryError = BadRequestException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidNumericDataException | InvalidParameterException | MissingParameterException | ParsingException | PreconditionsFailedException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Cancels a specified openCypher query. See Neptune openCypher status endpoint for more information.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:CancelQuery IAM action in that cluster.
 */
export declare const cancelOpenCypherQuery: API.OperationMethod<CancelOpenCypherQueryInput, CancelOpenCypherQueryOutput, CancelOpenCypherQueryError, Credentials | HttpClient.HttpClient>;
export type CreateMLEndpointError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a new Neptune ML inference endpoint that lets you query one specific model that the model-training process constructed. See Managing inference endpoints using the endpoints command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:CreateMLEndpoint IAM action in that cluster.
 */
export declare const createMLEndpoint: API.OperationMethod<CreateMLEndpointInput, CreateMLEndpointOutput, CreateMLEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteMLEndpointError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Cancels the creation of a Neptune ML inference endpoint. See Managing inference endpoints using the endpoints command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:DeleteMLEndpoint IAM action in that cluster.
 */
export declare const deleteMLEndpoint: API.OperationMethod<DeleteMLEndpointInput, DeleteMLEndpointOutput, DeleteMLEndpointError, Credentials | HttpClient.HttpClient>;
export type DeletePropertygraphStatisticsError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | PreconditionsFailedException | ReadOnlyViolationException | StatisticsNotAvailableException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes statistics for Gremlin and openCypher (property graph) data.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:DeleteStatistics IAM action in that cluster.
 */
export declare const deletePropertygraphStatistics: API.OperationMethod<DeletePropertygraphStatisticsRequest, DeletePropertygraphStatisticsOutput, DeletePropertygraphStatisticsError, Credentials | HttpClient.HttpClient>;
export type DeleteSparqlStatisticsError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | PreconditionsFailedException | ReadOnlyViolationException | StatisticsNotAvailableException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes SPARQL statistics
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:DeleteStatistics IAM action in that cluster.
 */
export declare const deleteSparqlStatistics: API.OperationMethod<DeleteSparqlStatisticsRequest, DeleteSparqlStatisticsOutput, DeleteSparqlStatisticsError, Credentials | HttpClient.HttpClient>;
export type ExecuteFastResetError = AccessDeniedException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MethodNotAllowedException | MissingParameterException | PreconditionsFailedException | ReadOnlyViolationException | ServerShutdownException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * The fast reset REST API lets you reset a Neptune graph quicky and easily, removing all of its data.
 *
 * Neptune fast reset is a two-step process. First you call `ExecuteFastReset` with `action` set to `initiateDatabaseReset`. This returns a UUID token which you then include when calling `ExecuteFastReset` again with `action` set to `performDatabaseReset`. See Empty an Amazon Neptune DB cluster using the fast reset API.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:ResetDatabase IAM action in that cluster.
 */
export declare const executeFastReset: API.OperationMethod<ExecuteFastResetInput, ExecuteFastResetOutput, ExecuteFastResetError, Credentials | HttpClient.HttpClient>;
export type ExecuteGremlinExplainQueryError = BadRequestException | CancelledByUserException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MalformedQueryException | MemoryLimitExceededException | MissingParameterException | ParsingException | PreconditionsFailedException | QueryLimitExceededException | QueryLimitException | QueryTooLargeException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Executes a Gremlin Explain query.
 *
 * Amazon Neptune has added a Gremlin feature named `explain` that provides is a self-service tool for understanding the execution approach being taken by the Neptune engine for the query. You invoke it by adding an `explain` parameter to an HTTP call that submits a Gremlin query.
 *
 * The explain feature provides information about the logical structure of query execution plans. You can use this information to identify potential evaluation and execution bottlenecks and to tune your query, as explained in Tuning Gremlin queries. You can also use query hints to improve query execution plans.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows one of the following IAM actions in that cluster, depending on the query:
 *
 * - neptune-db:ReadDataViaQuery
 *
 * - neptune-db:WriteDataViaQuery
 *
 * - neptune-db:DeleteDataViaQuery
 *
 * Note that the neptune-db:QueryLanguage:Gremlin IAM condition key can be used in the policy document to restrict the use of Gremlin queries (see Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const executeGremlinExplainQuery: API.OperationMethod<ExecuteGremlinExplainQueryInput, ExecuteGremlinExplainQueryOutput, ExecuteGremlinExplainQueryError, Credentials | HttpClient.HttpClient>;
export type ExecuteGremlinProfileQueryError = BadRequestException | CancelledByUserException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MalformedQueryException | MemoryLimitExceededException | MissingParameterException | ParsingException | PreconditionsFailedException | QueryLimitExceededException | QueryLimitException | QueryTooLargeException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Executes a Gremlin Profile query, which runs a specified traversal, collects various metrics about the run, and produces a profile report as output. See Gremlin profile API in Neptune for details.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:ReadDataViaQuery IAM action in that cluster.
 *
 * Note that the neptune-db:QueryLanguage:Gremlin IAM condition key can be used in the policy document to restrict the use of Gremlin queries (see Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const executeGremlinProfileQuery: API.OperationMethod<ExecuteGremlinProfileQueryInput, ExecuteGremlinProfileQueryOutput, ExecuteGremlinProfileQueryError, Credentials | HttpClient.HttpClient>;
export type ExecuteGremlinQueryError = BadRequestException | CancelledByUserException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MalformedQueryException | MemoryLimitExceededException | MissingParameterException | ParsingException | PreconditionsFailedException | QueryLimitExceededException | QueryLimitException | QueryTooLargeException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * This commands executes a Gremlin query. Amazon Neptune is compatible with Apache TinkerPop3 and Gremlin, so you can use the Gremlin traversal language to query the graph, as described under The Graph in the Apache TinkerPop3 documentation. More details can also be found in Accessing a Neptune graph with Gremlin.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that enables one of the following IAM actions in that cluster, depending on the query:
 *
 * - neptune-db:ReadDataViaQuery
 *
 * - neptune-db:WriteDataViaQuery
 *
 * - neptune-db:DeleteDataViaQuery
 *
 * Note that the neptune-db:QueryLanguage:Gremlin IAM condition key can be used in the policy document to restrict the use of Gremlin queries (see Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const executeGremlinQuery: API.OperationMethod<ExecuteGremlinQueryInput, ExecuteGremlinQueryOutput, ExecuteGremlinQueryError, Credentials | HttpClient.HttpClient>;
export type ExecuteOpenCypherExplainQueryError = BadRequestException | CancelledByUserException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidNumericDataException | InvalidParameterException | MalformedQueryException | MemoryLimitExceededException | MissingParameterException | ParsingException | PreconditionsFailedException | QueryLimitExceededException | QueryLimitException | QueryTooLargeException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Executes an openCypher `explain` request. See The openCypher explain feature for more information.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:ReadDataViaQuery IAM action in that cluster.
 *
 * Note that the neptune-db:QueryLanguage:OpenCypher IAM condition key can be used in the policy document to restrict the use of openCypher queries (see Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const executeOpenCypherExplainQuery: API.OperationMethod<ExecuteOpenCypherExplainQueryInput, ExecuteOpenCypherExplainQueryOutput, ExecuteOpenCypherExplainQueryError, Credentials | HttpClient.HttpClient>;
export type ExecuteOpenCypherQueryError = BadRequestException | CancelledByUserException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidNumericDataException | InvalidParameterException | MalformedQueryException | MemoryLimitExceededException | MissingParameterException | ParsingException | PreconditionsFailedException | QueryLimitExceededException | QueryLimitException | QueryTooLargeException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Executes an openCypher query. See Accessing the Neptune Graph with openCypher for more information.
 *
 * Neptune supports building graph applications using openCypher, which is currently one of the most popular query languages among developers working with graph databases. Developers, business analysts, and data scientists like openCypher's declarative, SQL-inspired syntax because it provides a familiar structure in which to querying property graphs.
 *
 * The openCypher language was originally developed by Neo4j, then open-sourced in 2015 and contributed to the openCypher project under an Apache 2 open-source license.
 *
 * Note that when invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows one of the following IAM actions in that cluster, depending on the query:
 *
 * - neptune-db:ReadDataViaQuery
 *
 * - neptune-db:WriteDataViaQuery
 *
 * - neptune-db:DeleteDataViaQuery
 *
 * Note also that the neptune-db:QueryLanguage:OpenCypher IAM condition key can be used in the policy document to restrict the use of openCypher queries (see Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const executeOpenCypherQuery: API.OperationMethod<ExecuteOpenCypherQueryInput, ExecuteOpenCypherQueryOutput, ExecuteOpenCypherQueryError, Credentials | HttpClient.HttpClient>;
export type GetEngineStatusError = ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InternalFailureException | InvalidArgumentException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves the status of the graph database on the host.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetEngineStatus IAM action in that cluster.
 */
export declare const getEngineStatus: API.OperationMethod<GetEngineStatusRequest, GetEngineStatusOutput, GetEngineStatusError, Credentials | HttpClient.HttpClient>;
export type GetGremlinQueryStatusError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | ParsingException | PreconditionsFailedException | ReadOnlyViolationException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Gets the status of a specified Gremlin query.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetQueryStatus IAM action in that cluster.
 *
 * Note that the neptune-db:QueryLanguage:Gremlin IAM condition key can be used in the policy document to restrict the use of Gremlin queries (see Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const getGremlinQueryStatus: API.OperationMethod<GetGremlinQueryStatusInput, GetGremlinQueryStatusOutput, GetGremlinQueryStatusError, Credentials | HttpClient.HttpClient>;
export type GetLoaderJobStatusError = BadRequestException | BulkLoadIdNotFoundException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InternalFailureException | InvalidArgumentException | InvalidParameterException | LoadUrlAccessDeniedException | MissingParameterException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Gets status information about a specified load job. Neptune keeps track of the most recent 1,024 bulk load jobs, and stores the last 10,000 error details per job.
 *
 * See Neptune Loader Get-Status API for more information.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetLoaderJobStatus IAM action in that cluster..
 */
export declare const getLoaderJobStatus: API.OperationMethod<GetLoaderJobStatusInput, GetLoaderJobStatusOutput, GetLoaderJobStatusError, Credentials | HttpClient.HttpClient>;
export type GetMLDataProcessingJobError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves information about a specified data processing job. See The `dataprocessing` command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:neptune-db:GetMLDataProcessingJobStatus IAM action in that cluster.
 */
export declare const getMLDataProcessingJob: API.OperationMethod<GetMLDataProcessingJobInput, GetMLDataProcessingJobOutput, GetMLDataProcessingJobError, Credentials | HttpClient.HttpClient>;
export type GetMLEndpointError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves details about an inference endpoint. See Managing inference endpoints using the endpoints command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetMLEndpointStatus IAM action in that cluster.
 */
export declare const getMLEndpoint: API.OperationMethod<GetMLEndpointInput, GetMLEndpointOutput, GetMLEndpointError, Credentials | HttpClient.HttpClient>;
export type GetMLModelTrainingJobError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves information about a Neptune ML model training job. See Model training using the `modeltraining` command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetMLModelTrainingJobStatus IAM action in that cluster.
 */
export declare const getMLModelTrainingJob: API.OperationMethod<GetMLModelTrainingJobInput, GetMLModelTrainingJobOutput, GetMLModelTrainingJobError, Credentials | HttpClient.HttpClient>;
export type GetMLModelTransformJobError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Gets information about a specified model transform job. See Use a trained model to generate new model artifacts.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetMLModelTransformJobStatus IAM action in that cluster.
 */
export declare const getMLModelTransformJob: API.OperationMethod<GetMLModelTransformJobInput, GetMLModelTransformJobOutput, GetMLModelTransformJobError, Credentials | HttpClient.HttpClient>;
export type GetOpenCypherQueryStatusError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidNumericDataException | InvalidParameterException | MissingParameterException | ParsingException | PreconditionsFailedException | ReadOnlyViolationException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves the status of a specified openCypher query.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetQueryStatus IAM action in that cluster.
 *
 * Note that the neptune-db:QueryLanguage:OpenCypher IAM condition key can be used in the policy document to restrict the use of openCypher queries (see Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const getOpenCypherQueryStatus: API.OperationMethod<GetOpenCypherQueryStatusInput, GetOpenCypherQueryStatusOutput, GetOpenCypherQueryStatusError, Credentials | HttpClient.HttpClient>;
export type GetPropertygraphStatisticsError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | PreconditionsFailedException | ReadOnlyViolationException | StatisticsNotAvailableException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Gets property graph statistics (Gremlin and openCypher).
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetStatisticsStatus IAM action in that cluster.
 */
export declare const getPropertygraphStatistics: API.OperationMethod<GetPropertygraphStatisticsRequest, GetPropertygraphStatisticsOutput, GetPropertygraphStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetPropertygraphStreamError = ClientTimeoutException | ConstraintViolationException | ExpiredStreamException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MemoryLimitExceededException | PreconditionsFailedException | StreamRecordsNotFoundException | ThrottlingException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Gets a stream for a property graph.
 *
 * With the Neptune Streams feature, you can generate a complete sequence of change-log entries that record every change made to your graph data as it happens. `GetPropertygraphStream` lets you collect these change-log entries for a property graph.
 *
 * The Neptune streams feature needs to be enabled on your Neptune DBcluster. To enable streams, set the neptune_streams DB cluster parameter to `1`.
 *
 * See Capturing graph changes in real time using Neptune streams.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetStreamRecords IAM action in that cluster.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that enables one of the following IAM actions, depending on the query:
 *
 * Note that you can restrict property-graph queries using the following IAM context keys:
 *
 * - neptune-db:QueryLanguage:Gremlin
 *
 * - neptune-db:QueryLanguage:OpenCypher
 *
 * See Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const getPropertygraphStream: API.OperationMethod<GetPropertygraphStreamInput, GetPropertygraphStreamOutput, GetPropertygraphStreamError, Credentials | HttpClient.HttpClient>;
export type GetPropertygraphSummaryError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | PreconditionsFailedException | ReadOnlyViolationException | StatisticsNotAvailableException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Gets a graph summary for a property graph.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetGraphSummary IAM action in that cluster.
 */
export declare const getPropertygraphSummary: API.OperationMethod<GetPropertygraphSummaryInput, GetPropertygraphSummaryOutput, GetPropertygraphSummaryError, Credentials | HttpClient.HttpClient>;
export type GetRDFGraphSummaryError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | PreconditionsFailedException | ReadOnlyViolationException | StatisticsNotAvailableException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Gets a graph summary for an RDF graph.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetGraphSummary IAM action in that cluster.
 */
export declare const getRDFGraphSummary: API.OperationMethod<GetRDFGraphSummaryInput, GetRDFGraphSummaryOutput, GetRDFGraphSummaryError, Credentials | HttpClient.HttpClient>;
export type GetSparqlStatisticsError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | PreconditionsFailedException | ReadOnlyViolationException | StatisticsNotAvailableException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Gets RDF statistics (SPARQL).
 */
export declare const getSparqlStatistics: API.OperationMethod<GetSparqlStatisticsRequest, GetSparqlStatisticsOutput, GetSparqlStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetSparqlStreamError = ClientTimeoutException | ConstraintViolationException | ExpiredStreamException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MemoryLimitExceededException | PreconditionsFailedException | StreamRecordsNotFoundException | ThrottlingException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Gets a stream for an RDF graph.
 *
 * With the Neptune Streams feature, you can generate a complete sequence of change-log entries that record every change made to your graph data as it happens. `GetSparqlStream` lets you collect these change-log entries for an RDF graph.
 *
 * The Neptune streams feature needs to be enabled on your Neptune DBcluster. To enable streams, set the neptune_streams DB cluster parameter to `1`.
 *
 * See Capturing graph changes in real time using Neptune streams.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetStreamRecords IAM action in that cluster.
 *
 * Note that the neptune-db:QueryLanguage:Sparql IAM condition key can be used in the policy document to restrict the use of SPARQL queries (see Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const getSparqlStream: API.OperationMethod<GetSparqlStreamInput, GetSparqlStreamOutput, GetSparqlStreamError, Credentials | HttpClient.HttpClient>;
export type ListGremlinQueriesError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | ParsingException | PreconditionsFailedException | ReadOnlyViolationException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Lists active Gremlin queries. See Gremlin query status API for details about the output.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetQueryStatus IAM action in that cluster.
 *
 * Note that the neptune-db:QueryLanguage:Gremlin IAM condition key can be used in the policy document to restrict the use of Gremlin queries (see Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const listGremlinQueries: API.OperationMethod<ListGremlinQueriesInput, ListGremlinQueriesOutput, ListGremlinQueriesError, Credentials | HttpClient.HttpClient>;
export type ListLoaderJobsError = BadRequestException | BulkLoadIdNotFoundException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InternalFailureException | InvalidArgumentException | InvalidParameterException | LoadUrlAccessDeniedException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves a list of the `loadIds` for all active loader jobs.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:ListLoaderJobs IAM action in that cluster..
 */
export declare const listLoaderJobs: API.OperationMethod<ListLoaderJobsInput, ListLoaderJobsOutput, ListLoaderJobsError, Credentials | HttpClient.HttpClient>;
export type ListMLDataProcessingJobsError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Returns a list of Neptune ML data processing jobs. See Listing active data-processing jobs using the Neptune ML dataprocessing command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:ListMLDataProcessingJobs IAM action in that cluster.
 */
export declare const listMLDataProcessingJobs: API.OperationMethod<ListMLDataProcessingJobsInput, ListMLDataProcessingJobsOutput, ListMLDataProcessingJobsError, Credentials | HttpClient.HttpClient>;
export type ListMLEndpointsError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Lists existing inference endpoints. See Managing inference endpoints using the endpoints command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:ListMLEndpoints IAM action in that cluster.
 */
export declare const listMLEndpoints: API.OperationMethod<ListMLEndpointsInput, ListMLEndpointsOutput, ListMLEndpointsError, Credentials | HttpClient.HttpClient>;
export type ListMLModelTrainingJobsError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Lists Neptune ML model-training jobs. See Model training using the `modeltraining` command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:neptune-db:ListMLModelTrainingJobs IAM action in that cluster.
 */
export declare const listMLModelTrainingJobs: API.OperationMethod<ListMLModelTrainingJobsInput, ListMLModelTrainingJobsOutput, ListMLModelTrainingJobsError, Credentials | HttpClient.HttpClient>;
export type ListMLModelTransformJobsError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Returns a list of model transform job IDs. See Use a trained model to generate new model artifacts.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:ListMLModelTransformJobs IAM action in that cluster.
 */
export declare const listMLModelTransformJobs: API.OperationMethod<ListMLModelTransformJobsInput, ListMLModelTransformJobsOutput, ListMLModelTransformJobsError, Credentials | HttpClient.HttpClient>;
export type ListOpenCypherQueriesError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidNumericDataException | InvalidParameterException | MissingParameterException | ParsingException | PreconditionsFailedException | ReadOnlyViolationException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Lists active openCypher queries. See Neptune openCypher status endpoint for more information.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetQueryStatus IAM action in that cluster.
 *
 * Note that the neptune-db:QueryLanguage:OpenCypher IAM condition key can be used in the policy document to restrict the use of openCypher queries (see Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const listOpenCypherQueries: API.OperationMethod<ListOpenCypherQueriesInput, ListOpenCypherQueriesOutput, ListOpenCypherQueriesError, Credentials | HttpClient.HttpClient>;
export type ManagePropertygraphStatisticsError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | PreconditionsFailedException | ReadOnlyViolationException | StatisticsNotAvailableException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Manages the generation and use of property graph statistics.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:ManageStatistics IAM action in that cluster.
 */
export declare const managePropertygraphStatistics: API.OperationMethod<ManagePropertygraphStatisticsInput, ManagePropertygraphStatisticsOutput, ManagePropertygraphStatisticsError, Credentials | HttpClient.HttpClient>;
export type ManageSparqlStatisticsError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | PreconditionsFailedException | ReadOnlyViolationException | StatisticsNotAvailableException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Manages the generation and use of RDF graph statistics.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:ManageStatistics IAM action in that cluster.
 */
export declare const manageSparqlStatistics: API.OperationMethod<ManageSparqlStatisticsInput, ManageSparqlStatisticsOutput, ManageSparqlStatisticsError, Credentials | HttpClient.HttpClient>;
export type StartLoaderJobError = BadRequestException | BulkLoadIdNotFoundException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InternalFailureException | InvalidArgumentException | InvalidParameterException | LoadUrlAccessDeniedException | MissingParameterException | PreconditionsFailedException | S3Exception | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Starts a Neptune bulk loader job to load data from an Amazon S3 bucket into a Neptune DB instance. See Using the Amazon Neptune Bulk Loader to Ingest Data.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:StartLoaderJob IAM action in that cluster.
 */
export declare const startLoaderJob: API.OperationMethod<StartLoaderJobInput, StartLoaderJobOutput, StartLoaderJobError, Credentials | HttpClient.HttpClient>;
export type StartMLDataProcessingJobError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a new Neptune ML data processing job for processing the graph data exported from Neptune for training. See The `dataprocessing` command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:StartMLModelDataProcessingJob IAM action in that cluster.
 */
export declare const startMLDataProcessingJob: API.OperationMethod<StartMLDataProcessingJobInput, StartMLDataProcessingJobOutput, StartMLDataProcessingJobError, Credentials | HttpClient.HttpClient>;
export type StartMLModelTrainingJobError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a new Neptune ML model training job. See Model training using the `modeltraining` command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:StartMLModelTrainingJob IAM action in that cluster.
 */
export declare const startMLModelTrainingJob: API.OperationMethod<StartMLModelTrainingJobInput, StartMLModelTrainingJobOutput, StartMLModelTrainingJobError, Credentials | HttpClient.HttpClient>;
export type StartMLModelTransformJobError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a new model transform job. See Use a trained model to generate new model artifacts.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:StartMLModelTransformJob IAM action in that cluster.
 */
export declare const startMLModelTransformJob: API.OperationMethod<StartMLModelTransformJobInput, StartMLModelTransformJobOutput, StartMLModelTransformJobError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=neptunedata.d.ts.map