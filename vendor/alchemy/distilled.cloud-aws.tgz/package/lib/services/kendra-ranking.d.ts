import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceUnavailableException_base: S.TaggedErrorClass<"ResourceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceUnavailableException extends /*@__PURE__*/ ResourceUnavailableException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type RescoreExecutionPlanName = string;
export type Description = string;
export type RescoreCapacityUnit = number;
export interface CapacityUnitsConfiguration {
    RescoreCapacityUnits: number;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export type ClientTokenName = string;
export interface CreateRescoreExecutionPlanRequest {
    Name: string;
    Description?: string;
    CapacityUnits?: CapacityUnitsConfiguration;
    Tags?: Tag[];
    ClientToken?: string;
}
export type RescoreExecutionPlanId = string;
export type RescoreExecutionPlanArn = string;
export interface CreateRescoreExecutionPlanResponse {
    Id: string;
    Arn: string;
}
export interface DeleteRescoreExecutionPlanRequest {
    Id: string;
}
export interface DeleteRescoreExecutionPlanResponse {
}
export interface DescribeRescoreExecutionPlanRequest {
    Id: string;
}
export type RescoreExecutionPlanStatus = "CREATING" | "UPDATING" | "ACTIVE" | "DELETING" | "FAILED" | (string & {});
export type ErrorMessage = string;
export interface DescribeRescoreExecutionPlanResponse {
    Id?: string;
    Arn?: string;
    Name?: string;
    Description?: string;
    CapacityUnits?: CapacityUnitsConfiguration;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    Status?: RescoreExecutionPlanStatus;
    ErrorMessage?: string;
}
export type NextToken = string;
export type MaxResultsIntegerForListRescoreExecutionPlansRequest = number;
export interface ListRescoreExecutionPlansRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface RescoreExecutionPlanSummary {
    Name?: string;
    Id?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    Status?: RescoreExecutionPlanStatus;
}
export type RescoreExecutionPlanSummaryList = RescoreExecutionPlanSummary[];
export interface ListRescoreExecutionPlansResponse {
    SummaryItems?: RescoreExecutionPlanSummary[];
    NextToken?: string;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export type SearchQuery = string;
export type DocumentId = string;
export type GroupId = string;
export type DocumentTitle = string;
export type DocumentBody = string;
export type Tokens = string;
export type TitleTokensList = string[];
export type BodyTokensList = string[];
export interface Document {
    Id: string;
    GroupId?: string;
    Title?: string;
    Body?: string;
    TokenizedTitle?: string[];
    TokenizedBody?: string[];
    OriginalScore: number;
}
export type DocumentList = Document[];
export interface RescoreRequest {
    RescoreExecutionPlanId: string;
    SearchQuery: string;
    Documents: Document[];
}
export type RescoreId = string;
export interface RescoreResultItem {
    DocumentId?: string;
    Score?: number;
}
export type RescoreResultItemList = RescoreResultItem[];
export interface RescoreResult {
    RescoreId?: string;
    ResultItems?: RescoreResultItem[];
}
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateRescoreExecutionPlanRequest {
    Id: string;
    Name?: string;
    Description?: string;
    CapacityUnits?: CapacityUnitsConfiguration;
}
export interface UpdateRescoreExecutionPlanResponse {
}
export type CreateRescoreExecutionPlanError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a rescore execution plan. A rescore execution
 * plan is an Amazon Kendra Intelligent Ranking resource
 * used for provisioning the `Rescore` API. You set
 * the number of capacity units that you require for
 * Amazon Kendra Intelligent Ranking to rescore or re-rank
 * a search service's results.
 *
 * For an example of using the
 * `CreateRescoreExecutionPlan` API, including using
 * the Python and Java SDKs, see Semantically
 * ranking a search service's results.
 */
export declare const createRescoreExecutionPlan: API.OperationMethod<CreateRescoreExecutionPlanRequest, CreateRescoreExecutionPlanResponse, CreateRescoreExecutionPlanError, Credentials | HttpClient.HttpClient>;
export type DeleteRescoreExecutionPlanError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a rescore execution plan. A rescore execution
 * plan is an Amazon Kendra Intelligent Ranking resource
 * used for provisioning the `Rescore` API.
 */
export declare const deleteRescoreExecutionPlan: API.OperationMethod<DeleteRescoreExecutionPlanRequest, DeleteRescoreExecutionPlanResponse, DeleteRescoreExecutionPlanError, Credentials | HttpClient.HttpClient>;
export type DescribeRescoreExecutionPlanError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a rescore execution plan. A rescore
 * execution plan is an Amazon Kendra Intelligent Ranking
 * resource used for provisioning the `Rescore` API.
 */
export declare const describeRescoreExecutionPlan: API.OperationMethod<DescribeRescoreExecutionPlanRequest, DescribeRescoreExecutionPlanResponse, DescribeRescoreExecutionPlanError, Credentials | HttpClient.HttpClient>;
export type ListRescoreExecutionPlansError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists your rescore execution plans. A rescore execution plan
 * is an Amazon Kendra Intelligent Ranking resource used for
 * provisioning the `Rescore` API.
 */
export declare const listRescoreExecutionPlans: API.PaginatedOperationMethod<ListRescoreExecutionPlansRequest, ListRescoreExecutionPlansResponse, ListRescoreExecutionPlansError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a list of tags associated with a specified resource.
 * A rescore execution plan is an example of a resource that
 * can have tags associated with it.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RescoreError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Rescores or re-ranks search results from a search service
 * such as OpenSearch (self managed). You use the semantic search
 * capabilities of Amazon Kendra Intelligent Ranking to
 * improve the search service's results.
 */
export declare const rescore: API.OperationMethod<RescoreRequest, RescoreResult, RescoreError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a specified tag to a specified rescore execution
 * plan. A rescore execution plan is an Amazon Kendra
 * Intelligent Ranking resource used for provisioning the
 * `Rescore` API. If the tag already exists,
 * the existing value is replaced with the new value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a tag from a rescore execution plan. A rescore
 * execution plan is an Amazon Kendra Intelligent
 * Ranking resource used for provisioning the
 * `Rescore` operation.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateRescoreExecutionPlanError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a rescore execution plan. A rescore execution plan
 * is an Amazon Kendra Intelligent Ranking resource used for
 * provisioning the `Rescore` API. You can update the
 * number of capacity units you require for Amazon Kendra
 * Intelligent Ranking to rescore or re-rank a search service's
 * results.
 */
export declare const updateRescoreExecutionPlan: API.OperationMethod<UpdateRescoreExecutionPlanRequest, UpdateRescoreExecutionPlanResponse, UpdateRescoreExecutionPlanError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=kendra-ranking.d.ts.map