import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
export type RoleNameType = string;
export type AccountIdType = string;
export type AccessTokenType = string | redacted.Redacted<string>;
export interface GetRoleCredentialsRequest {
    roleName: string;
    accountId: string;
    accessToken: string | redacted.Redacted<string>;
}
export type AccessKeyType = string;
export type SecretAccessKeyType = string | redacted.Redacted<string>;
export type SessionTokenType = string | redacted.Redacted<string>;
export type ExpirationTimestampType = number;
export interface RoleCredentials {
    accessKeyId?: string;
    secretAccessKey?: string | redacted.Redacted<string>;
    sessionToken?: string | redacted.Redacted<string>;
    expiration?: number;
}
export interface GetRoleCredentialsResponse {
    roleCredentials?: RoleCredentials;
}
export type NextTokenType = string;
export type MaxResultType = number;
export interface ListAccountRolesRequest {
    nextToken?: string;
    maxResults?: number;
    accessToken: string | redacted.Redacted<string>;
    accountId: string;
}
export interface RoleInfo {
    roleName?: string;
    accountId?: string;
}
export type RoleListType = RoleInfo[];
export interface ListAccountRolesResponse {
    nextToken?: string;
    roleList?: RoleInfo[];
}
export interface ListAccountsRequest {
    nextToken?: string;
    maxResults?: number;
    accessToken: string | redacted.Redacted<string>;
}
export type AccountNameType = string;
export type EmailAddressType = string;
export interface AccountInfo {
    accountId?: string;
    accountName?: string;
    emailAddress?: string;
}
export type AccountListType = AccountInfo[];
export interface ListAccountsResponse {
    nextToken?: string;
    accountList?: AccountInfo[];
}
export interface LogoutRequest {
    accessToken: string | redacted.Redacted<string>;
}
export interface LogoutResponse {
}
export type ErrorDescription = string;
export type GetRoleCredentialsError = InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns the STS short-term credentials for a given role name that is assigned to the
 * user.
 */
export declare const getRoleCredentials: API.OperationMethod<GetRoleCredentialsRequest, GetRoleCredentialsResponse, GetRoleCredentialsError, Credentials | HttpClient.HttpClient>;
export type ListAccountRolesError = InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Lists all roles that are assigned to the user for a given AWS account.
 */
export declare const listAccountRoles: API.PaginatedOperationMethod<ListAccountRolesRequest, ListAccountRolesResponse, ListAccountRolesError, Credentials | HttpClient.HttpClient, RoleInfo>;
export type ListAccountsError = InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Lists all AWS accounts assigned to the user. These AWS accounts are assigned by the
 * administrator of the account. For more information, see Assign User Access in the *IAM Identity Center User Guide*. This operation
 * returns a paginated response.
 */
export declare const listAccounts: API.PaginatedOperationMethod<ListAccountsRequest, ListAccountsResponse, ListAccountsError, Credentials | HttpClient.HttpClient, AccountInfo>;
export type LogoutError = InvalidRequestException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Removes the locally stored SSO tokens from the client-side cache and sends an API call to
 * the IAM Identity Center service to invalidate the corresponding server-side IAM Identity Center sign in
 * session.
 *
 * If a user uses IAM Identity Center to access the AWS CLI, the user's IAM Identity Center sign in session is
 * used to obtain an IAM session, as specified in the corresponding IAM Identity Center permission set.
 * More specifically, IAM Identity Center assumes an IAM role in the target account on behalf of the user,
 * and the corresponding temporary AWS credentials are returned to the client.
 *
 * After user logout, any existing IAM role sessions that were created by using IAM Identity Center
 * permission sets continue based on the duration configured in the permission set.
 * For more information, see User
 * authentications in the IAM Identity Center User
 * Guide.
 */
export declare const logout: API.OperationMethod<LogoutRequest, LogoutResponse, LogoutError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=sso.d.ts.map