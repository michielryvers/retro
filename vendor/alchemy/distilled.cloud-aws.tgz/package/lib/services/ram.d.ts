import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const IdempotentParameterMismatchException_base: S.TaggedErrorClass<"IdempotentParameterMismatchException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IdempotentParameterMismatchException extends /*@__PURE__*/ IdempotentParameterMismatchException_base {
}
declare const InvalidClientTokenException_base: S.TaggedErrorClass<"InvalidClientTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidClientTokenException extends /*@__PURE__*/ InvalidClientTokenException_base {
}
declare const InvalidMaxResultsException_base: S.TaggedErrorClass<"InvalidMaxResultsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidMaxResultsException extends /*@__PURE__*/ InvalidMaxResultsException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidPolicyException_base: S.TaggedErrorClass<"InvalidPolicyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidPolicyException extends /*@__PURE__*/ InvalidPolicyException_base {
}
declare const InvalidResourceTypeException_base: S.TaggedErrorClass<"InvalidResourceTypeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidResourceTypeException extends /*@__PURE__*/ InvalidResourceTypeException_base {
}
declare const InvalidStateTransitionException_base: S.TaggedErrorClass<"InvalidStateTransitionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidStateTransitionException extends /*@__PURE__*/ InvalidStateTransitionException_base {
}
declare const MalformedArnException_base: S.TaggedErrorClass<"MalformedArnException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MalformedArnException extends /*@__PURE__*/ MalformedArnException_base {
}
declare const MalformedPolicyTemplateException_base: S.TaggedErrorClass<"MalformedPolicyTemplateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MalformedPolicyTemplateException extends /*@__PURE__*/ MalformedPolicyTemplateException_base {
}
declare const MissingRequiredParameterException_base: S.TaggedErrorClass<"MissingRequiredParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MissingRequiredParameterException extends /*@__PURE__*/ MissingRequiredParameterException_base {
}
declare const OperationNotPermittedException_base: S.TaggedErrorClass<"OperationNotPermittedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OperationNotPermittedException extends /*@__PURE__*/ OperationNotPermittedException_base {
}
declare const PermissionAlreadyExistsException_base: S.TaggedErrorClass<"PermissionAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class PermissionAlreadyExistsException extends /*@__PURE__*/ PermissionAlreadyExistsException_base {
}
declare const PermissionLimitExceededException_base: S.TaggedErrorClass<"PermissionLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PermissionLimitExceededException extends /*@__PURE__*/ PermissionLimitExceededException_base {
}
declare const PermissionVersionsLimitExceededException_base: S.TaggedErrorClass<"PermissionVersionsLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PermissionVersionsLimitExceededException extends /*@__PURE__*/ PermissionVersionsLimitExceededException_base {
}
declare const ResourceArnNotFoundException_base: S.TaggedErrorClass<"ResourceArnNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceArnNotFoundException extends /*@__PURE__*/ ResourceArnNotFoundException_base {
}
declare const ResourceShareInvitationAlreadyAcceptedException_base: S.TaggedErrorClass<"ResourceShareInvitationAlreadyAcceptedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceShareInvitationAlreadyAcceptedException extends /*@__PURE__*/ ResourceShareInvitationAlreadyAcceptedException_base {
}
declare const ResourceShareInvitationAlreadyRejectedException_base: S.TaggedErrorClass<"ResourceShareInvitationAlreadyRejectedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceShareInvitationAlreadyRejectedException extends /*@__PURE__*/ ResourceShareInvitationAlreadyRejectedException_base {
}
declare const ResourceShareInvitationArnNotFoundException_base: S.TaggedErrorClass<"ResourceShareInvitationArnNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceShareInvitationArnNotFoundException extends /*@__PURE__*/ ResourceShareInvitationArnNotFoundException_base {
}
declare const ResourceShareInvitationExpiredException_base: S.TaggedErrorClass<"ResourceShareInvitationExpiredException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceShareInvitationExpiredException extends /*@__PURE__*/ ResourceShareInvitationExpiredException_base {
}
declare const ResourceShareLimitExceededException_base: S.TaggedErrorClass<"ResourceShareLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceShareLimitExceededException extends /*@__PURE__*/ ResourceShareLimitExceededException_base {
}
declare const ServerInternalException_base: S.TaggedErrorClass<"ServerInternalException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServerInternalException extends /*@__PURE__*/ ServerInternalException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TagLimitExceededException_base: S.TaggedErrorClass<"TagLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagLimitExceededException extends /*@__PURE__*/ TagLimitExceededException_base {
}
declare const TagPolicyViolationException_base: S.TaggedErrorClass<"TagPolicyViolationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagPolicyViolationException extends /*@__PURE__*/ TagPolicyViolationException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnknownResourceException_base: S.TaggedErrorClass<"UnknownResourceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnknownResourceException extends /*@__PURE__*/ UnknownResourceException_base {
}
declare const UnmatchedPolicyPermissionException_base: S.TaggedErrorClass<"UnmatchedPolicyPermissionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnmatchedPolicyPermissionException extends /*@__PURE__*/ UnmatchedPolicyPermissionException_base {
}
export interface AcceptResourceShareInvitationRequest {
    resourceShareInvitationArn: string;
    clientToken?: string;
}
export type ResourceShareInvitationStatus = "PENDING" | "ACCEPTED" | "REJECTED" | "EXPIRED" | (string & {});
export type ResourceShareAssociationType = "PRINCIPAL" | "RESOURCE" | "SOURCE" | (string & {});
export type ResourceShareAssociationStatus = "ASSOCIATING" | "ASSOCIATED" | "FAILED" | "DISASSOCIATING" | "DISASSOCIATED" | "SUSPENDED" | "SUSPENDING" | "RESTORING" | (string & {});
export interface ResourceShareAssociation {
    resourceShareArn?: string;
    resourceShareName?: string;
    associatedEntity?: string;
    associationType?: ResourceShareAssociationType;
    status?: ResourceShareAssociationStatus;
    statusMessage?: string;
    creationTime?: Date;
    lastUpdatedTime?: Date;
    external?: boolean;
}
export type ResourceShareAssociationList = ResourceShareAssociation[];
export interface ResourceShareInvitation {
    resourceShareInvitationArn?: string;
    resourceShareName?: string;
    resourceShareArn?: string;
    senderAccountId?: string;
    receiverAccountId?: string;
    invitationTimestamp?: Date;
    status?: ResourceShareInvitationStatus;
    resourceShareAssociations?: ResourceShareAssociation[];
    receiverArn?: string;
}
export interface AcceptResourceShareInvitationResponse {
    resourceShareInvitation?: ResourceShareInvitation;
    clientToken?: string;
}
export type ResourceArnList = string[];
export type PrincipalArnOrIdList = string[];
export type SourceArnOrAccountList = string[];
export interface AssociateResourceShareRequest {
    resourceShareArn: string;
    resourceArns?: string[];
    principals?: string[];
    clientToken?: string;
    sources?: string[];
}
export interface AssociateResourceShareResponse {
    resourceShareAssociations?: ResourceShareAssociation[];
    clientToken?: string;
}
export interface AssociateResourceSharePermissionRequest {
    resourceShareArn: string;
    permissionArn: string;
    replace?: boolean;
    clientToken?: string;
    permissionVersion?: number;
}
export interface AssociateResourceSharePermissionResponse {
    returnValue?: boolean;
    clientToken?: string;
}
export type PermissionName = string;
export type Policy = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key?: string;
    value?: string;
}
export type TagList = Tag[];
export interface CreatePermissionRequest {
    name: string;
    resourceType: string;
    policyTemplate: string;
    clientToken?: string;
    tags?: Tag[];
}
export type PermissionType = "CUSTOMER_MANAGED" | "AWS_MANAGED" | (string & {});
export type PermissionFeatureSet = "CREATED_FROM_POLICY" | "PROMOTING_TO_STANDARD" | "STANDARD" | (string & {});
export interface ResourceSharePermissionSummary {
    arn?: string;
    version?: string;
    defaultVersion?: boolean;
    name?: string;
    resourceType?: string;
    status?: string;
    creationTime?: Date;
    lastUpdatedTime?: Date;
    isResourceTypeDefault?: boolean;
    permissionType?: PermissionType;
    featureSet?: PermissionFeatureSet;
    tags?: Tag[];
}
export interface CreatePermissionResponse {
    permission?: ResourceSharePermissionSummary;
    clientToken?: string;
}
export interface CreatePermissionVersionRequest {
    permissionArn: string;
    policyTemplate: string;
    clientToken?: string;
}
export type PermissionStatus = "ATTACHABLE" | "UNATTACHABLE" | "DELETING" | "DELETED" | (string & {});
export interface ResourceSharePermissionDetail {
    arn?: string;
    version?: string;
    defaultVersion?: boolean;
    name?: string;
    resourceType?: string;
    permission?: string;
    creationTime?: Date;
    lastUpdatedTime?: Date;
    isResourceTypeDefault?: boolean;
    permissionType?: PermissionType;
    featureSet?: PermissionFeatureSet;
    status?: PermissionStatus;
    tags?: Tag[];
}
export interface CreatePermissionVersionResponse {
    permission?: ResourceSharePermissionDetail;
    clientToken?: string;
}
export type PermissionArnList = string[];
export interface ResourceShareConfiguration {
    retainSharingOnAccountLeaveOrganization?: boolean;
}
export interface CreateResourceShareRequest {
    name: string;
    resourceArns?: string[];
    principals?: string[];
    tags?: Tag[];
    allowExternalPrincipals?: boolean;
    clientToken?: string;
    permissionArns?: string[];
    sources?: string[];
    resourceShareConfiguration?: ResourceShareConfiguration;
}
export type ResourceShareStatus = "PENDING" | "ACTIVE" | "FAILED" | "DELETING" | "DELETED" | (string & {});
export type ResourceShareFeatureSet = "CREATED_FROM_POLICY" | "PROMOTING_TO_STANDARD" | "STANDARD" | (string & {});
export interface ResourceShare {
    resourceShareArn?: string;
    name?: string;
    owningAccountId?: string;
    allowExternalPrincipals?: boolean;
    status?: ResourceShareStatus;
    statusMessage?: string;
    tags?: Tag[];
    creationTime?: Date;
    lastUpdatedTime?: Date;
    featureSet?: ResourceShareFeatureSet;
    resourceShareConfiguration?: ResourceShareConfiguration;
}
export interface CreateResourceShareResponse {
    resourceShare?: ResourceShare;
    clientToken?: string;
}
export interface DeletePermissionRequest {
    permissionArn: string;
    clientToken?: string;
}
export interface DeletePermissionResponse {
    returnValue?: boolean;
    clientToken?: string;
    permissionStatus?: PermissionStatus;
}
export interface DeletePermissionVersionRequest {
    permissionArn: string;
    permissionVersion: number;
    clientToken?: string;
}
export interface DeletePermissionVersionResponse {
    returnValue?: boolean;
    clientToken?: string;
    permissionStatus?: PermissionStatus;
}
export interface DeleteResourceShareRequest {
    resourceShareArn: string;
    clientToken?: string;
}
export interface DeleteResourceShareResponse {
    returnValue?: boolean;
    clientToken?: string;
}
export interface DisassociateResourceShareRequest {
    resourceShareArn: string;
    resourceArns?: string[];
    principals?: string[];
    clientToken?: string;
    sources?: string[];
}
export interface DisassociateResourceShareResponse {
    resourceShareAssociations?: ResourceShareAssociation[];
    clientToken?: string;
}
export interface DisassociateResourceSharePermissionRequest {
    resourceShareArn: string;
    permissionArn: string;
    clientToken?: string;
}
export interface DisassociateResourceSharePermissionResponse {
    returnValue?: boolean;
    clientToken?: string;
}
export interface EnableSharingWithAwsOrganizationRequest {
}
export interface EnableSharingWithAwsOrganizationResponse {
    returnValue?: boolean;
}
export interface GetPermissionRequest {
    permissionArn: string;
    permissionVersion?: number;
}
export interface GetPermissionResponse {
    permission?: ResourceSharePermissionDetail;
}
export type MaxResults = number;
export interface GetResourcePoliciesRequest {
    resourceArns: string[];
    principal?: string;
    nextToken?: string;
    maxResults?: number;
}
export type PolicyList = string[];
export interface GetResourcePoliciesResponse {
    policies?: string[];
    nextToken?: string;
}
export type ResourceShareArnList = string[];
export interface GetResourceShareAssociationsRequest {
    associationType: ResourceShareAssociationType;
    resourceShareArns?: string[];
    resourceArn?: string;
    principal?: string;
    associationStatus?: ResourceShareAssociationStatus;
    nextToken?: string;
    maxResults?: number;
}
export interface GetResourceShareAssociationsResponse {
    resourceShareAssociations?: ResourceShareAssociation[];
    nextToken?: string;
}
export type ResourceShareInvitationArnList = string[];
export interface GetResourceShareInvitationsRequest {
    resourceShareInvitationArns?: string[];
    resourceShareArns?: string[];
    nextToken?: string;
    maxResults?: number;
}
export type ResourceShareInvitationList = ResourceShareInvitation[];
export interface GetResourceShareInvitationsResponse {
    resourceShareInvitations?: ResourceShareInvitation[];
    nextToken?: string;
}
export type ResourceOwner = "SELF" | "OTHER-ACCOUNTS" | (string & {});
export type TagValueList = string[];
export interface TagFilter {
    tagKey?: string;
    tagValues?: string[];
}
export type TagFilters = TagFilter[];
export interface GetResourceSharesRequest {
    resourceShareArns?: string[];
    resourceShareStatus?: ResourceShareStatus;
    resourceOwner: ResourceOwner;
    name?: string;
    tagFilters?: TagFilter[];
    nextToken?: string;
    maxResults?: number;
    permissionArn?: string;
    permissionVersion?: number;
}
export type ResourceShareList = ResourceShare[];
export interface GetResourceSharesResponse {
    resourceShares?: ResourceShare[];
    nextToken?: string;
}
export type ResourceRegionScopeFilter = "ALL" | "REGIONAL" | "GLOBAL" | (string & {});
export interface ListPendingInvitationResourcesRequest {
    resourceShareInvitationArn: string;
    nextToken?: string;
    maxResults?: number;
    resourceRegionScope?: ResourceRegionScopeFilter;
}
export type ResourceStatus = "AVAILABLE" | "ZONAL_RESOURCE_INACCESSIBLE" | "LIMIT_EXCEEDED" | "UNAVAILABLE" | "PENDING" | (string & {});
export type ResourceRegionScope = "REGIONAL" | "GLOBAL" | (string & {});
export interface Resource {
    arn?: string;
    type?: string;
    resourceShareArn?: string;
    resourceGroupArn?: string;
    status?: ResourceStatus;
    statusMessage?: string;
    creationTime?: Date;
    lastUpdatedTime?: Date;
    resourceRegionScope?: ResourceRegionScope;
}
export type ResourceList = Resource[];
export interface ListPendingInvitationResourcesResponse {
    resources?: Resource[];
    nextToken?: string;
}
export interface ListPermissionAssociationsRequest {
    permissionArn?: string;
    permissionVersion?: number;
    associationStatus?: ResourceShareAssociationStatus;
    resourceType?: string;
    featureSet?: PermissionFeatureSet;
    defaultVersion?: boolean;
    nextToken?: string;
    maxResults?: number;
}
export interface AssociatedPermission {
    arn?: string;
    permissionVersion?: string;
    defaultVersion?: boolean;
    resourceType?: string;
    status?: string;
    featureSet?: PermissionFeatureSet;
    lastUpdatedTime?: Date;
    resourceShareArn?: string;
}
export type AssociatedPermissionList = AssociatedPermission[];
export interface ListPermissionAssociationsResponse {
    permissions?: AssociatedPermission[];
    nextToken?: string;
}
export type PermissionTypeFilter = "ALL" | "AWS_MANAGED" | "CUSTOMER_MANAGED" | (string & {});
export interface ListPermissionsRequest {
    resourceType?: string;
    nextToken?: string;
    maxResults?: number;
    permissionType?: PermissionTypeFilter;
}
export type ResourceSharePermissionList = ResourceSharePermissionSummary[];
export interface ListPermissionsResponse {
    permissions?: ResourceSharePermissionSummary[];
    nextToken?: string;
}
export interface ListPermissionVersionsRequest {
    permissionArn: string;
    nextToken?: string;
    maxResults?: number;
}
export interface ListPermissionVersionsResponse {
    permissions?: ResourceSharePermissionSummary[];
    nextToken?: string;
}
export interface ListPrincipalsRequest {
    resourceOwner: ResourceOwner;
    resourceArn?: string;
    principals?: string[];
    resourceType?: string;
    resourceShareArns?: string[];
    nextToken?: string;
    maxResults?: number;
}
export interface Principal {
    id?: string;
    resourceShareArn?: string;
    creationTime?: Date;
    lastUpdatedTime?: Date;
    external?: boolean;
}
export type PrincipalList = Principal[];
export interface ListPrincipalsResponse {
    principals?: Principal[];
    nextToken?: string;
}
export type ReplacePermissionAssociationsWorkIdList = string[];
export type ReplacePermissionAssociationsWorkStatus = "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export interface ListReplacePermissionAssociationsWorkRequest {
    workIds?: string[];
    status?: ReplacePermissionAssociationsWorkStatus;
    nextToken?: string;
    maxResults?: number;
}
export interface ReplacePermissionAssociationsWork {
    id?: string;
    fromPermissionArn?: string;
    fromPermissionVersion?: string;
    toPermissionArn?: string;
    toPermissionVersion?: string;
    status?: ReplacePermissionAssociationsWorkStatus;
    statusMessage?: string;
    creationTime?: Date;
    lastUpdatedTime?: Date;
}
export type ReplacePermissionAssociationsWorkList = ReplacePermissionAssociationsWork[];
export interface ListReplacePermissionAssociationsWorkResponse {
    replacePermissionAssociationsWorks?: ReplacePermissionAssociationsWork[];
    nextToken?: string;
}
export interface ListResourcesRequest {
    resourceOwner: ResourceOwner;
    principal?: string;
    resourceType?: string;
    resourceArns?: string[];
    resourceShareArns?: string[];
    nextToken?: string;
    maxResults?: number;
    resourceRegionScope?: ResourceRegionScopeFilter;
}
export interface ListResourcesResponse {
    resources?: Resource[];
    nextToken?: string;
}
export interface ListResourceSharePermissionsRequest {
    resourceShareArn: string;
    nextToken?: string;
    maxResults?: number;
}
export interface ListResourceSharePermissionsResponse {
    permissions?: ResourceSharePermissionSummary[];
    nextToken?: string;
}
export interface ListResourceTypesRequest {
    nextToken?: string;
    maxResults?: number;
    resourceRegionScope?: ResourceRegionScopeFilter;
}
export interface ServiceNameAndResourceType {
    resourceType?: string;
    serviceName?: string;
    resourceRegionScope?: ResourceRegionScope;
}
export type ServiceNameAndResourceTypeList = ServiceNameAndResourceType[];
export interface ListResourceTypesResponse {
    resourceTypes?: ServiceNameAndResourceType[];
    nextToken?: string;
}
export interface ListSourceAssociationsRequest {
    resourceShareArns?: string[];
    sourceId?: string;
    sourceType?: string;
    associationStatus?: ResourceShareAssociationStatus;
    nextToken?: string;
    maxResults?: number;
}
export interface AssociatedSource {
    resourceShareArn?: string;
    sourceId?: string;
    sourceType?: string;
    status?: string;
    lastUpdatedTime?: Date;
    creationTime?: Date;
    statusMessage?: string;
}
export type AssociatedSourceList = AssociatedSource[];
export interface ListSourceAssociationsResponse {
    sourceAssociations?: AssociatedSource[];
    nextToken?: string;
}
export interface PromotePermissionCreatedFromPolicyRequest {
    permissionArn: string;
    name: string;
    clientToken?: string;
}
export interface PromotePermissionCreatedFromPolicyResponse {
    permission?: ResourceSharePermissionSummary;
    clientToken?: string;
}
export interface PromoteResourceShareCreatedFromPolicyRequest {
    resourceShareArn: string;
}
export interface PromoteResourceShareCreatedFromPolicyResponse {
    returnValue?: boolean;
}
export interface RejectResourceShareInvitationRequest {
    resourceShareInvitationArn: string;
    clientToken?: string;
}
export interface RejectResourceShareInvitationResponse {
    resourceShareInvitation?: ResourceShareInvitation;
    clientToken?: string;
}
export interface ReplacePermissionAssociationsRequest {
    fromPermissionArn: string;
    fromPermissionVersion?: number;
    toPermissionArn: string;
    clientToken?: string;
}
export interface ReplacePermissionAssociationsResponse {
    replacePermissionAssociationsWork?: ReplacePermissionAssociationsWork;
    clientToken?: string;
}
export interface SetDefaultPermissionVersionRequest {
    permissionArn: string;
    permissionVersion: number;
    clientToken?: string;
}
export interface SetDefaultPermissionVersionResponse {
    returnValue?: boolean;
    clientToken?: string;
}
export interface TagResourceRequest {
    resourceShareArn?: string;
    tags: Tag[];
    resourceArn?: string;
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceShareArn?: string;
    tagKeys: string[];
    resourceArn?: string;
}
export interface UntagResourceResponse {
}
export interface UpdateResourceShareRequest {
    resourceShareArn: string;
    name?: string;
    allowExternalPrincipals?: boolean;
    clientToken?: string;
}
export interface UpdateResourceShareResponse {
    resourceShare?: ResourceShare;
    clientToken?: string;
}
export type AcceptResourceShareInvitationError = IdempotentParameterMismatchException | InvalidClientTokenException | MalformedArnException | OperationNotPermittedException | ResourceShareInvitationAlreadyAcceptedException | ResourceShareInvitationAlreadyRejectedException | ResourceShareInvitationArnNotFoundException | ResourceShareInvitationExpiredException | ServerInternalException | ServiceUnavailableException | CommonErrors;
/**
 * Accepts an invitation to a resource share from another Amazon Web Services account. After you accept the
 * invitation, the resources included in the resource share are available to interact with in the
 * relevant Amazon Web Services Management Consoles and tools.
 */
export declare const acceptResourceShareInvitation: API.OperationMethod<AcceptResourceShareInvitationRequest, AcceptResourceShareInvitationResponse, AcceptResourceShareInvitationError, Credentials | HttpClient.HttpClient>;
export type AssociateResourceShareError = IdempotentParameterMismatchException | InvalidClientTokenException | InvalidParameterException | InvalidStateTransitionException | MalformedArnException | OperationNotPermittedException | ResourceShareLimitExceededException | ServerInternalException | ServiceUnavailableException | ThrottlingException | UnknownResourceException | CommonErrors;
/**
 * Adds the specified list of principals, resources, and source constraints to a resource share. Principals that
 * already have access to this resource share immediately receive access to the added resources.
 * Newly added principals immediately receive access to the resources shared in this resource share.
 */
export declare const associateResourceShare: API.OperationMethod<AssociateResourceShareRequest, AssociateResourceShareResponse, AssociateResourceShareError, Credentials | HttpClient.HttpClient>;
export type AssociateResourceSharePermissionError = InvalidClientTokenException | InvalidParameterException | MalformedArnException | OperationNotPermittedException | ServerInternalException | ServiceUnavailableException | UnknownResourceException | CommonErrors;
/**
 * Adds or replaces the RAM permission for a resource type included in a resource share. You can
 * have exactly one permission associated with each resource type in the resource share. You can add
 * a new RAM permission only if there are currently no resources of that resource type
 * currently in the resource share.
 */
export declare const associateResourceSharePermission: API.OperationMethod<AssociateResourceSharePermissionRequest, AssociateResourceSharePermissionResponse, AssociateResourceSharePermissionError, Credentials | HttpClient.HttpClient>;
export type CreatePermissionError = IdempotentParameterMismatchException | InvalidClientTokenException | InvalidParameterException | InvalidPolicyException | MalformedPolicyTemplateException | OperationNotPermittedException | PermissionAlreadyExistsException | PermissionLimitExceededException | ServerInternalException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a customer managed permission for a specified resource type that you can attach to resource shares.
 * It is created in the Amazon Web Services Region in which you call the operation.
 */
export declare const createPermission: API.OperationMethod<CreatePermissionRequest, CreatePermissionResponse, CreatePermissionError, Credentials | HttpClient.HttpClient>;
export type CreatePermissionVersionError = IdempotentParameterMismatchException | InvalidClientTokenException | InvalidParameterException | InvalidPolicyException | MalformedArnException | MalformedPolicyTemplateException | PermissionVersionsLimitExceededException | ServerInternalException | ServiceUnavailableException | UnknownResourceException | CommonErrors;
/**
 * Creates a new version of the specified customer managed permission. The new version is automatically set as
 * the default version of the customer managed permission. New resource shares automatically use the default
 * permission. Existing resource shares continue to use their original permission versions,
 * but you can use ReplacePermissionAssociations to update them.
 *
 * If the specified customer managed permission already has the maximum of 5 versions, then
 * you must delete one of the existing versions before you can create a new one.
 */
export declare const createPermissionVersion: API.OperationMethod<CreatePermissionVersionRequest, CreatePermissionVersionResponse, CreatePermissionVersionError, Credentials | HttpClient.HttpClient>;
export type CreateResourceShareError = IdempotentParameterMismatchException | InvalidClientTokenException | InvalidParameterException | InvalidStateTransitionException | MalformedArnException | OperationNotPermittedException | ResourceShareLimitExceededException | ServerInternalException | ServiceUnavailableException | TagLimitExceededException | TagPolicyViolationException | ThrottlingException | UnknownResourceException | CommonErrors;
/**
 * Creates a resource share. You can provide a list of the Amazon Resource Names (ARNs) for the resources that you
 * want to share, a list of principals you want to share the resources with, the
 * permissions to grant those principals, and optionally source constraints to enhance security for service principal sharing.
 *
 * Sharing a resource makes it available for use by principals outside of the
 * Amazon Web Services account that created the resource. Sharing doesn't change any permissions or
 * quotas that apply to the resource in the account that created it.
 */
export declare const createResourceShare: API.OperationMethod<CreateResourceShareRequest, CreateResourceShareResponse, CreateResourceShareError, Credentials | HttpClient.HttpClient>;
export type DeletePermissionError = IdempotentParameterMismatchException | InvalidClientTokenException | MalformedArnException | OperationNotPermittedException | ServerInternalException | ServiceUnavailableException | UnknownResourceException | CommonErrors;
/**
 * Deletes the specified customer managed permission in the Amazon Web Services Region in which you call this operation. You
 * can delete a customer managed permission only if it isn't attached to any resource share. The operation deletes all
 * versions associated with the customer managed permission.
 */
export declare const deletePermission: API.OperationMethod<DeletePermissionRequest, DeletePermissionResponse, DeletePermissionError, Credentials | HttpClient.HttpClient>;
export type DeletePermissionVersionError = IdempotentParameterMismatchException | InvalidClientTokenException | InvalidParameterException | MalformedArnException | OperationNotPermittedException | ServerInternalException | ServiceUnavailableException | UnknownResourceException | CommonErrors;
/**
 * Deletes one version of a customer managed permission. The version you specify must not be attached to any
 * resource share and must not be the default version for the permission.
 *
 * If a customer managed permission has the maximum of 5 versions, then you must delete at
 * least one version before you can create another.
 */
export declare const deletePermissionVersion: API.OperationMethod<DeletePermissionVersionRequest, DeletePermissionVersionResponse, DeletePermissionVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceShareError = IdempotentParameterMismatchException | InvalidClientTokenException | InvalidParameterException | InvalidStateTransitionException | MalformedArnException | OperationNotPermittedException | ServerInternalException | ServiceUnavailableException | ThrottlingException | UnknownResourceException | CommonErrors;
/**
 * Deletes the specified resource share.
 *
 * This doesn't delete any of the resources that were associated with the resource share; it
 * only stops the sharing of those resources through this resource share.
 */
export declare const deleteResourceShare: API.OperationMethod<DeleteResourceShareRequest, DeleteResourceShareResponse, DeleteResourceShareError, Credentials | HttpClient.HttpClient>;
export type DisassociateResourceShareError = IdempotentParameterMismatchException | InvalidClientTokenException | InvalidParameterException | InvalidStateTransitionException | MalformedArnException | OperationNotPermittedException | ResourceShareLimitExceededException | ServerInternalException | ServiceUnavailableException | ThrottlingException | UnknownResourceException | CommonErrors;
/**
 * Removes the specified principals, resources, or source constraints from participating in the specified
 * resource share.
 */
export declare const disassociateResourceShare: API.OperationMethod<DisassociateResourceShareRequest, DisassociateResourceShareResponse, DisassociateResourceShareError, Credentials | HttpClient.HttpClient>;
export type DisassociateResourceSharePermissionError = InvalidClientTokenException | InvalidParameterException | InvalidStateTransitionException | MalformedArnException | OperationNotPermittedException | ServerInternalException | ServiceUnavailableException | UnknownResourceException | CommonErrors;
/**
 * Removes a managed permission from a resource share. Permission changes take effect immediately. You can
 * remove a managed permission from a resource share only if there are currently no resources of the relevant
 * resource type currently attached to the resource share.
 */
export declare const disassociateResourceSharePermission: API.OperationMethod<DisassociateResourceSharePermissionRequest, DisassociateResourceSharePermissionResponse, DisassociateResourceSharePermissionError, Credentials | HttpClient.HttpClient>;
export type EnableSharingWithAwsOrganizationError = OperationNotPermittedException | ServerInternalException | ServiceUnavailableException | CommonErrors;
/**
 * Enables resource sharing within your organization in Organizations. This operation creates
 * a service-linked role called `AWSServiceRoleForResourceAccessManager` that has the IAM managed policy
 * named AWSResourceAccessManagerServiceRolePolicy attached. This role permits RAM to retrieve information about
 * the organization and its structure. This lets you share resources with all of the
 * accounts in the calling account's organization by specifying the organization ID, or all
 * of the accounts in an organizational unit (OU) by specifying the OU ID. Until you enable
 * sharing within the organization, you can specify only individual Amazon Web Services accounts, or for
 * supported resource types, IAM roles and users.
 *
 * You must call this operation from an IAM role or user in the organization's
 * management account.
 */
export declare const enableSharingWithAwsOrganization: API.OperationMethod<EnableSharingWithAwsOrganizationRequest, EnableSharingWithAwsOrganizationResponse, EnableSharingWithAwsOrganizationError, Credentials | HttpClient.HttpClient>;
export type GetPermissionError = InvalidParameterException | MalformedArnException | OperationNotPermittedException | ServerInternalException | ServiceUnavailableException | UnknownResourceException | CommonErrors;
/**
 * Retrieves the contents of a managed permission in JSON format.
 */
export declare const getPermission: API.OperationMethod<GetPermissionRequest, GetPermissionResponse, GetPermissionError, Credentials | HttpClient.HttpClient>;
export type GetResourcePoliciesError = InvalidNextTokenException | InvalidParameterException | MalformedArnException | ResourceArnNotFoundException | ServerInternalException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves the resource policies for the specified resources that you own and have
 * shared.
 *
 * Always check the `NextToken` response parameter for a `null` value
 * when calling a paginated operation. These operations can occasionally return an empty set of results even when there are more
 * results available. The `NextToken` response parameter value is `null`
 * *only*
 * when there are no more results to display.
 */
export declare const getResourcePolicies: API.PaginatedOperationMethod<GetResourcePoliciesRequest, GetResourcePoliciesResponse, GetResourcePoliciesError, Credentials | HttpClient.HttpClient, unknown>;
export type GetResourceShareAssociationsError = InvalidNextTokenException | InvalidParameterException | MalformedArnException | OperationNotPermittedException | ServerInternalException | ServiceUnavailableException | UnknownResourceException | CommonErrors;
/**
 * Retrieves the lists of resources and principals that associated for resource shares that you
 * own.
 *
 * Always check the `NextToken` response parameter for a `null` value
 * when calling a paginated operation. These operations can occasionally return an empty set of results even when there are more
 * results available. The `NextToken` response parameter value is `null`
 * *only*
 * when there are no more results to display.
 */
export declare const getResourceShareAssociations: API.PaginatedOperationMethod<GetResourceShareAssociationsRequest, GetResourceShareAssociationsResponse, GetResourceShareAssociationsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetResourceShareInvitationsError = InvalidMaxResultsException | InvalidNextTokenException | InvalidParameterException | MalformedArnException | ResourceShareInvitationArnNotFoundException | ServerInternalException | ServiceUnavailableException | UnknownResourceException | CommonErrors;
/**
 * Retrieves details about invitations that you have received for resource shares.
 *
 * Always check the `NextToken` response parameter for a `null` value
 * when calling a paginated operation. These operations can occasionally return an empty set of results even when there are more
 * results available. The `NextToken` response parameter value is `null`
 * *only*
 * when there are no more results to display.
 */
export declare const getResourceShareInvitations: API.PaginatedOperationMethod<GetResourceShareInvitationsRequest, GetResourceShareInvitationsResponse, GetResourceShareInvitationsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetResourceSharesError = InvalidNextTokenException | InvalidParameterException | MalformedArnException | ServerInternalException | ServiceUnavailableException | UnknownResourceException | CommonErrors;
/**
 * Retrieves details about the resource shares that you own or that are shared with you.
 *
 * Always check the `NextToken` response parameter for a `null` value
 * when calling a paginated operation. These operations can occasionally return an empty set of results even when there are more
 * results available. The `NextToken` response parameter value is `null`
 * *only*
 * when there are no more results to display.
 */
export declare const getResourceShares: API.PaginatedOperationMethod<GetResourceSharesRequest, GetResourceSharesResponse, GetResourceSharesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPendingInvitationResourcesError = InvalidNextTokenException | InvalidParameterException | MalformedArnException | MissingRequiredParameterException | ResourceShareInvitationAlreadyRejectedException | ResourceShareInvitationArnNotFoundException | ResourceShareInvitationExpiredException | ServerInternalException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the resources in a resource share that is shared with you but for which the invitation is
 * still `PENDING`. That means that you haven't accepted or rejected the
 * invitation and the invitation hasn't expired.
 *
 * Always check the `NextToken` response parameter for a `null` value
 * when calling a paginated operation. These operations can occasionally return an empty set of results even when there are more
 * results available. The `NextToken` response parameter value is `null`
 * *only*
 * when there are no more results to display.
 */
export declare const listPendingInvitationResources: API.PaginatedOperationMethod<ListPendingInvitationResourcesRequest, ListPendingInvitationResourcesResponse, ListPendingInvitationResourcesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPermissionAssociationsError = InvalidNextTokenException | InvalidParameterException | MalformedArnException | ServerInternalException | ServiceUnavailableException | CommonErrors;
/**
 * Lists information about the managed permission and its associations to any resource shares that use
 * this managed permission. This lets you see which resource shares use which versions of the specified
 * managed permission.
 *
 * Always check the `NextToken` response parameter for a `null` value
 * when calling a paginated operation. These operations can occasionally return an empty set of results even when there are more
 * results available. The `NextToken` response parameter value is `null`
 * *only*
 * when there are no more results to display.
 */
export declare const listPermissionAssociations: API.PaginatedOperationMethod<ListPermissionAssociationsRequest, ListPermissionAssociationsResponse, ListPermissionAssociationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPermissionsError = InvalidNextTokenException | InvalidParameterException | OperationNotPermittedException | ServerInternalException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves a list of available RAM permissions that you can use for the supported
 * resource types.
 *
 * Always check the `NextToken` response parameter for a `null` value
 * when calling a paginated operation. These operations can occasionally return an empty set of results even when there are more
 * results available. The `NextToken` response parameter value is `null`
 * *only*
 * when there are no more results to display.
 */
export declare const listPermissions: API.PaginatedOperationMethod<ListPermissionsRequest, ListPermissionsResponse, ListPermissionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPermissionVersionsError = InvalidNextTokenException | InvalidParameterException | MalformedArnException | OperationNotPermittedException | ServerInternalException | ServiceUnavailableException | UnknownResourceException | CommonErrors;
/**
 * Lists the available versions of the specified RAM permission.
 *
 * Always check the `NextToken` response parameter for a `null` value
 * when calling a paginated operation. These operations can occasionally return an empty set of results even when there are more
 * results available. The `NextToken` response parameter value is `null`
 * *only*
 * when there are no more results to display.
 */
export declare const listPermissionVersions: API.PaginatedOperationMethod<ListPermissionVersionsRequest, ListPermissionVersionsResponse, ListPermissionVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPrincipalsError = InvalidNextTokenException | InvalidParameterException | MalformedArnException | ServerInternalException | ServiceUnavailableException | UnknownResourceException | CommonErrors;
/**
 * Lists the principals that you are sharing resources with or that are sharing resources
 * with you.
 *
 * Always check the `NextToken` response parameter for a `null` value
 * when calling a paginated operation. These operations can occasionally return an empty set of results even when there are more
 * results available. The `NextToken` response parameter value is `null`
 * *only*
 * when there are no more results to display.
 */
export declare const listPrincipals: API.PaginatedOperationMethod<ListPrincipalsRequest, ListPrincipalsResponse, ListPrincipalsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListReplacePermissionAssociationsWorkError = InvalidNextTokenException | InvalidParameterException | ServerInternalException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves the current status of the asynchronous tasks performed by RAM when you
 * perform the ReplacePermissionAssociationsWork operation.
 *
 * Always check the `NextToken` response parameter for a `null` value
 * when calling a paginated operation. These operations can occasionally return an empty set of results even when there are more
 * results available. The `NextToken` response parameter value is `null`
 * *only*
 * when there are no more results to display.
 */
export declare const listReplacePermissionAssociationsWork: API.PaginatedOperationMethod<ListReplacePermissionAssociationsWorkRequest, ListReplacePermissionAssociationsWorkResponse, ListReplacePermissionAssociationsWorkError, Credentials | HttpClient.HttpClient, unknown>;
export type ListResourcesError = InvalidNextTokenException | InvalidParameterException | InvalidResourceTypeException | MalformedArnException | ServerInternalException | ServiceUnavailableException | UnknownResourceException | CommonErrors;
/**
 * Lists the resources that you added to a resource share or the resources that are shared with
 * you.
 *
 * Always check the `NextToken` response parameter for a `null` value
 * when calling a paginated operation. These operations can occasionally return an empty set of results even when there are more
 * results available. The `NextToken` response parameter value is `null`
 * *only*
 * when there are no more results to display.
 */
export declare const listResources: API.PaginatedOperationMethod<ListResourcesRequest, ListResourcesResponse, ListResourcesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListResourceSharePermissionsError = InvalidNextTokenException | InvalidParameterException | MalformedArnException | OperationNotPermittedException | ServerInternalException | ServiceUnavailableException | UnknownResourceException | CommonErrors;
/**
 * Lists the RAM permissions that are associated with a resource share.
 *
 * Always check the `NextToken` response parameter for a `null` value
 * when calling a paginated operation. These operations can occasionally return an empty set of results even when there are more
 * results available. The `NextToken` response parameter value is `null`
 * *only*
 * when there are no more results to display.
 */
export declare const listResourceSharePermissions: API.PaginatedOperationMethod<ListResourceSharePermissionsRequest, ListResourceSharePermissionsResponse, ListResourceSharePermissionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListResourceTypesError = InvalidNextTokenException | InvalidParameterException | ServerInternalException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the resource types that can be shared by RAM.
 */
export declare const listResourceTypes: API.PaginatedOperationMethod<ListResourceTypesRequest, ListResourceTypesResponse, ListResourceTypesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSourceAssociationsError = InvalidNextTokenException | InvalidParameterException | MalformedArnException | ServerInternalException | ServiceUnavailableException | UnknownResourceException | CommonErrors;
/**
 * Lists source associations for resource shares. Source associations control which sources can be used with service principals in resource shares. This operation provides visibility into source associations for resource share owners.
 *
 * You can filter the results by resource share Amazon Resource Name (ARN), source ID, source type, or association status. We recommend using pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listSourceAssociations: API.PaginatedOperationMethod<ListSourceAssociationsRequest, ListSourceAssociationsResponse, ListSourceAssociationsError, Credentials | HttpClient.HttpClient, AssociatedSource>;
export type PromotePermissionCreatedFromPolicyError = InvalidParameterException | InvalidPolicyException | MalformedArnException | MissingRequiredParameterException | OperationNotPermittedException | ServerInternalException | ServiceUnavailableException | UnknownResourceException | CommonErrors;
/**
 * When you attach a resource-based policy to a resource, RAM automatically creates
 * a resource share of `featureSet`=`CREATED_FROM_POLICY` with a managed permission that
 * has the same IAM permissions as the original resource-based policy. However, this type
 * of managed permission is visible to only the resource share owner, and the associated resource share can't be modified by
 * using RAM.
 *
 * This operation creates a separate, fully manageable customer managed permission that has the same IAM
 * permissions as the original resource-based policy. You can associate this customer managed permission to any
 * resource shares.
 *
 * Before you use PromoteResourceShareCreatedFromPolicy, you should
 * first run this operation to ensure that you have an appropriate customer managed permission that can be
 * associated with the promoted resource share.
 *
 * - The original `CREATED_FROM_POLICY` policy isn't deleted, and
 * resource shares using that original policy aren't automatically
 * updated.
 *
 * - You can't modify a `CREATED_FROM_POLICY` resource share so you can't
 * associate the new customer managed permission by using
 * `ReplacePermsissionAssociations`. However, if you use PromoteResourceShareCreatedFromPolicy, that operation
 * automatically associates the fully manageable customer managed permission to the newly promoted
 * `STANDARD` resource share.
 *
 * - After you promote a resource share, if the original `CREATED_FROM_POLICY`
 * managed permission has no other associations to A resource share, then RAM automatically deletes
 * it.
 */
export declare const promotePermissionCreatedFromPolicy: API.OperationMethod<PromotePermissionCreatedFromPolicyRequest, PromotePermissionCreatedFromPolicyResponse, PromotePermissionCreatedFromPolicyError, Credentials | HttpClient.HttpClient>;
export type PromoteResourceShareCreatedFromPolicyError = InvalidParameterException | InvalidStateTransitionException | MalformedArnException | MissingRequiredParameterException | OperationNotPermittedException | ResourceShareLimitExceededException | ServerInternalException | ServiceUnavailableException | UnknownResourceException | UnmatchedPolicyPermissionException | CommonErrors;
/**
 * When you attach a resource-based policy to a resource, RAM automatically creates
 * a resource share of `featureSet`=`CREATED_FROM_POLICY` with a managed permission that
 * has the same IAM permissions as the original resource-based policy. However, this type
 * of managed permission is visible to only the resource share owner, and the associated resource share can't be modified by
 * using RAM.
 *
 * This operation promotes the resource share to a `STANDARD` resource share that is fully
 * manageable in RAM. When you promote a resource share, you can then manage the resource share in RAM and
 * it becomes visible to all of the principals you shared it with.
 *
 * Before you perform this operation, you should first run PromotePermissionCreatedFromPolicyto ensure that you have an
 * appropriate customer managed permission that can be associated with this resource share after its is promoted. If
 * this operation can't find a managed permission that exactly matches the existing
 * `CREATED_FROM_POLICY` permission, then this operation fails.
 */
export declare const promoteResourceShareCreatedFromPolicy: API.OperationMethod<PromoteResourceShareCreatedFromPolicyRequest, PromoteResourceShareCreatedFromPolicyResponse, PromoteResourceShareCreatedFromPolicyError, Credentials | HttpClient.HttpClient>;
export type RejectResourceShareInvitationError = IdempotentParameterMismatchException | InvalidClientTokenException | MalformedArnException | OperationNotPermittedException | ResourceShareInvitationAlreadyAcceptedException | ResourceShareInvitationAlreadyRejectedException | ResourceShareInvitationArnNotFoundException | ResourceShareInvitationExpiredException | ServerInternalException | ServiceUnavailableException | CommonErrors;
/**
 * Rejects an invitation to a resource share from another Amazon Web Services account.
 */
export declare const rejectResourceShareInvitation: API.OperationMethod<RejectResourceShareInvitationRequest, RejectResourceShareInvitationResponse, RejectResourceShareInvitationError, Credentials | HttpClient.HttpClient>;
export type ReplacePermissionAssociationsError = IdempotentParameterMismatchException | InvalidClientTokenException | InvalidParameterException | MalformedArnException | OperationNotPermittedException | ServerInternalException | ServiceUnavailableException | UnknownResourceException | CommonErrors;
/**
 * Updates all resource shares that use a managed permission to a different managed
 * permission. This operation always applies the default version of the target managed
 * permission. You can optionally specify that the update applies to only resource shares that
 * currently use a specified version. This enables you to update to the latest version,
 * without changing the which managed permission is used.
 *
 * You can use this operation to update all of your resource shares to use the current
 * default version of the permission by specifying the same value for the
 * `fromPermissionArn` and `toPermissionArn` parameters.
 *
 * You can use the optional `fromPermissionVersion` parameter to update only
 * those resources that use a specified version of the managed permission to the new managed
 * permission.
 *
 * To successfully perform this operation, you must have permission to update the
 * resource-based policy on all affected resource types.
 */
export declare const replacePermissionAssociations: API.OperationMethod<ReplacePermissionAssociationsRequest, ReplacePermissionAssociationsResponse, ReplacePermissionAssociationsError, Credentials | HttpClient.HttpClient>;
export type SetDefaultPermissionVersionError = IdempotentParameterMismatchException | InvalidClientTokenException | InvalidParameterException | MalformedArnException | ServerInternalException | ServiceUnavailableException | UnknownResourceException | CommonErrors;
/**
 * Designates the specified version number as the default version for the specified
 * customer managed permission. New resource shares automatically use this new default permission. Existing
 * resource shares continue to use their original permission version, but you can use ReplacePermissionAssociations to update them.
 */
export declare const setDefaultPermissionVersion: API.OperationMethod<SetDefaultPermissionVersionRequest, SetDefaultPermissionVersionResponse, SetDefaultPermissionVersionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidParameterException | MalformedArnException | ResourceArnNotFoundException | ServerInternalException | ServiceUnavailableException | TagLimitExceededException | TagPolicyViolationException | UnknownResourceException | CommonErrors;
/**
 * Adds the specified tag keys and values to a resource share or managed permission. If you choose a resource share, the
 * tags are attached to only the resource share, not to the resources that are in the resource share.
 *
 * The tags on a managed permission are the same for all versions of the managed permission.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InvalidParameterException | MalformedArnException | ServerInternalException | ServiceUnavailableException | UnknownResourceException | CommonErrors;
/**
 * Removes the specified tag key and value pairs from the specified resource share or managed permission.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateResourceShareError = IdempotentParameterMismatchException | InvalidClientTokenException | InvalidParameterException | MalformedArnException | MissingRequiredParameterException | OperationNotPermittedException | ServerInternalException | ServiceUnavailableException | UnknownResourceException | CommonErrors;
/**
 * Modifies some of the properties of the specified resource share.
 */
export declare const updateResourceShare: API.OperationMethod<UpdateResourceShareRequest, UpdateResourceShareResponse, UpdateResourceShareError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ram.d.ts.map