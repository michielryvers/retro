import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AddFlowOutputs420Exception_base: S.TaggedErrorClass<"AddFlowOutputs420Exception", {
    readonly message: any;
}>;
export declare class AddFlowOutputs420Exception extends /*@__PURE__*/ AddFlowOutputs420Exception_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const CreateBridge420Exception_base: S.TaggedErrorClass<"CreateBridge420Exception", {
    readonly message: any;
}>;
export declare class CreateBridge420Exception extends /*@__PURE__*/ CreateBridge420Exception_base {
}
declare const CreateFlow420Exception_base: S.TaggedErrorClass<"CreateFlow420Exception", {
    readonly message: any;
}>;
export declare class CreateFlow420Exception extends /*@__PURE__*/ CreateFlow420Exception_base {
}
declare const CreateGateway420Exception_base: S.TaggedErrorClass<"CreateGateway420Exception", {
    readonly message: any;
}>;
export declare class CreateGateway420Exception extends /*@__PURE__*/ CreateGateway420Exception_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const GrantFlowEntitlements420Exception_base: S.TaggedErrorClass<"GrantFlowEntitlements420Exception", {
    readonly message: any;
}>;
export declare class GrantFlowEntitlements420Exception extends /*@__PURE__*/ GrantFlowEntitlements420Exception_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const RouterInputServiceQuotaExceededException_base: S.TaggedErrorClass<"RouterInputServiceQuotaExceededException", {
    readonly message: any;
}>;
export declare class RouterInputServiceQuotaExceededException extends /*@__PURE__*/ RouterInputServiceQuotaExceededException_base {
}
declare const RouterNetworkInterfaceServiceQuotaExceededException_base: S.TaggedErrorClass<"RouterNetworkInterfaceServiceQuotaExceededException", {
    readonly message: any;
}>;
export declare class RouterNetworkInterfaceServiceQuotaExceededException extends /*@__PURE__*/ RouterNetworkInterfaceServiceQuotaExceededException_base {
}
declare const RouterOutputServiceQuotaExceededException_base: S.TaggedErrorClass<"RouterOutputServiceQuotaExceededException", {
    readonly message: any;
}>;
export declare class RouterOutputServiceQuotaExceededException extends /*@__PURE__*/ RouterOutputServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type BridgeArn = string;
export type Protocol = "zixi-push" | "rtp-fec" | "rtp" | "zixi-pull" | "rist" | "st2110-jpegxs" | "cdi" | "srt-listener" | "srt-caller" | "fujitsu-qos" | "udp" | "ndi-speed-hq" | (string & {});
export interface AddBridgeNetworkOutputRequest {
    IpAddress?: string;
    Name?: string;
    NetworkName?: string;
    Port?: number;
    Protocol?: Protocol;
    Ttl?: number;
}
export interface AddBridgeOutputRequest {
    NetworkOutput?: AddBridgeNetworkOutputRequest;
}
export type __listOfAddBridgeOutputRequest = AddBridgeOutputRequest[];
export interface AddBridgeOutputsRequest {
    BridgeArn: string;
    Outputs?: AddBridgeOutputRequest[];
}
export interface BridgeFlowOutput {
    FlowArn?: string;
    FlowSourceArn?: string;
    Name?: string;
}
export interface BridgeNetworkOutput {
    IpAddress?: string;
    Name?: string;
    NetworkName?: string;
    Port?: number;
    Protocol?: Protocol;
    Ttl?: number;
}
export interface BridgeOutput {
    FlowOutput?: BridgeFlowOutput;
    NetworkOutput?: BridgeNetworkOutput;
}
export type __listOfBridgeOutput = BridgeOutput[];
export interface AddBridgeOutputsResponse {
    BridgeArn?: string;
    Outputs?: (BridgeOutput & {
        FlowOutput: BridgeFlowOutput & {
            FlowArn: string;
            FlowSourceArn: string;
            Name: string;
        };
        NetworkOutput: BridgeNetworkOutput & {
            IpAddress: string;
            Name: string;
            NetworkName: string;
            Port: number;
            Protocol: Protocol;
            Ttl: number;
        };
    })[];
}
export interface VpcInterfaceAttachment {
    VpcInterfaceName?: string;
}
export interface AddBridgeFlowSourceRequest {
    FlowArn?: string;
    FlowVpcInterfaceAttachment?: VpcInterfaceAttachment;
    Name?: string;
}
export interface MulticastSourceSettings {
    MulticastSourceIp?: string;
}
export interface AddBridgeNetworkSourceRequest {
    MulticastIp?: string;
    MulticastSourceSettings?: MulticastSourceSettings;
    Name?: string;
    NetworkName?: string;
    Port?: number;
    Protocol?: Protocol;
}
export interface AddBridgeSourceRequest {
    FlowSource?: AddBridgeFlowSourceRequest;
    NetworkSource?: AddBridgeNetworkSourceRequest;
}
export type __listOfAddBridgeSourceRequest = AddBridgeSourceRequest[];
export interface AddBridgeSourcesRequest {
    BridgeArn: string;
    Sources?: AddBridgeSourceRequest[];
}
export interface BridgeFlowSource {
    FlowArn?: string;
    FlowVpcInterfaceAttachment?: VpcInterfaceAttachment;
    Name?: string;
    OutputArn?: string;
}
export interface BridgeNetworkSource {
    MulticastIp?: string;
    MulticastSourceSettings?: MulticastSourceSettings;
    Name?: string;
    NetworkName?: string;
    Port?: number;
    Protocol?: Protocol;
}
export interface BridgeSource {
    FlowSource?: BridgeFlowSource;
    NetworkSource?: BridgeNetworkSource;
}
export type __listOfBridgeSource = BridgeSource[];
export interface AddBridgeSourcesResponse {
    BridgeArn?: string;
    Sources?: (BridgeSource & {
        FlowSource: BridgeFlowSource & {
            FlowArn: string;
            Name: string;
        };
        NetworkSource: BridgeNetworkSource & {
            MulticastIp: string;
            Name: string;
            NetworkName: string;
            Port: number;
            Protocol: Protocol;
        };
    })[];
}
export type FlowArn = string;
export type Colorimetry = "BT601" | "BT709" | "BT2020" | "BT2100" | "ST2065-1" | "ST2065-3" | "XYZ" | (string & {});
export type Range = "NARROW" | "FULL" | "FULLPROTECT" | (string & {});
export type ScanMode = "progressive" | "interlace" | "progressive-segmented-frame" | (string & {});
export type Tcs = "SDR" | "PQ" | "HLG" | "LINEAR" | "BT2100LINPQ" | "BT2100LINHLG" | "ST2065-1" | "ST428-1" | "DENSITY" | (string & {});
export interface FmtpRequest {
    ChannelOrder?: string;
    Colorimetry?: Colorimetry;
    ExactFramerate?: string;
    Par?: string;
    Range?: Range;
    ScanMode?: ScanMode;
    Tcs?: Tcs;
}
export interface MediaStreamAttributesRequest {
    Fmtp?: FmtpRequest;
    Lang?: string;
}
export type MediaStreamType = "video" | "audio" | "ancillary-data" | (string & {});
export type __mapOfString = {
    [key: string]: string | undefined;
};
export interface AddMediaStreamRequest {
    Attributes?: MediaStreamAttributesRequest;
    ClockRate?: number;
    Description?: string;
    MediaStreamId?: number;
    MediaStreamName?: string;
    MediaStreamType?: MediaStreamType;
    VideoFormat?: string;
    MediaStreamTags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfAddMediaStreamRequest = AddMediaStreamRequest[];
export interface AddFlowMediaStreamsRequest {
    FlowArn: string;
    MediaStreams?: AddMediaStreamRequest[];
}
export interface Fmtp {
    ChannelOrder?: string;
    Colorimetry?: Colorimetry;
    ExactFramerate?: string;
    Par?: string;
    Range?: Range;
    ScanMode?: ScanMode;
    Tcs?: Tcs;
}
export interface MediaStreamAttributes {
    Fmtp?: Fmtp;
    Lang?: string;
}
export interface MediaStream {
    Attributes?: MediaStreamAttributes;
    ClockRate?: number;
    Description?: string;
    Fmt?: number;
    MediaStreamId?: number;
    MediaStreamName?: string;
    MediaStreamType?: MediaStreamType;
    VideoFormat?: string;
}
export type __listOfMediaStream = MediaStream[];
export interface AddFlowMediaStreamsResponse {
    FlowArn?: string;
    MediaStreams?: (MediaStream & {
        Fmt: number;
        MediaStreamId: number;
        MediaStreamName: string;
        MediaStreamType: MediaStreamType;
        Attributes: MediaStreamAttributes & {
            Fmtp: Fmtp;
        };
    })[];
}
export type __listOfString = string[];
export type Algorithm = "aes128" | "aes192" | "aes256" | (string & {});
export type KeyType = "speke" | "static-key" | "srt-password" | (string & {});
export interface Encryption {
    Algorithm?: Algorithm;
    ConstantInitializationVector?: string;
    DeviceId?: string;
    KeyType?: KeyType;
    Region?: string;
    ResourceId?: string;
    RoleArn?: string;
    SecretArn?: string;
    Url?: string;
}
export interface InterfaceRequest {
    Name?: string;
}
export interface DestinationConfigurationRequest {
    DestinationIp?: string;
    DestinationPort?: number;
    Interface?: InterfaceRequest;
}
export type __listOfDestinationConfigurationRequest = DestinationConfigurationRequest[];
export type EncodingName = "jxsv" | "raw" | "smpte291" | "pcm" | (string & {});
export type EncoderProfile = "main" | "high" | (string & {});
export interface EncodingParametersRequest {
    CompressionFactor?: number;
    EncoderProfile?: EncoderProfile;
}
export interface MediaStreamOutputConfigurationRequest {
    DestinationConfigurations?: DestinationConfigurationRequest[];
    EncodingName?: EncodingName;
    EncodingParameters?: EncodingParametersRequest;
    MediaStreamName?: string;
}
export type __listOfMediaStreamOutputConfigurationRequest = MediaStreamOutputConfigurationRequest[];
export type OutputStatus = "ENABLED" | "DISABLED" | (string & {});
export type State = "ENABLED" | "DISABLED" | (string & {});
export type FlowTransitEncryptionKeyType = "SECRETS_MANAGER" | "AUTOMATIC" | (string & {});
export type SecretArn = string;
export type RoleArn = string;
export interface SecretsManagerEncryptionKeyConfiguration {
    SecretArn: string;
    RoleArn: string;
}
export interface AutomaticEncryptionKeyConfiguration {
}
export type FlowTransitEncryptionKeyConfiguration = {
    SecretsManager: SecretsManagerEncryptionKeyConfiguration;
    Automatic?: never;
} | {
    SecretsManager?: never;
    Automatic: AutomaticEncryptionKeyConfiguration;
};
export interface FlowTransitEncryption {
    EncryptionKeyType?: FlowTransitEncryptionKeyType;
    EncryptionKeyConfiguration: FlowTransitEncryptionKeyConfiguration;
}
export type NdiOutputTimecodeSource = "EMBEDDED_TIMECODE" | "UTC_SYSTEM_TIME" | (string & {});
export interface AddOutputRequest {
    CidrAllowList?: string[];
    Description?: string;
    Destination?: string;
    Encryption?: Encryption;
    MaxLatency?: number;
    MediaStreamOutputConfigurations?: MediaStreamOutputConfigurationRequest[];
    MinLatency?: number;
    Name?: string;
    Port?: number;
    Protocol?: Protocol;
    RemoteId?: string;
    SenderControlPort?: number;
    SmoothingLatency?: number;
    StreamId?: string;
    VpcInterfaceAttachment?: VpcInterfaceAttachment;
    OutputStatus?: OutputStatus;
    NdiSpeedHqQuality?: number;
    NdiProgramName?: string;
    OutputTags?: {
        [key: string]: string | undefined;
    };
    RouterIntegrationState?: State;
    RouterIntegrationTransitEncryption?: FlowTransitEncryption;
    NdiOutputTimecodeSource?: NdiOutputTimecodeSource;
}
export type __listOfAddOutputRequest = AddOutputRequest[];
export interface AddFlowOutputsRequest {
    FlowArn: string;
    Outputs?: AddOutputRequest[];
}
export interface Interface {
    Name?: string;
}
export interface DestinationConfiguration {
    DestinationIp?: string;
    DestinationPort?: number;
    Interface?: Interface;
    OutboundIp?: string;
}
export type __listOfDestinationConfiguration = DestinationConfiguration[];
export interface EncodingParameters {
    CompressionFactor?: number;
    EncoderProfile?: EncoderProfile;
}
export interface MediaStreamOutputConfiguration {
    DestinationConfigurations?: DestinationConfiguration[];
    EncodingName?: EncodingName;
    EncodingParameters?: EncodingParameters;
    MediaStreamName?: string;
}
export type __listOfMediaStreamOutputConfiguration = MediaStreamOutputConfiguration[];
export interface NdiSourceSettings {
    SourceName?: string;
}
export interface Transport {
    CidrAllowList?: string[];
    MaxBitrate?: number;
    MaxLatency?: number;
    MaxSyncBuffer?: number;
    MinLatency?: number;
    Protocol?: Protocol;
    RemoteId?: string;
    SenderControlPort?: number;
    SenderIpAddress?: string;
    SmoothingLatency?: number;
    SourceListenerAddress?: string;
    SourceListenerPort?: number;
    StreamId?: string;
    NdiSpeedHqQuality?: number;
    NdiProgramName?: string;
    NdiSourceSettings?: NdiSourceSettings;
    NdiOutputTimecodeSource?: NdiOutputTimecodeSource;
}
export type __listOfInteger = number[];
export interface Output {
    DataTransferSubscriberFeePercent?: number;
    Description?: string;
    Destination?: string;
    Encryption?: Encryption;
    EntitlementArn?: string;
    ListenerAddress?: string;
    MediaLiveInputArn?: string;
    MediaStreamOutputConfigurations?: MediaStreamOutputConfiguration[];
    Name?: string;
    OutputArn?: string;
    Port?: number;
    Transport?: Transport;
    VpcInterfaceAttachment?: VpcInterfaceAttachment;
    BridgeArn?: string;
    BridgePorts?: number[];
    OutputStatus?: OutputStatus;
    PeerIpAddress?: string;
    RouterIntegrationState?: State;
    RouterIntegrationTransitEncryption?: FlowTransitEncryption;
    ConnectedRouterInputArn?: string;
}
export type __listOfOutput = Output[];
export interface AddFlowOutputsResponse {
    FlowArn?: string;
    Outputs?: (Output & {
        Name: string;
        OutputArn: string;
        Encryption: Encryption & {
            RoleArn: string;
        };
        MediaStreamOutputConfigurations: (MediaStreamOutputConfiguration & {
            EncodingName: EncodingName;
            MediaStreamName: string;
            DestinationConfigurations: (DestinationConfiguration & {
                DestinationIp: string;
                DestinationPort: number;
                Interface: Interface & {
                    Name: string;
                };
                OutboundIp: string;
            })[];
            EncodingParameters: EncodingParameters & {
                CompressionFactor: number;
                EncoderProfile: EncoderProfile;
            };
        })[];
        Transport: Transport & {
            Protocol: Protocol;
        };
    })[];
}
export interface InputConfigurationRequest {
    InputPort?: number;
    Interface?: InterfaceRequest;
}
export type __listOfInputConfigurationRequest = InputConfigurationRequest[];
export interface MediaStreamSourceConfigurationRequest {
    EncodingName?: EncodingName;
    InputConfigurations?: InputConfigurationRequest[];
    MediaStreamName?: string;
}
export type __listOfMediaStreamSourceConfigurationRequest = MediaStreamSourceConfigurationRequest[];
export interface SetGatewayBridgeSourceRequest {
    BridgeArn?: string;
    VpcInterfaceAttachment?: VpcInterfaceAttachment;
}
export interface SetSourceRequest {
    Decryption?: Encryption;
    Description?: string;
    EntitlementArn?: string;
    IngestPort?: number;
    MaxBitrate?: number;
    MaxLatency?: number;
    MaxSyncBuffer?: number;
    MediaStreamSourceConfigurations?: MediaStreamSourceConfigurationRequest[];
    MinLatency?: number;
    Name?: string;
    Protocol?: Protocol;
    SenderControlPort?: number;
    SenderIpAddress?: string;
    SourceListenerAddress?: string;
    SourceListenerPort?: number;
    StreamId?: string;
    VpcInterfaceName?: string;
    WhitelistCidr?: string;
    GatewayBridgeSource?: SetGatewayBridgeSourceRequest;
    NdiSourceSettings?: NdiSourceSettings;
    SourceTags?: {
        [key: string]: string | undefined;
    };
    RouterIntegrationState?: State;
    RouterIntegrationTransitDecryption?: FlowTransitEncryption;
}
export type __listOfSetSourceRequest = SetSourceRequest[];
export interface AddFlowSourcesRequest {
    FlowArn: string;
    Sources?: SetSourceRequest[];
}
export interface InputConfiguration {
    InputIp?: string;
    InputPort?: number;
    Interface?: Interface;
}
export type __listOfInputConfiguration = InputConfiguration[];
export interface MediaStreamSourceConfiguration {
    EncodingName?: EncodingName;
    InputConfigurations?: InputConfiguration[];
    MediaStreamName?: string;
}
export type __listOfMediaStreamSourceConfiguration = MediaStreamSourceConfiguration[];
export interface GatewayBridgeSource {
    BridgeArn?: string;
    VpcInterfaceAttachment?: VpcInterfaceAttachment;
}
export interface Source {
    DataTransferSubscriberFeePercent?: number;
    Decryption?: Encryption;
    Description?: string;
    EntitlementArn?: string;
    IngestIp?: string;
    IngestPort?: number;
    MediaStreamSourceConfigurations?: MediaStreamSourceConfiguration[];
    Name?: string;
    SenderControlPort?: number;
    SenderIpAddress?: string;
    SourceArn?: string;
    Transport?: Transport;
    VpcInterfaceName?: string;
    WhitelistCidr?: string;
    GatewayBridgeSource?: GatewayBridgeSource;
    PeerIpAddress?: string;
    RouterIntegrationState?: State;
    RouterIntegrationTransitDecryption?: FlowTransitEncryption;
    ConnectedRouterOutputArn?: string;
}
export type __listOfSource = Source[];
export interface AddFlowSourcesResponse {
    FlowArn?: string;
    Sources?: (Source & {
        Name: string;
        SourceArn: string;
        Decryption: Encryption & {
            RoleArn: string;
        };
        MediaStreamSourceConfigurations: (MediaStreamSourceConfiguration & {
            EncodingName: EncodingName;
            MediaStreamName: string;
            InputConfigurations: (InputConfiguration & {
                InputIp: string;
                InputPort: number;
                Interface: Interface & {
                    Name: string;
                };
            })[];
        })[];
        Transport: Transport & {
            Protocol: Protocol;
        };
        GatewayBridgeSource: GatewayBridgeSource & {
            BridgeArn: string;
        };
    })[];
}
export type NetworkInterfaceType = "ena" | "efa" | (string & {});
export interface VpcInterfaceRequest {
    Name?: string;
    NetworkInterfaceType?: NetworkInterfaceType;
    RoleArn?: string;
    SecurityGroupIds?: string[];
    SubnetId?: string;
    VpcInterfaceTags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfVpcInterfaceRequest = VpcInterfaceRequest[];
export interface AddFlowVpcInterfacesRequest {
    FlowArn: string;
    VpcInterfaces?: VpcInterfaceRequest[];
}
export interface VpcInterface {
    Name?: string;
    NetworkInterfaceIds?: string[];
    NetworkInterfaceType?: NetworkInterfaceType;
    RoleArn?: string;
    SecurityGroupIds?: string[];
    SubnetId?: string;
}
export type __listOfVpcInterface = VpcInterface[];
export interface AddFlowVpcInterfacesResponse {
    FlowArn?: string;
    VpcInterfaces?: (VpcInterface & {
        Name: string;
        NetworkInterfaceIds: __listOfString;
        NetworkInterfaceType: NetworkInterfaceType;
        RoleArn: string;
        SecurityGroupIds: __listOfString;
        SubnetId: string;
    })[];
}
export type RouterInputArn = string;
export type RouterInputArnList = string[];
export interface BatchGetRouterInputRequest {
    Arns: string[];
}
export type RouterInputState = "CREATING" | "STANDBY" | "STARTING" | "ACTIVE" | "STOPPING" | "DELETING" | "UPDATING" | "ERROR" | "RECOVERING" | "MIGRATING" | (string & {});
export type RouterInputType = "STANDARD" | "FAILOVER" | "MERGE" | "MEDIACONNECT_FLOW" | "MEDIALIVE_CHANNEL" | (string & {});
export type RouterNetworkInterfaceArn = string;
export interface RistRouterInputConfiguration {
    Port: number;
    RecoveryLatencyMilliseconds: number;
}
export interface SrtDecryptionConfiguration {
    EncryptionKey: SecretsManagerEncryptionKeyConfiguration;
}
export interface SrtListenerRouterInputConfiguration {
    Port: number;
    MinimumLatencyMilliseconds: number;
    DecryptionConfiguration?: SrtDecryptionConfiguration;
}
export interface SrtCallerRouterInputConfiguration {
    SourceAddress: string;
    SourcePort: number;
    MinimumLatencyMilliseconds: number;
    StreamId?: string;
    DecryptionConfiguration?: SrtDecryptionConfiguration;
}
export type ForwardErrorCorrectionState = "ENABLED" | "DISABLED" | (string & {});
export interface RtpRouterInputConfiguration {
    Port: number;
    ForwardErrorCorrection?: ForwardErrorCorrectionState;
}
export type RouterInputProtocolConfiguration = {
    Rist: RistRouterInputConfiguration;
    SrtListener?: never;
    SrtCaller?: never;
    Rtp?: never;
} | {
    Rist?: never;
    SrtListener: SrtListenerRouterInputConfiguration;
    SrtCaller?: never;
    Rtp?: never;
} | {
    Rist?: never;
    SrtListener?: never;
    SrtCaller: SrtCallerRouterInputConfiguration;
    Rtp?: never;
} | {
    Rist?: never;
    SrtListener?: never;
    SrtCaller?: never;
    Rtp: RtpRouterInputConfiguration;
};
export type RouterInputProtocol = "RTP" | "RIST" | "SRT_CALLER" | "SRT_LISTENER" | (string & {});
export interface StandardRouterInputConfiguration {
    NetworkInterfaceArn: string;
    ProtocolConfiguration: RouterInputProtocolConfiguration;
    Protocol?: RouterInputProtocol;
}
export type MediaLiveChannelArn = string;
export type MediaLiveChannelPipelineId = "PIPELINE_0" | "PIPELINE_1" | (string & {});
export type MediaLiveTransitEncryptionKeyType = "SECRETS_MANAGER" | "AUTOMATIC" | (string & {});
export type MediaLiveTransitEncryptionKeyConfiguration = {
    SecretsManager: SecretsManagerEncryptionKeyConfiguration;
    Automatic?: never;
} | {
    SecretsManager?: never;
    Automatic: AutomaticEncryptionKeyConfiguration;
};
export interface MediaLiveTransitEncryption {
    EncryptionKeyType?: MediaLiveTransitEncryptionKeyType;
    EncryptionKeyConfiguration: MediaLiveTransitEncryptionKeyConfiguration;
}
export interface MediaLiveChannelRouterInputConfiguration {
    MediaLiveChannelArn?: string;
    MediaLivePipelineId?: MediaLiveChannelPipelineId;
    MediaLiveChannelOutputName?: string;
    SourceTransitDecryption: MediaLiveTransitEncryption;
}
export type FailoverRouterInputProtocolConfiguration = {
    Rist: RistRouterInputConfiguration;
    SrtListener?: never;
    SrtCaller?: never;
    Rtp?: never;
} | {
    Rist?: never;
    SrtListener: SrtListenerRouterInputConfiguration;
    SrtCaller?: never;
    Rtp?: never;
} | {
    Rist?: never;
    SrtListener?: never;
    SrtCaller: SrtCallerRouterInputConfiguration;
    Rtp?: never;
} | {
    Rist?: never;
    SrtListener?: never;
    SrtCaller?: never;
    Rtp: RtpRouterInputConfiguration;
};
export type FailoverRouterInputProtocolConfigurationList = FailoverRouterInputProtocolConfiguration[];
export type FailoverInputSourcePriorityMode = "NO_PRIORITY" | "PRIMARY_SECONDARY" | (string & {});
export interface FailoverRouterInputConfiguration {
    NetworkInterfaceArn: string;
    ProtocolConfigurations: FailoverRouterInputProtocolConfiguration[];
    SourcePriorityMode: FailoverInputSourcePriorityMode;
    PrimarySourceIndex?: number;
}
export type FlowOutputArn = string;
export interface MediaConnectFlowRouterInputConfiguration {
    FlowArn?: string;
    FlowOutputArn?: string;
    SourceTransitDecryption: FlowTransitEncryption;
}
export type MergeRouterInputProtocolConfiguration = {
    Rtp: RtpRouterInputConfiguration;
    Rist?: never;
} | {
    Rtp?: never;
    Rist: RistRouterInputConfiguration;
};
export type MergeRouterInputProtocolConfigurationList = MergeRouterInputProtocolConfiguration[];
export interface MergeRouterInputConfiguration {
    NetworkInterfaceArn: string;
    ProtocolConfigurations: MergeRouterInputProtocolConfiguration[];
    MergeRecoveryWindowMilliseconds: number;
}
export type RouterInputConfiguration = {
    Standard: StandardRouterInputConfiguration;
    MediaLiveChannel?: never;
    Failover?: never;
    MediaConnectFlow?: never;
    Merge?: never;
} | {
    Standard?: never;
    MediaLiveChannel: MediaLiveChannelRouterInputConfiguration;
    Failover?: never;
    MediaConnectFlow?: never;
    Merge?: never;
} | {
    Standard?: never;
    MediaLiveChannel?: never;
    Failover: FailoverRouterInputConfiguration;
    MediaConnectFlow?: never;
    Merge?: never;
} | {
    Standard?: never;
    MediaLiveChannel?: never;
    Failover?: never;
    MediaConnectFlow: MediaConnectFlowRouterInputConfiguration;
    Merge?: never;
} | {
    Standard?: never;
    MediaLiveChannel?: never;
    Failover?: never;
    MediaConnectFlow?: never;
    Merge: MergeRouterInputConfiguration;
};
export type RouterInputTier = "INPUT_100" | "INPUT_50" | "INPUT_20" | (string & {});
export type RoutingScope = "REGIONAL" | "GLOBAL" | (string & {});
export interface RouterInputMessage {
    Code: string;
    Message: string;
}
export type RouterInputMessages = RouterInputMessage[];
export type RouterInputTransitEncryptionKeyType = "SECRETS_MANAGER" | "AUTOMATIC" | (string & {});
export type RouterInputTransitEncryptionKeyConfiguration = {
    SecretsManager: SecretsManagerEncryptionKeyConfiguration;
    Automatic?: never;
} | {
    SecretsManager?: never;
    Automatic: AutomaticEncryptionKeyConfiguration;
};
export interface RouterInputTransitEncryption {
    EncryptionKeyType?: RouterInputTransitEncryptionKeyType;
    EncryptionKeyConfiguration: RouterInputTransitEncryptionKeyConfiguration;
}
export interface StandardRouterInputStreamDetails {
    SourceIpAddress?: string;
}
export interface MediaLiveChannelRouterInputStreamDetails {
}
export interface FailoverRouterInputIndexedStreamDetails {
    SourceIndex: number;
    SourceIpAddress?: string;
}
export interface FailoverRouterInputStreamDetails {
    SourceIndexZeroStreamDetails: FailoverRouterInputIndexedStreamDetails;
    SourceIndexOneStreamDetails: FailoverRouterInputIndexedStreamDetails;
}
export interface MediaConnectFlowRouterInputStreamDetails {
}
export interface MergeRouterInputIndexedStreamDetails {
    SourceIndex: number;
    SourceIpAddress?: string;
}
export interface MergeRouterInputStreamDetails {
    SourceIndexZeroStreamDetails: MergeRouterInputIndexedStreamDetails;
    SourceIndexOneStreamDetails: MergeRouterInputIndexedStreamDetails;
}
export type RouterInputStreamDetails = {
    Standard: StandardRouterInputStreamDetails;
    MediaLiveChannel?: never;
    Failover?: never;
    MediaConnectFlow?: never;
    Merge?: never;
} | {
    Standard?: never;
    MediaLiveChannel: MediaLiveChannelRouterInputStreamDetails;
    Failover?: never;
    MediaConnectFlow?: never;
    Merge?: never;
} | {
    Standard?: never;
    MediaLiveChannel?: never;
    Failover: FailoverRouterInputStreamDetails;
    MediaConnectFlow?: never;
    Merge?: never;
} | {
    Standard?: never;
    MediaLiveChannel?: never;
    Failover?: never;
    MediaConnectFlow: MediaConnectFlowRouterInputStreamDetails;
    Merge?: never;
} | {
    Standard?: never;
    MediaLiveChannel?: never;
    Failover?: never;
    MediaConnectFlow?: never;
    Merge: MergeRouterInputStreamDetails;
};
export type MaintenanceType = "PREFERRED_DAY_TIME" | "DEFAULT" | (string & {});
export type Day = "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | "SUNDAY" | (string & {});
export interface PreferredDayTimeMaintenanceConfiguration {
    Day: Day;
    Time: string;
}
export interface DefaultMaintenanceConfiguration {
}
export type MaintenanceConfiguration = {
    PreferredDayTime: PreferredDayTimeMaintenanceConfiguration;
    Default?: never;
} | {
    PreferredDayTime?: never;
    Default: DefaultMaintenanceConfiguration;
};
export type MaintenanceScheduleType = "WINDOW" | (string & {});
export interface WindowMaintenanceSchedule {
    Start: Date;
    End: Date;
    ScheduledTime: Date;
}
export type MaintenanceSchedule = {
    Window: WindowMaintenanceSchedule;
};
export type RouterContentQualityAnalysisType = "CONTENT_LEVEL" | (string & {});
export type ContentQualityAnalysisState = "ENABLED" | "DISABLED" | (string & {});
export type RouterCqaThresholdSeconds = number;
export interface BlackFramesConfiguration {
    State: ContentQualityAnalysisState;
    ThresholdSeconds: number;
}
export interface FrozenFramesConfiguration {
    State: ContentQualityAnalysisState;
    ThresholdSeconds: number;
}
export interface SilentAudioConfiguration {
    State: ContentQualityAnalysisState;
    ThresholdSeconds: number;
}
export interface ContentQualityAnalysisFeatureConfiguration {
    BlackFrames?: BlackFramesConfiguration;
    FrozenFrames?: FrozenFramesConfiguration;
    SilentAudio?: SilentAudioConfiguration;
}
export type RouterContentQualityAnalysisConfiguration = {
    ContentLevel: ContentQualityAnalysisFeatureConfiguration;
};
export interface RouterInput {
    Name: string;
    Arn: string;
    Id: string;
    State: RouterInputState;
    InputType: RouterInputType;
    Configuration: RouterInputConfiguration;
    RoutedOutputs: number;
    MaximumRoutedOutputs?: number;
    RegionName: string;
    AvailabilityZone: string;
    MaximumBitrate: number;
    Tier: RouterInputTier;
    RoutingScope: RoutingScope;
    CreatedAt: Date;
    UpdatedAt: Date;
    Messages: RouterInputMessage[];
    TransitEncryption: RouterInputTransitEncryption;
    Tags: {
        [key: string]: string | undefined;
    };
    StreamDetails: RouterInputStreamDetails;
    IpAddress?: string;
    MaintenanceType: MaintenanceType;
    MaintenanceConfiguration: MaintenanceConfiguration;
    MaintenanceScheduleType?: MaintenanceScheduleType;
    MaintenanceSchedule?: MaintenanceSchedule;
    ContentQualityAnalysisType?: RouterContentQualityAnalysisType;
    ContentQualityAnalysisConfiguration?: RouterContentQualityAnalysisConfiguration;
}
export type RouterInputList = RouterInput[];
export interface BatchGetRouterInputError_ {
    Arn: string;
    Code: string;
    Message: string;
}
export type BatchGetRouterInputErrorList = BatchGetRouterInputError_[];
export interface BatchGetRouterInputResponse {
    RouterInputs: (RouterInput & {
        ContentQualityAnalysisType: RouterContentQualityAnalysisType;
        ContentQualityAnalysisConfiguration: RouterContentQualityAnalysisConfiguration;
    })[];
    Errors: BatchGetRouterInputError_[];
}
export type RouterNetworkInterfaceArnList = string[];
export interface BatchGetRouterNetworkInterfaceRequest {
    Arns: string[];
}
export type RouterNetworkInterfaceState = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "ERROR" | "RECOVERING" | (string & {});
export type RouterNetworkInterfaceType = "PUBLIC" | "VPC" | (string & {});
export interface PublicRouterNetworkInterfaceRule {
    Cidr: string;
}
export type NetworkInterfaceRuleList = PublicRouterNetworkInterfaceRule[];
export interface PublicRouterNetworkInterfaceConfiguration {
    AllowRules: PublicRouterNetworkInterfaceRule[];
}
export type SecurityGroupIdList = string[];
export interface VpcRouterNetworkInterfaceConfiguration {
    SecurityGroupIds: string[];
    SubnetId: string;
}
export type RouterNetworkInterfaceConfiguration = {
    Public: PublicRouterNetworkInterfaceConfiguration;
    Vpc?: never;
} | {
    Public?: never;
    Vpc: VpcRouterNetworkInterfaceConfiguration;
};
export interface RouterNetworkInterface {
    Name: string;
    Arn: string;
    Id: string;
    State: RouterNetworkInterfaceState;
    NetworkInterfaceType: RouterNetworkInterfaceType;
    Configuration: RouterNetworkInterfaceConfiguration;
    AssociatedOutputCount: number;
    AssociatedInputCount: number;
    RegionName: string;
    CreatedAt: Date;
    UpdatedAt: Date;
    Tags: {
        [key: string]: string | undefined;
    };
}
export type RouterNetworkInterfaceList = RouterNetworkInterface[];
export interface BatchGetRouterNetworkInterfaceError_ {
    Arn: string;
    Code: string;
    Message: string;
}
export type BatchGetRouterNetworkInterfaceErrorList = BatchGetRouterNetworkInterfaceError_[];
export interface BatchGetRouterNetworkInterfaceResponse {
    RouterNetworkInterfaces: RouterNetworkInterface[];
    Errors: BatchGetRouterNetworkInterfaceError_[];
}
export type RouterOutputArn = string;
export type RouterOutputArnList = string[];
export interface BatchGetRouterOutputRequest {
    Arns: string[];
}
export type RouterOutputState = "CREATING" | "STANDBY" | "STARTING" | "ACTIVE" | "STOPPING" | "DELETING" | "UPDATING" | "ERROR" | "RECOVERING" | "MIGRATING" | (string & {});
export type RouterOutputType = "STANDARD" | "MEDIACONNECT_FLOW" | "MEDIALIVE_INPUT" | (string & {});
export interface RistRouterOutputConfiguration {
    DestinationAddress: string;
    DestinationPort: number;
}
export interface SrtEncryptionConfiguration {
    EncryptionKey: SecretsManagerEncryptionKeyConfiguration;
}
export interface SrtListenerRouterOutputConfiguration {
    Port: number;
    MinimumLatencyMilliseconds: number;
    EncryptionConfiguration?: SrtEncryptionConfiguration;
}
export type TlsEncryptionType = "PUBLIC" | (string & {});
export interface PublicTlsEncryptionConfiguration {
}
export type TlsEncryptionConfiguration = {
    Public: PublicTlsEncryptionConfiguration;
};
export interface TlsEncryption {
    EncryptionType?: TlsEncryptionType;
    EncryptionConfiguration: TlsEncryptionConfiguration;
}
export interface RtmpPushRouterOutputConfiguration {
    DestinationAddress: string;
    DestinationPort: number;
    ApplicationName: string;
    StreamName: string;
    TlsEncryption?: TlsEncryption;
}
export interface SrtCallerRouterOutputConfiguration {
    DestinationAddress: string;
    DestinationPort: number;
    MinimumLatencyMilliseconds: number;
    StreamId?: string;
    EncryptionConfiguration?: SrtEncryptionConfiguration;
}
export interface RtpRouterOutputConfiguration {
    DestinationAddress: string;
    DestinationPort: number;
    ForwardErrorCorrection?: ForwardErrorCorrectionState;
}
export type RouterOutputProtocolConfiguration = {
    Rist: RistRouterOutputConfiguration;
    SrtListener?: never;
    RtmpPush?: never;
    SrtCaller?: never;
    Rtp?: never;
} | {
    Rist?: never;
    SrtListener: SrtListenerRouterOutputConfiguration;
    RtmpPush?: never;
    SrtCaller?: never;
    Rtp?: never;
} | {
    Rist?: never;
    SrtListener?: never;
    RtmpPush: RtmpPushRouterOutputConfiguration;
    SrtCaller?: never;
    Rtp?: never;
} | {
    Rist?: never;
    SrtListener?: never;
    RtmpPush?: never;
    SrtCaller: SrtCallerRouterOutputConfiguration;
    Rtp?: never;
} | {
    Rist?: never;
    SrtListener?: never;
    RtmpPush?: never;
    SrtCaller?: never;
    Rtp: RtpRouterOutputConfiguration;
};
export type RouterOutputProtocol = "RTP" | "RIST" | "SRT_CALLER" | "SRT_LISTENER" | "RTMP_PUSH" | (string & {});
export interface StandardRouterOutputConfiguration {
    NetworkInterfaceArn: string;
    ProtocolConfiguration: RouterOutputProtocolConfiguration;
    Protocol?: RouterOutputProtocol;
}
export type FlowSourceArn = string;
export interface MediaConnectFlowRouterOutputConfiguration {
    FlowArn?: string;
    FlowSourceArn?: string;
    DestinationTransitEncryption: FlowTransitEncryption;
}
export type MediaLiveInputArn = string;
export type MediaLiveInputPipelineId = "PIPELINE_0" | "PIPELINE_1" | (string & {});
export interface MediaLiveInputRouterOutputConfiguration {
    MediaLiveInputArn?: string;
    MediaLivePipelineId?: MediaLiveInputPipelineId;
    DestinationTransitEncryption: MediaLiveTransitEncryption;
}
export type RouterOutputConfiguration = {
    Standard: StandardRouterOutputConfiguration;
    MediaConnectFlow?: never;
    MediaLiveInput?: never;
} | {
    Standard?: never;
    MediaConnectFlow: MediaConnectFlowRouterOutputConfiguration;
    MediaLiveInput?: never;
} | {
    Standard?: never;
    MediaConnectFlow?: never;
    MediaLiveInput: MediaLiveInputRouterOutputConfiguration;
};
export type RouterOutputRoutedState = "ROUTED" | "ROUTING" | "UNROUTED" | (string & {});
export type RouterOutputTier = "OUTPUT_100" | "OUTPUT_50" | "OUTPUT_20" | (string & {});
export interface RouterOutputMessage {
    Code: string;
    Message: string;
}
export type RouterOutputMessages = RouterOutputMessage[];
export interface StandardRouterOutputStreamDetails {
    DestinationIpAddress?: string;
}
export interface MediaConnectFlowRouterOutputStreamDetails {
}
export interface MediaLiveInputRouterOutputStreamDetails {
}
export type RouterOutputStreamDetails = {
    Standard: StandardRouterOutputStreamDetails;
    MediaConnectFlow?: never;
    MediaLiveInput?: never;
} | {
    Standard?: never;
    MediaConnectFlow: MediaConnectFlowRouterOutputStreamDetails;
    MediaLiveInput?: never;
} | {
    Standard?: never;
    MediaConnectFlow?: never;
    MediaLiveInput: MediaLiveInputRouterOutputStreamDetails;
};
export type FabricLatencyMode = "BALANCED" | "LOW_LATENCY" | (string & {});
export interface FabricConfiguration {
    RecoveryLatencyMode: FabricLatencyMode;
}
export interface RouterOutput {
    Name: string;
    Arn: string;
    Id: string;
    State: RouterOutputState;
    OutputType: RouterOutputType;
    Configuration: RouterOutputConfiguration;
    RoutedState: RouterOutputRoutedState;
    RegionName: string;
    AvailabilityZone: string;
    MaximumBitrate: number;
    RoutingScope: RoutingScope;
    Tier: RouterOutputTier;
    CreatedAt: Date;
    UpdatedAt: Date;
    Messages: RouterOutputMessage[];
    Tags: {
        [key: string]: string | undefined;
    };
    StreamDetails: RouterOutputStreamDetails;
    IpAddress?: string;
    RoutedInputArn?: string;
    MaintenanceType: MaintenanceType;
    MaintenanceConfiguration: MaintenanceConfiguration;
    MaintenanceScheduleType?: MaintenanceScheduleType;
    MaintenanceSchedule?: MaintenanceSchedule;
    FabricConfiguration?: FabricConfiguration;
}
export type RouterOutputList = RouterOutput[];
export interface BatchGetRouterOutputError_ {
    Arn: string;
    Code: string;
    Message: string;
}
export type BatchGetRouterOutputErrorList = BatchGetRouterOutputError_[];
export interface BatchGetRouterOutputResponse {
    RouterOutputs: (RouterOutput & {
        FabricConfiguration: FabricConfiguration;
    })[];
    Errors: BatchGetRouterOutputError_[];
}
export interface AddEgressGatewayBridgeRequest {
    MaxBitrate?: number;
}
export interface AddIngressGatewayBridgeRequest {
    MaxBitrate?: number;
    MaxOutputs?: number;
}
export type FailoverMode = "MERGE" | "FAILOVER" | (string & {});
export interface SourcePriority {
    PrimarySource?: string;
}
export interface FailoverConfig {
    FailoverMode?: FailoverMode;
    RecoveryWindow?: number;
    SourcePriority?: SourcePriority;
    State?: State;
}
export interface CreateBridgeRequest {
    EgressGatewayBridge?: AddEgressGatewayBridgeRequest;
    IngressGatewayBridge?: AddIngressGatewayBridgeRequest;
    Name?: string;
    Outputs?: AddBridgeOutputRequest[];
    PlacementArn?: string;
    SourceFailoverConfig?: FailoverConfig;
    Sources?: AddBridgeSourceRequest[];
}
export interface MessageDetail {
    Code?: string;
    Message?: string;
    ResourceName?: string;
}
export type __listOfMessageDetail = MessageDetail[];
export type BridgeState = "CREATING" | "STANDBY" | "STARTING" | "DEPLOYING" | "ACTIVE" | "STOPPING" | "DELETING" | "DELETED" | "START_FAILED" | "START_PENDING" | "STOP_FAILED" | "UPDATING" | (string & {});
export interface EgressGatewayBridge {
    InstanceId?: string;
    MaxBitrate?: number;
}
export interface IngressGatewayBridge {
    InstanceId?: string;
    MaxBitrate?: number;
    MaxOutputs?: number;
}
export interface Bridge {
    BridgeArn?: string;
    BridgeMessages?: MessageDetail[];
    BridgeState?: BridgeState;
    EgressGatewayBridge?: EgressGatewayBridge;
    IngressGatewayBridge?: IngressGatewayBridge;
    Name?: string;
    Outputs?: BridgeOutput[];
    PlacementArn?: string;
    SourceFailoverConfig?: FailoverConfig;
    Sources?: BridgeSource[];
}
export interface CreateBridgeResponse {
    Bridge?: Bridge & {
        BridgeArn: string;
        BridgeState: BridgeState;
        Name: string;
        PlacementArn: string;
        BridgeMessages: (MessageDetail & {
            Code: string;
            Message: string;
        })[];
        EgressGatewayBridge: EgressGatewayBridge & {
            MaxBitrate: number;
        };
        IngressGatewayBridge: IngressGatewayBridge & {
            MaxBitrate: number;
            MaxOutputs: number;
        };
        Outputs: (BridgeOutput & {
            FlowOutput: BridgeFlowOutput & {
                FlowArn: string;
                FlowSourceArn: string;
                Name: string;
            };
            NetworkOutput: BridgeNetworkOutput & {
                IpAddress: string;
                Name: string;
                NetworkName: string;
                Port: number;
                Protocol: Protocol;
                Ttl: number;
            };
        })[];
        Sources: (BridgeSource & {
            FlowSource: BridgeFlowSource & {
                FlowArn: string;
                Name: string;
            };
            NetworkSource: BridgeNetworkSource & {
                MulticastIp: string;
                Name: string;
                NetworkName: string;
                Port: number;
                Protocol: Protocol;
            };
        })[];
    };
}
export type EntitlementStatus = "ENABLED" | "DISABLED" | (string & {});
export interface GrantEntitlementRequest {
    DataTransferSubscriberFeePercent?: number;
    Description?: string;
    Encryption?: Encryption;
    EntitlementStatus?: EntitlementStatus;
    Name?: string;
    Subscribers?: string[];
    EntitlementTags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfGrantEntitlementRequest = GrantEntitlementRequest[];
export type MaintenanceDay = "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday" | "Sunday" | (string & {});
export interface AddMaintenance {
    MaintenanceDay?: MaintenanceDay;
    MaintenanceStartHour?: string;
}
export type ThumbnailState = "ENABLED" | "DISABLED" | (string & {});
export interface SilentAudio {
    State?: State;
    ThresholdSeconds?: number;
}
export interface AudioMonitoringSetting {
    SilentAudio?: SilentAudio;
}
export type __listOfAudioMonitoringSetting = AudioMonitoringSetting[];
export interface BlackFrames {
    State?: State;
    ThresholdSeconds?: number;
}
export interface FrozenFrames {
    State?: State;
    ThresholdSeconds?: number;
}
export interface VideoMonitoringSetting {
    BlackFrames?: BlackFrames;
    FrozenFrames?: FrozenFrames;
}
export type __listOfVideoMonitoringSetting = VideoMonitoringSetting[];
export interface MonitoringConfig {
    ThumbnailState?: ThumbnailState;
    AudioMonitoringSettings?: AudioMonitoringSetting[];
    ContentQualityAnalysisState?: ContentQualityAnalysisState;
    VideoMonitoringSettings?: VideoMonitoringSetting[];
}
export type FlowSize = "MEDIUM" | "LARGE" | "LARGE_4X" | (string & {});
export type NdiState = "ENABLED" | "DISABLED" | (string & {});
export interface NdiDiscoveryServerConfig {
    DiscoveryServerAddress?: string;
    DiscoveryServerPort?: number;
    VpcInterfaceAdapter?: string;
}
export type __listOfNdiDiscoveryServerConfig = NdiDiscoveryServerConfig[];
export interface NdiConfig {
    NdiState?: NdiState;
    MachineName?: string;
    NdiDiscoveryServers?: NdiDiscoveryServerConfig[];
}
export type EncodingProfile = "DISTRIBUTION_H264_DEFAULT" | "CONTRIBUTION_H264_DEFAULT" | (string & {});
export interface EncodingConfig {
    EncodingProfile?: EncodingProfile;
    VideoMaxBitrate?: number;
}
export interface CreateFlowRequest {
    AvailabilityZone?: string;
    Entitlements?: GrantEntitlementRequest[];
    MediaStreams?: AddMediaStreamRequest[];
    Name?: string;
    Outputs?: AddOutputRequest[];
    Source?: SetSourceRequest;
    SourceFailoverConfig?: FailoverConfig;
    Sources?: SetSourceRequest[];
    VpcInterfaces?: VpcInterfaceRequest[];
    Maintenance?: AddMaintenance;
    SourceMonitoringConfig?: MonitoringConfig;
    FlowSize?: FlowSize;
    NdiConfig?: NdiConfig;
    EncodingConfig?: EncodingConfig;
    FlowTags?: {
        [key: string]: string | undefined;
    };
}
export interface Entitlement {
    DataTransferSubscriberFeePercent?: number;
    Description?: string;
    Encryption?: Encryption;
    EntitlementArn?: string;
    EntitlementStatus?: EntitlementStatus;
    Name?: string;
    Subscribers?: string[];
}
export type __listOfEntitlement = Entitlement[];
export type Status = "STANDBY" | "ACTIVE" | "UPDATING" | "DELETING" | "STARTING" | "STOPPING" | "ERROR" | (string & {});
export interface Maintenance {
    MaintenanceDay?: MaintenanceDay;
    MaintenanceDeadline?: string;
    MaintenanceScheduledDate?: string;
    MaintenanceStartHour?: string;
}
export interface Flow {
    AvailabilityZone?: string;
    Description?: string;
    EgressIp?: string;
    Entitlements?: Entitlement[];
    FlowArn?: string;
    MediaStreams?: MediaStream[];
    Name?: string;
    Outputs?: Output[];
    Source?: Source;
    SourceFailoverConfig?: FailoverConfig;
    Sources?: Source[];
    Status?: Status;
    VpcInterfaces?: VpcInterface[];
    Maintenance?: Maintenance;
    SourceMonitoringConfig?: MonitoringConfig;
    FlowSize?: FlowSize;
    NdiConfig?: NdiConfig;
    EncodingConfig?: EncodingConfig;
}
export interface CreateFlowResponse {
    Flow?: Flow & {
        AvailabilityZone: string;
        Entitlements: (Entitlement & {
            EntitlementArn: string;
            Name: string;
            Subscribers: __listOfString;
            Encryption: Encryption & {
                RoleArn: string;
            };
        })[];
        FlowArn: string;
        Name: string;
        Outputs: (Output & {
            Name: string;
            OutputArn: string;
            Encryption: Encryption & {
                RoleArn: string;
            };
            MediaStreamOutputConfigurations: (MediaStreamOutputConfiguration & {
                EncodingName: EncodingName;
                MediaStreamName: string;
                DestinationConfigurations: (DestinationConfiguration & {
                    DestinationIp: string;
                    DestinationPort: number;
                    Interface: Interface & {
                        Name: string;
                    };
                    OutboundIp: string;
                })[];
                EncodingParameters: EncodingParameters & {
                    CompressionFactor: number;
                    EncoderProfile: EncoderProfile;
                };
            })[];
            Transport: Transport & {
                Protocol: Protocol;
            };
        })[];
        Source: Source & {
            Name: string;
            SourceArn: string;
            Decryption: Encryption & {
                RoleArn: string;
            };
            MediaStreamSourceConfigurations: (MediaStreamSourceConfiguration & {
                EncodingName: EncodingName;
                MediaStreamName: string;
                InputConfigurations: (InputConfiguration & {
                    InputIp: string;
                    InputPort: number;
                    Interface: Interface & {
                        Name: string;
                    };
                })[];
            })[];
            Transport: Transport & {
                Protocol: Protocol;
            };
            GatewayBridgeSource: GatewayBridgeSource & {
                BridgeArn: string;
            };
        };
        Status: Status;
        MediaStreams: (MediaStream & {
            Fmt: number;
            MediaStreamId: number;
            MediaStreamName: string;
            MediaStreamType: MediaStreamType;
            Attributes: MediaStreamAttributes & {
                Fmtp: Fmtp;
            };
        })[];
        Sources: (Source & {
            Name: string;
            SourceArn: string;
            Decryption: Encryption & {
                RoleArn: string;
            };
            MediaStreamSourceConfigurations: (MediaStreamSourceConfiguration & {
                EncodingName: EncodingName;
                MediaStreamName: string;
                InputConfigurations: (InputConfiguration & {
                    InputIp: string;
                    InputPort: number;
                    Interface: Interface & {
                        Name: string;
                    };
                })[];
            })[];
            Transport: Transport & {
                Protocol: Protocol;
            };
            GatewayBridgeSource: GatewayBridgeSource & {
                BridgeArn: string;
            };
        })[];
        VpcInterfaces: (VpcInterface & {
            Name: string;
            NetworkInterfaceIds: __listOfString;
            NetworkInterfaceType: NetworkInterfaceType;
            RoleArn: string;
            SecurityGroupIds: __listOfString;
            SubnetId: string;
        })[];
        NdiConfig: NdiConfig & {
            NdiDiscoveryServers: (NdiDiscoveryServerConfig & {
                DiscoveryServerAddress: string;
                VpcInterfaceAdapter: string;
            })[];
        };
    };
}
export interface GatewayNetwork {
    CidrBlock?: string;
    Name?: string;
}
export type __listOfGatewayNetwork = GatewayNetwork[];
export interface CreateGatewayRequest {
    EgressCidrBlocks?: string[];
    Name?: string;
    Networks?: GatewayNetwork[];
}
export type GatewayState = "CREATING" | "ACTIVE" | "UPDATING" | "ERROR" | "DELETING" | "DELETED" | (string & {});
export interface Gateway {
    EgressCidrBlocks?: string[];
    GatewayArn?: string;
    GatewayMessages?: MessageDetail[];
    GatewayState?: GatewayState;
    Name?: string;
    Networks?: GatewayNetwork[];
}
export interface CreateGatewayResponse {
    Gateway?: Gateway & {
        EgressCidrBlocks: __listOfString;
        GatewayArn: string;
        Name: string;
        Networks: (GatewayNetwork & {
            CidrBlock: string;
            Name: string;
        })[];
        GatewayMessages: (MessageDetail & {
            Code: string;
            Message: string;
        })[];
    };
}
export type ClientToken = string;
export interface CreateRouterInputRequest {
    Name: string;
    Configuration: RouterInputConfiguration;
    MaximumBitrate: number;
    RoutingScope: RoutingScope;
    Tier: RouterInputTier;
    RegionName?: string;
    AvailabilityZone?: string;
    TransitEncryption?: RouterInputTransitEncryption;
    MaintenanceConfiguration?: MaintenanceConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
    ContentQualityAnalysisConfiguration?: RouterContentQualityAnalysisConfiguration;
}
export interface CreateRouterInputResponse {
    RouterInput: RouterInput & {
        ContentQualityAnalysisType: RouterContentQualityAnalysisType;
        ContentQualityAnalysisConfiguration: RouterContentQualityAnalysisConfiguration;
    };
}
export interface CreateRouterNetworkInterfaceRequest {
    Name: string;
    Configuration: RouterNetworkInterfaceConfiguration;
    RegionName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
}
export interface CreateRouterNetworkInterfaceResponse {
    RouterNetworkInterface: RouterNetworkInterface;
}
export interface CreateRouterOutputRequest {
    Name: string;
    Configuration: RouterOutputConfiguration;
    MaximumBitrate: number;
    RoutingScope: RoutingScope;
    Tier: RouterOutputTier;
    RegionName?: string;
    AvailabilityZone?: string;
    MaintenanceConfiguration?: MaintenanceConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    };
    FabricConfiguration?: FabricConfiguration;
    ClientToken?: string;
}
export interface CreateRouterOutputResponse {
    RouterOutput: RouterOutput & {
        FabricConfiguration: FabricConfiguration;
    };
}
export interface DeleteBridgeRequest {
    BridgeArn: string;
}
export interface DeleteBridgeResponse {
    BridgeArn?: string;
}
export interface DeleteFlowRequest {
    FlowArn: string;
}
export interface DeleteFlowResponse {
    FlowArn?: string;
    Status?: Status;
}
export type GatewayArn = string;
export interface DeleteGatewayRequest {
    GatewayArn: string;
}
export interface DeleteGatewayResponse {
    GatewayArn?: string;
}
export interface DeleteRouterInputRequest {
    Arn: string;
}
export interface DeleteRouterInputResponse {
    Arn: string;
    Name: string;
    State: RouterInputState;
}
export interface DeleteRouterNetworkInterfaceRequest {
    Arn: string;
}
export interface DeleteRouterNetworkInterfaceResponse {
    Arn: string;
    Name: string;
    State: RouterNetworkInterfaceState;
}
export interface DeleteRouterOutputRequest {
    Arn: string;
}
export interface DeleteRouterOutputResponse {
    Arn: string;
    Name: string;
    State: RouterOutputState;
}
export type GatewayInstanceArn = string;
export interface DeregisterGatewayInstanceRequest {
    Force?: boolean;
    GatewayInstanceArn: string;
}
export type InstanceState = "REGISTERING" | "ACTIVE" | "DEREGISTERING" | "DEREGISTERED" | "REGISTRATION_ERROR" | "DEREGISTRATION_ERROR" | (string & {});
export interface DeregisterGatewayInstanceResponse {
    GatewayInstanceArn?: string;
    InstanceState?: InstanceState;
}
export interface DescribeBridgeRequest {
    BridgeArn: string;
}
export interface DescribeBridgeResponse {
    Bridge?: Bridge & {
        BridgeArn: string;
        BridgeState: BridgeState;
        Name: string;
        PlacementArn: string;
        BridgeMessages: (MessageDetail & {
            Code: string;
            Message: string;
        })[];
        EgressGatewayBridge: EgressGatewayBridge & {
            MaxBitrate: number;
        };
        IngressGatewayBridge: IngressGatewayBridge & {
            MaxBitrate: number;
            MaxOutputs: number;
        };
        Outputs: (BridgeOutput & {
            FlowOutput: BridgeFlowOutput & {
                FlowArn: string;
                FlowSourceArn: string;
                Name: string;
            };
            NetworkOutput: BridgeNetworkOutput & {
                IpAddress: string;
                Name: string;
                NetworkName: string;
                Port: number;
                Protocol: Protocol;
                Ttl: number;
            };
        })[];
        Sources: (BridgeSource & {
            FlowSource: BridgeFlowSource & {
                FlowArn: string;
                Name: string;
            };
            NetworkSource: BridgeNetworkSource & {
                MulticastIp: string;
                Name: string;
                NetworkName: string;
                Port: number;
                Protocol: Protocol;
            };
        })[];
    };
}
export interface DescribeFlowRequest {
    FlowArn: string;
}
export interface Messages {
    Errors?: string[];
}
export interface DescribeFlowResponse {
    Flow?: Flow & {
        AvailabilityZone: string;
        Entitlements: (Entitlement & {
            EntitlementArn: string;
            Name: string;
            Subscribers: __listOfString;
            Encryption: Encryption & {
                RoleArn: string;
            };
        })[];
        FlowArn: string;
        Name: string;
        Outputs: (Output & {
            Name: string;
            OutputArn: string;
            Encryption: Encryption & {
                RoleArn: string;
            };
            MediaStreamOutputConfigurations: (MediaStreamOutputConfiguration & {
                EncodingName: EncodingName;
                MediaStreamName: string;
                DestinationConfigurations: (DestinationConfiguration & {
                    DestinationIp: string;
                    DestinationPort: number;
                    Interface: Interface & {
                        Name: string;
                    };
                    OutboundIp: string;
                })[];
                EncodingParameters: EncodingParameters & {
                    CompressionFactor: number;
                    EncoderProfile: EncoderProfile;
                };
            })[];
            Transport: Transport & {
                Protocol: Protocol;
            };
        })[];
        Source: Source & {
            Name: string;
            SourceArn: string;
            Decryption: Encryption & {
                RoleArn: string;
            };
            MediaStreamSourceConfigurations: (MediaStreamSourceConfiguration & {
                EncodingName: EncodingName;
                MediaStreamName: string;
                InputConfigurations: (InputConfiguration & {
                    InputIp: string;
                    InputPort: number;
                    Interface: Interface & {
                        Name: string;
                    };
                })[];
            })[];
            Transport: Transport & {
                Protocol: Protocol;
            };
            GatewayBridgeSource: GatewayBridgeSource & {
                BridgeArn: string;
            };
        };
        Status: Status;
        MediaStreams: (MediaStream & {
            Fmt: number;
            MediaStreamId: number;
            MediaStreamName: string;
            MediaStreamType: MediaStreamType;
            Attributes: MediaStreamAttributes & {
                Fmtp: Fmtp;
            };
        })[];
        Sources: (Source & {
            Name: string;
            SourceArn: string;
            Decryption: Encryption & {
                RoleArn: string;
            };
            MediaStreamSourceConfigurations: (MediaStreamSourceConfiguration & {
                EncodingName: EncodingName;
                MediaStreamName: string;
                InputConfigurations: (InputConfiguration & {
                    InputIp: string;
                    InputPort: number;
                    Interface: Interface & {
                        Name: string;
                    };
                })[];
            })[];
            Transport: Transport & {
                Protocol: Protocol;
            };
            GatewayBridgeSource: GatewayBridgeSource & {
                BridgeArn: string;
            };
        })[];
        VpcInterfaces: (VpcInterface & {
            Name: string;
            NetworkInterfaceIds: __listOfString;
            NetworkInterfaceType: NetworkInterfaceType;
            RoleArn: string;
            SecurityGroupIds: __listOfString;
            SubnetId: string;
        })[];
        NdiConfig: NdiConfig & {
            NdiDiscoveryServers: (NdiDiscoveryServerConfig & {
                DiscoveryServerAddress: string;
                VpcInterfaceAdapter: string;
            })[];
        };
    };
    Messages?: Messages & {
        Errors: __listOfString;
    };
}
export interface DescribeFlowSourceMetadataRequest {
    FlowArn: string;
}
export interface FrameResolution {
    FrameHeight?: number;
    FrameWidth?: number;
}
export interface TransportStream {
    Channels?: number;
    Codec?: string;
    FrameRate?: string;
    FrameResolution?: FrameResolution;
    Pid?: number;
    SampleRate?: number;
    SampleSize?: number;
    StreamType?: string;
}
export type __listOfTransportStream = TransportStream[];
export interface TransportStreamProgram {
    PcrPid?: number;
    ProgramName?: string;
    ProgramNumber?: number;
    ProgramPid?: number;
    Streams?: TransportStream[];
}
export type __listOfTransportStreamProgram = TransportStreamProgram[];
export interface TransportMediaInfo {
    Programs?: TransportStreamProgram[];
}
export interface NdiSourceInfo {
    SourceName?: string;
}
export type __listOfNdiSourceInfo = NdiSourceInfo[];
export interface NdiMediaStreamInfo {
    StreamType?: string;
    Codec?: string;
    StreamId?: number;
    ScanMode?: ScanMode;
    FrameResolution?: FrameResolution;
    FrameRate?: string;
    Channels?: number;
    SampleRate?: number;
}
export type __listOfNdiMediaStreamInfo = NdiMediaStreamInfo[];
export interface NdiMediaInfo {
    Streams?: NdiMediaStreamInfo[];
}
export interface NdiSourceMetadataInfo {
    ActiveSource?: NdiSourceInfo;
    DiscoveredSources?: NdiSourceInfo[];
    MediaInfo?: NdiMediaInfo;
    Messages?: MessageDetail[];
}
export interface DescribeFlowSourceMetadataResponse {
    FlowArn?: string;
    Messages?: (MessageDetail & {
        Code: string;
        Message: string;
    })[];
    Timestamp?: Date;
    TransportMediaInfo?: TransportMediaInfo & {
        Programs: (TransportStreamProgram & {
            PcrPid: number;
            ProgramNumber: number;
            ProgramPid: number;
            Streams: (TransportStream & {
                Pid: number;
                StreamType: string;
                FrameResolution: FrameResolution & {
                    FrameHeight: number;
                    FrameWidth: number;
                };
            })[];
        })[];
    };
    NdiInfo?: NdiSourceMetadataInfo & {
        DiscoveredSources: (NdiSourceInfo & {
            SourceName: string;
        })[];
        MediaInfo: NdiMediaInfo & {
            Streams: (NdiMediaStreamInfo & {
                StreamType: string;
                Codec: string;
                StreamId: number;
                FrameResolution: FrameResolution & {
                    FrameHeight: number;
                    FrameWidth: number;
                };
            })[];
        };
        Messages: (MessageDetail & {
            Code: string;
            Message: string;
        })[];
        ActiveSource: NdiSourceInfo & {
            SourceName: string;
        };
    };
}
export interface DescribeFlowSourceThumbnailRequest {
    FlowArn: string;
}
export interface ThumbnailDetails {
    FlowArn?: string;
    Thumbnail?: string;
    ThumbnailMessages?: MessageDetail[];
    Timecode?: string;
    Timestamp?: Date;
}
export interface DescribeFlowSourceThumbnailResponse {
    ThumbnailDetails?: ThumbnailDetails & {
        FlowArn: string;
        ThumbnailMessages: (MessageDetail & {
            Code: string;
            Message: string;
        })[];
    };
}
export interface DescribeGatewayRequest {
    GatewayArn: string;
}
export interface DescribeGatewayResponse {
    Gateway?: Gateway & {
        EgressCidrBlocks: __listOfString;
        GatewayArn: string;
        Name: string;
        Networks: (GatewayNetwork & {
            CidrBlock: string;
            Name: string;
        })[];
        GatewayMessages: (MessageDetail & {
            Code: string;
            Message: string;
        })[];
    };
}
export interface DescribeGatewayInstanceRequest {
    GatewayInstanceArn: string;
}
export type BridgePlacement = "AVAILABLE" | "LOCKED" | (string & {});
export type ConnectionStatus = "CONNECTED" | "DISCONNECTED" | (string & {});
export interface GatewayInstance {
    BridgePlacement?: BridgePlacement;
    ConnectionStatus?: ConnectionStatus;
    GatewayArn?: string;
    GatewayInstanceArn?: string;
    InstanceId?: string;
    InstanceMessages?: MessageDetail[];
    InstanceState?: InstanceState;
    RunningBridgeCount?: number;
}
export interface DescribeGatewayInstanceResponse {
    GatewayInstance?: GatewayInstance & {
        BridgePlacement: BridgePlacement;
        ConnectionStatus: ConnectionStatus;
        GatewayArn: string;
        GatewayInstanceArn: string;
        InstanceId: string;
        InstanceState: InstanceState;
        RunningBridgeCount: number;
        InstanceMessages: (MessageDetail & {
            Code: string;
            Message: string;
        })[];
    };
}
export type OfferingArn = string;
export interface DescribeOfferingRequest {
    OfferingArn: string;
}
export type DurationUnits = "MONTHS" | (string & {});
export type PriceUnits = "HOURLY" | (string & {});
export type ResourceType = "Mbps_Outbound_Bandwidth" | (string & {});
export interface ResourceSpecification {
    ReservedBitrate?: number;
    ResourceType?: ResourceType;
}
export interface Offering {
    CurrencyCode?: string;
    Duration?: number;
    DurationUnits?: DurationUnits;
    OfferingArn?: string;
    OfferingDescription?: string;
    PricePerUnit?: string;
    PriceUnits?: PriceUnits;
    ResourceSpecification?: ResourceSpecification;
}
export interface DescribeOfferingResponse {
    Offering?: Offering & {
        CurrencyCode: string;
        Duration: number;
        DurationUnits: DurationUnits;
        OfferingArn: string;
        OfferingDescription: string;
        PricePerUnit: string;
        PriceUnits: PriceUnits;
        ResourceSpecification: ResourceSpecification & {
            ResourceType: ResourceType;
        };
    };
}
export type ReservationArn = string;
export interface DescribeReservationRequest {
    ReservationArn: string;
}
export type ReservationState = "ACTIVE" | "EXPIRED" | "PROCESSING" | "CANCELED" | (string & {});
export interface Reservation {
    CurrencyCode?: string;
    Duration?: number;
    DurationUnits?: DurationUnits;
    End?: string;
    OfferingArn?: string;
    OfferingDescription?: string;
    PricePerUnit?: string;
    PriceUnits?: PriceUnits;
    ReservationArn?: string;
    ReservationName?: string;
    ReservationState?: ReservationState;
    ResourceSpecification?: ResourceSpecification;
    Start?: string;
}
export interface DescribeReservationResponse {
    Reservation?: Reservation & {
        CurrencyCode: string;
        Duration: number;
        DurationUnits: DurationUnits;
        End: string;
        OfferingArn: string;
        OfferingDescription: string;
        PricePerUnit: string;
        PriceUnits: PriceUnits;
        ReservationArn: string;
        ReservationName: string;
        ReservationState: ReservationState;
        ResourceSpecification: ResourceSpecification & {
            ResourceType: ResourceType;
        };
        Start: string;
    };
}
export interface GetRouterInputRequest {
    Arn: string;
}
export interface GetRouterInputResponse {
    RouterInput: RouterInput & {
        ContentQualityAnalysisType: RouterContentQualityAnalysisType;
        ContentQualityAnalysisConfiguration: RouterContentQualityAnalysisConfiguration;
    };
}
export interface GetRouterInputSourceMetadataRequest {
    Arn: string;
}
export type RouterInputMetadata = {
    TransportStreamMediaInfo: TransportMediaInfo;
};
export interface RouterInputSourceMetadataDetails {
    SourceMetadataMessages: RouterInputMessage[];
    Timestamp: Date;
    RouterInputMetadata?: RouterInputMetadata;
}
export interface GetRouterInputSourceMetadataResponse {
    Arn: string;
    Name: string;
    SourceMetadataDetails: RouterInputSourceMetadataDetails;
}
export interface GetRouterInputThumbnailRequest {
    Arn: string;
}
export interface RouterInputThumbnailDetails {
    ThumbnailMessages: RouterInputMessage[];
    Thumbnail?: Uint8Array;
    Timecode?: string;
    Timestamp?: Date;
}
export interface GetRouterInputThumbnailResponse {
    Arn: string;
    Name: string;
    ThumbnailDetails: RouterInputThumbnailDetails;
}
export interface GetRouterNetworkInterfaceRequest {
    Arn: string;
}
export interface GetRouterNetworkInterfaceResponse {
    RouterNetworkInterface: RouterNetworkInterface;
}
export interface GetRouterOutputRequest {
    Arn: string;
}
export interface GetRouterOutputResponse {
    RouterOutput: RouterOutput & {
        FabricConfiguration: FabricConfiguration;
    };
}
export interface GrantFlowEntitlementsRequest {
    Entitlements?: GrantEntitlementRequest[];
    FlowArn: string;
}
export interface GrantFlowEntitlementsResponse {
    Entitlements?: (Entitlement & {
        EntitlementArn: string;
        Name: string;
        Subscribers: __listOfString;
        Encryption: Encryption & {
            RoleArn: string;
        };
    })[];
    FlowArn?: string;
}
export type MaxResults = number;
export interface ListBridgesRequest {
    FilterArn?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface ListedBridge {
    BridgeArn?: string;
    BridgeState?: BridgeState;
    BridgeType?: string;
    Name?: string;
    PlacementArn?: string;
}
export type __listOfListedBridge = ListedBridge[];
export interface ListBridgesResponse {
    Bridges?: (ListedBridge & {
        BridgeArn: string;
        BridgeState: BridgeState;
        BridgeType: string;
        Name: string;
        PlacementArn: string;
    })[];
    NextToken?: string;
}
export interface ListEntitlementsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface ListedEntitlement {
    DataTransferSubscriberFeePercent?: number;
    EntitlementArn?: string;
    EntitlementName?: string;
}
export type __listOfListedEntitlement = ListedEntitlement[];
export interface ListEntitlementsResponse {
    Entitlements?: (ListedEntitlement & {
        EntitlementArn: string;
        EntitlementName: string;
    })[];
    NextToken?: string;
}
export interface ListFlowsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export type SourceType = "OWNED" | "ENTITLED" | (string & {});
export interface ListedFlow {
    AvailabilityZone?: string;
    Description?: string;
    FlowArn?: string;
    Name?: string;
    SourceType?: SourceType;
    Status?: Status;
    Maintenance?: Maintenance;
}
export type __listOfListedFlow = ListedFlow[];
export interface ListFlowsResponse {
    Flows?: (ListedFlow & {
        AvailabilityZone: string;
        Description: string;
        FlowArn: string;
        Name: string;
        SourceType: SourceType;
        Status: Status;
    })[];
    NextToken?: string;
}
export interface ListGatewayInstancesRequest {
    FilterArn?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface ListedGatewayInstance {
    GatewayArn?: string;
    GatewayInstanceArn?: string;
    InstanceId?: string;
    InstanceState?: InstanceState;
}
export type __listOfListedGatewayInstance = ListedGatewayInstance[];
export interface ListGatewayInstancesResponse {
    Instances?: (ListedGatewayInstance & {
        GatewayArn: string;
        GatewayInstanceArn: string;
        InstanceId: string;
    })[];
    NextToken?: string;
}
export interface ListGatewaysRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface ListedGateway {
    GatewayArn?: string;
    GatewayState?: GatewayState;
    Name?: string;
}
export type __listOfListedGateway = ListedGateway[];
export interface ListGatewaysResponse {
    Gateways?: (ListedGateway & {
        GatewayArn: string;
        GatewayState: GatewayState;
        Name: string;
    })[];
    NextToken?: string;
}
export interface ListOfferingsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export type __listOfOffering = Offering[];
export interface ListOfferingsResponse {
    NextToken?: string;
    Offerings?: (Offering & {
        CurrencyCode: string;
        Duration: number;
        DurationUnits: DurationUnits;
        OfferingArn: string;
        OfferingDescription: string;
        PricePerUnit: string;
        PriceUnits: PriceUnits;
        ResourceSpecification: ResourceSpecification & {
            ResourceType: ResourceType;
        };
    })[];
}
export interface ListReservationsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export type __listOfReservation = Reservation[];
export interface ListReservationsResponse {
    NextToken?: string;
    Reservations?: (Reservation & {
        CurrencyCode: string;
        Duration: number;
        DurationUnits: DurationUnits;
        End: string;
        OfferingArn: string;
        OfferingDescription: string;
        PricePerUnit: string;
        PriceUnits: PriceUnits;
        ReservationArn: string;
        ReservationName: string;
        ReservationState: ReservationState;
        ResourceSpecification: ResourceSpecification & {
            ResourceType: ResourceType;
        };
        Start: string;
    })[];
}
export type StringList = string[];
export type RoutingScopeList = RoutingScope[];
export type RouterInputTypeList = RouterInputType[];
export type RouterInputFilter = {
    NameContains: string[];
    RegionNames?: never;
    NetworkInterfaceArns?: never;
    RoutingScopes?: never;
    InputTypes?: never;
} | {
    NameContains?: never;
    RegionNames: string[];
    NetworkInterfaceArns?: never;
    RoutingScopes?: never;
    InputTypes?: never;
} | {
    NameContains?: never;
    RegionNames?: never;
    NetworkInterfaceArns: string[];
    RoutingScopes?: never;
    InputTypes?: never;
} | {
    NameContains?: never;
    RegionNames?: never;
    NetworkInterfaceArns?: never;
    RoutingScopes: RoutingScope[];
    InputTypes?: never;
} | {
    NameContains?: never;
    RegionNames?: never;
    NetworkInterfaceArns?: never;
    RoutingScopes?: never;
    InputTypes: RouterInputType[];
};
export type RouterInputFilterList = RouterInputFilter[];
export interface ListRouterInputsRequest {
    MaxResults?: number;
    NextToken?: string;
    Filters?: RouterInputFilter[];
}
export interface ListedRouterInput {
    Name: string;
    Arn: string;
    Id: string;
    InputType: RouterInputType;
    State: RouterInputState;
    RoutedOutputs: number;
    RegionName: string;
    AvailabilityZone: string;
    MaximumBitrate: number;
    RoutingScope: RoutingScope;
    CreatedAt: Date;
    UpdatedAt: Date;
    MessageCount: number;
    NetworkInterfaceArn?: string;
    MaintenanceScheduleType?: MaintenanceScheduleType;
    MaintenanceSchedule?: MaintenanceSchedule;
}
export type ListedRouterInputList = ListedRouterInput[];
export interface ListRouterInputsResponse {
    RouterInputs: ListedRouterInput[];
    NextToken?: string;
}
export type RouterNetworkInterfaceTypeList = RouterNetworkInterfaceType[];
export type RouterNetworkInterfaceFilter = {
    RegionNames: string[];
    NetworkInterfaceTypes?: never;
    NameContains?: never;
} | {
    RegionNames?: never;
    NetworkInterfaceTypes: RouterNetworkInterfaceType[];
    NameContains?: never;
} | {
    RegionNames?: never;
    NetworkInterfaceTypes?: never;
    NameContains: string[];
};
export type RouterNetworkInterfaceFilterList = RouterNetworkInterfaceFilter[];
export interface ListRouterNetworkInterfacesRequest {
    MaxResults?: number;
    NextToken?: string;
    Filters?: RouterNetworkInterfaceFilter[];
}
export interface ListedRouterNetworkInterface {
    Name: string;
    Arn: string;
    Id: string;
    NetworkInterfaceType: RouterNetworkInterfaceType;
    AssociatedOutputCount: number;
    AssociatedInputCount: number;
    State: RouterNetworkInterfaceState;
    RegionName: string;
    CreatedAt: Date;
    UpdatedAt: Date;
}
export type ListedRouterNetworkInterfaceList = ListedRouterNetworkInterface[];
export interface ListRouterNetworkInterfacesResponse {
    RouterNetworkInterfaces: ListedRouterNetworkInterface[];
    NextToken?: string;
}
export type RouterOutputTypeList = RouterOutputType[];
export type RouterOutputFilter = {
    RegionNames: string[];
    NetworkInterfaceArns?: never;
    RoutingScopes?: never;
    OutputTypes?: never;
    RoutedInputArns?: never;
    NameContains?: never;
} | {
    RegionNames?: never;
    NetworkInterfaceArns: string[];
    RoutingScopes?: never;
    OutputTypes?: never;
    RoutedInputArns?: never;
    NameContains?: never;
} | {
    RegionNames?: never;
    NetworkInterfaceArns?: never;
    RoutingScopes: RoutingScope[];
    OutputTypes?: never;
    RoutedInputArns?: never;
    NameContains?: never;
} | {
    RegionNames?: never;
    NetworkInterfaceArns?: never;
    RoutingScopes?: never;
    OutputTypes: RouterOutputType[];
    RoutedInputArns?: never;
    NameContains?: never;
} | {
    RegionNames?: never;
    NetworkInterfaceArns?: never;
    RoutingScopes?: never;
    OutputTypes?: never;
    RoutedInputArns: string[];
    NameContains?: never;
} | {
    RegionNames?: never;
    NetworkInterfaceArns?: never;
    RoutingScopes?: never;
    OutputTypes?: never;
    RoutedInputArns?: never;
    NameContains: string[];
};
export type RouterOutputFilterList = RouterOutputFilter[];
export interface ListRouterOutputsRequest {
    MaxResults?: number;
    NextToken?: string;
    Filters?: RouterOutputFilter[];
}
export interface ListedRouterOutput {
    Name: string;
    Arn: string;
    Id: string;
    OutputType: RouterOutputType;
    State: RouterOutputState;
    RoutedState: RouterOutputRoutedState;
    RegionName: string;
    AvailabilityZone: string;
    MaximumBitrate: number;
    RoutingScope: RoutingScope;
    CreatedAt: Date;
    UpdatedAt: Date;
    MessageCount: number;
    RoutedInputArn?: string;
    NetworkInterfaceArn?: string;
    MaintenanceScheduleType?: MaintenanceScheduleType;
    MaintenanceSchedule?: MaintenanceSchedule;
}
export type ListedRouterOutputList = ListedRouterOutput[];
export interface ListRouterOutputsResponse {
    RouterOutputs: ListedRouterOutput[];
    NextToken?: string;
}
export interface ListTagsForGlobalResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForGlobalResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface PurchaseOfferingRequest {
    OfferingArn: string;
    ReservationName?: string;
    Start?: string;
}
export interface PurchaseOfferingResponse {
    Reservation?: Reservation & {
        CurrencyCode: string;
        Duration: number;
        DurationUnits: DurationUnits;
        End: string;
        OfferingArn: string;
        OfferingDescription: string;
        PricePerUnit: string;
        PriceUnits: PriceUnits;
        ReservationArn: string;
        ReservationName: string;
        ReservationState: ReservationState;
        ResourceSpecification: ResourceSpecification & {
            ResourceType: ResourceType;
        };
        Start: string;
    };
}
export interface RemoveBridgeOutputRequest {
    BridgeArn: string;
    OutputName: string;
}
export interface RemoveBridgeOutputResponse {
    BridgeArn?: string;
    OutputName?: string;
}
export interface RemoveBridgeSourceRequest {
    BridgeArn: string;
    SourceName: string;
}
export interface RemoveBridgeSourceResponse {
    BridgeArn?: string;
    SourceName?: string;
}
export interface RemoveFlowMediaStreamRequest {
    FlowArn: string;
    MediaStreamName: string;
}
export interface RemoveFlowMediaStreamResponse {
    FlowArn?: string;
    MediaStreamName?: string;
}
export interface RemoveFlowOutputRequest {
    FlowArn: string;
    OutputArn: string;
}
export interface RemoveFlowOutputResponse {
    FlowArn?: string;
    OutputArn?: string;
}
export interface RemoveFlowSourceRequest {
    FlowArn: string;
    SourceArn: string;
}
export interface RemoveFlowSourceResponse {
    FlowArn?: string;
    SourceArn?: string;
}
export interface RemoveFlowVpcInterfaceRequest {
    FlowArn: string;
    VpcInterfaceName: string;
}
export interface RemoveFlowVpcInterfaceResponse {
    FlowArn?: string;
    NonDeletedNetworkInterfaceIds?: string[];
    VpcInterfaceName?: string;
}
export interface RestartRouterInputRequest {
    Arn: string;
}
export interface RestartRouterInputResponse {
    Arn: string;
    Name: string;
    State: RouterInputState;
}
export interface RestartRouterOutputRequest {
    Arn: string;
}
export interface RestartRouterOutputResponse {
    Arn: string;
    Name: string;
    State: RouterOutputState;
}
export interface RevokeFlowEntitlementRequest {
    EntitlementArn: string;
    FlowArn: string;
}
export interface RevokeFlowEntitlementResponse {
    EntitlementArn?: string;
    FlowArn?: string;
}
export interface StartFlowRequest {
    FlowArn: string;
}
export interface StartFlowResponse {
    FlowArn?: string;
    Status?: Status;
}
export interface StartRouterInputRequest {
    Arn: string;
}
export interface StartRouterInputResponse {
    Arn: string;
    Name: string;
    State: RouterInputState;
    MaintenanceScheduleType: MaintenanceScheduleType;
    MaintenanceSchedule: MaintenanceSchedule;
}
export interface StartRouterOutputRequest {
    Arn: string;
}
export interface StartRouterOutputResponse {
    Arn: string;
    Name: string;
    State: RouterOutputState;
    MaintenanceScheduleType: MaintenanceScheduleType;
    MaintenanceSchedule: MaintenanceSchedule;
}
export interface StopFlowRequest {
    FlowArn: string;
}
export interface StopFlowResponse {
    FlowArn?: string;
    Status?: Status;
}
export interface StopRouterInputRequest {
    Arn: string;
}
export interface StopRouterInputResponse {
    Arn: string;
    Name: string;
    State: RouterInputState;
}
export interface StopRouterOutputRequest {
    Arn: string;
}
export interface StopRouterOutputResponse {
    Arn: string;
    Name: string;
    State: RouterOutputState;
}
export interface TagGlobalResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface TagGlobalResourceResponse {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export interface TakeRouterInputRequest {
    RouterOutputArn: string;
    RouterInputArn?: string;
}
export interface TakeRouterInputResponse {
    RoutedState: RouterOutputRoutedState;
    RouterOutputArn: string;
    RouterOutputName: string;
    RouterInputArn?: string;
    RouterInputName?: string;
}
export interface UntagGlobalResourceRequest {
    ResourceArn: string;
    TagKeys?: string[];
}
export interface UntagGlobalResourceResponse {
}
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateEgressGatewayBridgeRequest {
    MaxBitrate?: number;
}
export interface UpdateIngressGatewayBridgeRequest {
    MaxBitrate?: number;
    MaxOutputs?: number;
}
export interface UpdateFailoverConfig {
    FailoverMode?: FailoverMode;
    RecoveryWindow?: number;
    SourcePriority?: SourcePriority;
    State?: State;
}
export interface UpdateBridgeRequest {
    BridgeArn: string;
    EgressGatewayBridge?: UpdateEgressGatewayBridgeRequest;
    IngressGatewayBridge?: UpdateIngressGatewayBridgeRequest;
    SourceFailoverConfig?: UpdateFailoverConfig;
}
export interface UpdateBridgeResponse {
    Bridge?: Bridge & {
        BridgeArn: string;
        BridgeState: BridgeState;
        Name: string;
        PlacementArn: string;
        BridgeMessages: (MessageDetail & {
            Code: string;
            Message: string;
        })[];
        EgressGatewayBridge: EgressGatewayBridge & {
            MaxBitrate: number;
        };
        IngressGatewayBridge: IngressGatewayBridge & {
            MaxBitrate: number;
            MaxOutputs: number;
        };
        Outputs: (BridgeOutput & {
            FlowOutput: BridgeFlowOutput & {
                FlowArn: string;
                FlowSourceArn: string;
                Name: string;
            };
            NetworkOutput: BridgeNetworkOutput & {
                IpAddress: string;
                Name: string;
                NetworkName: string;
                Port: number;
                Protocol: Protocol;
                Ttl: number;
            };
        })[];
        Sources: (BridgeSource & {
            FlowSource: BridgeFlowSource & {
                FlowArn: string;
                Name: string;
            };
            NetworkSource: BridgeNetworkSource & {
                MulticastIp: string;
                Name: string;
                NetworkName: string;
                Port: number;
                Protocol: Protocol;
            };
        })[];
    };
}
export interface UpdateBridgeNetworkOutputRequest {
    IpAddress?: string;
    NetworkName?: string;
    Port?: number;
    Protocol?: Protocol;
    Ttl?: number;
}
export interface UpdateBridgeOutputRequest {
    BridgeArn: string;
    NetworkOutput?: UpdateBridgeNetworkOutputRequest;
    OutputName: string;
}
export interface UpdateBridgeOutputResponse {
    BridgeArn?: string;
    Output?: BridgeOutput & {
        FlowOutput: BridgeFlowOutput & {
            FlowArn: string;
            FlowSourceArn: string;
            Name: string;
        };
        NetworkOutput: BridgeNetworkOutput & {
            IpAddress: string;
            Name: string;
            NetworkName: string;
            Port: number;
            Protocol: Protocol;
            Ttl: number;
        };
    };
}
export interface UpdateBridgeFlowSourceRequest {
    FlowArn?: string;
    FlowVpcInterfaceAttachment?: VpcInterfaceAttachment;
}
export interface UpdateBridgeNetworkSourceRequest {
    MulticastIp?: string;
    MulticastSourceSettings?: MulticastSourceSettings;
    NetworkName?: string;
    Port?: number;
    Protocol?: Protocol;
}
export interface UpdateBridgeSourceRequest {
    BridgeArn: string;
    FlowSource?: UpdateBridgeFlowSourceRequest;
    NetworkSource?: UpdateBridgeNetworkSourceRequest;
    SourceName: string;
}
export interface UpdateBridgeSourceResponse {
    BridgeArn?: string;
    Source?: BridgeSource & {
        FlowSource: BridgeFlowSource & {
            FlowArn: string;
            Name: string;
        };
        NetworkSource: BridgeNetworkSource & {
            MulticastIp: string;
            Name: string;
            NetworkName: string;
            Port: number;
            Protocol: Protocol;
        };
    };
}
export type DesiredState = "ACTIVE" | "STANDBY" | "DELETED" | (string & {});
export interface UpdateBridgeStateRequest {
    BridgeArn: string;
    DesiredState?: DesiredState;
}
export interface UpdateBridgeStateResponse {
    BridgeArn?: string;
    DesiredState?: DesiredState;
}
export interface UpdateMaintenance {
    MaintenanceDay?: MaintenanceDay;
    MaintenanceScheduledDate?: string;
    MaintenanceStartHour?: string;
}
export interface UpdateFlowRequest {
    FlowArn: string;
    SourceFailoverConfig?: UpdateFailoverConfig;
    Maintenance?: UpdateMaintenance;
    SourceMonitoringConfig?: MonitoringConfig;
    NdiConfig?: NdiConfig;
    FlowSize?: FlowSize;
    EncodingConfig?: EncodingConfig;
}
export interface UpdateFlowResponse {
    Flow?: Flow & {
        AvailabilityZone: string;
        Entitlements: (Entitlement & {
            EntitlementArn: string;
            Name: string;
            Subscribers: __listOfString;
            Encryption: Encryption & {
                RoleArn: string;
            };
        })[];
        FlowArn: string;
        Name: string;
        Outputs: (Output & {
            Name: string;
            OutputArn: string;
            Encryption: Encryption & {
                RoleArn: string;
            };
            MediaStreamOutputConfigurations: (MediaStreamOutputConfiguration & {
                EncodingName: EncodingName;
                MediaStreamName: string;
                DestinationConfigurations: (DestinationConfiguration & {
                    DestinationIp: string;
                    DestinationPort: number;
                    Interface: Interface & {
                        Name: string;
                    };
                    OutboundIp: string;
                })[];
                EncodingParameters: EncodingParameters & {
                    CompressionFactor: number;
                    EncoderProfile: EncoderProfile;
                };
            })[];
            Transport: Transport & {
                Protocol: Protocol;
            };
        })[];
        Source: Source & {
            Name: string;
            SourceArn: string;
            Decryption: Encryption & {
                RoleArn: string;
            };
            MediaStreamSourceConfigurations: (MediaStreamSourceConfiguration & {
                EncodingName: EncodingName;
                MediaStreamName: string;
                InputConfigurations: (InputConfiguration & {
                    InputIp: string;
                    InputPort: number;
                    Interface: Interface & {
                        Name: string;
                    };
                })[];
            })[];
            Transport: Transport & {
                Protocol: Protocol;
            };
            GatewayBridgeSource: GatewayBridgeSource & {
                BridgeArn: string;
            };
        };
        Status: Status;
        MediaStreams: (MediaStream & {
            Fmt: number;
            MediaStreamId: number;
            MediaStreamName: string;
            MediaStreamType: MediaStreamType;
            Attributes: MediaStreamAttributes & {
                Fmtp: Fmtp;
            };
        })[];
        Sources: (Source & {
            Name: string;
            SourceArn: string;
            Decryption: Encryption & {
                RoleArn: string;
            };
            MediaStreamSourceConfigurations: (MediaStreamSourceConfiguration & {
                EncodingName: EncodingName;
                MediaStreamName: string;
                InputConfigurations: (InputConfiguration & {
                    InputIp: string;
                    InputPort: number;
                    Interface: Interface & {
                        Name: string;
                    };
                })[];
            })[];
            Transport: Transport & {
                Protocol: Protocol;
            };
            GatewayBridgeSource: GatewayBridgeSource & {
                BridgeArn: string;
            };
        })[];
        VpcInterfaces: (VpcInterface & {
            Name: string;
            NetworkInterfaceIds: __listOfString;
            NetworkInterfaceType: NetworkInterfaceType;
            RoleArn: string;
            SecurityGroupIds: __listOfString;
            SubnetId: string;
        })[];
        NdiConfig: NdiConfig & {
            NdiDiscoveryServers: (NdiDiscoveryServerConfig & {
                DiscoveryServerAddress: string;
                VpcInterfaceAdapter: string;
            })[];
        };
    };
}
export interface UpdateEncryption {
    Algorithm?: Algorithm;
    ConstantInitializationVector?: string;
    DeviceId?: string;
    KeyType?: KeyType;
    Region?: string;
    ResourceId?: string;
    RoleArn?: string;
    SecretArn?: string;
    Url?: string;
}
export interface UpdateFlowEntitlementRequest {
    Description?: string;
    Encryption?: UpdateEncryption;
    EntitlementArn: string;
    EntitlementStatus?: EntitlementStatus;
    FlowArn: string;
    Subscribers?: string[];
}
export interface UpdateFlowEntitlementResponse {
    Entitlement?: Entitlement & {
        EntitlementArn: string;
        Name: string;
        Subscribers: __listOfString;
        Encryption: Encryption & {
            RoleArn: string;
        };
    };
    FlowArn?: string;
}
export interface UpdateFlowMediaStreamRequest {
    Attributes?: MediaStreamAttributesRequest;
    ClockRate?: number;
    Description?: string;
    FlowArn: string;
    MediaStreamName: string;
    MediaStreamType?: MediaStreamType;
    VideoFormat?: string;
}
export interface UpdateFlowMediaStreamResponse {
    FlowArn?: string;
    MediaStream?: MediaStream & {
        Fmt: number;
        MediaStreamId: number;
        MediaStreamName: string;
        MediaStreamType: MediaStreamType;
        Attributes: MediaStreamAttributes & {
            Fmtp: Fmtp;
        };
    };
}
export interface UpdateFlowOutputRequest {
    CidrAllowList?: string[];
    Description?: string;
    Destination?: string;
    Encryption?: UpdateEncryption;
    FlowArn: string;
    MaxLatency?: number;
    MediaStreamOutputConfigurations?: MediaStreamOutputConfigurationRequest[];
    MinLatency?: number;
    OutputArn: string;
    Port?: number;
    Protocol?: Protocol;
    RemoteId?: string;
    SenderControlPort?: number;
    SenderIpAddress?: string;
    SmoothingLatency?: number;
    StreamId?: string;
    VpcInterfaceAttachment?: VpcInterfaceAttachment;
    OutputStatus?: OutputStatus;
    NdiProgramName?: string;
    NdiSpeedHqQuality?: number;
    RouterIntegrationState?: State;
    RouterIntegrationTransitEncryption?: FlowTransitEncryption;
    NdiOutputTimecodeSource?: NdiOutputTimecodeSource;
}
export interface UpdateFlowOutputResponse {
    FlowArn?: string;
    Output?: Output & {
        Name: string;
        OutputArn: string;
        Encryption: Encryption & {
            RoleArn: string;
        };
        MediaStreamOutputConfigurations: (MediaStreamOutputConfiguration & {
            EncodingName: EncodingName;
            MediaStreamName: string;
            DestinationConfigurations: (DestinationConfiguration & {
                DestinationIp: string;
                DestinationPort: number;
                Interface: Interface & {
                    Name: string;
                };
                OutboundIp: string;
            })[];
            EncodingParameters: EncodingParameters & {
                CompressionFactor: number;
                EncoderProfile: EncoderProfile;
            };
        })[];
        Transport: Transport & {
            Protocol: Protocol;
        };
    };
}
export interface UpdateGatewayBridgeSourceRequest {
    BridgeArn?: string;
    VpcInterfaceAttachment?: VpcInterfaceAttachment;
}
export interface UpdateFlowSourceRequest {
    Decryption?: UpdateEncryption;
    Description?: string;
    EntitlementArn?: string;
    FlowArn: string;
    IngestPort?: number;
    MaxBitrate?: number;
    MaxLatency?: number;
    MaxSyncBuffer?: number;
    MediaStreamSourceConfigurations?: MediaStreamSourceConfigurationRequest[];
    MinLatency?: number;
    Protocol?: Protocol;
    SenderControlPort?: number;
    SenderIpAddress?: string;
    SourceArn: string;
    SourceListenerAddress?: string;
    SourceListenerPort?: number;
    StreamId?: string;
    VpcInterfaceName?: string;
    WhitelistCidr?: string;
    GatewayBridgeSource?: UpdateGatewayBridgeSourceRequest;
    NdiSourceSettings?: NdiSourceSettings;
    RouterIntegrationState?: State;
    RouterIntegrationTransitDecryption?: FlowTransitEncryption;
}
export interface UpdateFlowSourceResponse {
    FlowArn?: string;
    Source?: Source & {
        Name: string;
        SourceArn: string;
        Decryption: Encryption & {
            RoleArn: string;
        };
        MediaStreamSourceConfigurations: (MediaStreamSourceConfiguration & {
            EncodingName: EncodingName;
            MediaStreamName: string;
            InputConfigurations: (InputConfiguration & {
                InputIp: string;
                InputPort: number;
                Interface: Interface & {
                    Name: string;
                };
            })[];
        })[];
        Transport: Transport & {
            Protocol: Protocol;
        };
        GatewayBridgeSource: GatewayBridgeSource & {
            BridgeArn: string;
        };
    };
}
export interface UpdateGatewayInstanceRequest {
    BridgePlacement?: BridgePlacement;
    GatewayInstanceArn: string;
}
export interface UpdateGatewayInstanceResponse {
    BridgePlacement?: BridgePlacement;
    GatewayInstanceArn?: string;
}
export interface UpdateRouterInputRequest {
    Arn: string;
    Name?: string;
    Configuration?: RouterInputConfiguration;
    MaximumBitrate?: number;
    RoutingScope?: RoutingScope;
    Tier?: RouterInputTier;
    TransitEncryption?: RouterInputTransitEncryption;
    MaintenanceConfiguration?: MaintenanceConfiguration;
    ContentQualityAnalysisConfiguration?: RouterContentQualityAnalysisConfiguration;
}
export interface UpdateRouterInputResponse {
    RouterInput: RouterInput & {
        ContentQualityAnalysisType: RouterContentQualityAnalysisType;
        ContentQualityAnalysisConfiguration: RouterContentQualityAnalysisConfiguration;
    };
}
export interface UpdateRouterNetworkInterfaceRequest {
    Arn: string;
    Name?: string;
    Configuration?: RouterNetworkInterfaceConfiguration;
}
export interface UpdateRouterNetworkInterfaceResponse {
    RouterNetworkInterface: RouterNetworkInterface;
}
export interface UpdateRouterOutputRequest {
    Arn: string;
    Name?: string;
    Configuration?: RouterOutputConfiguration;
    MaximumBitrate?: number;
    RoutingScope?: RoutingScope;
    Tier?: RouterOutputTier;
    MaintenanceConfiguration?: MaintenanceConfiguration;
    FabricConfiguration?: FabricConfiguration;
}
export interface UpdateRouterOutputResponse {
    RouterOutput: RouterOutput & {
        FabricConfiguration: FabricConfiguration;
    };
}
export type AddBridgeOutputsError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Adds outputs to an existing bridge.
 */
export declare const addBridgeOutputs: API.OperationMethod<AddBridgeOutputsRequest, AddBridgeOutputsResponse, AddBridgeOutputsError, Credentials | HttpClient.HttpClient>;
export type AddBridgeSourcesError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Adds sources to an existing bridge.
 */
export declare const addBridgeSources: API.OperationMethod<AddBridgeSourcesRequest, AddBridgeSourcesResponse, AddBridgeSourcesError, Credentials | HttpClient.HttpClient>;
export type AddFlowMediaStreamsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Adds media streams to an existing flow. After you add a media stream to a flow, you can associate it with a source and/or an output that uses the ST 2110 JPEG XS or CDI protocol.
 */
export declare const addFlowMediaStreams: API.OperationMethod<AddFlowMediaStreamsRequest, AddFlowMediaStreamsResponse, AddFlowMediaStreamsError, Credentials | HttpClient.HttpClient>;
export type AddFlowOutputsError = AddFlowOutputs420Exception | BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Adds outputs to an existing flow. You can create up to 50 outputs per flow.
 */
export declare const addFlowOutputs: API.OperationMethod<AddFlowOutputsRequest, AddFlowOutputsResponse, AddFlowOutputsError, Credentials | HttpClient.HttpClient>;
export type AddFlowSourcesError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Adds sources to a flow.
 */
export declare const addFlowSources: API.OperationMethod<AddFlowSourcesRequest, AddFlowSourcesResponse, AddFlowSourcesError, Credentials | HttpClient.HttpClient>;
export type AddFlowVpcInterfacesError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Adds VPC interfaces to a flow.
 */
export declare const addFlowVpcInterfaces: API.OperationMethod<AddFlowVpcInterfacesRequest, AddFlowVpcInterfacesResponse, AddFlowVpcInterfacesError, Credentials | HttpClient.HttpClient>;
export type BatchGetRouterInputError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about multiple router inputs in AWS Elemental MediaConnect.
 */
export declare const batchGetRouterInput: API.OperationMethod<BatchGetRouterInputRequest, BatchGetRouterInputResponse, BatchGetRouterInputError, Credentials | HttpClient.HttpClient>;
export type BatchGetRouterNetworkInterfaceError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about multiple router network interfaces in AWS Elemental MediaConnect.
 */
export declare const batchGetRouterNetworkInterface: API.OperationMethod<BatchGetRouterNetworkInterfaceRequest, BatchGetRouterNetworkInterfaceResponse, BatchGetRouterNetworkInterfaceError, Credentials | HttpClient.HttpClient>;
export type BatchGetRouterOutputError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about multiple router outputs in AWS Elemental MediaConnect.
 */
export declare const batchGetRouterOutput: API.OperationMethod<BatchGetRouterOutputRequest, BatchGetRouterOutputResponse, BatchGetRouterOutputError, Credentials | HttpClient.HttpClient>;
export type CreateBridgeError = BadRequestException | ConflictException | CreateBridge420Exception | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new bridge. The request must include one source.
 */
export declare const createBridge: API.OperationMethod<CreateBridgeRequest, CreateBridgeResponse, CreateBridgeError, Credentials | HttpClient.HttpClient>;
export type CreateFlowError = BadRequestException | CreateFlow420Exception | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new flow. The request must include one source. The request optionally can include outputs (up to 50) and entitlements (up to 50).
 */
export declare const createFlow: API.OperationMethod<CreateFlowRequest, CreateFlowResponse, CreateFlowError, Credentials | HttpClient.HttpClient>;
export type CreateGatewayError = BadRequestException | ConflictException | CreateGateway420Exception | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new gateway. The request must include at least one network (up to four).
 */
export declare const createGateway: API.OperationMethod<CreateGatewayRequest, CreateGatewayResponse, CreateGatewayError, Credentials | HttpClient.HttpClient>;
export type CreateRouterInputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | RouterInputServiceQuotaExceededException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new router input in AWS Elemental MediaConnect.
 */
export declare const createRouterInput: API.OperationMethod<CreateRouterInputRequest, CreateRouterInputResponse, CreateRouterInputError, Credentials | HttpClient.HttpClient>;
export type CreateRouterNetworkInterfaceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | RouterNetworkInterfaceServiceQuotaExceededException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new router network interface in AWS Elemental MediaConnect.
 */
export declare const createRouterNetworkInterface: API.OperationMethod<CreateRouterNetworkInterfaceRequest, CreateRouterNetworkInterfaceResponse, CreateRouterNetworkInterfaceError, Credentials | HttpClient.HttpClient>;
export type CreateRouterOutputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | RouterOutputServiceQuotaExceededException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new router output in AWS Elemental MediaConnect.
 */
export declare const createRouterOutput: API.OperationMethod<CreateRouterOutputRequest, CreateRouterOutputResponse, CreateRouterOutputError, Credentials | HttpClient.HttpClient>;
export type DeleteBridgeError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a bridge. Before you can delete a bridge, you must stop the bridge.
 */
export declare const deleteBridge: API.OperationMethod<DeleteBridgeRequest, DeleteBridgeResponse, DeleteBridgeError, Credentials | HttpClient.HttpClient>;
export type DeleteFlowError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a flow. Before you can delete a flow, you must stop the flow.
 */
export declare const deleteFlow: API.OperationMethod<DeleteFlowRequest, DeleteFlowResponse, DeleteFlowError, Credentials | HttpClient.HttpClient>;
export type DeleteGatewayError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a gateway. Before you can delete a gateway, you must deregister its instances and delete its bridges.
 */
export declare const deleteGateway: API.OperationMethod<DeleteGatewayRequest, DeleteGatewayResponse, DeleteGatewayError, Credentials | HttpClient.HttpClient>;
export type DeleteRouterInputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a router input from AWS Elemental MediaConnect.
 */
export declare const deleteRouterInput: API.OperationMethod<DeleteRouterInputRequest, DeleteRouterInputResponse, DeleteRouterInputError, Credentials | HttpClient.HttpClient>;
export type DeleteRouterNetworkInterfaceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a router network interface from AWS Elemental MediaConnect.
 */
export declare const deleteRouterNetworkInterface: API.OperationMethod<DeleteRouterNetworkInterfaceRequest, DeleteRouterNetworkInterfaceResponse, DeleteRouterNetworkInterfaceError, Credentials | HttpClient.HttpClient>;
export type DeleteRouterOutputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a router output from AWS Elemental MediaConnect.
 */
export declare const deleteRouterOutput: API.OperationMethod<DeleteRouterOutputRequest, DeleteRouterOutputResponse, DeleteRouterOutputError, Credentials | HttpClient.HttpClient>;
export type DeregisterGatewayInstanceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deregisters an instance. Before you deregister an instance, all bridges running on the instance must be stopped. If you want to deregister an instance without stopping the bridges, you must use the --force option.
 */
export declare const deregisterGatewayInstance: API.OperationMethod<DeregisterGatewayInstanceRequest, DeregisterGatewayInstanceResponse, DeregisterGatewayInstanceError, Credentials | HttpClient.HttpClient>;
export type DescribeBridgeError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays the details of a bridge.
 */
export declare const describeBridge: API.OperationMethod<DescribeBridgeRequest, DescribeBridgeResponse, DescribeBridgeError, Credentials | HttpClient.HttpClient>;
export type DescribeFlowError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays the details of a flow. The response includes the flow Amazon Resource Name (ARN), name, and Availability Zone, as well as details about the source, outputs, and entitlements.
 */
export declare const describeFlow: API.OperationMethod<DescribeFlowRequest, DescribeFlowResponse, DescribeFlowError, Credentials | HttpClient.HttpClient>;
export type DescribeFlowSourceMetadataError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * The `DescribeFlowSourceMetadata` API is used to view information about the flow's source transport stream and programs. This API displays status messages about the flow's source as well as details about the program's video, audio, and other data.
 */
export declare const describeFlowSourceMetadata: API.OperationMethod<DescribeFlowSourceMetadataRequest, DescribeFlowSourceMetadataResponse, DescribeFlowSourceMetadataError, Credentials | HttpClient.HttpClient>;
export type DescribeFlowSourceThumbnailError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Describes the thumbnail for the flow source.
 */
export declare const describeFlowSourceThumbnail: API.OperationMethod<DescribeFlowSourceThumbnailRequest, DescribeFlowSourceThumbnailResponse, DescribeFlowSourceThumbnailError, Credentials | HttpClient.HttpClient>;
export type DescribeGatewayError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays the details of a gateway. The response includes the gateway Amazon Resource Name (ARN), name, and CIDR blocks, as well as details about the networks.
 */
export declare const describeGateway: API.OperationMethod<DescribeGatewayRequest, DescribeGatewayResponse, DescribeGatewayError, Credentials | HttpClient.HttpClient>;
export type DescribeGatewayInstanceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays the details of an instance.
 */
export declare const describeGatewayInstance: API.OperationMethod<DescribeGatewayInstanceRequest, DescribeGatewayInstanceResponse, DescribeGatewayInstanceError, Credentials | HttpClient.HttpClient>;
export type DescribeOfferingError = BadRequestException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays the details of an offering. The response includes the offering description, duration, outbound bandwidth, price, and Amazon Resource Name (ARN).
 */
export declare const describeOffering: API.OperationMethod<DescribeOfferingRequest, DescribeOfferingResponse, DescribeOfferingError, Credentials | HttpClient.HttpClient>;
export type DescribeReservationError = BadRequestException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays the details of a reservation. The response includes the reservation name, state, start date and time, and the details of the offering that make up the rest of the reservation (such as price, duration, and outbound bandwidth).
 */
export declare const describeReservation: API.OperationMethod<DescribeReservationRequest, DescribeReservationResponse, DescribeReservationError, Credentials | HttpClient.HttpClient>;
export type GetRouterInputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about a specific router input in AWS Elemental MediaConnect.
 */
export declare const getRouterInput: API.OperationMethod<GetRouterInputRequest, GetRouterInputResponse, GetRouterInputError, Credentials | HttpClient.HttpClient>;
export type GetRouterInputSourceMetadataError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves detailed metadata information about a specific router input source, including stream details and connection state.
 */
export declare const getRouterInputSourceMetadata: API.OperationMethod<GetRouterInputSourceMetadataRequest, GetRouterInputSourceMetadataResponse, GetRouterInputSourceMetadataError, Credentials | HttpClient.HttpClient>;
export type GetRouterInputThumbnailError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the thumbnail for a router input in AWS Elemental MediaConnect.
 */
export declare const getRouterInputThumbnail: API.OperationMethod<GetRouterInputThumbnailRequest, GetRouterInputThumbnailResponse, GetRouterInputThumbnailError, Credentials | HttpClient.HttpClient>;
export type GetRouterNetworkInterfaceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about a specific router network interface in AWS Elemental MediaConnect.
 */
export declare const getRouterNetworkInterface: API.OperationMethod<GetRouterNetworkInterfaceRequest, GetRouterNetworkInterfaceResponse, GetRouterNetworkInterfaceError, Credentials | HttpClient.HttpClient>;
export type GetRouterOutputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about a specific router output in AWS Elemental MediaConnect.
 */
export declare const getRouterOutput: API.OperationMethod<GetRouterOutputRequest, GetRouterOutputResponse, GetRouterOutputError, Credentials | HttpClient.HttpClient>;
export type GrantFlowEntitlementsError = BadRequestException | ForbiddenException | GrantFlowEntitlements420Exception | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Grants entitlements to an existing flow.
 */
export declare const grantFlowEntitlements: API.OperationMethod<GrantFlowEntitlementsRequest, GrantFlowEntitlementsResponse, GrantFlowEntitlementsError, Credentials | HttpClient.HttpClient>;
export type ListBridgesError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays a list of bridges that are associated with this account and an optionally specified Amazon Resource Name (ARN). This request returns a paginated result.
 */
export declare const listBridges: API.PaginatedOperationMethod<ListBridgesRequest, ListBridgesResponse, ListBridgesError, Credentials | HttpClient.HttpClient, ListedBridge>;
export type ListEntitlementsError = BadRequestException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays a list of all entitlements that have been granted to this account. This request returns 20 results per page.
 */
export declare const listEntitlements: API.PaginatedOperationMethod<ListEntitlementsRequest, ListEntitlementsResponse, ListEntitlementsError, Credentials | HttpClient.HttpClient, ListedEntitlement>;
export type ListFlowsError = BadRequestException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays a list of flows that are associated with this account. This request returns a paginated result.
 */
export declare const listFlows: API.PaginatedOperationMethod<ListFlowsRequest, ListFlowsResponse, ListFlowsError, Credentials | HttpClient.HttpClient, ListedFlow>;
export type ListGatewayInstancesError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays a list of instances associated with the Amazon Web Services account. This request returns a paginated result. You can use the filterArn property to display only the instances associated with the selected Gateway Amazon Resource Name (ARN).
 */
export declare const listGatewayInstances: API.PaginatedOperationMethod<ListGatewayInstancesRequest, ListGatewayInstancesResponse, ListGatewayInstancesError, Credentials | HttpClient.HttpClient, ListedGatewayInstance>;
export type ListGatewaysError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays a list of gateways that are associated with this account. This request returns a paginated result.
 */
export declare const listGateways: API.PaginatedOperationMethod<ListGatewaysRequest, ListGatewaysResponse, ListGatewaysError, Credentials | HttpClient.HttpClient, ListedGateway>;
export type ListOfferingsError = BadRequestException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays a list of all offerings that are available to this account in the current Amazon Web Services Region. If you have an active reservation (which means you've purchased an offering that has already started and hasn't expired yet), your account isn't eligible for other offerings.
 */
export declare const listOfferings: API.PaginatedOperationMethod<ListOfferingsRequest, ListOfferingsResponse, ListOfferingsError, Credentials | HttpClient.HttpClient, Offering>;
export type ListReservationsError = BadRequestException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays a list of all reservations that have been purchased by this account in the current Amazon Web Services Region. This list includes all reservations in all states (such as active and expired).
 */
export declare const listReservations: API.PaginatedOperationMethod<ListReservationsRequest, ListReservationsResponse, ListReservationsError, Credentials | HttpClient.HttpClient, Reservation>;
export type ListRouterInputsError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves a list of router inputs in AWS Elemental MediaConnect.
 */
export declare const listRouterInputs: API.PaginatedOperationMethod<ListRouterInputsRequest, ListRouterInputsResponse, ListRouterInputsError, Credentials | HttpClient.HttpClient, ListedRouterInput>;
export type ListRouterNetworkInterfacesError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves a list of router network interfaces in AWS Elemental MediaConnect.
 */
export declare const listRouterNetworkInterfaces: API.PaginatedOperationMethod<ListRouterNetworkInterfacesRequest, ListRouterNetworkInterfacesResponse, ListRouterNetworkInterfacesError, Credentials | HttpClient.HttpClient, ListedRouterNetworkInterface>;
export type ListRouterOutputsError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves a list of router outputs in AWS Elemental MediaConnect.
 */
export declare const listRouterOutputs: API.PaginatedOperationMethod<ListRouterOutputsRequest, ListRouterOutputsResponse, ListRouterOutputsError, Credentials | HttpClient.HttpClient, ListedRouterOutput>;
export type ListTagsForGlobalResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Lists the tags associated with a global resource in AWS Elemental MediaConnect. The API supports the following global resources: router inputs, router outputs and router network interfaces.
 */
export declare const listTagsForGlobalResource: API.OperationMethod<ListTagsForGlobalResourceRequest, ListTagsForGlobalResourceResponse, ListTagsForGlobalResourceError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * List all tags on a MediaConnect resource in the current region.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PurchaseOfferingError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Submits a request to purchase an offering. If you already have an active reservation, you can't purchase another offering.
 */
export declare const purchaseOffering: API.OperationMethod<PurchaseOfferingRequest, PurchaseOfferingResponse, PurchaseOfferingError, Credentials | HttpClient.HttpClient>;
export type RemoveBridgeOutputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Removes an output from a bridge.
 */
export declare const removeBridgeOutput: API.OperationMethod<RemoveBridgeOutputRequest, RemoveBridgeOutputResponse, RemoveBridgeOutputError, Credentials | HttpClient.HttpClient>;
export type RemoveBridgeSourceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Removes a source from a bridge.
 */
export declare const removeBridgeSource: API.OperationMethod<RemoveBridgeSourceRequest, RemoveBridgeSourceResponse, RemoveBridgeSourceError, Credentials | HttpClient.HttpClient>;
export type RemoveFlowMediaStreamError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Removes a media stream from a flow. This action is only available if the media stream is not associated with a source or output.
 */
export declare const removeFlowMediaStream: API.OperationMethod<RemoveFlowMediaStreamRequest, RemoveFlowMediaStreamResponse, RemoveFlowMediaStreamError, Credentials | HttpClient.HttpClient>;
export type RemoveFlowOutputError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Removes an output from an existing flow. This request can be made only on an output that does not have an entitlement associated with it. If the output has an entitlement, you must revoke the entitlement instead. When an entitlement is revoked from a flow, the service automatically removes the associated output.
 */
export declare const removeFlowOutput: API.OperationMethod<RemoveFlowOutputRequest, RemoveFlowOutputResponse, RemoveFlowOutputError, Credentials | HttpClient.HttpClient>;
export type RemoveFlowSourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Removes a source from an existing flow. This request can be made only if there is more than one source on the flow.
 */
export declare const removeFlowSource: API.OperationMethod<RemoveFlowSourceRequest, RemoveFlowSourceResponse, RemoveFlowSourceError, Credentials | HttpClient.HttpClient>;
export type RemoveFlowVpcInterfaceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Removes a VPC Interface from an existing flow. This request can be made only on a VPC interface that does not have a Source or Output associated with it. If the VPC interface is referenced by a Source or Output, you must first delete or update the Source or Output to no longer reference the VPC interface.
 */
export declare const removeFlowVpcInterface: API.OperationMethod<RemoveFlowVpcInterfaceRequest, RemoveFlowVpcInterfaceResponse, RemoveFlowVpcInterfaceError, Credentials | HttpClient.HttpClient>;
export type RestartRouterInputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Restarts a router input. This operation can be used to recover from errors or refresh the input state.
 */
export declare const restartRouterInput: API.OperationMethod<RestartRouterInputRequest, RestartRouterInputResponse, RestartRouterInputError, Credentials | HttpClient.HttpClient>;
export type RestartRouterOutputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Restarts a router output. This operation can be used to recover from errors or refresh the output state.
 */
export declare const restartRouterOutput: API.OperationMethod<RestartRouterOutputRequest, RestartRouterOutputResponse, RestartRouterOutputError, Credentials | HttpClient.HttpClient>;
export type RevokeFlowEntitlementError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Revokes an entitlement from a flow. Once an entitlement is revoked, the content becomes unavailable to the subscriber and the associated output is removed.
 */
export declare const revokeFlowEntitlement: API.OperationMethod<RevokeFlowEntitlementRequest, RevokeFlowEntitlementResponse, RevokeFlowEntitlementError, Credentials | HttpClient.HttpClient>;
export type StartFlowError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Starts a flow.
 */
export declare const startFlow: API.OperationMethod<StartFlowRequest, StartFlowResponse, StartFlowError, Credentials | HttpClient.HttpClient>;
export type StartRouterInputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Starts a router input in AWS Elemental MediaConnect.
 */
export declare const startRouterInput: API.OperationMethod<StartRouterInputRequest, StartRouterInputResponse, StartRouterInputError, Credentials | HttpClient.HttpClient>;
export type StartRouterOutputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Starts a router output in AWS Elemental MediaConnect.
 */
export declare const startRouterOutput: API.OperationMethod<StartRouterOutputRequest, StartRouterOutputResponse, StartRouterOutputError, Credentials | HttpClient.HttpClient>;
export type StopFlowError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Stops a flow.
 */
export declare const stopFlow: API.OperationMethod<StopFlowRequest, StopFlowResponse, StopFlowError, Credentials | HttpClient.HttpClient>;
export type StopRouterInputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Stops a router input in AWS Elemental MediaConnect.
 */
export declare const stopRouterInput: API.OperationMethod<StopRouterInputRequest, StopRouterInputResponse, StopRouterInputError, Credentials | HttpClient.HttpClient>;
export type StopRouterOutputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Stops a router output in AWS Elemental MediaConnect.
 */
export declare const stopRouterOutput: API.OperationMethod<StopRouterOutputRequest, StopRouterOutputResponse, StopRouterOutputError, Credentials | HttpClient.HttpClient>;
export type TagGlobalResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Adds tags to a global resource in AWS Elemental MediaConnect. The API supports the following global resources: router inputs, router outputs and router network interfaces.
 */
export declare const tagGlobalResource: API.OperationMethod<TagGlobalResourceRequest, TagGlobalResourceResponse, TagGlobalResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Associates the specified tags to a resource with the specified `resourceArn` in the current region. If existing tags on a resource are not specified in the request parameters, they are not changed. When a resource is deleted, the tags associated with that resource are deleted as well.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TakeRouterInputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Associates a router input with a router output in AWS Elemental MediaConnect.
 */
export declare const takeRouterInput: API.OperationMethod<TakeRouterInputRequest, TakeRouterInputResponse, TakeRouterInputError, Credentials | HttpClient.HttpClient>;
export type UntagGlobalResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Removes tags from a global resource in AWS Elemental MediaConnect. The API supports the following global resources: router inputs, router outputs and router network interfaces.
 */
export declare const untagGlobalResource: API.OperationMethod<UntagGlobalResourceRequest, UntagGlobalResourceResponse, UntagGlobalResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Deletes specified tags from a resource in the current region.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBridgeError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates the bridge.
 */
export declare const updateBridge: API.OperationMethod<UpdateBridgeRequest, UpdateBridgeResponse, UpdateBridgeError, Credentials | HttpClient.HttpClient>;
export type UpdateBridgeOutputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing bridge output.
 */
export declare const updateBridgeOutput: API.OperationMethod<UpdateBridgeOutputRequest, UpdateBridgeOutputResponse, UpdateBridgeOutputError, Credentials | HttpClient.HttpClient>;
export type UpdateBridgeSourceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing bridge source.
 */
export declare const updateBridgeSource: API.OperationMethod<UpdateBridgeSourceRequest, UpdateBridgeSourceResponse, UpdateBridgeSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBridgeStateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates the bridge state.
 */
export declare const updateBridgeState: API.OperationMethod<UpdateBridgeStateRequest, UpdateBridgeStateResponse, UpdateBridgeStateError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing flow.
 *
 * Because `UpdateFlowSources` and `UpdateFlow` are separate operations, you can't change both the source type AND the flow size in a single request.
 *
 * - If you have a `MEDIUM` flow and you want to change the flow source to NDI®:
 *
 * - First, use the `UpdateFlow` operation to upgrade the flow size to `LARGE`.
 *
 * - After that, you can then use the `UpdateFlowSource` operation to configure the NDI source.
 *
 * - If you're switching from an NDI source to a transport stream (TS) source and want to downgrade the flow size:
 *
 * - First, use the `UpdateFlowSource` operation to change the flow source type.
 *
 * - After that, you can then use the `UpdateFlow` operation to downgrade the flow size to `MEDIUM`.
 */
export declare const updateFlow: API.OperationMethod<UpdateFlowRequest, UpdateFlowResponse, UpdateFlowError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowEntitlementError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an entitlement. You can change an entitlement's description, subscribers, and encryption. If you change the subscribers, the service will remove the outputs that are are used by the subscribers that are removed.
 */
export declare const updateFlowEntitlement: API.OperationMethod<UpdateFlowEntitlementRequest, UpdateFlowEntitlementResponse, UpdateFlowEntitlementError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowMediaStreamError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing media stream.
 */
export declare const updateFlowMediaStream: API.OperationMethod<UpdateFlowMediaStreamRequest, UpdateFlowMediaStreamResponse, UpdateFlowMediaStreamError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowOutputError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing flow output.
 */
export declare const updateFlowOutput: API.OperationMethod<UpdateFlowOutputRequest, UpdateFlowOutputResponse, UpdateFlowOutputError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowSourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates the source of a flow.
 *
 * Because `UpdateFlowSources` and `UpdateFlow` are separate operations, you can't change both the source type AND the flow size in a single request.
 *
 * - If you have a `MEDIUM` flow and you want to change the flow source to NDI®:
 *
 * - First, use the `UpdateFlow` operation to upgrade the flow size to `LARGE`.
 *
 * - After that, you can then use the `UpdateFlowSource` operation to configure the NDI source.
 *
 * - If you're switching from an NDI source to a transport stream (TS) source and want to downgrade the flow size:
 *
 * - First, use the `UpdateFlowSource` operation to change the flow source type.
 *
 * - After that, you can then use the `UpdateFlow` operation to downgrade the flow size to `MEDIUM`.
 */
export declare const updateFlowSource: API.OperationMethod<UpdateFlowSourceRequest, UpdateFlowSourceResponse, UpdateFlowSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewayInstanceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing gateway instance.
 */
export declare const updateGatewayInstance: API.OperationMethod<UpdateGatewayInstanceRequest, UpdateGatewayInstanceResponse, UpdateGatewayInstanceError, Credentials | HttpClient.HttpClient>;
export type UpdateRouterInputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates the configuration of an existing router input in AWS Elemental MediaConnect.
 */
export declare const updateRouterInput: API.OperationMethod<UpdateRouterInputRequest, UpdateRouterInputResponse, UpdateRouterInputError, Credentials | HttpClient.HttpClient>;
export type UpdateRouterNetworkInterfaceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates the configuration of an existing router network interface in AWS Elemental MediaConnect.
 */
export declare const updateRouterNetworkInterface: API.OperationMethod<UpdateRouterNetworkInterfaceRequest, UpdateRouterNetworkInterfaceResponse, UpdateRouterNetworkInterfaceError, Credentials | HttpClient.HttpClient>;
export type UpdateRouterOutputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates the configuration of an existing router output in AWS Elemental MediaConnect.
 */
export declare const updateRouterOutput: API.OperationMethod<UpdateRouterOutputRequest, UpdateRouterOutputResponse, UpdateRouterOutputError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=mediaconnect.d.ts.map