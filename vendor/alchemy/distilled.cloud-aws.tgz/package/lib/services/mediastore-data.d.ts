import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import * as T from "../traits.ts";
declare const ContainerNotFoundException_base: S.TaggedErrorClass<"ContainerNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ContainerNotFoundException extends /*@__PURE__*/ ContainerNotFoundException_base {
}
declare const InternalServerError_base: S.TaggedErrorClass<"InternalServerError", {
    readonly message: any;
}>;
export declare class InternalServerError extends /*@__PURE__*/ InternalServerError_base {
}
declare const ObjectNotFoundException_base: S.TaggedErrorClass<"ObjectNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ObjectNotFoundException extends /*@__PURE__*/ ObjectNotFoundException_base {
}
declare const RequestedRangeNotSatisfiableException_base: S.TaggedErrorClass<"RequestedRangeNotSatisfiableException", {
    readonly message: any;
}>;
export declare class RequestedRangeNotSatisfiableException extends /*@__PURE__*/ RequestedRangeNotSatisfiableException_base {
}
export type PathNaming = string;
export interface DeleteObjectRequest {
    Path: string;
}
export interface DeleteObjectResponse {
}
export interface DescribeObjectRequest {
    Path: string;
}
export type ETag = string;
export type ContentType = string;
export type NonNegativeLong = number;
export type StringPrimitive = string;
export interface DescribeObjectResponse {
    ETag?: string;
    ContentType?: string;
    ContentLength?: number;
    CacheControl?: string;
    LastModified?: Date;
}
export type RangePattern = string;
export interface GetObjectRequest {
    Path: string;
    Range?: string;
}
export type ContentRangePattern = string;
export type StatusCode = number;
export interface GetObjectResponse {
    Body?: T.StreamingOutputBody;
    CacheControl?: string;
    ContentRange?: string;
    ContentLength?: number;
    ContentType?: string;
    ETag?: string;
    LastModified?: Date;
    StatusCode: number;
}
export type ListPathNaming = string;
export type ListLimit = number;
export type PaginationToken = string;
export interface ListItemsRequest {
    Path?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type ItemName = string;
export type ItemType = "OBJECT" | "FOLDER" | (string & {});
export interface Item {
    Name?: string;
    Type?: ItemType;
    ETag?: string;
    LastModified?: Date;
    ContentType?: string;
    ContentLength?: number;
}
export type ItemList = Item[];
export interface ListItemsResponse {
    Items?: Item[];
    NextToken?: string;
}
export type StorageClass = "TEMPORAL" | (string & {});
export type UploadAvailability = "STANDARD" | "STREAMING" | (string & {});
export interface PutObjectRequest {
    Body: T.StreamingInputBody;
    Path: string;
    ContentType?: string;
    CacheControl?: string;
    StorageClass?: StorageClass;
    UploadAvailability?: UploadAvailability;
}
export type SHA256Hash = string;
export interface PutObjectResponse {
    ContentSHA256?: string;
    ETag?: string;
    StorageClass?: StorageClass;
}
export type ErrorMessage = string;
export type DeleteObjectError = ContainerNotFoundException | InternalServerError | ObjectNotFoundException | CommonErrors;
/**
 * Deletes an object at the specified path.
 */
export declare const deleteObject: API.OperationMethod<DeleteObjectRequest, DeleteObjectResponse, DeleteObjectError, Credentials | HttpClient.HttpClient>;
export type DescribeObjectError = ContainerNotFoundException | InternalServerError | ObjectNotFoundException | CommonErrors;
/**
 * Gets the headers for an object at the specified path.
 */
export declare const describeObject: API.OperationMethod<DescribeObjectRequest, DescribeObjectResponse, DescribeObjectError, Credentials | HttpClient.HttpClient>;
export type GetObjectError = ContainerNotFoundException | InternalServerError | ObjectNotFoundException | RequestedRangeNotSatisfiableException | CommonErrors;
/**
 * Downloads the object at the specified path. If the object's upload availability is set to `streaming`, AWS Elemental MediaStore downloads the object even if it's still uploading the object.
 */
export declare const getObject: API.OperationMethod<GetObjectRequest, GetObjectResponse, GetObjectError, Credentials | HttpClient.HttpClient>;
export type ListItemsError = ContainerNotFoundException | InternalServerError | CommonErrors;
/**
 * Provides a list of metadata entries about folders and objects in the specified
 * folder.
 */
export declare const listItems: API.PaginatedOperationMethod<ListItemsRequest, ListItemsResponse, ListItemsError, Credentials | HttpClient.HttpClient, unknown>;
export type PutObjectError = ContainerNotFoundException | InternalServerError | CommonErrors;
/**
 * Uploads an object to the specified path. Object sizes are limited to 25 MB for standard upload availability and 10 MB for streaming upload availability.
 */
export declare const putObject: API.OperationMethod<PutObjectRequest, PutObjectResponse, PutObjectError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=mediastore-data.d.ts.map