import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly error: any;
    readonly reason: any;
    readonly error_description: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AuthorizationPendingException_base: S.TaggedErrorClass<"AuthorizationPendingException", {
    readonly error: any;
    readonly error_description: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AuthorizationPendingException extends /*@__PURE__*/ AuthorizationPendingException_base {
}
declare const ExpiredTokenException_base: S.TaggedErrorClass<"ExpiredTokenException", {
    readonly error: any;
    readonly error_description: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ExpiredTokenException extends /*@__PURE__*/ ExpiredTokenException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly error: any;
    readonly error_description: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidClientException_base: S.TaggedErrorClass<"InvalidClientException", {
    readonly error: any;
    readonly error_description: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class InvalidClientException extends /*@__PURE__*/ InvalidClientException_base {
}
declare const InvalidClientMetadataException_base: S.TaggedErrorClass<"InvalidClientMetadataException", {
    readonly error: any;
    readonly error_description: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidClientMetadataException extends /*@__PURE__*/ InvalidClientMetadataException_base {
}
declare const InvalidGrantException_base: S.TaggedErrorClass<"InvalidGrantException", {
    readonly error: any;
    readonly error_description: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidGrantException extends /*@__PURE__*/ InvalidGrantException_base {
}
declare const InvalidRedirectUriException_base: S.TaggedErrorClass<"InvalidRedirectUriException", {
    readonly error: any;
    readonly error_description: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRedirectUriException extends /*@__PURE__*/ InvalidRedirectUriException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly error: any;
    readonly reason: any;
    readonly error_description: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const InvalidRequestRegionException_base: S.TaggedErrorClass<"InvalidRequestRegionException", {
    readonly error: any;
    readonly error_description: any;
    readonly endpoint: any;
    readonly region: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestRegionException extends /*@__PURE__*/ InvalidRequestRegionException_base {
}
declare const InvalidScopeException_base: S.TaggedErrorClass<"InvalidScopeException", {
    readonly error: any;
    readonly error_description: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidScopeException extends /*@__PURE__*/ InvalidScopeException_base {
}
declare const SlowDownException_base: S.TaggedErrorClass<"SlowDownException", {
    readonly error: any;
    readonly error_description: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SlowDownException extends /*@__PURE__*/ SlowDownException_base {
}
declare const UnauthorizedClientException_base: S.TaggedErrorClass<"UnauthorizedClientException", {
    readonly error: any;
    readonly error_description: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedClientException extends /*@__PURE__*/ UnauthorizedClientException_base {
}
declare const UnsupportedGrantTypeException_base: S.TaggedErrorClass<"UnsupportedGrantTypeException", {
    readonly error: any;
    readonly error_description: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedGrantTypeException extends /*@__PURE__*/ UnsupportedGrantTypeException_base {
}
export type ClientId = string;
export type ClientSecret = string | redacted.Redacted<string>;
export type GrantType = string;
export type DeviceCode = string;
export type AuthCode = string;
export type RefreshToken = string | redacted.Redacted<string>;
export type Scope = string;
export type Scopes = string[];
export type URI = string;
export type CodeVerifier = string | redacted.Redacted<string>;
export interface CreateTokenRequest {
    clientId: string;
    clientSecret: string | redacted.Redacted<string>;
    grantType: string;
    deviceCode?: string;
    code?: string;
    refreshToken?: string | redacted.Redacted<string>;
    scope?: string[];
    redirectUri?: string;
    codeVerifier?: string | redacted.Redacted<string>;
}
export type AccessToken = string | redacted.Redacted<string>;
export type TokenType = string;
export type ExpirationInSeconds = number;
export type IdToken = string | redacted.Redacted<string>;
export interface CreateTokenResponse {
    accessToken?: string | redacted.Redacted<string>;
    tokenType?: string;
    expiresIn?: number;
    refreshToken?: string | redacted.Redacted<string>;
    idToken?: string | redacted.Redacted<string>;
}
export type Assertion = string | redacted.Redacted<string>;
export type SubjectToken = string | redacted.Redacted<string>;
export type TokenTypeURI = string;
export interface CreateTokenWithIAMRequest {
    clientId: string;
    grantType: string;
    code?: string;
    refreshToken?: string | redacted.Redacted<string>;
    assertion?: string | redacted.Redacted<string>;
    scope?: string[];
    redirectUri?: string;
    subjectToken?: string | redacted.Redacted<string>;
    subjectTokenType?: string;
    requestedTokenType?: string;
    codeVerifier?: string | redacted.Redacted<string>;
}
export type IdentityContext = string;
export interface AwsAdditionalDetails {
    identityContext?: string;
}
export interface CreateTokenWithIAMResponse {
    accessToken?: string | redacted.Redacted<string>;
    tokenType?: string;
    expiresIn?: number;
    refreshToken?: string | redacted.Redacted<string>;
    idToken?: string | redacted.Redacted<string>;
    issuedTokenType?: string;
    scope?: string[];
    awsAdditionalDetails?: AwsAdditionalDetails;
}
export type ClientName = string;
export type ClientType = string;
export type RedirectUris = string[];
export type GrantTypes = string[];
export type ArnType = string;
export interface RegisterClientRequest {
    clientName: string;
    clientType: string;
    scopes?: string[];
    redirectUris?: string[];
    grantTypes?: string[];
    issuerUrl?: string;
    entitledApplicationArn?: string;
}
export type LongTimeStampType = number;
export interface RegisterClientResponse {
    clientId?: string;
    clientSecret?: string | redacted.Redacted<string>;
    clientIdIssuedAt?: number;
    clientSecretExpiresAt?: number;
    authorizationEndpoint?: string;
    tokenEndpoint?: string;
}
export interface StartDeviceAuthorizationRequest {
    clientId: string;
    clientSecret: string | redacted.Redacted<string>;
    startUrl: string;
}
export type UserCode = string;
export type IntervalInSeconds = number;
export interface StartDeviceAuthorizationResponse {
    deviceCode?: string;
    userCode?: string;
    verificationUri?: string;
    verificationUriComplete?: string;
    expiresIn?: number;
    interval?: number;
}
export type AccessDeniedExceptionReason = "KMS_AccessDeniedException" | (string & {});
export type ErrorDescription = string;
export type InvalidRequestExceptionReason = "KMS_NotFoundException" | "KMS_InvalidKeyUsageException" | "KMS_InvalidStateException" | "KMS_DisabledException" | (string & {});
export type Location = string;
export type Region = string;
export type CreateTokenError = AccessDeniedException | AuthorizationPendingException | ExpiredTokenException | InternalServerException | InvalidClientException | InvalidGrantException | InvalidRequestException | InvalidScopeException | SlowDownException | UnauthorizedClientException | UnsupportedGrantTypeException | CommonErrors;
/**
 * Creates and returns access and refresh tokens for clients that are authenticated using
 * client secrets. The access token can be used to fetch short-lived credentials for the assigned
 * AWS accounts or to access application APIs using `bearer` authentication.
 */
export declare const createToken: API.OperationMethod<CreateTokenRequest, CreateTokenResponse, CreateTokenError, Credentials | HttpClient.HttpClient>;
export type CreateTokenWithIAMError = AccessDeniedException | AuthorizationPendingException | ExpiredTokenException | InternalServerException | InvalidClientException | InvalidGrantException | InvalidRequestException | InvalidRequestRegionException | InvalidScopeException | SlowDownException | UnauthorizedClientException | UnsupportedGrantTypeException | CommonErrors;
/**
 * Creates and returns access and refresh tokens for authorized client applications that are
 * authenticated using any IAM entity, such as a service
 * role or user. These tokens might contain defined scopes that specify permissions such as `read:profile` or `write:data`. Through downscoping, you can use the scopes parameter to request tokens with reduced permissions compared to the original client application's permissions or, if applicable, the refresh token's scopes. The access token can be used to fetch short-lived credentials for the assigned
 * Amazon Web Services accounts or to access application APIs using `bearer` authentication.
 *
 * This API is used with Signature Version 4. For more information, see Amazon Web Services Signature
 * Version 4 for API Requests.
 */
export declare const createTokenWithIAM: API.OperationMethod<CreateTokenWithIAMRequest, CreateTokenWithIAMResponse, CreateTokenWithIAMError, Credentials | HttpClient.HttpClient>;
export type RegisterClientError = InternalServerException | InvalidClientMetadataException | InvalidRedirectUriException | InvalidRequestException | InvalidScopeException | SlowDownException | UnsupportedGrantTypeException | CommonErrors;
/**
 * Registers a public client with IAM Identity Center. This allows clients to perform authorization using
 * the authorization code grant with Proof Key for Code Exchange (PKCE) or the device
 * code grant.
 */
export declare const registerClient: API.OperationMethod<RegisterClientRequest, RegisterClientResponse, RegisterClientError, Credentials | HttpClient.HttpClient>;
export type StartDeviceAuthorizationError = InternalServerException | InvalidClientException | InvalidRequestException | SlowDownException | UnauthorizedClientException | CommonErrors;
/**
 * Initiates device authorization by requesting a pair of verification codes from the
 * authorization service.
 */
export declare const startDeviceAuthorization: API.OperationMethod<StartDeviceAuthorizationRequest, StartDeviceAuthorizationResponse, StartDeviceAuthorizationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=sso-oidc.d.ts.map