import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type HumanLoopName = string;
export interface DeleteHumanLoopRequest {
    HumanLoopName: string;
}
export interface DeleteHumanLoopResponse {
}
export interface DescribeHumanLoopRequest {
    HumanLoopName: string;
}
export type HumanLoopStatus = "InProgress" | "Failed" | "Completed" | "Stopped" | "Stopping" | (string & {});
export type HumanLoopArn = string;
export type FlowDefinitionArn = string;
export interface HumanLoopOutput {
    OutputS3Uri?: string;
}
export interface DescribeHumanLoopResponse {
    CreationTime: Date;
    FailureReason?: string;
    FailureCode?: string;
    HumanLoopStatus: HumanLoopStatus;
    HumanLoopName: string;
    HumanLoopArn: string;
    FlowDefinitionArn: string;
    HumanLoopOutput?: HumanLoopOutput & {
        OutputS3Uri: string;
    };
}
export type SortOrder = "Ascending" | "Descending" | (string & {});
export type NextToken = string;
export type MaxResults = number;
export interface ListHumanLoopsRequest {
    CreationTimeAfter?: Date;
    CreationTimeBefore?: Date;
    FlowDefinitionArn?: string;
    SortOrder?: SortOrder;
    NextToken?: string;
    MaxResults?: number;
}
export type FailureReason = string;
export interface HumanLoopSummary {
    HumanLoopName?: string;
    HumanLoopStatus?: HumanLoopStatus;
    CreationTime?: Date;
    FailureReason?: string;
    FlowDefinitionArn?: string;
}
export type HumanLoopSummaries = HumanLoopSummary[];
export interface ListHumanLoopsResponse {
    HumanLoopSummaries: HumanLoopSummary[];
    NextToken?: string;
}
export type InputContent = string;
export interface HumanLoopInput {
    InputContent?: string;
}
export type ContentClassifier = "FreeOfPersonallyIdentifiableInformation" | "FreeOfAdultContent" | (string & {});
export type ContentClassifiers = ContentClassifier[];
export interface HumanLoopDataAttributes {
    ContentClassifiers?: ContentClassifier[];
}
export interface StartHumanLoopRequest {
    HumanLoopName?: string;
    FlowDefinitionArn?: string;
    HumanLoopInput?: HumanLoopInput;
    DataAttributes?: HumanLoopDataAttributes;
}
export interface StartHumanLoopResponse {
    HumanLoopArn?: string;
}
export interface StopHumanLoopRequest {
    HumanLoopName?: string;
}
export interface StopHumanLoopResponse {
}
export type DeleteHumanLoopError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified human loop for a flow definition.
 *
 * If the human loop was deleted, this operation will return a
 * `ResourceNotFoundException`.
 */
export declare const deleteHumanLoop: API.OperationMethod<DeleteHumanLoopRequest, DeleteHumanLoopResponse, DeleteHumanLoopError, Credentials | HttpClient.HttpClient>;
export type DescribeHumanLoopError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the specified human loop. If the human loop was deleted, this
 * operation will return a `ResourceNotFoundException` error.
 */
export declare const describeHumanLoop: API.OperationMethod<DescribeHumanLoopRequest, DescribeHumanLoopResponse, DescribeHumanLoopError, Credentials | HttpClient.HttpClient>;
export type ListHumanLoopsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about human loops, given the specified parameters. If a human loop was deleted, it will not be included.
 */
export declare const listHumanLoops: API.PaginatedOperationMethod<ListHumanLoopsRequest, ListHumanLoopsResponse, ListHumanLoopsError, Credentials | HttpClient.HttpClient, HumanLoopSummary>;
export type StartHumanLoopError = ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a human loop, provided that at least one activation condition is met.
 */
export declare const startHumanLoop: API.OperationMethod<StartHumanLoopRequest, StartHumanLoopResponse, StartHumanLoopError, Credentials | HttpClient.HttpClient>;
export type StopHumanLoopError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops the specified human loop.
 */
export declare const stopHumanLoop: API.OperationMethod<StopHumanLoopRequest, StopHumanLoopResponse, StopHumanLoopError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=sagemaker-a2i-runtime.d.ts.map