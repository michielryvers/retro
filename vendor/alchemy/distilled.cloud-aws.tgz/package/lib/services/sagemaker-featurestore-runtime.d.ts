import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessForbidden_base: S.TaggedErrorClass<"AccessForbidden", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessForbidden extends /*@__PURE__*/ AccessForbidden_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const FeatureGroupNotFound_base: S.TaggedErrorClass<"FeatureGroupNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class FeatureGroupNotFound extends /*@__PURE__*/ FeatureGroupNotFound_base {
}
declare const InternalFailure_base: S.TaggedErrorClass<"InternalFailure", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalFailure extends /*@__PURE__*/ InternalFailure_base {
}
declare const ResourceNotFound_base: S.TaggedErrorClass<"ResourceNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFound extends /*@__PURE__*/ ResourceNotFound_base {
}
declare const ServiceUnavailable_base: S.TaggedErrorClass<"ServiceUnavailable", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailable extends /*@__PURE__*/ ServiceUnavailable_base {
}
declare const ValidationError_base: S.TaggedErrorClass<"ValidationError", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationError extends /*@__PURE__*/ ValidationError_base {
}
export type FeatureGroupNameOrArn = string;
export type ValueAsString = string;
export type RecordIdentifiers = string[];
export type FeatureName = string;
export type FeatureNames = string[];
export interface BatchGetRecordIdentifier {
    FeatureGroupName?: string;
    RecordIdentifiersValueAsString?: string[];
    FeatureNames?: string[];
}
export type BatchGetRecordIdentifiers = BatchGetRecordIdentifier[];
export type ExpirationTimeResponse = "Enabled" | "Disabled" | (string & {});
export interface BatchGetRecordRequest {
    Identifiers?: BatchGetRecordIdentifier[];
    ExpirationTimeResponse?: ExpirationTimeResponse;
}
export type ValueAsStringList = string[];
export interface FeatureValue {
    FeatureName?: string;
    ValueAsString?: string;
    ValueAsStringList?: string[];
}
export type Record = FeatureValue[];
export type ExpiresAt = string;
export interface BatchGetRecordResultDetail {
    FeatureGroupName?: string;
    RecordIdentifierValueAsString?: string;
    Record?: FeatureValue[];
    ExpiresAt?: string;
}
export type BatchGetRecordResultDetails = BatchGetRecordResultDetail[];
export type Message = string;
export interface BatchGetRecordError_ {
    FeatureGroupName?: string;
    RecordIdentifierValueAsString?: string;
    ErrorCode?: string;
    ErrorMessage?: string;
}
export type BatchGetRecordErrors = BatchGetRecordError_[];
export type UnprocessedIdentifiers = BatchGetRecordIdentifier[];
export interface BatchGetRecordResponse {
    Records: (BatchGetRecordResultDetail & {
        FeatureGroupName: ValueAsString;
        RecordIdentifierValueAsString: ValueAsString;
        Record: (FeatureValue & {
            FeatureName: FeatureName;
        })[];
    })[];
    Errors: (BatchGetRecordError & {
        FeatureGroupName: ValueAsString;
        RecordIdentifierValueAsString: ValueAsString;
        ErrorCode: ValueAsString;
        ErrorMessage: Message;
    })[];
    UnprocessedIdentifiers: (BatchGetRecordIdentifier & {
        FeatureGroupName: FeatureGroupNameOrArn;
        RecordIdentifiersValueAsString: RecordIdentifiers;
    })[];
}
export type TargetStore = "OnlineStore" | "OfflineStore" | (string & {});
export type TargetStores = TargetStore[];
export type TtlDurationUnit = "Seconds" | "Minutes" | "Hours" | "Days" | "Weeks" | (string & {});
export type TtlDurationValue = number;
export interface TtlDuration {
    Unit?: TtlDurationUnit;
    Value?: number;
}
export interface BatchWriteRecordEntry {
    FeatureGroupName?: string;
    Record?: FeatureValue[];
    TargetStores?: TargetStore[];
    TtlDuration?: TtlDuration;
}
export type BatchWriteRecordEntries = BatchWriteRecordEntry[];
export interface BatchWriteRecordRequest {
    Entries?: BatchWriteRecordEntry[];
    TtlDuration?: TtlDuration;
}
export interface BatchWriteRecordError_ {
    Entry?: BatchWriteRecordEntry;
    ErrorCode?: string;
    ErrorMessage?: string;
}
export type BatchWriteRecordErrors = BatchWriteRecordError_[];
export type UnprocessedBatchWriteRecordEntries = BatchWriteRecordEntry[];
export interface BatchWriteRecordResponse {
    Errors: (BatchWriteRecordError & {
        Entry: BatchWriteRecordEntry & {
            FeatureGroupName: FeatureGroupNameOrArn;
            Record: (FeatureValue & {
                FeatureName: FeatureName;
            })[];
            TtlDuration: TtlDuration & {
                Unit: TtlDurationUnit;
                Value: TtlDurationValue;
            };
        };
        ErrorCode: ValueAsString;
        ErrorMessage: Message;
    })[];
    UnprocessedEntries: (BatchWriteRecordEntry & {
        FeatureGroupName: FeatureGroupNameOrArn;
        Record: (FeatureValue & {
            FeatureName: FeatureName;
        })[];
        TtlDuration: TtlDuration & {
            Unit: TtlDurationUnit;
            Value: TtlDurationValue;
        };
    })[];
}
export type DeletionMode = "SoftDelete" | "HardDelete" | (string & {});
export interface DeleteRecordRequest {
    FeatureGroupName: string;
    RecordIdentifierValueAsString?: string;
    EventTime?: string;
    TargetStores?: TargetStore[];
    DeletionMode?: DeletionMode;
}
export interface DeleteRecordResponse {
}
export interface GetRecordRequest {
    FeatureGroupName: string;
    RecordIdentifierValueAsString?: string;
    FeatureNames?: string[];
    ExpirationTimeResponse?: ExpirationTimeResponse;
}
export interface GetRecordResponse {
    Record?: (FeatureValue & {
        FeatureName: FeatureName;
    })[];
    ExpiresAt?: string;
}
export type ListRecordsMaxResults = number;
export type ListRecordsNextToken = string;
export interface ListRecordsRequest {
    FeatureGroupName: string;
    MaxResults?: number;
    NextToken?: string;
    IncludeSoftDeletedRecords?: boolean;
}
export type RecordIdentifierList = string[];
export interface ListRecordsResponse {
    RecordIdentifiers: string[];
    NextToken?: string;
}
export interface PutRecordRequest {
    FeatureGroupName: string;
    Record?: FeatureValue[];
    TargetStores?: TargetStore[];
    TtlDuration?: TtlDuration;
}
export interface PutRecordResponse {
}
export interface UpdateRecordRequest {
    FeatureGroupName: string;
    RecordIdentifierValueAsString?: string;
    Features?: FeatureValue[];
    TargetStores?: TargetStore[];
    TtlDuration?: TtlDuration;
}
export interface UpdateRecordResponse {
}
export type BatchGetRecordError = AccessForbidden | InternalFailure | ServiceUnavailable | ValidationError | CommonErrors;
/**
 * Retrieves a batch of `Records` from a `FeatureGroup`.
 */
export declare const batchGetRecord: API.OperationMethod<BatchGetRecordRequest, BatchGetRecordResponse, BatchGetRecordError, Credentials | HttpClient.HttpClient>;
export type BatchWriteRecordError = AccessForbidden | InternalFailure | ResourceNotFound | ServiceUnavailable | ValidationError | CommonErrors;
/**
 * Writes a batch of `Records` to one or more `FeatureGroup`s. Use
 * this API for bulk ingestion of records into the `OnlineStore` and
 * `OfflineStore`.
 *
 * You can set the ingested records to expire at a given time to live (TTL) duration after
 * the record's event time by specifying the `TtlDuration` parameter. A request
 * level `TtlDuration` applies to all entries that do not specify their own
 * `TtlDuration`.
 */
export declare const batchWriteRecord: API.OperationMethod<BatchWriteRecordRequest, BatchWriteRecordResponse, BatchWriteRecordError, Credentials | HttpClient.HttpClient>;
export type DeleteRecordError = AccessForbidden | InternalFailure | ServiceUnavailable | ValidationError | FeatureGroupNotFound | CommonErrors;
/**
 * Deletes a `Record` from a `FeatureGroup` in the
 * `OnlineStore`. Feature Store supports both `SoftDelete` and
 * `HardDelete`. For `SoftDelete` (default), feature columns are set
 * to `null` and the record is no longer retrievable by `GetRecord` or
 * `BatchGetRecord`. For `HardDelete`, the complete
 * `Record` is removed from the `OnlineStore`. In both cases, Feature
 * Store appends the deleted record marker to the `OfflineStore`. The deleted
 * record marker is a record with the same `RecordIdentifer` as the original, but
 * with `is_deleted` value set to `True`, `EventTime` set to
 * the delete input `EventTime`, and other feature values set to
 * `null`.
 *
 * Note that the `EventTime` specified in `DeleteRecord` should be
 * set later than the `EventTime` of the existing record in the
 * `OnlineStore` for that `RecordIdentifer`. If it is not, the
 * deletion does not occur:
 *
 * - For `SoftDelete`, the existing (not deleted) record remains in the
 * `OnlineStore`, though the delete record marker is still written to the
 * `OfflineStore`.
 *
 * - `HardDelete` returns `EventTime`: 400
 * ValidationException to indicate that the delete operation failed. No delete
 * record marker is written to the `OfflineStore`.
 *
 * When a record is deleted from the `OnlineStore`, the deleted record marker is
 * appended to the `OfflineStore`. If you have the Iceberg table format enabled for
 * your `OfflineStore`, you can remove all history of a record from the
 * `OfflineStore` using Amazon Athena or Apache Spark. For information on how to
 * hard delete a record from the `OfflineStore` with the Iceberg table format
 * enabled, see Delete records from the offline store.
 */
export declare const deleteRecord: API.OperationMethod<DeleteRecordRequest, DeleteRecordResponse, DeleteRecordError, Credentials | HttpClient.HttpClient>;
export type GetRecordError = AccessForbidden | InternalFailure | ResourceNotFound | ServiceUnavailable | ValidationError | FeatureGroupNotFound | CommonErrors;
/**
 * Use for `OnlineStore` serving from a `FeatureStore`. Only the
 * latest records stored in the `OnlineStore` can be retrieved. If no Record with
 * `RecordIdentifierValue` is found, then an empty result is returned.
 */
export declare const getRecord: API.OperationMethod<GetRecordRequest, GetRecordResponse, GetRecordError, Credentials | HttpClient.HttpClient>;
export type ListRecordsError = AccessForbidden | InternalFailure | ResourceNotFound | ServiceUnavailable | ValidationError | CommonErrors;
/**
 * Lists the `RecordIdentifier` values of all records stored in a
 * `FeatureGroup`'s `OnlineStore`. This enables you to discover which
 * records exist without retrieving the full record data.
 */
export declare const listRecords: API.PaginatedOperationMethod<ListRecordsRequest, ListRecordsResponse, ListRecordsError, Credentials | HttpClient.HttpClient, ValueAsString>;
export type PutRecordError = AccessForbidden | InternalFailure | ServiceUnavailable | ValidationError | FeatureGroupNotFound | CommonErrors;
/**
 * The `PutRecord` API is used to ingest a list of `Records` into
 * your feature group.
 *
 * If a new record's `EventTime` is greater, the new record is written to both
 * the `OnlineStore` and `OfflineStore`. Otherwise, the record is a
 * historic record and it is written only to the `OfflineStore`.
 *
 * You can specify the ingestion to be applied to the `OnlineStore`,
 * `OfflineStore`, or both by using the `TargetStores` request
 * parameter.
 *
 * You can set the ingested record to expire at a given time to live (TTL) duration after
 * the record's event time, `ExpiresAt` = `EventTime` +
 * `TtlDuration`, by specifying the `TtlDuration` parameter. A record
 * level `TtlDuration` is set when specifying the `TtlDuration`
 * parameter using the `PutRecord` API call. If the input `TtlDuration`
 * is `null` or unspecified, `TtlDuration` is set to the default feature
 * group level `TtlDuration`. A record level `TtlDuration` supersedes
 * the group level `TtlDuration`.
 */
export declare const putRecord: API.OperationMethod<PutRecordRequest, PutRecordResponse, PutRecordError, Credentials | HttpClient.HttpClient>;
export type UpdateRecordError = AccessForbidden | ConflictException | InternalFailure | ResourceNotFound | ServiceUnavailable | ValidationError | CommonErrors;
/**
 * Updates one or more feature values for an existing record in the specified
 * feature group. Features that you do not include in the request remain unchanged.
 * You can update up to 100 features per call.
 *
 * This operation is available only for feature groups that use the
 * `Standard_V2` or `InMemory` online store type.
 *
 * The record must already exist. If the record does not exist or has been
 * soft-deleted, the operation returns a `ResourceNotFound` error. To create
 * a record, use `PutRecord`.
 *
 * If you provide an `EventTime` that is older than the record's current
 * `EventTime`, the service rejects the update with a
 * `ConflictException`. If the `EventTime` is equal to or newer
 * than the current value, the service applies the update. If you omit
 * `EventTime`, the service keeps the record's existing
 * `EventTime` and applies the update.
 *
 * If you specify a `TtlDuration`, you must also provide an
 * `EventTime` in the request. Otherwise, the operation returns a
 * `ValidationError`.
 */
export declare const updateRecord: API.OperationMethod<UpdateRecordRequest, UpdateRecordResponse, UpdateRecordError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=sagemaker-featurestore-runtime.d.ts.map