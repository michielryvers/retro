import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnprocessableEntityException_base: S.TaggedErrorClass<"UnprocessableEntityException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableEntityException extends /*@__PURE__*/ UnprocessableEntityException_base {
}
export interface AssociateCertificateRequest {
    Arn?: string;
}
export interface AssociateCertificateResponse {
}
export interface CancelJobRequest {
    Id: string;
}
export interface CancelJobResponse {
}
export type AccelerationMode = "DISABLED" | "ENABLED" | "PREFERRED" | (string & {});
export interface AccelerationSettings {
    Mode?: AccelerationMode;
}
export type BillingTagsSource = "QUEUE" | "PRESET" | "JOB_TEMPLATE" | "JOB" | (string & {});
export type __integerMinNegative50Max50 = number;
export interface HopDestination {
    Priority?: number;
    Queue?: string;
    WaitMinutes?: number;
}
export type __listOfHopDestination = HopDestination[];
export type __integerMinNegative1000Max1000 = number;
export type __stringMin14PatternS3BmpBMPPngPNGHttpsBmpBMPPngPNG = string;
export interface AvailBlanking {
    AvailBlankingImage?: string;
}
export type __stringMin14PatternS3CubeCUBEHttpsCubeCUBE = string;
export type ColorSpace = "FOLLOW" | "REC_601" | "REC_709" | "HDR10" | "HLG_2020" | "P3DCI" | "P3D65_SDR" | "P3D65_HDR" | (string & {});
export type __integerMin0Max2147483647 = number;
export interface ColorConversion3DLUTSetting {
    FileInput?: string;
    InputColorSpace?: ColorSpace;
    InputMasteringLuminance?: number;
    OutputColorSpace?: ColorSpace;
    OutputMasteringLuminance?: number;
}
export type __listOfColorConversion3DLUTSetting = ColorConversion3DLUTSetting[];
export type __stringPatternSNManifestConfirmConditionNotificationNS = string;
export interface EsamManifestConfirmConditionNotification {
    MccXml?: string;
}
export type __integerMin0Max30000 = number;
export type __stringPatternSNSignalProcessingNotificationNS = string;
export interface EsamSignalProcessingNotification {
    SccXml?: string;
}
export interface EsamSettings {
    ManifestConfirmConditionNotification?: EsamManifestConfirmConditionNotification;
    ResponseSignalPreroll?: number;
    SignalProcessingNotification?: EsamSignalProcessingNotification;
}
export type CopyProtectionAction = "PASSTHROUGH" | "STRIP" | (string & {});
export type VchipAction = "PASSTHROUGH" | "STRIP" | (string & {});
export interface ExtendedDataServices {
    CopyProtectionAction?: CopyProtectionAction;
    VchipAction?: VchipAction;
}
export type __integerMin1Max150 = number;
export type AdvancedInputFilter = "ENABLED" | "DISABLED" | (string & {});
export type AdvancedInputFilterAddTexture = "ENABLED" | "DISABLED" | (string & {});
export type AdvancedInputFilterSharpen = "OFF" | "LOW" | "HIGH" | (string & {});
export interface AdvancedInputFilterSettings {
    AddTexture?: AdvancedInputFilterAddTexture;
    Sharpening?: AdvancedInputFilterSharpen;
}
export type __stringMin1 = string;
export type __listOf__stringMin1 = string[];
export interface AudioSelectorGroup {
    AudioSelectorNames?: string[];
}
export type __mapOfAudioSelectorGroup = {
    [key: string]: AudioSelectorGroup | undefined;
};
export type AudioDurationCorrection = "DISABLED" | "AUTO" | "TRACK" | "FRAME" | "FORCE" | (string & {});
export type __stringMin3Max3PatternAZaZ3 = string;
export type AudioDefaultSelection = "DEFAULT" | "NOT_DEFAULT" | (string & {});
export type __stringPatternS3Https = string;
export type LanguageCode = "ENG" | "SPA" | "FRA" | "DEU" | "GER" | "ZHO" | "ARA" | "HIN" | "JPN" | "RUS" | "POR" | "ITA" | "URD" | "VIE" | "KOR" | "PAN" | "ABK" | "AAR" | "AFR" | "AKA" | "SQI" | "AMH" | "ARG" | "HYE" | "ASM" | "AVA" | "AVE" | "AYM" | "AZE" | "BAM" | "BAK" | "EUS" | "BEL" | "BEN" | "BIH" | "BIS" | "BOS" | "BRE" | "BUL" | "MYA" | "CAT" | "KHM" | "CHA" | "CHE" | "NYA" | "CHU" | "CHV" | "COR" | "COS" | "CRE" | "HRV" | "CES" | "DAN" | "DIV" | "NLD" | "DZO" | "ENM" | "EPO" | "EST" | "EWE" | "FAO" | "FIJ" | "FIN" | "FRM" | "FUL" | "GLA" | "GLG" | "LUG" | "KAT" | "ELL" | "GRN" | "GUJ" | "HAT" | "HAU" | "HEB" | "HER" | "HMO" | "HUN" | "ISL" | "IDO" | "IBO" | "IND" | "INA" | "ILE" | "IKU" | "IPK" | "GLE" | "JAV" | "KAL" | "KAN" | "KAU" | "KAS" | "KAZ" | "KIK" | "KIN" | "KIR" | "KOM" | "KON" | "KUA" | "KUR" | "LAO" | "LAT" | "LAV" | "LIM" | "LIN" | "LIT" | "LUB" | "LTZ" | "MKD" | "MLG" | "MSA" | "MAL" | "MLT" | "GLV" | "MRI" | "MAR" | "MAH" | "MON" | "NAU" | "NAV" | "NDE" | "NBL" | "NDO" | "NEP" | "SME" | "NOR" | "NOB" | "NNO" | "OCI" | "OJI" | "ORI" | "ORM" | "OSS" | "PLI" | "FAS" | "POL" | "PUS" | "QUE" | "QAA" | "RON" | "ROH" | "RUN" | "SMO" | "SAG" | "SAN" | "SRD" | "SRB" | "SNA" | "III" | "SND" | "SIN" | "SLK" | "SLV" | "SOM" | "SOT" | "SUN" | "SWA" | "SSW" | "SWE" | "TGL" | "TAH" | "TGK" | "TAM" | "TAT" | "TEL" | "THA" | "BOD" | "TIR" | "TON" | "TSO" | "TSN" | "TUR" | "TUK" | "TWI" | "UIG" | "UKR" | "UZB" | "VEN" | "VOL" | "WLN" | "CYM" | "FRY" | "WOL" | "XHO" | "YID" | "YOR" | "ZHA" | "ZUL" | "ORJ" | "QPC" | "TNG" | "SRP" | (string & {});
export interface HlsRenditionGroupSettings {
    RenditionGroupId?: string;
    RenditionLanguageCode?: LanguageCode;
    RenditionName?: string;
}
export type __integerMinNegative2147483648Max2147483647 = number;
export type __integerMin1Max2147483647 = number;
export type __listOf__integerMin1Max2147483647 = number[];
export type __integerMin0Max8 = number;
export type __integerMin1Max64 = number;
export type __integerMinNegative60Max6 = number;
export type __listOf__integerMinNegative60Max6 = number[];
export type __doubleMinNegative60Max6 = number;
export type __listOf__doubleMinNegative60Max6 = number[];
export interface OutputChannelMapping {
    InputChannels?: number[];
    InputChannelsFineTune?: number[];
}
export type __listOfOutputChannelMapping = OutputChannelMapping[];
export interface ChannelMapping {
    OutputChannels?: OutputChannelMapping[];
}
export interface RemixSettings {
    AudioDescriptionAudioChannel?: number;
    AudioDescriptionDataChannel?: number;
    ChannelMapping?: ChannelMapping;
    ChannelsIn?: number;
    ChannelsOut?: number;
}
export type AudioSelectorType = "PID" | "TRACK" | "LANGUAGE_CODE" | "HLS_RENDITION_GROUP" | "ALL_PCM" | "STREAM" | (string & {});
export type AudioSmpte337Passthrough = "ENABLED" | "DISABLED" | (string & {});
export interface AudioSelector {
    AudioDurationCorrection?: AudioDurationCorrection;
    CustomLanguageCode?: string;
    DefaultSelection?: AudioDefaultSelection;
    ExternalAudioFileInput?: string;
    HlsRenditionGroupSettings?: HlsRenditionGroupSettings;
    LanguageCode?: LanguageCode;
    Offset?: number;
    Pids?: number[];
    ProgramSelection?: number;
    RemixSettings?: RemixSettings;
    SelectorType?: AudioSelectorType;
    Smpte337Passthrough?: AudioSmpte337Passthrough;
    Streams?: number[];
    Tracks?: number[];
}
export type __mapOfAudioSelector = {
    [key: string]: AudioSelector | undefined;
};
export type AncillaryConvert608To708 = "UPCONVERT" | "DISABLED" | (string & {});
export type __integerMin1Max4 = number;
export type AncillaryTerminateCaptions = "END_OF_INPUT" | "DISABLED" | (string & {});
export interface AncillarySourceSettings {
    Convert608To708?: AncillaryConvert608To708;
    SourceAncillaryChannelNumber?: number;
    TerminateCaptions?: AncillaryTerminateCaptions;
}
export interface DvbSubSourceSettings {
    Pid?: number;
}
export type EmbeddedConvert608To708 = "UPCONVERT" | "DISABLED" | (string & {});
export type __integerMin1Max1 = number;
export type EmbeddedTerminateCaptions = "END_OF_INPUT" | "DISABLED" | (string & {});
export interface EmbeddedSourceSettings {
    Convert608To708?: EmbeddedConvert608To708;
    Source608ChannelNumber?: number;
    Source608TrackNumber?: number;
    TerminateCaptions?: EmbeddedTerminateCaptions;
}
export type CaptionSourceByteRateLimit = "ENABLED" | "DISABLED" | (string & {});
export type FileSourceConvert608To708 = "UPCONVERT" | "DISABLED" | (string & {});
export type CaptionSourceConvertPaintOnToPopOn = "ENABLED" | "DISABLED" | (string & {});
export type __integerMin1Max1001 = number;
export type __integerMin1Max60000 = number;
export interface CaptionSourceFramerate {
    FramerateDenominator?: number;
    FramerateNumerator?: number;
}
export type __stringMin14PatternS3SccSCCTtmlTTMLDfxpDFXPStlSTLSrtSRTXmlXMLSmiSMIVttVTTWebvttWEBVTTHttpsSccSCCTtmlTTMLDfxpDFXPStlSTLSrtSRTXmlXMLSmiSMIVttVTTWebvttWEBVTT = string;
export type FileSourceTimeDeltaUnits = "SECONDS" | "MILLISECONDS" | (string & {});
export type CaptionSourceUpconvertSTLToTeletext = "UPCONVERT" | "DISABLED" | (string & {});
export interface FileSourceSettings {
    ByteRateLimit?: CaptionSourceByteRateLimit;
    Convert608To708?: FileSourceConvert608To708;
    ConvertPaintToPop?: CaptionSourceConvertPaintOnToPopOn;
    Framerate?: CaptionSourceFramerate;
    SourceFile?: string;
    TimeDelta?: number;
    TimeDeltaUnits?: FileSourceTimeDeltaUnits;
    UpconvertSTLToTeletext?: CaptionSourceUpconvertSTLToTeletext;
}
export type CaptionSourceType = "ANCILLARY" | "DVB_SUB" | "EMBEDDED" | "SCTE20" | "SCC" | "TTML" | "STL" | "SRT" | "SMI" | "SMPTE_TT" | "TELETEXT" | "NULL_SOURCE" | "IMSC" | "WEBVTT" | "TT_3GPP" | (string & {});
export type __stringMin3Max3Pattern1809aFAF09aEAE = string;
export interface TeletextSourceSettings {
    PageNumber?: string;
}
export interface TrackSourceSettings {
    StreamNumber?: number;
    TrackNumber?: number;
}
export interface WebvttHlsSourceSettings {
    RenditionGroupId?: string;
    RenditionLanguageCode?: LanguageCode;
    RenditionName?: string;
}
export interface CaptionSourceSettings {
    AncillarySourceSettings?: AncillarySourceSettings;
    DvbSubSourceSettings?: DvbSubSourceSettings;
    EmbeddedSourceSettings?: EmbeddedSourceSettings;
    FileSourceSettings?: FileSourceSettings;
    SourceType?: CaptionSourceType;
    TeletextSourceSettings?: TeletextSourceSettings;
    TrackSourceSettings?: TrackSourceSettings;
    WebvttHlsSourceSettings?: WebvttHlsSourceSettings;
}
export interface CaptionSelector {
    CustomLanguageCode?: string;
    LanguageCode?: LanguageCode;
    SourceSettings?: CaptionSourceSettings;
}
export type __mapOfCaptionSelector = {
    [key: string]: CaptionSelector | undefined;
};
export type __integerMin2Max2147483647 = number;
export interface Rectangle {
    Height?: number;
    Width?: number;
    X?: number;
    Y?: number;
}
export type InputDeblockFilter = "ENABLED" | "DISABLED" | (string & {});
export type DecryptionMode = "AES_CTR" | "AES_CBC" | "AES_GCM" | (string & {});
export type __stringMin24Max512PatternAZaZ0902 = string;
export type __stringMin16Max24PatternAZaZ0922AZaZ0916 = string;
export type __stringMin9Max19PatternAZ26EastWestCentralNorthSouthEastWest1912 = string;
export interface InputDecryptionSettings {
    DecryptionMode?: DecryptionMode;
    EncryptedDecryptionKey?: string;
    InitializationVector?: string;
    KmsKeyRegion?: string;
}
export type InputDenoiseFilter = "ENABLED" | "DISABLED" | (string & {});
export type __stringMin14PatternS3XmlXMLHttpsXmlXML = string;
export type DynamicAudioSelectorType = "ALL_TRACKS" | "LANGUAGE_CODE" | (string & {});
export interface DynamicAudioSelector {
    AudioDurationCorrection?: AudioDurationCorrection;
    ExternalAudioFileInput?: string;
    LanguageCode?: LanguageCode;
    Offset?: number;
    SelectorType?: DynamicAudioSelectorType;
}
export type __mapOfDynamicAudioSelector = {
    [key: string]: DynamicAudioSelector | undefined;
};
export type __stringMax2048PatternS3Https = string;
export type InputFilterEnable = "AUTO" | "DISABLE" | "FORCE" | (string & {});
export type __integerMin0Max5 = number;
export type __stringMin14PatternS3BmpBMPPngPNGTgaTGAHttpsBmpBMPPngPNGTgaTGA = string;
export type __integerMin0Max99 = number;
export type __integerMin0Max100 = number;
export type __stringPattern01D20305D205D = string;
export interface InsertableImage {
    Duration?: number;
    FadeIn?: number;
    FadeOut?: number;
    Height?: number;
    ImageInserterInput?: string;
    ImageX?: number;
    ImageY?: number;
    Layer?: number;
    Opacity?: number;
    StartTime?: string;
    Width?: number;
}
export type __listOfInsertableImage = InsertableImage[];
export type __integerMin100Max1000 = number;
export interface ImageInserter {
    InsertableImages?: InsertableImage[];
    SdrReferenceWhiteLevel?: number;
}
export type __stringPattern010920405090509092090909 = string;
export interface InputClipping {
    EndTimecode?: string;
    StartTimecode?: string;
}
export type __listOfInputClipping = InputClipping[];
export type InputScanType = "AUTO" | "PSF" | (string & {});
export interface MultiViewInput {
    FileInput?: string;
}
export interface MultiViewSettings {
    Input?: MultiViewInput;
}
export type __listOfMultiViewSettings = MultiViewSettings[];
export type InputPsiControl = "IGNORE_PSI" | "USE_PSI" | (string & {});
export type __stringPatternS3ASSETMAPXml = string;
export type __listOf__stringPatternS3ASSETMAPXml = string[];
export type __stringPatternArnAwsAZ09EventsAZ090912ConnectionAZAZ09AF0936 = string;
export type TamsGapHandling = "SKIP_GAPS" | "FILL_WITH_BLACK" | "HOLD_LAST_FRAME" | (string & {});
export type __stringPattern019090190908019090190908 = string;
export interface InputTamsSettings {
    AuthConnectionArn?: string;
    GapHandling?: TamsGapHandling;
    SourceId?: string;
    Timerange?: string;
}
export type InputTimecodeSource = "EMBEDDED" | "ZEROBASED" | "SPECIFIEDSTART" | (string & {});
export type __stringMin11Max11Pattern01D20305D205D = string;
export type __integerMin1Max32 = number;
export type __integerMin1Max86400000 = number;
export type __integerMin32Max8192 = number;
export type __integerMin32000Max48000 = number;
export interface InputVideoGenerator {
    Channels?: number;
    Duration?: number;
    FramerateDenominator?: number;
    FramerateNumerator?: number;
    Height?: number;
    ImageInput?: string;
    SampleRate?: number;
    Width?: number;
}
export type VideoOverlayUnit = "PIXELS" | "PERCENTAGE" | (string & {});
export interface VideoOverlayCrop {
    Height?: number;
    Unit?: VideoOverlayUnit;
    Width?: number;
    X?: number;
    Y?: number;
}
export type __stringPattern010920405090509092 = string;
export type __integerMinNegative1Max2147483647 = number;
export interface VideoOverlayPosition {
    Height?: number;
    Opacity?: number;
    Unit?: VideoOverlayUnit;
    Width?: number;
    XPosition?: number;
    YPosition?: number;
}
export interface VideoOverlayInputClipping {
    EndTimecode?: string;
    StartTimecode?: string;
}
export type __listOfVideoOverlayInputClipping = VideoOverlayInputClipping[];
export interface VideoOverlayInput {
    AudioSelectors?: {
        [key: string]: AudioSelector | undefined;
    };
    FileInput?: string;
    InputClippings?: VideoOverlayInputClipping[];
    TimecodeSource?: InputTimecodeSource;
    TimecodeStart?: string;
}
export type VideoOverlayPlayBackMode = "ONCE" | "REPEAT" | (string & {});
export interface VideoOverlayTransition {
    EndPosition?: VideoOverlayPosition;
    EndTimecode?: string;
    StartTimecode?: string;
}
export type __listOfVideoOverlayTransition = VideoOverlayTransition[];
export interface VideoOverlay {
    Crop?: VideoOverlayCrop;
    EndTimecode?: string;
    InitialPosition?: VideoOverlayPosition;
    Input?: VideoOverlayInput;
    Playback?: VideoOverlayPlayBackMode;
    StartTimecode?: string;
    Transitions?: VideoOverlayTransition[];
}
export type __listOfVideoOverlay = VideoOverlay[];
export type AlphaBehavior = "DISCARD" | "REMAP_TO_LUMA" | (string & {});
export type ColorSpaceUsage = "FORCE" | "FALLBACK" | (string & {});
export type EmbeddedTimecodeOverride = "NONE" | "USE_MDPM" | (string & {});
export type __integerMin0Max50000 = number;
export type __integerMin0Max65535 = number;
export interface Hdr10Metadata {
    BluePrimaryX?: number;
    BluePrimaryY?: number;
    GreenPrimaryX?: number;
    GreenPrimaryY?: number;
    MaxContentLightLevel?: number;
    MaxFrameAverageLightLevel?: number;
    MaxLuminance?: number;
    MinLuminance?: number;
    RedPrimaryX?: number;
    RedPrimaryY?: number;
    WhitePointX?: number;
    WhitePointY?: number;
}
export type PadVideo = "DISABLED" | "BLACK" | (string & {});
export type InputRotate = "DEGREE_0" | "DEGREES_90" | "DEGREES_180" | "DEGREES_270" | "AUTO" | (string & {});
export type InputSampleRange = "FOLLOW" | "FULL_RANGE" | "LIMITED_RANGE" | (string & {});
export type VideoSelectorType = "AUTO" | "STREAM" | (string & {});
export interface VideoSelector {
    AlphaBehavior?: AlphaBehavior;
    ColorSpace?: ColorSpace;
    ColorSpaceUsage?: ColorSpaceUsage;
    EmbeddedTimecodeOverride?: EmbeddedTimecodeOverride;
    Hdr10Metadata?: Hdr10Metadata;
    MaxLuminance?: number;
    PadVideo?: PadVideo;
    Pid?: number;
    ProgramNumber?: number;
    Rotate?: InputRotate;
    SampleRange?: InputSampleRange;
    SelectorType?: VideoSelectorType;
    Streams?: number[];
}
export interface Input {
    AdvancedInputFilter?: AdvancedInputFilter;
    AdvancedInputFilterSettings?: AdvancedInputFilterSettings;
    AudioSelectorGroups?: {
        [key: string]: AudioSelectorGroup | undefined;
    };
    AudioSelectors?: {
        [key: string]: AudioSelector | undefined;
    };
    CaptionSelectors?: {
        [key: string]: CaptionSelector | undefined;
    };
    Crop?: Rectangle;
    DeblockFilter?: InputDeblockFilter;
    DecryptionSettings?: InputDecryptionSettings;
    DenoiseFilter?: InputDenoiseFilter;
    DolbyVisionMetadataXml?: string;
    DynamicAudioSelectors?: {
        [key: string]: DynamicAudioSelector | undefined;
    };
    FileInput?: string;
    FilterEnable?: InputFilterEnable;
    FilterStrength?: number;
    ImageInserter?: ImageInserter;
    InputClippings?: InputClipping[];
    InputScanType?: InputScanType;
    MultiViewSettings?: MultiViewSettings[];
    Position?: Rectangle;
    ProgramNumber?: number;
    PsiControl?: InputPsiControl;
    SupplementalImps?: string[];
    TamsSettings?: InputTamsSettings;
    TimecodeSource?: InputTimecodeSource;
    TimecodeStart?: string;
    VideoGenerator?: InputVideoGenerator;
    VideoOverlays?: VideoOverlay[];
    VideoSelector?: VideoSelector;
}
export type __listOfInput = Input[];
export type __stringMin1Max20 = string;
export type __stringMin1Max50PatternAZAZ09 = string;
export type __stringMin1Max2048PatternArnAZSecretsmanagerWD12SecretAZAZ09 = string;
export type __doubleMin0 = number;
export type __stringPatternHttpsKantarmedia55Prod = string;
export type __stringPatternS3 = string;
export type __stringMin1Max50 = string;
export interface KantarWatermarkSettings {
    ChannelName?: string;
    ContentReference?: string;
    CredentialsSecretName?: string;
    FileOffset?: number;
    KantarLicenseId?: number;
    KantarServerUrl?: string;
    LogDestination?: string;
    Metadata3?: string;
    Metadata4?: string;
    Metadata5?: string;
    Metadata6?: string;
    Metadata7?: string;
    Metadata8?: string;
}
export type __integerMin1Max17895697 = number;
export type __integerMin1Max2147483640 = number;
export interface MotionImageInsertionFramerate {
    FramerateDenominator?: number;
    FramerateNumerator?: number;
}
export type __stringMin14PatternS3Mov09PngHttpsMov09Png = string;
export type MotionImageInsertionMode = "MOV" | "PNG" | (string & {});
export interface MotionImageInsertionOffset {
    ImageX?: number;
    ImageY?: number;
}
export type MotionImagePlayback = "ONCE" | "REPEAT" | (string & {});
export interface MotionImageInserter {
    Framerate?: MotionImageInsertionFramerate;
    Input?: string;
    InsertionMode?: MotionImageInsertionMode;
    Offset?: MotionImageInsertionOffset;
    Playback?: MotionImagePlayback;
    StartTime?: string;
}
export type __listOfMotionImageInserter = MotionImageInserter[];
export type __integerMin0Max0 = number;
export interface NielsenConfiguration {
    BreakoutCode?: number;
    DistributorId?: string;
}
export type NielsenActiveWatermarkProcessType = "NAES2_AND_NW" | "CBET" | "NAES2_AND_NW_AND_CBET" | (string & {});
export type __stringPattern0xAFaF0908190908 = string;
export type __integerMin0Max65534 = number;
export type NielsenSourceWatermarkStatusType = "CLEAN" | "WATERMARKED" | (string & {});
export type __stringPatternHttps = string;
export type NielsenUniqueTicPerAudioTrackType = "RESERVE_UNIQUE_TICS_PER_TRACK" | "SAME_TICS_PER_TRACK" | (string & {});
export interface NielsenNonLinearWatermarkSettings {
    ActiveWatermarkProcess?: NielsenActiveWatermarkProcessType;
    AdiFilename?: string;
    AssetId?: string;
    AssetName?: string;
    CbetSourceId?: string;
    EpisodeId?: string;
    MetadataDestination?: string;
    SourceId?: number;
    SourceWatermarkStatus?: NielsenSourceWatermarkStatusType;
    TicServerUrl?: string;
    UniqueTicPerAudioTrack?: NielsenUniqueTicPerAudioTrackType;
}
export type __integerMin100000Max100000000 = number;
export type __doubleMin1Max10 = number;
export type __integerMin3Max15 = number;
export type RequiredFlag = "ENABLED" | "DISABLED" | (string & {});
export interface AllowedRenditionSize {
    Height?: number;
    Required?: RequiredFlag;
    Width?: number;
}
export type __listOfAllowedRenditionSize = AllowedRenditionSize[];
export interface ForceIncludeRenditionSize {
    Height?: number;
    Width?: number;
}
export type __listOfForceIncludeRenditionSize = ForceIncludeRenditionSize[];
export interface MinBottomRenditionSize {
    Height?: number;
    Width?: number;
}
export interface MinTopRenditionSize {
    Height?: number;
    Width?: number;
}
export type RuleType = "MIN_TOP_RENDITION_SIZE" | "MIN_BOTTOM_RENDITION_SIZE" | "FORCE_INCLUDE_RENDITIONS" | "ALLOWED_RENDITIONS" | (string & {});
export interface AutomatedAbrRule {
    AllowedRenditions?: AllowedRenditionSize[];
    ForceIncludeRenditions?: ForceIncludeRenditionSize[];
    MinBottomRenditionSize?: MinBottomRenditionSize;
    MinTopRenditionSize?: MinTopRenditionSize;
    Type?: RuleType;
}
export type __listOfAutomatedAbrRule = AutomatedAbrRule[];
export interface AutomatedAbrSettings {
    MaxAbrBitrate?: number;
    MaxQualityLevel?: number;
    MaxRenditions?: number;
    MinAbrBitrate?: number;
    Rules?: AutomatedAbrRule[];
}
export interface AutomatedEncodingSettings {
    AbrSettings?: AutomatedAbrSettings;
}
export type __stringMax2048 = string;
export interface CmafAdditionalManifest {
    ManifestNameModifier?: string;
    SelectedOutputs?: string[];
}
export type __listOfCmafAdditionalManifest = CmafAdditionalManifest[];
export type CmafClientCache = "DISABLED" | "ENABLED" | (string & {});
export type CmafCodecSpecification = "RFC_6381" | "RFC_4281" | (string & {});
export type __stringMin1Max256 = string;
export type DashManifestStyle = "BASIC" | "COMPACT" | "DISTINCT" | "FULL" | (string & {});
export type S3ObjectCannedAcl = "PUBLIC_READ" | "AUTHENTICATED_READ" | "BUCKET_OWNER_READ" | "BUCKET_OWNER_FULL_CONTROL" | (string & {});
export interface S3DestinationAccessControl {
    CannedAcl?: S3ObjectCannedAcl;
}
export type S3ServerSideEncryptionType = "SERVER_SIDE_ENCRYPTION_S3" | "SERVER_SIDE_ENCRYPTION_KMS" | (string & {});
export type __stringPatternAZaZ0902 = string;
export type __stringPatternArnAwsUsGovCnKmsAZ26EastWestCentralNorthSouthEastWest1912D12KeyAFAF098AFAF094AFAF094AFAF094AFAF0912MrkAFAF0932 = string;
export interface S3EncryptionSettings {
    EncryptionType?: S3ServerSideEncryptionType;
    KmsEncryptionContext?: string;
    KmsKeyArn?: string;
}
export type S3StorageClass = "STANDARD" | "REDUCED_REDUNDANCY" | "STANDARD_IA" | "ONEZONE_IA" | "INTELLIGENT_TIERING" | "GLACIER" | "DEEP_ARCHIVE" | "GLACIER_IR" | (string & {});
export interface S3DestinationSettings {
    AccessControl?: S3DestinationAccessControl;
    Encryption?: S3EncryptionSettings;
    StorageClass?: S3StorageClass;
}
export interface DestinationSettings {
    S3Settings?: S3DestinationSettings;
}
export type __integerMin1Max9999 = number;
export type __stringMin32Max32Pattern09aFAF32 = string;
export type CmafEncryptionType = "SAMPLE_AES" | "AES_CTR" | (string & {});
export type CmafInitializationVectorInManifest = "INCLUDE" | "EXCLUDE" | (string & {});
export type __stringPatternArnAwsUsGovAcm = string;
export type __stringMin36Max36Pattern09aFAF809aFAF409aFAF409aFAF409aFAF12 = string;
export type __listOf__stringMin36Max36Pattern09aFAF809aFAF409aFAF409aFAF409aFAF12 = string[];
export type PresetSpeke20Audio = "PRESET_AUDIO_1" | "PRESET_AUDIO_2" | "PRESET_AUDIO_3" | "SHARED" | "UNENCRYPTED" | (string & {});
export type PresetSpeke20Video = "PRESET_VIDEO_1" | "PRESET_VIDEO_2" | "PRESET_VIDEO_3" | "PRESET_VIDEO_4" | "PRESET_VIDEO_5" | "PRESET_VIDEO_6" | "PRESET_VIDEO_7" | "PRESET_VIDEO_8" | "SHARED" | "UNENCRYPTED" | (string & {});
export interface EncryptionContractConfiguration {
    SpekeAudioPreset?: PresetSpeke20Audio;
    SpekeVideoPreset?: PresetSpeke20Video;
}
export type __stringPatternW = string;
export type __stringPatternHttpsD = string;
export interface SpekeKeyProviderCmaf {
    CertificateArn?: string;
    DashSignaledSystemIds?: string[];
    EncryptionContractConfiguration?: EncryptionContractConfiguration;
    HlsSignaledSystemIds?: string[];
    ResourceId?: string;
    Url?: string;
}
export type __stringPatternIdentityAZaZ26AZaZ09163 = string;
export type __stringPatternDD = string;
export type __stringPatternAZaZ0932 = string;
export interface StaticKeyProvider {
    KeyFormat?: string;
    KeyFormatVersions?: string;
    StaticKeyValue?: string | redacted.Redacted<string>;
    Url?: string;
}
export type CmafKeyProviderType = "SPEKE" | "STATIC_KEY" | (string & {});
export interface CmafEncryptionSettings {
    ClearLeadSegments?: number;
    ConstantInitializationVector?: string;
    EncryptionMethod?: CmafEncryptionType;
    InitializationVectorInManifest?: CmafInitializationVectorInManifest;
    SpekeKeyProvider?: SpekeKeyProviderCmaf;
    StaticKeyProvider?: StaticKeyProvider;
    Type?: CmafKeyProviderType;
}
export type CmafImageBasedTrickPlay = "NONE" | "THUMBNAIL" | "THUMBNAIL_AND_FULLFRAME" | "ADVANCED" | "VARIANTS" | (string & {});
export type CmafIntervalCadence = "FOLLOW_IFRAME" | "FOLLOW_CUSTOM" | "FOLLOW_SEGMENTATION" | (string & {});
export type __integerMin2Max4096 = number;
export type __doubleMin0Max2147483647 = number;
export type __integerMin8Max4096 = number;
export type __integerMin1Max2048 = number;
export type __integerMin1Max512 = number;
export interface CmafImageBasedTrickPlaySettings {
    IntervalCadence?: CmafIntervalCadence;
    ThumbnailHeight?: number;
    ThumbnailInterval?: number;
    ThumbnailWidth?: number;
    TileHeight?: number;
    TileWidth?: number;
}
export interface CmafImageBasedTrickPlayVariant {
    IntervalCadence?: CmafIntervalCadence;
    ThumbnailHeight?: number;
    ThumbnailInterval?: number;
    ThumbnailWidth?: number;
    TileHeight?: number;
    TileWidth?: number;
}
export type __listOfCmafImageBasedTrickPlayVariant = CmafImageBasedTrickPlayVariant[];
export type CmafManifestCompression = "GZIP" | "NONE" | (string & {});
export type CmafManifestDurationFormat = "FLOATING_POINT" | "INTEGER" | (string & {});
export type CmafMpdManifestBandwidthType = "AVERAGE" | "MAX" | (string & {});
export type CmafMpdProfile = "MAIN_PROFILE" | "ON_DEMAND_PROFILE" | (string & {});
export type CmafPtsOffsetHandlingForBFrames = "ZERO_BASED" | "MATCH_INITIAL_PTS" | (string & {});
export type CmafSegmentControl = "SINGLE_FILE" | "SEGMENTED_FILES" | (string & {});
export type CmafSegmentLengthControl = "EXACT" | "GOP_MULTIPLE" | "MATCH" | (string & {});
export type CmafStreamInfResolution = "INCLUDE" | "EXCLUDE" | (string & {});
export type CmafTargetDurationCompatibilityMode = "LEGACY" | "SPEC_COMPLIANT" | (string & {});
export type CmafVideoCompositionOffsets = "SIGNED" | "UNSIGNED" | (string & {});
export type CmafWriteDASHManifest = "DISABLED" | "ENABLED" | (string & {});
export type CmafWriteHLSManifest = "DISABLED" | "ENABLED" | (string & {});
export type CmafWriteSegmentTimelineInRepresentation = "ENABLED" | "DISABLED" | (string & {});
export interface CmafGroupSettings {
    AdditionalManifests?: CmafAdditionalManifest[];
    BaseUrl?: string;
    ClientCache?: CmafClientCache;
    CodecSpecification?: CmafCodecSpecification;
    DashIFrameTrickPlayNameModifier?: string;
    DashManifestStyle?: DashManifestStyle;
    Destination?: string;
    DestinationSettings?: DestinationSettings;
    Encryption?: CmafEncryptionSettings;
    FragmentLength?: number;
    ImageBasedTrickPlay?: CmafImageBasedTrickPlay;
    ImageBasedTrickPlaySettings?: CmafImageBasedTrickPlaySettings;
    ImageBasedTrickPlayVariants?: CmafImageBasedTrickPlayVariant[];
    ManifestCompression?: CmafManifestCompression;
    ManifestDurationFormat?: CmafManifestDurationFormat;
    MinBufferTime?: number;
    MinFinalSegmentLength?: number;
    MpdManifestBandwidthType?: CmafMpdManifestBandwidthType;
    MpdProfile?: CmafMpdProfile;
    PtsOffsetHandlingForBFrames?: CmafPtsOffsetHandlingForBFrames;
    SegmentControl?: CmafSegmentControl;
    SegmentLength?: number;
    SegmentLengthControl?: CmafSegmentLengthControl;
    StreamInfResolution?: CmafStreamInfResolution;
    TargetDurationCompatibilityMode?: CmafTargetDurationCompatibilityMode;
    VideoCompositionOffsets?: CmafVideoCompositionOffsets;
    WriteDashManifest?: CmafWriteDASHManifest;
    WriteHlsManifest?: CmafWriteHLSManifest;
    WriteSegmentTimelineInRepresentation?: CmafWriteSegmentTimelineInRepresentation;
}
export interface DashAdditionalManifest {
    ManifestNameModifier?: string;
    SelectedOutputs?: string[];
}
export type __listOfDashAdditionalManifest = DashAdditionalManifest[];
export type DashIsoGroupAudioChannelConfigSchemeIdUri = "MPEG_CHANNEL_CONFIGURATION" | "DOLBY_CHANNEL_CONFIGURATION" | (string & {});
export type DashIsoPlaybackDeviceCompatibility = "CENC_V1" | "UNENCRYPTED_SEI" | "CENC_V1_UNENCRYPTED_HEADERS" | (string & {});
export type __stringPattern09aFAF809aFAF409aFAF409aFAF409aFAF12 = string;
export type __listOf__stringPattern09aFAF809aFAF409aFAF409aFAF409aFAF12 = string[];
export interface SpekeKeyProvider {
    CertificateArn?: string;
    EncryptionContractConfiguration?: EncryptionContractConfiguration;
    ResourceId?: string;
    SystemIds?: string[];
    Url?: string;
}
export interface DashIsoEncryptionSettings {
    PlaybackDeviceCompatibility?: DashIsoPlaybackDeviceCompatibility;
    SpekeKeyProvider?: SpekeKeyProvider;
}
export type DashIsoHbbtvCompliance = "HBBTV_1_5" | "NONE" | (string & {});
export type DashIsoImageBasedTrickPlay = "NONE" | "THUMBNAIL" | "THUMBNAIL_AND_FULLFRAME" | "ADVANCED" | "VARIANTS" | (string & {});
export type DashIsoIntervalCadence = "FOLLOW_IFRAME" | "FOLLOW_CUSTOM" | "FOLLOW_SEGMENTATION" | (string & {});
export type __integerMin1Max4096 = number;
export interface DashIsoImageBasedTrickPlaySettings {
    IntervalCadence?: DashIsoIntervalCadence;
    ThumbnailHeight?: number;
    ThumbnailInterval?: number;
    ThumbnailWidth?: number;
    TileHeight?: number;
    TileWidth?: number;
}
export interface DashIsoImageBasedTrickPlayVariant {
    IntervalCadence?: DashIsoIntervalCadence;
    ThumbnailHeight?: number;
    ThumbnailInterval?: number;
    ThumbnailWidth?: number;
    TileHeight?: number;
    TileWidth?: number;
}
export type __listOfDashIsoImageBasedTrickPlayVariant = DashIsoImageBasedTrickPlayVariant[];
export type DashIsoMpdManifestBandwidthType = "AVERAGE" | "MAX" | (string & {});
export type DashIsoMpdProfile = "MAIN_PROFILE" | "ON_DEMAND_PROFILE" | (string & {});
export type DashIsoPtsOffsetHandlingForBFrames = "ZERO_BASED" | "MATCH_INITIAL_PTS" | (string & {});
export type DashIsoSegmentControl = "SINGLE_FILE" | "SEGMENTED_FILES" | (string & {});
export type DashIsoSegmentLengthControl = "EXACT" | "GOP_MULTIPLE" | "MATCH" | (string & {});
export type DashIsoVideoCompositionOffsets = "SIGNED" | "UNSIGNED" | (string & {});
export type DashIsoWriteSegmentTimelineInRepresentation = "ENABLED" | "DISABLED" | (string & {});
export interface DashIsoGroupSettings {
    AdditionalManifests?: DashAdditionalManifest[];
    AudioChannelConfigSchemeIdUri?: DashIsoGroupAudioChannelConfigSchemeIdUri;
    BaseUrl?: string;
    DashIFrameTrickPlayNameModifier?: string;
    DashManifestStyle?: DashManifestStyle;
    Destination?: string;
    DestinationSettings?: DestinationSettings;
    Encryption?: DashIsoEncryptionSettings;
    FragmentLength?: number;
    HbbtvCompliance?: DashIsoHbbtvCompliance;
    ImageBasedTrickPlay?: DashIsoImageBasedTrickPlay;
    ImageBasedTrickPlaySettings?: DashIsoImageBasedTrickPlaySettings;
    ImageBasedTrickPlayVariants?: DashIsoImageBasedTrickPlayVariant[];
    MinBufferTime?: number;
    MinFinalSegmentLength?: number;
    MpdManifestBandwidthType?: DashIsoMpdManifestBandwidthType;
    MpdProfile?: DashIsoMpdProfile;
    PtsOffsetHandlingForBFrames?: DashIsoPtsOffsetHandlingForBFrames;
    SegmentControl?: DashIsoSegmentControl;
    SegmentLength?: number;
    SegmentLengthControl?: DashIsoSegmentLengthControl;
    VideoCompositionOffsets?: DashIsoVideoCompositionOffsets;
    WriteSegmentTimelineInRepresentation?: DashIsoWriteSegmentTimelineInRepresentation;
}
export interface FileGroupSettings {
    Destination?: string;
    DestinationSettings?: DestinationSettings;
}
export type HlsAdMarkers = "ELEMENTAL" | "ELEMENTAL_SCTE35" | (string & {});
export type __listOfHlsAdMarkers = HlsAdMarkers[];
export interface HlsAdditionalManifest {
    ManifestNameModifier?: string;
    SelectedOutputs?: string[];
}
export type __listOfHlsAdditionalManifest = HlsAdditionalManifest[];
export type HlsAudioOnlyHeader = "INCLUDE" | "EXCLUDE" | (string & {});
export interface HlsCaptionLanguageMapping {
    CaptionChannel?: number;
    CustomLanguageCode?: string;
    LanguageCode?: LanguageCode;
    LanguageDescription?: string;
}
export type __listOfHlsCaptionLanguageMapping = HlsCaptionLanguageMapping[];
export type HlsCaptionLanguageSetting = "INSERT" | "OMIT" | "NONE" | (string & {});
export type HlsCaptionSegmentLengthControl = "LARGE_SEGMENTS" | "MATCH_VIDEO" | (string & {});
export type HlsClientCache = "DISABLED" | "ENABLED" | (string & {});
export type HlsCodecSpecification = "RFC_6381" | "RFC_4281" | (string & {});
export type HlsDirectoryStructure = "SINGLE_DIRECTORY" | "SUBDIRECTORY_PER_STREAM" | (string & {});
export type HlsEncryptionType = "AES128" | "SAMPLE_AES" | (string & {});
export type HlsInitializationVectorInManifest = "INCLUDE" | "EXCLUDE" | (string & {});
export type HlsOfflineEncrypted = "ENABLED" | "DISABLED" | (string & {});
export type HlsKeyProviderType = "SPEKE" | "STATIC_KEY" | (string & {});
export interface HlsEncryptionSettings {
    ConstantInitializationVector?: string;
    EncryptionMethod?: HlsEncryptionType;
    InitializationVectorInManifest?: HlsInitializationVectorInManifest;
    OfflineEncrypted?: HlsOfflineEncrypted;
    SpekeKeyProvider?: SpekeKeyProvider;
    StaticKeyProvider?: StaticKeyProvider;
    Type?: HlsKeyProviderType;
}
export type HlsImageBasedTrickPlay = "NONE" | "THUMBNAIL" | "THUMBNAIL_AND_FULLFRAME" | "ADVANCED" | "VARIANTS" | (string & {});
export type HlsIntervalCadence = "FOLLOW_IFRAME" | "FOLLOW_CUSTOM" | "FOLLOW_SEGMENTATION" | (string & {});
export interface HlsImageBasedTrickPlaySettings {
    IntervalCadence?: HlsIntervalCadence;
    ThumbnailHeight?: number;
    ThumbnailInterval?: number;
    ThumbnailWidth?: number;
    TileHeight?: number;
    TileWidth?: number;
}
export interface HlsImageBasedTrickPlayVariant {
    IntervalCadence?: HlsIntervalCadence;
    ThumbnailHeight?: number;
    ThumbnailInterval?: number;
    ThumbnailWidth?: number;
    TileHeight?: number;
    TileWidth?: number;
}
export type __listOfHlsImageBasedTrickPlayVariant = HlsImageBasedTrickPlayVariant[];
export type HlsManifestCompression = "GZIP" | "NONE" | (string & {});
export type HlsManifestDurationFormat = "FLOATING_POINT" | "INTEGER" | (string & {});
export type HlsOutputSelection = "MANIFESTS_AND_SEGMENTS" | "SEGMENTS_ONLY" | (string & {});
export type HlsProgramDateTime = "INCLUDE" | "EXCLUDE" | (string & {});
export type __integerMin0Max3600 = number;
export type HlsProgressiveWriteHlsManifest = "ENABLED" | "DISABLED" | (string & {});
export type HlsSegmentControl = "SINGLE_FILE" | "SEGMENTED_FILES" | (string & {});
export type HlsSegmentLengthControl = "EXACT" | "GOP_MULTIPLE" | "MATCH" | (string & {});
export type HlsStreamInfResolution = "INCLUDE" | "EXCLUDE" | (string & {});
export type HlsTargetDurationCompatibilityMode = "LEGACY" | "SPEC_COMPLIANT" | (string & {});
export type HlsTimedMetadataId3Frame = "NONE" | "PRIV" | "TDRL" | (string & {});
export interface HlsGroupSettings {
    AdMarkers?: HlsAdMarkers[];
    AdditionalManifests?: HlsAdditionalManifest[];
    AudioOnlyHeader?: HlsAudioOnlyHeader;
    BaseUrl?: string;
    CaptionLanguageMappings?: HlsCaptionLanguageMapping[];
    CaptionLanguageSetting?: HlsCaptionLanguageSetting;
    CaptionSegmentLengthControl?: HlsCaptionSegmentLengthControl;
    ClientCache?: HlsClientCache;
    CodecSpecification?: HlsCodecSpecification;
    Destination?: string;
    DestinationSettings?: DestinationSettings;
    DirectoryStructure?: HlsDirectoryStructure;
    Encryption?: HlsEncryptionSettings;
    ImageBasedTrickPlay?: HlsImageBasedTrickPlay;
    ImageBasedTrickPlaySettings?: HlsImageBasedTrickPlaySettings;
    ImageBasedTrickPlayVariants?: HlsImageBasedTrickPlayVariant[];
    ManifestCompression?: HlsManifestCompression;
    ManifestDurationFormat?: HlsManifestDurationFormat;
    MinFinalSegmentLength?: number;
    MinSegmentLength?: number;
    OutputSelection?: HlsOutputSelection;
    ProgramDateTime?: HlsProgramDateTime;
    ProgramDateTimePeriod?: number;
    ProgressiveWriteHlsManifest?: HlsProgressiveWriteHlsManifest;
    SegmentControl?: HlsSegmentControl;
    SegmentLength?: number;
    SegmentLengthControl?: HlsSegmentLengthControl;
    SegmentsPerSubdirectory?: number;
    StreamInfResolution?: HlsStreamInfResolution;
    TargetDurationCompatibilityMode?: HlsTargetDurationCompatibilityMode;
    TimedMetadataId3Frame?: HlsTimedMetadataId3Frame;
    TimedMetadataId3Period?: number;
    TimestampDeltaMilliseconds?: number;
}
export interface MsSmoothAdditionalManifest {
    ManifestNameModifier?: string;
    SelectedOutputs?: string[];
}
export type __listOfMsSmoothAdditionalManifest = MsSmoothAdditionalManifest[];
export type MsSmoothAudioDeduplication = "COMBINE_DUPLICATE_STREAMS" | "NONE" | (string & {});
export interface MsSmoothEncryptionSettings {
    SpekeKeyProvider?: SpekeKeyProvider;
}
export type MsSmoothFragmentLengthControl = "EXACT" | "GOP_MULTIPLE" | (string & {});
export type MsSmoothManifestEncoding = "UTF8" | "UTF16" | (string & {});
export interface MsSmoothGroupSettings {
    AdditionalManifests?: MsSmoothAdditionalManifest[];
    AudioDeduplication?: MsSmoothAudioDeduplication;
    Destination?: string;
    DestinationSettings?: DestinationSettings;
    Encryption?: MsSmoothEncryptionSettings;
    FragmentLength?: number;
    FragmentLengthControl?: MsSmoothFragmentLengthControl;
    ManifestEncoding?: MsSmoothManifestEncoding;
}
export type FrameMetricType = "PSNR" | "SSIM" | "MS_SSIM" | "PSNR_HVS" | "VMAF" | "QVBR" | "SHOT_CHANGE" | (string & {});
export type __listOfFrameMetricType = FrameMetricType[];
export type OutputGroupType = "HLS_GROUP_SETTINGS" | "DASH_ISO_GROUP_SETTINGS" | "FILE_GROUP_SETTINGS" | "MS_SMOOTH_GROUP_SETTINGS" | "CMAF_GROUP_SETTINGS" | (string & {});
export interface OutputGroupSettings {
    CmafGroupSettings?: CmafGroupSettings;
    DashIsoGroupSettings?: DashIsoGroupSettings;
    FileGroupSettings?: FileGroupSettings;
    HlsGroupSettings?: HlsGroupSettings;
    MsSmoothGroupSettings?: MsSmoothGroupSettings;
    PerFrameMetrics?: FrameMetricType[];
    Type?: OutputGroupType;
}
export type AudioChannelTag = "L" | "R" | "C" | "LFE" | "LS" | "RS" | "LC" | "RC" | "CS" | "LSD" | "RSD" | "TCS" | "VHL" | "VHC" | "VHR" | "TBL" | "TBC" | "TBR" | "RSL" | "RSR" | "LW" | "RW" | "LFE2" | "LT" | "RT" | "HI" | "NAR" | "M" | (string & {});
export type __listOfAudioChannelTag = AudioChannelTag[];
export interface AudioChannelTaggingSettings {
    ChannelTag?: AudioChannelTag;
    ChannelTags?: AudioChannelTag[];
}
export type AudioNormalizationAlgorithm = "ITU_BS_1770_1" | "ITU_BS_1770_2" | "ITU_BS_1770_3" | "ITU_BS_1770_4" | (string & {});
export type AudioNormalizationAlgorithmControl = "CORRECT_AUDIO" | "MEASURE_ONLY" | (string & {});
export type __integerMinNegative70Max0 = number;
export type AudioNormalizationLoudnessLogging = "LOG" | "DONT_LOG" | (string & {});
export type AudioNormalizationPeakCalculation = "TRUE_PEAK" | "NONE" | (string & {});
export type __doubleMinNegative59Max0 = number;
export type __doubleMinNegative8Max0 = number;
export interface AudioNormalizationSettings {
    Algorithm?: AudioNormalizationAlgorithm;
    AlgorithmControl?: AudioNormalizationAlgorithmControl;
    CorrectionGateLevel?: number;
    LoudnessLogging?: AudioNormalizationLoudnessLogging;
    PeakCalculation?: AudioNormalizationPeakCalculation;
    TargetLkfs?: number;
    TruePeakLimiterThreshold?: number;
}
export type SlowPalPitchCorrection = "DISABLED" | "ENABLED" | (string & {});
export interface AudioPitchCorrectionSettings {
    SlowPalPitchCorrection?: SlowPalPitchCorrection;
}
export type __integerMin0Max255 = number;
export type AudioTypeControl = "FOLLOW_INPUT" | "USE_CONFIGURED" | (string & {});
export type AacAudioDescriptionBroadcasterMix = "BROADCASTER_MIXED_AD" | "NORMAL" | (string & {});
export type __integerMin6000Max1024000 = number;
export type AacCodecProfile = "LC" | "HEV1" | "HEV2" | "XHE" | (string & {});
export type AacCodingMode = "AD_RECEIVER_MIX" | "CODING_MODE_1_0" | "CODING_MODE_1_1" | "CODING_MODE_2_0" | "CODING_MODE_5_1" | "CODING_MODE_AUTO" | (string & {});
export type AacLoudnessMeasurementMode = "PROGRAM" | "ANCHOR" | (string & {});
export type AacPassthroughControl = "WHEN_POSSIBLE" | "NO_PASSTHROUGH" | (string & {});
export type __integerMin2000Max30000 = number;
export type AacRateControlMode = "CBR" | "VBR" | (string & {});
export type AacRawFormat = "LATM_LOAS" | "NONE" | (string & {});
export type __integerMin8000Max96000 = number;
export type AacSpecification = "MPEG2" | "MPEG4" | (string & {});
export type __integerMin6Max16 = number;
export type AacVbrQuality = "LOW" | "MEDIUM_LOW" | "MEDIUM_HIGH" | "HIGH" | (string & {});
export interface AacSettings {
    AudioDescriptionBroadcasterMix?: AacAudioDescriptionBroadcasterMix;
    Bitrate?: number;
    CodecProfile?: AacCodecProfile;
    CodingMode?: AacCodingMode;
    LoudnessMeasurementMode?: AacLoudnessMeasurementMode;
    PassthroughControl?: AacPassthroughControl;
    RapInterval?: number;
    RateControlMode?: AacRateControlMode;
    RawFormat?: AacRawFormat;
    SampleRate?: number;
    Specification?: AacSpecification;
    TargetLoudnessRange?: number;
    VbrQuality?: AacVbrQuality;
}
export type __integerMin64000Max640000 = number;
export type Ac3BitstreamMode = "COMPLETE_MAIN" | "COMMENTARY" | "DIALOGUE" | "EMERGENCY" | "HEARING_IMPAIRED" | "MUSIC_AND_EFFECTS" | "VISUALLY_IMPAIRED" | "VOICE_OVER" | (string & {});
export type Ac3CodingMode = "CODING_MODE_1_0" | "CODING_MODE_1_1" | "CODING_MODE_2_0" | "CODING_MODE_3_2_LFE" | "CODING_MODE_AUTO" | (string & {});
export type __integerMin1Max31 = number;
export type Ac3DynamicRangeCompressionLine = "FILM_STANDARD" | "FILM_LIGHT" | "MUSIC_STANDARD" | "MUSIC_LIGHT" | "SPEECH" | "NONE" | (string & {});
export type Ac3DynamicRangeCompressionProfile = "FILM_STANDARD" | "NONE" | (string & {});
export type Ac3DynamicRangeCompressionRf = "FILM_STANDARD" | "FILM_LIGHT" | "MUSIC_STANDARD" | "MUSIC_LIGHT" | "SPEECH" | "NONE" | (string & {});
export type Ac3LfeFilter = "ENABLED" | "DISABLED" | (string & {});
export type Ac3MetadataControl = "FOLLOW_INPUT" | "USE_CONFIGURED" | (string & {});
export type __integerMin48000Max48000 = number;
export interface Ac3Settings {
    Bitrate?: number;
    BitstreamMode?: Ac3BitstreamMode;
    CodingMode?: Ac3CodingMode;
    Dialnorm?: number;
    DynamicRangeCompressionLine?: Ac3DynamicRangeCompressionLine;
    DynamicRangeCompressionProfile?: Ac3DynamicRangeCompressionProfile;
    DynamicRangeCompressionRf?: Ac3DynamicRangeCompressionRf;
    LfeFilter?: Ac3LfeFilter;
    MetadataControl?: Ac3MetadataControl;
    SampleRate?: number;
}
export type __integerMin48000Max768000 = number;
export type Ac4BitstreamMode = "COMPLETE_MAIN" | "EMERGENCY" | (string & {});
export type Ac4CodingMode = "CODING_MODE_2_0" | "CODING_MODE_3_2_LFE" | "CODING_MODE_5_1_4" | (string & {});
export type Ac4DynamicRangeCompressionDrcProfile = "NONE" | "FILM_STANDARD" | "FILM_LIGHT" | "MUSIC_STANDARD" | "MUSIC_LIGHT" | "SPEECH" | (string & {});
export type __doubleMinNegative1000Max3 = number;
export type __doubleMinNegative1000MaxNegative1 = number;
export type Ac4StereoDownmix = "NOT_INDICATED" | "LO_RO" | "LT_RT" | "DPL2" | (string & {});
export interface Ac4Settings {
    Bitrate?: number;
    BitstreamMode?: Ac4BitstreamMode;
    CodingMode?: Ac4CodingMode;
    DynamicRangeCompressionFlatPanelTv?: Ac4DynamicRangeCompressionDrcProfile;
    DynamicRangeCompressionHomeTheater?: Ac4DynamicRangeCompressionDrcProfile;
    DynamicRangeCompressionPortableHeadphones?: Ac4DynamicRangeCompressionDrcProfile;
    DynamicRangeCompressionPortableSpeakers?: Ac4DynamicRangeCompressionDrcProfile;
    LoRoCenterMixLevel?: number;
    LoRoSurroundMixLevel?: number;
    LtRtCenterMixLevel?: number;
    LtRtSurroundMixLevel?: number;
    SampleRate?: number;
    StereoDownmix?: Ac4StereoDownmix;
}
export type __integerMin16Max24 = number;
export type __integerMin0Max64 = number;
export type __integerMin8000Max192000 = number;
export interface AiffSettings {
    BitDepth?: number;
    Channels?: number;
    SampleRate?: number;
}
export type AudioCodec = "AAC" | "MP2" | "MP3" | "WAV" | "AIFF" | "AC3" | "AC4" | "EAC3" | "EAC3_ATMOS" | "VORBIS" | "OPUS" | "PASSTHROUGH" | "FLAC" | (string & {});
export type __integerMin384000Max1024000 = number;
export type Eac3AtmosBitstreamMode = "COMPLETE_MAIN" | (string & {});
export type Eac3AtmosCodingMode = "CODING_MODE_AUTO" | "CODING_MODE_5_1_4" | "CODING_MODE_7_1_4" | "CODING_MODE_9_1_6" | (string & {});
export type Eac3AtmosDialogueIntelligence = "ENABLED" | "DISABLED" | (string & {});
export type Eac3AtmosDownmixControl = "SPECIFIED" | "INITIALIZE_FROM_SOURCE" | (string & {});
export type Eac3AtmosDynamicRangeCompressionLine = "NONE" | "FILM_STANDARD" | "FILM_LIGHT" | "MUSIC_STANDARD" | "MUSIC_LIGHT" | "SPEECH" | (string & {});
export type Eac3AtmosDynamicRangeCompressionRf = "NONE" | "FILM_STANDARD" | "FILM_LIGHT" | "MUSIC_STANDARD" | "MUSIC_LIGHT" | "SPEECH" | (string & {});
export type Eac3AtmosDynamicRangeControl = "SPECIFIED" | "INITIALIZE_FROM_SOURCE" | (string & {});
export type __doubleMinNegative6Max3 = number;
export type __doubleMinNegative60MaxNegative1 = number;
export type Eac3AtmosMeteringMode = "LEQ_A" | "ITU_BS_1770_1" | "ITU_BS_1770_2" | "ITU_BS_1770_3" | "ITU_BS_1770_4" | (string & {});
export type Eac3AtmosStereoDownmix = "NOT_INDICATED" | "STEREO" | "SURROUND" | "DPL2" | (string & {});
export type Eac3AtmosSurroundExMode = "NOT_INDICATED" | "ENABLED" | "DISABLED" | (string & {});
export interface Eac3AtmosSettings {
    Bitrate?: number;
    BitstreamMode?: Eac3AtmosBitstreamMode;
    CodingMode?: Eac3AtmosCodingMode;
    DialogueIntelligence?: Eac3AtmosDialogueIntelligence;
    DownmixControl?: Eac3AtmosDownmixControl;
    DynamicRangeCompressionLine?: Eac3AtmosDynamicRangeCompressionLine;
    DynamicRangeCompressionRf?: Eac3AtmosDynamicRangeCompressionRf;
    DynamicRangeControl?: Eac3AtmosDynamicRangeControl;
    LoRoCenterMixLevel?: number;
    LoRoSurroundMixLevel?: number;
    LtRtCenterMixLevel?: number;
    LtRtSurroundMixLevel?: number;
    MeteringMode?: Eac3AtmosMeteringMode;
    SampleRate?: number;
    SpeechThreshold?: number;
    StereoDownmix?: Eac3AtmosStereoDownmix;
    SurroundExMode?: Eac3AtmosSurroundExMode;
}
export type Eac3AttenuationControl = "ATTENUATE_3_DB" | "NONE" | (string & {});
export type __integerMin32000Max3024000 = number;
export type Eac3BitstreamMode = "COMPLETE_MAIN" | "COMMENTARY" | "EMERGENCY" | "HEARING_IMPAIRED" | "VISUALLY_IMPAIRED" | (string & {});
export type Eac3CodingMode = "CODING_MODE_1_0" | "CODING_MODE_2_0" | "CODING_MODE_3_2" | "CODING_MODE_AUTO" | (string & {});
export type Eac3DcFilter = "ENABLED" | "DISABLED" | (string & {});
export type Eac3DynamicRangeCompressionLine = "NONE" | "FILM_STANDARD" | "FILM_LIGHT" | "MUSIC_STANDARD" | "MUSIC_LIGHT" | "SPEECH" | (string & {});
export type Eac3DynamicRangeCompressionRf = "NONE" | "FILM_STANDARD" | "FILM_LIGHT" | "MUSIC_STANDARD" | "MUSIC_LIGHT" | "SPEECH" | (string & {});
export type Eac3LfeControl = "LFE" | "NO_LFE" | (string & {});
export type Eac3LfeFilter = "ENABLED" | "DISABLED" | (string & {});
export type __doubleMinNegative60Max3 = number;
export type Eac3MetadataControl = "FOLLOW_INPUT" | "USE_CONFIGURED" | (string & {});
export type Eac3PassthroughControl = "WHEN_POSSIBLE" | "NO_PASSTHROUGH" | (string & {});
export type Eac3PhaseControl = "SHIFT_90_DEGREES" | "NO_SHIFT" | (string & {});
export type Eac3StereoDownmix = "NOT_INDICATED" | "LO_RO" | "LT_RT" | "DPL2" | (string & {});
export type Eac3SurroundExMode = "NOT_INDICATED" | "ENABLED" | "DISABLED" | (string & {});
export type Eac3SurroundMode = "NOT_INDICATED" | "ENABLED" | "DISABLED" | (string & {});
export interface Eac3Settings {
    AttenuationControl?: Eac3AttenuationControl;
    Bitrate?: number;
    BitstreamMode?: Eac3BitstreamMode;
    CodingMode?: Eac3CodingMode;
    DcFilter?: Eac3DcFilter;
    Dialnorm?: number;
    DynamicRangeCompressionLine?: Eac3DynamicRangeCompressionLine;
    DynamicRangeCompressionRf?: Eac3DynamicRangeCompressionRf;
    LfeControl?: Eac3LfeControl;
    LfeFilter?: Eac3LfeFilter;
    LoRoCenterMixLevel?: number;
    LoRoSurroundMixLevel?: number;
    LtRtCenterMixLevel?: number;
    LtRtSurroundMixLevel?: number;
    MetadataControl?: Eac3MetadataControl;
    PassthroughControl?: Eac3PassthroughControl;
    PhaseControl?: Eac3PhaseControl;
    SampleRate?: number;
    StereoDownmix?: Eac3StereoDownmix;
    SurroundExMode?: Eac3SurroundExMode;
    SurroundMode?: Eac3SurroundMode;
}
export type __integerMin22050Max192000 = number;
export interface FlacSettings {
    BitDepth?: number;
    Channels?: number;
    SampleRate?: number;
}
export type Mp2AudioDescriptionMix = "BROADCASTER_MIXED_AD" | "NONE" | (string & {});
export type __integerMin32000Max384000 = number;
export type __integerMin0Max2 = number;
export interface Mp2Settings {
    AudioDescriptionMix?: Mp2AudioDescriptionMix;
    Bitrate?: number;
    Channels?: number;
    SampleRate?: number;
}
export type __integerMin16000Max320000 = number;
export type Mp3RateControlMode = "CBR" | "VBR" | (string & {});
export type __integerMin22050Max48000 = number;
export type __integerMin0Max9 = number;
export interface Mp3Settings {
    Bitrate?: number;
    Channels?: number;
    RateControlMode?: Mp3RateControlMode;
    SampleRate?: number;
    VbrQuality?: number;
}
export type __integerMin32000Max192000 = number;
export type __integerMin16000Max48000 = number;
export interface OpusSettings {
    Bitrate?: number;
    Channels?: number;
    SampleRate?: number;
}
export type __integerMinNegative1Max10 = number;
export interface VorbisSettings {
    Channels?: number;
    SampleRate?: number;
    VbrQuality?: number;
}
export type WavFormat = "RIFF" | "RF64" | "EXTENSIBLE" | (string & {});
export interface WavSettings {
    BitDepth?: number;
    Channels?: number;
    Format?: WavFormat;
    SampleRate?: number;
}
export interface AudioCodecSettings {
    AacSettings?: AacSettings;
    Ac3Settings?: Ac3Settings;
    Ac4Settings?: Ac4Settings;
    AiffSettings?: AiffSettings;
    Codec?: AudioCodec;
    Eac3AtmosSettings?: Eac3AtmosSettings;
    Eac3Settings?: Eac3Settings;
    FlacSettings?: FlacSettings;
    Mp2Settings?: Mp2Settings;
    Mp3Settings?: Mp3Settings;
    OpusSettings?: OpusSettings;
    VorbisSettings?: VorbisSettings;
    WavSettings?: WavSettings;
}
export type __stringPatternAZaZ23AZaZ09 = string;
export type AudioLanguageCodeControl = "FOLLOW_INPUT" | "USE_CONFIGURED" | (string & {});
export type __stringPatternWS = string;
export interface AudioDescription {
    AudioChannelTaggingSettings?: AudioChannelTaggingSettings;
    AudioNormalizationSettings?: AudioNormalizationSettings;
    AudioPitchCorrectionSettings?: AudioPitchCorrectionSettings;
    AudioSourceName?: string;
    AudioType?: number;
    AudioTypeControl?: AudioTypeControl;
    CodecSettings?: AudioCodecSettings;
    CustomLanguageCode?: string;
    LanguageCode?: LanguageCode;
    LanguageCodeControl?: AudioLanguageCodeControl;
    RemixSettings?: RemixSettings;
    StreamName?: string;
}
export type __listOfAudioDescription = AudioDescription[];
export type __stringPatternAZaZ23AZaZ = string;
export type BurninSubtitleAlignment = "CENTERED" | "LEFT" | "AUTO" | (string & {});
export type BurninSubtitleApplyFontColor = "WHITE_TEXT_ONLY" | "ALL_TEXT" | (string & {});
export type BurninSubtitleBackgroundColor = "NONE" | "BLACK" | "WHITE" | "AUTO" | (string & {});
export type BurninSubtitleFallbackFont = "BEST_MATCH" | "MONOSPACED_SANSSERIF" | "MONOSPACED_SERIF" | "PROPORTIONAL_SANSSERIF" | "PROPORTIONAL_SERIF" | (string & {});
export type BurninSubtitleFontColor = "WHITE" | "BLACK" | "YELLOW" | "RED" | "GREEN" | "BLUE" | "HEX" | "AUTO" | (string & {});
export type __stringPatternS3TtfHttpsTtf = string;
export type __integerMin96Max600 = number;
export type FontScript = "AUTOMATIC" | "HANS" | "HANT" | (string & {});
export type __integerMin0Max96 = number;
export type __stringMin6Max8Pattern09aFAF609aFAF2 = string;
export type BurninSubtitleOutlineColor = "BLACK" | "WHITE" | "YELLOW" | "RED" | "GREEN" | "BLUE" | "AUTO" | (string & {});
export type __integerMin0Max10 = number;
export type RemoveRubyReserveAttributes = "DISABLED" | "ENABLED" | (string & {});
export type BurninSubtitleShadowColor = "NONE" | "BLACK" | "WHITE" | "AUTO" | (string & {});
export type BurnInSubtitleStylePassthrough = "ENABLED" | "DISABLED" | (string & {});
export type BurninSubtitleTeletextSpacing = "FIXED_GRID" | "PROPORTIONAL" | "AUTO" | (string & {});
export interface BurninDestinationSettings {
    Alignment?: BurninSubtitleAlignment;
    ApplyFontColor?: BurninSubtitleApplyFontColor;
    BackgroundColor?: BurninSubtitleBackgroundColor;
    BackgroundOpacity?: number;
    FallbackFont?: BurninSubtitleFallbackFont;
    FontColor?: BurninSubtitleFontColor;
    FontFileBold?: string;
    FontFileBoldItalic?: string;
    FontFileItalic?: string;
    FontFileRegular?: string;
    FontOpacity?: number;
    FontResolution?: number;
    FontScript?: FontScript;
    FontSize?: number;
    HexFontColor?: string;
    OutlineColor?: BurninSubtitleOutlineColor;
    OutlineSize?: number;
    RemoveRubyReserveAttributes?: RemoveRubyReserveAttributes;
    ShadowColor?: BurninSubtitleShadowColor;
    ShadowOpacity?: number;
    ShadowXOffset?: number;
    ShadowYOffset?: number;
    StylePassthrough?: BurnInSubtitleStylePassthrough;
    TeletextSpacing?: BurninSubtitleTeletextSpacing;
    XPosition?: number;
    YPosition?: number;
}
export type CaptionDestinationType = "BURN_IN" | "DVB_SUB" | "EMBEDDED" | "EMBEDDED_PLUS_SCTE20" | "IMSC" | "SCTE20_PLUS_EMBEDDED" | "SCC" | "SRT" | "SMI" | "TELETEXT" | "TTML" | "WEBVTT" | (string & {});
export type DvbSubtitleAlignment = "CENTERED" | "LEFT" | "AUTO" | (string & {});
export type DvbSubtitleApplyFontColor = "WHITE_TEXT_ONLY" | "ALL_TEXT" | (string & {});
export type DvbSubtitleBackgroundColor = "NONE" | "BLACK" | "WHITE" | "AUTO" | (string & {});
export type DvbddsHandling = "NONE" | "SPECIFIED" | "NO_DISPLAY_WINDOW" | "SPECIFIED_OPTIMAL" | (string & {});
export type DvbSubSubtitleFallbackFont = "BEST_MATCH" | "MONOSPACED_SANSSERIF" | "MONOSPACED_SERIF" | "PROPORTIONAL_SANSSERIF" | "PROPORTIONAL_SERIF" | (string & {});
export type DvbSubtitleFontColor = "WHITE" | "BLACK" | "YELLOW" | "RED" | "GREEN" | "BLUE" | "HEX" | "AUTO" | (string & {});
export type DvbSubtitleOutlineColor = "BLACK" | "WHITE" | "YELLOW" | "RED" | "GREEN" | "BLUE" | "AUTO" | (string & {});
export type DvbSubtitleShadowColor = "NONE" | "BLACK" | "WHITE" | "AUTO" | (string & {});
export type DvbSubtitleStylePassthrough = "ENABLED" | "DISABLED" | (string & {});
export type DvbSubtitlingType = "HEARING_IMPAIRED" | "STANDARD" | (string & {});
export type DvbSubtitleTeletextSpacing = "FIXED_GRID" | "PROPORTIONAL" | "AUTO" | (string & {});
export interface DvbSubDestinationSettings {
    Alignment?: DvbSubtitleAlignment;
    ApplyFontColor?: DvbSubtitleApplyFontColor;
    BackgroundColor?: DvbSubtitleBackgroundColor;
    BackgroundOpacity?: number;
    DdsHandling?: DvbddsHandling;
    DdsXCoordinate?: number;
    DdsYCoordinate?: number;
    FallbackFont?: DvbSubSubtitleFallbackFont;
    FontColor?: DvbSubtitleFontColor;
    FontFileBold?: string;
    FontFileBoldItalic?: string;
    FontFileItalic?: string;
    FontFileRegular?: string;
    FontOpacity?: number;
    FontResolution?: number;
    FontScript?: FontScript;
    FontSize?: number;
    Height?: number;
    HexFontColor?: string;
    OutlineColor?: DvbSubtitleOutlineColor;
    OutlineSize?: number;
    ShadowColor?: DvbSubtitleShadowColor;
    ShadowOpacity?: number;
    ShadowXOffset?: number;
    ShadowYOffset?: number;
    StylePassthrough?: DvbSubtitleStylePassthrough;
    SubtitlingType?: DvbSubtitlingType;
    TeletextSpacing?: DvbSubtitleTeletextSpacing;
    Width?: number;
    XPosition?: number;
    YPosition?: number;
}
export type __integerMin1Max6 = number;
export interface EmbeddedDestinationSettings {
    Destination608ChannelNumber?: number;
    Destination708ServiceNumber?: number;
}
export type ImscAccessibilitySubs = "DISABLED" | "ENABLED" | (string & {});
export type ImscStylePassthrough = "ENABLED" | "DISABLED" | (string & {});
export interface ImscDestinationSettings {
    Accessibility?: ImscAccessibilitySubs;
    StylePassthrough?: ImscStylePassthrough;
}
export type SccDestinationFramerate = "FRAMERATE_23_97" | "FRAMERATE_24" | "FRAMERATE_25" | "FRAMERATE_29_97_DROPFRAME" | "FRAMERATE_29_97_NON_DROPFRAME" | (string & {});
export interface SccDestinationSettings {
    Framerate?: SccDestinationFramerate;
}
export type SrtStylePassthrough = "ENABLED" | "DISABLED" | (string & {});
export interface SrtDestinationSettings {
    StylePassthrough?: SrtStylePassthrough;
}
export type TeletextPageType = "PAGE_TYPE_INITIAL" | "PAGE_TYPE_SUBTITLE" | "PAGE_TYPE_ADDL_INFO" | "PAGE_TYPE_PROGRAM_SCHEDULE" | "PAGE_TYPE_HEARING_IMPAIRED_SUBTITLE" | (string & {});
export type __listOfTeletextPageType = TeletextPageType[];
export interface TeletextDestinationSettings {
    PageNumber?: string;
    PageTypes?: TeletextPageType[];
}
export type TtmlBackgroundColor = "NONE" | "BLACK" | "WHITE" | "AUTO" | (string & {});
export type TtmlFontColor = "WHITE" | "BLACK" | "YELLOW" | "RED" | "GREEN" | "BLUE" | "AUTO" | (string & {});
export type TtmlFontStyle = "NORMAL" | "ITALIC" | (string & {});
export type TtmlFontWeight = "NORMAL" | "BOLD" | (string & {});
export type TtmlStylePassthrough = "ENABLED" | "DISABLED" | (string & {});
export type TtmlTextDecoration = "NONE" | "UNDERLINE" | (string & {});
export interface TtmlDestinationSettings {
    BackgroundColor?: TtmlBackgroundColor;
    BackgroundOpacity?: number;
    FontColor?: TtmlFontColor;
    FontOpacity?: number;
    FontSize?: number;
    FontStyle?: TtmlFontStyle;
    FontWeight?: TtmlFontWeight;
    StylePassthrough?: TtmlStylePassthrough;
    TextDecoration?: TtmlTextDecoration;
}
export type WebvttAccessibilitySubs = "DISABLED" | "ENABLED" | (string & {});
export type WebvttStylePassthrough = "ENABLED" | "DISABLED" | "STRICT" | "MERGE" | (string & {});
export interface WebvttDestinationSettings {
    Accessibility?: WebvttAccessibilitySubs;
    StylePassthrough?: WebvttStylePassthrough;
}
export interface CaptionDestinationSettings {
    BurninDestinationSettings?: BurninDestinationSettings;
    DestinationType?: CaptionDestinationType;
    DvbSubDestinationSettings?: DvbSubDestinationSettings;
    EmbeddedDestinationSettings?: EmbeddedDestinationSettings;
    ImscDestinationSettings?: ImscDestinationSettings;
    SccDestinationSettings?: SccDestinationSettings;
    SrtDestinationSettings?: SrtDestinationSettings;
    TeletextDestinationSettings?: TeletextDestinationSettings;
    TtmlDestinationSettings?: TtmlDestinationSettings;
    WebvttDestinationSettings?: WebvttDestinationSettings;
}
export interface CaptionDescription {
    CaptionSelectorName?: string;
    CustomLanguageCode?: string;
    DestinationSettings?: CaptionDestinationSettings;
    LanguageCode?: LanguageCode;
    LanguageDescription?: string;
}
export type __listOfCaptionDescription = CaptionDescription[];
export type CmfcAudioDuration = "DEFAULT_CODEC_DURATION" | "MATCH_VIDEO_DURATION" | (string & {});
export type CmfcAudioTrackType = "ALTERNATE_AUDIO_AUTO_SELECT_DEFAULT" | "ALTERNATE_AUDIO_AUTO_SELECT" | "ALTERNATE_AUDIO_NOT_AUTO_SELECT" | "AUDIO_ONLY_VARIANT_STREAM" | (string & {});
export type CmfcC2paManifest = "INCLUDE" | "EXCLUDE" | (string & {});
export type CmfcDescriptiveVideoServiceFlag = "DONT_FLAG" | "FLAG" | (string & {});
export type CmfcIFrameOnlyManifest = "INCLUDE" | "EXCLUDE" | (string & {});
export type CmfcKlvMetadata = "PASSTHROUGH" | "NONE" | (string & {});
export type CmfcManifestMetadataSignaling = "ENABLED" | "DISABLED" | (string & {});
export type CmfcScte35Esam = "INSERT" | "NONE" | (string & {});
export type CmfcScte35Source = "PASSTHROUGH" | "NONE" | "MANIFEST_CUES" | (string & {});
export type __stringMin1PatternArnAwsUsGovCnKmsAZ26EastWestCentralNorthSouthEastWest1912D12KeyAFAF098AFAF094AFAF094AFAF094AFAF0912MrkAFAF0932 = string;
export type CmfcTimedMetadata = "PASSTHROUGH" | "NONE" | (string & {});
export type CmfcTimedMetadataBoxVersion = "VERSION_0" | "VERSION_1" | (string & {});
export type __stringMax1000 = string;
export interface CmfcSettings {
    AudioDuration?: CmfcAudioDuration;
    AudioGroupId?: string;
    AudioRenditionSets?: string;
    AudioTrackType?: CmfcAudioTrackType;
    C2paManifest?: CmfcC2paManifest;
    CertificateSecret?: string;
    DescriptiveVideoServiceFlag?: CmfcDescriptiveVideoServiceFlag;
    IFrameOnlyManifest?: CmfcIFrameOnlyManifest;
    KlvMetadata?: CmfcKlvMetadata;
    ManifestMetadataSignaling?: CmfcManifestMetadataSignaling;
    Scte35Esam?: CmfcScte35Esam;
    Scte35Source?: CmfcScte35Source;
    SigningKmsKey?: string;
    TimedMetadata?: CmfcTimedMetadata;
    TimedMetadataBoxVersion?: CmfcTimedMetadataBoxVersion;
    TimedMetadataSchemeIdUri?: string;
    TimedMetadataValue?: string;
}
export type ContainerType = "F4V" | "GIF" | "ISMV" | "M2TS" | "M3U8" | "CMFC" | "MOV" | "MP4" | "MPD" | "MXF" | "OGG" | "WEBM" | "RAW" | "Y4M" | (string & {});
export type F4vMoovPlacement = "PROGRESSIVE_DOWNLOAD" | "NORMAL" | (string & {});
export interface F4vSettings {
    MoovPlacement?: F4vMoovPlacement;
}
export type M2tsAudioBufferModel = "DVB" | "ATSC" | (string & {});
export type M2tsAudioDuration = "DEFAULT_CODEC_DURATION" | "MATCH_VIDEO_DURATION" | (string & {});
export type __integerMin32Max8182 = number;
export type __listOf__integerMin32Max8182 = number[];
export type __integerMinNegative10000Max10000 = number;
export type M2tsBufferModel = "MULTIPLEX" | "NONE" | (string & {});
export type M2tsDataPtsControl = "AUTO" | "ALIGN_TO_VIDEO" | (string & {});
export type __integerMin25Max10000 = number;
export interface DvbNitSettings {
    NetworkId?: number;
    NetworkName?: string;
    NitInterval?: number;
}
export type OutputSdt = "SDT_FOLLOW" | "SDT_FOLLOW_IF_PRESENT" | "SDT_MANUAL" | "SDT_NONE" | (string & {});
export type __integerMin25Max2000 = number;
export interface DvbSdtSettings {
    OutputSdt?: OutputSdt;
    SdtInterval?: number;
    ServiceName?: string;
    ServiceProviderName?: string;
}
export type __integerMin1000Max30000 = number;
export interface DvbTdtSettings {
    TdtInterval?: number;
}
export type M2tsEbpAudioInterval = "VIDEO_AND_FIXED_INTERVALS" | "VIDEO_INTERVAL" | (string & {});
export type M2tsEbpPlacement = "VIDEO_AND_AUDIO_PIDS" | "VIDEO_PID" | (string & {});
export type M2tsEsRateInPes = "INCLUDE" | "EXCLUDE" | (string & {});
export type M2tsForceTsVideoEbpOrder = "FORCE" | "DEFAULT" | (string & {});
export type M2tsKlvMetadata = "PASSTHROUGH" | "NONE" | (string & {});
export type __integerMin0Max500 = number;
export type __integerMin0Max10000 = number;
export type M2tsNielsenId3 = "INSERT" | "NONE" | (string & {});
export type __integerMin0Max1000 = number;
export type M2tsPcrControl = "PCR_EVERY_PES_PACKET" | "CONFIGURED_PCR_PERIOD" | (string & {});
export type M2tsPreventBufferUnderflow = "DISABLED" | "ENABLED" | (string & {});
export type TsPtsOffset = "AUTO" | "SECONDS" | "MILLISECONDS" | (string & {});
export type M2tsRateMode = "VBR" | "CBR" | (string & {});
export interface M2tsScte35Esam {
    Scte35EsamPid?: number;
}
export type M2tsScte35Source = "PASSTHROUGH" | "NONE" | "MANIFEST_CUES" | (string & {});
export type M2tsSegmentationMarkers = "NONE" | "RAI_SEGSTART" | "RAI_ADAPT" | "PSI_SEGSTART" | "EBP" | "EBP_LEGACY" | (string & {});
export type M2tsSegmentationStyle = "MAINTAIN_CADENCE" | "RESET_CADENCE" | (string & {});
export interface M2tsSettings {
    AudioBufferModel?: M2tsAudioBufferModel;
    AudioDuration?: M2tsAudioDuration;
    AudioFramesPerPes?: number;
    AudioPids?: number[];
    AudioPtsOffsetDelta?: number;
    Bitrate?: number;
    BufferModel?: M2tsBufferModel;
    DataPTSControl?: M2tsDataPtsControl;
    DvbNitSettings?: DvbNitSettings;
    DvbSdtSettings?: DvbSdtSettings;
    DvbSubPids?: number[];
    DvbTdtSettings?: DvbTdtSettings;
    DvbTeletextPid?: number;
    EbpAudioInterval?: M2tsEbpAudioInterval;
    EbpPlacement?: M2tsEbpPlacement;
    EsRateInPes?: M2tsEsRateInPes;
    ForceTsVideoEbpOrder?: M2tsForceTsVideoEbpOrder;
    FragmentTime?: number;
    KlvMetadata?: M2tsKlvMetadata;
    MaxPcrInterval?: number;
    MinEbpInterval?: number;
    NielsenId3?: M2tsNielsenId3;
    NullPacketBitrate?: number;
    PatInterval?: number;
    PcrControl?: M2tsPcrControl;
    PcrPid?: number;
    PmtInterval?: number;
    PmtPid?: number;
    PreventBufferUnderflow?: M2tsPreventBufferUnderflow;
    PrivateMetadataPid?: number;
    ProgramNumber?: number;
    PtsOffset?: number;
    PtsOffsetMode?: TsPtsOffset;
    RateMode?: M2tsRateMode;
    Scte35Esam?: M2tsScte35Esam;
    Scte35Pid?: number;
    Scte35Source?: M2tsScte35Source;
    SegmentationMarkers?: M2tsSegmentationMarkers;
    SegmentationStyle?: M2tsSegmentationStyle;
    SegmentationTime?: number;
    TimedMetadataPid?: number;
    TransportStreamId?: number;
    VideoPid?: number;
}
export type M3u8AudioDuration = "DEFAULT_CODEC_DURATION" | "MATCH_VIDEO_DURATION" | (string & {});
export type M3u8DataPtsControl = "AUTO" | "ALIGN_TO_VIDEO" | (string & {});
export type M3u8NielsenId3 = "INSERT" | "NONE" | (string & {});
export type M3u8PcrControl = "PCR_EVERY_PES_PACKET" | "CONFIGURED_PCR_PERIOD" | (string & {});
export type M3u8Scte35Source = "PASSTHROUGH" | "NONE" | "MANIFEST_CUES" | (string & {});
export type TimedMetadata = "PASSTHROUGH" | "NONE" | (string & {});
export interface M3u8Settings {
    AudioDuration?: M3u8AudioDuration;
    AudioFramesPerPes?: number;
    AudioPids?: number[];
    AudioPtsOffsetDelta?: number;
    DataPTSControl?: M3u8DataPtsControl;
    MaxPcrInterval?: number;
    NielsenId3?: M3u8NielsenId3;
    PatInterval?: number;
    PcrControl?: M3u8PcrControl;
    PcrPid?: number;
    PmtInterval?: number;
    PmtPid?: number;
    PrivateMetadataPid?: number;
    ProgramNumber?: number;
    PtsOffset?: number;
    PtsOffsetMode?: TsPtsOffset;
    Scte35Pid?: number;
    Scte35Source?: M3u8Scte35Source;
    TimedMetadata?: TimedMetadata;
    TimedMetadataPid?: number;
    TransportStreamId?: number;
    VideoPid?: number;
}
export type MovClapAtom = "INCLUDE" | "EXCLUDE" | (string & {});
export type MovCslgAtom = "INCLUDE" | "EXCLUDE" | (string & {});
export type MovMpeg2FourCCControl = "XDCAM" | "MPEG" | (string & {});
export type MovPaddingControl = "OMNEON" | "NONE" | (string & {});
export type MovReference = "SELF_CONTAINED" | "EXTERNAL" | (string & {});
export interface MovSettings {
    AudioDuration?: CmfcAudioDuration;
    ClapAtom?: MovClapAtom;
    CslgAtom?: MovCslgAtom;
    Mpeg2FourCCControl?: MovMpeg2FourCCControl;
    PaddingControl?: MovPaddingControl;
    Reference?: MovReference;
}
export type Mp4C2paManifest = "INCLUDE" | "EXCLUDE" | (string & {});
export type Mp4CslgAtom = "INCLUDE" | "EXCLUDE" | (string & {});
export type __integerMin0Max1 = number;
export type Mp4FreeSpaceBox = "INCLUDE" | "EXCLUDE" | (string & {});
export type Mp4MoovPlacement = "PROGRESSIVE_DOWNLOAD" | "NORMAL" | (string & {});
export interface Mp4Settings {
    AudioDuration?: CmfcAudioDuration;
    C2paManifest?: Mp4C2paManifest;
    CertificateSecret?: string;
    CslgAtom?: Mp4CslgAtom;
    CttsVersion?: number;
    FreeSpaceBox?: Mp4FreeSpaceBox;
    MoovPlacement?: Mp4MoovPlacement;
    Mp4MajorBrand?: string;
    SigningKmsKey?: string;
}
export type MpdAccessibilityCaptionHints = "INCLUDE" | "EXCLUDE" | (string & {});
export type MpdAudioDuration = "DEFAULT_CODEC_DURATION" | "MATCH_VIDEO_DURATION" | (string & {});
export type MpdC2paManifest = "INCLUDE" | "EXCLUDE" | (string & {});
export type MpdCaptionContainerType = "RAW" | "FRAGMENTED_MP4" | (string & {});
export type MpdKlvMetadata = "NONE" | "PASSTHROUGH" | (string & {});
export type MpdManifestMetadataSignaling = "ENABLED" | "DISABLED" | (string & {});
export type MpdScte35Esam = "INSERT" | "NONE" | (string & {});
export type MpdScte35Source = "PASSTHROUGH" | "NONE" | "MANIFEST_CUES" | (string & {});
export type MpdTimedMetadata = "PASSTHROUGH" | "NONE" | (string & {});
export type MpdTimedMetadataBoxVersion = "VERSION_0" | "VERSION_1" | (string & {});
export interface MpdSettings {
    AccessibilityCaptionHints?: MpdAccessibilityCaptionHints;
    AudioDuration?: MpdAudioDuration;
    C2paManifest?: MpdC2paManifest;
    CaptionContainerType?: MpdCaptionContainerType;
    CertificateSecret?: string;
    KlvMetadata?: MpdKlvMetadata;
    ManifestMetadataSignaling?: MpdManifestMetadataSignaling;
    Scte35Esam?: MpdScte35Esam;
    Scte35Source?: MpdScte35Source;
    SigningKmsKey?: string;
    TimedMetadata?: MpdTimedMetadata;
    TimedMetadataBoxVersion?: MpdTimedMetadataBoxVersion;
    TimedMetadataSchemeIdUri?: string;
    TimedMetadataValue?: string;
}
export type MxfAfdSignaling = "NO_COPY" | "COPY_FROM_VIDEO" | (string & {});
export type MxfProfile = "D_10" | "XDCAM" | "OP1A" | "XAVC" | "XDCAM_RDD9" | (string & {});
export type MxfUncompressedAudioWrapping = "AUTO" | "AES3" | (string & {});
export type MxfXavcDurationMode = "ALLOW_ANY_DURATION" | "DROP_FRAMES_FOR_COMPLIANCE" | (string & {});
export interface MxfXavcProfileSettings {
    DurationMode?: MxfXavcDurationMode;
    MaxAncDataSize?: number;
}
export interface MxfSettings {
    AfdSignaling?: MxfAfdSignaling;
    Profile?: MxfProfile;
    UncompressedAudioWrapping?: MxfUncompressedAudioWrapping;
    XavcProfileSettings?: MxfXavcProfileSettings;
}
export interface ContainerSettings {
    CmfcSettings?: CmfcSettings;
    Container?: ContainerType;
    F4vSettings?: F4vSettings;
    M2tsSettings?: M2tsSettings;
    M3u8Settings?: M3u8Settings;
    MovSettings?: MovSettings;
    Mp4Settings?: Mp4Settings;
    MpdSettings?: MpdSettings;
    MxfSettings?: MxfSettings;
}
export type __stringMax256 = string;
export type HlsAudioOnlyContainer = "AUTOMATIC" | "M2TS" | (string & {});
export type HlsAudioTrackType = "ALTERNATE_AUDIO_AUTO_SELECT_DEFAULT" | "ALTERNATE_AUDIO_AUTO_SELECT" | "ALTERNATE_AUDIO_NOT_AUTO_SELECT" | "AUDIO_ONLY_VARIANT_STREAM" | (string & {});
export type HlsDescriptiveVideoServiceFlag = "DONT_FLAG" | "FLAG" | (string & {});
export type HlsIFrameOnlyManifest = "INCLUDE" | "INCLUDE_AS_TS" | "EXCLUDE" | (string & {});
export interface HlsSettings {
    AudioGroupId?: string;
    AudioOnlyContainer?: HlsAudioOnlyContainer;
    AudioRenditionSets?: string;
    AudioTrackType?: HlsAudioTrackType;
    DescriptiveVideoServiceFlag?: HlsDescriptiveVideoServiceFlag;
    IFrameOnlyManifest?: HlsIFrameOnlyManifest;
    SegmentModifier?: string;
}
export interface OutputSettings {
    HlsSettings?: HlsSettings;
}
export type __stringMin0 = string;
export type AfdSignaling = "NONE" | "AUTO" | "FIXED" | (string & {});
export type AntiAlias = "DISABLED" | "ENABLED" | (string & {});
export type ChromaPositionMode = "AUTO" | "FORCE_CENTER" | "FORCE_TOP_LEFT" | (string & {});
export type Av1AdaptiveQuantization = "OFF" | "LOW" | "MEDIUM" | "HIGH" | "HIGHER" | "MAX" | (string & {});
export type Av1BitDepth = "BIT_8" | "BIT_10" | (string & {});
export type Av1FilmGrainSynthesis = "DISABLED" | "ENABLED" | (string & {});
export type Av1FramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type Av1FramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type __integerMin1000Max1152000000 = number;
export type __integerMin0Max15 = number;
export type __integerMin1Max10 = number;
export type __doubleMin0Max1 = number;
export interface Av1QvbrSettings {
    QvbrQualityLevel?: number;
    QvbrQualityLevelFineTune?: number;
}
export type Av1RateControlMode = "QVBR" | (string & {});
export type Av1SpatialAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export interface Av1Settings {
    AdaptiveQuantization?: Av1AdaptiveQuantization;
    BitDepth?: Av1BitDepth;
    FilmGrainSynthesis?: Av1FilmGrainSynthesis;
    FramerateControl?: Av1FramerateControl;
    FramerateConversionAlgorithm?: Av1FramerateConversionAlgorithm;
    FramerateDenominator?: number;
    FramerateNumerator?: number;
    GopSize?: number;
    MaxBitrate?: number;
    NumberBFramesBetweenReferenceFrames?: number;
    PerFrameMetrics?: FrameMetricType[];
    QvbrSettings?: Av1QvbrSettings;
    RateControlMode?: Av1RateControlMode;
    Slices?: number;
    SpatialAdaptiveQuantization?: Av1SpatialAdaptiveQuantization;
}
export type AvcIntraClass = "CLASS_50" | "CLASS_100" | "CLASS_200" | "CLASS_4K_2K" | (string & {});
export type AvcIntraUhdQualityTuningLevel = "SINGLE_PASS" | "MULTI_PASS" | (string & {});
export interface AvcIntraUhdSettings {
    QualityTuningLevel?: AvcIntraUhdQualityTuningLevel;
}
export type AvcIntraFramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type AvcIntraFramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type __integerMin24Max60000 = number;
export type AvcIntraInterlaceMode = "PROGRESSIVE" | "TOP_FIELD" | "BOTTOM_FIELD" | "FOLLOW_TOP_FIELD" | "FOLLOW_BOTTOM_FIELD" | (string & {});
export type AvcIntraScanTypeConversionMode = "INTERLACED" | "INTERLACED_OPTIMIZE" | (string & {});
export type AvcIntraSlowPal = "DISABLED" | "ENABLED" | (string & {});
export type AvcIntraTelecine = "NONE" | "HARD" | (string & {});
export interface AvcIntraSettings {
    AvcIntraClass?: AvcIntraClass;
    AvcIntraUhdSettings?: AvcIntraUhdSettings;
    FramerateControl?: AvcIntraFramerateControl;
    FramerateConversionAlgorithm?: AvcIntraFramerateConversionAlgorithm;
    FramerateDenominator?: number;
    FramerateNumerator?: number;
    InterlaceMode?: AvcIntraInterlaceMode;
    PerFrameMetrics?: FrameMetricType[];
    ScanTypeConversionMode?: AvcIntraScanTypeConversionMode;
    SlowPal?: AvcIntraSlowPal;
    Telecine?: AvcIntraTelecine;
}
export type VideoCodec = "AV1" | "AVC_INTRA" | "FRAME_CAPTURE" | "GIF" | "H_264" | "H_265" | "MPEG2" | "PASSTHROUGH" | "PRORES" | "UNCOMPRESSED" | "VC3" | "VP8" | "VP9" | "XAVC" | (string & {});
export type __integerMin1Max10000000 = number;
export type __integerMin1Max100 = number;
export interface FrameCaptureSettings {
    FramerateDenominator?: number;
    FramerateNumerator?: number;
    MaxCaptures?: number;
    Quality?: number;
}
export type GifFramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type GifFramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | (string & {});
export interface GifSettings {
    FramerateControl?: GifFramerateControl;
    FramerateConversionAlgorithm?: GifFramerateConversionAlgorithm;
    FramerateDenominator?: number;
    FramerateNumerator?: number;
}
export type H264AdaptiveQuantization = "OFF" | "AUTO" | "LOW" | "MEDIUM" | "HIGH" | "HIGHER" | "MAX" | (string & {});
export type BandwidthReductionFilterSharpening = "LOW" | "MEDIUM" | "HIGH" | "OFF" | (string & {});
export type BandwidthReductionFilterStrength = "LOW" | "MEDIUM" | "HIGH" | "AUTO" | "OFF" | (string & {});
export interface BandwidthReductionFilter {
    Sharpening?: BandwidthReductionFilterSharpening;
    Strength?: BandwidthReductionFilterStrength;
}
export type H264CodecLevel = "AUTO" | "LEVEL_1" | "LEVEL_1_1" | "LEVEL_1_2" | "LEVEL_1_3" | "LEVEL_2" | "LEVEL_2_1" | "LEVEL_2_2" | "LEVEL_3" | "LEVEL_3_1" | "LEVEL_3_2" | "LEVEL_4" | "LEVEL_4_1" | "LEVEL_4_2" | "LEVEL_5" | "LEVEL_5_1" | "LEVEL_5_2" | (string & {});
export type H264CodecProfile = "BASELINE" | "HIGH" | "HIGH_10BIT" | "HIGH_422" | "HIGH_422_10BIT" | "MAIN" | (string & {});
export type H264DynamicSubGop = "ADAPTIVE" | "STATIC" | (string & {});
export type H264EndOfStreamMarkers = "INCLUDE" | "SUPPRESS" | (string & {});
export type H264EntropyEncoding = "CABAC" | "CAVLC" | (string & {});
export type H264ExplicitWeightedPrediction = "DISABLED" | "ENABLED" | (string & {});
export type H264FieldEncoding = "PAFF" | "FORCE_FIELD" | "MBAFF" | (string & {});
export type H264FlickerAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export type H264FramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type H264FramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type H264GopBReference = "DISABLED" | "ENABLED" | (string & {});
export type H264GopSizeUnits = "FRAMES" | "SECONDS" | "AUTO" | (string & {});
export type __integerMin0Max1152000000 = number;
export type H264InterlaceMode = "PROGRESSIVE" | "TOP_FIELD" | "BOTTOM_FIELD" | "FOLLOW_TOP_FIELD" | "FOLLOW_BOTTOM_FIELD" | (string & {});
export type __integerMin0Max30 = number;
export type __integerMin0Max7 = number;
export type H264ParControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type H264QualityTuningLevel = "SINGLE_PASS" | "SINGLE_PASS_HQ" | "MULTI_PASS_HQ" | (string & {});
export interface H264QvbrSettings {
    MaxAverageBitrate?: number;
    QvbrQualityLevel?: number;
    QvbrQualityLevelFineTune?: number;
}
export type H264RateControlMode = "VBR" | "CBR" | "QVBR" | (string & {});
export type H264RepeatPps = "DISABLED" | "ENABLED" | (string & {});
export type H264SaliencyAwareEncoding = "DISABLED" | "PREFERRED" | (string & {});
export type H264ScanTypeConversionMode = "INTERLACED" | "INTERLACED_OPTIMIZE" | (string & {});
export type H264SceneChangeDetect = "DISABLED" | "ENABLED" | "TRANSITION_DETECTION" | (string & {});
export type H264SlowPal = "DISABLED" | "ENABLED" | (string & {});
export type __integerMin0Max128 = number;
export type H264SpatialAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export type H264Syntax = "DEFAULT" | "RP2027" | (string & {});
export type H264Telecine = "NONE" | "SOFT" | "HARD" | (string & {});
export type H264TemporalAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export type H264UnregisteredSeiTimecode = "DISABLED" | "ENABLED" | (string & {});
export type H264WriteMp4PackagingType = "AVC1" | "AVC3" | (string & {});
export interface H264Settings {
    AdaptiveQuantization?: H264AdaptiveQuantization;
    BandwidthReductionFilter?: BandwidthReductionFilter;
    Bitrate?: number;
    CodecLevel?: H264CodecLevel;
    CodecProfile?: H264CodecProfile;
    DynamicSubGop?: H264DynamicSubGop;
    EndOfStreamMarkers?: H264EndOfStreamMarkers;
    EntropyEncoding?: H264EntropyEncoding;
    ExplicitWeightedPrediction?: H264ExplicitWeightedPrediction;
    FieldEncoding?: H264FieldEncoding;
    FlickerAdaptiveQuantization?: H264FlickerAdaptiveQuantization;
    FramerateControl?: H264FramerateControl;
    FramerateConversionAlgorithm?: H264FramerateConversionAlgorithm;
    FramerateDenominator?: number;
    FramerateNumerator?: number;
    GopBReference?: H264GopBReference;
    GopClosedCadence?: number;
    GopSize?: number;
    GopSizeUnits?: H264GopSizeUnits;
    HrdBufferFinalFillPercentage?: number;
    HrdBufferInitialFillPercentage?: number;
    HrdBufferSize?: number;
    InterlaceMode?: H264InterlaceMode;
    MaxBitrate?: number;
    MinIInterval?: number;
    NumberBFramesBetweenReferenceFrames?: number;
    NumberReferenceFrames?: number;
    ParControl?: H264ParControl;
    ParDenominator?: number;
    ParNumerator?: number;
    PerFrameMetrics?: FrameMetricType[];
    QualityTuningLevel?: H264QualityTuningLevel;
    QvbrSettings?: H264QvbrSettings;
    RateControlMode?: H264RateControlMode;
    RepeatPps?: H264RepeatPps;
    SaliencyAwareEncoding?: H264SaliencyAwareEncoding;
    ScanTypeConversionMode?: H264ScanTypeConversionMode;
    SceneChangeDetect?: H264SceneChangeDetect;
    Slices?: number;
    SlowPal?: H264SlowPal;
    Softness?: number;
    SpatialAdaptiveQuantization?: H264SpatialAdaptiveQuantization;
    Syntax?: H264Syntax;
    Telecine?: H264Telecine;
    TemporalAdaptiveQuantization?: H264TemporalAdaptiveQuantization;
    UnregisteredSeiTimecode?: H264UnregisteredSeiTimecode;
    WriteMp4PackagingType?: H264WriteMp4PackagingType;
}
export type H265AdaptiveQuantization = "OFF" | "LOW" | "MEDIUM" | "HIGH" | "HIGHER" | "MAX" | "AUTO" | (string & {});
export type H265AlternateTransferFunctionSei = "DISABLED" | "ENABLED" | (string & {});
export type __integerMin1000Max1466400000 = number;
export type H265CodecLevel = "AUTO" | "LEVEL_1" | "LEVEL_2" | "LEVEL_2_1" | "LEVEL_3" | "LEVEL_3_1" | "LEVEL_4" | "LEVEL_4_1" | "LEVEL_5" | "LEVEL_5_1" | "LEVEL_5_2" | "LEVEL_6" | "LEVEL_6_1" | "LEVEL_6_2" | (string & {});
export type H265CodecProfile = "MAIN_MAIN" | "MAIN_HIGH" | "MAIN10_MAIN" | "MAIN10_HIGH" | "MAIN_422_8BIT_MAIN" | "MAIN_422_8BIT_HIGH" | "MAIN_422_10BIT_MAIN" | "MAIN_422_10BIT_HIGH" | (string & {});
export type H265Deblocking = "ENABLED" | "DISABLED" | (string & {});
export type H265DynamicSubGop = "ADAPTIVE" | "STATIC" | (string & {});
export type H265EndOfStreamMarkers = "INCLUDE" | "SUPPRESS" | (string & {});
export type H265FlickerAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export type H265FramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type H265FramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type H265GopBReference = "DISABLED" | "ENABLED" | (string & {});
export type H265GopSizeUnits = "FRAMES" | "SECONDS" | "AUTO" | (string & {});
export type __integerMin0Max1466400000 = number;
export type H265InterlaceMode = "PROGRESSIVE" | "TOP_FIELD" | "BOTTOM_FIELD" | "FOLLOW_TOP_FIELD" | "FOLLOW_BOTTOM_FIELD" | (string & {});
export type H265MvOverPictureBoundaries = "ENABLED" | "DISABLED" | (string & {});
export type H265MvTemporalPredictor = "ENABLED" | "DISABLED" | (string & {});
export type H265ParControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type H265QualityTuningLevel = "SINGLE_PASS" | "SINGLE_PASS_HQ" | "MULTI_PASS_HQ" | (string & {});
export interface H265QvbrSettings {
    MaxAverageBitrate?: number;
    QvbrQualityLevel?: number;
    QvbrQualityLevelFineTune?: number;
}
export type H265RateControlMode = "VBR" | "CBR" | "QVBR" | (string & {});
export type H265SampleAdaptiveOffsetFilterMode = "DEFAULT" | "ADAPTIVE" | "OFF" | (string & {});
export type H265ScanTypeConversionMode = "INTERLACED" | "INTERLACED_OPTIMIZE" | (string & {});
export type H265SceneChangeDetect = "DISABLED" | "ENABLED" | "TRANSITION_DETECTION" | (string & {});
export type H265SlowPal = "DISABLED" | "ENABLED" | (string & {});
export type H265SpatialAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export type H265Telecine = "NONE" | "SOFT" | "HARD" | (string & {});
export type H265TemporalAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export type H265TemporalIds = "DISABLED" | "ENABLED" | (string & {});
export type __integerMin64Max2160 = number;
export type H265TilePadding = "NONE" | "PADDED" | (string & {});
export type __integerMin256Max3840 = number;
export type H265Tiles = "DISABLED" | "ENABLED" | (string & {});
export type H265TreeBlockSize = "AUTO" | "TREE_SIZE_32X32" | (string & {});
export type H265UnregisteredSeiTimecode = "DISABLED" | "ENABLED" | (string & {});
export type H265WriteMp4PackagingType = "HVC1" | "HEV1" | (string & {});
export interface H265Settings {
    AdaptiveQuantization?: H265AdaptiveQuantization;
    AlternateTransferFunctionSei?: H265AlternateTransferFunctionSei;
    BandwidthReductionFilter?: BandwidthReductionFilter;
    Bitrate?: number;
    CodecLevel?: H265CodecLevel;
    CodecProfile?: H265CodecProfile;
    Deblocking?: H265Deblocking;
    DynamicSubGop?: H265DynamicSubGop;
    EndOfStreamMarkers?: H265EndOfStreamMarkers;
    FlickerAdaptiveQuantization?: H265FlickerAdaptiveQuantization;
    FramerateControl?: H265FramerateControl;
    FramerateConversionAlgorithm?: H265FramerateConversionAlgorithm;
    FramerateDenominator?: number;
    FramerateNumerator?: number;
    GopBReference?: H265GopBReference;
    GopClosedCadence?: number;
    GopSize?: number;
    GopSizeUnits?: H265GopSizeUnits;
    HrdBufferFinalFillPercentage?: number;
    HrdBufferInitialFillPercentage?: number;
    HrdBufferSize?: number;
    InterlaceMode?: H265InterlaceMode;
    MaxBitrate?: number;
    MinIInterval?: number;
    MvOverPictureBoundaries?: H265MvOverPictureBoundaries;
    MvTemporalPredictor?: H265MvTemporalPredictor;
    NumberBFramesBetweenReferenceFrames?: number;
    NumberReferenceFrames?: number;
    ParControl?: H265ParControl;
    ParDenominator?: number;
    ParNumerator?: number;
    PerFrameMetrics?: FrameMetricType[];
    QualityTuningLevel?: H265QualityTuningLevel;
    QvbrSettings?: H265QvbrSettings;
    RateControlMode?: H265RateControlMode;
    SampleAdaptiveOffsetFilterMode?: H265SampleAdaptiveOffsetFilterMode;
    ScanTypeConversionMode?: H265ScanTypeConversionMode;
    SceneChangeDetect?: H265SceneChangeDetect;
    Slices?: number;
    SlowPal?: H265SlowPal;
    SpatialAdaptiveQuantization?: H265SpatialAdaptiveQuantization;
    Telecine?: H265Telecine;
    TemporalAdaptiveQuantization?: H265TemporalAdaptiveQuantization;
    TemporalIds?: H265TemporalIds;
    TileHeight?: number;
    TilePadding?: H265TilePadding;
    TileWidth?: number;
    Tiles?: H265Tiles;
    TreeBlockSize?: H265TreeBlockSize;
    UnregisteredSeiTimecode?: H265UnregisteredSeiTimecode;
    WriteMp4PackagingType?: H265WriteMp4PackagingType;
}
export type Mpeg2AdaptiveQuantization = "OFF" | "LOW" | "MEDIUM" | "HIGH" | (string & {});
export type __integerMin1000Max288000000 = number;
export type Mpeg2CodecLevel = "AUTO" | "LOW" | "MAIN" | "HIGH1440" | "HIGH" | (string & {});
export type Mpeg2CodecProfile = "MAIN" | "PROFILE_422" | (string & {});
export type Mpeg2DynamicSubGop = "ADAPTIVE" | "STATIC" | (string & {});
export type Mpeg2FramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type Mpeg2FramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type Mpeg2GopSizeUnits = "FRAMES" | "SECONDS" | (string & {});
export type __integerMin0Max47185920 = number;
export type Mpeg2InterlaceMode = "PROGRESSIVE" | "TOP_FIELD" | "BOTTOM_FIELD" | "FOLLOW_TOP_FIELD" | "FOLLOW_BOTTOM_FIELD" | (string & {});
export type Mpeg2IntraDcPrecision = "AUTO" | "INTRA_DC_PRECISION_8" | "INTRA_DC_PRECISION_9" | "INTRA_DC_PRECISION_10" | "INTRA_DC_PRECISION_11" | (string & {});
export type __integerMin1000Max300000000 = number;
export type Mpeg2ParControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type Mpeg2QualityTuningLevel = "SINGLE_PASS" | "MULTI_PASS" | (string & {});
export type Mpeg2RateControlMode = "VBR" | "CBR" | (string & {});
export type Mpeg2ScanTypeConversionMode = "INTERLACED" | "INTERLACED_OPTIMIZE" | (string & {});
export type Mpeg2SceneChangeDetect = "DISABLED" | "ENABLED" | (string & {});
export type Mpeg2SlowPal = "DISABLED" | "ENABLED" | (string & {});
export type Mpeg2SpatialAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export type Mpeg2Syntax = "DEFAULT" | "D_10" | (string & {});
export type Mpeg2Telecine = "NONE" | "SOFT" | "HARD" | (string & {});
export type Mpeg2TemporalAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export interface Mpeg2Settings {
    AdaptiveQuantization?: Mpeg2AdaptiveQuantization;
    Bitrate?: number;
    CodecLevel?: Mpeg2CodecLevel;
    CodecProfile?: Mpeg2CodecProfile;
    DynamicSubGop?: Mpeg2DynamicSubGop;
    FramerateControl?: Mpeg2FramerateControl;
    FramerateConversionAlgorithm?: Mpeg2FramerateConversionAlgorithm;
    FramerateDenominator?: number;
    FramerateNumerator?: number;
    GopClosedCadence?: number;
    GopSize?: number;
    GopSizeUnits?: Mpeg2GopSizeUnits;
    HrdBufferFinalFillPercentage?: number;
    HrdBufferInitialFillPercentage?: number;
    HrdBufferSize?: number;
    InterlaceMode?: Mpeg2InterlaceMode;
    IntraDcPrecision?: Mpeg2IntraDcPrecision;
    MaxBitrate?: number;
    MinIInterval?: number;
    NumberBFramesBetweenReferenceFrames?: number;
    ParControl?: Mpeg2ParControl;
    ParDenominator?: number;
    ParNumerator?: number;
    PerFrameMetrics?: FrameMetricType[];
    QualityTuningLevel?: Mpeg2QualityTuningLevel;
    RateControlMode?: Mpeg2RateControlMode;
    ScanTypeConversionMode?: Mpeg2ScanTypeConversionMode;
    SceneChangeDetect?: Mpeg2SceneChangeDetect;
    SlowPal?: Mpeg2SlowPal;
    Softness?: number;
    SpatialAdaptiveQuantization?: Mpeg2SpatialAdaptiveQuantization;
    Syntax?: Mpeg2Syntax;
    Telecine?: Mpeg2Telecine;
    TemporalAdaptiveQuantization?: Mpeg2TemporalAdaptiveQuantization;
}
export type FrameControl = "NEAREST_IDRFRAME" | "NEAREST_IFRAME" | (string & {});
export type PassthroughSegmentationMode = "AUTO" | "DURATION_BASED" | "GOP_COUNT" | (string & {});
export type VideoSelectorMode = "AUTO" | "REMUX_ALL" | (string & {});
export interface PassthroughSettings {
    FrameControl?: FrameControl;
    GopsPerSegment?: number;
    SegmentationMode?: PassthroughSegmentationMode;
    VideoSelectorMode?: VideoSelectorMode;
}
export type ProresChromaSampling = "PRESERVE_444_SAMPLING" | "SUBSAMPLE_TO_422" | (string & {});
export type ProresCodecProfile = "APPLE_PRORES_422" | "APPLE_PRORES_422_HQ" | "APPLE_PRORES_422_LT" | "APPLE_PRORES_422_PROXY" | "APPLE_PRORES_4444" | "APPLE_PRORES_4444_XQ" | (string & {});
export type ProresFramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type ProresFramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type ProresInterlaceMode = "PROGRESSIVE" | "TOP_FIELD" | "BOTTOM_FIELD" | "FOLLOW_TOP_FIELD" | "FOLLOW_BOTTOM_FIELD" | (string & {});
export type ProresParControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type ProresScanTypeConversionMode = "INTERLACED" | "INTERLACED_OPTIMIZE" | (string & {});
export type ProresSlowPal = "DISABLED" | "ENABLED" | (string & {});
export type ProresTelecine = "NONE" | "HARD" | (string & {});
export interface ProresSettings {
    ChromaSampling?: ProresChromaSampling;
    CodecProfile?: ProresCodecProfile;
    FramerateControl?: ProresFramerateControl;
    FramerateConversionAlgorithm?: ProresFramerateConversionAlgorithm;
    FramerateDenominator?: number;
    FramerateNumerator?: number;
    InterlaceMode?: ProresInterlaceMode;
    ParControl?: ProresParControl;
    ParDenominator?: number;
    ParNumerator?: number;
    PerFrameMetrics?: FrameMetricType[];
    ScanTypeConversionMode?: ProresScanTypeConversionMode;
    SlowPal?: ProresSlowPal;
    Telecine?: ProresTelecine;
}
export type UncompressedFourcc = "I420" | "I422" | "I444" | (string & {});
export type UncompressedFramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type UncompressedFramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type UncompressedInterlaceMode = "INTERLACED" | "PROGRESSIVE" | (string & {});
export type UncompressedScanTypeConversionMode = "INTERLACED" | "INTERLACED_OPTIMIZE" | (string & {});
export type UncompressedSlowPal = "DISABLED" | "ENABLED" | (string & {});
export type UncompressedTelecine = "NONE" | "HARD" | (string & {});
export interface UncompressedSettings {
    Fourcc?: UncompressedFourcc;
    FramerateControl?: UncompressedFramerateControl;
    FramerateConversionAlgorithm?: UncompressedFramerateConversionAlgorithm;
    FramerateDenominator?: number;
    FramerateNumerator?: number;
    InterlaceMode?: UncompressedInterlaceMode;
    ScanTypeConversionMode?: UncompressedScanTypeConversionMode;
    SlowPal?: UncompressedSlowPal;
    Telecine?: UncompressedTelecine;
}
export type Vc3FramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type Vc3FramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type Vc3InterlaceMode = "INTERLACED" | "PROGRESSIVE" | (string & {});
export type Vc3ScanTypeConversionMode = "INTERLACED" | "INTERLACED_OPTIMIZE" | (string & {});
export type Vc3SlowPal = "DISABLED" | "ENABLED" | (string & {});
export type Vc3Telecine = "NONE" | "HARD" | (string & {});
export type Vc3Class = "CLASS_145_8BIT" | "CLASS_220_8BIT" | "CLASS_220_10BIT" | (string & {});
export interface Vc3Settings {
    FramerateControl?: Vc3FramerateControl;
    FramerateConversionAlgorithm?: Vc3FramerateConversionAlgorithm;
    FramerateDenominator?: number;
    FramerateNumerator?: number;
    InterlaceMode?: Vc3InterlaceMode;
    ScanTypeConversionMode?: Vc3ScanTypeConversionMode;
    SlowPal?: Vc3SlowPal;
    Telecine?: Vc3Telecine;
    Vc3Class?: Vc3Class;
}
export type Vp8FramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type Vp8FramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type Vp8ParControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type Vp8QualityTuningLevel = "MULTI_PASS" | "MULTI_PASS_HQ" | (string & {});
export type Vp8RateControlMode = "VBR" | (string & {});
export interface Vp8Settings {
    Bitrate?: number;
    FramerateControl?: Vp8FramerateControl;
    FramerateConversionAlgorithm?: Vp8FramerateConversionAlgorithm;
    FramerateDenominator?: number;
    FramerateNumerator?: number;
    GopSize?: number;
    HrdBufferSize?: number;
    MaxBitrate?: number;
    ParControl?: Vp8ParControl;
    ParDenominator?: number;
    ParNumerator?: number;
    QualityTuningLevel?: Vp8QualityTuningLevel;
    RateControlMode?: Vp8RateControlMode;
}
export type __integerMin1000Max480000000 = number;
export type Vp9FramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type Vp9FramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type Vp9ParControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type Vp9QualityTuningLevel = "MULTI_PASS" | "MULTI_PASS_HQ" | (string & {});
export type Vp9RateControlMode = "VBR" | (string & {});
export interface Vp9Settings {
    Bitrate?: number;
    FramerateControl?: Vp9FramerateControl;
    FramerateConversionAlgorithm?: Vp9FramerateConversionAlgorithm;
    FramerateDenominator?: number;
    FramerateNumerator?: number;
    GopSize?: number;
    HrdBufferSize?: number;
    MaxBitrate?: number;
    ParControl?: Vp9ParControl;
    ParDenominator?: number;
    ParNumerator?: number;
    QualityTuningLevel?: Vp9QualityTuningLevel;
    RateControlMode?: Vp9RateControlMode;
}
export type XavcAdaptiveQuantization = "OFF" | "AUTO" | "LOW" | "MEDIUM" | "HIGH" | "HIGHER" | "MAX" | (string & {});
export type XavcEntropyEncoding = "AUTO" | "CABAC" | "CAVLC" | (string & {});
export type XavcFramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type XavcFramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type XavcProfile = "XAVC_HD_INTRA_CBG" | "XAVC_4K_INTRA_CBG" | "XAVC_4K_INTRA_VBR" | "XAVC_HD" | "XAVC_4K" | (string & {});
export type XavcSlowPal = "DISABLED" | "ENABLED" | (string & {});
export type XavcSpatialAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export type XavcTemporalAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export type Xavc4kIntraCbgProfileClass = "CLASS_100" | "CLASS_300" | "CLASS_480" | (string & {});
export interface Xavc4kIntraCbgProfileSettings {
    XavcClass?: Xavc4kIntraCbgProfileClass;
}
export type Xavc4kIntraVbrProfileClass = "CLASS_100" | "CLASS_300" | "CLASS_480" | (string & {});
export interface Xavc4kIntraVbrProfileSettings {
    XavcClass?: Xavc4kIntraVbrProfileClass;
}
export type Xavc4kProfileBitrateClass = "BITRATE_CLASS_100" | "BITRATE_CLASS_140" | "BITRATE_CLASS_200" | (string & {});
export type Xavc4kProfileCodecProfile = "HIGH" | "HIGH_422" | (string & {});
export type XavcFlickerAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export type XavcGopBReference = "DISABLED" | "ENABLED" | (string & {});
export type Xavc4kProfileQualityTuningLevel = "SINGLE_PASS" | "SINGLE_PASS_HQ" | "MULTI_PASS_HQ" | (string & {});
export type __integerMin8Max12 = number;
export interface Xavc4kProfileSettings {
    BitrateClass?: Xavc4kProfileBitrateClass;
    CodecProfile?: Xavc4kProfileCodecProfile;
    FlickerAdaptiveQuantization?: XavcFlickerAdaptiveQuantization;
    GopBReference?: XavcGopBReference;
    GopClosedCadence?: number;
    HrdBufferSize?: number;
    QualityTuningLevel?: Xavc4kProfileQualityTuningLevel;
    Slices?: number;
}
export type XavcInterlaceMode = "PROGRESSIVE" | "TOP_FIELD" | "BOTTOM_FIELD" | "FOLLOW_TOP_FIELD" | "FOLLOW_BOTTOM_FIELD" | (string & {});
export type XavcHdIntraCbgProfileClass = "CLASS_50" | "CLASS_100" | "CLASS_200" | (string & {});
export interface XavcHdIntraCbgProfileSettings {
    InterlaceMode?: XavcInterlaceMode;
    XavcClass?: XavcHdIntraCbgProfileClass;
}
export type XavcHdProfileBitrateClass = "BITRATE_CLASS_25" | "BITRATE_CLASS_35" | "BITRATE_CLASS_50" | (string & {});
export type XavcHdProfileQualityTuningLevel = "SINGLE_PASS" | "SINGLE_PASS_HQ" | "MULTI_PASS_HQ" | (string & {});
export type __integerMin4Max12 = number;
export type XavcHdProfileTelecine = "NONE" | "HARD" | (string & {});
export interface XavcHdProfileSettings {
    BitrateClass?: XavcHdProfileBitrateClass;
    FlickerAdaptiveQuantization?: XavcFlickerAdaptiveQuantization;
    GopBReference?: XavcGopBReference;
    GopClosedCadence?: number;
    HrdBufferSize?: number;
    InterlaceMode?: XavcInterlaceMode;
    QualityTuningLevel?: XavcHdProfileQualityTuningLevel;
    Slices?: number;
    Telecine?: XavcHdProfileTelecine;
}
export interface XavcSettings {
    AdaptiveQuantization?: XavcAdaptiveQuantization;
    EntropyEncoding?: XavcEntropyEncoding;
    FramerateControl?: XavcFramerateControl;
    FramerateConversionAlgorithm?: XavcFramerateConversionAlgorithm;
    FramerateDenominator?: number;
    FramerateNumerator?: number;
    PerFrameMetrics?: FrameMetricType[];
    Profile?: XavcProfile;
    SlowPal?: XavcSlowPal;
    Softness?: number;
    SpatialAdaptiveQuantization?: XavcSpatialAdaptiveQuantization;
    TemporalAdaptiveQuantization?: XavcTemporalAdaptiveQuantization;
    Xavc4kIntraCbgProfileSettings?: Xavc4kIntraCbgProfileSettings;
    Xavc4kIntraVbrProfileSettings?: Xavc4kIntraVbrProfileSettings;
    Xavc4kProfileSettings?: Xavc4kProfileSettings;
    XavcHdIntraCbgProfileSettings?: XavcHdIntraCbgProfileSettings;
    XavcHdProfileSettings?: XavcHdProfileSettings;
}
export interface VideoCodecSettings {
    Av1Settings?: Av1Settings;
    AvcIntraSettings?: AvcIntraSettings;
    Codec?: VideoCodec;
    FrameCaptureSettings?: FrameCaptureSettings;
    GifSettings?: GifSettings;
    H264Settings?: H264Settings;
    H265Settings?: H265Settings;
    Mpeg2Settings?: Mpeg2Settings;
    PassthroughSettings?: PassthroughSettings;
    ProresSettings?: ProresSettings;
    UncompressedSettings?: UncompressedSettings;
    Vc3Settings?: Vc3Settings;
    Vp8Settings?: Vp8Settings;
    Vp9Settings?: Vp9Settings;
    XavcSettings?: XavcSettings;
}
export type ColorMetadata = "IGNORE" | "INSERT" | (string & {});
export type DropFrameTimecode = "DISABLED" | "ENABLED" | (string & {});
export type RespondToAfd = "NONE" | "RESPOND" | "PASSTHROUGH" | (string & {});
export type ScalingBehavior = "DEFAULT" | "STRETCH_TO_OUTPUT" | "FIT" | "FIT_NO_UPSCALE" | "FILL" | "SMART_CROP" | (string & {});
export type VideoTimecodeInsertion = "DISABLED" | "PIC_TIMING_SEI" | (string & {});
export type TimecodeTrack = "DISABLED" | "ENABLED" | (string & {});
export type __integerMin90Max105 = number;
export type __integerMin920Max1023 = number;
export type __integerMinNegative5Max10 = number;
export interface ClipLimits {
    MaximumRGBTolerance?: number;
    MaximumYUV?: number;
    MinimumRGBTolerance?: number;
    MinimumYUV?: number;
}
export type ColorSpaceConversion = "NONE" | "FORCE_601" | "FORCE_709" | "FORCE_HDR10" | "FORCE_HLG_2020" | "FORCE_P3DCI" | "FORCE_P3D65_SDR" | "FORCE_P3D65_HDR" | (string & {});
export type HDRToSDRToneMapper = "PRESERVE_DETAILS" | "VIBRANT" | (string & {});
export type __integerMinNegative180Max180 = number;
export type SampleRangeConversion = "LIMITED_RANGE_SQUEEZE" | "NONE" | "LIMITED_RANGE_CLIP" | (string & {});
export interface ColorCorrector {
    Brightness?: number;
    ClipLimits?: ClipLimits;
    ColorSpaceConversion?: ColorSpaceConversion;
    Contrast?: number;
    Hdr10Metadata?: Hdr10Metadata;
    HdrToSdrToneMapper?: HDRToSDRToneMapper;
    Hue?: number;
    MaxLuminance?: number;
    SampleRangeConversion?: SampleRangeConversion;
    Saturation?: number;
    SdrReferenceWhiteLevel?: number;
}
export type DeinterlaceAlgorithm = "INTERPOLATE" | "INTERPOLATE_TICKER" | "BLEND" | "BLEND_TICKER" | "LINEAR_INTERPOLATION" | (string & {});
export type DeinterlacerControl = "FORCE_ALL_FRAMES" | "NORMAL" | (string & {});
export type DeinterlacerMode = "DEINTERLACE" | "INVERSE_TELECINE" | "ADAPTIVE" | (string & {});
export interface Deinterlacer {
    Algorithm?: DeinterlaceAlgorithm;
    Control?: DeinterlacerControl;
    Mode?: DeinterlacerMode;
}
export type DolbyVisionCompatibility = "DUPLICATE_STREAM" | "SUPPLEMENTAL_CODECS" | (string & {});
export interface DolbyVisionLevel6Metadata {
    MaxCll?: number;
    MaxFall?: number;
}
export type DolbyVisionLevel6Mode = "PASSTHROUGH" | "RECALCULATE" | "SPECIFY" | (string & {});
export type DolbyVisionMapping = "HDR10_NOMAP" | "HDR10_1000" | (string & {});
export type DolbyVisionProfile = "PROFILE_5" | "PROFILE_8_1" | (string & {});
export interface DolbyVision {
    Compatibility?: DolbyVisionCompatibility;
    L6Metadata?: DolbyVisionLevel6Metadata;
    L6Mode?: DolbyVisionLevel6Mode;
    Mapping?: DolbyVisionMapping;
    Profile?: DolbyVisionProfile;
}
export interface DurationControl {
    IntegerDurationMaximumCompressionDenominator?: number;
    IntegerDurationMaximumCompressionNumerator?: number;
    IntegerDurationTrimThresholdMilliseconds?: number;
}
export type __integerMin0Max4000 = number;
export interface Hdr10Plus {
    MasteringMonitorNits?: number;
    TargetMonitorNits?: number;
}
export type NoiseReducerFilter = "BILATERAL" | "MEAN" | "GAUSSIAN" | "LANCZOS" | "SHARPEN" | "CONSERVE" | "SPATIAL" | "TEMPORAL" | (string & {});
export type __integerMin0Max3 = number;
export interface NoiseReducerFilterSettings {
    Strength?: number;
}
export type __integerMinNegative2Max3 = number;
export type __integerMin0Max16 = number;
export interface NoiseReducerSpatialFilterSettings {
    PostFilterSharpenStrength?: number;
    Speed?: number;
    Strength?: number;
}
export type __integerMin0Max4 = number;
export type NoiseFilterPostTemporalSharpening = "DISABLED" | "ENABLED" | "AUTO" | (string & {});
export type NoiseFilterPostTemporalSharpeningStrength = "LOW" | "MEDIUM" | "HIGH" | (string & {});
export type __integerMinNegative1Max3 = number;
export interface NoiseReducerTemporalFilterSettings {
    AggressiveMode?: number;
    PostTemporalSharpening?: NoiseFilterPostTemporalSharpening;
    PostTemporalSharpeningStrength?: NoiseFilterPostTemporalSharpeningStrength;
    Speed?: number;
    Strength?: number;
}
export interface NoiseReducer {
    Filter?: NoiseReducerFilter;
    FilterSettings?: NoiseReducerFilterSettings;
    SpatialFilterSettings?: NoiseReducerSpatialFilterSettings;
    TemporalFilterSettings?: NoiseReducerTemporalFilterSettings;
}
export type __stringMin1Max100000 = string;
export type __integerMin0Max4194303 = number;
export type WatermarkingStrength = "LIGHTEST" | "LIGHTER" | "DEFAULT" | "STRONGER" | "STRONGEST" | (string & {});
export interface NexGuardFileMarkerSettings {
    License?: string;
    Payload?: number;
    Preset?: string;
    Strength?: WatermarkingStrength;
}
export interface PartnerWatermarking {
    NexguardFileMarkerSettings?: NexGuardFileMarkerSettings;
}
export type __integerMin10Max48 = number;
export type TimecodeBurninPosition = "TOP_CENTER" | "TOP_LEFT" | "TOP_RIGHT" | "MIDDLE_LEFT" | "MIDDLE_CENTER" | "MIDDLE_RIGHT" | "BOTTOM_LEFT" | "BOTTOM_CENTER" | "BOTTOM_RIGHT" | (string & {});
export type __stringPattern = string;
export interface TimecodeBurnin {
    FontSize?: number;
    Position?: TimecodeBurninPosition;
    Prefix?: string;
}
export interface VideoPreprocessor {
    ColorCorrector?: ColorCorrector;
    Deinterlacer?: Deinterlacer;
    DolbyVision?: DolbyVision;
    DurationControl?: DurationControl;
    Hdr10Plus?: Hdr10Plus;
    ImageInserter?: ImageInserter;
    NoiseReducer?: NoiseReducer;
    PartnerWatermarking?: PartnerWatermarking;
    TimecodeBurnin?: TimecodeBurnin;
}
export interface VideoDescription {
    AfdSignaling?: AfdSignaling;
    AntiAlias?: AntiAlias;
    ChromaPositionMode?: ChromaPositionMode;
    CodecSettings?: VideoCodecSettings;
    ColorMetadata?: ColorMetadata;
    Crop?: Rectangle;
    DropFrameTimecode?: DropFrameTimecode;
    FixedAfd?: number;
    Height?: number;
    Position?: Rectangle;
    RespondToAfd?: RespondToAfd;
    ScalingBehavior?: ScalingBehavior;
    Sharpness?: number;
    TimecodeInsertion?: VideoTimecodeInsertion;
    TimecodeTrack?: TimecodeTrack;
    VideoPreprocessors?: VideoPreprocessor;
    Width?: number;
}
export interface Output {
    AudioDescriptions?: AudioDescription[];
    CaptionDescriptions?: CaptionDescription[];
    ContainerSettings?: ContainerSettings;
    Extension?: string;
    NameModifier?: string;
    OutputSettings?: OutputSettings;
    Preset?: string;
    VideoDescription?: VideoDescription;
}
export type __listOfOutput = Output[];
export interface OutputGroup {
    AutomatedEncodingSettings?: AutomatedEncodingSettings;
    CustomName?: string;
    Name?: string;
    OutputGroupSettings?: OutputGroupSettings;
    Outputs?: Output[];
}
export type __listOfOutputGroup = OutputGroup[];
export type TimecodeSource = "EMBEDDED" | "ZEROBASED" | "SPECIFIEDSTART" | (string & {});
export type __stringPattern0940191020191209301 = string;
export interface TimecodeConfig {
    Anchor?: string;
    Source?: TimecodeSource;
    Start?: string;
    TimestampOffset?: string;
}
export interface Id3Insertion {
    Id3?: string;
    Timecode?: string;
}
export type __listOfId3Insertion = Id3Insertion[];
export interface TimedMetadataInsertion {
    Id3Insertions?: Id3Insertion[];
}
export interface JobSettings {
    AdAvailOffset?: number;
    AvailBlanking?: AvailBlanking;
    ColorConversion3DLUTSettings?: ColorConversion3DLUTSetting[];
    Esam?: EsamSettings;
    ExtendedDataServices?: ExtendedDataServices;
    FollowSource?: number;
    Inputs?: Input[];
    KantarWatermark?: KantarWatermarkSettings;
    MotionImageInserter?: MotionImageInserter;
    MotionImageInserters?: MotionImageInserter[];
    NielsenConfiguration?: NielsenConfiguration;
    NielsenNonLinearWatermark?: NielsenNonLinearWatermarkSettings;
    OutputGroups?: OutputGroup[];
    TimecodeConfig?: TimecodeConfig;
    TimedMetadataInsertion?: TimedMetadataInsertion;
}
export type SimulateReservedQueue = "DISABLED" | "ENABLED" | (string & {});
export type StatusUpdateInterval = "SECONDS_10" | "SECONDS_12" | "SECONDS_15" | "SECONDS_20" | "SECONDS_30" | "SECONDS_60" | "SECONDS_120" | "SECONDS_180" | "SECONDS_240" | "SECONDS_300" | "SECONDS_360" | "SECONDS_420" | "SECONDS_480" | "SECONDS_540" | "SECONDS_600" | (string & {});
export type __mapOf__string = {
    [key: string]: string | undefined;
};
export interface CreateJobRequest {
    AccelerationSettings?: AccelerationSettings;
    BillingTagsSource?: BillingTagsSource;
    ClientRequestToken?: string;
    HopDestinations?: HopDestination[];
    JobEngineVersion?: string;
    JobTemplate?: string;
    Priority?: number;
    Queue?: string;
    Role?: string;
    Settings?: JobSettings;
    SimulateReservedQueue?: SimulateReservedQueue;
    StatusUpdateInterval?: StatusUpdateInterval;
    Tags?: {
        [key: string]: string | undefined;
    };
    UserMetadata?: {
        [key: string]: string | undefined;
    };
}
export type AccelerationStatus = "NOT_APPLICABLE" | "IN_PROGRESS" | "ACCELERATED" | "NOT_ACCELERATED" | (string & {});
export type __timestampUnix = Date;
export type JobPhase = "PROBING" | "TRANSCODING" | "UPLOADING" | (string & {});
export type ElementalInferenceFeature = "SMART_CROP" | (string & {});
export type __listOfElementalInferenceFeature = ElementalInferenceFeature[];
export type ElementalInferenceFeedManagementState = "CREATED" | "ASSOCIATED" | "PENDING_DELETION" | "DELETED" | (string & {});
export interface ElementalInferenceFeed {
    Arn?: string;
    FeedManagementState?: ElementalInferenceFeedManagementState;
}
export type __listOfElementalInferenceFeed = ElementalInferenceFeed[];
export interface ElementalInferenceConfiguration {
    Features?: ElementalInferenceFeature[];
    Feeds?: ElementalInferenceFeed[];
}
export type __listOf__string = string[];
export interface JobMessages {
    Info?: string[];
    Warning?: string[];
}
export interface VideoDetail {
    HeightInPx?: number;
    WidthInPx?: number;
}
export interface OutputDetail {
    DurationInMs?: number;
    VideoDetails?: VideoDetail;
}
export type __listOfOutputDetail = OutputDetail[];
export interface OutputGroupDetail {
    OutputDetails?: OutputDetail[];
}
export type __listOfOutputGroupDetail = OutputGroupDetail[];
export interface QueueTransition {
    DestinationQueue?: string;
    SourceQueue?: string;
    Timestamp?: Date;
}
export type __listOfQueueTransition = QueueTransition[];
export type ShareStatus = "NOT_SHARED" | "INITIATED" | "SHARED" | (string & {});
export type JobStatus = "SUBMITTED" | "PROGRESSING" | "COMPLETE" | "CANCELED" | "ERROR" | (string & {});
export interface Timing {
    FinishTime?: Date;
    StartTime?: Date;
    SubmitTime?: Date;
}
export interface WarningGroup {
    Code?: number;
    Count?: number;
}
export type __listOfWarningGroup = WarningGroup[];
export interface Job {
    AccelerationSettings?: AccelerationSettings;
    AccelerationStatus?: AccelerationStatus;
    Arn?: string;
    BillingTagsSource?: BillingTagsSource;
    ClientRequestToken?: string;
    CreatedAt?: Date;
    CurrentPhase?: JobPhase;
    ElementalInferenceConfiguration?: ElementalInferenceConfiguration;
    ErrorCode?: number;
    ErrorMessage?: string;
    HopDestinations?: HopDestination[];
    Id?: string;
    JobEngineVersionRequested?: string;
    JobEngineVersionUsed?: string;
    JobPercentComplete?: number;
    JobTemplate?: string;
    LastShareDetails?: string;
    Messages?: JobMessages;
    OutputGroupDetails?: OutputGroupDetail[];
    Priority?: number;
    Queue?: string;
    QueueTransitions?: QueueTransition[];
    RetryCount?: number;
    Role?: string;
    Settings?: JobSettings;
    ShareStatus?: ShareStatus;
    SimulateReservedQueue?: SimulateReservedQueue;
    Status?: JobStatus;
    StatusUpdateInterval?: StatusUpdateInterval;
    Timing?: Timing;
    UserMetadata?: {
        [key: string]: string | undefined;
    };
    Warnings?: WarningGroup[];
}
export interface CreateJobResponse {
    Job?: Job & {
        Role: string;
        Settings: JobSettings;
        AccelerationSettings: AccelerationSettings & {
            Mode: AccelerationMode;
        };
        Warnings: (WarningGroup & {
            Code: number;
            Count: number;
        })[];
    };
}
export interface InputTemplate {
    AdvancedInputFilter?: AdvancedInputFilter;
    AdvancedInputFilterSettings?: AdvancedInputFilterSettings;
    AudioSelectorGroups?: {
        [key: string]: AudioSelectorGroup | undefined;
    };
    AudioSelectors?: {
        [key: string]: AudioSelector | undefined;
    };
    CaptionSelectors?: {
        [key: string]: CaptionSelector | undefined;
    };
    Crop?: Rectangle;
    DeblockFilter?: InputDeblockFilter;
    DenoiseFilter?: InputDenoiseFilter;
    DolbyVisionMetadataXml?: string;
    DynamicAudioSelectors?: {
        [key: string]: DynamicAudioSelector | undefined;
    };
    FilterEnable?: InputFilterEnable;
    FilterStrength?: number;
    ImageInserter?: ImageInserter;
    InputClippings?: InputClipping[];
    InputScanType?: InputScanType;
    MultiViewSettings?: MultiViewSettings[];
    Position?: Rectangle;
    ProgramNumber?: number;
    PsiControl?: InputPsiControl;
    TimecodeSource?: InputTimecodeSource;
    TimecodeStart?: string;
    VideoOverlays?: VideoOverlay[];
    VideoSelector?: VideoSelector;
}
export type __listOfInputTemplate = InputTemplate[];
export interface JobTemplateSettings {
    AdAvailOffset?: number;
    AvailBlanking?: AvailBlanking;
    ColorConversion3DLUTSettings?: ColorConversion3DLUTSetting[];
    Esam?: EsamSettings;
    ExtendedDataServices?: ExtendedDataServices;
    FollowSource?: number;
    Inputs?: InputTemplate[];
    KantarWatermark?: KantarWatermarkSettings;
    MotionImageInserter?: MotionImageInserter;
    MotionImageInserters?: MotionImageInserter[];
    NielsenConfiguration?: NielsenConfiguration;
    NielsenNonLinearWatermark?: NielsenNonLinearWatermarkSettings;
    OutputGroups?: OutputGroup[];
    TimecodeConfig?: TimecodeConfig;
    TimedMetadataInsertion?: TimedMetadataInsertion;
}
export interface CreateJobTemplateRequest {
    AccelerationSettings?: AccelerationSettings;
    Category?: string;
    Description?: string;
    HopDestinations?: HopDestination[];
    Name?: string;
    Priority?: number;
    Queue?: string;
    Settings?: JobTemplateSettings;
    StatusUpdateInterval?: StatusUpdateInterval;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type Type = "SYSTEM" | "CUSTOM" | (string & {});
export interface JobTemplate {
    AccelerationSettings?: AccelerationSettings;
    Arn?: string;
    Category?: string;
    CreatedAt?: Date;
    Description?: string;
    HopDestinations?: HopDestination[];
    LastUpdated?: Date;
    Name?: string;
    Priority?: number;
    Queue?: string;
    Settings?: JobTemplateSettings;
    StatusUpdateInterval?: StatusUpdateInterval;
    Type?: Type;
}
export interface CreateJobTemplateResponse {
    JobTemplate?: JobTemplate & {
        Name: string;
        Settings: JobTemplateSettings;
        AccelerationSettings: AccelerationSettings & {
            Mode: AccelerationMode;
        };
    };
}
export interface CaptionDescriptionPreset {
    CustomLanguageCode?: string;
    DestinationSettings?: CaptionDestinationSettings;
    LanguageCode?: LanguageCode;
    LanguageDescription?: string;
}
export type __listOfCaptionDescriptionPreset = CaptionDescriptionPreset[];
export interface PresetSettings {
    AudioDescriptions?: AudioDescription[];
    CaptionDescriptions?: CaptionDescriptionPreset[];
    ContainerSettings?: ContainerSettings;
    VideoDescription?: VideoDescription;
}
export interface CreatePresetRequest {
    Category?: string;
    Description?: string;
    Name?: string;
    Settings?: PresetSettings;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface Preset {
    Arn?: string;
    Category?: string;
    CreatedAt?: Date;
    Description?: string;
    LastUpdated?: Date;
    Name?: string;
    Settings?: PresetSettings;
    Type?: Type;
}
export interface CreatePresetResponse {
    Preset?: Preset & {
        Name: string;
        Settings: PresetSettings;
    };
}
export type __integerMin0 = number;
export type PricingPlan = "ON_DEMAND" | "RESERVED" | (string & {});
export type Commitment = "ONE_YEAR" | (string & {});
export type RenewalType = "AUTO_RENEW" | "EXPIRE" | (string & {});
export interface ReservationPlanSettings {
    Commitment?: Commitment;
    RenewalType?: RenewalType;
    ReservedSlots?: number;
}
export type QueueStatus = "ACTIVE" | "PAUSED" | (string & {});
export interface CreateQueueRequest {
    ConcurrentJobs?: number;
    Description?: string;
    MaximumConcurrentFeeds?: number;
    Name?: string;
    PricingPlan?: PricingPlan;
    ReservationPlanSettings?: ReservationPlanSettings;
    Status?: QueueStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type ReservationPlanStatus = "ACTIVE" | "EXPIRED" | (string & {});
export interface ReservationPlan {
    Commitment?: Commitment;
    ExpiresAt?: Date;
    PurchasedAt?: Date;
    RenewalType?: RenewalType;
    ReservedSlots?: number;
    Status?: ReservationPlanStatus;
}
export interface ServiceOverride {
    Message?: string;
    Name?: string;
    OverrideValue?: string;
    Value?: string;
}
export type __listOfServiceOverride = ServiceOverride[];
export interface Queue {
    Arn?: string;
    ConcurrentJobs?: number;
    CreatedAt?: Date;
    Description?: string;
    LastUpdated?: Date;
    MaximumConcurrentFeeds?: number;
    Name?: string;
    PricingPlan?: PricingPlan;
    ProgressingJobsCount?: number;
    ReservationPlan?: ReservationPlan;
    ServiceOverrides?: ServiceOverride[];
    Status?: QueueStatus;
    SubmittedJobsCount?: number;
    Type?: Type;
}
export interface CreateQueueResponse {
    Queue?: Queue & {
        Name: string;
    };
}
export interface CreateResourceShareRequest {
    JobId?: string;
    SupportCaseId?: string;
}
export interface CreateResourceShareResponse {
}
export interface DeleteJobTemplateRequest {
    Name: string;
}
export interface DeleteJobTemplateResponse {
}
export interface DeletePolicyRequest {
}
export interface DeletePolicyResponse {
}
export interface DeletePresetRequest {
    Name: string;
}
export interface DeletePresetResponse {
}
export interface DeleteQueueRequest {
    Name: string;
}
export interface DeleteQueueResponse {
}
export type DescribeEndpointsMode = "DEFAULT" | "GET_ONLY" | (string & {});
export interface DescribeEndpointsRequest {
    MaxResults?: number;
    Mode?: DescribeEndpointsMode;
    NextToken?: string;
}
export interface Endpoint {
    Url?: string;
}
export type __listOfEndpoint = Endpoint[];
export interface DescribeEndpointsResponse {
    Endpoints?: Endpoint[];
    NextToken?: string;
}
export interface DisassociateCertificateRequest {
    Arn: string;
}
export interface DisassociateCertificateResponse {
}
export interface GetJobRequest {
    Id: string;
}
export interface GetJobResponse {
    Job?: Job & {
        Role: string;
        Settings: JobSettings;
        AccelerationSettings: AccelerationSettings & {
            Mode: AccelerationMode;
        };
        Warnings: (WarningGroup & {
            Code: number;
            Count: number;
        })[];
    };
}
export interface GetJobsQueryResultsRequest {
    Id: string;
}
export type __listOfJob = Job[];
export type JobsQueryStatus = "SUBMITTED" | "PROGRESSING" | "COMPLETE" | "ERROR" | (string & {});
export interface GetJobsQueryResultsResponse {
    Jobs?: (Job & {
        Role: string;
        Settings: JobSettings;
        AccelerationSettings: AccelerationSettings & {
            Mode: AccelerationMode;
        };
        Warnings: (WarningGroup & {
            Code: number;
            Count: number;
        })[];
    })[];
    NextToken?: string;
    Status?: JobsQueryStatus;
}
export interface GetJobTemplateRequest {
    Name: string;
}
export interface GetJobTemplateResponse {
    JobTemplate?: JobTemplate & {
        Name: string;
        Settings: JobTemplateSettings;
        AccelerationSettings: AccelerationSettings & {
            Mode: AccelerationMode;
        };
    };
}
export interface GetPolicyRequest {
}
export type InputPolicy = "ALLOWED" | "DISALLOWED" | (string & {});
export interface Policy {
    HttpInputs?: InputPolicy;
    HttpsInputs?: InputPolicy;
    S3Inputs?: InputPolicy;
}
export interface GetPolicyResponse {
    Policy?: Policy;
}
export interface GetPresetRequest {
    Name: string;
}
export interface GetPresetResponse {
    Preset?: Preset & {
        Name: string;
        Settings: PresetSettings;
    };
}
export interface GetQueueRequest {
    Name: string;
}
export interface GetQueueResponse {
    Queue?: Queue & {
        Name: string;
    };
}
export type __integerMin1Max20 = number;
export type Order = "ASCENDING" | "DESCENDING" | (string & {});
export interface ListJobsRequest {
    MaxResults?: number;
    NextToken?: string;
    Order?: Order;
    Queue?: string;
    Status?: JobStatus;
}
export interface ListJobsResponse {
    Jobs?: (Job & {
        Role: string;
        Settings: JobSettings;
        AccelerationSettings: AccelerationSettings & {
            Mode: AccelerationMode;
        };
        Warnings: (WarningGroup & {
            Code: number;
            Count: number;
        })[];
    })[];
    NextToken?: string;
}
export type JobTemplateListBy = "NAME" | "CREATION_DATE" | "SYSTEM" | (string & {});
export interface ListJobTemplatesRequest {
    Category?: string;
    ListBy?: JobTemplateListBy;
    MaxResults?: number;
    NextToken?: string;
    Order?: Order;
}
export type __listOfJobTemplate = JobTemplate[];
export interface ListJobTemplatesResponse {
    JobTemplates?: (JobTemplate & {
        Name: string;
        Settings: JobTemplateSettings;
        AccelerationSettings: AccelerationSettings & {
            Mode: AccelerationMode;
        };
    })[];
    NextToken?: string;
}
export type PresetListBy = "NAME" | "CREATION_DATE" | "SYSTEM" | (string & {});
export interface ListPresetsRequest {
    Category?: string;
    ListBy?: PresetListBy;
    MaxResults?: number;
    NextToken?: string;
    Order?: Order;
}
export type __listOfPreset = Preset[];
export interface ListPresetsResponse {
    NextToken?: string;
    Presets?: (Preset & {
        Name: string;
        Settings: PresetSettings;
    })[];
}
export type QueueListBy = "NAME" | "CREATION_DATE" | (string & {});
export interface ListQueuesRequest {
    ListBy?: QueueListBy;
    MaxResults?: number;
    NextToken?: string;
    Order?: Order;
}
export type __listOfQueue = Queue[];
export interface ListQueuesResponse {
    NextToken?: string;
    Queues?: (Queue & {
        Name: string;
    })[];
    TotalConcurrentJobs?: number;
    UnallocatedConcurrentJobs?: number;
}
export interface ListTagsForResourceRequest {
    Arn: string;
}
export interface ResourceTags {
    Arn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListTagsForResourceResponse {
    ResourceTags?: ResourceTags;
}
export interface ListVersionsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface JobEngineVersion {
    ExpirationDate?: Date;
    Version?: string;
}
export type __listOfJobEngineVersion = JobEngineVersion[];
export interface ListVersionsResponse {
    NextToken?: string;
    Versions?: JobEngineVersion[];
}
export interface ProbeInputFile {
    FileUrl?: string;
}
export type __listOfProbeInputFile = ProbeInputFile[];
export interface ProbeRequest {
    InputFiles?: ProbeInputFile[];
}
export type Format = "mp4" | "quicktime" | "matroska" | "webm" | "mxf" | "wave" | "avi" | "mpegts" | "mpegps" | "mp3" | "flac" | "asf" | "ogg" | "three_gp" | "three_g2" | "aac" | "ac3" | "eac3" | (string & {});
export interface FrameRate {
    Denominator?: number;
    Numerator?: number;
}
export interface AudioProperties {
    BitDepth?: number;
    BitRate?: number;
    ChannelLayout?: string;
    Channels?: number;
    FrameRate?: FrameRate;
    LanguageCode?: string;
    ObjectCount?: number;
    SampleRate?: number;
}
export type Codec = "UNKNOWN" | "AAC" | "AC3" | "AMR" | "EAC3" | "FLAC" | "MP2" | "MP3" | "OPUS" | "PCM" | "VORBIS" | "WMA" | "WMA2" | "WMAPRO" | "AV1" | "AVC" | "DV" | "H263" | "HEVC" | "JPEG2000" | "MJPEG" | "MPEG1" | "MP4V" | "MPEG2" | "PRORES" | "QTRLE" | "THEORA" | "UNCOMPRESSED" | "VC1" | "VC3" | "VFW" | "VP8" | "VP9" | "C608" | "C708" | "WEBVTT" | (string & {});
export interface DataProperties {
    LanguageCode?: string;
}
export type TrackType = "video" | "audio" | "data" | (string & {});
export type ColorPrimaries = "ITU_709" | "UNSPECIFIED" | "RESERVED" | "ITU_470M" | "ITU_470BG" | "SMPTE_170M" | "SMPTE_240M" | "GENERIC_FILM" | "ITU_2020" | "SMPTE_428_1" | "SMPTE_431_2" | "SMPTE_EG_432_1" | "IPT" | "SMPTE_2067XYZ" | "EBU_3213_E" | "LAST" | (string & {});
export interface ContentLightLevel {
    MaxContentLightLevel?: number;
    MaxFrameAverageLightLevel?: number;
}
export interface AspectRatio {
    Denominator?: number;
    Numerator?: number;
}
export type DolbyVisionPresence = "PRESENT" | "ABSENT" | (string & {});
export interface DolbyVisionMetadata {
    BaseLayer?: DolbyVisionPresence;
    EnhancementLayer?: DolbyVisionPresence;
    Level?: number;
    Profile?: number;
    Rpu?: DolbyVisionPresence;
}
export type Hdr10PlusPresence = "PRESENT" | (string & {});
export type MatrixCoefficients = "RGB" | "ITU_709" | "UNSPECIFIED" | "RESERVED" | "FCC" | "ITU_470BG" | "SMPTE_170M" | "SMPTE_240M" | "YCgCo" | "ITU_2020_NCL" | "ITU_2020_CL" | "SMPTE_2085" | "CD_NCL" | "CD_CL" | "ITU_2100ICtCp" | "IPT" | "EBU3213" | "LAST" | (string & {});
export type TransferCharacteristics = "ITU_709" | "UNSPECIFIED" | "RESERVED" | "ITU_470M" | "ITU_470BG" | "SMPTE_170M" | "SMPTE_240M" | "LINEAR" | "LOG10_2" | "LOC10_2_5" | "IEC_61966_2_4" | "ITU_1361" | "IEC_61966_2_1" | "ITU_2020_10bit" | "ITU_2020_12bit" | "SMPTE_2084" | "SMPTE_428_1" | "ARIB_B67" | "LAST" | (string & {});
export interface CodecMetadata {
    BitDepth?: number;
    ChromaSubsampling?: string;
    CodedFrameRate?: FrameRate;
    ColorPrimaries?: ColorPrimaries;
    ContentLightLevel?: ContentLightLevel;
    DisplayAspectRatio?: AspectRatio;
    DolbyVision?: DolbyVisionMetadata;
    FieldOrder?: string;
    Hdr10PlusPresence?: Hdr10PlusPresence;
    Height?: number;
    Level?: string;
    MatrixCoefficients?: MatrixCoefficients;
    Profile?: string;
    Rotation?: number;
    SampleAspectRatio?: AspectRatio;
    ScanType?: string;
    TransferCharacteristics?: TransferCharacteristics;
    Width?: number;
}
export interface MasteringDisplayColorVolume {
    BluePrimaryX?: number;
    BluePrimaryY?: number;
    GreenPrimaryX?: number;
    GreenPrimaryY?: number;
    MaxLuminance?: number;
    MinLuminance?: number;
    RedPrimaryX?: number;
    RedPrimaryY?: number;
    WhitePointX?: number;
    WhitePointY?: number;
}
export interface HdrMetadata {
    ContentLightLevel?: ContentLightLevel;
    MasteringDisplayColorVolume?: MasteringDisplayColorVolume;
}
export interface VideoProperties {
    BitDepth?: number;
    BitRate?: number;
    CodecMetadata?: CodecMetadata;
    ColorPrimaries?: ColorPrimaries;
    DisplayAspectRatio?: AspectRatio;
    FrameRate?: FrameRate;
    HdrMetadata?: HdrMetadata;
    Height?: number;
    MatrixCoefficients?: MatrixCoefficients;
    Rotation?: number;
    SampleAspectRatio?: AspectRatio;
    TransferCharacteristics?: TransferCharacteristics;
    Width?: number;
}
export interface Track {
    AudioProperties?: AudioProperties;
    Codec?: Codec;
    DataProperties?: DataProperties;
    Duration?: number;
    Index?: number;
    TrackType?: TrackType;
    VideoProperties?: VideoProperties;
}
export type __listOfTrack = Track[];
export interface Container {
    BitRate?: number;
    Duration?: number;
    Format?: Format;
    StartTimecode?: string;
    Tracks?: Track[];
}
export interface Metadata {
    ETag?: string;
    FileSize?: number;
    LastModified?: Date;
    MimeType?: string;
}
export type __listOf__integer = number[];
export interface TrackMapping {
    AudioTrackIndexes?: number[];
    DataTrackIndexes?: number[];
    VideoTrackIndexes?: number[];
}
export type __listOfTrackMapping = TrackMapping[];
export interface ProbeResult {
    Container?: Container;
    Metadata?: Metadata;
    TrackMappings?: TrackMapping[];
}
export type __listOfProbeResult = ProbeResult[];
export interface ProbeResponse {
    ProbeResults?: ProbeResult[];
}
export interface PutPolicyRequest {
    Policy?: Policy;
}
export interface PutPolicyResponse {
    Policy?: Policy;
}
export interface SearchJobsRequest {
    InputFile?: string;
    MaxResults?: number;
    NextToken?: string;
    Order?: Order;
    Queue?: string;
    Status?: JobStatus;
}
export interface SearchJobsResponse {
    Jobs?: (Job & {
        Role: string;
        Settings: JobSettings;
        AccelerationSettings: AccelerationSettings & {
            Mode: AccelerationMode;
        };
        Warnings: (WarningGroup & {
            Code: number;
            Count: number;
        })[];
    })[];
    NextToken?: string;
}
export type JobsQueryFilterKey = "queue" | "status" | "fileInput" | "jobEngineVersionRequested" | "jobEngineVersionUsed" | "audioCodec" | "videoCodec" | "errorCode" | (string & {});
export type __stringMax100 = string;
export type __listOf__stringMax100 = string[];
export interface JobsQueryFilter {
    Key?: JobsQueryFilterKey;
    Values?: string[];
}
export type __listOfJobsQueryFilter = JobsQueryFilter[];
export interface StartJobsQueryRequest {
    FilterList?: JobsQueryFilter[];
    MaxResults?: number;
    NextToken?: string;
    Order?: Order;
}
export interface StartJobsQueryResponse {
    Id?: string;
}
export interface TagResourceRequest {
    Arn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export interface UntagResourceRequest {
    Arn: string;
    TagKeys?: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateJobTemplateRequest {
    AccelerationSettings?: AccelerationSettings;
    Category?: string;
    Description?: string;
    HopDestinations?: HopDestination[];
    Name: string;
    Priority?: number;
    Queue?: string;
    Settings?: JobTemplateSettings;
    StatusUpdateInterval?: StatusUpdateInterval;
}
export interface UpdateJobTemplateResponse {
    JobTemplate?: JobTemplate & {
        Name: string;
        Settings: JobTemplateSettings;
        AccelerationSettings: AccelerationSettings & {
            Mode: AccelerationMode;
        };
    };
}
export interface UpdatePresetRequest {
    Category?: string;
    Description?: string;
    Name: string;
    Settings?: PresetSettings;
}
export interface UpdatePresetResponse {
    Preset?: Preset & {
        Name: string;
        Settings: PresetSettings;
    };
}
export interface UpdateQueueRequest {
    ConcurrentJobs?: number;
    Description?: string;
    MaximumConcurrentFeeds?: number;
    Name: string;
    ReservationPlanSettings?: ReservationPlanSettings;
    Status?: QueueStatus;
}
export interface UpdateQueueResponse {
    Queue?: Queue & {
        Name: string;
    };
}
export type AssociateCertificateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Associates an AWS Certificate Manager (ACM) Amazon Resource Name (ARN) with AWS Elemental MediaConvert.
 */
export declare const associateCertificate: API.OperationMethod<AssociateCertificateRequest, AssociateCertificateResponse, AssociateCertificateError, Credentials | HttpClient.HttpClient>;
export type CancelJobError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Permanently cancel a job. Once you have canceled a job, you can't start it again.
 */
export declare const cancelJob: API.OperationMethod<CancelJobRequest, CancelJobResponse, CancelJobError, Credentials | HttpClient.HttpClient>;
export type CreateJobError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Create a new transcoding job. For information about jobs and job settings, see the User Guide at http://docs.aws.amazon.com/mediaconvert/latest/ug/what-is.html
 */
export declare const createJob: API.OperationMethod<CreateJobRequest, CreateJobResponse, CreateJobError, Credentials | HttpClient.HttpClient>;
export type CreateJobTemplateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Create a new job template. For information about job templates see the User Guide at http://docs.aws.amazon.com/mediaconvert/latest/ug/what-is.html
 */
export declare const createJobTemplate: API.OperationMethod<CreateJobTemplateRequest, CreateJobTemplateResponse, CreateJobTemplateError, Credentials | HttpClient.HttpClient>;
export type CreatePresetError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Create a new preset. For information about job templates see the User Guide at http://docs.aws.amazon.com/mediaconvert/latest/ug/what-is.html
 */
export declare const createPreset: API.OperationMethod<CreatePresetRequest, CreatePresetResponse, CreatePresetError, Credentials | HttpClient.HttpClient>;
export type CreateQueueError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Create a new transcoding queue. For information about queues, see Working With Queues in the User Guide at https://docs.aws.amazon.com/mediaconvert/latest/ug/working-with-queues.html
 */
export declare const createQueue: API.OperationMethod<CreateQueueRequest, CreateQueueResponse, CreateQueueError, Credentials | HttpClient.HttpClient>;
export type CreateResourceShareError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Create a new resource share request for MediaConvert resources with AWS Support.
 */
export declare const createResourceShare: API.OperationMethod<CreateResourceShareRequest, CreateResourceShareResponse, CreateResourceShareError, Credentials | HttpClient.HttpClient>;
export type DeleteJobTemplateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Permanently delete a job template you have created.
 */
export declare const deleteJobTemplate: API.OperationMethod<DeleteJobTemplateRequest, DeleteJobTemplateResponse, DeleteJobTemplateError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Permanently delete a policy that you created.
 */
export declare const deletePolicy: API.OperationMethod<DeletePolicyRequest, DeletePolicyResponse, DeletePolicyError, Credentials | HttpClient.HttpClient>;
export type DeletePresetError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Permanently delete a preset you have created.
 */
export declare const deletePreset: API.OperationMethod<DeletePresetRequest, DeletePresetResponse, DeletePresetError, Credentials | HttpClient.HttpClient>;
export type DeleteQueueError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Permanently delete a queue you have created.
 */
export declare const deleteQueue: API.OperationMethod<DeleteQueueRequest, DeleteQueueResponse, DeleteQueueError, Credentials | HttpClient.HttpClient>;
export type DescribeEndpointsError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Send a request with an empty body to the regional API endpoint to get your account API endpoint. Note that DescribeEndpoints is no longer required. We recommend that you send your requests directly to the regional endpoint instead.
 */
export declare const describeEndpoints: API.PaginatedOperationMethod<DescribeEndpointsRequest, DescribeEndpointsResponse, DescribeEndpointsError, Credentials | HttpClient.HttpClient, Endpoint>;
export type DisassociateCertificateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Removes an association between the Amazon Resource Name (ARN) of an AWS Certificate Manager (ACM) certificate and an AWS Elemental MediaConvert resource.
 */
export declare const disassociateCertificate: API.OperationMethod<DisassociateCertificateRequest, DisassociateCertificateResponse, DisassociateCertificateError, Credentials | HttpClient.HttpClient>;
export type GetJobError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the JSON for a specific transcoding job.
 */
export declare const getJob: API.OperationMethod<GetJobRequest, GetJobResponse, GetJobError, Credentials | HttpClient.HttpClient>;
export type GetJobsQueryResultsError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a JSON array of up to twenty of your most recent jobs matched by a jobs query.
 */
export declare const getJobsQueryResults: API.OperationMethod<GetJobsQueryResultsRequest, GetJobsQueryResultsResponse, GetJobsQueryResultsError, Credentials | HttpClient.HttpClient>;
export type GetJobTemplateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the JSON for a specific job template.
 */
export declare const getJobTemplate: API.OperationMethod<GetJobTemplateRequest, GetJobTemplateResponse, GetJobTemplateError, Credentials | HttpClient.HttpClient>;
export type GetPolicyError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the JSON for your policy.
 */
export declare const getPolicy: API.OperationMethod<GetPolicyRequest, GetPolicyResponse, GetPolicyError, Credentials | HttpClient.HttpClient>;
export type GetPresetError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the JSON for a specific preset.
 */
export declare const getPreset: API.OperationMethod<GetPresetRequest, GetPresetResponse, GetPresetError, Credentials | HttpClient.HttpClient>;
export type GetQueueError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the JSON for a specific queue.
 */
export declare const getQueue: API.OperationMethod<GetQueueRequest, GetQueueResponse, GetQueueError, Credentials | HttpClient.HttpClient>;
export type ListJobsError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a JSON array of up to twenty of your most recently created jobs. This array includes in-process, completed, and errored jobs. This will return the jobs themselves, not just a list of the jobs. To retrieve the twenty next most recent jobs, use the nextToken string returned with the array.
 */
export declare const listJobs: API.PaginatedOperationMethod<ListJobsRequest, ListJobsResponse, ListJobsError, Credentials | HttpClient.HttpClient, Job>;
export type ListJobTemplatesError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a JSON array of up to twenty of your job templates. This will return the templates themselves, not just a list of them. To retrieve the next twenty templates, use the nextToken string returned with the array
 */
export declare const listJobTemplates: API.PaginatedOperationMethod<ListJobTemplatesRequest, ListJobTemplatesResponse, ListJobTemplatesError, Credentials | HttpClient.HttpClient, JobTemplate>;
export type ListPresetsError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a JSON array of up to twenty of your presets. This will return the presets themselves, not just a list of them. To retrieve the next twenty presets, use the nextToken string returned with the array.
 */
export declare const listPresets: API.PaginatedOperationMethod<ListPresetsRequest, ListPresetsResponse, ListPresetsError, Credentials | HttpClient.HttpClient, Preset>;
export type ListQueuesError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a JSON array of up to twenty of your queues. This will return the queues themselves, not just a list of them. To retrieve the next twenty queues, use the nextToken string returned with the array.
 */
export declare const listQueues: API.PaginatedOperationMethod<ListQueuesRequest, ListQueuesResponse, ListQueuesError, Credentials | HttpClient.HttpClient, Queue>;
export type ListTagsForResourceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the tags for a MediaConvert resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVersionsError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a JSON array of all available Job engine versions and the date they expire.
 */
export declare const listVersions: API.PaginatedOperationMethod<ListVersionsRequest, ListVersionsResponse, ListVersionsError, Credentials | HttpClient.HttpClient, JobEngineVersion>;
export type ProbeError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Use Probe to obtain detailed information about your input media files. Probe returns a JSON that includes container, codec, frame rate, resolution, track count, audio layout, captions, and more. You can use this information to learn more about your media files, or to help make decisions while automating your transcoding workflow. Probe supports the following input container formats: MP4, QuickTime (MOV), 3GP, 3G2, Matroska (MKV), WebM, MXF, MPEG-TS, MPEG-PS, AVI, WAV, MP3, FLAC, Ogg, and ASF (Windows Media / WMA). The fields that Probe returns vary by container and codec. A field isn't returned when the source doesn't contain it, or when it isn't available for that container and codec.
 */
export declare const probe: API.OperationMethod<ProbeRequest, ProbeResponse, ProbeError, Credentials | HttpClient.HttpClient>;
export type PutPolicyError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Create or change your policy. For more information about policies, see the user guide at http://docs.aws.amazon.com/mediaconvert/latest/ug/what-is.html
 */
export declare const putPolicy: API.OperationMethod<PutPolicyRequest, PutPolicyResponse, PutPolicyError, Credentials | HttpClient.HttpClient>;
export type SearchJobsError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a JSON array that includes job details for up to twenty of your most recent jobs. Optionally filter results further according to input file, queue, or status. To retrieve the twenty next most recent jobs, use the nextToken string returned with the array.
 */
export declare const searchJobs: API.PaginatedOperationMethod<SearchJobsRequest, SearchJobsResponse, SearchJobsError, Credentials | HttpClient.HttpClient, Job>;
export type StartJobsQueryError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Start an asynchronous jobs query using the provided filters. To receive the list of jobs that match your query, call the GetJobsQueryResults API using the query ID returned by this API.
 */
export declare const startJobsQuery: API.OperationMethod<StartJobsQueryRequest, StartJobsQueryResponse, StartJobsQueryError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Add tags to a MediaConvert queue, preset, job, or job template. For information about tagging, see the User Guide at https://docs.aws.amazon.com/mediaconvert/latest/ug/tagging-mediaconvert-resources.html.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Remove tags from a MediaConvert queue, preset, job, or job template. For information about tagging, see the User Guide at https://docs.aws.amazon.com/mediaconvert/latest/ug/tagging-mediaconvert-resources.html.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateJobTemplateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Modify one of your existing job templates.
 */
export declare const updateJobTemplate: API.OperationMethod<UpdateJobTemplateRequest, UpdateJobTemplateResponse, UpdateJobTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdatePresetError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Modify one of your existing presets.
 */
export declare const updatePreset: API.OperationMethod<UpdatePresetRequest, UpdatePresetResponse, UpdatePresetError, Credentials | HttpClient.HttpClient>;
export type UpdateQueueError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Modify one of your existing queues.
 */
export declare const updateQueue: API.OperationMethod<UpdateQueueRequest, UpdateQueueResponse, UpdateQueueError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=mediaconvert.d.ts.map