import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type * as stream from "effect/Stream";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ContentSizeExceededException_base: S.TaggedErrorClass<"ContentSizeExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ContentSizeExceededException extends /*@__PURE__*/ ContentSizeExceededException_base {
}
declare const IdentityCenterServiceException_base: S.TaggedErrorClass<"IdentityCenterServiceException", {
    readonly message: any;
    readonly underlyingErrorCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IdentityCenterServiceException extends /*@__PURE__*/ IdentityCenterServiceException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly fieldList: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type AgentSpaceId = string;
export type ServiceId = string;
export type SourceAccountType = "source" | (string & {});
export type RoleArn = string;
export type ValidationStatus = "valid" | "invalid" | "pending-confirmation" | (string & {});
export interface SourceAwsConfiguration {
    accountId: string;
    accountType: SourceAccountType;
    assumableRoleArn: string;
    externalId?: string;
    agentElevatedRoleArn?: string;
    agentElevatedRoleArnStatus?: ValidationStatus;
}
export type MonitorAccountType = "monitor" | (string & {});
export interface AWSConfiguration {
    assumableRoleArn: string;
    accountId: string;
    accountType: MonitorAccountType;
    agentElevatedRoleArn?: string;
    agentElevatedRoleArnStatus?: ValidationStatus;
}
export type GithubRepoOwnerType = "organization" | "user" | (string & {});
export interface GitHubConfiguration {
    repoName: string;
    repoId: string;
    owner: string;
    ownerType: GithubRepoOwnerType;
    instanceIdentifier?: string;
    runtimeRoleArn?: string;
}
export interface SlackChannel {
    channelName?: string;
    channelId: string;
}
export interface SlackTransmissionTarget {
    opsOncallTarget: SlackChannel;
    opsSRETarget?: SlackChannel;
}
export interface SlackBidirectionalConfiguration {
    roleArn: string;
    enabled?: boolean;
}
export interface SlackConfiguration {
    workspaceId: string;
    workspaceName: string;
    transmissionTarget: SlackTransmissionTarget;
    bidirectional?: SlackBidirectionalConfiguration;
}
export type DynatraceResourceList = string[];
export interface DynatraceConfiguration {
    envId: string;
    resources?: string[];
}
export type ServiceNowAuthenticationScopeList = string[];
export interface ServiceNowConfiguration {
    instanceId?: string;
    authScopes?: string[];
}
export interface MCPServerNewRelicConfiguration {
    accountId: string;
    endpoint: string;
}
export type ToolClassification = "READ_ONLY" | "MUTATIVE" | "DESTRUCTIVE" | (string & {});
export interface MCPToolDetail {
    name: string;
    toolClassification?: ToolClassification;
}
export type MCPToolDetailsList = MCPToolDetail[];
export interface MCPServerDatadogConfiguration {
    enabledElevatedTools?: MCPToolDetail[];
}
export type MCPToolsList = string[];
export interface MCPServerConfiguration {
    tools: string[];
    toolDetails?: MCPToolDetail[];
}
export interface GitLabConfiguration {
    projectId: string;
    projectPath: string;
    instanceIdentifier?: string;
    runtimeRoleArn?: string;
}
export interface MCPServerSplunkConfiguration {
}
export interface EventChannelConfiguration {
}
export interface AzureConfiguration {
    subscriptionId: string;
}
export interface AzureDevOpsConfiguration {
    organizationName: string;
    projectId: string;
    projectName: string;
}
export interface MCPServerGrafanaConfiguration {
    endpoint: string;
    organizationId?: string;
    tools?: string[];
    enabledElevatedTools?: MCPToolDetail[];
}
export type PagerDutyServicesList = string[];
export type EmailAddress = string | redacted.Redacted<string>;
export interface PagerDutyConfiguration {
    services: string[];
    customerEmail: string | redacted.Redacted<string>;
}
export interface MCPServerSigV4Configuration {
    tools: string[];
    toolDetails?: MCPToolDetail[];
}
export interface RemoteAgentConfiguration {
}
export interface RemoteAgentSigV4Configuration {
}
export type ServiceConfiguration = {
    sourceAws: SourceAwsConfiguration;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws: AWSConfiguration;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github: GitHubConfiguration;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack: SlackConfiguration;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace: DynatraceConfiguration;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow: ServiceNowConfiguration;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic: MCPServerNewRelicConfiguration;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog: MCPServerDatadogConfiguration;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver: MCPServerConfiguration;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab: GitLabConfiguration;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk: MCPServerSplunkConfiguration;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel: EventChannelConfiguration;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure: AzureConfiguration;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops: AzureDevOpsConfiguration;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana: MCPServerGrafanaConfiguration;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty: PagerDutyConfiguration;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4: MCPServerSigV4Configuration;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent: RemoteAgentConfiguration;
    remoteagentsigv4?: never;
} | {
    sourceAws?: never;
    aws?: never;
    github?: never;
    slack?: never;
    dynatrace?: never;
    servicenow?: never;
    mcpservernewrelic?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    eventChannel?: never;
    azure?: never;
    azuredevops?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4: RemoteAgentSigV4Configuration;
};
export type CapabilityType = "RELEASE_READINESS_REVIEW" | "RELEASE_READINESS_REVIEW_AUTOMATED_TESTING" | (string & {});
export type TriggerEvent = "PULL_REQUEST_READY_FOR_REVIEW" | "PULL_REQUEST_DRAFT" | (string & {});
export type TriggerEventList = TriggerEvent[];
export type TriggerRegexPattern = string;
export type TriggerRegexPatternList = string[];
export interface PatternFilter {
    patterns: string[];
}
export interface TriggerFilterGroup {
    events?: TriggerEvent[];
    targetBranches?: PatternFilter;
}
export type TriggerFilterGroups = TriggerFilterGroup[];
export interface CapabilityConfiguration {
    enabled?: boolean;
    triggerFilterGroups?: TriggerFilterGroup[];
}
export type AssociationCapabilities = {
    [key in CapabilityType]?: CapabilityConfiguration;
};
export interface AssociateServiceInput {
    agentSpaceId: string;
    serviceId: string;
    configuration: ServiceConfiguration;
    capabilities?: {
        [key: string]: CapabilityConfiguration | undefined;
    };
}
export type AssociationId = string;
export interface Association {
    agentSpaceId: string;
    createdAt: Date;
    updatedAt: Date;
    status?: ValidationStatus;
    associationId: string;
    serviceId: string;
    configuration: ServiceConfiguration;
    capabilities?: {
        [key: string]: CapabilityConfiguration | undefined;
    };
}
export type WebhookType = "hmac" | "apikey" | "gitlab" | "pagerduty" | (string & {});
export type WebhookSecret = string | redacted.Redacted<string>;
export type ApiKeyValue = string | redacted.Redacted<string>;
export interface GenericWebhook {
    webhookUrl?: string;
    webhookId?: string;
    webhookType?: WebhookType;
    webhookSecret?: string | redacted.Redacted<string>;
    apiKey?: string | redacted.Redacted<string>;
}
export interface AssociateServiceOutput {
    association: Association;
    webhook?: GenericWebhook;
}
export type AgentSpaceName = string;
export type Description = string | redacted.Redacted<string>;
export type Locale = string;
export type KmsKeyArn = string;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export type AgentSpacePreferenceKey = "elevatedActionsEnabled" | (string & {});
export type AgentSpacePreferences = {
    [key in AgentSpacePreferenceKey]?: boolean;
};
export interface CreateAgentSpaceInput {
    name: string;
    description?: string | redacted.Redacted<string>;
    locale?: string;
    kmsKeyArn?: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    preferences?: {
        [key: string]: boolean | undefined;
    };
}
export interface AgentSpace {
    name: string;
    description?: string | redacted.Redacted<string>;
    locale?: string;
    createdAt: Date;
    updatedAt: Date;
    kmsKeyArn?: string;
    agentSpaceId: string;
    preferences?: {
        [key: string]: boolean | undefined;
    };
}
export interface CreateAgentSpaceOutput {
    agentSpace: AgentSpace;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type AgentSpaceIdentifier = string;
export type AssetType = string;
export type AssetFilePath = string;
export type AssetFileBytes = Uint8Array;
export type AssetFileText = string;
export type AssetFileBody = {
    bytes: Uint8Array;
    text?: never;
} | {
    bytes?: never;
    text: string;
};
export interface AssetFileContent {
    path: string;
    body: AssetFileBody;
    metadata?: any;
}
export type AssetZipBytes = Uint8Array;
export interface AssetZipContent {
    zipFile: Uint8Array;
}
export type AssetContentUrl = string;
export interface AssetSourceUrlContent {
    url: string;
}
export type AssetContent = {
    file: AssetFileContent;
    zip?: never;
    sourceUrl?: never;
} | {
    file?: never;
    zip: AssetZipContent;
    sourceUrl?: never;
} | {
    file?: never;
    zip?: never;
    sourceUrl: AssetSourceUrlContent;
};
export interface CreateAssetRequest {
    agentSpaceId: string;
    assetType: string;
    metadata?: any;
    content: AssetContent;
    clientToken?: string;
}
export type ResourceId = string;
export interface Asset {
    assetId: string;
    assetType: string;
    metadata: any;
    version: number;
    createdAt: Date;
    updatedAt: Date;
}
export interface CreateAssetResponse {
    asset: Asset;
}
export interface CreateAssetFileRequest {
    agentSpaceId: string;
    assetId: string;
    path: string;
    content: AssetFileBody;
    metadata?: any;
    clientToken?: string;
}
export interface AssetFile {
    path: string;
    content: AssetFileBody;
    metadata?: any;
    version: number;
    createdAt: Date;
    updatedAt: Date;
}
export interface CreateAssetFileResponse {
    file: AssetFile;
}
export interface ReferenceInput {
    system: string;
    title?: string;
    referenceId: string;
    referenceUrl: string;
    associationId: string;
}
export type TaskType = "INVESTIGATION" | "EVALUATION" | "RELEASE_READINESS_REVIEW" | "RELEASE_TESTING" | (string & {});
export type BacklogTaskTitle = string;
export type BacklogTaskDescription = string;
export type Priority = "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "MINIMAL" | (string & {});
export interface CreateBacklogTaskRequest {
    agentSpaceId: string;
    reference?: ReferenceInput;
    taskType: TaskType;
    title: string;
    description?: string;
    priority: Priority;
    clientToken?: string;
}
export interface ReferenceOutput {
    system: string;
    title?: string;
    referenceId: string;
    referenceUrl: string;
    associationId: string;
}
export type TaskStatus = "PENDING_TRIAGE" | "LINKED" | "PENDING_START" | "IN_PROGRESS" | "PENDING_CUSTOMER_APPROVAL" | "COMPLETED" | "FAILED" | "TIMED_OUT" | "CANCELED" | "SKIPPED" | "WAITING" | (string & {});
export type BackLogTimestamp = Date;
export interface Task {
    agentSpaceId: string;
    taskId: string;
    executionId?: string;
    title: string;
    description?: string;
    reference?: ReferenceOutput;
    taskType: TaskType;
    priority: Priority;
    status: TaskStatus;
    createdAt: Date;
    updatedAt: Date;
    version: number;
    supportMetadata?: any;
    metadata?: any;
    primaryTaskId?: string;
    statusReason?: string;
    hasLinkedTasks?: boolean;
}
export interface CreateBacklogTaskResponse {
    task: Task;
}
export type UserType = "IAM" | "IDC" | "IDP" | (string & {});
export interface CreateChatRequest {
    agentSpaceId: string;
    userId?: string;
    userType?: UserType;
}
export interface CreateChatResponse {
    executionId: string;
    createdAt: Date;
}
export type PrivateConnectionName = string;
export type IpAddressOrDnsName = string;
export type VpcId = string;
export type SubnetId = string;
export type ListOfSubnetIds = string[];
export type SecurityGroupId = string;
export type ListOfSecurityGroupIds = string[];
export type IpAddressType = "IPV4" | "IPV6" | "DUAL_STACK" | (string & {});
export type MaxIpv4AddressesPerEni = number;
export type PortRange = string;
export type PortRanges = string[];
export type CertificateString = string;
export type ResourceConfigDnsResolution = "PUBLIC" | "IN_VPC" | (string & {});
export interface ServiceManagedInput {
    hostAddress: string;
    vpcId: string;
    subnetIds: string[];
    securityGroupIds?: string[];
    ipAddressType?: IpAddressType;
    ipv4AddressesPerEni?: number;
    portRanges?: string[];
    certificate?: string;
    dnsResolution?: ResourceConfigDnsResolution;
}
export type ResourceConfigurationArn = string;
export interface SelfManagedInput {
    resourceConfigurationId: string;
    certificate?: string;
}
export type PrivateConnectionMode = {
    serviceManaged: ServiceManagedInput;
    selfManaged?: never;
} | {
    serviceManaged?: never;
    selfManaged: SelfManagedInput;
};
export interface CreatePrivateConnectionInput {
    name: string;
    mode: PrivateConnectionMode;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type PrivateConnectionType = "SELF_MANAGED" | "SERVICE_MANAGED" | (string & {});
export type ResourceGatewayArn = string;
export type PrivateConnectionStatus = "ACTIVE" | "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | (string & {});
export type FailureMessage = string;
export interface CreatePrivateConnectionOutput {
    name: string;
    type: PrivateConnectionType;
    resourceGatewayId?: string;
    hostAddress?: string;
    vpcId?: string;
    resourceConfigurationId?: string;
    status: PrivateConnectionStatus;
    certificateExpiryTime?: Date;
    dnsResolution?: ResourceConfigDnsResolution;
    failureMessage?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type TriggerType = string;
export type ScheduleExpression = string;
export interface ScheduleCondition {
    expression: string;
}
export type TriggerCondition = {
    schedule: ScheduleCondition;
};
export type TriggerAction = unknown;
export type TriggerStatus = string;
export interface CreateTriggerRequest {
    agentSpaceId: string;
    type: string;
    condition: TriggerCondition;
    action: any;
    status?: string;
    clientToken?: string;
}
export interface Trigger {
    triggerId: string;
    agentSpaceId: string;
    type: string;
    condition: TriggerCondition;
    action: any;
    status: string;
    createdAt: Date;
    updatedAt: Date;
}
export interface CreateTriggerResponse {
    trigger: Trigger;
}
export interface DeleteAgentSpaceInput {
    agentSpaceId: string;
}
export interface DeleteAgentSpaceOutput {
}
export interface DeleteAssetRequest {
    agentSpaceId: string;
    assetId: string;
}
export interface DeleteAssetResponse {
}
export interface DeleteAssetFileRequest {
    agentSpaceId: string;
    assetId: string;
    path: string;
}
export interface DeleteAssetFileResponse {
}
export interface DeletePrivateConnectionInput {
    name: string;
}
export interface DeletePrivateConnectionOutput {
    name: string;
    status: PrivateConnectionStatus;
}
export interface DeleteTriggerRequest {
    agentSpaceId: string;
    triggerId: string;
}
export interface DeleteTriggerResponse {
}
export interface DeregisterServiceInput {
    serviceId: string;
}
export interface DeregisterServiceOutput {
}
export interface DescribePrivateConnectionInput {
    name: string;
}
export interface DescribePrivateConnectionOutput {
    name: string;
    type: PrivateConnectionType;
    resourceGatewayId?: string;
    hostAddress?: string;
    vpcId?: string;
    resourceConfigurationId?: string;
    status: PrivateConnectionStatus;
    certificateExpiryTime?: Date;
    dnsResolution?: ResourceConfigDnsResolution;
    failureMessage?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type AuthFlow = "iam" | "idc" | "idp" | (string & {});
export interface DisableOperatorAppInput {
    agentSpaceId: string;
    authFlow?: AuthFlow;
}
export interface DisableOperatorAppResponse {
}
export interface DisassociateServiceInput {
    agentSpaceId: string;
    associationId: string;
}
export interface DisassociateServiceOutput {
}
export type IdpClientId = string;
export type IdpClientSecret = string | redacted.Redacted<string>;
export interface EnableOperatorAppInput {
    agentSpaceId: string;
    authFlow: AuthFlow;
    operatorAppRoleArn: string;
    idcInstanceArn?: string;
    issuerUrl?: string;
    idpClientId?: string;
    idpClientSecret?: string | redacted.Redacted<string>;
    provider?: string;
}
export type OperatorAppUrl = string;
export interface IamAuthConfiguration {
    operatorAppRoleArn: string;
    createdAt: Date;
    updatedAt?: Date;
}
export interface IdcAuthConfiguration {
    operatorAppRoleArn: string;
    idcInstanceArn: string;
    idcApplicationArn?: string;
    createdAt: Date;
    updatedAt?: Date;
}
export interface IdpAuthConfiguration {
    issuerUrl: string;
    clientId: string;
    operatorAppRoleArn: string;
    provider: string;
    createdAt: Date;
    updatedAt?: Date;
}
export interface EnableOperatorAppOutput {
    agentSpaceId: string;
    operatorAppUrl?: string;
    iam?: IamAuthConfiguration;
    idc?: IdcAuthConfiguration;
    idp?: IdpAuthConfiguration;
}
export interface GetAccountUsageInput {
}
export interface UsageMetric {
    limit: number;
    usage: number;
}
export interface GetAccountUsageOutput {
    monthlyAccountInvestigationHours?: UsageMetric;
    monthlyAccountEvaluationHours?: UsageMetric;
    monthlyAccountSystemLearningHours?: UsageMetric;
    monthlyAccountOnDemandHours?: UsageMetric;
    usagePeriodStartTime: Date;
    usagePeriodEndTime: Date;
}
export interface GetAgentSpaceInput {
    agentSpaceId: string;
}
export interface GetAgentSpaceOutput {
    agentSpace: AgentSpace;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetAssetRequest {
    agentSpaceId: string;
    assetId: string;
    assetVersion?: number;
}
export interface GetAssetResponse {
    asset: Asset;
}
export interface GetAssetContentRequest {
    agentSpaceId: string;
    assetId: string;
    assetVersion?: number;
}
export interface GetAssetContentResponse {
    content: AssetZipContent;
    version: number;
}
export interface GetAssetFileRequest {
    agentSpaceId: string;
    assetId: string;
    path: string;
    assetVersion?: number;
}
export interface GetAssetFileResponse {
    file: AssetFile;
}
export interface GetAssociationInput {
    agentSpaceId: string;
    associationId: string;
}
export interface GetAssociationOutput {
    association: Association;
}
export interface GetBacklogTaskRequest {
    agentSpaceId: string;
    taskId: string;
}
export interface GetBacklogTaskResponse {
    task: Task;
}
export interface GetOperatorAppInput {
    agentSpaceId: string;
}
export interface GetOperatorAppOutput {
    operatorAppUrl?: string;
    iam?: IamAuthConfiguration;
    idc?: IdcAuthConfiguration;
    idp?: IdpAuthConfiguration;
}
export interface GetRecommendationRequest {
    agentSpaceId: string;
    recommendationId: string;
    recommendationVersion?: number;
}
export interface RecommendationContent {
    summary: string;
    spec?: string;
}
export type RecommendationStatus = "PROPOSED" | "ACCEPTED" | "REJECTED" | "CLOSED" | "COMPLETED" | "UPDATE_IN_PROGRESS" | (string & {});
export type RecommendationPriority = "HIGH" | "MEDIUM" | "LOW" | (string & {});
export interface Recommendation {
    agentSpaceArn: string;
    recommendationId: string;
    taskId: string;
    goalId?: string;
    title: string;
    content: RecommendationContent;
    status: RecommendationStatus;
    priority: RecommendationPriority;
    goalVersion?: number;
    additionalContext?: string;
    rankPosition?: number;
    rankedAt?: Date;
    createdAt: Date;
    updatedAt: Date;
    version: number;
}
export interface GetRecommendationResponse {
    recommendation: Recommendation;
}
export interface GetServiceInput {
    serviceId: string;
}
export type Service = "github" | "slack" | "azure" | "azuredevops" | "dynatrace" | "servicenow" | "pagerduty" | "gitlab" | "eventChannel" | "mcpservernewrelic" | "mcpservergrafana" | "mcpserverdatadog" | "mcpserver" | "mcpserversplunk" | "azureidentity" | "mcpserversigv4" | "remoteagent" | "remoteagentsigv4" | (string & {});
export type ServiceName = string;
export type DocumentList = any[];
export interface RegisteredGithubServiceDetails {
    owner: string;
    ownerType: GithubRepoOwnerType;
    targetUrl?: string;
}
export interface RegisteredSlackServiceDetails {
    teamId: string;
    teamName: string;
}
export type MCPServerAuthorizationMethod = "oauth-client-credentials" | "oauth-3lo" | "api-key" | "bearer-token" | (string & {});
export interface RegisteredMCPServerDetails {
    name: string;
    endpoint: string;
    authorizationMethod: MCPServerAuthorizationMethod;
    description?: string | redacted.Redacted<string>;
    apiKeyHeader?: string;
}
export type ServiceNowInstanceUrl = string;
export interface RegisteredServiceNowDetails {
    instanceUrl?: string;
}
export type GitLabTokenType = "personal" | "group" | (string & {});
export interface RegisteredGitLabServiceDetails {
    targetUrl: string;
    tokenType: GitLabTokenType;
    groupId?: string;
}
export type NewRelicRegion = "US" | "EU" | "JP" | (string & {});
export interface RegisteredNewRelicDetails {
    accountId: string;
    region: NewRelicRegion;
    description?: string | redacted.Redacted<string>;
}
export interface RegisteredAzureDevOpsServiceDetails {
    organizationName: string;
}
export type Guid = string;
export type WebIdentityTokenAudienceList = string[];
export interface RegisteredAzureIdentityDetails {
    tenantId: string;
    clientId: string;
    webIdentityRoleArn: string;
    webIdentityTokenAudiences: string[];
}
export type MCPServerEndpoint = string;
export interface RegisteredGrafanaServerDetails {
    endpoint: string;
    authorizationMethod: MCPServerAuthorizationMethod;
}
export type PagerDutyScopesList = string[];
export interface RegisteredPagerDutyDetails {
    scopes: string[];
}
export type MCPServerName = string;
export type SigV4Region = string;
export type CustomHeaderName = string;
export type CustomHeaderValue = string | redacted.Redacted<string>;
export type CustomHeaders = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export interface RegisteredMCPServerSigV4Details {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string>;
    region: string;
    service: string;
    roleArn: string;
    mcpRoleArn?: string;
    customHeaders?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export type RemoteAgentName = string;
export type RemoteAgentEndpoint = string;
export type RemoteAgentAuthorizationMethod = "oauth-client-credentials" | "api-key" | "bearer-token" | (string & {});
export interface RegisteredRemoteAgentDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string>;
    authorizationMethod: RemoteAgentAuthorizationMethod;
    apiKeyHeader?: string;
}
export interface RegisteredRemoteAgentSigV4Details {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string>;
    region: string;
    service: string;
    roleArn?: string;
}
export type AdditionalServiceDetails = {
    github: RegisteredGithubServiceDetails;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack: RegisteredSlackServiceDetails;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog: RegisteredMCPServerDetails;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver: RegisteredMCPServerDetails;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow: RegisteredServiceNowDetails;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab: RegisteredGitLabServiceDetails;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk: RegisteredMCPServerDetails;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic: RegisteredNewRelicDetails;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops: RegisteredAzureDevOpsServiceDetails;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity: RegisteredAzureIdentityDetails;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana: RegisteredGrafanaServerDetails;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty: RegisteredPagerDutyDetails;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4: RegisteredMCPServerSigV4Details;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent: RegisteredRemoteAgentDetails;
    remoteagentsigv4?: never;
} | {
    github?: never;
    slack?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    servicenow?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    azuredevops?: never;
    azureidentity?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4: RegisteredRemoteAgentSigV4Details;
};
export interface RegisteredService {
    serviceId: string;
    serviceType: Service;
    name?: string;
    accessibleResources?: any[];
    additionalServiceDetails?: AdditionalServiceDetails;
    kmsKeyArn?: string;
    privateConnectionName?: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export interface GetServiceOutput {
    service: RegisteredService & {
        createdAt: Date;
        updatedAt: Date;
    };
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetTriggerRequest {
    agentSpaceId: string;
    triggerId: string;
}
export interface GetTriggerResponse {
    trigger: Trigger;
}
export type NextToken = string;
export interface ListAgentSpacesInput {
    maxResults?: number;
    nextToken?: string;
}
export type AgentSpaceList = AgentSpace[];
export interface ListAgentSpacesOutput {
    nextToken?: string;
    agentSpaces: AgentSpace[];
}
export interface ListAssetFilesRequest {
    agentSpaceId: string;
    assetId: string;
    assetVersion?: number;
    nextToken?: string;
    maxResults?: number;
}
export interface AssetFileSummary {
    path: string;
    metadata?: any;
    version: number;
    createdAt: Date;
    updatedAt: Date;
}
export type AssetFileSummaryList = AssetFileSummary[];
export interface ListAssetFilesResponse {
    items: AssetFileSummary[];
    nextToken?: string;
}
export interface ListAssetsRequest {
    agentSpaceId: string;
    assetType?: string;
    updatedAfter?: Date;
    updatedBefore?: Date;
    nextToken?: string;
    maxResults?: number;
}
export type AssetList = Asset[];
export interface ListAssetsResponse {
    items: Asset[];
    nextToken?: string;
}
export interface ListAssetTypesRequest {
    nextToken?: string;
    maxResults?: number;
}
export interface AssetTypeSummary {
    assetType: string;
    description: string;
}
export type AssetTypeList = AssetTypeSummary[];
export interface ListAssetTypesResponse {
    items: AssetTypeSummary[];
    nextToken?: string;
}
export interface ListAssetVersionsRequest {
    agentSpaceId: string;
    assetId: string;
    maxResults?: number;
    nextToken?: string;
}
export interface AssetVersionMetadata {
    version: number;
    createdAt: Date;
    updatedAt: Date;
}
export type AssetVersionMetadataList = AssetVersionMetadata[];
export interface ListAssetVersionsResponse {
    items: AssetVersionMetadata[];
    nextToken?: string;
}
export interface ListAssociationsInput {
    agentSpaceId: string;
    maxResults?: number;
    nextToken?: string;
    filterServiceTypes?: string;
}
export type AssociationsList = Association[];
export interface ListAssociationsOutput {
    nextToken?: string;
    associations: Association[];
}
export type PriorityList = Priority[];
export type TaskStatusList = TaskStatus[];
export type TaskTypeList = TaskType[];
export interface TaskFilter {
    createdAfter?: Date;
    createdBefore?: Date;
    priority?: Priority[];
    status?: TaskStatus[];
    taskType?: TaskType[];
    primaryTaskId?: string;
}
export type TaskSortField = "CREATED_AT" | "PRIORITY" | (string & {});
export type TaskSortOrder = "ASC" | "DESC" | (string & {});
export interface ListBacklogTasksRequest {
    agentSpaceId: string;
    filter?: TaskFilter;
    limit?: number;
    nextToken?: string;
    sortField?: TaskSortField;
    order?: TaskSortOrder;
}
export type TaskList = Task[];
export interface ListBacklogTasksResponse {
    tasks: Task[];
    nextToken?: string;
}
export interface ListChatsRequest {
    agentSpaceId: string;
    userId?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface ChatExecution {
    executionId: string;
    createdAt: Date;
    updatedAt?: Date;
    summary?: string;
}
export type ChatExecutionList = ChatExecution[];
export interface ListChatsResponse {
    executions: ChatExecution[];
    nextToken?: string;
}
export interface ListExecutionsRequest {
    agentSpaceId: string;
    taskId: string;
    limit?: number;
    nextToken?: string;
}
export type JournalTimestamp = Date;
export type ExecutionStatus = "FAILED" | "RUNNING" | "STOPPED" | "CANCELED" | "TIMED_OUT" | "WAITING" | (string & {});
export interface Execution {
    agentSpaceId: string;
    executionId: string;
    parentExecutionId?: string;
    agentSubTask: string;
    createdAt: Date;
    updatedAt: Date;
    executionStatus: ExecutionStatus;
    agentType?: string;
    uid?: string;
}
export type ExecutionList = Execution[];
export interface ListExecutionsResponse {
    executions: Execution[];
    nextToken?: string;
}
export type GoalStatus = "ACTIVE" | "PAUSED" | "COMPLETE" | (string & {});
export type GoalType = "CUSTOMER_DEFINED" | "ONCALL_REPORT" | (string & {});
export interface ListGoalsRequest {
    agentSpaceId: string;
    status?: GoalStatus;
    goalType?: GoalType;
    limit?: number;
    nextToken?: string;
}
export interface GoalContent {
    description: string;
    objectives: string;
}
export type SchedulerState = "ENABLED" | "DISABLED" | (string & {});
export interface GoalSchedule {
    state: SchedulerState;
    expression?: string;
}
export interface Goal {
    agentSpaceArn: string;
    goalId: string;
    title: string;
    content: GoalContent;
    status: GoalStatus;
    goalType: GoalType;
    createdAt: Date;
    updatedAt: Date;
    lastEvaluatedAt?: Date;
    lastTaskId?: string;
    lastSuccessfulTaskId?: string;
    version: number;
    evaluationSchedule?: GoalSchedule;
}
export type GoalList = Goal[];
export interface ListGoalsResponse {
    goals: Goal[];
    nextToken?: string;
}
export type OrderType = "ASC" | "DESC" | (string & {});
export interface ListJournalRecordsRequest {
    agentSpaceId: string;
    executionId: string;
    limit?: number;
    nextToken?: string;
    recordType?: string;
    order?: OrderType;
}
export interface UserReference {
    userId: string;
    userType: UserType;
}
export interface JournalRecord {
    agentSpaceId: string;
    executionId: string;
    recordId: string;
    content: any;
    createdAt: Date;
    recordType: string;
    userReference?: UserReference;
}
export type JournalRecordList = JournalRecord[];
export interface ListJournalRecordsResponse {
    records: JournalRecord[];
    nextToken?: string;
}
export interface ListPendingMessagesRequest {
    agentSpaceId: string;
    executionId: string;
}
export type UserMessageBlock = {
    text: string;
    toolResult?: never;
} | {
    text?: never;
    toolResult: any;
};
export type UserMessage = UserMessageBlock[];
export type AssistantMessageBlock = {
    text: string;
    toolUse?: never;
} | {
    text?: never;
    toolUse: any;
};
export type AssistantMessage = AssistantMessageBlock[];
export type Message = {
    userMessage: UserMessageBlock[];
    assistantMessage?: never;
} | {
    userMessage?: never;
    assistantMessage: AssistantMessageBlock[];
};
export interface PendingMessage {
    messageId: string;
    message: Message;
}
export type PendingMessages = PendingMessage[];
export interface ListPendingMessagesResponse {
    agentSpaceId: string;
    executionId: string;
    messages: PendingMessage[];
    createdAt: Date;
}
export interface ListPrivateConnectionsInput {
}
export interface PrivateConnectionSummary {
    name: string;
    type: PrivateConnectionType;
    resourceGatewayId?: string;
    hostAddress?: string;
    vpcId?: string;
    resourceConfigurationId?: string;
    status: PrivateConnectionStatus;
    certificateExpiryTime?: Date;
    dnsResolution?: ResourceConfigDnsResolution;
    failureMessage?: string;
}
export type PrivateConnectionSummaryList = PrivateConnectionSummary[];
export interface ListPrivateConnectionsOutput {
    privateConnections: PrivateConnectionSummary[];
}
export interface ListRecommendationsRequest {
    agentSpaceId: string;
    taskId?: string;
    goalId?: string;
    status?: RecommendationStatus;
    priority?: RecommendationPriority;
    limit?: number;
    nextToken?: string;
}
export type RecommendationList = Recommendation[];
export interface ListRecommendationsResponse {
    recommendations: Recommendation[];
    nextToken?: string;
}
export interface ListServicesInput {
    maxResults?: number;
    nextToken?: string;
    filterServiceType?: Service;
}
export type RegisteredServicesList = RegisteredService[];
export interface ListServicesOutput {
    nextToken?: string;
    services: (RegisteredService & {
        createdAt: Date;
        updatedAt: Date;
    })[];
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags: {
        [key: string]: string | undefined;
    };
}
export interface ListTriggersRequest {
    agentSpaceId: string;
    status?: string;
    nextToken?: string;
    maxResults?: number;
}
export type TriggerList = Trigger[];
export interface ListTriggersResponse {
    items: Trigger[];
    nextToken?: string;
}
export interface ListWebhooksInput {
    agentSpaceId: string;
    associationId: string;
}
export interface Webhook {
    webhookUrl: string;
    webhookType?: WebhookType;
    webhookId: string;
}
export type WebhooksList = Webhook[];
export interface ListWebhooksOutput {
    webhooks: Webhook[];
}
export type PostRegisterServiceSupportedService = "dynatrace" | "servicenow" | "pagerduty" | "gitlab" | "eventChannel" | "mcpservernewrelic" | "mcpservergrafana" | "mcpserverdatadog" | "mcpserver" | "mcpserversplunk" | "azureidentity" | "mcpserversigv4" | "remoteagent" | "remoteagentsigv4" | (string & {});
export type ClientId = string | redacted.Redacted<string>;
export type ExchangeParameterValue = string | redacted.Redacted<string>;
export type ExchangeParameters = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export type ClientSecret = string | redacted.Redacted<string>;
export interface DynatraceOAuthClientCredentialsConfig {
    clientName?: string;
    clientId: string | redacted.Redacted<string>;
    exchangeParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    clientSecret: string | redacted.Redacted<string>;
}
export type DynatraceServiceAuthorizationConfig = {
    oAuthClientCredentials: DynatraceOAuthClientCredentialsConfig;
};
export interface DynatraceServiceDetails {
    accountUrn: string;
    authorizationConfig?: DynatraceServiceAuthorizationConfig;
}
export interface ServiceNowOAuthClientCredentialsConfig {
    clientName?: string;
    clientId: string | redacted.Redacted<string>;
    exchangeParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    clientSecret: string | redacted.Redacted<string>;
}
export type ServiceNowServiceAuthorizationConfig = {
    oAuthClientCredentials: ServiceNowOAuthClientCredentialsConfig;
};
export interface ServiceNowServiceDetails {
    instanceUrl: string;
    authorizationConfig?: ServiceNowServiceAuthorizationConfig;
}
export interface MCPServerAuthorizationDiscoveryConfig {
    returnToEndpoint: string;
}
export type DatadogAuthorizationConfig = {
    authorizationDiscovery: MCPServerAuthorizationDiscoveryConfig;
};
export interface DatadogServiceDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string>;
    authorizationConfig: DatadogAuthorizationConfig;
}
export type OAuthScope = string;
export type Scopes = string[];
export interface MCPServerOAuthClientCredentialsConfig {
    clientName?: string;
    clientId: string | redacted.Redacted<string>;
    exchangeParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    clientSecret: string | redacted.Redacted<string>;
    exchangeUrl: string;
    scopes?: string[];
}
export interface MCPServerOAuth3LOConfig {
    clientName?: string;
    clientId: string | redacted.Redacted<string>;
    exchangeParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    returnToEndpoint: string;
    authorizationUrl: string;
    exchangeUrl: string;
    clientSecret?: string | redacted.Redacted<string>;
    supportCodeChallenge?: boolean;
    scopes?: string[];
}
export interface MCPServerAPIKeyConfig {
    apiKeyName: string;
    apiKeyValue: string | redacted.Redacted<string>;
    apiKeyHeader: string;
}
export type TokenValue = string | redacted.Redacted<string>;
export interface MCPServerBearerTokenConfig {
    tokenName: string;
    tokenValue: string | redacted.Redacted<string>;
    authorizationHeader?: string;
}
export type MCPServerAuthorizationConfig = {
    oAuthClientCredentials: MCPServerOAuthClientCredentialsConfig;
    oAuth3LO?: never;
    apiKey?: never;
    bearerToken?: never;
    authorizationDiscovery?: never;
} | {
    oAuthClientCredentials?: never;
    oAuth3LO: MCPServerOAuth3LOConfig;
    apiKey?: never;
    bearerToken?: never;
    authorizationDiscovery?: never;
} | {
    oAuthClientCredentials?: never;
    oAuth3LO?: never;
    apiKey: MCPServerAPIKeyConfig;
    bearerToken?: never;
    authorizationDiscovery?: never;
} | {
    oAuthClientCredentials?: never;
    oAuth3LO?: never;
    apiKey?: never;
    bearerToken: MCPServerBearerTokenConfig;
    authorizationDiscovery?: never;
} | {
    oAuthClientCredentials?: never;
    oAuth3LO?: never;
    apiKey?: never;
    bearerToken?: never;
    authorizationDiscovery: MCPServerAuthorizationDiscoveryConfig;
};
export interface MCPServerDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string>;
    authorizationConfig: MCPServerAuthorizationConfig;
}
export type GitLabTokenValue = string | redacted.Redacted<string>;
export interface GitLabDetails {
    targetUrl: string;
    tokenType: GitLabTokenType;
    tokenValue: string | redacted.Redacted<string>;
    groupId?: string;
}
export type NewRelicApiKey = string | redacted.Redacted<string>;
export type NewRelicApplicationIds = string[];
export type NewRelicEntityGuids = string[];
export type NewRelicAlertPolicyIds = string[];
export interface NewRelicApiKeyConfig {
    apiKey: string | redacted.Redacted<string>;
    accountId: string;
    region: NewRelicRegion;
    applicationIds?: string[];
    entityGuids?: string[];
    alertPolicyIds?: string[];
}
export type NewRelicServiceAuthorizationConfig = {
    apiKey: NewRelicApiKeyConfig;
};
export interface NewRelicServiceDetails {
    authorizationConfig: NewRelicServiceAuthorizationConfig;
}
export type EventChannelType = "webhook" | (string & {});
export interface EventChannelDetails {
    type?: EventChannelType;
}
export interface GrafanaServiceDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string>;
    authorizationConfig: MCPServerAuthorizationConfig;
}
export type PagerDutyScopes = string[];
export interface PagerDutyOAuthClientCredentialsConfig {
    clientName?: string;
    clientId: string | redacted.Redacted<string>;
    exchangeParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    clientSecret: string | redacted.Redacted<string>;
}
export type PagerDutyAuthorizationConfig = {
    oAuthClientCredentials: PagerDutyOAuthClientCredentialsConfig;
};
export interface PagerDutyDetails {
    scopes: string[];
    authorizationConfig: PagerDutyAuthorizationConfig;
}
export interface MCPServerSigV4AuthorizationConfig {
    region: string;
    service: string;
    roleArn?: string;
    mcpRoleArn?: string;
    customHeaders?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export interface MCPServerSigV4ServiceDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string>;
    authorizationConfig: MCPServerSigV4AuthorizationConfig;
}
export interface RemoteAgentAPIKeyConfig {
    apiKeyName: string;
    apiKeyValue: string | redacted.Redacted<string>;
    apiKeyHeader: string;
}
export interface RemoteAgentOAuthClientCredentialsConfig {
    clientName?: string;
    clientId: string | redacted.Redacted<string>;
    exchangeParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    clientSecret: string | redacted.Redacted<string>;
    exchangeUrl: string;
    scopes?: string[];
}
export interface RemoteAgentBearerTokenConfig {
    tokenName: string;
    tokenValue: string | redacted.Redacted<string>;
    authorizationHeader?: string;
}
export type RemoteAgentAuthorizationConfig = {
    apiKey: RemoteAgentAPIKeyConfig;
    oAuthClientCredentials?: never;
    bearerToken?: never;
} | {
    apiKey?: never;
    oAuthClientCredentials: RemoteAgentOAuthClientCredentialsConfig;
    bearerToken?: never;
} | {
    apiKey?: never;
    oAuthClientCredentials?: never;
    bearerToken: RemoteAgentBearerTokenConfig;
};
export interface RemoteAgentServiceDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string>;
    authorizationConfig: RemoteAgentAuthorizationConfig;
}
export interface RemoteAgentSigV4AuthorizationConfig {
    region: string;
    service: string;
    roleArn?: string;
}
export interface RemoteAgentSigV4ServiceDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string>;
    authorizationConfig: RemoteAgentSigV4AuthorizationConfig;
}
export type ServiceDetails = {
    dynatrace: DynatraceServiceDetails;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow: ServiceNowServiceDetails;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog: DatadogServiceDetails;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver: MCPServerDetails;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab: GitLabDetails;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk: MCPServerDetails;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic: NewRelicServiceDetails;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel: EventChannelDetails;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana: GrafanaServiceDetails;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty: PagerDutyDetails;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity: RegisteredAzureIdentityDetails;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4: MCPServerSigV4ServiceDetails;
    remoteagent?: never;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent: RemoteAgentServiceDetails;
    remoteagentsigv4?: never;
} | {
    dynatrace?: never;
    servicenow?: never;
    mcpserverdatadog?: never;
    mcpserver?: never;
    gitlab?: never;
    mcpserversplunk?: never;
    mcpservernewrelic?: never;
    eventChannel?: never;
    mcpservergrafana?: never;
    pagerduty?: never;
    azureidentity?: never;
    mcpserversigv4?: never;
    remoteagent?: never;
    remoteagentsigv4: RemoteAgentSigV4ServiceDetails;
};
export interface RegisterServiceInput {
    service: PostRegisterServiceSupportedService;
    serviceDetails: ServiceDetails;
    kmsKeyArn?: string;
    privateConnectionName?: string;
    targetUrlPrivateConnectionName?: string;
    exchangeUrlPrivateConnectionName?: string;
    name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface OAuthAdditionalStepDetails {
    authorizationUrl: string;
}
export type AdditionalServiceRegistrationStep = {
    oauth: OAuthAdditionalStepDetails;
};
export interface RegisterServiceOutput {
    serviceId?: string;
    additionalStep?: AdditionalServiceRegistrationStep;
    kmsKeyArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type ChatExecutionId = string;
export type MessageContent = string;
export type ToolUseId = string;
export type InterruptId = string;
export type ApprovalId = string;
export type ButtonText = string;
export type ApprovalActionType = "APPROVED" | "REJECTED" | (string & {});
export interface ApprovalAction {
    toolUseId?: string;
    interruptId?: string;
    approvalId?: string;
    buttonText?: string;
    action?: ApprovalActionType;
}
export interface SendMessageContext {
    currentPage?: string;
    lastMessage?: string;
    userActionResponse?: string;
    approvalAction?: ApprovalAction;
}
export type AssetIdList = string[];
export interface SendMessageRequest {
    agentSpaceId: string;
    executionId: string;
    content: string;
    context?: SendMessageContext;
    userId?: string;
    assetIds?: string[];
    modelTier?: string;
}
export interface SendMessageResponseCreatedEvent {
    responseId?: string;
    sequenceNumber?: number;
}
export interface SendMessageResponseInProgressEvent {
    responseId?: string;
    sequenceNumber?: number;
}
export interface SendMessageUsageInfo {
    inputTokens?: number;
    outputTokens?: number;
    totalTokens?: number;
}
export interface SendMessageResponseCompletedEvent {
    responseId?: string;
    usage?: SendMessageUsageInfo;
    sequenceNumber?: number;
}
export interface SendMessageResponseFailedEvent {
    responseId?: string;
    errorCode?: string;
    errorMessage?: string;
    sequenceNumber?: number;
}
export interface SendMessageSummaryEvent {
    content?: string;
    sequenceNumber?: number;
}
export interface SendMessageHeartbeatEvent {
}
export interface SendMessageContentBlockStartEvent {
    index?: number;
    type?: string;
    id?: string;
    parentId?: string;
    sequenceNumber?: number;
}
export interface SendMessageTextDelta {
    text?: string;
}
export interface SendMessageJsonDelta {
    partialJson?: string;
}
export type SendMessageContentBlockDelta = {
    textDelta: SendMessageTextDelta;
    jsonDelta?: never;
} | {
    textDelta?: never;
    jsonDelta: SendMessageJsonDelta;
};
export interface SendMessageContentBlockDeltaEvent {
    index?: number;
    delta?: SendMessageContentBlockDelta;
    sequenceNumber?: number;
}
export interface SendMessageContentBlockStopEvent {
    index?: number;
    type?: string;
    text?: string;
    last?: boolean;
    sequenceNumber?: number;
}
export type SendMessageEvents = {
    responseCreated: SendMessageResponseCreatedEvent;
    responseInProgress?: never;
    responseCompleted?: never;
    responseFailed?: never;
    summary?: never;
    heartbeat?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
} | {
    responseCreated?: never;
    responseInProgress: SendMessageResponseInProgressEvent;
    responseCompleted?: never;
    responseFailed?: never;
    summary?: never;
    heartbeat?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
} | {
    responseCreated?: never;
    responseInProgress?: never;
    responseCompleted: SendMessageResponseCompletedEvent;
    responseFailed?: never;
    summary?: never;
    heartbeat?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
} | {
    responseCreated?: never;
    responseInProgress?: never;
    responseCompleted?: never;
    responseFailed: SendMessageResponseFailedEvent;
    summary?: never;
    heartbeat?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
} | {
    responseCreated?: never;
    responseInProgress?: never;
    responseCompleted?: never;
    responseFailed?: never;
    summary: SendMessageSummaryEvent;
    heartbeat?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
} | {
    responseCreated?: never;
    responseInProgress?: never;
    responseCompleted?: never;
    responseFailed?: never;
    summary?: never;
    heartbeat: SendMessageHeartbeatEvent;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
} | {
    responseCreated?: never;
    responseInProgress?: never;
    responseCompleted?: never;
    responseFailed?: never;
    summary?: never;
    heartbeat?: never;
    contentBlockStart: SendMessageContentBlockStartEvent;
    contentBlockDelta?: never;
    contentBlockStop?: never;
} | {
    responseCreated?: never;
    responseInProgress?: never;
    responseCompleted?: never;
    responseFailed?: never;
    summary?: never;
    heartbeat?: never;
    contentBlockStart?: never;
    contentBlockDelta: SendMessageContentBlockDeltaEvent;
    contentBlockStop?: never;
} | {
    responseCreated?: never;
    responseInProgress?: never;
    responseCompleted?: never;
    responseFailed?: never;
    summary?: never;
    heartbeat?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop: SendMessageContentBlockStopEvent;
};
export interface SendMessageResponse {
    events: stream.Stream<SendMessageEvents, Error, never>;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAgentSpaceInput {
    agentSpaceId: string;
    name?: string;
    description?: string | redacted.Redacted<string>;
    locale?: string;
    preferences?: {
        [key: string]: boolean | undefined;
    };
}
export interface UpdateAgentSpaceOutput {
    agentSpace: AgentSpace;
}
export type ToolIdentifier = string;
export type ApprovalPinKey = string;
export type ApprovalPinValue = string;
export type ApprovalArgumentPins = {
    [key: string]: string | undefined;
};
export interface ApprovalPattern {
    tool: string;
    argumentPins: {
        [key: string]: string | undefined;
    };
}
export type ApprovalReason = string;
export interface UpdateApprovalActionRequest {
    agentSpaceId: string;
    approvalId: string;
    action: ApprovalActionType;
    finalPattern?: ApprovalPattern;
    reason?: string;
    ttlSeconds?: number;
    singleUse?: boolean;
}
export type ApprovalStatus = "PENDING" | "APPROVED" | "REJECTED" | "REVOKED" | "REDEEMED" | (string & {});
export interface UpdateApprovalActionResponse {
    approvalId: string;
    status: ApprovalStatus;
    expiresAt?: Date;
}
export interface UpdateAssetRequest {
    agentSpaceId: string;
    assetId: string;
    metadata?: any;
    content?: AssetContent;
    clientToken?: string;
}
export interface UpdateAssetResponse {
    asset: Asset;
}
export interface UpdateAssetFileRequest {
    agentSpaceId: string;
    assetId: string;
    path: string;
    content?: AssetFileBody;
    metadata?: any;
    clientToken?: string;
}
export interface UpdateAssetFileResponse {
    file: AssetFile;
}
export interface UpdateAssociationInput {
    agentSpaceId: string;
    associationId: string;
    configuration: ServiceConfiguration;
    capabilities?: {
        [key: string]: CapabilityConfiguration | undefined;
    };
}
export interface UpdateAssociationOutput {
    association: Association;
    webhook?: GenericWebhook;
}
export interface UpdateBacklogTaskRequest {
    agentSpaceId: string;
    taskId: string;
    taskStatus?: TaskStatus;
    clientToken?: string;
}
export interface UpdateBacklogTaskResponse {
    task: Task;
}
export interface GoalScheduleInput {
    state: SchedulerState;
}
export interface UpdateGoalRequest {
    agentSpaceId: string;
    goalId: string;
    evaluationSchedule?: GoalScheduleInput;
    clientToken?: string;
}
export interface UpdateGoalResponse {
    goal: Goal;
}
export interface UpdateOperatorAppIdpConfigInput {
    agentSpaceId: string;
    idpClientSecret?: string | redacted.Redacted<string>;
}
export interface UpdateOperatorAppIdpConfigOutput {
    agentSpaceId: string;
    idp: IdpAuthConfiguration;
}
export interface UpdatePrivateConnectionCertificateInput {
    name: string;
    certificate: string;
}
export interface UpdatePrivateConnectionCertificateOutput {
    name: string;
    type: PrivateConnectionType;
    resourceGatewayId?: string;
    hostAddress?: string;
    vpcId?: string;
    resourceConfigurationId?: string;
    status: PrivateConnectionStatus;
    certificateExpiryTime?: Date;
    dnsResolution?: ResourceConfigDnsResolution;
    failureMessage?: string;
}
export interface UpdateRecommendationRequest {
    agentSpaceId: string;
    recommendationId: string;
    status?: RecommendationStatus;
    additionalContext?: string;
    clientToken?: string;
}
export interface UpdateRecommendationResponse {
    recommendation: Recommendation;
}
export interface UpdateTriggerRequest {
    agentSpaceId: string;
    triggerId: string;
    status?: string;
    clientToken?: string;
}
export interface UpdateTriggerResponse {
    trigger: Trigger;
}
export interface ValidateAwsAssociationsInput {
    agentSpaceId: string;
}
export interface ValidateAwsAssociationsOutput {
}
export interface ValidationExceptionField {
    path: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AssociateServiceError = ConflictException | InternalServerException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a specific service association to an AgentSpace. It overwrites the existing association of the same service. Returns 201 Created on success.
 */
export declare const associateService: API.OperationMethod<AssociateServiceInput, AssociateServiceOutput, AssociateServiceError, Credentials | HttpClient.HttpClient>;
export type CreateAgentSpaceError = ConflictException | InternalServerException | InvalidParameterException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new AgentSpace with the specified name and description. Duplicate space names are allowed.
 */
export declare const createAgentSpace: API.OperationMethod<CreateAgentSpaceInput, CreateAgentSpaceOutput, CreateAgentSpaceError, Credentials | HttpClient.HttpClient>;
export type CreateAssetError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new asset in the specified agent space
 */
export declare const createAsset: API.OperationMethod<CreateAssetRequest, CreateAssetResponse, CreateAssetError, Credentials | HttpClient.HttpClient>;
export type CreateAssetFileError = AccessDeniedException | ConflictException | ContentSizeExceededException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a file in an asset
 */
export declare const createAssetFile: API.OperationMethod<CreateAssetFileRequest, CreateAssetFileResponse, CreateAssetFileError, Credentials | HttpClient.HttpClient>;
export type CreateBacklogTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new backlog task in the specified agent space
 */
export declare const createBacklogTask: API.OperationMethod<CreateBacklogTaskRequest, CreateBacklogTaskResponse, CreateBacklogTaskError, Credentials | HttpClient.HttpClient>;
export type CreateChatError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new chat execution in the specified agent space
 */
export declare const createChat: API.OperationMethod<CreateChatRequest, CreateChatResponse, CreateChatError, Credentials | HttpClient.HttpClient>;
export type CreatePrivateConnectionError = AccessDeniedException | InternalServerException | InvalidParameterException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a Private Connection to a target resource.
 */
export declare const createPrivateConnection: API.OperationMethod<CreatePrivateConnectionInput, CreatePrivateConnectionOutput, CreatePrivateConnectionError, Credentials | HttpClient.HttpClient>;
export type CreateTriggerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Trigger in the specified agent space
 */
export declare const createTrigger: API.OperationMethod<CreateTriggerRequest, CreateTriggerResponse, CreateTriggerError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentSpaceError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an AgentSpace. This operation is idempotent and returns a 204 No Content response on success.
 */
export declare const deleteAgentSpace: API.OperationMethod<DeleteAgentSpaceInput, DeleteAgentSpaceOutput, DeleteAgentSpaceError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an asset and all its files from the specified agent space
 */
export declare const deleteAsset: API.OperationMethod<DeleteAssetRequest, DeleteAssetResponse, DeleteAssetError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetFileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a file from an asset
 */
export declare const deleteAssetFile: API.OperationMethod<DeleteAssetFileRequest, DeleteAssetFileResponse, DeleteAssetFileError, Credentials | HttpClient.HttpClient>;
export type DeletePrivateConnectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Private Connection. The deletion is asynchronous and returns DELETE_IN_PROGRESS status.
 */
export declare const deletePrivateConnection: API.OperationMethod<DeletePrivateConnectionInput, DeletePrivateConnectionOutput, DeletePrivateConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteTriggerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Trigger from the specified agent space
 */
export declare const deleteTrigger: API.OperationMethod<DeleteTriggerRequest, DeleteTriggerResponse, DeleteTriggerError, Credentials | HttpClient.HttpClient>;
export type DeregisterServiceError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deregister a service
 */
export declare const deregisterService: API.OperationMethod<DeregisterServiceInput, DeregisterServiceOutput, DeregisterServiceError, Credentials | HttpClient.HttpClient>;
export type DescribePrivateConnectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details of an existing Private Connection.
 */
export declare const describePrivateConnection: API.OperationMethod<DescribePrivateConnectionInput, DescribePrivateConnectionOutput, DescribePrivateConnectionError, Credentials | HttpClient.HttpClient>;
export type DisableOperatorAppError = IdentityCenterServiceException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disable the Operator App for the specified AgentSpace
 */
export declare const disableOperatorApp: API.OperationMethod<DisableOperatorAppInput, DisableOperatorAppResponse, DisableOperatorAppError, Credentials | HttpClient.HttpClient>;
export type DisassociateServiceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specific service association from an AgentSpace. This operation is idempotent and returns a 204 No Content response on success.
 */
export declare const disassociateService: API.OperationMethod<DisassociateServiceInput, DisassociateServiceOutput, DisassociateServiceError, Credentials | HttpClient.HttpClient>;
export type EnableOperatorAppError = IdentityCenterServiceException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enable the Operator App to access the given AgentSpace
 */
export declare const enableOperatorApp: API.OperationMethod<EnableOperatorAppInput, EnableOperatorAppOutput, EnableOperatorAppError, Credentials | HttpClient.HttpClient>;
export type GetAccountUsageError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves monthly account usage metrics and limits for the AWS account.
 */
export declare const getAccountUsage: API.OperationMethod<GetAccountUsageInput, GetAccountUsageOutput, GetAccountUsageError, Credentials | HttpClient.HttpClient>;
export type GetAgentSpaceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific AgentSpace.
 */
export declare const getAgentSpace: API.OperationMethod<GetAgentSpaceInput, GetAgentSpaceOutput, GetAgentSpaceError, Credentials | HttpClient.HttpClient>;
export type GetAssetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an asset from the specified agent space
 */
export declare const getAsset: API.OperationMethod<GetAssetRequest, GetAssetResponse, GetAssetError, Credentials | HttpClient.HttpClient>;
export type GetAssetContentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an asset's content as a zip bundle
 */
export declare const getAssetContent: API.OperationMethod<GetAssetContentRequest, GetAssetContentResponse, GetAssetContentError, Credentials | HttpClient.HttpClient>;
export type GetAssetFileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a file from an asset
 */
export declare const getAssetFile: API.OperationMethod<GetAssetFileRequest, GetAssetFileResponse, GetAssetFileError, Credentials | HttpClient.HttpClient>;
export type GetAssociationError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves given associations configured for a specific AgentSpace.
 */
export declare const getAssociation: API.OperationMethod<GetAssociationInput, GetAssociationOutput, GetAssociationError, Credentials | HttpClient.HttpClient>;
export type GetBacklogTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a backlog task for the specified agent space and task id
 */
export declare const getBacklogTask: API.OperationMethod<GetBacklogTaskRequest, GetBacklogTaskResponse, GetBacklogTaskError, Credentials | HttpClient.HttpClient>;
export type GetOperatorAppError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the full auth configuration of operator including any enabled auth flow
 */
export declare const getOperatorApp: API.OperationMethod<GetOperatorAppInput, GetOperatorAppOutput, GetOperatorAppError, Credentials | HttpClient.HttpClient>;
export type GetRecommendationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a specific recommendation by its ID
 */
export declare const getRecommendation: API.OperationMethod<GetRecommendationRequest, GetRecommendationResponse, GetRecommendationError, Credentials | HttpClient.HttpClient>;
export type GetServiceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves given service by it's unique identifier
 */
export declare const getService: API.OperationMethod<GetServiceInput, GetServiceOutput, GetServiceError, Credentials | HttpClient.HttpClient>;
export type GetTriggerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a Trigger from the specified agent space
 */
export declare const getTrigger: API.OperationMethod<GetTriggerRequest, GetTriggerResponse, GetTriggerError, Credentials | HttpClient.HttpClient>;
export type ListAgentSpacesError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all AgentSpaces with optional pagination.
 */
export declare const listAgentSpaces: API.PaginatedOperationMethod<ListAgentSpacesInput, ListAgentSpacesOutput, ListAgentSpacesError, Credentials | HttpClient.HttpClient, AgentSpace>;
export type ListAssetFilesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists files in an asset
 */
export declare const listAssetFiles: API.PaginatedOperationMethod<ListAssetFilesRequest, ListAssetFilesResponse, ListAssetFilesError, Credentials | HttpClient.HttpClient, AssetFileSummary>;
export type ListAssetsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists assets in the specified agent space
 */
export declare const listAssets: API.PaginatedOperationMethod<ListAssetsRequest, ListAssetsResponse, ListAssetsError, Credentials | HttpClient.HttpClient, Asset>;
export type ListAssetTypesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the supported asset types
 */
export declare const listAssetTypes: API.PaginatedOperationMethod<ListAssetTypesRequest, ListAssetTypesResponse, ListAssetTypesError, Credentials | HttpClient.HttpClient, AssetTypeSummary>;
export type ListAssetVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists versions of an asset in the specified agent space
 */
export declare const listAssetVersions: API.PaginatedOperationMethod<ListAssetVersionsRequest, ListAssetVersionsResponse, ListAssetVersionsError, Credentials | HttpClient.HttpClient, AssetVersionMetadata>;
export type ListAssociationsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all associations for given AgentSpace
 */
export declare const listAssociations: API.PaginatedOperationMethod<ListAssociationsInput, ListAssociationsOutput, ListAssociationsError, Credentials | HttpClient.HttpClient, Association>;
export type ListBacklogTasksError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists backlog tasks in the specified agent space with optional filtering and sorting
 */
export declare const listBacklogTasks: API.PaginatedOperationMethod<ListBacklogTasksRequest, ListBacklogTasksResponse, ListBacklogTasksError, Credentials | HttpClient.HttpClient, Task>;
export type ListChatsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of the user's recent chat executions
 */
export declare const listChats: API.OperationMethod<ListChatsRequest, ListChatsResponse, ListChatsError, Credentials | HttpClient.HttpClient>;
export type ListExecutionsError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List executions
 */
export declare const listExecutions: API.PaginatedOperationMethod<ListExecutionsRequest, ListExecutionsResponse, ListExecutionsError, Credentials | HttpClient.HttpClient, Execution>;
export type ListGoalsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists goals in the specified agent space with optional filtering
 */
export declare const listGoals: API.PaginatedOperationMethod<ListGoalsRequest, ListGoalsResponse, ListGoalsError, Credentials | HttpClient.HttpClient, Goal>;
export type ListJournalRecordsError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List journal records for a specific execution
 */
export declare const listJournalRecords: API.PaginatedOperationMethod<ListJournalRecordsRequest, ListJournalRecordsResponse, ListJournalRecordsError, Credentials | HttpClient.HttpClient, JournalRecord>;
export type ListPendingMessagesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List pending messages for a specific execution.
 */
export declare const listPendingMessages: API.OperationMethod<ListPendingMessagesRequest, ListPendingMessagesResponse, ListPendingMessagesError, Credentials | HttpClient.HttpClient>;
export type ListPrivateConnectionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all Private Connections in the caller's account.
 */
export declare const listPrivateConnections: API.OperationMethod<ListPrivateConnectionsInput, ListPrivateConnectionsOutput, ListPrivateConnectionsError, Credentials | HttpClient.HttpClient>;
export type ListRecommendationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists recommendations for the specified agent space
 */
export declare const listRecommendations: API.OperationMethod<ListRecommendationsRequest, ListRecommendationsResponse, ListRecommendationsError, Credentials | HttpClient.HttpClient>;
export type ListServicesError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List a list of registered service on the account level.
 */
export declare const listServices: API.PaginatedOperationMethod<ListServicesInput, ListServicesOutput, ListServicesError, Credentials | HttpClient.HttpClient, RegisteredService>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists tags for the specified AWS DevOps Agent resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTriggersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists Triggers in the specified agent space
 */
export declare const listTriggers: API.PaginatedOperationMethod<ListTriggersRequest, ListTriggersResponse, ListTriggersError, Credentials | HttpClient.HttpClient, Trigger>;
export type ListWebhooksError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all webhooks for given Association
 */
export declare const listWebhooks: API.OperationMethod<ListWebhooksInput, ListWebhooksOutput, ListWebhooksError, Credentials | HttpClient.HttpClient>;
export type RegisterServiceError = InternalServerException | InvalidParameterException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * This operation registers the specified service
 */
export declare const registerService: API.OperationMethod<RegisterServiceInput, RegisterServiceOutput, RegisterServiceError, Credentials | HttpClient.HttpClient>;
export type SendMessageError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends a chat message and streams the response for the specified agent space execution
 */
export declare const sendMessage: API.OperationMethod<SendMessageRequest, SendMessageResponse, SendMessageError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds or overwrites tags for the specified AWS DevOps Agent resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes tags from the specified AWS DevOps Agent resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentSpaceError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the information of an existing AgentSpace.
 */
export declare const updateAgentSpace: API.OperationMethod<UpdateAgentSpaceInput, UpdateAgentSpaceOutput, UpdateAgentSpaceError, Credentials | HttpClient.HttpClient>;
export type UpdateApprovalActionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an approval request with the terminal decision (APPROVED or REJECTED). A single operation handles both verbs via the action enum.
 */
export declare const updateApprovalAction: API.OperationMethod<UpdateApprovalActionRequest, UpdateApprovalActionResponse, UpdateApprovalActionError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an asset in the specified agent space
 */
export declare const updateAsset: API.OperationMethod<UpdateAssetRequest, UpdateAssetResponse, UpdateAssetError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetFileError = AccessDeniedException | ConflictException | ContentSizeExceededException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a file in an asset
 */
export declare const updateAssetFile: API.OperationMethod<UpdateAssetFileRequest, UpdateAssetFileResponse, UpdateAssetFileError, Credentials | HttpClient.HttpClient>;
export type UpdateAssociationError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Partially updates the configuration of an existing service association for an AgentSpace. Present fields are fully replaced; absent fields are left unchanged. Returns 200 OK on success.
 */
export declare const updateAssociation: API.OperationMethod<UpdateAssociationInput, UpdateAssociationOutput, UpdateAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateBacklogTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update an existing backlog task.
 */
export declare const updateBacklogTask: API.OperationMethod<UpdateBacklogTaskRequest, UpdateBacklogTaskResponse, UpdateBacklogTaskError, Credentials | HttpClient.HttpClient>;
export type UpdateGoalError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update an existing goal
 */
export declare const updateGoal: API.OperationMethod<UpdateGoalRequest, UpdateGoalResponse, UpdateGoalError, Credentials | HttpClient.HttpClient>;
export type UpdateOperatorAppIdpConfigError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the external Identity Provider configuration for the Operator App
 */
export declare const updateOperatorAppIdpConfig: API.OperationMethod<UpdateOperatorAppIdpConfigInput, UpdateOperatorAppIdpConfigOutput, UpdateOperatorAppIdpConfigError, Credentials | HttpClient.HttpClient>;
export type UpdatePrivateConnectionCertificateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the certificate associated with a Private Connection.
 */
export declare const updatePrivateConnectionCertificate: API.OperationMethod<UpdatePrivateConnectionCertificateInput, UpdatePrivateConnectionCertificateOutput, UpdatePrivateConnectionCertificateError, Credentials | HttpClient.HttpClient>;
export type UpdateRecommendationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing recommendation with new content, status, or metadata
 */
export declare const updateRecommendation: API.OperationMethod<UpdateRecommendationRequest, UpdateRecommendationResponse, UpdateRecommendationError, Credentials | HttpClient.HttpClient>;
export type UpdateTriggerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the status of an existing Trigger
 */
export declare const updateTrigger: API.OperationMethod<UpdateTriggerRequest, UpdateTriggerResponse, UpdateTriggerError, Credentials | HttpClient.HttpClient>;
export type ValidateAwsAssociationsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Validates an aws association and set status and returns a 204 No Content response on success.
 */
export declare const validateAwsAssociations: API.OperationMethod<ValidateAwsAssociationsInput, ValidateAwsAssociationsOutput, ValidateAwsAssociationsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=devops-agent.d.ts.map