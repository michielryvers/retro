import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly ConflictExceptionType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceTypeNotFound: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly ValidationExceptionType: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ResourceName = string;
export type EntityTag = string;
export interface CancelHarvestJobRequest {
    ChannelGroupName: string;
    ChannelName: string;
    OriginEndpointName: string;
    HarvestJobName: string;
    ETag?: string;
}
export interface CancelHarvestJobResponse {
}
export type IdempotencyToken = string;
export type InputType = "HLS" | "CMAF" | "MULTIVIEW" | (string & {});
export type ResourceDescription = string;
export interface InputSwitchConfiguration {
    MQCSInputSwitching?: boolean;
    PreferredInput?: number;
}
export interface OutputHeaderConfiguration {
    PublishMQCS?: boolean;
}
export type MultiviewSourceList = string[];
export type MultiviewLayoutType = "LAYOUT_2EH" | "LAYOUT_2PL" | "LAYOUT_3EL" | "LAYOUT_3PL" | "LAYOUT_4E" | "LAYOUT_4PL" | (string & {});
export type MultiviewLayoutList = MultiviewLayoutType[];
export interface MultiviewConfiguration {
    AvailableSources: string[];
    AvailableLayouts: MultiviewLayoutType[];
}
export type OutputLockingMode = "EPOCH_LOCKED" | "NON_EPOCH_LOCKED" | (string & {});
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateChannelRequest {
    ChannelGroupName: string;
    ChannelName: string;
    ClientToken?: string;
    InputType?: InputType;
    Description?: string;
    InputSwitchConfiguration?: InputSwitchConfiguration;
    OutputHeaderConfiguration?: OutputHeaderConfiguration;
    MultiviewConfiguration?: MultiviewConfiguration;
    OutputLockingMode?: OutputLockingMode;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type AttachedMultiviewChannelList = string[];
export interface IngestEndpoint {
    Id?: string;
    Url?: string;
}
export type IngestEndpointList = IngestEndpoint[];
export interface CreateChannelResponse {
    MultiviewConfiguration?: MultiviewConfiguration;
    AttachedMultiviewChannels?: string[];
    Arn: string;
    ChannelName: string;
    ChannelGroupName: string;
    CreatedAt: Date;
    ModifiedAt: Date;
    Description?: string;
    IngestEndpoints?: IngestEndpoint[];
    InputType?: InputType;
    ETag?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    InputSwitchConfiguration?: InputSwitchConfiguration;
    OutputHeaderConfiguration?: OutputHeaderConfiguration;
    OutputLockingMode?: OutputLockingMode;
}
export interface CreateChannelGroupRequest {
    ChannelGroupName: string;
    ClientToken?: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateChannelGroupResponse {
    ChannelGroupName: string;
    Arn: string;
    EgressDomain: string;
    CreatedAt: Date;
    ModifiedAt: Date;
    ETag?: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface HarvestedHlsManifest {
    ManifestName: string;
}
export type HarvestedHlsManifestsList = HarvestedHlsManifest[];
export interface HarvestedDashManifest {
    ManifestName: string;
}
export type HarvestedDashManifestsList = HarvestedDashManifest[];
export interface HarvestedLowLatencyHlsManifest {
    ManifestName: string;
}
export type HarvestedLowLatencyHlsManifestsList = HarvestedLowLatencyHlsManifest[];
export interface HarvestedManifests {
    HlsManifests?: HarvestedHlsManifest[];
    DashManifests?: HarvestedDashManifest[];
    LowLatencyHlsManifests?: HarvestedLowLatencyHlsManifest[];
}
export interface HarvesterScheduleConfiguration {
    StartTime: Date;
    EndTime: Date;
}
export type S3BucketName = string;
export type S3DestinationPath = string;
export interface S3DestinationConfig {
    BucketName: string;
    DestinationPath: string;
}
export interface Destination {
    S3Destination: S3DestinationConfig;
}
export interface CreateHarvestJobRequest {
    ChannelGroupName: string;
    ChannelName: string;
    OriginEndpointName: string;
    Description?: string;
    HarvestedManifests: HarvestedManifests;
    ScheduleConfiguration: HarvesterScheduleConfiguration;
    Destination: Destination;
    ClientToken?: string;
    HarvestJobName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type HarvestJobStatus = "QUEUED" | "IN_PROGRESS" | "CANCELLED" | "COMPLETED" | "FAILED" | (string & {});
export interface CreateHarvestJobResponse {
    ChannelGroupName: string;
    ChannelName: string;
    OriginEndpointName: string;
    Destination: Destination;
    HarvestJobName: string;
    HarvestedManifests: HarvestedManifests;
    Description?: string;
    ScheduleConfiguration: HarvesterScheduleConfiguration;
    Arn: string;
    CreatedAt: Date;
    ModifiedAt: Date;
    Status: HarvestJobStatus;
    ErrorMessage?: string;
    ETag?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type ContainerType = "TS" | "CMAF" | "ISM" | (string & {});
export type ScteFilter = "SPLICE_INSERT" | "BREAK" | "PROVIDER_ADVERTISEMENT" | "DISTRIBUTOR_ADVERTISEMENT" | "PROVIDER_PLACEMENT_OPPORTUNITY" | "DISTRIBUTOR_PLACEMENT_OPPORTUNITY" | "PROVIDER_OVERLAY_PLACEMENT_OPPORTUNITY" | "DISTRIBUTOR_OVERLAY_PLACEMENT_OPPORTUNITY" | "PROGRAM" | "CHAPTER" | "UNSCHEDULED_EVENT" | "ALTERNATE_CONTENT_OPPORTUNITY" | "NETWORK" | "PROVIDER_PROMO" | "DISTRIBUTOR_PROMO" | "PROVIDER_AD_BLOCK" | "DISTRIBUTOR_AD_BLOCK" | "CONTENT_IDENTIFICATION" | "CALL_AD_SERVER" | (string & {});
export type ScteFilterList = ScteFilter[];
export type ScteInSegments = "NONE" | "ALL" | "MATCHES_FILTER" | (string & {});
export type CustomAdType = "PROGRAM" | "CHAPTER" | "UNSCHEDULED_EVENT" | "ALTERNATE_CONTENT_OPPORTUNITY" | "NETWORK" | (string & {});
export type CustomAdTypeList = CustomAdType[];
export interface Scte {
    ScteFilter?: ScteFilter[];
    ScteInSegments?: ScteInSegments;
    CustomAdTypes?: CustomAdType[];
}
export type TsEncryptionMethod = "AES_128" | "SAMPLE_AES" | (string & {});
export type CmafEncryptionMethod = "CENC" | "CBCS" | (string & {});
export type IsmEncryptionMethod = "CENC" | (string & {});
export interface EncryptionMethod {
    TsEncryptionMethod?: TsEncryptionMethod;
    CmafEncryptionMethod?: CmafEncryptionMethod;
    IsmEncryptionMethod?: IsmEncryptionMethod;
}
export type PresetSpeke20Audio = "PRESET_AUDIO_1" | "PRESET_AUDIO_2" | "PRESET_AUDIO_3" | "SHARED" | "UNENCRYPTED" | (string & {});
export type PresetSpeke20Video = "PRESET_VIDEO_1" | "PRESET_VIDEO_2" | "PRESET_VIDEO_3" | "PRESET_VIDEO_4" | "PRESET_VIDEO_5" | "PRESET_VIDEO_6" | "PRESET_VIDEO_7" | "PRESET_VIDEO_8" | "SHARED" | "UNENCRYPTED" | (string & {});
export interface EncryptionContractConfiguration {
    PresetSpeke20Audio: PresetSpeke20Audio;
    PresetSpeke20Video: PresetSpeke20Video;
}
export type DrmSystem = "CLEAR_KEY_AES_128" | "FAIRPLAY" | "PLAYREADY" | "WIDEVINE" | "IRDETO" | (string & {});
export type DrmSystems = DrmSystem[];
export type SpekeVersion = "V2_0" | "V2_1" | (string & {});
export type ContentKeyPeriodTiming = "INDEX_ONLY" | "START_END_ONLY" | "INDEX_WITH_START_END" | (string & {});
export interface ContentKeyPeriodConfiguration {
    ContentKeyPeriodTiming?: ContentKeyPeriodTiming;
}
export interface SpekeKeyProvider {
    EncryptionContractConfiguration: EncryptionContractConfiguration;
    ResourceId: string;
    DrmSystems: DrmSystem[];
    RoleArn: string;
    Url: string;
    CertificateArn?: string;
    SpekeVersion?: SpekeVersion;
    ContentKeyPeriodConfiguration?: ContentKeyPeriodConfiguration;
}
export interface Encryption {
    ConstantInitializationVector?: string;
    EncryptionMethod: EncryptionMethod;
    KeyRotationIntervalSeconds?: number;
    CmafExcludeSegmentDrmMetadata?: boolean;
    SpekeKeyProvider: SpekeKeyProvider;
}
export type OutputTimestampMode = "PASSTHROUGH" | "REBASED_TO_CHANNEL_START" | (string & {});
export interface Segment {
    SegmentDurationSeconds?: number;
    SegmentName?: string;
    TsUseAudioRenditionGroup?: boolean;
    IncludeIframeOnlyStreams?: boolean;
    TsIncludeDvbSubtitles?: boolean;
    Scte?: Scte;
    Encryption?: Encryption;
    OutputTimestampMode?: OutputTimestampMode;
}
export type ManifestName = string;
export type AdMarkerHls = "DATERANGE" | "SCTE35_ENHANCED" | (string & {});
export type ScteInManifests = "ALL" | "MATCHES_FILTER" | (string & {});
export interface ScteHls {
    AdMarkerHls?: AdMarkerHls;
    ScteInManifests?: ScteInManifests;
}
export interface StartTag {
    TimeOffset: number;
    Precise?: boolean;
}
export interface MultiviewFilterConfiguration {
    Layout: MultiviewLayoutType;
    Sources: string[];
}
export interface FilterConfiguration {
    ManifestFilter?: string;
    DrmSettings?: string;
    Start?: Date;
    End?: Date;
    TimeDelaySeconds?: number;
    ClipStartTime?: Date;
    Multiview?: MultiviewFilterConfiguration;
}
export type UriPathType = "LEAF" | "ROOT" | (string & {});
export interface CreateHlsManifestConfiguration {
    ManifestName: string;
    ChildManifestName?: string;
    ScteHls?: ScteHls;
    StartTag?: StartTag;
    ManifestWindowSeconds?: number;
    ProgramDateTimeIntervalSeconds?: number;
    FilterConfiguration?: FilterConfiguration;
    UrlEncodeChildManifest?: boolean;
    UriPathType?: UriPathType;
}
export type CreateHlsManifests = CreateHlsManifestConfiguration[];
export interface CreateLowLatencyHlsManifestConfiguration {
    ManifestName: string;
    ChildManifestName?: string;
    ScteHls?: ScteHls;
    StartTag?: StartTag;
    ManifestWindowSeconds?: number;
    ProgramDateTimeIntervalSeconds?: number;
    FilterConfiguration?: FilterConfiguration;
    UrlEncodeChildManifest?: boolean;
    UriPathType?: UriPathType;
}
export type CreateLowLatencyHlsManifests = CreateLowLatencyHlsManifestConfiguration[];
export type DashSegmentTemplateFormat = "NUMBER_WITH_TIMELINE" | (string & {});
export type DashPeriodTrigger = "AVAILS" | "DRM_KEY_ROTATION" | "SOURCE_CHANGES" | "SOURCE_DISRUPTIONS" | "NONE" | (string & {});
export type DashPeriodTriggers = DashPeriodTrigger[];
export type AdMarkerDash = "BINARY" | "XML" | (string & {});
export interface ScteDash {
    AdMarkerDash?: AdMarkerDash;
    ScteInManifests?: ScteInManifests;
}
export type DashDrmSignaling = "INDIVIDUAL" | "REFERENCED" | (string & {});
export type DashUtcTimingMode = "HTTP_HEAD" | "HTTP_ISO" | "HTTP_XSDATE" | "UTC_DIRECT" | (string & {});
export interface DashUtcTiming {
    TimingMode?: DashUtcTimingMode;
    TimingSource?: string;
}
export type DashProfile = "DVB_DASH" | (string & {});
export type DashProfiles = DashProfile[];
export interface DashBaseUrl {
    Url: string;
    ServiceLocation?: string;
    DvbPriority?: number;
    DvbWeight?: number;
}
export type DashBaseUrls = DashBaseUrl[];
export interface DashProgramInformation {
    Title?: string;
    Source?: string;
    Copyright?: string;
    LanguageCode?: string;
    MoreInformationUrl?: string;
}
export interface DashDvbFontDownload {
    Url?: string;
    MimeType?: string;
    FontFamily?: string;
}
export interface DashDvbMetricsReporting {
    ReportingUrl: string;
    Probability?: number;
}
export type DashDvbErrorMetrics = DashDvbMetricsReporting[];
export interface DashDvbSettings {
    FontDownload?: DashDvbFontDownload;
    ErrorMetrics?: DashDvbMetricsReporting[];
}
export type DashCompactness = "STANDARD" | "NONE" | (string & {});
export type DashAudioTimelinePattern = "NONE" | "PATTERNED" | (string & {});
export type DashTtmlProfile = "IMSC_1" | "EBU_TT_D_101" | (string & {});
export interface DashTtmlConfiguration {
    TtmlProfile: DashTtmlProfile;
}
export interface DashSubtitleConfiguration {
    TtmlConfiguration?: DashTtmlConfiguration;
}
export type DashAvailabilityStartTimeConfiguration = {
    FixedAvailabilityStartTime: Date;
};
export interface CreateDashManifestConfiguration {
    ManifestName: string;
    ManifestWindowSeconds?: number;
    FilterConfiguration?: FilterConfiguration;
    MinUpdatePeriodSeconds?: number;
    MinBufferTimeSeconds?: number;
    SuggestedPresentationDelaySeconds?: number;
    SegmentTemplateFormat?: DashSegmentTemplateFormat;
    PeriodTriggers?: DashPeriodTrigger[];
    ScteDash?: ScteDash;
    DrmSignaling?: DashDrmSignaling;
    UtcTiming?: DashUtcTiming;
    Profiles?: DashProfile[];
    BaseUrls?: DashBaseUrl[];
    ProgramInformation?: DashProgramInformation;
    DvbSettings?: DashDvbSettings;
    Compactness?: DashCompactness;
    AudioTimelinePattern?: DashAudioTimelinePattern;
    SubtitleConfiguration?: DashSubtitleConfiguration;
    UriPathType?: UriPathType;
    AvailabilityStartTimeConfiguration?: DashAvailabilityStartTimeConfiguration;
}
export type CreateDashManifests = CreateDashManifestConfiguration[];
export type MssManifestLayout = "FULL" | "COMPACT" | (string & {});
export interface CreateMssManifestConfiguration {
    ManifestName: string;
    ManifestWindowSeconds?: number;
    FilterConfiguration?: FilterConfiguration;
    ManifestLayout?: MssManifestLayout;
}
export type CreateMssManifests = CreateMssManifestConfiguration[];
export type EndpointErrorCondition = "STALE_MANIFEST" | "INCOMPLETE_MANIFEST" | "MISSING_DRM_KEY" | "SLATE_INPUT" | (string & {});
export type EndpointErrorConditions = EndpointErrorCondition[];
export interface ForceEndpointErrorConfiguration {
    EndpointErrorConditions?: EndpointErrorCondition[];
}
export type UriSeparator = "UNDERSCORE" | "HYPHEN" | (string & {});
export type StreamNameOutputMode = "INDEX" | "PASSTHROUGH_NAME" | (string & {});
export interface CreateOriginEndpointRequest {
    ChannelGroupName: string;
    ChannelName: string;
    OriginEndpointName: string;
    ContainerType: ContainerType;
    Segment?: Segment;
    ClientToken?: string;
    Description?: string;
    StartoverWindowSeconds?: number;
    HlsManifests?: CreateHlsManifestConfiguration[];
    LowLatencyHlsManifests?: CreateLowLatencyHlsManifestConfiguration[];
    DashManifests?: CreateDashManifestConfiguration[];
    MssManifests?: CreateMssManifestConfiguration[];
    ForceEndpointErrorConfiguration?: ForceEndpointErrorConfiguration;
    UriSeparator?: UriSeparator;
    StreamNameOutputMode?: StreamNameOutputMode;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetHlsManifestConfiguration {
    ManifestName: string;
    Url: string;
    ChildManifestName?: string;
    ManifestWindowSeconds?: number;
    ProgramDateTimeIntervalSeconds?: number;
    ScteHls?: ScteHls;
    FilterConfiguration?: FilterConfiguration;
    StartTag?: StartTag;
    UrlEncodeChildManifest?: boolean;
    UriPathType?: UriPathType;
}
export type GetHlsManifests = GetHlsManifestConfiguration[];
export interface GetLowLatencyHlsManifestConfiguration {
    ManifestName: string;
    Url: string;
    ChildManifestName?: string;
    ManifestWindowSeconds?: number;
    ProgramDateTimeIntervalSeconds?: number;
    ScteHls?: ScteHls;
    FilterConfiguration?: FilterConfiguration;
    StartTag?: StartTag;
    UrlEncodeChildManifest?: boolean;
    UriPathType?: UriPathType;
}
export type GetLowLatencyHlsManifests = GetLowLatencyHlsManifestConfiguration[];
export interface GetDashManifestConfiguration {
    ManifestName: string;
    Url: string;
    ManifestWindowSeconds?: number;
    FilterConfiguration?: FilterConfiguration;
    MinUpdatePeriodSeconds?: number;
    MinBufferTimeSeconds?: number;
    SuggestedPresentationDelaySeconds?: number;
    SegmentTemplateFormat?: DashSegmentTemplateFormat;
    PeriodTriggers?: DashPeriodTrigger[];
    ScteDash?: ScteDash;
    DrmSignaling?: DashDrmSignaling;
    UtcTiming?: DashUtcTiming;
    Profiles?: DashProfile[];
    BaseUrls?: DashBaseUrl[];
    ProgramInformation?: DashProgramInformation;
    DvbSettings?: DashDvbSettings;
    Compactness?: DashCompactness;
    AudioTimelinePattern?: DashAudioTimelinePattern;
    SubtitleConfiguration?: DashSubtitleConfiguration;
    UriPathType?: UriPathType;
    AvailabilityStartTimeConfiguration?: DashAvailabilityStartTimeConfiguration;
}
export type GetDashManifests = GetDashManifestConfiguration[];
export interface GetMssManifestConfiguration {
    ManifestName: string;
    Url: string;
    FilterConfiguration?: FilterConfiguration;
    ManifestWindowSeconds?: number;
    ManifestLayout?: MssManifestLayout;
}
export type GetMssManifests = GetMssManifestConfiguration[];
export interface CreateOriginEndpointResponse {
    Arn: string;
    ChannelGroupName: string;
    ChannelName: string;
    OriginEndpointName: string;
    ContainerType: ContainerType;
    Segment: Segment;
    CreatedAt: Date;
    ModifiedAt: Date;
    Description?: string;
    StartoverWindowSeconds?: number;
    HlsManifests?: GetHlsManifestConfiguration[];
    LowLatencyHlsManifests?: GetLowLatencyHlsManifestConfiguration[];
    DashManifests?: GetDashManifestConfiguration[];
    MssManifests?: GetMssManifestConfiguration[];
    ForceEndpointErrorConfiguration?: ForceEndpointErrorConfiguration;
    UriSeparator?: UriSeparator;
    StreamNameOutputMode?: StreamNameOutputMode;
    ETag?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DeleteChannelRequest {
    ChannelGroupName: string;
    ChannelName: string;
}
export interface DeleteChannelResponse {
}
export interface DeleteChannelGroupRequest {
    ChannelGroupName: string;
}
export interface DeleteChannelGroupResponse {
}
export interface DeleteChannelPolicyRequest {
    ChannelGroupName: string;
    ChannelName: string;
}
export interface DeleteChannelPolicyResponse {
}
export interface DeleteOriginEndpointRequest {
    ChannelGroupName: string;
    ChannelName: string;
    OriginEndpointName: string;
}
export interface DeleteOriginEndpointResponse {
}
export interface DeleteOriginEndpointPolicyRequest {
    ChannelGroupName: string;
    ChannelName: string;
    OriginEndpointName: string;
}
export interface DeleteOriginEndpointPolicyResponse {
}
export interface GetChannelRequest {
    ChannelGroupName: string;
    ChannelName: string;
}
export interface GetChannelResponse {
    MultiviewConfiguration?: MultiviewConfiguration;
    AttachedMultiviewChannels?: string[];
    Arn: string;
    ChannelName: string;
    ChannelGroupName: string;
    CreatedAt: Date;
    ModifiedAt: Date;
    ResetAt?: Date;
    Description?: string;
    IngestEndpoints?: IngestEndpoint[];
    InputType?: InputType;
    ETag?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    InputSwitchConfiguration?: InputSwitchConfiguration;
    OutputHeaderConfiguration?: OutputHeaderConfiguration;
    OutputLockingMode?: OutputLockingMode;
}
export interface GetChannelGroupRequest {
    ChannelGroupName: string;
}
export interface GetChannelGroupResponse {
    ChannelGroupName: string;
    Arn: string;
    EgressDomain: string;
    CreatedAt: Date;
    ModifiedAt: Date;
    Description?: string;
    ETag?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetChannelPolicyRequest {
    ChannelGroupName: string;
    ChannelName: string;
}
export type PolicyText = string;
export interface GetChannelPolicyResponse {
    ChannelGroupName: string;
    ChannelName: string;
    Policy: string;
}
export interface GetHarvestJobRequest {
    ChannelGroupName: string;
    ChannelName: string;
    OriginEndpointName: string;
    HarvestJobName: string;
}
export interface GetHarvestJobResponse {
    ChannelGroupName: string;
    ChannelName: string;
    OriginEndpointName: string;
    Destination: Destination;
    HarvestJobName: string;
    HarvestedManifests: HarvestedManifests;
    Description?: string;
    ScheduleConfiguration: HarvesterScheduleConfiguration;
    Arn: string;
    CreatedAt: Date;
    ModifiedAt: Date;
    Status: HarvestJobStatus;
    ErrorMessage?: string;
    ETag?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetOriginEndpointRequest {
    ChannelGroupName: string;
    ChannelName: string;
    OriginEndpointName: string;
}
export interface GetOriginEndpointResponse {
    Arn: string;
    ChannelGroupName: string;
    ChannelName: string;
    OriginEndpointName: string;
    ContainerType: ContainerType;
    Segment: Segment;
    CreatedAt: Date;
    ModifiedAt: Date;
    ResetAt?: Date;
    Description?: string;
    StartoverWindowSeconds?: number;
    HlsManifests?: GetHlsManifestConfiguration[];
    LowLatencyHlsManifests?: GetLowLatencyHlsManifestConfiguration[];
    DashManifests?: GetDashManifestConfiguration[];
    MssManifests?: GetMssManifestConfiguration[];
    ForceEndpointErrorConfiguration?: ForceEndpointErrorConfiguration;
    UriSeparator?: UriSeparator;
    StreamNameOutputMode?: StreamNameOutputMode;
    ETag?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetOriginEndpointPolicyRequest {
    ChannelGroupName: string;
    ChannelName: string;
    OriginEndpointName: string;
}
export type CdnIdentifierSecretArn = string;
export type CdnIdentifierSecretArns = string[];
export interface CdnAuthConfiguration {
    CdnIdentifierSecretArns: string[];
    SecretsRoleArn: string;
}
export interface GetOriginEndpointPolicyResponse {
    ChannelGroupName: string;
    ChannelName: string;
    OriginEndpointName: string;
    Policy: string;
    CdnAuthConfiguration?: CdnAuthConfiguration;
}
export type ListResourceMaxResults = number;
export interface ListChannelGroupsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface ChannelGroupListConfiguration {
    ChannelGroupName: string;
    Arn: string;
    CreatedAt: Date;
    ModifiedAt: Date;
    Description?: string;
}
export type ChannelGroupsList = ChannelGroupListConfiguration[];
export interface ListChannelGroupsResponse {
    Items?: ChannelGroupListConfiguration[];
    NextToken?: string;
}
export interface ListChannelsRequest {
    ChannelGroupName: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface ChannelListConfiguration {
    Arn: string;
    ChannelName: string;
    ChannelGroupName: string;
    CreatedAt: Date;
    ModifiedAt: Date;
    Description?: string;
    InputType?: InputType;
    OutputLockingMode?: OutputLockingMode;
    MultiviewConfiguration?: MultiviewConfiguration;
    AttachedMultiviewChannels?: string[];
}
export type ChannelList = ChannelListConfiguration[];
export interface ListChannelsResponse {
    Items?: ChannelListConfiguration[];
    NextToken?: string;
}
export interface ListHarvestJobsRequest {
    ChannelGroupName: string;
    ChannelName?: string;
    OriginEndpointName?: string;
    Status?: HarvestJobStatus;
    MaxResults?: number;
    NextToken?: string;
}
export interface HarvestJob {
    ChannelGroupName: string;
    ChannelName: string;
    OriginEndpointName: string;
    Destination: Destination;
    HarvestJobName: string;
    HarvestedManifests: HarvestedManifests;
    Description?: string;
    ScheduleConfiguration: HarvesterScheduleConfiguration;
    Arn: string;
    CreatedAt: Date;
    ModifiedAt: Date;
    Status: HarvestJobStatus;
    ErrorMessage?: string;
    ETag?: string;
}
export type HarvestJobsList = HarvestJob[];
export interface ListHarvestJobsResponse {
    Items?: HarvestJob[];
    NextToken?: string;
}
export interface ListOriginEndpointsRequest {
    ChannelGroupName: string;
    ChannelName: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface ListHlsManifestConfiguration {
    ManifestName: string;
    ChildManifestName?: string;
    Url?: string;
}
export type ListHlsManifests = ListHlsManifestConfiguration[];
export interface ListLowLatencyHlsManifestConfiguration {
    ManifestName: string;
    ChildManifestName?: string;
    Url?: string;
}
export type ListLowLatencyHlsManifests = ListLowLatencyHlsManifestConfiguration[];
export interface ListDashManifestConfiguration {
    ManifestName: string;
    Url?: string;
}
export type ListDashManifests = ListDashManifestConfiguration[];
export interface ListMssManifestConfiguration {
    ManifestName: string;
    Url?: string;
}
export type ListMssManifests = ListMssManifestConfiguration[];
export interface OriginEndpointListConfiguration {
    Arn: string;
    ChannelGroupName: string;
    ChannelName: string;
    OriginEndpointName: string;
    ContainerType: ContainerType;
    Description?: string;
    CreatedAt?: Date;
    ModifiedAt?: Date;
    HlsManifests?: ListHlsManifestConfiguration[];
    LowLatencyHlsManifests?: ListLowLatencyHlsManifestConfiguration[];
    DashManifests?: ListDashManifestConfiguration[];
    MssManifests?: ListMssManifestConfiguration[];
    ForceEndpointErrorConfiguration?: ForceEndpointErrorConfiguration;
    UriSeparator?: UriSeparator;
    StreamNameOutputMode?: StreamNameOutputMode;
}
export type OriginEndpointsList = OriginEndpointListConfiguration[];
export interface ListOriginEndpointsResponse {
    Items?: OriginEndpointListConfiguration[];
    NextToken?: string;
}
export type TagArn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface PutChannelPolicyRequest {
    ChannelGroupName: string;
    ChannelName: string;
    Policy: string;
}
export interface PutChannelPolicyResponse {
}
export interface PutOriginEndpointPolicyRequest {
    ChannelGroupName: string;
    ChannelName: string;
    OriginEndpointName: string;
    Policy: string;
    CdnAuthConfiguration?: CdnAuthConfiguration;
}
export interface PutOriginEndpointPolicyResponse {
}
export interface ResetChannelStateRequest {
    ChannelGroupName: string;
    ChannelName: string;
}
export interface ResetChannelStateResponse {
    ChannelGroupName: string;
    ChannelName: string;
    Arn: string;
    ResetAt: Date;
}
export interface ResetOriginEndpointStateRequest {
    ChannelGroupName: string;
    ChannelName: string;
    OriginEndpointName: string;
}
export interface ResetOriginEndpointStateResponse {
    ChannelGroupName: string;
    ChannelName: string;
    OriginEndpointName: string;
    Arn: string;
    ResetAt: Date;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateChannelRequest {
    ChannelGroupName: string;
    ChannelName: string;
    ETag?: string;
    Description?: string;
    InputSwitchConfiguration?: InputSwitchConfiguration;
    OutputHeaderConfiguration?: OutputHeaderConfiguration;
    MultiviewConfiguration?: MultiviewConfiguration;
}
export interface UpdateChannelResponse {
    MultiviewConfiguration?: MultiviewConfiguration;
    AttachedMultiviewChannels?: string[];
    Arn: string;
    ChannelName: string;
    ChannelGroupName: string;
    CreatedAt: Date;
    ModifiedAt: Date;
    Description?: string;
    IngestEndpoints?: IngestEndpoint[];
    InputType?: InputType;
    ETag?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    InputSwitchConfiguration?: InputSwitchConfiguration;
    OutputHeaderConfiguration?: OutputHeaderConfiguration;
    OutputLockingMode?: OutputLockingMode;
}
export interface UpdateChannelGroupRequest {
    ChannelGroupName: string;
    ETag?: string;
    Description?: string;
}
export interface UpdateChannelGroupResponse {
    ChannelGroupName: string;
    Arn: string;
    EgressDomain: string;
    CreatedAt: Date;
    ModifiedAt: Date;
    Description?: string;
    ETag?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface UpdateOriginEndpointRequest {
    ChannelGroupName: string;
    ChannelName: string;
    OriginEndpointName: string;
    ContainerType: ContainerType;
    Segment?: Segment;
    Description?: string;
    StartoverWindowSeconds?: number;
    HlsManifests?: CreateHlsManifestConfiguration[];
    LowLatencyHlsManifests?: CreateLowLatencyHlsManifestConfiguration[];
    DashManifests?: CreateDashManifestConfiguration[];
    MssManifests?: CreateMssManifestConfiguration[];
    ForceEndpointErrorConfiguration?: ForceEndpointErrorConfiguration;
    UriSeparator?: UriSeparator;
    StreamNameOutputMode?: StreamNameOutputMode;
    ETag?: string;
}
export interface UpdateOriginEndpointResponse {
    Arn: string;
    ChannelGroupName: string;
    ChannelName: string;
    OriginEndpointName: string;
    ContainerType: ContainerType;
    Segment: Segment;
    CreatedAt: Date;
    ModifiedAt: Date;
    Description?: string;
    StartoverWindowSeconds?: number;
    HlsManifests?: GetHlsManifestConfiguration[];
    LowLatencyHlsManifests?: GetLowLatencyHlsManifestConfiguration[];
    MssManifests?: GetMssManifestConfiguration[];
    ForceEndpointErrorConfiguration?: ForceEndpointErrorConfiguration;
    UriSeparator?: UriSeparator;
    StreamNameOutputMode?: StreamNameOutputMode;
    ETag?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    DashManifests?: GetDashManifestConfiguration[];
}
export type ConflictExceptionType = "RESOURCE_IN_USE" | "RESOURCE_ALREADY_EXISTS" | "IDEMPOTENT_PARAMETER_MISMATCH" | "CONFLICTING_OPERATION" | (string & {});
export type ResourceTypeNotFound = "CHANNEL_GROUP" | "CHANNEL" | "ORIGIN_ENDPOINT" | "HARVEST_JOB" | (string & {});
export type ValidationExceptionType = "CONTAINER_TYPE_IMMUTABLE" | "INVALID_PAGINATION_TOKEN" | "INVALID_PAGINATION_MAX_RESULTS" | "INVALID_POLICY" | "INVALID_ROLE_ARN" | "MANIFEST_NAME_COLLISION" | "ENCRYPTION_METHOD_CONTAINER_TYPE_MISMATCH" | "CENC_IV_INCOMPATIBLE" | "ENCRYPTION_CONTRACT_WITHOUT_AUDIO_RENDITION_INCOMPATIBLE" | "ENCRYPTION_CONTRACT_WITH_ISM_CONTAINER_INCOMPATIBLE" | "ENCRYPTION_CONTRACT_UNENCRYPTED" | "ENCRYPTION_CONTRACT_SHARED" | "NUM_MANIFESTS_LOW" | "NUM_MANIFESTS_HIGH" | "MANIFEST_DRM_SYSTEMS_INCOMPATIBLE" | "DRM_SYSTEMS_ENCRYPTION_METHOD_INCOMPATIBLE" | "ROLE_ARN_NOT_ASSUMABLE" | "ROLE_ARN_LENGTH_OUT_OF_RANGE" | "ROLE_ARN_INVALID_FORMAT" | "URL_INVALID" | "URL_SCHEME" | "URL_USER_INFO" | "URL_PORT" | "URL_UNKNOWN_HOST" | "URL_LOCAL_ADDRESS" | "URL_LOOPBACK_ADDRESS" | "URL_LINK_LOCAL_ADDRESS" | "URL_MULTICAST_ADDRESS" | "MEMBER_INVALID" | "MEMBER_MISSING" | "MEMBER_MIN_VALUE" | "MEMBER_MAX_VALUE" | "MEMBER_MIN_LENGTH" | "MEMBER_MAX_LENGTH" | "MEMBER_INVALID_ENUM_VALUE" | "MEMBER_DOES_NOT_MATCH_PATTERN" | "INVALID_MANIFEST_FILTER" | "INVALID_DRM_SETTINGS" | "INVALID_TIME_DELAY_SECONDS" | "END_TIME_EARLIER_THAN_START_TIME" | "TS_CONTAINER_TYPE_WITH_DASH_MANIFEST" | "DIRECT_MODE_WITH_TIMING_SOURCE" | "NONE_MODE_WITH_TIMING_SOURCE" | "TIMING_SOURCE_MISSING" | "UPDATE_PERIOD_SMALLER_THAN_SEGMENT_DURATION" | "PERIOD_TRIGGERS_NONE_SPECIFIED_WITH_ADDITIONAL_VALUES" | "DRM_SIGNALING_MISMATCH_SEGMENT_ENCRYPTION_STATUS" | "ONLY_CMAF_INPUT_TYPE_ALLOW_FORCE_ENDPOINT_ERROR_CONFIGURATION" | "SOURCE_DISRUPTIONS_ENABLED_INCORRECTLY" | "HARVESTED_MANIFEST_HAS_START_END_FILTER_CONFIGURATION" | "HARVESTED_MANIFEST_NOT_FOUND_ON_ENDPOINT" | "TOO_MANY_IN_PROGRESS_HARVEST_JOBS" | "HARVEST_JOB_INELIGIBLE_FOR_CANCELLATION" | "INVALID_HARVEST_JOB_DURATION" | "HARVEST_JOB_S3_DESTINATION_MISSING_OR_INCOMPLETE" | "HARVEST_JOB_UNABLE_TO_WRITE_TO_S3_DESTINATION" | "HARVEST_JOB_CUSTOMER_ENDPOINT_READ_ACCESS_DENIED" | "CLIP_START_TIME_WITH_START_OR_END" | "START_TAG_TIME_OFFSET_INVALID" | "INCOMPATIBLE_DASH_PROFILE_DVB_DASH_CONFIGURATION" | "DASH_DVB_ATTRIBUTES_WITHOUT_DVB_DASH_PROFILE" | "INCOMPATIBLE_DASH_COMPACTNESS_CONFIGURATION" | "INCOMPATIBLE_XML_ENCODING" | "CMAF_EXCLUDE_SEGMENT_DRM_METADATA_INCOMPATIBLE_CONTAINER_TYPE" | "ONLY_CMAF_INPUT_TYPE_ALLOW_MQCS_INPUT_SWITCHING" | "ONLY_CMAF_INPUT_TYPE_ALLOW_MQCS_OUTPUT_CONFIGURATION" | "ONLY_CMAF_INPUT_TYPE_ALLOW_PREFERRED_INPUT_CONFIGURATION" | "TS_CONTAINER_TYPE_WITH_MSS_MANIFEST" | "CMAF_CONTAINER_TYPE_WITH_MSS_MANIFEST" | "ISM_CONTAINER_TYPE_WITH_HLS_MANIFEST" | "ISM_CONTAINER_TYPE_WITH_LL_HLS_MANIFEST" | "ISM_CONTAINER_TYPE_WITH_DASH_MANIFEST" | "ISM_CONTAINER_TYPE_WITH_SCTE" | "ISM_CONTAINER_WITH_KEY_ROTATION" | "BATCH_GET_SECRET_VALUE_DENIED" | "GET_SECRET_VALUE_DENIED" | "DESCRIBE_SECRET_DENIED" | "INVALID_SECRET_FORMAT" | "SECRET_IS_NOT_ONE_KEY_VALUE_PAIR" | "INVALID_SECRET_KEY" | "INVALID_SECRET_VALUE" | "SECRET_ARN_RESOURCE_NOT_FOUND" | "DECRYPT_SECRET_FAILED" | "TOO_MANY_SECRETS" | "DUPLICATED_SECRET" | "MALFORMED_SECRET_ARN" | "SECRET_FROM_DIFFERENT_ACCOUNT" | "SECRET_FROM_DIFFERENT_REGION" | "INVALID_SECRET" | "RESOURCE_NOT_IN_SAME_REGION" | "CERTIFICATE_RESOURCE_NOT_FOUND" | "CERTIFICATE_ACCESS_DENIED" | "DESCRIBE_CERTIFICATE_FAILED" | "INVALID_CERTIFICATE_STATUS" | "INVALID_CERTIFICATE_KEY_ALGORITHM" | "INVALID_CERTIFICATE_SIGNATURE_ALGORITHM" | "MISSING_CERTIFICATE_DOMAIN_NAME" | "INVALID_ARN" | "SCTE_IN_MANIFESTS_INVALID_CONFIGURATION" | "CUSTOM_AD_TYPES_INVALID_CONFIGURATION" | "ONLY_CMAF_INPUT_TYPE_ALLOW_OUTPUT_LOCKING_MODE" | "ONLY_NON_EPOCH_LOCKED_ALLOW_OUTPUT_TIMESTAMP_MODE" | "OUTPUT_TIMESTAMP_MODE_IMMUTABLE" | "NON_EPOCH_LOCKED_WITH_FORCE_ENDPOINT_ERROR_CONFIGURATION" | "ONLY_HLS_INPUT_TYPE_ALLOW_STREAM_NAME_OUTPUT_MODE" | "STREAM_NAME_OUTPUT_MODE_IMMUTABLE" | "MULTIVIEW_CONFIGURATION_REQUIRED" | "MULTIVIEW_CONFIGURATION_NOT_ALLOWED" | "MULTIVIEW_SOURCE_NOT_FOUND" | "MULTIVIEW_SOURCE_INVALID_INPUT_TYPE" | "MULTIVIEW_CHANNEL_POLICY_NOT_ALLOWED" | "MULTIVIEW_INPUT_TYPE_WITH_LL_HLS_MANIFEST" | "MULTIVIEW_INPUT_TYPE_WITH_MSS_MANIFEST" | "MULTIVIEW_INPUT_TYPE_WITH_ISM_CONTAINER" | "MULTIVIEW_INPUT_TYPE_WITH_FILTER_CONFIGURATION" | "MULTIVIEW_INPUT_TYPE_WITH_START_TAG" | "MULTIVIEW_INPUT_TYPE_WITH_HARVEST_JOB" | "MULTIVIEW_RESET_NOT_ALLOWED" | "MULTIVIEW_DUPLICATE_SOURCE" | "MULTIVIEW_DUPLICATE_LAYOUT" | "MULTIVIEW_INPUT_SWITCH_NOT_ALLOWED" | "MULTIVIEW_OUTPUT_HEADER_NOT_ALLOWED" | "MULTIVIEW_STARTOVER_WINDOW_NOT_ALLOWED" | "MULTIVIEW_INVALID_TIME_DELAY_SECONDS" | "MULTIVIEW_MANIFEST_WINDOW_TOO_LONG" | "MULTIVIEW_INPUT_TYPE_WITH_IFRAME_ONLY_STREAMS" | "MULTIVIEW_INPUT_TYPE_WITH_NON_EPOCH_LOCKED" | "MULTIVIEW_INPUT_TYPE_WITH_SEGMENT_DURATION" | "MULTIVIEW_SOURCE_NON_EPOCH_LOCKED" | "MULTIVIEW_SCTE_REQUIRES_AVAILS_PERIOD_TRIGGER" | "CONTENT_KEY_PERIOD_TIMING_WITHOUT_KEY_ROTATION" | "CONTENT_KEY_PERIOD_TIMING_REQUIRES_SPEKE_V2_1" | "MULTIVIEW_FILTER_CONFIGURATION_NOT_ALLOWED" | "MULTIVIEW_FILTER_LAYOUT_NOT_AVAILABLE" | "MULTIVIEW_FILTER_SOURCE_NOT_AVAILABLE" | "MULTIVIEW_FILTER_SOURCE_COUNT_MISMATCH" | "MULTIVIEW_SOURCE_CHANNEL_LIMIT_EXCEEDED" | "MULTIVIEW_TS_USE_AUDIO_RENDITION_GROUP_DISABLED" | (string & {});
export type CancelHarvestJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels an in-progress harvest job.
 */
export declare const cancelHarvestJob: API.OperationMethod<CancelHarvestJobRequest, CancelHarvestJobResponse, CancelHarvestJobError, Credentials | HttpClient.HttpClient>;
export type CreateChannelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a channel to start receiving content streams. The channel represents the input to MediaPackage for incoming live content from an encoder such as AWS Elemental MediaLive. The channel receives content, and after packaging it, outputs it through an origin endpoint to downstream devices (such as video players or CDNs) that request the content. You can create only one channel with each request. We recommend that you spread out channels between channel groups, such as putting redundant channels in the same AWS Region in different channel groups.
 */
export declare const createChannel: API.OperationMethod<CreateChannelRequest, CreateChannelResponse, CreateChannelError, Credentials | HttpClient.HttpClient>;
export type CreateChannelGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a channel group to group your channels and origin endpoints. A channel group is the top-level resource that consists of channels and origin endpoints that are associated with it and that provides predictable URLs for stream delivery. All channels and origin endpoints within the channel group are guaranteed to share the DNS. You can create only one channel group with each request.
 */
export declare const createChannelGroup: API.OperationMethod<CreateChannelGroupRequest, CreateChannelGroupResponse, CreateChannelGroupError, Credentials | HttpClient.HttpClient>;
export type CreateHarvestJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new harvest job to export content from a MediaPackage v2 channel to an S3 bucket.
 */
export declare const createHarvestJob: API.OperationMethod<CreateHarvestJobRequest, CreateHarvestJobResponse, CreateHarvestJobError, Credentials | HttpClient.HttpClient>;
export type CreateOriginEndpointError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The endpoint is attached to a channel, and represents the output of the live content. You can associate multiple endpoints to a single channel. Each endpoint gives players and downstream CDNs (such as Amazon CloudFront) access to the content for playback. Content can't be served from a channel until it has an endpoint. You can create only one endpoint with each request.
 */
export declare const createOriginEndpoint: API.OperationMethod<CreateOriginEndpointRequest, CreateOriginEndpointResponse, CreateOriginEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteChannelError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a channel to stop AWS Elemental MediaPackage from receiving further content. You must delete the channel's origin endpoints before you can delete the channel.
 */
export declare const deleteChannel: API.OperationMethod<DeleteChannelRequest, DeleteChannelResponse, DeleteChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteChannelGroupError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a channel group. You must delete the channel group's channels and origin endpoints before you can delete the channel group. If you delete a channel group, you'll lose access to the egress domain and will have to create a new channel group to replace it.
 */
export declare const deleteChannelGroup: API.OperationMethod<DeleteChannelGroupRequest, DeleteChannelGroupResponse, DeleteChannelGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteChannelPolicyError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a channel policy.
 */
export declare const deleteChannelPolicy: API.OperationMethod<DeleteChannelPolicyRequest, DeleteChannelPolicyResponse, DeleteChannelPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteOriginEndpointError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Origin endpoints can serve content until they're deleted. Delete the endpoint if it should no longer respond to playback requests. You must delete all endpoints from a channel before you can delete the channel.
 */
export declare const deleteOriginEndpoint: API.OperationMethod<DeleteOriginEndpointRequest, DeleteOriginEndpointResponse, DeleteOriginEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteOriginEndpointPolicyError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete an origin endpoint policy.
 */
export declare const deleteOriginEndpointPolicy: API.OperationMethod<DeleteOriginEndpointPolicyRequest, DeleteOriginEndpointPolicyResponse, DeleteOriginEndpointPolicyError, Credentials | HttpClient.HttpClient>;
export type GetChannelError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the specified channel that's configured in AWS Elemental MediaPackage.
 */
export declare const getChannel: API.OperationMethod<GetChannelRequest, GetChannelResponse, GetChannelError, Credentials | HttpClient.HttpClient>;
export type GetChannelGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the specified channel group that's configured in AWS Elemental MediaPackage.
 */
export declare const getChannelGroup: API.OperationMethod<GetChannelGroupRequest, GetChannelGroupResponse, GetChannelGroupError, Credentials | HttpClient.HttpClient>;
export type GetChannelPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the specified channel policy that's configured in AWS Elemental MediaPackage. With policies, you can specify who has access to AWS resources and what actions they can perform on those resources.
 */
export declare const getChannelPolicy: API.OperationMethod<GetChannelPolicyRequest, GetChannelPolicyResponse, GetChannelPolicyError, Credentials | HttpClient.HttpClient>;
export type GetHarvestJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of a specific harvest job.
 */
export declare const getHarvestJob: API.OperationMethod<GetHarvestJobRequest, GetHarvestJobResponse, GetHarvestJobError, Credentials | HttpClient.HttpClient>;
export type GetOriginEndpointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the specified origin endpoint that's configured in AWS Elemental MediaPackage to obtain its playback URL and to view the packaging settings that it's currently using.
 */
export declare const getOriginEndpoint: API.OperationMethod<GetOriginEndpointRequest, GetOriginEndpointResponse, GetOriginEndpointError, Credentials | HttpClient.HttpClient>;
export type GetOriginEndpointPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the specified origin endpoint policy that's configured in AWS Elemental MediaPackage.
 */
export declare const getOriginEndpointPolicy: API.OperationMethod<GetOriginEndpointPolicyRequest, GetOriginEndpointPolicyResponse, GetOriginEndpointPolicyError, Credentials | HttpClient.HttpClient>;
export type ListChannelGroupsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves all channel groups that are configured in Elemental MediaPackage.
 */
export declare const listChannelGroups: API.PaginatedOperationMethod<ListChannelGroupsRequest, ListChannelGroupsResponse, ListChannelGroupsError, Credentials | HttpClient.HttpClient, ChannelGroupListConfiguration>;
export type ListChannelsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves all channels in a specific channel group that are configured in AWS Elemental MediaPackage.
 */
export declare const listChannels: API.PaginatedOperationMethod<ListChannelsRequest, ListChannelsResponse, ListChannelsError, Credentials | HttpClient.HttpClient, ChannelListConfiguration>;
export type ListHarvestJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of harvest jobs that match the specified criteria.
 */
export declare const listHarvestJobs: API.PaginatedOperationMethod<ListHarvestJobsRequest, ListHarvestJobsResponse, ListHarvestJobsError, Credentials | HttpClient.HttpClient, HarvestJob>;
export type ListOriginEndpointsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves all origin endpoints in a specific channel that are configured in AWS Elemental MediaPackage.
 */
export declare const listOriginEndpoints: API.PaginatedOperationMethod<ListOriginEndpointsRequest, ListOriginEndpointsResponse, ListOriginEndpointsError, Credentials | HttpClient.HttpClient, OriginEndpointListConfiguration>;
export type ListTagsForResourceError = ValidationException | CommonErrors;
/**
 * Lists the tags assigned to a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutChannelPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Attaches an IAM policy to the specified channel. With policies, you can specify who has access to AWS resources and what actions they can perform on those resources. You can attach only one policy with each request.
 */
export declare const putChannelPolicy: API.OperationMethod<PutChannelPolicyRequest, PutChannelPolicyResponse, PutChannelPolicyError, Credentials | HttpClient.HttpClient>;
export type PutOriginEndpointPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Attaches an IAM policy to the specified origin endpoint. You can attach only one policy with each request.
 */
export declare const putOriginEndpointPolicy: API.OperationMethod<PutOriginEndpointPolicyRequest, PutOriginEndpointPolicyResponse, PutOriginEndpointPolicyError, Credentials | HttpClient.HttpClient>;
export type ResetChannelStateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Resetting the channel can help to clear errors from misconfigurations in the encoder. A reset refreshes the ingest stream and removes previous content.
 *
 * Be sure to stop the encoder before you reset the channel, and wait at least 30 seconds before you restart the encoder.
 */
export declare const resetChannelState: API.OperationMethod<ResetChannelStateRequest, ResetChannelStateResponse, ResetChannelStateError, Credentials | HttpClient.HttpClient>;
export type ResetOriginEndpointStateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Resetting the origin endpoint can help to resolve unexpected behavior and other content packaging issues. It also helps to preserve special events when you don't want the previous content to be available for viewing. A reset clears out all previous content from the origin endpoint.
 *
 * MediaPackage might return old content from this endpoint in the first 30 seconds after the endpoint reset. For best results, when possible, wait 30 seconds from endpoint reset to send playback requests to this endpoint.
 */
export declare const resetOriginEndpointState: API.OperationMethod<ResetOriginEndpointStateRequest, ResetOriginEndpointStateResponse, ResetOriginEndpointStateError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ValidationException | CommonErrors;
/**
 * Assigns one of more tags (key-value pairs) to the specified MediaPackage resource.
 *
 * Tags can help you organize and categorize your resources. You can also use them to scope user permissions, by granting a user permission to access or change only resources with certain tag values. You can use the TagResource operation with a resource that already has tags. If you specify a new tag key for the resource, this tag is appended to the list of tags associated with the resource. If you specify a tag key that is already associated with the resource, the new tag value that you specify replaces the previous value for that tag.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ValidationException | CommonErrors;
/**
 * Removes one or more tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the specified channel. You can edit if MediaPackage sends ingest or egress access logs to the CloudWatch log group, if content will be encrypted, the description on a channel, and your channel's policy settings. You can't edit the name of the channel or CloudFront distribution details.
 *
 * Any edits you make that impact the video output may not be reflected for a few minutes.
 */
export declare const updateChannel: API.OperationMethod<UpdateChannelRequest, UpdateChannelResponse, UpdateChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the specified channel group. You can edit the description on a channel group for easier identification later from the AWS Elemental MediaPackage console. You can't edit the name of the channel group.
 *
 * Any edits you make that impact the video output may not be reflected for a few minutes.
 */
export declare const updateChannelGroup: API.OperationMethod<UpdateChannelGroupRequest, UpdateChannelGroupResponse, UpdateChannelGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateOriginEndpointError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the specified origin endpoint. Edit the packaging preferences on an endpoint to optimize the viewing experience. You can't edit the name of the endpoint.
 *
 * Any edits you make that impact the video output may not be reflected for a few minutes.
 */
export declare const updateOriginEndpoint: API.OperationMethod<UpdateOriginEndpointRequest, UpdateOriginEndpointResponse, UpdateOriginEndpointError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=mediapackagev2.d.ts.map