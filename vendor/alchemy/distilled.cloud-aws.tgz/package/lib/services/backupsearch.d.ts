import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
export type GenericId = string;
export interface GetSearchJobInput {
    SearchJobIdentifier: string;
}
export interface SearchScopeSummary {
    TotalRecoveryPointsToScanCount?: number;
    TotalItemsToScanCount?: number;
}
export interface CurrentSearchProgress {
    RecoveryPointsScannedCount?: number;
    ItemsScannedCount?: number;
    ItemsMatchedCount?: number;
}
export type EncryptionKeyArn = string;
export type SearchJobState = "RUNNING" | "COMPLETED" | "STOPPING" | "STOPPED" | "FAILED" | (string & {});
export type ResourceType = "S3" | "EBS" | (string & {});
export type ResourceTypeList = ResourceType[];
export interface BackupCreationTimeFilter {
    CreatedAfter?: Date;
    CreatedBefore?: Date;
}
export type ResourceArnList = string[];
export type RecoveryPoint = string;
export type RecoveryPointArnList = string[];
export type TagMap = {
    [key: string]: string | undefined;
};
export interface SearchScope {
    BackupResourceTypes: ResourceType[];
    BackupResourceCreationTime?: BackupCreationTimeFilter;
    SourceResourceArns?: string[];
    BackupResourceArns?: string[];
    BackupResourceTags?: {
        [key: string]: string | undefined;
    };
}
export type StringConditionOperator = "EQUALS_TO" | "NOT_EQUALS_TO" | "CONTAINS" | "DOES_NOT_CONTAIN" | "BEGINS_WITH" | "ENDS_WITH" | "DOES_NOT_BEGIN_WITH" | "DOES_NOT_END_WITH" | (string & {});
export interface StringCondition {
    Value: string;
    Operator?: StringConditionOperator;
}
export type StringConditionList = StringCondition[];
export type LongConditionOperator = "EQUALS_TO" | "NOT_EQUALS_TO" | "LESS_THAN_EQUAL_TO" | "GREATER_THAN_EQUAL_TO" | (string & {});
export interface LongCondition {
    Value: number;
    Operator?: LongConditionOperator;
}
export type LongConditionList = LongCondition[];
export type TimeConditionOperator = "EQUALS_TO" | "NOT_EQUALS_TO" | "LESS_THAN_EQUAL_TO" | "GREATER_THAN_EQUAL_TO" | (string & {});
export interface TimeCondition {
    Value: Date;
    Operator?: TimeConditionOperator;
}
export type TimeConditionList = TimeCondition[];
export interface S3ItemFilter {
    ObjectKeys?: StringCondition[];
    Sizes?: LongCondition[];
    CreationTimes?: TimeCondition[];
    VersionIds?: StringCondition[];
    ETags?: StringCondition[];
}
export type S3ItemFilters = S3ItemFilter[];
export interface EBSItemFilter {
    FilePaths?: StringCondition[];
    Sizes?: LongCondition[];
    CreationTimes?: TimeCondition[];
    LastModificationTimes?: TimeCondition[];
}
export type EBSItemFilters = EBSItemFilter[];
export interface ItemFilters {
    S3ItemFilters?: S3ItemFilter[];
    EBSItemFilters?: EBSItemFilter[];
}
export type SearchJobArn = string;
export interface GetSearchJobOutput {
    Name?: string;
    SearchScopeSummary?: SearchScopeSummary;
    CurrentSearchProgress?: CurrentSearchProgress;
    StatusMessage?: string;
    EncryptionKeyArn?: string;
    CompletionTime?: Date;
    Status: SearchJobState;
    SearchScope: SearchScope;
    ItemFilters: ItemFilters;
    CreationTime: Date;
    SearchJobIdentifier: string;
    SearchJobArn: string;
}
export interface GetSearchResultExportJobInput {
    ExportJobIdentifier: string;
}
export type ExportJobArn = string;
export type ExportJobStatus = "RUNNING" | "FAILED" | "COMPLETED" | (string & {});
export interface S3ExportSpecification {
    DestinationBucket: string;
    DestinationPrefix?: string;
}
export type ExportSpecification = {
    s3ExportSpecification: S3ExportSpecification;
};
export interface GetSearchResultExportJobOutput {
    ExportJobIdentifier: string;
    ExportJobArn?: string;
    Status?: ExportJobStatus;
    CreationTime?: Date;
    CompletionTime?: Date;
    StatusMessage?: string;
    ExportSpecification?: ExportSpecification;
    SearchJobArn?: string;
}
export interface ListSearchJobBackupsInput {
    SearchJobIdentifier: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface SearchJobBackupsResult {
    Status?: SearchJobState;
    StatusMessage?: string;
    ResourceType?: ResourceType;
    BackupResourceArn?: string;
    SourceResourceArn?: string;
    IndexCreationTime?: Date;
    BackupCreationTime?: Date;
}
export type SearchJobBackupsResults = SearchJobBackupsResult[];
export interface ListSearchJobBackupsOutput {
    Results: SearchJobBackupsResult[];
    NextToken?: string;
}
export interface ListSearchJobResultsInput {
    SearchJobIdentifier: string;
    NextToken?: string;
    MaxResults?: number;
}
export type ObjectKey = string | redacted.Redacted<string>;
export interface S3ResultItem {
    BackupResourceArn?: string;
    SourceResourceArn?: string;
    BackupVaultName?: string;
    ObjectKey?: string | redacted.Redacted<string>;
    ObjectSize?: number;
    CreationTime?: Date;
    ETag?: string;
    VersionId?: string;
}
export type FilePath = string | redacted.Redacted<string>;
export interface EBSResultItem {
    BackupResourceArn?: string;
    SourceResourceArn?: string;
    BackupVaultName?: string;
    FileSystemIdentifier?: string;
    FilePath?: string | redacted.Redacted<string>;
    FileSize?: number;
    CreationTime?: Date;
    LastModifiedTime?: Date;
}
export type ResultItem = {
    S3ResultItem: S3ResultItem;
    EBSResultItem?: never;
} | {
    S3ResultItem?: never;
    EBSResultItem: EBSResultItem;
};
export type Results = ResultItem[];
export interface ListSearchJobResultsOutput {
    Results: ResultItem[];
    NextToken?: string;
}
export interface ListSearchJobsInput {
    ByStatus?: SearchJobState;
    NextToken?: string;
    MaxResults?: number;
}
export interface SearchJobSummary {
    SearchJobIdentifier?: string;
    SearchJobArn?: string;
    Name?: string;
    Status?: SearchJobState;
    CreationTime?: Date;
    CompletionTime?: Date;
    SearchScopeSummary?: SearchScopeSummary;
    StatusMessage?: string;
}
export type SearchJobs = SearchJobSummary[];
export interface ListSearchJobsOutput {
    SearchJobs: SearchJobSummary[];
    NextToken?: string;
}
export interface ListSearchResultExportJobsInput {
    Status?: ExportJobStatus;
    SearchJobIdentifier?: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface ExportJobSummary {
    ExportJobIdentifier: string;
    ExportJobArn?: string;
    Status?: ExportJobStatus;
    CreationTime?: Date;
    CompletionTime?: Date;
    StatusMessage?: string;
    SearchJobArn?: string;
}
export type ExportJobSummaries = ExportJobSummary[];
export interface ListSearchResultExportJobsOutput {
    ExportJobs: ExportJobSummary[];
    NextToken?: string;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface StartSearchJobInput {
    Tags?: {
        [key: string]: string | undefined;
    };
    Name?: string;
    EncryptionKeyArn?: string;
    ClientToken?: string;
    SearchScope: SearchScope;
    ItemFilters?: ItemFilters;
}
export interface StartSearchJobOutput {
    SearchJobArn?: string;
    CreationTime?: Date;
    SearchJobIdentifier?: string;
}
export type IamRoleArn = string;
export interface StartSearchResultExportJobInput {
    SearchJobIdentifier: string;
    ExportSpecification: ExportSpecification;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    RoleArn?: string;
}
export interface StartSearchResultExportJobOutput {
    ExportJobArn?: string;
    ExportJobIdentifier: string;
}
export interface StopSearchJobInput {
    SearchJobIdentifier: string;
}
export interface StopSearchJobOutput {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export type GetSearchJobError = ResourceNotFoundException | CommonErrors;
/**
 * This operation retrieves metadata of a search job, including its progress.
 */
export declare const getSearchJob: API.OperationMethod<GetSearchJobInput, GetSearchJobOutput, GetSearchJobError, Credentials | HttpClient.HttpClient>;
export type GetSearchResultExportJobError = ResourceNotFoundException | CommonErrors;
/**
 * This operation retrieves the metadata of an export job.
 *
 * An export job is an operation that transmits the results of a search job to a specified S3 bucket in a .csv file.
 *
 * An export job allows you to retain results of a search beyond the search job's scheduled retention of 7 days.
 */
export declare const getSearchResultExportJob: API.OperationMethod<GetSearchResultExportJobInput, GetSearchResultExportJobOutput, GetSearchResultExportJobError, Credentials | HttpClient.HttpClient>;
export type ListSearchJobBackupsError = ResourceNotFoundException | CommonErrors;
/**
 * This operation returns a list of all backups (recovery points) in a paginated format that were included in the search job.
 *
 * If a search does not display an expected backup in the results, you can call this operation to display each backup included in the search. Any backups that were not included because they have a `FAILED` status from a permissions issue will be displayed, along with a status message.
 *
 * Only recovery points with a backup index that has a status of `ACTIVE` will be included in search results. If the index has any other status, its status will be displayed along with a status message.
 */
export declare const listSearchJobBackups: API.PaginatedOperationMethod<ListSearchJobBackupsInput, ListSearchJobBackupsOutput, ListSearchJobBackupsError, Credentials | HttpClient.HttpClient, SearchJobBackupsResult>;
export type ListSearchJobResultsError = ResourceNotFoundException | CommonErrors;
/**
 * This operation returns a list of a specified search job.
 */
export declare const listSearchJobResults: API.PaginatedOperationMethod<ListSearchJobResultsInput, ListSearchJobResultsOutput, ListSearchJobResultsError, Credentials | HttpClient.HttpClient, ResultItem>;
export type ListSearchJobsError = CommonErrors;
/**
 * This operation returns a list of search jobs belonging to an account.
 */
export declare const listSearchJobs: API.PaginatedOperationMethod<ListSearchJobsInput, ListSearchJobsOutput, ListSearchJobsError, Credentials | HttpClient.HttpClient, SearchJobSummary>;
export type ListSearchResultExportJobsError = ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * This operation exports search results of a search job to a specified destination S3 bucket.
 */
export declare const listSearchResultExportJobs: API.PaginatedOperationMethod<ListSearchResultExportJobsInput, ListSearchResultExportJobsOutput, ListSearchResultExportJobsError, Credentials | HttpClient.HttpClient, ExportJobSummary>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * This operation returns the tags for a resource type.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartSearchJobError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * This operation creates a search job which returns recovery points filtered by SearchScope and items filtered by ItemFilters.
 *
 * You can optionally include ClientToken, EncryptionKeyArn, Name, and/or Tags.
 */
export declare const startSearchJob: API.OperationMethod<StartSearchJobInput, StartSearchJobOutput, StartSearchJobError, Credentials | HttpClient.HttpClient>;
export type StartSearchResultExportJobError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * This operations starts a job to export the results of search job to a designated S3 bucket.
 */
export declare const startSearchResultExportJob: API.OperationMethod<StartSearchResultExportJobInput, StartSearchResultExportJobOutput, StartSearchResultExportJobError, Credentials | HttpClient.HttpClient>;
export type StopSearchJobError = ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * This operations ends a search job.
 *
 * Only a search job with a status of `RUNNING` can be stopped.
 */
export declare const stopSearchJob: API.OperationMethod<StopSearchJobInput, StopSearchJobOutput, StopSearchJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * This operation puts tags on the resource you indicate.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * This operation removes tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=backupsearch.d.ts.map