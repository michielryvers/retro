import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema";
import * as HttpClient from "effect/http/HttpClient";
import * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
    readonly ErrorId: any;
    readonly ErrorArguments: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
    readonly RetryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
    readonly QuotaCode: any;
    readonly ServiceCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
    readonly ErrorId: any;
    readonly ErrorArguments: any;
    readonly Fields: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ApplicationInstanceName = string;
export type Description = string;
export type ManifestPayloadData = string;
export type ManifestPayload = {
    PayloadData: string;
};
export type ManifestOverridesPayloadData = string;
export type ManifestOverridesPayload = {
    PayloadData: string;
};
export type ApplicationInstanceId = string;
export type RuntimeRoleArn = string;
export type DefaultRuntimeContextDevice = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateApplicationInstanceRequest {
    Name?: string;
    Description?: string;
    ManifestPayload: ManifestPayload;
    ManifestOverridesPayload?: ManifestOverridesPayload;
    ApplicationInstanceIdToReplace?: string;
    RuntimeRoleArn?: string;
    DefaultRuntimeContextDevice: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateApplicationInstanceResponse {
    ApplicationInstanceId: string;
}
export type DeviceId = string;
export type DeviceIdList = string[];
export type ImageVersion = string;
export interface OTAJobConfig {
    ImageVersion: string;
    AllowMajorVersionUpdate?: boolean;
}
export interface DeviceJobConfig {
    OTAJobConfig?: OTAJobConfig;
}
export type JobType = string;
export interface CreateJobForDevicesRequest {
    DeviceIds: string[];
    DeviceJobConfig?: DeviceJobConfig;
    JobType: string;
}
export type JobId = string;
export interface Job {
    JobId?: string;
    DeviceId?: string;
}
export type JobList = Job[];
export interface CreateJobForDevicesResponse {
    Jobs: Job[];
}
export type TemplateType = string;
export type NodePackageName = string;
export type NodePackageVersion = string;
export type NodeName = string;
export type TemplateKey = string;
export type TemplateValue = string | redacted.Redacted<string>;
export type TemplateParametersMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export type JobResourceType = string;
export interface JobResourceTags {
    ResourceType: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export type JobTagsList = JobResourceTags[];
export interface CreateNodeFromTemplateJobRequest {
    TemplateType: string;
    OutputPackageName: string;
    OutputPackageVersion: string;
    NodeName: string;
    NodeDescription?: string;
    TemplateParameters: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    JobTags?: JobResourceTags[];
}
export interface CreateNodeFromTemplateJobResponse {
    JobId: string;
}
export interface CreatePackageRequest {
    PackageName: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type NodePackageId = string;
export type NodePackageArn = string;
export type Bucket = string;
export interface StorageLocation {
    Bucket: string;
    RepoPrefixLocation: string;
    GeneratedPrefixLocation: string;
    BinaryPrefixLocation: string;
    ManifestPrefixLocation: string;
}
export interface CreatePackageResponse {
    PackageId?: string;
    Arn?: string;
    StorageLocation: StorageLocation;
}
export type PackageImportJobType = string;
export type Region = string;
export type BucketName = string;
export type ObjectKey = string;
export interface S3Location {
    Region?: string;
    BucketName: string;
    ObjectKey: string;
}
export interface PackageVersionInputConfig {
    S3Location: S3Location;
}
export interface PackageImportJobInputConfig {
    PackageVersionInputConfig?: PackageVersionInputConfig;
}
export type MarkLatestPatch = boolean;
export interface PackageVersionOutputConfig {
    PackageName: string;
    PackageVersion: string;
    MarkLatest?: boolean;
}
export interface PackageImportJobOutputConfig {
    PackageVersionOutputConfig?: PackageVersionOutputConfig;
}
export type ClientToken = string;
export interface CreatePackageImportJobRequest {
    JobType: string;
    InputConfig: PackageImportJobInputConfig;
    OutputConfig: PackageImportJobOutputConfig;
    ClientToken: string;
    JobTags?: JobResourceTags[];
}
export interface CreatePackageImportJobResponse {
    JobId: string;
}
export interface DeleteDeviceRequest {
    DeviceId: string;
}
export interface DeleteDeviceResponse {
    DeviceId?: string;
}
export interface DeletePackageRequest {
    PackageId: string;
    ForceDelete?: boolean;
}
export interface DeletePackageResponse {
}
export type PackageOwnerAccount = string;
export type NodePackagePatchVersion = string;
export interface DeregisterPackageVersionRequest {
    OwnerAccount?: string;
    PackageId: string;
    PackageVersion: string;
    PatchVersion: string;
    UpdatedLatestPatchVersion?: string;
}
export interface DeregisterPackageVersionResponse {
}
export interface DescribeApplicationInstanceRequest {
    ApplicationInstanceId: string;
}
export type DeviceName = string;
export type ApplicationInstanceStatus = string;
export type ApplicationInstanceHealthStatus = string;
export type ApplicationInstanceStatusDescription = string;
export type ApplicationInstanceArn = string;
export type DesiredState = string;
export type RuntimeContextName = string;
export type DeviceReportedStatus = string;
export interface ReportedRuntimeContextState {
    DesiredState: string;
    RuntimeContextName: string;
    DeviceReportedStatus: string;
    DeviceReportedTime: Date;
}
export type ReportedRuntimeContextStates = ReportedRuntimeContextState[];
export interface DescribeApplicationInstanceResponse {
    Name?: string;
    Description?: string;
    DefaultRuntimeContextDevice?: string;
    DefaultRuntimeContextDeviceName?: string;
    ApplicationInstanceIdToReplace?: string;
    RuntimeRoleArn?: string;
    Status?: string;
    HealthStatus?: string;
    StatusDescription?: string;
    CreatedTime?: Date;
    LastUpdatedTime?: Date;
    ApplicationInstanceId?: string;
    Arn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    RuntimeContextStates?: ReportedRuntimeContextState[];
}
export interface DescribeApplicationInstanceDetailsRequest {
    ApplicationInstanceId: string;
}
export interface DescribeApplicationInstanceDetailsResponse {
    Name?: string;
    Description?: string;
    DefaultRuntimeContextDevice?: string;
    ManifestPayload?: ManifestPayload;
    ManifestOverridesPayload?: ManifestOverridesPayload;
    ApplicationInstanceIdToReplace?: string;
    CreatedTime?: Date;
    ApplicationInstanceId?: string;
}
export interface DescribeDeviceRequest {
    DeviceId: string;
}
export type DeviceArn = string;
export type DeviceType = string;
export type DeviceConnectionStatus = string;
export type CreatedTime = Date;
export type DeviceStatus = string;
export type LatestSoftware = string;
export type CurrentSoftware = string;
export type DeviceSerialNumber = string;
export type ConnectionType = string;
export type IpAddress = string;
export type Mask = string;
export type Dns = string;
export type DnsList = string[];
export type DefaultGateway = string;
export interface StaticIpConnectionInfo {
    IpAddress: string;
    Mask: string;
    Dns: string[];
    DefaultGateway: string;
}
export interface EthernetPayload {
    ConnectionType: string;
    StaticIpConnectionInfo?: StaticIpConnectionInfo;
}
export type IpAddressOrServerName = string;
export type NtpServerList = string[];
export interface NtpPayload {
    NtpServers: string[];
}
export interface NetworkPayload {
    Ethernet0?: EthernetPayload;
    Ethernet1?: EthernetPayload;
    Ntp?: NtpPayload;
}
export type NetworkConnectionStatus = string;
export type HwAddress = string;
export interface EthernetStatus {
    IpAddress?: string;
    ConnectionStatus?: string;
    HwAddress?: string;
}
export type NtpServerName = string;
export interface NtpStatus {
    ConnectionStatus?: string;
    IpAddress?: string;
    NtpServerName?: string;
}
export type LastUpdatedTime = Date;
export interface NetworkStatus {
    Ethernet0Status?: EthernetStatus;
    Ethernet1Status?: EthernetStatus;
    NtpStatus?: NtpStatus;
    LastUpdatedTime?: Date;
}
export type LeaseExpirationTime = Date;
export type Version = string;
export interface AlternateSoftwareMetadata {
    Version?: string;
}
export type AlternateSoftwares = AlternateSoftwareMetadata[];
export type LatestAlternateSoftware = string;
export type DeviceBrand = string;
export type UpdateProgress = string;
export interface LatestDeviceJob {
    ImageVersion?: string;
    Status?: string;
    JobType?: string;
}
export type DeviceAggregatedStatus = string;
export interface DescribeDeviceResponse {
    DeviceId?: string;
    Name?: string;
    Arn?: string;
    Description?: string;
    Type?: string;
    DeviceConnectionStatus?: string;
    CreatedTime?: Date;
    ProvisioningStatus?: string;
    LatestSoftware?: string;
    CurrentSoftware?: string;
    SerialNumber?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    NetworkingConfiguration?: NetworkPayload;
    CurrentNetworkingStatus?: NetworkStatus;
    LeaseExpirationTime?: Date;
    AlternateSoftwares?: AlternateSoftwareMetadata[];
    LatestAlternateSoftware?: string;
    Brand?: string;
    LatestDeviceJob?: LatestDeviceJob;
    DeviceAggregatedStatus?: string;
}
export interface DescribeDeviceJobRequest {
    JobId: string;
}
export type UpdateCreatedTime = Date;
export interface DescribeDeviceJobResponse {
    JobId?: string;
    DeviceId?: string;
    DeviceArn?: string;
    DeviceName?: string;
    DeviceType?: string;
    ImageVersion?: string;
    Status?: string;
    CreatedTime?: Date;
    JobType?: string;
}
export type NodeId = string;
export interface DescribeNodeRequest {
    NodeId: string;
    OwnerAccount?: string;
}
export type NodeCategory = string;
export type PortName = string;
export type PortType = string;
export type PortDefaultValue = string;
export type MaxConnections = number;
export interface NodeInputPort {
    Name?: string;
    Description?: string;
    Type?: string;
    DefaultValue?: string;
    MaxConnections?: number;
}
export type InputPortList = NodeInputPort[];
export interface NodeOutputPort {
    Name?: string;
    Description?: string;
    Type?: string;
}
export type OutputPortList = NodeOutputPort[];
export interface NodeInterface {
    Inputs: NodeInputPort[];
    Outputs: NodeOutputPort[];
}
export type NodeAssetName = string;
export interface DescribeNodeResponse {
    NodeId: string;
    Name: string;
    Category: string;
    OwnerAccount: string;
    PackageName: string;
    PackageId: string;
    PackageArn?: string;
    PackageVersion: string;
    PatchVersion: string;
    NodeInterface: NodeInterface;
    AssetName?: string;
    Description: string;
    CreatedTime: Date;
    LastUpdatedTime: Date;
}
export interface DescribeNodeFromTemplateJobRequest {
    JobId: string;
}
export type NodeFromTemplateJobStatus = string;
export type NodeFromTemplateJobStatusMessage = string;
export interface DescribeNodeFromTemplateJobResponse {
    JobId: string;
    Status: string;
    StatusMessage: string;
    CreatedTime: Date;
    LastUpdatedTime: Date;
    OutputPackageName: string;
    OutputPackageVersion: string;
    NodeName: string;
    NodeDescription?: string;
    TemplateType: string;
    TemplateParameters: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    JobTags?: JobResourceTags[];
}
export interface DescribePackageRequest {
    PackageId: string;
}
export type PrincipalArn = string;
export type PrincipalArnsList = string[];
export interface DescribePackageResponse {
    PackageId: string;
    PackageName: string;
    Arn: string;
    StorageLocation: StorageLocation;
    ReadAccessPrincipalArns?: string[];
    WriteAccessPrincipalArns?: string[];
    CreatedTime: Date;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface DescribePackageImportJobRequest {
    JobId: string;
}
export interface OutPutS3Location {
    BucketName: string;
    ObjectKey: string;
}
export interface PackageImportJobOutput {
    PackageId: string;
    PackageVersion: string;
    PatchVersion: string;
    OutputS3Location: OutPutS3Location;
}
export type PackageImportJobStatus = string;
export type PackageImportJobStatusMessage = string;
export interface DescribePackageImportJobResponse {
    JobId: string;
    ClientToken?: string;
    JobType: string;
    InputConfig: PackageImportJobInputConfig;
    OutputConfig: PackageImportJobOutputConfig;
    Output: PackageImportJobOutput;
    CreatedTime: Date;
    LastUpdatedTime: Date;
    Status: string;
    StatusMessage: string;
    JobTags?: JobResourceTags[];
}
export interface DescribePackageVersionRequest {
    OwnerAccount?: string;
    PackageId: string;
    PackageVersion: string;
    PatchVersion?: string;
}
export type PackageVersionStatus = string;
export type PackageVersionStatusDescription = string;
export interface DescribePackageVersionResponse {
    OwnerAccount?: string;
    PackageId: string;
    PackageArn?: string;
    PackageName: string;
    PackageVersion: string;
    PatchVersion: string;
    IsLatestPatch: boolean;
    Status: string;
    StatusDescription?: string;
    RegisteredTime?: Date;
}
export type MaxSize25 = number;
export type NextToken = string;
export interface ListApplicationInstanceDependenciesRequest {
    ApplicationInstanceId: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface PackageObject {
    Name: string;
    PackageVersion: string;
    PatchVersion: string;
}
export type PackageObjects = PackageObject[];
export interface ListApplicationInstanceDependenciesResponse {
    PackageObjects?: PackageObject[];
    NextToken?: string;
}
export interface ListApplicationInstanceNodeInstancesRequest {
    ApplicationInstanceId: string;
    MaxResults?: number;
    NextToken?: string;
}
export type NodeInstanceId = string;
export type NodeInstanceStatus = string;
export interface NodeInstance {
    NodeInstanceId: string;
    NodeId?: string;
    PackageName?: string;
    PackageVersion?: string;
    PackagePatchVersion?: string;
    NodeName?: string;
    CurrentStatus: string;
}
export type NodeInstances = NodeInstance[];
export interface ListApplicationInstanceNodeInstancesResponse {
    NodeInstances?: NodeInstance[];
    NextToken?: string;
}
export type StatusFilter = string;
export interface ListApplicationInstancesRequest {
    DeviceId?: string;
    StatusFilter?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface ApplicationInstance {
    Name?: string;
    ApplicationInstanceId?: string;
    DefaultRuntimeContextDevice?: string;
    DefaultRuntimeContextDeviceName?: string;
    Description?: string;
    Status?: string;
    HealthStatus?: string;
    StatusDescription?: string;
    CreatedTime?: Date;
    Arn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    RuntimeContextStates?: ReportedRuntimeContextState[];
}
export type ApplicationInstances = ApplicationInstance[];
export interface ListApplicationInstancesResponse {
    ApplicationInstances?: ApplicationInstance[];
    NextToken?: string;
}
export type ListDevicesSortBy = string;
export type SortOrder = string;
export type NameFilter = string;
export interface ListDevicesRequest {
    NextToken?: string;
    MaxResults?: number;
    SortBy?: string;
    SortOrder?: string;
    NameFilter?: string;
    DeviceAggregatedStatusFilter?: string;
}
export interface Device {
    DeviceId?: string;
    Name?: string;
    CreatedTime?: Date;
    ProvisioningStatus?: string;
    LastUpdatedTime?: Date;
    LeaseExpirationTime?: Date;
    Brand?: string;
    CurrentSoftware?: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Type?: string;
    LatestDeviceJob?: LatestDeviceJob;
    DeviceAggregatedStatus?: string;
}
export type DeviceList = Device[];
export interface ListDevicesResponse {
    Devices: Device[];
    NextToken?: string;
}
export interface ListDevicesJobsRequest {
    DeviceId?: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface DeviceJob {
    DeviceName?: string;
    DeviceId?: string;
    JobId?: string;
    CreatedTime?: Date;
    JobType?: string;
}
export type DeviceJobList = DeviceJob[];
export interface ListDevicesJobsResponse {
    DeviceJobs?: DeviceJob[];
    NextToken?: string;
}
export interface ListNodeFromTemplateJobsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface NodeFromTemplateJob {
    JobId?: string;
    TemplateType?: string;
    Status?: string;
    StatusMessage?: string;
    CreatedTime?: Date;
    NodeName?: string;
}
export type NodeFromTemplateJobList = NodeFromTemplateJob[];
export interface ListNodeFromTemplateJobsResponse {
    NodeFromTemplateJobs: NodeFromTemplateJob[];
    NextToken?: string;
}
export type Token = string;
export interface ListNodesRequest {
    Category?: string;
    OwnerAccount?: string;
    PackageName?: string;
    PackageVersion?: string;
    PatchVersion?: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface Node {
    NodeId: string;
    Name: string;
    Category: string;
    OwnerAccount?: string;
    PackageName: string;
    PackageId: string;
    PackageArn?: string;
    PackageVersion: string;
    PatchVersion: string;
    Description?: string;
    CreatedTime: Date;
}
export type NodesList = Node[];
export interface ListNodesResponse {
    Nodes?: Node[];
    NextToken?: string;
}
export interface ListPackageImportJobsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface PackageImportJob {
    JobId?: string;
    JobType?: string;
    Status?: string;
    StatusMessage?: string;
    CreatedTime?: Date;
    LastUpdatedTime?: Date;
}
export type PackageImportJobList = PackageImportJob[];
export interface ListPackageImportJobsResponse {
    PackageImportJobs: PackageImportJob[];
    NextToken?: string;
}
export interface ListPackagesRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface PackageListItem {
    PackageId?: string;
    PackageName?: string;
    Arn?: string;
    CreatedTime?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type PackageList = PackageListItem[];
export interface ListPackagesResponse {
    Packages?: PackageListItem[];
    NextToken?: string;
}
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface ProvisionDeviceRequest {
    Name: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    NetworkingConfiguration?: NetworkPayload;
}
export type Certificates = Uint8Array;
export type IotThingName = string;
export interface ProvisionDeviceResponse {
    DeviceId?: string;
    Arn: string;
    Status: string;
    Certificates?: Uint8Array;
    IotThingName?: string;
}
export interface RegisterPackageVersionRequest {
    OwnerAccount?: string;
    PackageId: string;
    PackageVersion: string;
    PatchVersion: string;
    MarkLatest?: boolean;
}
export interface RegisterPackageVersionResponse {
}
export interface RemoveApplicationInstanceRequest {
    ApplicationInstanceId: string;
}
export interface RemoveApplicationInstanceResponse {
}
export type NodeSignalValue = string;
export interface NodeSignal {
    NodeInstanceId: string;
    Signal: string;
}
export type NodeSignalList = NodeSignal[];
export interface SignalApplicationInstanceNodeInstancesRequest {
    ApplicationInstanceId: string;
    NodeSignals: NodeSignal[];
}
export interface SignalApplicationInstanceNodeInstancesResponse {
    ApplicationInstanceId: string;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateDeviceMetadataRequest {
    DeviceId: string;
    Description?: string;
}
export interface UpdateDeviceMetadataResponse {
    DeviceId?: string;
}
export type RetryAfterSeconds = number;
export type ValidationExceptionReason = string;
export interface ValidationExceptionErrorArgument {
    Name: string;
    Value: string;
}
export type ValidationExceptionErrorArgumentList = ValidationExceptionErrorArgument[];
export interface ValidationExceptionField {
    Name: string;
    Message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export interface ConflictExceptionErrorArgument {
    Name: string;
    Value: string;
}
export type ConflictExceptionErrorArgumentList = ConflictExceptionErrorArgument[];
export type CreateApplicationInstanceError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates an application instance and deploys it to a device.
 */
export declare const createApplicationInstance: API.OperationMethod<CreateApplicationInstanceRequest, CreateApplicationInstanceResponse, CreateApplicationInstanceError, Credentials | HttpClient.HttpClient>;
export type CreateJobForDevicesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates a job to run on a device. A job can update a device's software or reboot it.
 */
export declare const createJobForDevices: API.OperationMethod<CreateJobForDevicesRequest, CreateJobForDevicesResponse, CreateJobForDevicesError, Credentials | HttpClient.HttpClient>;
export type CreateNodeFromTemplateJobError = AccessDeniedException | ConflictException | InternalServerException | ValidationException | CommonErrors;
/**
 * Creates a camera stream node.
 */
export declare const createNodeFromTemplateJob: API.OperationMethod<CreateNodeFromTemplateJobRequest, CreateNodeFromTemplateJobResponse, CreateNodeFromTemplateJobError, Credentials | HttpClient.HttpClient>;
export type CreatePackageError = AccessDeniedException | ConflictException | InternalServerException | ValidationException | CommonErrors;
/**
 * Creates a package and storage location in an Amazon S3 access point.
 */
export declare const createPackage: API.OperationMethod<CreatePackageRequest, CreatePackageResponse, CreatePackageError, Credentials | HttpClient.HttpClient>;
export type CreatePackageImportJobError = AccessDeniedException | ConflictException | InternalServerException | ValidationException | CommonErrors;
/**
 * Imports a node package.
 */
export declare const createPackageImportJob: API.OperationMethod<CreatePackageImportJobRequest, CreatePackageImportJobResponse, CreatePackageImportJobError, Credentials | HttpClient.HttpClient>;
export type DeleteDeviceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a device.
 */
export declare const deleteDevice: API.OperationMethod<DeleteDeviceRequest, DeleteDeviceResponse, DeleteDeviceError, Credentials | HttpClient.HttpClient>;
export type DeletePackageError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a package.
 *
 * To delete a package, you need permission to call `s3:DeleteObject` in addition to permissions for
 * the AWS Panorama API.
 */
export declare const deletePackage: API.OperationMethod<DeletePackageRequest, DeletePackageResponse, DeletePackageError, Credentials | HttpClient.HttpClient>;
export type DeregisterPackageVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deregisters a package version.
 */
export declare const deregisterPackageVersion: API.OperationMethod<DeregisterPackageVersionRequest, DeregisterPackageVersionResponse, DeregisterPackageVersionError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationInstanceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about an application instance on a device.
 */
export declare const describeApplicationInstance: API.OperationMethod<DescribeApplicationInstanceRequest, DescribeApplicationInstanceResponse, DescribeApplicationInstanceError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationInstanceDetailsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about an application instance's configuration manifest.
 */
export declare const describeApplicationInstanceDetails: API.OperationMethod<DescribeApplicationInstanceDetailsRequest, DescribeApplicationInstanceDetailsResponse, DescribeApplicationInstanceDetailsError, Credentials | HttpClient.HttpClient>;
export type DescribeDeviceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a device.
 */
export declare const describeDevice: API.OperationMethod<DescribeDeviceRequest, DescribeDeviceResponse, DescribeDeviceError, Credentials | HttpClient.HttpClient>;
export type DescribeDeviceJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a device job.
 */
export declare const describeDeviceJob: API.OperationMethod<DescribeDeviceJobRequest, DescribeDeviceJobResponse, DescribeDeviceJobError, Credentials | HttpClient.HttpClient>;
export type DescribeNodeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a node.
 */
export declare const describeNode: API.OperationMethod<DescribeNodeRequest, DescribeNodeResponse, DescribeNodeError, Credentials | HttpClient.HttpClient>;
export type DescribeNodeFromTemplateJobError = AccessDeniedException | ConflictException | InternalServerException | ValidationException | CommonErrors;
/**
 * Returns information about a job to create a camera stream node.
 */
export declare const describeNodeFromTemplateJob: API.OperationMethod<DescribeNodeFromTemplateJobRequest, DescribeNodeFromTemplateJobResponse, DescribeNodeFromTemplateJobError, Credentials | HttpClient.HttpClient>;
export type DescribePackageError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a package.
 */
export declare const describePackage: API.OperationMethod<DescribePackageRequest, DescribePackageResponse, DescribePackageError, Credentials | HttpClient.HttpClient>;
export type DescribePackageImportJobError = AccessDeniedException | ConflictException | InternalServerException | ValidationException | CommonErrors;
/**
 * Returns information about a package import job.
 */
export declare const describePackageImportJob: API.OperationMethod<DescribePackageImportJobRequest, DescribePackageImportJobResponse, DescribePackageImportJobError, Credentials | HttpClient.HttpClient>;
export type DescribePackageVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a package version.
 */
export declare const describePackageVersion: API.OperationMethod<DescribePackageVersionRequest, DescribePackageVersionResponse, DescribePackageVersionError, Credentials | HttpClient.HttpClient>;
export type ListApplicationInstanceDependenciesError = AccessDeniedException | InternalServerException | CommonErrors;
/**
 * Returns a list of application instance dependencies.
 */
export declare const listApplicationInstanceDependencies: API.PaginatedOperationMethod<ListApplicationInstanceDependenciesRequest, ListApplicationInstanceDependenciesResponse, ListApplicationInstanceDependenciesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListApplicationInstanceNodeInstancesError = AccessDeniedException | InternalServerException | CommonErrors;
/**
 * Returns a list of application node instances.
 */
export declare const listApplicationInstanceNodeInstances: API.PaginatedOperationMethod<ListApplicationInstanceNodeInstancesRequest, ListApplicationInstanceNodeInstancesResponse, ListApplicationInstanceNodeInstancesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListApplicationInstancesError = AccessDeniedException | InternalServerException | CommonErrors;
/**
 * Returns a list of application instances.
 */
export declare const listApplicationInstances: API.PaginatedOperationMethod<ListApplicationInstancesRequest, ListApplicationInstancesResponse, ListApplicationInstancesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDevicesError = AccessDeniedException | ConflictException | InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of devices.
 */
export declare const listDevices: API.PaginatedOperationMethod<ListDevicesRequest, ListDevicesResponse, ListDevicesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDevicesJobsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of jobs.
 */
export declare const listDevicesJobs: API.PaginatedOperationMethod<ListDevicesJobsRequest, ListDevicesJobsResponse, ListDevicesJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListNodeFromTemplateJobsError = AccessDeniedException | ConflictException | InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of camera stream node jobs.
 */
export declare const listNodeFromTemplateJobs: API.PaginatedOperationMethod<ListNodeFromTemplateJobsRequest, ListNodeFromTemplateJobsResponse, ListNodeFromTemplateJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListNodesError = ConflictException | InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of nodes.
 */
export declare const listNodes: API.PaginatedOperationMethod<ListNodesRequest, ListNodesResponse, ListNodesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPackageImportJobsError = AccessDeniedException | ConflictException | InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of package import jobs.
 */
export declare const listPackageImportJobs: API.PaginatedOperationMethod<ListPackageImportJobsRequest, ListPackageImportJobsResponse, ListPackageImportJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPackagesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of packages.
 */
export declare const listPackages: API.PaginatedOperationMethod<ListPackagesRequest, ListPackagesResponse, ListPackagesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ProvisionDeviceError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a device and returns a configuration archive. The configuration archive is a ZIP file that contains a
 * provisioning certificate that is valid for 5 minutes. Name the configuration archive
 * `certificates-omni_*device-name*.zip` and transfer it to the device within 5
 * minutes. Use the included USB storage device and connect it to the USB 3.0 port next to the HDMI output.
 */
export declare const provisionDevice: API.OperationMethod<ProvisionDeviceRequest, ProvisionDeviceResponse, ProvisionDeviceError, Credentials | HttpClient.HttpClient>;
export type RegisterPackageVersionError = AccessDeniedException | ConflictException | InternalServerException | ValidationException | CommonErrors;
/**
 * Registers a package version.
 */
export declare const registerPackageVersion: API.OperationMethod<RegisterPackageVersionRequest, RegisterPackageVersionResponse, RegisterPackageVersionError, Credentials | HttpClient.HttpClient>;
export type RemoveApplicationInstanceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes an application instance.
 */
export declare const removeApplicationInstance: API.OperationMethod<RemoveApplicationInstanceRequest, RemoveApplicationInstanceResponse, RemoveApplicationInstanceError, Credentials | HttpClient.HttpClient>;
export type SignalApplicationInstanceNodeInstancesError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Signal camera nodes to stop or resume.
 */
export declare const signalApplicationInstanceNodeInstances: API.OperationMethod<SignalApplicationInstanceNodeInstancesRequest, SignalApplicationInstanceNodeInstancesResponse, SignalApplicationInstanceNodeInstancesError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Tags a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDeviceMetadataError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a device's metadata.
 */
export declare const updateDeviceMetadata: API.OperationMethod<UpdateDeviceMetadataRequest, UpdateDeviceMetadataResponse, UpdateDeviceMetadataError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=panorama.d.ts.map