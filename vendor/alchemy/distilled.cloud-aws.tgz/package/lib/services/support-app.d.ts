import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type TeamId = string;
export type ChannelId = string;
export type ChannelName = string;
export type NotificationSeverityLevel = string;
export type RoleArn = string;
export interface CreateSlackChannelConfigurationRequest {
    teamId: string;
    channelId: string;
    channelName?: string;
    notifyOnCreateOrReopenCase?: boolean;
    notifyOnAddCorrespondenceToCase?: boolean;
    notifyOnResolveCase?: boolean;
    notifyOnCaseSeverity: string;
    channelRoleArn: string;
}
export interface CreateSlackChannelConfigurationResult {
}
export interface DeleteAccountAliasRequest {
}
export interface DeleteAccountAliasResult {
}
export interface DeleteSlackChannelConfigurationRequest {
    teamId: string;
    channelId: string;
}
export interface DeleteSlackChannelConfigurationResult {
}
export interface DeleteSlackWorkspaceConfigurationRequest {
    teamId: string;
}
export interface DeleteSlackWorkspaceConfigurationResult {
}
export interface GetAccountAliasRequest {
}
export type AwsAccountAlias = string;
export interface GetAccountAliasResult {
    accountAlias?: string;
}
export type PaginationToken = string;
export interface ListSlackChannelConfigurationsRequest {
    nextToken?: string;
}
export interface SlackChannelConfiguration {
    teamId: string;
    channelId: string;
    channelName?: string;
    notifyOnCreateOrReopenCase?: boolean;
    notifyOnAddCorrespondenceToCase?: boolean;
    notifyOnResolveCase?: boolean;
    notifyOnCaseSeverity?: string;
    channelRoleArn?: string;
}
export type SlackChannelConfigurationList = SlackChannelConfiguration[];
export interface ListSlackChannelConfigurationsResult {
    nextToken?: string;
    slackChannelConfigurations: SlackChannelConfiguration[];
}
export interface ListSlackWorkspaceConfigurationsRequest {
    nextToken?: string;
}
export type TeamName = string;
export interface SlackWorkspaceConfiguration {
    teamId: string;
    teamName?: string;
    allowOrganizationMemberAccount?: boolean;
}
export type SlackWorkspaceConfigurationList = SlackWorkspaceConfiguration[];
export interface ListSlackWorkspaceConfigurationsResult {
    nextToken?: string;
    slackWorkspaceConfigurations?: SlackWorkspaceConfiguration[];
}
export interface PutAccountAliasRequest {
    accountAlias: string;
}
export interface PutAccountAliasResult {
}
export interface RegisterSlackWorkspaceForOrganizationRequest {
    teamId: string;
}
export type AccountType = string;
export interface RegisterSlackWorkspaceForOrganizationResult {
    teamId?: string;
    teamName?: string;
    accountType?: string;
}
export interface UpdateSlackChannelConfigurationRequest {
    teamId: string;
    channelId: string;
    channelName?: string;
    notifyOnCreateOrReopenCase?: boolean;
    notifyOnAddCorrespondenceToCase?: boolean;
    notifyOnResolveCase?: boolean;
    notifyOnCaseSeverity?: string;
    channelRoleArn?: string;
}
export interface UpdateSlackChannelConfigurationResult {
    teamId?: string;
    channelId?: string;
    channelName?: string;
    notifyOnCreateOrReopenCase?: boolean;
    notifyOnAddCorrespondenceToCase?: boolean;
    notifyOnResolveCase?: boolean;
    notifyOnCaseSeverity?: string;
    channelRoleArn?: string;
}
export type ErrorMessage = string;
export type CreateSlackChannelConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a Slack channel configuration for your Amazon Web Services account.
 *
 * - You can add up to 5 Slack workspaces for your account.
 *
 * - You can add up to 20 Slack channels for your account.
 *
 * A Slack channel can have up to 100 Amazon Web Services accounts. This means that only 100 accounts can
 * add the same Slack channel to the Amazon Web Services Support App. We recommend that you only add the accounts that
 * you need to manage support cases for your organization. This can reduce the notifications
 * about case updates that you receive in the Slack channel.
 *
 * We recommend that you choose a private Slack channel so that only members in that
 * channel have read and write access to your support cases. Anyone in your Slack channel can
 * create, update, or resolve support cases for your account. Users require an invitation to
 * join private channels.
 */
export declare const createSlackChannelConfiguration: API.OperationMethod<CreateSlackChannelConfigurationRequest, CreateSlackChannelConfigurationResult, CreateSlackChannelConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteAccountAliasError = AccessDeniedException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an alias for an Amazon Web Services account ID. The alias appears in the Amazon Web Services Support App page of the
 * Amazon Web Services Support Center. The alias also appears in Slack messages from the Amazon Web Services Support App.
 */
export declare const deleteAccountAlias: API.OperationMethod<DeleteAccountAliasRequest, DeleteAccountAliasResult, DeleteAccountAliasError, Credentials | HttpClient.HttpClient>;
export type DeleteSlackChannelConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a Slack channel configuration from your Amazon Web Services account. This operation doesn't
 * delete your Slack channel.
 */
export declare const deleteSlackChannelConfiguration: API.OperationMethod<DeleteSlackChannelConfigurationRequest, DeleteSlackChannelConfigurationResult, DeleteSlackChannelConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteSlackWorkspaceConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a Slack workspace configuration from your Amazon Web Services account. This operation doesn't
 * delete your Slack workspace.
 */
export declare const deleteSlackWorkspaceConfiguration: API.OperationMethod<DeleteSlackWorkspaceConfigurationRequest, DeleteSlackWorkspaceConfigurationResult, DeleteSlackWorkspaceConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetAccountAliasError = InternalServerException | CommonErrors;
/**
 * Retrieves the alias from an Amazon Web Services account ID. The alias appears in the Amazon Web Services Support App page of
 * the Amazon Web Services Support Center. The alias also appears in Slack messages from the Amazon Web Services Support App.
 */
export declare const getAccountAlias: API.OperationMethod<GetAccountAliasRequest, GetAccountAliasResult, GetAccountAliasError, Credentials | HttpClient.HttpClient>;
export type ListSlackChannelConfigurationsError = AccessDeniedException | InternalServerException | CommonErrors;
/**
 * Lists the Slack channel configurations for an Amazon Web Services account.
 */
export declare const listSlackChannelConfigurations: API.PaginatedOperationMethod<ListSlackChannelConfigurationsRequest, ListSlackChannelConfigurationsResult, ListSlackChannelConfigurationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSlackWorkspaceConfigurationsError = AccessDeniedException | InternalServerException | CommonErrors;
/**
 * Lists the Slack workspace configurations for an Amazon Web Services account.
 */
export declare const listSlackWorkspaceConfigurations: API.PaginatedOperationMethod<ListSlackWorkspaceConfigurationsRequest, ListSlackWorkspaceConfigurationsResult, ListSlackWorkspaceConfigurationsError, Credentials | HttpClient.HttpClient, unknown>;
export type PutAccountAliasError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Creates or updates an individual alias for each Amazon Web Services account ID. The alias appears in the
 * Amazon Web Services Support App page of the Amazon Web Services Support Center. The alias also appears in Slack messages from the
 * Amazon Web Services Support App.
 */
export declare const putAccountAlias: API.OperationMethod<PutAccountAliasRequest, PutAccountAliasResult, PutAccountAliasError, Credentials | HttpClient.HttpClient>;
export type RegisterSlackWorkspaceForOrganizationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Registers a Slack workspace for your Amazon Web Services account. To call this API, your account must be
 * part of an organization in Organizations.
 *
 * If you're the *management account* and you want to register Slack
 * workspaces for your organization, you must complete the following tasks:
 *
 * - Sign in to the Amazon Web Services Support Center and
 * authorize the Slack workspaces where you want your organization to have access to. See
 * Authorize a Slack workspace in the Amazon Web Services Support User
 * Guide.
 *
 * - Call the `RegisterSlackWorkspaceForOrganization` API to authorize each
 * Slack workspace for the organization.
 *
 * After the management account authorizes the Slack workspace, member accounts can call this
 * API to authorize the same Slack workspace for their individual accounts. Member accounts don't
 * need to authorize the Slack workspace manually through the Amazon Web Services Support Center.
 *
 * To use the Amazon Web Services Support App, each account must then complete the following tasks:
 *
 * - Create an Identity and Access Management (IAM) role with the required permission. For more information,
 * see Managing access to the Amazon Web Services Support App.
 *
 * - Configure a Slack channel to use the Amazon Web Services Support App for support cases for that account. For
 * more information, see Configuring a Slack channel.
 */
export declare const registerSlackWorkspaceForOrganization: API.OperationMethod<RegisterSlackWorkspaceForOrganizationRequest, RegisterSlackWorkspaceForOrganizationResult, RegisterSlackWorkspaceForOrganizationError, Credentials | HttpClient.HttpClient>;
export type UpdateSlackChannelConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the configuration for a Slack channel, such as case update notifications.
 */
export declare const updateSlackChannelConfiguration: API.OperationMethod<UpdateSlackChannelConfigurationRequest, UpdateSlackChannelConfigurationResult, UpdateSlackChannelConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=support-app.d.ts.map