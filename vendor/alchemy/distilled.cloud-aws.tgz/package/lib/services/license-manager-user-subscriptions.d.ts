import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}>;
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}>;
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}>;
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Directory = string;
export type IpV4 = string;
export type IpV4List = string[];
export type IpV6 = string;
export type IpV6List = string[];
export interface SecretsManagerCredentialsProvider {
    SecretId?: string;
}
export type CredentialsProvider = {
    SecretsManagerCredentialsProvider: SecretsManagerCredentialsProvider;
};
export type Subnet = string;
export type Subnets = string[];
export interface DomainNetworkSettings {
    Subnets: string[];
}
export interface ActiveDirectorySettings {
    DomainName?: string;
    DomainIpv4List?: string[];
    DomainIpv6List?: string[];
    DomainCredentialsProvider?: CredentialsProvider;
    DomainNetworkSettings?: DomainNetworkSettings;
}
export type ActiveDirectoryType = string;
export interface ActiveDirectoryIdentityProvider {
    DirectoryId?: string;
    ActiveDirectorySettings?: ActiveDirectorySettings;
    ActiveDirectoryType?: string;
    IsSharedActiveDirectory?: boolean;
}
export type IdentityProvider = {
    ActiveDirectoryIdentityProvider: ActiveDirectoryIdentityProvider;
};
export type Tags = {
    [key: string]: string | undefined;
};
export interface AssociateUserRequest {
    Username: string;
    InstanceId: string;
    IdentityProvider: IdentityProvider;
    Domain?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type Arn = string;
export interface InstanceUserSummary {
    Username: string;
    InstanceId: string;
    IdentityProvider: IdentityProvider;
    Status: string;
    InstanceUserArn?: string;
    StatusMessage?: string;
    Domain?: string;
    AssociationDate?: string;
    DisassociationDate?: string;
}
export interface AssociateUserResponse {
    InstanceUserSummary: InstanceUserSummary;
}
export type ServerType = string;
export interface RdsSalSettings {
    RdsSalCredentialsProvider: CredentialsProvider;
}
export type ServerSettings = {
    RdsSalSettings: RdsSalSettings;
};
export interface LicenseServerSettings {
    ServerType: string;
    ServerSettings: ServerSettings;
}
export interface CreateLicenseServerEndpointRequest {
    IdentityProviderArn: string;
    LicenseServerSettings: LicenseServerSettings;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateLicenseServerEndpointResponse {
    IdentityProviderArn?: string;
    LicenseServerEndpointArn?: string;
}
export interface DeleteLicenseServerEndpointRequest {
    LicenseServerEndpointArn: string;
    ServerType: string;
}
export interface ServerEndpoint {
    Endpoint?: string;
}
export type LicenseServerEndpointId = string;
export type LicenseServerEndpointProvisioningStatus = string;
export type LicenseServerHealthStatus = string;
export interface LicenseServer {
    ProvisioningStatus?: string;
    HealthStatus?: string;
    Ipv4Address?: string;
    Ipv6Address?: string;
}
export type LicenseServerList = LicenseServer[];
export interface LicenseServerEndpoint {
    IdentityProviderArn?: string;
    ServerType?: string;
    ServerEndpoint?: ServerEndpoint;
    StatusMessage?: string;
    LicenseServerEndpointId?: string;
    LicenseServerEndpointArn?: string;
    LicenseServerEndpointProvisioningStatus?: string;
    LicenseServers?: LicenseServer[];
    CreationTime?: Date;
}
export interface DeleteLicenseServerEndpointResponse {
    LicenseServerEndpoint?: LicenseServerEndpoint;
}
export interface DeregisterIdentityProviderRequest {
    IdentityProvider?: IdentityProvider;
    Product?: string;
    IdentityProviderArn?: string;
}
export type SecurityGroup = string;
export interface Settings {
    Subnets: string[];
    SecurityGroupId: string;
}
export interface IdentityProviderSummary {
    IdentityProvider: IdentityProvider;
    Settings: Settings;
    Product: string;
    Status: string;
    IdentityProviderArn?: string;
    FailureMessage?: string;
    OwnerAccountId?: string;
}
export interface DeregisterIdentityProviderResponse {
    IdentityProviderSummary: IdentityProviderSummary;
}
export interface DisassociateUserRequest {
    Username?: string;
    InstanceId?: string;
    IdentityProvider?: IdentityProvider;
    InstanceUserArn?: string;
    Domain?: string;
}
export interface DisassociateUserResponse {
    InstanceUserSummary: InstanceUserSummary;
}
export type BoxInteger = number;
export interface Filter {
    Attribute?: string;
    Operation?: string;
    Value?: string;
}
export type FilterList = Filter[];
export interface ListIdentityProvidersRequest {
    MaxResults?: number;
    Filters?: Filter[];
    NextToken?: string;
}
export type IdentityProviderSummaryList = IdentityProviderSummary[];
export interface ListIdentityProvidersResponse {
    IdentityProviderSummaries: IdentityProviderSummary[];
    NextToken?: string;
}
export interface ListInstancesRequest {
    MaxResults?: number;
    NextToken?: string;
    Filters?: Filter[];
}
export type StringList = string[];
export interface InstanceSummary {
    InstanceId: string;
    Status: string;
    Products: string[];
    LastStatusCheckDate?: string;
    StatusMessage?: string;
    OwnerAccountId?: string;
    IdentityProvider?: IdentityProvider;
}
export type InstanceSummaryList = InstanceSummary[];
export interface ListInstancesResponse {
    InstanceSummaries?: InstanceSummary[];
    NextToken?: string;
}
export interface ListLicenseServerEndpointsRequest {
    MaxResults?: number;
    Filters?: Filter[];
    NextToken?: string;
}
export type LicenseServerEndpointList = LicenseServerEndpoint[];
export interface ListLicenseServerEndpointsResponse {
    LicenseServerEndpoints?: LicenseServerEndpoint[];
    NextToken?: string;
}
export interface ListProductSubscriptionsRequest {
    Product?: string;
    IdentityProvider: IdentityProvider;
    MaxResults?: number;
    Filters?: Filter[];
    NextToken?: string;
}
export interface ProductUserSummary {
    Username: string;
    Product: string;
    IdentityProvider: IdentityProvider;
    Status: string;
    ProductUserArn?: string;
    StatusMessage?: string;
    Domain?: string;
    SubscriptionStartDate?: string;
    SubscriptionEndDate?: string;
    LicenseExpirationDate?: string;
}
export type ProductUserSummaryList = ProductUserSummary[];
export interface ListProductSubscriptionsResponse {
    ProductUserSummaries?: ProductUserSummary[];
    NextToken?: string;
}
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListUserAssociationsRequest {
    InstanceId: string;
    IdentityProvider: IdentityProvider;
    MaxResults?: number;
    Filters?: Filter[];
    NextToken?: string;
}
export type InstanceUserSummaryList = InstanceUserSummary[];
export interface ListUserAssociationsResponse {
    InstanceUserSummaries?: InstanceUserSummary[];
    NextToken?: string;
}
export interface RegisterIdentityProviderRequest {
    IdentityProvider: IdentityProvider;
    Product: string;
    Settings?: Settings;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface RegisterIdentityProviderResponse {
    IdentityProviderSummary: IdentityProviderSummary;
}
export interface StartProductSubscriptionRequest {
    Username: string;
    IdentityProvider: IdentityProvider;
    Product: string;
    Domain?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface StartProductSubscriptionResponse {
    ProductUserSummary: ProductUserSummary;
}
export interface StopProductSubscriptionRequest {
    Username?: string;
    IdentityProvider?: IdentityProvider;
    Product?: string;
    ProductUserArn?: string;
    Domain?: string;
}
export interface StopProductSubscriptionResponse {
    ProductUserSummary: ProductUserSummary;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateSettings {
    AddSubnets: string[];
    RemoveSubnets: string[];
    SecurityGroupId?: string;
}
export interface UpdateIdentityProviderSettingsRequest {
    IdentityProvider?: IdentityProvider;
    Product?: string;
    IdentityProviderArn?: string;
    UpdateSettings: UpdateSettings;
}
export interface UpdateIdentityProviderSettingsResponse {
    IdentityProviderSummary: IdentityProviderSummary;
}
export type AssociateUserError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates the user to an EC2 instance to utilize user-based subscriptions.
 *
 * Your estimated bill for charges on the number of users and related costs will take 48 hours to appear for billing periods that haven't closed (marked as **Pending** billing status) in Amazon Web Services Billing. For more information, see Viewing your monthly charges in the *Amazon Web Services Billing User Guide*.
 */
export declare const associateUser: API.OperationMethod<AssociateUserRequest, AssociateUserResponse, AssociateUserError, Credentials | HttpClient.HttpClient>;
export type CreateLicenseServerEndpointError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a network endpoint for the Remote Desktop Services (RDS) license server.
 */
export declare const createLicenseServerEndpoint: API.OperationMethod<CreateLicenseServerEndpointRequest, CreateLicenseServerEndpointResponse, CreateLicenseServerEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteLicenseServerEndpointError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a `LicenseServerEndpoint` resource.
 */
export declare const deleteLicenseServerEndpoint: API.OperationMethod<DeleteLicenseServerEndpointRequest, DeleteLicenseServerEndpointResponse, DeleteLicenseServerEndpointError, Credentials | HttpClient.HttpClient>;
export type DeregisterIdentityProviderError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deregisters the Active Directory identity provider from License Manager user-based subscriptions.
 */
export declare const deregisterIdentityProvider: API.OperationMethod<DeregisterIdentityProviderRequest, DeregisterIdentityProviderResponse, DeregisterIdentityProviderError, Credentials | HttpClient.HttpClient>;
export type DisassociateUserError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates the user from an EC2 instance providing user-based subscriptions.
 */
export declare const disassociateUser: API.OperationMethod<DisassociateUserRequest, DisassociateUserResponse, DisassociateUserError, Credentials | HttpClient.HttpClient>;
export type ListIdentityProvidersError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the Active Directory identity providers for user-based subscriptions.
 */
export declare const listIdentityProviders: API.PaginatedOperationMethod<ListIdentityProvidersRequest, ListIdentityProvidersResponse, ListIdentityProvidersError, Credentials | HttpClient.HttpClient, IdentityProviderSummary>;
export type ListInstancesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the EC2 instances providing user-based subscriptions.
 */
export declare const listInstances: API.PaginatedOperationMethod<ListInstancesRequest, ListInstancesResponse, ListInstancesError, Credentials | HttpClient.HttpClient, InstanceSummary>;
export type ListLicenseServerEndpointsError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the Remote Desktop Services (RDS) License Server endpoints
 */
export declare const listLicenseServerEndpoints: API.PaginatedOperationMethod<ListLicenseServerEndpointsRequest, ListLicenseServerEndpointsResponse, ListLicenseServerEndpointsError, Credentials | HttpClient.HttpClient, LicenseServerEndpoint>;
export type ListProductSubscriptionsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the user-based subscription products available from an identity provider.
 */
export declare const listProductSubscriptions: API.PaginatedOperationMethod<ListProductSubscriptionsRequest, ListProductSubscriptionsResponse, ListProductSubscriptionsError, Credentials | HttpClient.HttpClient, ProductUserSummary>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the list of tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListUserAssociationsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists user associations for an identity provider.
 */
export declare const listUserAssociations: API.PaginatedOperationMethod<ListUserAssociationsRequest, ListUserAssociationsResponse, ListUserAssociationsError, Credentials | HttpClient.HttpClient, InstanceUserSummary>;
export type RegisterIdentityProviderError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Registers an identity provider for user-based subscriptions.
 */
export declare const registerIdentityProvider: API.OperationMethod<RegisterIdentityProviderRequest, RegisterIdentityProviderResponse, RegisterIdentityProviderError, Credentials | HttpClient.HttpClient>;
export type StartProductSubscriptionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a product subscription for a user with the specified identity provider.
 *
 * Your estimated bill for charges on the number of users and related costs will take 48 hours to appear for billing periods that haven't closed (marked as **Pending** billing status) in Amazon Web Services Billing. For more information, see Viewing your monthly charges in the *Amazon Web Services Billing User Guide*.
 */
export declare const startProductSubscription: API.OperationMethod<StartProductSubscriptionRequest, StartProductSubscriptionResponse, StartProductSubscriptionError, Credentials | HttpClient.HttpClient>;
export type StopProductSubscriptionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a product subscription for a user with the specified identity provider.
 */
export declare const stopProductSubscription: API.OperationMethod<StopProductSubscriptionRequest, StopProductSubscriptionResponse, StopProductSubscriptionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateIdentityProviderSettingsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates additional product configuration settings for the registered identity provider.
 */
export declare const updateIdentityProviderSettings: API.OperationMethod<UpdateIdentityProviderSettingsRequest, UpdateIdentityProviderSettingsResponse, UpdateIdentityProviderSettingsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=license-manager-user-subscriptions.d.ts.map