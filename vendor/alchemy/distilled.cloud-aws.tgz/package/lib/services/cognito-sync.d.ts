import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AlreadyStreamedException_base: S.TaggedErrorClass<"AlreadyStreamedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AlreadyStreamedException extends /*@__PURE__*/ AlreadyStreamedException_base {
}
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const DuplicateRequestException_base: S.TaggedErrorClass<"DuplicateRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicateRequestException extends /*@__PURE__*/ DuplicateRequestException_base {
}
declare const InternalErrorException_base: S.TaggedErrorClass<"InternalErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalErrorException extends /*@__PURE__*/ InternalErrorException_base {
}
declare const InvalidConfigurationException_base: S.TaggedErrorClass<"InvalidConfigurationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidConfigurationException extends /*@__PURE__*/ InvalidConfigurationException_base {
}
declare const InvalidLambdaFunctionOutputException_base: S.TaggedErrorClass<"InvalidLambdaFunctionOutputException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidLambdaFunctionOutputException extends /*@__PURE__*/ InvalidLambdaFunctionOutputException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const LambdaThrottledException_base: S.TaggedErrorClass<"LambdaThrottledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class LambdaThrottledException extends /*@__PURE__*/ LambdaThrottledException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NotAuthorizedException_base: S.TaggedErrorClass<"NotAuthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class NotAuthorizedException extends /*@__PURE__*/ NotAuthorizedException_base {
}
declare const ResourceConflictException_base: S.TaggedErrorClass<"ResourceConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceConflictException extends /*@__PURE__*/ ResourceConflictException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type IdentityPoolId = string;
export interface BulkPublishRequest {
    IdentityPoolId: string;
}
export interface BulkPublishResponse {
    IdentityPoolId?: string;
}
export type IdentityId = string;
export type DatasetName = string;
export interface DeleteDatasetRequest {
    IdentityPoolId: string;
    IdentityId: string;
    DatasetName: string;
}
export interface Dataset {
    IdentityId?: string;
    DatasetName?: string;
    CreationDate?: Date;
    LastModifiedDate?: Date;
    LastModifiedBy?: string;
    DataStorage?: number;
    NumRecords?: number;
}
export interface DeleteDatasetResponse {
    Dataset?: Dataset;
}
export interface DescribeDatasetRequest {
    IdentityPoolId: string;
    IdentityId: string;
    DatasetName: string;
}
export interface DescribeDatasetResponse {
    Dataset?: Dataset;
}
export interface DescribeIdentityPoolUsageRequest {
    IdentityPoolId: string;
}
export interface IdentityPoolUsage {
    IdentityPoolId?: string;
    SyncSessionsCount?: number;
    DataStorage?: number;
    LastModifiedDate?: Date;
}
export interface DescribeIdentityPoolUsageResponse {
    IdentityPoolUsage?: IdentityPoolUsage;
}
export interface DescribeIdentityUsageRequest {
    IdentityPoolId: string;
    IdentityId: string;
}
export interface IdentityUsage {
    IdentityId?: string;
    IdentityPoolId?: string;
    LastModifiedDate?: Date;
    DatasetCount?: number;
    DataStorage?: number;
}
export interface DescribeIdentityUsageResponse {
    IdentityUsage?: IdentityUsage;
}
export interface GetBulkPublishDetailsRequest {
    IdentityPoolId: string;
}
export type BulkPublishStatus = "NOT_STARTED" | "IN_PROGRESS" | "FAILED" | "SUCCEEDED" | (string & {});
export interface GetBulkPublishDetailsResponse {
    IdentityPoolId?: string;
    BulkPublishStartTime?: Date;
    BulkPublishCompleteTime?: Date;
    BulkPublishStatus?: BulkPublishStatus;
    FailureMessage?: string;
}
export interface GetCognitoEventsRequest {
    IdentityPoolId: string;
}
export type CognitoEventType = string;
export type LambdaFunctionArn = string;
export type Events = {
    [key: string]: string | undefined;
};
export interface GetCognitoEventsResponse {
    Events?: {
        [key: string]: string | undefined;
    };
}
export interface GetIdentityPoolConfigurationRequest {
    IdentityPoolId: string;
}
export type ApplicationArn = string;
export type ApplicationArnList = string[];
export type AssumeRoleArn = string;
export interface PushSync {
    ApplicationArns?: string[];
    RoleArn?: string;
}
export type StreamName = string;
export type StreamingStatus = "ENABLED" | "DISABLED" | (string & {});
export interface CognitoStreams {
    StreamName?: string;
    RoleArn?: string;
    StreamingStatus?: StreamingStatus;
}
export interface GetIdentityPoolConfigurationResponse {
    IdentityPoolId?: string;
    PushSync?: PushSync;
    CognitoStreams?: CognitoStreams;
}
export type IntegerString = number;
export interface ListDatasetsRequest {
    IdentityPoolId: string;
    IdentityId: string;
    NextToken?: string;
    MaxResults?: number;
}
export type DatasetList = Dataset[];
export interface ListDatasetsResponse {
    Datasets?: Dataset[];
    Count?: number;
    NextToken?: string;
}
export interface ListIdentityPoolUsageRequest {
    NextToken?: string;
    MaxResults?: number;
}
export type IdentityPoolUsageList = IdentityPoolUsage[];
export interface ListIdentityPoolUsageResponse {
    IdentityPoolUsages?: IdentityPoolUsage[];
    MaxResults?: number;
    Count?: number;
    NextToken?: string;
}
export type SyncSessionToken = string;
export interface ListRecordsRequest {
    IdentityPoolId: string;
    IdentityId: string;
    DatasetName: string;
    LastSyncCount?: number;
    NextToken?: string;
    MaxResults?: number;
    SyncSessionToken?: string;
}
export type RecordKey = string;
export type RecordValue = string;
export interface Record {
    Key?: string;
    Value?: string;
    SyncCount?: number;
    LastModifiedDate?: Date;
    LastModifiedBy?: string;
    DeviceLastModifiedDate?: Date;
}
export type RecordList = Record[];
export type MergedDatasetNameList = string[];
export interface ListRecordsResponse {
    Records?: Record[];
    NextToken?: string;
    Count?: number;
    DatasetSyncCount?: number;
    LastModifiedBy?: string;
    MergedDatasetNames?: string[];
    DatasetExists?: boolean;
    DatasetDeletedAfterRequestedSyncCount?: boolean;
    SyncSessionToken?: string;
}
export type Platform = "APNS" | "APNS_SANDBOX" | "GCM" | "ADM" | (string & {});
export type PushToken = string;
export interface RegisterDeviceRequest {
    IdentityPoolId: string;
    IdentityId: string;
    Platform: Platform;
    Token: string;
}
export type DeviceId = string;
export interface RegisterDeviceResponse {
    DeviceId?: string;
}
export interface SetCognitoEventsRequest {
    IdentityPoolId: string;
    Events: {
        [key: string]: string | undefined;
    };
}
export interface SetCognitoEventsResponse {
}
export interface SetIdentityPoolConfigurationRequest {
    IdentityPoolId: string;
    PushSync?: PushSync;
    CognitoStreams?: CognitoStreams;
}
export interface SetIdentityPoolConfigurationResponse {
    IdentityPoolId?: string;
    PushSync?: PushSync;
    CognitoStreams?: CognitoStreams;
}
export interface SubscribeToDatasetRequest {
    IdentityPoolId: string;
    IdentityId: string;
    DatasetName: string;
    DeviceId: string;
}
export interface SubscribeToDatasetResponse {
}
export interface UnsubscribeFromDatasetRequest {
    IdentityPoolId: string;
    IdentityId: string;
    DatasetName: string;
    DeviceId: string;
}
export interface UnsubscribeFromDatasetResponse {
}
export type Operation = "replace" | "remove" | (string & {});
export interface RecordPatch {
    Op: Operation;
    Key: string;
    Value?: string;
    SyncCount: number;
    DeviceLastModifiedDate?: Date;
}
export type RecordPatchList = RecordPatch[];
export type ClientContext = string;
export interface UpdateRecordsRequest {
    IdentityPoolId: string;
    IdentityId: string;
    DatasetName: string;
    DeviceId?: string;
    RecordPatches?: RecordPatch[];
    SyncSessionToken: string;
    ClientContext?: string;
}
export interface UpdateRecordsResponse {
    Records?: Record[];
}
export type ExceptionMessage = string;
export type BulkPublishError = AlreadyStreamedException | DuplicateRequestException | InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | CommonErrors;
/**
 * Initiates a bulk publish of all existing datasets for an Identity Pool to the configured stream. Customers are limited to one successful bulk publish per 24 hours. Bulk publish is an asynchronous request, customers can see the status of the request via the GetBulkPublishDetails operation.
 *
 * This API can only be called with developer credentials. You cannot call this API with the temporary user credentials provided by Cognito Identity.
 */
export declare const bulkPublish: API.OperationMethod<BulkPublishRequest, BulkPublishResponse, BulkPublishError, Credentials | HttpClient.HttpClient>;
export type DeleteDatasetError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceConflictException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the specific dataset. The dataset will be deleted permanently, and the action can't
 * be undone. Datasets that this dataset was merged with will no longer report the merge. Any
 * subsequent operation on this dataset will result in a
 * ResourceNotFoundException.
 *
 * This API can be called with temporary user credentials provided by Cognito Identity or with developer credentials.
 */
export declare const deleteDataset: API.OperationMethod<DeleteDatasetRequest, DeleteDatasetResponse, DeleteDatasetError, Credentials | HttpClient.HttpClient>;
export type DescribeDatasetError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets meta data about a dataset by identity and dataset name. With Amazon Cognito Sync, each
 * identity has access only to its own data. Thus, the credentials used to make this API call
 * need to have access to the identity data.
 *
 * This API can be called with temporary user credentials provided by Cognito Identity or with developer credentials. You should use Cognito Identity credentials to make this API call.
 */
export declare const describeDataset: API.OperationMethod<DescribeDatasetRequest, DescribeDatasetResponse, DescribeDatasetError, Credentials | HttpClient.HttpClient>;
export type DescribeIdentityPoolUsageError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets usage details (for example, data storage) about a particular identity pool.
 *
 * This API can only be called with developer credentials. You cannot call this API with the temporary user credentials provided by Cognito Identity.
 *
 * DescribeIdentityPoolUsage
 * The following examples have been edited for readability.
 *
 * POST / HTTP/1.1
 * CONTENT-TYPE: application/json
 * X-AMZN-REQUESTID: 8dc0e749-c8cd-48bd-8520-da6be00d528b
 * X-AMZ-TARGET: com.amazonaws.cognito.sync.model.AWSCognitoSyncService.DescribeIdentityPoolUsage
 * HOST: cognito-sync.us-east-1.amazonaws.com:443
 * X-AMZ-DATE: 20141111T205737Z
 * AUTHORIZATION: AWS4-HMAC-SHA256 Credential=, SignedHeaders=content-type;host;x-amz-date;x-amz-target;x-amzn-requestid, Signature=
 *
 * {
 * "Operation": "com.amazonaws.cognito.sync.model#DescribeIdentityPoolUsage",
 * "Service": "com.amazonaws.cognito.sync.model#AWSCognitoSyncService",
 * "Input":
 * {
 * "IdentityPoolId": "IDENTITY_POOL_ID"
 * }
 * }
 *
 * 1.1 200 OK
 * x-amzn-requestid: 8dc0e749-c8cd-48bd-8520-da6be00d528b
 * content-type: application/json
 * content-length: 271
 * date: Tue, 11 Nov 2014 20:57:37 GMT
 *
 * {
 * "Output":
 * {
 * "__type": "com.amazonaws.cognito.sync.model#DescribeIdentityPoolUsageResponse",
 * "IdentityPoolUsage":
 * {
 * "DataStorage": 0,
 * "IdentityPoolId": "IDENTITY_POOL_ID",
 * "LastModifiedDate": 1.413231134115E9,
 * "SyncSessionsCount": null
 * }
 * },
 * "Version": "1.0"
 * }
 */
export declare const describeIdentityPoolUsage: API.OperationMethod<DescribeIdentityPoolUsageRequest, DescribeIdentityPoolUsageResponse, DescribeIdentityPoolUsageError, Credentials | HttpClient.HttpClient>;
export type DescribeIdentityUsageError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets usage information for an identity, including number of datasets and data usage.
 *
 * This API can be called with temporary user credentials provided by Cognito Identity or with developer credentials.
 *
 * DescribeIdentityUsage
 * The following examples have been edited for readability.
 *
 * POST / HTTP/1.1
 * CONTENT-TYPE: application/json
 * X-AMZN-REQUESTID: 33f9b4e4-a177-4aad-a3bb-6edb7980b283
 * X-AMZ-TARGET: com.amazonaws.cognito.sync.model.AWSCognitoSyncService.DescribeIdentityUsage
 * HOST: cognito-sync.us-east-1.amazonaws.com:443
 * X-AMZ-DATE: 20141111T215129Z
 * AUTHORIZATION: AWS4-HMAC-SHA256 Credential=, SignedHeaders=content-type;host;x-amz-date;x-amz-target;x-amzn-requestid, Signature=
 *
 * {
 * "Operation": "com.amazonaws.cognito.sync.model#DescribeIdentityUsage",
 * "Service": "com.amazonaws.cognito.sync.model#AWSCognitoSyncService",
 * "Input":
 * {
 * "IdentityPoolId": "IDENTITY_POOL_ID",
 * "IdentityId": "IDENTITY_ID"
 * }
 * }
 *
 * 1.1 200 OK
 * x-amzn-requestid: 33f9b4e4-a177-4aad-a3bb-6edb7980b283
 * content-type: application/json
 * content-length: 318
 * date: Tue, 11 Nov 2014 21:51:29 GMT
 *
 * {
 * "Output":
 * {
 * "__type": "com.amazonaws.cognito.sync.model#DescribeIdentityUsageResponse",
 * "IdentityUsage":
 * {
 * "DataStorage": 16,
 * "DatasetCount": 1,
 * "IdentityId": "IDENTITY_ID",
 * "IdentityPoolId": "IDENTITY_POOL_ID",
 * "LastModifiedDate": 1.412974081336E9
 * }
 * },
 * "Version": "1.0"
 * }
 */
export declare const describeIdentityUsage: API.OperationMethod<DescribeIdentityUsageRequest, DescribeIdentityUsageResponse, DescribeIdentityUsageError, Credentials | HttpClient.HttpClient>;
export type GetBulkPublishDetailsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | CommonErrors;
/**
 * Get the status of the last BulkPublish operation for an identity pool.
 *
 * This API can only be called with developer credentials. You cannot call this API with the temporary user credentials provided by Cognito Identity.
 */
export declare const getBulkPublishDetails: API.OperationMethod<GetBulkPublishDetailsRequest, GetBulkPublishDetailsResponse, GetBulkPublishDetailsError, Credentials | HttpClient.HttpClient>;
export type GetCognitoEventsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the events and the corresponding Lambda functions associated with an identity pool.
 *
 * This API can only be called with developer credentials. You cannot call this API with the temporary user credentials provided by Cognito Identity.
 */
export declare const getCognitoEvents: API.OperationMethod<GetCognitoEventsRequest, GetCognitoEventsResponse, GetCognitoEventsError, Credentials | HttpClient.HttpClient>;
export type GetIdentityPoolConfigurationError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the configuration settings of an identity pool.
 *
 * This API can only be called with developer credentials. You cannot call this API with the temporary user credentials provided by Cognito Identity.
 *
 * GetIdentityPoolConfiguration
 * The following examples have been edited for readability.
 *
 * POST / HTTP/1.1
 * CONTENT-TYPE: application/json
 * X-AMZN-REQUESTID: b1cfdd4b-f620-4fe4-be0f-02024a1d33da
 * X-AMZ-TARGET: com.amazonaws.cognito.sync.model.AWSCognitoSyncService.GetIdentityPoolConfiguration
 * HOST: cognito-sync.us-east-1.amazonaws.com
 * X-AMZ-DATE: 20141004T195722Z
 * AUTHORIZATION: AWS4-HMAC-SHA256 Credential=, SignedHeaders=content-type;content-length;host;x-amz-date;x-amz-target, Signature=
 *
 * {
 * "Operation": "com.amazonaws.cognito.sync.model#GetIdentityPoolConfiguration",
 * "Service": "com.amazonaws.cognito.sync.model#AWSCognitoSyncService",
 * "Input":
 * {
 * "IdentityPoolId": "ID_POOL_ID"
 * }
 * }
 *
 * 1.1 200 OK
 * x-amzn-requestid: b1cfdd4b-f620-4fe4-be0f-02024a1d33da
 * date: Sat, 04 Oct 2014 19:57:22 GMT
 * content-type: application/json
 * content-length: 332
 *
 * {
 * "Output":
 * {
 * "__type": "com.amazonaws.cognito.sync.model#GetIdentityPoolConfigurationResponse",
 * "IdentityPoolId": "ID_POOL_ID",
 * "PushSync":
 * {
 * "ApplicationArns": ["PLATFORMARN1", "PLATFORMARN2"],
 * "RoleArn": "ROLEARN"
 * }
 * },
 * "Version": "1.0"
 * }
 */
export declare const getIdentityPoolConfiguration: API.OperationMethod<GetIdentityPoolConfigurationRequest, GetIdentityPoolConfigurationResponse, GetIdentityPoolConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListDatasetsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | TooManyRequestsException | CommonErrors;
/**
 * Lists datasets for an identity. With Amazon Cognito Sync, each identity has access only to
 * its own data. Thus, the credentials used to make this API call need to have access to the
 * identity data.
 *
 * ListDatasets can be called with temporary user credentials provided by Cognito
 * Identity or with developer credentials. You should use the Cognito Identity credentials to
 * make this API call.
 *
 * ListDatasets
 * The following examples have been edited for readability.
 *
 * POST / HTTP/1.1
 * CONTENT-TYPE: application/json
 * X-AMZN-REQUESTID: 15225768-209f-4078-aaed-7494ace9f2db
 * X-AMZ-TARGET: com.amazonaws.cognito.sync.model.AWSCognitoSyncService.ListDatasets
 * HOST: cognito-sync.us-east-1.amazonaws.com:443
 * X-AMZ-DATE: 20141111T215640Z
 * AUTHORIZATION: AWS4-HMAC-SHA256 Credential=, SignedHeaders=content-type;host;x-amz-date;x-amz-target;x-amzn-requestid, Signature=
 *
 * {
 * "Operation": "com.amazonaws.cognito.sync.model#ListDatasets",
 * "Service": "com.amazonaws.cognito.sync.model#AWSCognitoSyncService",
 * "Input":
 * {
 * "IdentityPoolId": "IDENTITY_POOL_ID",
 * "IdentityId": "IDENTITY_ID",
 * "MaxResults": "3"
 * }
 * }
 *
 * 1.1 200 OK
 * x-amzn-requestid: 15225768-209f-4078-aaed-7494ace9f2db, 15225768-209f-4078-aaed-7494ace9f2db
 * content-type: application/json
 * content-length: 355
 * date: Tue, 11 Nov 2014 21:56:40 GMT
 *
 * {
 * "Output":
 * {
 * "__type": "com.amazonaws.cognito.sync.model#ListDatasetsResponse",
 * "Count": 1,
 * "Datasets": [
 * {
 * "CreationDate": 1.412974057151E9,
 * "DataStorage": 16,
 * "DatasetName": "my_list",
 * "IdentityId": "IDENTITY_ID",
 * "LastModifiedBy": "123456789012",
 * "LastModifiedDate": 1.412974057244E9,
 * "NumRecords": 1
 * }],
 * "NextToken": null
 * },
 * "Version": "1.0"
 * }
 */
export declare const listDatasets: API.OperationMethod<ListDatasetsRequest, ListDatasetsResponse, ListDatasetsError, Credentials | HttpClient.HttpClient>;
export type ListIdentityPoolUsageError = InternalErrorException | InvalidParameterException | NotAuthorizedException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of identity pools registered with Cognito.
 *
 * ListIdentityPoolUsage can only be called with developer credentials. You
 * cannot make this API call with the temporary user credentials provided by Cognito
 * Identity.
 *
 * ListIdentityPoolUsage
 * The following examples have been edited for readability.
 *
 * POST / HTTP/1.1
 * CONTENT-TYPE: application/json
 * X-AMZN-REQUESTID: 9be7c425-ef05-48c0-aef3-9f0ff2fe17d3
 * X-AMZ-TARGET: com.amazonaws.cognito.sync.model.AWSCognitoSyncService.ListIdentityPoolUsage
 * HOST: cognito-sync.us-east-1.amazonaws.com:443
 * X-AMZ-DATE: 20141111T211414Z
 * AUTHORIZATION: AWS4-HMAC-SHA256 Credential=, SignedHeaders=content-type;host;x-amz-date;x-amz-target;x-amzn-requestid, Signature=
 *
 * {
 * "Operation": "com.amazonaws.cognito.sync.model#ListIdentityPoolUsage",
 * "Service": "com.amazonaws.cognito.sync.model#AWSCognitoSyncService",
 * "Input":
 * {
 * "MaxResults": "2"
 * }
 * }
 *
 * 1.1 200 OK
 * x-amzn-requestid: 9be7c425-ef05-48c0-aef3-9f0ff2fe17d3
 * content-type: application/json
 * content-length: 519
 * date: Tue, 11 Nov 2014 21:14:14 GMT
 *
 * {
 * "Output":
 * {
 * "__type": "com.amazonaws.cognito.sync.model#ListIdentityPoolUsageResponse",
 * "Count": 2,
 * "IdentityPoolUsages": [
 * {
 * "DataStorage": 0,
 * "IdentityPoolId": "IDENTITY_POOL_ID",
 * "LastModifiedDate": 1.413836234607E9,
 * "SyncSessionsCount": null
 * },
 * {
 * "DataStorage": 0,
 * "IdentityPoolId": "IDENTITY_POOL_ID",
 * "LastModifiedDate": 1.410892165601E9,
 * "SyncSessionsCount": null
 * }],
 * "MaxResults": 2,
 * "NextToken": "dXMtZWFzdC0xOjBjMWJhMDUyLWUwOTgtNDFmYS1hNzZlLWVhYTJjMTI1Zjg2MQ=="
 * },
 * "Version": "1.0"
 * }
 */
export declare const listIdentityPoolUsage: API.OperationMethod<ListIdentityPoolUsageRequest, ListIdentityPoolUsageResponse, ListIdentityPoolUsageError, Credentials | HttpClient.HttpClient>;
export type ListRecordsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | TooManyRequestsException | CommonErrors;
/**
 * Gets paginated records, optionally changed after a particular sync count for a dataset and
 * identity. With Amazon Cognito Sync, each identity has access only to its own data. Thus,
 * the credentials used to make this API call need to have access to the identity data.
 *
 * ListRecords can be called with temporary user credentials provided by Cognito
 * Identity or with developer credentials. You should use Cognito Identity credentials to make
 * this API call.
 *
 * ListRecords
 * The following examples have been edited for readability.
 *
 * POST / HTTP/1.1
 * CONTENT-TYPE: application/json
 * X-AMZN-REQUESTID: b3d2e31e-d6b7-4612-8e84-c9ba288dab5d
 * X-AMZ-TARGET: com.amazonaws.cognito.sync.model.AWSCognitoSyncService.ListRecords
 * HOST: cognito-sync.us-east-1.amazonaws.com:443
 * X-AMZ-DATE: 20141111T183230Z
 * AUTHORIZATION: AWS4-HMAC-SHA256 Credential=, SignedHeaders=content-type;host;x-amz-date;x-amz-target;x-amzn-requestid, Signature=
 *
 * {
 * "Operation": "com.amazonaws.cognito.sync.model#ListRecords",
 * "Service": "com.amazonaws.cognito.sync.model#AWSCognitoSyncService",
 * "Input":
 * {
 * "IdentityPoolId": "IDENTITY_POOL_ID",
 * "IdentityId": "IDENTITY_ID",
 * "DatasetName": "newDataSet"
 * }
 * }
 *
 * 1.1 200 OK
 * x-amzn-requestid: b3d2e31e-d6b7-4612-8e84-c9ba288dab5d
 * content-type: application/json
 * content-length: 623
 * date: Tue, 11 Nov 2014 18:32:30 GMT
 *
 * {
 * "Output":
 * {
 * "__type": "com.amazonaws.cognito.sync.model#ListRecordsResponse",
 * "Count": 0,
 * "DatasetDeletedAfterRequestedSyncCount": false,
 * "DatasetExists": false,
 * "DatasetSyncCount": 0,
 * "LastModifiedBy": null,
 * "MergedDatasetNames": null,
 * "NextToken": null,
 * "Records": [],
 * "SyncSessionToken": "SYNC_SESSION_TOKEN"
 * },
 * "Version": "1.0"
 * }
 */
export declare const listRecords: API.OperationMethod<ListRecordsRequest, ListRecordsResponse, ListRecordsError, Credentials | HttpClient.HttpClient>;
export type RegisterDeviceError = InternalErrorException | InvalidConfigurationException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Registers a device to receive push sync notifications.
 *
 * This API can only be called with temporary credentials provided by Cognito Identity. You cannot call this API with developer credentials.
 *
 * RegisterDevice
 * The following examples have been edited for readability.
 *
 * POST / HTTP/1.1
 * CONTENT-TYPE: application/json
 * X-AMZN-REQUESTID: 368f9200-3eca-449e-93b3-7b9c08d8e185
 * X-AMZ-TARGET: com.amazonaws.cognito.sync.model.AWSCognitoSyncService.RegisterDevice
 * HOST: cognito-sync.us-east-1.amazonaws.com
 * X-AMZ-DATE: 20141004T194643Z
 * X-AMZ-SECURITY-TOKEN:
 * AUTHORIZATION: AWS4-HMAC-SHA256 Credential=, SignedHeaders=content-type;content-length;host;x-amz-date;x-amz-target, Signature=
 *
 * {
 * "Operation": "com.amazonaws.cognito.sync.model#RegisterDevice",
 * "Service": "com.amazonaws.cognito.sync.model#AWSCognitoSyncService",
 * "Input":
 * {
 * "IdentityPoolId": "ID_POOL_ID",
 * "IdentityId": "IDENTITY_ID",
 * "Platform": "GCM",
 * "Token": "PUSH_TOKEN"
 * }
 * }
 *
 * 1.1 200 OK
 * x-amzn-requestid: 368f9200-3eca-449e-93b3-7b9c08d8e185
 * date: Sat, 04 Oct 2014 19:46:44 GMT
 * content-type: application/json
 * content-length: 145
 *
 * {
 * "Output":
 * {
 * "__type": "com.amazonaws.cognito.sync.model#RegisterDeviceResponse",
 * "DeviceId": "5cd28fbe-dd83-47ab-9f83-19093a5fb014"
 * },
 * "Version": "1.0"
 * }
 */
export declare const registerDevice: API.OperationMethod<RegisterDeviceRequest, RegisterDeviceResponse, RegisterDeviceError, Credentials | HttpClient.HttpClient>;
export type SetCognitoEventsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Sets the AWS Lambda function for a given event type for an identity pool. This request only updates the key/value pair specified. Other key/values pairs are not updated. To remove a key value pair, pass a empty value for the particular key.
 *
 * This API can only be called with developer credentials. You cannot call this API with the temporary user credentials provided by Cognito Identity.
 */
export declare const setCognitoEvents: API.OperationMethod<SetCognitoEventsRequest, SetCognitoEventsResponse, SetCognitoEventsError, Credentials | HttpClient.HttpClient>;
export type SetIdentityPoolConfigurationError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Sets the necessary configuration for push sync.
 *
 * This API can only be called with developer credentials. You cannot call this API with the temporary user credentials provided by Cognito Identity.
 *
 * SetIdentityPoolConfiguration
 * The following examples have been edited for readability.
 *
 * POST / HTTP/1.1
 * CONTENT-TYPE: application/json
 * X-AMZN-REQUESTID: a46db021-f5dd-45d6-af5b-7069fa4a211b
 * X-AMZ-TARGET: com.amazonaws.cognito.sync.model.AWSCognitoSyncService.SetIdentityPoolConfiguration
 * HOST: cognito-sync.us-east-1.amazonaws.com
 * X-AMZ-DATE: 20141004T200006Z
 * AUTHORIZATION: AWS4-HMAC-SHA256 Credential=, SignedHeaders=content-type;content-length;host;x-amz-date;x-amz-target, Signature=
 *
 * {
 * "Operation": "com.amazonaws.cognito.sync.model#SetIdentityPoolConfiguration",
 * "Service": "com.amazonaws.cognito.sync.model#AWSCognitoSyncService",
 * "Input":
 * {
 * "IdentityPoolId": "ID_POOL_ID",
 * "PushSync":
 * {
 * "ApplicationArns": ["PLATFORMARN1", "PLATFORMARN2"],
 * "RoleArn": "ROLEARN"
 * }
 * }
 * }
 *
 * 1.1 200 OK
 * x-amzn-requestid: a46db021-f5dd-45d6-af5b-7069fa4a211b
 * date: Sat, 04 Oct 2014 20:00:06 GMT
 * content-type: application/json
 * content-length: 332
 *
 * {
 * "Output":
 * {
 * "__type": "com.amazonaws.cognito.sync.model#SetIdentityPoolConfigurationResponse",
 * "IdentityPoolId": "ID_POOL_ID",
 * "PushSync":
 * {
 * "ApplicationArns": ["PLATFORMARN1", "PLATFORMARN2"],
 * "RoleArn": "ROLEARN"
 * }
 * },
 * "Version": "1.0"
 * }
 */
export declare const setIdentityPoolConfiguration: API.OperationMethod<SetIdentityPoolConfigurationRequest, SetIdentityPoolConfigurationResponse, SetIdentityPoolConfigurationError, Credentials | HttpClient.HttpClient>;
export type SubscribeToDatasetError = InternalErrorException | InvalidConfigurationException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Subscribes to receive notifications when a dataset is modified by another device.
 *
 * This API can only be called with temporary credentials provided by Cognito Identity. You cannot call this API with developer credentials.
 *
 * SubscribeToDataset
 * The following examples have been edited for readability.
 *
 * POST / HTTP/1.1
 * CONTENT-TYPE: application/json
 * X-AMZN-REQUESTID: 8b9932b7-201d-4418-a960-0a470e11de9f
 * X-AMZ-TARGET: com.amazonaws.cognito.sync.model.AWSCognitoSyncService.SubscribeToDataset
 * HOST: cognito-sync.us-east-1.amazonaws.com
 * X-AMZ-DATE: 20141004T195350Z
 * X-AMZ-SECURITY-TOKEN:
 * AUTHORIZATION: AWS4-HMAC-SHA256 Credential=, SignedHeaders=content-type;content-length;host;x-amz-date;x-amz-target, Signature=
 *
 * {
 * "Operation": "com.amazonaws.cognito.sync.model#SubscribeToDataset",
 * "Service": "com.amazonaws.cognito.sync.model#AWSCognitoSyncService",
 * "Input":
 * {
 * "IdentityPoolId": "ID_POOL_ID",
 * "IdentityId": "IDENTITY_ID",
 * "DatasetName": "Rufus",
 * "DeviceId": "5cd28fbe-dd83-47ab-9f83-19093a5fb014"
 * }
 * }
 *
 * 1.1 200 OK
 * x-amzn-requestid: 8b9932b7-201d-4418-a960-0a470e11de9f
 * date: Sat, 04 Oct 2014 19:53:50 GMT
 * content-type: application/json
 * content-length: 99
 *
 * {
 * "Output":
 * {
 * "__type": "com.amazonaws.cognito.sync.model#SubscribeToDatasetResponse"
 * },
 * "Version": "1.0"
 * }
 */
export declare const subscribeToDataset: API.OperationMethod<SubscribeToDatasetRequest, SubscribeToDatasetResponse, SubscribeToDatasetError, Credentials | HttpClient.HttpClient>;
export type UnsubscribeFromDatasetError = InternalErrorException | InvalidConfigurationException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Unsubscribes from receiving notifications when a dataset is modified by another device.
 *
 * This API can only be called with temporary credentials provided by Cognito Identity. You cannot call this API with developer credentials.
 *
 * UnsubscribeFromDataset
 * The following examples have been edited for readability.
 *
 * POST / HTTP/1.1
 * CONTENT-TYPE: application/json
 * X-AMZ-REQUESTSUPERTRACE: true
 * X-AMZN-REQUESTID: 676896d6-14ca-45b1-8029-6d36b10a077e
 * X-AMZ-TARGET: com.amazonaws.cognito.sync.model.AWSCognitoSyncService.UnsubscribeFromDataset
 * HOST: cognito-sync.us-east-1.amazonaws.com
 * X-AMZ-DATE: 20141004T195446Z
 * X-AMZ-SECURITY-TOKEN:
 * AUTHORIZATION: AWS4-HMAC-SHA256 Credential=, SignedHeaders=content-type;content-length;host;x-amz-date;x-amz-target, Signature=
 *
 * {
 * "Operation": "com.amazonaws.cognito.sync.model#UnsubscribeFromDataset",
 * "Service": "com.amazonaws.cognito.sync.model#AWSCognitoSyncService",
 * "Input":
 * {
 * "IdentityPoolId": "ID_POOL_ID",
 * "IdentityId": "IDENTITY_ID",
 * "DatasetName": "Rufus",
 * "DeviceId": "5cd28fbe-dd83-47ab-9f83-19093a5fb014"
 * }
 * }
 *
 * 1.1 200 OK
 * x-amzn-requestid: 676896d6-14ca-45b1-8029-6d36b10a077e
 * date: Sat, 04 Oct 2014 19:54:46 GMT
 * content-type: application/json
 * content-length: 103
 *
 * {
 * "Output":
 * {
 * "__type": "com.amazonaws.cognito.sync.model#UnsubscribeFromDatasetResponse"
 * },
 * "Version": "1.0"
 * }
 */
export declare const unsubscribeFromDataset: API.OperationMethod<UnsubscribeFromDatasetRequest, UnsubscribeFromDatasetResponse, UnsubscribeFromDatasetError, Credentials | HttpClient.HttpClient>;
export type UpdateRecordsError = InternalErrorException | InvalidLambdaFunctionOutputException | InvalidParameterException | LambdaThrottledException | LimitExceededException | NotAuthorizedException | ResourceConflictException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Posts updates to records and adds and deletes records for a dataset and user.
 *
 * The sync count in the record patch is your last known sync count for that record. The server will reject an UpdateRecords request with a ResourceConflictException if you try to patch a record with a new value but a stale sync count.
 *
 * For example, if the sync count on the server is 5 for a key called highScore and you try and submit a new highScore with sync count of 4, the request will be rejected. To obtain the current sync count for a record, call ListRecords. On a successful update of the record, the response returns the new sync count for that record. You should present that sync count the next time you try to update that same record. When the record does not exist, specify the sync count as 0.
 *
 * This API can be called with temporary user credentials provided by Cognito Identity or with developer credentials.
 */
export declare const updateRecords: API.OperationMethod<UpdateRecordsRequest, UpdateRecordsResponse, UpdateRecordsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cognito-sync.d.ts.map