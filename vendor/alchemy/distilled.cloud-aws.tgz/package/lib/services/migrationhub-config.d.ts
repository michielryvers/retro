import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const DryRunOperation_base: S.TaggedErrorClass<"DryRunOperation", {
    readonly message: any;
}>;
export declare class DryRunOperation extends /*@__PURE__*/ DryRunOperation_base {
}
declare const InternalServerError_base: S.TaggedErrorClass<"InternalServerError", {
    readonly message: any;
}>;
export declare class InternalServerError extends /*@__PURE__*/ InternalServerError_base {
}
declare const InvalidInputException_base: S.TaggedErrorClass<"InvalidInputException", {
    readonly message: any;
}>;
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly RetryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type HomeRegion = string;
export type TargetType = "ACCOUNT" | (string & {});
export type TargetId = string;
export interface Target {
    Type: TargetType;
    Id?: string;
}
export type DryRun = boolean;
export interface CreateHomeRegionControlRequest {
    HomeRegion: string;
    Target: Target;
    DryRun?: boolean;
}
export type ControlId = string;
export type RequestedTime = Date;
export interface HomeRegionControl {
    ControlId?: string;
    HomeRegion?: string;
    Target?: Target;
    RequestedTime?: Date;
}
export interface CreateHomeRegionControlResult {
    HomeRegionControl?: HomeRegionControl;
}
export interface DeleteHomeRegionControlRequest {
    ControlId: string;
}
export interface DeleteHomeRegionControlResult {
}
export type DescribeHomeRegionControlsMaxResults = number;
export type Token = string;
export interface DescribeHomeRegionControlsRequest {
    ControlId?: string;
    HomeRegion?: string;
    Target?: Target;
    MaxResults?: number;
    NextToken?: string;
}
export type HomeRegionControls = HomeRegionControl[];
export interface DescribeHomeRegionControlsResult {
    HomeRegionControls?: HomeRegionControl[];
    NextToken?: string;
}
export interface GetHomeRegionRequest {
}
export interface GetHomeRegionResult {
    HomeRegion?: string;
}
export type ErrorMessage = string;
export type RetryAfterSeconds = number;
export type CreateHomeRegionControlError = AccessDeniedException | DryRunOperation | InternalServerError | InvalidInputException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * This API sets up the home region for the calling account only.
 */
export declare const createHomeRegionControl: API.OperationMethod<CreateHomeRegionControlRequest, CreateHomeRegionControlResult, CreateHomeRegionControlError, Credentials | HttpClient.HttpClient>;
export type DeleteHomeRegionControlError = AccessDeniedException | InternalServerError | InvalidInputException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * This operation deletes the home region configuration for the calling account. The operation does not delete discovery or migration tracking data in the home region.
 */
export declare const deleteHomeRegionControl: API.OperationMethod<DeleteHomeRegionControlRequest, DeleteHomeRegionControlResult, DeleteHomeRegionControlError, Credentials | HttpClient.HttpClient>;
export type DescribeHomeRegionControlsError = AccessDeniedException | InternalServerError | InvalidInputException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * This API permits filtering on the `ControlId` and `HomeRegion`
 * fields.
 */
export declare const describeHomeRegionControls: API.PaginatedOperationMethod<DescribeHomeRegionControlsRequest, DescribeHomeRegionControlsResult, DescribeHomeRegionControlsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetHomeRegionError = AccessDeniedException | InternalServerError | InvalidInputException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns the calling account's home region, if configured. This API is used by other AWS
 * services to determine the regional endpoint for calling AWS Application Discovery Service and
 * Migration Hub. You must call `GetHomeRegion` at least once before you call any
 * other AWS Application Discovery Service and AWS Migration Hub APIs, to obtain the account's
 * Migration Hub home region.
 */
export declare const getHomeRegion: API.OperationMethod<GetHomeRegionRequest, GetHomeRegionResult, GetHomeRegionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=migrationhub-config.d.ts.map