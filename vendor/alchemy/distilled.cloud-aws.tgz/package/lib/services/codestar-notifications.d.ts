import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConfigurationException_base: S.TaggedErrorClass<"ConfigurationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConfigurationException extends /*@__PURE__*/ ConfigurationException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type NotificationRuleName = string | redacted.Redacted<string>;
export type EventTypeId = string;
export type EventTypeIds = string[];
export type NotificationRuleResource = string;
export type TargetType = string;
export type TargetAddress = string | redacted.Redacted<string>;
export interface Target {
    TargetType?: string;
    TargetAddress?: string | redacted.Redacted<string>;
}
export type Targets = Target[];
export type DetailType = "BASIC" | "FULL" | (string & {});
export type ClientRequestToken = string;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export type NotificationRuleStatus = "ENABLED" | "DISABLED" | (string & {});
export interface CreateNotificationRuleRequest {
    Name: string | redacted.Redacted<string>;
    EventTypeIds: string[];
    Resource: string;
    Targets: Target[];
    DetailType: DetailType;
    ClientRequestToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Status?: NotificationRuleStatus;
}
export type NotificationRuleArn = string;
export interface CreateNotificationRuleResult {
    Arn?: string;
}
export interface DeleteNotificationRuleRequest {
    Arn: string;
}
export interface DeleteNotificationRuleResult {
    Arn?: string;
}
export type ForceUnsubscribeAll = boolean;
export interface DeleteTargetRequest {
    TargetAddress: string | redacted.Redacted<string>;
    ForceUnsubscribeAll?: boolean;
}
export interface DeleteTargetResult {
}
export interface DescribeNotificationRuleRequest {
    Arn: string;
}
export type ServiceName = string;
export type EventTypeName = string;
export type ResourceType = string;
export interface EventTypeSummary {
    EventTypeId?: string;
    ServiceName?: string;
    EventTypeName?: string;
    ResourceType?: string;
}
export type EventTypeBatch = EventTypeSummary[];
export type TargetStatus = "PENDING" | "ACTIVE" | "UNREACHABLE" | "INACTIVE" | "DEACTIVATED" | (string & {});
export interface TargetSummary {
    TargetAddress?: string | redacted.Redacted<string>;
    TargetType?: string;
    TargetStatus?: TargetStatus;
}
export type TargetsBatch = TargetSummary[];
export type NotificationRuleCreatedBy = string;
export type CreatedTimestamp = Date;
export type LastModifiedTimestamp = Date;
export interface DescribeNotificationRuleResult {
    Arn: string;
    Name?: string | redacted.Redacted<string>;
    EventTypes?: EventTypeSummary[];
    Resource?: string;
    Targets?: TargetSummary[];
    DetailType?: DetailType;
    CreatedBy?: string;
    Status?: NotificationRuleStatus;
    CreatedTimestamp?: Date;
    LastModifiedTimestamp?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type ListEventTypesFilterName = "RESOURCE_TYPE" | "SERVICE_NAME" | (string & {});
export type ListEventTypesFilterValue = string;
export interface ListEventTypesFilter {
    Name: ListEventTypesFilterName;
    Value: string;
}
export type ListEventTypesFilters = ListEventTypesFilter[];
export type NextToken = string;
export type MaxResults = number;
export interface ListEventTypesRequest {
    Filters?: ListEventTypesFilter[];
    NextToken?: string;
    MaxResults?: number;
}
export interface ListEventTypesResult {
    EventTypes?: EventTypeSummary[];
    NextToken?: string;
}
export type ListNotificationRulesFilterName = "EVENT_TYPE_ID" | "CREATED_BY" | "RESOURCE" | "TARGET_ADDRESS" | (string & {});
export type ListNotificationRulesFilterValue = string;
export interface ListNotificationRulesFilter {
    Name: ListNotificationRulesFilterName;
    Value: string;
}
export type ListNotificationRulesFilters = ListNotificationRulesFilter[];
export interface ListNotificationRulesRequest {
    Filters?: ListNotificationRulesFilter[];
    NextToken?: string;
    MaxResults?: number;
}
export type NotificationRuleId = string;
export interface NotificationRuleSummary {
    Id?: string;
    Arn?: string;
}
export type NotificationRuleBatch = NotificationRuleSummary[];
export interface ListNotificationRulesResult {
    NextToken?: string;
    NotificationRules?: NotificationRuleSummary[];
}
export interface ListTagsForResourceRequest {
    Arn: string;
}
export interface ListTagsForResourceResult {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type ListTargetsFilterName = "TARGET_TYPE" | "TARGET_ADDRESS" | "TARGET_STATUS" | (string & {});
export type ListTargetsFilterValue = string;
export interface ListTargetsFilter {
    Name: ListTargetsFilterName;
    Value: string;
}
export type ListTargetsFilters = ListTargetsFilter[];
export interface ListTargetsRequest {
    Filters?: ListTargetsFilter[];
    NextToken?: string;
    MaxResults?: number;
}
export interface ListTargetsResult {
    Targets?: TargetSummary[];
    NextToken?: string;
}
export interface SubscribeRequest {
    Arn: string;
    Target: Target;
    ClientRequestToken?: string;
}
export interface SubscribeResult {
    Arn?: string;
}
export interface TagResourceRequest {
    Arn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResult {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface UnsubscribeRequest {
    Arn: string;
    TargetAddress: string | redacted.Redacted<string>;
}
export interface UnsubscribeResult {
    Arn: string;
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    Arn: string;
    TagKeys: string[];
}
export interface UntagResourceResult {
}
export interface UpdateNotificationRuleRequest {
    Arn: string;
    Name?: string | redacted.Redacted<string>;
    Status?: NotificationRuleStatus;
    EventTypeIds?: string[];
    Targets?: Target[];
    DetailType?: DetailType;
}
export interface UpdateNotificationRuleResult {
}
export type Message = string;
export type CreateNotificationRuleError = AccessDeniedException | ConcurrentModificationException | ConfigurationException | LimitExceededException | ResourceAlreadyExistsException | ValidationException | CommonErrors;
/**
 * Creates a notification rule for a resource. The rule specifies the events you want
 * notifications about and the targets (such as Amazon Q Developer in chat applications topics or Amazon Q Developer in chat applications clients configured for Slack) where you want to receive
 * them.
 */
export declare const createNotificationRule: API.OperationMethod<CreateNotificationRuleRequest, CreateNotificationRuleResult, CreateNotificationRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteNotificationRuleError = ConcurrentModificationException | LimitExceededException | ValidationException | CommonErrors;
/**
 * Deletes a notification rule for a resource.
 */
export declare const deleteNotificationRule: API.OperationMethod<DeleteNotificationRuleRequest, DeleteNotificationRuleResult, DeleteNotificationRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteTargetError = ValidationException | CommonErrors;
/**
 * Deletes a specified target for notifications.
 */
export declare const deleteTarget: API.OperationMethod<DeleteTargetRequest, DeleteTargetResult, DeleteTargetError, Credentials | HttpClient.HttpClient>;
export type DescribeNotificationRuleError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a specified notification rule.
 */
export declare const describeNotificationRule: API.OperationMethod<DescribeNotificationRuleRequest, DescribeNotificationRuleResult, DescribeNotificationRuleError, Credentials | HttpClient.HttpClient>;
export type ListEventTypesError = InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Returns information about the event types available for configuring notifications.
 */
export declare const listEventTypes: API.PaginatedOperationMethod<ListEventTypesRequest, ListEventTypesResult, ListEventTypesError, Credentials | HttpClient.HttpClient, EventTypeSummary>;
export type ListNotificationRulesError = InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Returns a list of the notification rules for an Amazon Web Services account.
 */
export declare const listNotificationRules: API.PaginatedOperationMethod<ListNotificationRulesRequest, ListNotificationRulesResult, ListNotificationRulesError, Credentials | HttpClient.HttpClient, NotificationRuleSummary>;
export type ListTagsForResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of the tags associated with a notification rule.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResult, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTargetsError = InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Returns a list of the notification rule targets for an Amazon Web Services account.
 */
export declare const listTargets: API.PaginatedOperationMethod<ListTargetsRequest, ListTargetsResult, ListTargetsError, Credentials | HttpClient.HttpClient, TargetSummary>;
export type SubscribeError = ConfigurationException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates an association between a notification rule and an Amazon Q Developer in chat applications topic or Amazon Q Developer in chat applications client so that the
 * associated target can receive notifications when the events described in the rule are
 * triggered.
 */
export declare const subscribe: API.OperationMethod<SubscribeRequest, SubscribeResult, SubscribeError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConcurrentModificationException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Associates a set of provided tags with a notification rule.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResult, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UnsubscribeError = ValidationException | CommonErrors;
/**
 * Removes an association between a notification rule and an Amazon Q Developer in chat applications topic so that
 * subscribers to that topic stop receiving notifications when the events described in the
 * rule are triggered.
 */
export declare const unsubscribe: API.OperationMethod<UnsubscribeRequest, UnsubscribeResult, UnsubscribeError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConcurrentModificationException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes the association between one or more provided tags and a notification
 * rule.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResult, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateNotificationRuleError = ConfigurationException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a notification rule for a resource. You can change the events that trigger the
 * notification rule, the status of the rule, and the targets that receive the
 * notifications.
 *
 * To add or remove tags for a notification rule, you must use TagResource and UntagResource.
 */
export declare const updateNotificationRule: API.OperationMethod<UpdateNotificationRuleRequest, UpdateNotificationRuleResult, UpdateNotificationRuleError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=codestar-notifications.d.ts.map