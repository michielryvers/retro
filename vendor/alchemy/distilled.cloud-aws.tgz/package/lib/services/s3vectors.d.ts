import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const KmsDisabledException_base: S.TaggedErrorClass<"KmsDisabledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KmsDisabledException extends /*@__PURE__*/ KmsDisabledException_base {
}
declare const KmsInvalidKeyUsageException_base: S.TaggedErrorClass<"KmsInvalidKeyUsageException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KmsInvalidKeyUsageException extends /*@__PURE__*/ KmsInvalidKeyUsageException_base {
}
declare const KmsInvalidStateException_base: S.TaggedErrorClass<"KmsInvalidStateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KmsInvalidStateException extends /*@__PURE__*/ KmsInvalidStateException_base {
}
declare const KmsNotFoundException_base: S.TaggedErrorClass<"KmsNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KmsNotFoundException extends /*@__PURE__*/ KmsNotFoundException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
export type VectorBucketName = string;
export type VectorBucketArn = string;
export type IndexName = string;
export type DataType = "float32" | (string & {});
export type Dimension = number;
export type DistanceMetric = "euclidean" | "cosine" | (string & {});
export type MetadataKey = string;
export type NonFilterableMetadataKeys = string[];
export interface MetadataConfiguration {
    nonFilterableMetadataKeys: string[];
}
export type SseType = "AES256" | "aws:kms" | (string & {});
export type KmsKeyArn = string;
export interface EncryptionConfiguration {
    sseType?: SseType;
    kmsKeyArn?: string;
}
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export interface CreateIndexInput {
    vectorBucketName?: string;
    vectorBucketArn?: string;
    indexName: string;
    dataType: DataType;
    dimension: number;
    distanceMetric: DistanceMetric;
    metadataConfiguration?: MetadataConfiguration;
    encryptionConfiguration?: EncryptionConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type IndexArn = string;
export interface CreateIndexOutput {
    indexArn: string;
}
export interface CreateVectorBucketInput {
    vectorBucketName: string;
    encryptionConfiguration?: EncryptionConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateVectorBucketOutput {
    vectorBucketArn: string;
}
export interface DeleteIndexInput {
    vectorBucketName?: string;
    indexName?: string;
    indexArn?: string;
}
export interface DeleteIndexOutput {
}
export interface DeleteVectorBucketInput {
    vectorBucketName?: string;
    vectorBucketArn?: string;
}
export interface DeleteVectorBucketOutput {
}
export interface DeleteVectorBucketPolicyInput {
    vectorBucketName?: string;
    vectorBucketArn?: string;
}
export interface DeleteVectorBucketPolicyOutput {
}
export type VectorKey = string;
export type DeleteVectorsInputList = string[];
export interface DeleteVectorsInput {
    vectorBucketName?: string;
    indexName?: string;
    indexArn?: string;
    keys: string[];
}
export interface DeleteVectorsOutput {
}
export interface GetIndexInput {
    vectorBucketName?: string;
    indexName?: string;
    indexArn?: string;
}
export type IndexMode = "CLASSIC" | "ENHANCED" | (string & {});
export interface Index {
    vectorBucketName: string;
    indexName: string;
    indexArn: string;
    creationTime: Date;
    dataType: DataType;
    dimension: number;
    distanceMetric: DistanceMetric;
    metadataConfiguration?: MetadataConfiguration;
    encryptionConfiguration?: EncryptionConfiguration;
    indexMode?: IndexMode;
}
export interface GetIndexOutput {
    index: Index;
}
export interface GetVectorBucketInput {
    vectorBucketName?: string;
    vectorBucketArn?: string;
}
export interface VectorBucket {
    vectorBucketName: string;
    vectorBucketArn: string;
    creationTime: Date;
    encryptionConfiguration?: EncryptionConfiguration;
    defaultIndexMode?: IndexMode;
}
export interface GetVectorBucketOutput {
    vectorBucket: VectorBucket;
}
export interface GetVectorBucketPolicyInput {
    vectorBucketName?: string;
    vectorBucketArn?: string;
}
export type VectorBucketPolicy = string;
export interface GetVectorBucketPolicyOutput {
    policy?: string;
}
export type GetVectorsInputList = string[];
export interface GetVectorsInput {
    vectorBucketName?: string;
    indexName?: string;
    indexArn?: string;
    keys: string[];
    returnData?: boolean;
    returnMetadata?: boolean;
}
export type Float32VectorData = number[];
export type VectorData = {
    float32: number[];
};
export type VectorMetadata = unknown;
export interface GetOutputVector {
    key: string;
    data?: VectorData;
    metadata?: any;
}
export type GetVectorsOutputList = GetOutputVector[];
export interface GetVectorsOutput {
    vectors: GetOutputVector[];
}
export type ListIndexesMaxResults = number;
export type ListIndexesNextToken = string;
export type ListIndexesPrefix = string;
export interface ListIndexesInput {
    vectorBucketName?: string;
    vectorBucketArn?: string;
    maxResults?: number;
    nextToken?: string;
    prefix?: string;
}
export interface IndexSummary {
    vectorBucketName: string;
    indexName: string;
    indexArn: string;
    creationTime: Date;
}
export type ListIndexesOutputList = IndexSummary[];
export interface ListIndexesOutput {
    nextToken?: string;
    indexes: IndexSummary[];
}
export type ResourceARN = string;
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags: {
        [key: string]: string | undefined;
    };
}
export type ListVectorBucketsMaxResults = number;
export type ListVectorBucketsNextToken = string;
export type ListVectorBucketsPrefix = string;
export interface ListVectorBucketsInput {
    maxResults?: number;
    nextToken?: string;
    prefix?: string;
}
export interface VectorBucketSummary {
    vectorBucketName: string;
    vectorBucketArn: string;
    creationTime: Date;
}
export type ListVectorBucketsOutputList = VectorBucketSummary[];
export interface ListVectorBucketsOutput {
    nextToken?: string;
    vectorBuckets: VectorBucketSummary[];
}
export type ListVectorsMaxResults = number;
export type ListVectorsNextToken = string;
export type ListVectorsSegmentCount = number;
export type ListVectorsSegmentIndex = number;
export interface ListVectorsInput {
    vectorBucketName?: string;
    indexName?: string;
    indexArn?: string;
    maxResults?: number;
    nextToken?: string;
    segmentCount?: number;
    segmentIndex?: number;
    returnData?: boolean;
    returnMetadata?: boolean;
}
export interface ListOutputVector {
    key: string;
    data?: VectorData;
    metadata?: any;
}
export type ListVectorsOutputList = ListOutputVector[];
export interface ListVectorsOutput {
    nextToken?: string;
    vectors: ListOutputVector[];
}
export interface PutVectorBucketDefaultIndexModeInput {
    vectorBucketName?: string;
    vectorBucketArn?: string;
    defaultIndexMode: IndexMode;
}
export interface PutVectorBucketDefaultIndexModeOutput {
}
export interface PutVectorBucketPolicyInput {
    vectorBucketName?: string;
    vectorBucketArn?: string;
    policy: string;
}
export interface PutVectorBucketPolicyOutput {
}
export interface PutInputVector {
    key: string;
    data: VectorData;
    metadata?: any;
}
export type PutVectorsInputList = PutInputVector[];
export interface PutVectorsInput {
    vectorBucketName?: string;
    indexName?: string;
    indexArn?: string;
    vectors: PutInputVector[];
}
export interface PutVectorsOutput {
}
export type TopK = number;
export type QueryVectorsNextToken = string;
export interface QueryVectorsInput {
    vectorBucketName?: string;
    indexName?: string;
    indexArn?: string;
    topK: number;
    queryVector: VectorData;
    filter?: any;
    queryMode?: IndexMode;
    returnMetadata?: boolean;
    returnDistance?: boolean;
    nextToken?: string;
}
export interface QueryOutputVector {
    distance?: number;
    key: string;
    metadata?: any;
}
export type QueryVectorsOutputList = QueryOutputVector[];
export interface QueryVectorsOutput {
    vectors: QueryOutputVector[];
    distanceMetric: DistanceMetric;
    nextToken?: string;
}
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateIndexModeInput {
    vectorBucketName?: string;
    indexName?: string;
    indexArn?: string;
    indexMode: IndexMode;
}
export interface UpdateIndexModeOutput {
}
export type ExceptionMessage = string;
export type CreateIndexError = ConflictException | NotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a vector index within a vector bucket. To specify the vector bucket, you must use either the vector bucket name or the vector bucket Amazon Resource Name (ARN).
 *
 * ### Permissions
 *
 * You must have the `s3vectors:CreateIndex` permission to use this operation.
 *
 * You must have the `s3vectors:TagResource` permission in addition to `s3vectors:CreateIndex` permission to create a vector index with tags.
 */
export declare const createIndex: API.OperationMethod<CreateIndexInput, CreateIndexOutput, CreateIndexError, Credentials | HttpClient.HttpClient>;
export type CreateVectorBucketError = ConflictException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a vector bucket in the Amazon Web Services Region that you want your bucket to be in.
 *
 * ### Permissions
 *
 * You must have the `s3vectors:CreateVectorBucket` permission to use this operation.
 *
 * You must have the `s3vectors:TagResource` permission in addition to `s3vectors:CreateVectorBucket` permission to create a vector bucket with tags.
 */
export declare const createVectorBucket: API.OperationMethod<CreateVectorBucketInput, CreateVectorBucketOutput, CreateVectorBucketError, Credentials | HttpClient.HttpClient>;
export type DeleteIndexError = NotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes a vector index. To specify the vector index, you can either use both the vector bucket name and vector index name, or use the vector index Amazon Resource Name (ARN).
 *
 * ### Permissions
 *
 * You must have the `s3vectors:DeleteIndex` permission to use this operation.
 */
export declare const deleteIndex: API.OperationMethod<DeleteIndexInput, DeleteIndexOutput, DeleteIndexError, Credentials | HttpClient.HttpClient>;
export type DeleteVectorBucketError = ConflictException | NotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes a vector bucket. All vector indexes in the vector bucket must be deleted before the vector bucket can be deleted. To perform this operation, you must use either the vector bucket name or the vector bucket Amazon Resource Name (ARN).
 *
 * ### Permissions
 *
 * You must have the `s3vectors:DeleteVectorBucket` permission to use this operation.
 */
export declare const deleteVectorBucket: API.OperationMethod<DeleteVectorBucketInput, DeleteVectorBucketOutput, DeleteVectorBucketError, Credentials | HttpClient.HttpClient>;
export type DeleteVectorBucketPolicyError = NotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes a vector bucket policy. To specify the bucket, you must use either the vector bucket name or the vector bucket Amazon Resource Name (ARN).
 *
 * ### Permissions
 *
 * You must have the `s3vectors:DeleteVectorBucketPolicy` permission to use this operation.
 */
export declare const deleteVectorBucketPolicy: API.OperationMethod<DeleteVectorBucketPolicyInput, DeleteVectorBucketPolicyOutput, DeleteVectorBucketPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteVectorsError = AccessDeniedException | KmsDisabledException | KmsInvalidKeyUsageException | KmsInvalidStateException | KmsNotFoundException | NotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes one or more vectors in a vector index. To specify the vector index, you can either use both the vector bucket name and vector index name, or use the vector index Amazon Resource Name (ARN).
 *
 * ### Permissions
 *
 * You must have the `s3vectors:DeleteVectors` permission to use this operation.
 */
export declare const deleteVectors: API.OperationMethod<DeleteVectorsInput, DeleteVectorsOutput, DeleteVectorsError, Credentials | HttpClient.HttpClient>;
export type GetIndexError = NotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns vector index attributes. To specify the vector index, you can either use both the vector bucket name and the vector index name, or use the vector index Amazon Resource Name (ARN).
 *
 * ### Permissions
 *
 * You must have the `s3vectors:GetIndex` permission to use this operation.
 */
export declare const getIndex: API.OperationMethod<GetIndexInput, GetIndexOutput, GetIndexError, Credentials | HttpClient.HttpClient>;
export type GetVectorBucketError = NotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns vector bucket attributes. To specify the bucket, you must use either the vector bucket name or the vector bucket Amazon Resource Name (ARN).
 *
 * ### Permissions
 *
 * You must have the `s3vectors:GetVectorBucket` permission to use this operation.
 */
export declare const getVectorBucket: API.OperationMethod<GetVectorBucketInput, GetVectorBucketOutput, GetVectorBucketError, Credentials | HttpClient.HttpClient>;
export type GetVectorBucketPolicyError = NotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Gets details about a vector bucket policy. To specify the bucket, you must use either the vector bucket name or the vector bucket Amazon Resource Name (ARN).
 *
 * ### Permissions
 *
 * You must have the `s3vectors:GetVectorBucketPolicy` permission to use this operation.
 */
export declare const getVectorBucketPolicy: API.OperationMethod<GetVectorBucketPolicyInput, GetVectorBucketPolicyOutput, GetVectorBucketPolicyError, Credentials | HttpClient.HttpClient>;
export type GetVectorsError = KmsDisabledException | KmsInvalidKeyUsageException | KmsInvalidStateException | KmsNotFoundException | NotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns vector attributes. To specify the vector index, you can either use both the vector bucket name and the vector index name, or use the vector index Amazon Resource Name (ARN).
 *
 * ### Permissions
 *
 * You must have the `s3vectors:GetVectors` permission to use this operation.
 */
export declare const getVectors: API.OperationMethod<GetVectorsInput, GetVectorsOutput, GetVectorsError, Credentials | HttpClient.HttpClient>;
export type ListIndexesError = NotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of all the vector indexes within the specified vector bucket. To specify the bucket, you must use either the vector bucket name or the vector bucket Amazon Resource Name (ARN).
 *
 * ### Permissions
 *
 * You must have the `s3vectors:ListIndexes` permission to use this operation.
 */
export declare const listIndexes: API.PaginatedOperationMethod<ListIndexesInput, ListIndexesOutput, ListIndexesError, Credentials | HttpClient.HttpClient, IndexSummary>;
export type ListTagsForResourceError = NotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Lists all of the tags applied to a specified Amazon S3 Vectors resource. Each tag is a label consisting of a key and value pair. Tags can help you organize, track costs for, and control access to resources.
 *
 * For a list of S3 resources that support tagging, see Managing tags for Amazon S3 resources.
 *
 * ### Permissions
 *
 * For vector buckets and vector indexes, you must have the `s3vectors:ListTagsForResource` permission to use this operation.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVectorBucketsError = ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of all the vector buckets that are owned by the authenticated sender of the request.
 *
 * ### Permissions
 *
 * You must have the `s3vectors:ListVectorBuckets` permission to use this operation.
 */
export declare const listVectorBuckets: API.PaginatedOperationMethod<ListVectorBucketsInput, ListVectorBucketsOutput, ListVectorBucketsError, Credentials | HttpClient.HttpClient, VectorBucketSummary>;
export type ListVectorsError = AccessDeniedException | NotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * List vectors in the specified vector index. To specify the vector index, you can either use both the vector bucket name and the vector index name, or use the vector index Amazon Resource Name (ARN).
 *
 * `ListVectors` operations proceed sequentially; however, for faster performance on a large number of vectors in a vector index, applications can request a parallel `ListVectors` operation by providing the `segmentCount` and `segmentIndex` parameters.
 *
 * ### Permissions
 *
 * You must have the `s3vectors:ListVectors` permission to use this operation. Additional permissions are required based on the request parameters you specify:
 *
 * - With only `s3vectors:ListVectors` permission, you can list vector keys when `returnData` and `returnMetadata` are both set to false or not specified..
 *
 * - If you set `returnData` or `returnMetadata` to true, you must have both `s3vectors:ListVectors` and `s3vectors:GetVectors` permissions. The request fails with a `403 Forbidden` error if you request vector data or metadata without the `s3vectors:GetVectors` permission.
 */
export declare const listVectors: API.PaginatedOperationMethod<ListVectorsInput, ListVectorsOutput, ListVectorsError, Credentials | HttpClient.HttpClient, ListOutputVector>;
export type PutVectorBucketDefaultIndexModeError = NotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Updates the default index mode for a vector bucket. The updated default applies to vector indexes that you create after the request succeeds. The operation doesn't change existing vector indexes. To specify the vector bucket, you must use either the vector bucket name or the vector bucket Amazon Resource Name (ARN).
 *
 * ### Permissions
 *
 * You must have the `s3vectors:PutVectorBucketDefaultIndexMode` permission to use this operation.
 */
export declare const putVectorBucketDefaultIndexMode: API.OperationMethod<PutVectorBucketDefaultIndexModeInput, PutVectorBucketDefaultIndexModeOutput, PutVectorBucketDefaultIndexModeError, Credentials | HttpClient.HttpClient>;
export type PutVectorBucketPolicyError = NotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a bucket policy for a vector bucket. To specify the bucket, you must use either the vector bucket name or the vector bucket Amazon Resource Name (ARN).
 *
 * ### Permissions
 *
 * You must have the `s3vectors:PutVectorBucketPolicy` permission to use this operation.
 */
export declare const putVectorBucketPolicy: API.OperationMethod<PutVectorBucketPolicyInput, PutVectorBucketPolicyOutput, PutVectorBucketPolicyError, Credentials | HttpClient.HttpClient>;
export type PutVectorsError = AccessDeniedException | KmsDisabledException | KmsInvalidKeyUsageException | KmsInvalidStateException | KmsNotFoundException | NotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Adds one or more vectors to a vector index. To specify the vector index, you can either use both the vector bucket name and the vector index name, or use the vector index Amazon Resource Name (ARN).
 *
 * For more information about limits, see Limitations and restrictions in the *Amazon S3 User Guide*.
 *
 * When inserting vector data into your vector index, you must provide the vector data as `float32` (32-bit floating point) values. If you pass higher-precision values to an Amazon Web Services SDK, S3 Vectors converts the values to 32-bit floating point before storing them, and `GetVectors`, `ListVectors`, and `QueryVectors` operations return the float32 values. Different Amazon Web Services SDKs may have different default numeric types, so ensure your vectors are properly formatted as `float32` values regardless of which SDK you're using. For example, in Python, use `numpy.float32` or explicitly cast your values.
 *
 * ### Permissions
 *
 * You must have the `s3vectors:PutVectors` permission to use this operation.
 */
export declare const putVectors: API.OperationMethod<PutVectorsInput, PutVectorsOutput, PutVectorsError, Credentials | HttpClient.HttpClient>;
export type QueryVectorsError = KmsDisabledException | KmsInvalidKeyUsageException | KmsInvalidStateException | KmsNotFoundException | NotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Performs an approximate nearest neighbor search query in a vector index using a query vector. By default, it returns the keys of approximate nearest neighbors. You can optionally include the computed distance (between the query vector and each vector in the response) and metadata of each vector in the response.
 *
 * To specify the vector index, you can either use both the vector bucket name and the vector index name, or use the vector index Amazon Resource Name (ARN).
 *
 * ### Permissions
 *
 * You must have the `s3vectors:QueryVectors` permission to use this operation. Additional permissions are required based on the request parameters you specify:
 *
 * - With only `s3vectors:QueryVectors` permission, you can retrieve vector keys of approximate nearest neighbors and computed distances between these vectors. This permission is sufficient only when you don't set any metadata filters and don't request metadata (by keeping the `returnMetadata` parameter set to `false` or not specified).
 *
 * - If you specify a metadata filter or set `returnMetadata` to true, you must have both `s3vectors:QueryVectors` and `s3vectors:GetVectors` permissions. The request fails with a `403 Forbidden error` if you request metadata filtering or metadata without the `s3vectors:GetVectors` permission.
 */
export declare const queryVectors: API.PaginatedOperationMethod<QueryVectorsInput, QueryVectorsOutput, QueryVectorsError, Credentials | HttpClient.HttpClient, QueryOutputVector>;
export type TagResourceError = ConflictException | NotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Applies one or more user-defined tags to an Amazon S3 Vectors resource or updates existing tags. Each tag is a label consisting of a key and value pair. Tags can help you organize, track costs for, and control access to your resources. You can add up to 50 tags for each resource.
 *
 * For a list of S3 resources that support tagging, see Managing tags for Amazon S3 resources.
 *
 * ### Permissions
 *
 * For vector buckets and vector indexes, you must have the `s3vectors:TagResource` permission to use this operation.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConflictException | NotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Removes the specified user-defined tags from an Amazon S3 Vectors resource. You can pass one or more tag keys.
 *
 * For a list of S3 resources that support tagging, see Managing tags for Amazon S3 resources.
 *
 * ### Permissions
 *
 * For vector buckets and vector indexes, you must have the `s3vectors:UntagResource` permission to use this operation.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateIndexModeError = NotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Updates the mode for an existing vector index. You can set the mode to `ENHANCED` for any vector index. You can set the mode to `CLASSIC` only for a vector index in a vector bucket created before September 30, 2026. This operation doesn't change the default index mode of the vector bucket or the mode of other vector indexes. Specify the vector index by using its Amazon Resource Name (ARN) or both the vector bucket name and vector index name.
 *
 * ### Permissions
 *
 * You must have the `s3vectors:UpdateIndexMode` permission to use this operation.
 */
export declare const updateIndexMode: API.OperationMethod<UpdateIndexModeInput, UpdateIndexModeOutput, UpdateIndexModeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=s3vectors.d.ts.map