import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials as Creds } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConditionalOperationFailedException_base: S.TaggedErrorClass<"ConditionalOperationFailedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConditionalOperationFailedException extends /*@__PURE__*/ ConditionalOperationFailedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ContactFlowNotPublishedException_base: S.TaggedErrorClass<"ContactFlowNotPublishedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ContactFlowNotPublishedException extends /*@__PURE__*/ ContactFlowNotPublishedException_base {
}
declare const ContactNotFoundException_base: S.TaggedErrorClass<"ContactNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ContactNotFoundException extends /*@__PURE__*/ ContactNotFoundException_base {
}
declare const ContactNotTerminatedException_base: S.TaggedErrorClass<"ContactNotTerminatedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ContactNotTerminatedException extends /*@__PURE__*/ ContactNotTerminatedException_base {
}
declare const DestinationNotAllowedException_base: S.TaggedErrorClass<"DestinationNotAllowedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class DestinationNotAllowedException extends /*@__PURE__*/ DestinationNotAllowedException_base {
}
declare const DuplicateResourceException_base: S.TaggedErrorClass<"DuplicateResourceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DuplicateResourceException extends /*@__PURE__*/ DuplicateResourceException_base {
}
declare const IdempotencyException_base: S.TaggedErrorClass<"IdempotencyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class IdempotencyException extends /*@__PURE__*/ IdempotencyException_base {
}
declare const InternalServiceException_base: S.TaggedErrorClass<"InternalServiceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServiceException extends /*@__PURE__*/ InternalServiceException_base {
}
declare const InvalidActiveRegionException_base: S.TaggedErrorClass<"InvalidActiveRegionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidActiveRegionException extends /*@__PURE__*/ InvalidActiveRegionException_base {
}
declare const InvalidContactFlowException_base: S.TaggedErrorClass<"InvalidContactFlowException", {
    readonly problems: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidContactFlowException extends /*@__PURE__*/ InvalidContactFlowException_base {
}
declare const InvalidContactFlowModuleException_base: S.TaggedErrorClass<"InvalidContactFlowModuleException", {
    readonly Problems: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidContactFlowModuleException extends /*@__PURE__*/ InvalidContactFlowModuleException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const InvalidTestCaseException_base: S.TaggedErrorClass<"InvalidTestCaseException", {
    readonly Problems: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTestCaseException extends /*@__PURE__*/ InvalidTestCaseException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const MaximumResultReturnedException_base: S.TaggedErrorClass<"MaximumResultReturnedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MaximumResultReturnedException extends /*@__PURE__*/ MaximumResultReturnedException_base {
}
declare const OutboundContactNotPermittedException_base: S.TaggedErrorClass<"OutboundContactNotPermittedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class OutboundContactNotPermittedException extends /*@__PURE__*/ OutboundContactNotPermittedException_base {
}
declare const OutputTypeNotFoundException_base: S.TaggedErrorClass<"OutputTypeNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OutputTypeNotFoundException extends /*@__PURE__*/ OutputTypeNotFoundException_base {
}
declare const PropertyValidationException_base: S.TaggedErrorClass<"PropertyValidationException", {
    readonly message: any;
    readonly PropertyList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PropertyValidationException extends /*@__PURE__*/ PropertyValidationException_base {
}
declare const ResourceConflictException_base: S.TaggedErrorClass<"ResourceConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceConflictException extends /*@__PURE__*/ ResourceConflictException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
    readonly ResourceType: any;
    readonly ResourceId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceNotReadyException_base: S.TaggedErrorClass<"ResourceNotReadyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceNotReadyException extends /*@__PURE__*/ ResourceNotReadyException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UserNotFoundException_base: S.TaggedErrorClass<"UserNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserNotFoundException extends /*@__PURE__*/ UserNotFoundException_base {
}
export type InstanceId = string;
export type ResourceId = string;
export type VersionNumber = number;
export interface ActivateEvaluationFormRequest {
    InstanceId: string;
    EvaluationFormId: string;
    EvaluationFormVersion: number;
}
export type ARN = string;
export interface ActivateEvaluationFormResponse {
    EvaluationFormId: string;
    EvaluationFormArn: string;
    EvaluationFormVersion: number;
}
export type DataSetId = string;
export type AWSAccountId = string;
export interface AssociateAnalyticsDataSetRequest {
    InstanceId: string;
    DataSetId: string;
    TargetAccountId?: string;
}
export interface AssociateAnalyticsDataSetResponse {
    DataSetId?: string;
    TargetAccountId?: string;
    ResourceShareId?: string;
    ResourceShareArn?: string;
}
export type Origin = string;
export type ClientToken = string;
export interface AssociateApprovedOriginRequest {
    InstanceId: string;
    Origin: string;
    ClientToken?: string;
}
export interface AssociateApprovedOriginResponse {
}
export type BotName = string;
export type LexRegion = string;
export interface LexBot {
    Name: string;
    LexRegion: string;
}
export type AliasArn = string;
export interface LexV2Bot {
    AliasArn?: string;
}
export interface AssociateBotRequest {
    InstanceId: string;
    LexBot?: LexBot;
    LexV2Bot?: LexV2Bot;
    ClientToken?: string;
}
export interface AssociateBotResponse {
}
export type ContactId = string;
export type AgentResourceId = string;
export interface AssociateContactWithUserRequest {
    InstanceId: string;
    ContactId: string;
    UserId: string;
}
export interface AssociateContactWithUserResponse {
}
export type VocabularyLanguageCode = "ar-AE" | "de-CH" | "de-DE" | "en-AB" | "en-AU" | "en-GB" | "en-IE" | "en-IN" | "en-US" | "en-WL" | "es-ES" | "es-US" | "fr-CA" | "fr-FR" | "hi-IN" | "it-IT" | "ja-JP" | "ko-KR" | "pt-BR" | "pt-PT" | "zh-CN" | "en-NZ" | "en-ZA" | "ca-ES" | "da-DK" | "fi-FI" | "id-ID" | "ms-MY" | "nl-NL" | "no-NO" | "pl-PL" | "sv-SE" | "tl-PH" | (string & {});
export type VocabularyId = string;
export interface AssociateDefaultVocabularyRequest {
    InstanceId: string;
    LanguageCode: VocabularyLanguageCode;
    VocabularyId?: string;
}
export interface AssociateDefaultVocabularyResponse {
}
export type EmailAddressId = string;
export interface AliasConfiguration {
    EmailAddressId: string;
}
export interface AssociateEmailAddressAliasRequest {
    EmailAddressId: string;
    InstanceId: string;
    AliasConfiguration: AliasConfiguration;
    ClientToken?: string;
}
export interface AssociateEmailAddressAliasResponse {
}
export type FlowAssociationResourceType = "SMS_PHONE_NUMBER" | "INBOUND_EMAIL" | "OUTBOUND_EMAIL" | "ANALYTICS_CONNECTOR" | "WHATSAPP_MESSAGING_PHONE_NUMBER" | (string & {});
export interface AssociateFlowRequest {
    InstanceId: string;
    ResourceId: string;
    FlowId: string;
    ResourceType: FlowAssociationResourceType;
}
export interface AssociateFlowResponse {
}
export type HoursOfOperationId = string;
export interface ParentHoursOfOperationConfig {
    HoursOfOperationId?: string;
}
export type ParentHoursOfOperationConfigList = ParentHoursOfOperationConfig[];
export interface AssociateHoursOfOperationsRequest {
    InstanceId: string;
    HoursOfOperationId: string;
    ParentHoursOfOperationConfigs: ParentHoursOfOperationConfig[];
}
export interface AssociateHoursOfOperationsResponse {
}
export type InstanceStorageResourceType = "CHAT_TRANSCRIPTS" | "CALL_RECORDINGS" | "SCHEDULED_REPORTS" | "MEDIA_STREAMS" | "CONTACT_TRACE_RECORDS" | "AGENT_EVENTS" | "REAL_TIME_CONTACT_ANALYSIS_SEGMENTS" | "ATTACHMENTS" | "CONTACT_EVALUATIONS" | "SCREEN_RECORDINGS" | "REAL_TIME_CONTACT_ANALYSIS_CHAT_SEGMENTS" | "REAL_TIME_CONTACT_ANALYSIS_VOICE_SEGMENTS" | "EMAIL_MESSAGES" | (string & {});
export type AssociationId = string;
export type StorageType = "S3" | "KINESIS_VIDEO_STREAM" | "KINESIS_STREAM" | "KINESIS_FIREHOSE" | (string & {});
export type BucketName = string;
export type Prefix = string;
export type EncryptionType = "KMS" | (string & {});
export type KeyId = string;
export interface EncryptionConfig {
    EncryptionType: EncryptionType;
    KeyId: string;
}
export interface S3Config {
    BucketName: string;
    BucketPrefix: string;
    EncryptionConfig?: EncryptionConfig;
}
export type Hours = number;
export interface KinesisVideoStreamConfig {
    Prefix: string;
    RetentionPeriodHours: number;
    EncryptionConfig: EncryptionConfig;
}
export interface KinesisStreamConfig {
    StreamArn: string;
}
export interface KinesisFirehoseConfig {
    FirehoseArn: string;
}
export interface InstanceStorageConfig {
    AssociationId?: string;
    StorageType: StorageType;
    S3Config?: S3Config;
    KinesisVideoStreamConfig?: KinesisVideoStreamConfig;
    KinesisStreamConfig?: KinesisStreamConfig;
    KinesisFirehoseConfig?: KinesisFirehoseConfig;
}
export interface AssociateInstanceStorageConfigRequest {
    InstanceId: string;
    ResourceType: InstanceStorageResourceType;
    StorageConfig: InstanceStorageConfig;
    ClientToken?: string;
}
export interface AssociateInstanceStorageConfigResponse {
    AssociationId?: string;
}
export type FunctionArn = string;
export interface AssociateLambdaFunctionRequest {
    InstanceId: string;
    FunctionArn: string;
    ClientToken?: string;
}
export interface AssociateLambdaFunctionResponse {
}
export interface AssociateLexBotRequest {
    InstanceId: string;
    LexBot: LexBot;
    ClientToken?: string;
}
export interface AssociateLexBotResponse {
}
export type PhoneNumberId = string;
export type ContactFlowId = string;
export interface AssociatePhoneNumberContactFlowRequest {
    PhoneNumberId: string;
    InstanceId: string;
    ContactFlowId: string;
}
export interface AssociatePhoneNumberContactFlowResponse {
}
export type QueueId = string;
export interface EmailAddressConfig {
    EmailAddressId: string;
}
export type EmailAddressConfigList = EmailAddressConfig[];
export interface AssociateQueueEmailAddressesRequest {
    InstanceId: string;
    QueueId: string;
    EmailAddressesConfig: EmailAddressConfig[];
    ClientToken?: string;
}
export interface AssociateQueueEmailAddressesResponse {
}
export type QuickConnectId = string;
export type QuickConnectsList = string[];
export interface AssociateQueueQuickConnectsRequest {
    InstanceId: string;
    QueueId: string;
    QuickConnectIds: string[];
}
export interface AssociateQueueQuickConnectsResponse {
}
export type RoutingProfileId = string;
export type Channel = "VOICE" | "CHAT" | "TASK" | "EMAIL" | (string & {});
export interface RoutingProfileQueueReference {
    QueueId: string;
    Channel: Channel;
}
export type Priority = number;
export type Delay = number;
export interface RoutingProfileQueueConfig {
    QueueReference: RoutingProfileQueueReference;
    Priority: number;
    Delay: number;
}
export type RoutingProfileQueueConfigList = RoutingProfileQueueConfig[];
export interface RoutingProfileManualAssignmentQueueConfig {
    QueueReference: RoutingProfileQueueReference;
}
export type RoutingProfileManualAssignmentQueueConfigList = RoutingProfileManualAssignmentQueueConfig[];
export interface AssociateRoutingProfileQueuesRequest {
    InstanceId: string;
    RoutingProfileId: string;
    QueueConfigs?: RoutingProfileQueueConfig[];
    ManualAssignmentQueueConfigs?: RoutingProfileManualAssignmentQueueConfig[];
}
export interface AssociateRoutingProfileQueuesResponse {
}
export type PEM = string;
export interface AssociateSecurityKeyRequest {
    InstanceId: string;
    Key: string;
    ClientToken?: string;
}
export interface AssociateSecurityKeyResponse {
    AssociationId?: string;
}
export type SecurityProfileId = string;
export interface SecurityProfileItem {
    Id?: string;
}
export type SecurityProfiles = SecurityProfileItem[];
export type EntityType = "USER" | "AI_AGENT" | (string & {});
export type EntityArn = string;
export interface AssociateSecurityProfilesRequest {
    InstanceId: string;
    SecurityProfiles: SecurityProfileItem[];
    EntityType: EntityType;
    EntityArn: string;
}
export interface AssociateSecurityProfilesResponse {
}
export type TrafficDistributionGroupIdOrArn = string;
export type UserId = string;
export interface AssociateTrafficDistributionGroupUserRequest {
    TrafficDistributionGroupId: string;
    UserId: string;
    InstanceId: string;
}
export interface AssociateTrafficDistributionGroupUserResponse {
}
export type PredefinedAttributeName = string;
export type PredefinedAttributeStringValue = string;
export type ProficiencyLevel = number;
export interface UserProficiency {
    AttributeName: string;
    AttributeValue: string;
    Level: number;
}
export type UserProficiencyList = UserProficiency[];
export interface AssociateUserProficienciesRequest {
    InstanceId: string;
    UserId: string;
    UserProficiencies: UserProficiency[];
}
export interface AssociateUserProficienciesResponse {
}
export type WorkspaceId = string;
export type WorkspaceResourceArnList = string[];
export interface AssociateWorkspaceRequest {
    InstanceId: string;
    WorkspaceId: string;
    ResourceArns: string[];
}
export interface SuccessfulBatchAssociationSummary {
    ResourceArn?: string;
}
export type SuccessfulBatchAssociationSummaryList = SuccessfulBatchAssociationSummary[];
export type WorkspaceErrorCode = string;
export type WorkspaceBatchErrorMessage = string;
export interface FailedBatchAssociationSummary {
    ResourceArn?: string;
    ErrorCode?: string;
    ErrorMessage?: string;
}
export type FailedBatchAssociationSummaryList = FailedBatchAssociationSummary[];
export interface AssociateWorkspaceResponse {
    SuccessfulList?: SuccessfulBatchAssociationSummary[];
    FailedList?: FailedBatchAssociationSummary[];
}
export type DataSetIds = string[];
export interface BatchAssociateAnalyticsDataSetRequest {
    InstanceId: string;
    DataSetIds: string[];
    TargetAccountId?: string;
}
export interface AnalyticsDataAssociationResult {
    DataSetId?: string;
    TargetAccountId?: string;
    ResourceShareId?: string;
    ResourceShareArn?: string;
    ResourceShareStatus?: string;
}
export type AnalyticsDataAssociationResults = AnalyticsDataAssociationResult[];
export interface ErrorResult {
    ErrorCode?: string;
    ErrorMessage?: string;
}
export type ErrorResults = ErrorResult[];
export interface BatchAssociateAnalyticsDataSetResponse {
    Created?: AnalyticsDataAssociationResult[];
    Errors?: ErrorResult[];
}
export type DataTableId = string;
export type DataTableName = string;
export interface PrimaryValue {
    AttributeName: string;
    Value: string;
}
export type PrimaryValuesSet = PrimaryValue[];
export interface DataTableLockVersion {
    DataTable?: string;
    Attribute?: string;
    PrimaryValues?: string;
    Value?: string;
}
export type RegionName = string;
export interface DataTableValue {
    PrimaryValues?: PrimaryValue[];
    AttributeName: string;
    Value: string;
    LockVersion?: DataTableLockVersion;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export type DataTableValueList = DataTableValue[];
export interface BatchCreateDataTableValueRequest {
    InstanceId: string;
    DataTableId: string;
    Values: DataTableValue[];
}
export interface BatchCreateDataTableValueSuccessResult {
    PrimaryValues: PrimaryValue[];
    AttributeName: string;
    RecordId: string;
    LockVersion: DataTableLockVersion;
}
export type BatchCreateDataTableValueSuccessResultList = BatchCreateDataTableValueSuccessResult[];
export interface BatchCreateDataTableValueFailureResult {
    PrimaryValues: PrimaryValue[];
    AttributeName: string;
    Message: string;
}
export type BatchCreateDataTableValueFailureResultList = BatchCreateDataTableValueFailureResult[];
export interface BatchCreateDataTableValueResponse {
    Successful: BatchCreateDataTableValueSuccessResult[];
    Failed: BatchCreateDataTableValueFailureResult[];
}
export interface DataTableDeleteValueIdentifier {
    PrimaryValues?: PrimaryValue[];
    AttributeName: string;
    LockVersion: DataTableLockVersion;
}
export type DataTableDeleteValueIdentifierList = DataTableDeleteValueIdentifier[];
export interface BatchDeleteDataTableValueRequest {
    InstanceId: string;
    DataTableId: string;
    Values: DataTableDeleteValueIdentifier[];
}
export interface BatchDeleteDataTableValueSuccessResult {
    PrimaryValues: PrimaryValue[];
    AttributeName: string;
    LockVersion: DataTableLockVersion;
}
export type BatchDeleteDataTableValueSuccessResultList = BatchDeleteDataTableValueSuccessResult[];
export interface BatchDeleteDataTableValueFailureResult {
    PrimaryValues: PrimaryValue[];
    AttributeName: string;
    Message: string;
}
export type BatchDeleteDataTableValueFailureResultList = BatchDeleteDataTableValueFailureResult[];
export interface BatchDeleteDataTableValueResponse {
    Successful: BatchDeleteDataTableValueSuccessResult[];
    Failed: BatchDeleteDataTableValueFailureResult[];
}
export interface DataTableValueIdentifier {
    PrimaryValues?: PrimaryValue[];
    AttributeName: string;
}
export type DataTableValueIdentifierList = DataTableValueIdentifier[];
export interface BatchDescribeDataTableValueRequest {
    InstanceId: string;
    DataTableId: string;
    Values: DataTableValueIdentifier[];
}
export interface PrimaryValueResponse {
    AttributeName?: string;
    AttributeId?: string;
    Value?: string;
}
export type PrimaryValuesResponseSet = PrimaryValueResponse[];
export interface BatchDescribeDataTableValueSuccessResult {
    RecordId: string;
    AttributeId: string;
    PrimaryValues: PrimaryValueResponse[];
    AttributeName: string;
    Value?: string;
    LockVersion: DataTableLockVersion;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export type BatchDescribeDataTableValueSuccessResultList = BatchDescribeDataTableValueSuccessResult[];
export interface BatchDescribeDataTableValueFailureResult {
    PrimaryValues: PrimaryValue[];
    AttributeName: string;
    Message: string;
}
export type BatchDescribeDataTableValueFailureResultList = BatchDescribeDataTableValueFailureResult[];
export interface BatchDescribeDataTableValueResponse {
    Successful: BatchDescribeDataTableValueSuccessResult[];
    Failed: BatchDescribeDataTableValueFailureResult[];
}
export interface BatchDisassociateAnalyticsDataSetRequest {
    InstanceId: string;
    DataSetIds: string[];
    TargetAccountId?: string;
}
export interface BatchDisassociateAnalyticsDataSetResponse {
    Deleted?: string[];
    Errors?: ErrorResult[];
}
export type FileId = string;
export type FileIdList = string[];
export interface BatchGetAttachedFileMetadataRequest {
    FileIds: string[];
    InstanceId: string;
    AssociatedResourceArn: string;
}
export type ISO8601Datetime = string;
export type FileName = string;
export type FileSizeInBytes = number;
export type FileStatusType = "APPROVED" | "REJECTED" | "PROCESSING" | "FAILED" | (string & {});
export type CreatedByInfo = {
    ConnectUserArn: string;
    AWSIdentityArn?: never;
} | {
    ConnectUserArn?: never;
    AWSIdentityArn: string;
};
export type FileUseCaseType = "CONTACT_ANALYSIS" | "EMAIL_MESSAGE" | "EMAIL_MESSAGE_PLAIN_TEXT" | "EMAIL_MESSAGE_REDACTED" | "EMAIL_MESSAGE_PLAIN_TEXT_REDACTED" | "ATTACHMENT" | "VOICE_RECORDING" | (string & {});
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface AttachedFile {
    CreationTime: string;
    FileArn: string;
    FileId: string;
    FileName: string;
    FileSizeInBytes: number;
    FileStatus: FileStatusType;
    CreatedBy?: CreatedByInfo;
    FileUseCaseType?: FileUseCaseType;
    AssociatedResourceArn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type AttachedFilesList = AttachedFile[];
export type ErrorCode = string;
export type ErrorMessage = string;
export interface AttachedFileError {
    ErrorCode?: string;
    ErrorMessage?: string;
    FileId?: string;
}
export type AttachedFileErrorsList = AttachedFileError[];
export interface BatchGetAttachedFileMetadataResponse {
    Files?: AttachedFile[];
    Errors?: AttachedFileError[];
}
export type ResourceArnListMaxLimit100 = string[];
export type ListFlowAssociationResourceType = "WHATSAPP_MESSAGING_PHONE_NUMBER" | "VOICE_PHONE_NUMBER" | "INBOUND_EMAIL" | "OUTBOUND_EMAIL" | "ANALYTICS_CONNECTOR" | (string & {});
export interface BatchGetFlowAssociationRequest {
    InstanceId: string;
    ResourceIds: string[];
    ResourceType?: ListFlowAssociationResourceType;
}
export interface FlowAssociationSummary {
    ResourceId?: string;
    FlowId?: string;
    ResourceType?: ListFlowAssociationResourceType;
}
export type FlowAssociationSummaryList = FlowAssociationSummary[];
export interface BatchGetFlowAssociationResponse {
    FlowAssociationSummaryList?: FlowAssociationSummary[];
}
export type EndpointType = "TELEPHONE_NUMBER" | "VOIP" | "CONTACT_FLOW" | "CONNECT_PHONENUMBER_ARN" | "EMAIL_ADDRESS" | (string & {});
export type EndpointAddress = string;
export interface Endpoint {
    Type?: EndpointType;
    Address?: string;
}
export type RequestIdentifier = string;
export type AttributeName = string;
export type AttributeValue = string;
export type Attributes = {
    [key: string]: string | undefined;
};
export type CampaignId = string;
export interface Campaign {
    CampaignId?: string;
}
export type OutboundStrategyType = "AGENT_FIRST" | (string & {});
export type PostAcceptPreviewTimeoutDurationInSeconds = number;
export interface PostAcceptTimeoutConfig {
    DurationInSeconds: number;
}
export type AllowedUserAction = "CALL" | "DISCARD" | (string & {});
export type AllowedUserActions = AllowedUserAction[];
export interface Preview {
    PostAcceptTimeoutConfig: PostAcceptTimeoutConfig;
    AllowedUserActions: AllowedUserAction[];
}
export interface AgentFirst {
    Preview?: Preview;
}
export interface OutboundStrategyConfig {
    AgentFirst?: AgentFirst;
}
export interface OutboundStrategy {
    Type: OutboundStrategyType;
    Config?: OutboundStrategyConfig;
}
export interface ContactDataRequest {
    SystemEndpoint?: Endpoint;
    CustomerEndpoint?: Endpoint;
    RequestIdentifier?: string;
    QueueId?: string;
    Attributes?: {
        [key: string]: string | undefined;
    };
    Campaign?: Campaign;
    OutboundStrategy?: OutboundStrategy;
}
export type ContactDataRequestList = ContactDataRequest[];
export interface BatchPutContactRequest {
    ClientToken?: string;
    InstanceId: string;
    ContactDataRequestList: ContactDataRequest[];
}
export interface SuccessfulRequest {
    RequestIdentifier?: string;
    ContactId?: string;
}
export type SuccessfulRequestList = SuccessfulRequest[];
export type FailureReasonCode = "INVALID_ATTRIBUTE_KEY" | "INVALID_CUSTOMER_ENDPOINT" | "INVALID_SYSTEM_ENDPOINT" | "INVALID_QUEUE" | "INVALID_OUTBOUND_STRATEGY" | "MISSING_CAMPAIGN" | "MISSING_CUSTOMER_ENDPOINT" | "MISSING_QUEUE_ID_AND_SYSTEM_ENDPOINT" | "REQUEST_THROTTLED" | "IDEMPOTENCY_EXCEPTION" | "INTERNAL_ERROR" | (string & {});
export interface FailedRequest {
    RequestIdentifier?: string;
    FailureReasonCode?: FailureReasonCode;
    FailureReasonMessage?: string;
}
export type FailedRequestList = FailedRequest[];
export interface BatchPutContactResponse {
    SuccessfulRequestList?: SuccessfulRequest[];
    FailedRequestList?: FailedRequest[];
}
export interface BatchUpdateDataTableValueRequest {
    InstanceId: string;
    DataTableId: string;
    Values: DataTableValue[];
}
export interface BatchUpdateDataTableValueSuccessResult {
    PrimaryValues: PrimaryValue[];
    AttributeName: string;
    LockVersion: DataTableLockVersion;
}
export type BatchUpdateDataTableValueSuccessResultList = BatchUpdateDataTableValueSuccessResult[];
export interface BatchUpdateDataTableValueFailureResult {
    PrimaryValues: PrimaryValue[];
    AttributeName: string;
    Message: string;
}
export type BatchUpdateDataTableValueFailureResultList = BatchUpdateDataTableValueFailureResult[];
export interface BatchUpdateDataTableValueResponse {
    Successful: BatchUpdateDataTableValueSuccessResult[];
    Failed: BatchUpdateDataTableValueFailureResult[];
}
export type PhoneNumber = string;
export type PhoneNumberDescription = string;
export interface ClaimPhoneNumberRequest {
    TargetArn?: string;
    InstanceId?: string;
    PhoneNumber: string;
    PhoneNumberDescription?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
}
export interface ClaimPhoneNumberResponse {
    PhoneNumberId?: string;
    PhoneNumberArn?: string;
}
export interface CompleteAttachedFileUploadRequest {
    InstanceId: string;
    FileId: string;
    AssociatedResourceArn: string;
}
export interface CompleteAttachedFileUploadResponse {
}
export type AgentStatusName = string;
export type AgentStatusDescription = string;
export type AgentStatusState = "ENABLED" | "DISABLED" | (string & {});
export type AgentStatusOrderNumber = number;
export interface CreateAgentStatusRequest {
    InstanceId: string;
    Name: string;
    Description?: string;
    State: AgentStatusState;
    DisplayOrder?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type AgentStatusId = string;
export interface CreateAgentStatusResponse {
    AgentStatusARN?: string;
    AgentStatusId?: string;
}
export type FileSourceUri = string;
export interface CreateAttachedFileRequest {
    ClientToken?: string;
    InstanceId: string;
    FileUseCaseType: FileUseCaseType;
    FileSourceUri: string;
    AssociatedResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateAttachedFileResponse {
    FileArn?: string;
    FileId?: string;
    CreationTime?: string;
    FileStatus?: FileStatusType;
}
export type SecurityProfileIds = string[];
export type AuthCodeEntityType = "CUSTOMER_PROFILE" | (string & {});
export type EntityId = string;
export type CustomerProfilesDomainName = string;
export interface AuthScope {
    SecurityProfileIds?: string[];
    EntityType: AuthCodeEntityType;
    EntityId?: string;
    DomainName?: string;
}
export type MaxSessionDurationMinutes = number;
export type SessionInactivityDurationMinutes = number;
export interface CreateAuthCodeRequest {
    InstanceId: string;
    Scope: AuthScope;
    MaxSessionDurationMinutes?: number;
    SessionInactivityDurationMinutes: number;
}
export type AuthCode = string | redacted.Redacted<string>;
export type SessionId = string;
export interface CreateAuthCodeResponse {
    AuthCode?: string | redacted.Redacted<string>;
    SessionId?: string;
    EntityType?: AuthCodeEntityType;
    EntityId?: string;
}
export type ReferenceKey = string;
export type ReferenceValue = string;
export type ReferenceType = "URL" | "ATTACHMENT" | "CONTACT_ANALYSIS" | "NUMBER" | "STRING" | "DATE" | "EMAIL" | "EMAIL_MESSAGE" | "EMAIL_MESSAGE_PLAIN_TEXT" | "EMAIL_MESSAGE_PLAIN_TEXT_REDACTED" | "EMAIL_MESSAGE_REDACTED" | (string & {});
export type ReferenceStatus = "AVAILABLE" | "DELETED" | "APPROVED" | "REJECTED" | "PROCESSING" | "FAILED" | (string & {});
export type ReferenceArn = string;
export type ReferenceStatusReason = string;
export interface Reference {
    Value?: string;
    Type: ReferenceType;
    Status?: ReferenceStatus;
    Arn?: string;
    StatusReason?: string;
}
export type ContactReferences = {
    [key: string]: Reference | undefined;
};
export type ContactInitiationMethod = "INBOUND" | "OUTBOUND" | "TRANSFER" | "QUEUE_TRANSFER" | "CALLBACK" | "API" | "DISCONNECT" | "MONITOR" | "EXTERNAL_OUTBOUND" | "WEBRTC_API" | "AGENT_REPLY" | "FLOW" | (string & {});
export type ExpiryDurationInMinutes = number;
export interface UserInfo {
    UserId?: string;
}
export type InitiateAs = "CONNECTED_TO_USER" | "COMPLETED" | (string & {});
export type Name = string | redacted.Redacted<string>;
export type Description = string | redacted.Redacted<string>;
export type SegmentAttributeName = string;
export type SegmentAttributeValueString = string;
export type SegmentAttributeValueMap = {
    [key: string]: SegmentAttributeValue | undefined;
};
export type SegmentAttributeValueInteger = number;
export type SegmentAttributeValueList = SegmentAttributeValue[];
export interface SegmentAttributeValue {
    ValueString?: string;
    ValueMap?: {
        [key: string]: SegmentAttributeValue | undefined;
    };
    ValueInteger?: number;
    ValueList?: SegmentAttributeValue[];
    ValueArn?: string;
}
export type SegmentAttributes = {
    [key: string]: SegmentAttributeValue | undefined;
};
export interface CreateContactRequest {
    InstanceId: string;
    ClientToken?: string;
    RelatedContactId?: string;
    Attributes?: {
        [key: string]: string | undefined;
    };
    References?: {
        [key: string]: Reference | undefined;
    };
    Channel: Channel;
    InitiationMethod: ContactInitiationMethod;
    ExpiryDurationInMinutes?: number;
    UserInfo?: UserInfo;
    InitiateAs?: InitiateAs;
    Name?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    SegmentAttributes?: {
        [key: string]: SegmentAttributeValue | undefined;
    };
    PreviousContactId?: string;
}
export interface CreateContactResponse {
    ContactId?: string;
    ContactArn?: string;
}
export type ContactFlowName = string;
export type ContactFlowType = "CONTACT_FLOW" | "CUSTOMER_QUEUE" | "CUSTOMER_HOLD" | "CUSTOMER_WHISPER" | "AGENT_HOLD" | "AGENT_WHISPER" | "OUTBOUND_WHISPER" | "AGENT_TRANSFER" | "QUEUE_TRANSFER" | "CAMPAIGN" | (string & {});
export type ContactFlowDescription = string;
export type ContactFlowContent = string;
export type ContactFlowStatus = "PUBLISHED" | "SAVED" | (string & {});
export interface CreateContactFlowRequest {
    InstanceId: string;
    Name: string;
    Type: ContactFlowType;
    Description?: string;
    Content: string;
    Status?: ContactFlowStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type FlowContentSha256 = string;
export interface CreateContactFlowResponse {
    ContactFlowId?: string;
    ContactFlowArn?: string;
    FlowContentSha256?: string;
}
export type ContactFlowModuleName = string;
export type ContactFlowModuleDescription = string;
export type ContactFlowModuleContent = string;
export type FlowModuleSettings = string;
export interface ExternalInvocationConfiguration {
    Enabled?: boolean;
}
export interface CreateContactFlowModuleRequest {
    InstanceId: string;
    Name: string;
    Description?: string;
    Content: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
    Settings?: string;
    ExternalInvocationConfiguration?: ExternalInvocationConfiguration;
}
export type ContactFlowModuleId = string;
export interface CreateContactFlowModuleResponse {
    Id?: string;
    Arn?: string;
}
export type InstanceIdOrArn = string;
export type ResourceVersion = number;
export type ContactFlowModuleAlias = string;
export interface CreateContactFlowModuleAliasRequest {
    InstanceId: string;
    Description?: string;
    ContactFlowModuleId: string;
    ContactFlowModuleVersion: number;
    AliasName: string;
}
export interface CreateContactFlowModuleAliasResponse {
    ContactFlowModuleArn?: string;
    Id?: string;
}
export type FlowModuleContentSha256 = string;
export interface CreateContactFlowModuleVersionRequest {
    InstanceId: string;
    Description?: string;
    ContactFlowModuleId: string;
    FlowModuleContentSha256?: string;
}
export interface CreateContactFlowModuleVersionResponse {
    ContactFlowModuleArn?: string;
    Version?: number;
}
export interface CreateContactFlowVersionRequest {
    InstanceId: string;
    Description?: string;
    ContactFlowId: string;
    FlowContentSha256?: string;
    ContactFlowVersion?: number;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface CreateContactFlowVersionResponse {
    ContactFlowArn?: string;
    Version?: number;
}
export type DataTableDescription = string;
export type TimeZone = string;
export type DataTableLockLevel = "NONE" | "DATA_TABLE" | "PRIMARY_VALUE" | "ATTRIBUTE" | "VALUE" | (string & {});
export type DataTableStatus = "PUBLISHED" | (string & {});
export interface CreateDataTableRequest {
    InstanceId: string;
    Name: string;
    Description?: string;
    TimeZone: string;
    ValueLockLevel: DataTableLockLevel;
    Status: DataTableStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateDataTableResponse {
    Id: string;
    Arn: string;
    LockVersion: DataTableLockVersion;
}
export type DataTableAttributeValueType = "TEXT" | "NUMBER" | "BOOLEAN" | "TEXT_LIST" | "NUMBER_LIST" | (string & {});
export type LengthBoundary = number;
export type ValueBoundary = number;
export type PositiveAndNegativeDouble = number;
export type PositiveDouble = number;
export type ValidationEnumValues = string[];
export interface ValidationEnum {
    Strict?: boolean;
    Values?: string[];
}
export interface Validation {
    MinLength?: number;
    MaxLength?: number;
    MinValues?: number;
    MaxValues?: number;
    IgnoreCase?: boolean;
    Minimum?: number;
    Maximum?: number;
    ExclusiveMinimum?: number;
    ExclusiveMaximum?: number;
    MultipleOf?: number;
    Enum?: ValidationEnum;
}
export interface CreateDataTableAttributeRequest {
    InstanceId: string;
    DataTableId: string;
    Name: string;
    ValueType: DataTableAttributeValueType;
    Description?: string;
    Primary?: boolean;
    Validation?: Validation;
}
export interface CreateDataTableAttributeResponse {
    Name: string;
    AttributeId?: string;
    LockVersion: DataTableLockVersion;
}
export type EmailAddress = string | redacted.Redacted<string>;
export type EmailAddressDisplayName = string | redacted.Redacted<string>;
export interface CreateEmailAddressRequest {
    Description?: string | redacted.Redacted<string>;
    InstanceId: string;
    EmailAddress: string | redacted.Redacted<string>;
    DisplayName?: string | redacted.Redacted<string>;
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
}
export type EmailAddressArn = string;
export interface CreateEmailAddressResponse {
    EmailAddressId?: string;
    EmailAddressArn?: string;
}
export type EvaluationFormTitle = string;
export type EvaluationFormDescription = string;
export type EvaluationFormSectionTitle = string;
export type ReferenceId = string;
export type EvaluationFormQuestionInstructions = string;
export type EvaluationFormItemWeight = number;
export type PerformanceCategoryName = "NEEDS_IMPROVEMENT" | "EXCEEDS_EXPECTATIONS" | (string & {});
export type EvaluationScorePercentage = number;
export interface EvaluationFormScoreThreshold {
    PerformanceCategory: PerformanceCategoryName;
    MinScorePercentage?: number;
    MaxScorePercentage?: number;
}
export type EvaluationFormScoreThresholdList = EvaluationFormScoreThreshold[];
export interface EvaluationFormSection {
    Title: string;
    RefId: string;
    Instructions?: string;
    Items: EvaluationFormItem[];
    Weight?: number;
    IsExcludedFromScoring?: boolean;
    ScoreThresholds?: EvaluationFormScoreThreshold[];
}
export type EvaluationFormQuestionTitle = string;
export type EvaluationFormQuestionType = "TEXT" | "SINGLESELECT" | "NUMERIC" | "MULTISELECT" | "DATETIME" | (string & {});
export type EvaluationFormQuestionAnswerScore = number;
export interface AutomaticFailConfiguration {
    TargetSection?: string;
}
export type PointValue = number;
export interface QuestionOptionPointsConfiguration {
    PointValue: number;
    IsBonus?: boolean;
}
export interface EvaluationFormNumericQuestionOption {
    MinValue: number;
    MaxValue: number;
    Score?: number;
    AutomaticFail?: boolean;
    AutomaticFailConfiguration?: AutomaticFailConfiguration;
    PointsConfiguration?: QuestionOptionPointsConfiguration;
}
export type EvaluationFormNumericQuestionOptionList = EvaluationFormNumericQuestionOption[];
export type NumericQuestionPropertyAutomationLabel = "OVERALL_CUSTOMER_SENTIMENT_SCORE" | "OVERALL_AGENT_SENTIMENT_SCORE" | "CUSTOMER_SENTIMENT_SCORE_WITHOUT_AGENT" | "CUSTOMER_SENTIMENT_SCORE_WITH_AGENT" | "NON_TALK_TIME" | "NON_TALK_TIME_PERCENTAGE" | "NUMBER_OF_INTERRUPTIONS" | "CONTACT_DURATION" | "AGENT_INTERACTION_DURATION" | "CUSTOMER_HOLD_TIME" | "LONGEST_HOLD_DURATION" | "NUMBER_OF_HOLDS" | "AGENT_INTERACTION_AND_HOLD_DURATION" | (string & {});
export interface NumericQuestionPropertyValueAutomation {
    Label: NumericQuestionPropertyAutomationLabel;
}
export type EvaluationFormQuestionAutomationAnswerSourceType = "CONTACT_LENS_DATA" | "GEN_AI" | (string & {});
export interface EvaluationFormQuestionAutomationAnswerSource {
    SourceType: EvaluationFormQuestionAutomationAnswerSourceType;
}
export type EvaluationFormNumericQuestionAutomation = {
    PropertyValue: NumericQuestionPropertyValueAutomation;
    AnswerSource?: never;
} | {
    PropertyValue?: never;
    AnswerSource: EvaluationFormQuestionAutomationAnswerSource;
};
export interface EvaluationFormNumericQuestionProperties {
    MinValue: number;
    MaxValue: number;
    Options?: EvaluationFormNumericQuestionOption[];
    Automation?: EvaluationFormNumericQuestionAutomation;
}
export type EvaluationFormSingleSelectQuestionOptionText = string;
export interface EvaluationFormSingleSelectQuestionOption {
    RefId: string;
    Text: string;
    Score?: number;
    AutomaticFail?: boolean;
    AutomaticFailConfiguration?: AutomaticFailConfiguration;
    PointsConfiguration?: QuestionOptionPointsConfiguration;
}
export type EvaluationFormSingleSelectQuestionOptionList = EvaluationFormSingleSelectQuestionOption[];
export type EvaluationFormSingleSelectQuestionDisplayMode = "DROPDOWN" | "RADIO" | (string & {});
export type SingleSelectQuestionRuleCategoryAutomationLabel = string;
export type SingleSelectQuestionRuleCategoryAutomationCondition = "PRESENT" | "NOT_PRESENT" | (string & {});
export interface SingleSelectQuestionRuleCategoryAutomation {
    Category: string;
    Condition: SingleSelectQuestionRuleCategoryAutomationCondition;
    OptionRefId: string;
}
export type EvaluationFormSingleSelectQuestionAutomationOption = {
    RuleCategory: SingleSelectQuestionRuleCategoryAutomation;
};
export type EvaluationFormSingleSelectQuestionAutomationOptionList = EvaluationFormSingleSelectQuestionAutomationOption[];
export interface EvaluationFormSingleSelectQuestionAutomation {
    Options?: EvaluationFormSingleSelectQuestionAutomationOption[];
    DefaultOptionRefId?: string;
    AnswerSource?: EvaluationFormQuestionAutomationAnswerSource;
}
export interface EvaluationFormSingleSelectQuestionProperties {
    Options: EvaluationFormSingleSelectQuestionOption[];
    DisplayAs?: EvaluationFormSingleSelectQuestionDisplayMode;
    Automation?: EvaluationFormSingleSelectQuestionAutomation;
}
export interface EvaluationFormTextQuestionAutomation {
    AnswerSource?: EvaluationFormQuestionAutomationAnswerSource;
}
export interface EvaluationFormTextQuestionProperties {
    Automation?: EvaluationFormTextQuestionAutomation;
}
export type EvaluationFormMultiSelectQuestionOptionText = string;
export interface EvaluationFormMultiSelectQuestionOption {
    RefId: string;
    Text: string;
    Score?: number;
    AutomaticFail?: boolean;
    AutomaticFailConfiguration?: AutomaticFailConfiguration;
    PointsConfiguration?: QuestionOptionPointsConfiguration;
}
export type EvaluationFormMultiSelectQuestionOptionList = EvaluationFormMultiSelectQuestionOption[];
export type EvaluationFormMultiSelectQuestionDisplayMode = "DROPDOWN" | "CHECKBOX" | (string & {});
export type MultiSelectQuestionRuleCategoryAutomationLabel = string;
export type MultiSelectQuestionRuleCategoryAutomationCondition = "PRESENT" | "NOT_PRESENT" | (string & {});
export type ReferenceIdList = string[];
export interface MultiSelectQuestionRuleCategoryAutomation {
    Category: string;
    Condition: MultiSelectQuestionRuleCategoryAutomationCondition;
    OptionRefIds: string[];
}
export type EvaluationFormMultiSelectQuestionAutomationOption = {
    RuleCategory: MultiSelectQuestionRuleCategoryAutomation;
};
export type EvaluationFormMultiSelectQuestionAutomationOptionList = EvaluationFormMultiSelectQuestionAutomationOption[];
export interface EvaluationFormMultiSelectQuestionAutomation {
    Options?: EvaluationFormMultiSelectQuestionAutomationOption[];
    DefaultOptionRefIds?: string[];
    AnswerSource?: EvaluationFormQuestionAutomationAnswerSource;
}
export interface EvaluationFormMultiSelectQuestionProperties {
    Options: EvaluationFormMultiSelectQuestionOption[];
    DisplayAs?: EvaluationFormMultiSelectQuestionDisplayMode;
    Automation?: EvaluationFormMultiSelectQuestionAutomation;
}
export type EvaluationFormQuestionTypeProperties = {
    Numeric: EvaluationFormNumericQuestionProperties;
    SingleSelect?: never;
    Text?: never;
    MultiSelect?: never;
} | {
    Numeric?: never;
    SingleSelect: EvaluationFormSingleSelectQuestionProperties;
    Text?: never;
    MultiSelect?: never;
} | {
    Numeric?: never;
    SingleSelect?: never;
    Text: EvaluationFormTextQuestionProperties;
    MultiSelect?: never;
} | {
    Numeric?: never;
    SingleSelect?: never;
    Text?: never;
    MultiSelect: EvaluationFormMultiSelectQuestionProperties;
};
export type EvaluationFormItemEnablementSourceType = "QUESTION_REF_ID" | (string & {});
export interface EvaluationFormItemEnablementSource {
    Type: EvaluationFormItemEnablementSourceType;
    RefId?: string;
}
export type EvaluationFormItemEnablementSourceValueType = "OPTION_REF_ID" | (string & {});
export interface EvaluationFormItemEnablementSourceValue {
    Type: EvaluationFormItemEnablementSourceValueType;
    RefId?: string;
}
export type EvaluationFormItemEnablementSourceValueList = EvaluationFormItemEnablementSourceValue[];
export type EvaluationFormItemSourceValuesComparator = "IN" | "NOT_IN" | "ALL_IN" | "EXACT" | (string & {});
export interface EvaluationFormItemEnablementExpression {
    Source: EvaluationFormItemEnablementSource;
    Values: EvaluationFormItemEnablementSourceValue[];
    Comparator: EvaluationFormItemSourceValuesComparator;
}
export type EvaluationFormItemEnablementConditionOperand = {
    Expression: EvaluationFormItemEnablementExpression;
    Condition?: never;
} | {
    Expression?: never;
    Condition: EvaluationFormItemEnablementCondition;
};
export type EvaluationFormItemEnablementConditionOperandList = EvaluationFormItemEnablementConditionOperand[];
export type EvaluationFormItemEnablementOperator = "OR" | "AND" | (string & {});
export interface EvaluationFormItemEnablementCondition {
    Operands: EvaluationFormItemEnablementConditionOperand[];
    Operator?: EvaluationFormItemEnablementOperator;
}
export type EvaluationFormItemEnablementAction = "DISABLE" | "ENABLE" | (string & {});
export interface EvaluationFormItemEnablementConfiguration {
    Condition: EvaluationFormItemEnablementCondition;
    Action: EvaluationFormItemEnablementAction;
    DefaultAction?: EvaluationFormItemEnablementAction;
}
export interface QuestionPointsConfiguration {
    MaxPointValue?: number;
    MinPointValue?: number;
    IsBonus?: boolean;
}
export interface EvaluationFormQuestionScoringConfiguration {
    PointsConfiguration?: QuestionPointsConfiguration;
    IsExcludedFromScoring?: boolean;
    ScoreThresholds?: EvaluationFormScoreThreshold[];
}
export type EvaluationFormMetricType = "BUSINESS_OUTCOME" | (string & {});
export type EvaluationFormMetricName = string;
export interface EvaluationFormMetricConfiguration {
    MetricType: EvaluationFormMetricType;
    MetricName: string;
}
export interface EvaluationFormQuestion {
    Title: string;
    Instructions?: string;
    RefId: string;
    NotApplicableEnabled?: boolean;
    QuestionType: EvaluationFormQuestionType;
    QuestionTypeProperties?: EvaluationFormQuestionTypeProperties;
    Enablement?: EvaluationFormItemEnablementConfiguration;
    Weight?: number;
    ScoringConfiguration?: EvaluationFormQuestionScoringConfiguration;
    MetricConfiguration?: EvaluationFormMetricConfiguration;
}
export type EvaluationFormItem = {
    Section: EvaluationFormSection;
    Question?: never;
} | {
    Section?: never;
    Question: EvaluationFormQuestion;
};
export type EvaluationFormItemsList = EvaluationFormItem[];
export type EvaluationFormScoringMode = "QUESTION_ONLY" | "SECTION_ONLY" | "POINTS_BASED" | (string & {});
export type EvaluationFormScoringStatus = "ENABLED" | "DISABLED" | (string & {});
export interface EvaluationFormScoringStrategy {
    Mode: EvaluationFormScoringMode;
    Status: EvaluationFormScoringStatus;
    ScoreThresholds?: EvaluationFormScoreThreshold[];
}
export interface EvaluationFormAutoEvaluationConfiguration {
    Enabled: boolean;
}
export type BoxedBoolean = boolean;
export type EvaluationReviewNotificationRecipientType = "USER_ID" | (string & {});
export interface EvaluationReviewNotificationRecipientValue {
    UserId?: string;
}
export interface EvaluationReviewNotificationRecipient {
    Type: EvaluationReviewNotificationRecipientType;
    Value: EvaluationReviewNotificationRecipientValue;
}
export type EvaluationReviewNotificationRecipientList = EvaluationReviewNotificationRecipient[];
export interface EvaluationReviewConfiguration {
    ReviewNotificationRecipients: EvaluationReviewNotificationRecipient[];
    EligibilityDays?: number;
}
export type ContactInteractionType = "AGENT" | "AUTOMATED" | "CUSTOMER" | (string & {});
export interface EvaluationFormTargetConfiguration {
    ContactInteractionType: ContactInteractionType;
}
export type EvaluationFormLanguageCode = "de-DE" | "en-US" | "es-ES" | "fr-FR" | "it-IT" | "pt-BR" | "ja-JP" | "ko-KR" | "zh-CN" | "ms-MY" | (string & {});
export interface EvaluationFormLanguageConfiguration {
    FormLanguage?: EvaluationFormLanguageCode;
}
export type EvaluationFormAIVersion = string;
export interface CreateEvaluationFormRequest {
    InstanceId: string;
    Title: string;
    Description?: string;
    Items: EvaluationFormItem[];
    ScoringStrategy?: EvaluationFormScoringStrategy;
    AutoEvaluationConfiguration?: EvaluationFormAutoEvaluationConfiguration;
    ClientToken?: string;
    AsDraft?: boolean;
    Tags?: {
        [key: string]: string | undefined;
    };
    ReviewConfiguration?: EvaluationReviewConfiguration;
    TargetConfiguration?: EvaluationFormTargetConfiguration;
    LanguageConfiguration?: EvaluationFormLanguageConfiguration;
    AIVersion?: string;
}
export interface CreateEvaluationFormResponse {
    EvaluationFormId: string;
    EvaluationFormArn: string;
}
export type ExtractionDefinitionName = string;
export type ExtractionDefinitionPromptHint = string;
export type NotFoundBehaviorType = "USE_DEFAULT_VALUE" | "OMIT" | (string & {});
export type NotFoundDefaultValue = string;
export interface ExtractionDefinitionNotFoundBehavior {
    Behavior: NotFoundBehaviorType;
    DefaultValue?: string;
}
export interface ExtractionConfiguration {
    PromptHint: string;
    NotFoundBehavior?: ExtractionDefinitionNotFoundBehavior;
}
export type ExtractionDefinitionDisplayLabel = string;
export interface ExtractionDefinitionDisplay {
    Label?: string;
}
export interface CreateExtractionDefinitionRequest {
    ClientToken?: string;
    InstanceId: string;
    Name: string;
    ExtractionConfiguration: ExtractionConfiguration;
    Display?: ExtractionDefinitionDisplay;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type ExtractionDefinitionId = string;
export interface CreateExtractionDefinitionResponse {
    ExtractionDefinitionArn: string;
    ExtractionDefinitionId: string;
}
export type CommonNameLength127 = string;
export type HoursOfOperationDescription = string;
export type HoursOfOperationDays = "SUNDAY" | "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | (string & {});
export type Hours24Format = number;
export type MinutesLimit60 = number;
export interface HoursOfOperationTimeSlice {
    Hours: number;
    Minutes: number;
}
export interface HoursOfOperationConfig {
    Day: HoursOfOperationDays;
    StartTime: HoursOfOperationTimeSlice;
    EndTime: HoursOfOperationTimeSlice;
}
export type HoursOfOperationConfigList = HoursOfOperationConfig[];
export interface CreateHoursOfOperationRequest {
    InstanceId: string;
    Name: string;
    Description?: string;
    TimeZone: string;
    Config: HoursOfOperationConfig[];
    ParentHoursOfOperationConfigs?: ParentHoursOfOperationConfig[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateHoursOfOperationResponse {
    HoursOfOperationId?: string;
    HoursOfOperationArn?: string;
}
export type CommonHumanReadableName = string;
export type CommonHumanReadableDescription = string;
export type OverrideDays = "SUNDAY" | "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | (string & {});
export interface OverrideTimeSlice {
    Hours: number;
    Minutes: number;
}
export interface HoursOfOperationOverrideConfig {
    Day?: OverrideDays;
    StartTime?: OverrideTimeSlice;
    EndTime?: OverrideTimeSlice;
}
export type HoursOfOperationOverrideConfigList = HoursOfOperationOverrideConfig[];
export type HoursOfOperationOverrideYearMonthDayDateFormat = string;
export type RecurrenceFrequency = "WEEKLY" | "MONTHLY" | "YEARLY" | (string & {});
export type IntervalPositiveInteger = number;
export type Month = number;
export type MonthList = number[];
export type MonthDay = number;
export type MonthDayList = number[];
export type WeekdayOccurrenceInteger = number;
export type WeekdayOccurrenceList = number[];
export interface RecurrencePattern {
    Frequency: RecurrenceFrequency;
    Interval: number;
    ByMonth?: number[];
    ByMonthDay?: number[];
    ByWeekdayOccurrence?: number[];
}
export interface RecurrenceConfig {
    RecurrencePattern: RecurrencePattern;
}
export type OverrideType = "STANDARD" | "OPEN" | "CLOSED" | (string & {});
export interface CreateHoursOfOperationOverrideRequest {
    InstanceId: string;
    HoursOfOperationId: string;
    Name: string;
    Description?: string;
    Config: HoursOfOperationOverrideConfig[];
    EffectiveFrom: string;
    EffectiveTill: string;
    RecurrenceConfig?: RecurrenceConfig;
    OverrideType?: OverrideType;
}
export type HoursOfOperationOverrideId = string;
export interface CreateHoursOfOperationOverrideResponse {
    HoursOfOperationOverrideId?: string;
}
export type DirectoryType = "SAML" | "CONNECT_MANAGED" | "EXISTING_DIRECTORY" | (string & {});
export type DirectoryAlias = string | redacted.Redacted<string>;
export type DirectoryId = string;
export type InboundCallsEnabled = boolean;
export type OutboundCallsEnabled = boolean;
export interface CreateInstanceRequest {
    ClientToken?: string;
    IdentityManagementType: DirectoryType;
    InstanceAlias?: string | redacted.Redacted<string>;
    DirectoryId?: string;
    InboundCallsEnabled: boolean;
    OutboundCallsEnabled: boolean;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateInstanceResponse {
    Id?: string;
    Arn?: string;
}
export type IntegrationType = "EVENT" | "VOICE_ID" | "PINPOINT_APP" | "WISDOM_ASSISTANT" | "WISDOM_KNOWLEDGE_BASE" | "WISDOM_QUICK_RESPONSES" | "Q_MESSAGE_TEMPLATES" | "CASES_DOMAIN" | "APPLICATION" | "FILE_SCANNER" | "SES_IDENTITY" | "ANALYTICS_CONNECTOR" | "CALL_TRANSFER_CONNECTOR" | "COGNITO_USER_POOL" | "MESSAGE_PROCESSOR" | (string & {});
export type URI = string;
export type SourceApplicationName = string;
export type SourceType = "SALESFORCE" | "ZENDESK" | "CASES" | (string & {});
export interface CreateIntegrationAssociationRequest {
    InstanceId: string;
    IntegrationType: IntegrationType;
    IntegrationArn: string;
    SourceApplicationUrl?: string;
    SourceApplicationName?: string;
    SourceType?: SourceType;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type IntegrationAssociationId = string;
export interface CreateIntegrationAssociationResponse {
    IntegrationAssociationId?: string;
    IntegrationAssociationArn?: string;
}
export type MetricName = string;
export type ComponentAlias = string;
export type MetricId = string;
export type MetricFilterKey = string;
export type MetricFilterNumberConditionComparison = "LESSER" | "LESSER_OR_EQUAL" | "GREATER" | "GREATER_OR_EQUAL" | (string & {});
export type NumberValueList = number[];
export interface MetricFilterNumberCondition {
    Comparison: MetricFilterNumberConditionComparison;
    Values: number[];
}
export type MetricFilterStringConditionComparison = "MATCHES_ANY" | "MATCHES_NONE" | (string & {});
export type StringValueList = string[];
export interface MetricFilterStringCondition {
    Comparison: MetricFilterStringConditionComparison;
    Values: string[];
}
export type MetricFilterBooleanConditionComparison = "IS_TRUE" | "IS_FALSE" | (string & {});
export interface MetricFilterBooleanCondition {
    Comparison: MetricFilterBooleanConditionComparison;
}
export interface MetricFilter {
    MetricFilterKey: string;
    Negate?: boolean;
    NumberCondition?: MetricFilterNumberCondition;
    StringCondition?: MetricFilterStringCondition;
    BooleanCondition?: MetricFilterBooleanCondition;
}
export type MetricFilterList = MetricFilter[];
export interface CalculationComponent {
    Alias: string;
    MetricName?: string;
    MetricId?: string;
    MetricFilters?: MetricFilter[];
}
export type CalculationComponentList = CalculationComponent[];
export type CalculationExpression = string;
export interface MetricCalculation {
    CalculationComponents: CalculationComponent[];
    Calculation: string;
}
export type MetricUnit = "INTEGER" | "DOUBLE" | "PERCENT" | "SECONDS" | (string & {});
export type MetricStatus = "PUBLISHED" | "SAVED" | (string & {});
export type MetricDescription = string;
export type TrendIndicator = "POSITIVE" | "NEGATIVE" | "NEUTRAL" | (string & {});
export interface CreateMetricRequest {
    InstanceId: string;
    Name: string;
    MetricCalculation: MetricCalculation;
    Unit: MetricUnit;
    Status?: MetricStatus;
    ClientToken?: string;
    Description?: string;
    PositiveTrendIndicator?: TrendIndicator;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateMetricResponse {
    MetricArn: string;
    MetricId: string;
}
export type RecipientList = string[];
export type ConfigurableNotificationPriority = "HIGH" | "LOW" | (string & {});
export type LocaleCode = "en_US" | "de_DE" | "es_ES" | "fr_FR" | "id_ID" | "it_IT" | "ja_JP" | "ko_KR" | "pt_BR" | "zh_CN" | "zh_TW" | (string & {});
export type LocalizedString = string;
export type NotificationContent = {
    [key in LocaleCode]?: string;
};
export type NotificationId = string;
export interface CreateNotificationRequest {
    InstanceId: string;
    ExpiresAt?: Date;
    Recipients: string[];
    Priority?: ConfigurableNotificationPriority;
    Content: {
        [key: string]: string | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    };
    PredefinedNotificationId?: string;
    ClientToken?: string;
}
export interface CreateNotificationResponse {
    NotificationId: string;
    NotificationArn: string;
}
export type ParticipantRole = "AGENT" | "CUSTOMER" | "SYSTEM" | "CUSTOM_BOT" | "SUPERVISOR" | (string & {});
export type DisplayName = string;
export type VideoCapability = "SEND" | (string & {});
export type ScreenShareCapability = "SEND" | (string & {});
export interface ParticipantCapabilities {
    Video?: VideoCapability;
    ScreenShare?: ScreenShareCapability;
}
export interface ParticipantDetailsToAdd {
    ParticipantRole?: ParticipantRole;
    DisplayName?: string;
    ParticipantCapabilities?: ParticipantCapabilities;
}
export interface CreateParticipantRequest {
    InstanceId: string;
    ContactId: string;
    ClientToken?: string;
    ParticipantDetails: ParticipantDetailsToAdd;
}
export type ParticipantToken = string;
export interface ParticipantTokenCredentials {
    ParticipantToken?: string;
    Expiry?: string;
}
export type ParticipantId = string;
export interface CreateParticipantResponse {
    ParticipantCredentials?: ParticipantTokenCredentials;
    ParticipantId?: string;
}
export type RehydrationType = "ENTIRE_PAST_SESSION" | "FROM_SEGMENT" | (string & {});
export interface CreatePersistentContactAssociationRequest {
    InstanceId: string;
    InitialContactId: string;
    RehydrationType: RehydrationType;
    SourceContactId: string;
    ClientToken?: string;
}
export interface CreatePersistentContactAssociationResponse {
    ContinuedFromContactId?: string;
}
export type PredefinedAttributeStringValuesList = string[];
export type PredefinedAttributeValues = {
    StringList: string[];
};
export type PredefinedAttributePurposeName = string;
export type PredefinedAttributePurposeNameList = string[];
export type EnableValueValidationOnAssociation = boolean;
export interface InputPredefinedAttributeConfiguration {
    EnableValueValidationOnAssociation?: boolean;
}
export interface CreatePredefinedAttributeRequest {
    InstanceId: string;
    Name: string;
    Values?: PredefinedAttributeValues;
    Purposes?: string[];
    AttributeConfiguration?: InputPredefinedAttributeConfiguration;
}
export interface CreatePredefinedAttributeResponse {
}
export type PromptDescription = string;
export type S3Uri = string;
export interface CreatePromptRequest {
    InstanceId: string;
    Name: string;
    Description?: string;
    S3Uri: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type PromptId = string;
export interface CreatePromptResponse {
    PromptARN?: string;
    PromptId?: string;
}
export type DeviceToken = string;
export type DeviceType = "GCM" | "APNS" | "APNS_SANDBOX" | (string & {});
export type IncludeRawMessage = boolean;
export interface ContactConfiguration {
    ContactId: string;
    ParticipantRole?: ParticipantRole;
    IncludeRawMessage?: boolean;
}
export interface CreatePushNotificationRegistrationRequest {
    InstanceId: string;
    ClientToken?: string;
    PinpointAppArn: string;
    DeviceToken: string;
    DeviceType: DeviceType;
    ContactConfiguration: ContactConfiguration;
}
export type RegistrationId = string;
export interface CreatePushNotificationRegistrationResponse {
    RegistrationId: string;
}
export type QueueDescription = string;
export type OutboundCallerIdName = string;
export interface OutboundCallerConfig {
    OutboundCallerIdName?: string;
    OutboundCallerIdNumberId?: string;
    OutboundFlowId?: string;
}
export interface OutboundEmailConfig {
    OutboundEmailAddressId?: string;
}
export type QueueMaxContacts = number;
export interface CreateQueueRequest {
    InstanceId: string;
    Name: string;
    Description?: string;
    OutboundCallerConfig?: OutboundCallerConfig;
    OutboundEmailConfig?: OutboundEmailConfig;
    HoursOfOperationId: string;
    MaxContacts?: number;
    QuickConnectIds?: string[];
    EmailAddressesConfig?: EmailAddressConfig[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateQueueResponse {
    QueueArn?: string;
    QueueId?: string;
}
export type QuickConnectName = string;
export type QuickConnectDescription = string;
export type QuickConnectType = "USER" | "QUEUE" | "PHONE_NUMBER" | "FLOW" | (string & {});
export interface UserQuickConnectConfig {
    UserId: string;
    ContactFlowId: string;
}
export interface QueueQuickConnectConfig {
    QueueId: string;
    ContactFlowId: string;
}
export interface PhoneNumberQuickConnectConfig {
    PhoneNumber: string;
}
export interface FlowQuickConnectConfig {
    ContactFlowId: string;
}
export interface QuickConnectConfig {
    QuickConnectType: QuickConnectType;
    UserConfig?: UserQuickConnectConfig;
    QueueConfig?: QueueQuickConnectConfig;
    PhoneConfig?: PhoneNumberQuickConnectConfig;
    FlowConfig?: FlowQuickConnectConfig;
}
export interface CreateQuickConnectRequest {
    InstanceId: string;
    Name: string;
    Description?: string;
    QuickConnectConfig: QuickConnectConfig;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateQuickConnectResponse {
    QuickConnectARN?: string;
    QuickConnectId?: string;
}
export type RoutingProfileName = string;
export type RoutingProfileDescription = string;
export type Concurrency = number;
export type BehaviorType = "ROUTE_CURRENT_CHANNEL_ONLY" | "ROUTE_ANY_CHANNEL" | (string & {});
export interface CrossChannelBehavior {
    BehaviorType: BehaviorType;
}
export type WorkloadType = string;
export type WorkloadTypeConcurrencyType = number;
export type ChannelWorkloadBehaviorType = "ROUTE_CURRENT_CHANNEL_CURRENT_WORKLOADTYPE_ONLY" | "ROUTE_CURRENT_CHANNEL_ANY_WORKLOADTYPE_ONLY" | "ROUTE_ANY_CHANNEL_ANY_WORKLOAD_TYPE" | (string & {});
export interface CrossChannelWorkloadBehavior {
    ChannelWorkloadBehaviorType?: ChannelWorkloadBehaviorType;
}
export interface WorkloadTypeConcurrency {
    WorkloadType: string;
    Concurrency: number;
    CrossChannelWorkloadBehavior?: CrossChannelWorkloadBehavior;
}
export type WorkloadTypeConcurrencies = WorkloadTypeConcurrency[];
export interface MediaConcurrency {
    Channel: Channel;
    Concurrency?: number;
    CrossChannelBehavior?: CrossChannelBehavior;
    WorkloadTypeConcurrencies?: WorkloadTypeConcurrency[];
}
export type MediaConcurrencies = MediaConcurrency[];
export type AgentAvailabilityTimer = "TIME_SINCE_LAST_ACTIVITY" | "TIME_SINCE_LAST_INBOUND" | (string & {});
export interface CreateRoutingProfileRequest {
    InstanceId: string;
    Name: string;
    Description: string;
    DefaultOutboundQueueId: string;
    QueueConfigs?: RoutingProfileQueueConfig[];
    ManualAssignmentQueueConfigs?: RoutingProfileManualAssignmentQueueConfig[];
    MediaConcurrencies: MediaConcurrency[];
    Tags?: {
        [key: string]: string | undefined;
    };
    AgentAvailabilityTimer?: AgentAvailabilityTimer;
}
export interface CreateRoutingProfileResponse {
    RoutingProfileArn?: string;
    RoutingProfileId?: string;
}
export type RuleName = string;
export type EventSourceName = "OnPostCallAnalysisAvailable" | "OnRealTimeCallAnalysisAvailable" | "OnRealTimeChatAnalysisAvailable" | "OnPostChatAnalysisAvailable" | "OnAfterCallWorkAvailable" | "OnAfterChatWorkAvailable" | "OnEmailAnalysisAvailable" | "OnZendeskTicketCreate" | "OnZendeskTicketStatusUpdate" | "OnSalesforceCaseCreate" | "OnContactEvaluationSubmit" | "OnMetricDataUpdate" | "OnCaseCreate" | "OnCaseUpdate" | "OnSlaBreach" | "OnAlertUpdate" | "OnSchedulePublish" | "OnScheduleUpdate" | "OnScheduleTimeOffRequestActivity" | (string & {});
export interface RuleTriggerEventSource {
    EventSourceName: EventSourceName;
    IntegrationAssociationId?: string;
}
export type RuleFunction = string;
export type ActionType = "CREATE_TASK" | "ASSIGN_CONTACT_CATEGORY" | "GENERATE_EVENTBRIDGE_EVENT" | "SEND_NOTIFICATION" | "CREATE_CASE" | "UPDATE_CASE" | "ASSIGN_SLA" | "END_ASSOCIATED_TASKS" | "SUBMIT_AUTO_EVALUATION" | "EXTRACT_INFORMATION" | "SEND_IN_APP_NOTIFICATION" | (string & {});
export type TaskNameExpression = string;
export type TaskDescriptionExpression = string;
export interface TaskActionDefinition {
    Name: string;
    Description?: string;
    ContactFlowId: string;
    References?: {
        [key: string]: Reference | undefined;
    };
}
export type EventBridgeActionName = string;
export interface EventBridgeActionDefinition {
    Name: string;
}
export interface AssignContactCategoryActionDefinition {
}
export type NotificationDeliveryType = "EMAIL" | (string & {});
export type Subject = string;
export type Content = string;
export type NotificationContentType = "PLAIN_TEXT" | (string & {});
export type UserTagMap = {
    [key: string]: string | undefined;
};
export type UserIdList = string[];
export interface NotificationRecipientType {
    UserTags?: {
        [key: string]: string | undefined;
    };
    UserIds?: string[];
}
export interface SendNotificationActionDefinition {
    DeliveryMethod: NotificationDeliveryType;
    Subject?: string;
    Content: string;
    ContentType: NotificationContentType;
    Recipient: NotificationRecipientType;
    Exclusion?: NotificationRecipientType;
}
export type FieldValueId = string;
export interface EmptyFieldValue {
}
export type FieldStringValue = string;
export interface FieldValueUnion {
    BooleanValue?: boolean;
    DoubleValue?: number;
    EmptyValue?: EmptyFieldValue;
    StringValue?: string;
}
export interface FieldValue {
    Id: string;
    Value: FieldValueUnion;
}
export type FieldValues = FieldValue[];
export type TemplateId = string;
export interface CreateCaseActionDefinition {
    Fields: FieldValue[];
    TemplateId: string;
}
export interface UpdateCaseActionDefinition {
    Fields: FieldValue[];
}
export type SlaAssignmentType = "CASES" | (string & {});
export type SlaName = string;
export type SlaType = "CaseField" | (string & {});
export type SlaFieldValueUnionList = FieldValueUnion[];
export type TargetSlaMinutes = number;
export interface CaseSlaConfiguration {
    Name: string;
    Type: SlaType;
    FieldId?: string;
    TargetFieldValues?: FieldValueUnion[];
    TargetSlaMinutes: number;
}
export interface AssignSlaActionDefinition {
    SlaAssignmentType: SlaAssignmentType;
    CaseSlaConfiguration?: CaseSlaConfiguration;
}
export interface EndAssociatedTasksActionDefinition {
}
export type EvaluationFormId = string;
export interface SubmitAutoEvaluationActionDefinition {
    EvaluationFormId: string;
}
export type RulesExtractionDefinitionId = string;
export interface RulesExtractionDefinitionIdentifier {
    Identifier: string;
}
export type RulesExtractionDefinitionIdentifierList = RulesExtractionDefinitionIdentifier[];
export interface ExtractInformationActionDefinition {
    RulesExtractionDefinitions: RulesExtractionDefinitionIdentifier[];
}
export interface SendInAppNotificationActionDefinition {
    Content: {
        [key: string]: string | undefined;
    };
    Recipient: NotificationRecipientType;
    Exclusion?: NotificationRecipientType;
    Priority?: ConfigurableNotificationPriority;
}
export interface RuleAction {
    ActionType: ActionType;
    TaskAction?: TaskActionDefinition;
    EventBridgeAction?: EventBridgeActionDefinition;
    AssignContactCategoryAction?: AssignContactCategoryActionDefinition;
    SendNotificationAction?: SendNotificationActionDefinition;
    CreateCaseAction?: CreateCaseActionDefinition;
    UpdateCaseAction?: UpdateCaseActionDefinition;
    AssignSlaAction?: AssignSlaActionDefinition;
    EndAssociatedTasksAction?: EndAssociatedTasksActionDefinition;
    SubmitAutoEvaluationAction?: SubmitAutoEvaluationActionDefinition;
    ExtractInformationAction?: ExtractInformationActionDefinition;
    SendInAppNotificationAction?: SendInAppNotificationActionDefinition;
}
export type RuleActions = RuleAction[];
export type RulePublishStatus = "DRAFT" | "PUBLISHED" | (string & {});
export type PreEvaluationFilterResourceType = "CONTACT" | (string & {});
export type PreEvaluationFilterType = "TAG" | (string & {});
export type PreEvaluationFilterOperator = "EQUALS" | (string & {});
export interface PreEvaluationFilter {
    ResourceType: PreEvaluationFilterResourceType;
    FilterType: PreEvaluationFilterType;
    FilterKey: string;
    FilterValue: string;
    Operator: PreEvaluationFilterOperator;
}
export type PreEvaluationFilterList = PreEvaluationFilter[];
export interface PreEvaluationFilters {
    AndConditions?: PreEvaluationFilter[];
}
export interface CreateRuleRequest {
    InstanceId: string;
    Name: string;
    TriggerEventSource: RuleTriggerEventSource;
    Function: string;
    Actions: RuleAction[];
    PublishStatus: RulePublishStatus;
    PreEvaluationFilters?: PreEvaluationFilters;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type RuleId = string;
export interface CreateRuleResponse {
    RuleArn: string;
    RuleId: string;
}
export type CreateSecurityProfileName = string;
export type SecurityProfileDescription = string;
export type SecurityProfilePermission = string;
export type PermissionsList = string[];
export type SecurityProfilePolicyKey = string;
export type SecurityProfilePolicyValue = string;
export type AllowedAccessControlTags = {
    [key: string]: string | undefined;
};
export type TagRestrictedResourceName = string;
export type TagRestrictedResourceList = string[];
export type Namespace = string;
export type Permission = string;
export type ApplicationPermissions = string[];
export type ApplicationType = "MCP" | "THIRD_PARTY_APPLICATION" | (string & {});
export interface Application {
    Namespace?: string;
    ApplicationPermissions?: string[];
    Type?: ApplicationType;
}
export type Applications = Application[];
export type HierarchyRestrictedResourceName = string;
export type HierarchyRestrictedResourceList = string[];
export type HierarchyGroupId = string;
export type FlowModuleType = "MCP" | (string & {});
export type FlowModuleId = string;
export interface FlowModule {
    Type?: FlowModuleType;
    FlowModuleId?: string;
}
export type AllowedFlowModules = FlowModule[];
export type AIAgentType = "THIRD_PARTY" | (string & {});
export interface AIAgent {
    Arn?: string;
    Type?: AIAgentType;
}
export type AllowedAIAgents = AIAgent[];
export type AccessType = "ALLOW" | (string & {});
export type PrimaryAttributeContextKeyName = string;
export type IAMRestrictedPrimaryValue = string;
export type PrimaryValueList = string[];
export interface PrimaryAttributeValue {
    AccessType?: AccessType;
    AttributeName?: string;
    Values?: string[];
}
export type PrimaryAttributeValuesSet = PrimaryAttributeValue[];
export interface PrimaryAttributeAccessControlConfigurationItem {
    PrimaryAttributeValues?: PrimaryAttributeValue[];
}
export interface DataTableAccessControlConfiguration {
    PrimaryAttributeAccessControlConfiguration?: PrimaryAttributeAccessControlConfigurationItem;
}
export interface GranularAccessControlConfiguration {
    DataTableAccessControlConfiguration?: DataTableAccessControlConfiguration;
}
export interface CreateSecurityProfileRequest {
    SecurityProfileName: string;
    Description?: string;
    Permissions?: string[];
    InstanceId: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    AllowedAccessControlTags?: {
        [key: string]: string | undefined;
    };
    TagRestrictedResources?: string[];
    Applications?: Application[];
    HierarchyRestrictedResources?: string[];
    AllowedAccessControlHierarchyGroupId?: string;
    AllowedFlowModules?: FlowModule[];
    AllowedAIAgents?: AIAgent[];
    GranularAccessControlConfiguration?: GranularAccessControlConfiguration;
}
export interface CreateSecurityProfileResponse {
    SecurityProfileId?: string;
    SecurityProfileArn?: string;
}
export type TaskTemplateName = string;
export type TaskTemplateDescription = string;
export type TaskTemplateFieldName = string;
export interface TaskTemplateFieldIdentifier {
    Name?: string;
}
export interface RequiredFieldInfo {
    Id?: TaskTemplateFieldIdentifier;
}
export type RequiredTaskTemplateFields = RequiredFieldInfo[];
export interface ReadOnlyFieldInfo {
    Id?: TaskTemplateFieldIdentifier;
}
export type ReadOnlyTaskTemplateFields = ReadOnlyFieldInfo[];
export interface InvisibleFieldInfo {
    Id?: TaskTemplateFieldIdentifier;
}
export type InvisibleTaskTemplateFields = InvisibleFieldInfo[];
export interface TaskTemplateConstraints {
    RequiredFields?: RequiredFieldInfo[];
    ReadOnlyFields?: ReadOnlyFieldInfo[];
    InvisibleFields?: InvisibleFieldInfo[];
}
export type TaskTemplateFieldValue = string;
export interface TaskTemplateDefaultFieldValue {
    Id?: TaskTemplateFieldIdentifier;
    DefaultValue?: string;
}
export type TaskTemplateDefaultFieldValueList = TaskTemplateDefaultFieldValue[];
export interface TaskTemplateDefaults {
    DefaultFieldValues?: TaskTemplateDefaultFieldValue[];
}
export type TaskTemplateStatus = "ACTIVE" | "INACTIVE" | (string & {});
export type TaskTemplateFieldDescription = string;
export type TaskTemplateFieldType = "NAME" | "DESCRIPTION" | "SCHEDULED_TIME" | "QUICK_CONNECT" | "URL" | "NUMBER" | "TEXT" | "TEXT_AREA" | "DATE_TIME" | "BOOLEAN" | "SINGLE_SELECT" | "EMAIL" | "SELF_ASSIGN" | "EXPIRY_DURATION" | (string & {});
export type TaskTemplateSingleSelectOption = string;
export type SingleSelectOptions = string[];
export interface TaskTemplateField {
    Id: TaskTemplateFieldIdentifier;
    Description?: string;
    Type?: TaskTemplateFieldType;
    SingleSelectOptions?: string[];
}
export type TaskTemplateFields = TaskTemplateField[];
export interface CreateTaskTemplateRequest {
    InstanceId: string;
    Name: string;
    Description?: string;
    ContactFlowId?: string;
    SelfAssignFlowId?: string;
    Constraints?: TaskTemplateConstraints;
    Defaults?: TaskTemplateDefaults;
    Status?: TaskTemplateStatus;
    Fields: TaskTemplateField[];
    ClientToken?: string;
}
export type TaskTemplateId = string;
export type TaskTemplateArn = string;
export interface CreateTaskTemplateResponse {
    Id: string;
    Arn: string;
}
export type TestCaseName = string;
export type TestCaseDescription = string;
export type TestCaseContent = string;
export type TestCaseEntryPointType = "VOICE_CALL" | "CHAT" | (string & {});
export interface VoiceCallEntryPointParameters {
    SourcePhoneNumber?: string;
    DestinationPhoneNumber?: string;
    FlowId?: string;
}
export interface ChatEntryPointParameters {
    FlowId?: string;
}
export interface TestCaseEntryPoint {
    Type?: TestCaseEntryPointType;
    VoiceCallEntryPointParameters?: VoiceCallEntryPointParameters;
    ChatEntryPointParameters?: ChatEntryPointParameters;
}
export type TestCaseInitializationData = string;
export type TestCaseStatus = "PUBLISHED" | "SAVED" | (string & {});
export type TestCaseId = string;
export interface CreateTestCaseRequest {
    InstanceId: string;
    Name: string;
    Description?: string;
    Content: string;
    EntryPoint?: TestCaseEntryPoint;
    InitializationData?: string;
    Status?: TestCaseStatus;
    TestCaseId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface CreateTestCaseResponse {
    TestCaseId?: string;
    TestCaseArn?: string;
}
export type Name128 = string;
export type Description250 = string;
export type ACGRInstanceIdOrArn = string;
export interface CreateTrafficDistributionGroupRequest {
    Name: string;
    Description?: string;
    InstanceId: string;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type ACGRTrafficDistributionGroupId = string;
export type ACGRTrafficDistributionGroupArn = string;
export interface CreateTrafficDistributionGroupResponse {
    Id?: string;
    Arn?: string;
}
export type UseCaseType = "RULES_EVALUATION" | "CONNECT_CAMPAIGNS" | (string & {});
export interface CreateUseCaseRequest {
    InstanceId: string;
    IntegrationAssociationId: string;
    UseCaseType: UseCaseType;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type UseCaseId = string;
export interface CreateUseCaseResponse {
    UseCaseId?: string;
    UseCaseArn?: string;
}
export type AgentUsername = string;
export type Password = string | redacted.Redacted<string>;
export type AgentFirstName = string | redacted.Redacted<string>;
export type AgentLastName = string | redacted.Redacted<string>;
export type Email = string | redacted.Redacted<string>;
export interface UserIdentityInfo {
    FirstName?: string | redacted.Redacted<string>;
    LastName?: string | redacted.Redacted<string>;
    Email?: string | redacted.Redacted<string>;
    SecondaryEmail?: string | redacted.Redacted<string>;
    Mobile?: string;
}
export type PhoneType = "SOFT_PHONE" | "DESK_PHONE" | (string & {});
export type AutoAccept = boolean;
export type AfterContactWorkTimeLimit = number;
export type SensitivePhoneNumber = string | redacted.Redacted<string>;
export type PersistentConnection = boolean;
export interface UserPhoneConfig {
    PhoneType?: PhoneType;
    AutoAccept?: boolean;
    AfterContactWorkTimeLimit?: number;
    DeskPhoneNumber?: string | redacted.Redacted<string>;
    PersistentConnection?: boolean;
}
export type DirectoryUserId = string;
export type AgentFirstCallbackAutoAccept = boolean;
export interface AutoAcceptConfig {
    Channel: Channel;
    AutoAccept: boolean;
    AgentFirstCallbackAutoAccept?: boolean;
}
export type AutoAcceptConfigs = AutoAcceptConfig[];
export interface AfterContactWorkConfig {
    AfterContactWorkTimeLimit?: number;
}
export interface AfterContactWorkConfigPerChannel {
    Channel: Channel;
    AfterContactWorkConfig: AfterContactWorkConfig;
    AgentFirstCallbackAfterContactWorkConfig?: AfterContactWorkConfig;
}
export type AfterContactWorkConfigs = AfterContactWorkConfigPerChannel[];
export interface PhoneNumberConfig {
    Channel: Channel;
    PhoneType: PhoneType;
    PhoneNumber?: string | redacted.Redacted<string>;
}
export type PhoneNumberConfigs = PhoneNumberConfig[];
export interface PersistentConnectionConfig {
    Channel: Channel;
    PersistentConnection: boolean;
}
export type PersistentConnectionConfigs = PersistentConnectionConfig[];
export type VoiceEnhancementMode = "VOICE_ISOLATION" | "NOISE_SUPPRESSION" | "NONE" | (string & {});
export interface VoiceEnhancementConfig {
    Channel: Channel;
    VoiceEnhancementMode: VoiceEnhancementMode;
}
export type VoiceEnhancementConfigs = VoiceEnhancementConfig[];
export interface CreateUserRequest {
    Username: string;
    Password?: string | redacted.Redacted<string>;
    IdentityInfo?: UserIdentityInfo;
    PhoneConfig?: UserPhoneConfig;
    DirectoryUserId?: string;
    SecurityProfileIds: string[];
    RoutingProfileId: string;
    HierarchyGroupId?: string;
    InstanceId: string;
    AutoAcceptConfigs?: AutoAcceptConfig[];
    AfterContactWorkConfigs?: AfterContactWorkConfigPerChannel[];
    PhoneNumberConfigs?: PhoneNumberConfig[];
    PersistentConnectionConfigs?: PersistentConnectionConfig[];
    VoiceEnhancementConfigs?: VoiceEnhancementConfig[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateUserResponse {
    UserId?: string;
    UserArn?: string;
}
export type HierarchyGroupName = string;
export interface CreateUserHierarchyGroupRequest {
    Name: string;
    ParentGroupId?: string;
    InstanceId: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateUserHierarchyGroupResponse {
    HierarchyGroupId?: string;
    HierarchyGroupArn?: string;
}
export type ViewsInstanceId = string;
export type ViewsClientToken = string;
export type ViewStatus = "PUBLISHED" | "SAVED" | (string & {});
export type ViewTemplate = string;
export type ViewAction = string | redacted.Redacted<string>;
export type ViewActions = (string | redacted.Redacted<string>)[];
export interface ViewInputContent {
    Template?: string;
    Actions?: (string | redacted.Redacted<string>)[];
}
export type ViewDescription = string;
export type ViewName = string | redacted.Redacted<string>;
export interface CreateViewRequest {
    InstanceId: string;
    ClientToken?: string;
    Status: ViewStatus;
    Content: ViewInputContent;
    Description?: string;
    Name: string | redacted.Redacted<string>;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type ViewId = string;
export type ViewType = "CUSTOMER_MANAGED" | "AWS_MANAGED" | (string & {});
export type ViewVersion = number;
export type ViewInputSchema = string | redacted.Redacted<string>;
export interface ViewContent {
    InputSchema?: string | redacted.Redacted<string>;
    Template?: string;
    Actions?: (string | redacted.Redacted<string>)[];
}
export type ViewContentSha256 = string;
export interface View {
    Id?: string;
    Arn?: string;
    Name?: string | redacted.Redacted<string>;
    Status?: ViewStatus;
    Type?: ViewType;
    Description?: string;
    Version?: number;
    VersionDescription?: string;
    Content?: ViewContent;
    Tags?: {
        [key: string]: string | undefined;
    };
    CreatedTime?: Date;
    LastModifiedTime?: Date;
    ViewContentSha256?: string;
}
export interface CreateViewResponse {
    View?: View;
}
export interface CreateViewVersionRequest {
    InstanceId: string;
    ViewId: string;
    VersionDescription?: string;
    ViewContentSha256?: string;
}
export interface CreateViewVersionResponse {
    View?: View;
}
export type VocabularyName = string;
export type VocabularyContent = string;
export interface CreateVocabularyRequest {
    ClientToken?: string;
    InstanceId: string;
    VocabularyName: string;
    LanguageCode: VocabularyLanguageCode;
    Content: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type VocabularyState = "CREATION_IN_PROGRESS" | "ACTIVE" | "CREATION_FAILED" | "DELETE_IN_PROGRESS" | (string & {});
export interface CreateVocabularyResponse {
    VocabularyArn: string;
    VocabularyId: string;
    State: VocabularyState;
}
export type WorkspaceName = string;
export type WorkspaceDescription = string;
export type ThemeString = string;
export interface PaletteHeader {
    Background?: string;
    Text?: string;
    TextHover?: string;
    InvertActionsColors?: boolean;
}
export interface PaletteNavigation {
    Background?: string;
    TextBackgroundHover?: string;
    TextBackgroundActive?: string;
    Text?: string;
    TextHover?: string;
    TextActive?: string;
    InvertActionsColors?: boolean;
}
export interface PaletteCanvas {
    ContainerBackground?: string;
    PageBackground?: string;
    ActiveBackground?: string;
}
export interface PalettePrimary {
    Default?: string;
    Active?: string;
    ContrastText?: string;
}
export interface WorkspaceThemePalette {
    Header?: PaletteHeader;
    Navigation?: PaletteNavigation;
    Canvas?: PaletteCanvas;
    Primary?: PalettePrimary;
}
export type ThemeImageLink = string;
export interface ImagesLogo {
    Default?: string;
    Favicon?: string;
}
export interface WorkspaceThemeImages {
    Logo?: ImagesLogo;
}
export type WorkspaceFontFamily = "Arial" | "Courier New" | "Georgia" | "Times New Roman" | "Trebuchet" | "Verdana" | (string & {});
export interface FontFamily {
    Default?: WorkspaceFontFamily;
}
export interface WorkspaceThemeTypography {
    FontFamily?: FontFamily;
}
export interface WorkspaceThemeConfig {
    Palette?: WorkspaceThemePalette;
    Images?: WorkspaceThemeImages;
    Typography?: WorkspaceThemeTypography;
}
export interface WorkspaceTheme {
    Light?: WorkspaceThemeConfig;
    Dark?: WorkspaceThemeConfig;
}
export type WorkspaceTitle = string;
export interface CreateWorkspaceRequest {
    InstanceId: string;
    Name: string;
    Description?: string;
    Theme?: WorkspaceTheme;
    Title?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateWorkspaceResponse {
    WorkspaceId: string;
    WorkspaceArn: string;
}
export type Page = string;
export type Slug = string;
export type InputData = string;
export interface CreateWorkspacePageRequest {
    InstanceId: string;
    WorkspaceId: string;
    ResourceArn: string;
    Page: string;
    Slug?: string;
    InputData?: string;
}
export interface CreateWorkspacePageResponse {
}
export interface DeactivateEvaluationFormRequest {
    InstanceId: string;
    EvaluationFormId: string;
    EvaluationFormVersion: number;
}
export interface DeactivateEvaluationFormResponse {
    EvaluationFormId: string;
    EvaluationFormArn: string;
    EvaluationFormVersion: number;
}
export interface DeleteAttachedFileRequest {
    InstanceId: string;
    FileId: string;
    AssociatedResourceArn: string;
}
export interface DeleteAttachedFileResponse {
}
export type ContactField = "CUSTOMER_ENDPOINT" | "ADDITIONAL_EMAIL_RECIPIENTS" | "EMAIL_SUBJECT" | (string & {});
export type ContactFields = ContactField[];
export interface DeleteContactDataRequest {
    InstanceId: string;
    ContactId: string;
    ContactFields: ContactField[];
}
export interface DeleteContactDataResponse {
}
export interface DeleteContactEvaluationRequest {
    InstanceId: string;
    EvaluationId: string;
}
export interface DeleteContactEvaluationResponse {
}
export interface DeleteContactFlowRequest {
    InstanceId: string;
    ContactFlowId: string;
}
export interface DeleteContactFlowResponse {
}
export interface DeleteContactFlowModuleRequest {
    InstanceId: string;
    ContactFlowModuleId: string;
}
export interface DeleteContactFlowModuleResponse {
}
export interface DeleteContactFlowModuleAliasRequest {
    InstanceId: string;
    ContactFlowModuleId: string;
    AliasId: string;
}
export interface DeleteContactFlowModuleAliasResponse {
}
export interface DeleteContactFlowModuleVersionRequest {
    InstanceId: string;
    ContactFlowModuleId: string;
    ContactFlowModuleVersion: number;
}
export interface DeleteContactFlowModuleVersionResponse {
}
export interface DeleteContactFlowVersionRequest {
    InstanceId: string;
    ContactFlowId: string;
    ContactFlowVersion: number;
}
export interface DeleteContactFlowVersionResponse {
}
export interface DeleteDataTableRequest {
    InstanceId: string;
    DataTableId: string;
}
export interface DeleteDataTableResponse {
}
export interface DeleteDataTableAttributeRequest {
    InstanceId: string;
    DataTableId: string;
    AttributeName: string;
}
export interface DeleteDataTableAttributeResponse {
    LockVersion: DataTableLockVersion;
}
export interface DeleteEmailAddressRequest {
    InstanceId: string;
    EmailAddressId: string;
}
export interface DeleteEmailAddressResponse {
}
export interface DeleteEvaluationFormRequest {
    InstanceId: string;
    EvaluationFormId: string;
    EvaluationFormVersion?: number;
}
export interface DeleteEvaluationFormResponse {
}
export interface DeleteExtractionDefinitionRequest {
    InstanceId: string;
    ExtractionDefinitionId: string;
}
export interface DeleteExtractionDefinitionResponse {
}
export interface DeleteHoursOfOperationRequest {
    InstanceId: string;
    HoursOfOperationId: string;
}
export interface DeleteHoursOfOperationResponse {
}
export interface DeleteHoursOfOperationOverrideRequest {
    InstanceId: string;
    HoursOfOperationId: string;
    HoursOfOperationOverrideId: string;
}
export interface DeleteHoursOfOperationOverrideResponse {
}
export interface DeleteInstanceRequest {
    InstanceId: string;
    ClientToken?: string;
}
export interface DeleteInstanceResponse {
}
export interface DeleteIntegrationAssociationRequest {
    InstanceId: string;
    IntegrationAssociationId: string;
}
export interface DeleteIntegrationAssociationResponse {
}
export interface DeleteMetricRequest {
    InstanceId: string;
    MetricId: string;
}
export interface DeleteMetricResponse {
}
export interface DeleteNotificationRequest {
    InstanceId: string;
    NotificationId: string;
}
export interface DeleteNotificationResponse {
}
export interface DeletePredefinedAttributeRequest {
    InstanceId: string;
    Name: string;
}
export interface DeletePredefinedAttributeResponse {
}
export interface DeletePromptRequest {
    InstanceId: string;
    PromptId: string;
}
export interface DeletePromptResponse {
}
export interface DeletePushNotificationRegistrationRequest {
    InstanceId: string;
    RegistrationId: string;
    ContactId: string;
}
export interface DeletePushNotificationRegistrationResponse {
}
export interface DeleteQueueRequest {
    InstanceId: string;
    QueueId: string;
}
export interface DeleteQueueResponse {
}
export interface DeleteQuickConnectRequest {
    InstanceId: string;
    QuickConnectId: string;
}
export interface DeleteQuickConnectResponse {
}
export interface DeleteRoutingProfileRequest {
    InstanceId: string;
    RoutingProfileId: string;
}
export interface DeleteRoutingProfileResponse {
}
export interface DeleteRuleRequest {
    InstanceId: string;
    RuleId: string;
}
export interface DeleteRuleResponse {
}
export interface DeleteSecurityProfileRequest {
    InstanceId: string;
    SecurityProfileId: string;
}
export interface DeleteSecurityProfileResponse {
}
export interface DeleteSessionRequest {
    InstanceId: string;
    SessionId: string;
}
export interface DeleteSessionResponse {
}
export interface DeleteTaskTemplateRequest {
    InstanceId: string;
    TaskTemplateId: string;
}
export interface DeleteTaskTemplateResponse {
}
export interface DeleteTestCaseRequest {
    InstanceId: string;
    TestCaseId: string;
}
export interface DeleteTestCaseResponse {
}
export interface DeleteTrafficDistributionGroupRequest {
    TrafficDistributionGroupId: string;
}
export interface DeleteTrafficDistributionGroupResponse {
}
export interface DeleteUseCaseRequest {
    InstanceId: string;
    IntegrationAssociationId: string;
    UseCaseId: string;
}
export interface DeleteUseCaseResponse {
}
export interface DeleteUserRequest {
    InstanceId: string;
    UserId: string;
}
export interface DeleteUserResponse {
}
export interface DeleteUserHierarchyGroupRequest {
    HierarchyGroupId: string;
    InstanceId: string;
}
export interface DeleteUserHierarchyGroupResponse {
}
export interface DeleteViewRequest {
    InstanceId: string;
    ViewId: string;
}
export interface DeleteViewResponse {
}
export interface DeleteViewVersionRequest {
    InstanceId: string;
    ViewId: string;
    ViewVersion: number;
}
export interface DeleteViewVersionResponse {
}
export interface DeleteVocabularyRequest {
    InstanceId: string;
    VocabularyId: string;
}
export interface DeleteVocabularyResponse {
    VocabularyArn: string;
    VocabularyId: string;
    State: VocabularyState;
}
export interface DeleteWorkspaceRequest {
    InstanceId: string;
    WorkspaceId: string;
}
export interface DeleteWorkspaceResponse {
}
export type MediaType = "IMAGE_LOGO_LIGHT_FAVICON" | "IMAGE_LOGO_DARK_FAVICON" | "IMAGE_LOGO_LIGHT_HORIZONTAL" | "IMAGE_LOGO_DARK_HORIZONTAL" | (string & {});
export interface DeleteWorkspaceMediaRequest {
    InstanceId: string;
    WorkspaceId: string;
    MediaType: MediaType;
}
export interface DeleteWorkspaceMediaResponse {
}
export interface DeleteWorkspacePageRequest {
    InstanceId: string;
    WorkspaceId: string;
    Page: string;
}
export interface DeleteWorkspacePageResponse {
}
export interface DescribeAgentStatusRequest {
    InstanceId: string;
    AgentStatusId: string;
}
export type AgentStatusType = "ROUTABLE" | "CUSTOM" | "OFFLINE" | (string & {});
export interface AgentStatus {
    AgentStatusARN?: string;
    AgentStatusId?: string;
    Name?: string;
    Description?: string;
    Type?: AgentStatusType;
    DisplayOrder?: number;
    State?: AgentStatusState;
    Tags?: {
        [key: string]: string | undefined;
    };
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface DescribeAgentStatusResponse {
    AgentStatus?: AgentStatus;
}
export type AttachmentScope = "EMAIL" | "CHAT" | "CASE" | "TASK" | (string & {});
export interface DescribeAttachedFilesConfigurationRequest {
    InstanceId: string;
    AttachmentScope: AttachmentScope;
}
export type MaximumSizeLimitInBytes = number;
export type FileExtension = string;
export interface AllowedExtension {
    Extension: string;
}
export type AllowedExtensionsList = AllowedExtension[];
export interface ExtensionConfiguration {
    AllowedExtensions: AllowedExtension[];
}
export interface AttachedFilesConfiguration {
    InstanceId: string;
    AttachmentScope: AttachmentScope;
    MaximumSizeLimitInBytes?: number;
    ExtensionConfiguration?: ExtensionConfiguration;
    LastModifiedTime?: Date;
}
export interface DescribeAttachedFilesConfigurationResponse {
    AttachedFilesConfiguration: AttachedFilesConfiguration;
}
export type AuthenticationProfileId = string;
export interface DescribeAuthenticationProfileRequest {
    AuthenticationProfileId: string;
    InstanceId: string;
}
export type AuthenticationProfileName = string;
export type AuthenticationProfileDescription = string;
export type IpCidr = string;
export type IpCidrList = string[];
export type AccessTokenDuration = number;
export type RefreshTokenDuration = number;
export type InactivityDuration = number;
export interface AuthenticationProfile {
    Id?: string;
    Arn?: string;
    Name?: string;
    Description?: string;
    AllowedIps?: string[];
    BlockedIps?: string[];
    IsDefault?: boolean;
    CreatedTime?: Date;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
    PeriodicSessionDuration?: number;
    MaxSessionDuration?: number;
    SessionInactivityDuration?: number;
    SessionInactivityHandlingEnabled?: boolean;
}
export interface DescribeAuthenticationProfileResponse {
    AuthenticationProfile?: AuthenticationProfile;
}
export interface DescribeContactRequest {
    InstanceId: string;
    ContactId: string;
}
export interface QueueInfo {
    Id?: string;
    EnqueueTimestamp?: Date;
}
export type AgentPauseDurationInSeconds = number;
export interface AgentHierarchyGroup {
    Arn?: string;
}
export interface HierarchyGroups {
    Level1?: AgentHierarchyGroup;
    Level2?: AgentHierarchyGroup;
    Level3?: AgentHierarchyGroup;
    Level4?: AgentHierarchyGroup;
    Level5?: AgentHierarchyGroup;
}
export type PlatformName = string;
export type PlatformVersion = string;
export type OperatingSystem = string;
export interface DeviceInfo {
    PlatformName?: string;
    PlatformVersion?: string;
    OperatingSystem?: string;
}
export type Duration = number;
export type ParticipantState = "INITIAL" | "CONNECTED" | "DISCONNECTED" | "MISSED" | (string & {});
export interface StateTransition {
    State?: ParticipantState;
    StateStartTimestamp?: Date;
    StateEndTimestamp?: Date;
}
export type StateTransitions = StateTransition[];
export type ActiveRegion = string;
export interface AgentInfo {
    Id?: string;
    AcceptedByAgentTimestamp?: Date;
    PreviewEndTimestamp?: Date;
    ConnectedToAgentTimestamp?: Date;
    AgentPauseDurationInSeconds?: number;
    HierarchyGroups?: HierarchyGroups;
    DeviceInfo?: DeviceInfo;
    Capabilities?: ParticipantCapabilities;
    AfterContactWorkDuration?: number;
    AfterContactWorkStartTimestamp?: Date;
    AfterContactWorkEndTimestamp?: Date;
    AgentInitiatedHoldDuration?: number;
    StateTransitions?: StateTransition[];
    VoiceEnhancementMode?: VoiceEnhancementMode;
    ActiveRegion?: string;
}
export type TotalPauseCount = number;
export type TotalPauseDurationInSeconds = number;
export type AiUseCase = "AgentAssistance" | "SelfService" | (string & {});
export type AiAgentVersionId = string;
export interface AiAgentInfo {
    AiUseCase?: AiUseCase;
    AiAgentVersionId?: string;
    AiAgentEscalated?: boolean;
}
export type AiAgents = AiAgentInfo[];
export interface WisdomInfo {
    SessionArn?: string;
    AiAgents?: AiAgentInfo[];
}
export type CustomerId = string;
export type EndpointDisplayName = string;
export interface EndpointInfo {
    Type?: EndpointType;
    Address?: string;
    DisplayName?: string;
}
export type QueueTimeAdjustmentSeconds = number;
export type QueuePriority = number;
export type ContactTagKey = string;
export type ContactTagValue = string;
export type ContactTagMap = {
    [key: string]: string | undefined;
};
export type DurationInSeconds = number;
export interface Expiry {
    DurationInSeconds?: number;
    ExpiryTimestamp?: Date;
}
export type ProficiencyValue = string;
export type NullableProficiencyLevel = number;
export interface Range {
    MinProficiencyLevel?: number;
    MaxProficiencyLevel?: number;
}
export type AgentId = string;
export type AgentIds = string[];
export interface AgentsCriteria {
    AgentIds?: string[];
}
export interface MatchCriteria {
    AgentsCriteria?: AgentsCriteria;
}
export type ComparisonOperator = string;
export interface AttributeCondition {
    Name?: string;
    Value?: string;
    ProficiencyLevel?: number;
    Range?: Range;
    MatchCriteria?: MatchCriteria;
    ComparisonOperator?: string;
}
export type Expressions = Expression[];
export interface Expression {
    AttributeCondition?: AttributeCondition;
    AndExpression?: Expression[];
    OrExpression?: Expression[];
    NotAttributeCondition?: AttributeCondition;
}
export type RoutingCriteriaStepStatus = "ACTIVE" | "INACTIVE" | "JOINED" | "EXPIRED" | (string & {});
export interface Step {
    Expiry?: Expiry;
    Expression?: Expression;
    Status?: RoutingCriteriaStepStatus;
}
export type Steps = Step[];
export type Index = number;
export interface RoutingCriteria {
    Steps?: Step[];
    ActivationTimestamp?: Date;
    Index?: number;
}
export interface Customer {
    DeviceInfo?: DeviceInfo;
    Capabilities?: ParticipantCapabilities;
}
export type AnsweringMachineDetectionStatus = "ANSWERED" | "UNDETECTED" | "ERROR" | "HUMAN_ANSWERED" | "SIT_TONE_DETECTED" | "SIT_TONE_BUSY" | "SIT_TONE_INVALID_NUMBER" | "FAX_MACHINE_DETECTED" | "VOICEMAIL_BEEP" | "VOICEMAIL_NO_BEEP" | "AMD_UNRESOLVED" | "AMD_UNANSWERED" | "AMD_ERROR" | "AMD_NOT_APPLICABLE" | (string & {});
export interface CustomerVoiceActivity {
    GreetingStartTimestamp?: Date;
    GreetingEndTimestamp?: Date;
}
export type AudioQualityScore = number;
export type PotentialAudioQualityIssue = string;
export type PotentialAudioQualityIssues = string[];
export interface AudioQualityMetricsInfo {
    QualityScore?: number;
    PotentialQualityIssues?: string[];
}
export interface AgentQualityMetrics {
    Audio?: AudioQualityMetricsInfo;
}
export interface CustomerQualityMetrics {
    Audio?: AudioQualityMetricsInfo;
}
export interface QualityMetrics {
    Agent?: AgentQualityMetrics;
    Customer?: CustomerQualityMetrics;
}
export type Count = number;
export type DurationMillis = number;
export interface ChatContactMetrics {
    MultiParty?: boolean;
    TotalMessages?: number;
    TotalBotMessages?: number;
    TotalBotMessageLengthInChars?: number;
    ConversationCloseTimeInMillis?: number;
    ConversationTurnCount?: number;
    AgentFirstResponseTimestamp?: Date;
    AgentFirstResponseTimeInMillis?: number;
}
export type ParticipantType = "ALL" | "MANAGER" | "AGENT" | "CUSTOMER" | "THIRDPARTY" | (string & {});
export interface ParticipantMetrics {
    ParticipantId?: string;
    ParticipantType?: ParticipantType;
    ConversationAbandon?: boolean;
    MessagesSent?: number;
    NumResponses?: number;
    MessageLengthInChars?: number;
    TotalResponseTimeInMillis?: number;
    MaxResponseTimeInMillis?: number;
    LastMessageTimestamp?: Date;
}
export interface ChatMetrics {
    ChatContactMetrics?: ChatContactMetrics;
    AgentMetrics?: ParticipantMetrics;
    CustomerMetrics?: ParticipantMetrics;
}
export type PotentialDisconnectIssue = string;
export interface DisconnectDetails {
    PotentialDisconnectIssue?: string;
}
export interface EmailRecipient {
    Address?: string;
    DisplayName?: string;
}
export type EmailRecipientsList = EmailRecipient[];
export interface AdditionalEmailRecipients {
    ToList?: EmailRecipient[];
    CcList?: EmailRecipient[];
}
export type RecordingLocation = string;
export type MediaStreamType = "AUDIO" | "VIDEO" | (string & {});
export type FragmentNumber = string;
export type RecordingStatus = "AVAILABLE" | "DELETED" | (string & {});
export type RecordingDeletionReason = string;
export type UnprocessedTranscriptLocation = string;
export interface RecordingInfo {
    StorageType?: StorageType;
    Location?: string;
    MediaStreamType?: MediaStreamType;
    ParticipantType?: ParticipantType;
    FragmentStartNumber?: string;
    FragmentStopNumber?: string;
    StartTimestamp?: Date;
    StopTimestamp?: Date;
    Status?: RecordingStatus;
    DeletionReason?: string;
    UnprocessedTranscriptLocation?: string;
}
export type Recordings = RecordingInfo[];
export type EvaluationId = string;
export type FormId = string;
export type EvaluationArn = string;
export type Status = "COMPLETE" | "IN_PROGRESS" | "DELETED" | (string & {});
export type ExportLocation = string;
export interface ContactEvaluation {
    FormId?: string;
    EvaluationArn?: string;
    Status?: Status;
    StartTimestamp?: Date;
    EndTimestamp?: Date;
    DeleteTimestamp?: Date;
    ExportLocation?: string;
}
export type ContactEvaluations = {
    [key: string]: ContactEvaluation | undefined;
};
export interface TaskTemplateInfoV2 {
    Arn?: string;
    Name?: string;
}
export type ContactDetailName = string;
export type ContactDetailDescription = string;
export interface ContactDetails {
    Name?: string;
    Description?: string;
}
export type NextContactType = "QUICK_CONNECT" | (string & {});
export interface QuickConnectContactData {
    ContactId?: string;
    InitiationTimestamp?: Date;
    QuickConnectId?: string;
    QuickConnectName?: string;
    QuickConnectType?: QuickConnectType;
}
export type NextContactMetadata = {
    QuickConnectContactData: QuickConnectContactData;
};
export interface NextContactEntry {
    Type?: NextContactType;
    NextContactMetadata?: NextContactMetadata;
}
export type NextContacts = NextContactEntry[];
export type OriginRegion = string;
export type TrafficDistributionGroupId = string;
export interface GlobalResiliencyMetadata {
    ActiveRegion?: string;
    OriginRegion?: string;
    TrafficDistributionGroupId?: string;
}
export interface Contact {
    Arn?: string;
    Id?: string;
    InitialContactId?: string;
    PreviousContactId?: string;
    ContactAssociationId?: string;
    InitiationMethod?: ContactInitiationMethod;
    Name?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    Channel?: Channel;
    QueueInfo?: QueueInfo;
    AgentInfo?: AgentInfo;
    InitiationTimestamp?: Date;
    DisconnectTimestamp?: Date;
    LastUpdateTimestamp?: Date;
    LastPausedTimestamp?: Date;
    LastResumedTimestamp?: Date;
    RingStartTimestamp?: Date;
    TotalPauseCount?: number;
    TotalPauseDurationInSeconds?: number;
    ScheduledTimestamp?: Date;
    RelatedContactId?: string;
    WisdomInfo?: WisdomInfo;
    CustomerId?: string;
    CustomerEndpoint?: EndpointInfo;
    SystemEndpoint?: EndpointInfo;
    QueueTimeAdjustmentSeconds?: number;
    QueuePriority?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
    ConnectedToSystemTimestamp?: Date;
    RoutingCriteria?: RoutingCriteria;
    Customer?: Customer;
    Campaign?: Campaign;
    AnsweringMachineDetectionStatus?: AnsweringMachineDetectionStatus;
    CustomerVoiceActivity?: CustomerVoiceActivity;
    QualityMetrics?: QualityMetrics;
    ChatMetrics?: ChatMetrics;
    DisconnectDetails?: DisconnectDetails;
    AdditionalEmailRecipients?: AdditionalEmailRecipients;
    SegmentAttributes?: {
        [key: string]: SegmentAttributeValue | undefined;
    };
    Recordings?: RecordingInfo[];
    DisconnectReason?: string;
    ContactEvaluations?: {
        [key: string]: ContactEvaluation | undefined;
    };
    TaskTemplateInfo?: TaskTemplateInfoV2;
    ContactDetails?: ContactDetails;
    OutboundStrategy?: OutboundStrategy;
    Attributes?: {
        [key: string]: string | undefined;
    };
    NextContacts?: NextContactEntry[];
    GlobalResiliencyMetadata?: GlobalResiliencyMetadata;
}
export interface DescribeContactResponse {
    Contact?: Contact;
}
export interface DescribeContactEvaluationRequest {
    InstanceId: string;
    EvaluationId: string;
}
export interface EvaluationScore {
    Percentage?: number;
    NotApplicable?: boolean;
    AutomaticFail?: boolean;
    AppliedWeight?: number;
    EarnedPoints?: number;
    MaxBasePoint?: number;
    PerformanceCategory?: PerformanceCategoryName;
}
export type AutoEvaluationStatus = "IN_PROGRESS" | "FAILED" | "SUCCEEDED" | (string & {});
export interface AutoEvaluationDetails {
    AutoEvaluationEnabled: boolean;
    AutoEvaluationStatus?: AutoEvaluationStatus;
}
export type EvaluationAcknowledgerCommentString = string;
export interface EvaluationAcknowledgement {
    AcknowledgedTime: Date;
    AcknowledgedBy: string;
    AcknowledgerComment?: string;
}
export type EvaluationReviewRequestCommentContent = string;
export interface EvaluationReviewRequestComment {
    Comment?: string;
    CreatedTime?: Date;
    CreatedBy?: string;
}
export type EvaluationReviewRequestCommentList = EvaluationReviewRequestComment[];
export interface EvaluationReviewMetadata {
    ReviewId?: string;
    RequestedTime?: Date;
    RequestedBy?: string;
    CreatedTime?: Date;
    CreatedBy?: string;
    ReviewRequestComments: EvaluationReviewRequestComment[];
}
export type ContactParticipantRole = "AGENT" | "SYSTEM" | "CUSTOM_BOT" | "CUSTOMER" | (string & {});
export interface EvaluationContactParticipant {
    ContactParticipantRole?: ContactParticipantRole;
    ContactParticipantId?: string;
}
export interface EvaluationMetadata {
    ContactId: string;
    EvaluatorArn: string;
    ContactAgentId?: string;
    CalibrationSessionId?: string;
    Score?: EvaluationScore;
    AutoEvaluation?: AutoEvaluationDetails;
    Acknowledgement?: EvaluationAcknowledgement;
    Review?: EvaluationReviewMetadata;
    ContactParticipant?: EvaluationContactParticipant;
    SamplingJobId?: string;
}
export type EvaluationAnswerDataStringValue = string;
export type EvaluationAnswerDataNumericValue = number;
export type EvaluationAnswerDataStringValueList = string[];
export type EvaluationAnswerData = {
    StringValue: string;
    NumericValue?: never;
    StringValues?: never;
    DateTimeValue?: never;
    NotApplicable?: never;
} | {
    StringValue?: never;
    NumericValue: number;
    StringValues?: never;
    DateTimeValue?: never;
    NotApplicable?: never;
} | {
    StringValue?: never;
    NumericValue?: never;
    StringValues: string[];
    DateTimeValue?: never;
    NotApplicable?: never;
} | {
    StringValue?: never;
    NumericValue?: never;
    StringValues?: never;
    DateTimeValue: string;
    NotApplicable?: never;
} | {
    StringValue?: never;
    NumericValue?: never;
    StringValues?: never;
    DateTimeValue?: never;
    NotApplicable: boolean;
};
export type EvaluationSuggestedAnswerStatus = "IN_PROGRESS" | "FAILED" | "SUCCEEDED" | (string & {});
export type EvaluationTranscriptType = "RAW" | "REDACTED" | (string & {});
export interface EvaluationQuestionInputDetails {
    TranscriptType?: EvaluationTranscriptType;
}
export type EvaluationQuestionAnswerAnalysisType = "CONTACT_LENS_DATA" | "GEN_AI" | (string & {});
export type EvaluationSuggestedAnswerJustification = string;
export type EvaluationSuggestedAnswerTranscriptMillisOffset = number;
export interface EvaluationSuggestedAnswerTranscriptMillisecondOffsets {
    BeginOffsetMillis: number;
}
export type EvaluationSuggestedAnswerTranscriptSegment = string;
export interface EvaluationTranscriptPointOfInterest {
    MillisecondOffsets?: EvaluationSuggestedAnswerTranscriptMillisecondOffsets;
    TranscriptSegment?: string;
}
export type EvaluationTranscriptPointsOfInterest = EvaluationTranscriptPointOfInterest[];
export interface EvaluationGenAIAnswerAnalysisDetails {
    Justification?: string;
    PointsOfInterest?: EvaluationTranscriptPointOfInterest[];
}
export type QuestionRuleCategoryAutomationLabel = string;
export type QuestionRuleCategoryAutomationCondition = "PRESENT" | "NOT_PRESENT" | (string & {});
export interface EvaluationAutomationRuleCategory {
    Category: string;
    Condition: QuestionRuleCategoryAutomationCondition;
    PointsOfInterest?: EvaluationTranscriptPointOfInterest[];
}
export type EvaluationAutomationRuleCategoryList = EvaluationAutomationRuleCategory[];
export interface EvaluationContactLensAnswerAnalysisDetails {
    MatchedRuleCategories?: EvaluationAutomationRuleCategory[];
}
export type EvaluationQuestionAnswerAnalysisDetails = {
    GenAI: EvaluationGenAIAnswerAnalysisDetails;
    ContactLens?: never;
} | {
    GenAI?: never;
    ContactLens: EvaluationContactLensAnswerAnalysisDetails;
};
export interface EvaluationSuggestedAnswer {
    Value?: EvaluationAnswerData;
    Status: EvaluationSuggestedAnswerStatus;
    Input?: EvaluationQuestionInputDetails;
    AnalysisType: EvaluationQuestionAnswerAnalysisType;
    AnalysisDetails?: EvaluationQuestionAnswerAnalysisDetails;
}
export type EvaluationSuggestedAnswersList = EvaluationSuggestedAnswer[];
export interface EvaluationAnswerOutput {
    Value?: EvaluationAnswerData;
    SystemSuggestedValue?: EvaluationAnswerData;
    SuggestedAnswers?: EvaluationSuggestedAnswer[];
}
export type EvaluationAnswersOutputMap = {
    [key: string]: EvaluationAnswerOutput | undefined;
};
export type EvaluationNoteString = string;
export interface EvaluationNote {
    Value?: string;
}
export type EvaluationNotesMap = {
    [key: string]: EvaluationNote | undefined;
};
export type EvaluationStatus = "DRAFT" | "SUBMITTED" | "REVIEW_REQUESTED" | "UNDER_REVIEW" | (string & {});
export type EvaluationScoresMap = {
    [key: string]: EvaluationScore | undefined;
};
export type EvaluationType = "STANDARD" | "CALIBRATION" | (string & {});
export interface Evaluation {
    EvaluationId: string;
    EvaluationArn: string;
    Metadata: EvaluationMetadata;
    Answers: {
        [key: string]: EvaluationAnswerOutput | undefined;
    };
    Notes: {
        [key: string]: EvaluationNote | undefined;
    };
    Status: EvaluationStatus;
    Scores?: {
        [key: string]: EvaluationScore | undefined;
    };
    CreatedTime: Date;
    LastModifiedTime: Date;
    EvaluationType?: EvaluationType;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface EvaluationFormContent {
    EvaluationFormVersion: number;
    EvaluationFormId: string;
    EvaluationFormArn: string;
    Title: string;
    Description?: string;
    Items: EvaluationFormItem[];
    ScoringStrategy?: EvaluationFormScoringStrategy;
    AutoEvaluationConfiguration?: EvaluationFormAutoEvaluationConfiguration;
    TargetConfiguration?: EvaluationFormTargetConfiguration;
    LanguageConfiguration?: EvaluationFormLanguageConfiguration;
    ReviewConfiguration?: EvaluationReviewConfiguration;
    AIVersion?: string;
}
export interface DescribeContactEvaluationResponse {
    Evaluation: Evaluation;
    EvaluationForm: EvaluationFormContent;
}
export interface DescribeContactFlowRequest {
    InstanceId: string;
    ContactFlowId: string;
}
export type ContactFlowState = "ACTIVE" | "ARCHIVED" | (string & {});
export interface ContactFlow {
    Arn?: string;
    Id?: string;
    Name?: string;
    Type?: ContactFlowType;
    State?: ContactFlowState;
    Status?: ContactFlowStatus;
    Description?: string;
    Content?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    FlowContentSha256?: string;
    Version?: number;
    VersionDescription?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface DescribeContactFlowResponse {
    ContactFlow?: ContactFlow;
}
export interface DescribeContactFlowModuleRequest {
    InstanceId: string;
    ContactFlowModuleId: string;
}
export type ContactFlowModuleState = "ACTIVE" | "ARCHIVED" | (string & {});
export type ContactFlowModuleStatus = "PUBLISHED" | "SAVED" | (string & {});
export interface ContactFlowModule {
    Arn?: string;
    Id?: string;
    Name?: string;
    Content?: string;
    Description?: string;
    State?: ContactFlowModuleState;
    Status?: ContactFlowModuleStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
    FlowModuleContentSha256?: string;
    Version?: number;
    VersionDescription?: string;
    Settings?: string;
    ExternalInvocationConfiguration?: ExternalInvocationConfiguration;
}
export interface DescribeContactFlowModuleResponse {
    ContactFlowModule?: ContactFlowModule;
}
export interface DescribeContactFlowModuleAliasRequest {
    InstanceId: string;
    ContactFlowModuleId: string;
    AliasId: string;
}
export interface ContactFlowModuleAliasInfo {
    ContactFlowModuleId?: string;
    ContactFlowModuleArn?: string;
    AliasId?: string;
    Version?: number;
    Name?: string;
    Description?: string;
    LastModifiedRegion?: string;
    LastModifiedTime?: Date;
}
export interface DescribeContactFlowModuleAliasResponse {
    ContactFlowModuleAlias?: ContactFlowModuleAliasInfo;
}
export interface DescribeDataTableRequest {
    InstanceId: string;
    DataTableId: string;
}
export type DataTableVersion = string;
export interface DataTable {
    Name: string;
    Id: string;
    Arn: string;
    TimeZone: string;
    Description?: string;
    ValueLockLevel?: DataTableLockLevel;
    LockVersion?: DataTableLockVersion;
    Version?: string;
    VersionDescription?: string;
    Status?: DataTableStatus;
    CreatedTime?: Date;
    LastModifiedTime: Date;
    LastModifiedRegion?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeDataTableResponse {
    DataTable: DataTable;
}
export interface DescribeDataTableAttributeRequest {
    InstanceId: string;
    DataTableId: string;
    AttributeName: string;
}
export interface DataTableAttribute {
    AttributeId?: string;
    Name: string;
    ValueType: DataTableAttributeValueType;
    Description?: string;
    DataTableId?: string;
    DataTableArn?: string;
    Primary?: boolean;
    Version?: string;
    LockVersion?: DataTableLockVersion;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
    Validation?: Validation;
}
export interface DescribeDataTableAttributeResponse {
    Attribute: DataTableAttribute;
}
export interface DescribeEmailAddressRequest {
    InstanceId: string;
    EmailAddressId: string;
}
export type AliasConfigurationList = AliasConfiguration[];
export interface DescribeEmailAddressResponse {
    EmailAddressId?: string;
    EmailAddressArn?: string;
    EmailAddress?: string | redacted.Redacted<string>;
    DisplayName?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    CreateTimestamp?: string;
    ModifiedTimestamp?: string;
    AliasConfigurations?: AliasConfiguration[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeEvaluationFormRequest {
    InstanceId: string;
    EvaluationFormId: string;
    EvaluationFormVersion?: number;
}
export type EvaluationFormVersionIsLocked = boolean;
export type EvaluationFormVersionStatus = "DRAFT" | "ACTIVE" | (string & {});
export type EvaluationFormValidationStatus = "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export interface EvaluationForm {
    EvaluationFormId: string;
    EvaluationFormVersion: number;
    Locked: boolean;
    EvaluationFormArn: string;
    Title: string;
    Description?: string;
    Status: EvaluationFormVersionStatus;
    Items: EvaluationFormItem[];
    ScoringStrategy?: EvaluationFormScoringStrategy;
    CreatedTime: Date;
    CreatedBy: string;
    LastModifiedTime: Date;
    LastModifiedBy: string;
    AutoEvaluationConfiguration?: EvaluationFormAutoEvaluationConfiguration;
    ReviewConfiguration?: EvaluationReviewConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    };
    TargetConfiguration?: EvaluationFormTargetConfiguration;
    LanguageConfiguration?: EvaluationFormLanguageConfiguration;
    LatestValidationStatus?: EvaluationFormValidationStatus;
    LastValidationTime?: Date;
    AIVersion?: string;
}
export interface DescribeEvaluationFormResponse {
    EvaluationForm: EvaluationForm;
}
export interface DescribeExtractionDefinitionRequest {
    InstanceId: string;
    ExtractionDefinitionId: string;
}
export interface ExtractionDefinition {
    Name: string;
    ExtractionDefinitionId: string;
    ExtractionDefinitionArn: string;
    ExtractionConfiguration: ExtractionConfiguration;
    Display?: ExtractionDefinitionDisplay;
    CreatedTime: Date;
    LastUpdatedTime: Date;
    LastUpdatedBy: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeExtractionDefinitionResponse {
    ExtractionDefinition: ExtractionDefinition;
}
export interface DescribeHoursOfOperationRequest {
    InstanceId: string;
    HoursOfOperationId: string;
}
export interface HoursOfOperationsIdentifier {
    Name: string;
    Id: string;
    Arn?: string;
}
export type ParentHoursOfOperationsList = HoursOfOperationsIdentifier[];
export interface HoursOfOperation {
    HoursOfOperationId?: string;
    HoursOfOperationArn?: string;
    Name?: string;
    Description?: string;
    TimeZone?: string;
    Config?: HoursOfOperationConfig[];
    ParentHoursOfOperations?: HoursOfOperationsIdentifier[];
    Tags?: {
        [key: string]: string | undefined;
    };
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface DescribeHoursOfOperationResponse {
    HoursOfOperation?: HoursOfOperation;
}
export interface DescribeHoursOfOperationOverrideRequest {
    InstanceId: string;
    HoursOfOperationId: string;
    HoursOfOperationOverrideId: string;
}
export interface HoursOfOperationOverride {
    HoursOfOperationOverrideId?: string;
    HoursOfOperationId?: string;
    HoursOfOperationArn?: string;
    Name?: string;
    Description?: string;
    Config?: HoursOfOperationOverrideConfig[];
    EffectiveFrom?: string;
    EffectiveTill?: string;
    RecurrenceConfig?: RecurrenceConfig;
    OverrideType?: OverrideType;
}
export interface DescribeHoursOfOperationOverrideResponse {
    HoursOfOperationOverride?: HoursOfOperationOverride;
}
export interface DescribeInstanceRequest {
    InstanceId: string;
}
export type InstanceStatus = "CREATION_IN_PROGRESS" | "ACTIVE" | "CREATION_FAILED" | (string & {});
export interface InstanceStatusReason {
    Message?: string;
}
export type Url = string;
export interface Instance {
    Id?: string;
    Arn?: string;
    IdentityManagementType?: DirectoryType;
    InstanceAlias?: string | redacted.Redacted<string>;
    CreatedTime?: Date;
    ServiceRole?: string;
    InstanceStatus?: InstanceStatus;
    StatusReason?: InstanceStatusReason;
    InboundCallsEnabled?: boolean;
    OutboundCallsEnabled?: boolean;
    InstanceAccessUrl?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type AwsRegion = string;
export type InstanceReplicationStatus = "INSTANCE_REPLICATION_COMPLETE" | "INSTANCE_REPLICATION_IN_PROGRESS" | "INSTANCE_REPLICATION_FAILED" | "INSTANCE_REPLICA_DELETING" | "INSTANCE_REPLICATION_DELETION_FAILED" | "RESOURCE_REPLICATION_NOT_STARTED" | (string & {});
export type ReplicationStatusReason = string;
export interface ReplicationStatusSummary {
    Region?: string;
    ReplicationStatus?: InstanceReplicationStatus;
    ReplicationStatusReason?: string;
}
export type ReplicationStatusSummaryList = ReplicationStatusSummary[];
export type GlobalSignInEndpoint = string;
export interface ReplicationConfiguration {
    ReplicationStatusSummaryList?: ReplicationStatusSummary[];
    SourceRegion?: string;
    GlobalSignInEndpoint?: string;
}
export interface DescribeInstanceResponse {
    Instance?: Instance;
    ReplicationConfiguration?: ReplicationConfiguration;
}
export type InstanceAttributeType = "INBOUND_CALLS" | "OUTBOUND_CALLS" | "CONTACTFLOW_LOGS" | "CONTACT_LENS" | "AUTO_RESOLVE_BEST_VOICES" | "USE_CUSTOM_TTS_VOICES" | "EARLY_MEDIA" | "MULTI_PARTY_CONFERENCE" | "AUTO_MUTE_AGENT_ON_HOLD" | "HIGH_VOLUME_OUTBOUND" | "ENHANCED_CONTACT_MONITORING" | "ENHANCED_CHAT_MONITORING" | "MULTI_PARTY_CHAT_CONFERENCE" | "MESSAGE_STREAMING" | (string & {});
export interface DescribeInstanceAttributeRequest {
    InstanceId: string;
    AttributeType: InstanceAttributeType;
}
export type InstanceAttributeValue = string;
export interface Attribute {
    AttributeType?: InstanceAttributeType;
    Value?: string;
}
export interface DescribeInstanceAttributeResponse {
    Attribute?: Attribute;
}
export interface DescribeInstanceStorageConfigRequest {
    InstanceId: string;
    AssociationId: string;
    ResourceType: InstanceStorageResourceType;
}
export interface DescribeInstanceStorageConfigResponse {
    StorageConfig?: InstanceStorageConfig;
}
export interface DescribeMetricRequest {
    InstanceId: string;
    MetricId: string;
}
export type MetricCreationMethod = "SERVICE_LEVEL_BUILDER" | "METRIC_BUILDER" | (string & {});
export type MetricType = "AWS_MANAGED" | "CUSTOMER_MANAGED" | (string & {});
export type MetricGroupingList = string[];
export type FilterId = string;
export type AvailableFilterType = "METRIC_LEVEL" | "RESOURCE_LEVEL" | (string & {});
export interface AvailableFilter {
    Id?: string;
    Type?: AvailableFilterType;
}
export type AvailableFilterList = AvailableFilter[];
export type RefreshRate = number;
export type MetricCategory = string;
export type SupportedStatsList = string[];
export type DefaultStat = string;
export type SupportsPreaggregateCalculation = boolean;
export type SupportsCustomCalculation = boolean;
export type PrimaryEventSource = string;
export type PrimaryEventSourceEffectiveTimestampType = string;
export interface MetricDefinition {
    Arn: string;
    Id: string;
    Name: string;
    Description?: string;
    MetricCalculation?: MetricCalculation;
    CreationMethod?: MetricCreationMethod;
    Status?: MetricStatus;
    Type: MetricType;
    Unit: MetricUnit;
    PositiveTrendIndicator?: TrendIndicator;
    Groupings: string[];
    Filters: AvailableFilter[];
    EffectiveTime?: Date;
    RefreshRate?: number;
    Category: string;
    SupportedStats?: string[];
    DefaultStat?: string;
    SupportsPreaggregateCalculation: boolean;
    SupportsCustomCalculation: boolean;
    PrimaryEventSource?: string;
    PrimaryEventSourceEffectiveTimestampType?: string;
    CreatedTime?: Date;
    CreatedUser?: CreatedByInfo;
    LastModifiedRegion?: string;
    LastModifiedTime?: Date;
    LastModifiedUser?: CreatedByInfo;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeMetricResponse {
    Metric: MetricDefinition;
}
export interface DescribeNotificationRequest {
    InstanceId: string;
    NotificationId: string;
}
export type NotificationPriority = "URGENT" | "HIGH" | "LOW" | (string & {});
export interface Notification {
    Content?: {
        [key: string]: string | undefined;
    };
    Id: string;
    Arn: string;
    Priority?: NotificationPriority;
    Recipients?: string[];
    LastModifiedTime: Date;
    CreatedAt?: Date;
    ExpiresAt?: Date;
    LastModifiedRegion?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeNotificationResponse {
    Notification: Notification;
}
export interface DescribePhoneNumberRequest {
    PhoneNumberId: string;
}
export type PhoneNumberCountryCode = "AF" | "AL" | "DZ" | "AS" | "AD" | "AO" | "AI" | "AQ" | "AG" | "AR" | "AM" | "AW" | "AU" | "AT" | "AZ" | "BS" | "BH" | "BD" | "BB" | "BY" | "BE" | "BZ" | "BJ" | "BM" | "BT" | "BO" | "BA" | "BW" | "BR" | "IO" | "VG" | "BN" | "BG" | "BF" | "BI" | "KH" | "CM" | "CA" | "CV" | "KY" | "CF" | "TD" | "CL" | "CN" | "CX" | "CC" | "CO" | "KM" | "CK" | "CR" | "HR" | "CU" | "CW" | "CY" | "CZ" | "CD" | "DK" | "DJ" | "DM" | "DO" | "TL" | "EC" | "EG" | "SV" | "GQ" | "ER" | "EE" | "ET" | "FK" | "FO" | "FJ" | "FI" | "FR" | "PF" | "GA" | "GM" | "GE" | "DE" | "GH" | "GI" | "GR" | "GL" | "GD" | "GU" | "GT" | "GG" | "GN" | "GW" | "GY" | "HT" | "HN" | "HK" | "HU" | "IS" | "IN" | "ID" | "IR" | "IQ" | "IE" | "IM" | "IL" | "IT" | "CI" | "JM" | "JP" | "JE" | "JO" | "KZ" | "KE" | "KI" | "KW" | "KG" | "LA" | "LV" | "LB" | "LS" | "LR" | "LY" | "LI" | "LT" | "LU" | "MO" | "MK" | "MG" | "MW" | "MY" | "MV" | "ML" | "MT" | "MH" | "MR" | "MU" | "YT" | "MX" | "FM" | "MD" | "MC" | "MN" | "ME" | "MS" | "MA" | "MZ" | "MM" | "NA" | "NR" | "NP" | "NL" | "AN" | "NC" | "NZ" | "NI" | "NE" | "NG" | "NU" | "KP" | "MP" | "NO" | "OM" | "PK" | "PW" | "PA" | "PG" | "PY" | "PE" | "PH" | "PN" | "PL" | "PT" | "PR" | "QA" | "CG" | "RE" | "RO" | "RU" | "RW" | "BL" | "SH" | "KN" | "LC" | "MF" | "PM" | "VC" | "WS" | "SM" | "ST" | "SA" | "SN" | "RS" | "SC" | "SL" | "SG" | "SX" | "SK" | "SI" | "SB" | "SO" | "ZA" | "KR" | "ES" | "LK" | "SD" | "SR" | "SJ" | "SZ" | "SE" | "CH" | "SY" | "TW" | "TJ" | "TZ" | "TH" | "TG" | "TK" | "TO" | "TT" | "TN" | "TR" | "TM" | "TC" | "TV" | "VI" | "UG" | "UA" | "AE" | "GB" | "US" | "UY" | "UZ" | "VU" | "VA" | "VE" | "VN" | "WF" | "EH" | "YE" | "ZM" | "ZW" | (string & {});
export type PhoneNumberType = "TOLL_FREE" | "DID" | "UIFN" | "SHARED" | "THIRD_PARTY_TF" | "THIRD_PARTY_DID" | "SHORT_CODE" | (string & {});
export type PhoneNumberWorkflowStatus = "CLAIMED" | "IN_PROGRESS" | "FAILED" | (string & {});
export type PhoneNumberWorkflowMessage = string;
export interface PhoneNumberStatus {
    Status?: PhoneNumberWorkflowStatus;
    Message?: string;
}
export interface ClaimedPhoneNumberSummary {
    PhoneNumberId?: string;
    PhoneNumberArn?: string;
    PhoneNumber?: string;
    PhoneNumberCountryCode?: PhoneNumberCountryCode;
    PhoneNumberType?: PhoneNumberType;
    PhoneNumberDescription?: string;
    TargetArn?: string;
    InstanceId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    PhoneNumberStatus?: PhoneNumberStatus;
    SourcePhoneNumberArn?: string;
}
export interface DescribePhoneNumberResponse {
    ClaimedPhoneNumberSummary?: ClaimedPhoneNumberSummary;
}
export interface DescribePredefinedAttributeRequest {
    InstanceId: string;
    Name: string;
}
export type IsReadOnly = boolean;
export interface PredefinedAttributeConfiguration {
    EnableValueValidationOnAssociation?: boolean;
    IsReadOnly?: boolean;
}
export interface PredefinedAttribute {
    Name?: string;
    Values?: PredefinedAttributeValues;
    Purposes?: string[];
    AttributeConfiguration?: PredefinedAttributeConfiguration;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface DescribePredefinedAttributeResponse {
    PredefinedAttribute?: PredefinedAttribute;
}
export interface DescribePromptRequest {
    InstanceId: string;
    PromptId: string;
}
export interface Prompt {
    PromptARN?: string;
    PromptId?: string;
    Name?: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface DescribePromptResponse {
    Prompt?: Prompt;
}
export interface DescribeQueueRequest {
    InstanceId: string;
    QueueId: string;
}
export type QueueStatus = "ENABLED" | "DISABLED" | (string & {});
export interface Queue {
    Name?: string;
    QueueArn?: string;
    QueueId?: string;
    Description?: string;
    OutboundCallerConfig?: OutboundCallerConfig;
    OutboundEmailConfig?: OutboundEmailConfig;
    HoursOfOperationId?: string;
    MaxContacts?: number;
    Status?: QueueStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface DescribeQueueResponse {
    Queue?: Queue;
}
export interface DescribeQuickConnectRequest {
    InstanceId: string;
    QuickConnectId: string;
}
export interface QuickConnect {
    QuickConnectARN?: string;
    QuickConnectId?: string;
    Name?: string;
    Description?: string;
    QuickConnectConfig?: QuickConnectConfig;
    Tags?: {
        [key: string]: string | undefined;
    };
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface DescribeQuickConnectResponse {
    QuickConnect?: QuickConnect;
}
export interface DescribeRoutingProfileRequest {
    InstanceId: string;
    RoutingProfileId: string;
}
export type AssociatedQueueIdList = string[];
export interface RoutingProfile {
    InstanceId?: string;
    Name?: string;
    RoutingProfileArn?: string;
    RoutingProfileId?: string;
    Description?: string;
    MediaConcurrencies?: MediaConcurrency[];
    DefaultOutboundQueueId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    NumberOfAssociatedQueues?: number;
    NumberOfAssociatedManualAssignmentQueues?: number;
    NumberOfAssociatedUsers?: number;
    AgentAvailabilityTimer?: AgentAvailabilityTimer;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
    IsDefault?: boolean;
    AssociatedQueueIds?: string[];
    AssociatedManualAssignmentQueueIds?: string[];
}
export interface DescribeRoutingProfileResponse {
    RoutingProfile?: RoutingProfile;
}
export interface DescribeRuleRequest {
    InstanceId: string;
    RuleId: string;
}
export type RuleCapabilityTier = "GenerativeAI" | (string & {});
export type RuleCapabilityTiers = RuleCapabilityTier[];
export interface Rule {
    Name: string;
    RuleId: string;
    RuleArn: string;
    TriggerEventSource: RuleTriggerEventSource;
    RuleCapabilityTiers?: RuleCapabilityTier[];
    Function: string;
    Actions: RuleAction[];
    PublishStatus: RulePublishStatus;
    PreEvaluationFilters?: PreEvaluationFilters;
    CreatedTime: Date;
    LastUpdatedTime: Date;
    LastUpdatedBy: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeRuleResponse {
    Rule: Rule;
}
export interface DescribeSecurityProfileRequest {
    SecurityProfileId: string;
    InstanceId: string;
}
export type SecurityProfileName = string;
export interface SecurityProfile {
    Id?: string;
    OrganizationResourceId?: string;
    Arn?: string;
    SecurityProfileName?: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    AllowedAccessControlTags?: {
        [key: string]: string | undefined;
    };
    TagRestrictedResources?: string[];
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
    HierarchyRestrictedResources?: string[];
    AllowedAccessControlHierarchyGroupId?: string;
    GranularAccessControlConfiguration?: GranularAccessControlConfiguration;
}
export interface DescribeSecurityProfileResponse {
    SecurityProfile?: SecurityProfile;
}
export interface DescribeTestCaseRequest {
    InstanceId: string;
    TestCaseId: string;
    Status?: TestCaseStatus;
}
export type TestCaseSha256 = string;
export interface TestCase {
    Arn?: string;
    Id?: string;
    Name?: string;
    Content?: string;
    EntryPoint?: TestCaseEntryPoint;
    InitializationData?: string;
    Description?: string;
    Status?: TestCaseStatus;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    TestCaseSha256?: string;
}
export interface DescribeTestCaseResponse {
    TestCase?: TestCase;
}
export interface DescribeTrafficDistributionGroupRequest {
    TrafficDistributionGroupId: string;
}
export type ACGRInstanceArn = string;
export type TrafficDistributionGroupStatus = "CREATION_IN_PROGRESS" | "ACTIVE" | "CREATION_FAILED" | "PENDING_DELETION" | "DELETION_FAILED" | "UPDATE_IN_PROGRESS" | (string & {});
export interface TrafficDistributionGroup {
    Id?: string;
    Arn?: string;
    Name?: string;
    Description?: string;
    InstanceArn?: string;
    Status?: TrafficDistributionGroupStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
    IsDefault?: boolean;
}
export interface DescribeTrafficDistributionGroupResponse {
    TrafficDistributionGroup?: TrafficDistributionGroup;
}
export interface DescribeUserRequest {
    UserId: string;
    InstanceId: string;
}
export interface User {
    Id?: string;
    Arn?: string;
    Username?: string;
    IdentityInfo?: UserIdentityInfo;
    PhoneConfig?: UserPhoneConfig;
    DirectoryUserId?: string;
    SecurityProfileIds?: string[];
    RoutingProfileId?: string;
    HierarchyGroupId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    AutoAcceptConfigs?: AutoAcceptConfig[];
    AfterContactWorkConfigs?: AfterContactWorkConfigPerChannel[];
    PhoneNumberConfigs?: PhoneNumberConfig[];
    PersistentConnectionConfigs?: PersistentConnectionConfig[];
    VoiceEnhancementConfigs?: VoiceEnhancementConfig[];
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface DescribeUserResponse {
    User?: User;
}
export interface DescribeUserHierarchyGroupRequest {
    HierarchyGroupId: string;
    InstanceId: string;
}
export type HierarchyLevelId = string;
export interface HierarchyGroupSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface HierarchyPath {
    LevelOne?: HierarchyGroupSummary;
    LevelTwo?: HierarchyGroupSummary;
    LevelThree?: HierarchyGroupSummary;
    LevelFour?: HierarchyGroupSummary;
    LevelFive?: HierarchyGroupSummary;
}
export interface HierarchyGroup {
    Id?: string;
    Arn?: string;
    Name?: string;
    LevelId?: string;
    HierarchyPath?: HierarchyPath;
    Tags?: {
        [key: string]: string | undefined;
    };
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface DescribeUserHierarchyGroupResponse {
    HierarchyGroup?: HierarchyGroup;
}
export interface DescribeUserHierarchyStructureRequest {
    InstanceId: string;
}
export type HierarchyLevelName = string;
export interface HierarchyLevel {
    Id?: string;
    Arn?: string;
    Name?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface HierarchyStructure {
    LevelOne?: HierarchyLevel;
    LevelTwo?: HierarchyLevel;
    LevelThree?: HierarchyLevel;
    LevelFour?: HierarchyLevel;
    LevelFive?: HierarchyLevel;
}
export interface DescribeUserHierarchyStructureResponse {
    HierarchyStructure?: HierarchyStructure;
}
export interface DescribeViewRequest {
    InstanceId: string;
    ViewId: string;
}
export interface DescribeViewResponse {
    View?: View;
}
export interface DescribeVocabularyRequest {
    InstanceId: string;
    VocabularyId: string;
}
export type VocabularyLastModifiedTime = Date;
export type VocabularyFailureReason = string;
export interface Vocabulary {
    Name: string;
    Id: string;
    Arn: string;
    LanguageCode: VocabularyLanguageCode;
    State: VocabularyState;
    LastModifiedTime: Date;
    FailureReason?: string;
    Content?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeVocabularyResponse {
    Vocabulary: Vocabulary;
}
export interface DescribeWorkspaceRequest {
    InstanceId: string;
    WorkspaceId: string;
}
export type Visibility = "ALL" | "ASSIGNED" | "NONE" | (string & {});
export interface Workspace {
    Visibility?: Visibility;
    Id: string;
    Name: string;
    Arn: string;
    Description?: string;
    Theme?: WorkspaceTheme;
    Title?: string;
    LastModifiedTime: Date;
    LastModifiedRegion?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeWorkspaceResponse {
    Workspace: Workspace;
}
export interface DisassociateAnalyticsDataSetRequest {
    InstanceId: string;
    DataSetId: string;
    TargetAccountId?: string;
}
export interface DisassociateAnalyticsDataSetResponse {
}
export interface DisassociateApprovedOriginRequest {
    InstanceId: string;
    Origin: string;
    ClientToken?: string;
}
export interface DisassociateApprovedOriginResponse {
}
export interface DisassociateBotRequest {
    InstanceId: string;
    LexBot?: LexBot;
    LexV2Bot?: LexV2Bot;
    ClientToken?: string;
}
export interface DisassociateBotResponse {
}
export interface DisassociateEmailAddressAliasRequest {
    EmailAddressId: string;
    InstanceId: string;
    AliasConfiguration: AliasConfiguration;
    ClientToken?: string;
}
export interface DisassociateEmailAddressAliasResponse {
}
export interface DisassociateFlowRequest {
    InstanceId: string;
    ResourceId: string;
    ResourceType: FlowAssociationResourceType;
}
export interface DisassociateFlowResponse {
}
export type ParentHoursOfOperationIdList = string[];
export interface DisassociateHoursOfOperationsRequest {
    InstanceId: string;
    HoursOfOperationId: string;
    ParentHoursOfOperationIds: string[];
}
export interface DisassociateHoursOfOperationsResponse {
}
export interface DisassociateInstanceStorageConfigRequest {
    InstanceId: string;
    AssociationId: string;
    ResourceType: InstanceStorageResourceType;
    ClientToken?: string;
}
export interface DisassociateInstanceStorageConfigResponse {
}
export interface DisassociateLambdaFunctionRequest {
    InstanceId: string;
    FunctionArn: string;
    ClientToken?: string;
}
export interface DisassociateLambdaFunctionResponse {
}
export interface DisassociateLexBotRequest {
    InstanceId: string;
    BotName: string;
    LexRegion: string;
    ClientToken?: string;
}
export interface DisassociateLexBotResponse {
}
export interface DisassociatePhoneNumberContactFlowRequest {
    PhoneNumberId: string;
    InstanceId: string;
}
export interface DisassociatePhoneNumberContactFlowResponse {
}
export type EmailAddressIdList = string[];
export interface DisassociateQueueEmailAddressesRequest {
    InstanceId: string;
    QueueId: string;
    EmailAddressesId: string[];
    ClientToken?: string;
}
export interface DisassociateQueueEmailAddressesResponse {
}
export interface DisassociateQueueQuickConnectsRequest {
    InstanceId: string;
    QueueId: string;
    QuickConnectIds: string[];
}
export interface DisassociateQueueQuickConnectsResponse {
}
export type RoutingProfileQueueReferenceList = RoutingProfileQueueReference[];
export interface DisassociateRoutingProfileQueuesRequest {
    InstanceId: string;
    RoutingProfileId: string;
    QueueReferences?: RoutingProfileQueueReference[];
    ManualAssignmentQueueReferences?: RoutingProfileQueueReference[];
}
export interface DisassociateRoutingProfileQueuesResponse {
}
export interface DisassociateSecurityKeyRequest {
    InstanceId: string;
    AssociationId: string;
    ClientToken?: string;
}
export interface DisassociateSecurityKeyResponse {
}
export interface DisassociateSecurityProfilesRequest {
    InstanceId: string;
    SecurityProfiles: SecurityProfileItem[];
    EntityType: EntityType;
    EntityArn: string;
}
export interface DisassociateSecurityProfilesResponse {
}
export interface DisassociateTrafficDistributionGroupUserRequest {
    TrafficDistributionGroupId: string;
    UserId: string;
    InstanceId: string;
}
export interface DisassociateTrafficDistributionGroupUserResponse {
}
export interface UserProficiencyDisassociate {
    AttributeName: string;
    AttributeValue: string;
}
export type UserProficiencyDisassociateList = UserProficiencyDisassociate[];
export interface DisassociateUserProficienciesRequest {
    InstanceId: string;
    UserId: string;
    UserProficiencies: UserProficiencyDisassociate[];
}
export interface DisassociateUserProficienciesResponse {
}
export interface DisassociateWorkspaceRequest {
    InstanceId: string;
    WorkspaceId: string;
    ResourceArns: string[];
}
export interface DisassociateWorkspaceResponse {
    SuccessfulList?: SuccessfulBatchAssociationSummary[];
    FailedList?: FailedBatchAssociationSummary[];
}
export interface DismissUserContactRequest {
    UserId: string;
    InstanceId: string;
    ContactId: string;
}
export interface DismissUserContactResponse {
}
export type AttributeNameList = string[];
export interface DataTableValueEvaluationSet {
    PrimaryValues?: PrimaryValue[];
    AttributeNames: string[];
}
export type DataTableValueEvaluationSetList = DataTableValueEvaluationSet[];
export type NextToken = string;
export type MaxResult100 = number;
export interface EvaluateDataTableValuesRequest {
    InstanceId: string;
    DataTableId: string;
    Values: DataTableValueEvaluationSet[];
    TimeZone?: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface DataTableEvaluatedValue {
    RecordId: string;
    PrimaryValues: PrimaryValue[];
    AttributeName: string;
    ValueType: DataTableAttributeValueType;
    Found: boolean;
    Error: boolean;
    EvaluatedValue: string;
}
export type DataTableEvaluatedValueList = DataTableEvaluatedValue[];
export interface EvaluateDataTableValuesResponse {
    Values: DataTableEvaluatedValue[];
    NextToken?: string;
}
export type URLExpiryInSeconds = number;
export interface GetAttachedFileRequest {
    InstanceId: string;
    FileId: string;
    UrlExpiryInSeconds?: number;
    AssociatedResourceArn: string;
}
export type MetadataUrl = string;
export interface DownloadUrlMetadata {
    Url?: string;
    UrlExpiry?: string;
}
export interface GetAttachedFileResponse {
    FileArn?: string;
    FileId?: string;
    CreationTime?: string;
    FileStatus?: FileStatusType;
    FileName?: string;
    FileSizeInBytes: number;
    AssociatedResourceArn?: string;
    FileUseCaseType?: FileUseCaseType;
    CreatedBy?: CreatedByInfo;
    DownloadUrlMetadata?: DownloadUrlMetadata;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetContactAttributesRequest {
    InstanceId: string;
    InitialContactId: string;
}
export interface GetContactAttributesResponse {
    Attributes?: {
        [key: string]: string | undefined;
    };
}
export type ContactMetricName = "ESTIMATED_WAIT_TIME" | "POSITION_IN_QUEUE" | (string & {});
export interface ContactMetricInfo {
    Name: ContactMetricName;
}
export type ContactMetrics = ContactMetricInfo[];
export interface GetContactMetricsRequest {
    InstanceId: string;
    ContactId: string;
    Metrics: ContactMetricInfo[];
}
export type ContactMetricValue = {
    Number: number;
};
export interface ContactMetricResult {
    Name: ContactMetricName;
    Value: ContactMetricValue;
}
export type ContactMetricResults = ContactMetricResult[];
export interface GetContactMetricsResponse {
    MetricResults?: ContactMetricResult[];
    Id?: string;
    Arn?: string;
}
export interface GetCrossRegionRoutingRequest {
    InstanceId: string;
}
export type IsolatedRegionsList = string[];
export interface GetCrossRegionRoutingResponse {
    IsolatedRegions?: string[];
}
export type Queues = string[];
export type Channels = Channel[];
export type RoutingProfiles = string[];
export type RoutingExpression = string;
export type RoutingExpressions = string[];
export type AgentStatuses = string[];
export type Subtype = string;
export type Subtypes = string[];
export type ValidationTestType = string;
export type ValidationTestTypes = string[];
export interface Filters {
    Queues?: string[];
    Channels?: Channel[];
    RoutingProfiles?: string[];
    RoutingStepExpressions?: string[];
    AgentStatuses?: string[];
    Subtypes?: string[];
    ValidationTestTypes?: string[];
}
export type Grouping = "QUEUE" | "CHANNEL" | "ROUTING_PROFILE" | "ROUTING_STEP_EXPRESSION" | "AGENT_STATUS" | "SUBTYPE" | "VALIDATION_TEST_TYPE" | (string & {});
export type Groupings = Grouping[];
export type CurrentMetricName = "AGENTS_ONLINE" | "AGENTS_AVAILABLE" | "AGENTS_ON_CALL" | "AGENTS_NON_PRODUCTIVE" | "AGENTS_AFTER_CONTACT_WORK" | "AGENTS_ERROR" | "AGENTS_STAFFED" | "CONTACTS_IN_QUEUE" | "OLDEST_CONTACT_AGE" | "CONTACTS_SCHEDULED" | "AGENTS_ON_CONTACT" | "SLOTS_ACTIVE" | "SLOTS_AVAILABLE" | "ESTIMATED_WAIT_TIME" | (string & {});
export type CurrentMetricId = string;
export type Unit = "SECONDS" | "COUNT" | "PERCENT" | (string & {});
export interface CurrentMetric {
    Name?: CurrentMetricName;
    MetricId?: string;
    Unit?: Unit;
}
export type CurrentMetrics = CurrentMetric[];
export type SortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export interface CurrentMetricSortCriteria {
    SortByMetric?: CurrentMetricName;
    SortOrder?: SortOrder;
}
export type CurrentMetricSortCriteriaMaxOne = CurrentMetricSortCriteria[];
export interface GetCurrentMetricDataRequest {
    InstanceId: string;
    Filters: Filters;
    Groupings?: Grouping[];
    CurrentMetrics: CurrentMetric[];
    NextToken?: string;
    MaxResults?: number;
    SortCriteria?: CurrentMetricSortCriteria[];
}
export interface QueueReference {
    Id?: string;
    Arn?: string;
}
export interface RoutingProfileReference {
    Id?: string;
    Arn?: string;
}
export interface AgentStatusIdentifier {
    Arn?: string;
    Id?: string;
}
export interface Dimensions {
    Queue?: QueueReference;
    Channel?: Channel;
    RoutingProfile?: RoutingProfileReference;
    RoutingStepExpression?: string;
    AgentStatus?: AgentStatusIdentifier;
    Subtype?: string;
    ValidationTestType?: string;
}
export type Value = number;
export interface CurrentMetricData {
    Metric?: CurrentMetric;
    Value?: number;
}
export type CurrentMetricDataCollections = CurrentMetricData[];
export interface CurrentMetricResult {
    Dimensions?: Dimensions;
    Collections?: CurrentMetricData[];
}
export type CurrentMetricResults = CurrentMetricResult[];
export type ApproximateTotalCount = number;
export interface GetCurrentMetricDataResponse {
    NextToken?: string;
    MetricResults?: CurrentMetricResult[];
    DataSnapshotTime?: Date;
    ApproximateTotalCount?: number;
}
export type ContactState = "INCOMING" | "PENDING" | "CONNECTING" | "CONNECTED" | "CONNECTED_ONHOLD" | "MISSED" | "ERROR" | "ENDED" | "REJECTED" | (string & {});
export type ContactStates = ContactState[];
export interface ContactFilter {
    ContactStates?: ContactState[];
}
export type AgentsMinOneMaxHundred = string[];
export type UserDataHierarchyGroups = string[];
export interface UserDataFilters {
    Queues?: string[];
    ContactFilter?: ContactFilter;
    RoutingProfiles?: string[];
    Agents?: string[];
    UserHierarchyGroups?: string[];
}
export interface GetCurrentUserDataRequest {
    InstanceId: string;
    Filters: UserDataFilters;
    NextToken?: string;
    MaxResults?: number;
}
export interface UserReference {
    Id?: string;
    Arn?: string;
}
export interface HierarchyGroupSummaryReference {
    Id?: string;
    Arn?: string;
}
export interface HierarchyPathReference {
    LevelOne?: HierarchyGroupSummaryReference;
    LevelTwo?: HierarchyGroupSummaryReference;
    LevelThree?: HierarchyGroupSummaryReference;
    LevelFour?: HierarchyGroupSummaryReference;
    LevelFive?: HierarchyGroupSummaryReference;
}
export interface AgentStatusReference {
    StatusStartTimestamp?: Date;
    StatusArn?: string;
    StatusName?: string;
}
export type IntegerCount = number;
export type ChannelToCountMap = {
    [key in Channel]?: number;
};
export interface AgentContactReference {
    ContactId?: string;
    Channel?: Channel;
    InitiationMethod?: ContactInitiationMethod;
    AgentContactState?: ContactState;
    StateStartTimestamp?: Date;
    ConnectedToAgentTimestamp?: Date;
    Queue?: QueueReference;
}
export type AgentContactReferenceList = AgentContactReference[];
export interface UserData {
    User?: UserReference;
    RoutingProfile?: RoutingProfileReference;
    HierarchyPath?: HierarchyPathReference;
    Status?: AgentStatusReference;
    AvailableSlotsByChannel?: {
        [key: string]: number | undefined;
    };
    MaxSlotsByChannel?: {
        [key: string]: number | undefined;
    };
    ActiveSlotsByChannel?: {
        [key: string]: number | undefined;
    };
    Contacts?: AgentContactReference[];
    NextStatus?: string;
}
export type UserDataList = UserData[];
export interface GetCurrentUserDataResponse {
    NextToken?: string;
    UserDataList?: UserData[];
    ApproximateTotalCount?: number;
}
export interface GetEffectiveHoursOfOperationsRequest {
    InstanceId: string;
    HoursOfOperationId: string;
    FromDate: string;
    ToDate: string;
}
export interface OperationalHour {
    Start?: OverrideTimeSlice;
    End?: OverrideTimeSlice;
}
export type OperationalHours = OperationalHour[];
export interface EffectiveHoursOfOperations {
    Date?: string;
    OperationalHours?: OperationalHour[];
}
export type EffectiveHoursOfOperationList = EffectiveHoursOfOperations[];
export type OperationalStatus = "OPEN" | "CLOSED" | (string & {});
export interface OverrideHour {
    Start?: OverrideTimeSlice;
    End?: OverrideTimeSlice;
    OverrideName?: string;
    OperationalStatus?: OperationalStatus;
}
export type OverrideHours = OverrideHour[];
export interface EffectiveOverrideHours {
    Date?: string;
    OverrideHours?: OverrideHour[];
}
export type EffectiveOverrideHoursList = EffectiveOverrideHours[];
export interface GetEffectiveHoursOfOperationsResponse {
    EffectiveHoursOfOperationList?: EffectiveHoursOfOperations[];
    EffectiveOverrideHoursList?: EffectiveOverrideHours[];
    TimeZone?: string;
}
export interface GetEvaluationFormValidationRequest {
    InstanceId: string;
    EvaluationFormId: string;
    EvaluationFormVersion?: number;
}
export type EvaluationFormValidationFailureReason = string;
export type EvaluationFormValidationIssueCode = string;
export type EvaluationFormValidationFindingItemProperty = string;
export interface EvaluationFormValidationFindingItem {
    RefId?: string;
    Property?: string;
}
export type EvaluationFormValidationFindingItemList = EvaluationFormValidationFindingItem[];
export type EvaluationFormValidationFindingDescription = string;
export type EvaluationFormValidationFindingSuggestion = string;
export type EvaluationFormValidationFindingSeverity = "WARNING" | "ERROR" | (string & {});
export interface EvaluationFormValidationFinding {
    IssueCode: string;
    Items?: EvaluationFormValidationFindingItem[];
    Description: string;
    Suggestion?: string;
    Severity: EvaluationFormValidationFindingSeverity;
}
export type EvaluationFormValidationFindingList = EvaluationFormValidationFinding[];
export interface GetEvaluationFormValidationResponse {
    Status: EvaluationFormValidationStatus;
    FailureReason?: string;
    EvaluationFormId: string;
    EvaluationFormVersion: number;
    StartedTime: Date;
    Findings?: EvaluationFormValidationFinding[];
}
export interface GetFederationTokenRequest {
    InstanceId: string;
}
export type SecurityToken = string | redacted.Redacted<string>;
export interface Credentials {
    AccessToken?: string | redacted.Redacted<string>;
    AccessTokenExpiration?: Date;
    RefreshToken?: string | redacted.Redacted<string>;
    RefreshTokenExpiration?: Date;
}
export interface GetFederationTokenResponse {
    UserId?: string;
    UserArn?: string;
    Credentials?: Credentials;
    SignInUrl?: string;
}
export interface GetFlowAssociationRequest {
    InstanceId: string;
    ResourceId: string;
    ResourceType: FlowAssociationResourceType;
}
export interface GetFlowAssociationResponse {
    ResourceId?: string;
    FlowId?: string;
    ResourceType?: FlowAssociationResourceType;
}
export type HistoricalMetricName = "CONTACTS_QUEUED" | "CONTACTS_HANDLED" | "CONTACTS_ABANDONED" | "CONTACTS_CONSULTED" | "CONTACTS_AGENT_HUNG_UP_FIRST" | "CONTACTS_HANDLED_INCOMING" | "CONTACTS_HANDLED_OUTBOUND" | "CONTACTS_HOLD_ABANDONS" | "CONTACTS_TRANSFERRED_IN" | "CONTACTS_TRANSFERRED_OUT" | "CONTACTS_TRANSFERRED_IN_FROM_QUEUE" | "CONTACTS_TRANSFERRED_OUT_FROM_QUEUE" | "CONTACTS_MISSED" | "CALLBACK_CONTACTS_HANDLED" | "API_CONTACTS_HANDLED" | "OCCUPANCY" | "HANDLE_TIME" | "AFTER_CONTACT_WORK_TIME" | "QUEUED_TIME" | "ABANDON_TIME" | "QUEUE_ANSWER_TIME" | "HOLD_TIME" | "INTERACTION_TIME" | "INTERACTION_AND_HOLD_TIME" | "SERVICE_LEVEL" | (string & {});
export type Comparison = "LT" | (string & {});
export type ThresholdValue = number;
export interface Threshold {
    Comparison?: Comparison;
    ThresholdValue?: number;
}
export type Statistic = "SUM" | "MAX" | "AVG" | (string & {});
export interface HistoricalMetric {
    Name?: HistoricalMetricName;
    Threshold?: Threshold;
    Statistic?: Statistic;
    Unit?: Unit;
}
export type HistoricalMetrics = HistoricalMetric[];
export interface GetMetricDataRequest {
    InstanceId: string;
    StartTime: Date;
    EndTime: Date;
    Filters: Filters;
    Groupings?: Grouping[];
    HistoricalMetrics: HistoricalMetric[];
    NextToken?: string;
    MaxResults?: number;
}
export interface HistoricalMetricData {
    Metric?: HistoricalMetric;
    Value?: number;
}
export type HistoricalMetricDataCollections = HistoricalMetricData[];
export interface HistoricalMetricResult {
    Dimensions?: Dimensions;
    Collections?: HistoricalMetricData[];
}
export type HistoricalMetricResults = HistoricalMetricResult[];
export interface GetMetricDataResponse {
    NextToken?: string;
    MetricResults?: HistoricalMetricResult[];
}
export type IntervalPeriod = "FIFTEEN_MIN" | "THIRTY_MIN" | "HOUR" | "DAY" | "WEEK" | "TOTAL" | (string & {});
export interface IntervalDetails {
    TimeZone?: string;
    IntervalPeriod?: IntervalPeriod;
}
export type ResourceArnOrId = string;
export type FilterValueList = string[];
export type FilterV2StringConditionComparisonOperator = "NOT_EXISTS" | (string & {});
export interface FilterV2StringCondition {
    Comparison?: FilterV2StringConditionComparisonOperator;
}
export interface FilterV2 {
    FilterKey?: string;
    FilterValues?: string[];
    StringCondition?: FilterV2StringCondition;
}
export type FiltersV2List = FilterV2[];
export type GroupingV2 = string;
export type GroupingsV2 = string[];
export type MetricNameV2 = string;
export interface ThresholdV2 {
    Comparison?: string;
    ThresholdValue?: number;
}
export type ThresholdCollections = ThresholdV2[];
export type MetricFilterValueList = string[];
export interface MetricFilterV2 {
    MetricFilterKey?: string;
    MetricFilterValues?: string[];
    Negate?: boolean;
}
export type MetricFiltersV2List = MetricFilterV2[];
export interface MetricV2 {
    Name?: string;
    Threshold?: ThresholdV2[];
    MetricId?: string;
    MetricFilters?: MetricFilterV2[];
}
export type MetricsV2 = MetricV2[];
export type NextToken2500 = string;
export interface GetMetricDataV2Request {
    ResourceArn: string;
    StartTime: Date;
    EndTime: Date;
    Interval?: IntervalDetails;
    Filters: FilterV2[];
    Groupings?: string[];
    Metrics: MetricV2[];
    NextToken?: string;
    MaxResults?: number;
}
export type DimensionsV2Key = string;
export type DimensionsV2Value = string;
export type DimensionsV2Map = {
    [key: string]: string | undefined;
};
export interface MetricInterval {
    Interval?: IntervalPeriod;
    StartTime?: Date;
    EndTime?: Date;
}
export interface MetricDataV2 {
    Metric?: MetricV2;
    Value?: number;
}
export type MetricDataCollectionsV2 = MetricDataV2[];
export interface MetricResultV2 {
    Dimensions?: {
        [key: string]: string | undefined;
    };
    MetricInterval?: MetricInterval;
    Collections?: MetricDataV2[];
}
export type MetricResultsV2 = MetricResultV2[];
export interface GetMetricDataV2Response {
    NextToken?: string;
    MetricResults?: MetricResultV2[];
}
export interface GetPromptFileRequest {
    InstanceId: string;
    PromptId: string;
}
export type PromptPresignedUrl = string;
export interface GetPromptFileResponse {
    PromptPresignedUrl?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export type SnapshotVersion = string;
export interface GetTaskTemplateRequest {
    InstanceId: string;
    TaskTemplateId: string;
    SnapshotVersion?: string;
}
export interface GetTaskTemplateResponse {
    InstanceId?: string;
    Id: string;
    Arn: string;
    Name: string;
    Description?: string;
    ContactFlowId?: string;
    SelfAssignFlowId?: string;
    Constraints?: TaskTemplateConstraints;
    Defaults?: TaskTemplateDefaults;
    Fields?: TaskTemplateField[];
    Status?: TaskTemplateStatus;
    LastModifiedTime?: Date;
    CreatedTime?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type TestCaseExecutionId = string;
export interface GetTestCaseExecutionSummaryRequest {
    InstanceId: string;
    TestCaseId: string;
    TestCaseExecutionId: string;
}
export type TestCaseExecutionStatus = "INITIATED" | "PASSED" | "FAILED" | "IN_PROGRESS" | "STOPPED" | (string & {});
export interface ObservationSummary {
    TotalObservations?: number;
    ObservationsPassed?: number;
    ObservationsFailed?: number;
}
export interface GetTestCaseExecutionSummaryResponse {
    StartTime?: Date;
    EndTime?: Date;
    Status?: TestCaseExecutionStatus;
    ObservationSummary?: ObservationSummary;
}
export interface GetTrafficDistributionRequest {
    Id: string;
}
export type Percentage = number;
export interface Distribution {
    Region: string;
    Percentage: number;
}
export type DistributionList = Distribution[];
export interface TelephonyConfig {
    Distributions: Distribution[];
}
export interface SignInDistribution {
    Region: string;
    Enabled: boolean;
}
export type SignInDistributionList = SignInDistribution[];
export interface SignInConfig {
    Distributions: SignInDistribution[];
}
export interface AgentConfig {
    Distributions: Distribution[];
}
export interface GetTrafficDistributionResponse {
    TelephonyConfig?: TelephonyConfig;
    Id?: string;
    Arn?: string;
    SignInConfig?: SignInConfig;
    AgentConfig?: AgentConfig;
}
export interface ImportPhoneNumberRequest {
    InstanceId: string;
    SourcePhoneNumberArn: string;
    PhoneNumberDescription?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
}
export interface ImportPhoneNumberResponse {
    PhoneNumberId?: string;
    PhoneNumberArn?: string;
}
export type MediaSource = string;
export interface ImportWorkspaceMediaRequest {
    InstanceId: string;
    WorkspaceId: string;
    MediaType: MediaType;
    MediaSource: string;
}
export interface ImportWorkspaceMediaResponse {
}
export type MaxResult1000 = number;
export type AgentStatusTypes = AgentStatusType[];
export interface ListAgentStatusRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    AgentStatusTypes?: AgentStatusType[];
}
export interface AgentStatusSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    Type?: AgentStatusType;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export type AgentStatusSummaryList = AgentStatusSummary[];
export interface ListAgentStatusResponse {
    NextToken?: string;
    AgentStatusSummaryList?: AgentStatusSummary[];
}
export interface ListAnalyticsDataAssociationsRequest {
    InstanceId: string;
    DataSetId?: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface ListAnalyticsDataAssociationsResponse {
    Results?: AnalyticsDataAssociationResult[];
    NextToken?: string;
}
export interface ListAnalyticsDataLakeDataSetsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface AnalyticsDataSetsResult {
    DataSetId?: string;
    DataSetName?: string;
}
export type AnalyticsDataSetsResults = AnalyticsDataSetsResult[];
export interface ListAnalyticsDataLakeDataSetsResponse {
    Results?: AnalyticsDataSetsResult[];
    NextToken?: string;
}
export type MaxResult25 = number;
export interface ListApprovedOriginsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export type OriginsList = string[];
export interface ListApprovedOriginsResponse {
    Origins?: string[];
    NextToken?: string;
}
export type ListAssociatedContactsRequestMaxResults = number;
export interface ListAssociatedContactsRequest {
    InstanceId: string;
    ContactId: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface AssociatedContactSummary {
    ContactId?: string;
    ContactArn?: string;
    InitiationTimestamp?: Date;
    DisconnectTimestamp?: Date;
    InitialContactId?: string;
    PreviousContactId?: string;
    RelatedContactId?: string;
    InitiationMethod?: ContactInitiationMethod;
    Channel?: Channel;
}
export type AssociatedContactSummaryList = AssociatedContactSummary[];
export interface ListAssociatedContactsResponse {
    ContactSummaryList?: AssociatedContactSummary[];
    NextToken?: string;
}
export interface ListAttachedFilesConfigurationsRequest {
    InstanceId: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface AttachedFilesConfigurationSummary {
    InstanceId: string;
    AttachmentScope: AttachmentScope;
    MaximumSizeLimitInBytes?: number;
    ExtensionConfiguration?: ExtensionConfiguration;
}
export type AttachedFilesConfigurationSummaryList = AttachedFilesConfigurationSummary[];
export interface ListAttachedFilesConfigurationsResponse {
    AttachedFilesConfigurations?: AttachedFilesConfigurationSummary[];
    NextToken?: string;
}
export interface ListAuthenticationProfilesRequest {
    InstanceId: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface AuthenticationProfileSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    IsDefault?: boolean;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export type AuthenticationProfileSummaryList = AuthenticationProfileSummary[];
export interface ListAuthenticationProfilesResponse {
    AuthenticationProfileSummaryList?: AuthenticationProfileSummary[];
    NextToken?: string;
}
export type LexVersion = "V1" | "V2" | (string & {});
export interface ListBotsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    LexVersion: LexVersion;
}
export interface LexBotConfig {
    LexBot?: LexBot;
    LexV2Bot?: LexV2Bot;
}
export type LexBotConfigList = LexBotConfig[];
export interface ListBotsResponse {
    LexBots?: LexBotConfig[];
    NextToken?: string;
}
export interface ListChildHoursOfOperationsRequest {
    InstanceId: string;
    HoursOfOperationId: string;
    NextToken?: string;
    MaxResults?: number;
}
export type ChildHoursOfOperationsList = HoursOfOperationsIdentifier[];
export interface ListChildHoursOfOperationsResponse {
    NextToken?: string;
    ChildHoursOfOperationsSummaryList?: HoursOfOperationsIdentifier[];
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface ListContactEvaluationsRequest {
    InstanceId: string;
    ContactId: string;
    NextToken?: string;
}
export interface EvaluationAcknowledgementSummary {
    AcknowledgedTime?: Date;
    AcknowledgedBy?: string;
    AcknowledgerComment?: string;
}
export interface EvaluationSummary {
    EvaluationId: string;
    EvaluationArn: string;
    EvaluationFormTitle: string;
    EvaluationFormId: string;
    CalibrationSessionId?: string;
    Status: EvaluationStatus;
    AutoEvaluationEnabled?: boolean;
    AutoEvaluationStatus?: AutoEvaluationStatus;
    EvaluatorArn: string;
    Score?: EvaluationScore;
    Acknowledgement?: EvaluationAcknowledgementSummary;
    EvaluationType?: EvaluationType;
    CreatedTime: Date;
    LastModifiedTime: Date;
    ContactParticipant?: EvaluationContactParticipant;
}
export type EvaluationSummaryList = EvaluationSummary[];
export interface ListContactEvaluationsResponse {
    EvaluationSummaryList: EvaluationSummary[];
    NextToken?: string;
}
export interface ListContactFlowModuleAliasesRequest {
    InstanceId: string;
    ContactFlowModuleId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface ContactFlowModuleAliasSummary {
    Arn?: string;
    AliasId?: string;
    Version?: number;
    AliasName?: string;
    AliasDescription?: string;
    LastModifiedTime?: Date;
}
export type ContactFlowModuleAliasSummaryList = ContactFlowModuleAliasSummary[];
export interface ListContactFlowModuleAliasesResponse {
    ContactFlowModuleAliasSummaryList?: ContactFlowModuleAliasSummary[];
    NextToken?: string;
}
export interface ListContactFlowModulesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    ContactFlowModuleState?: ContactFlowModuleState;
}
export interface ContactFlowModuleSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    State?: ContactFlowModuleState;
}
export type ContactFlowModulesSummaryList = ContactFlowModuleSummary[];
export interface ListContactFlowModulesResponse {
    ContactFlowModulesSummaryList?: ContactFlowModuleSummary[];
    NextToken?: string;
}
export interface ListContactFlowModuleVersionsRequest {
    InstanceId: string;
    ContactFlowModuleId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface ContactFlowModuleVersionSummary {
    Arn?: string;
    VersionDescription?: string;
    Version?: number;
}
export type ContactFlowModuleVersionSummaryList = ContactFlowModuleVersionSummary[];
export interface ListContactFlowModuleVersionsResponse {
    ContactFlowModuleVersionSummaryList?: ContactFlowModuleVersionSummary[];
    NextToken?: string;
}
export type ContactFlowTypes = ContactFlowType[];
export interface ListContactFlowsRequest {
    InstanceId: string;
    ContactFlowTypes?: ContactFlowType[];
    NextToken?: string;
    MaxResults?: number;
}
export interface ContactFlowSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    ContactFlowType?: ContactFlowType;
    ContactFlowState?: ContactFlowState;
    ContactFlowStatus?: ContactFlowStatus;
}
export type ContactFlowSummaryList = ContactFlowSummary[];
export interface ListContactFlowsResponse {
    ContactFlowSummaryList?: ContactFlowSummary[];
    NextToken?: string;
}
export interface ListContactFlowVersionsRequest {
    InstanceId: string;
    ContactFlowId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface ContactFlowVersionSummary {
    Arn?: string;
    VersionDescription?: string;
    Version?: number;
}
export type ContactFlowVersionSummaryList = ContactFlowVersionSummary[];
export interface ListContactFlowVersionsResponse {
    ContactFlowVersionSummaryList?: ContactFlowVersionSummary[];
    NextToken?: string;
}
export type ReferenceTypes = ReferenceType[];
export interface ListContactReferencesRequest {
    InstanceId: string;
    ContactId: string;
    ReferenceTypes: ReferenceType[];
    NextToken?: string;
}
export interface UrlReference {
    Name?: string;
    Value?: string;
}
export interface AttachmentReference {
    Name?: string;
    Value?: string;
    Status?: ReferenceStatus;
    Arn?: string;
}
export interface EmailMessageReference {
    Name?: string;
    Arn?: string;
}
export interface StringReference {
    Name?: string;
    Value?: string;
}
export interface NumberReference {
    Name?: string;
    Value?: string;
}
export interface DateReference {
    Name?: string;
    Value?: string;
}
export interface EmailReference {
    Name?: string;
    Value?: string;
}
export type AnalyticsMode = "PostContact" | "RealTime" | "ContactLens" | "AutomatedInteraction" | (string & {});
export interface ContactAnalysisReference {
    Name?: string;
    Value?: string;
    Status?: ReferenceStatus;
    Arn?: string;
    AnalyticsMode?: AnalyticsMode;
    IsRedacted?: boolean;
}
export type ReferenceSummary = {
    Url: UrlReference;
    Attachment?: never;
    EmailMessage?: never;
    EmailMessageRedacted?: never;
    EmailMessagePlainText?: never;
    EmailMessagePlainTextRedacted?: never;
    String?: never;
    Number?: never;
    Date?: never;
    Email?: never;
    ContactAnalysis?: never;
} | {
    Url?: never;
    Attachment: AttachmentReference;
    EmailMessage?: never;
    EmailMessageRedacted?: never;
    EmailMessagePlainText?: never;
    EmailMessagePlainTextRedacted?: never;
    String?: never;
    Number?: never;
    Date?: never;
    Email?: never;
    ContactAnalysis?: never;
} | {
    Url?: never;
    Attachment?: never;
    EmailMessage: EmailMessageReference;
    EmailMessageRedacted?: never;
    EmailMessagePlainText?: never;
    EmailMessagePlainTextRedacted?: never;
    String?: never;
    Number?: never;
    Date?: never;
    Email?: never;
    ContactAnalysis?: never;
} | {
    Url?: never;
    Attachment?: never;
    EmailMessage?: never;
    EmailMessageRedacted: EmailMessageReference;
    EmailMessagePlainText?: never;
    EmailMessagePlainTextRedacted?: never;
    String?: never;
    Number?: never;
    Date?: never;
    Email?: never;
    ContactAnalysis?: never;
} | {
    Url?: never;
    Attachment?: never;
    EmailMessage?: never;
    EmailMessageRedacted?: never;
    EmailMessagePlainText: EmailMessageReference;
    EmailMessagePlainTextRedacted?: never;
    String?: never;
    Number?: never;
    Date?: never;
    Email?: never;
    ContactAnalysis?: never;
} | {
    Url?: never;
    Attachment?: never;
    EmailMessage?: never;
    EmailMessageRedacted?: never;
    EmailMessagePlainText?: never;
    EmailMessagePlainTextRedacted: EmailMessageReference;
    String?: never;
    Number?: never;
    Date?: never;
    Email?: never;
    ContactAnalysis?: never;
} | {
    Url?: never;
    Attachment?: never;
    EmailMessage?: never;
    EmailMessageRedacted?: never;
    EmailMessagePlainText?: never;
    EmailMessagePlainTextRedacted?: never;
    String: StringReference;
    Number?: never;
    Date?: never;
    Email?: never;
    ContactAnalysis?: never;
} | {
    Url?: never;
    Attachment?: never;
    EmailMessage?: never;
    EmailMessageRedacted?: never;
    EmailMessagePlainText?: never;
    EmailMessagePlainTextRedacted?: never;
    String?: never;
    Number: NumberReference;
    Date?: never;
    Email?: never;
    ContactAnalysis?: never;
} | {
    Url?: never;
    Attachment?: never;
    EmailMessage?: never;
    EmailMessageRedacted?: never;
    EmailMessagePlainText?: never;
    EmailMessagePlainTextRedacted?: never;
    String?: never;
    Number?: never;
    Date: DateReference;
    Email?: never;
    ContactAnalysis?: never;
} | {
    Url?: never;
    Attachment?: never;
    EmailMessage?: never;
    EmailMessageRedacted?: never;
    EmailMessagePlainText?: never;
    EmailMessagePlainTextRedacted?: never;
    String?: never;
    Number?: never;
    Date?: never;
    Email: EmailReference;
    ContactAnalysis?: never;
} | {
    Url?: never;
    Attachment?: never;
    EmailMessage?: never;
    EmailMessageRedacted?: never;
    EmailMessagePlainText?: never;
    EmailMessagePlainTextRedacted?: never;
    String?: never;
    Number?: never;
    Date?: never;
    Email?: never;
    ContactAnalysis: ContactAnalysisReference;
};
export type ReferenceSummaryList = ReferenceSummary[];
export interface ListContactReferencesResponse {
    ReferenceSummaryList?: ReferenceSummary[];
    NextToken?: string;
}
export type AttributeIds = string[];
export interface ListDataTableAttributesRequest {
    InstanceId: string;
    DataTableId: string;
    AttributeIds?: string[];
    NextToken?: string;
    MaxResults?: number;
}
export type AttributeList = DataTableAttribute[];
export interface ListDataTableAttributesResponse {
    NextToken?: string;
    Attributes: DataTableAttribute[];
}
export type RecordIds = string[];
export type ValueList = string[];
export interface PrimaryAttributeValueFilter {
    AttributeName: string;
    Values: string[];
}
export type PrimaryAttributeValueFilters = PrimaryAttributeValueFilter[];
export interface ListDataTablePrimaryValuesRequest {
    InstanceId: string;
    DataTableId: string;
    RecordIds?: string[];
    PrimaryAttributeValues?: PrimaryAttributeValueFilter[];
    NextToken?: string;
    MaxResults?: number;
}
export interface RecordPrimaryValue {
    RecordId?: string;
    PrimaryValues?: PrimaryValueResponse[];
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export type PrimaryValuesList = RecordPrimaryValue[];
export interface ListDataTablePrimaryValuesResponse {
    NextToken?: string;
    PrimaryValuesList: RecordPrimaryValue[];
}
export interface ListDataTablesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface DataTableSummary {
    Name?: string;
    Id?: string;
    Arn?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export type DataTableSummaryList = DataTableSummary[];
export interface ListDataTablesResponse {
    NextToken?: string;
    DataTableSummaryList: DataTableSummary[];
}
export interface ListDataTableValuesRequest {
    InstanceId: string;
    DataTableId: string;
    RecordIds?: string[];
    PrimaryAttributeValues?: PrimaryAttributeValueFilter[];
    NextToken?: string;
    MaxResults?: number;
}
export interface DataTableValueSummary {
    RecordId?: string;
    AttributeId?: string;
    PrimaryValues: PrimaryValueResponse[];
    AttributeName: string;
    ValueType: DataTableAttributeValueType;
    Value: string;
    LockVersion?: DataTableLockVersion;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export type DataTableValueSummaryList = DataTableValueSummary[];
export interface ListDataTableValuesResponse {
    NextToken?: string;
    Values: DataTableValueSummary[];
}
export type VocabularyNextToken = string;
export interface ListDefaultVocabulariesRequest {
    InstanceId: string;
    LanguageCode?: VocabularyLanguageCode;
    MaxResults?: number;
    NextToken?: string;
}
export interface DefaultVocabulary {
    InstanceId: string;
    LanguageCode: VocabularyLanguageCode;
    VocabularyId: string;
    VocabularyName: string;
}
export type DefaultVocabularyList = DefaultVocabulary[];
export interface ListDefaultVocabulariesResponse {
    DefaultVocabularyList: DefaultVocabulary[];
    NextToken?: string;
}
export interface ListEntitySecurityProfilesRequest {
    InstanceId: string;
    EntityType: EntityType;
    EntityArn: string;
    NextToken?: string;
    MaxResults?: number;
}
export type SecurityProfiles100 = SecurityProfileItem[];
export interface ListEntitySecurityProfilesResponse {
    SecurityProfiles?: SecurityProfileItem[];
    NextToken?: string;
}
export interface ListEvaluationFormAIVersionsRequest {
    InstanceId: string;
    ContactInteractionType: ContactInteractionType;
    MaxResults?: number;
    NextToken?: string;
}
export type EvaluationFormAIVersionStatus = "LATEST" | "PREVIEW" | "ACTIVE" | "DEPRECATED" | (string & {});
export interface EvaluationFormAIVersionLifecycle {
    Status: EvaluationFormAIVersionStatus;
    StartOfLifeTime: Date;
    EndOfLifeTime?: Date;
}
export interface EvaluationFormAIVersionSummary {
    AIVersionName: string;
    AIVersionLifecycle: EvaluationFormAIVersionLifecycle;
}
export type EvaluationFormAIVersionSummaryList = EvaluationFormAIVersionSummary[];
export interface ListEvaluationFormAIVersionsResponse {
    AIVersionSummaries: EvaluationFormAIVersionSummary[];
    NextToken?: string;
}
export interface ListEvaluationFormsRequest {
    InstanceId: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface EvaluationFormSummary {
    EvaluationFormId: string;
    EvaluationFormArn: string;
    Title: string;
    CreatedTime: Date;
    CreatedBy: string;
    LastModifiedTime: Date;
    LastModifiedBy: string;
    LastActivatedTime?: Date;
    LastActivatedBy?: string;
    LatestVersion: number;
    ActiveVersion?: number;
}
export type EvaluationFormSummaryList = EvaluationFormSummary[];
export interface ListEvaluationFormsResponse {
    EvaluationFormSummaryList: EvaluationFormSummary[];
    NextToken?: string;
}
export interface ListEvaluationFormVersionsRequest {
    InstanceId: string;
    EvaluationFormId: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface EvaluationFormVersionSummary {
    EvaluationFormArn: string;
    EvaluationFormId: string;
    EvaluationFormVersion: number;
    Locked: boolean;
    Status: EvaluationFormVersionStatus;
    CreatedTime: Date;
    CreatedBy: string;
    LastModifiedTime: Date;
    LastModifiedBy: string;
}
export type EvaluationFormVersionSummaryList = EvaluationFormVersionSummary[];
export interface ListEvaluationFormVersionsResponse {
    EvaluationFormVersionSummaryList: EvaluationFormVersionSummary[];
    NextToken?: string;
}
export interface ListExtractionDefinitionsRequest {
    InstanceId: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface ExtractionDefinitionSummary {
    Name: string;
    ExtractionDefinitionId: string;
    ExtractionDefinitionArn: string;
    CreatedTime: Date;
    LastUpdatedTime: Date;
    LastUpdatedBy: string;
}
export type ExtractionDefinitionSummaryList = ExtractionDefinitionSummary[];
export interface ListExtractionDefinitionsResponse {
    ExtractionDefinitionSummaryList: ExtractionDefinitionSummary[];
    NextToken?: string;
}
export interface ListFlowAssociationsRequest {
    InstanceId: string;
    ResourceType?: ListFlowAssociationResourceType;
    NextToken?: string;
    MaxResults?: number;
}
export interface ListFlowAssociationsResponse {
    FlowAssociationSummaryList?: FlowAssociationSummary[];
    NextToken?: string;
}
export interface ListHoursOfOperationOverridesRequest {
    InstanceId: string;
    HoursOfOperationId: string;
    NextToken?: string;
    MaxResults?: number;
}
export type HoursOfOperationOverrideList = HoursOfOperationOverride[];
export interface ListHoursOfOperationOverridesResponse {
    NextToken?: string;
    HoursOfOperationOverrideList?: HoursOfOperationOverride[];
    LastModifiedRegion?: string;
    LastModifiedTime?: Date;
}
export interface ListHoursOfOperationsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export type HoursOfOperationName = string;
export interface HoursOfOperationSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export type HoursOfOperationSummaryList = HoursOfOperationSummary[];
export interface ListHoursOfOperationsResponse {
    HoursOfOperationSummaryList?: HoursOfOperationSummary[];
    NextToken?: string;
}
export type MaxResult7 = number;
export interface ListInstanceAttributesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export type AttributesList = Attribute[];
export interface ListInstanceAttributesResponse {
    Attributes?: Attribute[];
    NextToken?: string;
}
export type MaxResult10 = number;
export interface ListInstancesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface InstanceSummary {
    Id?: string;
    Arn?: string;
    IdentityManagementType?: DirectoryType;
    InstanceAlias?: string | redacted.Redacted<string>;
    CreatedTime?: Date;
    ServiceRole?: string;
    InstanceStatus?: InstanceStatus;
    InboundCallsEnabled?: boolean;
    OutboundCallsEnabled?: boolean;
    InstanceAccessUrl?: string;
}
export type InstanceSummaryList = InstanceSummary[];
export interface ListInstancesResponse {
    InstanceSummaryList?: InstanceSummary[];
    NextToken?: string;
}
export interface ListInstanceStorageConfigsRequest {
    InstanceId: string;
    ResourceType: InstanceStorageResourceType;
    NextToken?: string;
    MaxResults?: number;
}
export type InstanceStorageConfigs = InstanceStorageConfig[];
export interface ListInstanceStorageConfigsResponse {
    StorageConfigs?: InstanceStorageConfig[];
    NextToken?: string;
}
export interface ListIntegrationAssociationsRequest {
    InstanceId: string;
    IntegrationType?: IntegrationType;
    NextToken?: string;
    MaxResults?: number;
    IntegrationArn?: string;
}
export interface IntegrationAssociationSummary {
    IntegrationAssociationId?: string;
    IntegrationAssociationArn?: string;
    InstanceId?: string;
    IntegrationType?: IntegrationType;
    IntegrationArn?: string;
    SourceApplicationUrl?: string;
    SourceApplicationName?: string;
    SourceType?: SourceType;
}
export type IntegrationAssociationSummaryList = IntegrationAssociationSummary[];
export interface ListIntegrationAssociationsResponse {
    IntegrationAssociationSummaryList?: IntegrationAssociationSummary[];
    NextToken?: string;
}
export interface ListLambdaFunctionsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export type FunctionArnsList = string[];
export interface ListLambdaFunctionsResponse {
    LambdaFunctions?: string[];
    NextToken?: string;
}
export interface ListLexBotsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export type LexBotsList = LexBot[];
export interface ListLexBotsResponse {
    LexBots?: LexBot[];
    NextToken?: string;
}
export interface ListMetricsRequest {
    InstanceId: string;
    Type?: MetricType;
    MaxResults?: number;
    NextToken?: string;
}
export interface MetricSummary {
    Arn: string;
    Id: string;
    Name: string;
    Status: MetricStatus;
    Type: MetricType;
    LastModifiedRegion?: string;
    LastModifiedTime?: Date;
}
export type MetricSummaryList = MetricSummary[];
export interface ListMetricsResponse {
    MetricSummaryList: MetricSummary[];
    NextToken?: string;
}
export interface ListNotificationsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export type NotificationSummaryList = Notification[];
export interface ListNotificationsResponse {
    NextToken?: string;
    NotificationSummaryList: Notification[];
}
export type PhoneNumberTypes = PhoneNumberType[];
export type PhoneNumberCountryCodes = PhoneNumberCountryCode[];
export interface ListPhoneNumbersRequest {
    InstanceId: string;
    PhoneNumberTypes?: PhoneNumberType[];
    PhoneNumberCountryCodes?: PhoneNumberCountryCode[];
    NextToken?: string;
    MaxResults?: number;
}
export interface PhoneNumberSummary {
    Id?: string;
    Arn?: string;
    PhoneNumber?: string;
    PhoneNumberType?: PhoneNumberType;
    PhoneNumberCountryCode?: PhoneNumberCountryCode;
}
export type PhoneNumberSummaryList = PhoneNumberSummary[];
export interface ListPhoneNumbersResponse {
    PhoneNumberSummaryList?: PhoneNumberSummary[];
    NextToken?: string;
}
export type LargeNextToken = string;
export type PhoneNumberPrefix = string;
export interface ListPhoneNumbersV2Request {
    TargetArn?: string;
    InstanceId?: string;
    MaxResults?: number;
    NextToken?: string;
    PhoneNumberCountryCodes?: PhoneNumberCountryCode[];
    PhoneNumberTypes?: PhoneNumberType[];
    PhoneNumberPrefix?: string;
}
export interface ListPhoneNumbersSummary {
    PhoneNumberId?: string;
    PhoneNumberArn?: string;
    PhoneNumber?: string;
    PhoneNumberCountryCode?: PhoneNumberCountryCode;
    PhoneNumberType?: PhoneNumberType;
    TargetArn?: string;
    InstanceId?: string;
    PhoneNumberDescription?: string;
    SourcePhoneNumberArn?: string;
}
export type ListPhoneNumbersSummaryList = ListPhoneNumbersSummary[];
export interface ListPhoneNumbersV2Response {
    NextToken?: string;
    ListPhoneNumbersSummaryList?: ListPhoneNumbersSummary[];
}
export interface ListPredefinedAttributesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface PredefinedAttributeSummary {
    Name?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export type PredefinedAttributeSummaryList = PredefinedAttributeSummary[];
export interface ListPredefinedAttributesResponse {
    NextToken?: string;
    PredefinedAttributeSummaryList?: PredefinedAttributeSummary[];
}
export interface ListPromptsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export type PromptName = string;
export interface PromptSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export type PromptSummaryList = PromptSummary[];
export interface ListPromptsResponse {
    PromptSummaryList?: PromptSummary[];
    NextToken?: string;
}
export interface ListQueueEmailAddressesRequest {
    InstanceId: string;
    QueueId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface EmailAddressSummary {
    Id?: string;
    Arn?: string;
    IsDefaultOutboundEmail?: boolean;
}
export type EmailAddressMetadataList = EmailAddressSummary[];
export interface ListQueueEmailAddressesResponse {
    NextToken?: string;
    EmailAddressMetadataList?: EmailAddressSummary[];
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface ListQueueQuickConnectsRequest {
    InstanceId: string;
    QueueId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface QuickConnectSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    QuickConnectType?: QuickConnectType;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export type QuickConnectSummaryList = QuickConnectSummary[];
export interface ListQueueQuickConnectsResponse {
    NextToken?: string;
    QuickConnectSummaryList?: QuickConnectSummary[];
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export type QueueType = "STANDARD" | "AGENT" | (string & {});
export type QueueTypes = QueueType[];
export interface ListQueuesRequest {
    InstanceId: string;
    QueueTypes?: QueueType[];
    NextToken?: string;
    MaxResults?: number;
}
export type QueueName = string;
export interface QueueSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    QueueType?: QueueType;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export type QueueSummaryList = QueueSummary[];
export interface ListQueuesResponse {
    QueueSummaryList?: QueueSummary[];
    NextToken?: string;
}
export type QuickConnectTypes = QuickConnectType[];
export interface ListQuickConnectsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    QuickConnectTypes?: QuickConnectType[];
}
export interface ListQuickConnectsResponse {
    QuickConnectSummaryList?: QuickConnectSummary[];
    NextToken?: string;
}
export type RealTimeContactAnalysisOutputType = "Raw" | "Redacted" | (string & {});
export type RealTimeContactAnalysisSegmentType = "Transcript" | "Categories" | "Issues" | "Event" | "Attachments" | "PostContactSummary" | "ExtractedInformation" | (string & {});
export type RealTimeContactAnalysisSegmentTypes = RealTimeContactAnalysisSegmentType[];
export interface ListRealtimeContactAnalysisSegmentsV2Request {
    InstanceId: string;
    ContactId: string;
    MaxResults?: number;
    NextToken?: string;
    OutputType: RealTimeContactAnalysisOutputType;
    SegmentTypes: RealTimeContactAnalysisSegmentType[];
}
export type RealTimeContactAnalysisSupportedChannel = "VOICE" | "CHAT" | (string & {});
export type RealTimeContactAnalysisStatus = "IN_PROGRESS" | "FAILED" | "COMPLETED" | (string & {});
export type RealTimeContactAnalysisId256 = string;
export type RealTimeContactAnalysisTranscriptContent = string;
export type RealTimeContactAnalysisContentType = string;
export type RealTimeContactAnalysisTimeInstant = Date;
export type RealTimeContactAnalysisTimeData = {
    AbsoluteTime: Date;
};
export type RealTimeContactAnalysisOffset = number;
export interface RealTimeContactAnalysisCharacterInterval {
    BeginOffsetChar: number;
    EndOffsetChar: number;
}
export type RealTimeContactAnalysisCharacterIntervals = RealTimeContactAnalysisCharacterInterval[];
export interface RealTimeContactAnalysisTranscriptItemRedaction {
    CharacterOffsets?: RealTimeContactAnalysisCharacterInterval[];
}
export type RealTimeContactAnalysisSentimentLabel = "POSITIVE" | "NEGATIVE" | "NEUTRAL" | (string & {});
export interface RealTimeContactAnalysisSegmentTranscript {
    Id: string;
    ParticipantId: string;
    ParticipantRole: ParticipantRole;
    DisplayName?: string;
    Content: string;
    ContentType?: string;
    Time: RealTimeContactAnalysisTimeData;
    Redaction?: RealTimeContactAnalysisTranscriptItemRedaction;
    Sentiment?: RealTimeContactAnalysisSentimentLabel;
}
export type RealTimeContactAnalysisCategoryName = string;
export interface RealTimeContactAnalysisTranscriptItemWithCharacterOffsets {
    Id: string;
    CharacterOffsets?: RealTimeContactAnalysisCharacterInterval;
}
export type RealTimeContactAnalysisTranscriptItemsWithCharacterOffsets = RealTimeContactAnalysisTranscriptItemWithCharacterOffsets[];
export interface RealTimeContactAnalysisPointOfInterest {
    TranscriptItems?: RealTimeContactAnalysisTranscriptItemWithCharacterOffsets[];
}
export type RealTimeContactAnalysisPointsOfInterest = RealTimeContactAnalysisPointOfInterest[];
export interface RealTimeContactAnalysisCategoryDetails {
    PointsOfInterest: RealTimeContactAnalysisPointOfInterest[];
}
export type RealTimeContactAnalysisMatchedDetails = {
    [key: string]: RealTimeContactAnalysisCategoryDetails | undefined;
};
export interface RealTimeContactAnalysisSegmentCategories {
    MatchedDetails: {
        [key: string]: RealTimeContactAnalysisCategoryDetails | undefined;
    };
}
export interface RealTimeContactAnalysisTranscriptItemWithContent {
    Content?: string;
    Id: string;
    CharacterOffsets?: RealTimeContactAnalysisCharacterInterval;
}
export type RealTimeContactAnalysisTranscriptItemsWithContent = RealTimeContactAnalysisTranscriptItemWithContent[];
export interface RealTimeContactAnalysisIssueDetected {
    TranscriptItems: RealTimeContactAnalysisTranscriptItemWithContent[];
}
export type RealTimeContactAnalysisIssuesDetected = RealTimeContactAnalysisIssueDetected[];
export interface RealTimeContactAnalysisSegmentIssues {
    IssuesDetected: RealTimeContactAnalysisIssueDetected[];
}
export type RealTimeContactAnalysisEventType = string;
export interface RealTimeContactAnalysisSegmentEvent {
    Id: string;
    ParticipantId?: string;
    ParticipantRole?: ParticipantRole;
    DisplayName?: string;
    EventType: string;
    Time: RealTimeContactAnalysisTimeData;
}
export type AttachmentName = string;
export type ContentType = string;
export type ArtifactId = string;
export type ArtifactStatus = "APPROVED" | "REJECTED" | "IN_PROGRESS" | (string & {});
export interface RealTimeContactAnalysisAttachment {
    AttachmentName: string;
    ContentType?: string;
    AttachmentId: string;
    Status?: ArtifactStatus;
}
export type RealTimeContactAnalysisAttachments = RealTimeContactAnalysisAttachment[];
export interface RealTimeContactAnalysisSegmentAttachments {
    Id: string;
    ParticipantId: string;
    ParticipantRole: ParticipantRole;
    DisplayName?: string;
    Attachments: RealTimeContactAnalysisAttachment[];
    Time: RealTimeContactAnalysisTimeData;
}
export type RealTimeContactAnalysisPostContactSummaryContent = string;
export type RealTimeContactAnalysisPostContactSummaryStatus = "FAILED" | "COMPLETED" | (string & {});
export type RealTimeContactAnalysisPostContactSummaryFailureCode = "QUOTA_EXCEEDED" | "INSUFFICIENT_CONVERSATION_CONTENT" | "FAILED_SAFETY_GUIDELINES" | "INVALID_ANALYSIS_CONFIGURATION" | "INTERNAL_ERROR" | (string & {});
export interface RealTimeContactAnalysisSegmentPostContactSummary {
    Content?: string;
    Status: RealTimeContactAnalysisPostContactSummaryStatus;
    FailureCode?: RealTimeContactAnalysisPostContactSummaryFailureCode;
}
export type RealTimeContactAnalysisExtractedInformationContent = string;
export interface RealTimeContactAnalysisExtractedInformationValue {
    Content: string;
    PointsOfInterest: RealTimeContactAnalysisTranscriptItemWithCharacterOffsets[];
}
export type RealTimeContactAnalysisExtractedInformationValues = RealTimeContactAnalysisExtractedInformationValue[];
export type RealTimeContactAnalysisExtractedInformationFailureCode = "QUOTA_EXCEEDED" | "INSUFFICIENT_CONVERSATION_CONTENT" | "FAILED_SAFETY_GUIDELINES" | "INTERNAL_ERROR" | "MAX_PACKAGE_FEATURE_ONLY" | (string & {});
export interface RealTimeContactAnalysisSegmentExtractedInformation {
    ExtractionDefinitionId: string;
    ExtractionDefinitionName: string;
    ExtractionDefinitionDisplayLabel?: string;
    ExtractedValues?: RealTimeContactAnalysisExtractedInformationValue[];
    FailureCode?: RealTimeContactAnalysisExtractedInformationFailureCode;
}
export type RealtimeContactAnalysisSegment = {
    Transcript: RealTimeContactAnalysisSegmentTranscript;
    Categories?: never;
    Issues?: never;
    Event?: never;
    Attachments?: never;
    PostContactSummary?: never;
    ExtractedInformation?: never;
} | {
    Transcript?: never;
    Categories: RealTimeContactAnalysisSegmentCategories;
    Issues?: never;
    Event?: never;
    Attachments?: never;
    PostContactSummary?: never;
    ExtractedInformation?: never;
} | {
    Transcript?: never;
    Categories?: never;
    Issues: RealTimeContactAnalysisSegmentIssues;
    Event?: never;
    Attachments?: never;
    PostContactSummary?: never;
    ExtractedInformation?: never;
} | {
    Transcript?: never;
    Categories?: never;
    Issues?: never;
    Event: RealTimeContactAnalysisSegmentEvent;
    Attachments?: never;
    PostContactSummary?: never;
    ExtractedInformation?: never;
} | {
    Transcript?: never;
    Categories?: never;
    Issues?: never;
    Event?: never;
    Attachments: RealTimeContactAnalysisSegmentAttachments;
    PostContactSummary?: never;
    ExtractedInformation?: never;
} | {
    Transcript?: never;
    Categories?: never;
    Issues?: never;
    Event?: never;
    Attachments?: never;
    PostContactSummary: RealTimeContactAnalysisSegmentPostContactSummary;
    ExtractedInformation?: never;
} | {
    Transcript?: never;
    Categories?: never;
    Issues?: never;
    Event?: never;
    Attachments?: never;
    PostContactSummary?: never;
    ExtractedInformation: RealTimeContactAnalysisSegmentExtractedInformation;
};
export type RealtimeContactAnalysisSegments = RealtimeContactAnalysisSegment[];
export interface ListRealtimeContactAnalysisSegmentsV2Response {
    Channel: RealTimeContactAnalysisSupportedChannel;
    Status: RealTimeContactAnalysisStatus;
    Segments: RealtimeContactAnalysisSegment[];
    NextToken?: string;
}
export interface ListRoutingProfileManualAssignmentQueuesRequest {
    InstanceId: string;
    RoutingProfileId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface RoutingProfileManualAssignmentQueueConfigSummary {
    QueueId: string;
    QueueArn: string;
    QueueName: string;
    Channel: Channel;
}
export type RoutingProfileManualAssignmentQueueConfigSummaryList = RoutingProfileManualAssignmentQueueConfigSummary[];
export interface ListRoutingProfileManualAssignmentQueuesResponse {
    NextToken?: string;
    RoutingProfileManualAssignmentQueueConfigSummaryList?: RoutingProfileManualAssignmentQueueConfigSummary[];
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface ListRoutingProfileQueuesRequest {
    InstanceId: string;
    RoutingProfileId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface RoutingProfileQueueConfigSummary {
    QueueId: string;
    QueueArn: string;
    QueueName: string;
    Priority: number;
    Delay: number;
    Channel: Channel;
}
export type RoutingProfileQueueConfigSummaryList = RoutingProfileQueueConfigSummary[];
export interface ListRoutingProfileQueuesResponse {
    NextToken?: string;
    RoutingProfileQueueConfigSummaryList?: RoutingProfileQueueConfigSummary[];
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface ListRoutingProfilesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface RoutingProfileSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export type RoutingProfileSummaryList = RoutingProfileSummary[];
export interface ListRoutingProfilesResponse {
    RoutingProfileSummaryList?: RoutingProfileSummary[];
    NextToken?: string;
}
export type MaxResult200 = number;
export interface ListRulesRequest {
    InstanceId: string;
    PublishStatus?: RulePublishStatus;
    EventSourceName?: EventSourceName;
    MaxResults?: number;
    NextToken?: string;
}
export interface ActionSummary {
    ActionType: ActionType;
}
export type ActionSummaries = ActionSummary[];
export interface RuleSummary {
    Name: string;
    RuleId: string;
    RuleArn: string;
    EventSourceName: EventSourceName;
    PublishStatus: RulePublishStatus;
    RuleCapabilityTiers?: RuleCapabilityTier[];
    ActionSummaries: ActionSummary[];
    CreatedTime: Date;
    LastUpdatedTime: Date;
}
export type RuleSummaryList = RuleSummary[];
export interface ListRulesResponse {
    RuleSummaryList: RuleSummary[];
    NextToken?: string;
}
export type MaxResult2 = number;
export interface ListSecurityKeysRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface SecurityKey {
    AssociationId?: string;
    Key?: string;
    CreationTime?: Date;
}
export type SecurityKeysList = SecurityKey[];
export interface ListSecurityKeysResponse {
    SecurityKeys?: SecurityKey[];
    NextToken?: string;
}
export interface ListSecurityProfileAIAgentsRequest {
    SecurityProfileId: string;
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface ListSecurityProfileAIAgentsResponse {
    AllowedAIAgents?: AIAgent[];
    NextToken?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface ListSecurityProfileApplicationsRequest {
    SecurityProfileId: string;
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface ListSecurityProfileApplicationsResponse {
    Applications?: Application[];
    NextToken?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface ListSecurityProfileFlowModulesRequest {
    SecurityProfileId: string;
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface ListSecurityProfileFlowModulesResponse {
    AllowedFlowModules?: FlowModule[];
    NextToken?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface ListSecurityProfilePermissionsRequest {
    SecurityProfileId: string;
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface ListSecurityProfilePermissionsResponse {
    Permissions?: string[];
    NextToken?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface ListSecurityProfilesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface SecurityProfileSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export type SecurityProfileSummaryList = SecurityProfileSummary[];
export interface ListSecurityProfilesResponse {
    SecurityProfileSummaryList?: SecurityProfileSummary[];
    NextToken?: string;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListTaskTemplatesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    Status?: TaskTemplateStatus;
    Name?: string;
}
export interface TaskTemplateMetadata {
    Id?: string;
    Arn?: string;
    Name?: string;
    Description?: string;
    Status?: TaskTemplateStatus;
    LastModifiedTime?: Date;
    CreatedTime?: Date;
}
export type TaskTemplateList = TaskTemplateMetadata[];
export interface ListTaskTemplatesResponse {
    TaskTemplates?: TaskTemplateMetadata[];
    NextToken?: string;
}
export interface ListTestCaseExecutionRecordsRequest {
    InstanceId: string;
    TestCaseId: string;
    TestCaseExecutionId: string;
    Status?: TestCaseExecutionStatus;
    NextToken?: string;
    MaxResults?: number;
}
export type TestCaseResourceId = string;
export type ExecutionRecordStatus = "PASSED" | "FAILED" | "IN_PROGRESS" | "STOPPED" | (string & {});
export type ExecutionRecordString = string;
export interface ExecutionRecord {
    ObservationId?: string;
    Status?: ExecutionRecordStatus;
    Timestamp?: Date;
    Record?: string;
}
export type ExecutionRecordList = ExecutionRecord[];
export interface ListTestCaseExecutionRecordsResponse {
    ExecutionRecords?: ExecutionRecord[];
    NextToken?: string;
}
export type EpochMilliseconds = number;
export interface ListTestCaseExecutionsRequest {
    InstanceId: string;
    TestCaseId?: string;
    TestCaseName?: string;
    StartTime?: number;
    EndTime?: number;
    Status?: TestCaseExecutionStatus;
    NextToken?: string;
    MaxResults?: number;
}
export interface TestCaseExecution {
    StartTime?: Date;
    EndTime?: Date;
    TestCaseExecutionId?: string;
    TestCaseId?: string;
    TestCaseExecutionStatus?: TestCaseExecutionStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type TestCaseExecutionList = TestCaseExecution[];
export interface ListTestCaseExecutionsResponse {
    TestCaseExecutions?: TestCaseExecution[];
    NextToken?: string;
}
export interface ListTestCasesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface TestCaseSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    Status?: TestCaseStatus;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export type TestCaseSummaryList = TestCaseSummary[];
export interface ListTestCasesResponse {
    TestCaseSummaryList?: TestCaseSummary[];
    NextToken?: string;
}
export interface ListTrafficDistributionGroupsRequest {
    MaxResults?: number;
    NextToken?: string;
    InstanceId?: string;
}
export interface TrafficDistributionGroupSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    InstanceArn?: string;
    Status?: TrafficDistributionGroupStatus;
    IsDefault?: boolean;
}
export type TrafficDistributionGroupSummaryList = TrafficDistributionGroupSummary[];
export interface ListTrafficDistributionGroupsResponse {
    NextToken?: string;
    TrafficDistributionGroupSummaryList?: TrafficDistributionGroupSummary[];
}
export interface ListTrafficDistributionGroupUsersRequest {
    TrafficDistributionGroupId: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface TrafficDistributionGroupUserSummary {
    UserId?: string;
}
export type TrafficDistributionGroupUserSummaryList = TrafficDistributionGroupUserSummary[];
export interface ListTrafficDistributionGroupUsersResponse {
    NextToken?: string;
    TrafficDistributionGroupUserSummaryList?: TrafficDistributionGroupUserSummary[];
}
export interface ListUseCasesRequest {
    InstanceId: string;
    IntegrationAssociationId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface UseCase {
    UseCaseId?: string;
    UseCaseArn?: string;
    UseCaseType?: UseCaseType;
}
export type UseCaseSummaryList = UseCase[];
export interface ListUseCasesResponse {
    UseCaseSummaryList?: UseCase[];
    NextToken?: string;
}
export interface ListUserHierarchyGroupsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export type HierarchyGroupSummaryList = HierarchyGroupSummary[];
export interface ListUserHierarchyGroupsResponse {
    UserHierarchyGroupSummaryList?: HierarchyGroupSummary[];
    NextToken?: string;
}
export interface ListUserNotificationsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    UserId: string;
}
export type NotificationStatus = "READ" | "UNREAD" | "HIDDEN" | (string & {});
export type NotificationSource = "CUSTOMER" | "RULES" | "SYSTEM" | (string & {});
export interface UserNotificationSummary {
    NotificationId?: string;
    NotificationStatus?: NotificationStatus;
    InstanceId?: string;
    RecipientId?: string;
    Content?: {
        [key: string]: string | undefined;
    };
    Priority?: NotificationPriority;
    Source?: NotificationSource;
    CreatedAt?: Date;
    ExpiresAt?: Date;
}
export type UserNotificationSummaryList = UserNotificationSummary[];
export interface ListUserNotificationsResponse {
    UserNotifications?: UserNotificationSummary[];
    NextToken?: string;
}
export interface ListUserProficienciesRequest {
    InstanceId: string;
    UserId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface ListUserProficienciesResponse {
    NextToken?: string;
    UserProficiencyList?: UserProficiency[];
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface ListUsersRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface UserSummary {
    Id?: string;
    Arn?: string;
    Username?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export type UserSummaryList = UserSummary[];
export interface ListUsersResponse {
    UserSummaryList?: UserSummary[];
    NextToken?: string;
}
export type ViewsNextToken = string;
export type MaxResults = number;
export interface ListViewsRequest {
    InstanceId: string;
    Type?: ViewType;
    NextToken?: string;
    MaxResults?: number;
}
export interface ViewSummary {
    Id?: string;
    Arn?: string;
    Name?: string | redacted.Redacted<string>;
    Type?: ViewType;
    Status?: ViewStatus;
    Description?: string;
}
export type ViewsSummaryList = ViewSummary[];
export interface ListViewsResponse {
    ViewsSummaryList?: ViewSummary[];
    NextToken?: string;
}
export interface ListViewVersionsRequest {
    InstanceId: string;
    ViewId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface ViewVersionSummary {
    Id?: string;
    Arn?: string;
    Description?: string;
    Name?: string | redacted.Redacted<string>;
    Type?: ViewType;
    Version?: number;
    VersionDescription?: string;
}
export type ViewVersionSummaryList = ViewVersionSummary[];
export interface ListViewVersionsResponse {
    ViewVersionSummaryList?: ViewVersionSummary[];
    NextToken?: string;
}
export interface ListWorkspaceMediaRequest {
    InstanceId: string;
    WorkspaceId: string;
}
export interface MediaItem {
    Type?: MediaType;
    Source?: string;
}
export type MediaList = MediaItem[];
export interface ListWorkspaceMediaResponse {
    Media?: MediaItem[];
}
export interface ListWorkspacePagesRequest {
    InstanceId: string;
    WorkspaceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface WorkspacePage {
    ResourceArn?: string;
    Page?: string;
    Slug?: string;
    InputData?: string;
}
export type WorkspacePageList = WorkspacePage[];
export interface ListWorkspacePagesResponse {
    NextToken?: string;
    WorkspacePageList: WorkspacePage[];
}
export interface ListWorkspacesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface WorkspaceSummary {
    Id?: string;
    Name?: string;
    Arn?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export type WorkspaceSummaryList = WorkspaceSummary[];
export interface ListWorkspacesResponse {
    NextToken?: string;
    WorkspaceSummaryList: WorkspaceSummary[];
}
export type MonitorCapability = "SILENT_MONITOR" | "BARGE" | (string & {});
export type AllowedMonitorCapabilities = MonitorCapability[];
export interface MonitorContactRequest {
    InstanceId: string;
    ContactId: string;
    UserId: string;
    AllowedMonitorCapabilities?: MonitorCapability[];
    ClientToken?: string;
}
export interface MonitorContactResponse {
    ContactId?: string;
    ContactArn?: string;
}
export interface PauseContactRequest {
    ContactId: string;
    InstanceId: string;
    ContactFlowId?: string;
}
export interface PauseContactResponse {
}
export interface PutUserStatusRequest {
    UserId: string;
    InstanceId: string;
    AgentStatusId: string;
}
export interface PutUserStatusResponse {
}
export interface ReleasePhoneNumberRequest {
    PhoneNumberId: string;
    ClientToken?: string;
}
export interface ReleasePhoneNumberResponse {
}
export interface ReplicateInstanceRequest {
    InstanceId: string;
    ReplicaRegion: string;
    ClientToken?: string;
    ReplicaAlias?: string | redacted.Redacted<string>;
}
export interface ReplicateInstanceResponse {
    Id?: string;
    Arn?: string;
}
export interface ResumeContactRequest {
    ContactId: string;
    InstanceId: string;
    ContactFlowId?: string;
}
export interface ResumeContactResponse {
}
export type ContactRecordingType = "AGENT" | "IVR" | "SCREEN" | (string & {});
export interface ResumeContactRecordingRequest {
    InstanceId: string;
    ContactId: string;
    InitialContactId: string;
    ContactRecordingType?: ContactRecordingType;
}
export interface ResumeContactRecordingResponse {
}
export interface TagCondition {
    TagKey?: string;
    TagValue?: string;
}
export type TagAndConditionList = TagCondition[];
export interface CommonAttributeAndCondition {
    TagConditions?: TagCondition[];
}
export type CommonAttributeOrConditionList = CommonAttributeAndCondition[];
export interface ControlPlaneAttributeFilter {
    OrConditions?: CommonAttributeAndCondition[];
    AndCondition?: CommonAttributeAndCondition;
    TagCondition?: TagCondition;
}
export interface AgentStatusSearchFilter {
    AttributeFilter?: ControlPlaneAttributeFilter;
}
export type AgentStatusSearchConditionList = AgentStatusSearchCriteria[];
export type StringComparisonType = "STARTS_WITH" | "CONTAINS" | "EXACT" | (string & {});
export interface StringCondition {
    FieldName?: string;
    Value?: string;
    ComparisonType?: StringComparisonType;
}
export interface AgentStatusSearchCriteria {
    OrConditions?: AgentStatusSearchCriteria[];
    AndConditions?: AgentStatusSearchCriteria[];
    StringCondition?: StringCondition;
}
export interface SearchAgentStatusesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: AgentStatusSearchFilter;
    SearchCriteria?: AgentStatusSearchCriteria;
}
export type AgentStatusList = AgentStatus[];
export interface SearchAgentStatusesResponse {
    AgentStatuses?: AgentStatus[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export interface SearchAvailablePhoneNumbersRequest {
    TargetArn?: string;
    InstanceId?: string;
    PhoneNumberCountryCode: PhoneNumberCountryCode;
    PhoneNumberType: PhoneNumberType;
    PhoneNumberPrefix?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface AvailableNumberSummary {
    PhoneNumber?: string;
    PhoneNumberCountryCode?: PhoneNumberCountryCode;
    PhoneNumberType?: PhoneNumberType;
}
export type AvailableNumbersList = AvailableNumberSummary[];
export interface SearchAvailablePhoneNumbersResponse {
    NextToken?: string;
    AvailableNumbersList?: AvailableNumberSummary[];
}
export type EvaluationSearchConditionList = EvaluationSearchCriteria[];
export type NullableProficiencyLimitValue = number;
export type NumberComparisonType = "GREATER_OR_EQUAL" | "GREATER" | "LESSER_OR_EQUAL" | "LESSER" | "EQUAL" | "NOT_EQUAL" | "RANGE" | (string & {});
export interface NumberCondition {
    FieldName?: string;
    MinValue?: number;
    MaxValue?: number;
    ComparisonType?: NumberComparisonType;
}
export type BooleanComparisonType = "IS_TRUE" | "IS_FALSE" | (string & {});
export interface BooleanCondition {
    FieldName?: string;
    ComparisonType?: BooleanComparisonType;
}
export type DateTimeFormat = string;
export type DateTimeComparisonType = "GREATER_THAN" | "LESS_THAN" | "GREATER_THAN_OR_EQUAL_TO" | "LESS_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "RANGE" | (string & {});
export interface DateTimeCondition {
    FieldName?: string;
    MinValue?: string;
    MaxValue?: string;
    ComparisonType?: DateTimeComparisonType;
}
export type DecimalComparisonType = "GREATER_OR_EQUAL" | "GREATER" | "LESSER_OR_EQUAL" | "LESSER" | "EQUAL" | "NOT_EQUAL" | "RANGE" | (string & {});
export interface DecimalCondition {
    FieldName?: string;
    MinValue?: number;
    MaxValue?: number;
    ComparisonType?: DecimalComparisonType;
}
export interface EvaluationSearchCriteria {
    OrConditions?: EvaluationSearchCriteria[];
    AndConditions?: EvaluationSearchCriteria[];
    StringCondition?: StringCondition;
    NumberCondition?: NumberCondition;
    BooleanCondition?: BooleanCondition;
    DateTimeCondition?: DateTimeCondition;
    DecimalCondition?: DecimalCondition;
}
export type ContactEvaluationAttributeKey = "ContactAgentId" | (string & {});
export interface ContactEvaluationAttributeValue {
    StringValue?: string;
}
export type ContactEvaluationAttributeComparisonType = "EXACT" | (string & {});
export interface ContactEvaluationAttributeCondition {
    AttributeKey?: ContactEvaluationAttributeKey;
    AttributeValue?: ContactEvaluationAttributeValue;
    ComparisonType?: ContactEvaluationAttributeComparisonType;
}
export type ContactEvaluationAttributeConditionList = ContactEvaluationAttributeCondition[];
export interface ContactEvaluationAttributeAndCondition {
    TagConditions?: TagCondition[];
    AttributeConditions?: ContactEvaluationAttributeCondition[];
}
export type ContactEvaluationAttributeOrConditionList = ContactEvaluationAttributeAndCondition[];
export interface ContactEvaluationAttributeFilter {
    OrConditions?: ContactEvaluationAttributeAndCondition[];
    AndCondition?: ContactEvaluationAttributeAndCondition;
    TagCondition?: TagCondition;
    ContactEvaluationAttributeCondition?: ContactEvaluationAttributeCondition;
}
export interface EvaluationSearchFilter {
    AttributeFilter?: ControlPlaneAttributeFilter;
    ContactEvaluationAttributeFilter?: ContactEvaluationAttributeFilter;
}
export interface SearchContactEvaluationsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchCriteria?: EvaluationSearchCriteria;
    SearchFilter?: EvaluationSearchFilter;
}
export interface EvaluationSearchMetadata {
    ContactId: string;
    EvaluatorArn: string;
    ContactAgentId?: string;
    CalibrationSessionId?: string;
    ScorePercentage?: number;
    ScoreAutomaticFail?: boolean;
    ScoreNotApplicable?: boolean;
    AutoEvaluationEnabled?: boolean;
    AutoEvaluationStatus?: AutoEvaluationStatus;
    AcknowledgedTime?: Date;
    AcknowledgedBy?: string;
    AcknowledgerComment?: string;
    SamplingJobId?: string;
    ReviewId?: string;
    ContactParticipantRole?: ContactParticipantRole;
    ContactParticipantId?: string;
    EarnedPoints?: number;
    MaxBasePoint?: number;
    PerformanceCategory?: PerformanceCategoryName;
}
export interface EvaluationSearchSummary {
    EvaluationId: string;
    EvaluationArn: string;
    EvaluationFormId?: string;
    EvaluationFormVersion: number;
    EvaluationFormTitle?: string;
    Metadata: EvaluationSearchMetadata;
    Status: EvaluationStatus;
    EvaluationType?: EvaluationType;
    CreatedTime: Date;
    LastModifiedTime: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type EvaluationSearchSummaryList = EvaluationSearchSummary[];
export interface SearchContactEvaluationsResponse {
    EvaluationSearchSummaryList?: EvaluationSearchSummary[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export type TagOrConditionList = TagCondition[][];
export interface ControlPlaneTagFilter {
    OrConditions?: TagCondition[][];
    AndConditions?: TagCondition[];
    TagCondition?: TagCondition;
}
export interface ContactFlowModuleSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
}
export type ContactFlowModuleSearchConditionList = ContactFlowModuleSearchCriteria[];
export interface ContactFlowModuleSearchCriteria {
    OrConditions?: ContactFlowModuleSearchCriteria[];
    AndConditions?: ContactFlowModuleSearchCriteria[];
    StringCondition?: StringCondition;
    StateCondition?: ContactFlowModuleState;
    StatusCondition?: ContactFlowModuleStatus;
}
export interface SearchContactFlowModulesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: ContactFlowModuleSearchFilter;
    SearchCriteria?: ContactFlowModuleSearchCriteria;
}
export type ContactFlowModuleSearchSummaryList = ContactFlowModule[];
export interface SearchContactFlowModulesResponse {
    ContactFlowModules?: ContactFlowModule[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export interface ContactFlowTypeCondition {
    ContactFlowType?: ContactFlowType;
}
export interface ContactFlowAttributeAndCondition {
    TagConditions?: TagCondition[];
    ContactFlowTypeCondition?: ContactFlowTypeCondition;
}
export type ContactFlowAttributeOrConditionList = ContactFlowAttributeAndCondition[];
export interface ContactFlowAttributeFilter {
    OrConditions?: ContactFlowAttributeAndCondition[];
    AndCondition?: ContactFlowAttributeAndCondition;
    TagCondition?: TagCondition;
    ContactFlowTypeCondition?: ContactFlowTypeCondition;
}
export interface ContactFlowSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
    FlowAttributeFilter?: ContactFlowAttributeFilter;
}
export type ContactFlowSearchConditionList = ContactFlowSearchCriteria[];
export interface ContactFlowSearchCriteria {
    OrConditions?: ContactFlowSearchCriteria[];
    AndConditions?: ContactFlowSearchCriteria[];
    StringCondition?: StringCondition;
    TypeCondition?: ContactFlowType;
    StateCondition?: ContactFlowState;
    StatusCondition?: ContactFlowStatus;
}
export interface SearchContactFlowsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: ContactFlowSearchFilter;
    SearchCriteria?: ContactFlowSearchCriteria;
}
export type ContactFlowSearchSummaryList = ContactFlow[];
export interface SearchContactFlowsResponse {
    ContactFlows?: ContactFlow[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export type SearchContactsTimeRangeType = "INITIATION_TIMESTAMP" | "SCHEDULED_TIMESTAMP" | "CONNECTED_TO_AGENT_TIMESTAMP" | "DISCONNECT_TIMESTAMP" | "ENQUEUE_TIMESTAMP" | (string & {});
export interface SearchContactsTimeRange {
    Type: SearchContactsTimeRangeType;
    StartTime: Date;
    EndTime: Date;
}
export type SearchText = string | redacted.Redacted<string>;
export type SearchTextList = (string | redacted.Redacted<string>)[];
export type SearchContactsMatchType = "MATCH_ALL" | "MATCH_ANY" | "MATCH_EXACT" | "MATCH_NONE" | (string & {});
export interface NameCriteria {
    SearchText: (string | redacted.Redacted<string>)[];
    MatchType: SearchContactsMatchType;
}
export type AgentResourceIdList = string[];
export type HierarchyGroupIdList = string[];
export interface AgentHierarchyGroups {
    L1Ids?: string[];
    L2Ids?: string[];
    L3Ids?: string[];
    L4Ids?: string[];
    L5Ids?: string[];
}
export type ChannelList = Channel[];
export interface TranscriptCriteria {
    ParticipantRole: ParticipantRole;
    SearchText: (string | redacted.Redacted<string>)[];
    MatchType: SearchContactsMatchType;
}
export type TranscriptCriteriaList = TranscriptCriteria[];
export interface Transcript {
    Criteria: TranscriptCriteria[];
    MatchType?: SearchContactsMatchType;
}
export interface ContactAnalysis {
    Transcript?: Transcript;
}
export type InitiationMethodList = ContactInitiationMethod[];
export type QueueIdList = string[];
export interface SearchableAgentCriteriaStep {
    AgentIds?: string[];
    MatchType?: SearchContactsMatchType;
}
export interface SearchableRoutingCriteriaStep {
    AgentCriteria?: SearchableAgentCriteriaStep;
}
export type SearchableRoutingCriteriaStepList = SearchableRoutingCriteriaStep[];
export interface SearchableRoutingCriteria {
    Steps?: SearchableRoutingCriteriaStep[];
}
export type SearchContactsTimeRangeConditionType = "NOT_EXISTS" | (string & {});
export interface SearchContactsTimestampCondition {
    Type: SearchContactsTimeRangeType;
    ConditionType: SearchContactsTimeRangeConditionType;
}
export interface SearchContactsAdditionalTimeRangeCriteria {
    TimeRange?: SearchContactsTimeRange;
    TimestampCondition?: SearchContactsTimestampCondition;
}
export type SearchContactsAdditionalTimeRangeCriteriaList = SearchContactsAdditionalTimeRangeCriteria[];
export interface SearchContactsAdditionalTimeRange {
    Criteria: SearchContactsAdditionalTimeRangeCriteria[];
    MatchType: SearchContactsMatchType;
}
export type SearchableContactAttributeKey = string | redacted.Redacted<string>;
export type SearchableContactAttributeValue = string | redacted.Redacted<string>;
export type SearchableContactAttributeValueList = (string | redacted.Redacted<string>)[];
export interface SearchableContactAttributesCriteria {
    Key: string | redacted.Redacted<string>;
    Values: (string | redacted.Redacted<string>)[];
}
export type SearchableContactAttributesCriteriaList = SearchableContactAttributesCriteria[];
export interface SearchableContactAttributes {
    Criteria: SearchableContactAttributesCriteria[];
    MatchType?: SearchContactsMatchType;
}
export type SearchableSegmentAttributeKey = string | redacted.Redacted<string>;
export type SearchableSegmentAttributeValue = string | redacted.Redacted<string>;
export type SearchableSegmentAttributeValueList = (string | redacted.Redacted<string>)[];
export interface SearchableSegmentAttributesCriteria {
    Key: string | redacted.Redacted<string>;
    Values: (string | redacted.Redacted<string>)[];
}
export type SearchableSegmentAttributesCriteriaList = SearchableSegmentAttributesCriteria[];
export interface SearchableSegmentAttributes {
    Criteria: SearchableSegmentAttributesCriteria[];
    MatchType?: SearchContactsMatchType;
}
export type ActiveRegionList = string[];
export type AiAgentId = string;
export type AiAgentVersionNumber = number;
export interface AiAgentSearchCriteria {
    Id?: string;
    VersionNumber?: number;
    AiAgentEscalated?: boolean;
    AiUseCase?: AiUseCase;
}
export type AiAgentSearchCriteriaList = AiAgentSearchCriteria[];
export interface AiAgentsCriteria {
    Criteria?: AiAgentSearchCriteria[];
}
export interface SearchCriteria {
    Name?: NameCriteria;
    AgentIds?: string[];
    AgentHierarchyGroups?: AgentHierarchyGroups;
    Channels?: Channel[];
    ContactAnalysis?: ContactAnalysis;
    InitiationMethods?: ContactInitiationMethod[];
    QueueIds?: string[];
    RoutingCriteria?: SearchableRoutingCriteria;
    AdditionalTimeRange?: SearchContactsAdditionalTimeRange;
    SearchableContactAttributes?: SearchableContactAttributes;
    SearchableSegmentAttributes?: SearchableSegmentAttributes;
    ActiveRegions?: string[];
    ContactTags?: ControlPlaneTagFilter;
    AiAgents?: AiAgentsCriteria;
}
export type SortableFieldName = "INITIATION_TIMESTAMP" | "SCHEDULED_TIMESTAMP" | "CONNECTED_TO_AGENT_TIMESTAMP" | "DISCONNECT_TIMESTAMP" | "INITIATION_METHOD" | "CHANNEL" | "EXPIRY_TIMESTAMP" | (string & {});
export interface Sort {
    FieldName: SortableFieldName;
    Order: SortOrder;
}
export interface SearchContactsRequest {
    InstanceId: string;
    TimeRange: SearchContactsTimeRange;
    SearchCriteria?: SearchCriteria;
    MaxResults?: number;
    NextToken?: string;
    Sort?: Sort;
}
export interface ContactSearchSummaryQueueInfo {
    Id?: string;
    EnqueueTimestamp?: Date;
}
export interface ContactSearchSummaryAgentInfo {
    Id?: string;
    ConnectedToAgentTimestamp?: Date;
}
export interface ContactSearchSummarySegmentAttributeValue {
    ValueString?: string;
    ValueMap?: {
        [key: string]: SegmentAttributeValue | undefined;
    };
}
export type ContactSearchSummarySegmentAttributes = {
    [key: string]: ContactSearchSummarySegmentAttributeValue | undefined;
};
export interface ContactSearchSummaryAiAgentInfo {
    AiAgentVersionId?: string;
    AiAgentEscalated?: boolean;
    AiUseCase?: AiUseCase;
}
export type ContactSearchSummaryAiAgentInfoList = ContactSearchSummaryAiAgentInfo[];
export interface ContactSearchSummary {
    Arn?: string;
    Id?: string;
    InitialContactId?: string;
    PreviousContactId?: string;
    InitiationMethod?: ContactInitiationMethod;
    Channel?: Channel;
    QueueInfo?: ContactSearchSummaryQueueInfo;
    AgentInfo?: ContactSearchSummaryAgentInfo;
    InitiationTimestamp?: Date;
    DisconnectTimestamp?: Date;
    ScheduledTimestamp?: Date;
    SegmentAttributes?: {
        [key: string]: ContactSearchSummarySegmentAttributeValue | undefined;
    };
    Name?: string | redacted.Redacted<string>;
    RoutingCriteria?: RoutingCriteria;
    Tags?: {
        [key: string]: string | undefined;
    };
    GlobalResiliencyMetadata?: GlobalResiliencyMetadata;
    AiAgentInfo?: ContactSearchSummaryAiAgentInfo[];
}
export type Contacts = ContactSearchSummary[];
export type TotalCount = number;
export interface SearchContactsResponse {
    Contacts: ContactSearchSummary[];
    NextToken?: string;
    TotalCount?: number;
}
export interface DataTableSearchFilter {
    AttributeFilter?: ControlPlaneAttributeFilter;
}
export type DataTableSearchConditionList = DataTableSearchCriteria[];
export interface DataTableSearchCriteria {
    OrConditions?: DataTableSearchCriteria[];
    AndConditions?: DataTableSearchCriteria[];
    StringCondition?: StringCondition;
}
export interface SearchDataTablesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: DataTableSearchFilter;
    SearchCriteria?: DataTableSearchCriteria;
}
export type DataTableList = DataTable[];
export interface SearchDataTablesResponse {
    DataTables?: DataTable[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export type EmailAddressSearchConditionList = EmailAddressSearchCriteria[];
export interface EmailAddressSearchCriteria {
    OrConditions?: EmailAddressSearchCriteria[];
    AndConditions?: EmailAddressSearchCriteria[];
    StringCondition?: StringCondition;
}
export interface EmailAddressSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
}
export interface SearchEmailAddressesRequest {
    InstanceId: string;
    MaxResults?: number;
    NextToken?: string;
    SearchCriteria?: EmailAddressSearchCriteria;
    SearchFilter?: EmailAddressSearchFilter;
}
export interface EmailAddressMetadata {
    EmailAddressId?: string;
    EmailAddressArn?: string;
    EmailAddress?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    DisplayName?: string | redacted.Redacted<string>;
    AliasConfigurations?: AliasConfiguration[];
}
export type EmailAddressList = EmailAddressMetadata[];
export interface SearchEmailAddressesResponse {
    NextToken?: string;
    EmailAddresses?: EmailAddressMetadata[];
    ApproximateTotalCount?: number;
}
export type EvaluationFormSearchConditionList = EvaluationFormSearchCriteria[];
export interface EvaluationFormSearchCriteria {
    OrConditions?: EvaluationFormSearchCriteria[];
    AndConditions?: EvaluationFormSearchCriteria[];
    StringCondition?: StringCondition;
    NumberCondition?: NumberCondition;
    BooleanCondition?: BooleanCondition;
    DateTimeCondition?: DateTimeCondition;
}
export interface EvaluationFormSearchFilter {
    AttributeFilter?: ControlPlaneAttributeFilter;
}
export interface SearchEvaluationFormsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchCriteria?: EvaluationFormSearchCriteria;
    SearchFilter?: EvaluationFormSearchFilter;
}
export interface EvaluationFormSearchSummary {
    EvaluationFormId: string;
    EvaluationFormArn: string;
    Title: string;
    Status: EvaluationFormVersionStatus;
    Description?: string;
    CreatedTime: Date;
    CreatedBy: string;
    LastModifiedTime: Date;
    LastModifiedBy: string;
    LastActivatedTime?: Date;
    LastActivatedBy?: string;
    LatestVersion: number;
    ActiveVersion?: number;
    AutoEvaluationEnabled?: boolean;
    EvaluationFormLanguage?: EvaluationFormLanguageCode;
    ContactInteractionType?: ContactInteractionType;
    Tags?: {
        [key: string]: string | undefined;
    };
    AIVersion?: string;
}
export type EvaluationFormSearchSummaryList = EvaluationFormSearchSummary[];
export interface SearchEvaluationFormsResponse {
    EvaluationFormSearchSummaryList?: EvaluationFormSearchSummary[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export interface HoursOfOperationSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
}
export type HoursOfOperationOverrideSearchConditionList = HoursOfOperationOverrideSearchCriteria[];
export type DateYearMonthDayFormat = string;
export type DateComparisonType = "GREATER_THAN" | "LESS_THAN" | "GREATER_THAN_OR_EQUAL_TO" | "LESS_THAN_OR_EQUAL_TO" | "EQUAL_TO" | (string & {});
export interface DateCondition {
    FieldName?: string;
    Value?: string;
    ComparisonType?: DateComparisonType;
}
export interface HoursOfOperationOverrideSearchCriteria {
    OrConditions?: HoursOfOperationOverrideSearchCriteria[];
    AndConditions?: HoursOfOperationOverrideSearchCriteria[];
    StringCondition?: StringCondition;
    DateCondition?: DateCondition;
}
export interface SearchHoursOfOperationOverridesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: HoursOfOperationSearchFilter;
    SearchCriteria?: HoursOfOperationOverrideSearchCriteria;
}
export interface SearchHoursOfOperationOverridesResponse {
    HoursOfOperationOverrides?: HoursOfOperationOverride[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export type HoursOfOperationSearchConditionList = HoursOfOperationSearchCriteria[];
export interface HoursOfOperationSearchCriteria {
    OrConditions?: HoursOfOperationSearchCriteria[];
    AndConditions?: HoursOfOperationSearchCriteria[];
    StringCondition?: StringCondition;
}
export interface SearchHoursOfOperationsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: HoursOfOperationSearchFilter;
    SearchCriteria?: HoursOfOperationSearchCriteria;
}
export type HoursOfOperationList = HoursOfOperation[];
export interface SearchHoursOfOperationsResponse {
    HoursOfOperations?: HoursOfOperation[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export interface MetricSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
}
export type MetricSearchConditionList = MetricSearchCriteria[];
export interface MetricSearchCriteria {
    OrConditions?: MetricSearchCriteria[];
    AndConditions?: MetricSearchCriteria[];
    StringCondition?: StringCondition;
    BooleanCondition?: BooleanCondition;
}
export interface SearchMetricsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: MetricSearchFilter;
    SearchCriteria?: MetricSearchCriteria;
}
export type MetricSearchSummaryList = MetricDefinition[];
export interface SearchMetricsResponse {
    Metrics?: MetricDefinition[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export interface NotificationSearchFilter {
    AttributeFilter?: ControlPlaneAttributeFilter;
}
export type NotificationSearchConditionList = NotificationSearchCriteria[];
export interface NotificationSearchCriteria {
    OrConditions?: NotificationSearchCriteria[];
    AndConditions?: NotificationSearchCriteria[];
    StringCondition?: StringCondition;
}
export interface SearchNotificationsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: NotificationSearchFilter;
    SearchCriteria?: NotificationSearchCriteria;
}
export interface NotificationSearchSummary {
    Id?: string;
    Arn?: string;
    InstanceId?: string;
    Content?: {
        [key: string]: string | undefined;
    };
    Priority?: NotificationPriority;
    Recipients?: string[];
    CreatedAt?: Date;
    ExpiresAt?: Date;
    LastModifiedRegion?: string;
    LastModifiedTime?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type NotificationSearchSummaryList = NotificationSearchSummary[];
export interface SearchNotificationsResponse {
    Notifications?: NotificationSearchSummary[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export type PredefinedAttributeSearchConditionList = PredefinedAttributeSearchCriteria[];
export interface PredefinedAttributeSearchCriteria {
    OrConditions?: PredefinedAttributeSearchCriteria[];
    AndConditions?: PredefinedAttributeSearchCriteria[];
    StringCondition?: StringCondition;
}
export interface SearchPredefinedAttributesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchCriteria?: PredefinedAttributeSearchCriteria;
}
export type PredefinedAttributeSearchSummaryList = PredefinedAttribute[];
export interface SearchPredefinedAttributesResponse {
    PredefinedAttributes?: PredefinedAttribute[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export interface PromptSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
}
export type PromptSearchConditionList = PromptSearchCriteria[];
export interface PromptSearchCriteria {
    OrConditions?: PromptSearchCriteria[];
    AndConditions?: PromptSearchCriteria[];
    StringCondition?: StringCondition;
}
export interface SearchPromptsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: PromptSearchFilter;
    SearchCriteria?: PromptSearchCriteria;
}
export type PromptList = Prompt[];
export interface SearchPromptsResponse {
    Prompts?: Prompt[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export type MaxResult500 = number;
export interface QueueSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
}
export type QueueSearchConditionList = QueueSearchCriteria[];
export type SearchableQueueType = "STANDARD" | (string & {});
export interface QueueSearchCriteria {
    OrConditions?: QueueSearchCriteria[];
    AndConditions?: QueueSearchCriteria[];
    StringCondition?: StringCondition;
    QueueTypeCondition?: SearchableQueueType;
}
export interface SearchQueuesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: QueueSearchFilter;
    SearchCriteria?: QueueSearchCriteria;
}
export type QueueSearchSummaryList = Queue[];
export interface SearchQueuesResponse {
    Queues?: Queue[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export interface QuickConnectSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
}
export type QuickConnectSearchConditionList = QuickConnectSearchCriteria[];
export interface QuickConnectSearchCriteria {
    OrConditions?: QuickConnectSearchCriteria[];
    AndConditions?: QuickConnectSearchCriteria[];
    StringCondition?: StringCondition;
}
export interface SearchQuickConnectsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: QuickConnectSearchFilter;
    SearchCriteria?: QuickConnectSearchCriteria;
}
export type QuickConnectSearchSummaryList = QuickConnect[];
export interface SearchQuickConnectsResponse {
    QuickConnects?: QuickConnect[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export type ResourceTypeList = string[];
export type TagKeyString = string;
export type TagValueString = string;
export interface TagSearchCondition {
    tagKey?: string;
    tagValue?: string;
    tagKeyComparisonType?: StringComparisonType;
    tagValueComparisonType?: StringComparisonType;
}
export interface ResourceTagsSearchCriteria {
    TagSearchCondition?: TagSearchCondition;
}
export interface SearchResourceTagsRequest {
    InstanceId: string;
    ResourceTypes?: string[];
    NextToken?: string;
    MaxResults?: number;
    SearchCriteria?: ResourceTagsSearchCriteria;
}
export interface TagSet {
    key?: string;
    value?: string;
}
export type TagsList = TagSet[];
export interface SearchResourceTagsResponse {
    Tags?: TagSet[];
    NextToken?: string;
}
export interface RoutingProfileSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
}
export type RoutingProfileSearchConditionList = RoutingProfileSearchCriteria[];
export interface RoutingProfileSearchCriteria {
    OrConditions?: RoutingProfileSearchCriteria[];
    AndConditions?: RoutingProfileSearchCriteria[];
    StringCondition?: StringCondition;
}
export interface SearchRoutingProfilesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: RoutingProfileSearchFilter;
    SearchCriteria?: RoutingProfileSearchCriteria;
}
export type RoutingProfileList = RoutingProfile[];
export interface SearchRoutingProfilesResponse {
    RoutingProfiles?: RoutingProfile[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export type RulesSearchConditionList = RulesSearchCriteria[];
export interface RulesSearchCriteria {
    OrConditions?: RulesSearchCriteria[];
    AndConditions?: RulesSearchCriteria[];
    StringCondition?: StringCondition;
}
export interface RuleAttributeAndCondition {
    TagConditions?: TagCondition[];
}
export type RuleAttributeOrConditionList = RuleAttributeAndCondition[];
export interface RuleAttributeFilter {
    OrConditions?: RuleAttributeAndCondition[];
    AndCondition?: RuleAttributeAndCondition;
    TagCondition?: TagCondition;
}
export interface RulesSearchFilter {
    AttributeFilter?: RuleAttributeFilter;
}
export interface SearchRulesRequest {
    InstanceId: string;
    MaxResults?: number;
    NextToken?: string;
    SearchCriteria?: RulesSearchCriteria;
    SearchFilter?: RulesSearchFilter;
}
export interface RuleSearchSummary {
    Name: string;
    RuleId: string;
    RuleArn: string;
    TriggerEventSource: RuleTriggerEventSource;
    ActionSummaries: ActionSummary[];
    RuleCapabilityTiers?: RuleCapabilityTier[];
    PublishStatus: RulePublishStatus;
    PreEvaluationFilters?: PreEvaluationFilters;
    CreatedTime: Date;
    LastUpdatedTime: Date;
    LastUpdatedBy: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type RuleSearchSummaryList = RuleSearchSummary[];
export interface SearchRulesResponse {
    Rules: RuleSearchSummary[];
    ApproximateTotalCount?: number;
    NextToken?: string;
}
export type SecurityProfileSearchConditionList = SecurityProfileSearchCriteria[];
export interface SecurityProfileSearchCriteria {
    OrConditions?: SecurityProfileSearchCriteria[];
    AndConditions?: SecurityProfileSearchCriteria[];
    StringCondition?: StringCondition;
}
export interface SecurityProfilesSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
}
export interface SearchSecurityProfilesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchCriteria?: SecurityProfileSearchCriteria;
    SearchFilter?: SecurityProfilesSearchFilter;
}
export interface SecurityProfileSearchSummary {
    Id?: string;
    OrganizationResourceId?: string;
    Arn?: string;
    SecurityProfileName?: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type SecurityProfilesSearchSummaryList = SecurityProfileSearchSummary[];
export interface SearchSecurityProfilesResponse {
    SecurityProfiles?: SecurityProfileSearchSummary[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export interface TestCaseSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
}
export type TestCaseSearchConditionList = TestCaseSearchCriteria[];
export interface TestCaseSearchCriteria {
    OrConditions?: TestCaseSearchCriteria[];
    AndConditions?: TestCaseSearchCriteria[];
    StringCondition?: StringCondition;
    StatusCondition?: TestCaseStatus;
}
export interface SearchTestCasesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: TestCaseSearchFilter;
    SearchCriteria?: TestCaseSearchCriteria;
}
export type TestCaseSearchSummaryList = TestCase[];
export interface SearchTestCasesResponse {
    TestCases?: TestCase[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export interface UserHierarchyGroupSearchFilter {
    AttributeFilter?: ControlPlaneAttributeFilter;
}
export type UserHierarchyGroupSearchConditionList = UserHierarchyGroupSearchCriteria[];
export interface UserHierarchyGroupSearchCriteria {
    OrConditions?: UserHierarchyGroupSearchCriteria[];
    AndConditions?: UserHierarchyGroupSearchCriteria[];
    StringCondition?: StringCondition;
}
export interface SearchUserHierarchyGroupsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: UserHierarchyGroupSearchFilter;
    SearchCriteria?: UserHierarchyGroupSearchCriteria;
}
export type UserHierarchyGroupList = HierarchyGroup[];
export interface SearchUserHierarchyGroupsResponse {
    UserHierarchyGroups?: HierarchyGroup[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export type HierarchyGroupMatchType = "EXACT" | "WITH_CHILD_GROUPS" | (string & {});
export interface HierarchyGroupCondition {
    Value?: string;
    HierarchyGroupMatchType?: HierarchyGroupMatchType;
}
export interface AttributeAndCondition {
    TagConditions?: TagCondition[];
    HierarchyGroupCondition?: HierarchyGroupCondition;
}
export type AttributeOrConditionList = AttributeAndCondition[];
export interface ControlPlaneUserAttributeFilter {
    OrConditions?: AttributeAndCondition[];
    AndCondition?: AttributeAndCondition;
    TagCondition?: TagCondition;
    HierarchyGroupCondition?: HierarchyGroupCondition;
}
export interface UserSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
    UserAttributeFilter?: ControlPlaneUserAttributeFilter;
}
export type UserSearchConditionList = UserSearchCriteria[];
export type TargetListType = "PROFICIENCIES" | (string & {});
export interface Condition {
    StringCondition?: StringCondition;
    NumberCondition?: NumberCondition;
}
export type Conditions = Condition[];
export interface ListCondition {
    TargetListType?: TargetListType;
    Conditions?: Condition[];
}
export interface UserSearchCriteria {
    OrConditions?: UserSearchCriteria[];
    AndConditions?: UserSearchCriteria[];
    StringCondition?: StringCondition;
    ListCondition?: ListCondition;
    HierarchyGroupCondition?: HierarchyGroupCondition;
}
export interface SearchUsersRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: UserSearchFilter;
    SearchCriteria?: UserSearchCriteria;
}
export interface UserIdentityInfoLite {
    FirstName?: string | redacted.Redacted<string>;
    LastName?: string | redacted.Redacted<string>;
}
export interface UserSearchSummary {
    Arn?: string;
    DirectoryUserId?: string;
    HierarchyGroupId?: string;
    Id?: string;
    IdentityInfo?: UserIdentityInfoLite;
    PhoneConfig?: UserPhoneConfig;
    RoutingProfileId?: string;
    SecurityProfileIds?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
    Username?: string;
    AutoAcceptConfigs?: AutoAcceptConfig[];
    AfterContactWorkConfigs?: AfterContactWorkConfigPerChannel[];
    PhoneNumberConfigs?: PhoneNumberConfig[];
    PersistentConnectionConfigs?: PersistentConnectionConfig[];
    VoiceEnhancementConfigs?: VoiceEnhancementConfig[];
}
export type UserSearchSummaryList = UserSearchSummary[];
export interface SearchUsersResponse {
    Users?: UserSearchSummary[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export interface ViewSearchFilter {
    AttributeFilter?: ControlPlaneAttributeFilter;
}
export type ViewSearchConditionList = ViewSearchCriteria[];
export interface ViewSearchCriteria {
    OrConditions?: ViewSearchCriteria[];
    AndConditions?: ViewSearchCriteria[];
    StringCondition?: StringCondition;
    ViewTypeCondition?: ViewType;
    ViewStatusCondition?: ViewStatus;
}
export interface SearchViewsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: ViewSearchFilter;
    SearchCriteria?: ViewSearchCriteria;
}
export type ViewSearchSummaryList = View[];
export interface SearchViewsResponse {
    Views?: View[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export interface SearchVocabulariesRequest {
    InstanceId: string;
    MaxResults?: number;
    NextToken?: string;
    State?: VocabularyState;
    NameStartsWith?: string;
    LanguageCode?: VocabularyLanguageCode;
}
export interface VocabularySummary {
    Name: string;
    Id: string;
    Arn: string;
    LanguageCode: VocabularyLanguageCode;
    State: VocabularyState;
    LastModifiedTime: Date;
    FailureReason?: string;
}
export type VocabularySummaryList = VocabularySummary[];
export interface SearchVocabulariesResponse {
    VocabularySummaryList?: VocabularySummary[];
    NextToken?: string;
}
export interface WorkspaceAssociationSearchFilter {
    AttributeFilter?: ControlPlaneAttributeFilter;
}
export type WorkspaceAssociationSearchConditionList = WorkspaceAssociationSearchCriteria[];
export interface WorkspaceAssociationSearchCriteria {
    OrConditions?: WorkspaceAssociationSearchCriteria[];
    AndConditions?: WorkspaceAssociationSearchCriteria[];
    StringCondition?: StringCondition;
}
export interface SearchWorkspaceAssociationsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: WorkspaceAssociationSearchFilter;
    SearchCriteria?: WorkspaceAssociationSearchCriteria;
}
export type WorkspaceAssociatedResourceId = string;
export type WorkspaceAssociatedResourceType = string;
export type WorkspaceAssociatedResourceName = string;
export interface WorkspaceAssociationSearchSummary {
    WorkspaceId?: string;
    WorkspaceArn?: string;
    ResourceId?: string;
    ResourceArn?: string;
    ResourceType?: string;
    ResourceName?: string;
}
export type WorkspaceAssociationSearchSummaryList = WorkspaceAssociationSearchSummary[];
export interface SearchWorkspaceAssociationsResponse {
    NextToken?: string;
    WorkspaceAssociations?: WorkspaceAssociationSearchSummary[];
    ApproximateTotalCount?: number;
}
export interface WorkspaceSearchFilter {
    AttributeFilter?: ControlPlaneAttributeFilter;
}
export type WorkspaceSearchConditionList = WorkspaceSearchCriteria[];
export interface WorkspaceSearchCriteria {
    OrConditions?: WorkspaceSearchCriteria[];
    AndConditions?: WorkspaceSearchCriteria[];
    StringCondition?: StringCondition;
}
export interface SearchWorkspacesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: WorkspaceSearchFilter;
    SearchCriteria?: WorkspaceSearchCriteria;
}
export interface WorkspaceSearchSummary {
    Id?: string;
    Name?: string;
    Visibility?: Visibility;
    Description?: string;
    Title?: string;
    Arn?: string;
    CreatedAt?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type WorkspaceSearchSummaryList = WorkspaceSearchSummary[];
export interface SearchWorkspacesResponse {
    NextToken?: string;
    Workspaces?: WorkspaceSearchSummary[];
    ApproximateTotalCount?: number;
}
export type SourceId = string;
export type DestinationId = string;
export type ChatEventType = "DISCONNECT" | "MESSAGE" | "EVENT" | (string & {});
export type ChatContentType = string;
export type ChatContent = string;
export interface ChatEvent {
    Type: ChatEventType;
    ContentType?: string;
    Content?: string;
}
export type SupportedMessagingContentType = string;
export type SupportedMessagingContentTypes = string[];
export interface ParticipantDetails {
    DisplayName: string;
}
export type ChatStreamingEndpointARN = string;
export interface ChatStreamingConfiguration {
    StreamingEndpointArn: string;
}
export interface NewSessionDetails {
    SupportedMessagingContentTypes?: string[];
    ParticipantDetails?: ParticipantDetails;
    Attributes?: {
        [key: string]: string | undefined;
    };
    StreamingConfiguration?: ChatStreamingConfiguration;
}
export interface SendChatIntegrationEventRequest {
    SourceId: string;
    DestinationId: string;
    Subtype?: string;
    Event: ChatEvent;
    NewSessionDetails?: NewSessionDetails;
}
export type NewChatCreated = boolean;
export interface SendChatIntegrationEventResponse {
    InitialContactId?: string;
    NewChatCreated?: boolean;
}
export interface EmailAddressInfo {
    EmailAddress: string | redacted.Redacted<string>;
    DisplayName?: string | redacted.Redacted<string>;
}
export type EmailAddressRecipientList = EmailAddressInfo[];
export interface OutboundAdditionalRecipients {
    CcEmailAddresses?: EmailAddressInfo[];
}
export type OutboundMessageSourceType = "TEMPLATE" | "RAW" | (string & {});
export type MessageTemplateKnowledgeBaseId = string;
export type MessageTemplateId = string;
export type CustomerProfileAttributesSerialized = string;
export interface TemplateAttributes {
    CustomAttributes?: {
        [key: string]: string | undefined;
    };
    CustomerProfileAttributes?: string;
}
export interface TemplatedMessageConfig {
    KnowledgeBaseId: string;
    MessageTemplateId: string;
    TemplateAttributes: TemplateAttributes;
}
export type OutboundSubject = string | redacted.Redacted<string>;
export type Body = string | redacted.Redacted<string>;
export type EmailMessageContentType = string;
export interface OutboundRawMessage {
    Subject: string | redacted.Redacted<string>;
    Body: string | redacted.Redacted<string>;
    ContentType: string;
}
export interface OutboundEmailContent {
    MessageSourceType: OutboundMessageSourceType;
    TemplatedMessageConfig?: TemplatedMessageConfig;
    RawMessage?: OutboundRawMessage;
}
export type TrafficType = "GENERAL" | "CAMPAIGN" | (string & {});
export type OutboundRequestId = string;
export interface SourceCampaign {
    CampaignId?: string;
    OutboundRequestId?: string;
}
export interface SendOutboundEmailRequest {
    InstanceId: string;
    FromEmailAddress: EmailAddressInfo;
    DestinationEmailAddress: EmailAddressInfo;
    AdditionalRecipients?: OutboundAdditionalRecipients;
    EmailMessage: OutboundEmailContent;
    TrafficType: TrafficType;
    SourceCampaign?: SourceCampaign;
    ClientToken?: string;
}
export interface SendOutboundEmailResponse {
}
export type WebBrowserId = string;
export type WebSessionId = string;
export interface WebNotificationSource {
    SourceCampaign: SourceCampaign;
}
export type WidgetId = string;
export type CustomerProfileId = string;
export interface WidgetDestination {
    WidgetId: string;
    ProfileId: string;
}
export type NotificationType = "WIDGET_VIEW" | "WIDGET_ACTION" | (string & {});
export type ViewArn = string;
export type PersonalizeDomainName = string;
export type RecommenderName = string;
export type RecommenderContextKey = string;
export type RecommenderContextValue = string;
export type RecommenderContext = {
    [key: string]: string | undefined;
};
export interface RecommenderConfig {
    DomainName: string;
    RecommenderName: string;
    Context?: {
        [key: string]: string | undefined;
    };
}
export interface ContentAttributes {
    RecommenderConfig?: RecommenderConfig;
}
export interface WebNotificationContent {
    Type: NotificationType;
    ViewArn?: string;
    Attributes?: ContentAttributes;
}
export interface SendOutboundWebNotificationRequest {
    InstanceId: string;
    ClientToken?: string;
    BrowserId: string;
    SessionId: string;
    ExpiresAt: Date;
    Source: WebNotificationSource;
    Destination: WidgetDestination;
    Content: WebNotificationContent;
}
export interface SendOutboundWebNotificationResponse {
}
export interface AiAgentInput {
    AiAgentId: string;
}
export interface ChatMessage {
    ContentType: string;
    Content: string;
}
export interface PersistentChat {
    RehydrationType?: RehydrationType;
    SourceContactId?: string;
}
export interface StartAssistantContactRequest {
    InstanceId: string;
    AiAgent: AiAgentInput;
    ParticipantDetails: ParticipantDetails;
    InitialMessage?: ChatMessage;
    Attributes?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
    PersistentChat?: PersistentChat;
    RelatedContactId?: string;
}
export interface StartAssistantContactResponse {
    ContactId?: string;
    ParticipantId?: string;
    ParticipantToken?: string;
    ContinuedFromContactId?: string;
}
export interface StartAttachedFileUploadRequest {
    ClientToken?: string;
    InstanceId: string;
    FileName: string;
    FileSizeInBytes: number;
    UrlExpiryInSeconds?: number;
    FileUseCaseType: FileUseCaseType;
    AssociatedResourceArn: string;
    CreatedBy?: CreatedByInfo;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type UrlMetadataSignedHeadersKey = string;
export type UrlMetadataSignedHeadersValue = string;
export type UrlMetadataSignedHeaders = {
    [key: string]: string | undefined;
};
export interface UploadUrlMetadata {
    Url?: string;
    UrlExpiry?: string;
    HeadersToInclude?: {
        [key: string]: string | undefined;
    };
}
export interface StartAttachedFileUploadResponse {
    FileArn?: string;
    FileId?: string;
    CreationTime?: string;
    FileStatus?: FileStatusType;
    CreatedBy?: CreatedByInfo;
    UploadUrlMetadata?: UploadUrlMetadata;
}
export type ResponseMode = "INCREMENTAL" | "COMPLETE" | (string & {});
export interface ParticipantConfiguration {
    ResponseMode?: ResponseMode;
}
export type ChatDurationInMinutes = number;
export type CustomerIdNonEmpty = string | redacted.Redacted<string>;
export type DisconnectOnCustomerExitParticipantType = "AGENT" | (string & {});
export type DisconnectOnCustomerExit = DisconnectOnCustomerExitParticipantType[];
export type ConnectionType = "WEBSOCKET" | "CONNECTION_CREDENTIALS" | "AUTHENTICATION_SESSION" | "WEBRTC_CONNECTION" | (string & {});
export type ConnectionTypeList = ConnectionType[];
export interface StartChatContactRequest {
    InstanceId: string;
    ContactFlowId: string;
    Attributes?: {
        [key: string]: string | undefined;
    };
    ParticipantDetails: ParticipantDetails;
    ParticipantConfiguration?: ParticipantConfiguration;
    InitialMessage?: ChatMessage;
    ClientToken?: string;
    ChatDurationInMinutes?: number;
    SupportedMessagingContentTypes?: string[];
    PersistentChat?: PersistentChat;
    RelatedContactId?: string;
    SegmentAttributes?: {
        [key: string]: SegmentAttributeValue | undefined;
    };
    CustomerId?: string | redacted.Redacted<string>;
    DisconnectOnCustomerExit?: DisconnectOnCustomerExitParticipantType[];
    ConnectionTypes?: ConnectionType[];
    ChatStreamingConfiguration?: ChatStreamingConfiguration;
}
export interface ConnectionCredentials {
    ConnectionToken?: string;
    Expiry?: string;
}
export type PreSignedConnectionUrl = string;
export interface Websocket {
    Url?: string;
    ConnectionExpiry?: string;
}
export type StreamingId = string;
export interface StartChatContactResponse {
    ContactId?: string;
    ParticipantId?: string;
    ParticipantToken?: string;
    ContinuedFromContactId?: string;
    ConnectionCredentials?: ConnectionCredentials;
    Websocket?: Websocket;
    StreamingId?: string;
}
export type AnalyticsModes = AnalyticsMode[];
export type LanguageLocale = string;
export interface LanguageConfiguration {
    LanguageLocale?: string;
}
export type Behavior = "Enable" | "Disable" | (string & {});
export type Policy = "None" | "RedactedOnly" | "RedactedAndOriginal" | (string & {});
export type Entity = string;
export type Entities = string[];
export type MaskMode = "PII" | "EntityType" | (string & {});
export interface RedactionConfiguration {
    Behavior: Behavior;
    Policy: Policy;
    Entities?: string[];
    MaskMode?: MaskMode;
}
export interface SentimentConfiguration {
    Behavior: Behavior;
}
export type SummaryMode = "PostContact" | "AutomatedInteraction" | "ContactChain" | (string & {});
export type SummaryModes = SummaryMode[];
export interface SummaryConfiguration {
    SummaryModes: SummaryMode[];
}
export interface RulesConfiguration {
    Behavior?: Behavior;
}
export interface AnalyticsConfiguration {
    LanguageConfiguration: LanguageConfiguration;
    RedactionConfiguration: RedactionConfiguration;
    SentimentConfiguration: SentimentConfiguration;
    SummaryConfiguration: SummaryConfiguration;
    RulesConfiguration: RulesConfiguration;
}
export interface StartContactConversationalAnalyticsJobRequest {
    InstanceId: string;
    ContactId: string;
    AnalyticsModes: AnalyticsMode[];
    AnalyticsConfiguration: AnalyticsConfiguration;
    ClientToken?: string;
}
export interface StartContactConversationalAnalyticsJobResponse {
    InstanceId?: string;
    ContactId?: string;
}
export interface AutoEvaluationConfiguration {
    Enabled: boolean;
}
export interface StartContactEvaluationRequest {
    InstanceId: string;
    ContactId: string;
    EvaluationFormId: string;
    AutoEvaluationConfiguration?: AutoEvaluationConfiguration;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface StartContactEvaluationResponse {
    EvaluationId: string;
    EvaluationArn: string;
}
export type ContactMediaProcessingFailureMode = "DELIVER_UNPROCESSED_MESSAGE" | "DO_NOT_DELIVER_UNPROCESSED_MESSAGE" | (string & {});
export interface StartContactMediaProcessingRequest {
    InstanceId?: string;
    ContactId?: string;
    ProcessorArn?: string;
    FailureMode?: ContactMediaProcessingFailureMode;
}
export interface StartContactMediaProcessingResponse {
}
export type VoiceRecordingTrack = "FROM_AGENT" | "TO_AGENT" | "ALL" | (string & {});
export type IvrRecordingTrack = "ALL" | (string & {});
export interface VoiceRecordingConfiguration {
    VoiceRecordingTrack?: VoiceRecordingTrack;
    IvrRecordingTrack?: IvrRecordingTrack;
}
export interface StartContactRecordingRequest {
    InstanceId: string;
    ContactId: string;
    InitialContactId: string;
    VoiceRecordingConfiguration: VoiceRecordingConfiguration;
}
export interface StartContactRecordingResponse {
}
export interface StartContactStreamingRequest {
    InstanceId: string;
    ContactId: string;
    ChatStreamingConfiguration: ChatStreamingConfiguration;
    ClientToken: string;
}
export interface StartContactStreamingResponse {
    StreamingId: string;
}
export type InboundMessageSourceType = "RAW" | (string & {});
export type InboundSubject = string | redacted.Redacted<string>;
export type EmailHeaderType = "REFERENCES" | "MESSAGE_ID" | "IN_REPLY_TO" | "X_SES_SPAM_VERDICT" | "X_SES_VIRUS_VERDICT" | (string & {});
export type EmailHeaderValue = string;
export type EmailHeaders = {
    [key in EmailHeaderType]?: string;
};
export interface InboundRawMessage {
    Subject: string | redacted.Redacted<string>;
    Body: string | redacted.Redacted<string>;
    ContentType: string;
    Headers?: {
        [key: string]: string | undefined;
    };
}
export interface InboundEmailContent {
    MessageSourceType: InboundMessageSourceType;
    RawMessage?: InboundRawMessage;
}
export interface InboundAdditionalRecipients {
    ToAddresses?: EmailAddressInfo[];
    CcAddresses?: EmailAddressInfo[];
}
export type PreSignedAttachmentUrl = string;
export interface EmailAttachment {
    FileName: string;
    S3Url: string;
}
export type EmailAttachments = EmailAttachment[];
export interface StartEmailContactRequest {
    InstanceId: string;
    FromEmailAddress: EmailAddressInfo;
    DestinationEmailAddress: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    References?: {
        [key: string]: Reference | undefined;
    };
    Name?: string | redacted.Redacted<string>;
    EmailMessage: InboundEmailContent;
    AdditionalRecipients?: InboundAdditionalRecipients;
    Attachments?: EmailAttachment[];
    ContactFlowId?: string;
    RelatedContactId?: string;
    Attributes?: {
        [key: string]: string | undefined;
    };
    SegmentAttributes?: {
        [key: string]: SegmentAttributeValue | undefined;
    };
    ClientToken?: string;
}
export interface StartEmailContactResponse {
    ContactId?: string;
}
export interface StartEvaluationFormValidationRequest {
    InstanceId: string;
    EvaluationFormId: string;
    EvaluationFormVersion: number;
}
export interface StartEvaluationFormValidationResponse {
    EvaluationFormId: string;
    EvaluationFormArn: string;
    EvaluationFormVersion: number;
}
export interface StartOutboundChatContactRequest {
    SourceEndpoint: Endpoint;
    DestinationEndpoint: Endpoint;
    InstanceId: string;
    SegmentAttributes: {
        [key: string]: SegmentAttributeValue | undefined;
    };
    Attributes?: {
        [key: string]: string | undefined;
    };
    ContactFlowId: string;
    ChatDurationInMinutes?: number;
    ParticipantDetails?: ParticipantDetails;
    InitialSystemMessage?: ChatMessage;
    InitialTemplatedSystemMessage?: TemplatedMessageConfig;
    RelatedContactId?: string;
    SupportedMessagingContentTypes?: string[];
    ClientToken?: string;
}
export interface StartOutboundChatContactResponse {
    ContactId?: string;
}
export interface StartOutboundEmailContactRequest {
    InstanceId: string;
    ContactId: string;
    FromEmailAddress?: EmailAddressInfo;
    DestinationEmailAddress: EmailAddressInfo;
    AdditionalRecipients?: OutboundAdditionalRecipients;
    EmailMessage: OutboundEmailContent;
    ClientToken?: string;
}
export interface StartOutboundEmailContactResponse {
    ContactId?: string;
}
export interface AnswerMachineDetectionConfig {
    EnableAnswerMachineDetection?: boolean;
    AwaitAnswerMachinePrompt?: boolean;
}
export type RingTimeoutInSeconds = number;
export interface StartOutboundVoiceContactRequest {
    Name?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    References?: {
        [key: string]: Reference | undefined;
    };
    RelatedContactId?: string;
    DestinationPhoneNumber: string;
    ContactFlowId: string;
    InstanceId: string;
    ClientToken?: string;
    SourcePhoneNumber?: string;
    QueueId?: string;
    Attributes?: {
        [key: string]: string | undefined;
    };
    AnswerMachineDetectionConfig?: AnswerMachineDetectionConfig;
    CampaignId?: string;
    TrafficType?: TrafficType;
    OutboundStrategy?: OutboundStrategy;
    RingTimeoutInSeconds?: number;
}
export interface StartOutboundVoiceContactResponse {
    ContactId?: string;
}
export interface StartScreenSharingRequest {
    ClientToken?: string;
    InstanceId: string;
    ContactId: string;
}
export interface StartScreenSharingResponse {
}
export interface TaskAttachment {
    FileName: string;
    S3Url: string;
}
export type TaskAttachments = TaskAttachment[];
export interface StartTaskContactRequest {
    InstanceId: string;
    PreviousContactId?: string;
    ContactFlowId?: string;
    Attributes?: {
        [key: string]: string | undefined;
    };
    Name: string | redacted.Redacted<string>;
    References?: {
        [key: string]: Reference | undefined;
    };
    Description?: string | redacted.Redacted<string>;
    ClientToken?: string;
    ScheduledTime?: Date;
    TaskTemplateId?: string;
    QuickConnectId?: string;
    RelatedContactId?: string;
    SegmentAttributes?: {
        [key: string]: SegmentAttributeValue | undefined;
    };
    Attachments?: TaskAttachment[];
}
export interface StartTaskContactResponse {
    ContactId?: string;
}
export interface StartTestCaseExecutionRequest {
    InstanceId: string;
    TestCaseId: string;
    ClientToken?: string;
}
export interface StartTestCaseExecutionResponse {
    TestCaseExecutionId?: string;
    TestCaseId?: string;
    Status?: TestCaseExecutionStatus;
}
export interface AllowedCapabilities {
    Customer?: ParticipantCapabilities;
    Agent?: ParticipantCapabilities;
}
export interface StartWebRTCContactRequest {
    Attributes?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
    ContactFlowId: string;
    InstanceId: string;
    AllowedCapabilities?: AllowedCapabilities;
    ParticipantDetails: ParticipantDetails;
    RelatedContactId?: string;
    References?: {
        [key: string]: Reference | undefined;
    };
    Description?: string | redacted.Redacted<string>;
    SegmentAttributes?: {
        [key: string]: SegmentAttributeValue | undefined;
    };
}
export type AttendeeId = string;
export type JoinToken = string | redacted.Redacted<string>;
export interface Attendee {
    AttendeeId?: string;
    JoinToken?: string | redacted.Redacted<string>;
}
export type MediaRegion = string;
export interface MediaPlacement {
    AudioHostUrl?: string;
    AudioFallbackUrl?: string;
    SignalingUrl?: string;
    TurnControlUrl?: string;
    EventIngestionUrl?: string;
}
export type MeetingFeatureStatus = "AVAILABLE" | "UNAVAILABLE" | (string & {});
export interface AudioFeatures {
    EchoReduction?: MeetingFeatureStatus;
}
export interface MeetingFeaturesConfiguration {
    Audio?: AudioFeatures;
}
export type MeetingId = string;
export interface Meeting {
    MediaRegion?: string;
    MediaPlacement?: MediaPlacement;
    MeetingFeatures?: MeetingFeaturesConfiguration;
    MeetingId?: string;
}
export interface ConnectionData {
    Attendee?: Attendee;
    Meeting?: Meeting;
}
export interface StartWebRTCContactResponse {
    ConnectionData?: ConnectionData;
    ContactId?: string;
    ParticipantId?: string;
    ParticipantToken?: string;
}
export type DisconnectReasonCode = string;
export interface DisconnectReason {
    Code?: string;
}
export interface StopContactRequest {
    ContactId: string;
    InstanceId: string;
    DisconnectReason?: DisconnectReason;
}
export interface StopContactResponse {
}
export interface StopContactMediaProcessingRequest {
    InstanceId?: string;
    ContactId?: string;
}
export interface StopContactMediaProcessingResponse {
}
export interface StopContactRecordingRequest {
    InstanceId: string;
    ContactId: string;
    InitialContactId: string;
    ContactRecordingType?: ContactRecordingType;
}
export interface StopContactRecordingResponse {
}
export interface StopContactStreamingRequest {
    InstanceId: string;
    ContactId: string;
    StreamingId: string;
}
export interface StopContactStreamingResponse {
}
export interface StopTestCaseExecutionRequest {
    InstanceId: string;
    TestCaseExecutionId: string;
    TestCaseId: string;
    ClientToken?: string;
}
export interface StopTestCaseExecutionResponse {
}
export interface EvaluationAnswerInput {
    Value?: EvaluationAnswerData;
}
export type EvaluationAnswersInputMap = {
    [key: string]: EvaluationAnswerInput | undefined;
};
export type EvaluatorUserUnion = {
    ConnectUserArn: string;
};
export interface SubmitContactEvaluationRequest {
    InstanceId: string;
    EvaluationId: string;
    Answers?: {
        [key: string]: EvaluationAnswerInput | undefined;
    };
    Notes?: {
        [key: string]: EvaluationNote | undefined;
    };
    SubmittedBy?: EvaluatorUserUnion;
}
export interface SubmitContactEvaluationResponse {
    EvaluationId: string;
    EvaluationArn: string;
}
export interface SuspendContactRecordingRequest {
    InstanceId: string;
    ContactId: string;
    InitialContactId: string;
    ContactRecordingType?: ContactRecordingType;
}
export interface SuspendContactRecordingResponse {
}
export interface TagContactRequest {
    ContactId: string;
    InstanceId: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagContactResponse {
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export interface TransferContactRequest {
    InstanceId: string;
    ContactId: string;
    QueueId?: string;
    UserId?: string;
    ContactFlowId: string;
    ClientToken?: string;
}
export interface TransferContactResponse {
    ContactId?: string;
    ContactArn?: string;
}
export type ContactTagKeys = string[];
export interface UntagContactRequest {
    ContactId: string;
    InstanceId: string;
    TagKeys: string[];
}
export interface UntagContactResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export type UpdateAgentStatusDescription = string;
export interface UpdateAgentStatusRequest {
    InstanceId: string;
    AgentStatusId: string;
    Name?: string;
    Description?: string;
    State?: AgentStatusState;
    DisplayOrder?: number;
    ResetOrderNumber?: boolean;
}
export interface UpdateAgentStatusResponse {
}
export interface UpdateAttachedFilesConfigurationRequest {
    InstanceId: string;
    AttachmentScope: AttachmentScope;
    MaximumSizeLimitInBytes?: number;
    ExtensionConfiguration?: ExtensionConfiguration;
}
export interface UpdateAttachedFilesConfigurationResponse {
    InstanceId: string;
    AttachmentScope: AttachmentScope;
    MaximumSizeLimitInBytes?: number;
    ExtensionConfiguration?: ExtensionConfiguration;
    LastModifiedTime?: Date;
}
export interface UpdateAuthenticationProfileRequest {
    AuthenticationProfileId: string;
    InstanceId: string;
    Name?: string;
    Description?: string;
    AllowedIps?: string[];
    BlockedIps?: string[];
    PeriodicSessionDuration?: number;
    SessionInactivityDuration?: number;
    SessionInactivityHandlingEnabled?: boolean;
}
export interface UpdateAuthenticationProfileResponse {
}
export interface QueueInfoInput {
    Id?: string;
}
export interface UpdateContactRequest {
    InstanceId: string;
    ContactId: string;
    Name?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    References?: {
        [key: string]: Reference | undefined;
    };
    SegmentAttributes?: {
        [key: string]: SegmentAttributeValue | undefined;
    };
    QueueInfo?: QueueInfoInput;
    UserInfo?: UserInfo;
    CustomerEndpoint?: Endpoint;
    SystemEndpoint?: Endpoint;
}
export interface UpdateContactResponse {
}
export interface UpdateContactAttributesRequest {
    InitialContactId: string;
    InstanceId: string;
    Attributes: {
        [key: string]: string | undefined;
    };
}
export interface UpdateContactAttributesResponse {
}
export interface UpdateContactEvaluationRequest {
    InstanceId: string;
    EvaluationId: string;
    Answers?: {
        [key: string]: EvaluationAnswerInput | undefined;
    };
    Notes?: {
        [key: string]: EvaluationNote | undefined;
    };
    UpdatedBy?: EvaluatorUserUnion;
}
export interface UpdateContactEvaluationResponse {
    EvaluationId: string;
    EvaluationArn: string;
}
export interface UpdateContactFlowContentRequest {
    InstanceId: string;
    ContactFlowId: string;
    Content: string;
}
export interface UpdateContactFlowContentResponse {
}
export interface UpdateContactFlowMetadataRequest {
    InstanceId: string;
    ContactFlowId: string;
    Name?: string;
    Description?: string;
    ContactFlowState?: ContactFlowState;
}
export interface UpdateContactFlowMetadataResponse {
}
export interface UpdateContactFlowModuleAliasRequest {
    InstanceId: string;
    ContactFlowModuleId: string;
    AliasId: string;
    Name?: string;
    Description?: string;
    ContactFlowModuleVersion?: number;
}
export interface UpdateContactFlowModuleAliasResponse {
}
export interface UpdateContactFlowModuleContentRequest {
    InstanceId: string;
    ContactFlowModuleId: string;
    Content?: string;
    Settings?: string;
}
export interface UpdateContactFlowModuleContentResponse {
}
export interface UpdateContactFlowModuleMetadataRequest {
    InstanceId: string;
    ContactFlowModuleId: string;
    Name?: string;
    Description?: string;
    State?: ContactFlowModuleState;
}
export interface UpdateContactFlowModuleMetadataResponse {
}
export interface UpdateContactFlowNameRequest {
    InstanceId: string;
    ContactFlowId: string;
    Name?: string;
    Description?: string;
}
export interface UpdateContactFlowNameResponse {
}
export interface RoutingCriteriaInputStepExpiry {
    DurationInSeconds?: number;
}
export interface RoutingCriteriaInputStep {
    Expiry?: RoutingCriteriaInputStepExpiry;
    Expression?: Expression;
}
export type RoutingCriteriaInputSteps = RoutingCriteriaInputStep[];
export interface RoutingCriteriaInput {
    Steps?: RoutingCriteriaInputStep[];
}
export interface UpdateContactRoutingDataRequest {
    InstanceId: string;
    ContactId: string;
    QueueTimeAdjustmentSeconds?: number;
    QueuePriority?: number;
    RoutingCriteria?: RoutingCriteriaInput;
}
export interface UpdateContactRoutingDataResponse {
}
export interface UpdateContactScheduleRequest {
    InstanceId: string;
    ContactId: string;
    ScheduledTime: Date;
}
export interface UpdateContactScheduleResponse {
}
export interface UpdateContactTaskTemplateRequest {
    InstanceId: string;
    TaskTemplateId: string;
    ContactId: string;
}
export interface UpdateContactTaskTemplateResponse {
}
export interface UpdateCrossRegionRoutingRequest {
    InstanceId: string;
    IsolatedAll: boolean;
}
export interface UpdateCrossRegionRoutingResponse {
}
export interface UpdateDataTableAttributeRequest {
    InstanceId: string;
    DataTableId: string;
    AttributeName: string;
    Name: string;
    ValueType: DataTableAttributeValueType;
    Description?: string;
    Primary?: boolean;
    Validation?: Validation;
}
export interface UpdateDataTableAttributeResponse {
    Name: string;
    LockVersion: DataTableLockVersion;
}
export interface UpdateDataTableMetadataRequest {
    InstanceId: string;
    DataTableId: string;
    Name: string;
    Description?: string;
    ValueLockLevel: DataTableLockLevel;
    TimeZone: string;
}
export interface UpdateDataTableMetadataResponse {
    LockVersion: DataTableLockVersion;
}
export interface UpdateDataTablePrimaryValuesRequest {
    InstanceId: string;
    DataTableId: string;
    PrimaryValues: PrimaryValue[];
    NewPrimaryValues: PrimaryValue[];
    LockVersion: DataTableLockVersion;
}
export interface UpdateDataTablePrimaryValuesResponse {
    LockVersion: DataTableLockVersion;
}
export interface UpdateEmailAddressMetadataRequest {
    InstanceId: string;
    EmailAddressId: string;
    Description?: string | redacted.Redacted<string>;
    DisplayName?: string | redacted.Redacted<string>;
    ClientToken?: string;
}
export interface UpdateEmailAddressMetadataResponse {
    EmailAddressId?: string;
    EmailAddressArn?: string;
}
export interface UpdateEvaluationFormRequest {
    InstanceId: string;
    EvaluationFormId: string;
    EvaluationFormVersion: number;
    CreateNewVersion?: boolean;
    Title: string;
    Description?: string;
    Items: EvaluationFormItem[];
    ScoringStrategy?: EvaluationFormScoringStrategy;
    AutoEvaluationConfiguration?: EvaluationFormAutoEvaluationConfiguration;
    ReviewConfiguration?: EvaluationReviewConfiguration;
    AsDraft?: boolean;
    ClientToken?: string;
    TargetConfiguration?: EvaluationFormTargetConfiguration;
    LanguageConfiguration?: EvaluationFormLanguageConfiguration;
    AIVersion?: string;
}
export interface UpdateEvaluationFormResponse {
    EvaluationFormId: string;
    EvaluationFormArn: string;
    EvaluationFormVersion: number;
}
export interface UpdateExtractionDefinitionRequest {
    ClientToken?: string;
    ExtractionDefinitionId: string;
    InstanceId: string;
    Name: string;
    ExtractionConfiguration: ExtractionConfiguration;
    Display?: ExtractionDefinitionDisplay;
}
export interface UpdateExtractionDefinitionResponse {
}
export type UpdateHoursOfOperationDescription = string;
export interface UpdateHoursOfOperationRequest {
    InstanceId: string;
    HoursOfOperationId: string;
    Name?: string;
    Description?: string;
    TimeZone?: string;
    Config?: HoursOfOperationConfig[];
}
export interface UpdateHoursOfOperationResponse {
}
export interface UpdateHoursOfOperationOverrideRequest {
    InstanceId: string;
    HoursOfOperationId: string;
    HoursOfOperationOverrideId: string;
    Name?: string;
    Description?: string;
    Config?: HoursOfOperationOverrideConfig[];
    EffectiveFrom?: string;
    EffectiveTill?: string;
    RecurrenceConfig?: RecurrenceConfig;
    OverrideType?: OverrideType;
}
export interface UpdateHoursOfOperationOverrideResponse {
}
export interface UpdateInstanceAttributeRequest {
    InstanceId: string;
    AttributeType: InstanceAttributeType;
    Value: string;
    ClientToken?: string;
}
export interface UpdateInstanceAttributeResponse {
}
export interface UpdateInstanceStorageConfigRequest {
    InstanceId: string;
    AssociationId: string;
    ResourceType: InstanceStorageResourceType;
    StorageConfig: InstanceStorageConfig;
    ClientToken?: string;
}
export interface UpdateInstanceStorageConfigResponse {
}
export interface UpdateMetricContentRequest {
    InstanceId: string;
    MetricId: string;
    MetricCalculation?: MetricCalculation;
    Unit?: MetricUnit;
    PositiveTrendIndicator?: TrendIndicator;
}
export interface UpdateMetricContentResponse {
}
export interface UpdateMetricMetadataRequest {
    InstanceId: string;
    MetricId: string;
    Name?: string;
    Description?: string;
}
export interface UpdateMetricMetadataResponse {
}
export interface UpdateNotificationContentRequest {
    InstanceId: string;
    NotificationId: string;
    Content: {
        [key: string]: string | undefined;
    };
}
export interface UpdateNotificationContentResponse {
}
export type AuthorizationCode = string | redacted.Redacted<string>;
export type AuthenticationError = string | redacted.Redacted<string>;
export type AuthenticationErrorDescription = string | redacted.Redacted<string>;
export interface UpdateParticipantAuthenticationRequest {
    State: string;
    InstanceId: string;
    Code?: string | redacted.Redacted<string>;
    Error?: string | redacted.Redacted<string>;
    ErrorDescription?: string | redacted.Redacted<string>;
}
export interface UpdateParticipantAuthenticationResponse {
}
export type TimerEligibleParticipantRoles = "CUSTOMER" | "AGENT" | (string & {});
export type ParticipantTimerType = "IDLE" | "DISCONNECT_NONCUSTOMER" | (string & {});
export type ParticipantTimerAction = "Unset" | (string & {});
export type ParticipantTimerDurationInMinutes = number;
export type ParticipantTimerValue = {
    ParticipantTimerAction: ParticipantTimerAction;
    ParticipantTimerDurationInMinutes?: never;
} | {
    ParticipantTimerAction?: never;
    ParticipantTimerDurationInMinutes: number;
};
export interface ParticipantTimerConfiguration {
    ParticipantRole: TimerEligibleParticipantRoles;
    TimerType: ParticipantTimerType;
    TimerValue: ParticipantTimerValue;
}
export type ParticipantTimerConfigList = ParticipantTimerConfiguration[];
export interface ChatParticipantRoleConfig {
    ParticipantTimerConfigList: ParticipantTimerConfiguration[];
}
export type UpdateParticipantRoleConfigChannelInfo = {
    Chat: ChatParticipantRoleConfig;
};
export interface UpdateParticipantRoleConfigRequest {
    InstanceId: string;
    ContactId: string;
    ChannelConfiguration: UpdateParticipantRoleConfigChannelInfo;
}
export interface UpdateParticipantRoleConfigResponse {
}
export interface UpdatePhoneNumberRequest {
    PhoneNumberId: string;
    TargetArn?: string;
    InstanceId?: string;
    ClientToken?: string;
}
export interface UpdatePhoneNumberResponse {
    PhoneNumberId?: string;
    PhoneNumberArn?: string;
}
export interface UpdatePhoneNumberMetadataRequest {
    PhoneNumberId: string;
    PhoneNumberDescription?: string;
    ClientToken?: string;
}
export interface UpdatePhoneNumberMetadataResponse {
}
export interface UpdatePredefinedAttributeRequest {
    InstanceId: string;
    Name: string;
    Values?: PredefinedAttributeValues;
    Purposes?: string[];
    AttributeConfiguration?: InputPredefinedAttributeConfiguration;
}
export interface UpdatePredefinedAttributeResponse {
}
export interface UpdatePromptRequest {
    InstanceId: string;
    PromptId: string;
    Name?: string;
    Description?: string;
    S3Uri?: string;
}
export interface UpdatePromptResponse {
    PromptARN?: string;
    PromptId?: string;
}
export interface UpdateQueueHoursOfOperationRequest {
    InstanceId: string;
    QueueId: string;
    HoursOfOperationId: string;
}
export interface UpdateQueueHoursOfOperationResponse {
}
export interface UpdateQueueMaxContactsRequest {
    InstanceId: string;
    QueueId: string;
    MaxContacts?: number;
}
export interface UpdateQueueMaxContactsResponse {
}
export interface UpdateQueueNameRequest {
    InstanceId: string;
    QueueId: string;
    Name?: string;
    Description?: string;
}
export interface UpdateQueueNameResponse {
}
export interface UpdateQueueOutboundCallerConfigRequest {
    InstanceId: string;
    QueueId: string;
    OutboundCallerConfig: OutboundCallerConfig;
}
export interface UpdateQueueOutboundCallerConfigResponse {
}
export interface UpdateQueueOutboundEmailConfigRequest {
    InstanceId: string;
    QueueId: string;
    OutboundEmailConfig: OutboundEmailConfig;
}
export interface UpdateQueueOutboundEmailConfigResponse {
}
export interface UpdateQueueStatusRequest {
    InstanceId: string;
    QueueId: string;
    Status: QueueStatus;
}
export interface UpdateQueueStatusResponse {
}
export interface UpdateQuickConnectConfigRequest {
    InstanceId: string;
    QuickConnectId: string;
    QuickConnectConfig: QuickConnectConfig;
}
export interface UpdateQuickConnectConfigResponse {
}
export type UpdateQuickConnectDescription = string;
export interface UpdateQuickConnectNameRequest {
    InstanceId: string;
    QuickConnectId: string;
    Name?: string;
    Description?: string;
}
export interface UpdateQuickConnectNameResponse {
}
export interface UpdateRoutingProfileAgentAvailabilityTimerRequest {
    InstanceId: string;
    RoutingProfileId: string;
    AgentAvailabilityTimer: AgentAvailabilityTimer;
}
export interface UpdateRoutingProfileAgentAvailabilityTimerResponse {
}
export interface UpdateRoutingProfileConcurrencyRequest {
    InstanceId: string;
    RoutingProfileId: string;
    MediaConcurrencies: MediaConcurrency[];
}
export interface UpdateRoutingProfileConcurrencyResponse {
}
export interface UpdateRoutingProfileDefaultOutboundQueueRequest {
    InstanceId: string;
    RoutingProfileId: string;
    DefaultOutboundQueueId: string;
}
export interface UpdateRoutingProfileDefaultOutboundQueueResponse {
}
export interface UpdateRoutingProfileNameRequest {
    InstanceId: string;
    RoutingProfileId: string;
    Name?: string;
    Description?: string;
}
export interface UpdateRoutingProfileNameResponse {
}
export interface UpdateRoutingProfileQueuesRequest {
    InstanceId: string;
    RoutingProfileId: string;
    QueueConfigs: RoutingProfileQueueConfig[];
}
export interface UpdateRoutingProfileQueuesResponse {
}
export interface UpdateRuleRequest {
    RuleId: string;
    InstanceId: string;
    Name: string;
    Function: string;
    Actions: RuleAction[];
    PublishStatus: RulePublishStatus;
    PreEvaluationFilters?: PreEvaluationFilters;
}
export interface UpdateRuleResponse {
}
export interface UpdateSecurityProfileRequest {
    Description?: string;
    Permissions?: string[];
    SecurityProfileId: string;
    InstanceId: string;
    AllowedAccessControlTags?: {
        [key: string]: string | undefined;
    };
    TagRestrictedResources?: string[];
    Applications?: Application[];
    HierarchyRestrictedResources?: string[];
    AllowedAccessControlHierarchyGroupId?: string;
    AllowedFlowModules?: FlowModule[];
    AllowedAIAgents?: AIAgent[];
    GranularAccessControlConfiguration?: GranularAccessControlConfiguration;
}
export interface UpdateSecurityProfileResponse {
}
export interface UpdateTaskTemplateRequest {
    TaskTemplateId: string;
    InstanceId: string;
    Name?: string;
    Description?: string;
    ContactFlowId?: string;
    SelfAssignFlowId?: string;
    Constraints?: TaskTemplateConstraints;
    Defaults?: TaskTemplateDefaults;
    Status?: TaskTemplateStatus;
    Fields?: TaskTemplateField[];
}
export interface UpdateTaskTemplateResponse {
    InstanceId?: string;
    Id?: string;
    Arn?: string;
    Name?: string;
    Description?: string;
    ContactFlowId?: string;
    SelfAssignFlowId?: string;
    Constraints?: TaskTemplateConstraints;
    Defaults?: TaskTemplateDefaults;
    Fields?: TaskTemplateField[];
    Status?: TaskTemplateStatus;
    LastModifiedTime?: Date;
    CreatedTime?: Date;
}
export interface UpdateTestCaseRequest {
    InstanceId: string;
    TestCaseId: string;
    Content?: string;
    EntryPoint?: TestCaseEntryPoint;
    InitializationData?: string;
    Name?: string;
    Description?: string;
    Status?: TestCaseStatus;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface UpdateTestCaseResponse {
}
export interface UpdateTrafficDistributionRequest {
    Id: string;
    TelephonyConfig?: TelephonyConfig;
    SignInConfig?: SignInConfig;
    AgentConfig?: AgentConfig;
}
export interface UpdateTrafficDistributionResponse {
}
export interface UpdateUserConfigRequest {
    AutoAcceptConfigs?: AutoAcceptConfig[];
    AfterContactWorkConfigs?: AfterContactWorkConfigPerChannel[];
    PhoneNumberConfigs?: PhoneNumberConfig[];
    PersistentConnectionConfigs?: PersistentConnectionConfig[];
    VoiceEnhancementConfigs?: VoiceEnhancementConfig[];
    UserId: string;
    InstanceId: string;
}
export interface UpdateUserConfigResponse {
}
export interface UpdateUserHierarchyRequest {
    HierarchyGroupId?: string;
    UserId: string;
    InstanceId: string;
}
export interface UpdateUserHierarchyResponse {
}
export interface UpdateUserHierarchyGroupNameRequest {
    Name: string;
    HierarchyGroupId: string;
    InstanceId: string;
}
export interface UpdateUserHierarchyGroupNameResponse {
}
export interface HierarchyLevelUpdate {
    Name: string;
}
export interface HierarchyStructureUpdate {
    LevelOne?: HierarchyLevelUpdate;
    LevelTwo?: HierarchyLevelUpdate;
    LevelThree?: HierarchyLevelUpdate;
    LevelFour?: HierarchyLevelUpdate;
    LevelFive?: HierarchyLevelUpdate;
}
export interface UpdateUserHierarchyStructureRequest {
    HierarchyStructure: HierarchyStructureUpdate;
    InstanceId: string;
}
export interface UpdateUserHierarchyStructureResponse {
}
export interface UpdateUserIdentityInfoRequest {
    IdentityInfo: UserIdentityInfo;
    UserId: string;
    InstanceId: string;
}
export interface UpdateUserIdentityInfoResponse {
}
export interface UpdateUserNotificationStatusRequest {
    InstanceId: string;
    NotificationId: string;
    UserId: string;
    Status: NotificationStatus;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export interface UpdateUserNotificationStatusResponse {
}
export interface UpdateUserPhoneConfigRequest {
    PhoneConfig: UserPhoneConfig;
    UserId: string;
    InstanceId: string;
}
export interface UpdateUserPhoneConfigResponse {
}
export interface UpdateUserProficienciesRequest {
    InstanceId: string;
    UserId: string;
    UserProficiencies: UserProficiency[];
}
export interface UpdateUserProficienciesResponse {
}
export interface UpdateUserRoutingProfileRequest {
    RoutingProfileId: string;
    UserId: string;
    InstanceId: string;
}
export interface UpdateUserRoutingProfileResponse {
}
export interface UpdateUserSecurityProfilesRequest {
    SecurityProfileIds: string[];
    UserId: string;
    InstanceId: string;
}
export interface UpdateUserSecurityProfilesResponse {
}
export interface UpdateViewContentRequest {
    InstanceId: string;
    ViewId: string;
    Status: ViewStatus;
    Content: ViewInputContent;
}
export interface UpdateViewContentResponse {
    View?: View;
}
export interface UpdateViewMetadataRequest {
    InstanceId: string;
    ViewId: string;
    Name?: string | redacted.Redacted<string>;
    Description?: string;
}
export interface UpdateViewMetadataResponse {
}
export interface UpdateWorkspaceMetadataRequest {
    InstanceId: string;
    WorkspaceId: string;
    Name?: string;
    Description?: string;
    Title?: string;
}
export interface UpdateWorkspaceMetadataResponse {
}
export interface UpdateWorkspacePageRequest {
    InstanceId: string;
    WorkspaceId: string;
    Page: string;
    NewPage?: string;
    ResourceArn?: string;
    Slug?: string;
    InputData?: string;
}
export interface UpdateWorkspacePageResponse {
}
export interface UpdateWorkspaceThemeRequest {
    InstanceId: string;
    WorkspaceId: string;
    Theme?: WorkspaceTheme;
}
export interface UpdateWorkspaceThemeResponse {
}
export interface UpdateWorkspaceVisibilityRequest {
    InstanceId: string;
    WorkspaceId: string;
    Visibility: Visibility;
}
export interface UpdateWorkspaceVisibilityResponse {
}
export type Message = string;
export type AttachedFileInvalidRequestExceptionReason = "INVALID_FILE_SIZE" | "INVALID_FILE_TYPE" | "INVALID_FILE_NAME" | (string & {});
export type InvalidRequestExceptionReason = {
    AttachedFileInvalidRequestExceptionReason: AttachedFileInvalidRequestExceptionReason;
};
export type AttachedFileServiceQuotaExceededExceptionReason = "TOTAL_FILE_SIZE_EXCEEDED" | "TOTAL_FILE_COUNT_EXCEEDED" | (string & {});
export type ServiceQuotaExceededExceptionReason = {
    AttachedFileServiceQuotaExceededExceptionReason: AttachedFileServiceQuotaExceededExceptionReason;
};
export type ProblemMessageString = string;
export interface ProblemDetail {
    message?: string;
}
export type Problems = ProblemDetail[];
export type PropertyValidationExceptionReason = "INVALID_FORMAT" | "UNIQUE_CONSTRAINT_VIOLATED" | "REFERENCED_RESOURCE_NOT_FOUND" | "RESOURCE_NAME_ALREADY_EXISTS" | "REQUIRED_PROPERTY_MISSING" | "NOT_SUPPORTED" | "TYPE_MISMATCH" | (string & {});
export interface PropertyValidationExceptionProperty {
    PropertyPath: string;
    Reason: PropertyValidationExceptionReason;
    Message: string;
}
export type PropertyValidationExceptionPropertyList = PropertyValidationExceptionProperty[];
export type ResourceType = "CONTACT" | "CONTACT_FLOW" | "INSTANCE" | "PARTICIPANT" | "HIERARCHY_LEVEL" | "HIERARCHY_GROUP" | "USER" | "PHONE_NUMBER" | (string & {});
export type ActivateEvaluationFormError = InternalServiceException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Activates an evaluation form in the specified Connect Customer instance. After the evaluation form is
 * activated, it is available to start new evaluations based on the form.
 */
export declare const activateEvaluationForm: API.OperationMethod<ActivateEvaluationFormRequest, ActivateEvaluationFormResponse, ActivateEvaluationFormError, Creds | HttpClient.HttpClient>;
export type AssociateAnalyticsDataSetError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates the specified dataset for a Connect Customer instance with the target account. You can associate
 * only one dataset in a single call.
 */
export declare const associateAnalyticsDataSet: API.OperationMethod<AssociateAnalyticsDataSetRequest, AssociateAnalyticsDataSetResponse, AssociateAnalyticsDataSetError, Creds | HttpClient.HttpClient>;
export type AssociateApprovedOriginError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Associates an approved origin to an Connect Customer instance.
 */
export declare const associateApprovedOrigin: API.OperationMethod<AssociateApprovedOriginRequest, AssociateApprovedOriginResponse, AssociateApprovedOriginError, Creds | HttpClient.HttpClient>;
export type AssociateBotError = InternalServiceException | InvalidRequestException | LimitExceededException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Allows the specified Connect Customer instance to access the specified Amazon Lex or Amazon Lex V2
 * bot.
 */
export declare const associateBot: API.OperationMethod<AssociateBotRequest, AssociateBotResponse, AssociateBotError, Creds | HttpClient.HttpClient>;
export type AssociateContactWithUserError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a queued contact with an agent.
 *
 * **Use cases**
 *
 * Following are common uses cases for this API:
 *
 * - Programmatically assign queued contacts to available users.
 *
 * - Leverage the IAM context key `connect:PreferredUserArn` to restrict contact association to specific
 * preferred user.
 *
 * **Important things to know**
 *
 * - Use this API with chat, email, task, and voice contacts. For voice callbacks, this API does not support customer-first mode.
 *
 * - This API can be used to offer a contact to an agent even if the agent is currently at maximum concurrency
 * for the channel.
 *
 * - Use it to associate contacts with users regardless of their current state, including custom states. Ensure
 * your application logic accounts for user availability before making associations.
 *
 * - It honors the IAM context key `connect:PreferredUserArn` to prevent unauthorized contact
 * associations.
 *
 * - It respects the IAM context key `connect:PreferredUserArn` to enforce authorization controls and
 * prevent unauthorized contact associations. Verify that your IAM policies are properly configured to support your
 * intended use cases.
 *
 * - The service quota *Queues per routing profile per instance* applies to manually assigned
 * queues, too. For more information about this quota, see Connect Customer
 * quotas in the *Connect Customer Administrator Guide*.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const associateContactWithUser: API.OperationMethod<AssociateContactWithUserRequest, AssociateContactWithUserResponse, AssociateContactWithUserError, Creds | HttpClient.HttpClient>;
export type AssociateDefaultVocabularyError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates an existing vocabulary as the default. Contact Lens for Connect Customer uses the vocabulary in post-call and real-time
 * analysis sessions for the given language.
 */
export declare const associateDefaultVocabulary: API.OperationMethod<AssociateDefaultVocabularyRequest, AssociateDefaultVocabularyResponse, AssociateDefaultVocabularyError, Creds | HttpClient.HttpClient>;
export type AssociateEmailAddressAliasError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates an email address alias with an existing email address in an Connect Customer instance. This creates
 * a forwarding relationship where emails sent to the alias email address are automatically forwarded to the primary
 * email address.
 *
 * **Use cases**
 *
 * Following are common uses cases for this API:
 *
 * - **Unified customer support**: Create multiple entry points (for example,
 * support@example.com, help@example.com, customercare@example.com) that all forward to a single agent queue for
 * streamlined management.
 *
 * - **Department consolidation**: Forward emails from legacy department addresses
 * (for example, sales@example.com, info@example.com) to a centralized customer service email during organizational
 * restructuring.
 *
 * - **Brand management**: Enable you to use familiar brand-specific email addresses
 * that forward to the appropriate Connect Customer instance email address.
 *
 * **Important things to know**
 *
 * - Each email address can have a maximum of one alias. You cannot create multiple aliases for the same email
 * address.
 *
 * - If the alias email address already receives direct emails, it continues to receive direct emails plus
 * forwarded emails.
 *
 * - You cannot chain email aliases together (that is, create an alias of an alias).
 *
 * `AssociateEmailAddressAlias` does not return the following information:
 *
 * - A confirmation of the alias relationship details (you must call DescribeEmailAddress to verify).
 *
 * - The timestamp of when the association occurred.
 *
 * - The status of the forwarding configuration.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 *
 * **Related operations**
 *
 * - DisassociateEmailAddressAlias: Removes the alias association between two email addresses in an Connect Customer instance.
 *
 * - DescribeEmailAddress: View current alias configurations for an email address.
 *
 * - SearchEmailAddresses: Find email addresses and their alias relationships across an instance.
 *
 * - CreateEmailAddress: Create new email addresses that can participate in alias relationships.
 *
 * - DeleteEmailAddress: Remove email addresses (automatically removes any alias relationships).
 *
 * - UpdateEmailAddressMetadata: Modify email address properties (does not affect alias relationships).
 */
export declare const associateEmailAddressAlias: API.OperationMethod<AssociateEmailAddressAliasRequest, AssociateEmailAddressAliasResponse, AssociateEmailAddressAliasError, Creds | HttpClient.HttpClient>;
export type AssociateFlowError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a connect resource to a flow.
 */
export declare const associateFlow: API.OperationMethod<AssociateFlowRequest, AssociateFlowResponse, AssociateFlowError, Creds | HttpClient.HttpClient>;
export type AssociateHoursOfOperationsError = ConditionalOperationFailedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Associates a set of hours of operations with another hours of operation. For more information about inheriting overrides from parent hours of operation, see Hours of operation overrides in the Administrator Guide.
 */
export declare const associateHoursOfOperations: API.OperationMethod<AssociateHoursOfOperationsRequest, AssociateHoursOfOperationsResponse, AssociateHoursOfOperationsError, Creds | HttpClient.HttpClient>;
export type AssociateInstanceStorageConfigError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Associates a storage resource type for the first time. You can only associate one type of storage configuration
 * in a single call. This means, for example, that you can't define an instance with multiple S3 buckets for storing
 * chat transcripts.
 *
 * This API does not create a resource that doesn't exist. It only associates it to the instance. Ensure that the
 * resource being specified in the storage configuration, like an S3 bucket, exists when being used for
 * association.
 */
export declare const associateInstanceStorageConfig: API.OperationMethod<AssociateInstanceStorageConfigRequest, AssociateInstanceStorageConfigResponse, AssociateInstanceStorageConfigError, Creds | HttpClient.HttpClient>;
export type AssociateLambdaFunctionError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Allows the specified Connect Customer instance to access the specified Lambda function.
 */
export declare const associateLambdaFunction: API.OperationMethod<AssociateLambdaFunctionRequest, AssociateLambdaFunctionResponse, AssociateLambdaFunctionError, Creds | HttpClient.HttpClient>;
export type AssociateLexBotError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Allows the specified Connect Customer instance to access the specified Amazon Lex V1 bot. This API
 * only supports the association of Amazon Lex V1 bots.
 */
export declare const associateLexBot: API.OperationMethod<AssociateLexBotRequest, AssociateLexBotResponse, AssociateLexBotError, Creds | HttpClient.HttpClient>;
export type AssociatePhoneNumberContactFlowError = AccessDeniedException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a flow with a phone number claimed to your Connect Customer instance.
 *
 * If the number is claimed to a traffic distribution group, and you are calling this API using an instance in the Amazon Web Services Region where the traffic distribution group was created, you can use either a full phone number ARN or UUID value for the
 * `PhoneNumberId` URI request parameter. However, if the number is claimed to a traffic distribution group and you are calling
 * this API using an instance in the alternate Amazon Web Services Region associated with the traffic distribution group, you must provide a
 * full phone number ARN. If a UUID is provided
 * in
 * this scenario, you will receive a `ResourceNotFoundException`.
 */
export declare const associatePhoneNumberContactFlow: API.OperationMethod<AssociatePhoneNumberContactFlowRequest, AssociatePhoneNumberContactFlowResponse, AssociatePhoneNumberContactFlowError, Creds | HttpClient.HttpClient>;
export type AssociateQueueEmailAddressesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a set of email addresses with a queue to enable agents to select different "From" (system) email addresses when replying to inbound email contacts or initiating outbound email contacts. This allows agents to handle email contacts across different brands and business units within the same queue.
 *
 * **Important things to know**
 *
 * - You can associate up to 49 additional email addresses with a single queue, plus 1 default outbound email address, for a total of 50.
 *
 * - The email addresses must already exist in the Connect Customer instance before they can be associated with a queue.
 *
 * - Agents will be able to select from these associated email addresses when handling email contacts in the queue.
 *
 * - For inbound email contacts, agents can select from email addresses associated with the queue where the contact was accepted.
 *
 * - For outbound email contacts, agents can select from email addresses associated with their default outbound queue configured in their routing profile.
 */
export declare const associateQueueEmailAddresses: API.OperationMethod<AssociateQueueEmailAddressesRequest, AssociateQueueEmailAddressesResponse, AssociateQueueEmailAddressesError, Creds | HttpClient.HttpClient>;
export type AssociateQueueQuickConnectsError = InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a set of quick connects with a queue.
 */
export declare const associateQueueQuickConnects: API.OperationMethod<AssociateQueueQuickConnectsRequest, AssociateQueueQuickConnectsResponse, AssociateQueueQuickConnectsError, Creds | HttpClient.HttpClient>;
export type AssociateRoutingProfileQueuesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a set of queues with a routing profile.
 */
export declare const associateRoutingProfileQueues: API.OperationMethod<AssociateRoutingProfileQueuesRequest, AssociateRoutingProfileQueuesResponse, AssociateRoutingProfileQueuesError, Creds | HttpClient.HttpClient>;
export type AssociateSecurityKeyError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Associates a security key to the instance.
 */
export declare const associateSecurityKey: API.OperationMethod<AssociateSecurityKeyRequest, AssociateSecurityKeyResponse, AssociateSecurityKeyError, Creds | HttpClient.HttpClient>;
export type AssociateSecurityProfilesError = AccessDeniedException | ConditionalOperationFailedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Associate security profiles with an Entity in an Amazon Connect instance.
 */
export declare const associateSecurityProfiles: API.OperationMethod<AssociateSecurityProfilesRequest, AssociateSecurityProfilesResponse, AssociateSecurityProfilesError, Creds | HttpClient.HttpClient>;
export type AssociateTrafficDistributionGroupUserError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates an agent with a traffic distribution group. This API can be called only in the Region where the traffic distribution group
 * is created.
 */
export declare const associateTrafficDistributionGroupUser: API.OperationMethod<AssociateTrafficDistributionGroupUserRequest, AssociateTrafficDistributionGroupUserResponse, AssociateTrafficDistributionGroupUserError, Creds | HttpClient.HttpClient>;
export type AssociateUserProficienciesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a set of proficiencies with a user.
 */
export declare const associateUserProficiencies: API.OperationMethod<AssociateUserProficienciesRequest, AssociateUserProficienciesResponse, AssociateUserProficienciesError, Creds | HttpClient.HttpClient>;
export type AssociateWorkspaceError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a workspace with one or more users or routing profiles, allowing them to access the workspace's
 * configured views and pages.
 */
export declare const associateWorkspace: API.OperationMethod<AssociateWorkspaceRequest, AssociateWorkspaceResponse, AssociateWorkspaceError, Creds | HttpClient.HttpClient>;
export type BatchAssociateAnalyticsDataSetError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a list of analytics datasets for a given Connect Customer instance to a target account. You can
 * associate multiple datasets in a single call.
 */
export declare const batchAssociateAnalyticsDataSet: API.OperationMethod<BatchAssociateAnalyticsDataSetRequest, BatchAssociateAnalyticsDataSetResponse, BatchAssociateAnalyticsDataSetError, Creds | HttpClient.HttpClient>;
export type BatchCreateDataTableValueError = AccessDeniedException | ConflictException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates values for attributes in a data table. The value may be a default or it may be associated with a primary
 * value. The value must pass all customer defined validation as well as the default validation for the value type. The
 * operation must conform to Batch Operation API Standards. Although the standard specifies that successful and failed
 * entities are listed separately in the response, authorization fails if any primary values or attributes are
 * unauthorized. The combination of primary values and the attribute name serve as the identifier for the individual
 * item request.
 */
export declare const batchCreateDataTableValue: API.OperationMethod<BatchCreateDataTableValueRequest, BatchCreateDataTableValueResponse, BatchCreateDataTableValueError, Creds | HttpClient.HttpClient>;
export type BatchDeleteDataTableValueError = AccessDeniedException | ConflictException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes multiple values from a data table. API users may delete values at any time. When deletion is requested
 * from the admin website, a warning is shown alerting the user of the most recent time the attribute and its values
 * were accessed. System managed values are not deletable by customers.
 */
export declare const batchDeleteDataTableValue: API.OperationMethod<BatchDeleteDataTableValueRequest, BatchDeleteDataTableValueResponse, BatchDeleteDataTableValueError, Creds | HttpClient.HttpClient>;
export type BatchDescribeDataTableValueError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves multiple values from a data table without evaluating expressions. Returns the raw stored values along
 * with metadata such as lock versions and modification timestamps. "Describe" is a deprecated term but is allowed to
 * maintain consistency with existing operations.
 */
export declare const batchDescribeDataTableValue: API.OperationMethod<BatchDescribeDataTableValueRequest, BatchDescribeDataTableValueResponse, BatchDescribeDataTableValueError, Creds | HttpClient.HttpClient>;
export type BatchDisassociateAnalyticsDataSetError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes a list of analytics datasets associated with a given Connect Customer instance. You can disassociate
 * multiple datasets in a single call.
 */
export declare const batchDisassociateAnalyticsDataSet: API.OperationMethod<BatchDisassociateAnalyticsDataSetRequest, BatchDisassociateAnalyticsDataSetResponse, BatchDisassociateAnalyticsDataSetError, Creds | HttpClient.HttpClient>;
export type BatchGetAttachedFileMetadataError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Allows you to retrieve metadata about multiple attached files on an associated resource. Each attached file
 * provided in the input list must be associated with the input AssociatedResourceArn.
 */
export declare const batchGetAttachedFileMetadata: API.OperationMethod<BatchGetAttachedFileMetadataRequest, BatchGetAttachedFileMetadataResponse, BatchGetAttachedFileMetadataError, Creds | HttpClient.HttpClient>;
export type BatchGetFlowAssociationError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieve the flow associations for the given resources.
 */
export declare const batchGetFlowAssociation: API.OperationMethod<BatchGetFlowAssociationRequest, BatchGetFlowAssociationResponse, BatchGetFlowAssociationError, Creds | HttpClient.HttpClient>;
export type BatchPutContactError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Only the Connect Customer outbound campaigns service principal is allowed to assume a role in your account
 * and call this API.
 *
 * Allows you to create a batch of contacts in Connect Customer. The outbound campaigns capability ingests dial
 * requests via the PutDialRequestBatch API. It then uses BatchPutContact to create contacts corresponding to those dial
 * requests. If agents are available, the dial requests are dialed out, which results in a voice call. The resulting
 * voice call uses the same contactId that was created by BatchPutContact.
 */
export declare const batchPutContact: API.OperationMethod<BatchPutContactRequest, BatchPutContactResponse, BatchPutContactError, Creds | HttpClient.HttpClient>;
export type BatchUpdateDataTableValueError = AccessDeniedException | ConflictException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates multiple data table values using all properties from BatchCreateDataTableValue. System managed values
 * are not modifiable by customers. The operation requires proper lock versions to prevent concurrent modification
 * conflicts.
 */
export declare const batchUpdateDataTableValue: API.OperationMethod<BatchUpdateDataTableValueRequest, BatchUpdateDataTableValueResponse, BatchUpdateDataTableValueError, Creds | HttpClient.HttpClient>;
export type ClaimPhoneNumberError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Claims an available phone number to your Connect Customer instance or traffic distribution group. You can call
 * this API only in the same Amazon Web Services Region where the Connect Customer instance or traffic distribution group was
 * created.
 *
 * For more information about how to use this operation, see Claim a phone number in your country and Claim
 * phone numbers to traffic distribution groups in the Connect Customer Administrator
 * Guide.
 *
 * You can call the SearchAvailablePhoneNumbers API for
 * available phone numbers that you can claim. Call the DescribePhoneNumber API to verify the status
 * of a previous ClaimPhoneNumber operation.
 *
 * If you plan to claim and release numbers frequently,
 * contact us for a service quota exception. Otherwise, it is possible you will be blocked from
 * claiming and releasing any more numbers until up to 180 days past the oldest number
 * released has expired.
 *
 * By default you can claim and release up to 200% of your maximum number of active
 * phone numbers. If you claim and release phone numbers using
 * the UI or API during a rolling 180 day cycle that exceeds 200% of your phone number
 * service level quota, you will be blocked from claiming any more numbers until 180
 * days past the oldest number released has expired.
 *
 * For example, if you already have 99 claimed numbers and a service level quota of 99 phone numbers, and in any 180
 * day period you release 99, claim 99, and then release 99, you will have exceeded the
 * 200% limit. At that point you are blocked from claiming any more numbers until you
 * open an Amazon Web Services support ticket.
 */
export declare const claimPhoneNumber: API.OperationMethod<ClaimPhoneNumberRequest, ClaimPhoneNumberResponse, ClaimPhoneNumberError, Creds | HttpClient.HttpClient>;
export type CompleteAttachedFileUploadError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Allows you to confirm that the attached file has been uploaded using the pre-signed URL provided in the
 * StartAttachedFileUpload API.
 */
export declare const completeAttachedFileUpload: API.OperationMethod<CompleteAttachedFileUploadRequest, CompleteAttachedFileUploadResponse, CompleteAttachedFileUploadError, Creds | HttpClient.HttpClient>;
export type CreateAgentStatusError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an agent status for the specified Connect Customer instance.
 */
export declare const createAgentStatus: API.OperationMethod<CreateAgentStatusRequest, CreateAgentStatusResponse, CreateAgentStatusError, Creds | HttpClient.HttpClient>;
export type CreateAttachedFileError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates an attached file for a completed voice contact by copying a recording from a source S3 URI into
 * Connect Customer managed storage. Use this API to attach voice recordings to contacts for downstream
 * processing such as conversational analytics.
 *
 * The `AssociatedResourceArn` must be the ARN of a completed voice contact, `FileUseCaseType`
 * must be set to `VOICE_RECORDING`, and `FileSourceUri` must be a valid S3 URI.
 *
 * For example, you can call `CreateContact`, then `CreateAttachedFile`, then
 * `StartContactConversationalAnalyticsJob` to create a contact, attach a recording, and
 * run post-call analytics.
 */
export declare const createAttachedFile: API.OperationMethod<CreateAttachedFileRequest, CreateAttachedFileResponse, CreateAttachedFileError, Creds | HttpClient.HttpClient>;
export type CreateAuthCodeError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an authorization code for the specified Connect Customer instance. The authorization code can be used
 * to establish a session with scoped permissions defined by the specified scope parameters.
 */
export declare const createAuthCode: API.OperationMethod<CreateAuthCodeRequest, CreateAuthCodeResponse, CreateAuthCodeError, Creds | HttpClient.HttpClient>;
export type CreateContactError = AccessDeniedException | ConflictException | IdempotencyException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Only the VOICE, EMAIL, and TASK channels are supported.
 *
 * - For VOICE: The supported initiation method is `TRANSFER`. The contacts created with this
 * initiation method have a subtype `connect:ExternalAudio`.
 *
 * - For EMAIL: The supported initiation methods are `OUTBOUND`, `AGENT_REPLY`, and
 * `FLOW`.
 *
 * - For TASK: The supported initiation method is `API`. Contacts created with this API have a sub-type
 * of `connect:ExternalTask`.
 *
 * Creates a new VOICE, EMAIL, or TASK contact.
 *
 * After a contact is created, you can move it to the desired state by using the `InitiateAs` parameter.
 * While you can use API to create task contacts that are in the `COMPLETED` state, you must contact Amazon Web Services Support before using it for bulk import use cases. Bulk import causes your requests to be throttled or
 * fail if your CreateContact limits aren't high enough.
 */
export declare const createContact: API.OperationMethod<CreateContactRequest, CreateContactResponse, CreateContactError, Creds | HttpClient.HttpClient>;
export type CreateContactFlowError = DuplicateResourceException | InternalServiceException | InvalidContactFlowException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a flow for the specified Connect Customer instance.
 *
 * You can also create and update flows using the Connect Customer
 * Flow language.
 */
export declare const createContactFlow: API.OperationMethod<CreateContactFlowRequest, CreateContactFlowResponse, CreateContactFlowError, Creds | HttpClient.HttpClient>;
export type CreateContactFlowModuleError = AccessDeniedException | DuplicateResourceException | IdempotencyException | InternalServiceException | InvalidContactFlowModuleException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a flow module for the specified Connect Customer instance.
 */
export declare const createContactFlowModule: API.OperationMethod<CreateContactFlowModuleRequest, CreateContactFlowModuleResponse, CreateContactFlowModuleError, Creds | HttpClient.HttpClient>;
export type CreateContactFlowModuleAliasError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a named alias that points to a specific version of a contact flow module.
 */
export declare const createContactFlowModuleAlias: API.OperationMethod<CreateContactFlowModuleAliasRequest, CreateContactFlowModuleAliasResponse, CreateContactFlowModuleAliasError, Creds | HttpClient.HttpClient>;
export type CreateContactFlowModuleVersionError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an immutable snapshot of a contact flow module, preserving its content and settings at a specific point
 * in time for version control and rollback capabilities.
 */
export declare const createContactFlowModuleVersion: API.OperationMethod<CreateContactFlowModuleVersionRequest, CreateContactFlowModuleVersionResponse, CreateContactFlowModuleVersionError, Creds | HttpClient.HttpClient>;
export type CreateContactFlowVersionError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Publishes a new version of the flow provided. Versions are immutable and monotonically increasing. If the
 * `FlowContentSha256` provided is different from the `FlowContentSha256` of the
 * `$LATEST` published flow content, then an error is returned. This API only supports creating versions for
 * flows of type `Campaign`.
 */
export declare const createContactFlowVersion: API.OperationMethod<CreateContactFlowVersionRequest, CreateContactFlowVersionResponse, CreateContactFlowVersionError, Creds | HttpClient.HttpClient>;
export type CreateDataTableError = AccessDeniedException | ConflictException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a new data table with the specified properties. Supports the creation of all table properties except for
 * attributes and values. A table with no attributes and values is a valid state for a table. The number of tables per
 * instance is limited to 100 per instance. Customers can request an increase by using Amazon Web Services Service Quotas.
 */
export declare const createDataTable: API.OperationMethod<CreateDataTableRequest, CreateDataTableResponse, CreateDataTableError, Creds | HttpClient.HttpClient>;
export type CreateDataTableAttributeError = AccessDeniedException | ConflictException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Adds an attribute to an existing data table. Creating a new primary attribute uses the empty value for the
 * specified value type for all existing records. This should not affect uniqueness of published data tables since the
 * existing primary values will already be unique. Creating attributes does not create any values. System managed tables
 * may not allow customers to create new attributes.
 */
export declare const createDataTableAttribute: API.OperationMethod<CreateDataTableAttributeRequest, CreateDataTableAttributeResponse, CreateDataTableAttributeError, Creds | HttpClient.HttpClient>;
export type CreateEmailAddressError = AccessDeniedException | DuplicateResourceException | IdempotencyException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Create new email address in the specified Connect Customer instance. For more information about email
 * addresses, see Create email
 * addresses in the Connect Customer Administrator Guide.
 */
export declare const createEmailAddress: API.OperationMethod<CreateEmailAddressRequest, CreateEmailAddressResponse, CreateEmailAddressError, Creds | HttpClient.HttpClient>;
export type CreateEvaluationFormError = InternalServiceException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates an evaluation form in the specified Connect Customer instance. The form can be used to define
 * questions related to agent performance, and create sections to organize such questions. Question and section
 * identifiers cannot be duplicated within the same evaluation form.
 */
export declare const createEvaluationForm: API.OperationMethod<CreateEvaluationFormRequest, CreateEvaluationFormResponse, CreateEvaluationFormError, Creds | HttpClient.HttpClient>;
export type CreateExtractionDefinitionError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates an extraction definition in the specified Connect Customer instance. An extraction
 * definition specifies how structured data is extracted from customer interactions using generative
 * AI, including the prompt hint that guides extraction and the behavior when a value cannot be
 * found.
 */
export declare const createExtractionDefinition: API.OperationMethod<CreateExtractionDefinitionRequest, CreateExtractionDefinitionResponse, CreateExtractionDefinitionError, Creds | HttpClient.HttpClient>;
export type CreateHoursOfOperationError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates hours of operation.
 */
export declare const createHoursOfOperation: API.OperationMethod<CreateHoursOfOperationRequest, CreateHoursOfOperationResponse, CreateHoursOfOperationError, Creds | HttpClient.HttpClient>;
export type CreateHoursOfOperationOverrideError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an hours of operation override in an Connect Customer hours of operation resource.
 */
export declare const createHoursOfOperationOverride: API.OperationMethod<CreateHoursOfOperationOverrideRequest, CreateHoursOfOperationOverrideResponse, CreateHoursOfOperationOverrideError, Creds | HttpClient.HttpClient>;
export type CreateInstanceError = InternalServiceException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Initiates an Connect Customer instance with all the supported channels enabled. It does not attach any
 * storage, such as Amazon Simple Storage Service (Amazon S3) or Amazon Kinesis. It also does not allow for any
 * configurations on features, such as Contact Lens for Connect Customer.
 *
 * For more information, see Create an Connect Customer instance in the
 * *Connect Customer Administrator Guide*.
 *
 * Connect Customer enforces a limit on the total number of instances that you can create or delete in 30 days.
 * If you exceed this limit, you will get an error message indicating there has been an excessive number of attempts at creating or deleting instances.
 * You must wait 30 days before you can restart creating and deleting instances in your account.
 */
export declare const createInstance: API.OperationMethod<CreateInstanceRequest, CreateInstanceResponse, CreateInstanceError, Creds | HttpClient.HttpClient>;
export type CreateIntegrationAssociationError = DuplicateResourceException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an Amazon Web Services resource association with an Connect Customer instance.
 */
export declare const createIntegrationAssociation: API.OperationMethod<CreateIntegrationAssociationRequest, CreateIntegrationAssociationResponse, CreateIntegrationAssociationError, Creds | HttpClient.HttpClient>;
export type CreateMetricError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new metric definition for the specified Connect Customer instance. You can create custom metrics
 * that use formulas referencing existing Amazon Web Services-managed metrics, optionally with filters applied.
 */
export declare const createMetric: API.OperationMethod<CreateMetricRequest, CreateMetricResponse, CreateMetricError, Creds | HttpClient.HttpClient>;
export type CreateNotificationError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new notification to be delivered to specified recipients. Notifications can include localized content with links, and an optional expiration time. Recipients can be specified as individual user ARNs or instance ARNs to target all users in an instance.
 */
export declare const createNotification: API.OperationMethod<CreateNotificationRequest, CreateNotificationResponse, CreateNotificationError, Creds | HttpClient.HttpClient>;
export type CreateParticipantError = ConflictException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Adds a new participant into an on-going chat contact or webRTC call. For more information, see Customize chat flow experiences by
 * integrating custom participants or Enable multi-user web, in-app, and video
 * calling.
 */
export declare const createParticipant: API.OperationMethod<CreateParticipantRequest, CreateParticipantResponse, CreateParticipantError, Creds | HttpClient.HttpClient>;
export type CreatePersistentContactAssociationError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Enables rehydration of chats for the lifespan of a contact. For more information about chat rehydration, see
 * Enable persistent chat in
 * the *Connect Customer Administrator Guide*.
 */
export declare const createPersistentContactAssociation: API.OperationMethod<CreatePersistentContactAssociationRequest, CreatePersistentContactAssociationResponse, CreatePersistentContactAssociationError, Creds | HttpClient.HttpClient>;
export type CreatePredefinedAttributeError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new predefined attribute for the specified Connect Customer instance. A *predefined attribute*
 * is made up of a name and a value.
 *
 * For the predefined attributes per instance quota, see Connect Customer
 * quotas.
 *
 * **Use cases**
 *
 * Following are common uses cases for this API:
 *
 * - Create an attribute for routing proficiency (for example, agent certification) that has predefined values (for
 * example, a list of possible certifications). For more information, see Create predefined attributes for routing contacts to
 * agents.
 *
 * - Create an attribute for business unit name that has a list of predefined business unit names used in your
 * organization. This is a use case where information for a contact varies between transfers or conferences. For more
 * information, see Use contact segment attributes.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const createPredefinedAttribute: API.OperationMethod<CreatePredefinedAttributeRequest, CreatePredefinedAttributeResponse, CreatePredefinedAttributeError, Creds | HttpClient.HttpClient>;
export type CreatePromptError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a prompt. For more information about prompts, such as supported file types and maximum length, see
 * Create prompts in the
 * *Connect Customer Administrator Guide*.
 */
export declare const createPrompt: API.OperationMethod<CreatePromptRequest, CreatePromptResponse, CreatePromptError, Creds | HttpClient.HttpClient>;
export type CreatePushNotificationRegistrationError = AccessDeniedException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates registration for a device token and a chat contact to receive real-time push notifications. For more
 * information about push notifications, see Set up push notifications in Connect Customer for mobile chat in the *Connect Customer Administrator Guide*.
 */
export declare const createPushNotificationRegistration: API.OperationMethod<CreatePushNotificationRegistrationRequest, CreatePushNotificationRegistrationResponse, CreatePushNotificationRegistrationError, Creds | HttpClient.HttpClient>;
export type CreateQueueError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new queue for the specified Connect Customer instance.
 *
 * - If the phone number is claimed to a traffic distribution group that was created in the
 * same Region as the Connect Customer instance where you are calling this API, then you can use a
 * full phone number ARN or a UUID for `OutboundCallerIdNumberId`. However, if the phone number is claimed
 * to a traffic distribution group that is in one Region, and you are calling this API from an instance in another Amazon Web Services Region that is associated with the traffic distribution group, you must provide a full phone number ARN. If a
 * UUID is provided in this scenario, you will receive a
 * `ResourceNotFoundException`.
 *
 * - Only use the phone number ARN format that doesn't contain `instance` in the path, for example,
 * `arn:aws:connect:us-east-1:1234567890:phone-number/uuid`. This is the same ARN format that is returned
 * when you call the ListPhoneNumbersV2 API.
 *
 * - If you plan to use IAM policies to allow/deny access to this API for phone number resources
 * claimed to a traffic distribution group, see Allow or Deny queue API actions for phone numbers in a replica Region.
 */
export declare const createQueue: API.OperationMethod<CreateQueueRequest, CreateQueueResponse, CreateQueueError, Creds | HttpClient.HttpClient>;
export type CreateQuickConnectError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a quick connect for the specified Connect Customer instance.
 */
export declare const createQuickConnect: API.OperationMethod<CreateQuickConnectRequest, CreateQuickConnectResponse, CreateQuickConnectError, Creds | HttpClient.HttpClient>;
export type CreateRoutingProfileError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new routing profile.
 */
export declare const createRoutingProfile: API.OperationMethod<CreateRoutingProfileRequest, CreateRoutingProfileResponse, CreateRoutingProfileError, Creds | HttpClient.HttpClient>;
export type CreateRuleError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a rule for the specified Connect Customer instance.
 *
 * Use the Rules Function
 * language to code conditions for the rule.
 */
export declare const createRule: API.OperationMethod<CreateRuleRequest, CreateRuleResponse, CreateRuleError, Creds | HttpClient.HttpClient>;
export type CreateSecurityProfileError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a security profile.
 *
 * For information about security profiles, see Security Profiles in the *Connect Customer Administrator Guide*. For a mapping of the API name and user interface name of the security
 * profile permissions, see List
 * of security profile permissions.
 */
export declare const createSecurityProfile: API.OperationMethod<CreateSecurityProfileRequest, CreateSecurityProfileResponse, CreateSecurityProfileError, Creds | HttpClient.HttpClient>;
export type CreateTaskTemplateError = InternalServiceException | InvalidParameterException | PropertyValidationException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a new task template in the specified Connect Customer instance.
 */
export declare const createTaskTemplate: API.OperationMethod<CreateTaskTemplateRequest, CreateTaskTemplateResponse, CreateTaskTemplateError, Creds | HttpClient.HttpClient>;
export type CreateTestCaseError = AccessDeniedException | DuplicateResourceException | IdempotencyException | InternalServiceException | InvalidParameterException | InvalidRequestException | InvalidTestCaseException | LimitExceededException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a test case with its content and metadata for the specified Amazon Connect instance.
 */
export declare const createTestCase: API.OperationMethod<CreateTestCaseRequest, CreateTestCaseResponse, CreateTestCaseError, Creds | HttpClient.HttpClient>;
export type CreateTrafficDistributionGroupError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ResourceNotReadyException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a traffic distribution group given an Connect Customer instance that has been replicated.
 *
 * The `SignInConfig` distribution is available only on a
 * default `TrafficDistributionGroup` (see the `IsDefault` parameter in the
 * TrafficDistributionGroup
 * data type). If you call
 * `UpdateTrafficDistribution` with a modified `SignInConfig` and a non-default `TrafficDistributionGroup`,
 * an `InvalidRequestException` is returned.
 *
 * For more information about creating traffic distribution groups, see Set up traffic distribution groups in the
 * *Connect Customer Administrator Guide*.
 */
export declare const createTrafficDistributionGroup: API.OperationMethod<CreateTrafficDistributionGroupRequest, CreateTrafficDistributionGroupResponse, CreateTrafficDistributionGroupError, Creds | HttpClient.HttpClient>;
export type CreateUseCaseError = DuplicateResourceException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a use case for an integration association.
 */
export declare const createUseCase: API.OperationMethod<CreateUseCaseRequest, CreateUseCaseResponse, CreateUseCaseError, Creds | HttpClient.HttpClient>;
export type CreateUserError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a user account for the specified Connect Customer instance.
 *
 * Certain UserIdentityInfo parameters are required in some situations. For example, `Email`,
 * `FirstName` and `LastName` are required if you are using Connect Customer or SAML for
 * identity management.
 *
 * Fields in `PhoneConfig` cannot be set simultaneously with their corresponding channel-specific configuration parameters. Specifically:
 *
 * - `PhoneConfig.AutoAccept` conflicts with `AutoAcceptConfigs`
 *
 * - `PhoneConfig.AfterContactWorkTimeLimit` conflicts with `AfterContactWorkConfigs`
 *
 * - `PhoneConfig.PhoneType` and `PhoneConfig.PhoneNumber` conflict with `PhoneNumberConfigs`
 *
 * - `PhoneConfig.PersistentConnection` conflicts with `PersistentConnectionConfigs`
 *
 * We recommend using channel-specific parameters such as `AutoAcceptConfigs`, `AfterContactWorkConfigs`, `PhoneNumberConfigs`, `PersistentConnectionConfigs`, and `VoiceEnhancementConfigs` for per-channel configuration.
 *
 * For information about how to create users using the Connect Customer admin website, see Add Users in the Connect Customer
 * Administrator Guide.
 */
export declare const createUser: API.OperationMethod<CreateUserRequest, CreateUserResponse, CreateUserError, Creds | HttpClient.HttpClient>;
export type CreateUserHierarchyGroupError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new user hierarchy group.
 */
export declare const createUserHierarchyGroup: API.OperationMethod<CreateUserHierarchyGroupRequest, CreateUserHierarchyGroupResponse, CreateUserHierarchyGroupError, Creds | HttpClient.HttpClient>;
export type CreateViewError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new view with the possible status of `SAVED` or `PUBLISHED`.
 *
 * The views will have a unique name for each connect instance.
 *
 * It performs basic content validation if the status is `SAVED` or full content validation if the
 * status is set to `PUBLISHED`. An error is returned if validation fails. It associates either the
 * `$SAVED` qualifier or both of the `$SAVED` and `$LATEST` qualifiers with the
 * provided view content based on the status. The view is idempotent if ClientToken is provided.
 */
export declare const createView: API.OperationMethod<CreateViewRequest, CreateViewResponse, CreateViewError, Creds | HttpClient.HttpClient>;
export type CreateViewVersionError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Publishes a new version of the view identifier.
 *
 * Versions are immutable and monotonically increasing.
 *
 * It returns the highest version if there is no change in content compared to that version. An error is displayed
 * if the supplied ViewContentSha256 is different from the ViewContentSha256 of the `$LATEST` alias.
 */
export declare const createViewVersion: API.OperationMethod<CreateViewVersionRequest, CreateViewVersionResponse, CreateViewVersionError, Creds | HttpClient.HttpClient>;
export type CreateVocabularyError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a custom vocabulary associated with your Connect Customer instance. You can set a custom vocabulary to
 * be your default vocabulary for a given language. Contact Lens for Connect Customer uses the default vocabulary in post-call and real-time
 * contact analysis sessions for that language.
 */
export declare const createVocabulary: API.OperationMethod<CreateVocabularyRequest, CreateVocabularyResponse, CreateVocabularyError, Creds | HttpClient.HttpClient>;
export type CreateWorkspaceError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a workspace that defines the user experience by mapping views to pages. Workspaces can be assigned to
 * users or routing profiles.
 */
export declare const createWorkspace: API.OperationMethod<CreateWorkspaceRequest, CreateWorkspaceResponse, CreateWorkspaceError, Creds | HttpClient.HttpClient>;
export type CreateWorkspacePageError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Associates a view with a page in a workspace, defining what users see when they navigate to that page.
 */
export declare const createWorkspacePage: API.OperationMethod<CreateWorkspacePageRequest, CreateWorkspacePageResponse, CreateWorkspacePageError, Creds | HttpClient.HttpClient>;
export type DeactivateEvaluationFormError = InternalServiceException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deactivates an evaluation form in the specified Connect Customer instance. After a form is deactivated, it is no longer
 * available for users to start new evaluations based on the form.
 */
export declare const deactivateEvaluationForm: API.OperationMethod<DeactivateEvaluationFormRequest, DeactivateEvaluationFormResponse, DeactivateEvaluationFormError, Creds | HttpClient.HttpClient>;
export type DeleteAttachedFileError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an attached file along with the underlying S3 Object.
 *
 * The attached file is **permanently deleted** if S3 bucket versioning is not
 * enabled.
 */
export declare const deleteAttachedFile: API.OperationMethod<DeleteAttachedFileRequest, DeleteAttachedFileResponse, DeleteAttachedFileError, Creds | HttpClient.HttpClient>;
export type DeleteContactDataError = ContactNotTerminatedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified fields containing personally identifiable information (PII) from a
 * contact in the specified Connect Customer instance. We redact PII (such as
 * customer endpoints, additional email recipients, and the email subject) from the contact and its
 * associated contact trace record (CTR). The contact must be in a terminated state.
 *
 * **This deletion is permanent and cannot be undone.** Performing this
 * operation permanently deletes the specified PII. There is
 * no retention period; you cannot recover the data after deletion. We remove only the fields
 * that Connect Customer identifies and stores as PII. Any PII that you place in fields
 * outside the scope of this operation remains your responsibility to remove.
 */
export declare const deleteContactData: API.OperationMethod<DeleteContactDataRequest, DeleteContactDataResponse, DeleteContactDataError, Creds | HttpClient.HttpClient>;
export type DeleteContactEvaluationError = InternalServiceException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a contact evaluation in the specified Connect Customer instance.
 */
export declare const deleteContactEvaluation: API.OperationMethod<DeleteContactEvaluationRequest, DeleteContactEvaluationResponse, DeleteContactEvaluationError, Creds | HttpClient.HttpClient>;
export type DeleteContactFlowError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a flow for the specified Connect Customer instance.
 */
export declare const deleteContactFlow: API.OperationMethod<DeleteContactFlowRequest, DeleteContactFlowResponse, DeleteContactFlowError, Creds | HttpClient.HttpClient>;
export type DeleteContactFlowModuleError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified flow module.
 */
export declare const deleteContactFlowModule: API.OperationMethod<DeleteContactFlowModuleRequest, DeleteContactFlowModuleResponse, DeleteContactFlowModuleError, Creds | HttpClient.HttpClient>;
export type DeleteContactFlowModuleAliasError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes an alias reference, breaking the named connection to the underlying module version without affecting the
 * version itself.
 */
export declare const deleteContactFlowModuleAlias: API.OperationMethod<DeleteContactFlowModuleAliasRequest, DeleteContactFlowModuleAliasResponse, DeleteContactFlowModuleAliasError, Creds | HttpClient.HttpClient>;
export type DeleteContactFlowModuleVersionError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes a specific version of a contact flow module.
 */
export declare const deleteContactFlowModuleVersion: API.OperationMethod<DeleteContactFlowModuleVersionRequest, DeleteContactFlowModuleVersionResponse, DeleteContactFlowModuleVersionError, Creds | HttpClient.HttpClient>;
export type DeleteContactFlowVersionError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the particular version specified in flow version identifier.
 */
export declare const deleteContactFlowVersion: API.OperationMethod<DeleteContactFlowVersionRequest, DeleteContactFlowVersionResponse, DeleteContactFlowVersionError, Creds | HttpClient.HttpClient>;
export type DeleteDataTableError = AccessDeniedException | ConflictException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a data table and all associated attributes, versions, audits, and values. Does not update any references
 * to the data table, even from other data tables. This includes dynamic values and conditional validations. System
 * managed data tables are not deletable by customers. API users may delete the table at any time. When deletion is
 * requested from the admin website, a warning is shown alerting the user of the most recent time the table and its
 * values were accessed.
 */
export declare const deleteDataTable: API.OperationMethod<DeleteDataTableRequest, DeleteDataTableResponse, DeleteDataTableError, Creds | HttpClient.HttpClient>;
export type DeleteDataTableAttributeError = AccessDeniedException | ConflictException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an attribute and all its values from a data table.
 */
export declare const deleteDataTableAttribute: API.OperationMethod<DeleteDataTableAttributeRequest, DeleteDataTableAttributeResponse, DeleteDataTableAttributeError, Creds | HttpClient.HttpClient>;
export type DeleteEmailAddressError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes email address from the specified Connect Customer instance.
 */
export declare const deleteEmailAddress: API.OperationMethod<DeleteEmailAddressRequest, DeleteEmailAddressResponse, DeleteEmailAddressError, Creds | HttpClient.HttpClient>;
export type DeleteEvaluationFormError = InternalServiceException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an evaluation form in the specified Connect Customer instance.
 *
 * - If the version property is provided, only the specified version of the evaluation form is deleted.
 *
 * - If no version is provided, then the full form (all versions) is deleted.
 */
export declare const deleteEvaluationForm: API.OperationMethod<DeleteEvaluationFormRequest, DeleteEvaluationFormResponse, DeleteEvaluationFormError, Creds | HttpClient.HttpClient>;
export type DeleteExtractionDefinitionError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an extraction definition from the specified Connect Customer instance.
 */
export declare const deleteExtractionDefinition: API.OperationMethod<DeleteExtractionDefinitionRequest, DeleteExtractionDefinitionResponse, DeleteExtractionDefinitionError, Creds | HttpClient.HttpClient>;
export type DeleteHoursOfOperationError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an hours of operation.
 */
export declare const deleteHoursOfOperation: API.OperationMethod<DeleteHoursOfOperationRequest, DeleteHoursOfOperationResponse, DeleteHoursOfOperationError, Creds | HttpClient.HttpClient>;
export type DeleteHoursOfOperationOverrideError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an hours of operation override in an Connect Customer hours of operation resource.
 */
export declare const deleteHoursOfOperationOverride: API.OperationMethod<DeleteHoursOfOperationOverrideRequest, DeleteHoursOfOperationOverrideResponse, DeleteHoursOfOperationOverrideError, Creds | HttpClient.HttpClient>;
export type DeleteInstanceError = InternalServiceException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Deletes the Connect Customer instance. For more information, see Delete your Connect Customer instance in the
 * *Connect Customer Administrator Guide*.
 *
 * Connect Customer enforces a limit on the total number of instances that you can create or delete in 30 days.
 * If you exceed this limit, you will get an error message indicating there has been an excessive number of attempts at creating or deleting instances.
 * You must wait 30 days before you can restart creating and deleting instances in your account.
 */
export declare const deleteInstance: API.OperationMethod<DeleteInstanceRequest, DeleteInstanceResponse, DeleteInstanceError, Creds | HttpClient.HttpClient>;
export type DeleteIntegrationAssociationError = InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an Amazon Web Services resource association from an Connect Customer instance. The association must not
 * have any use cases associated with it.
 */
export declare const deleteIntegrationAssociation: API.OperationMethod<DeleteIntegrationAssociationRequest, DeleteIntegrationAssociationResponse, DeleteIntegrationAssociationError, Creds | HttpClient.HttpClient>;
export type DeleteMetricError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an existing metric from the specified Connect Customer instance. This operation fails with `ResourceConflictException` if the metric is currently in use in a dashboard.
 */
export declare const deleteMetric: API.OperationMethod<DeleteMetricRequest, DeleteMetricResponse, DeleteMetricError, Creds | HttpClient.HttpClient>;
export type DeleteNotificationError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a notification. Once deleted, the notification is no longer visible to all users and cannot be managed through the Admin Website or APIs.
 */
export declare const deleteNotification: API.OperationMethod<DeleteNotificationRequest, DeleteNotificationResponse, DeleteNotificationError, Creds | HttpClient.HttpClient>;
export type DeletePredefinedAttributeError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a predefined attribute from the specified Connect Customer instance.
 */
export declare const deletePredefinedAttribute: API.OperationMethod<DeletePredefinedAttributeRequest, DeletePredefinedAttributeResponse, DeletePredefinedAttributeError, Creds | HttpClient.HttpClient>;
export type DeletePromptError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a prompt.
 */
export declare const deletePrompt: API.OperationMethod<DeletePromptRequest, DeletePromptResponse, DeletePromptError, Creds | HttpClient.HttpClient>;
export type DeletePushNotificationRegistrationError = AccessDeniedException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes registration for a device token and a chat contact.
 */
export declare const deletePushNotificationRegistration: API.OperationMethod<DeletePushNotificationRegistrationRequest, DeletePushNotificationRegistrationResponse, DeletePushNotificationRegistrationError, Creds | HttpClient.HttpClient>;
export type DeleteQueueError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a queue.
 */
export declare const deleteQueue: API.OperationMethod<DeleteQueueRequest, DeleteQueueResponse, DeleteQueueError, Creds | HttpClient.HttpClient>;
export type DeleteQuickConnectError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a quick connect.
 *
 * After calling DeleteUser, it's important to call `DeleteQuickConnect` to delete any records related to the
 * deleted users. This will help you:
 *
 * - Avoid dangling resources that impact your service quotas.
 *
 * - Remove deleted users so they don't appear to agents as transfer options.
 *
 * - Avoid the disruption of other Connect Customer processes, such as instance replication and syncing if
 * you're using Connect Customer Global Resiliency.
 */
export declare const deleteQuickConnect: API.OperationMethod<DeleteQuickConnectRequest, DeleteQuickConnectResponse, DeleteQuickConnectError, Creds | HttpClient.HttpClient>;
export type DeleteRoutingProfileError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a routing profile.
 */
export declare const deleteRoutingProfile: API.OperationMethod<DeleteRoutingProfileRequest, DeleteRoutingProfileResponse, DeleteRoutingProfileError, Creds | HttpClient.HttpClient>;
export type DeleteRuleError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a rule for the specified Connect Customer instance.
 */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest, DeleteRuleResponse, DeleteRuleError, Creds | HttpClient.HttpClient>;
export type DeleteSecurityProfileError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a security profile.
 */
export declare const deleteSecurityProfile: API.OperationMethod<DeleteSecurityProfileRequest, DeleteSecurityProfileResponse, DeleteSecurityProfileError, Creds | HttpClient.HttpClient>;
export type DeleteSessionError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a session for the specified Connect Customer instance.
 */
export declare const deleteSession: API.OperationMethod<DeleteSessionRequest, DeleteSessionResponse, DeleteSessionError, Creds | HttpClient.HttpClient>;
export type DeleteTaskTemplateError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the task template.
 */
export declare const deleteTaskTemplate: API.OperationMethod<DeleteTaskTemplateRequest, DeleteTaskTemplateResponse, DeleteTaskTemplateError, Creds | HttpClient.HttpClient>;
export type DeleteTestCaseError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the test case that has already been created for the specified Amazon Connect instance.
 */
export declare const deleteTestCase: API.OperationMethod<DeleteTestCaseRequest, DeleteTestCaseResponse, DeleteTestCaseError, Creds | HttpClient.HttpClient>;
export type DeleteTrafficDistributionGroupError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceInUseException | ThrottlingException | CommonErrors;
/**
 * Deletes a traffic distribution group. This API can be called only in the Region where the traffic distribution group is created.
 *
 * For more information about deleting traffic distribution groups, see Delete traffic distribution groups in the
 * *Connect Customer Administrator Guide*.
 */
export declare const deleteTrafficDistributionGroup: API.OperationMethod<DeleteTrafficDistributionGroupRequest, DeleteTrafficDistributionGroupResponse, DeleteTrafficDistributionGroupError, Creds | HttpClient.HttpClient>;
export type DeleteUseCaseError = InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a use case from an integration association.
 */
export declare const deleteUseCase: API.OperationMethod<DeleteUseCaseRequest, DeleteUseCaseResponse, DeleteUseCaseError, Creds | HttpClient.HttpClient>;
export type DeleteUserError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a user account from the specified Connect Customer instance.
 *
 * For information about what happens to a user's data when their account is deleted, see Delete Users from Your Connect Customer
 * Instance in the *Connect Customer Administrator Guide*.
 *
 * After calling DeleteUser, call DeleteQuickConnect to delete any records
 * related to the deleted users. This will help you:
 *
 * - Avoid dangling resources that impact your service quotas.
 *
 * - Remove deleted users so they don't appear to agents as transfer options.
 *
 * - Avoid the disruption of other Connect Customer processes, such as instance replication and syncing if
 * you're using Connect Customer Global Resiliency.
 */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest, DeleteUserResponse, DeleteUserError, Creds | HttpClient.HttpClient>;
export type DeleteUserHierarchyGroupError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an existing user hierarchy group. It must not be associated with any agents or have any active child
 * groups.
 */
export declare const deleteUserHierarchyGroup: API.OperationMethod<DeleteUserHierarchyGroupRequest, DeleteUserHierarchyGroupResponse, DeleteUserHierarchyGroupError, Creds | HttpClient.HttpClient>;
export type DeleteViewError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the view entirely. It deletes the view and all associated qualifiers (versions and aliases).
 */
export declare const deleteView: API.OperationMethod<DeleteViewRequest, DeleteViewResponse, DeleteViewError, Creds | HttpClient.HttpClient>;
export type DeleteViewVersionError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the particular version specified in `ViewVersion` identifier.
 */
export declare const deleteViewVersion: API.OperationMethod<DeleteViewVersionRequest, DeleteViewVersionResponse, DeleteViewVersionError, Creds | HttpClient.HttpClient>;
export type DeleteVocabularyError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the vocabulary that has the given identifier.
 */
export declare const deleteVocabulary: API.OperationMethod<DeleteVocabularyRequest, DeleteVocabularyResponse, DeleteVocabularyError, Creds | HttpClient.HttpClient>;
export type DeleteWorkspaceError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a workspace and removes all associated view and resource assignments.
 */
export declare const deleteWorkspace: API.OperationMethod<DeleteWorkspaceRequest, DeleteWorkspaceResponse, DeleteWorkspaceError, Creds | HttpClient.HttpClient>;
export type DeleteWorkspaceMediaError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a media asset (such as a logo) from a workspace.
 */
export declare const deleteWorkspaceMedia: API.OperationMethod<DeleteWorkspaceMediaRequest, DeleteWorkspaceMediaResponse, DeleteWorkspaceMediaError, Creds | HttpClient.HttpClient>;
export type DeleteWorkspacePageError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the association between a view and a page in a workspace. The page will display the default view after
 * deletion.
 */
export declare const deleteWorkspacePage: API.OperationMethod<DeleteWorkspacePageRequest, DeleteWorkspacePageResponse, DeleteWorkspacePageError, Creds | HttpClient.HttpClient>;
export type DescribeAgentStatusError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes an agent status.
 */
export declare const describeAgentStatus: API.OperationMethod<DescribeAgentStatusRequest, DescribeAgentStatusResponse, DescribeAgentStatusError, Creds | HttpClient.HttpClient>;
export type DescribeAttachedFilesConfigurationError = AccessDeniedException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the attached files configuration for the specified Connect Customer instance and attachment scope.
 *
 * If a custom configuration exists for the specified attachment scope, the custom configuration is returned. If no custom configuration exists, the default configuration values for that attachment scope are returned.
 */
export declare const describeAttachedFilesConfiguration: API.OperationMethod<DescribeAttachedFilesConfigurationRequest, DescribeAttachedFilesConfigurationResponse, DescribeAttachedFilesConfigurationError, Creds | HttpClient.HttpClient>;
export type DescribeAuthenticationProfileError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change. To
 * request access to this API, contact Amazon Web Services Support.
 *
 * Describes the target authentication profile.
 */
export declare const describeAuthenticationProfile: API.OperationMethod<DescribeAuthenticationProfileRequest, DescribeAuthenticationProfileResponse, DescribeAuthenticationProfileError, Creds | HttpClient.HttpClient>;
export type DescribeContactError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Describes the specified contact.
 *
 * **Use cases**
 *
 * Following are common uses cases for this API:
 *
 * - Retrieve contact information such as the caller's phone number and the specific number the caller dialed to
 * integrate into custom monitoring or custom agent experience solutions.
 *
 * - Detect when a customer chat session disconnects due to a network issue on the agent's end. Use the
 * DisconnectReason field in the ContactTraceRecord to detect
 * this event and then re-queue the chat for followup.
 *
 * - Identify after contact work (ACW) duration and call recordings information when a COMPLETED event is received
 * by using the contact event
 * stream.
 *
 * **Important things to know**
 *
 * - `SystemEndpoint` is not populated for contacts with initiation method of MONITOR, QUEUE_TRANSFER,
 * or CALLBACK
 *
 * - Contact information remains available in Connect Customer for 24 months from the
 * `InitiationTimestamp`, and then it is deleted. Only contact information that is available in Connect Customer is returned by this API.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const describeContact: API.OperationMethod<DescribeContactRequest, DescribeContactResponse, DescribeContactError, Creds | HttpClient.HttpClient>;
export type DescribeContactEvaluationError = InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a contact evaluation in the specified Connect Customer instance.
 */
export declare const describeContactEvaluation: API.OperationMethod<DescribeContactEvaluationRequest, DescribeContactEvaluationResponse, DescribeContactEvaluationError, Creds | HttpClient.HttpClient>;
export type DescribeContactFlowError = ContactFlowNotPublishedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the specified flow.
 *
 * You can also create and update flows using the Connect Customer
 * Flow language.
 *
 * Use the `$SAVED` alias in the request to describe the `SAVED` content of a Flow. For
 * example, `arn:aws:.../contact-flow/{id}:$SAVED`. After a flow is published, `$SAVED` needs to
 * be supplied to view saved content that has not been published.
 *
 * Use `arn:aws:.../contact-flow/{id}:{version}` to retrieve the content of a specific flow
 * version.
 *
 * In the response, **Status** indicates the flow status as either `SAVED`
 * or `PUBLISHED`. The `PUBLISHED` status will initiate validation on the content.
 * `SAVED` does not initiate validation of the content. `SAVED` | `PUBLISHED`
 */
export declare const describeContactFlow: API.OperationMethod<DescribeContactFlowRequest, DescribeContactFlowResponse, DescribeContactFlowError, Creds | HttpClient.HttpClient>;
export type DescribeContactFlowModuleError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the specified flow module.
 *
 * Use the `$SAVED` alias in the request to describe the `SAVED` content of a Flow. For
 * example, `arn:aws:.../contact-flow/{id}:$SAVED`. After a flow is published, `$SAVED` needs to
 * be supplied to view saved content that has not been published.
 */
export declare const describeContactFlowModule: API.OperationMethod<DescribeContactFlowModuleRequest, DescribeContactFlowModuleResponse, DescribeContactFlowModuleError, Creds | HttpClient.HttpClient>;
export type DescribeContactFlowModuleAliasError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves detailed information about a specific alias, including which version it currently points to and its
 * metadata.
 */
export declare const describeContactFlowModuleAlias: API.OperationMethod<DescribeContactFlowModuleAliasRequest, DescribeContactFlowModuleAliasResponse, DescribeContactFlowModuleAliasError, Creds | HttpClient.HttpClient>;
export type DescribeDataTableError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns all properties for a data table except for attributes and values. All properties from CreateDataTable
 * are returned as well as properties for region replication, versioning, and system tables. "Describe" is a deprecated
 * term but is allowed to maintain consistency with existing operations.
 */
export declare const describeDataTable: API.OperationMethod<DescribeDataTableRequest, DescribeDataTableResponse, DescribeDataTableError, Creds | HttpClient.HttpClient>;
export type DescribeDataTableAttributeError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns detailed information for a specific data table attribute including its configuration, validation rules,
 * and metadata. "Describe" is a deprecated term but is allowed to maintain consistency with existing operations.
 */
export declare const describeDataTableAttribute: API.OperationMethod<DescribeDataTableAttributeRequest, DescribeDataTableAttributeResponse, DescribeDataTableAttributeError, Creds | HttpClient.HttpClient>;
export type DescribeEmailAddressError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describe email address form the specified Connect Customer instance.
 */
export declare const describeEmailAddress: API.OperationMethod<DescribeEmailAddressRequest, DescribeEmailAddressResponse, DescribeEmailAddressError, Creds | HttpClient.HttpClient>;
export type DescribeEvaluationFormError = InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes an evaluation form in the specified Connect Customer instance. If the version property is not
 * provided, the latest version of the evaluation form is described.
 */
export declare const describeEvaluationForm: API.OperationMethod<DescribeEvaluationFormRequest, DescribeEvaluationFormResponse, DescribeEvaluationFormError, Creds | HttpClient.HttpClient>;
export type DescribeExtractionDefinitionError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes an extraction definition in the specified Connect Customer instance.
 */
export declare const describeExtractionDefinition: API.OperationMethod<DescribeExtractionDefinitionRequest, DescribeExtractionDefinitionResponse, DescribeExtractionDefinitionError, Creds | HttpClient.HttpClient>;
export type DescribeHoursOfOperationError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the hours of operation.
 */
export declare const describeHoursOfOperation: API.OperationMethod<DescribeHoursOfOperationRequest, DescribeHoursOfOperationResponse, DescribeHoursOfOperationError, Creds | HttpClient.HttpClient>;
export type DescribeHoursOfOperationOverrideError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the hours of operation override.
 */
export declare const describeHoursOfOperationOverride: API.OperationMethod<DescribeHoursOfOperationOverrideRequest, DescribeHoursOfOperationOverrideResponse, DescribeHoursOfOperationOverrideError, Creds | HttpClient.HttpClient>;
export type DescribeInstanceError = InternalServiceException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Returns the current state of the specified instance identifier. It tracks the instance while it is being created
 * and returns an error status, if applicable.
 *
 * If an instance is not created successfully, the instance status reason field returns details relevant to the
 * reason. The instance in a failed state is returned only for 24 hours after the CreateInstance API was invoked.
 */
export declare const describeInstance: API.OperationMethod<DescribeInstanceRequest, DescribeInstanceResponse, DescribeInstanceError, Creds | HttpClient.HttpClient>;
export type DescribeInstanceAttributeError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Describes the specified instance attribute.
 */
export declare const describeInstanceAttribute: API.OperationMethod<DescribeInstanceAttributeRequest, DescribeInstanceAttributeResponse, DescribeInstanceAttributeError, Creds | HttpClient.HttpClient>;
export type DescribeInstanceStorageConfigError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Retrieves the current storage configurations for the specified resource type, association ID, and instance
 * ID.
 */
export declare const describeInstanceStorageConfig: API.OperationMethod<DescribeInstanceStorageConfigRequest, DescribeInstanceStorageConfigResponse, DescribeInstanceStorageConfigError, Creds | HttpClient.HttpClient>;
export type DescribeMetricError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the full definition of an existing metric from the specified Connect Customer instance.
 */
export declare const describeMetric: API.OperationMethod<DescribeMetricRequest, DescribeMetricResponse, DescribeMetricError, Creds | HttpClient.HttpClient>;
export type DescribeNotificationError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves detailed information about a specific notification, including its content, priority, recipients, and metadata.
 */
export declare const describeNotification: API.OperationMethod<DescribeNotificationRequest, DescribeNotificationResponse, DescribeNotificationError, Creds | HttpClient.HttpClient>;
export type DescribePhoneNumberError = AccessDeniedException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets details and status of a phone number that's claimed to your Connect Customer instance or traffic distribution group.
 *
 * If the number is claimed to a traffic distribution group, and you are calling in the Amazon Web Services Region where the traffic distribution group was
 * created, you can use either a phone number ARN or UUID value for the `PhoneNumberId` URI request
 * parameter. However, if the number is claimed to a traffic distribution group and you are calling this API in the alternate Amazon Web Services Region associated with the traffic distribution group, you must provide a full phone number ARN. If a UUID is provided
 * in
 * this scenario, you receive a `ResourceNotFoundException`.
 */
export declare const describePhoneNumber: API.OperationMethod<DescribePhoneNumberRequest, DescribePhoneNumberResponse, DescribePhoneNumberError, Creds | HttpClient.HttpClient>;
export type DescribePredefinedAttributeError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a predefined attribute for the specified Connect Customer instance. A *predefined attribute*
 * is made up of a name and a value. You can use predefined attributes for:
 *
 * - Routing proficiency (for example, agent certification) that has predefined values (for example, a list of
 * possible certifications). For more information, see Create predefined attributes for routing contacts to
 * agents.
 *
 * - Contact information that varies between transfers or conferences, such as the name of the business unit
 * handling the contact. For more information, see Use contact segment attributes.
 *
 * For the predefined attributes per instance quota, see Connect Customer
 * quotas.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const describePredefinedAttribute: API.OperationMethod<DescribePredefinedAttributeRequest, DescribePredefinedAttributeResponse, DescribePredefinedAttributeError, Creds | HttpClient.HttpClient>;
export type DescribePromptError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the prompt.
 */
export declare const describePrompt: API.OperationMethod<DescribePromptRequest, DescribePromptResponse, DescribePromptError, Creds | HttpClient.HttpClient>;
export type DescribeQueueError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the specified queue.
 */
export declare const describeQueue: API.OperationMethod<DescribeQueueRequest, DescribeQueueResponse, DescribeQueueError, Creds | HttpClient.HttpClient>;
export type DescribeQuickConnectError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the quick connect.
 */
export declare const describeQuickConnect: API.OperationMethod<DescribeQuickConnectRequest, DescribeQuickConnectResponse, DescribeQuickConnectError, Creds | HttpClient.HttpClient>;
export type DescribeRoutingProfileError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the specified routing profile.
 *
 * `DescribeRoutingProfile` does not populate AssociatedQueueIds in its response. The example Response
 * Syntax shown on this page is incorrect; we are working to update it. SearchRoutingProfiles does include
 * AssociatedQueueIds.
 */
export declare const describeRoutingProfile: API.OperationMethod<DescribeRoutingProfileRequest, DescribeRoutingProfileResponse, DescribeRoutingProfileError, Creds | HttpClient.HttpClient>;
export type DescribeRuleError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a rule for the specified Connect Customer instance.
 */
export declare const describeRule: API.OperationMethod<DescribeRuleRequest, DescribeRuleResponse, DescribeRuleError, Creds | HttpClient.HttpClient>;
export type DescribeSecurityProfileError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets basic information about the security profile.
 *
 * For information about security profiles, see Security Profiles in the *Connect Customer Administrator Guide*. For a mapping of the API name and user interface name of the security
 * profile permissions, see List
 * of security profile permissions.
 */
export declare const describeSecurityProfile: API.OperationMethod<DescribeSecurityProfileRequest, DescribeSecurityProfileResponse, DescribeSecurityProfileError, Creds | HttpClient.HttpClient>;
export type DescribeTestCaseError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the specified test case and allows you to get the content and metadata of the test case for the specified Amazon Connect instance.
 */
export declare const describeTestCase: API.OperationMethod<DescribeTestCaseRequest, DescribeTestCaseResponse, DescribeTestCaseError, Creds | HttpClient.HttpClient>;
export type DescribeTrafficDistributionGroupError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets details and status of a traffic distribution group.
 */
export declare const describeTrafficDistributionGroup: API.OperationMethod<DescribeTrafficDistributionGroupRequest, DescribeTrafficDistributionGroupResponse, DescribeTrafficDistributionGroupError, Creds | HttpClient.HttpClient>;
export type DescribeUserError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the specified user. You can find the instance ID in the Connect Customer
 * console (it's the final part of the ARN). The console does not display the user IDs. Instead, list the users
 * and note the IDs provided in the output.
 */
export declare const describeUser: API.OperationMethod<DescribeUserRequest, DescribeUserResponse, DescribeUserError, Creds | HttpClient.HttpClient>;
export type DescribeUserHierarchyGroupError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the specified hierarchy group.
 */
export declare const describeUserHierarchyGroup: API.OperationMethod<DescribeUserHierarchyGroupRequest, DescribeUserHierarchyGroupResponse, DescribeUserHierarchyGroupError, Creds | HttpClient.HttpClient>;
export type DescribeUserHierarchyStructureError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the hierarchy structure of the specified Connect Customer instance.
 */
export declare const describeUserHierarchyStructure: API.OperationMethod<DescribeUserHierarchyStructureRequest, DescribeUserHierarchyStructureResponse, DescribeUserHierarchyStructureError, Creds | HttpClient.HttpClient>;
export type DescribeViewError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the view for the specified Connect Customer instance and view identifier.
 *
 * The view identifier can be supplied as a ViewId or ARN.
 *
 * `$SAVED` needs to be supplied if a view is unpublished.
 *
 * The view identifier can contain an optional qualifier, for example, `:$SAVED`, which
 * is either an actual version number or an Connect Customer managed qualifier `$SAVED | $LATEST`. If it is
 * not supplied, then `$LATEST` is assumed for customer managed views and an error is returned if there is no
 * published content available. Version 1 is assumed for Amazon Web Services managed views.
 */
export declare const describeView: API.OperationMethod<DescribeViewRequest, DescribeViewResponse, DescribeViewError, Creds | HttpClient.HttpClient>;
export type DescribeVocabularyError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the specified vocabulary.
 */
export declare const describeVocabulary: API.OperationMethod<DescribeVocabularyRequest, DescribeVocabularyResponse, DescribeVocabularyError, Creds | HttpClient.HttpClient>;
export type DescribeWorkspaceError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves details about a workspace, including its configuration and metadata.
 */
export declare const describeWorkspace: API.OperationMethod<DescribeWorkspaceRequest, DescribeWorkspaceResponse, DescribeWorkspaceError, Creds | HttpClient.HttpClient>;
export type DisassociateAnalyticsDataSetError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the dataset ID associated with a given Connect Customer instance.
 */
export declare const disassociateAnalyticsDataSet: API.OperationMethod<DisassociateAnalyticsDataSetRequest, DisassociateAnalyticsDataSetResponse, DisassociateAnalyticsDataSetError, Creds | HttpClient.HttpClient>;
export type DisassociateApprovedOriginError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Revokes access to integrated applications from Connect Customer.
 */
export declare const disassociateApprovedOrigin: API.OperationMethod<DisassociateApprovedOriginRequest, DisassociateApprovedOriginResponse, DisassociateApprovedOriginError, Creds | HttpClient.HttpClient>;
export type DisassociateBotError = InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Revokes authorization from the specified instance to access the specified Amazon Lex or Amazon Lex V2 bot.
 */
export declare const disassociateBot: API.OperationMethod<DisassociateBotRequest, DisassociateBotResponse, DisassociateBotError, Creds | HttpClient.HttpClient>;
export type DisassociateEmailAddressAliasError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the alias association between two email addresses in an Connect Customer instance. After
 * disassociation, emails sent to the former alias email address are no longer forwarded to the primary email address.
 * Both email addresses continue to exist independently and can receive emails directly.
 *
 * **Use cases**
 *
 * Following are common uses cases for this API:
 *
 * - **Department separation**: Remove alias relationships when splitting a
 * consolidated support queue back into separate department-specific queues.
 *
 * - **Email address retirement**: Cleanly remove forwarding relationships before
 * decommissioning old email addresses.
 *
 * - **Organizational restructuring**: Reconfigure email routing when business
 * processes change and aliases are no longer needed.
 *
 * **Important things to know**
 *
 * - Concurrent operations: This API uses distributed locking, so concurrent operations on the same email addresses
 * may be temporarily blocked.
 *
 * - Emails sent to the former alias address are still delivered directly to that address if it exists.
 *
 * - You do not need to delete the email addresses after disassociation. Both addresses remain active
 * independently.
 *
 * - After a successful disassociation, you can immediately create a new alias relationship with the same
 * addresses.
 *
 * - 200 status means alias was successfully disassociated.
 *
 * `DisassociateEmailAddressAlias` does not return the following information:
 *
 * - Details in the response about the email that was disassociated. The response returns an empty body.
 *
 * - The timestamp of when the disassociation occurred.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 *
 * **Related operations**
 *
 * - AssociateEmailAddressAlias: Associates an email address alias with an existing email address in an
 * Connect Customer instance.
 *
 * - DescribeEmailAddress: View current alias configurations for an email address.
 *
 * - SearchEmailAddresses: Find email addresses and their alias relationships across an instance.
 *
 * - CreateEmailAddress: Create new email addresses that can participate in alias relationships.
 *
 * - DeleteEmailAddress: Remove email addresses (automatically removes any alias relationships).
 *
 * - UpdateEmailAddressMetadata: Modify email address properties (does not affect alias relationships).
 */
export declare const disassociateEmailAddressAlias: API.OperationMethod<DisassociateEmailAddressAliasRequest, DisassociateEmailAddressAliasResponse, DisassociateEmailAddressAliasError, Creds | HttpClient.HttpClient>;
export type DisassociateFlowError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates a connect resource from a flow.
 */
export declare const disassociateFlow: API.OperationMethod<DisassociateFlowRequest, DisassociateFlowResponse, DisassociateFlowError, Creds | HttpClient.HttpClient>;
export type DisassociateHoursOfOperationsError = ConditionalOperationFailedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates a set of hours of operations with another hours of operation. For more information about inheriting overrides from parent hours of operation, see Hours of operation overrides in the Administrator Guide.
 */
export declare const disassociateHoursOfOperations: API.OperationMethod<DisassociateHoursOfOperationsRequest, DisassociateHoursOfOperationsResponse, DisassociateHoursOfOperationsError, Creds | HttpClient.HttpClient>;
export type DisassociateInstanceStorageConfigError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Removes the storage type configurations for the specified resource type and association ID.
 */
export declare const disassociateInstanceStorageConfig: API.OperationMethod<DisassociateInstanceStorageConfigRequest, DisassociateInstanceStorageConfigResponse, DisassociateInstanceStorageConfigError, Creds | HttpClient.HttpClient>;
export type DisassociateLambdaFunctionError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Remove the Lambda function from the dropdown options available in the relevant flow blocks.
 */
export declare const disassociateLambdaFunction: API.OperationMethod<DisassociateLambdaFunctionRequest, DisassociateLambdaFunctionResponse, DisassociateLambdaFunctionError, Creds | HttpClient.HttpClient>;
export type DisassociateLexBotError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Revokes authorization from the specified instance to access the specified Amazon Lex bot.
 */
export declare const disassociateLexBot: API.OperationMethod<DisassociateLexBotRequest, DisassociateLexBotResponse, DisassociateLexBotError, Creds | HttpClient.HttpClient>;
export type DisassociatePhoneNumberContactFlowError = AccessDeniedException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the flow association from a phone number claimed to your Connect Customer instance.
 *
 * If the number is claimed to a traffic distribution group, and you are calling this API using an instance in the Amazon Web Services Region where the traffic distribution group was created, you can use either a full phone number ARN or UUID value for the
 * `PhoneNumberId` URI request parameter. However, if the number is claimed to a traffic distribution group and you are calling
 * this API using an instance in the alternate Amazon Web Services Region associated with the traffic distribution group, you must provide a
 * full phone number ARN. If a UUID is provided in this scenario, you will receive a
 * `ResourceNotFoundException`.
 */
export declare const disassociatePhoneNumberContactFlow: API.OperationMethod<DisassociatePhoneNumberContactFlowRequest, DisassociatePhoneNumberContactFlowResponse, DisassociatePhoneNumberContactFlowError, Creds | HttpClient.HttpClient>;
export type DisassociateQueueEmailAddressesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the association between a set of email addresses and a queue. After disassociation, agents will no longer be able to select these email addresses as "From" addresses when replying to inbound email contacts or initiating outbound email contacts in this queue.
 *
 * **Important things to know**
 *
 * - Agents will no longer see these email addresses in their "From" address selection options for this queue.
 *
 * - The email addresses themselves are not deleted from the instance, only their availability for agent selection in this queue is removed.
 *
 * - Changes take effect immediately and will affect the agent experience in the Contact Control Panel (CCP).
 */
export declare const disassociateQueueEmailAddresses: API.OperationMethod<DisassociateQueueEmailAddressesRequest, DisassociateQueueEmailAddressesResponse, DisassociateQueueEmailAddressesError, Creds | HttpClient.HttpClient>;
export type DisassociateQueueQuickConnectsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates a set of quick connects from a queue.
 */
export declare const disassociateQueueQuickConnects: API.OperationMethod<DisassociateQueueQuickConnectsRequest, DisassociateQueueQuickConnectsResponse, DisassociateQueueQuickConnectsError, Creds | HttpClient.HttpClient>;
export type DisassociateRoutingProfileQueuesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates a set of queues from a routing profile.
 *
 * Up to 10 queue references can be disassociated in a single API call. More than 10 queue references results in a
 * single call results in an InvalidParameterException.
 */
export declare const disassociateRoutingProfileQueues: API.OperationMethod<DisassociateRoutingProfileQueuesRequest, DisassociateRoutingProfileQueuesResponse, DisassociateRoutingProfileQueuesError, Creds | HttpClient.HttpClient>;
export type DisassociateSecurityKeyError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Deletes the specified security key.
 */
export declare const disassociateSecurityKey: API.OperationMethod<DisassociateSecurityKeyRequest, DisassociateSecurityKeyResponse, DisassociateSecurityKeyError, Creds | HttpClient.HttpClient>;
export type DisassociateSecurityProfilesError = AccessDeniedException | ConditionalOperationFailedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates a security profile attached to a Q in Connect AI Agent Entity in an Amazon Connect instance.
 */
export declare const disassociateSecurityProfiles: API.OperationMethod<DisassociateSecurityProfilesRequest, DisassociateSecurityProfilesResponse, DisassociateSecurityProfilesError, Creds | HttpClient.HttpClient>;
export type DisassociateTrafficDistributionGroupUserError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates an agent from a traffic distribution group. This API can be called only in the Region where the
 * traffic distribution group is created.
 */
export declare const disassociateTrafficDistributionGroupUser: API.OperationMethod<DisassociateTrafficDistributionGroupUserRequest, DisassociateTrafficDistributionGroupUserResponse, DisassociateTrafficDistributionGroupUserError, Creds | HttpClient.HttpClient>;
export type DisassociateUserProficienciesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates a set of proficiencies from a user.
 */
export declare const disassociateUserProficiencies: API.OperationMethod<DisassociateUserProficienciesRequest, DisassociateUserProficienciesResponse, DisassociateUserProficienciesError, Creds | HttpClient.HttpClient>;
export type DisassociateWorkspaceError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the association between a workspace and one or more users or routing profiles.
 */
export declare const disassociateWorkspace: API.OperationMethod<DisassociateWorkspaceRequest, DisassociateWorkspaceResponse, DisassociateWorkspaceError, Creds | HttpClient.HttpClient>;
export type DismissUserContactError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Dismisses contacts from an agent's CCP and returns the agent to an available state, which allows the agent to
 * receive a new routed contact. Contacts can only be dismissed if they are in a `MISSED`,
 * `ERROR`, `ENDED`, or `REJECTED` state in the Agent Event Stream.
 */
export declare const dismissUserContact: API.OperationMethod<DismissUserContactRequest, DismissUserContactResponse, DismissUserContactError, Creds | HttpClient.HttpClient>;
export type EvaluateDataTableValuesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Evaluates values at the time of the request and returns them. It considers the request's timezone or the table's
 * timezone, in that order, when accessing time based tables. When a value is accessed, the accessor's identity and the
 * time of access are saved alongside the value to help identify values that are actively in use. The term "Batch" is
 * not included in the operation name since it does not meet all the criteria for a batch operation as specified in
 * Batch Operations: Amazon Web Services API Standards.
 */
export declare const evaluateDataTableValues: API.PaginatedOperationMethod<EvaluateDataTableValuesRequest, EvaluateDataTableValuesResponse, EvaluateDataTableValuesError, Creds | HttpClient.HttpClient, unknown>;
export type GetAttachedFileError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides a pre-signed URL for download of an approved attached file. This API also returns metadata about the
 * attached file. It will only return a downloadURL if the status of the attached file is `APPROVED`.
 */
export declare const getAttachedFile: API.OperationMethod<GetAttachedFileRequest, GetAttachedFileResponse, GetAttachedFileError, Creds | HttpClient.HttpClient>;
export type GetContactAttributesError = InternalServiceException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the contact attributes for the specified contact.
 */
export declare const getContactAttributes: API.OperationMethod<GetContactAttributesRequest, GetContactAttributesResponse, GetContactAttributesError, Creds | HttpClient.HttpClient>;
export type GetContactMetricsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves contact metric data for a specified contact.
 *
 * **Use cases**
 *
 * Following are common use cases for position in queue and estimated wait time:
 *
 * - Customer-Facing Wait Time Announcements - Display or announce the estimated wait time and position in queue to customers before or during their queue experience.
 *
 * - Callback Offerings - Offer customers a callback option when the estimated wait time or position in queue exceeds a defined threshold.
 *
 * - Queue Routing Decisions - Route incoming contacts to less congested queues by comparing estimated wait time and position in queue across multiple queues.
 *
 * - Self-Service Deflection - Redirect customers to self-service options like chatbots or FAQs when estimated wait time is high or position in queue is unfavorable.
 *
 * **Important things to know**
 *
 * - Metrics are only available while the contact is actively in queue.
 *
 * - For more information, see the Position in queue metric in the *Connect Customer Administrator Guide*.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const getContactMetrics: API.OperationMethod<GetContactMetricsRequest, GetContactMetricsResponse, GetContactMetricsError, Creds | HttpClient.HttpClient>;
export type GetCrossRegionRoutingError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the current cross-region routing configuration for an Amazon Connect Global Resiliency instance
 * enabled for global routing. This operation returns whether cross-region routing is currently enabled or disabled
 * (isolated) for the instance.
 *
 * This operation is available only for Amazon Connect Global Resiliency instances enabled for global routing.
 */
export declare const getCrossRegionRouting: API.OperationMethod<GetCrossRegionRoutingRequest, GetCrossRegionRoutingResponse, GetCrossRegionRoutingError, Creds | HttpClient.HttpClient>;
export type GetCurrentMetricDataError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets the real-time metric data from the specified Connect Customer instance.
 *
 * For a description of each metric, see Metrics definitions in the *Connect Customer Administrator Guide*.
 *
 * When you make a successful API request, you can expect the following metric values in the response:
 *
 * - **Metric value is null**: The calculation cannot be performed due to divide by
 * zero or insufficient data
 *
 * - **Metric value is a number (including 0) of defined type**: The number provided
 * is the calculation result
 *
 * - **MetricResult list is empty**: The request cannot find any data in the
 * system
 *
 * The following guidelines can help you work with the API:
 *
 * - Each dimension in the metric response must contain a value
 *
 * - Each item in MetricResult must include all requested metrics
 *
 * - If the response is slow due to large result sets, try these approaches:
 *
 * - Add filters to reduce the amount of data returned
 */
export declare const getCurrentMetricData: API.PaginatedOperationMethod<GetCurrentMetricDataRequest, GetCurrentMetricDataResponse, GetCurrentMetricDataError, Creds | HttpClient.HttpClient, unknown>;
export type GetCurrentUserDataError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets the real-time active user data from the specified Connect Customer instance.
 */
export declare const getCurrentUserData: API.PaginatedOperationMethod<GetCurrentUserDataRequest, GetCurrentUserDataResponse, GetCurrentUserDataError, Creds | HttpClient.HttpClient, unknown>;
export type GetEffectiveHoursOfOperationsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Get the hours of operations with the effective override applied.
 */
export declare const getEffectiveHoursOfOperations: API.OperationMethod<GetEffectiveHoursOfOperationsRequest, GetEffectiveHoursOfOperationsResponse, GetEffectiveHoursOfOperationsError, Creds | HttpClient.HttpClient>;
export type GetEvaluationFormValidationError = InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the status and results of a validation process started by StartEvaluationFormValidation.
 * Returns the current execution status (`IN_PROGRESS`, `COMPLETED`, or `FAILED`),
 * the validated form version, and when completed, a list of findings that identify structural issues and quality
 * improvements for the evaluation form, and may include suggested fixes. If the validation failed, a reason is provided
 * indicating the cause of the failure.
 */
export declare const getEvaluationFormValidation: API.OperationMethod<GetEvaluationFormValidationRequest, GetEvaluationFormValidationResponse, GetEvaluationFormValidationError, Creds | HttpClient.HttpClient>;
export type GetFederationTokenError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | UserNotFoundException | CommonErrors;
/**
 * Supports SAML sign-in for Connect Customer. Retrieves a token for federation. The token is for the Connect Customer user which corresponds to the IAM credentials that were used to invoke this action.
 *
 * For more information about how SAML sign-in works in Connect Customer, see Configure SAML with IAM for Connect Customer
 * in the *Connect Customer Administrator Guide*.
 *
 * This API doesn't support root users. If you try to invoke GetFederationToken with root credentials, an error
 * message similar to the following one appears:
 *
 * `Provided identity: Principal: .... User: .... cannot be used for federation with Connect Customer`
 */
export declare const getFederationToken: API.OperationMethod<GetFederationTokenRequest, GetFederationTokenResponse, GetFederationTokenError, Creds | HttpClient.HttpClient>;
export type GetFlowAssociationError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the flow associated for a given resource.
 */
export declare const getFlowAssociation: API.OperationMethod<GetFlowAssociationRequest, GetFlowAssociationResponse, GetFlowAssociationError, Creds | HttpClient.HttpClient>;
export type GetMetricDataError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets historical metric data from the specified Connect Customer instance.
 *
 * For a description of each historical metric, see Metrics definitions in the *Connect Customer Administrator Guide*.
 *
 * We recommend using the GetMetricDataV2 API. It provides more flexibility, features, and the ability to query longer time ranges
 * than `GetMetricData`. Use it to retrieve historical agent and contact metrics for the last 3 months, at
 * varying intervals. You can also use it to build custom dashboards to measure historical queue and agent performance.
 * For example, you can track the number of incoming contacts for the last 7 days, with data split by day, to see how
 * contact volume changed per day of the week.
 */
export declare const getMetricData: API.PaginatedOperationMethod<GetMetricDataRequest, GetMetricDataResponse, GetMetricDataError, Creds | HttpClient.HttpClient, unknown>;
export type GetMetricDataV2Error = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets metric data from the specified Connect Customer instance.
 *
 * `GetMetricDataV2` offers more features than GetMetricData, the previous version of this API. It
 * has new metrics, offers filtering at a metric level, and offers the ability to filter and group data by channels,
 * queues, routing profiles, agents, and agent hierarchy levels. It can retrieve historical data for the last 3 months,
 * at varying intervals. It does not support agent queues.
 *
 * For a description of the historical metrics that are supported by `GetMetricDataV2` and
 * `GetMetricData`, see Metrics definitions in the *Connect Customer Administrator Guide*.
 *
 * When you make a successful API request, you can expect the following metric values in the response:
 *
 * - **Metric value is null**: The calculation cannot be performed due to divide by
 * zero or insufficient data
 *
 * - **Metric value is a number (including 0) of defined type**: The number provided
 * is the calculation result
 *
 * - **MetricResult list is empty**: The request cannot find any data in the
 * system
 *
 * The following guidelines can help you work with the API:
 *
 * - Each dimension in the metric response must contain a value
 *
 * - Each item in MetricResult must include all requested metrics
 *
 * - If the response is slow due to large result sets, try these approaches:
 *
 * - Narrow the time range of your request
 *
 * - Add filters to reduce the amount of data returned
 */
export declare const getMetricDataV2: API.PaginatedOperationMethod<GetMetricDataV2Request, GetMetricDataV2Response, GetMetricDataV2Error, Creds | HttpClient.HttpClient, unknown>;
export type GetPromptFileError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets the prompt file.
 */
export declare const getPromptFile: API.OperationMethod<GetPromptFileRequest, GetPromptFileResponse, GetPromptFileError, Creds | HttpClient.HttpClient>;
export type GetTaskTemplateError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets details about a specific task template in the specified Connect Customer instance.
 */
export declare const getTaskTemplate: API.OperationMethod<GetTaskTemplateRequest, GetTaskTemplateResponse, GetTaskTemplateError, Creds | HttpClient.HttpClient>;
export type GetTestCaseExecutionSummaryError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves an overview of a test execution that includes the status of the execution, start and end time, and observation summary.
 */
export declare const getTestCaseExecutionSummary: API.OperationMethod<GetTestCaseExecutionSummaryRequest, GetTestCaseExecutionSummaryResponse, GetTestCaseExecutionSummaryError, Creds | HttpClient.HttpClient>;
export type GetTrafficDistributionError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the current traffic distribution for a given traffic distribution group.
 */
export declare const getTrafficDistribution: API.OperationMethod<GetTrafficDistributionRequest, GetTrafficDistributionResponse, GetTrafficDistributionError, Creds | HttpClient.HttpClient>;
export type ImportPhoneNumberError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Imports a claimed phone number from an external service, such as Amazon Web Services End User Messaging, into an
 * Connect Customer instance. You can call this API only in the same Amazon Web Services Region where the Connect Customer instance was created.
 *
 * Call the DescribePhoneNumber API to verify the status of a previous `ImportPhoneNumber` operation.
 *
 * If you plan to claim or import numbers and then release numbers frequently, contact us for a service quota
 * exception. Otherwise, it is possible you will be blocked from claiming and releasing any more numbers until up to 180
 * days past the oldest number released has expired.
 *
 * By default you can claim or import and then release up to 200% of your maximum number of active phone numbers.
 * If you claim or import and then release phone numbers using the UI or API during a rolling 180 day cycle that exceeds
 * 200% of your phone number service level quota, you will be blocked from claiming or importing any more numbers until
 * 180 days past the oldest number released has expired.
 *
 * For example, if you already have 99 claimed or imported numbers and a service level quota of 99 phone numbers,
 * and in any 180 day period you release 99, claim 99, and then release 99, you will have exceeded the 200% limit. At
 * that point you are blocked from claiming any more numbers until you open an Amazon Web Services Support ticket.
 */
export declare const importPhoneNumber: API.OperationMethod<ImportPhoneNumberRequest, ImportPhoneNumberResponse, ImportPhoneNumberError, Creds | HttpClient.HttpClient>;
export type ImportWorkspaceMediaError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Imports a media asset (such as a logo) for use in a workspace.
 */
export declare const importWorkspaceMedia: API.OperationMethod<ImportWorkspaceMediaRequest, ImportWorkspaceMediaResponse, ImportWorkspaceMediaError, Creds | HttpClient.HttpClient>;
export type ListAgentStatusesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists agent statuses.
 */
export declare const listAgentStatuses: API.PaginatedOperationMethod<ListAgentStatusRequest, ListAgentStatusResponse, ListAgentStatusesError, Creds | HttpClient.HttpClient, AgentStatusSummary>;
export type ListAnalyticsDataAssociationsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the association status of requested dataset ID for a given Connect Customer instance.
 */
export declare const listAnalyticsDataAssociations: API.OperationMethod<ListAnalyticsDataAssociationsRequest, ListAnalyticsDataAssociationsResponse, ListAnalyticsDataAssociationsError, Creds | HttpClient.HttpClient>;
export type ListAnalyticsDataLakeDataSetsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the data lake datasets available to associate with for a given Connect Customer instance.
 */
export declare const listAnalyticsDataLakeDataSets: API.OperationMethod<ListAnalyticsDataLakeDataSetsRequest, ListAnalyticsDataLakeDataSetsResponse, ListAnalyticsDataLakeDataSetsError, Creds | HttpClient.HttpClient>;
export type ListApprovedOriginsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Returns a paginated list of all approved origins associated with the instance.
 */
export declare const listApprovedOrigins: API.PaginatedOperationMethod<ListApprovedOriginsRequest, ListApprovedOriginsResponse, ListApprovedOriginsError, Creds | HttpClient.HttpClient, Origin>;
export type ListAssociatedContactsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides information about contact tree, a list of associated contacts with a unique identifier.
 */
export declare const listAssociatedContacts: API.OperationMethod<ListAssociatedContactsRequest, ListAssociatedContactsResponse, ListAssociatedContactsError, Creds | HttpClient.HttpClient>;
export type ListAttachedFilesConfigurationsError = AccessDeniedException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides summary information about the attached files configurations for the specified Connect Customer instance.
 *
 * This API returns effective configurations (custom overrides or defaults) for each attachment scope. If no custom configuration exists for a scope, the default configuration values are returned.
 */
export declare const listAttachedFilesConfigurations: API.PaginatedOperationMethod<ListAttachedFilesConfigurationsRequest, ListAttachedFilesConfigurationsResponse, ListAttachedFilesConfigurationsError, Creds | HttpClient.HttpClient, AttachedFilesConfigurationSummary>;
export type ListAuthenticationProfilesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change. To
 * request access to this API, contact Amazon Web Services Support.
 *
 * Provides summary information about the authentication profiles in a specified Connect Customer
 * instance.
 */
export declare const listAuthenticationProfiles: API.PaginatedOperationMethod<ListAuthenticationProfilesRequest, ListAuthenticationProfilesResponse, ListAuthenticationProfilesError, Creds | HttpClient.HttpClient, AuthenticationProfileSummary>;
export type ListBotsError = InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * For the specified version of Amazon Lex, returns a paginated list of all the Amazon Lex bots
 * currently associated with the instance. Use this API to return both Amazon Lex V1 and V2
 * bots.
 */
export declare const listBots: API.PaginatedOperationMethod<ListBotsRequest, ListBotsResponse, ListBotsError, Creds | HttpClient.HttpClient, LexBotConfig>;
export type ListChildHoursOfOperationsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides information about the child hours of operations for the specified parent hours of operation.
 *
 * For more information about child hours of operations, see Link overrides from different hours of operation in the
 * * Administrator Guide*.
 */
export declare const listChildHoursOfOperations: API.PaginatedOperationMethod<ListChildHoursOfOperationsRequest, ListChildHoursOfOperationsResponse, ListChildHoursOfOperationsError, Creds | HttpClient.HttpClient, HoursOfOperationsIdentifier>;
export type ListContactEvaluationsError = InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists contact evaluations in the specified Connect Customer instance.
 */
export declare const listContactEvaluations: API.PaginatedOperationMethod<ListContactEvaluationsRequest, ListContactEvaluationsResponse, ListContactEvaluationsError, Creds | HttpClient.HttpClient, EvaluationSummary>;
export type ListContactFlowModuleAliasesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all aliases associated with a contact flow module, showing their current version mappings and
 * metadata.
 */
export declare const listContactFlowModuleAliases: API.PaginatedOperationMethod<ListContactFlowModuleAliasesRequest, ListContactFlowModuleAliasesResponse, ListContactFlowModuleAliasesError, Creds | HttpClient.HttpClient, ContactFlowModuleAliasSummary>;
export type ListContactFlowModulesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides information about the flow modules for the specified Connect Customer instance.
 */
export declare const listContactFlowModules: API.PaginatedOperationMethod<ListContactFlowModulesRequest, ListContactFlowModulesResponse, ListContactFlowModulesError, Creds | HttpClient.HttpClient, ContactFlowModuleSummary>;
export type ListContactFlowModuleVersionsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of all versions for a specific contact flow module.
 */
export declare const listContactFlowModuleVersions: API.PaginatedOperationMethod<ListContactFlowModuleVersionsRequest, ListContactFlowModuleVersionsResponse, ListContactFlowModuleVersionsError, Creds | HttpClient.HttpClient, ContactFlowModuleVersionSummary>;
export type ListContactFlowsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides information about the flows for the specified Connect Customer instance.
 *
 * You can also create and update flows using the Connect Customer
 * Flow language.
 *
 * For more information about flows, see Flows in the Connect Customer
 * Administrator Guide.
 */
export declare const listContactFlows: API.PaginatedOperationMethod<ListContactFlowsRequest, ListContactFlowsResponse, ListContactFlowsError, Creds | HttpClient.HttpClient, ContactFlowSummary>;
export type ListContactFlowVersionsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns all the available versions for the specified Connect Customer instance and flow identifier.
 */
export declare const listContactFlowVersions: API.PaginatedOperationMethod<ListContactFlowVersionsRequest, ListContactFlowVersionsResponse, ListContactFlowVersionsError, Creds | HttpClient.HttpClient, ContactFlowVersionSummary>;
export type ListContactReferencesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * For the specified `referenceTypes`, returns a list of references associated with the contact.
 * *References* are links to documents that are related to a contact, such as emails, attachments,
 * or URLs.
 */
export declare const listContactReferences: API.PaginatedOperationMethod<ListContactReferencesRequest, ListContactReferencesResponse, ListContactReferencesError, Creds | HttpClient.HttpClient, ReferenceSummary>;
export type ListDataTableAttributesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns all attributes for a specified data table. A maximum of 100 attributes per data table is allowed.
 * Customers can request an increase by using Amazon Web Services Service Quotas. The response can be filtered by specific attribute IDs
 * for CloudFormation integration.
 */
export declare const listDataTableAttributes: API.PaginatedOperationMethod<ListDataTableAttributesRequest, ListDataTableAttributesResponse, ListDataTableAttributesError, Creds | HttpClient.HttpClient, DataTableAttribute>;
export type ListDataTablePrimaryValuesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all primary value combinations for a given data table. Returns the unique combinations of primary
 * attribute values that identify records in the table. Up to 100 records are returned per request.
 */
export declare const listDataTablePrimaryValues: API.PaginatedOperationMethod<ListDataTablePrimaryValuesRequest, ListDataTablePrimaryValuesResponse, ListDataTablePrimaryValuesError, Creds | HttpClient.HttpClient, RecordPrimaryValue>;
export type ListDataTablesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all data tables for the specified Amazon Connect instance. Returns summary information for each table
 * including basic metadata and modification details.
 */
export declare const listDataTables: API.PaginatedOperationMethod<ListDataTablesRequest, ListDataTablesResponse, ListDataTablesError, Creds | HttpClient.HttpClient, DataTableSummary>;
export type ListDataTableValuesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists values stored in a data table with optional filtering by record IDs or primary attribute values. Returns
 * the raw stored values along with metadata such as lock versions and modification timestamps.
 */
export declare const listDataTableValues: API.PaginatedOperationMethod<ListDataTableValuesRequest, ListDataTableValuesResponse, ListDataTableValuesError, Creds | HttpClient.HttpClient, DataTableValueSummary>;
export type ListDefaultVocabulariesError = AccessDeniedException | InternalServiceException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Lists the default vocabularies for the specified Connect Customer instance.
 */
export declare const listDefaultVocabularies: API.PaginatedOperationMethod<ListDefaultVocabulariesRequest, ListDefaultVocabulariesResponse, ListDefaultVocabulariesError, Creds | HttpClient.HttpClient, DefaultVocabulary>;
export type ListEntitySecurityProfilesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all security profiles attached to a Q in Connect AIAgent Entity in an Amazon Connect instance.
 */
export declare const listEntitySecurityProfiles: API.PaginatedOperationMethod<ListEntitySecurityProfilesRequest, ListEntitySecurityProfilesResponse, ListEntitySecurityProfilesError, Creds | HttpClient.HttpClient, SecurityProfileItem>;
export type ListEvaluationFormAIVersionsError = InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the available AI versions for evaluation forms in the specified Connect Customer instance.
 */
export declare const listEvaluationFormAIVersions: API.PaginatedOperationMethod<ListEvaluationFormAIVersionsRequest, ListEvaluationFormAIVersionsResponse, ListEvaluationFormAIVersionsError, Creds | HttpClient.HttpClient, EvaluationFormAIVersionSummary>;
export type ListEvaluationFormsError = InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists evaluation forms in the specified Connect Customer instance.
 */
export declare const listEvaluationForms: API.PaginatedOperationMethod<ListEvaluationFormsRequest, ListEvaluationFormsResponse, ListEvaluationFormsError, Creds | HttpClient.HttpClient, EvaluationFormSummary>;
export type ListEvaluationFormVersionsError = InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists versions of an evaluation form in the specified Connect Customer instance.
 */
export declare const listEvaluationFormVersions: API.PaginatedOperationMethod<ListEvaluationFormVersionsRequest, ListEvaluationFormVersionsResponse, ListEvaluationFormVersionsError, Creds | HttpClient.HttpClient, EvaluationFormVersionSummary>;
export type ListExtractionDefinitionsError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists extraction definitions in the specified Connect Customer instance.
 */
export declare const listExtractionDefinitions: API.PaginatedOperationMethod<ListExtractionDefinitionsRequest, ListExtractionDefinitionsResponse, ListExtractionDefinitionsError, Creds | HttpClient.HttpClient, ExtractionDefinitionSummary>;
export type ListFlowAssociationsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * List the flow association based on the filters.
 */
export declare const listFlowAssociations: API.PaginatedOperationMethod<ListFlowAssociationsRequest, ListFlowAssociationsResponse, ListFlowAssociationsError, Creds | HttpClient.HttpClient, FlowAssociationSummary>;
export type ListHoursOfOperationOverridesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * List the hours of operation overrides.
 */
export declare const listHoursOfOperationOverrides: API.PaginatedOperationMethod<ListHoursOfOperationOverridesRequest, ListHoursOfOperationOverridesResponse, ListHoursOfOperationOverridesError, Creds | HttpClient.HttpClient, HoursOfOperationOverride>;
export type ListHoursOfOperationsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides information about the hours of operation for the specified Connect Customer instance.
 *
 * For more information about hours of operation, see Set the Hours of Operation for a Queue in the
 * *Connect Customer Administrator Guide*.
 */
export declare const listHoursOfOperations: API.PaginatedOperationMethod<ListHoursOfOperationsRequest, ListHoursOfOperationsResponse, ListHoursOfOperationsError, Creds | HttpClient.HttpClient, HoursOfOperationSummary>;
export type ListInstanceAttributesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Returns a paginated list of all attribute types for the given instance.
 */
export declare const listInstanceAttributes: API.PaginatedOperationMethod<ListInstanceAttributesRequest, ListInstanceAttributesResponse, ListInstanceAttributesError, Creds | HttpClient.HttpClient, Attribute>;
export type ListInstancesError = InternalServiceException | InvalidRequestException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Return a list of instances which are in active state, creation-in-progress state, and failed state. Instances
 * that aren't successfully created (they are in a failed state) are returned only for 24 hours after the CreateInstance
 * API was invoked.
 */
export declare const listInstances: API.PaginatedOperationMethod<ListInstancesRequest, ListInstancesResponse, ListInstancesError, Creds | HttpClient.HttpClient, InstanceSummary>;
export type ListInstanceStorageConfigsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Returns a paginated list of storage configs for the identified instance and resource type.
 */
export declare const listInstanceStorageConfigs: API.PaginatedOperationMethod<ListInstanceStorageConfigsRequest, ListInstanceStorageConfigsResponse, ListInstanceStorageConfigsError, Creds | HttpClient.HttpClient, InstanceStorageConfig>;
export type ListIntegrationAssociationsError = InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides summary information about the Amazon Web Services resource associations for the specified Connect Customer instance.
 */
export declare const listIntegrationAssociations: API.PaginatedOperationMethod<ListIntegrationAssociationsRequest, ListIntegrationAssociationsResponse, ListIntegrationAssociationsError, Creds | HttpClient.HttpClient, IntegrationAssociationSummary>;
export type ListLambdaFunctionsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Returns a paginated list of all Lambda functions that display in the dropdown options in the relevant flow
 * blocks.
 */
export declare const listLambdaFunctions: API.PaginatedOperationMethod<ListLambdaFunctionsRequest, ListLambdaFunctionsResponse, ListLambdaFunctionsError, Creds | HttpClient.HttpClient, FunctionArn>;
export type ListLexBotsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Returns a paginated list of all the Amazon Lex V1 bots currently associated with the instance. To return
 * both Amazon Lex V1 and V2 bots, use the ListBots API.
 */
export declare const listLexBots: API.PaginatedOperationMethod<ListLexBotsRequest, ListLexBotsResponse, ListLexBotsError, Creds | HttpClient.HttpClient, LexBot>;
export type ListMetricsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of metric summaries for the specified Connect Customer instance. Use pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listMetrics: API.PaginatedOperationMethod<ListMetricsRequest, ListMetricsResponse, ListMetricsError, Creds | HttpClient.HttpClient, MetricSummary>;
export type ListNotificationsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of all notifications in the Amazon Connect instance.
 */
export declare const listNotifications: API.OperationMethod<ListNotificationsRequest, ListNotificationsResponse, ListNotificationsError, Creds | HttpClient.HttpClient>;
export type ListPhoneNumbersError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides information about the phone numbers for the specified Connect Customer instance.
 *
 * For more information about phone numbers, see Set Up Phone Numbers for Your Contact
 * Center in the *Connect Customer Administrator Guide*.
 *
 * - We recommend using ListPhoneNumbersV2 to return phone number types. ListPhoneNumbers doesn't support number types
 * `UIFN`, `SHARED`, `THIRD_PARTY_TF`, and `THIRD_PARTY_DID`. While it
 * returns numbers of those types, it incorrectly lists them as `TOLL_FREE` or `DID`.
 *
 * - The phone number `Arn` value that is returned from each of the items in the PhoneNumberSummaryList cannot be used to tag phone number resources. It will fail with a
 * `ResourceNotFoundException`. Instead, use the ListPhoneNumbersV2 API. It returns the new
 * phone number ARN that can be used to tag phone number resources.
 */
export declare const listPhoneNumbers: API.PaginatedOperationMethod<ListPhoneNumbersRequest, ListPhoneNumbersResponse, ListPhoneNumbersError, Creds | HttpClient.HttpClient, PhoneNumberSummary>;
export type ListPhoneNumbersV2Error = AccessDeniedException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists phone numbers claimed to your Connect Customer instance or traffic distribution group. If the provided `TargetArn`
 * is a traffic distribution group, you can call this API in both Amazon Web Services Regions associated with traffic distribution group.
 *
 * For more information about phone numbers, see Set Up Phone Numbers for Your Contact
 * Center in the *Connect Customer Administrator Guide*.
 *
 * - When given an instance ARN, `ListPhoneNumbersV2` returns only the phone numbers claimed to the
 * instance.
 *
 * - When given a traffic distribution group ARN `ListPhoneNumbersV2` returns only the phone numbers claimed to the
 * traffic distribution group.
 */
export declare const listPhoneNumbersV2: API.PaginatedOperationMethod<ListPhoneNumbersV2Request, ListPhoneNumbersV2Response, ListPhoneNumbersV2Error, Creds | HttpClient.HttpClient, ListPhoneNumbersSummary>;
export type ListPredefinedAttributesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists predefined attributes for the specified Connect Customer instance. A *predefined attribute* is
 * made up of a name and a value. You can use predefined attributes for:
 *
 * - Routing proficiency (for example, agent certification) that has predefined values (for example, a list of
 * possible certifications). For more information, see Create predefined attributes for routing contacts to
 * agents.
 *
 * - Contact information that varies between transfers or conferences, such as the name of the business unit
 * handling the contact. For more information, see Use contact segment attributes.
 *
 * For the predefined attributes per instance quota, see Connect Customer
 * quotas.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const listPredefinedAttributes: API.PaginatedOperationMethod<ListPredefinedAttributesRequest, ListPredefinedAttributesResponse, ListPredefinedAttributesError, Creds | HttpClient.HttpClient, PredefinedAttributeSummary>;
export type ListPromptsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides information about the prompts for the specified Connect Customer instance.
 */
export declare const listPrompts: API.PaginatedOperationMethod<ListPromptsRequest, ListPromptsResponse, ListPromptsError, Creds | HttpClient.HttpClient, PromptSummary>;
export type ListQueueEmailAddressesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all email addresses that are currently associated with a specific queue, providing details about which "From" email addresses agents can select when handling email contacts. This helps administrators manage agent email address options and understand the available choices for different brands and business units.
 *
 * **Important things to know**
 *
 * - The response includes metadata about each email address available for agent selection, including whether it's configured as the default outbound email.
 *
 * - Agents can select from these email addresses when replying to inbound contacts or initiating outbound contacts in this queue.
 *
 * - The list includes both explicitly associated email addresses and any default outbound email address configured for the queue.
 *
 * - Results are paginated to handle queues with many associated email addresses (up to 50 per queue).
 */
export declare const listQueueEmailAddresses: API.OperationMethod<ListQueueEmailAddressesRequest, ListQueueEmailAddressesResponse, ListQueueEmailAddressesError, Creds | HttpClient.HttpClient>;
export type ListQueueQuickConnectsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the quick connects associated with a queue.
 */
export declare const listQueueQuickConnects: API.PaginatedOperationMethod<ListQueueQuickConnectsRequest, ListQueueQuickConnectsResponse, ListQueueQuickConnectsError, Creds | HttpClient.HttpClient, QuickConnectSummary>;
export type ListQueuesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides information about the queues for the specified Connect Customer instance.
 *
 * If you do not specify a `QueueTypes` parameter, both standard and
 * agent queues are returned. This might cause an unexpected truncation of results if you have more than 1000 agents and
 * you limit the number of results of the API call in code.
 *
 * For more information about queues, see Queues: Standard and Agent in the
 * *Connect Customer Administrator Guide*.
 */
export declare const listQueues: API.PaginatedOperationMethod<ListQueuesRequest, ListQueuesResponse, ListQueuesError, Creds | HttpClient.HttpClient, QueueSummary>;
export type ListQuickConnectsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides information about the quick connects for the specified Connect Customer instance.
 */
export declare const listQuickConnects: API.PaginatedOperationMethod<ListQuickConnectsRequest, ListQuickConnectsResponse, ListQuickConnectsError, Creds | HttpClient.HttpClient, QuickConnectSummary>;
export type ListRealtimeContactAnalysisSegmentsV2Error = AccessDeniedException | InternalServiceException | InvalidRequestException | OutputTypeNotFoundException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides a list of analysis segments for a real-time chat analysis session. This API supports CHAT channels
 * only.
 *
 * This API does not support VOICE. If you attempt to use it for VOICE, an `InvalidRequestException`
 * occurs.
 */
export declare const listRealtimeContactAnalysisSegmentsV2: API.PaginatedOperationMethod<ListRealtimeContactAnalysisSegmentsV2Request, ListRealtimeContactAnalysisSegmentsV2Response, ListRealtimeContactAnalysisSegmentsV2Error, Creds | HttpClient.HttpClient, unknown>;
export type ListRoutingProfileManualAssignmentQueuesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the manual assignment queues associated with a routing profile.
 *
 * **Use cases**
 *
 * Following are common uses cases for this API:
 *
 * - This API returns list of queues where contacts can be manually assigned or picked by an agent who has access
 * to the Worklist app. The user can additionally filter on queues, if they have access to those queues (otherwise a
 * invalid request exception will be thrown).
 *
 * For information about how manual contact assignment works in the agent workspace, see the Access the Worklist app in the Connect Customer agent workspace in the *Connect Customer Administrator Guide*.
 *
 * **Important things to know**
 *
 * - This API only returns the manual assignment queues associated with a routing profile. Use the
 * ListRoutingProfileQueues API to list the auto assignment queues for the routing profile.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const listRoutingProfileManualAssignmentQueues: API.PaginatedOperationMethod<ListRoutingProfileManualAssignmentQueuesRequest, ListRoutingProfileManualAssignmentQueuesResponse, ListRoutingProfileManualAssignmentQueuesError, Creds | HttpClient.HttpClient, RoutingProfileManualAssignmentQueueConfigSummary>;
export type ListRoutingProfileQueuesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the queues associated with a routing profile.
 */
export declare const listRoutingProfileQueues: API.PaginatedOperationMethod<ListRoutingProfileQueuesRequest, ListRoutingProfileQueuesResponse, ListRoutingProfileQueuesError, Creds | HttpClient.HttpClient, RoutingProfileQueueConfigSummary>;
export type ListRoutingProfilesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides summary information about the routing profiles for the specified Connect Customer instance.
 *
 * For more information about routing profiles, see Routing Profiles and Create a Routing Profile in the *Connect Customer Administrator Guide*.
 */
export declare const listRoutingProfiles: API.PaginatedOperationMethod<ListRoutingProfilesRequest, ListRoutingProfilesResponse, ListRoutingProfilesError, Creds | HttpClient.HttpClient, RoutingProfileSummary>;
export type ListRulesError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * List all rules for the specified Connect Customer instance.
 */
export declare const listRules: API.PaginatedOperationMethod<ListRulesRequest, ListRulesResponse, ListRulesError, Creds | HttpClient.HttpClient, RuleSummary>;
export type ListSecurityKeysError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Returns a paginated list of all security keys associated with the instance.
 */
export declare const listSecurityKeys: API.PaginatedOperationMethod<ListSecurityKeysRequest, ListSecurityKeysResponse, ListSecurityKeysError, Creds | HttpClient.HttpClient, SecurityKey>;
export type ListSecurityProfileAIAgentsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of the allowed AI agents in a specific security profile.
 */
export declare const listSecurityProfileAIAgents: API.PaginatedOperationMethod<ListSecurityProfileAIAgentsRequest, ListSecurityProfileAIAgentsResponse, ListSecurityProfileAIAgentsError, Creds | HttpClient.HttpClient, AIAgent>;
export type ListSecurityProfileApplicationsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of third-party applications or MCP Servers in a specific security profile.
 */
export declare const listSecurityProfileApplications: API.PaginatedOperationMethod<ListSecurityProfileApplicationsRequest, ListSecurityProfileApplicationsResponse, ListSecurityProfileApplicationsError, Creds | HttpClient.HttpClient, Application>;
export type ListSecurityProfileFlowModulesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * A list of Flow Modules an AI Agent can invoke as a tool
 */
export declare const listSecurityProfileFlowModules: API.PaginatedOperationMethod<ListSecurityProfileFlowModulesRequest, ListSecurityProfileFlowModulesResponse, ListSecurityProfileFlowModulesError, Creds | HttpClient.HttpClient, FlowModule>;
export type ListSecurityProfilePermissionsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the permissions granted to a security profile.
 *
 * For information about security profiles, see Security Profiles in the *Connect Customer Administrator Guide*. For a mapping of the API name and user interface name of the security
 * profile permissions, see List
 * of security profile permissions.
 */
export declare const listSecurityProfilePermissions: API.PaginatedOperationMethod<ListSecurityProfilePermissionsRequest, ListSecurityProfilePermissionsResponse, ListSecurityProfilePermissionsError, Creds | HttpClient.HttpClient, SecurityProfilePermission>;
export type ListSecurityProfilesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides summary information about the security profiles for the specified Connect Customer instance.
 *
 * For more information about security profiles, see Security Profiles in the *Connect Customer Administrator Guide*. For a mapping of the API name and user interface name of the security
 * profile permissions, see List
 * of security profile permissions.
 */
export declare const listSecurityProfiles: API.PaginatedOperationMethod<ListSecurityProfilesRequest, ListSecurityProfilesResponse, ListSecurityProfilesError, Creds | HttpClient.HttpClient, SecurityProfileSummary>;
export type ListTagsForResourceError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the tags for the specified resource.
 *
 * For sample policies that use tags, see Connect Customer Identity-Based Policy
 * Examples in the *Connect Customer Administrator Guide*.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Creds | HttpClient.HttpClient>;
export type ListTaskTemplatesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists task templates for the specified Connect Customer instance.
 */
export declare const listTaskTemplates: API.PaginatedOperationMethod<ListTaskTemplatesRequest, ListTaskTemplatesResponse, ListTaskTemplatesError, Creds | HttpClient.HttpClient, TaskTemplateMetadata>;
export type ListTestCaseExecutionRecordsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists detailed steps of test case execution that includes all observations along with actions taken and data associated in the specified Amazon Connect instance.
 */
export declare const listTestCaseExecutionRecords: API.OperationMethod<ListTestCaseExecutionRecordsRequest, ListTestCaseExecutionRecordsResponse, ListTestCaseExecutionRecordsError, Creds | HttpClient.HttpClient>;
export type ListTestCaseExecutionsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all test case executions and allows filtering by test case id, test case name, start time, end time or status of the execution for the specified Amazon Connect instance.
 */
export declare const listTestCaseExecutions: API.OperationMethod<ListTestCaseExecutionsRequest, ListTestCaseExecutionsResponse, ListTestCaseExecutionsError, Creds | HttpClient.HttpClient>;
export type ListTestCasesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the test cases present in the specific Amazon Connect instance.
 */
export declare const listTestCases: API.PaginatedOperationMethod<ListTestCasesRequest, ListTestCasesResponse, ListTestCasesError, Creds | HttpClient.HttpClient, TestCaseSummary>;
export type ListTrafficDistributionGroupsError = AccessDeniedException | InternalServiceException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Lists traffic distribution groups.
 */
export declare const listTrafficDistributionGroups: API.PaginatedOperationMethod<ListTrafficDistributionGroupsRequest, ListTrafficDistributionGroupsResponse, ListTrafficDistributionGroupsError, Creds | HttpClient.HttpClient, TrafficDistributionGroupSummary>;
export type ListTrafficDistributionGroupUsersError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists traffic distribution group users.
 */
export declare const listTrafficDistributionGroupUsers: API.PaginatedOperationMethod<ListTrafficDistributionGroupUsersRequest, ListTrafficDistributionGroupUsersResponse, ListTrafficDistributionGroupUsersError, Creds | HttpClient.HttpClient, TrafficDistributionGroupUserSummary>;
export type ListUseCasesError = InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the use cases for the integration association.
 */
export declare const listUseCases: API.PaginatedOperationMethod<ListUseCasesRequest, ListUseCasesResponse, ListUseCasesError, Creds | HttpClient.HttpClient, UseCase>;
export type ListUserHierarchyGroupsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides summary information about the hierarchy groups for the specified Connect Customer instance.
 *
 * For more information about agent hierarchies, see Set Up Agent Hierarchies in the *Connect Customer Administrator Guide*.
 */
export declare const listUserHierarchyGroups: API.PaginatedOperationMethod<ListUserHierarchyGroupsRequest, ListUserHierarchyGroupsResponse, ListUserHierarchyGroupsError, Creds | HttpClient.HttpClient, HierarchyGroupSummary>;
export type ListUserNotificationsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of notifications for a specific user, including the notification status for that user.
 */
export declare const listUserNotifications: API.OperationMethod<ListUserNotificationsRequest, ListUserNotificationsResponse, ListUserNotificationsError, Creds | HttpClient.HttpClient>;
export type ListUserProficienciesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists proficiencies associated with a user.
 */
export declare const listUserProficiencies: API.PaginatedOperationMethod<ListUserProficienciesRequest, ListUserProficienciesResponse, ListUserProficienciesError, Creds | HttpClient.HttpClient, UserProficiency>;
export type ListUsersError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides summary information about the users for the specified Connect Customer instance.
 */
export declare const listUsers: API.PaginatedOperationMethod<ListUsersRequest, ListUsersResponse, ListUsersError, Creds | HttpClient.HttpClient, UserSummary>;
export type ListViewsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns views in the given instance.
 *
 * Results are sorted primarily by type, and secondarily by name.
 */
export declare const listViews: API.PaginatedOperationMethod<ListViewsRequest, ListViewsResponse, ListViewsError, Creds | HttpClient.HttpClient, ViewSummary>;
export type ListViewVersionsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns all the available versions for the specified Connect Customer instance and view identifier.
 *
 * Results will be sorted from highest to lowest.
 */
export declare const listViewVersions: API.PaginatedOperationMethod<ListViewVersionsRequest, ListViewVersionsResponse, ListViewVersionsError, Creds | HttpClient.HttpClient, ViewVersionSummary>;
export type ListWorkspaceMediaError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists media assets (such as logos) associated with a workspace.
 */
export declare const listWorkspaceMedia: API.OperationMethod<ListWorkspaceMediaRequest, ListWorkspaceMediaResponse, ListWorkspaceMediaError, Creds | HttpClient.HttpClient>;
export type ListWorkspacePagesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the page configurations in a workspace, including the views assigned to each page.
 */
export declare const listWorkspacePages: API.PaginatedOperationMethod<ListWorkspacePagesRequest, ListWorkspacePagesResponse, ListWorkspacePagesError, Creds | HttpClient.HttpClient, WorkspacePage>;
export type ListWorkspacesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the workspaces in an Amazon Connect instance.
 */
export declare const listWorkspaces: API.PaginatedOperationMethod<ListWorkspacesRequest, ListWorkspacesResponse, ListWorkspacesError, Creds | HttpClient.HttpClient, WorkspaceSummary>;
export type MonitorContactError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Initiates silent monitoring of a contact. The Contact Control Panel (CCP) of the user specified by
 * *userId* will be set to silent monitoring mode on the contact.
 */
export declare const monitorContact: API.OperationMethod<MonitorContactRequest, MonitorContactResponse, MonitorContactError, Creds | HttpClient.HttpClient>;
export type PauseContactError = AccessDeniedException | ConflictException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Allows pausing an ongoing task contact.
 */
export declare const pauseContact: API.OperationMethod<PauseContactRequest, PauseContactResponse, PauseContactError, Creds | HttpClient.HttpClient>;
export type PutUserStatusError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Changes the current status of a user or agent in Connect Customer. If the agent is currently handling a
 * contact, this sets the agent's next status.
 *
 * For more information, see Agent status and Set your
 * next status in the *Connect Customer Administrator Guide*.
 */
export declare const putUserStatus: API.OperationMethod<PutUserStatusRequest, PutUserStatusResponse, PutUserStatusError, Creds | HttpClient.HttpClient>;
export type ReleasePhoneNumberError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidParameterException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Releases a phone number previously claimed to an Connect Customer instance or traffic distribution group. You can call this API
 * only in the Amazon Web Services Region where the number was claimed.
 *
 * To release phone numbers from a traffic distribution group, use the `ReleasePhoneNumber` API, not the Connect Customer admin website.
 *
 * After releasing a phone number, the phone number enters into a cooldown period for up to 180 days. It cannot be
 * searched for or claimed again until the period has ended. If you accidentally release a phone number, contact
 * Amazon Web Services Support.
 *
 * If you plan to claim and release numbers frequently,
 * contact us for a service quota exception. Otherwise, it is possible you will be blocked from
 * claiming and releasing any more numbers until up to 180 days past the oldest number
 * released has expired.
 *
 * By default you can claim and release up to 200% of your maximum number of active
 * phone numbers. If you claim and release phone numbers using
 * the UI or API during a rolling 180 day cycle that exceeds 200% of your phone number
 * service level quota, you will be blocked from claiming any more numbers until 180
 * days past the oldest number released has expired.
 *
 * For example, if you already have 99 claimed numbers and a service level quota of 99 phone numbers, and in any 180
 * day period you release 99, claim 99, and then release 99, you will have exceeded the
 * 200% limit. At that point you are blocked from claiming any more numbers until you
 * open an Amazon Web Services support ticket.
 */
export declare const releasePhoneNumber: API.OperationMethod<ReleasePhoneNumberRequest, ReleasePhoneNumberResponse, ReleasePhoneNumberError, Creds | HttpClient.HttpClient>;
export type ReplicateInstanceError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ResourceNotReadyException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Replicates an Connect Customer instance in the specified Amazon Web Services Region and copies configuration
 * information for Connect Customer resources across Amazon Web Services Regions.
 *
 * For more information about replicating an Connect Customer instance, see Create a replica of your existing Connect Customer
 * instance in the *Connect Customer Administrator Guide*.
 */
export declare const replicateInstance: API.OperationMethod<ReplicateInstanceRequest, ReplicateInstanceResponse, ReplicateInstanceError, Creds | HttpClient.HttpClient>;
export type ResumeContactError = AccessDeniedException | ConflictException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Allows resuming a task contact in a paused state.
 */
export declare const resumeContact: API.OperationMethod<ResumeContactRequest, ResumeContactResponse, ResumeContactError, Creds | HttpClient.HttpClient>;
export type ResumeContactRecordingError = InternalServiceException | InvalidActiveRegionException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * When a contact is being recorded, and the recording has been suspended using SuspendContactRecording, this API
 * resumes recording whatever recording is selected in the flow configuration: call, screen, or both. If only call
 * recording or only screen recording is enabled, then it would resume.
 *
 * Voice and screen recordings are supported.
 */
export declare const resumeContactRecording: API.OperationMethod<ResumeContactRecordingRequest, ResumeContactRecordingResponse, ResumeContactRecordingError, Creds | HttpClient.HttpClient>;
export type SearchAgentStatusesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches AgentStatuses in an Connect Customer instance, with optional filtering.
 */
export declare const searchAgentStatuses: API.PaginatedOperationMethod<SearchAgentStatusesRequest, SearchAgentStatusesResponse, SearchAgentStatusesError, Creds | HttpClient.HttpClient, AgentStatus>;
export type SearchAvailablePhoneNumbersError = AccessDeniedException | InternalServiceException | InvalidParameterException | ThrottlingException | CommonErrors;
/**
 * Searches for available phone numbers that you can claim to your Connect Customer instance or traffic distribution group. If the
 * provided `TargetArn` is a traffic distribution group, you can call this API in both Amazon Web Services Regions associated with
 * the traffic distribution group.
 */
export declare const searchAvailablePhoneNumbers: API.PaginatedOperationMethod<SearchAvailablePhoneNumbersRequest, SearchAvailablePhoneNumbersResponse, SearchAvailablePhoneNumbersError, Creds | HttpClient.HttpClient, AvailableNumberSummary>;
export type SearchContactEvaluationsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches contact evaluations in an Connect Customer instance, with optional filtering.
 *
 * **Use cases**
 *
 * Following are common uses cases for this API:
 *
 * - Find contact evaluations by using specific search criteria.
 *
 * - Find contact evaluations that are tagged with a specific set of tags.
 *
 * **Important things to know**
 *
 * - A Search operation, unlike a List operation, takes time to index changes to resource (create, update or
 * delete). If you don't see updated information for recently changed contact evaluations, try calling the API again
 * in a few seconds.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const searchContactEvaluations: API.OperationMethod<SearchContactEvaluationsRequest, SearchContactEvaluationsResponse, SearchContactEvaluationsError, Creds | HttpClient.HttpClient>;
export type SearchContactFlowModulesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches the flow modules in an Connect Customer instance, with optional filtering.
 */
export declare const searchContactFlowModules: API.PaginatedOperationMethod<SearchContactFlowModulesRequest, SearchContactFlowModulesResponse, SearchContactFlowModulesError, Creds | HttpClient.HttpClient, ContactFlowModule>;
export type SearchContactFlowsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches the flows in an Connect Customer instance, with optional filtering.
 */
export declare const searchContactFlows: API.PaginatedOperationMethod<SearchContactFlowsRequest, SearchContactFlowsResponse, SearchContactFlowsError, Creds | HttpClient.HttpClient, ContactFlow>;
export type SearchContactsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches contacts in an Connect Customer instance.
 */
export declare const searchContacts: API.PaginatedOperationMethod<SearchContactsRequest, SearchContactsResponse, SearchContactsError, Creds | HttpClient.HttpClient, ContactSearchSummary>;
export type SearchDataTablesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches for data tables based on the table's ID, name, and description. In the future, this operation can
 * support searching on attribute names and possibly primary values. Follows other search operations closely and
 * supports both search criteria and filters.
 */
export declare const searchDataTables: API.PaginatedOperationMethod<SearchDataTablesRequest, SearchDataTablesResponse, SearchDataTablesError, Creds | HttpClient.HttpClient, DataTable>;
export type SearchEmailAddressesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches email address in an instance, with optional filtering.
 */
export declare const searchEmailAddresses: API.OperationMethod<SearchEmailAddressesRequest, SearchEmailAddressesResponse, SearchEmailAddressesError, Creds | HttpClient.HttpClient>;
export type SearchEvaluationFormsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches evaluation forms in an Connect Customer instance, with optional filtering.
 *
 * **Use cases**
 *
 * Following are common uses cases for this API:
 *
 * - List all evaluation forms in an instance.
 *
 * - Find all evaluation forms that meet specific criteria, such as Title, Description, Status, and more.
 *
 * - Find all evaluation forms that are tagged with a specific set of tags.
 *
 * **Important things to know**
 *
 * - A Search operation, unlike a List operation, takes time to index changes to resource (create, update or
 * delete). If you don't see updated information for recently changed contact evaluations, try calling the API again
 * in a few seconds.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const searchEvaluationForms: API.OperationMethod<SearchEvaluationFormsRequest, SearchEvaluationFormsResponse, SearchEvaluationFormsError, Creds | HttpClient.HttpClient>;
export type SearchHoursOfOperationOverridesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches the hours of operation overrides.
 */
export declare const searchHoursOfOperationOverrides: API.PaginatedOperationMethod<SearchHoursOfOperationOverridesRequest, SearchHoursOfOperationOverridesResponse, SearchHoursOfOperationOverridesError, Creds | HttpClient.HttpClient, HoursOfOperationOverride>;
export type SearchHoursOfOperationsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches the hours of operation in an Connect Customer instance, with optional filtering.
 */
export declare const searchHoursOfOperations: API.PaginatedOperationMethod<SearchHoursOfOperationsRequest, SearchHoursOfOperationsResponse, SearchHoursOfOperationsError, Creds | HttpClient.HttpClient, HoursOfOperation>;
export type SearchMetricsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches for metrics in the specified Connect Customer instance using search criteria and optional tag-based filters. Use pagination to ensure that the operation returns quickly and successfully.
 */
export declare const searchMetrics: API.PaginatedOperationMethod<SearchMetricsRequest, SearchMetricsResponse, SearchMetricsError, Creds | HttpClient.HttpClient, MetricDefinition>;
export type SearchNotificationsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches for notifications based on specified criteria and filters. Returns a paginated list of notifications matching the search parameters, ordered by descending creation time. Supports filtering by content and tags.
 */
export declare const searchNotifications: API.OperationMethod<SearchNotificationsRequest, SearchNotificationsResponse, SearchNotificationsError, Creds | HttpClient.HttpClient>;
export type SearchPredefinedAttributesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches predefined attributes that meet certain criteria. A *predefined attribute* is made
 * up of a name and a value. You can use predefined attributes for:
 *
 * - Routing proficiency (for example, agent certification) that has predefined values (for example, a list of
 * possible certifications). For more information, see Create predefined attributes for routing contacts to
 * agents.
 *
 * - Contact information that varies between transfers or conferences, such as the name of the business unit
 * handling the contact. For more information, see Use contact segment attributes.
 *
 * For the predefined attributes per instance quota, see Connect Customer
 * quotas.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const searchPredefinedAttributes: API.PaginatedOperationMethod<SearchPredefinedAttributesRequest, SearchPredefinedAttributesResponse, SearchPredefinedAttributesError, Creds | HttpClient.HttpClient, PredefinedAttribute>;
export type SearchPromptsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches prompts in an Connect Customer instance, with optional filtering.
 */
export declare const searchPrompts: API.PaginatedOperationMethod<SearchPromptsRequest, SearchPromptsResponse, SearchPromptsError, Creds | HttpClient.HttpClient, Prompt>;
export type SearchQueuesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches queues in an Connect Customer instance, with optional filtering.
 */
export declare const searchQueues: API.PaginatedOperationMethod<SearchQueuesRequest, SearchQueuesResponse, SearchQueuesError, Creds | HttpClient.HttpClient, Queue>;
export type SearchQuickConnectsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches quick connects in an Connect Customer instance, with optional filtering.
 */
export declare const searchQuickConnects: API.PaginatedOperationMethod<SearchQuickConnectsRequest, SearchQuickConnectsResponse, SearchQuickConnectsError, Creds | HttpClient.HttpClient, QuickConnect>;
export type SearchResourceTagsError = InternalServiceException | InvalidParameterException | InvalidRequestException | MaximumResultReturnedException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches tags used in an Connect Customer instance using optional search criteria.
 */
export declare const searchResourceTags: API.PaginatedOperationMethod<SearchResourceTagsRequest, SearchResourceTagsResponse, SearchResourceTagsError, Creds | HttpClient.HttpClient, TagSet>;
export type SearchRoutingProfilesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches routing profiles in an Connect Customer instance, with optional filtering.
 *
 * `SearchRoutingProfiles` does not populate LastModifiedRegion, LastModifiedTime,
 * MediaConcurrencies.CrossChannelBehavior, and AgentAvailabilityTimer in its response, but DescribeRoutingProfile does.
 */
export declare const searchRoutingProfiles: API.PaginatedOperationMethod<SearchRoutingProfilesRequest, SearchRoutingProfilesResponse, SearchRoutingProfilesError, Creds | HttpClient.HttpClient, RoutingProfile>;
export type SearchRulesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches rules in an Connect Customer instance, with optional filtering.
 */
export declare const searchRules: API.PaginatedOperationMethod<SearchRulesRequest, SearchRulesResponse, SearchRulesError, Creds | HttpClient.HttpClient, RuleSearchSummary>;
export type SearchSecurityProfilesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches security profiles in an Connect Customer instance, with optional filtering.
 *
 * For information about security profiles, see Security Profiles in the *Connect Customer Administrator Guide*. For a mapping of the API name and user interface name of the security
 * profile permissions, see List
 * of security profile permissions.
 */
export declare const searchSecurityProfiles: API.PaginatedOperationMethod<SearchSecurityProfilesRequest, SearchSecurityProfilesResponse, SearchSecurityProfilesError, Creds | HttpClient.HttpClient, SecurityProfileSearchSummary>;
export type SearchTestCasesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches for test cases in the specified Amazon Connect instance, with optional filtering.
 */
export declare const searchTestCases: API.PaginatedOperationMethod<SearchTestCasesRequest, SearchTestCasesResponse, SearchTestCasesError, Creds | HttpClient.HttpClient, TestCase>;
export type SearchUserHierarchyGroupsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches UserHierarchyGroups in an Connect Customer instance, with optional filtering.
 *
 * The UserHierarchyGroup with `"LevelId": "0"` is the foundation for building levels on top of an
 * instance. It is not user-definable, nor is it visible in the UI.
 */
export declare const searchUserHierarchyGroups: API.PaginatedOperationMethod<SearchUserHierarchyGroupsRequest, SearchUserHierarchyGroupsResponse, SearchUserHierarchyGroupsError, Creds | HttpClient.HttpClient, HierarchyGroup>;
export type SearchUsersError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches users in an Connect Customer instance, with optional filtering.
 *
 * `AfterContactWorkTimeLimit` is returned in milliseconds.
 */
export declare const searchUsers: API.PaginatedOperationMethod<SearchUsersRequest, SearchUsersResponse, SearchUsersError, Creds | HttpClient.HttpClient, UserSearchSummary>;
export type SearchViewsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches views based on name, description, or tags.
 */
export declare const searchViews: API.PaginatedOperationMethod<SearchViewsRequest, SearchViewsResponse, SearchViewsError, Creds | HttpClient.HttpClient, View>;
export type SearchVocabulariesError = AccessDeniedException | InternalServiceException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Searches for vocabularies within a specific Connect Customer instance using `State`,
 * `NameStartsWith`, and `LanguageCode`.
 */
export declare const searchVocabularies: API.PaginatedOperationMethod<SearchVocabulariesRequest, SearchVocabulariesResponse, SearchVocabulariesError, Creds | HttpClient.HttpClient, VocabularySummary>;
export type SearchWorkspaceAssociationsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches for workspace associations with users or routing profiles based on various criteria.
 */
export declare const searchWorkspaceAssociations: API.PaginatedOperationMethod<SearchWorkspaceAssociationsRequest, SearchWorkspaceAssociationsResponse, SearchWorkspaceAssociationsError, Creds | HttpClient.HttpClient, WorkspaceAssociationSearchSummary>;
export type SearchWorkspacesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches workspaces based on name, description, visibility, or tags.
 */
export declare const searchWorkspaces: API.PaginatedOperationMethod<SearchWorkspacesRequest, SearchWorkspacesResponse, SearchWorkspacesError, Creds | HttpClient.HttpClient, WorkspaceSearchSummary>;
export type SendChatIntegrationEventError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Processes chat integration events from Amazon Web Services or external integrations to Connect Customer. A chat
 * integration event includes:
 *
 * - SourceId, DestinationId, and Subtype: a set of identifiers, uniquely representing a chat
 *
 * - ChatEvent: details of the chat action to perform such as sending a message, event, or disconnecting from a
 * chat
 *
 * When a chat integration event is sent with chat identifiers that do not map to an active chat contact, a new
 * chat contact is also created before handling chat action.
 *
 * Access to this API is currently restricted to Amazon Web Services End User Messaging for supporting SMS
 * integration.
 */
export declare const sendChatIntegrationEvent: API.OperationMethod<SendChatIntegrationEventRequest, SendChatIntegrationEventResponse, SendChatIntegrationEventError, Creds | HttpClient.HttpClient>;
export type SendOutboundEmailError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Send outbound email for outbound campaigns. For more information about outbound campaigns, see Set up Connect Customer
 * outbound campaigns.
 *
 * Only the Connect Customer outbound campaigns service principal is allowed to assume a role in your account
 * and call this API.
 */
export declare const sendOutboundEmail: API.OperationMethod<SendOutboundEmailRequest, SendOutboundEmailResponse, SendOutboundEmailError, Creds | HttpClient.HttpClient>;
export type SendOutboundWebNotificationError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Sends an outbound web notification to a customer's web browser for outbound campaigns. For more information
 * about outbound campaigns, see Set up Connect Customer outbound
 * campaigns.
 *
 * Only the Connect Customer outbound campaigns service principal is allowed to assume a role in your account
 * and call this API.
 */
export declare const sendOutboundWebNotification: API.OperationMethod<SendOutboundWebNotificationRequest, SendOutboundWebNotificationResponse, SendOutboundWebNotificationError, Creds | HttpClient.HttpClient>;
export type StartAssistantContactError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Starts a chat contact with an AI agent.
 *
 * Use the returned `ParticipantToken` with the CreateParticipantConnection operation.
 *
 * For more information about chat, see the following topics in the Connect Customer
 * Administrator Guide:
 *
 * - Concepts: Web and mobile messaging capabilities in Connect Customer
 *
 * - Connect Customer Chat security best practices
 */
export declare const startAssistantContact: API.OperationMethod<StartAssistantContactRequest, StartAssistantContactResponse, StartAssistantContactError, Creds | HttpClient.HttpClient>;
export type StartAttachedFileUploadError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Provides a pre-signed Amazon S3 URL in response for uploading your content.
 *
 * You may only use this API to upload attachments to a Connect Customer Case, Connect Customer Email, or
 * Connect Customer Task.
 */
export declare const startAttachedFileUpload: API.OperationMethod<StartAttachedFileUploadRequest, StartAttachedFileUploadResponse, StartAttachedFileUploadError, Creds | HttpClient.HttpClient>;
export type StartChatContactError = InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Initiates a flow to start a new chat for the customer. Response of this API provides a token required to obtain
 * credentials from the CreateParticipantConnection API in the Connect Customer Participant Service.
 *
 * When a new chat contact is successfully created, clients must subscribe to the participant's connection for the
 * created chat within 5 minutes. This is achieved by invoking CreateParticipantConnection with WEBSOCKET and CONNECTION_CREDENTIALS.
 *
 * To receive connection information directly in the response, set `ConnectionTypes` on the request. To
 * initiate real-time message streaming when the chat is created, set `ChatStreamingConfiguration` on the
 * request. Both parameters are optional.
 *
 * A 429 error occurs in the following situations:
 *
 * - API rate limit is exceeded. API TPS throttling returns a `TooManyRequests` exception.
 *
 * - The quota for
 * concurrent active chats is exceeded. Active chat throttling returns a
 * `LimitExceededException`.
 *
 * If you use the `ChatDurationInMinutes` parameter and receive a 400 error, your account may not
 * support the ability to configure custom chat durations. For more information, contact Amazon Web Services Support.
 *
 * For more information about chat, see the following topics in the Connect Customer
 * Administrator Guide:
 *
 * - Concepts: Web and mobile messaging capabilities in Connect Customer
 *
 * - Connect Customer Chat security best practices
 */
export declare const startChatContact: API.OperationMethod<StartChatContactRequest, StartChatContactResponse, StartChatContactError, Creds | HttpClient.HttpClient>;
export type StartContactConversationalAnalyticsJobError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Starts a Contact Lens post-call analytics job for the specified contact. This API runs Conversational
 * Analytics post-contact analysis on a voice recording that is already attached to the contact, generating
 * transcription, sentiment analysis, redaction, and summarization results based on the provided configuration.
 *
 * A voice recording must already be attached to the contact before calling this API. Use
 * `CreateAttachedFile` to attach a recording from an S3 source URI.
 *
 * For example, you can call `CreateContact`, then `CreateAttachedFile`, then
 * `StartContactConversationalAnalyticsJob` to create a contact, attach a recording, and
 * run post-call analytics.
 */
export declare const startContactConversationalAnalyticsJob: API.OperationMethod<StartContactConversationalAnalyticsJobRequest, StartContactConversationalAnalyticsJobResponse, StartContactConversationalAnalyticsJobError, Creds | HttpClient.HttpClient>;
export type StartContactEvaluationError = InternalServiceException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Starts an empty evaluation in the specified Connect Customer instance, using the given evaluation form for the
 * particular contact. The evaluation form version used for the contact evaluation corresponds to the currently
 * activated version. If no version is activated for the evaluation form, the contact evaluation cannot be started.
 */
export declare const startContactEvaluation: API.OperationMethod<StartContactEvaluationRequest, StartContactEvaluationResponse, StartContactEvaluationError, Creds | HttpClient.HttpClient>;
export type StartContactMediaProcessingError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Enables in-flight message processing for an ongoing chat session. Message processing will stay active for the
 * rest of the chat, even if an individual contact segment ends.
 */
export declare const startContactMediaProcessing: API.OperationMethod<StartContactMediaProcessingRequest, StartContactMediaProcessingResponse, StartContactMediaProcessingError, Creds | HttpClient.HttpClient>;
export type StartContactRecordingError = InternalServiceException | InvalidActiveRegionException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Starts recording the contact:
 *
 * - If the API is called *before* the agent joins the call, recording starts when the agent
 * joins the call.
 *
 * - If the API is called *after* the agent joins the call, recording starts at the time of the
 * API call.
 *
 * StartContactRecording is a one-time action. For example, if you use StopContactRecording to stop recording an
 * ongoing call, you can't use StartContactRecording to restart it. For scenarios where the recording has started and
 * you want to suspend and resume it, such as when collecting sensitive information (for example, a credit card number),
 * use SuspendContactRecording and ResumeContactRecording.
 *
 * You can use this API to override the recording behavior configured in the Set recording behavior block.
 *
 * Only voice recordings are supported at this time.
 */
export declare const startContactRecording: API.OperationMethod<StartContactRecordingRequest, StartContactRecordingResponse, StartContactRecordingError, Creds | HttpClient.HttpClient>;
export type StartContactStreamingError = InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Initiates real-time message streaming for a new chat contact.
 *
 * For more information about message streaming, see Enable real-time chat message streaming in the
 * *Connect Customer Administrator Guide*.
 *
 * For more information about chat, see the following topics in the Connect Customer
 * Administrator Guide:
 *
 * - Concepts: Web and mobile messaging capabilities in Connect Customer
 *
 * - Connect Customer Chat security best practices
 */
export declare const startContactStreaming: API.OperationMethod<StartContactStreamingRequest, StartContactStreamingResponse, StartContactStreamingError, Creds | HttpClient.HttpClient>;
export type StartEmailContactError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates an inbound email contact and initiates a flow to start the email contact for the customer. Response of
 * this API provides the ContactId of the email contact created.
 */
export declare const startEmailContact: API.OperationMethod<StartEmailContactRequest, StartEmailContactResponse, StartEmailContactError, Creds | HttpClient.HttpClient>;
export type StartEvaluationFormValidationError = InternalServiceException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Starts an asynchronous validation process for an evaluation form version in the specified Connect Customer
 * instance. The validation first performs structural checks on the form content (such as verifying required fields,
 * valid scoring configuration, and correct conditional logic), then asynchronously analyzes questions configured for
 * generative AI evaluation against a set of best practices. Use GetEvaluationFormValidation to
 * retrieve the status and results once the validation completes.
 */
export declare const startEvaluationFormValidation: API.OperationMethod<StartEvaluationFormValidationRequest, StartEvaluationFormValidationResponse, StartEvaluationFormValidationError, Creds | HttpClient.HttpClient>;
export type StartOutboundChatContactError = AccessDeniedException | ConflictException | InternalServiceException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Initiates a new outbound SMS or WhatsApp contact to a customer. Response of this API provides the
 * `ContactId` of the outbound SMS or WhatsApp contact created.
 *
 * **SourceEndpoint** only supports Endpoints with
 * `CONNECT_PHONENUMBER_ARN` as Type and **DestinationEndpoint** only supports
 * Endpoints with `TELEPHONE_NUMBER` as Type. **ContactFlowId** initiates the
 * flow to manage the new contact created.
 *
 * This API can be used to initiate outbound SMS or WhatsApp contacts for an agent, or it can also deflect
 * an ongoing contact to an outbound SMS or WhatsApp contact by using the StartOutboundChatContact Flow
 * Action.
 *
 * For more information about using SMS or WhatsApp in Connect Customer, see the following topics in
 * the *Connect Customer Administrator Guide*:
 *
 * - Set up SMS
 * messaging
 *
 * - Request an SMS-enabled phone
 * number through Amazon Web Services End User Messaging SMS
 *
 * - Set up WhatsApp
 * Business messaging
 */
export declare const startOutboundChatContact: API.OperationMethod<StartOutboundChatContactRequest, StartOutboundChatContactResponse, StartOutboundChatContactError, Creds | HttpClient.HttpClient>;
export type StartOutboundEmailContactError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Initiates a flow to send an agent reply or outbound email contact (created from the CreateContact API) to a
 * customer.
 */
export declare const startOutboundEmailContact: API.OperationMethod<StartOutboundEmailContactRequest, StartOutboundEmailContactResponse, StartOutboundEmailContactError, Creds | HttpClient.HttpClient>;
export type StartOutboundVoiceContactError = DestinationNotAllowedException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | OutboundContactNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Places an outbound call to a contact, and then initiates the flow. It performs the actions in the flow that's
 * specified (in `ContactFlowId`).
 *
 * Agents do not initiate the outbound API, which means that they do not dial the contact. If the flow places an
 * outbound call to a contact, and then puts the contact in queue, the call is then routed to the agent, like any other
 * inbound case.
 *
 * Dialing timeout for this operation can be configured with the "RingTimeoutInSeconds" parameter. If not
 * specified, the default dialing timeout will be 60 seconds which means if the call is not connected within 60 seconds,
 * it fails.
 *
 * UK numbers with a 447 prefix are not allowed by default. Before you can dial these UK mobile numbers, you must
 * submit a service quota increase request. For more information, see Connect Customer Service Quotas in the
 * *Connect Customer Administrator Guide*.
 *
 * Campaign calls are not allowed by default. Before you can make a call with `TrafficType` =
 * `CAMPAIGN`, you must submit a service quota increase request to the quota Connect Customer campaigns.
 *
 * For Preview dialing mode, only the Amazon Connect outbound campaigns service principal is allowed to assume a
 * role in your account and call this API with OutboundStrategy.
 */
export declare const startOutboundVoiceContact: API.OperationMethod<StartOutboundVoiceContactRequest, StartOutboundVoiceContactResponse, StartOutboundVoiceContactError, Creds | HttpClient.HttpClient>;
export type StartScreenSharingError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Starts screen sharing for a contact. For more information about screen sharing, see Set up in-app, web, video calling, and screen sharing
 * capabilities in the *Connect Customer Administrator Guide*.
 */
export declare const startScreenSharing: API.OperationMethod<StartScreenSharingRequest, StartScreenSharingResponse, StartScreenSharingError, Creds | HttpClient.HttpClient>;
export type StartTaskContactError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Initiates a flow to start a new task contact. For more information about task contacts, see Concepts: Tasks in Connect Customer in the
 * *Connect Customer Administrator Guide*.
 *
 * When using `PreviousContactId` and `RelatedContactId` input parameters, note the
 * following:
 *
 * - `PreviousContactId`
 *
 * - Any updates to user-defined task contact attributes on any contact linked through the same
 * `PreviousContactId` will affect every contact in the chain.
 *
 * - There can be a maximum of 12 linked task contacts in a chain. That is, 12 task contacts can be created that
 * share the same `PreviousContactId`.
 *
 * - `RelatedContactId`
 *
 * - Copies contact attributes from the related task contact to the new contact.
 *
 * - Any update on attributes in a new task contact does not update attributes on previous contact.
 *
 * - There's no limit on the number of task contacts that can be created that use the same
 * `RelatedContactId`.
 *
 * In addition, when calling StartTaskContact include only one of these parameters: `ContactFlowID`,
 * `QuickConnectID`, or `TaskTemplateID`. Only one parameter is required as long as the task
 * template has a flow configured to run it. If more than one parameter is specified, or only the
 * `TaskTemplateID` is specified but it does not have a flow configured, the request returns an error
 * because Connect Customer cannot identify the unique flow to run when the task is created.
 *
 * A `ServiceQuotaExceededException` occurs when the number of open tasks exceeds the active tasks quota
 * or there are already 12 tasks referencing the same `PreviousContactId`. For more information about service
 * quotas for task contacts, see Connect Customer service quotas in the
 * *Connect Customer Administrator Guide*.
 */
export declare const startTaskContact: API.OperationMethod<StartTaskContactRequest, StartTaskContactResponse, StartTaskContactError, Creds | HttpClient.HttpClient>;
export type StartTestCaseExecutionError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Starts executing a published test case.
 */
export declare const startTestCaseExecution: API.OperationMethod<StartTestCaseExecutionRequest, StartTestCaseExecutionResponse, StartTestCaseExecutionError, Creds | HttpClient.HttpClient>;
export type StartWebRTCContactError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Places an inbound in-app, web, or video call to a contact, and then initiates the flow. It performs the actions
 * in the flow that are specified (in ContactFlowId) and present in the Connect Customer instance (specified as
 * InstanceId).
 */
export declare const startWebRTCContact: API.OperationMethod<StartWebRTCContactRequest, StartWebRTCContactResponse, StartWebRTCContactError, Creds | HttpClient.HttpClient>;
export type StopContactError = ContactNotFoundException | InternalServiceException | InvalidActiveRegionException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Ends the specified contact. Use this API to stop queued callbacks. It does not work for voice contacts that use
 * the following initiation methods:
 *
 * - DISCONNECT
 *
 * - TRANSFER
 *
 * - QUEUE_TRANSFER
 *
 * - EXTERNAL_OUTBOUND
 *
 * - MONITOR
 *
 * Chat and task contacts can be terminated in any state, regardless of initiation method.
 */
export declare const stopContact: API.OperationMethod<StopContactRequest, StopContactResponse, StopContactError, Creds | HttpClient.HttpClient>;
export type StopContactMediaProcessingError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Stops in-flight message processing for an ongoing chat session.
 */
export declare const stopContactMediaProcessing: API.OperationMethod<StopContactMediaProcessingRequest, StopContactMediaProcessingResponse, StopContactMediaProcessingError, Creds | HttpClient.HttpClient>;
export type StopContactRecordingError = InternalServiceException | InvalidActiveRegionException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Stops recording a call when a contact is being recorded. StopContactRecording is a one-time action. If you use
 * StopContactRecording to stop recording an ongoing call, you can't use StartContactRecording to restart it. For
 * scenarios where the recording has started and you want to suspend it for sensitive information (for example, to
 * collect a credit card number), and then restart it, use SuspendContactRecording and ResumeContactRecording.
 *
 * Only voice recordings are supported at this time.
 */
export declare const stopContactRecording: API.OperationMethod<StopContactRecordingRequest, StopContactRecordingResponse, StopContactRecordingError, Creds | HttpClient.HttpClient>;
export type StopContactStreamingError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Ends message streaming on a specified contact. To restart message streaming on that contact, call the StartContactStreaming
 * API.
 */
export declare const stopContactStreaming: API.OperationMethod<StopContactStreamingRequest, StopContactStreamingResponse, StopContactStreamingError, Creds | HttpClient.HttpClient>;
export type StopTestCaseExecutionError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Stops a running test execution.
 */
export declare const stopTestCaseExecution: API.OperationMethod<StopTestCaseExecutionRequest, StopTestCaseExecutionResponse, StopTestCaseExecutionError, Creds | HttpClient.HttpClient>;
export type SubmitContactEvaluationError = InternalServiceException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Submits a contact evaluation in the specified Connect Customer instance. Answers included in the request are
 * merged with existing answers for the given evaluation. If no answers or notes are passed, the evaluation is submitted
 * with the existing answers and notes. You can delete an answer or note by passing an empty object (`{}`) to
 * the question identifier.
 *
 * If a contact evaluation is already in submitted state, this operation will trigger a resubmission.
 */
export declare const submitContactEvaluation: API.OperationMethod<SubmitContactEvaluationRequest, SubmitContactEvaluationResponse, SubmitContactEvaluationError, Creds | HttpClient.HttpClient>;
export type SuspendContactRecordingError = InternalServiceException | InvalidActiveRegionException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * When a contact is being recorded, this API suspends recording whatever is selected in the flow configuration:
 * call (IVR or agent), screen, or both. If only call recording or only screen recording is enabled, then it would be
 * suspended. For example, you might suspend the screen recording while collecting sensitive information, such as a
 * credit card number. Then use ResumeContactRecording to restart
 * recording the screen.
 *
 * The period of time that the recording is suspended is filled with silence in the final recording.
 *
 * Voice (IVR, agent) and screen recordings are supported.
 */
export declare const suspendContactRecording: API.OperationMethod<SuspendContactRecordingRequest, SuspendContactRecordingResponse, SuspendContactRecordingError, Creds | HttpClient.HttpClient>;
export type TagContactError = InternalServiceException | InvalidActiveRegionException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Adds the specified tags to the contact resource. For more information about this API is used, see Set up granular billing for a detailed
 * view of your Connect Customer usage.
 */
export declare const tagContact: API.OperationMethod<TagContactRequest, TagContactResponse, TagContactError, Creds | HttpClient.HttpClient>;
export type TagResourceError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Adds the specified tags to the specified resource.
 *
 * Some of the supported resource types are agents, routing profiles, queues, quick connects, flows, agent
 * statuses, hours of operation, phone numbers, security profiles, task templates, and custom metrics. For a complete list, see Tagging resources in Connect Customer.
 *
 * For sample policies that use tags, see Connect Customer Identity-Based Policy
 * Examples in the *Connect Customer Administrator Guide*.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Creds | HttpClient.HttpClient>;
export type TransferContactError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Transfers `TASK` or `EMAIL`
 * contacts from one agent or queue to another agent or queue at any point after a contact is
 * created. You can transfer a contact to another queue by providing the flow which orchestrates the contact to the
 * destination queue. This gives you more control over contact handling and helps you adhere to the service level
 * agreement (SLA) guaranteed to your customers.
 *
 * Note the following requirements:
 *
 * - Transfer is only supported for `TASK` and `EMAIL` contacts.
 *
 * - Do not use both `QueueId` and `UserId` in the same call.
 *
 * - The following flow types are supported: Inbound flow, Transfer to agent flow, and Transfer to queue
 * flow.
 *
 * - The `TransferContact` API can be called only on active contacts.
 *
 * - A contact cannot be transferred more than 11 times.
 */
export declare const transferContact: API.OperationMethod<TransferContactRequest, TransferContactResponse, TransferContactError, Creds | HttpClient.HttpClient>;
export type UntagContactError = InternalServiceException | InvalidActiveRegionException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the specified tags from the contact resource. For more information about this API is used, see Set up granular billing for a detailed
 * view of your Connect Customer usage.
 */
export declare const untagContact: API.OperationMethod<UntagContactRequest, UntagContactResponse, UntagContactError, Creds | HttpClient.HttpClient>;
export type UntagResourceError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the specified tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Creds | HttpClient.HttpClient>;
export type UpdateAgentStatusError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates agent status.
 */
export declare const updateAgentStatus: API.OperationMethod<UpdateAgentStatusRequest, UpdateAgentStatusResponse, UpdateAgentStatusError, Creds | HttpClient.HttpClient>;
export type UpdateAttachedFilesConfigurationError = AccessDeniedException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the attached files configuration for the specified Connect Customer instance and attachment scope.
 *
 * If no instance-specific configuration exists, this operation creates one. Partial updates are supported--only specified fields are updated, while unspecified fields retain their current values.
 */
export declare const updateAttachedFilesConfiguration: API.OperationMethod<UpdateAttachedFilesConfigurationRequest, UpdateAttachedFilesConfigurationResponse, UpdateAttachedFilesConfigurationError, Creds | HttpClient.HttpClient>;
export type UpdateAuthenticationProfileError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change. To
 * request access to this API, contact Amazon Web Services Support.
 *
 * Updates the selected authentication profile.
 */
export declare const updateAuthenticationProfile: API.OperationMethod<UpdateAuthenticationProfileRequest, UpdateAuthenticationProfileResponse, UpdateAuthenticationProfileError, Creds | HttpClient.HttpClient>;
export type UpdateContactError = AccessDeniedException | ConflictException | InternalServiceException | InvalidActiveRegionException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Adds or updates user-defined contact information associated with the specified contact. At least one field to be
 * updated must be present in the request.
 *
 * You can add or update user-defined contact information for both ongoing and completed contacts.
 */
export declare const updateContact: API.OperationMethod<UpdateContactRequest, UpdateContactResponse, UpdateContactError, Creds | HttpClient.HttpClient>;
export type UpdateContactAttributesError = InternalServiceException | InvalidActiveRegionException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Creates or updates user-defined contact
 * attributes associated with the specified contact.
 *
 * You can create or update user-defined attributes for both ongoing and completed contacts. For example, while the
 * call is active, you can update the customer's name or the reason the customer called. You can add notes about steps
 * that the agent took during the call that display to the next agent that takes the call. You can also update
 * attributes for a contact using data from your CRM application and save the data with the contact in Connect Customer. You could also flag calls for additional analysis, such as legal review or to identify abusive callers.
 *
 * Contact attributes are available in Connect Customer for 24 months, and are then deleted. For information
 * about contact record retention and the maximum size of the contact record attributes section, see Feature
 * specifications in the *Connect Customer Administrator Guide*.
 */
export declare const updateContactAttributes: API.OperationMethod<UpdateContactAttributesRequest, UpdateContactAttributesResponse, UpdateContactAttributesError, Creds | HttpClient.HttpClient>;
export type UpdateContactEvaluationError = InternalServiceException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates details about a contact evaluation in the specified Connect Customer instance. A contact evaluation
 * must be in draft state. Answers included in the request are merged with existing answers for the given evaluation. An
 * answer or note can be deleted by passing an empty object (`{}`) to the question identifier.
 */
export declare const updateContactEvaluation: API.OperationMethod<UpdateContactEvaluationRequest, UpdateContactEvaluationResponse, UpdateContactEvaluationError, Creds | HttpClient.HttpClient>;
export type UpdateContactFlowContentError = InternalServiceException | InvalidContactFlowException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the specified flow.
 *
 * You can also create and update flows using the Connect Customer
 * Flow language.
 *
 * Use the `$SAVED` alias in the request to describe the `SAVED` content of a Flow. For
 * example, `arn:aws:.../contact-flow/{id}:$SAVED`. After a flow is published, `$SAVED` needs to
 * be supplied to view saved content that has not been published.
 */
export declare const updateContactFlowContent: API.OperationMethod<UpdateContactFlowContentRequest, UpdateContactFlowContentResponse, UpdateContactFlowContentError, Creds | HttpClient.HttpClient>;
export type UpdateContactFlowMetadataError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates metadata about specified flow.
 */
export declare const updateContactFlowMetadata: API.OperationMethod<UpdateContactFlowMetadataRequest, UpdateContactFlowMetadataResponse, UpdateContactFlowMetadataError, Creds | HttpClient.HttpClient>;
export type UpdateContactFlowModuleAliasError = AccessDeniedException | ConditionalOperationFailedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a specific Aliases metadata, including the version it's tied to, it's name, and description.
 */
export declare const updateContactFlowModuleAlias: API.OperationMethod<UpdateContactFlowModuleAliasRequest, UpdateContactFlowModuleAliasResponse, UpdateContactFlowModuleAliasError, Creds | HttpClient.HttpClient>;
export type UpdateContactFlowModuleContentError = AccessDeniedException | InternalServiceException | InvalidContactFlowModuleException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates specified flow module for the specified Connect Customer instance.
 *
 * Use the `$SAVED` alias in the request to describe the `SAVED` content of a Flow. For
 * example, `arn:aws:.../contact-flow/{id}:$SAVED`. After a flow is published, `$SAVED` needs to
 * be supplied to view saved content that has not been published.
 */
export declare const updateContactFlowModuleContent: API.OperationMethod<UpdateContactFlowModuleContentRequest, UpdateContactFlowModuleContentResponse, UpdateContactFlowModuleContentError, Creds | HttpClient.HttpClient>;
export type UpdateContactFlowModuleMetadataError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates metadata about specified flow module.
 */
export declare const updateContactFlowModuleMetadata: API.OperationMethod<UpdateContactFlowModuleMetadataRequest, UpdateContactFlowModuleMetadataResponse, UpdateContactFlowModuleMetadataError, Creds | HttpClient.HttpClient>;
export type UpdateContactFlowNameError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The name of the flow.
 *
 * You can also create and update flows using the Connect Customer
 * Flow language.
 */
export declare const updateContactFlowName: API.OperationMethod<UpdateContactFlowNameRequest, UpdateContactFlowNameResponse, UpdateContactFlowNameError, Creds | HttpClient.HttpClient>;
export type UpdateContactRoutingDataError = AccessDeniedException | InternalServiceException | InvalidActiveRegionException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates routing priority and age on the contact (**QueuePriority** and **QueueTimeAdjustmentInSeconds**). These properties can be used to change a customer's position
 * in the queue. For example, you can move a contact to the back of the queue by setting a lower routing priority
 * relative to other contacts in queue; or you can move a contact to the front of the queue by increasing the routing
 * age which will make the contact look artificially older and therefore higher up in the first-in-first-out routing
 * order. Note that adjusting the routing age of a contact affects only its position in queue, and not its actual queue
 * wait time as reported through metrics. These properties can also be updated by using the Set routing priority / age flow
 * block.
 *
 * Either **QueuePriority** or **QueueTimeAdjustmentInSeconds** should be provided within the request body, but not both.
 */
export declare const updateContactRoutingData: API.OperationMethod<UpdateContactRoutingDataRequest, UpdateContactRoutingDataResponse, UpdateContactRoutingDataError, Creds | HttpClient.HttpClient>;
export type UpdateContactScheduleError = InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the scheduled time of a task contact that is already scheduled.
 */
export declare const updateContactSchedule: API.OperationMethod<UpdateContactScheduleRequest, UpdateContactScheduleResponse, UpdateContactScheduleError, Creds | HttpClient.HttpClient>;
export type UpdateContactTaskTemplateError = AccessDeniedException | InternalServiceException | InvalidRequestException | LimitExceededException | PropertyValidationException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Updates the task template association on an existing task contact. You can update the task template on a contact
 * before assignment to support tasks that are created without a template (for example Rules or disconnect flows) or change the agent interaction
 * form to represent the latest task data (for example an initial request that was submitted as a refund gets updated to
 * an account cancellation and requires a new template).
 *
 * This operation can only be used with task contacts that are in progress and not connected to an agent. A task
 * template can be updated a maximum of 5 times per contact.
 *
 * The task's references must be compatible with the fields of the target task template. If the target template has
 * a required field, the task must have a corresponding reference with a matching name and compatible type. The
 * following task template field types map to reference types:
 *
 * - `TEXT`, `TEXT_AREA`, `BOOLEAN`, and `SINGLE_SELECT` map to
 * references of type `STRING`.
 *
 * - `NUMBER` maps to references of type `NUMBER`.
 *
 * - `DATE_TIME` maps to references of type `DATE`.
 *
 * - `URL` maps to references of type `URL`.
 *
 * - `EMAIL` maps to references of type `EMAIL`.
 *
 * References corresponding to `TEXT` fields must be fewer than 512 characters.
 * `TEXT_AREA` fields must be fewer than 4,096 characters. `BOOLEAN` fields must have a value
 * of `true` or `false`.
 *
 * An `InvalidRequestException` occurs when `UpdateContactTaskTemplate` is called on a
 * connected or terminated task, when it is called on non-task contacts, and when the task contact already uses the
 * provided task template. A `PropertyValidationException` occurs when the task's references conflict with
 * the task template's fields, for example if the task is missing a reference that matches a required field, or if the
 * task has a reference that matches a required field's name but not its datatype.
 */
export declare const updateContactTaskTemplate: API.OperationMethod<UpdateContactTaskTemplateRequest, UpdateContactTaskTemplateResponse, UpdateContactTaskTemplateError, Creds | HttpClient.HttpClient>;
export type UpdateCrossRegionRoutingError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the cross-region routing configuration for an Amazon Connect Global Resiliency instance enabled
 * for global routing. When invoked with `IsolatedAll` set to `true`, this operation disables
 * cross-region routing, meaning contacts originating in one Region will no longer be routed to agents in
 * another Region.
 *
 * This operation is available only for Amazon Connect Global Resiliency instances enabled for global routing. Reporting and contact
 * search continue to operate globally after you use this operation.
 */
export declare const updateCrossRegionRouting: API.OperationMethod<UpdateCrossRegionRoutingRequest, UpdateCrossRegionRoutingResponse, UpdateCrossRegionRoutingError, Creds | HttpClient.HttpClient>;
export type UpdateDataTableAttributeError = AccessDeniedException | ConflictException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Updates all properties for an attribute using all properties from CreateDataTableAttribute. There are no other
 * granular update endpoints. It does not act as a patch operation - all properties must be provided. System managed
 * attributes are not mutable by customers. Changing an attribute's validation does not invalidate existing values since
 * validation only runs when values are created or updated.
 */
export declare const updateDataTableAttribute: API.OperationMethod<UpdateDataTableAttributeRequest, UpdateDataTableAttributeResponse, UpdateDataTableAttributeError, Creds | HttpClient.HttpClient>;
export type UpdateDataTableMetadataError = AccessDeniedException | ConflictException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the metadata properties of a data table. Accepts all fields similar to CreateDataTable, except for
 * fields and tags. There are no other granular update endpoints. It does not act as a patch operation - all properties
 * must be provided or defaults will be used. Fields follow the same requirements as CreateDataTable.
 */
export declare const updateDataTableMetadata: API.OperationMethod<UpdateDataTableMetadataRequest, UpdateDataTableMetadataResponse, UpdateDataTableMetadataError, Creds | HttpClient.HttpClient>;
export type UpdateDataTablePrimaryValuesError = AccessDeniedException | ConflictException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the primary values for a record. This operation affects all existing values that are currently
 * associated to the record and its primary values. Users that have restrictions on attributes and/or primary values are
 * not authorized to use this endpoint. The combination of new primary values must be unique within the table.
 */
export declare const updateDataTablePrimaryValues: API.OperationMethod<UpdateDataTablePrimaryValuesRequest, UpdateDataTablePrimaryValuesResponse, UpdateDataTablePrimaryValuesError, Creds | HttpClient.HttpClient>;
export type UpdateEmailAddressMetadataError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an email address metadata. For more information about email addresses, see Create email addresses in the Connect Customer
 * Administrator Guide.
 */
export declare const updateEmailAddressMetadata: API.OperationMethod<UpdateEmailAddressMetadataRequest, UpdateEmailAddressMetadataResponse, UpdateEmailAddressMetadataError, Creds | HttpClient.HttpClient>;
export type UpdateEvaluationFormError = InternalServiceException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Updates details about a specific evaluation form version in the specified Connect Customer instance. Question
 * and section identifiers cannot be duplicated within the same evaluation form.
 *
 * This operation does not support partial updates. Instead it does a full update of evaluation form
 * content.
 */
export declare const updateEvaluationForm: API.OperationMethod<UpdateEvaluationFormRequest, UpdateEvaluationFormResponse, UpdateEvaluationFormError, Creds | HttpClient.HttpClient>;
export type UpdateExtractionDefinitionError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an extraction definition in the specified Connect Customer instance.
 */
export declare const updateExtractionDefinition: API.OperationMethod<UpdateExtractionDefinitionRequest, UpdateExtractionDefinitionResponse, UpdateExtractionDefinitionError, Creds | HttpClient.HttpClient>;
export type UpdateHoursOfOperationError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the hours of operation.
 */
export declare const updateHoursOfOperation: API.OperationMethod<UpdateHoursOfOperationRequest, UpdateHoursOfOperationResponse, UpdateHoursOfOperationError, Creds | HttpClient.HttpClient>;
export type UpdateHoursOfOperationOverrideError = ConditionalOperationFailedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Update the hours of operation override.
 */
export declare const updateHoursOfOperationOverride: API.OperationMethod<UpdateHoursOfOperationOverrideRequest, UpdateHoursOfOperationOverrideResponse, UpdateHoursOfOperationOverrideError, Creds | HttpClient.HttpClient>;
export type UpdateInstanceAttributeError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Updates the value for the specified attribute type.
 */
export declare const updateInstanceAttribute: API.OperationMethod<UpdateInstanceAttributeRequest, UpdateInstanceAttributeResponse, UpdateInstanceAttributeError, Creds | HttpClient.HttpClient>;
export type UpdateInstanceStorageConfigError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Updates an existing configuration for a resource type. This API is idempotent.
 */
export declare const updateInstanceStorageConfig: API.OperationMethod<UpdateInstanceStorageConfigRequest, UpdateInstanceStorageConfigResponse, UpdateInstanceStorageConfigError, Creds | HttpClient.HttpClient>;
export type UpdateMetricContentError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the calculation, unit, and/or trend indicator of an existing metric in the specified Connect Customer instance.
 */
export declare const updateMetricContent: API.OperationMethod<UpdateMetricContentRequest, UpdateMetricContentResponse, UpdateMetricContentError, Creds | HttpClient.HttpClient>;
export type UpdateMetricMetadataError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the name and/or description of an existing metric in the specified Connect Customer instance.
 */
export declare const updateMetricMetadata: API.OperationMethod<UpdateMetricMetadataRequest, UpdateMetricMetadataResponse, UpdateMetricMetadataError, Creds | HttpClient.HttpClient>;
export type UpdateNotificationContentError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the localized content of an existing notification. This operation applies to all users for whom the notification was sent.
 */
export declare const updateNotificationContent: API.OperationMethod<UpdateNotificationContentRequest, UpdateNotificationContentResponse, UpdateNotificationContentError, Creds | HttpClient.HttpClient>;
export type UpdateParticipantAuthenticationError = AccessDeniedException | ConflictException | InternalServiceException | InvalidParameterException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Instructs Connect Customer to resume the authentication process. The subsequent actions depend on the request
 * body contents:
 *
 * - **If a code is provided**: Connect retrieves the identity information from Amazon
 * Cognito and imports it into Connect Customer Profiles.
 *
 * - **If an error is provided**: The error branch of the Authenticate Customer block
 * is executed.
 *
 * The API returns a success response to acknowledge the request. However, the interaction and exchange of
 * identity information occur asynchronously after the response is returned.
 */
export declare const updateParticipantAuthentication: API.OperationMethod<UpdateParticipantAuthenticationRequest, UpdateParticipantAuthenticationResponse, UpdateParticipantAuthenticationError, Creds | HttpClient.HttpClient>;
export type UpdateParticipantRoleConfigError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates timeouts for when human chat participants are to be considered idle, and when agents are automatically
 * disconnected from a chat due to idleness. You can set four timers:
 *
 * - Customer idle timeout
 *
 * - Customer auto-disconnect timeout
 *
 * - Agent idle timeout
 *
 * - Agent auto-disconnect timeout
 *
 * For more information about how chat timeouts work, see
 * Set up chat timeouts for human participants.
 */
export declare const updateParticipantRoleConfig: API.OperationMethod<UpdateParticipantRoleConfigRequest, UpdateParticipantRoleConfigResponse, UpdateParticipantRoleConfigError, Creds | HttpClient.HttpClient>;
export type UpdatePhoneNumberError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidParameterException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates your claimed phone number from its current Connect Customer instance or traffic distribution group to another Connect Customer instance or traffic distribution group in the same Amazon Web Services Region.
 *
 * After using this API, you must verify that the phone number is attached to the correct flow in the target
 * instance or traffic distribution group. You need to do this because the API switches only the phone number to a new
 * instance or traffic distribution group. It doesn't migrate the flow configuration of the phone number, too.
 *
 * You can call DescribePhoneNumber API to verify the status of a previous UpdatePhoneNumber operation.
 */
export declare const updatePhoneNumber: API.OperationMethod<UpdatePhoneNumberRequest, UpdatePhoneNumberResponse, UpdatePhoneNumberError, Creds | HttpClient.HttpClient>;
export type UpdatePhoneNumberMetadataError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a phone number's metadata.
 *
 * To verify the status of a previous UpdatePhoneNumberMetadata operation, call the DescribePhoneNumber API.
 */
export declare const updatePhoneNumberMetadata: API.OperationMethod<UpdatePhoneNumberMetadataRequest, UpdatePhoneNumberMetadataResponse, UpdatePhoneNumberMetadataError, Creds | HttpClient.HttpClient>;
export type UpdatePredefinedAttributeError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a predefined attribute for the specified Connect Customer instance. A *predefined attribute* is
 * made up of a name and a value.
 *
 * For the predefined attributes per instance quota, see Connect Customer
 * quotas.
 *
 * **Use cases**
 *
 * Following are common uses cases for this API:
 *
 * - Update routing proficiency (for example, agent certification) that has predefined values (for example, a list
 * of possible certifications). For more information, see Create predefined attributes for routing contacts to
 * agents.
 *
 * - Update an attribute for business unit name that has a list of predefined business unit names used in your
 * organization. This is a use case where information for a contact varies between transfers or conferences. For more
 * information, see Use contact segment attributes.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const updatePredefinedAttribute: API.OperationMethod<UpdatePredefinedAttributeRequest, UpdatePredefinedAttributeResponse, UpdatePredefinedAttributeError, Creds | HttpClient.HttpClient>;
export type UpdatePromptError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a prompt.
 */
export declare const updatePrompt: API.OperationMethod<UpdatePromptRequest, UpdatePromptResponse, UpdatePromptError, Creds | HttpClient.HttpClient>;
export type UpdateQueueHoursOfOperationError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the hours of operation for the specified queue.
 */
export declare const updateQueueHoursOfOperation: API.OperationMethod<UpdateQueueHoursOfOperationRequest, UpdateQueueHoursOfOperationResponse, UpdateQueueHoursOfOperationError, Creds | HttpClient.HttpClient>;
export type UpdateQueueMaxContactsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the maximum number of contacts allowed in a queue before it is considered full.
 */
export declare const updateQueueMaxContacts: API.OperationMethod<UpdateQueueMaxContactsRequest, UpdateQueueMaxContactsResponse, UpdateQueueMaxContactsError, Creds | HttpClient.HttpClient>;
export type UpdateQueueNameError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the name and description of a queue. At least `Name` or `Description` must be provided.
 */
export declare const updateQueueName: API.OperationMethod<UpdateQueueNameRequest, UpdateQueueNameResponse, UpdateQueueNameError, Creds | HttpClient.HttpClient>;
export type UpdateQueueOutboundCallerConfigError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the outbound caller ID name, number, and outbound whisper flow for a specified queue.
 *
 * - If the phone number is claimed to a traffic distribution group that was created in the
 * same Region as the Connect Customer instance where you are calling this API, then you can use a
 * full phone number ARN or a UUID for `OutboundCallerIdNumberId`. However, if the phone number is claimed
 * to a traffic distribution group that is in one Region, and you are calling this API from an instance in another Amazon Web Services Region that is associated with the traffic distribution group, you must provide a full phone number ARN. If a
 * UUID is provided in this scenario, you will receive a
 * `ResourceNotFoundException`.
 *
 * - Only use the phone number ARN format that doesn't contain `instance` in the path, for example,
 * `arn:aws:connect:us-east-1:1234567890:phone-number/uuid`. This is the same ARN format that is returned
 * when you call the ListPhoneNumbersV2 API.
 *
 * - If you plan to use IAM policies to allow/deny access to this API for phone number resources
 * claimed to a traffic distribution group, see Allow or Deny queue API actions for phone numbers in a replica Region.
 */
export declare const updateQueueOutboundCallerConfig: API.OperationMethod<UpdateQueueOutboundCallerConfigRequest, UpdateQueueOutboundCallerConfigResponse, UpdateQueueOutboundCallerConfigError, Creds | HttpClient.HttpClient>;
export type UpdateQueueOutboundEmailConfigError = AccessDeniedException | ConditionalOperationFailedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the outbound email address Id for a specified queue.
 */
export declare const updateQueueOutboundEmailConfig: API.OperationMethod<UpdateQueueOutboundEmailConfigRequest, UpdateQueueOutboundEmailConfigResponse, UpdateQueueOutboundEmailConfigError, Creds | HttpClient.HttpClient>;
export type UpdateQueueStatusError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the status of the queue.
 */
export declare const updateQueueStatus: API.OperationMethod<UpdateQueueStatusRequest, UpdateQueueStatusResponse, UpdateQueueStatusError, Creds | HttpClient.HttpClient>;
export type UpdateQuickConnectConfigError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the configuration settings for the specified quick connect.
 */
export declare const updateQuickConnectConfig: API.OperationMethod<UpdateQuickConnectConfigRequest, UpdateQuickConnectConfigResponse, UpdateQuickConnectConfigError, Creds | HttpClient.HttpClient>;
export type UpdateQuickConnectNameError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the name and description of a quick connect. The request accepts the following data in JSON format. At least `Name` or `Description` must be provided.
 */
export declare const updateQuickConnectName: API.OperationMethod<UpdateQuickConnectNameRequest, UpdateQuickConnectNameResponse, UpdateQuickConnectNameError, Creds | HttpClient.HttpClient>;
export type UpdateRoutingProfileAgentAvailabilityTimerError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Whether agents with this routing profile will have their routing order calculated based on time since
 * their last inbound contact or *longest idle time*.
 */
export declare const updateRoutingProfileAgentAvailabilityTimer: API.OperationMethod<UpdateRoutingProfileAgentAvailabilityTimerRequest, UpdateRoutingProfileAgentAvailabilityTimerResponse, UpdateRoutingProfileAgentAvailabilityTimerError, Creds | HttpClient.HttpClient>;
export type UpdateRoutingProfileConcurrencyError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the channels that agents can handle in the Contact Control Panel (CCP) for a routing profile.
 */
export declare const updateRoutingProfileConcurrency: API.OperationMethod<UpdateRoutingProfileConcurrencyRequest, UpdateRoutingProfileConcurrencyResponse, UpdateRoutingProfileConcurrencyError, Creds | HttpClient.HttpClient>;
export type UpdateRoutingProfileDefaultOutboundQueueError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the default outbound queue of a routing profile.
 */
export declare const updateRoutingProfileDefaultOutboundQueue: API.OperationMethod<UpdateRoutingProfileDefaultOutboundQueueRequest, UpdateRoutingProfileDefaultOutboundQueueResponse, UpdateRoutingProfileDefaultOutboundQueueError, Creds | HttpClient.HttpClient>;
export type UpdateRoutingProfileNameError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the name and description of a routing profile. The request accepts the following data in JSON format. At least `Name` or `Description` must be provided.
 */
export declare const updateRoutingProfileName: API.OperationMethod<UpdateRoutingProfileNameRequest, UpdateRoutingProfileNameResponse, UpdateRoutingProfileNameError, Creds | HttpClient.HttpClient>;
export type UpdateRoutingProfileQueuesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the properties associated with a set of queues for a routing profile.
 */
export declare const updateRoutingProfileQueues: API.OperationMethod<UpdateRoutingProfileQueuesRequest, UpdateRoutingProfileQueuesResponse, UpdateRoutingProfileQueuesError, Creds | HttpClient.HttpClient>;
export type UpdateRuleError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a rule for the specified Connect Customer instance.
 *
 * Use the Rules Function
 * language to code conditions for the rule.
 */
export declare const updateRule: API.OperationMethod<UpdateRuleRequest, UpdateRuleResponse, UpdateRuleError, Creds | HttpClient.HttpClient>;
export type UpdateSecurityProfileError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a security profile.
 *
 * For information about security profiles, see Security Profiles in the *Connect Customer Administrator Guide*. For a mapping of the API name and user interface name of the security
 * profile permissions, see List
 * of security profile permissions.
 */
export declare const updateSecurityProfile: API.OperationMethod<UpdateSecurityProfileRequest, UpdateSecurityProfileResponse, UpdateSecurityProfileError, Creds | HttpClient.HttpClient>;
export type UpdateTaskTemplateError = InternalServiceException | InvalidParameterException | PropertyValidationException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Updates details about a specific task template in the specified Connect Customer instance. This operation does
 * not support partial updates. Instead it does a full update of template content.
 */
export declare const updateTaskTemplate: API.OperationMethod<UpdateTaskTemplateRequest, UpdateTaskTemplateResponse, UpdateTaskTemplateError, Creds | HttpClient.HttpClient>;
export type UpdateTestCaseError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | InvalidTestCaseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates any of the metadata for a test case, such as the name, description, and status or content of an existing test case. This API doesn't allow customers to update the tags of the test case resource for the specified Amazon Connect instance.
 */
export declare const updateTestCase: API.OperationMethod<UpdateTestCaseRequest, UpdateTestCaseResponse, UpdateTestCaseError, Creds | HttpClient.HttpClient>;
export type UpdateTrafficDistributionError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the traffic distribution for a given traffic distribution group.
 *
 * When you shift telephony traffic, also shift agents and/or agent sign-ins to ensure they can handle the calls
 * in the other Region. If you don't shift the agents, voice calls will go to the shifted Region but there won't be any
 * agents available to receive the calls.
 *
 * The `SignInConfig` distribution is available only on a
 * default `TrafficDistributionGroup` (see the `IsDefault` parameter in the
 * TrafficDistributionGroup
 * data type). If you call
 * `UpdateTrafficDistribution` with a modified `SignInConfig` and a non-default `TrafficDistributionGroup`,
 * an `InvalidRequestException` is returned.
 *
 * For more information about updating a traffic distribution group, see Update telephony traffic distribution
 * across Amazon Web Services Regions
 * in the *Connect Customer Administrator Guide*.
 *
 * **Important things to know**
 *
 * - Invoke the UpdateTrafficDistribution API in the region that should handle traffic.
 */
export declare const updateTrafficDistribution: API.OperationMethod<UpdateTrafficDistributionRequest, UpdateTrafficDistributionResponse, UpdateTrafficDistributionError, Creds | HttpClient.HttpClient>;
export type UpdateUserConfigError = ConditionalOperationFailedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the configuration settings for the specified user, including per-channel auto-accept and after contact work (ACW) timeout settings.
 *
 * This operation replaces the UpdateUserPhoneConfig API. While UpdateUserPhoneConfig applies the same ACW timeout to all channels, UpdateUserConfig allows you to set different auto-accept and ACW timeout values for each channel type.
 */
export declare const updateUserConfig: API.OperationMethod<UpdateUserConfigRequest, UpdateUserConfigResponse, UpdateUserConfigError, Creds | HttpClient.HttpClient>;
export type UpdateUserHierarchyError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Assigns the specified hierarchy group to the specified user.
 */
export declare const updateUserHierarchy: API.OperationMethod<UpdateUserHierarchyRequest, UpdateUserHierarchyResponse, UpdateUserHierarchyError, Creds | HttpClient.HttpClient>;
export type UpdateUserHierarchyGroupNameError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the name of the user hierarchy group.
 */
export declare const updateUserHierarchyGroupName: API.OperationMethod<UpdateUserHierarchyGroupNameRequest, UpdateUserHierarchyGroupNameResponse, UpdateUserHierarchyGroupNameError, Creds | HttpClient.HttpClient>;
export type UpdateUserHierarchyStructureError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the user hierarchy structure: add, remove, and rename user hierarchy levels.
 */
export declare const updateUserHierarchyStructure: API.OperationMethod<UpdateUserHierarchyStructureRequest, UpdateUserHierarchyStructureResponse, UpdateUserHierarchyStructureError, Creds | HttpClient.HttpClient>;
export type UpdateUserIdentityInfoError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the identity information for the specified user.
 *
 * We strongly recommend limiting who has the ability to invoke `UpdateUserIdentityInfo`. Someone with
 * that ability can change the login credentials of other users by changing their email address. This poses a security
 * risk to your organization. They can change the email address of a user to the attacker's email address, and then
 * reset the password through email. For more information, see Best Practices for Security Profiles
 * in the *Connect Customer Administrator Guide*.
 */
export declare const updateUserIdentityInfo: API.OperationMethod<UpdateUserIdentityInfoRequest, UpdateUserIdentityInfoResponse, UpdateUserIdentityInfoError, Creds | HttpClient.HttpClient>;
export type UpdateUserNotificationStatusError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the status of a notification for a specific user, such as marking it as read or hidden. Users can only update notification status for notifications that have been sent to them. READ status deprioritizes the notification and greys it out, while HIDDEN status removes it from the notification widget.
 */
export declare const updateUserNotificationStatus: API.OperationMethod<UpdateUserNotificationStatusRequest, UpdateUserNotificationStatusResponse, UpdateUserNotificationStatusError, Creds | HttpClient.HttpClient>;
export type UpdateUserPhoneConfigError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the phone configuration settings for the specified user.
 *
 * We recommend using the UpdateUserConfig API, which supports additional functionality that is not available in the UpdateUserPhoneConfig API, such as voice enhancement settings and per-channel configuration for auto-accept and After Contact Work (ACW) timeouts. In comparison, the UpdateUserPhoneConfig API will always set the same ACW timeouts to all channels the user handles.
 */
export declare const updateUserPhoneConfig: API.OperationMethod<UpdateUserPhoneConfigRequest, UpdateUserPhoneConfigResponse, UpdateUserPhoneConfigError, Creds | HttpClient.HttpClient>;
export type UpdateUserProficienciesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the properties associated with the proficiencies of a user.
 */
export declare const updateUserProficiencies: API.OperationMethod<UpdateUserProficienciesRequest, UpdateUserProficienciesResponse, UpdateUserProficienciesError, Creds | HttpClient.HttpClient>;
export type UpdateUserRoutingProfileError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Assigns the specified routing profile to the specified user.
 */
export declare const updateUserRoutingProfile: API.OperationMethod<UpdateUserRoutingProfileRequest, UpdateUserRoutingProfileResponse, UpdateUserRoutingProfileError, Creds | HttpClient.HttpClient>;
export type UpdateUserSecurityProfilesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Assigns the specified security profiles to the specified user.
 */
export declare const updateUserSecurityProfiles: API.OperationMethod<UpdateUserSecurityProfilesRequest, UpdateUserSecurityProfilesResponse, UpdateUserSecurityProfilesError, Creds | HttpClient.HttpClient>;
export type UpdateViewContentError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the view content of the given view identifier in the specified Connect Customer instance.
 *
 * It performs content validation if `Status` is set to `SAVED` and performs full content
 * validation if `Status` is `PUBLISHED`. Note that the `$SAVED` alias' content will
 * always be updated, but the `$LATEST` alias' content will only be updated if `Status` is
 * `PUBLISHED`.
 */
export declare const updateViewContent: API.OperationMethod<UpdateViewContentRequest, UpdateViewContentResponse, UpdateViewContentError, Creds | HttpClient.HttpClient>;
export type UpdateViewMetadataError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the view metadata. Note that either `Name` or `Description` must be
 * provided.
 */
export declare const updateViewMetadata: API.OperationMethod<UpdateViewMetadataRequest, UpdateViewMetadataResponse, UpdateViewMetadataError, Creds | HttpClient.HttpClient>;
export type UpdateWorkspaceMetadataError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the metadata of a workspace, such as its name and description.
 */
export declare const updateWorkspaceMetadata: API.OperationMethod<UpdateWorkspaceMetadataRequest, UpdateWorkspaceMetadataResponse, UpdateWorkspaceMetadataError, Creds | HttpClient.HttpClient>;
export type UpdateWorkspacePageError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the configuration of a page in a workspace, including the associated view and input data.
 */
export declare const updateWorkspacePage: API.OperationMethod<UpdateWorkspacePageRequest, UpdateWorkspacePageResponse, UpdateWorkspacePageError, Creds | HttpClient.HttpClient>;
export type UpdateWorkspaceThemeError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the theme configuration for a workspace, including colors and styling.
 */
export declare const updateWorkspaceTheme: API.OperationMethod<UpdateWorkspaceThemeRequest, UpdateWorkspaceThemeResponse, UpdateWorkspaceThemeError, Creds | HttpClient.HttpClient>;
export type UpdateWorkspaceVisibilityError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the visibility setting of a workspace, controlling whether it is available to all users, assigned users
 * only, or none.
 */
export declare const updateWorkspaceVisibility: API.OperationMethod<UpdateWorkspaceVisibilityRequest, UpdateWorkspaceVisibilityResponse, UpdateWorkspaceVisibilityError, Creds | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=connect.d.ts.map