import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly fieldList: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type AgentSpaceId = string;
export type ArtifactType = "TXT" | "PNG" | "JPEG" | "MD" | "PDF" | "DOCX" | "DOC" | "JSON" | "YAML" | (string & {});
export interface AddArtifactInput {
    agentSpaceId: string;
    artifactContent: Uint8Array;
    artifactType: ArtifactType;
    fileName: string;
}
export type ArtifactId = string;
export interface AddArtifactOutput {
    artifactId: string;
}
export type SecurityRequirementPackId = string;
export type SecurityRequirementName = string;
export interface CreateSecurityRequirementEntry {
    name: string;
    description: string;
    domain: string;
    evaluation: string;
    remediation?: string;
}
export type CreateSecurityRequirementEntryList = CreateSecurityRequirementEntry[];
export interface BatchCreateSecurityRequirementsInput {
    packId: string;
    securityRequirements: CreateSecurityRequirementEntry[];
}
export interface BatchCreateSecurityRequirementResult {
    packId: string;
    name: string;
    description: string;
    domain: string;
    evaluation: string;
    remediation?: string;
    createdAt: Date;
    updatedAt: Date;
}
export type BatchCreateSecurityRequirementResultList = BatchCreateSecurityRequirementResult[];
export interface BatchSecurityRequirementError {
    securityRequirementName: string;
    code: string;
    message: string;
}
export type BatchSecurityRequirementErrors = BatchSecurityRequirementError[];
export interface BatchCreateSecurityRequirementsOutput {
    securityRequirements: BatchCreateSecurityRequirementResult[];
    errors: BatchSecurityRequirementError[];
}
export type CodeReviewIdList = string[];
export interface BatchDeleteCodeReviewsInput {
    codeReviewIds: string[];
    agentSpaceId: string;
}
export interface DeleteCodeReviewFailure {
    codeReviewId?: string;
    reason?: string;
}
export type DeleteCodeReviewFailureList = DeleteCodeReviewFailure[];
export interface BatchDeleteCodeReviewsOutput {
    deleted?: string[];
    failed?: DeleteCodeReviewFailure[];
}
export type PentestIdList = string[];
export interface BatchDeletePentestsInput {
    pentestIds: string[];
    agentSpaceId: string;
}
export interface Endpoint {
    uri?: string;
}
export type EndpointList = Endpoint[];
export type UriList = string[];
export type AuthenticationProviderType = "SECRETS_MANAGER" | "AWS_LAMBDA" | "AWS_IAM_ROLE" | "AWS_INTERNAL" | (string & {});
export interface Authentication {
    providerType?: AuthenticationProviderType;
    value?: string;
}
export type SensitiveEmailAddress = string | redacted.Redacted<string>;
export interface Actor {
    identifier?: string;
    uris?: string[];
    authentication?: Authentication;
    description?: string;
    enableEmailMfa?: boolean;
    mfaForwardingAddress?: string | redacted.Redacted<string>;
}
export type ActorList = Actor[];
export interface IntegratedDocument {
    integrationId: string;
    resourceId: string;
}
export interface DocumentInfo {
    s3Location?: string;
    artifactId?: string;
    integratedDocument?: IntegratedDocument;
}
export type DocumentList = DocumentInfo[];
export interface SourceCodeRepository {
    s3Location?: string;
}
export type SourceCodeRepositoryList = SourceCodeRepository[];
export interface IntegratedRepository {
    integrationId: string;
    providerResourceId: string;
    branch?: string;
}
export type IntegratedRepositoryList = IntegratedRepository[];
export type CaCertificatePem = string | redacted.Redacted<string>;
export type CaCertificateSource = {
    inlinePem: string | redacted.Redacted<string>;
    artifactId?: never;
    s3Location?: never;
} | {
    inlinePem?: never;
    artifactId: string;
    s3Location?: never;
} | {
    inlinePem?: never;
    artifactId?: never;
    s3Location: string;
};
export interface TrustedCaCertificate {
    source: CaCertificateSource;
}
export type TrustedCaCertificateList = TrustedCaCertificate[];
export interface Assets {
    endpoints?: Endpoint[];
    actors?: Actor[];
    documents?: DocumentInfo[];
    sourceCode?: SourceCodeRepository[];
    integratedRepositories?: IntegratedRepository[];
    trustedCaCertificates?: TrustedCaCertificate[];
}
export type RiskType = "CROSS_SITE_SCRIPTING" | "DEFAULT_CREDENTIALS" | "INSECURE_DIRECT_OBJECT_REFERENCE" | "PRIVILEGE_ESCALATION" | "SERVER_SIDE_TEMPLATE_INJECTION" | "COMMAND_INJECTION" | "CODE_INJECTION" | "SQL_INJECTION" | "ARBITRARY_FILE_UPLOAD" | "INSECURE_DESERIALIZATION" | "LOCAL_FILE_INCLUSION" | "INFORMATION_DISCLOSURE" | "PATH_TRAVERSAL" | "SERVER_SIDE_REQUEST_FORGERY" | "JSON_WEB_TOKEN_VULNERABILITIES" | "XML_EXTERNAL_ENTITY" | "FILE_DELETION" | "OTHER" | "GRAPHQL_VULNERABILITIES" | "BUSINESS_LOGIC_VULNERABILITIES" | "CRYPTOGRAPHIC_VULNERABILITIES" | "DENIAL_OF_SERVICE" | "FILE_ACCESS" | "FILE_CREATION" | "DATABASE_MODIFICATION" | "DATABASE_ACCESS" | "OUTBOUND_SERVICE_REQUEST" | "UNKNOWN" | (string & {});
export type RiskTypeList = RiskType[];
export type ServiceRole = string;
export interface CloudWatchLog {
    logGroup?: string;
    logStream?: string;
}
export type VpcArn = string;
export type SecurityGroupArn = string;
export type SecurityGroupArns = string[];
export type SubnetArn = string;
export type SubnetArns = string[];
export interface VpcConfig {
    vpcArn?: string;
    securityGroupArns?: string[];
    subnetArns?: string[];
}
export type NetworkTrafficRuleEffect = "ALLOW" | "DENY" | (string & {});
export type NetworkTrafficRuleType = "URL" | (string & {});
export interface NetworkTrafficRule {
    effect?: NetworkTrafficRuleEffect;
    pattern?: string;
    networkTrafficRuleType?: NetworkTrafficRuleType;
}
export type NetworkTrafficRuleList = NetworkTrafficRule[];
export interface CustomHeader {
    name?: string;
    value?: string;
}
export type CustomHeaderList = CustomHeader[];
export interface NetworkTrafficConfig {
    rules?: NetworkTrafficRule[];
    customHeaders?: CustomHeader[];
}
export type CodeRemediationStrategy = "AUTOMATIC" | "DISABLED" | (string & {});
export type CleanUpStrategy = "BEST_EFFORT_DELETE" | "RETAIN_ALL" | (string & {});
export type SkillType = "FINDING_PERSONALIZATION" | "LOGIN_OPTIMIZATION" | (string & {});
export type SkillTypeList = SkillType[];
export interface ReportDestination {
    integrationId: string;
    containerId: string;
    parentId?: string;
    documentId?: string;
}
export type RiskLevel = "UNKNOWN" | "INFORMATIONAL" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" | (string & {});
export type RiskLevelFilterList = RiskLevel[];
export type ConfidenceLevel = "FALSE_POSITIVE" | "UNCONFIRMED" | "LOW" | "MEDIUM" | "HIGH" | (string & {});
export type ConfidenceLevelFilterList = ConfidenceLevel[];
export type FindingStatus = "ACTIVE" | "RESOLVED" | "ACCEPTED" | "FALSE_POSITIVE" | (string & {});
export type FindingStatusFilterList = FindingStatus[];
export type RiskTypeFilterList = RiskType[];
export type ReportFilterValue = string;
export type ReportFilterList = string[];
export type TaskExecutionStatus = "IN_PROGRESS" | "ABORTED" | "COMPLETED" | "INTERNAL_ERROR" | "FAILED" | (string & {});
export type TaskExecutionStatusFilterList = TaskExecutionStatus[];
export interface ReportFilters {
    riskLevels?: RiskLevel[];
    confidenceLevels?: ConfidenceLevel[];
    statuses?: FindingStatus[];
    riskTypes?: RiskType[];
    findingTypes?: string[];
    taskStatuses?: TaskExecutionStatus[];
    annotationNotes?: boolean;
    complianceReport?: boolean;
}
export interface CiCdConfiguration {
    enabled?: boolean;
}
export interface Pentest {
    pentestId: string;
    agentSpaceId: string;
    title: string;
    assets: Assets;
    excludeRiskTypes?: RiskType[];
    serviceRole?: string;
    logConfig?: CloudWatchLog;
    vpcConfig?: VpcConfig;
    networkTrafficConfig?: NetworkTrafficConfig;
    codeRemediationStrategy?: CodeRemediationStrategy;
    cleanUpStrategy?: CleanUpStrategy;
    disableManagedSkills?: SkillType[];
    maxTaskHours?: number;
    reportDestination?: ReportDestination;
    reportFilters?: ReportFilters;
    cicdConfiguration?: CiCdConfiguration;
    createdAt?: Date;
    updatedAt?: Date;
}
export type PentestList = Pentest[];
export interface DeletePentestFailure {
    pentestId?: string;
    reason?: string;
}
export type DeletePentestFailureList = DeletePentestFailure[];
export interface BatchDeletePentestsOutput {
    deleted?: Pentest[];
    failed?: DeletePentestFailure[];
}
export type SecurityRequirementNameList = string[];
export interface BatchDeleteSecurityRequirementsInput {
    packId: string;
    securityRequirementNames: string[];
}
export interface BatchDeleteSecurityRequirementsOutput {
    deletedSecurityRequirementNames: string[];
    errors: BatchSecurityRequirementError[];
}
export type ThreatModelIdList = string[];
export interface BatchDeleteThreatModelsInput {
    threatModelIds: string[];
    agentSpaceId: string;
}
export interface DeleteThreatModelFailure {
    threatModelId?: string;
    reason?: string;
}
export type DeleteThreatModelFailureList = DeleteThreatModelFailure[];
export interface BatchDeleteThreatModelsOutput {
    deleted?: string[];
    failed?: DeleteThreatModelFailure[];
}
export type AgentSpaceIdList = string[];
export interface BatchGetAgentSpacesInput {
    agentSpaceIds: string[];
}
export type VpcConfigs = VpcConfig[];
export type LogGroupArn = string;
export type LogGroupArns = string[];
export type S3BucketArn = string;
export type S3BucketArns = string[];
export type SecretArn = string;
export type SecretArns = string[];
export type LambdaFunctionArn = string;
export type LambdaFunctionArns = string[];
export type IamRoles = string[];
export interface AWSResources {
    vpcs?: VpcConfig[];
    logGroups?: string[];
    s3Buckets?: string[];
    secretArns?: string[];
    lambdaFunctionArns?: string[];
    iamRoles?: string[];
}
export type TargetDomainIdList = string[];
export interface CodeReviewSettings {
    controlsScanning: boolean;
    generalPurposeScanning: boolean;
}
export type KmsKeyId = string;
export interface AgentSpace {
    agentSpaceId: string;
    name: string;
    description?: string;
    awsResources?: AWSResources;
    targetDomainIds?: string[];
    codeReviewSettings?: CodeReviewSettings;
    kmsKeyId?: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export type AgentSpaceList = AgentSpace[];
export interface BatchGetAgentSpacesOutput {
    agentSpaces?: AgentSpace[];
    notFound?: string[];
}
export type ArtifactIds = string[];
export interface BatchGetArtifactMetadataInput {
    agentSpaceId: string;
    artifactIds: string[];
}
export interface ArtifactMetadataItem {
    agentSpaceId: string;
    artifactId: string;
    fileName: string;
    updatedAt: Date;
}
export type ArtifactMetadataList = ArtifactMetadataItem[];
export interface BatchGetArtifactMetadataOutput {
    artifactMetadataList: ArtifactMetadataItem[];
}
export type CodeReviewJobIdList = string[];
export interface BatchGetCodeReviewJobsInput {
    codeReviewJobIds: string[];
    agentSpaceId: string;
}
export type JobStatus = "IN_PROGRESS" | "STOPPING" | "STOPPED" | "FAILED" | "COMPLETED" | (string & {});
export type StepName = "PREFLIGHT" | "STATIC_ANALYSIS" | "PENTEST" | "FINALIZING" | "VALIDATION" | (string & {});
export type StepStatus = "NOT_STARTED" | "IN_PROGRESS" | "COMPLETED" | "FAILED" | "STOPPED" | (string & {});
export interface Step {
    name?: StepName;
    status?: StepStatus;
    createdAt?: Date;
    updatedAt?: Date;
}
export type StepList = Step[];
export type ContextType = "ERROR" | "CLIENT_ERROR" | "WARNING" | "INFO" | (string & {});
export interface ExecutionContext {
    contextType?: ContextType;
    context?: string;
    timestamp?: Date;
}
export type ExecutionContextList = ExecutionContext[];
export type ErrorCode = "CLIENT_ERROR" | "INTERNAL_ERROR" | "STOPPED_BY_USER" | (string & {});
export interface ErrorInformation {
    code?: ErrorCode;
    message?: string;
}
export interface CodeReviewJob {
    codeReviewJobId?: string;
    codeReviewId?: string;
    title?: string;
    overview?: string;
    status?: JobStatus;
    documents?: DocumentInfo[];
    sourceCode?: SourceCodeRepository[];
    steps?: Step[];
    executionContext?: ExecutionContext[];
    serviceRole?: string;
    logConfig?: CloudWatchLog;
    errorInformation?: ErrorInformation;
    integratedRepositories?: IntegratedRepository[];
    codeRemediationStrategy?: CodeRemediationStrategy;
    maxTaskHours?: number;
    reportDestination?: ReportDestination;
    createdAt?: Date;
    updatedAt?: Date;
}
export type CodeReviewJobList = CodeReviewJob[];
export interface BatchGetCodeReviewJobsOutput {
    codeReviewJobs?: CodeReviewJob[];
    notFound?: string[];
}
export type TaskIdList = string[];
export interface BatchGetCodeReviewJobTasksInput {
    agentSpaceId: string;
    codeReviewJobTaskIds: string[];
}
export interface Category {
    name?: string;
    isPrimary?: boolean;
}
export type CategoryList = Category[];
export type LogType = "CLOUDWATCH" | (string & {});
export interface LogLocation {
    logType?: LogType;
    cloudWatchLog?: CloudWatchLog;
}
export interface CodeReviewJobTask {
    taskId: string;
    codeReviewId?: string;
    codeReviewJobId?: string;
    agentSpaceId?: string;
    title?: string;
    description?: string;
    categories?: Category[];
    riskType?: RiskType;
    executionStatus?: TaskExecutionStatus;
    logsLocation?: LogLocation;
    createdAt?: Date;
    updatedAt?: Date;
}
export type CodeReviewJobTaskList = CodeReviewJobTask[];
export interface BatchGetCodeReviewJobTasksOutput {
    codeReviewJobTasks?: CodeReviewJobTask[];
    notFound?: string[];
}
export interface BatchGetCodeReviewsInput {
    codeReviewIds: string[];
    agentSpaceId: string;
}
export type ValidationMode = "DISABLED" | "SIMULATED" | (string & {});
export interface CodeReview {
    codeReviewId: string;
    agentSpaceId: string;
    title: string;
    assets: Assets;
    serviceRole?: string;
    logConfig?: CloudWatchLog;
    codeRemediationStrategy?: CodeRemediationStrategy;
    validationMode?: ValidationMode;
    maxTaskHours?: number;
    reportDestination?: ReportDestination;
    reportFilters?: ReportFilters;
    createdAt?: Date;
    updatedAt?: Date;
}
export type CodeReviewList = CodeReview[];
export interface BatchGetCodeReviewsOutput {
    codeReviews?: CodeReview[];
    notFound?: string[];
}
export type FindingIdList = string[];
export interface BatchGetFindingsInput {
    findingIds: string[];
    agentSpaceId: string;
}
export type ValidationStatus = "CONFIRMED" | "NOT_REPRODUCED" | "VALIDATION_FAILED" | "VALIDATING" | "NOT_VALIDATED" | (string & {});
export type CodeRemediationTaskStatus = "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export interface CodeRemediationTaskDetails {
    repoName?: string;
    codeDiffLink?: string;
    pullRequestLink?: string;
}
export type CodeRemediationTaskDetailsList = CodeRemediationTaskDetails[];
export interface CodeRemediationTask {
    status: CodeRemediationTaskStatus;
    statusReason?: string;
    taskDetails?: CodeRemediationTaskDetails[];
}
export interface CodeLocation {
    filePath: string;
    lineStart?: number;
    lineEnd?: number;
    label?: string;
}
export type CodeLocationList = CodeLocation[];
export interface VerificationScriptEnvVar {
    name?: string;
    value?: string;
}
export type VerificationScriptEnvVarList = VerificationScriptEnvVar[];
export interface VerificationScript {
    scriptType?: string;
    scriptUrl?: string;
    instructions?: string;
    envVars?: VerificationScriptEnvVar[];
}
export type StringList = string[];
export interface Finding {
    findingId: string;
    agentSpaceId: string;
    pentestId?: string;
    pentestJobId?: string;
    codeReviewId?: string;
    codeReviewJobId?: string;
    taskId?: string;
    name?: string;
    description?: string;
    status?: FindingStatus;
    riskType?: string;
    riskLevel?: RiskLevel;
    riskScore?: string;
    reasoning?: string;
    confidence?: ConfidenceLevel;
    validationStatus?: ValidationStatus;
    attackScript?: string;
    codeRemediationTask?: CodeRemediationTask;
    lastUpdatedBy?: string;
    customerNote?: string;
    codeLocations?: CodeLocation[];
    verificationScript?: VerificationScript;
    alignmentRationale?: string;
    revalidationJobIds?: string[];
    originalFindingId?: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export type FindingList = Finding[];
export interface BatchGetFindingsOutput {
    findings?: Finding[];
    notFound?: string[];
}
export type PentestJobIdList = string[];
export interface BatchGetPentestJobsInput {
    pentestJobIds: string[];
    agentSpaceId: string;
}
export type JobType = "FULL" | "REVALIDATION" | "CICD" | (string & {});
export type ScopeDecision = "IN_SCOPE" | "SCOPED_OUT" | "SCOPE_CONFLICT" | (string & {});
export interface ScopeResult {
    decision: ScopeDecision;
    reason: string;
}
export interface ScopeChange {
    integrationId: string;
    providerResourceId: string;
    baseCommitSha?: string;
    headCommitSha: string;
    triggerRunId?: string;
}
export type ScopeChangeList = ScopeChange[];
export interface PentestJob {
    pentestJobId?: string;
    pentestId?: string;
    title?: string;
    overview?: string;
    status?: JobStatus;
    endpoints?: Endpoint[];
    actors?: Actor[];
    documents?: DocumentInfo[];
    sourceCode?: SourceCodeRepository[];
    excludePaths?: Endpoint[];
    allowedDomains?: Endpoint[];
    excludeRiskTypes?: RiskType[];
    steps?: Step[];
    executionContext?: ExecutionContext[];
    serviceRole?: string;
    logConfig?: CloudWatchLog;
    vpcConfig?: VpcConfig;
    networkTrafficConfig?: NetworkTrafficConfig;
    errorInformation?: ErrorInformation;
    integratedRepositories?: IntegratedRepository[];
    trustedCaCertificates?: TrustedCaCertificate[];
    codeRemediationStrategy?: CodeRemediationStrategy;
    cleanUpStrategy?: CleanUpStrategy;
    disableManagedSkills?: SkillType[];
    maxTaskHours?: number;
    jobType?: JobType;
    selectedFindingIds?: string[];
    reportDestination?: ReportDestination;
    reportUrl?: string;
    scopeResult?: ScopeResult;
    scopeChanges?: ScopeChange[];
    cicdConfiguration?: CiCdConfiguration;
    createdAt?: Date;
    updatedAt?: Date;
}
export type PentestJobList = PentestJob[];
export interface BatchGetPentestJobsOutput {
    pentestJobs?: PentestJob[];
    notFound?: string[];
}
export interface BatchGetPentestJobTasksInput {
    agentSpaceId: string;
    taskIds: string[];
}
export interface Task {
    taskId: string;
    pentestId?: string;
    pentestJobId?: string;
    agentSpaceId?: string;
    title?: string;
    description?: string;
    categories?: Category[];
    riskType?: RiskType;
    targetEndpoint?: Endpoint;
    executionStatus?: TaskExecutionStatus;
    logsLocation?: LogLocation;
    taskHours?: number;
    createdAt?: Date;
    updatedAt?: Date;
}
export type TaskList = Task[];
export interface BatchGetPentestJobTasksOutput {
    tasks?: Task[];
    notFound?: string[];
}
export interface BatchGetPentestsInput {
    pentestIds: string[];
    agentSpaceId: string;
}
export interface BatchGetPentestsOutput {
    pentests?: Pentest[];
    notFound?: string[];
}
export interface BatchGetSecurityRequirementsInput {
    packId: string;
    securityRequirementNames: string[];
}
export interface BatchGetSecurityRequirementResult {
    packId: string;
    name: string;
    description: string;
    domain: string;
    evaluation: string;
    remediation?: string;
    createdAt: Date;
    updatedAt: Date;
}
export type BatchGetSecurityRequirementResultList = BatchGetSecurityRequirementResult[];
export interface BatchGetSecurityRequirementsOutput {
    securityRequirements: BatchGetSecurityRequirementResult[];
    errors: BatchSecurityRequirementError[];
}
export interface BatchGetTargetDomainsInput {
    targetDomainIds: string[];
}
export type TargetDomainId = string;
export type TargetDomainStatus = "PENDING" | "VERIFIED" | "FAILED" | "UNREACHABLE" | (string & {});
export type DomainVerificationMethod = "DNS_TXT" | "HTTP_ROUTE" | "PRIVATE_VPC" | (string & {});
export type DNSRecordType = "TXT" | (string & {});
export interface DnsVerification {
    token?: string;
    dnsRecordName?: string;
    dnsRecordType?: DNSRecordType;
}
export interface HttpVerification {
    token?: string;
    routePath?: string;
}
export interface VerificationDetails {
    method?: DomainVerificationMethod;
    dnsTxt?: DnsVerification;
    httpRoute?: HttpVerification;
}
export interface TargetDomain {
    targetDomainId: string;
    domainName: string;
    verificationStatus?: TargetDomainStatus;
    verificationStatusReason?: string;
    verificationDetails?: VerificationDetails;
    createdAt?: Date;
    verifiedAt?: Date;
}
export type TargetDomainList = TargetDomain[];
export interface BatchGetTargetDomainsOutput {
    targetDomains?: TargetDomain[];
    notFound?: string[];
}
export type ThreatModelJobIdList = string[];
export interface BatchGetThreatModelJobsInput {
    threatModelJobIds: string[];
    agentSpaceId: string;
}
export interface ThreatModelJob {
    threatModelJobId?: string;
    threatModelId?: string;
    agentSpaceId?: string;
    title?: string;
    status?: JobStatus;
    createdAt?: Date;
    updatedAt?: Date;
    executionStartTime?: Date;
    executionEndTime?: Date;
    sourceCode?: SourceCodeRepository[];
    integratedRepositories?: IntegratedRepository[];
    documents?: DocumentInfo[];
    scopeDocs?: DocumentInfo[];
    errorInformation?: ErrorInformation;
    systemOverview?: string;
    reportDestination?: ReportDestination;
}
export type ThreatModelJobList = ThreatModelJob[];
export interface BatchGetThreatModelJobsOutput {
    threatModelJobs?: ThreatModelJob[];
    notFound?: string[];
}
export interface BatchGetThreatModelJobTasksInput {
    agentSpaceId: string;
    threatModelJobTaskIds: string[];
}
export interface ThreatModelJobTask {
    taskId: string;
    threatModelId?: string;
    threatModelJobId?: string;
    agentSpaceId?: string;
    title?: string;
    description?: string;
    executionStatus?: TaskExecutionStatus;
    logsLocation?: LogLocation;
    createdAt?: Date;
    updatedAt?: Date;
}
export type ThreatModelJobTaskList = ThreatModelJobTask[];
export interface BatchGetThreatModelJobTasksOutput {
    threatModelJobTasks?: ThreatModelJobTask[];
    notFound?: string[];
}
export interface BatchGetThreatModelsInput {
    threatModelIds: string[];
    agentSpaceId: string;
}
export interface ThreatModel {
    threatModelId: string;
    agentSpaceId: string;
    title: string;
    description?: string;
    assets: Assets;
    scopeDocs?: DocumentInfo[];
    serviceRole?: string;
    logConfig?: CloudWatchLog;
    reportDestination?: ReportDestination;
    createdAt?: Date;
    updatedAt?: Date;
}
export type ThreatModelList = ThreatModel[];
export interface BatchGetThreatModelsOutput {
    threatModels?: ThreatModel[];
    notFound?: string[];
}
export type ThreatIdList = string[];
export interface BatchGetThreatsInput {
    threatIds: string[];
    agentSpaceId: string;
}
export type ThreatSeverity = "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "INFO" | (string & {});
export type ThreatStatus = "OPEN" | "RESOLVED" | "DISMISSED" | (string & {});
export interface ThreatAnchorShape {
    kind?: string;
    id?: string;
    packageId?: string;
}
export interface ThreatEvidenceShape {
    packageId?: string;
    path?: string;
}
export type ThreatEvidenceList = ThreatEvidenceShape[];
export type StrideCategory = "SPOOFING" | "TAMPERING" | "REPUDIATION" | "INFORMATION_DISCLOSURE" | "DENIAL_OF_SERVICE" | "ELEVATION_OF_PRIVILEGE" | (string & {});
export type StrideCategoryList = StrideCategory[];
export type ThreatActor = "CUSTOMER" | "AGENT" | (string & {});
export interface Threat {
    threatId?: string;
    threatJobId?: string;
    title?: string;
    statement?: string;
    severity?: ThreatSeverity;
    status?: ThreatStatus;
    comments?: string;
    threatSource?: string;
    prerequisites?: string;
    threatAction?: string;
    threatImpact?: string;
    impactedGoal?: string[];
    impactedAssets?: string[];
    anchor?: ThreatAnchorShape;
    evidence?: ThreatEvidenceShape[];
    stride?: StrideCategory[];
    recommendation?: string;
    createdBy?: ThreatActor;
    updatedBy?: ThreatActor;
    createdAt?: Date;
    updatedAt?: Date;
}
export type ThreatList = Threat[];
export interface BatchGetThreatsOutput {
    threats?: Threat[];
    notFound?: string[];
}
export interface UpdateSecurityRequirementEntry {
    name: string;
    description?: string;
    domain?: string;
    evaluation?: string;
    remediation?: string;
}
export type UpdateSecurityRequirementEntryList = UpdateSecurityRequirementEntry[];
export interface BatchUpdateSecurityRequirementsInput {
    packId: string;
    securityRequirements: UpdateSecurityRequirementEntry[];
}
export interface BatchUpdateSecurityRequirementsOutput {
    updatedSecurityRequirementNames: string[];
    errors: BatchSecurityRequirementError[];
}
export type AgentName = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateAgentSpaceInput {
    name: string;
    description?: string;
    awsResources?: AWSResources;
    targetDomainIds?: string[];
    codeReviewSettings?: CodeReviewSettings;
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateAgentSpaceOutput {
    agentSpaceId: string;
    name: string;
    description?: string;
    awsResources?: AWSResources;
    targetDomainIds?: string[];
    codeReviewSettings?: CodeReviewSettings;
    kmsKeyId?: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export type IdCInstanceArn = string;
export type RoleArn = string;
export type DefaultKmsKeyId = string;
export interface CreateApplicationRequest {
    idcInstanceArn?: string;
    roleArn?: string;
    defaultKmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type ApplicationId = string;
export interface CreateApplicationResponse {
    applicationId: string;
}
export interface CreateCodeReviewInput {
    title: string;
    agentSpaceId: string;
    assets: Assets;
    serviceRole?: string;
    logConfig?: CloudWatchLog;
    codeRemediationStrategy?: CodeRemediationStrategy;
    validationMode?: ValidationMode;
    maxTaskHours?: number;
    reportDestination?: ReportDestination;
    reportFilters?: ReportFilters;
}
export interface CreateCodeReviewOutput {
    codeReviewId: string;
    title?: string;
    createdAt?: Date;
    updatedAt?: Date;
    assets?: Assets;
    serviceRole?: string;
    logConfig?: CloudWatchLog;
    agentSpaceId?: string;
    codeRemediationStrategy?: CodeRemediationStrategy;
    validationMode?: ValidationMode;
    maxTaskHours?: number;
    reportDestination?: ReportDestination;
    reportFilters?: ReportFilters;
}
export type Provider = "GITHUB" | "GITLAB" | "BITBUCKET" | "CONFLUENCE" | "AZURE_DEVOPS" | (string & {});
export type AuthCode = string;
export type CsrfState = string;
export type TargetUrl = string;
export interface GitHubIntegrationInput {
    code: string;
    state: string;
    organizationName?: string;
    targetUrl?: string;
    installationId?: string;
}
export type AccessToken = string | redacted.Redacted<string>;
export type GitLabTokenType = "PERSONAL" | "GROUP" | (string & {});
export interface GitLabIntegrationInput {
    accessToken: string | redacted.Redacted<string>;
    targetUrl?: string;
    tokenType: GitLabTokenType;
    groupId?: string;
}
export type BitbucketInstallationId = string;
export type BitbucketWorkspace = string;
export interface BitbucketIntegrationInput {
    installationId: string;
    workspace: string;
    code: string;
    state: string;
}
export type ConfluenceInstallationId = string;
export type ConfluenceSiteUrl = string;
export interface ConfluenceIntegrationInput {
    installationId: string;
    code: string;
    state: string;
    siteUrl: string;
}
export interface AzureDevOpsIntegrationInput {
    code: string;
    state: string;
    organizationName: string;
}
export interface BitbucketDataCenterIntegrationInput {
    targetUrl: string;
    code: string;
    state: string;
}
export type ProviderInput = {
    github: GitHubIntegrationInput;
    gitlab?: never;
    bitbucket?: never;
    confluence?: never;
    azureDevOps?: never;
    bitbucketDataCenter?: never;
} | {
    github?: never;
    gitlab: GitLabIntegrationInput;
    bitbucket?: never;
    confluence?: never;
    azureDevOps?: never;
    bitbucketDataCenter?: never;
} | {
    github?: never;
    gitlab?: never;
    bitbucket: BitbucketIntegrationInput;
    confluence?: never;
    azureDevOps?: never;
    bitbucketDataCenter?: never;
} | {
    github?: never;
    gitlab?: never;
    bitbucket?: never;
    confluence: ConfluenceIntegrationInput;
    azureDevOps?: never;
    bitbucketDataCenter?: never;
} | {
    github?: never;
    gitlab?: never;
    bitbucket?: never;
    confluence?: never;
    azureDevOps: AzureDevOpsIntegrationInput;
    bitbucketDataCenter?: never;
} | {
    github?: never;
    gitlab?: never;
    bitbucket?: never;
    confluence?: never;
    azureDevOps?: never;
    bitbucketDataCenter: BitbucketDataCenterIntegrationInput;
};
export type PrivateConnectionName = string;
export interface CreateIntegrationInput {
    provider: Provider;
    input: ProviderInput;
    integrationDisplayName: string;
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    privateConnectionName?: string;
}
export type IntegrationId = string;
export interface CreateIntegrationOutput {
    integrationId: string;
}
export type MembershipId = string;
export type MembershipType = "USER" | (string & {});
export type UserRole = "MEMBER" | (string & {});
export interface UserConfig {
    role?: UserRole;
}
export type MembershipConfig = {
    user: UserConfig;
};
export interface CreateMembershipRequest {
    applicationId: string;
    agentSpaceId: string;
    membershipId: string;
    memberType: MembershipType;
    config?: MembershipConfig;
}
export interface CreateMembershipResponse {
}
export interface CreatePentestInput {
    title: string;
    agentSpaceId: string;
    assets?: Assets;
    excludeRiskTypes?: RiskType[];
    serviceRole?: string;
    logConfig?: CloudWatchLog;
    vpcConfig?: VpcConfig;
    networkTrafficConfig?: NetworkTrafficConfig;
    codeRemediationStrategy?: CodeRemediationStrategy;
    disableManagedSkills?: SkillType[];
    maxTaskHours?: number;
    reportDestination?: ReportDestination;
    reportFilters?: ReportFilters;
    cicdConfiguration?: CiCdConfiguration;
}
export interface CreatePentestOutput {
    pentestId?: string;
    title?: string;
    createdAt?: Date;
    updatedAt?: Date;
    assets?: Assets;
    excludeRiskTypes?: RiskType[];
    serviceRole?: string;
    logConfig?: CloudWatchLog;
    agentSpaceId?: string;
    reportDestination?: ReportDestination;
    reportFilters?: ReportFilters;
    cicdConfiguration?: CiCdConfiguration;
}
export type HostAddress = string;
export type PrivateConnectionVpcId = string;
export type PrivateConnectionSubnetId = string;
export type PrivateConnectionSubnetIds = string[];
export type PrivateConnectionSecurityGroupId = string;
export type PrivateConnectionSecurityGroupIds = string[];
export type IpAddressType = "IPV4" | "IPV6" | "DUAL_STACK" | (string & {});
export type MaxIpv4AddressesPerEni = number;
export type PortRange = string;
export type PortRanges = string[];
export type CertificateChain = string | redacted.Redacted<string>;
export type ResourceConfigDnsResolution = "PUBLIC" | "IN_VPC" | (string & {});
export interface ServiceManagedInput {
    hostAddress: string;
    vpcId: string;
    subnetIds: string[];
    securityGroupIds?: string[];
    ipAddressType?: IpAddressType;
    ipv4AddressesPerEni?: number;
    portRanges?: string[];
    certificate?: string | redacted.Redacted<string>;
    dnsResolution?: ResourceConfigDnsResolution;
}
export type ResourceConfigurationId = string;
export interface SelfManagedInput {
    resourceConfigurationId: string;
    certificate?: string | redacted.Redacted<string>;
}
export type PrivateConnectionMode = {
    serviceManaged: ServiceManagedInput;
    selfManaged?: never;
} | {
    serviceManaged?: never;
    selfManaged: SelfManagedInput;
};
export interface CreatePrivateConnectionInput {
    privateConnectionName: string;
    mode: PrivateConnectionMode;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type PrivateConnectionType = "SERVICE_MANAGED" | "SELF_MANAGED" | (string & {});
export type PrivateConnectionStatus = "ACTIVE" | "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | (string & {});
export type ResourceGatewayId = string;
export interface CreatePrivateConnectionOutput {
    name: string;
    type: PrivateConnectionType;
    status: PrivateConnectionStatus;
    resourceGatewayId?: string;
    hostAddress?: string;
    vpcId?: string;
    resourceConfigurationId?: string;
    certificateExpiryTime?: Date;
    dnsResolution?: ResourceConfigDnsResolution;
    failureMessage?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type SecurityRequirementPackName = string;
export type SecurityRequirementPackStatus = "ENABLED" | "DISABLED" | (string & {});
export interface CreateSecurityRequirementPackInput {
    name: string;
    description?: string;
    status?: SecurityRequirementPackStatus;
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateSecurityRequirementPackOutput {
    packId: string;
    status: SecurityRequirementPackStatus;
    kmsKeyId?: string;
}
export interface CreateTargetDomainInput {
    targetDomainName: string;
    verificationMethod: DomainVerificationMethod;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateTargetDomainOutput {
    targetDomainId: string;
    domainName: string;
    verificationStatus: TargetDomainStatus;
    verificationStatusReason?: string;
    verificationDetails?: VerificationDetails;
    createdAt?: Date;
    verifiedAt?: Date;
}
export interface CreateThreatInput {
    agentSpaceId: string;
    threatJobId: string;
    title?: string;
    statement?: string;
    severity?: ThreatSeverity;
    comments?: string;
    stride?: StrideCategory[];
    threatSource?: string;
    prerequisites?: string;
    threatAction?: string;
    threatImpact?: string;
    impactedGoal?: string[];
    impactedAssets?: string[];
    anchor?: ThreatAnchorShape;
    evidence?: ThreatEvidenceShape[];
    recommendation?: string;
}
export interface CreateThreatOutput {
    threatId: string;
    threatJobId: string;
    title?: string;
    statement?: string;
    severity?: ThreatSeverity;
    status?: ThreatStatus;
    comments?: string;
    stride?: StrideCategory[];
    threatSource?: string;
    prerequisites?: string;
    threatAction?: string;
    threatImpact?: string;
    impactedGoal?: string[];
    impactedAssets?: string[];
    anchor?: ThreatAnchorShape;
    evidence?: ThreatEvidenceShape[];
    recommendation?: string;
    createdBy?: ThreatActor;
    updatedBy?: ThreatActor;
    createdAt?: Date;
    updatedAt?: Date;
}
export interface CreateThreatModelInput {
    title: string;
    agentSpaceId: string;
    description?: string;
    assets?: Assets;
    scopeDocs?: DocumentInfo[];
    serviceRole: string;
    logConfig?: CloudWatchLog;
    reportDestination?: ReportDestination;
}
export interface CreateThreatModelOutput {
    threatModelId: string;
    title?: string;
    agentSpaceId?: string;
    description?: string;
    assets?: Assets;
    scopeDocs?: DocumentInfo[];
    serviceRole?: string;
    logConfig?: CloudWatchLog;
    createdAt?: Date;
    updatedAt?: Date;
    reportDestination?: ReportDestination;
}
export interface DeleteAgentSpaceInput {
    agentSpaceId: string;
}
export interface DeleteAgentSpaceOutput {
    agentSpaceId?: string;
}
export interface DeleteApplicationRequest {
    applicationId: string;
}
export interface DeleteApplicationResponse {
}
export interface DeleteArtifactInput {
    agentSpaceId: string;
    artifactId: string;
}
export interface DeleteArtifactOutput {
}
export interface DeleteIntegrationInput {
    integrationId: string;
}
export interface DeleteIntegrationOutput {
}
export interface DeleteMembershipRequest {
    applicationId: string;
    agentSpaceId: string;
    membershipId: string;
    memberType?: MembershipType;
}
export interface DeleteMembershipResponse {
}
export interface DeletePrivateConnectionInput {
    privateConnectionName: string;
}
export interface DeletePrivateConnectionOutput {
    name: string;
    type: PrivateConnectionType;
    status: PrivateConnectionStatus;
    resourceGatewayId?: string;
    hostAddress?: string;
    vpcId?: string;
    resourceConfigurationId?: string;
    certificateExpiryTime?: Date;
    dnsResolution?: ResourceConfigDnsResolution;
    failureMessage?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface DeleteSecurityRequirementPackInput {
    packId: string;
}
export interface DeleteSecurityRequirementPackOutput {
}
export interface DeleteTargetDomainInput {
    targetDomainId: string;
}
export interface DeleteTargetDomainOutput {
    targetDomainId?: string;
}
export interface DescribePrivateConnectionInput {
    privateConnectionName: string;
}
export interface DescribePrivateConnectionOutput {
    name: string;
    type: PrivateConnectionType;
    status: PrivateConnectionStatus;
    resourceGatewayId?: string;
    hostAddress?: string;
    vpcId?: string;
    resourceConfigurationId?: string;
    certificateExpiryTime?: Date;
    dnsResolution?: ResourceConfigDnsResolution;
    failureMessage?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetApplicationRequest {
    applicationId: string;
}
export type ApplicationDomain = string;
export type IdCApplicationArn = string;
export interface IdCConfiguration {
    idcApplicationArn?: string;
    idcInstanceArn?: string;
}
export interface GetApplicationResponse {
    applicationId: string;
    domain: string;
    applicationName?: string;
    idcConfiguration?: IdCConfiguration;
    roleArn?: string;
    defaultKmsKeyId?: string;
}
export interface GetArtifactInput {
    agentSpaceId: string;
    artifactId: string;
}
export interface Artifact {
    contents: string;
    type: ArtifactType;
}
export interface GetArtifactOutput {
    agentSpaceId: string;
    artifactId: string;
    artifact: Artifact;
    fileName: string;
    updatedAt: Date;
}
export interface GetIntegrationInput {
    integrationId: string;
}
export type ProviderType = "SOURCE_CODE" | "DOCUMENTATION" | (string & {});
export interface GetIntegrationOutput {
    integrationId: string;
    installationId: string;
    provider: Provider;
    providerType: ProviderType;
    displayName?: string;
    kmsKeyId?: string;
    targetUrl?: string;
    webhookUrl?: string;
    privateConnectionName?: string;
}
export interface GetSecurityRequirementPackInput {
    packId: string;
}
export type ManagementType = "AWS_MANAGED" | "CUSTOMER_MANAGED" | (string & {});
export type SecurityRequirementPackImportStatus = "PENDING" | "IN_PROGRESS" | "FAILED" | "COMPLETED" | (string & {});
export interface GetSecurityRequirementPackOutput {
    packId: string;
    name: string;
    description?: string;
    vendorName?: string;
    managementType: ManagementType;
    status: SecurityRequirementPackStatus;
    importStatus?: SecurityRequirementPackImportStatus;
    createdAt: Date;
    updatedAt: Date;
    kmsKeyId?: string;
}
export type SecurityRequirementArtifactName = string;
export type SecurityRequirementArtifactFormat = "MD" | "PDF" | "TXT" | "DOCX" | "DOC" | (string & {});
export type SecurityRequirementDocumentContent = Uint8Array | redacted.Redacted<Uint8Array>;
export interface SecurityRequirementArtifact {
    name: string;
    format: SecurityRequirementArtifactFormat;
    content: Uint8Array | redacted.Redacted<Uint8Array>;
}
export type SecurityRequirementArtifactList = SecurityRequirementArtifact[];
export type ImportSource = {
    documents: SecurityRequirementArtifact[];
};
export interface ImportSecurityRequirementsInput {
    packId: string;
    input: ImportSource;
}
export interface ImportSecurityRequirementsOutput {
    packId: string;
    importStatus: SecurityRequirementPackImportStatus;
}
export type ClientId = string;
export type ClientSecret = string | redacted.Redacted<string>;
export interface InitiateProviderRegistrationInput {
    provider: Provider;
    targetUrl?: string;
    organizationName?: string;
    clientId?: string;
    clientSecret?: string | redacted.Redacted<string>;
}
export type Location = string;
export interface InitiateProviderRegistrationOutput {
    redirectTo: string;
    csrfState: string;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListActorMessagesInput {
    maxResults?: number;
    nextToken?: string;
    agentSpaceId: string;
    pentestId: string;
    actorIdentifier: string;
}
export type SensitiveMessageSender = string | redacted.Redacted<string>;
export type SensitiveMessageSubject = string | redacted.Redacted<string>;
export type SensitiveMessageBody = string | redacted.Redacted<string>;
export interface ActorMessage {
    sender?: string | redacted.Redacted<string>;
    subject?: string | redacted.Redacted<string>;
    body?: string | redacted.Redacted<string>;
    receivedAt?: Date;
}
export type ActorMessageList = ActorMessage[];
export interface ListActorMessagesOutput {
    messages?: ActorMessage[];
    nextToken?: string;
}
export interface ListAgentSpacesInput {
    nextToken?: string;
    maxResults?: number;
}
export interface AgentSpaceSummary {
    agentSpaceId: string;
    name: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export type AgentSpaceSummaryList = AgentSpaceSummary[];
export interface ListAgentSpacesOutput {
    agentSpaceSummaries?: AgentSpaceSummary[];
    nextToken?: string;
}
export interface ListApplicationsRequest {
    nextToken?: string;
    maxResults?: number;
}
export interface ApplicationSummary {
    applicationId: string;
    applicationName: string;
    domain: string;
    defaultKmsKeyId?: string;
}
export type ApplicationSummaryList = ApplicationSummary[];
export interface ListApplicationsResponse {
    applicationSummaries: ApplicationSummary[];
    nextToken?: string;
}
export interface ListArtifactsInput {
    agentSpaceId: string;
    nextToken?: string;
    maxResults?: number;
}
export interface ArtifactSummary {
    artifactId: string;
    fileName: string;
    artifactType: ArtifactType;
}
export type ArtifactSummaryList = ArtifactSummary[];
export interface ListArtifactsOutput {
    artifactSummaries: ArtifactSummary[];
    nextToken?: string;
}
export interface ListCodeReviewJobsForCodeReviewInput {
    maxResults?: number;
    codeReviewId: string;
    agentSpaceId: string;
    nextToken?: string;
}
export interface CodeReviewJobSummary {
    codeReviewJobId: string;
    codeReviewId: string;
    title?: string;
    status?: JobStatus;
    createdAt?: Date;
    updatedAt?: Date;
}
export type CodeReviewJobSummaryList = CodeReviewJobSummary[];
export interface ListCodeReviewJobsForCodeReviewOutput {
    codeReviewJobSummaries?: CodeReviewJobSummary[];
    nextToken?: string;
}
export interface ListCodeReviewJobTasksInput {
    agentSpaceId: string;
    maxResults?: number;
    codeReviewJobId?: string;
    stepName?: StepName;
    categoryName?: string;
    nextToken?: string;
}
export interface CodeReviewJobTaskSummary {
    taskId: string;
    codeReviewId?: string;
    codeReviewJobId?: string;
    agentSpaceId?: string;
    title?: string;
    riskType?: RiskType;
    executionStatus?: TaskExecutionStatus;
    createdAt?: Date;
    updatedAt?: Date;
}
export type CodeReviewJobTaskSummaryList = CodeReviewJobTaskSummary[];
export interface ListCodeReviewJobTasksOutput {
    codeReviewJobTaskSummaries?: CodeReviewJobTaskSummary[];
    nextToken?: string;
}
export interface ListCodeReviewsInput {
    maxResults?: number;
    nextToken?: string;
    agentSpaceId: string;
}
export interface CodeReviewSummary {
    codeReviewId: string;
    agentSpaceId: string;
    title: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export type CodeReviewSummaryList = CodeReviewSummary[];
export interface ListCodeReviewsOutput {
    codeReviewSummaries?: CodeReviewSummary[];
    nextToken?: string;
}
export interface ListDiscoveredEndpointsInput {
    maxResults?: number;
    pentestJobId: string;
    agentSpaceId: string;
    prefix?: string;
    nextToken?: string;
}
export interface DiscoveredEndpoint {
    uri: string;
    pentestJobId: string;
    taskId: string;
    agentSpaceId: string;
    evidence?: string;
    operation?: string;
    description?: string;
}
export type DiscoveredEndpointList = DiscoveredEndpoint[];
export interface ListDiscoveredEndpointsOutput {
    discoveredEndpoints?: DiscoveredEndpoint[];
    nextToken?: string;
}
export interface ListFindingsInput {
    maxResults?: number;
    pentestJobId?: string;
    codeReviewJobId?: string;
    agentSpaceId: string;
    nextToken?: string;
    riskType?: string;
    riskLevel?: RiskLevel;
    status?: FindingStatus;
    confidence?: ConfidenceLevel;
    name?: string;
}
export interface FindingSummary {
    findingId: string;
    agentSpaceId: string;
    pentestId?: string;
    pentestJobId?: string;
    codeReviewId?: string;
    codeReviewJobId?: string;
    name?: string;
    status?: FindingStatus;
    riskType?: string;
    riskLevel?: RiskLevel;
    confidence?: ConfidenceLevel;
    validationStatus?: ValidationStatus;
    createdAt?: Date;
    updatedAt?: Date;
}
export type FindingSummaryList = FindingSummary[];
export interface ListFindingsOutput {
    findingsSummaries?: FindingSummary[];
    nextToken?: string;
}
export type ResourceType = "CODE_REPOSITORY" | "DOCUMENT" | (string & {});
export interface ListIntegratedResourcesInput {
    agentSpaceId: string;
    integrationId?: string;
    resourceType?: ResourceType;
    nextToken?: string;
    maxResults?: number;
}
export type ProviderResourceName = string;
export type ProviderResourceId = string;
export type GitHubOwner = string;
export type AccessType = "PRIVATE" | "PUBLIC" | (string & {});
export interface GitHubRepositoryMetadata {
    name: string;
    providerResourceId: string;
    owner: string;
    accessType?: AccessType;
}
export type GitLabNamespace = string;
export interface GitLabRepositoryMetadata {
    name: string;
    providerResourceId: string;
    namespace: string;
    accessType?: AccessType;
}
export interface BitbucketRepositoryMetadata {
    name: string;
    providerResourceId: string;
    workspace: string;
    accessType?: AccessType;
}
export interface ConfluenceDocumentMetadata {
    name: string;
    providerResourceId: string;
    spaceKey: string;
    pageId: string;
    title?: string;
    spaceTitle?: string;
}
export type AzureDevOpsOrganization = string;
export interface AzureDevOpsRepositoryMetadata {
    name: string;
    providerResourceId: string;
    organization: string;
    project?: string;
    projectId?: string;
    accessType?: AccessType;
}
export type IntegratedResourceMetadata = {
    githubRepository: GitHubRepositoryMetadata;
    gitlabRepository?: never;
    bitbucketRepository?: never;
    confluenceDocument?: never;
    azureDevOpsRepository?: never;
} | {
    githubRepository?: never;
    gitlabRepository: GitLabRepositoryMetadata;
    bitbucketRepository?: never;
    confluenceDocument?: never;
    azureDevOpsRepository?: never;
} | {
    githubRepository?: never;
    gitlabRepository?: never;
    bitbucketRepository: BitbucketRepositoryMetadata;
    confluenceDocument?: never;
    azureDevOpsRepository?: never;
} | {
    githubRepository?: never;
    gitlabRepository?: never;
    bitbucketRepository?: never;
    confluenceDocument: ConfluenceDocumentMetadata;
    azureDevOpsRepository?: never;
} | {
    githubRepository?: never;
    gitlabRepository?: never;
    bitbucketRepository?: never;
    confluenceDocument?: never;
    azureDevOpsRepository: AzureDevOpsRepositoryMetadata;
};
export type TriggerEvent = "PULL_REQUEST_READY_FOR_REVIEW" | "PULL_REQUEST_DRAFT" | "PULL_REQUEST_LABEL_ADDED" | (string & {});
export type TriggerEventList = TriggerEvent[];
export type TriggerFilterType = "TARGET_BRANCH" | "LABEL" | (string & {});
export type TriggerRegexPattern = string;
export type TriggerRegexPatternList = string[];
export type TriggerFilterMatchMode = "INCLUDE" | "EXCLUDE" | (string & {});
export interface TriggerFilter {
    type: TriggerFilterType;
    patterns: string[];
    matchMode?: TriggerFilterMatchMode;
}
export type TriggerFilterList = TriggerFilter[];
export interface TriggerFilterGroup {
    events?: TriggerEvent[];
    filters?: TriggerFilter[];
}
export type TriggerFilterGroups = TriggerFilterGroup[];
export interface GitHubResourceCapabilities {
    triggerFilterGroups?: TriggerFilterGroup[];
    leaveComments?: boolean;
    remediateCode?: boolean;
}
export interface GitLabResourceCapabilities {
    triggerFilterGroups?: TriggerFilterGroup[];
    leaveComments?: boolean;
    remediateCode?: boolean;
}
export interface BitbucketResourceCapabilities {
    triggerFilterGroups?: TriggerFilterGroup[];
    leaveComments?: boolean;
    remediateCode?: boolean;
}
export interface ConfluenceResourceCapabilities {
    fetchDocument?: boolean;
    createDocument?: boolean;
    updateDocument?: boolean;
}
export interface AzureDevOpsResourceCapabilities {
    triggerFilterGroups?: TriggerFilterGroup[];
    leaveComments?: boolean;
    remediateCode?: boolean;
}
export type ProviderResourceCapabilities = {
    github: GitHubResourceCapabilities;
    gitlab?: never;
    bitbucket?: never;
    confluence?: never;
    azureDevOps?: never;
} | {
    github?: never;
    gitlab: GitLabResourceCapabilities;
    bitbucket?: never;
    confluence?: never;
    azureDevOps?: never;
} | {
    github?: never;
    gitlab?: never;
    bitbucket: BitbucketResourceCapabilities;
    confluence?: never;
    azureDevOps?: never;
} | {
    github?: never;
    gitlab?: never;
    bitbucket?: never;
    confluence: ConfluenceResourceCapabilities;
    azureDevOps?: never;
} | {
    github?: never;
    gitlab?: never;
    bitbucket?: never;
    confluence?: never;
    azureDevOps: AzureDevOpsResourceCapabilities;
};
export interface IntegratedResourceSummary {
    integrationId: string;
    resource: IntegratedResourceMetadata;
    capabilities?: ProviderResourceCapabilities;
}
export type IntegratedResourceSummaryList = IntegratedResourceSummary[];
export interface ListIntegratedResourcesOutput {
    integratedResourceSummaries: IntegratedResourceSummary[];
    nextToken?: string;
}
export type IntegrationFilter = {
    provider: Provider;
    providerType?: never;
} | {
    provider?: never;
    providerType: ProviderType;
};
export interface ListIntegrationsInput {
    filter?: IntegrationFilter;
    nextToken?: string;
    maxResults?: number;
}
export interface IntegrationSummary {
    integrationId: string;
    installationId: string;
    provider: Provider;
    providerType: ProviderType;
    displayName: string;
    targetUrl?: string;
    webhookUrl?: string;
    privateConnectionName?: string;
}
export type IntegrationSummaryList = IntegrationSummary[];
export interface ListIntegrationsOutput {
    integrationSummaries: IntegrationSummary[];
    nextToken?: string;
}
export type MembershipTypeFilter = "USER" | "ALL" | (string & {});
export interface ListMembershipsRequest {
    applicationId: string;
    agentSpaceId: string;
    memberType?: MembershipTypeFilter;
    maxResults?: number;
    nextToken?: string;
}
export type SensitiveEmail = string;
export interface UserMetadata {
    username: string;
    email: string;
}
export type MemberMetadata = {
    user: UserMetadata;
};
export interface MembershipSummary {
    membershipId: string;
    applicationId: string;
    agentSpaceId: string;
    memberType: MembershipType;
    config?: MembershipConfig;
    metadata?: MemberMetadata;
    createdAt: Date;
    updatedAt: Date;
    createdBy: string;
    updatedBy: string;
}
export type MembershipSummaryList = MembershipSummary[];
export interface ListMembershipsResponse {
    membershipSummaries: MembershipSummary[];
    nextToken?: string;
}
export interface ListPentestJobsForPentestInput {
    maxResults?: number;
    pentestId: string;
    agentSpaceId: string;
    nextToken?: string;
    jobType?: JobType;
}
export interface PentestJobSummary {
    pentestJobId: string;
    pentestId: string;
    title?: string;
    status?: JobStatus;
    createdAt?: Date;
    updatedAt?: Date;
    jobType?: JobType;
    reportUrl?: string;
}
export type PentestJobSummaryList = PentestJobSummary[];
export interface ListPentestJobsForPentestOutput {
    pentestJobSummaries?: PentestJobSummary[];
    nextToken?: string;
}
export interface ListPentestJobTasksInput {
    agentSpaceId: string;
    maxResults?: number;
    pentestJobId?: string;
    stepName?: StepName;
    categoryName?: string;
    nextToken?: string;
}
export interface TaskSummary {
    taskId: string;
    pentestId?: string;
    pentestJobId?: string;
    agentSpaceId?: string;
    title?: string;
    riskType?: RiskType;
    executionStatus?: TaskExecutionStatus;
    taskHours?: number;
    createdAt?: Date;
    updatedAt?: Date;
}
export type TaskSummaryList = TaskSummary[];
export interface ListPentestJobTasksOutput {
    taskSummaries?: TaskSummary[];
    nextToken?: string;
}
export interface ListPentestsInput {
    maxResults?: number;
    nextToken?: string;
    agentSpaceId: string;
}
export interface PentestSummary {
    pentestId: string;
    agentSpaceId: string;
    title: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export type PentestSummaryList = PentestSummary[];
export interface ListPentestsOutput {
    pentestSummaries?: PentestSummary[];
    nextToken?: string;
}
export interface ListPrivateConnectionsInput {
    maxResults?: number;
    nextToken?: string;
}
export interface PrivateConnectionSummary {
    name: string;
    type: PrivateConnectionType;
    status: PrivateConnectionStatus;
    resourceGatewayId?: string;
    hostAddress?: string;
    vpcId?: string;
    resourceConfigurationId?: string;
    certificateExpiryTime?: Date;
    dnsResolution?: ResourceConfigDnsResolution;
    failureMessage?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type PrivateConnectionList = PrivateConnectionSummary[];
export interface ListPrivateConnectionsOutput {
    privateConnections: PrivateConnectionSummary[];
    nextToken?: string;
}
export interface ListSecurityRequirementPackFilter {
    managementType?: ManagementType;
    status?: SecurityRequirementPackStatus;
}
export interface ListSecurityRequirementPacksInput {
    filter?: ListSecurityRequirementPackFilter;
    nextToken?: string;
    maxResults?: number;
}
export interface SecurityRequirementPackSummary {
    packId: string;
    name: string;
    description?: string;
    vendorName?: string;
    managementType: ManagementType;
    status: SecurityRequirementPackStatus;
    createdAt: Date;
    updatedAt: Date;
}
export type SecurityRequirementPackSummaryList = SecurityRequirementPackSummary[];
export interface ListSecurityRequirementPacksOutput {
    securityRequirementPackSummaries: SecurityRequirementPackSummary[];
    nextToken?: string;
}
export interface ListSecurityRequirementsInput {
    packId: string;
    nextToken?: string;
    maxResults?: number;
}
export interface SecurityRequirementSummary {
    packId: string;
    name: string;
    description: string;
    createdAt: Date;
    updatedAt: Date;
}
export type SecurityRequirementSummaryList = SecurityRequirementSummary[];
export interface ListSecurityRequirementsOutput {
    securityRequirementSummaries: SecurityRequirementSummary[];
    nextToken?: string;
}
export type ResourceArn = string;
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListTargetDomainsInput {
    nextToken?: string;
    maxResults?: number;
}
export interface TargetDomainSummary {
    targetDomainId: string;
    domainName: string;
    verificationStatus?: TargetDomainStatus;
}
export type TargetDomainSummaryList = TargetDomainSummary[];
export interface ListTargetDomainsOutput {
    targetDomainSummaries?: TargetDomainSummary[];
    nextToken?: string;
}
export interface ListThreatModelJobsInput {
    maxResults?: number;
    threatModelId: string;
    agentSpaceId: string;
    nextToken?: string;
}
export interface ThreatModelJobSummary {
    threatModelJobId: string;
    threatModelId: string;
    agentSpaceId?: string;
    title?: string;
    status?: JobStatus;
    createdAt?: Date;
    updatedAt?: Date;
}
export type ThreatModelJobSummaryList = ThreatModelJobSummary[];
export interface ListThreatModelJobsOutput {
    threatModelJobSummaries?: ThreatModelJobSummary[];
    nextToken?: string;
}
export interface ListThreatModelJobTasksInput {
    agentSpaceId: string;
    maxResults?: number;
    threatModelJobId: string;
    nextToken?: string;
}
export interface ThreatModelJobTaskSummary {
    taskId: string;
    threatModelId?: string;
    threatModelJobId?: string;
    agentSpaceId?: string;
    title?: string;
    executionStatus?: TaskExecutionStatus;
    createdAt?: Date;
    updatedAt?: Date;
}
export type ThreatModelJobTaskSummaryList = ThreatModelJobTaskSummary[];
export interface ListThreatModelJobTasksOutput {
    threatModelJobTaskSummaries?: ThreatModelJobTaskSummary[];
    nextToken?: string;
}
export interface ListThreatModelsInput {
    maxResults?: number;
    nextToken?: string;
    agentSpaceId: string;
}
export interface ThreatModelSummary {
    threatModelId: string;
    agentSpaceId: string;
    title: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export type ThreatModelSummaryList = ThreatModelSummary[];
export interface ListThreatModelsOutput {
    threatModelSummaries?: ThreatModelSummary[];
    nextToken?: string;
}
export interface ListThreatsInput {
    threatJobId: string;
    agentSpaceId: string;
    nextToken?: string;
    maxResults?: number;
}
export interface ThreatSummary {
    threatId?: string;
    threatJobId?: string;
    title?: string;
    statement?: string;
    severity?: ThreatSeverity;
    status?: ThreatStatus;
    stride?: StrideCategory[];
    createdBy?: ThreatActor;
    updatedBy?: ThreatActor;
    createdAt?: Date;
    updatedAt?: Date;
}
export type ThreatSummaryList = ThreatSummary[];
export interface ListThreatsOutput {
    threats?: ThreatSummary[];
    nextToken?: string;
}
export interface StartCodeRemediationInput {
    agentSpaceId: string;
    pentestJobId?: string;
    codeReviewJobId?: string;
    findingIds: string[];
}
export interface StartCodeRemediationOutput {
}
export type DiffSource = {
    s3Uri: string;
};
export interface StartCodeReviewJobInput {
    agentSpaceId: string;
    codeReviewId: string;
    diffSource?: DiffSource;
}
export interface StartCodeReviewJobOutput {
    title?: string;
    status?: JobStatus;
    createdAt?: Date;
    updatedAt?: Date;
    codeReviewId: string;
    codeReviewJobId: string;
    agentSpaceId?: string;
}
export interface StartPentestJobInput {
    agentSpaceId: string;
    pentestId: string;
    jobType?: JobType;
    selectedFindingIds?: string[];
    scopeChanges?: ScopeChange[];
}
export interface StartPentestJobOutput {
    title?: string;
    status?: JobStatus;
    createdAt?: Date;
    updatedAt?: Date;
    pentestId?: string;
    pentestJobId?: string;
    agentSpaceId?: string;
}
export interface StartThreatModelJobInput {
    agentSpaceId: string;
    threatModelId: string;
}
export interface StartThreatModelJobOutput {
    title?: string;
    status?: JobStatus;
    createdAt?: Date;
    updatedAt?: Date;
    threatModelId?: string;
    threatModelJobId: string;
    agentSpaceId?: string;
}
export interface StopCodeReviewJobInput {
    agentSpaceId: string;
    codeReviewJobId: string;
}
export interface StopCodeReviewJobOutput {
}
export interface StopPentestJobInput {
    agentSpaceId: string;
    pentestJobId: string;
}
export interface StopPentestJobOutput {
}
export interface StopThreatModelJobInput {
    agentSpaceId: string;
    threatModelJobId: string;
}
export interface StopThreatModelJobOutput {
}
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateAgentSpaceInput {
    agentSpaceId: string;
    name?: string;
    description?: string;
    awsResources?: AWSResources;
    targetDomainIds?: string[];
    codeReviewSettings?: CodeReviewSettings;
}
export interface UpdateAgentSpaceOutput {
    agentSpaceId: string;
    name: string;
    description?: string;
    awsResources?: AWSResources;
    targetDomainIds?: string[];
    codeReviewSettings?: CodeReviewSettings;
    createdAt?: Date;
    updatedAt?: Date;
}
export interface UpdateApplicationRequest {
    applicationId: string;
    roleArn?: string;
    defaultKmsKeyId?: string;
}
export interface UpdateApplicationResponse {
    applicationId: string;
}
export interface UpdateCodeReviewInput {
    codeReviewId: string;
    agentSpaceId: string;
    title?: string;
    assets?: Assets;
    serviceRole?: string;
    logConfig?: CloudWatchLog;
    codeRemediationStrategy?: CodeRemediationStrategy;
    validationMode?: ValidationMode;
    maxTaskHours?: number;
    reportDestination?: ReportDestination;
    reportFilters?: ReportFilters;
}
export interface UpdateCodeReviewOutput {
    codeReviewId: string;
    title?: string;
    createdAt?: Date;
    updatedAt?: Date;
    assets?: Assets;
    serviceRole?: string;
    logConfig?: CloudWatchLog;
    agentSpaceId?: string;
    codeRemediationStrategy?: CodeRemediationStrategy;
    validationMode?: ValidationMode;
    maxTaskHours?: number;
    reportDestination?: ReportDestination;
    reportFilters?: ReportFilters;
}
export interface UpdateFindingInput {
    findingId: string;
    agentSpaceId: string;
    name?: string;
    description?: string;
    riskType?: string;
    riskLevel?: RiskLevel;
    riskScore?: string;
    attackScript?: string;
    reasoning?: string;
    status?: FindingStatus;
    customerNote?: string;
}
export interface UpdateFindingOutput {
}
export interface GitHubRepositoryResource {
    name: string;
    owner: string;
}
export interface GitLabRepositoryResource {
    name: string;
    namespace: string;
}
export interface BitbucketRepositoryResource {
    name: string;
    workspace: string;
}
export interface ConfluenceDocumentResource {
    name: string;
    spaceKey: string;
    pageId: string;
    title?: string;
    spaceTitle?: string;
}
export interface AzureDevOpsRepositoryResource {
    name: string;
    organization: string;
    project?: string;
}
export type IntegratedResource = {
    githubRepository: GitHubRepositoryResource;
    gitlabRepository?: never;
    bitbucketRepository?: never;
    confluenceDocument?: never;
    azureDevOpsRepository?: never;
} | {
    githubRepository?: never;
    gitlabRepository: GitLabRepositoryResource;
    bitbucketRepository?: never;
    confluenceDocument?: never;
    azureDevOpsRepository?: never;
} | {
    githubRepository?: never;
    gitlabRepository?: never;
    bitbucketRepository: BitbucketRepositoryResource;
    confluenceDocument?: never;
    azureDevOpsRepository?: never;
} | {
    githubRepository?: never;
    gitlabRepository?: never;
    bitbucketRepository?: never;
    confluenceDocument: ConfluenceDocumentResource;
    azureDevOpsRepository?: never;
} | {
    githubRepository?: never;
    gitlabRepository?: never;
    bitbucketRepository?: never;
    confluenceDocument?: never;
    azureDevOpsRepository: AzureDevOpsRepositoryResource;
};
export interface IntegratedResourceInputItem {
    resource: IntegratedResource;
    capabilities?: ProviderResourceCapabilities;
}
export type IntegratedResourceInputItemList = IntegratedResourceInputItem[];
export interface UpdateIntegratedResourcesInput {
    agentSpaceId: string;
    integrationId: string;
    items: IntegratedResourceInputItem[];
}
export interface UpdateIntegratedResourcesOutput {
}
export type WebhookAction = "CREATE_IF_ABSENT" | "ROTATE" | (string & {});
export interface UpdateIntegrationInput {
    integrationId: string;
    webhookAction: WebhookAction;
}
export type WebhookSecret = string | redacted.Redacted<string>;
export interface UpdateIntegrationOutput {
    integrationId: string;
    webhookUrl?: string;
    secret?: string | redacted.Redacted<string>;
}
export interface UpdatePentestInput {
    pentestId: string;
    agentSpaceId: string;
    title?: string;
    assets?: Assets;
    excludeRiskTypes?: RiskType[];
    serviceRole?: string;
    logConfig?: CloudWatchLog;
    vpcConfig?: VpcConfig;
    networkTrafficConfig?: NetworkTrafficConfig;
    codeRemediationStrategy?: CodeRemediationStrategy;
    disableManagedSkills?: SkillType[];
    maxTaskHours?: number;
    reportDestination?: ReportDestination;
    reportFilters?: ReportFilters;
    cicdConfiguration?: CiCdConfiguration;
}
export interface UpdatePentestOutput {
    pentestId?: string;
    title?: string;
    createdAt?: Date;
    updatedAt?: Date;
    assets?: Assets;
    excludeRiskTypes?: RiskType[];
    serviceRole?: string;
    logConfig?: CloudWatchLog;
    agentSpaceId?: string;
    reportDestination?: ReportDestination;
    reportFilters?: ReportFilters;
    cicdConfiguration?: CiCdConfiguration;
}
export interface UpdatePrivateConnectionCertificateInput {
    privateConnectionName: string;
    certificate: string | redacted.Redacted<string>;
}
export interface UpdatePrivateConnectionCertificateOutput {
    name: string;
    type: PrivateConnectionType;
    status: PrivateConnectionStatus;
    resourceGatewayId?: string;
    hostAddress?: string;
    vpcId?: string;
    resourceConfigurationId?: string;
    certificateExpiryTime?: Date;
    dnsResolution?: ResourceConfigDnsResolution;
    failureMessage?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface UpdateSecurityRequirementPackInput {
    packId: string;
    name?: string;
    description?: string;
    status?: SecurityRequirementPackStatus;
}
export interface UpdateSecurityRequirementPackOutput {
    packId: string;
    name?: string;
    description?: string;
    status?: SecurityRequirementPackStatus;
}
export interface UpdateTargetDomainInput {
    targetDomainId: string;
    verificationMethod: DomainVerificationMethod;
}
export interface UpdateTargetDomainOutput {
    targetDomainId: string;
    domainName: string;
    verificationStatus: TargetDomainStatus;
    verificationStatusReason?: string;
    verificationDetails?: VerificationDetails;
    createdAt?: Date;
    verifiedAt?: Date;
}
export interface UpdateThreatInput {
    threatId: string;
    agentSpaceId: string;
    title?: string;
    status?: ThreatStatus;
    comments?: string;
    statement?: string;
    severity?: ThreatSeverity;
    threatSource?: string;
    prerequisites?: string;
    threatAction?: string;
    threatImpact?: string;
    impactedGoal?: string[];
    impactedAssets?: string[];
    anchor?: ThreatAnchorShape;
    evidence?: ThreatEvidenceShape[];
    recommendation?: string;
}
export interface UpdateThreatOutput {
    threatId: string;
    threatJobId: string;
    title?: string;
    statement?: string;
    severity?: ThreatSeverity;
    status?: ThreatStatus;
    comments?: string;
    stride?: StrideCategory[];
    threatSource?: string;
    prerequisites?: string;
    threatAction?: string;
    threatImpact?: string;
    impactedGoal?: string[];
    impactedAssets?: string[];
    anchor?: ThreatAnchorShape;
    evidence?: ThreatEvidenceShape[];
    recommendation?: string;
    createdBy?: ThreatActor;
    updatedBy?: ThreatActor;
    createdAt?: Date;
    updatedAt?: Date;
}
export interface UpdateThreatModelInput {
    threatModelId: string;
    agentSpaceId: string;
    title?: string;
    description?: string;
    assets?: Assets;
    scopeDocs?: DocumentInfo[];
    serviceRole?: string;
    logConfig?: CloudWatchLog;
    reportDestination?: ReportDestination;
}
export interface UpdateThreatModelOutput {
    threatModelId: string;
    title?: string;
    agentSpaceId?: string;
    description?: string;
    assets?: Assets;
    scopeDocs?: DocumentInfo[];
    serviceRole?: string;
    logConfig?: CloudWatchLog;
    createdAt?: Date;
    updatedAt?: Date;
    reportDestination?: ReportDestination;
}
export interface VerifyTargetDomainInput {
    targetDomainId: string;
}
export interface VerifyTargetDomainOutput {
    targetDomainId?: string;
    domainName?: string;
    createdAt?: Date;
    updatedAt?: Date;
    verifiedAt?: Date;
    status?: TargetDomainStatus;
    verificationStatusReason?: string;
}
export interface ValidationExceptionField {
    path: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AddArtifactError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Uploads an artifact to an agent space. Artifacts provide additional context for security testing, such as architecture diagrams, API specifications, or configuration files.
 */
export declare const addArtifact: API.OperationMethod<AddArtifactInput, AddArtifactOutput, AddArtifactError, Credentials | HttpClient.HttpClient>;
export type BatchCreateSecurityRequirementsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Batch creates security requirements in a customer managed pack.
 */
export declare const batchCreateSecurityRequirements: API.OperationMethod<BatchCreateSecurityRequirementsInput, BatchCreateSecurityRequirementsOutput, BatchCreateSecurityRequirementsError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteCodeReviewsError = CommonErrors;
/**
 * Deletes one or more code reviews from an agent space.
 */
export declare const batchDeleteCodeReviews: API.OperationMethod<BatchDeleteCodeReviewsInput, BatchDeleteCodeReviewsOutput, BatchDeleteCodeReviewsError, Credentials | HttpClient.HttpClient>;
export type BatchDeletePentestsError = CommonErrors;
/**
 * Deletes one or more pentests from an agent space.
 */
export declare const batchDeletePentests: API.OperationMethod<BatchDeletePentestsInput, BatchDeletePentestsOutput, BatchDeletePentestsError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteSecurityRequirementsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Batch deletes security requirements from a customer managed pack.
 */
export declare const batchDeleteSecurityRequirements: API.OperationMethod<BatchDeleteSecurityRequirementsInput, BatchDeleteSecurityRequirementsOutput, BatchDeleteSecurityRequirementsError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteThreatModelsError = CommonErrors;
/**
 * Deletes one or more threat models from an agent space.
 */
export declare const batchDeleteThreatModels: API.OperationMethod<BatchDeleteThreatModelsInput, BatchDeleteThreatModelsOutput, BatchDeleteThreatModelsError, Credentials | HttpClient.HttpClient>;
export type BatchGetAgentSpacesError = CommonErrors;
/**
 * Retrieves information about one or more agent spaces.
 */
export declare const batchGetAgentSpaces: API.OperationMethod<BatchGetAgentSpacesInput, BatchGetAgentSpacesOutput, BatchGetAgentSpacesError, Credentials | HttpClient.HttpClient>;
export type BatchGetArtifactMetadataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves metadata for one or more artifacts in an agent space.
 */
export declare const batchGetArtifactMetadata: API.OperationMethod<BatchGetArtifactMetadataInput, BatchGetArtifactMetadataOutput, BatchGetArtifactMetadataError, Credentials | HttpClient.HttpClient>;
export type BatchGetCodeReviewJobsError = CommonErrors;
/**
 * Retrieves information about one or more code review jobs in an agent space.
 */
export declare const batchGetCodeReviewJobs: API.OperationMethod<BatchGetCodeReviewJobsInput, BatchGetCodeReviewJobsOutput, BatchGetCodeReviewJobsError, Credentials | HttpClient.HttpClient>;
export type BatchGetCodeReviewJobTasksError = CommonErrors;
/**
 * Retrieves information about one or more tasks within a code review job.
 */
export declare const batchGetCodeReviewJobTasks: API.OperationMethod<BatchGetCodeReviewJobTasksInput, BatchGetCodeReviewJobTasksOutput, BatchGetCodeReviewJobTasksError, Credentials | HttpClient.HttpClient>;
export type BatchGetCodeReviewsError = CommonErrors;
/**
 * Retrieves information about one or more code reviews in an agent space.
 */
export declare const batchGetCodeReviews: API.OperationMethod<BatchGetCodeReviewsInput, BatchGetCodeReviewsOutput, BatchGetCodeReviewsError, Credentials | HttpClient.HttpClient>;
export type BatchGetFindingsError = CommonErrors;
/**
 * Retrieves information about one or more security findings in an agent space.
 */
export declare const batchGetFindings: API.OperationMethod<BatchGetFindingsInput, BatchGetFindingsOutput, BatchGetFindingsError, Credentials | HttpClient.HttpClient>;
export type BatchGetPentestJobsError = CommonErrors;
/**
 * Retrieves information about one or more pentest jobs in an agent space.
 */
export declare const batchGetPentestJobs: API.OperationMethod<BatchGetPentestJobsInput, BatchGetPentestJobsOutput, BatchGetPentestJobsError, Credentials | HttpClient.HttpClient>;
export type BatchGetPentestJobTasksError = CommonErrors;
/**
 * Retrieves information about one or more tasks within a pentest job.
 */
export declare const batchGetPentestJobTasks: API.OperationMethod<BatchGetPentestJobTasksInput, BatchGetPentestJobTasksOutput, BatchGetPentestJobTasksError, Credentials | HttpClient.HttpClient>;
export type BatchGetPentestsError = CommonErrors;
/**
 * Retrieves information about one or more pentests in an agent space.
 */
export declare const batchGetPentests: API.OperationMethod<BatchGetPentestsInput, BatchGetPentestsOutput, BatchGetPentestsError, Credentials | HttpClient.HttpClient>;
export type BatchGetSecurityRequirementsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Batch retrieves security requirements from a pack.
 */
export declare const batchGetSecurityRequirements: API.OperationMethod<BatchGetSecurityRequirementsInput, BatchGetSecurityRequirementsOutput, BatchGetSecurityRequirementsError, Credentials | HttpClient.HttpClient>;
export type BatchGetTargetDomainsError = CommonErrors;
/**
 * Retrieves information about one or more target domains.
 */
export declare const batchGetTargetDomains: API.OperationMethod<BatchGetTargetDomainsInput, BatchGetTargetDomainsOutput, BatchGetTargetDomainsError, Credentials | HttpClient.HttpClient>;
export type BatchGetThreatModelJobsError = CommonErrors;
/**
 * Retrieves information about one or more threat model jobs in an agent space.
 */
export declare const batchGetThreatModelJobs: API.OperationMethod<BatchGetThreatModelJobsInput, BatchGetThreatModelJobsOutput, BatchGetThreatModelJobsError, Credentials | HttpClient.HttpClient>;
export type BatchGetThreatModelJobTasksError = CommonErrors;
/**
 * Retrieves information about one or more tasks within a threat model job.
 */
export declare const batchGetThreatModelJobTasks: API.OperationMethod<BatchGetThreatModelJobTasksInput, BatchGetThreatModelJobTasksOutput, BatchGetThreatModelJobTasksError, Credentials | HttpClient.HttpClient>;
export type BatchGetThreatModelsError = CommonErrors;
/**
 * Retrieves information about one or more threat models in an agent space.
 */
export declare const batchGetThreatModels: API.OperationMethod<BatchGetThreatModelsInput, BatchGetThreatModelsOutput, BatchGetThreatModelsError, Credentials | HttpClient.HttpClient>;
export type BatchGetThreatsError = CommonErrors;
/**
 * Retrieves information about one or more threats.
 */
export declare const batchGetThreats: API.OperationMethod<BatchGetThreatsInput, BatchGetThreatsOutput, BatchGetThreatsError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateSecurityRequirementsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Batch updates security requirements within a customer managed pack.
 */
export declare const batchUpdateSecurityRequirements: API.OperationMethod<BatchUpdateSecurityRequirementsInput, BatchUpdateSecurityRequirementsOutput, BatchUpdateSecurityRequirementsError, Credentials | HttpClient.HttpClient>;
export type CreateAgentSpaceError = CommonErrors;
/**
 * Creates a new agent space. An agent space is a dedicated workspace for securing a specific application.
 */
export declare const createAgentSpace: API.OperationMethod<CreateAgentSpaceInput, CreateAgentSpaceOutput, CreateAgentSpaceError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = CommonErrors;
/**
 * Creates a new application. An application is the top-level organizational unit that supports IAM Identity Center integration.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateCodeReviewError = CommonErrors;
/**
 * Creates a new code review configuration in an agent space. A code review defines the parameters for automated security-focused code analysis.
 */
export declare const createCodeReview: API.OperationMethod<CreateCodeReviewInput, CreateCodeReviewOutput, CreateCodeReviewError, Credentials | HttpClient.HttpClient>;
export type CreateIntegrationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new integration with a third-party provider, such as GitHub, for code review and remediation.
 */
export declare const createIntegration: API.OperationMethod<CreateIntegrationInput, CreateIntegrationOutput, CreateIntegrationError, Credentials | HttpClient.HttpClient>;
export type CreateMembershipError = CommonErrors;
/**
 * Creates a new membership, granting a user access to an agent space within an application.
 */
export declare const createMembership: API.OperationMethod<CreateMembershipRequest, CreateMembershipResponse, CreateMembershipError, Credentials | HttpClient.HttpClient>;
export type CreatePentestError = CommonErrors;
/**
 * Creates a new pentest configuration in an agent space. A pentest defines the security test parameters, including target assets, risk type exclusions, and logging configuration.
 */
export declare const createPentest: API.OperationMethod<CreatePentestInput, CreatePentestOutput, CreatePentestError, Credentials | HttpClient.HttpClient>;
export type CreatePrivateConnectionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a private connection for reaching a self-hosted provider instance over private networking using Amazon VPC Lattice.
 */
export declare const createPrivateConnection: API.OperationMethod<CreatePrivateConnectionInput, CreatePrivateConnectionOutput, CreatePrivateConnectionError, Credentials | HttpClient.HttpClient>;
export type CreateSecurityRequirementPackError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a customer managed security requirement pack.
 */
export declare const createSecurityRequirementPack: API.OperationMethod<CreateSecurityRequirementPackInput, CreateSecurityRequirementPackOutput, CreateSecurityRequirementPackError, Credentials | HttpClient.HttpClient>;
export type CreateTargetDomainError = CommonErrors;
/**
 * Creates a new target domain for penetration testing. A target domain is a web domain that must be registered and verified before it can be tested.
 */
export declare const createTargetDomain: API.OperationMethod<CreateTargetDomainInput, CreateTargetDomainOutput, CreateTargetDomainError, Credentials | HttpClient.HttpClient>;
export type CreateThreatError = CommonErrors;
/**
 * Creates a new threat under a threat model job.
 */
export declare const createThreat: API.OperationMethod<CreateThreatInput, CreateThreatOutput, CreateThreatError, Credentials | HttpClient.HttpClient>;
export type CreateThreatModelError = CommonErrors;
/**
 * Creates a new threat model configuration in an agent space. A threat model defines the parameters for automated threat analysis.
 */
export declare const createThreatModel: API.OperationMethod<CreateThreatModelInput, CreateThreatModelOutput, CreateThreatModelError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentSpaceError = CommonErrors;
/**
 * Deletes an agent space and all of its associated resources, including pentests, findings, and artifacts.
 */
export declare const deleteAgentSpace: API.OperationMethod<DeleteAgentSpaceInput, DeleteAgentSpaceOutput, DeleteAgentSpaceError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = CommonErrors;
/**
 * Deletes an application and its associated configuration, including IAM Identity Center settings.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteArtifactError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an artifact from an agent space.
 */
export declare const deleteArtifact: API.OperationMethod<DeleteArtifactInput, DeleteArtifactOutput, DeleteArtifactError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an integration with a third-party provider.
 */
export declare const deleteIntegration: API.OperationMethod<DeleteIntegrationInput, DeleteIntegrationOutput, DeleteIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteMembershipError = CommonErrors;
/**
 * Deletes a membership, revoking a user's access to an agent space.
 */
export declare const deleteMembership: API.OperationMethod<DeleteMembershipRequest, DeleteMembershipResponse, DeleteMembershipError, Credentials | HttpClient.HttpClient>;
export type DeletePrivateConnectionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a private connection.
 */
export declare const deletePrivateConnection: API.OperationMethod<DeletePrivateConnectionInput, DeletePrivateConnectionOutput, DeletePrivateConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteSecurityRequirementPackError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a customer managed security requirement pack and all its associated security requirements.
 */
export declare const deleteSecurityRequirementPack: API.OperationMethod<DeleteSecurityRequirementPackInput, DeleteSecurityRequirementPackOutput, DeleteSecurityRequirementPackError, Credentials | HttpClient.HttpClient>;
export type DeleteTargetDomainError = CommonErrors;
/**
 * Deletes a target domain registration. After deletion, the domain can no longer be used for penetration testing.
 */
export declare const deleteTargetDomain: API.OperationMethod<DeleteTargetDomainInput, DeleteTargetDomainOutput, DeleteTargetDomainError, Credentials | HttpClient.HttpClient>;
export type DescribePrivateConnectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of a private connection.
 */
export declare const describePrivateConnection: API.OperationMethod<DescribePrivateConnectionInput, DescribePrivateConnectionOutput, DescribePrivateConnectionError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = CommonErrors;
/**
 * Retrieves information about an application.
 */
export declare const getApplication: API.OperationMethod<GetApplicationRequest, GetApplicationResponse, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetArtifactError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves an artifact from an agent space.
 */
export declare const getArtifact: API.OperationMethod<GetArtifactInput, GetArtifactOutput, GetArtifactError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an integration.
 */
export declare const getIntegration: API.OperationMethod<GetIntegrationInput, GetIntegrationOutput, GetIntegrationError, Credentials | HttpClient.HttpClient>;
export type GetSecurityRequirementPackError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a security requirement pack.
 */
export declare const getSecurityRequirementPack: API.OperationMethod<GetSecurityRequirementPackInput, GetSecurityRequirementPackOutput, GetSecurityRequirementPackError, Credentials | HttpClient.HttpClient>;
export type ImportSecurityRequirementsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Imports security requirements from uploaded documents into a customer managed security requirement pack. The import process asynchronously extracts and generates structured security requirements from the provided source files.
 */
export declare const importSecurityRequirements: API.OperationMethod<ImportSecurityRequirementsInput, ImportSecurityRequirementsOutput, ImportSecurityRequirementsError, Credentials | HttpClient.HttpClient>;
export type InitiateProviderRegistrationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initiates the OAuth registration flow with a third-party provider. Returns a redirect URL and CSRF state token for completing the authorization.
 */
export declare const initiateProviderRegistration: API.OperationMethod<InitiateProviderRegistrationInput, InitiateProviderRegistrationOutput, InitiateProviderRegistrationError, Credentials | HttpClient.HttpClient>;
export type ListActorMessagesError = CommonErrors;
/**
 * Returns a paginated list of the email MFA messages received for an actor at its server-generated email address, most recent first.
 */
export declare const listActorMessages: API.PaginatedOperationMethod<ListActorMessagesInput, ListActorMessagesOutput, ListActorMessagesError, Credentials | HttpClient.HttpClient, ActorMessage>;
export type ListAgentSpacesError = CommonErrors;
/**
 * Returns a paginated list of agent space summaries in your account.
 */
export declare const listAgentSpaces: API.PaginatedOperationMethod<ListAgentSpacesInput, ListAgentSpacesOutput, ListAgentSpacesError, Credentials | HttpClient.HttpClient, AgentSpaceSummary>;
export type ListApplicationsError = CommonErrors;
/**
 * Returns a paginated list of application summaries in your account.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationSummary>;
export type ListArtifactsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of artifact summaries for the specified agent space.
 */
export declare const listArtifacts: API.PaginatedOperationMethod<ListArtifactsInput, ListArtifactsOutput, ListArtifactsError, Credentials | HttpClient.HttpClient, ArtifactSummary>;
export type ListCodeReviewJobsForCodeReviewError = CommonErrors;
/**
 * Returns a paginated list of code review job summaries for the specified code review configuration.
 */
export declare const listCodeReviewJobsForCodeReview: API.PaginatedOperationMethod<ListCodeReviewJobsForCodeReviewInput, ListCodeReviewJobsForCodeReviewOutput, ListCodeReviewJobsForCodeReviewError, Credentials | HttpClient.HttpClient, CodeReviewJobSummary>;
export type ListCodeReviewJobTasksError = CommonErrors;
/**
 * Returns a paginated list of task summaries for the specified code review job, optionally filtered by step name or category.
 */
export declare const listCodeReviewJobTasks: API.PaginatedOperationMethod<ListCodeReviewJobTasksInput, ListCodeReviewJobTasksOutput, ListCodeReviewJobTasksError, Credentials | HttpClient.HttpClient, CodeReviewJobTaskSummary>;
export type ListCodeReviewsError = CommonErrors;
/**
 * Returns a paginated list of code review summaries for the specified agent space.
 */
export declare const listCodeReviews: API.PaginatedOperationMethod<ListCodeReviewsInput, ListCodeReviewsOutput, ListCodeReviewsError, Credentials | HttpClient.HttpClient, CodeReviewSummary>;
export type ListDiscoveredEndpointsError = CommonErrors;
/**
 * Returns a paginated list of endpoints discovered during a pentest job execution.
 */
export declare const listDiscoveredEndpoints: API.PaginatedOperationMethod<ListDiscoveredEndpointsInput, ListDiscoveredEndpointsOutput, ListDiscoveredEndpointsError, Credentials | HttpClient.HttpClient, DiscoveredEndpoint>;
export type ListFindingsError = CommonErrors;
/**
 * Lists the security findings for a pentest job.
 */
export declare const listFindings: API.PaginatedOperationMethod<ListFindingsInput, ListFindingsOutput, ListFindingsError, Credentials | HttpClient.HttpClient, FindingSummary>;
export type ListIntegratedResourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the integrated resources for an agent space, optionally filtered by integration or resource type.
 */
export declare const listIntegratedResources: API.PaginatedOperationMethod<ListIntegratedResourcesInput, ListIntegratedResourcesOutput, ListIntegratedResourcesError, Credentials | HttpClient.HttpClient, IntegratedResourceSummary>;
export type ListIntegrationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the integrations in your account, optionally filtered by provider or provider type.
 */
export declare const listIntegrations: API.PaginatedOperationMethod<ListIntegrationsInput, ListIntegrationsOutput, ListIntegrationsError, Credentials | HttpClient.HttpClient, IntegrationSummary>;
export type ListMembershipsError = CommonErrors;
/**
 * Returns a paginated list of membership summaries for the specified agent space within an application.
 */
export declare const listMemberships: API.PaginatedOperationMethod<ListMembershipsRequest, ListMembershipsResponse, ListMembershipsError, Credentials | HttpClient.HttpClient, MembershipSummary>;
export type ListPentestJobsForPentestError = CommonErrors;
/**
 * Returns a paginated list of pentest job summaries for the specified pentest configuration.
 */
export declare const listPentestJobsForPentest: API.PaginatedOperationMethod<ListPentestJobsForPentestInput, ListPentestJobsForPentestOutput, ListPentestJobsForPentestError, Credentials | HttpClient.HttpClient, PentestJobSummary>;
export type ListPentestJobTasksError = CommonErrors;
/**
 * Returns a paginated list of task summaries for the specified pentest job, optionally filtered by step name or category.
 */
export declare const listPentestJobTasks: API.PaginatedOperationMethod<ListPentestJobTasksInput, ListPentestJobTasksOutput, ListPentestJobTasksError, Credentials | HttpClient.HttpClient, TaskSummary>;
export type ListPentestsError = CommonErrors;
/**
 * Returns a paginated list of pentest summaries for the specified agent space.
 */
export declare const listPentests: API.PaginatedOperationMethod<ListPentestsInput, ListPentestsOutput, ListPentestsError, Credentials | HttpClient.HttpClient, PentestSummary>;
export type ListPrivateConnectionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the private connections in your account.
 */
export declare const listPrivateConnections: API.PaginatedOperationMethod<ListPrivateConnectionsInput, ListPrivateConnectionsOutput, ListPrivateConnectionsError, Credentials | HttpClient.HttpClient, PrivateConnectionSummary>;
export type ListSecurityRequirementPacksError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all security requirement packs in the caller's account.
 */
export declare const listSecurityRequirementPacks: API.PaginatedOperationMethod<ListSecurityRequirementPacksInput, ListSecurityRequirementPacksOutput, ListSecurityRequirementPacksError, Credentials | HttpClient.HttpClient, SecurityRequirementPackSummary>;
export type ListSecurityRequirementsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists security requirements within a pack.
 */
export declare const listSecurityRequirements: API.PaginatedOperationMethod<ListSecurityRequirementsInput, ListSecurityRequirementsOutput, ListSecurityRequirementsError, Credentials | HttpClient.HttpClient, SecurityRequirementSummary>;
export type ListTagsForResourceError = CommonErrors;
/**
 * Returns the tags associated with the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTargetDomainsError = CommonErrors;
/**
 * Returns a paginated list of target domain summaries in your account.
 */
export declare const listTargetDomains: API.PaginatedOperationMethod<ListTargetDomainsInput, ListTargetDomainsOutput, ListTargetDomainsError, Credentials | HttpClient.HttpClient, TargetDomainSummary>;
export type ListThreatModelJobsError = CommonErrors;
/**
 * Returns a paginated list of threat model job summaries for the specified threat model.
 */
export declare const listThreatModelJobs: API.PaginatedOperationMethod<ListThreatModelJobsInput, ListThreatModelJobsOutput, ListThreatModelJobsError, Credentials | HttpClient.HttpClient, ThreatModelJobSummary>;
export type ListThreatModelJobTasksError = CommonErrors;
/**
 * Returns a paginated list of task summaries for the specified threat model job.
 */
export declare const listThreatModelJobTasks: API.PaginatedOperationMethod<ListThreatModelJobTasksInput, ListThreatModelJobTasksOutput, ListThreatModelJobTasksError, Credentials | HttpClient.HttpClient, ThreatModelJobTaskSummary>;
export type ListThreatModelsError = CommonErrors;
/**
 * Returns a paginated list of threat model summaries for the specified agent space.
 */
export declare const listThreatModels: API.PaginatedOperationMethod<ListThreatModelsInput, ListThreatModelsOutput, ListThreatModelsError, Credentials | HttpClient.HttpClient, ThreatModelSummary>;
export type ListThreatsError = CommonErrors;
/**
 * Returns a paginated list of threats for a threat model job.
 */
export declare const listThreats: API.PaginatedOperationMethod<ListThreatsInput, ListThreatsOutput, ListThreatsError, Credentials | HttpClient.HttpClient, ThreatSummary>;
export type StartCodeRemediationError = CommonErrors;
/**
 * Initiates code remediation for one or more security findings. This creates pull requests in integrated repositories to fix the identified vulnerabilities.
 */
export declare const startCodeRemediation: API.OperationMethod<StartCodeRemediationInput, StartCodeRemediationOutput, StartCodeRemediationError, Credentials | HttpClient.HttpClient>;
export type StartCodeReviewJobError = CommonErrors;
/**
 * Starts a new code review job for a code review configuration. The job executes the security-focused code analysis defined in the code review.
 */
export declare const startCodeReviewJob: API.OperationMethod<StartCodeReviewJobInput, StartCodeReviewJobOutput, StartCodeReviewJobError, Credentials | HttpClient.HttpClient>;
export type StartPentestJobError = CommonErrors;
/**
 * Starts a new pentest job for a pentest configuration. The job executes the security tests defined in the pentest.
 */
export declare const startPentestJob: API.OperationMethod<StartPentestJobInput, StartPentestJobOutput, StartPentestJobError, Credentials | HttpClient.HttpClient>;
export type StartThreatModelJobError = CommonErrors;
/**
 * Starts a new threat model job for a threat model configuration.
 */
export declare const startThreatModelJob: API.OperationMethod<StartThreatModelJobInput, StartThreatModelJobOutput, StartThreatModelJobError, Credentials | HttpClient.HttpClient>;
export type StopCodeReviewJobError = CommonErrors;
/**
 * Stops a running code review job. The job transitions to a stopping state and then to stopped after cleanup completes.
 */
export declare const stopCodeReviewJob: API.OperationMethod<StopCodeReviewJobInput, StopCodeReviewJobOutput, StopCodeReviewJobError, Credentials | HttpClient.HttpClient>;
export type StopPentestJobError = CommonErrors;
/**
 * Stops a running pentest job. The job transitions to a stopping state and then to stopped after cleanup completes.
 */
export declare const stopPentestJob: API.OperationMethod<StopPentestJobInput, StopPentestJobOutput, StopPentestJobError, Credentials | HttpClient.HttpClient>;
export type StopThreatModelJobError = CommonErrors;
/**
 * Stops a running threat model job.
 */
export declare const stopThreatModelJob: API.OperationMethod<StopThreatModelJobInput, StopThreatModelJobOutput, StopThreatModelJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = CommonErrors;
/**
 * Adds tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentSpaceError = CommonErrors;
/**
 * Updates the configuration of an existing agent space, including its name, description, AWS resources, target domains, and code review settings.
 */
export declare const updateAgentSpace: API.OperationMethod<UpdateAgentSpaceInput, UpdateAgentSpaceOutput, UpdateAgentSpaceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = CommonErrors;
/**
 * Updates the configuration of an existing application, including the IAM role and default KMS key.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateCodeReviewError = CommonErrors;
/**
 * Updates an existing code review configuration.
 */
export declare const updateCodeReview: API.OperationMethod<UpdateCodeReviewInput, UpdateCodeReviewOutput, UpdateCodeReviewError, Credentials | HttpClient.HttpClient>;
export type UpdateFindingError = CommonErrors;
/**
 * Updates the status or risk level of a security finding.
 */
export declare const updateFinding: API.OperationMethod<UpdateFindingInput, UpdateFindingOutput, UpdateFindingError, Credentials | HttpClient.HttpClient>;
export type UpdateIntegratedResourcesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the integrated resources for an agent space, including their capabilities.
 */
export declare const updateIntegratedResources: API.OperationMethod<UpdateIntegratedResourcesInput, UpdateIntegratedResourcesOutput, UpdateIntegratedResourcesError, Credentials | HttpClient.HttpClient>;
export type UpdateIntegrationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an integration's webhook, or rotates the HMAC signing secret of an existing one. The secret is returned only once, in this response, and cannot be retrieved again.
 */
export declare const updateIntegration: API.OperationMethod<UpdateIntegrationInput, UpdateIntegrationOutput, UpdateIntegrationError, Credentials | HttpClient.HttpClient>;
export type UpdatePentestError = CommonErrors;
/**
 * Updates an existing pentest configuration.
 */
export declare const updatePentest: API.OperationMethod<UpdatePentestInput, UpdatePentestOutput, UpdatePentestError, Credentials | HttpClient.HttpClient>;
export type UpdatePrivateConnectionCertificateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the certificate associated with a private connection. Certificates can be added or replaced but not removed.
 */
export declare const updatePrivateConnectionCertificate: API.OperationMethod<UpdatePrivateConnectionCertificateInput, UpdatePrivateConnectionCertificateOutput, UpdatePrivateConnectionCertificateError, Credentials | HttpClient.HttpClient>;
export type UpdateSecurityRequirementPackError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a security requirement pack. For customer managed packs, both metadata and status can be updated. For AWS managed packs, only status can be updated.
 */
export declare const updateSecurityRequirementPack: API.OperationMethod<UpdateSecurityRequirementPackInput, UpdateSecurityRequirementPackOutput, UpdateSecurityRequirementPackError, Credentials | HttpClient.HttpClient>;
export type UpdateTargetDomainError = CommonErrors;
/**
 * Updates the verification method for a target domain.
 */
export declare const updateTargetDomain: API.OperationMethod<UpdateTargetDomainInput, UpdateTargetDomainOutput, UpdateTargetDomainError, Credentials | HttpClient.HttpClient>;
export type UpdateThreatError = CommonErrors;
/**
 * Updates a threat.
 */
export declare const updateThreat: API.OperationMethod<UpdateThreatInput, UpdateThreatOutput, UpdateThreatError, Credentials | HttpClient.HttpClient>;
export type UpdateThreatModelError = CommonErrors;
/**
 * Updates an existing threat model configuration.
 */
export declare const updateThreatModel: API.OperationMethod<UpdateThreatModelInput, UpdateThreatModelOutput, UpdateThreatModelError, Credentials | HttpClient.HttpClient>;
export type VerifyTargetDomainError = CommonErrors;
/**
 * Initiates verification of a target domain. This checks whether the domain ownership verification token has been properly configured.
 */
export declare const verifyTargetDomain: API.OperationMethod<VerifyTargetDomainInput, VerifyTargetDomainOutput, VerifyTargetDomainError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=securityagent.d.ts.map