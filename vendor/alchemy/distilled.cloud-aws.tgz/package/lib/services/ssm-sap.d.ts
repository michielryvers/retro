import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type PermissionActionType = "RESTORE" | (string & {});
export type Arn = string;
export interface DeleteResourcePermissionInput {
    ActionType?: PermissionActionType;
    SourceResourceArn?: string;
    ResourceArn: string;
}
export interface DeleteResourcePermissionOutput {
    Policy?: string;
}
export type ApplicationId = string;
export interface DeregisterApplicationInput {
    ApplicationId: string;
}
export interface DeregisterApplicationOutput {
}
export type SsmSapArn = string;
export type AppRegistryArn = string;
export interface GetApplicationInput {
    ApplicationId?: string;
    ApplicationArn?: string;
    AppRegistryArn?: string;
}
export type ApplicationType = "HANA" | "SAP_ABAP" | (string & {});
export type ApplicationStatus = "ACTIVATED" | "STARTING" | "STOPPED" | "STOPPING" | "FAILED" | "REGISTERING" | "DELETING" | "UNKNOWN" | (string & {});
export type ApplicationDiscoveryStatus = "SUCCESS" | "REGISTRATION_FAILED" | "REFRESH_FAILED" | "REGISTERING" | "DELETING" | (string & {});
export type ComponentId = string;
export type ComponentIdList = string[];
export type ApplicationArnList = string[];
export interface Application {
    Id?: string;
    Type?: ApplicationType;
    Arn?: string;
    AppRegistryArn?: string;
    Status?: ApplicationStatus;
    DiscoveryStatus?: ApplicationDiscoveryStatus;
    Components?: string[];
    LastUpdated?: Date;
    StatusMessage?: string;
    AssociatedApplicationArns?: string[];
}
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface GetApplicationOutput {
    Application?: Application;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetComponentInput {
    ApplicationId: string;
    ComponentId: string;
}
export type SID = string;
export type SAPInstanceNumber = string;
export type ComponentType = "HANA" | "HANA_NODE" | "ABAP" | "ASCS" | "DIALOG" | "WEBDISP" | "WD" | "ERS" | (string & {});
export type ComponentStatus = "ACTIVATED" | "STARTING" | "STOPPED" | "STOPPING" | "RUNNING" | "RUNNING_WITH_ERROR" | "UNDEFINED" | (string & {});
export type ReplicationMode = "PRIMARY" | "NONE" | "SYNC" | "SYNCMEM" | "ASYNC" | (string & {});
export type OperationMode = "PRIMARY" | "LOGREPLAY" | "DELTA_DATASHIPPING" | "LOGREPLAY_READACCESS" | "NONE" | (string & {});
export type ClusterStatus = "ONLINE" | "STANDBY" | "MAINTENANCE" | "OFFLINE" | "NONE" | (string & {});
export interface Resilience {
    HsrTier?: string;
    HsrReplicationMode?: ReplicationMode;
    HsrOperationMode?: OperationMode;
    ClusterStatus?: ClusterStatus;
    EnqueueReplication?: boolean;
}
export type AllocationType = "VPC_SUBNET" | "ELASTIC_IP" | "OVERLAY" | "UNKNOWN" | (string & {});
export interface IpAddressMember {
    IpAddress?: string;
    Primary?: boolean;
    AllocationType?: AllocationType;
}
export type IpAddressList = IpAddressMember[];
export interface AssociatedHost {
    Hostname?: string;
    Ec2InstanceId?: string;
    IpAddresses?: IpAddressMember[];
    OsVersion?: string;
}
export type DatabaseId = string;
export type DatabaseIdList = string[];
export type HostRole = "LEADER" | "WORKER" | "STANDBY" | "UNKNOWN" | (string & {});
export interface Host {
    HostName?: string;
    HostIp?: string;
    EC2InstanceId?: string;
    InstanceId?: string;
    HostRole?: HostRole;
    OsVersion?: string;
}
export type HostList = Host[];
export type DatabaseConnectionMethod = "DIRECT" | "OVERLAY" | (string & {});
export interface DatabaseConnection {
    DatabaseConnectionMethod?: DatabaseConnectionMethod;
    DatabaseArn?: string;
    ConnectionIp?: string;
}
export interface Component {
    ComponentId?: string;
    Sid?: string;
    SystemNumber?: string;
    ParentComponent?: string;
    ChildComponents?: string[];
    ApplicationId?: string;
    ComponentType?: ComponentType;
    Status?: ComponentStatus;
    SapHostname?: string;
    SapFeature?: string;
    SapKernelVersion?: string;
    HdbVersion?: string;
    Resilience?: Resilience;
    AssociatedHost?: AssociatedHost;
    Databases?: string[];
    Hosts?: Host[];
    PrimaryHost?: string;
    DatabaseConnection?: DatabaseConnection;
    LastUpdated?: Date;
    Arn?: string;
}
export interface GetComponentOutput {
    Component?: Component;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type OperationId = string;
export interface GetConfigurationCheckOperationInput {
    OperationId: string;
}
export type OperationStatus = "INPROGRESS" | "SUCCESS" | "ERROR" | (string & {});
export type ConfigurationCheckType = "SAP_CHECK_01" | "SAP_CHECK_02" | "SAP_CHECK_03" | (string & {});
export interface RuleStatusCounts {
    Failed?: number;
    Warning?: number;
    Info?: number;
    Passed?: number;
    Unknown?: number;
}
export interface ConfigurationCheckOperation {
    Id?: string;
    ApplicationId?: string;
    Status?: OperationStatus;
    StatusMessage?: string;
    ConfigurationCheckId?: ConfigurationCheckType;
    ConfigurationCheckName?: string;
    ConfigurationCheckDescription?: string;
    StartTime?: Date;
    EndTime?: Date;
    RuleStatusCounts?: RuleStatusCounts;
}
export interface GetConfigurationCheckOperationOutput {
    ConfigurationCheckOperation?: ConfigurationCheckOperation;
}
export interface GetDatabaseInput {
    ApplicationId?: string;
    ComponentId?: string;
    DatabaseId?: string;
    DatabaseArn?: string;
}
export type DatabaseName = string;
export type CredentialType = "ADMIN" | (string & {});
export type SecretId = string | redacted.Redacted<string>;
export interface ApplicationCredential {
    DatabaseName: string;
    CredentialType: CredentialType;
    SecretId: string | redacted.Redacted<string>;
}
export type ApplicationCredentialList = ApplicationCredential[];
export type DatabaseType = "SYSTEM" | "TENANT" | (string & {});
export type DatabaseStatus = "RUNNING" | "STARTING" | "STOPPED" | "WARNING" | "UNKNOWN" | "ERROR" | "STOPPING" | (string & {});
export type ComponentArnList = string[];
export interface Database {
    ApplicationId?: string;
    ComponentId?: string;
    Credentials?: ApplicationCredential[];
    DatabaseId?: string;
    DatabaseName?: string;
    DatabaseType?: DatabaseType;
    Arn?: string;
    Status?: DatabaseStatus;
    PrimaryHost?: string;
    SQLPort?: number;
    LastUpdated?: Date;
    ConnectedComponentArns?: string[];
}
export interface GetDatabaseOutput {
    Database?: Database;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetOperationInput {
    OperationId: string;
}
export type OperationType = string;
export type OperationProperties = {
    [key: string]: string | undefined;
};
export type ResourceType = string;
export type ResourceId = string;
export interface Operation {
    Id?: string;
    Type?: string;
    Status?: OperationStatus;
    StatusMessage?: string;
    Properties?: {
        [key: string]: string | undefined;
    };
    ResourceType?: string;
    ResourceId?: string;
    ResourceArn?: string;
    StartTime?: Date;
    EndTime?: Date;
    LastUpdatedTime?: Date;
}
export interface GetOperationOutput {
    Operation?: Operation;
}
export interface GetResourcePermissionInput {
    ActionType?: PermissionActionType;
    ResourceArn: string;
}
export interface GetResourcePermissionOutput {
    Policy?: string;
}
export type NextToken = string;
export type MaxResults = number;
export type FilterName = string;
export type FilterValue = string;
export type FilterOperator = "Equals" | "GreaterThanOrEquals" | "LessThanOrEquals" | (string & {});
export interface Filter {
    Name: string;
    Value: string;
    Operator: FilterOperator;
}
export type FilterList = Filter[];
export interface ListApplicationsInput {
    NextToken?: string;
    MaxResults?: number;
    Filters?: Filter[];
}
export interface ApplicationSummary {
    Id?: string;
    DiscoveryStatus?: ApplicationDiscoveryStatus;
    Type?: ApplicationType;
    Arn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type ApplicationSummaryList = ApplicationSummary[];
export interface ListApplicationsOutput {
    Applications?: ApplicationSummary[];
    NextToken?: string;
}
export interface ListComponentsInput {
    ApplicationId?: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface ComponentSummary {
    ApplicationId?: string;
    ComponentId?: string;
    ComponentType?: ComponentType;
    Tags?: {
        [key: string]: string | undefined;
    };
    Arn?: string;
}
export type ComponentSummaryList = ComponentSummary[];
export interface ListComponentsOutput {
    Components?: ComponentSummary[];
    NextToken?: string;
}
export interface ListConfigurationCheckDefinitionsInput {
    MaxResults?: number;
    NextToken?: string;
}
export type ApplicationTypeList = ApplicationType[];
export interface ConfigurationCheckDefinition {
    Id?: ConfigurationCheckType;
    Name?: string;
    Description?: string;
    ApplicableApplicationTypes?: ApplicationType[];
}
export type ConfigurationCheckDefinitionList = ConfigurationCheckDefinition[];
export interface ListConfigurationCheckDefinitionsOutput {
    ConfigurationChecks?: ConfigurationCheckDefinition[];
    NextToken?: string;
}
export type ConfigurationCheckOperationListingMode = "ALL_OPERATIONS" | "LATEST_PER_CHECK" | (string & {});
export interface ListConfigurationCheckOperationsInput {
    ApplicationId: string;
    ListMode?: ConfigurationCheckOperationListingMode;
    MaxResults?: number;
    NextToken?: string;
    Filters?: Filter[];
}
export type ConfigurationCheckOperationList = ConfigurationCheckOperation[];
export interface ListConfigurationCheckOperationsOutput {
    ConfigurationCheckOperations?: ConfigurationCheckOperation[];
    NextToken?: string;
}
export interface ListDatabasesInput {
    ApplicationId?: string;
    ComponentId?: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface DatabaseSummary {
    ApplicationId?: string;
    ComponentId?: string;
    DatabaseId?: string;
    DatabaseType?: DatabaseType;
    Arn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type DatabaseSummaryList = DatabaseSummary[];
export interface ListDatabasesOutput {
    Databases?: DatabaseSummary[];
    NextToken?: string;
}
export interface ListOperationEventsInput {
    OperationId: string;
    MaxResults?: number;
    NextToken?: string;
    Filters?: Filter[];
}
export type OperationEventResourceType = string;
export interface Resource {
    ResourceArn?: string;
    ResourceType?: string;
}
export type OperationEventStatus = "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export interface OperationEvent {
    Description?: string;
    Resource?: Resource;
    Status?: OperationEventStatus;
    StatusMessage?: string;
    Timestamp?: Date;
}
export type OperationEventList = OperationEvent[];
export interface ListOperationEventsOutput {
    OperationEvents?: OperationEvent[];
    NextToken?: string;
}
export interface ListOperationsInput {
    ApplicationId: string;
    MaxResults?: number;
    NextToken?: string;
    Filters?: Filter[];
}
export type OperationList = Operation[];
export interface ListOperationsOutput {
    Operations?: Operation[];
    NextToken?: string;
}
export interface ListSubCheckResultsInput {
    OperationId: string;
    MaxResults?: number;
    NextToken?: string;
}
export type SubCheckResultId = string;
export type SubCheckReferencesList = string[];
export interface SubCheckResult {
    Id?: string;
    Name?: string;
    Description?: string;
    References?: string[];
}
export type SubCheckResultList = SubCheckResult[];
export interface ListSubCheckResultsOutput {
    SubCheckResults?: SubCheckResult[];
    NextToken?: string;
}
export interface ListSubCheckRuleResultsInput {
    SubCheckResultId: string;
    MaxResults?: number;
    NextToken?: string;
}
export type RuleResultId = string;
export type RuleResultStatus = "PASSED" | "FAILED" | "WARNING" | "INFO" | "UNKNOWN" | (string & {});
export type RuleResultMetadataKey = string;
export type RuleResultMetadataValue = string;
export type RuleResultMetadata = {
    [key: string]: string | undefined;
};
export interface RuleResult {
    Id?: string;
    Description?: string;
    Status?: RuleResultStatus;
    Message?: string;
    Metadata?: {
        [key: string]: string | undefined;
    };
}
export type RuleResultList = RuleResult[];
export interface ListSubCheckRuleResultsOutput {
    RuleResults?: RuleResult[];
    NextToken?: string;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface PutResourcePermissionInput {
    ActionType: PermissionActionType;
    SourceResourceArn: string;
    ResourceArn: string;
}
export interface PutResourcePermissionOutput {
    Policy?: string;
}
export type InstanceId = string;
export type InstanceList = string[];
export interface ComponentInfo {
    ComponentType: ComponentType;
    Sid: string;
    Ec2InstanceId: string;
}
export type ComponentInfoList = ComponentInfo[];
export interface RegisterApplicationInput {
    ApplicationId: string;
    ApplicationType: ApplicationType;
    Instances: string[];
    SapInstanceNumber?: string;
    Sid?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Credentials?: ApplicationCredential[];
    DatabaseArn?: string;
    ComponentsInfo?: ComponentInfo[];
}
export interface RegisterApplicationOutput {
    Application?: Application;
    OperationId?: string;
}
export interface StartApplicationInput {
    ApplicationId: string;
}
export interface StartApplicationOutput {
    OperationId?: string;
}
export interface StartApplicationRefreshInput {
    ApplicationId: string;
}
export interface StartApplicationRefreshOutput {
    OperationId?: string;
}
export type ConfigurationCheckTypeList = ConfigurationCheckType[];
export interface StartConfigurationChecksInput {
    ApplicationId: string;
    ConfigurationCheckIds?: ConfigurationCheckType[];
}
export interface StartConfigurationChecksOutput {
    ConfigurationCheckOperations?: ConfigurationCheckOperation[];
}
export type ConnectedEntityType = "DBMS" | (string & {});
export interface StopApplicationInput {
    ApplicationId: string;
    StopConnectedEntity?: ConnectedEntityType;
    IncludeEc2InstanceShutdown?: boolean;
}
export interface StopApplicationOutput {
    OperationId?: string;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export type BackintMode = "AWSBackup" | (string & {});
export interface BackintConfig {
    BackintMode: BackintMode;
    EnsureNoBackupInProcess: boolean;
}
export interface UpdateApplicationSettingsInput {
    ApplicationId: string;
    CredentialsToAddOrUpdate?: ApplicationCredential[];
    CredentialsToRemove?: ApplicationCredential[];
    Backint?: BackintConfig;
    DatabaseArn?: string;
}
export type OperationIdList = string[];
export interface UpdateApplicationSettingsOutput {
    Message?: string;
    OperationIds?: string[];
}
export type DeleteResourcePermissionError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes permissions associated with the target database.
 */
export declare const deleteResourcePermission: API.OperationMethod<DeleteResourcePermissionInput, DeleteResourcePermissionOutput, DeleteResourcePermissionError, Credentials | HttpClient.HttpClient>;
export type DeregisterApplicationError = InternalServerException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deregister an SAP application with AWS Systems Manager for SAP. This action does not aU+FB00ect the existing setup of your SAP workloads on Amazon EC2.
 */
export declare const deregisterApplication: API.OperationMethod<DeregisterApplicationInput, DeregisterApplicationOutput, DeregisterApplicationError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = InternalServerException | ValidationException | CommonErrors;
/**
 * Gets an application registered with AWS Systems Manager for SAP. It also returns the components of the application.
 */
export declare const getApplication: API.OperationMethod<GetApplicationInput, GetApplicationOutput, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetComponentError = InternalServerException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Gets the component of an application registered with AWS Systems Manager for SAP.
 */
export declare const getComponent: API.OperationMethod<GetComponentInput, GetComponentOutput, GetComponentError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationCheckOperationError = InternalServerException | ValidationException | CommonErrors;
/**
 * Gets the details of a configuration check operation by specifying the operation ID.
 */
export declare const getConfigurationCheckOperation: API.OperationMethod<GetConfigurationCheckOperationInput, GetConfigurationCheckOperationOutput, GetConfigurationCheckOperationError, Credentials | HttpClient.HttpClient>;
export type GetDatabaseError = InternalServerException | ValidationException | CommonErrors;
/**
 * Gets the SAP HANA database of an application registered with AWS Systems Manager for SAP.
 */
export declare const getDatabase: API.OperationMethod<GetDatabaseInput, GetDatabaseOutput, GetDatabaseError, Credentials | HttpClient.HttpClient>;
export type GetOperationError = InternalServerException | ValidationException | CommonErrors;
/**
 * Gets the details of an operation by specifying the operation ID.
 */
export declare const getOperation: API.OperationMethod<GetOperationInput, GetOperationOutput, GetOperationError, Credentials | HttpClient.HttpClient>;
export type GetResourcePermissionError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets permissions associated with the target database.
 */
export declare const getResourcePermission: API.OperationMethod<GetResourcePermissionInput, GetResourcePermissionOutput, GetResourcePermissionError, Credentials | HttpClient.HttpClient>;
export type ListApplicationsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all the applications registered with AWS Systems Manager for SAP.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsInput, ListApplicationsOutput, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationSummary>;
export type ListComponentsError = InternalServerException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists all the components registered with AWS Systems Manager for SAP.
 */
export declare const listComponents: API.PaginatedOperationMethod<ListComponentsInput, ListComponentsOutput, ListComponentsError, Credentials | HttpClient.HttpClient, ComponentSummary>;
export type ListConfigurationCheckDefinitionsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists all configuration check types supported by AWS Systems Manager for SAP.
 */
export declare const listConfigurationCheckDefinitions: API.PaginatedOperationMethod<ListConfigurationCheckDefinitionsInput, ListConfigurationCheckDefinitionsOutput, ListConfigurationCheckDefinitionsError, Credentials | HttpClient.HttpClient, ConfigurationCheckDefinition>;
export type ListConfigurationCheckOperationsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the configuration check operations performed by AWS Systems Manager for SAP.
 */
export declare const listConfigurationCheckOperations: API.PaginatedOperationMethod<ListConfigurationCheckOperationsInput, ListConfigurationCheckOperationsOutput, ListConfigurationCheckOperationsError, Credentials | HttpClient.HttpClient, ConfigurationCheckOperation>;
export type ListDatabasesError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the SAP HANA databases of an application registered with AWS Systems Manager for SAP.
 */
export declare const listDatabases: API.PaginatedOperationMethod<ListDatabasesInput, ListDatabasesOutput, ListDatabasesError, Credentials | HttpClient.HttpClient, DatabaseSummary>;
export type ListOperationEventsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of operations events.
 *
 * Available parameters include `OperationID`, as well as optional parameters `MaxResults`, `NextToken`, and `Filters`.
 */
export declare const listOperationEvents: API.PaginatedOperationMethod<ListOperationEventsInput, ListOperationEventsOutput, ListOperationEventsError, Credentials | HttpClient.HttpClient, OperationEvent>;
export type ListOperationsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists the operations performed by AWS Systems Manager for SAP.
 */
export declare const listOperations: API.PaginatedOperationMethod<ListOperationsInput, ListOperationsOutput, ListOperationsError, Credentials | HttpClient.HttpClient, Operation>;
export type ListSubCheckResultsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists the sub-check results of a specified configuration check operation.
 */
export declare const listSubCheckResults: API.PaginatedOperationMethod<ListSubCheckResultsInput, ListSubCheckResultsOutput, ListSubCheckResultsError, Credentials | HttpClient.HttpClient, SubCheckResult>;
export type ListSubCheckRuleResultsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists the rules of a specified sub-check belonging to a configuration check operation.
 */
export declare const listSubCheckRuleResults: API.PaginatedOperationMethod<ListSubCheckRuleResultsInput, ListSubCheckRuleResultsOutput, ListSubCheckRuleResultsError, Credentials | HttpClient.HttpClient, RuleResult>;
export type ListTagsForResourceError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all tags on an SAP HANA application and/or database registered with AWS Systems Manager for SAP.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutResourcePermissionError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds permissions to the target database.
 */
export declare const putResourcePermission: API.OperationMethod<PutResourcePermissionInput, PutResourcePermissionOutput, PutResourcePermissionError, Credentials | HttpClient.HttpClient>;
export type RegisterApplicationError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Register an SAP application with AWS Systems Manager for SAP. You must meet the following requirements before registering.
 *
 * The SAP application you want to register with AWS Systems Manager for SAP is running on Amazon EC2.
 *
 * AWS Systems Manager Agent must be setup on an Amazon EC2 instance along with the required IAM permissions.
 *
 * Amazon EC2 instance(s) must have access to the secrets created in AWS Secrets Manager to manage SAP applications and components.
 */
export declare const registerApplication: API.OperationMethod<RegisterApplicationInput, RegisterApplicationOutput, RegisterApplicationError, Credentials | HttpClient.HttpClient>;
export type StartApplicationError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Request is an operation which starts an application.
 *
 * Parameter `ApplicationId` is required.
 */
export declare const startApplication: API.OperationMethod<StartApplicationInput, StartApplicationOutput, StartApplicationError, Credentials | HttpClient.HttpClient>;
export type StartApplicationRefreshError = ConflictException | InternalServerException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Refreshes a registered application.
 */
export declare const startApplicationRefresh: API.OperationMethod<StartApplicationRefreshInput, StartApplicationRefreshOutput, StartApplicationRefreshError, Credentials | HttpClient.HttpClient>;
export type StartConfigurationChecksError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Initiates configuration check operations against a specified application.
 */
export declare const startConfigurationChecks: API.OperationMethod<StartConfigurationChecksInput, StartConfigurationChecksOutput, StartConfigurationChecksError, Credentials | HttpClient.HttpClient>;
export type StopApplicationError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Request is an operation to stop an application.
 *
 * Parameter `ApplicationId` is required. Parameters `StopConnectedEntity` and `IncludeEc2InstanceShutdown` are optional.
 */
export declare const stopApplication: API.OperationMethod<StopApplicationInput, StopApplicationOutput, StopApplicationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates tag for a resource by specifying the ARN.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Delete the tags for a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationSettingsError = ConflictException | InternalServerException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Updates the settings of an application registered with AWS Systems Manager for SAP.
 */
export declare const updateApplicationSettings: API.OperationMethod<UpdateApplicationSettingsInput, UpdateApplicationSettingsOutput, UpdateApplicationSettingsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ssm-sap.d.ts.map