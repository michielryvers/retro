import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type MigrationWorkflowId = string;
export type TemplateSource = {
    workflowId: string;
};
export type ClientToken = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateTemplateRequest {
    templateName: string;
    templateDescription?: string;
    templateSource: TemplateSource;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type StringMapKey = string;
export type StringMapValue = string;
export type StringMap = {
    [key: string]: string | undefined;
};
export interface CreateTemplateResponse {
    templateId?: string;
    templateArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type StepInputParametersKey = string;
export type StringValue = string;
export type StringListMember = string;
export type StringList = string[];
export type StepInput = {
    integerValue: number;
    stringValue?: never;
    listOfStringsValue?: never;
    mapOfStringValue?: never;
} | {
    integerValue?: never;
    stringValue: string;
    listOfStringsValue?: never;
    mapOfStringValue?: never;
} | {
    integerValue?: never;
    stringValue?: never;
    listOfStringsValue: string[];
    mapOfStringValue?: never;
} | {
    integerValue?: never;
    stringValue?: never;
    listOfStringsValue?: never;
    mapOfStringValue: {
        [key: string]: string | undefined;
    };
};
export type StepInputParameters = {
    [key: string]: StepInput | undefined;
};
export interface CreateMigrationWorkflowRequest {
    name: string;
    description?: string;
    templateId: string;
    applicationConfigurationId?: string;
    inputParameters: {
        [key: string]: StepInput | undefined;
    };
    stepTargets?: string[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export type MigrationWorkflowStatusEnum = string;
export interface CreateMigrationWorkflowResponse {
    id?: string;
    arn?: string;
    name?: string;
    description?: string;
    templateId?: string;
    adsApplicationConfigurationId?: string;
    workflowInputs?: {
        [key: string]: StepInput | undefined;
    };
    stepTargets?: string[];
    status?: string;
    creationTime?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type MigrationWorkflowName = string;
export type StepGroupId = string;
export type StepActionType = string;
export type MigrationWorkflowDescription = string;
export type S3Bucket = string;
export type S3Key = string;
export interface PlatformScriptKey {
    linux?: string;
    windows?: string;
}
export interface PlatformCommand {
    linux?: string;
    windows?: string;
}
export type RunEnvironment = string;
export type TargetType = string;
export interface WorkflowStepAutomationConfiguration {
    scriptLocationS3Bucket?: string;
    scriptLocationS3Key?: PlatformScriptKey;
    command?: PlatformCommand;
    runEnvironment?: string;
    targetType?: string;
}
export type WorkflowStepOutputName = string;
export type DataType = string;
export type MaxStringValue = string;
export type MaxStringList = string[];
export type WorkflowStepOutputUnion = {
    integerValue: number;
    stringValue?: never;
    listOfStringValue?: never;
} | {
    integerValue?: never;
    stringValue: string;
    listOfStringValue?: never;
} | {
    integerValue?: never;
    stringValue?: never;
    listOfStringValue: string[];
};
export interface WorkflowStepOutput {
    name?: string;
    dataType?: string;
    required?: boolean;
    value?: WorkflowStepOutputUnion;
}
export type WorkflowStepOutputList = WorkflowStepOutput[];
export interface CreateWorkflowStepRequest {
    name: string;
    stepGroupId: string;
    workflowId: string;
    stepActionType: string;
    description?: string;
    workflowStepAutomationConfiguration?: WorkflowStepAutomationConfiguration;
    stepTarget?: string[];
    outputs?: WorkflowStepOutput[];
    previous?: string[];
    next?: string[];
}
export interface CreateWorkflowStepResponse {
    id?: string;
    stepGroupId?: string;
    workflowId?: string;
    name?: string;
}
export type StepGroupName = string;
export type StepGroupDescription = string;
export interface CreateWorkflowStepGroupRequest {
    workflowId: string;
    name: string;
    description?: string;
    next?: string[];
    previous?: string[];
}
export interface Tool {
    name?: string;
    url?: string;
}
export type ToolsList = Tool[];
export interface CreateWorkflowStepGroupResponse {
    workflowId?: string;
    name?: string;
    id?: string;
    description?: string;
    tools?: Tool[];
    next?: string[];
    previous?: string[];
    creationTime?: Date;
}
export type TemplateId = string;
export interface DeleteTemplateRequest {
    id: string;
}
export interface DeleteTemplateResponse {
}
export interface DeleteMigrationWorkflowRequest {
    id: string;
}
export interface DeleteMigrationWorkflowResponse {
    id?: string;
    arn?: string;
    status?: string;
}
export type StepId = string;
export interface DeleteWorkflowStepRequest {
    id: string;
    stepGroupId: string;
    workflowId: string;
}
export interface DeleteWorkflowStepResponse {
}
export interface DeleteWorkflowStepGroupRequest {
    workflowId: string;
    id: string;
}
export interface DeleteWorkflowStepGroupResponse {
}
export interface GetMigrationWorkflowTemplateRequest {
    id: string;
}
export type TemplateInputName = string;
export interface TemplateInput {
    inputName?: string;
    dataType?: string;
    required?: boolean;
}
export type TemplateInputList = TemplateInput[];
export type TemplateStatus = string;
export interface GetMigrationWorkflowTemplateResponse {
    id?: string;
    templateArn?: string;
    name?: string;
    description?: string;
    inputs?: TemplateInput[];
    tools?: Tool[];
    creationTime?: Date;
    owner?: string;
    status?: string;
    statusMessage?: string;
    templateClass?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetTemplateStepRequest {
    id: string;
    templateId: string;
    stepGroupId: string;
}
export interface StepOutput {
    name?: string;
    dataType?: string;
    required?: boolean;
}
export type StepOutputList = StepOutput[];
export interface StepAutomationConfiguration {
    scriptLocationS3Bucket?: string;
    scriptLocationS3Key?: PlatformScriptKey;
    command?: PlatformCommand;
    runEnvironment?: string;
    targetType?: string;
}
export interface GetTemplateStepResponse {
    id?: string;
    stepGroupId?: string;
    templateId?: string;
    name?: string;
    description?: string;
    stepActionType?: string;
    creationTime?: string;
    previous?: string[];
    next?: string[];
    outputs?: StepOutput[];
    stepAutomationConfiguration?: StepAutomationConfiguration;
}
export interface GetTemplateStepGroupRequest {
    templateId: string;
    id: string;
}
export type StepGroupStatus = string;
export interface GetTemplateStepGroupResponse {
    templateId?: string;
    id?: string;
    name?: string;
    description?: string;
    status?: string;
    creationTime?: Date;
    lastModifiedTime?: Date;
    tools?: Tool[];
    previous?: string[];
    next?: string[];
}
export interface GetMigrationWorkflowRequest {
    id: string;
}
export interface GetMigrationWorkflowResponse {
    id?: string;
    arn?: string;
    name?: string;
    description?: string;
    templateId?: string;
    adsApplicationConfigurationId?: string;
    adsApplicationName?: string;
    status?: string;
    statusMessage?: string;
    creationTime?: Date;
    lastStartTime?: Date;
    lastStopTime?: Date;
    lastModifiedTime?: Date;
    endTime?: Date;
    tools?: Tool[];
    totalSteps?: number;
    completedSteps?: number;
    workflowInputs?: {
        [key: string]: StepInput | undefined;
    };
    tags?: {
        [key: string]: string | undefined;
    };
    workflowBucket?: string;
}
export interface GetWorkflowStepRequest {
    workflowId: string;
    stepGroupId: string;
    id: string;
}
export type Owner = string;
export type StepStatus = string;
export interface GetWorkflowStepResponse {
    name?: string;
    stepGroupId?: string;
    workflowId?: string;
    stepId?: string;
    description?: string;
    stepActionType?: string;
    owner?: string;
    workflowStepAutomationConfiguration?: WorkflowStepAutomationConfiguration;
    stepTarget?: string[];
    outputs?: WorkflowStepOutput[];
    previous?: string[];
    next?: string[];
    status?: string;
    statusMessage?: string;
    scriptOutputLocation?: string;
    creationTime?: Date;
    lastStartTime?: Date;
    endTime?: Date;
    noOfSrvCompleted?: number;
    noOfSrvFailed?: number;
    totalNoOfSrv?: number;
}
export interface GetWorkflowStepGroupRequest {
    id: string;
    workflowId: string;
}
export interface GetWorkflowStepGroupResponse {
    id?: string;
    workflowId?: string;
    name?: string;
    description?: string;
    status?: string;
    owner?: string;
    creationTime?: Date;
    lastModifiedTime?: Date;
    endTime?: Date;
    tools?: Tool[];
    previous?: string[];
    next?: string[];
}
export type MaxResults = number;
export type NextToken = string;
export interface ListPluginsRequest {
    maxResults?: number;
    nextToken?: string;
}
export type PluginId = string;
export type PluginHealth = string;
export type IPAddress = string;
export type PluginVersion = string;
export interface PluginSummary {
    pluginId?: string;
    hostname?: string;
    status?: string;
    ipAddress?: string;
    version?: string;
    registeredTime?: string;
}
export type PluginSummaries = PluginSummary[];
export interface ListPluginsResponse {
    nextToken?: string;
    plugins?: PluginSummary[];
}
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export type TemplateName = string;
export interface ListMigrationWorkflowTemplatesRequest {
    maxResults?: number;
    nextToken?: string;
    name?: string;
}
export interface TemplateSummary {
    id?: string;
    name?: string;
    arn?: string;
    description?: string;
}
export type TemplateSummaryList = TemplateSummary[];
export interface ListMigrationWorkflowTemplatesResponse {
    nextToken?: string;
    templateSummary: TemplateSummary[];
}
export interface ListTemplateStepGroupsRequest {
    maxResults?: number;
    nextToken?: string;
    templateId: string;
}
export interface TemplateStepGroupSummary {
    id?: string;
    name?: string;
    previous?: string[];
    next?: string[];
}
export type TemplateStepGroupSummaryList = TemplateStepGroupSummary[];
export interface ListTemplateStepGroupsResponse {
    nextToken?: string;
    templateStepGroupSummary: TemplateStepGroupSummary[];
}
export interface ListTemplateStepsRequest {
    maxResults?: number;
    nextToken?: string;
    templateId: string;
    stepGroupId: string;
}
export interface TemplateStepSummary {
    id?: string;
    stepGroupId?: string;
    templateId?: string;
    name?: string;
    stepActionType?: string;
    targetType?: string;
    owner?: string;
    previous?: string[];
    next?: string[];
}
export type TemplateStepSummaryList = TemplateStepSummary[];
export interface ListTemplateStepsResponse {
    nextToken?: string;
    templateStepSummaryList?: TemplateStepSummary[];
}
export type ApplicationConfigurationName = string;
export interface ListMigrationWorkflowsRequest {
    maxResults?: number;
    nextToken?: string;
    templateId?: string;
    adsApplicationConfigurationName?: string;
    status?: string;
    name?: string;
}
export interface MigrationWorkflowSummary {
    id?: string;
    name?: string;
    templateId?: string;
    adsApplicationConfigurationName?: string;
    status?: string;
    creationTime?: Date;
    endTime?: Date;
    statusMessage?: string;
    completedSteps?: number;
    totalSteps?: number;
}
export type MigrationWorkflowSummaryList = MigrationWorkflowSummary[];
export interface ListMigrationWorkflowsResponse {
    nextToken?: string;
    migrationWorkflowSummary: MigrationWorkflowSummary[];
}
export interface ListWorkflowStepGroupsRequest {
    nextToken?: string;
    maxResults?: number;
    workflowId: string;
}
export interface WorkflowStepGroupSummary {
    id?: string;
    name?: string;
    owner?: string;
    status?: string;
    previous?: string[];
    next?: string[];
}
export type WorkflowStepGroupsSummaryList = WorkflowStepGroupSummary[];
export interface ListWorkflowStepGroupsResponse {
    nextToken?: string;
    workflowStepGroupsSummary: WorkflowStepGroupSummary[];
}
export interface ListWorkflowStepsRequest {
    nextToken?: string;
    maxResults?: number;
    workflowId: string;
    stepGroupId: string;
}
export interface WorkflowStepSummary {
    stepId?: string;
    name?: string;
    stepActionType?: string;
    owner?: string;
    previous?: string[];
    next?: string[];
    status?: string;
    statusMessage?: string;
    noOfSrvCompleted?: number;
    noOfSrvFailed?: number;
    totalNoOfSrv?: number;
    description?: string;
    scriptLocation?: string;
}
export type WorkflowStepsSummaryList = WorkflowStepSummary[];
export interface ListWorkflowStepsResponse {
    nextToken?: string;
    workflowStepsSummary: WorkflowStepSummary[];
}
export interface RetryWorkflowStepRequest {
    workflowId: string;
    stepGroupId: string;
    id: string;
}
export interface RetryWorkflowStepResponse {
    stepGroupId?: string;
    workflowId?: string;
    id?: string;
    status?: string;
}
export interface StartMigrationWorkflowRequest {
    id: string;
}
export interface StartMigrationWorkflowResponse {
    id?: string;
    arn?: string;
    status?: string;
    statusMessage?: string;
    lastStartTime?: Date;
}
export interface StopMigrationWorkflowRequest {
    id: string;
}
export interface StopMigrationWorkflowResponse {
    id?: string;
    arn?: string;
    status?: string;
    statusMessage?: string;
    lastStopTime?: Date;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateTemplateRequest {
    id: string;
    templateName?: string;
    templateDescription?: string;
    clientToken?: string;
}
export interface UpdateTemplateResponse {
    templateId?: string;
    templateArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface UpdateMigrationWorkflowRequest {
    id: string;
    name?: string;
    description?: string;
    inputParameters?: {
        [key: string]: StepInput | undefined;
    };
    stepTargets?: string[];
}
export interface UpdateMigrationWorkflowResponse {
    id?: string;
    arn?: string;
    name?: string;
    description?: string;
    templateId?: string;
    adsApplicationConfigurationId?: string;
    workflowInputs?: {
        [key: string]: StepInput | undefined;
    };
    stepTargets?: string[];
    status?: string;
    creationTime?: Date;
    lastModifiedTime?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type StepName = string;
export type StepDescription = string;
export interface UpdateWorkflowStepRequest {
    id: string;
    stepGroupId: string;
    workflowId: string;
    name?: string;
    description?: string;
    stepActionType?: string;
    workflowStepAutomationConfiguration?: WorkflowStepAutomationConfiguration;
    stepTarget?: string[];
    outputs?: WorkflowStepOutput[];
    previous?: string[];
    next?: string[];
    status?: string;
}
export interface UpdateWorkflowStepResponse {
    id?: string;
    stepGroupId?: string;
    workflowId?: string;
    name?: string;
}
export interface UpdateWorkflowStepGroupRequest {
    workflowId: string;
    id: string;
    name?: string;
    description?: string;
    next?: string[];
    previous?: string[];
}
export interface UpdateWorkflowStepGroupResponse {
    workflowId?: string;
    name?: string;
    id?: string;
    description?: string;
    tools?: Tool[];
    next?: string[];
    previous?: string[];
    lastModifiedTime?: Date;
}
export type CreateTemplateError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a migration workflow template.
 */
export declare const createTemplate: API.OperationMethod<CreateTemplateRequest, CreateTemplateResponse, CreateTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateWorkflowError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a workflow to orchestrate your migrations.
 */
export declare const createWorkflow: API.OperationMethod<CreateMigrationWorkflowRequest, CreateMigrationWorkflowResponse, CreateWorkflowError, Credentials | HttpClient.HttpClient>;
export type CreateWorkflowStepError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a step in the migration workflow.
 */
export declare const createWorkflowStep: API.OperationMethod<CreateWorkflowStepRequest, CreateWorkflowStepResponse, CreateWorkflowStepError, Credentials | HttpClient.HttpClient>;
export type CreateWorkflowStepGroupError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a step group in a migration workflow.
 */
export declare const createWorkflowStepGroup: API.OperationMethod<CreateWorkflowStepGroupRequest, CreateWorkflowStepGroupResponse, CreateWorkflowStepGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a migration workflow template.
 */
export declare const deleteTemplate: API.OperationMethod<DeleteTemplateRequest, DeleteTemplateResponse, DeleteTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a migration workflow. You must pause a running workflow in Migration Hub Orchestrator console to
 * delete it.
 */
export declare const deleteWorkflow: API.OperationMethod<DeleteMigrationWorkflowRequest, DeleteMigrationWorkflowResponse, DeleteWorkflowError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkflowStepError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a step in a migration workflow. Pause the workflow to delete a running
 * step.
 */
export declare const deleteWorkflowStep: API.OperationMethod<DeleteWorkflowStepRequest, DeleteWorkflowStepResponse, DeleteWorkflowStepError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkflowStepGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a step group in a migration workflow.
 */
export declare const deleteWorkflowStepGroup: API.OperationMethod<DeleteWorkflowStepGroupRequest, DeleteWorkflowStepGroupResponse, DeleteWorkflowStepGroupError, Credentials | HttpClient.HttpClient>;
export type GetTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Get the template you want to use for creating a migration workflow.
 */
export declare const getTemplate: API.OperationMethod<GetMigrationWorkflowTemplateRequest, GetMigrationWorkflowTemplateResponse, GetTemplateError, Credentials | HttpClient.HttpClient>;
export type GetTemplateStepError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a specific step in a template.
 */
export declare const getTemplateStep: API.OperationMethod<GetTemplateStepRequest, GetTemplateStepResponse, GetTemplateStepError, Credentials | HttpClient.HttpClient>;
export type GetTemplateStepGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a step group in a template.
 */
export declare const getTemplateStepGroup: API.OperationMethod<GetTemplateStepGroupRequest, GetTemplateStepGroupResponse, GetTemplateStepGroupError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get migration workflow.
 */
export declare const getWorkflow: API.OperationMethod<GetMigrationWorkflowRequest, GetMigrationWorkflowResponse, GetWorkflowError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowStepError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Get a step in the migration workflow.
 */
export declare const getWorkflowStep: API.OperationMethod<GetWorkflowStepRequest, GetWorkflowStepResponse, GetWorkflowStepError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowStepGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the step group of a migration workflow.
 */
export declare const getWorkflowStepGroup: API.OperationMethod<GetWorkflowStepGroupRequest, GetWorkflowStepGroupResponse, GetWorkflowStepGroupError, Credentials | HttpClient.HttpClient>;
export type ListPluginsError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * List AWS Migration Hub Orchestrator plugins.
 */
export declare const listPlugins: API.PaginatedOperationMethod<ListPluginsRequest, ListPluginsResponse, ListPluginsError, Credentials | HttpClient.HttpClient, PluginSummary>;
export type ListTagsForResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List the tags added to a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTemplatesError = AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * List the templates available in Migration Hub Orchestrator to create a migration workflow.
 */
export declare const listTemplates: API.PaginatedOperationMethod<ListMigrationWorkflowTemplatesRequest, ListMigrationWorkflowTemplatesResponse, ListTemplatesError, Credentials | HttpClient.HttpClient, TemplateSummary>;
export type ListTemplateStepGroupsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * List the step groups in a template.
 */
export declare const listTemplateStepGroups: API.PaginatedOperationMethod<ListTemplateStepGroupsRequest, ListTemplateStepGroupsResponse, ListTemplateStepGroupsError, Credentials | HttpClient.HttpClient, TemplateStepGroupSummary>;
export type ListTemplateStepsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the steps in a template.
 */
export declare const listTemplateSteps: API.PaginatedOperationMethod<ListTemplateStepsRequest, ListTemplateStepsResponse, ListTemplateStepsError, Credentials | HttpClient.HttpClient, TemplateStepSummary>;
export type ListWorkflowsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the migration workflows.
 */
export declare const listWorkflows: API.PaginatedOperationMethod<ListMigrationWorkflowsRequest, ListMigrationWorkflowsResponse, ListWorkflowsError, Credentials | HttpClient.HttpClient, MigrationWorkflowSummary>;
export type ListWorkflowStepGroupsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the step groups in a migration workflow.
 */
export declare const listWorkflowStepGroups: API.PaginatedOperationMethod<ListWorkflowStepGroupsRequest, ListWorkflowStepGroupsResponse, ListWorkflowStepGroupsError, Credentials | HttpClient.HttpClient, WorkflowStepGroupSummary>;
export type ListWorkflowStepsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the steps in a workflow.
 */
export declare const listWorkflowSteps: API.PaginatedOperationMethod<ListWorkflowStepsRequest, ListWorkflowStepsResponse, ListWorkflowStepsError, Credentials | HttpClient.HttpClient, WorkflowStepSummary>;
export type RetryWorkflowStepError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retry a failed step in a migration workflow.
 */
export declare const retryWorkflowStep: API.OperationMethod<RetryWorkflowStepRequest, RetryWorkflowStepResponse, RetryWorkflowStepError, Credentials | HttpClient.HttpClient>;
export type StartWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Start a migration workflow.
 */
export declare const startWorkflow: API.OperationMethod<StartMigrationWorkflowRequest, StartMigrationWorkflowResponse, StartWorkflowError, Credentials | HttpClient.HttpClient>;
export type StopWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stop an ongoing migration workflow.
 */
export declare const stopWorkflow: API.OperationMethod<StopMigrationWorkflowRequest, StopMigrationWorkflowResponse, StopWorkflowError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Tag a resource by specifying its Amazon Resource Name (ARN).
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the tags for a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a migration workflow template.
 */
export declare const updateTemplate: API.OperationMethod<UpdateTemplateRequest, UpdateTemplateResponse, UpdateTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a migration workflow.
 */
export declare const updateWorkflow: API.OperationMethod<UpdateMigrationWorkflowRequest, UpdateMigrationWorkflowResponse, UpdateWorkflowError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkflowStepError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a step in a migration workflow.
 */
export declare const updateWorkflowStep: API.OperationMethod<UpdateWorkflowStepRequest, UpdateWorkflowStepResponse, UpdateWorkflowStepError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkflowStepGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the step group in a migration workflow.
 */
export declare const updateWorkflowStepGroup: API.OperationMethod<UpdateWorkflowStepGroupRequest, UpdateWorkflowStepGroupResponse, UpdateWorkflowStepGroupError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=migrationhuborchestrator.d.ts.map