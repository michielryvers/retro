import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DependencyFailedException_base: S.TaggedErrorClass<"DependencyFailedException", {
    readonly message: any;
}>;
export declare class DependencyFailedException extends /*@__PURE__*/ DependencyFailedException_base {
}
declare const PreconditionFailedException_base: S.TaggedErrorClass<"PreconditionFailedException", {
    readonly message: any;
}>;
export declare class PreconditionFailedException extends /*@__PURE__*/ PreconditionFailedException_base {
}
declare const RequestTimeoutException_base: S.TaggedErrorClass<"RequestTimeoutException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class RequestTimeoutException extends /*@__PURE__*/ RequestTimeoutException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
    readonly resourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const UnprocessableContentException_base: S.TaggedErrorClass<"UnprocessableContentException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableContentException extends /*@__PURE__*/ UnprocessableContentException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type UuidOrArn = string;
export type UuidOrArnOrEitherWithQualifier = string;
export type Version = number;
export interface ActivateMessageTemplateRequest {
    knowledgeBaseId: string;
    messageTemplateId: string;
    versionNumber: number;
}
export type ArnWithQualifier = string;
export type Uuid = string;
export interface ActivateMessageTemplateResponse {
    messageTemplateArn: string;
    messageTemplateId: string;
    versionNumber: number;
}
export type ClientToken = string;
export type Name = string;
export type AIAgentType = string;
export type UuidWithQualifier = string;
export type AIAgentAssociationConfigurationType = string;
export type TagKey = string;
export type TagValue = string;
export interface TagCondition {
    key: string;
    value?: string;
}
export type AndConditions = TagCondition[];
export type OrCondition = {
    andConditions: TagCondition[];
    tagCondition?: never;
} | {
    andConditions?: never;
    tagCondition: TagCondition;
};
export type OrConditions = OrCondition[];
export type TagFilter = {
    tagCondition: TagCondition;
    andConditions?: never;
    orConditions?: never;
} | {
    tagCondition?: never;
    andConditions: TagCondition[];
    orConditions?: never;
} | {
    tagCondition?: never;
    andConditions?: never;
    orConditions: OrCondition[];
};
export type MaxResults = number;
export type KnowledgeBaseSearchType = string;
export interface KnowledgeBaseAssociationConfigurationData {
    contentTagFilter?: TagFilter;
    maxResults?: number;
    overrideKnowledgeBaseSearchType?: string;
}
export type AssociationConfigurationData = {
    knowledgeBaseAssociationConfigurationData: KnowledgeBaseAssociationConfigurationData;
};
export interface AssociationConfiguration {
    associationId?: string;
    associationType?: string;
    associationConfigurationData?: AssociationConfigurationData;
}
export type AssociationConfigurationList = AssociationConfiguration[];
export type NonEmptyString = string;
export interface ManualSearchAIAgentConfiguration {
    answerGenerationAIPromptId?: string;
    answerGenerationAIGuardrailId?: string;
    associationConfigurations?: AssociationConfiguration[];
    locale?: string;
}
export type NonEmptySensitiveString = string | redacted.Redacted<string>;
export type SuggestedMessagesList = (string | redacted.Redacted<string>)[];
export interface AnswerRecommendationAIAgentConfiguration {
    intentLabelingGenerationAIPromptId?: string;
    queryReformulationAIPromptId?: string;
    answerGenerationAIPromptId?: string;
    answerGenerationAIGuardrailId?: string;
    associationConfigurations?: AssociationConfiguration[];
    locale?: string;
    suggestedMessages?: (string | redacted.Redacted<string>)[];
}
export interface SelfServiceAIAgentConfiguration {
    selfServicePreProcessingAIPromptId?: string;
    selfServiceAnswerGenerationAIPromptId?: string;
    selfServiceAIGuardrailId?: string;
    associationConfigurations?: AssociationConfiguration[];
}
export interface EmailResponseAIAgentConfiguration {
    emailResponseAIPromptId?: string;
    emailQueryReformulationAIPromptId?: string;
    locale?: string;
    associationConfigurations?: AssociationConfiguration[];
}
export interface EmailOverviewAIAgentConfiguration {
    emailOverviewAIPromptId?: string;
    locale?: string;
}
export interface EmailGenerativeAnswerAIAgentConfiguration {
    emailGenerativeAnswerAIPromptId?: string;
    emailQueryReformulationAIPromptId?: string;
    locale?: string;
    associationConfigurations?: AssociationConfiguration[];
}
export type ToolType = string;
export type ToolExampleList = string[];
export interface ToolInstruction {
    instruction?: string;
    examples?: string[];
}
export type ToolOverrideInputValueType = string;
export interface ToolOverrideConstantInputValue {
    type: string;
    value: string | redacted.Redacted<string>;
}
export type ToolOverrideInputValueConfiguration = {
    constant: ToolOverrideConstantInputValue;
};
export interface ToolOverrideInputValue {
    jsonPath: string;
    value: ToolOverrideInputValueConfiguration;
}
export type ToolOverrideInputValueList = ToolOverrideInputValue[];
export interface ToolOutputConfiguration {
    outputVariableNameOverride?: string;
    sessionDataNamespace?: string;
}
export interface ToolOutputFilter {
    jsonPath: string;
    outputConfiguration?: ToolOutputConfiguration;
}
export type ToolOutputFilterList = ToolOutputFilter[];
export type JSONDocument = unknown;
export interface Annotation {
    title?: string;
    destructiveHint?: boolean;
}
export interface UserInteractionConfiguration {
    isUserConfirmationRequired?: boolean;
}
export interface ToolConfiguration {
    toolName: string;
    toolType: string;
    title?: string | redacted.Redacted<string>;
    toolId?: string;
    description?: string | redacted.Redacted<string>;
    instruction?: ToolInstruction;
    overrideInputValues?: ToolOverrideInputValue[];
    outputFilters?: ToolOutputFilter[];
    inputSchema?: any;
    outputSchema?: any;
    annotations?: Annotation;
    userInteractionConfiguration?: UserInteractionConfiguration;
}
export type ToolConfigurationList = ToolConfiguration[];
export type AgentTarget = {
    aiAgentId: string;
    applicationId?: never;
} | {
    aiAgentId?: never;
    applicationId: string;
};
export type MultiAgentExampleList = string[];
export interface MultiAgentInstruction {
    instruction?: string;
    examples?: string[];
}
export interface DelegateAgentConfiguration {
    agentTarget: AgentTarget;
    instruction?: MultiAgentInstruction;
}
export interface HandoffAgentConfiguration {
    agentTarget: AgentTarget;
    instruction?: MultiAgentInstruction;
    audioStreamingEnabled?: boolean;
    immediateHandoff?: boolean;
}
export type MultiAgentConfiguration = {
    delegateAgentConfiguration: DelegateAgentConfiguration;
    handoffAgentConfiguration?: never;
} | {
    delegateAgentConfiguration?: never;
    handoffAgentConfiguration: HandoffAgentConfiguration;
};
export type MultiAgentConfigurationList = MultiAgentConfiguration[];
export type GenericArn = string;
export type JSONDocumentList = any[];
export interface OrchestrationAIAgentConfiguration {
    orchestrationAIPromptId?: string;
    orchestrationAIGuardrailId?: string;
    toolConfigurations?: ToolConfiguration[];
    multiAgentConfigurations?: MultiAgentConfiguration[];
    connectInstanceArn?: string;
    locale?: string;
    inputSchemas?: any[];
    outputSchemas?: any[];
}
export interface NoteTakingAIAgentConfiguration {
    noteTakingAIPromptId?: string;
    noteTakingAIGuardrailId?: string;
    locale?: string;
}
export interface CaseSummarizationAIAgentConfiguration {
    caseSummarizationAIPromptId?: string;
    caseSummarizationAIGuardrailId?: string;
    locale?: string;
}
export type AIAgentConfiguration = {
    manualSearchAIAgentConfiguration: ManualSearchAIAgentConfiguration;
    answerRecommendationAIAgentConfiguration?: never;
    selfServiceAIAgentConfiguration?: never;
    emailResponseAIAgentConfiguration?: never;
    emailOverviewAIAgentConfiguration?: never;
    emailGenerativeAnswerAIAgentConfiguration?: never;
    orchestrationAIAgentConfiguration?: never;
    noteTakingAIAgentConfiguration?: never;
    caseSummarizationAIAgentConfiguration?: never;
} | {
    manualSearchAIAgentConfiguration?: never;
    answerRecommendationAIAgentConfiguration: AnswerRecommendationAIAgentConfiguration;
    selfServiceAIAgentConfiguration?: never;
    emailResponseAIAgentConfiguration?: never;
    emailOverviewAIAgentConfiguration?: never;
    emailGenerativeAnswerAIAgentConfiguration?: never;
    orchestrationAIAgentConfiguration?: never;
    noteTakingAIAgentConfiguration?: never;
    caseSummarizationAIAgentConfiguration?: never;
} | {
    manualSearchAIAgentConfiguration?: never;
    answerRecommendationAIAgentConfiguration?: never;
    selfServiceAIAgentConfiguration: SelfServiceAIAgentConfiguration;
    emailResponseAIAgentConfiguration?: never;
    emailOverviewAIAgentConfiguration?: never;
    emailGenerativeAnswerAIAgentConfiguration?: never;
    orchestrationAIAgentConfiguration?: never;
    noteTakingAIAgentConfiguration?: never;
    caseSummarizationAIAgentConfiguration?: never;
} | {
    manualSearchAIAgentConfiguration?: never;
    answerRecommendationAIAgentConfiguration?: never;
    selfServiceAIAgentConfiguration?: never;
    emailResponseAIAgentConfiguration: EmailResponseAIAgentConfiguration;
    emailOverviewAIAgentConfiguration?: never;
    emailGenerativeAnswerAIAgentConfiguration?: never;
    orchestrationAIAgentConfiguration?: never;
    noteTakingAIAgentConfiguration?: never;
    caseSummarizationAIAgentConfiguration?: never;
} | {
    manualSearchAIAgentConfiguration?: never;
    answerRecommendationAIAgentConfiguration?: never;
    selfServiceAIAgentConfiguration?: never;
    emailResponseAIAgentConfiguration?: never;
    emailOverviewAIAgentConfiguration: EmailOverviewAIAgentConfiguration;
    emailGenerativeAnswerAIAgentConfiguration?: never;
    orchestrationAIAgentConfiguration?: never;
    noteTakingAIAgentConfiguration?: never;
    caseSummarizationAIAgentConfiguration?: never;
} | {
    manualSearchAIAgentConfiguration?: never;
    answerRecommendationAIAgentConfiguration?: never;
    selfServiceAIAgentConfiguration?: never;
    emailResponseAIAgentConfiguration?: never;
    emailOverviewAIAgentConfiguration?: never;
    emailGenerativeAnswerAIAgentConfiguration: EmailGenerativeAnswerAIAgentConfiguration;
    orchestrationAIAgentConfiguration?: never;
    noteTakingAIAgentConfiguration?: never;
    caseSummarizationAIAgentConfiguration?: never;
} | {
    manualSearchAIAgentConfiguration?: never;
    answerRecommendationAIAgentConfiguration?: never;
    selfServiceAIAgentConfiguration?: never;
    emailResponseAIAgentConfiguration?: never;
    emailOverviewAIAgentConfiguration?: never;
    emailGenerativeAnswerAIAgentConfiguration?: never;
    orchestrationAIAgentConfiguration: OrchestrationAIAgentConfiguration;
    noteTakingAIAgentConfiguration?: never;
    caseSummarizationAIAgentConfiguration?: never;
} | {
    manualSearchAIAgentConfiguration?: never;
    answerRecommendationAIAgentConfiguration?: never;
    selfServiceAIAgentConfiguration?: never;
    emailResponseAIAgentConfiguration?: never;
    emailOverviewAIAgentConfiguration?: never;
    emailGenerativeAnswerAIAgentConfiguration?: never;
    orchestrationAIAgentConfiguration?: never;
    noteTakingAIAgentConfiguration: NoteTakingAIAgentConfiguration;
    caseSummarizationAIAgentConfiguration?: never;
} | {
    manualSearchAIAgentConfiguration?: never;
    answerRecommendationAIAgentConfiguration?: never;
    selfServiceAIAgentConfiguration?: never;
    emailResponseAIAgentConfiguration?: never;
    emailOverviewAIAgentConfiguration?: never;
    emailGenerativeAnswerAIAgentConfiguration?: never;
    orchestrationAIAgentConfiguration?: never;
    noteTakingAIAgentConfiguration?: never;
    caseSummarizationAIAgentConfiguration: CaseSummarizationAIAgentConfiguration;
};
export type VisibilityStatus = string;
export type Tags = {
    [key: string]: string | undefined;
};
export type Description = string;
export interface CreateAIAgentRequest {
    clientToken?: string;
    assistantId: string;
    name: string;
    type: string;
    configuration: AIAgentConfiguration;
    visibilityStatus: string;
    tags?: {
        [key: string]: string | undefined;
    };
    description?: string;
}
export type Arn = string;
export type Origin = string;
export type Status = string;
export interface AIAgentData {
    assistantId: string;
    assistantArn: string;
    aiAgentId: string;
    aiAgentArn: string;
    name: string;
    type: string;
    configuration: AIAgentConfiguration;
    modifiedTime?: Date;
    description?: string;
    visibilityStatus: string;
    tags?: {
        [key: string]: string | undefined;
    };
    origin?: string;
    status?: string;
}
export interface CreateAIAgentResponse {
    aiAgent?: AIAgentData;
}
export interface CreateAIAgentVersionRequest {
    assistantId: string;
    aiAgentId: string;
    modifiedTime?: Date;
    clientToken?: string;
}
export interface CreateAIAgentVersionResponse {
    aiAgent?: AIAgentData;
    versionNumber?: number;
}
export type AIGuardrailBlockedMessaging = string | redacted.Redacted<string>;
export type AIGuardrailDescription = string | redacted.Redacted<string>;
export type GuardrailTopicName = string | redacted.Redacted<string>;
export type GuardrailTopicDefinition = string | redacted.Redacted<string>;
export type GuardrailTopicExample = string | redacted.Redacted<string>;
export type GuardrailTopicExamples = (string | redacted.Redacted<string>)[];
export type GuardrailTopicType = string | redacted.Redacted<string>;
export interface GuardrailTopicConfig {
    name: string | redacted.Redacted<string>;
    definition: string | redacted.Redacted<string>;
    examples?: (string | redacted.Redacted<string>)[];
    type: string | redacted.Redacted<string>;
}
export type GuardrailTopicsConfig = GuardrailTopicConfig[];
export interface AIGuardrailTopicPolicyConfig {
    topicsConfig: GuardrailTopicConfig[];
}
export type GuardrailContentFilterType = string | redacted.Redacted<string>;
export type GuardrailFilterStrength = string | redacted.Redacted<string>;
export interface GuardrailContentFilterConfig {
    type: string | redacted.Redacted<string>;
    inputStrength: string | redacted.Redacted<string>;
    outputStrength: string | redacted.Redacted<string>;
}
export type GuardrailContentFiltersConfig = GuardrailContentFilterConfig[];
export interface AIGuardrailContentPolicyConfig {
    filtersConfig: GuardrailContentFilterConfig[];
}
export type GuardrailWordText = string | redacted.Redacted<string>;
export interface GuardrailWordConfig {
    text: string | redacted.Redacted<string>;
}
export type GuardrailWordsConfig = GuardrailWordConfig[];
export type GuardrailManagedWordsType = string | redacted.Redacted<string>;
export interface GuardrailManagedWordsConfig {
    type: string | redacted.Redacted<string>;
}
export type GuardrailManagedWordListsConfig = GuardrailManagedWordsConfig[];
export interface AIGuardrailWordPolicyConfig {
    wordsConfig?: GuardrailWordConfig[];
    managedWordListsConfig?: GuardrailManagedWordsConfig[];
}
export type GuardrailPiiEntityType = string | redacted.Redacted<string>;
export type GuardrailSensitiveInformationAction = string | redacted.Redacted<string>;
export interface GuardrailPiiEntityConfig {
    type: string | redacted.Redacted<string>;
    action: string | redacted.Redacted<string>;
}
export type GuardrailPiiEntitiesConfig = GuardrailPiiEntityConfig[];
export type GuardrailRegexName = string | redacted.Redacted<string>;
export type GuardrailRegexDescription = string | redacted.Redacted<string>;
export type GuardrailRegexPattern = string | redacted.Redacted<string>;
export interface GuardrailRegexConfig {
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    pattern: string | redacted.Redacted<string>;
    action: string | redacted.Redacted<string>;
}
export type GuardrailRegexesConfig = GuardrailRegexConfig[];
export interface AIGuardrailSensitiveInformationPolicyConfig {
    piiEntitiesConfig?: GuardrailPiiEntityConfig[];
    regexesConfig?: GuardrailRegexConfig[];
}
export type GuardrailContextualGroundingFilterType = string | redacted.Redacted<string>;
export type GuardrailContextualGroundingFilterThreshold = number;
export interface GuardrailContextualGroundingFilterConfig {
    type: string | redacted.Redacted<string>;
    threshold: number;
}
export type GuardrailContextualGroundingFiltersConfig = GuardrailContextualGroundingFilterConfig[];
export interface AIGuardrailContextualGroundingPolicyConfig {
    filtersConfig: GuardrailContextualGroundingFilterConfig[];
}
export interface CreateAIGuardrailRequest {
    clientToken?: string;
    assistantId: string;
    name: string;
    blockedInputMessaging: string | redacted.Redacted<string>;
    blockedOutputsMessaging: string | redacted.Redacted<string>;
    visibilityStatus: string;
    description?: string | redacted.Redacted<string>;
    topicPolicyConfig?: AIGuardrailTopicPolicyConfig;
    contentPolicyConfig?: AIGuardrailContentPolicyConfig;
    wordPolicyConfig?: AIGuardrailWordPolicyConfig;
    sensitiveInformationPolicyConfig?: AIGuardrailSensitiveInformationPolicyConfig;
    contextualGroundingPolicyConfig?: AIGuardrailContextualGroundingPolicyConfig;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface AIGuardrailData {
    assistantId: string;
    assistantArn: string;
    aiGuardrailArn: string;
    aiGuardrailId: string;
    name: string;
    visibilityStatus: string;
    blockedInputMessaging: string | redacted.Redacted<string>;
    blockedOutputsMessaging: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    topicPolicyConfig?: AIGuardrailTopicPolicyConfig;
    contentPolicyConfig?: AIGuardrailContentPolicyConfig;
    wordPolicyConfig?: AIGuardrailWordPolicyConfig;
    sensitiveInformationPolicyConfig?: AIGuardrailSensitiveInformationPolicyConfig;
    contextualGroundingPolicyConfig?: AIGuardrailContextualGroundingPolicyConfig;
    tags?: {
        [key: string]: string | undefined;
    };
    status?: string;
    modifiedTime?: Date;
}
export interface CreateAIGuardrailResponse {
    aiGuardrail?: AIGuardrailData;
}
export interface CreateAIGuardrailVersionRequest {
    assistantId: string;
    aiGuardrailId: string;
    modifiedTime?: Date;
    clientToken?: string;
}
export interface CreateAIGuardrailVersionResponse {
    aiGuardrail?: AIGuardrailData;
    versionNumber?: number;
}
export type AIPromptType = string;
export type TextAIPrompt = string | redacted.Redacted<string>;
export interface TextFullAIPromptEditTemplateConfiguration {
    text: string | redacted.Redacted<string>;
}
export type AIPromptTemplateConfiguration = {
    textFullAIPromptEditTemplateConfiguration: TextFullAIPromptEditTemplateConfiguration;
};
export type AIPromptTemplateType = string;
export type AIPromptModelIdentifier = string;
export type AIPromptAPIFormat = string;
export type Probability = number;
export type TopK = number;
export type MaxTokensToSample = number;
export interface AIPromptInferenceConfiguration {
    temperature?: number;
    topP?: number;
    topK?: number;
    maxTokensToSample?: number;
}
export interface CreateAIPromptRequest {
    clientToken?: string;
    assistantId: string;
    name: string;
    type: string;
    templateConfiguration: AIPromptTemplateConfiguration;
    visibilityStatus: string;
    templateType: string;
    modelId: string;
    apiFormat: string;
    tags?: {
        [key: string]: string | undefined;
    };
    description?: string;
    inferenceConfiguration?: AIPromptInferenceConfiguration;
}
export interface AIPromptData {
    assistantId: string;
    assistantArn: string;
    aiPromptId: string;
    aiPromptArn: string;
    name: string;
    type: string;
    templateType: string;
    modelId: string;
    apiFormat: string;
    templateConfiguration: AIPromptTemplateConfiguration;
    inferenceConfiguration?: AIPromptInferenceConfiguration;
    modifiedTime?: Date;
    description?: string;
    visibilityStatus: string;
    tags?: {
        [key: string]: string | undefined;
    };
    origin?: string;
    status?: string;
}
export interface CreateAIPromptResponse {
    aiPrompt?: AIPromptData;
}
export interface CreateAIPromptVersionRequest {
    assistantId: string;
    aiPromptId: string;
    modifiedTime?: Date;
    clientToken?: string;
}
export interface CreateAIPromptVersionResponse {
    aiPrompt?: AIPromptData;
    versionNumber?: number;
}
export type AssistantType = string;
export interface ServerSideEncryptionConfiguration {
    kmsKeyId?: string;
}
export interface CreateAssistantRequest {
    clientToken?: string;
    name: string;
    type: string;
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    serverSideEncryptionConfiguration?: ServerSideEncryptionConfiguration;
}
export type AssistantStatus = string;
export interface AssistantIntegrationConfiguration {
    topicIntegrationArn?: string;
}
export type AssistantCapabilityType = string;
export interface AssistantCapabilityConfiguration {
    type?: string;
}
export interface AIAgentConfigurationData {
    aiAgentId: string;
    enabled?: boolean;
}
export type AIAgentConfigurationMap = {
    [key: string]: AIAgentConfigurationData | undefined;
};
export interface OrchestratorConfigurationEntry {
    aiAgentId?: string;
    orchestratorUseCase: string;
}
export type OrchestratorConfigurationList = OrchestratorConfigurationEntry[];
export interface AssistantData {
    assistantId: string;
    assistantArn: string;
    name: string;
    type: string;
    status: string;
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    serverSideEncryptionConfiguration?: ServerSideEncryptionConfiguration;
    integrationConfiguration?: AssistantIntegrationConfiguration;
    capabilityConfiguration?: AssistantCapabilityConfiguration;
    aiAgentConfiguration?: {
        [key: string]: AIAgentConfigurationData | undefined;
    };
    orchestratorConfigurationList?: OrchestratorConfigurationEntry[];
}
export interface CreateAssistantResponse {
    assistant?: AssistantData;
}
export type AssociationType = string;
export type BedrockKnowledgeBaseArn = string;
export type AccessRoleArn = string;
export interface ExternalBedrockKnowledgeBaseConfig {
    bedrockKnowledgeBaseArn: string;
    accessRoleArn: string;
}
export type AssistantAssociationInputData = {
    knowledgeBaseId: string;
    externalBedrockKnowledgeBaseConfig?: never;
} | {
    knowledgeBaseId?: never;
    externalBedrockKnowledgeBaseConfig: ExternalBedrockKnowledgeBaseConfig;
};
export interface CreateAssistantAssociationRequest {
    assistantId: string;
    associationType: string;
    association: AssistantAssociationInputData;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface KnowledgeBaseAssociationData {
    knowledgeBaseId?: string;
    knowledgeBaseArn?: string;
}
export type AssistantAssociationOutputData = {
    knowledgeBaseAssociation: KnowledgeBaseAssociationData;
    externalBedrockKnowledgeBaseConfig?: never;
} | {
    knowledgeBaseAssociation?: never;
    externalBedrockKnowledgeBaseConfig: ExternalBedrockKnowledgeBaseConfig;
};
export interface AssistantAssociationData {
    assistantAssociationId: string;
    assistantAssociationArn: string;
    assistantId: string;
    assistantArn: string;
    associationType: string;
    associationData: AssistantAssociationOutputData;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateAssistantAssociationResponse {
    assistantAssociation?: AssistantAssociationData;
}
export type ContentTitle = string;
export type Uri = string;
export type ContentMetadata = {
    [key: string]: string | undefined;
};
export type UploadId = string;
export interface CreateContentRequest {
    knowledgeBaseId: string;
    name: string;
    title?: string;
    overrideLinkOutUri?: string;
    metadata?: {
        [key: string]: string | undefined;
    };
    uploadId: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type ContentType = string;
export type ContentStatus = string;
export type Url = string | redacted.Redacted<string>;
export interface ContentData {
    contentArn: string;
    contentId: string;
    knowledgeBaseArn: string;
    knowledgeBaseId: string;
    name: string;
    revisionId: string;
    title: string;
    contentType: string;
    status: string;
    metadata: {
        [key: string]: string | undefined;
    };
    tags?: {
        [key: string]: string | undefined;
    };
    linkOutUri?: string;
    url: string | redacted.Redacted<string>;
    urlExpiry: Date;
}
export interface CreateContentResponse {
    content?: ContentData;
}
export type ContentAssociationType = string;
export interface AmazonConnectGuideAssociationData {
    flowId?: string;
}
export type ContentAssociationContents = {
    amazonConnectGuideAssociation: AmazonConnectGuideAssociationData;
};
export interface CreateContentAssociationRequest {
    clientToken?: string;
    knowledgeBaseId: string;
    contentId: string;
    associationType: string;
    association: ContentAssociationContents;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface ContentAssociationData {
    knowledgeBaseId: string;
    knowledgeBaseArn: string;
    contentId: string;
    contentArn: string;
    contentAssociationId: string;
    contentAssociationArn: string;
    associationType: string;
    associationData: ContentAssociationContents;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateContentAssociationResponse {
    contentAssociation?: ContentAssociationData;
}
export type KnowledgeBaseType = string;
export type ObjectFieldsList = string[];
export interface AppIntegrationsConfiguration {
    appIntegrationArn: string;
    objectFields?: string[];
}
export type WebUrl = string;
export interface SeedUrl {
    url?: string;
}
export type SeedUrls = SeedUrl[];
export interface UrlConfiguration {
    seedUrls?: SeedUrl[];
}
export interface WebCrawlerLimits {
    rateLimit?: number;
}
export type UrlFilterPattern = string | redacted.Redacted<string>;
export type UrlFilterList = (string | redacted.Redacted<string>)[];
export type WebScopeType = string;
export interface WebCrawlerConfiguration {
    urlConfiguration: UrlConfiguration;
    crawlerLimits?: WebCrawlerLimits;
    inclusionFilters?: (string | redacted.Redacted<string>)[];
    exclusionFilters?: (string | redacted.Redacted<string>)[];
    scope?: string;
}
export type ManagedSourceConfiguration = {
    webCrawlerConfiguration: WebCrawlerConfiguration;
};
export type SourceConfiguration = {
    appIntegrations: AppIntegrationsConfiguration;
    managedSourceConfiguration?: never;
} | {
    appIntegrations?: never;
    managedSourceConfiguration: ManagedSourceConfiguration;
};
export interface RenderingConfiguration {
    templateUri?: string;
}
export type ChunkingStrategy = string;
export interface FixedSizeChunkingConfiguration {
    maxTokens: number;
    overlapPercentage: number;
}
export interface HierarchicalChunkingLevelConfiguration {
    maxTokens: number;
}
export type HierarchicalChunkingLevelConfigurations = HierarchicalChunkingLevelConfiguration[];
export interface HierarchicalChunkingConfiguration {
    levelConfigurations: HierarchicalChunkingLevelConfiguration[];
    overlapTokens: number;
}
export interface SemanticChunkingConfiguration {
    maxTokens: number;
    bufferSize: number;
    breakpointPercentileThreshold: number;
}
export interface ChunkingConfiguration {
    chunkingStrategy: string;
    fixedSizeChunkingConfiguration?: FixedSizeChunkingConfiguration;
    hierarchicalChunkingConfiguration?: HierarchicalChunkingConfiguration;
    semanticChunkingConfiguration?: SemanticChunkingConfiguration;
}
export type ParsingStrategy = string;
export type BedrockModelArnForParsing = string;
export type ParsingPromptText = string;
export interface ParsingPrompt {
    parsingPromptText: string;
}
export interface BedrockFoundationModelConfigurationForParsing {
    modelArn: string;
    parsingPrompt?: ParsingPrompt;
}
export interface ParsingConfiguration {
    parsingStrategy: string;
    bedrockFoundationModelConfiguration?: BedrockFoundationModelConfigurationForParsing;
}
export interface VectorIngestionConfiguration {
    chunkingConfiguration?: ChunkingConfiguration;
    parsingConfiguration?: ParsingConfiguration;
}
export interface CreateKnowledgeBaseRequest {
    clientToken?: string;
    name: string;
    knowledgeBaseType: string;
    sourceConfiguration?: SourceConfiguration;
    renderingConfiguration?: RenderingConfiguration;
    vectorIngestionConfiguration?: VectorIngestionConfiguration;
    serverSideEncryptionConfiguration?: ServerSideEncryptionConfiguration;
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type KnowledgeBaseStatus = string;
export type SyncStatus = string;
export type FailureReason = string[];
export interface KnowledgeBaseData {
    knowledgeBaseId: string;
    knowledgeBaseArn: string;
    name: string;
    knowledgeBaseType: string;
    status: string;
    lastContentModificationTime?: Date;
    vectorIngestionConfiguration?: VectorIngestionConfiguration;
    sourceConfiguration?: SourceConfiguration;
    renderingConfiguration?: RenderingConfiguration;
    serverSideEncryptionConfiguration?: ServerSideEncryptionConfiguration;
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    ingestionStatus?: string;
    ingestionFailureReasons?: string[];
}
export interface CreateKnowledgeBaseResponse {
    knowledgeBase?: KnowledgeBaseData;
}
export type NonEmptyUnlimitedString = string | redacted.Redacted<string>;
export type MessageTemplateBodyContentProvider = {
    content: string | redacted.Redacted<string>;
};
export interface EmailMessageTemplateContentBody {
    plainText?: MessageTemplateBodyContentProvider;
    html?: MessageTemplateBodyContentProvider;
}
export type EmailHeaderKey = string;
export type EmailHeaderValue = string | redacted.Redacted<string>;
export interface EmailHeader {
    name?: string;
    value?: string | redacted.Redacted<string>;
}
export type EmailHeaders = EmailHeader[];
export interface EmailMessageTemplateContent {
    subject?: string | redacted.Redacted<string>;
    body?: EmailMessageTemplateContentBody;
    headers?: EmailHeader[];
}
export interface SMSMessageTemplateContentBody {
    plainText?: MessageTemplateBodyContentProvider;
}
export interface SMSMessageTemplateContent {
    body?: SMSMessageTemplateContentBody;
}
export type WhatsAppMessageTemplateContentData = string;
export interface WhatsAppMessageTemplateContent {
    data?: string;
}
export type PushMessageAction = string;
export interface PushADMMessageTemplateContent {
    title?: string | redacted.Redacted<string>;
    body?: MessageTemplateBodyContentProvider;
    action?: string;
    sound?: string | redacted.Redacted<string>;
    url?: string | redacted.Redacted<string>;
    imageUrl?: string | redacted.Redacted<string>;
    imageIconUrl?: string | redacted.Redacted<string>;
    smallImageIconUrl?: string | redacted.Redacted<string>;
    rawContent?: MessageTemplateBodyContentProvider;
}
export interface PushAPNSMessageTemplateContent {
    title?: string | redacted.Redacted<string>;
    body?: MessageTemplateBodyContentProvider;
    action?: string;
    sound?: string | redacted.Redacted<string>;
    url?: string | redacted.Redacted<string>;
    mediaUrl?: string | redacted.Redacted<string>;
    rawContent?: MessageTemplateBodyContentProvider;
}
export interface PushFCMMessageTemplateContent {
    title?: string | redacted.Redacted<string>;
    body?: MessageTemplateBodyContentProvider;
    action?: string;
    sound?: string | redacted.Redacted<string>;
    url?: string | redacted.Redacted<string>;
    imageUrl?: string | redacted.Redacted<string>;
    imageIconUrl?: string | redacted.Redacted<string>;
    smallImageIconUrl?: string | redacted.Redacted<string>;
    rawContent?: MessageTemplateBodyContentProvider;
}
export interface PushBaiduMessageTemplateContent {
    title?: string | redacted.Redacted<string>;
    body?: MessageTemplateBodyContentProvider;
    action?: string;
    sound?: string | redacted.Redacted<string>;
    url?: string | redacted.Redacted<string>;
    imageUrl?: string | redacted.Redacted<string>;
    imageIconUrl?: string | redacted.Redacted<string>;
    smallImageIconUrl?: string | redacted.Redacted<string>;
    rawContent?: MessageTemplateBodyContentProvider;
}
export interface PushMessageTemplateContent {
    adm?: PushADMMessageTemplateContent;
    apns?: PushAPNSMessageTemplateContent;
    fcm?: PushFCMMessageTemplateContent;
    baidu?: PushBaiduMessageTemplateContent;
}
export type MessageTemplateContentProvider = {
    email: EmailMessageTemplateContent;
    sms?: never;
    whatsApp?: never;
    push?: never;
} | {
    email?: never;
    sms: SMSMessageTemplateContent;
    whatsApp?: never;
    push?: never;
} | {
    email?: never;
    sms?: never;
    whatsApp: WhatsAppMessageTemplateContent;
    push?: never;
} | {
    email?: never;
    sms?: never;
    whatsApp?: never;
    push: PushMessageTemplateContent;
};
export type ChannelSubtype = string;
export type LanguageCode = string;
export type WhatsAppBusinessAccountId = string;
export type WhatsAppMessageTemplateId = string;
export type WhatsAppMessageTemplateComponent = string;
export type WhatsAppMessageTemplateComponents = string[];
export interface WhatsAppMessageTemplateSourceConfiguration {
    businessAccountId: string;
    templateId: string;
    components?: string[];
}
export type MessageTemplateSourceConfiguration = {
    whatsApp: WhatsAppMessageTemplateSourceConfiguration;
};
export type MessageTemplateAttributeValue = string | redacted.Redacted<string>;
export interface SystemEndpointAttributes {
    address?: string | redacted.Redacted<string>;
}
export interface SystemAttributes {
    name?: string | redacted.Redacted<string>;
    customerEndpoint?: SystemEndpointAttributes;
    systemEndpoint?: SystemEndpointAttributes;
}
export interface AgentAttributes {
    firstName?: string | redacted.Redacted<string>;
    lastName?: string | redacted.Redacted<string>;
}
export type MessageTemplateAttributeKey = string;
export type CustomAttributes = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export interface CustomerProfileAttributes {
    profileId?: string | redacted.Redacted<string>;
    profileARN?: string | redacted.Redacted<string>;
    firstName?: string | redacted.Redacted<string>;
    middleName?: string | redacted.Redacted<string>;
    lastName?: string | redacted.Redacted<string>;
    accountNumber?: string | redacted.Redacted<string>;
    emailAddress?: string | redacted.Redacted<string>;
    phoneNumber?: string | redacted.Redacted<string>;
    additionalInformation?: string | redacted.Redacted<string>;
    partyType?: string | redacted.Redacted<string>;
    businessName?: string | redacted.Redacted<string>;
    birthDate?: string | redacted.Redacted<string>;
    gender?: string | redacted.Redacted<string>;
    mobilePhoneNumber?: string | redacted.Redacted<string>;
    homePhoneNumber?: string | redacted.Redacted<string>;
    businessPhoneNumber?: string | redacted.Redacted<string>;
    businessEmailAddress?: string | redacted.Redacted<string>;
    address1?: string | redacted.Redacted<string>;
    address2?: string | redacted.Redacted<string>;
    address3?: string | redacted.Redacted<string>;
    address4?: string | redacted.Redacted<string>;
    city?: string | redacted.Redacted<string>;
    county?: string | redacted.Redacted<string>;
    country?: string | redacted.Redacted<string>;
    postalCode?: string | redacted.Redacted<string>;
    province?: string | redacted.Redacted<string>;
    state?: string | redacted.Redacted<string>;
    shippingAddress1?: string | redacted.Redacted<string>;
    shippingAddress2?: string | redacted.Redacted<string>;
    shippingAddress3?: string | redacted.Redacted<string>;
    shippingAddress4?: string | redacted.Redacted<string>;
    shippingCity?: string | redacted.Redacted<string>;
    shippingCounty?: string | redacted.Redacted<string>;
    shippingCountry?: string | redacted.Redacted<string>;
    shippingPostalCode?: string | redacted.Redacted<string>;
    shippingProvince?: string | redacted.Redacted<string>;
    shippingState?: string | redacted.Redacted<string>;
    mailingAddress1?: string | redacted.Redacted<string>;
    mailingAddress2?: string | redacted.Redacted<string>;
    mailingAddress3?: string | redacted.Redacted<string>;
    mailingAddress4?: string | redacted.Redacted<string>;
    mailingCity?: string | redacted.Redacted<string>;
    mailingCounty?: string | redacted.Redacted<string>;
    mailingCountry?: string | redacted.Redacted<string>;
    mailingPostalCode?: string | redacted.Redacted<string>;
    mailingProvince?: string | redacted.Redacted<string>;
    mailingState?: string | redacted.Redacted<string>;
    billingAddress1?: string | redacted.Redacted<string>;
    billingAddress2?: string | redacted.Redacted<string>;
    billingAddress3?: string | redacted.Redacted<string>;
    billingAddress4?: string | redacted.Redacted<string>;
    billingCity?: string | redacted.Redacted<string>;
    billingCounty?: string | redacted.Redacted<string>;
    billingCountry?: string | redacted.Redacted<string>;
    billingPostalCode?: string | redacted.Redacted<string>;
    billingProvince?: string | redacted.Redacted<string>;
    billingState?: string | redacted.Redacted<string>;
    custom?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export interface MessageTemplateAttributes {
    systemAttributes?: SystemAttributes;
    agentAttributes?: AgentAttributes;
    customerProfileAttributes?: CustomerProfileAttributes;
    customAttributes?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export type GroupingCriteria = string | redacted.Redacted<string>;
export type GroupingValue = string | redacted.Redacted<string>;
export type GroupingValues = (string | redacted.Redacted<string>)[];
export interface GroupingConfiguration {
    criteria?: string | redacted.Redacted<string>;
    values?: (string | redacted.Redacted<string>)[];
}
export interface CreateMessageTemplateRequest {
    knowledgeBaseId: string;
    name?: string;
    content?: MessageTemplateContentProvider;
    description?: string;
    channelSubtype: string;
    language?: string;
    sourceConfiguration?: MessageTemplateSourceConfiguration;
    defaultAttributes?: MessageTemplateAttributes;
    groupingConfiguration?: GroupingConfiguration;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type Channel = string | redacted.Redacted<string>;
export type WhatsAppMessageTemplateName = string;
export type WhatsAppMessageTemplateLanguage = string;
export type WhatsAppSourceConfigurationStatus = string;
export interface WhatsAppMessageTemplateSourceConfigurationSummary {
    businessAccountId: string;
    templateId: string;
    name?: string;
    language?: string;
    components?: string[];
    status?: string;
    statusReason?: string | redacted.Redacted<string>;
}
export type MessageTemplateSourceConfigurationSummary = {
    whatsApp: WhatsAppMessageTemplateSourceConfigurationSummary;
};
export type MessageTemplateAttributeType = string;
export type MessageTemplateAttributeTypeList = string[];
export type MessageTemplateContentSha256 = string;
export interface MessageTemplateData {
    messageTemplateArn: string;
    messageTemplateId: string;
    knowledgeBaseArn: string;
    knowledgeBaseId: string;
    name: string;
    channel?: string | redacted.Redacted<string>;
    channelSubtype: string;
    createdTime: Date;
    lastModifiedTime: Date;
    lastModifiedBy: string;
    content?: MessageTemplateContentProvider;
    description?: string;
    language?: string;
    sourceConfigurationSummary?: MessageTemplateSourceConfigurationSummary;
    groupingConfiguration?: GroupingConfiguration;
    defaultAttributes?: MessageTemplateAttributes;
    attributeTypes?: string[];
    messageTemplateContentSha256: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateMessageTemplateResponse {
    messageTemplate?: MessageTemplateData;
}
export type ContentDisposition = string;
export type AttachmentFileName = string | redacted.Redacted<string>;
export interface CreateMessageTemplateAttachmentRequest {
    knowledgeBaseId: string;
    messageTemplateId: string;
    contentDisposition: string;
    name: string | redacted.Redacted<string>;
    body: string | redacted.Redacted<string>;
    clientToken?: string;
}
export interface MessageTemplateAttachment {
    contentDisposition: string;
    name: string | redacted.Redacted<string>;
    uploadedTime: Date;
    url: string | redacted.Redacted<string>;
    urlExpiry: Date;
    attachmentId: string;
}
export interface CreateMessageTemplateAttachmentResponse {
    attachment?: MessageTemplateAttachment;
}
export interface CreateMessageTemplateVersionRequest {
    knowledgeBaseId: string;
    messageTemplateId: string;
    messageTemplateContentSha256?: string;
}
export type MessageTemplateAttachmentList = MessageTemplateAttachment[];
export interface ExtendedMessageTemplateData {
    messageTemplateArn: string;
    messageTemplateId: string;
    knowledgeBaseArn: string;
    knowledgeBaseId: string;
    name: string;
    channel?: string | redacted.Redacted<string>;
    channelSubtype: string;
    createdTime: Date;
    lastModifiedTime: Date;
    lastModifiedBy: string;
    content?: MessageTemplateContentProvider;
    description?: string;
    language?: string;
    sourceConfigurationSummary?: MessageTemplateSourceConfigurationSummary;
    groupingConfiguration?: GroupingConfiguration;
    defaultAttributes?: MessageTemplateAttributes;
    attributeTypes?: string[];
    attachments?: MessageTemplateAttachment[];
    isActive?: boolean;
    versionNumber?: number;
    messageTemplateContentSha256: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateMessageTemplateVersionResponse {
    messageTemplate?: ExtendedMessageTemplateData;
}
export type QuickResponseName = string;
export type QuickResponseContent = string | redacted.Redacted<string>;
export type QuickResponseDataProvider = {
    content: string | redacted.Redacted<string>;
};
export type QuickResponseType = string;
export type QuickResponseDescription = string;
export type ShortCutKey = string;
export type Channels = (string | redacted.Redacted<string>)[];
export interface CreateQuickResponseRequest {
    knowledgeBaseId: string;
    name: string;
    content: QuickResponseDataProvider;
    contentType?: string;
    groupingConfiguration?: GroupingConfiguration;
    description?: string;
    shortcutKey?: string;
    isActive?: boolean;
    channels?: (string | redacted.Redacted<string>)[];
    language?: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type QuickResponseStatus = string;
export type QuickResponseContentProvider = {
    content: string | redacted.Redacted<string>;
};
export interface QuickResponseContents {
    plainText?: QuickResponseContentProvider;
    markdown?: QuickResponseContentProvider;
}
export interface QuickResponseData {
    quickResponseArn: string;
    quickResponseId: string;
    knowledgeBaseArn: string;
    knowledgeBaseId: string;
    name: string;
    contentType: string;
    status: string;
    createdTime: Date;
    lastModifiedTime: Date;
    contents?: QuickResponseContents;
    description?: string;
    groupingConfiguration?: GroupingConfiguration;
    shortcutKey?: string;
    lastModifiedBy?: string;
    isActive?: boolean;
    channels?: (string | redacted.Redacted<string>)[];
    language?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateQuickResponseResponse {
    quickResponse?: QuickResponseData;
}
export interface CreateSessionRequest {
    clientToken?: string;
    assistantId: string;
    name: string;
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    tagFilter?: TagFilter;
    aiAgentConfiguration?: {
        [key: string]: AIAgentConfigurationData | undefined;
    };
    contactArn?: string;
    orchestratorConfigurationList?: OrchestratorConfigurationEntry[];
    removeOrchestratorConfigurationList?: boolean;
}
export interface SessionIntegrationConfiguration {
    topicIntegrationArn?: string;
}
export interface SessionData {
    sessionArn: string;
    sessionId: string;
    name: string;
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    integrationConfiguration?: SessionIntegrationConfiguration;
    tagFilter?: TagFilter;
    aiAgentConfiguration?: {
        [key: string]: AIAgentConfigurationData | undefined;
    };
    origin?: string;
    orchestratorConfigurationList?: OrchestratorConfigurationEntry[];
}
export interface CreateSessionResponse {
    session?: SessionData;
}
export interface DeactivateMessageTemplateRequest {
    knowledgeBaseId: string;
    messageTemplateId: string;
    versionNumber: number;
}
export interface DeactivateMessageTemplateResponse {
    messageTemplateArn: string;
    messageTemplateId: string;
    versionNumber: number;
}
export interface DeleteAIAgentRequest {
    assistantId: string;
    aiAgentId: string;
}
export interface DeleteAIAgentResponse {
}
export interface DeleteAIAgentVersionRequest {
    assistantId: string;
    aiAgentId: string;
    versionNumber: number;
}
export interface DeleteAIAgentVersionResponse {
}
export interface DeleteAIGuardrailRequest {
    assistantId: string;
    aiGuardrailId: string;
}
export interface DeleteAIGuardrailResponse {
}
export interface DeleteAIGuardrailVersionRequest {
    assistantId: string;
    aiGuardrailId: string;
    versionNumber: number;
}
export interface DeleteAIGuardrailVersionResponse {
}
export interface DeleteAIPromptRequest {
    assistantId: string;
    aiPromptId: string;
}
export interface DeleteAIPromptResponse {
}
export interface DeleteAIPromptVersionRequest {
    assistantId: string;
    aiPromptId: string;
    versionNumber: number;
}
export interface DeleteAIPromptVersionResponse {
}
export interface DeleteAssistantRequest {
    assistantId: string;
}
export interface DeleteAssistantResponse {
}
export interface DeleteAssistantAssociationRequest {
    assistantAssociationId: string;
    assistantId: string;
}
export interface DeleteAssistantAssociationResponse {
}
export interface DeleteContentRequest {
    knowledgeBaseId: string;
    contentId: string;
}
export interface DeleteContentResponse {
}
export interface DeleteContentAssociationRequest {
    knowledgeBaseId: string;
    contentId: string;
    contentAssociationId: string;
}
export interface DeleteContentAssociationResponse {
}
export interface DeleteImportJobRequest {
    knowledgeBaseId: string;
    importJobId: string;
}
export interface DeleteImportJobResponse {
}
export interface DeleteKnowledgeBaseRequest {
    knowledgeBaseId: string;
}
export interface DeleteKnowledgeBaseResponse {
}
export interface DeleteMessageTemplateRequest {
    knowledgeBaseId: string;
    messageTemplateId: string;
}
export interface DeleteMessageTemplateResponse {
}
export interface DeleteMessageTemplateAttachmentRequest {
    knowledgeBaseId: string;
    messageTemplateId: string;
    attachmentId: string;
}
export interface DeleteMessageTemplateAttachmentResponse {
}
export interface DeleteQuickResponseRequest {
    knowledgeBaseId: string;
    quickResponseId: string;
}
export interface DeleteQuickResponseResponse {
}
export interface GetAIAgentRequest {
    assistantId: string;
    aiAgentId: string;
}
export interface GetAIAgentResponse {
    aiAgent?: AIAgentData;
    versionNumber?: number;
}
export interface GetAIGuardrailRequest {
    assistantId: string;
    aiGuardrailId: string;
}
export interface GetAIGuardrailResponse {
    aiGuardrail?: AIGuardrailData;
    versionNumber?: number;
}
export interface GetAIPromptRequest {
    assistantId: string;
    aiPromptId: string;
}
export interface GetAIPromptResponse {
    aiPrompt?: AIPromptData;
    versionNumber?: number;
}
export interface GetAssistantRequest {
    assistantId: string;
}
export interface GetAssistantResponse {
    assistant?: AssistantData;
}
export interface GetAssistantAssociationRequest {
    assistantAssociationId: string;
    assistantId: string;
}
export interface GetAssistantAssociationResponse {
    assistantAssociation?: AssistantAssociationData;
}
export interface GetContentRequest {
    contentId: string;
    knowledgeBaseId: string;
}
export interface GetContentResponse {
    content?: ContentData;
}
export interface GetContentAssociationRequest {
    knowledgeBaseId: string;
    contentId: string;
    contentAssociationId: string;
}
export interface GetContentAssociationResponse {
    contentAssociation?: ContentAssociationData;
}
export interface GetContentSummaryRequest {
    contentId: string;
    knowledgeBaseId: string;
}
export interface ContentSummary {
    contentArn: string;
    contentId: string;
    knowledgeBaseArn: string;
    knowledgeBaseId: string;
    name: string;
    revisionId: string;
    title: string;
    contentType: string;
    status: string;
    metadata: {
        [key: string]: string | undefined;
    };
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetContentSummaryResponse {
    contentSummary?: ContentSummary;
}
export interface GetImportJobRequest {
    importJobId: string;
    knowledgeBaseId: string;
}
export type ImportJobType = string;
export type ImportJobStatus = string;
export type ExternalSource = string;
export interface ConnectConfiguration {
    instanceId?: string;
}
export type Configuration = {
    connectConfiguration: ConnectConfiguration;
};
export interface ExternalSourceConfiguration {
    source: string;
    configuration: Configuration;
}
export interface ImportJobData {
    importJobId: string;
    knowledgeBaseId: string;
    uploadId: string;
    knowledgeBaseArn: string;
    importJobType: string;
    status: string;
    url: string | redacted.Redacted<string>;
    failedRecordReport?: string | redacted.Redacted<string>;
    urlExpiry: Date;
    createdTime: Date;
    lastModifiedTime: Date;
    metadata?: {
        [key: string]: string | undefined;
    };
    externalSourceConfiguration?: ExternalSourceConfiguration;
}
export interface GetImportJobResponse {
    importJob?: ImportJobData;
}
export interface GetKnowledgeBaseRequest {
    knowledgeBaseId: string;
}
export interface GetKnowledgeBaseResponse {
    knowledgeBase?: KnowledgeBaseData;
}
export interface GetMessageTemplateRequest {
    messageTemplateId: string;
    knowledgeBaseId: string;
}
export interface GetMessageTemplateResponse {
    messageTemplate?: ExtendedMessageTemplateData;
}
export type NextToken = string;
export interface GetNextMessageRequest {
    assistantId: string;
    sessionId: string;
    nextMessageToken: string;
}
export type MessageType = string;
export type SensitiveString = string | redacted.Redacted<string>;
export type CitationSpanOffset = number;
export interface CitationSpan {
    beginOffsetInclusive?: number;
    endOffsetExclusive?: number;
}
export type ReferenceType = string;
export interface Citation {
    contentId?: string;
    title?: string | redacted.Redacted<string>;
    knowledgeBaseId?: string;
    citationSpan: CitationSpan;
    sourceURL?: string | redacted.Redacted<string>;
    referenceType: string;
}
export type Citations = Citation[];
export interface AIGuardrailAssessment {
    blocked: boolean;
}
export interface TextMessage {
    value?: string | redacted.Redacted<string>;
    citations?: Citation[];
    aiGuardrailAssessment?: AIGuardrailAssessment;
}
export interface ToolUseResultData {
    toolUseId: string;
    toolName: string;
    toolResult: any;
    inputSchema?: any;
}
export type MessageData = {
    text: TextMessage;
    toolUseResult?: never;
    data?: never;
} | {
    text?: never;
    toolUseResult: ToolUseResultData;
    data?: never;
} | {
    text?: never;
    toolUseResult?: never;
    data: any;
};
export type Participant = string;
export interface MessageOutput {
    value: MessageData;
    messageId: string;
    participant: string;
    timestamp: Date;
}
export type ConversationStatus = string;
export type ConversationStatusReason = string;
export interface ConversationState {
    status: string;
    reason?: string;
}
export type RuntimeSessionDataValue = {
    stringValue: string | redacted.Redacted<string>;
};
export interface RuntimeSessionData {
    key: string | redacted.Redacted<string>;
    value: RuntimeSessionDataValue;
}
export type RuntimeSessionDataList = RuntimeSessionData[];
export interface GetNextMessageResponse {
    type: string;
    response: MessageOutput;
    requestMessageId: string;
    conversationState: ConversationState;
    nextMessageToken?: string;
    conversationSessionData?: RuntimeSessionData[];
    chunkedResponseTerminated?: boolean;
}
export interface GetQuickResponseRequest {
    quickResponseId: string;
    knowledgeBaseId: string;
}
export interface GetQuickResponseResponse {
    quickResponse?: QuickResponseData;
}
export type WaitTimeSeconds = number;
export type RecommendationType = string;
export interface GetRecommendationsRequest {
    assistantId: string;
    sessionId: string;
    maxResults?: number;
    waitTimeSeconds?: number;
    nextChunkToken?: string;
    recommendationType?: string;
}
export type RecommendationId = string;
export interface ContentReference {
    knowledgeBaseArn?: string;
    knowledgeBaseId?: string;
    contentArn?: string;
    contentId?: string;
    sourceURL?: string;
    referenceType?: string;
}
export type HighlightOffset = number;
export interface Highlight {
    beginOffsetInclusive?: number;
    endOffsetExclusive?: number;
}
export type Highlights = Highlight[];
export interface DocumentText {
    text?: string | redacted.Redacted<string>;
    highlights?: Highlight[];
}
export interface Document {
    contentReference: ContentReference;
    title?: DocumentText;
    excerpt?: DocumentText;
}
export type RelevanceScore = number;
export type RelevanceLevel = string;
export type LlmModelId = string;
export interface GenerativeReference {
    modelId?: string;
    generationId?: string;
}
export interface SuggestedMessageReference {
    aiAgentId: string;
    aiAgentArn: string;
}
export type DataReference = {
    contentReference: ContentReference;
    generativeReference?: never;
    suggestedMessageReference?: never;
} | {
    contentReference?: never;
    generativeReference: GenerativeReference;
    suggestedMessageReference?: never;
} | {
    contentReference?: never;
    generativeReference?: never;
    suggestedMessageReference: SuggestedMessageReference;
};
export interface TextData {
    title?: DocumentText;
    excerpt?: DocumentText;
}
export interface RankingData {
    relevanceScore?: number;
    relevanceLevel?: string;
}
export interface ContentDataDetails {
    textData: TextData;
    rankingData: RankingData;
}
export type DataSummaryList = DataSummary[];
export interface GenerativeDataDetails {
    completion: string | redacted.Redacted<string>;
    references: DataSummary[];
    rankingData: RankingData;
}
export interface IntentDetectedDataDetails {
    intent: string | redacted.Redacted<string>;
    intentId: string;
    relevanceLevel?: string;
}
export type SourceContentType = string;
export interface SourceContentDataDetails {
    id: string;
    type: string;
    textData: TextData;
    rankingData: RankingData;
    citationSpan?: CitationSpan;
}
export interface GenerativeChunkDataDetails {
    completion?: string | redacted.Redacted<string>;
    references?: DataSummary[];
    nextChunkToken?: string;
}
export interface EmailResponseChunkDataDetails {
    completion?: string | redacted.Redacted<string>;
    nextChunkToken?: string;
}
export interface EmailOverviewChunkDataDetails {
    completion?: string | redacted.Redacted<string>;
    nextChunkToken?: string;
}
export interface EmailGenerativeAnswerChunkDataDetails {
    completion?: string | redacted.Redacted<string>;
    references?: DataSummary[];
    nextChunkToken?: string;
}
export interface CaseSummarizationChunkDataDetails {
    completion?: string | redacted.Redacted<string>;
    nextChunkToken?: string;
}
export interface SuggestedMessageDataDetails {
    messageText: string | redacted.Redacted<string>;
}
export interface NotesDataDetails {
    completion?: string | redacted.Redacted<string>;
}
export interface NotesChunkDataDetails {
    completion?: string | redacted.Redacted<string>;
    nextChunkToken?: string;
}
export interface ProactiveRecommendationDataDetails {
    nextMessageToken: string;
}
export type DataDetails = {
    contentData: ContentDataDetails;
    generativeData?: never;
    intentDetectedData?: never;
    sourceContentData?: never;
    generativeChunkData?: never;
    emailResponseChunkData?: never;
    emailOverviewChunkData?: never;
    emailGenerativeAnswerChunkData?: never;
    caseSummarizationChunkData?: never;
    suggestedMessageData?: never;
    notesData?: never;
    notesChunkData?: never;
    proactiveRecommendationData?: never;
} | {
    contentData?: never;
    generativeData: GenerativeDataDetails;
    intentDetectedData?: never;
    sourceContentData?: never;
    generativeChunkData?: never;
    emailResponseChunkData?: never;
    emailOverviewChunkData?: never;
    emailGenerativeAnswerChunkData?: never;
    caseSummarizationChunkData?: never;
    suggestedMessageData?: never;
    notesData?: never;
    notesChunkData?: never;
    proactiveRecommendationData?: never;
} | {
    contentData?: never;
    generativeData?: never;
    intentDetectedData: IntentDetectedDataDetails;
    sourceContentData?: never;
    generativeChunkData?: never;
    emailResponseChunkData?: never;
    emailOverviewChunkData?: never;
    emailGenerativeAnswerChunkData?: never;
    caseSummarizationChunkData?: never;
    suggestedMessageData?: never;
    notesData?: never;
    notesChunkData?: never;
    proactiveRecommendationData?: never;
} | {
    contentData?: never;
    generativeData?: never;
    intentDetectedData?: never;
    sourceContentData: SourceContentDataDetails;
    generativeChunkData?: never;
    emailResponseChunkData?: never;
    emailOverviewChunkData?: never;
    emailGenerativeAnswerChunkData?: never;
    caseSummarizationChunkData?: never;
    suggestedMessageData?: never;
    notesData?: never;
    notesChunkData?: never;
    proactiveRecommendationData?: never;
} | {
    contentData?: never;
    generativeData?: never;
    intentDetectedData?: never;
    sourceContentData?: never;
    generativeChunkData: GenerativeChunkDataDetails;
    emailResponseChunkData?: never;
    emailOverviewChunkData?: never;
    emailGenerativeAnswerChunkData?: never;
    caseSummarizationChunkData?: never;
    suggestedMessageData?: never;
    notesData?: never;
    notesChunkData?: never;
    proactiveRecommendationData?: never;
} | {
    contentData?: never;
    generativeData?: never;
    intentDetectedData?: never;
    sourceContentData?: never;
    generativeChunkData?: never;
    emailResponseChunkData: EmailResponseChunkDataDetails;
    emailOverviewChunkData?: never;
    emailGenerativeAnswerChunkData?: never;
    caseSummarizationChunkData?: never;
    suggestedMessageData?: never;
    notesData?: never;
    notesChunkData?: never;
    proactiveRecommendationData?: never;
} | {
    contentData?: never;
    generativeData?: never;
    intentDetectedData?: never;
    sourceContentData?: never;
    generativeChunkData?: never;
    emailResponseChunkData?: never;
    emailOverviewChunkData: EmailOverviewChunkDataDetails;
    emailGenerativeAnswerChunkData?: never;
    caseSummarizationChunkData?: never;
    suggestedMessageData?: never;
    notesData?: never;
    notesChunkData?: never;
    proactiveRecommendationData?: never;
} | {
    contentData?: never;
    generativeData?: never;
    intentDetectedData?: never;
    sourceContentData?: never;
    generativeChunkData?: never;
    emailResponseChunkData?: never;
    emailOverviewChunkData?: never;
    emailGenerativeAnswerChunkData: EmailGenerativeAnswerChunkDataDetails;
    caseSummarizationChunkData?: never;
    suggestedMessageData?: never;
    notesData?: never;
    notesChunkData?: never;
    proactiveRecommendationData?: never;
} | {
    contentData?: never;
    generativeData?: never;
    intentDetectedData?: never;
    sourceContentData?: never;
    generativeChunkData?: never;
    emailResponseChunkData?: never;
    emailOverviewChunkData?: never;
    emailGenerativeAnswerChunkData?: never;
    caseSummarizationChunkData: CaseSummarizationChunkDataDetails;
    suggestedMessageData?: never;
    notesData?: never;
    notesChunkData?: never;
    proactiveRecommendationData?: never;
} | {
    contentData?: never;
    generativeData?: never;
    intentDetectedData?: never;
    sourceContentData?: never;
    generativeChunkData?: never;
    emailResponseChunkData?: never;
    emailOverviewChunkData?: never;
    emailGenerativeAnswerChunkData?: never;
    caseSummarizationChunkData?: never;
    suggestedMessageData: SuggestedMessageDataDetails;
    notesData?: never;
    notesChunkData?: never;
    proactiveRecommendationData?: never;
} | {
    contentData?: never;
    generativeData?: never;
    intentDetectedData?: never;
    sourceContentData?: never;
    generativeChunkData?: never;
    emailResponseChunkData?: never;
    emailOverviewChunkData?: never;
    emailGenerativeAnswerChunkData?: never;
    caseSummarizationChunkData?: never;
    suggestedMessageData?: never;
    notesData: NotesDataDetails;
    notesChunkData?: never;
    proactiveRecommendationData?: never;
} | {
    contentData?: never;
    generativeData?: never;
    intentDetectedData?: never;
    sourceContentData?: never;
    generativeChunkData?: never;
    emailResponseChunkData?: never;
    emailOverviewChunkData?: never;
    emailGenerativeAnswerChunkData?: never;
    caseSummarizationChunkData?: never;
    suggestedMessageData?: never;
    notesData?: never;
    notesChunkData: NotesChunkDataDetails;
    proactiveRecommendationData?: never;
} | {
    contentData?: never;
    generativeData?: never;
    intentDetectedData?: never;
    sourceContentData?: never;
    generativeChunkData?: never;
    emailResponseChunkData?: never;
    emailOverviewChunkData?: never;
    emailGenerativeAnswerChunkData?: never;
    caseSummarizationChunkData?: never;
    suggestedMessageData?: never;
    notesData?: never;
    notesChunkData?: never;
    proactiveRecommendationData: ProactiveRecommendationDataDetails;
};
export interface DataSummary {
    reference: DataReference;
    details: DataDetails;
}
export interface RecommendationData {
    recommendationId: string;
    document?: Document;
    relevanceScore?: number;
    relevanceLevel?: string;
    type?: string;
    data?: DataSummary;
}
export type RecommendationList = RecommendationData[];
export type RecommendationTriggerType = string;
export type RecommendationSourceType = string;
export type QueryText = string | redacted.Redacted<string>;
export interface QueryRecommendationTriggerData {
    text?: string | redacted.Redacted<string>;
}
export type RecommendationTriggerData = {
    query: QueryRecommendationTriggerData;
};
export type RecommendationIdList = string[];
export interface RecommendationTrigger {
    id: string;
    type: string;
    source: string;
    data: RecommendationTriggerData;
    recommendationIds: string[];
}
export type RecommendationTriggerList = RecommendationTrigger[];
export interface GetRecommendationsResponse {
    recommendations: RecommendationData[];
    triggers?: RecommendationTrigger[];
}
export interface GetSessionRequest {
    assistantId: string;
    sessionId: string;
}
export interface GetSessionResponse {
    session?: SessionData;
}
export interface ListAIAgentsRequest {
    assistantId: string;
    nextToken?: string;
    maxResults?: number;
    origin?: string;
}
export interface AIAgentSummary {
    name: string;
    assistantId: string;
    assistantArn: string;
    aiAgentId: string;
    type: string;
    aiAgentArn: string;
    modifiedTime?: Date;
    visibilityStatus: string;
    configuration?: AIAgentConfiguration;
    origin?: string;
    description?: string;
    status?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type AIAgentSummaryList = AIAgentSummary[];
export interface ListAIAgentsResponse {
    aiAgentSummaries: AIAgentSummary[];
    nextToken?: string;
}
export interface ListAIAgentVersionsRequest {
    assistantId: string;
    aiAgentId: string;
    nextToken?: string;
    maxResults?: number;
    origin?: string;
}
export interface AIAgentVersionSummary {
    aiAgentSummary?: AIAgentSummary;
    versionNumber?: number;
}
export type AIAgentVersionSummariesList = AIAgentVersionSummary[];
export interface ListAIAgentVersionsResponse {
    aiAgentVersionSummaries: AIAgentVersionSummary[];
    nextToken?: string;
}
export interface ListAIGuardrailsRequest {
    assistantId: string;
    nextToken?: string;
    maxResults?: number;
}
export interface AIGuardrailSummary {
    name: string;
    assistantId: string;
    assistantArn: string;
    aiGuardrailId: string;
    aiGuardrailArn: string;
    modifiedTime?: Date;
    visibilityStatus: string;
    description?: string | redacted.Redacted<string>;
    status?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type AIGuardrailSummariesList = AIGuardrailSummary[];
export interface ListAIGuardrailsResponse {
    aiGuardrailSummaries: AIGuardrailSummary[];
    nextToken?: string;
}
export interface ListAIGuardrailVersionsRequest {
    assistantId: string;
    aiGuardrailId: string;
    nextToken?: string;
    maxResults?: number;
}
export interface AIGuardrailVersionSummary {
    aiGuardrailSummary?: AIGuardrailSummary;
    versionNumber?: number;
}
export type AIGuardrailVersionSummariesList = AIGuardrailVersionSummary[];
export interface ListAIGuardrailVersionsResponse {
    aiGuardrailVersionSummaries: AIGuardrailVersionSummary[];
    nextToken?: string;
}
export interface ListAIPromptsRequest {
    assistantId: string;
    nextToken?: string;
    maxResults?: number;
    origin?: string;
}
export interface AIPromptSummary {
    name: string;
    assistantId: string;
    assistantArn: string;
    aiPromptId: string;
    type: string;
    aiPromptArn: string;
    modifiedTime?: Date;
    templateType: string;
    modelId: string;
    apiFormat: string;
    visibilityStatus: string;
    origin?: string;
    description?: string;
    status?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type AIPromptSummaryList = AIPromptSummary[];
export interface ListAIPromptsResponse {
    aiPromptSummaries: AIPromptSummary[];
    nextToken?: string;
}
export interface ListAIPromptVersionsRequest {
    assistantId: string;
    aiPromptId: string;
    nextToken?: string;
    maxResults?: number;
    origin?: string;
}
export interface AIPromptVersionSummary {
    aiPromptSummary?: AIPromptSummary;
    versionNumber?: number;
}
export type AIPromptVersionSummariesList = AIPromptVersionSummary[];
export interface ListAIPromptVersionsResponse {
    aiPromptVersionSummaries: AIPromptVersionSummary[];
    nextToken?: string;
}
export interface ListAssistantAssociationsRequest {
    nextToken?: string;
    maxResults?: number;
    assistantId: string;
}
export interface AssistantAssociationSummary {
    assistantAssociationId: string;
    assistantAssociationArn: string;
    assistantId: string;
    assistantArn: string;
    associationType: string;
    associationData: AssistantAssociationOutputData;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type AssistantAssociationSummaryList = AssistantAssociationSummary[];
export interface ListAssistantAssociationsResponse {
    assistantAssociationSummaries: AssistantAssociationSummary[];
    nextToken?: string;
}
export interface ListAssistantsRequest {
    nextToken?: string;
    maxResults?: number;
}
export interface AssistantSummary {
    assistantId: string;
    assistantArn: string;
    name: string;
    type: string;
    status: string;
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    serverSideEncryptionConfiguration?: ServerSideEncryptionConfiguration;
    integrationConfiguration?: AssistantIntegrationConfiguration;
    capabilityConfiguration?: AssistantCapabilityConfiguration;
    aiAgentConfiguration?: {
        [key: string]: AIAgentConfigurationData | undefined;
    };
    orchestratorConfigurationList?: OrchestratorConfigurationEntry[];
}
export type AssistantList = AssistantSummary[];
export interface ListAssistantsResponse {
    assistantSummaries: AssistantSummary[];
    nextToken?: string;
}
export interface ListContentAssociationsRequest {
    nextToken?: string;
    maxResults?: number;
    knowledgeBaseId: string;
    contentId: string;
}
export interface ContentAssociationSummary {
    knowledgeBaseId: string;
    knowledgeBaseArn: string;
    contentId: string;
    contentArn: string;
    contentAssociationId: string;
    contentAssociationArn: string;
    associationType: string;
    associationData: ContentAssociationContents;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type ContentAssociationSummaryList = ContentAssociationSummary[];
export interface ListContentAssociationsResponse {
    contentAssociationSummaries: ContentAssociationSummary[];
    nextToken?: string;
}
export interface ListContentsRequest {
    nextToken?: string;
    maxResults?: number;
    knowledgeBaseId: string;
}
export type ContentSummaryList = ContentSummary[];
export interface ListContentsResponse {
    contentSummaries: ContentSummary[];
    nextToken?: string;
}
export interface ListImportJobsRequest {
    nextToken?: string;
    maxResults?: number;
    knowledgeBaseId: string;
}
export interface ImportJobSummary {
    importJobId: string;
    knowledgeBaseId: string;
    uploadId: string;
    knowledgeBaseArn: string;
    importJobType: string;
    status: string;
    createdTime: Date;
    lastModifiedTime: Date;
    metadata?: {
        [key: string]: string | undefined;
    };
    externalSourceConfiguration?: ExternalSourceConfiguration;
}
export type ImportJobList = ImportJobSummary[];
export interface ListImportJobsResponse {
    importJobSummaries: ImportJobSummary[];
    nextToken?: string;
}
export interface ListKnowledgeBasesRequest {
    nextToken?: string;
    maxResults?: number;
}
export interface KnowledgeBaseSummary {
    knowledgeBaseId: string;
    knowledgeBaseArn: string;
    name: string;
    knowledgeBaseType: string;
    status: string;
    sourceConfiguration?: SourceConfiguration;
    vectorIngestionConfiguration?: VectorIngestionConfiguration;
    renderingConfiguration?: RenderingConfiguration;
    serverSideEncryptionConfiguration?: ServerSideEncryptionConfiguration;
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type KnowledgeBaseList = KnowledgeBaseSummary[];
export interface ListKnowledgeBasesResponse {
    knowledgeBaseSummaries: KnowledgeBaseSummary[];
    nextToken?: string;
}
export type MessageFilterType = string;
export interface ListMessagesRequest {
    assistantId: string;
    sessionId: string;
    nextToken?: string;
    maxResults?: number;
    filter?: string;
}
export type MessageList = MessageOutput[];
export interface ListMessagesResponse {
    messages: MessageOutput[];
    nextToken?: string;
}
export interface ListMessageTemplatesRequest {
    nextToken?: string;
    maxResults?: number;
    knowledgeBaseId: string;
}
export interface MessageTemplateSummary {
    messageTemplateArn: string;
    messageTemplateId: string;
    knowledgeBaseArn: string;
    knowledgeBaseId: string;
    name: string;
    channel?: string | redacted.Redacted<string>;
    channelSubtype: string;
    createdTime: Date;
    lastModifiedTime: Date;
    lastModifiedBy: string;
    sourceConfiguration?: MessageTemplateSourceConfiguration;
    activeVersionNumber?: number;
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type MessageTemplateSummaryList = MessageTemplateSummary[];
export interface ListMessageTemplatesResponse {
    messageTemplateSummaries: MessageTemplateSummary[];
    nextToken?: string;
}
export interface ListMessageTemplateVersionsRequest {
    knowledgeBaseId: string;
    messageTemplateId: string;
    nextToken?: string;
    maxResults?: number;
}
export interface MessageTemplateVersionSummary {
    messageTemplateArn: string;
    messageTemplateId: string;
    knowledgeBaseArn: string;
    knowledgeBaseId: string;
    name: string;
    channel?: string | redacted.Redacted<string>;
    channelSubtype: string;
    isActive: boolean;
    versionNumber: number;
}
export type MessageTemplateVersionSummaryList = MessageTemplateVersionSummary[];
export interface ListMessageTemplateVersionsResponse {
    messageTemplateVersionSummaries: MessageTemplateVersionSummary[];
    nextToken?: string;
}
export type ModelLifecycle = string;
export interface ListModelsRequest {
    assistantId: string;
    aiPromptType?: string;
    modelLifecycle?: string;
    nextToken?: string;
    maxResults?: number;
}
export type ModelId = string;
export type ModelDisplayName = string;
export type CrossRegionStatus = string;
export type AIPromptTypeList = string[];
export interface ModelSummary {
    modelId: string;
    displayName: string;
    crossRegionStatus?: string;
    supportsPromptCaching?: boolean;
    supportedAIPromptTypes?: string[];
    modelLifecycle?: string;
    legacyTimestamp?: Date;
    endOfLifeTimestamp?: Date;
}
export type ModelSummaryList = ModelSummary[];
export interface ListModelsResponse {
    modelSummaries: ModelSummary[];
    nextToken?: string;
}
export interface ListQuickResponsesRequest {
    nextToken?: string;
    maxResults?: number;
    knowledgeBaseId: string;
}
export interface QuickResponseSummary {
    quickResponseArn: string;
    quickResponseId: string;
    knowledgeBaseArn: string;
    knowledgeBaseId: string;
    name: string;
    contentType: string;
    status: string;
    createdTime: Date;
    lastModifiedTime: Date;
    description?: string;
    lastModifiedBy?: string;
    isActive?: boolean;
    channels?: (string | redacted.Redacted<string>)[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export type QuickResponseSummaryList = QuickResponseSummary[];
export interface ListQuickResponsesResponse {
    quickResponseSummaries: QuickResponseSummary[];
    nextToken?: string;
}
export interface ListSpansRequest {
    assistantId: string;
    sessionId: string;
    nextToken?: string;
    maxResults?: number;
}
export type SpanType = string;
export type SpanStatus = string;
export type InteractionMode = string;
export type ReturnReason = string;
export type SpanFinishReasonList = string[];
export interface SpanCitation {
    contentId?: string;
    title?: string | redacted.Redacted<string>;
    knowledgeBaseId?: string;
    knowledgeBaseArn?: string;
}
export type SpanCitationList = SpanCitation[];
export interface SpanTextValue {
    value: string | redacted.Redacted<string>;
    citations?: SpanCitation[];
    aiGuardrailAssessment?: AIGuardrailAssessment;
}
export interface SpanToolUseValue {
    toolUseId: string;
    name: string;
    arguments: any;
}
export interface SpanToolResultValue {
    toolUseId: string;
    values: SpanMessageValue[];
    error?: string;
}
export interface SpanReasoningValue {
    value: string | redacted.Redacted<string>;
}
export type SpanMessageValue = {
    text: SpanTextValue;
    toolUse?: never;
    toolResult?: never;
    reasoning?: never;
} | {
    text?: never;
    toolUse: SpanToolUseValue;
    toolResult?: never;
    reasoning?: never;
} | {
    text?: never;
    toolUse?: never;
    toolResult: SpanToolResultValue;
    reasoning?: never;
} | {
    text?: never;
    toolUse?: never;
    toolResult?: never;
    reasoning: SpanReasoningValue;
};
export type SpanMessageValueList = SpanMessageValue[];
export interface SpanMessage {
    messageId: string;
    participant: string;
    timestamp: Date;
    values: SpanMessageValue[];
}
export type SpanMessageList = SpanMessage[];
export type GuardrailSource = string;
export type GuardrailAction = string;
export type GuardrailPolicyType = string;
export interface GuardrailPolicyResult {
    policyType: string;
    action: string;
    details?: string;
}
export type GuardrailPolicyResultList = GuardrailPolicyResult[];
export interface SpanGuardrailAssessment {
    guardrailId: string;
    guardrailName: string;
    source: string;
    action: string;
    policies?: GuardrailPolicyResult[];
}
export type SpanGuardrailAssessmentList = SpanGuardrailAssessment[];
export interface SpanAttributes {
    operationName?: string;
    providerName?: string;
    errorType?: string;
    agentId?: string;
    instanceArn?: string;
    contactId?: string;
    initialContactId?: string;
    sessionName?: string;
    aiAgentArn?: string;
    aiAgentType?: string;
    aiAgentName?: string;
    aiAgentId?: string;
    aiAgentVersion?: number;
    aiAgentInvoker?: string;
    aiAgentOrchestratorUseCase?: string;
    interactionMode?: string;
    targetAgentId?: string;
    returnReason?: string;
    requestModel?: string;
    requestMaxTokens?: number;
    temperature?: number;
    topP?: number;
    responseModel?: string;
    responseFinishReasons?: string[];
    usageInputTokens?: number;
    usageOutputTokens?: number;
    usageTotalTokens?: number;
    cacheReadInputTokens?: number;
    cacheWriteInputTokens?: number;
    inputMessages?: SpanMessage[];
    outputMessages?: SpanMessage[];
    systemInstructions?: SpanMessageValue[];
    promptArn?: string;
    promptId?: string;
    promptType?: string;
    promptName?: string;
    promptVersion?: number;
    timeToFirstTokenMs?: number;
    guardrailAssessments?: SpanGuardrailAssessment[];
}
export interface Span {
    spanId: string;
    assistantId: string;
    sessionId: string;
    parentSpanId?: string;
    spanName: string;
    spanType: string;
    startTimestamp: Date;
    endTimestamp: Date;
    status: string;
    statusDescription?: string;
    requestId: string;
    originRequestId?: string;
    attributes: SpanAttributes;
}
export type SpanList = Span[];
export interface ListSpansResponse {
    spans: Span[];
    nextToken?: string;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface NotifyRecommendationsReceivedRequest {
    assistantId: string;
    sessionId: string;
    recommendationIds: string[];
}
export type NotifyRecommendationsReceivedErrorMessage = string;
export interface NotifyRecommendationsReceivedError_ {
    recommendationId?: string;
    message?: string;
}
export type NotifyRecommendationsReceivedErrorList = NotifyRecommendationsReceivedError_[];
export interface NotifyRecommendationsReceivedResponse {
    recommendationIds?: string[];
    errors?: NotifyRecommendationsReceivedError_[];
}
export type TargetType = string;
export type Relevance = string;
export interface GenerativeContentFeedbackData {
    relevance: string;
}
export type ContentFeedbackData = {
    generativeContentFeedbackData: GenerativeContentFeedbackData;
};
export interface PutFeedbackRequest {
    assistantId: string;
    targetId: string;
    targetType: string;
    contentFeedback: ContentFeedbackData;
}
export interface PutFeedbackResponse {
    assistantId: string;
    assistantArn: string;
    targetId: string;
    targetType: string;
    contentFeedback: ContentFeedbackData;
}
export type QueryConditionFieldName = string;
export type QueryConditionComparisonOperator = string;
export interface QueryConditionItem {
    field: string;
    comparator: string;
    value: string;
}
export type QueryCondition = {
    single: QueryConditionItem;
};
export type QueryConditionExpression = QueryCondition[];
export interface QueryTextInputData {
    text: string | redacted.Redacted<string>;
}
export interface IntentInputData {
    intentId: string;
}
export type CaseArn = string;
export interface CaseSummarizationInputData {
    caseArn: string;
}
export type QueryInputData = {
    queryTextInputData: QueryTextInputData;
    intentInputData?: never;
    caseSummarizationInputData?: never;
} | {
    queryTextInputData?: never;
    intentInputData: IntentInputData;
    caseSummarizationInputData?: never;
} | {
    queryTextInputData?: never;
    intentInputData?: never;
    caseSummarizationInputData: CaseSummarizationInputData;
};
export interface QueryAssistantRequest {
    assistantId: string;
    queryText?: string | redacted.Redacted<string>;
    nextToken?: string;
    maxResults?: number;
    sessionId?: string;
    queryCondition?: QueryCondition[];
    queryInputData?: QueryInputData;
    overrideKnowledgeBaseSearchType?: string;
}
export type QueryResultType = string;
export interface ResultData {
    resultId: string;
    document?: Document;
    relevanceScore?: number;
    data?: DataSummary;
    type?: string;
}
export type QueryResultsList = ResultData[];
export interface QueryAssistantResponse {
    results: ResultData[];
    nextToken?: string;
}
export interface RemoveAssistantAIAgentRequest {
    assistantId: string;
    aiAgentType: string;
    orchestratorUseCase?: string;
}
export interface RemoveAssistantAIAgentResponse {
}
export interface RemoveKnowledgeBaseTemplateUriRequest {
    knowledgeBaseId: string;
}
export interface RemoveKnowledgeBaseTemplateUriResponse {
}
export interface RenderMessageTemplateRequest {
    knowledgeBaseId: string;
    messageTemplateId: string;
    attributes: MessageTemplateAttributes;
}
export type MessageTemplateAttributeKeyList = string[];
export interface RenderMessageTemplateResponse {
    content?: MessageTemplateContentProvider;
    sourceConfigurationSummary?: MessageTemplateSourceConfigurationSummary;
    attributesNotInterpolated?: string[];
    attachments?: MessageTemplateAttachment[];
}
export type AssistantAssociationIdList = string[];
export type KnowledgeSource = {
    assistantAssociationIds: string[];
};
export type RetrievalFilterList = RetrievalFilterConfiguration[];
export type FilterAttributeKey = string;
export interface FilterAttribute {
    key: string;
    value: any;
}
export type RetrievalFilterConfiguration = {
    andAll: RetrievalFilterConfiguration[];
    equals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    in?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    listContains?: never;
    notEquals?: never;
    notIn?: never;
    orAll?: never;
    startsWith?: never;
    stringContains?: never;
} | {
    andAll?: never;
    equals: FilterAttribute;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    in?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    listContains?: never;
    notEquals?: never;
    notIn?: never;
    orAll?: never;
    startsWith?: never;
    stringContains?: never;
} | {
    andAll?: never;
    equals?: never;
    greaterThan: FilterAttribute;
    greaterThanOrEquals?: never;
    in?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    listContains?: never;
    notEquals?: never;
    notIn?: never;
    orAll?: never;
    startsWith?: never;
    stringContains?: never;
} | {
    andAll?: never;
    equals?: never;
    greaterThan?: never;
    greaterThanOrEquals: FilterAttribute;
    in?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    listContains?: never;
    notEquals?: never;
    notIn?: never;
    orAll?: never;
    startsWith?: never;
    stringContains?: never;
} | {
    andAll?: never;
    equals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    in: FilterAttribute;
    lessThan?: never;
    lessThanOrEquals?: never;
    listContains?: never;
    notEquals?: never;
    notIn?: never;
    orAll?: never;
    startsWith?: never;
    stringContains?: never;
} | {
    andAll?: never;
    equals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    in?: never;
    lessThan: FilterAttribute;
    lessThanOrEquals?: never;
    listContains?: never;
    notEquals?: never;
    notIn?: never;
    orAll?: never;
    startsWith?: never;
    stringContains?: never;
} | {
    andAll?: never;
    equals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    in?: never;
    lessThan?: never;
    lessThanOrEquals: FilterAttribute;
    listContains?: never;
    notEquals?: never;
    notIn?: never;
    orAll?: never;
    startsWith?: never;
    stringContains?: never;
} | {
    andAll?: never;
    equals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    in?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    listContains: FilterAttribute;
    notEquals?: never;
    notIn?: never;
    orAll?: never;
    startsWith?: never;
    stringContains?: never;
} | {
    andAll?: never;
    equals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    in?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    listContains?: never;
    notEquals: FilterAttribute;
    notIn?: never;
    orAll?: never;
    startsWith?: never;
    stringContains?: never;
} | {
    andAll?: never;
    equals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    in?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    listContains?: never;
    notEquals?: never;
    notIn: FilterAttribute;
    orAll?: never;
    startsWith?: never;
    stringContains?: never;
} | {
    andAll?: never;
    equals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    in?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    listContains?: never;
    notEquals?: never;
    notIn?: never;
    orAll: RetrievalFilterConfiguration[];
    startsWith?: never;
    stringContains?: never;
} | {
    andAll?: never;
    equals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    in?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    listContains?: never;
    notEquals?: never;
    notIn?: never;
    orAll?: never;
    startsWith: FilterAttribute;
    stringContains?: never;
} | {
    andAll?: never;
    equals?: never;
    greaterThan?: never;
    greaterThanOrEquals?: never;
    in?: never;
    lessThan?: never;
    lessThanOrEquals?: never;
    listContains?: never;
    notEquals?: never;
    notIn?: never;
    orAll?: never;
    startsWith?: never;
    stringContains: FilterAttribute;
};
export interface RetrievalConfiguration {
    knowledgeSource: KnowledgeSource;
    filter?: RetrievalFilterConfiguration;
    numberOfResults?: number;
    overrideKnowledgeBaseSearchType?: string;
}
export interface RetrieveRequest {
    assistantId: string;
    retrievalConfiguration: RetrievalConfiguration;
    retrievalQuery: string | redacted.Redacted<string>;
}
export interface RetrieveResult {
    associationId: string;
    sourceId: string | redacted.Redacted<string>;
    referenceType: string;
    contentText: string | redacted.Redacted<string>;
}
export type RetrieveResultList = RetrieveResult[];
export type RetrieveErrorCode = string;
export interface RetrieveError_ {
    associationId: string;
    code: string;
    message: string;
}
export type RetrieveErrorList = RetrieveError_[];
export interface RetrieveResponse {
    results: RetrieveResult[];
    errors?: RetrieveError_[];
}
export type FilterField = string;
export type FilterOperator = string;
export interface Filter {
    field: string;
    operator: string;
    value: string;
}
export type FilterList = Filter[];
export interface SearchExpression {
    filters: Filter[];
}
export interface SearchContentRequest {
    nextToken?: string;
    maxResults?: number;
    knowledgeBaseId: string;
    searchExpression: SearchExpression;
}
export interface SearchContentResponse {
    contentSummaries: ContentSummary[];
    nextToken?: string;
}
export type MessageTemplateQueryValue = string;
export type MessageTemplateQueryValueList = string[];
export type MessageTemplateQueryOperator = string;
export type Priority = string;
export interface MessageTemplateQueryField {
    name: string;
    values: string[];
    operator: string;
    allowFuzziness?: boolean;
    priority?: string;
}
export type MessageTemplateQueryFieldList = MessageTemplateQueryField[];
export type MessageTemplateFilterValue = string;
export type MessageTemplateFilterValueList = string[];
export type MessageTemplateFilterOperator = string;
export interface MessageTemplateFilterField {
    name: string;
    values?: string[];
    operator: string;
    includeNoExistence?: boolean;
}
export type MessageTemplateFilterFieldList = MessageTemplateFilterField[];
export type Order = string;
export interface MessageTemplateOrderField {
    name: string;
    order?: string;
}
export interface MessageTemplateSearchExpression {
    queries?: MessageTemplateQueryField[];
    filters?: MessageTemplateFilterField[];
    orderOnField?: MessageTemplateOrderField;
}
export interface SearchMessageTemplatesRequest {
    knowledgeBaseId: string;
    searchExpression: MessageTemplateSearchExpression;
    nextToken?: string;
    maxResults?: number;
}
export interface MessageTemplateSearchResultData {
    messageTemplateArn: string;
    messageTemplateId: string;
    knowledgeBaseArn: string;
    knowledgeBaseId: string;
    name: string;
    channel?: string | redacted.Redacted<string>;
    channelSubtype: string;
    createdTime: Date;
    lastModifiedTime: Date;
    lastModifiedBy: string;
    isActive?: boolean;
    versionNumber?: number;
    description?: string;
    sourceConfigurationSummary?: MessageTemplateSourceConfigurationSummary;
    groupingConfiguration?: GroupingConfiguration;
    language?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type MessageTemplateSearchResultsList = MessageTemplateSearchResultData[];
export interface SearchMessageTemplatesResponse {
    results: MessageTemplateSearchResultData[];
    nextToken?: string;
}
export type QuickResponseQueryValue = string;
export type QuickResponseQueryValueList = string[];
export type QuickResponseQueryOperator = string;
export interface QuickResponseQueryField {
    name: string;
    values: string[];
    operator: string;
    allowFuzziness?: boolean;
    priority?: string;
}
export type QuickResponseQueryFieldList = QuickResponseQueryField[];
export type QuickResponseFilterValue = string;
export type QuickResponseFilterValueList = string[];
export type QuickResponseFilterOperator = string;
export interface QuickResponseFilterField {
    name: string;
    values?: string[];
    operator: string;
    includeNoExistence?: boolean;
}
export type QuickResponseFilterFieldList = QuickResponseFilterField[];
export interface QuickResponseOrderField {
    name: string;
    order?: string;
}
export interface QuickResponseSearchExpression {
    queries?: QuickResponseQueryField[];
    filters?: QuickResponseFilterField[];
    orderOnField?: QuickResponseOrderField;
}
export type ContactAttributeKey = string;
export type ContactAttributeValue = string;
export type ContactAttributes = {
    [key: string]: string | undefined;
};
export interface SearchQuickResponsesRequest {
    knowledgeBaseId: string;
    searchExpression: QuickResponseSearchExpression;
    nextToken?: string;
    maxResults?: number;
    attributes?: {
        [key: string]: string | undefined;
    };
}
export type ContactAttributeKeys = string[];
export interface QuickResponseSearchResultData {
    quickResponseArn: string;
    quickResponseId: string;
    knowledgeBaseArn: string;
    knowledgeBaseId: string;
    name: string;
    contentType: string;
    status: string;
    contents: QuickResponseContents;
    createdTime: Date;
    lastModifiedTime: Date;
    isActive: boolean;
    description?: string;
    groupingConfiguration?: GroupingConfiguration;
    shortcutKey?: string;
    lastModifiedBy?: string;
    channels?: (string | redacted.Redacted<string>)[];
    language?: string;
    attributesNotInterpolated?: string[];
    attributesInterpolated?: string[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export type QuickResponseSearchResultsList = QuickResponseSearchResultData[];
export interface SearchQuickResponsesResponse {
    results: QuickResponseSearchResultData[];
    nextToken?: string;
}
export interface SearchSessionsRequest {
    nextToken?: string;
    maxResults?: number;
    assistantId: string;
    searchExpression: SearchExpression;
}
export interface SessionSummary {
    sessionId: string;
    sessionArn: string;
    assistantId: string;
    assistantArn: string;
}
export type SessionSummaries = SessionSummary[];
export interface SearchSessionsResponse {
    sessionSummaries: SessionSummary[];
    nextToken?: string;
}
export interface MessageInput {
    value: MessageData;
}
export interface SelfServiceConversationHistory {
    turnNumber?: number;
    inputTranscript?: string | redacted.Redacted<string>;
    botResponse?: string | redacted.Redacted<string>;
    timestamp?: Date;
}
export type SelfServiceConversationHistoryList = SelfServiceConversationHistory[];
export interface ConversationContext {
    selfServiceConversationHistory: SelfServiceConversationHistory[];
}
export interface MessageConfiguration {
    generateFillerMessage?: boolean;
    generateChunkedMessage?: boolean;
}
export type MessageMetadata = {
    [key: string]: string | undefined;
};
export interface SendMessageRequest {
    assistantId: string;
    sessionId: string;
    type: string;
    message: MessageInput;
    aiAgentId?: string;
    conversationContext?: ConversationContext;
    configuration?: MessageConfiguration;
    clientToken?: string;
    orchestratorUseCase?: string;
    metadata?: {
        [key: string]: string | undefined;
    };
    originRequestId?: string;
}
export interface SendMessageResponse {
    requestMessageId: string;
    configuration?: MessageConfiguration;
    nextMessageToken: string;
}
export type TimeToLive = number;
export interface StartContentUploadRequest {
    knowledgeBaseId: string;
    contentType: string;
    presignedUrlTimeToLive?: number;
}
export type Headers = {
    [key: string]: string | undefined;
};
export interface StartContentUploadResponse {
    uploadId: string;
    url: string | redacted.Redacted<string>;
    urlExpiry: Date;
    headersToInclude: {
        [key: string]: string | undefined;
    };
}
export interface StartImportJobRequest {
    knowledgeBaseId: string;
    importJobType: string;
    uploadId: string;
    clientToken?: string;
    metadata?: {
        [key: string]: string | undefined;
    };
    externalSourceConfiguration?: ExternalSourceConfiguration;
}
export interface StartImportJobResponse {
    importJob?: ImportJobData;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAIAgentRequest {
    clientToken?: string;
    assistantId: string;
    aiAgentId: string;
    visibilityStatus: string;
    configuration?: AIAgentConfiguration;
    description?: string;
}
export interface UpdateAIAgentResponse {
    aiAgent?: AIAgentData;
}
export interface UpdateAIGuardrailRequest {
    clientToken?: string;
    assistantId: string;
    aiGuardrailId: string;
    visibilityStatus: string;
    blockedInputMessaging: string | redacted.Redacted<string>;
    blockedOutputsMessaging: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    topicPolicyConfig?: AIGuardrailTopicPolicyConfig;
    contentPolicyConfig?: AIGuardrailContentPolicyConfig;
    wordPolicyConfig?: AIGuardrailWordPolicyConfig;
    sensitiveInformationPolicyConfig?: AIGuardrailSensitiveInformationPolicyConfig;
    contextualGroundingPolicyConfig?: AIGuardrailContextualGroundingPolicyConfig;
}
export interface UpdateAIGuardrailResponse {
    aiGuardrail?: AIGuardrailData;
}
export interface UpdateAIPromptRequest {
    clientToken?: string;
    assistantId: string;
    aiPromptId: string;
    visibilityStatus: string;
    templateConfiguration?: AIPromptTemplateConfiguration;
    description?: string;
    modelId?: string;
    inferenceConfiguration?: AIPromptInferenceConfiguration;
}
export interface UpdateAIPromptResponse {
    aiPrompt?: AIPromptData;
}
export interface UpdateAssistantAIAgentRequest {
    assistantId: string;
    aiAgentType: string;
    configuration: AIAgentConfigurationData;
    orchestratorUseCase?: string;
}
export interface UpdateAssistantAIAgentResponse {
    assistant?: AssistantData;
}
export interface UpdateContentRequest {
    knowledgeBaseId: string;
    contentId: string;
    revisionId?: string;
    title?: string;
    overrideLinkOutUri?: string;
    removeOverrideLinkOutUri?: boolean;
    metadata?: {
        [key: string]: string | undefined;
    };
    uploadId?: string;
}
export interface UpdateContentResponse {
    content?: ContentData;
}
export interface UpdateKnowledgeBaseTemplateUriRequest {
    knowledgeBaseId: string;
    templateUri: string;
}
export interface UpdateKnowledgeBaseTemplateUriResponse {
    knowledgeBase?: KnowledgeBaseData;
}
export interface UpdateMessageTemplateRequest {
    knowledgeBaseId: string;
    messageTemplateId: string;
    content?: MessageTemplateContentProvider;
    language?: string;
    sourceConfiguration?: MessageTemplateSourceConfiguration;
    defaultAttributes?: MessageTemplateAttributes;
}
export interface UpdateMessageTemplateResponse {
    messageTemplate?: MessageTemplateData;
}
export interface UpdateMessageTemplateMetadataRequest {
    knowledgeBaseId: string;
    messageTemplateId: string;
    name?: string;
    description?: string;
    groupingConfiguration?: GroupingConfiguration;
}
export interface UpdateMessageTemplateMetadataResponse {
    messageTemplate?: MessageTemplateData;
}
export interface UpdateQuickResponseRequest {
    knowledgeBaseId: string;
    quickResponseId: string;
    name?: string;
    content?: QuickResponseDataProvider;
    contentType?: string;
    groupingConfiguration?: GroupingConfiguration;
    removeGroupingConfiguration?: boolean;
    description?: string;
    removeDescription?: boolean;
    shortcutKey?: string;
    removeShortcutKey?: boolean;
    isActive?: boolean;
    channels?: (string | redacted.Redacted<string>)[];
    language?: string;
}
export interface UpdateQuickResponseResponse {
    quickResponse?: QuickResponseData;
}
export interface UpdateSessionRequest {
    assistantId: string;
    sessionId: string;
    description?: string;
    tagFilter?: TagFilter;
    aiAgentConfiguration?: {
        [key: string]: AIAgentConfigurationData | undefined;
    };
    orchestratorConfigurationList?: OrchestratorConfigurationEntry[];
    removeOrchestratorConfigurationList?: boolean;
}
export interface UpdateSessionResponse {
    session?: SessionData;
}
export type SessionDataNamespace = string;
export interface UpdateSessionDataRequest {
    assistantId: string;
    sessionId: string;
    namespace?: string;
    data: RuntimeSessionData[];
}
export interface UpdateSessionDataResponse {
    sessionArn: string;
    sessionId: string;
    namespace: string;
    data: RuntimeSessionData[];
}
export type ActivateMessageTemplateError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Activates a specific version of the Amazon Q in Connect message template. After the version is activated, the previous active version will be deactivated automatically. You can use the `$ACTIVE_VERSION` qualifier later to reference the version that is in active status.
 */
export declare const activateMessageTemplate: API.OperationMethod<ActivateMessageTemplateRequest, ActivateMessageTemplateResponse, ActivateMessageTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateAIAgentError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Q in Connect AI Agent.
 */
export declare const createAIAgent: API.OperationMethod<CreateAIAgentRequest, CreateAIAgentResponse, CreateAIAgentError, Credentials | HttpClient.HttpClient>;
export type CreateAIAgentVersionError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates and Amazon Q in Connect AI Agent version.
 */
export declare const createAIAgentVersion: API.OperationMethod<CreateAIAgentVersionRequest, CreateAIAgentVersionResponse, CreateAIAgentVersionError, Credentials | HttpClient.HttpClient>;
export type CreateAIGuardrailError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Q in Connect AI Guardrail.
 */
export declare const createAIGuardrail: API.OperationMethod<CreateAIGuardrailRequest, CreateAIGuardrailResponse, CreateAIGuardrailError, Credentials | HttpClient.HttpClient>;
export type CreateAIGuardrailVersionError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Q in Connect AI Guardrail version.
 */
export declare const createAIGuardrailVersion: API.OperationMethod<CreateAIGuardrailVersionRequest, CreateAIGuardrailVersionResponse, CreateAIGuardrailVersionError, Credentials | HttpClient.HttpClient>;
export type CreateAIPromptError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Q in Connect AI Prompt.
 */
export declare const createAIPrompt: API.OperationMethod<CreateAIPromptRequest, CreateAIPromptResponse, CreateAIPromptError, Credentials | HttpClient.HttpClient>;
export type CreateAIPromptVersionError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Q in Connect AI Prompt version.
 */
export declare const createAIPromptVersion: API.OperationMethod<CreateAIPromptVersionRequest, CreateAIPromptVersionResponse, CreateAIPromptVersionError, Credentials | HttpClient.HttpClient>;
export type CreateAssistantError = AccessDeniedException | ConflictException | ServiceQuotaExceededException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Q in Connect assistant.
 */
export declare const createAssistant: API.OperationMethod<CreateAssistantRequest, CreateAssistantResponse, CreateAssistantError, Credentials | HttpClient.HttpClient>;
export type CreateAssistantAssociationError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates an association between an Amazon Q in Connect assistant and another resource. Currently, the only supported association is with a knowledge base. An assistant can have only a single association.
 */
export declare const createAssistantAssociation: API.OperationMethod<CreateAssistantAssociationRequest, CreateAssistantAssociationResponse, CreateAssistantAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateContentError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates Amazon Q in Connect content. Before to calling this API, use StartContentUpload to upload an asset.
 */
export declare const createContent: API.OperationMethod<CreateContentRequest, CreateContentResponse, CreateContentError, Credentials | HttpClient.HttpClient>;
export type CreateContentAssociationError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates an association between a content resource in a knowledge base and step-by-step guides. Step-by-step guides offer instructions to agents for resolving common customer issues. You create a content association to integrate Amazon Q in Connect and step-by-step guides.
 *
 * After you integrate Amazon Q and step-by-step guides, when Amazon Q provides a recommendation to an agent based on the intent that it's detected, it also provides them with the option to start the step-by-step guide that you have associated with the content.
 *
 * Note the following limitations:
 *
 * - You can create only one content association for each content resource in a knowledge base.
 *
 * - You can associate a step-by-step guide with multiple content resources.
 *
 * For more information, see Integrate Amazon Q in Connect with step-by-step guides in the *Connect Customer Administrator Guide*.
 */
export declare const createContentAssociation: API.OperationMethod<CreateContentAssociationRequest, CreateContentAssociationResponse, CreateContentAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateKnowledgeBaseError = AccessDeniedException | ConflictException | ServiceQuotaExceededException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates a knowledge base.
 *
 * When using this API, you cannot reuse Amazon AppIntegrations DataIntegrations with external knowledge bases such as Salesforce and ServiceNow. If you do, you'll get an `InvalidRequestException` error.
 *
 * For example, you're programmatically managing your external knowledge base, and you want to add or remove one of the fields that is being ingested from Salesforce. Do the following:
 *
 * - Call DeleteKnowledgeBase.
 *
 * - Call DeleteDataIntegration.
 *
 * - Call CreateDataIntegration to recreate the DataIntegration or a create different one.
 *
 * - Call CreateKnowledgeBase.
 */
export declare const createKnowledgeBase: API.OperationMethod<CreateKnowledgeBaseRequest, CreateKnowledgeBaseResponse, CreateKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type CreateMessageTemplateError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Q in Connect message template. The name of the message template has to be unique for each knowledge base. The channel subtype of the message template is immutable and cannot be modified after creation. After the message template is created, you can use the `$LATEST` qualifier to reference the created message template.
 */
export declare const createMessageTemplate: API.OperationMethod<CreateMessageTemplateRequest, CreateMessageTemplateResponse, CreateMessageTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateMessageTemplateAttachmentError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Uploads an attachment file to the specified Amazon Q in Connect message template. The name of the message template attachment has to be unique for each message template referenced by the `$LATEST` qualifier. The body of the attachment file should be encoded using base64 encoding. After the file is uploaded, you can use the pre-signed Amazon S3 URL returned in response to download the uploaded file.
 */
export declare const createMessageTemplateAttachment: API.OperationMethod<CreateMessageTemplateAttachmentRequest, CreateMessageTemplateAttachmentResponse, CreateMessageTemplateAttachmentError, Credentials | HttpClient.HttpClient>;
export type CreateMessageTemplateVersionError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Amazon Q in Connect message template version from the current content and configuration of a message template. Versions are immutable and monotonically increasing. Once a version is created, you can reference a specific version of the message template by passing in `<message-template-id>:<versionNumber>` as the message template identifier. An error is displayed if the supplied `messageTemplateContentSha256` is different from the `messageTemplateContentSha256` of the message template with `$LATEST` qualifier. If multiple `CreateMessageTemplateVersion` requests are made while the message template remains the same, only the first invocation creates a new version and the succeeding requests will return the same response as the first invocation.
 */
export declare const createMessageTemplateVersion: API.OperationMethod<CreateMessageTemplateVersionRequest, CreateMessageTemplateVersionResponse, CreateMessageTemplateVersionError, Credentials | HttpClient.HttpClient>;
export type CreateQuickResponseError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Q in Connect quick response.
 */
export declare const createQuickResponse: API.OperationMethod<CreateQuickResponseRequest, CreateQuickResponseResponse, CreateQuickResponseError, Credentials | HttpClient.HttpClient>;
export type CreateSessionError = AccessDeniedException | ConflictException | DependencyFailedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates a session. A session is a contextual container used for generating recommendations. Connect Customer creates a new Amazon Q in Connect session for each contact on which Amazon Q in Connect is enabled.
 */
export declare const createSession: API.OperationMethod<CreateSessionRequest, CreateSessionResponse, CreateSessionError, Credentials | HttpClient.HttpClient>;
export type DeactivateMessageTemplateError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deactivates a specific version of the Amazon Q in Connect message template . After the version is deactivated, you can no longer use the `$ACTIVE_VERSION` qualifier to reference the version in active status.
 */
export declare const deactivateMessageTemplate: API.OperationMethod<DeactivateMessageTemplateRequest, DeactivateMessageTemplateResponse, DeactivateMessageTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteAIAgentError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Q in Connect AI Agent.
 */
export declare const deleteAIAgent: API.OperationMethod<DeleteAIAgentRequest, DeleteAIAgentResponse, DeleteAIAgentError, Credentials | HttpClient.HttpClient>;
export type DeleteAIAgentVersionError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Q in Connect AI Agent Version.
 */
export declare const deleteAIAgentVersion: API.OperationMethod<DeleteAIAgentVersionRequest, DeleteAIAgentVersionResponse, DeleteAIAgentVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteAIGuardrailError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Q in Connect AI Guardrail.
 */
export declare const deleteAIGuardrail: API.OperationMethod<DeleteAIGuardrailRequest, DeleteAIGuardrailResponse, DeleteAIGuardrailError, Credentials | HttpClient.HttpClient>;
export type DeleteAIGuardrailVersionError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Delete and Amazon Q in Connect AI Guardrail version.
 */
export declare const deleteAIGuardrailVersion: API.OperationMethod<DeleteAIGuardrailVersionRequest, DeleteAIGuardrailVersionResponse, DeleteAIGuardrailVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteAIPromptError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Q in Connect AI Prompt.
 */
export declare const deleteAIPrompt: API.OperationMethod<DeleteAIPromptRequest, DeleteAIPromptResponse, DeleteAIPromptError, Credentials | HttpClient.HttpClient>;
export type DeleteAIPromptVersionError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Delete and Amazon Q in Connect AI Prompt version.
 */
export declare const deleteAIPromptVersion: API.OperationMethod<DeleteAIPromptVersionRequest, DeleteAIPromptVersionResponse, DeleteAIPromptVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteAssistantError = AccessDeniedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deletes an assistant.
 */
export declare const deleteAssistant: API.OperationMethod<DeleteAssistantRequest, DeleteAssistantResponse, DeleteAssistantError, Credentials | HttpClient.HttpClient>;
export type DeleteAssistantAssociationError = AccessDeniedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deletes an assistant association.
 */
export declare const deleteAssistantAssociation: API.OperationMethod<DeleteAssistantAssociationRequest, DeleteAssistantAssociationResponse, DeleteAssistantAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteContentError = AccessDeniedException | ConflictException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deletes the content.
 */
export declare const deleteContent: API.OperationMethod<DeleteContentRequest, DeleteContentResponse, DeleteContentError, Credentials | HttpClient.HttpClient>;
export type DeleteContentAssociationError = AccessDeniedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deletes the content association.
 *
 * For more information about content associations--what they are and when they are used--see Integrate Amazon Q in Connect with step-by-step guides in the *Connect Customer Administrator Guide*.
 */
export declare const deleteContentAssociation: API.OperationMethod<DeleteContentAssociationRequest, DeleteContentAssociationResponse, DeleteContentAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteImportJobError = AccessDeniedException | ConflictException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deletes the quick response import job.
 */
export declare const deleteImportJob: API.OperationMethod<DeleteImportJobRequest, DeleteImportJobResponse, DeleteImportJobError, Credentials | HttpClient.HttpClient>;
export type DeleteKnowledgeBaseError = AccessDeniedException | ConflictException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deletes the knowledge base.
 *
 * When you use this API to delete an external knowledge base such as Salesforce or ServiceNow, you must also delete the Amazon AppIntegrations DataIntegration. This is because you can't reuse the DataIntegration after it's been associated with an external knowledge base. However, you can delete and recreate it. See DeleteDataIntegration and CreateDataIntegration in the *Amazon AppIntegrations API Reference*.
 */
export declare const deleteKnowledgeBase: API.OperationMethod<DeleteKnowledgeBaseRequest, DeleteKnowledgeBaseResponse, DeleteKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type DeleteMessageTemplateError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Q in Connect message template entirely or a specific version of the message template if version is supplied in the request. You can provide the message template identifier as `<message-template-id>:<versionNumber>` to delete a specific version of the message template. If it is not supplied, the message template and all available versions will be deleted.
 */
export declare const deleteMessageTemplate: API.OperationMethod<DeleteMessageTemplateRequest, DeleteMessageTemplateResponse, DeleteMessageTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteMessageTemplateAttachmentError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the attachment file from the Amazon Q in Connect message template that is referenced by `$LATEST` qualifier. Attachments on available message template versions will remain unchanged.
 */
export declare const deleteMessageTemplateAttachment: API.OperationMethod<DeleteMessageTemplateAttachmentRequest, DeleteMessageTemplateAttachmentResponse, DeleteMessageTemplateAttachmentError, Credentials | HttpClient.HttpClient>;
export type DeleteQuickResponseError = AccessDeniedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deletes a quick response.
 */
export declare const deleteQuickResponse: API.OperationMethod<DeleteQuickResponseRequest, DeleteQuickResponseResponse, DeleteQuickResponseError, Credentials | HttpClient.HttpClient>;
export type GetAIAgentError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Gets an Amazon Q in Connect AI Agent.
 */
export declare const getAIAgent: API.OperationMethod<GetAIAgentRequest, GetAIAgentResponse, GetAIAgentError, Credentials | HttpClient.HttpClient>;
export type GetAIGuardrailError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Gets the Amazon Q in Connect AI Guardrail.
 */
export declare const getAIGuardrail: API.OperationMethod<GetAIGuardrailRequest, GetAIGuardrailResponse, GetAIGuardrailError, Credentials | HttpClient.HttpClient>;
export type GetAIPromptError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Gets and Amazon Q in Connect AI Prompt.
 */
export declare const getAIPrompt: API.OperationMethod<GetAIPromptRequest, GetAIPromptResponse, GetAIPromptError, Credentials | HttpClient.HttpClient>;
export type GetAssistantError = AccessDeniedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves information about an assistant.
 */
export declare const getAssistant: API.OperationMethod<GetAssistantRequest, GetAssistantResponse, GetAssistantError, Credentials | HttpClient.HttpClient>;
export type GetAssistantAssociationError = AccessDeniedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves information about an assistant association.
 */
export declare const getAssistantAssociation: API.OperationMethod<GetAssistantAssociationRequest, GetAssistantAssociationResponse, GetAssistantAssociationError, Credentials | HttpClient.HttpClient>;
export type GetContentError = AccessDeniedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves content, including a pre-signed URL to download the content.
 */
export declare const getContent: API.OperationMethod<GetContentRequest, GetContentResponse, GetContentError, Credentials | HttpClient.HttpClient>;
export type GetContentAssociationError = AccessDeniedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Returns the content association.
 *
 * For more information about content associations--what they are and when they are used--see Integrate Amazon Q in Connect with step-by-step guides in the *Connect Customer Administrator Guide*.
 */
export declare const getContentAssociation: API.OperationMethod<GetContentAssociationRequest, GetContentAssociationResponse, GetContentAssociationError, Credentials | HttpClient.HttpClient>;
export type GetContentSummaryError = AccessDeniedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves summary information about the content.
 */
export declare const getContentSummary: API.OperationMethod<GetContentSummaryRequest, GetContentSummaryResponse, GetContentSummaryError, Credentials | HttpClient.HttpClient>;
export type GetImportJobError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the started import job.
 */
export declare const getImportJob: API.OperationMethod<GetImportJobRequest, GetImportJobResponse, GetImportJobError, Credentials | HttpClient.HttpClient>;
export type GetKnowledgeBaseError = AccessDeniedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves information about the knowledge base.
 */
export declare const getKnowledgeBase: API.OperationMethod<GetKnowledgeBaseRequest, GetKnowledgeBaseResponse, GetKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type GetMessageTemplateError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves the Amazon Q in Connect message template. The message template identifier can contain an optional qualifier, for example, `<message-template-id>:<qualifier>`, which is either an actual version number or an Amazon Q Connect managed qualifier `$ACTIVE_VERSION` | `$LATEST`. If it is not supplied, then `$LATEST` is assumed implicitly.
 */
export declare const getMessageTemplate: API.OperationMethod<GetMessageTemplateRequest, GetMessageTemplateResponse, GetMessageTemplateError, Credentials | HttpClient.HttpClient>;
export type GetNextMessageError = AccessDeniedException | ResourceNotFoundException | UnprocessableContentException | ValidationException | CommonErrors;
/**
 * Retrieves next message on an Amazon Q in Connect session.
 */
export declare const getNextMessage: API.OperationMethod<GetNextMessageRequest, GetNextMessageResponse, GetNextMessageError, Credentials | HttpClient.HttpClient>;
export type GetQuickResponseError = AccessDeniedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves the quick response.
 */
export declare const getQuickResponse: API.OperationMethod<GetQuickResponseRequest, GetQuickResponseResponse, GetQuickResponseError, Credentials | HttpClient.HttpClient>;
export type GetRecommendationsError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * This API will be discontinued starting June 1, 2024. To receive generative responses after March 1, 2024, you will need to create a new Assistant in the Connect Customer console and integrate the Amazon Q in Connect JavaScript library (amazon-q-connectjs) into your applications.
 *
 * Retrieves recommendations for the specified session. To avoid retrieving the same recommendations in subsequent calls, use NotifyRecommendationsReceived. This API supports long-polling behavior with the `waitTimeSeconds` parameter. Short poll is the default behavior and only returns recommendations already available. To perform a manual query against an assistant, use QueryAssistant.
 */
export declare const getRecommendations: API.OperationMethod<GetRecommendationsRequest, GetRecommendationsResponse, GetRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetSessionError = AccessDeniedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves information for a specified session.
 */
export declare const getSession: API.OperationMethod<GetSessionRequest, GetSessionResponse, GetSessionError, Credentials | HttpClient.HttpClient>;
export type ListAIAgentsError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists AI Agents.
 */
export declare const listAIAgents: API.PaginatedOperationMethod<ListAIAgentsRequest, ListAIAgentsResponse, ListAIAgentsError, Credentials | HttpClient.HttpClient, AIAgentSummary>;
export type ListAIAgentVersionsError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * List AI Agent versions.
 */
export declare const listAIAgentVersions: API.PaginatedOperationMethod<ListAIAgentVersionsRequest, ListAIAgentVersionsResponse, ListAIAgentVersionsError, Credentials | HttpClient.HttpClient, AIAgentVersionSummary>;
export type ListAIGuardrailsError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists the AI Guardrails available on the Amazon Q in Connect assistant.
 */
export declare const listAIGuardrails: API.PaginatedOperationMethod<ListAIGuardrailsRequest, ListAIGuardrailsResponse, ListAIGuardrailsError, Credentials | HttpClient.HttpClient, AIGuardrailSummary>;
export type ListAIGuardrailVersionsError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists AI Guardrail versions.
 */
export declare const listAIGuardrailVersions: API.PaginatedOperationMethod<ListAIGuardrailVersionsRequest, ListAIGuardrailVersionsResponse, ListAIGuardrailVersionsError, Credentials | HttpClient.HttpClient, AIGuardrailVersionSummary>;
export type ListAIPromptsError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists the AI Prompts available on the Amazon Q in Connect assistant.
 */
export declare const listAIPrompts: API.PaginatedOperationMethod<ListAIPromptsRequest, ListAIPromptsResponse, ListAIPromptsError, Credentials | HttpClient.HttpClient, AIPromptSummary>;
export type ListAIPromptVersionsError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists AI Prompt versions.
 */
export declare const listAIPromptVersions: API.PaginatedOperationMethod<ListAIPromptVersionsRequest, ListAIPromptVersionsResponse, ListAIPromptVersionsError, Credentials | HttpClient.HttpClient, AIPromptVersionSummary>;
export type ListAssistantAssociationsError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists information about assistant associations.
 */
export declare const listAssistantAssociations: API.PaginatedOperationMethod<ListAssistantAssociationsRequest, ListAssistantAssociationsResponse, ListAssistantAssociationsError, Credentials | HttpClient.HttpClient, AssistantAssociationSummary>;
export type ListAssistantsError = AccessDeniedException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists information about assistants.
 */
export declare const listAssistants: API.PaginatedOperationMethod<ListAssistantsRequest, ListAssistantsResponse, ListAssistantsError, Credentials | HttpClient.HttpClient, AssistantSummary>;
export type ListContentAssociationsError = AccessDeniedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists the content associations.
 *
 * For more information about content associations--what they are and when they are used--see Integrate Amazon Q in Connect with step-by-step guides in the *Connect Customer Administrator Guide*.
 */
export declare const listContentAssociations: API.PaginatedOperationMethod<ListContentAssociationsRequest, ListContentAssociationsResponse, ListContentAssociationsError, Credentials | HttpClient.HttpClient, ContentAssociationSummary>;
export type ListContentsError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the content.
 */
export declare const listContents: API.PaginatedOperationMethod<ListContentsRequest, ListContentsResponse, ListContentsError, Credentials | HttpClient.HttpClient, ContentSummary>;
export type ListImportJobsError = AccessDeniedException | ValidationException | CommonErrors;
/**
 * Lists information about import jobs.
 */
export declare const listImportJobs: API.PaginatedOperationMethod<ListImportJobsRequest, ListImportJobsResponse, ListImportJobsError, Credentials | HttpClient.HttpClient, ImportJobSummary>;
export type ListKnowledgeBasesError = AccessDeniedException | ValidationException | CommonErrors;
/**
 * Lists the knowledge bases.
 */
export declare const listKnowledgeBases: API.PaginatedOperationMethod<ListKnowledgeBasesRequest, ListKnowledgeBasesResponse, ListKnowledgeBasesError, Credentials | HttpClient.HttpClient, KnowledgeBaseSummary>;
export type ListMessagesError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists messages on an Amazon Q in Connect session.
 */
export declare const listMessages: API.PaginatedOperationMethod<ListMessagesRequest, ListMessagesResponse, ListMessagesError, Credentials | HttpClient.HttpClient, MessageOutput>;
export type ListMessageTemplatesError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the available Amazon Q in Connect message templates for the specified knowledge base.
 */
export declare const listMessageTemplates: API.PaginatedOperationMethod<ListMessageTemplatesRequest, ListMessageTemplatesResponse, ListMessageTemplatesError, Credentials | HttpClient.HttpClient, MessageTemplateSummary>;
export type ListMessageTemplateVersionsError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the available versions for the specified Amazon Q in Connect message template.
 */
export declare const listMessageTemplateVersions: API.PaginatedOperationMethod<ListMessageTemplateVersionsRequest, ListMessageTemplateVersionsResponse, ListMessageTemplateVersionsError, Credentials | HttpClient.HttpClient, MessageTemplateVersionSummary>;
export type ListModelsError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists the models available to an Amazon Q in Connect assistant in the assistant's Amazon Web Services Region. The available models are determined by the region of the specified assistant.
 */
export declare const listModels: API.PaginatedOperationMethod<ListModelsRequest, ListModelsResponse, ListModelsError, Credentials | HttpClient.HttpClient, ModelSummary>;
export type ListQuickResponsesError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists information about quick response.
 */
export declare const listQuickResponses: API.PaginatedOperationMethod<ListQuickResponsesRequest, ListQuickResponsesResponse, ListQuickResponsesError, Credentials | HttpClient.HttpClient, QuickResponseSummary>;
export type ListSpansError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves AI agent execution traces for a session, providing granular visibility into agent orchestration flows, LLM interactions, and tool invocations.
 */
export declare const listSpans: API.PaginatedOperationMethod<ListSpansRequest, ListSpansResponse, ListSpansError, Credentials | HttpClient.HttpClient, Span>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Lists the tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type NotifyRecommendationsReceivedError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes the specified recommendations from the specified assistant's queue of newly available recommendations. You can use this API in conjunction with GetRecommendations and a `waitTimeSeconds` input for long-polling behavior and avoiding duplicate recommendations.
 */
export declare const notifyRecommendationsReceived: API.OperationMethod<NotifyRecommendationsReceivedRequest, NotifyRecommendationsReceivedResponse, NotifyRecommendationsReceivedError, Credentials | HttpClient.HttpClient>;
export type PutFeedbackError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Provides feedback against the specified assistant for the specified target. This API only supports generative targets.
 */
export declare const putFeedback: API.OperationMethod<PutFeedbackRequest, PutFeedbackResponse, PutFeedbackError, Credentials | HttpClient.HttpClient>;
export type QueryAssistantError = AccessDeniedException | RequestTimeoutException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * This API will be discontinued starting June 1, 2024. To receive generative responses after March 1, 2024, you will need to create a new Assistant in the Connect Customer console and integrate the Amazon Q in Connect JavaScript library (amazon-q-connectjs) into your applications.
 *
 * Performs a manual search against the specified assistant. To retrieve recommendations for an assistant, use GetRecommendations.
 */
export declare const queryAssistant: API.PaginatedOperationMethod<QueryAssistantRequest, QueryAssistantResponse, QueryAssistantError, Credentials | HttpClient.HttpClient, ResultData>;
export type RemoveAssistantAIAgentError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the AI Agent that is set for use by default on an Amazon Q in Connect Assistant.
 */
export declare const removeAssistantAIAgent: API.OperationMethod<RemoveAssistantAIAgentRequest, RemoveAssistantAIAgentResponse, RemoveAssistantAIAgentError, Credentials | HttpClient.HttpClient>;
export type RemoveKnowledgeBaseTemplateUriError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a URI template from a knowledge base.
 */
export declare const removeKnowledgeBaseTemplateUri: API.OperationMethod<RemoveKnowledgeBaseTemplateUriRequest, RemoveKnowledgeBaseTemplateUriResponse, RemoveKnowledgeBaseTemplateUriError, Credentials | HttpClient.HttpClient>;
export type RenderMessageTemplateError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Renders the Amazon Q in Connect message template based on the attribute values provided and generates the message content. For any variable present in the message template, if the attribute value is neither provided in the attribute request parameter nor the default attribute of the message template, the rendered message content will keep the variable placeholder as it is and return the attribute keys that are missing.
 */
export declare const renderMessageTemplate: API.OperationMethod<RenderMessageTemplateRequest, RenderMessageTemplateResponse, RenderMessageTemplateError, Credentials | HttpClient.HttpClient>;
export type RetrieveError = AccessDeniedException | ConflictException | DependencyFailedException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves content from knowledge sources based on a query.
 */
export declare const retrieve: API.OperationMethod<RetrieveRequest, RetrieveResponse, RetrieveError, Credentials | HttpClient.HttpClient>;
export type SearchContentError = AccessDeniedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Searches for content in a specified knowledge base. Can be used to get a specific content resource by its name.
 */
export declare const searchContent: API.PaginatedOperationMethod<SearchContentRequest, SearchContentResponse, SearchContentError, Credentials | HttpClient.HttpClient, ContentSummary>;
export type SearchMessageTemplatesError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Searches for Amazon Q in Connect message templates in the specified knowledge base.
 */
export declare const searchMessageTemplates: API.PaginatedOperationMethod<SearchMessageTemplatesRequest, SearchMessageTemplatesResponse, SearchMessageTemplatesError, Credentials | HttpClient.HttpClient, MessageTemplateSearchResultData>;
export type SearchQuickResponsesError = AccessDeniedException | RequestTimeoutException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Searches existing Amazon Q in Connect quick responses in an Amazon Q in Connect knowledge base.
 */
export declare const searchQuickResponses: API.PaginatedOperationMethod<SearchQuickResponsesRequest, SearchQuickResponsesResponse, SearchQuickResponsesError, Credentials | HttpClient.HttpClient, QuickResponseSearchResultData>;
export type SearchSessionsError = AccessDeniedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Searches for sessions.
 */
export declare const searchSessions: API.PaginatedOperationMethod<SearchSessionsRequest, SearchSessionsResponse, SearchSessionsError, Credentials | HttpClient.HttpClient, SessionSummary>;
export type SendMessageError = AccessDeniedException | ConflictException | DependencyFailedException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Submits a message to the Amazon Q in Connect session.
 */
export declare const sendMessage: API.OperationMethod<SendMessageRequest, SendMessageResponse, SendMessageError, Credentials | HttpClient.HttpClient>;
export type StartContentUploadError = AccessDeniedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Get a URL to upload content to a knowledge base. To upload content, first make a PUT request to the returned URL with your file, making sure to include the required headers. Then use CreateContent to finalize the content creation process or UpdateContent to modify an existing resource. You can only upload content to a knowledge base of type CUSTOM.
 */
export declare const startContentUpload: API.OperationMethod<StartContentUploadRequest, StartContentUploadResponse, StartContentUploadError, Credentials | HttpClient.HttpClient>;
export type StartImportJobError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Start an asynchronous job to import Amazon Q in Connect resources from an uploaded source file. Before calling this API, use StartContentUpload to upload an asset that contains the resource data.
 *
 * - For importing Amazon Q in Connect quick responses, you need to upload a csv file including the quick responses. For information about how to format the csv file for importing quick responses, see Import quick responses.
 */
export declare const startImportJob: API.OperationMethod<StartImportJobRequest, StartImportJobResponse, StartImportJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Adds the specified tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Removes the specified tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAIAgentError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Updates an AI Agent.
 */
export declare const updateAIAgent: API.OperationMethod<UpdateAIAgentRequest, UpdateAIAgentResponse, UpdateAIAgentError, Credentials | HttpClient.HttpClient>;
export type UpdateAIGuardrailError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Updates an AI Guardrail.
 */
export declare const updateAIGuardrail: API.OperationMethod<UpdateAIGuardrailRequest, UpdateAIGuardrailResponse, UpdateAIGuardrailError, Credentials | HttpClient.HttpClient>;
export type UpdateAIPromptError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Updates an AI Prompt.
 */
export declare const updateAIPrompt: API.OperationMethod<UpdateAIPromptRequest, UpdateAIPromptResponse, UpdateAIPromptError, Credentials | HttpClient.HttpClient>;
export type UpdateAssistantAIAgentError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the AI Agent that is set for use by default on an Amazon Q in Connect Assistant.
 */
export declare const updateAssistantAIAgent: API.OperationMethod<UpdateAssistantAIAgentRequest, UpdateAssistantAIAgentResponse, UpdateAssistantAIAgentError, Credentials | HttpClient.HttpClient>;
export type UpdateContentError = AccessDeniedException | PreconditionFailedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Updates information about the content.
 */
export declare const updateContent: API.OperationMethod<UpdateContentRequest, UpdateContentResponse, UpdateContentError, Credentials | HttpClient.HttpClient>;
export type UpdateKnowledgeBaseTemplateUriError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the template URI of a knowledge base. This is only supported for knowledge bases of type EXTERNAL. Include a single variable in `${variable}` format; this interpolated by Amazon Q in Connect using ingested content. For example, if you ingest a Salesforce article, it has an `Id` value, and you can set the template URI to `https://myInstanceName.lightning.force.com/lightning/r/Knowledge__kav/*${Id}*\/view`.
 */
export declare const updateKnowledgeBaseTemplateUri: API.OperationMethod<UpdateKnowledgeBaseTemplateUriRequest, UpdateKnowledgeBaseTemplateUriResponse, UpdateKnowledgeBaseTemplateUriError, Credentials | HttpClient.HttpClient>;
export type UpdateMessageTemplateError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the Amazon Q in Connect message template. Partial update is supported. If any field is not supplied, it will remain unchanged for the message template that is referenced by the `$LATEST` qualifier. Any modification will only apply to the message template that is referenced by the `$LATEST` qualifier. The fields for all available versions will remain unchanged.
 */
export declare const updateMessageTemplate: API.OperationMethod<UpdateMessageTemplateRequest, UpdateMessageTemplateResponse, UpdateMessageTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateMessageTemplateMetadataError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the Amazon Q in Connect message template metadata. Note that any modification to the message template's name, description and grouping configuration will applied to the message template pointed by the `$LATEST` qualifier and all available versions. Partial update is supported. If any field is not supplied, it will remain unchanged for the message template.
 */
export declare const updateMessageTemplateMetadata: API.OperationMethod<UpdateMessageTemplateMetadataRequest, UpdateMessageTemplateMetadataResponse, UpdateMessageTemplateMetadataError, Credentials | HttpClient.HttpClient>;
export type UpdateQuickResponseError = AccessDeniedException | ConflictException | PreconditionFailedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Updates an existing Amazon Q in Connect quick response.
 */
export declare const updateQuickResponse: API.OperationMethod<UpdateQuickResponseRequest, UpdateQuickResponseResponse, UpdateQuickResponseError, Credentials | HttpClient.HttpClient>;
export type UpdateSessionError = AccessDeniedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Updates a session. A session is a contextual container used for generating recommendations. Connect Customer updates the existing Amazon Q in Connect session for each contact on which Amazon Q in Connect is enabled.
 */
export declare const updateSession: API.OperationMethod<UpdateSessionRequest, UpdateSessionResponse, UpdateSessionError, Credentials | HttpClient.HttpClient>;
export type UpdateSessionDataError = AccessDeniedException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Updates the data stored on an Amazon Q in Connect Session.
 */
export declare const updateSessionData: API.OperationMethod<UpdateSessionDataRequest, UpdateSessionDataResponse, UpdateSessionDataError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=qconnect.d.ts.map