import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type * as stream from "effect/Stream";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DomainId = string;
export type SubscriptionId = string;
export interface ActivateSubscriptionInput {
    domainId: string;
    subscriptionId: string;
}
export type SubscriptionArn = string;
export type SubscriptionStatus = "ACTIVE" | "INACTIVE" | "DELETED" | (string & {});
export interface SubscriptionDescription {
    domainId: string;
    subscriptionId: string;
    arn: string;
    status: SubscriptionStatus;
    createdAt: Date;
    lastUpdatedAt: Date;
    activatedAt?: Date;
    deactivatedAt?: Date;
}
export interface ActivateSubscriptionOutput {
    subscription?: SubscriptionDescription;
}
export type DomainName = string;
export type KmsKeyArn = string;
export interface CreateWebAppConfiguration {
    ehrRole: string;
    idcInstanceId: string;
    idcRegion: string;
}
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateDomainInput {
    name: string;
    kmsKeyArn?: string;
    webAppSetupConfiguration?: CreateWebAppConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type DomainArn = string;
export type EncryptionType = "AWS_OWNED_KEY" | "CUSTOMER_MANAGED_KEY" | (string & {});
export interface EncryptionContext {
    encryptionType: EncryptionType;
    kmsKeyArn?: string;
}
export type DomainStatus = "ACTIVE" | "DELETING" | "DELETED" | (string & {});
export type WebAppUrl = string;
export interface WebAppConfiguration {
    ehrRole: string;
    idcApplicationId: string;
    idcRegion: string;
}
export interface CreateDomainOutput {
    domainId: string;
    arn: string;
    name: string;
    kmsKeyArn?: string;
    encryptionContext?: EncryptionContext;
    status: DomainStatus;
    webAppUrl?: string;
    webAppConfiguration?: WebAppConfiguration;
    createdAt: Date;
}
export interface CreateSubscriptionInput {
    domainId: string;
}
export interface CreateSubscriptionOutput {
    domainId: string;
    subscriptionId: string;
    arn: string;
    status: SubscriptionStatus;
    createdAt: Date;
    lastUpdatedAt: Date;
    activatedAt?: Date;
    deactivatedAt?: Date;
}
export interface DeactivateSubscriptionInput {
    domainId: string;
    subscriptionId: string;
}
export interface DeactivateSubscriptionOutput {
    subscription?: SubscriptionDescription;
}
export interface DeleteDomainInput {
    domainId: string;
}
export interface DeleteDomainOutput {
    domainId: string;
    arn: string;
    status: DomainStatus;
}
export interface GetDomainInput {
    domainId: string;
}
export interface GetDomainOutput {
    domainId: string;
    arn: string;
    name: string;
    kmsKeyArn?: string;
    encryptionContext?: EncryptionContext;
    status: DomainStatus;
    webAppUrl?: string;
    webAppConfiguration?: WebAppConfiguration;
    createdAt: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type ScribeSessionId = string;
export interface GetMedicalScribeListeningSessionInput {
    sessionId: string;
    domainId: string;
    subscriptionId: string;
}
export type MedicalScribeLanguageCode = "en-US" | "multi" | (string & {});
export type MedicalScribeMediaSampleRateHertz = number;
export type MedicalScribeMediaEncoding = "pcm" | "flac" | (string & {});
export type MedicalScribeChannelId = number;
export type MedicalScribeParticipantRole = "PATIENT" | "CLINICIAN" | (string & {});
export interface MedicalScribeChannelDefinition {
    channelId: number;
    participantRole: MedicalScribeParticipantRole;
}
export type MedicalScribeChannelDefinitions = MedicalScribeChannelDefinition[];
export type S3Uri = string;
export type ManagedNoteTemplate = "HISTORY_AND_PHYSICAL" | "GIRPP" | "DAP" | "SIRP" | "BIRP" | "BEHAVIORAL_SOAP" | "PHYSICAL_SOAP" | (string & {});
export interface ManagedTemplateResponse {
    templateType?: ManagedNoteTemplate;
}
export type CustomTemplateBase = "HISTORY_AND_PHYSICAL" | "GIRPP" | "DAP" | "SIRP" | "BIRP" | "BEHAVIORAL_SOAP" | (string & {});
export interface CustomTemplateResponse {
    templateType?: CustomTemplateBase;
}
export type NoteTemplateSettingsResponse = {
    managedTemplate: ManagedTemplateResponse;
    customTemplate?: never;
} | {
    managedTemplate?: never;
    customTemplate: CustomTemplateResponse;
};
export interface ClinicalNoteGenerationSettingsResponse {
    noteTemplateSettings?: NoteTemplateSettingsResponse;
}
export interface MedicalScribePostStreamActionSettingsResponse {
    outputS3Uri: string;
    clinicalNoteGenerationSettings: ClinicalNoteGenerationSettingsResponse;
}
export type Uri = string;
export type PostStreamArtifactGenerationStatus = "IN_PROGRESS" | "FAILED" | "COMPLETED" | (string & {});
export type ErrorMessage = string;
export interface ArtifactDetails {
    outputLocation?: string;
    status?: PostStreamArtifactGenerationStatus;
    failureReason?: string;
}
export interface ClinicalNoteGenerationResult {
    noteResult?: ArtifactDetails;
    transcriptResult?: ArtifactDetails;
    afterVisitSummaryResult?: ArtifactDetails;
}
export interface MedicalScribePostStreamActionsResult {
    clinicalNoteGenerationResult?: ClinicalNoteGenerationResult;
}
export type NonNullBoolean = boolean;
export type MedicalScribeStreamStatus = "IN_PROGRESS" | "PAUSED" | "FAILED" | "COMPLETED" | (string & {});
export interface MedicalScribeListeningSessionDetails {
    sessionId?: string;
    domainId?: string;
    subscriptionId?: string;
    languageCode?: MedicalScribeLanguageCode;
    mediaSampleRateHertz?: number;
    mediaEncoding?: MedicalScribeMediaEncoding;
    channelDefinitions?: MedicalScribeChannelDefinition[];
    postStreamActionSettings?: MedicalScribePostStreamActionSettingsResponse;
    postStreamActionResult?: MedicalScribePostStreamActionsResult;
    encounterContextProvided?: boolean;
    streamStatus?: MedicalScribeStreamStatus;
    streamCreationTime?: Date;
    streamEndTime?: Date;
}
export interface GetMedicalScribeListeningSessionOutput {
    medicalScribeListeningSessionDetails?: MedicalScribeListeningSessionDetails;
}
export type JobId = string;
export interface GetPatientInsightsJobRequest {
    domainId: string;
    jobId: string;
}
export type JobArn = string;
export type JobStatus = "SUBMITTED" | "IN_PROGRESS" | "FAILED" | "SUCCEEDED" | (string & {});
export interface InsightsOutput {
    uri: string;
}
export type NonEmptyString = string;
export type SensitiveNonEmptyString = string | redacted.Redacted<string>;
export type SensitiveIsoDateString = string | redacted.Redacted<string>;
export type Pronouns = "HE_HIM" | "SHE_HER" | "THEY_THEM" | (string & {});
export interface PatientInsightsPatientContext {
    patientId: string | redacted.Redacted<string>;
    dateOfBirth?: string | redacted.Redacted<string>;
    pronouns?: Pronouns;
}
export type InsightsType = "PRE_VISIT" | (string & {});
export interface InsightsContext {
    insightsType: InsightsType;
}
export interface PatientInsightsEncounterContext {
    encounterReason: string | redacted.Redacted<string>;
}
export type ProviderRole = "CLINICIAN" | (string & {});
export type Specialty = "PRIMARY_CARE" | (string & {});
export interface UserContext {
    role: ProviderRole;
    userId: string | redacted.Redacted<string>;
    specialty?: Specialty;
}
export interface FHIRServer {
    fhirEndpoint: string;
    oauthToken?: string | redacted.Redacted<string>;
}
export interface S3Source {
    uri: string;
}
export type S3Sources = S3Source[];
export interface InputDataConfig {
    fhirServer?: FHIRServer;
    s3Sources?: S3Source[];
}
export interface OutputDataConfig {
    s3OutputPath: string;
}
export interface GetPatientInsightsJobResponse {
    jobId: string;
    jobArn: string;
    jobStatus: JobStatus;
    creationTime?: Date;
    updatedTime?: Date;
    insightsOutput?: InsightsOutput;
    statusDetails?: string;
    patientContext: PatientInsightsPatientContext;
    insightsContext: InsightsContext;
    encounterContext: PatientInsightsEncounterContext;
    userContext: UserContext;
    inputDataConfig: InputDataConfig;
    outputDataConfig: OutputDataConfig;
}
export interface GetSubscriptionInput {
    domainId: string;
    subscriptionId: string;
}
export interface GetSubscriptionOutput {
    subscription?: SubscriptionDescription;
}
export interface ListDomainsInput {
    status?: DomainStatus;
    maxResults?: number;
    nextToken?: string;
}
export interface DomainSummary {
    domainId: string;
    arn: string;
    name: string;
    status: DomainStatus;
    createdAt: Date;
}
export type DomainSummaryList = DomainSummary[];
export interface ListDomainsOutput {
    domains: DomainSummary[];
    nextToken?: string;
}
export interface ListSubscriptionsInput {
    domainId: string;
    maxResults?: number;
    nextToken?: string;
}
export type SubscriptionList = SubscriptionDescription[];
export interface ListSubscriptionsOutput {
    subscriptions: SubscriptionDescription[];
    nextToken?: string;
}
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags?: {
        [key: string]: string | undefined;
    };
}
export type AudioChunk = Uint8Array;
export interface MedicalScribeAudioEvent {
    audioChunk: Uint8Array;
}
export interface MedicalScribeBinaryAudioEvent {
    audioChunk: Uint8Array;
}
export type MedicalScribeSessionControlEventType = "END_OF_SESSION" | (string & {});
export interface MedicalScribeSessionControlEvent {
    type?: MedicalScribeSessionControlEventType;
}
export interface ManagedTemplate {
    templateType: ManagedNoteTemplate;
}
export type SensitiveSectionHeaderString = string | redacted.Redacted<string>;
export type SensitiveMarkdownString = string | redacted.Redacted<string>;
export interface TemplateSectionInstruction {
    sectionHeader: string | redacted.Redacted<string>;
    sectionInstruction: string | redacted.Redacted<string>;
}
export type TemplateInstructions = TemplateSectionInstruction[];
export interface CustomTemplate {
    templateType: CustomTemplateBase;
    templateInstructions: TemplateSectionInstruction[];
}
export type NoteTemplateSettings = {
    managedTemplate: ManagedTemplate;
    customTemplate?: never;
} | {
    managedTemplate?: never;
    customTemplate: CustomTemplate;
};
export interface ClinicalNoteGenerationSettings {
    noteTemplateSettings: NoteTemplateSettings;
}
export interface MedicalScribePostStreamActionSettings {
    outputS3Uri: string;
    clinicalNoteGenerationSettings: ClinicalNoteGenerationSettings;
}
export interface EncounterContext {
    unstructuredContext?: string | redacted.Redacted<string>;
}
export interface MedicalScribeConfigurationEvent {
    postStreamActionSettings: MedicalScribePostStreamActionSettings;
    channelDefinitions?: MedicalScribeChannelDefinition[];
    encounterContext?: EncounterContext;
}
export type MedicalScribeInputStream = {
    audioEvent: MedicalScribeAudioEvent;
    binaryAudioEvent?: never;
    sessionControlEvent?: never;
    configurationEvent?: never;
} | {
    audioEvent?: never;
    binaryAudioEvent: MedicalScribeBinaryAudioEvent;
    sessionControlEvent?: never;
    configurationEvent?: never;
} | {
    audioEvent?: never;
    binaryAudioEvent?: never;
    sessionControlEvent: MedicalScribeSessionControlEvent;
    configurationEvent?: never;
} | {
    audioEvent?: never;
    binaryAudioEvent?: never;
    sessionControlEvent?: never;
    configurationEvent: MedicalScribeConfigurationEvent;
};
export interface StartMedicalScribeListeningSessionInput {
    sessionId: string;
    domainId: string;
    subscriptionId: string;
    languageCode: MedicalScribeLanguageCode;
    mediaSampleRateHertz: number;
    mediaEncoding: MedicalScribeMediaEncoding;
    inputStream?: stream.Stream<MedicalScribeInputStream, Error, never>;
}
export type RequestId = string;
export type AudioOffset = number;
export interface MedicalScribeTranscriptSegment {
    segmentId?: string;
    audioBeginOffset?: number;
    audioEndOffset?: number;
    isPartial?: boolean;
    channelId?: string;
    content?: string;
}
export interface MedicalScribeTranscriptEvent {
    transcriptSegment?: MedicalScribeTranscriptSegment;
}
export type MedicalScribeOutputStream = {
    transcriptEvent: MedicalScribeTranscriptEvent;
    internalFailureException?: never;
    validationException?: never;
} | {
    transcriptEvent?: never;
    internalFailureException: InternalServerException;
    validationException?: never;
} | {
    transcriptEvent?: never;
    internalFailureException?: never;
    validationException: ValidationException;
};
export interface StartMedicalScribeListeningSessionOutput {
    sessionId?: string;
    domainId?: string;
    subscriptionId?: string;
    requestId?: string;
    languageCode?: MedicalScribeLanguageCode;
    mediaSampleRateHertz?: number;
    mediaEncoding?: MedicalScribeMediaEncoding;
    responseStream?: stream.Stream<MedicalScribeOutputStream, Error, never>;
}
export interface StartPatientInsightsJobRequest {
    domainId: string;
    patientContext: PatientInsightsPatientContext;
    insightsContext: InsightsContext;
    encounterContext: PatientInsightsEncounterContext;
    userContext: UserContext;
    inputDataConfig: InputDataConfig;
    outputDataConfig: OutputDataConfig;
    clientToken?: string;
}
export interface StartPatientInsightsJobResponse {
    jobArn: string;
    jobId: string;
    creationTime?: Date;
}
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export type ActivateSubscriptionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Activates a Subscription to enable billing for a user.
 */
export declare const activateSubscription: API.OperationMethod<ActivateSubscriptionInput, ActivateSubscriptionOutput, ActivateSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateDomainError = ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a new Domain for managing HealthAgent resources.
 */
export declare const createDomain: API.OperationMethod<CreateDomainInput, CreateDomainOutput, CreateDomainError, Credentials | HttpClient.HttpClient>;
export type CreateSubscriptionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a new Subscription within a Domain for billing and user management.
 */
export declare const createSubscription: API.OperationMethod<CreateSubscriptionInput, CreateSubscriptionOutput, CreateSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeactivateSubscriptionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deactivates a Subscription to stop billing for a user.
 */
export declare const deactivateSubscription: API.OperationMethod<DeactivateSubscriptionInput, DeactivateSubscriptionOutput, DeactivateSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainError = ResourceNotFoundException | CommonErrors;
/**
 * Deletes a Domain and all associated resources.
 */
export declare const deleteDomain: API.OperationMethod<DeleteDomainInput, DeleteDomainOutput, DeleteDomainError, Credentials | HttpClient.HttpClient>;
export type GetDomainError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about a Domain.
 */
export declare const getDomain: API.OperationMethod<GetDomainInput, GetDomainOutput, GetDomainError, Credentials | HttpClient.HttpClient>;
export type GetMedicalScribeListeningSessionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Retrieves details about an existing Medical Scribe listening session
 */
export declare const getMedicalScribeListeningSession: API.OperationMethod<GetMedicalScribeListeningSessionInput, GetMedicalScribeListeningSessionOutput, GetMedicalScribeListeningSessionError, Credentials | HttpClient.HttpClient>;
export type GetPatientInsightsJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get details of a started patient insights job.
 */
export declare const getPatientInsightsJob: API.OperationMethod<GetPatientInsightsJobRequest, GetPatientInsightsJobResponse, GetPatientInsightsJobError, Credentials | HttpClient.HttpClient>;
export type GetSubscriptionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves information about a Subscription.
 */
export declare const getSubscription: API.OperationMethod<GetSubscriptionInput, GetSubscriptionOutput, GetSubscriptionError, Credentials | HttpClient.HttpClient>;
export type ListDomainsError = CommonErrors;
/**
 * Lists Domains for a given account.
 */
export declare const listDomains: API.PaginatedOperationMethod<ListDomainsInput, ListDomainsOutput, ListDomainsError, Credentials | HttpClient.HttpClient, DomainSummary>;
export type ListSubscriptionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all Subscriptions within a Domain.
 */
export declare const listSubscriptions: API.PaginatedOperationMethod<ListSubscriptionsInput, ListSubscriptionsOutput, ListSubscriptionsError, Credentials | HttpClient.HttpClient, SubscriptionDescription>;
export type ListTagsForResourceError = CommonErrors;
/**
 * Lists the tags associated with the specified resource
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartMedicalScribeListeningSessionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a new Medical Scribe listening session for real-time audio transcription
 */
export declare const startMedicalScribeListeningSession: API.OperationMethod<StartMedicalScribeListeningSessionInput, StartMedicalScribeListeningSessionOutput, StartMedicalScribeListeningSessionError, Credentials | HttpClient.HttpClient>;
export type StartPatientInsightsJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a new patient insights job.
 */
export declare const startPatientInsightsJob: API.OperationMethod<StartPatientInsightsJobRequest, StartPatientInsightsJobResponse, StartPatientInsightsJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = CommonErrors;
/**
 * Associates the specified tags with the specified resource
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = CommonErrors;
/**
 * Removes the specified tags from the specified resource
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=connecthealth.d.ts.map