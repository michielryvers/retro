import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SpaceId = string;
export type ChannelId = string;
export type AccessorId = string;
export type AccessorIdList = string[];
export type ChannelRole = "ASKER" | "EXPERT" | "MODERATOR" | "SUPPORTREQUESTOR" | (string & {});
export interface BatchAddChannelRoleToAccessorsInput {
    spaceId: string;
    channelId: string;
    accessorIds: string[];
    channelRole: ChannelRole;
}
export type ErrorCode = number;
export type ErrorMessage = string;
export interface BatchError {
    accessorId: string;
    error: number;
    message: string;
}
export type BatchErrorList = BatchError[];
export interface BatchAddChannelRoleToAccessorsOutput {
    addedAccessorIds: string[];
    errors: BatchError[];
}
export type Role = "EXPERT" | "MODERATOR" | "ADMINISTRATOR" | "SUPPORTREQUESTOR" | (string & {});
export interface BatchAddRoleInput {
    spaceId: string;
    accessorIds: string[];
    role: Role;
}
export interface BatchAddRoleOutput {
    addedAccessorIds: string[];
    errors: BatchError[];
}
export interface BatchRemoveChannelRoleFromAccessorsInput {
    spaceId: string;
    channelId: string;
    accessorIds: string[];
    channelRole: ChannelRole;
}
export interface BatchRemoveChannelRoleFromAccessorsOutput {
    removedAccessorIds: string[];
    errors: BatchError[];
}
export interface BatchRemoveRoleInput {
    spaceId: string;
    accessorIds: string[];
    role: Role;
}
export interface BatchRemoveRoleOutput {
    removedAccessorIds: string[];
    errors: BatchError[];
}
export type ChannelName = string | redacted.Redacted<string>;
export type ChannelDescription = string | redacted.Redacted<string>;
export interface CreateChannelInput {
    spaceId: string;
    channelName: string | redacted.Redacted<string>;
    channelDescription?: string | redacted.Redacted<string>;
}
export interface CreateChannelOutput {
    channelId: string;
}
export type SpaceName = string | redacted.Redacted<string>;
export type SpaceSubdomain = string;
export type TierLevel = "BASIC" | "STANDARD" | (string & {});
export type SpaceDescription = string | redacted.Redacted<string>;
export type KMSKey = string;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export type Arn = string;
export type FeatureEnableParameter = "ENABLED" | "DISABLED" | (string & {});
export type EmailDomain = string | redacted.Redacted<string>;
export type AllowedDomainsList = (string | redacted.Redacted<string>)[];
export interface SupportedEmailDomainsParameters {
    enabled?: FeatureEnableParameter;
    allowedDomains?: (string | redacted.Redacted<string>)[];
}
export interface CreateSpaceInput {
    name: string | redacted.Redacted<string>;
    subdomain: string;
    tier: TierLevel;
    description?: string | redacted.Redacted<string>;
    userKMSKey?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    roleArn?: string;
    supportedEmailDomains?: SupportedEmailDomainsParameters;
}
export interface CreateSpaceOutput {
    spaceId: string;
}
export interface DeleteSpaceInput {
    spaceId: string;
}
export interface DeleteSpaceResponse {
}
export type AdminId = string;
export interface DeregisterAdminInput {
    spaceId: string;
    adminId: string;
}
export interface DeregisterAdminResponse {
}
export interface GetChannelInput {
    spaceId: string;
    channelId: string;
}
export type ChannelRoleList = ChannelRole[];
export type ChannelRoles = {
    [key: string]: ChannelRole[] | undefined;
};
export type ChannelStatus = "CREATED" | "CREATING" | "CREATE_FAILED" | "DELETED" | "DELETING" | "DELETE_FAILED" | (string & {});
export interface GetChannelOutput {
    spaceId: string;
    channelId: string;
    channelName: string | redacted.Redacted<string>;
    channelDescription?: string | redacted.Redacted<string>;
    createDateTime: Date;
    deleteDateTime?: Date;
    channelRoles?: {
        [key: string]: ChannelRole[] | undefined;
    };
    channelStatus: ChannelStatus;
}
export interface GetSpaceInput {
    spaceId: string;
}
export type ProvisioningStatus = string;
export type ConfigurationStatus = "CONFIGURED" | "UNCONFIGURED" | (string & {});
export type ClientId = string;
export type IdentityStoreId = string;
export type VanityDomainStatus = "PENDING" | "APPROVED" | "UNAPPROVED" | (string & {});
export type Url = string;
export type StorageLimit = number;
export type UserAdmins = string[];
export type GroupAdmins = string[];
export type RoleList = Role[];
export type Roles = {
    [key: string]: Role[] | undefined;
};
export type UserCount = number;
export type ContentSize = number;
export type FeatureEnableStatus = "ENABLED" | "DISABLED" | "NOT_ALLOWED" | (string & {});
export interface SupportedEmailDomainsStatus {
    enabled?: FeatureEnableStatus;
    allowedDomains?: (string | redacted.Redacted<string>)[];
}
export interface GetSpaceOutput {
    spaceId: string;
    arn: string;
    name: string | redacted.Redacted<string>;
    status: string;
    configurationStatus: ConfigurationStatus;
    clientId: string;
    identityStoreId?: string;
    applicationArn?: string;
    description?: string | redacted.Redacted<string>;
    vanityDomainStatus: VanityDomainStatus;
    vanityDomain: string;
    randomDomain: string;
    customerRoleArn?: string;
    createDateTime: Date;
    deleteDateTime?: Date;
    tier: TierLevel;
    storageLimit: number;
    userAdmins?: string[];
    groupAdmins?: string[];
    roles?: {
        [key: string]: Role[] | undefined;
    };
    userKMSKey?: string;
    userCount?: number;
    contentSize?: number;
    supportedEmailDomains?: SupportedEmailDomainsStatus;
}
export type ListChannelsLimit = number;
export interface ListChannelsInput {
    spaceId: string;
    nextToken?: string;
    maxResults?: number;
}
export type GroupCount = number;
export interface ChannelData {
    spaceId: string;
    channelId: string;
    channelName: string | redacted.Redacted<string>;
    channelDescription?: string | redacted.Redacted<string>;
    createDateTime: Date;
    deleteDateTime?: Date;
    channelStatus: ChannelStatus;
    userCount: number;
    groupCount: number;
}
export type ChannelsList = ChannelData[];
export interface ListChannelsOutput {
    channels: ChannelData[];
    nextToken?: string;
}
export type ListSpacesLimit = number;
export interface ListSpacesInput {
    nextToken?: string;
    maxResults?: number;
}
export interface SpaceData {
    spaceId: string;
    arn: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    status: string;
    configurationStatus: ConfigurationStatus;
    vanityDomainStatus: VanityDomainStatus;
    vanityDomain: string;
    randomDomain: string;
    tier: TierLevel;
    storageLimit: number;
    createDateTime: Date;
    deleteDateTime?: Date;
    userKMSKey?: string;
    userCount?: number;
    contentSize?: number;
    supportedEmailDomains?: SupportedEmailDomainsStatus;
}
export type SpacesList = SpaceData[];
export interface ListSpacesOutput {
    spaces: SpaceData[];
    nextToken?: string;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface RegisterAdminInput {
    spaceId: string;
    adminId: string;
}
export interface RegisterAdminResponse {
}
export type InviteTitle = string | redacted.Redacted<string>;
export type InviteBody = string | redacted.Redacted<string>;
export interface SendInvitesInput {
    spaceId: string;
    accessorIds: string[];
    title: string | redacted.Redacted<string>;
    body: string | redacted.Redacted<string>;
}
export interface SendInvitesResponse {
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateChannelInput {
    spaceId: string;
    channelId: string;
    channelName: string | redacted.Redacted<string>;
    channelDescription?: string | redacted.Redacted<string>;
}
export interface UpdateChannelOutput {
}
export interface UpdateSpaceInput {
    spaceId: string;
    description?: string | redacted.Redacted<string>;
    tier?: TierLevel;
    roleArn?: string;
    supportedEmailDomains?: SupportedEmailDomainsParameters;
}
export interface UpdateSpaceResponse {
}
export type ValidationExceptionReason = "unknownOperation" | "cannotParse" | "fieldValidationFailed" | "other" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type BatchAddChannelRoleToAccessorsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Add role to multiple users or groups in a private re:Post channel.
 */
export declare const batchAddChannelRoleToAccessors: API.OperationMethod<BatchAddChannelRoleToAccessorsInput, BatchAddChannelRoleToAccessorsOutput, BatchAddChannelRoleToAccessorsError, Credentials | HttpClient.HttpClient>;
export type BatchAddRoleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Add a role to multiple users or groups in a private re:Post.
 */
export declare const batchAddRole: API.OperationMethod<BatchAddRoleInput, BatchAddRoleOutput, BatchAddRoleError, Credentials | HttpClient.HttpClient>;
export type BatchRemoveChannelRoleFromAccessorsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Remove a role from multiple users or groups in a private re:Post channel.
 */
export declare const batchRemoveChannelRoleFromAccessors: API.OperationMethod<BatchRemoveChannelRoleFromAccessorsInput, BatchRemoveChannelRoleFromAccessorsOutput, BatchRemoveChannelRoleFromAccessorsError, Credentials | HttpClient.HttpClient>;
export type BatchRemoveRoleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Remove a role from multiple users or groups in a private re:Post.
 */
export declare const batchRemoveRole: API.OperationMethod<BatchRemoveRoleInput, BatchRemoveRoleOutput, BatchRemoveRoleError, Credentials | HttpClient.HttpClient>;
export type CreateChannelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a channel in an AWS re:Post Private private re:Post.
 */
export declare const createChannel: API.OperationMethod<CreateChannelInput, CreateChannelOutput, CreateChannelError, Credentials | HttpClient.HttpClient>;
export type CreateSpaceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an AWS re:Post Private private re:Post.
 */
export declare const createSpace: API.OperationMethod<CreateSpaceInput, CreateSpaceOutput, CreateSpaceError, Credentials | HttpClient.HttpClient>;
export type DeleteSpaceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an AWS re:Post Private private re:Post.
 */
export declare const deleteSpace: API.OperationMethod<DeleteSpaceInput, DeleteSpaceResponse, DeleteSpaceError, Credentials | HttpClient.HttpClient>;
export type DeregisterAdminError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the user or group from the list of administrators of the private re:Post.
 */
export declare const deregisterAdmin: API.OperationMethod<DeregisterAdminInput, DeregisterAdminResponse, DeregisterAdminError, Credentials | HttpClient.HttpClient>;
export type GetChannelError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Displays information about a channel in a private re:Post.
 */
export declare const getChannel: API.OperationMethod<GetChannelInput, GetChannelOutput, GetChannelError, Credentials | HttpClient.HttpClient>;
export type GetSpaceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Displays information about the AWS re:Post Private private re:Post.
 */
export declare const getSpace: API.OperationMethod<GetSpaceInput, GetSpaceOutput, GetSpaceError, Credentials | HttpClient.HttpClient>;
export type ListChannelsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | ResourceNotFoundException | CommonErrors;
/**
 * Returns the list of channel within a private re:Post with some information about each channel.
 */
export declare const listChannels: API.PaginatedOperationMethod<ListChannelsInput, ListChannelsOutput, ListChannelsError, Credentials | HttpClient.HttpClient, ChannelData>;
export type ListSpacesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of AWS re:Post Private private re:Posts in the account with some information about each private re:Post.
 */
export declare const listSpaces: API.PaginatedOperationMethod<ListSpacesInput, ListSpacesOutput, ListSpacesError, Credentials | HttpClient.HttpClient, SpaceData>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the tags that are associated with the AWS re:Post Private resource specified by the resourceArn. The only resource that can be tagged is a private re:Post.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RegisterAdminError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a user or group to the list of administrators of the private re:Post.
 */
export declare const registerAdmin: API.OperationMethod<RegisterAdminInput, RegisterAdminResponse, RegisterAdminError, Credentials | HttpClient.HttpClient>;
export type SendInvitesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends an invitation email to selected users and groups.
 */
export declare const sendInvites: API.OperationMethod<SendInvitesInput, SendInvitesResponse, SendInvitesError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates tags with an AWS re:Post Private resource. Currently, the only resource that can be tagged is the private re:Post. If you specify a new tag key for the resource, the tag is appended to the list of tags that are associated with the resource. If you specify a tag key that's already associated with the resource, the new tag value that you specify replaces the previous value for that tag.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the association of the tag with the AWS re:Post Private resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies an existing channel.
 */
export declare const updateChannel: API.OperationMethod<UpdateChannelInput, UpdateChannelOutput, UpdateChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateSpaceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies an existing AWS re:Post Private private re:Post.
 */
export declare const updateSpace: API.OperationMethod<UpdateSpaceInput, UpdateSpaceResponse, UpdateSpaceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=repostspace.d.ts.map