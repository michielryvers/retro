import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ConfigurationParametersMap = {
    [key: string]: string | undefined;
};
export type IAMRoleArn = string;
export interface ConfigurationDefinitionInput {
    Type: string;
    Parameters: {
        [key: string]: string | undefined;
    };
    TypeVersion?: string;
    LocalDeploymentExecutionRoleName?: string;
    LocalDeploymentAdministrationRoleArn?: string;
}
export type ConfigurationDefinitionsInputList = ConfigurationDefinitionInput[];
export type TagsMap = {
    [key: string]: string | undefined;
};
export interface CreateConfigurationManagerInput {
    Name?: string;
    Description?: string;
    ConfigurationDefinitions: ConfigurationDefinitionInput[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateConfigurationManagerOutput {
    ManagerArn: string;
}
export interface DeleteConfigurationManagerInput {
    ManagerArn: string;
}
export interface DeleteConfigurationManagerResponse {
}
export interface GetConfigurationInput {
    ConfigurationId: string;
}
export type StatusType = "Deployment" | "AsyncExecutions" | (string & {});
export type Status = "INITIALIZING" | "DEPLOYING" | "SUCCEEDED" | "DELETING" | "STOPPING" | "FAILED" | "STOPPED" | "DELETE_FAILED" | "STOP_FAILED" | "NONE" | (string & {});
export type StatusDetails = {
    [key: string]: string | undefined;
};
export interface StatusSummary {
    StatusType: StatusType;
    Status?: Status;
    StatusMessage?: string;
    LastUpdatedAt: Date;
    StatusDetails?: {
        [key: string]: string | undefined;
    };
}
export type StatusSummariesList = StatusSummary[];
export interface GetConfigurationOutput {
    Id?: string;
    ManagerArn?: string;
    ConfigurationDefinitionId?: string;
    Type?: string;
    TypeVersion?: string;
    Account?: string;
    Region?: string;
    CreatedAt?: Date;
    LastModifiedAt?: Date;
    StatusSummaries?: StatusSummary[];
    Parameters?: {
        [key: string]: string | undefined;
    };
}
export interface GetConfigurationManagerInput {
    ManagerArn: string;
}
export interface ConfigurationDefinition {
    Type: string;
    Parameters: {
        [key: string]: string | undefined;
    };
    TypeVersion?: string;
    LocalDeploymentExecutionRoleName?: string;
    LocalDeploymentAdministrationRoleArn?: string;
    Id?: string;
}
export type ConfigurationDefinitionsList = ConfigurationDefinition[];
export interface GetConfigurationManagerOutput {
    ManagerArn: string;
    Description?: string;
    Name?: string;
    CreatedAt?: Date;
    LastModifiedAt?: Date;
    StatusSummaries?: StatusSummary[];
    ConfigurationDefinitions?: ConfigurationDefinition[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetServiceSettingsRequest {
}
export interface ServiceSettings {
    ExplorerEnablingRoleArn?: string;
}
export interface GetServiceSettingsOutput {
    ServiceSettings?: ServiceSettings;
}
export type FilterValues = string[];
export interface Filter {
    Key: string;
    Values: string[];
}
export type FiltersList = Filter[];
export interface ListConfigurationManagersInput {
    StartingToken?: string;
    MaxItems?: number;
    Filters?: Filter[];
}
export interface ConfigurationDefinitionSummary {
    Id?: string;
    Type?: string;
    TypeVersion?: string;
    FirstClassParameters?: {
        [key: string]: string | undefined;
    };
}
export type ConfigurationDefinitionSummariesList = ConfigurationDefinitionSummary[];
export interface ConfigurationManagerSummary {
    ManagerArn: string;
    Description?: string;
    Name?: string;
    StatusSummaries?: StatusSummary[];
    ConfigurationDefinitionSummaries?: ConfigurationDefinitionSummary[];
}
export type ConfigurationManagerList = ConfigurationManagerSummary[];
export interface ListConfigurationManagersOutput {
    ConfigurationManagersList?: ConfigurationManagerSummary[];
    NextToken?: string;
}
export interface ListConfigurationsInput {
    StartingToken?: string;
    MaxItems?: number;
    Filters?: Filter[];
    ManagerArn?: string;
    ConfigurationDefinitionId?: string;
}
export interface ConfigurationSummary {
    Id?: string;
    ManagerArn?: string;
    ConfigurationDefinitionId?: string;
    Type?: string;
    TypeVersion?: string;
    Region?: string;
    Account?: string;
    CreatedAt?: Date;
    FirstClassParameters?: {
        [key: string]: string | undefined;
    };
    StatusSummaries?: StatusSummary[];
}
export type ConfigurationsList = ConfigurationSummary[];
export interface ListConfigurationsOutput {
    ConfigurationsList?: ConfigurationSummary[];
    NextToken?: string;
}
export interface ListQuickSetupTypesRequest {
}
export interface QuickSetupTypeOutput {
    Type?: string;
    LatestVersion?: string;
}
export type QuickSetupTypeList = QuickSetupTypeOutput[];
export interface ListQuickSetupTypesOutput {
    QuickSetupTypeList?: QuickSetupTypeOutput[];
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface TagEntry {
    Key?: string;
    Value?: string;
}
export type Tags = TagEntry[];
export interface ListTagsForResourceResponse {
    Tags?: TagEntry[];
}
export interface TagResourceInput {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceInput {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateConfigurationDefinitionInput {
    ManagerArn: string;
    Id: string;
    TypeVersion?: string;
    Parameters?: {
        [key: string]: string | undefined;
    };
    LocalDeploymentExecutionRoleName?: string;
    LocalDeploymentAdministrationRoleArn?: string;
}
export interface UpdateConfigurationDefinitionResponse {
}
export interface UpdateConfigurationManagerInput {
    ManagerArn: string;
    Name?: string;
    Description?: string;
}
export interface UpdateConfigurationManagerResponse {
}
export interface UpdateServiceSettingsInput {
    ExplorerEnablingRoleArn?: string;
}
export interface UpdateServiceSettingsResponse {
}
export type CreateConfigurationManagerError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a Quick Setup configuration manager resource. This object is a collection
 * of desired state configurations for multiple configuration definitions and
 * summaries describing the deployments of those definitions.
 */
export declare const createConfigurationManager: API.OperationMethod<CreateConfigurationManagerInput, CreateConfigurationManagerOutput, CreateConfigurationManagerError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationManagerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a configuration manager.
 */
export declare const deleteConfigurationManager: API.OperationMethod<DeleteConfigurationManagerInput, DeleteConfigurationManagerResponse, DeleteConfigurationManagerError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details about the specified configuration.
 */
export declare const getConfiguration: API.OperationMethod<GetConfigurationInput, GetConfigurationOutput, GetConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationManagerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a configuration manager.
 */
export declare const getConfigurationManager: API.OperationMethod<GetConfigurationManagerInput, GetConfigurationManagerOutput, GetConfigurationManagerError, Credentials | HttpClient.HttpClient>;
export type GetServiceSettingsError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Returns settings configured for Quick Setup in the requesting Amazon Web Services account and Amazon Web Services Region.
 */
export declare const getServiceSettings: API.OperationMethod<GetServiceSettingsRequest, GetServiceSettingsOutput, GetServiceSettingsError, Credentials | HttpClient.HttpClient>;
export type ListConfigurationManagersError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns Quick Setup configuration managers.
 */
export declare const listConfigurationManagers: API.PaginatedOperationMethod<ListConfigurationManagersInput, ListConfigurationManagersOutput, ListConfigurationManagersError, Credentials | HttpClient.HttpClient, ConfigurationManagerSummary>;
export type ListConfigurationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns configurations deployed by Quick Setup in the requesting Amazon Web Services account and Amazon Web Services Region.
 */
export declare const listConfigurations: API.PaginatedOperationMethod<ListConfigurationsInput, ListConfigurationsOutput, ListConfigurationsError, Credentials | HttpClient.HttpClient, ConfigurationSummary>;
export type ListQuickSetupTypesError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Returns the available Quick Setup types.
 */
export declare const listQuickSetupTypes: API.OperationMethod<ListQuickSetupTypesRequest, ListQuickSetupTypesOutput, ListQuickSetupTypesError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns tags assigned to the resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Assigns key-value pairs of metadata to Amazon Web Services resources.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationDefinitionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a Quick Setup configuration definition.
 */
export declare const updateConfigurationDefinition: API.OperationMethod<UpdateConfigurationDefinitionInput, UpdateConfigurationDefinitionResponse, UpdateConfigurationDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationManagerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a Quick Setup configuration manager.
 */
export declare const updateConfigurationManager: API.OperationMethod<UpdateConfigurationManagerInput, UpdateConfigurationManagerResponse, UpdateConfigurationManagerError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceSettingsError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates settings configured for Quick Setup.
 */
export declare const updateServiceSettings: API.OperationMethod<UpdateServiceSettingsInput, UpdateServiceSettingsResponse, UpdateServiceSettingsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ssm-quicksetup.d.ts.map