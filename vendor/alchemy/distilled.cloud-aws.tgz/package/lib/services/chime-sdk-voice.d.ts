import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const GoneException_base: S.TaggedErrorClass<"GoneException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GoneException extends /*@__PURE__*/ GoneException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ResourceLimitExceededException_base: S.TaggedErrorClass<"ResourceLimitExceededException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceLimitExceededException extends /*@__PURE__*/ ResourceLimitExceededException_base {
}
declare const ServiceFailureException_base: S.TaggedErrorClass<"ServiceFailureException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceFailureException extends /*@__PURE__*/ ServiceFailureException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottledClientException_base: S.TaggedErrorClass<"ThrottledClientException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottledClientException extends /*@__PURE__*/ ThrottledClientException_base {
}
declare const UnauthorizedClientException_base: S.TaggedErrorClass<"UnauthorizedClientException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedClientException extends /*@__PURE__*/ UnauthorizedClientException_base {
}
declare const UnprocessableEntityException_base: S.TaggedErrorClass<"UnprocessableEntityException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableEntityException extends /*@__PURE__*/ UnprocessableEntityException_base {
}
export type VoiceConnectorId = string;
export type E164PhoneNumber = string | redacted.Redacted<string>;
export type E164PhoneNumberList = (string | redacted.Redacted<string>)[];
export interface AssociatePhoneNumbersWithVoiceConnectorRequest {
    VoiceConnectorId: string;
    E164PhoneNumbers: (string | redacted.Redacted<string>)[];
    ForceAssociate?: boolean;
}
export type SensitiveNonEmptyString = string | redacted.Redacted<string>;
export type ErrorCode = "BadRequest" | "Conflict" | "Forbidden" | "NotFound" | "PreconditionFailed" | "ResourceLimitExceeded" | "ServiceFailure" | "AccessDenied" | "ServiceUnavailable" | "Throttled" | "Throttling" | "Unauthorized" | "Unprocessable" | "VoiceConnectorGroupAssociationsExist" | "PhoneNumberAssociationsExist" | "Gone" | "Validation" | (string & {});
export interface PhoneNumberError {
    PhoneNumberId?: string | redacted.Redacted<string>;
    ErrorCode?: ErrorCode;
    ErrorMessage?: string;
}
export type PhoneNumberErrorList = PhoneNumberError[];
export interface AssociatePhoneNumbersWithVoiceConnectorResponse {
    PhoneNumberErrors?: PhoneNumberError[];
}
export type NonEmptyString = string;
export interface AssociatePhoneNumbersWithVoiceConnectorGroupRequest {
    VoiceConnectorGroupId: string;
    E164PhoneNumbers: (string | redacted.Redacted<string>)[];
    ForceAssociate?: boolean;
}
export interface AssociatePhoneNumbersWithVoiceConnectorGroupResponse {
    PhoneNumberErrors?: PhoneNumberError[];
}
export type NonEmptyStringList = string[];
export interface BatchDeletePhoneNumberRequest {
    PhoneNumberIds: string[];
}
export interface BatchDeletePhoneNumberResponse {
    PhoneNumberErrors?: PhoneNumberError[];
}
export type PhoneNumberProductType = "VoiceConnector" | "SipMediaApplicationDialIn" | (string & {});
export type CallingName = string | redacted.Redacted<string>;
export type PhoneNumberName = string | redacted.Redacted<string>;
export interface UpdatePhoneNumberRequestItem {
    PhoneNumberId: string | redacted.Redacted<string>;
    ProductType?: PhoneNumberProductType;
    CallingName?: string | redacted.Redacted<string>;
    Name?: string | redacted.Redacted<string>;
}
export type UpdatePhoneNumberRequestItemList = UpdatePhoneNumberRequestItem[];
export interface BatchUpdatePhoneNumberRequest {
    UpdatePhoneNumberRequestItems: UpdatePhoneNumberRequestItem[];
}
export interface BatchUpdatePhoneNumberResponse {
    PhoneNumberErrors?: PhoneNumberError[];
}
export interface CreatePhoneNumberOrderRequest {
    ProductType: PhoneNumberProductType;
    E164PhoneNumbers: (string | redacted.Redacted<string>)[];
    Name?: string | redacted.Redacted<string>;
}
export type GuidString = string;
export type PhoneNumberOrderStatus = "Processing" | "Successful" | "Failed" | "Partial" | "PendingDocuments" | "Submitted" | "FOC" | "ChangeRequested" | "Exception" | "CancelRequested" | "Cancelled" | (string & {});
export type PhoneNumberOrderType = "New" | "Porting" | (string & {});
export type OrderedPhoneNumberStatus = "Processing" | "Acquired" | "Failed" | (string & {});
export interface OrderedPhoneNumber {
    E164PhoneNumber?: string | redacted.Redacted<string>;
    Status?: OrderedPhoneNumberStatus;
}
export type OrderedPhoneNumberList = OrderedPhoneNumber[];
export type Iso8601Timestamp = Date;
export interface PhoneNumberOrder {
    PhoneNumberOrderId?: string;
    ProductType?: PhoneNumberProductType;
    Status?: PhoneNumberOrderStatus;
    OrderType?: PhoneNumberOrderType;
    OrderedPhoneNumbers?: OrderedPhoneNumber[];
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    FocDate?: string;
}
export interface CreatePhoneNumberOrderResponse {
    PhoneNumberOrder?: PhoneNumberOrder;
}
export type ParticipantPhoneNumberList = (string | redacted.Redacted<string>)[];
export type ProxySessionNameString = string | redacted.Redacted<string>;
export type PositiveInteger = number;
export type Capability = "Voice" | "SMS" | (string & {});
export type CapabilityList = Capability[];
export type NumberSelectionBehavior = "PreferSticky" | "AvoidSticky" | (string & {});
export type GeoMatchLevel = "Country" | "AreaCode" | (string & {});
export type Country = string;
export type AreaCode = string;
export interface GeoMatchParams {
    Country: string;
    AreaCode: string;
}
export interface CreateProxySessionRequest {
    VoiceConnectorId: string;
    ParticipantPhoneNumbers: (string | redacted.Redacted<string>)[];
    Name?: string | redacted.Redacted<string>;
    ExpiryMinutes?: number;
    Capabilities: Capability[];
    NumberSelectionBehavior?: NumberSelectionBehavior;
    GeoMatchLevel?: GeoMatchLevel;
    GeoMatchParams?: GeoMatchParams;
}
export type NonEmptyString128 = string;
export type String128 = string;
export type ProxySessionStatus = "Open" | "InProgress" | "Closed" | (string & {});
export interface Participant {
    PhoneNumber?: string | redacted.Redacted<string>;
    ProxyPhoneNumber?: string | redacted.Redacted<string>;
}
export type Participants = Participant[];
export interface ProxySession {
    VoiceConnectorId?: string;
    ProxySessionId?: string;
    Name?: string;
    Status?: ProxySessionStatus;
    ExpiryMinutes?: number;
    Capabilities?: Capability[];
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    EndedTimestamp?: Date;
    Participants?: Participant[];
    NumberSelectionBehavior?: NumberSelectionBehavior;
    GeoMatchLevel?: GeoMatchLevel;
    GeoMatchParams?: GeoMatchParams;
}
export interface CreateProxySessionResponse {
    ProxySession?: ProxySession;
}
export type SipMediaApplicationName = string;
export type FunctionArn = string | redacted.Redacted<string>;
export interface SipMediaApplicationEndpoint {
    LambdaArn?: string | redacted.Redacted<string>;
}
export type SipMediaApplicationEndpointList = SipMediaApplicationEndpoint[];
export type TagKey = string | redacted.Redacted<string>;
export type TagValue = string | redacted.Redacted<string>;
export interface Tag {
    Key: string | redacted.Redacted<string>;
    Value: string | redacted.Redacted<string>;
}
export type TagList = Tag[];
export interface CreateSipMediaApplicationRequest {
    AwsRegion: string;
    Name: string;
    Endpoints: SipMediaApplicationEndpoint[];
    Tags?: Tag[];
}
export interface SipMediaApplication {
    SipMediaApplicationId?: string;
    AwsRegion?: string;
    Name?: string;
    Endpoints?: SipMediaApplicationEndpoint[];
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    SipMediaApplicationArn?: string;
}
export interface CreateSipMediaApplicationResponse {
    SipMediaApplication?: SipMediaApplication;
}
export type SensitiveString = string | redacted.Redacted<string>;
export type SipHeadersMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export type SMACreateCallArgumentsMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export interface CreateSipMediaApplicationCallRequest {
    FromPhoneNumber: string | redacted.Redacted<string>;
    ToPhoneNumber: string | redacted.Redacted<string>;
    SipMediaApplicationId: string;
    SipHeaders?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    ArgumentsMap?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export interface SipMediaApplicationCall {
    TransactionId?: string;
}
export interface CreateSipMediaApplicationCallResponse {
    SipMediaApplicationCall?: SipMediaApplicationCall;
}
export type SipRuleName = string;
export type SipRuleTriggerType = "ToPhoneNumber" | "RequestUriHostname" | (string & {});
export type SipApplicationPriority = number;
export interface SipRuleTargetApplication {
    SipMediaApplicationId?: string;
    Priority?: number;
    AwsRegion?: string;
}
export type SipRuleTargetApplicationList = SipRuleTargetApplication[];
export interface CreateSipRuleRequest {
    Name: string;
    TriggerType: SipRuleTriggerType;
    TriggerValue: string;
    Disabled?: boolean;
    TargetApplications: SipRuleTargetApplication[];
}
export interface SipRule {
    SipRuleId?: string;
    Name?: string;
    Disabled?: boolean;
    TriggerType?: SipRuleTriggerType;
    TriggerValue?: string;
    TargetApplications?: SipRuleTargetApplication[];
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
}
export interface CreateSipRuleResponse {
    SipRule?: SipRule;
}
export type VoiceConnectorName = string;
export type VoiceConnectorAwsRegion = "us-east-1" | "us-west-2" | "ca-central-1" | "eu-central-1" | "eu-west-1" | "eu-west-2" | "ap-northeast-2" | "ap-northeast-1" | "ap-southeast-1" | "ap-southeast-2" | (string & {});
export type VoiceConnectorIntegrationType = "CONNECT_CALL_TRANSFER_CONNECTOR" | "CONNECT_ANALYTICS_CONNECTOR" | (string & {});
export type NetworkType = "IPV4_ONLY" | "DUAL_STACK" | (string & {});
export interface CreateVoiceConnectorRequest {
    Name: string;
    AwsRegion?: VoiceConnectorAwsRegion;
    RequireEncryption: boolean;
    Tags?: Tag[];
    IntegrationType?: VoiceConnectorIntegrationType;
    NetworkType?: NetworkType;
}
export interface VoiceConnector {
    VoiceConnectorId?: string;
    AwsRegion?: VoiceConnectorAwsRegion;
    Name?: string;
    OutboundHostName?: string;
    RequireEncryption?: boolean;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    VoiceConnectorArn?: string;
    IntegrationType?: VoiceConnectorIntegrationType;
    NetworkType?: NetworkType;
}
export interface CreateVoiceConnectorResponse {
    VoiceConnector?: VoiceConnector;
}
export type VoiceConnectorGroupName = string;
export type VoiceConnectorItemPriority = number;
export interface VoiceConnectorItem {
    VoiceConnectorId: string;
    Priority?: number;
}
export type VoiceConnectorItemList = VoiceConnectorItem[];
export type CallDistributionType = "PriorityWeightedDistribution" | "LoadBalancedDistribution" | (string & {});
export interface CreateVoiceConnectorGroupRequest {
    Name: string;
    VoiceConnectorItems?: VoiceConnectorItem[];
    CallDistributionType?: CallDistributionType;
}
export interface VoiceConnectorGroup {
    VoiceConnectorGroupId?: string;
    Name?: string;
    VoiceConnectorItems?: VoiceConnectorItem[];
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    VoiceConnectorGroupArn?: string;
    CallDistributionType?: CallDistributionType;
}
export interface CreateVoiceConnectorGroupResponse {
    VoiceConnectorGroup?: VoiceConnectorGroup;
}
export type NonEmptyString256 = string;
export interface CreateVoiceProfileRequest {
    SpeakerSearchTaskId: string;
}
export type Arn = string | redacted.Redacted<string>;
export interface VoiceProfile {
    VoiceProfileId?: string;
    VoiceProfileArn?: string | redacted.Redacted<string>;
    VoiceProfileDomainId?: string;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    ExpirationTimestamp?: Date;
}
export interface CreateVoiceProfileResponse {
    VoiceProfile?: VoiceProfile;
}
export type VoiceProfileDomainName = string;
export type VoiceProfileDomainDescription = string;
export interface ServerSideEncryptionConfiguration {
    KmsKeyArn: string | redacted.Redacted<string>;
}
export type ClientRequestId = string;
export interface CreateVoiceProfileDomainRequest {
    Name: string;
    Description?: string;
    ServerSideEncryptionConfiguration: ServerSideEncryptionConfiguration;
    ClientRequestToken?: string;
    Tags?: Tag[];
}
export interface VoiceProfileDomain {
    VoiceProfileDomainId?: string;
    VoiceProfileDomainArn?: string | redacted.Redacted<string>;
    Name?: string;
    Description?: string;
    ServerSideEncryptionConfiguration?: ServerSideEncryptionConfiguration;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
}
export interface CreateVoiceProfileDomainResponse {
    VoiceProfileDomain?: VoiceProfileDomain;
}
export interface DeletePhoneNumberRequest {
    PhoneNumberId: string | redacted.Redacted<string>;
}
export interface DeletePhoneNumberResponse {
}
export interface DeleteProxySessionRequest {
    VoiceConnectorId: string;
    ProxySessionId: string;
}
export interface DeleteProxySessionResponse {
}
export interface DeleteSipMediaApplicationRequest {
    SipMediaApplicationId: string;
}
export interface DeleteSipMediaApplicationResponse {
}
export interface DeleteSipRuleRequest {
    SipRuleId: string;
}
export interface DeleteSipRuleResponse {
}
export interface DeleteVoiceConnectorRequest {
    VoiceConnectorId: string;
}
export interface DeleteVoiceConnectorResponse {
}
export interface DeleteVoiceConnectorEmergencyCallingConfigurationRequest {
    VoiceConnectorId: string;
}
export interface DeleteVoiceConnectorEmergencyCallingConfigurationResponse {
}
export interface DeleteVoiceConnectorExternalSystemsConfigurationRequest {
    VoiceConnectorId: string;
}
export interface DeleteVoiceConnectorExternalSystemsConfigurationResponse {
}
export interface DeleteVoiceConnectorGroupRequest {
    VoiceConnectorGroupId: string;
}
export interface DeleteVoiceConnectorGroupResponse {
}
export interface DeleteVoiceConnectorOriginationRequest {
    VoiceConnectorId: string;
}
export interface DeleteVoiceConnectorOriginationResponse {
}
export interface DeleteVoiceConnectorProxyRequest {
    VoiceConnectorId: string;
}
export interface DeleteVoiceConnectorProxyResponse {
}
export interface DeleteVoiceConnectorStreamingConfigurationRequest {
    VoiceConnectorId: string;
}
export interface DeleteVoiceConnectorStreamingConfigurationResponse {
}
export interface DeleteVoiceConnectorTerminationRequest {
    VoiceConnectorId: string;
}
export interface DeleteVoiceConnectorTerminationResponse {
}
export type SensitiveStringList = (string | redacted.Redacted<string>)[];
export interface DeleteVoiceConnectorTerminationCredentialsRequest {
    VoiceConnectorId: string;
    Usernames: (string | redacted.Redacted<string>)[];
}
export interface DeleteVoiceConnectorTerminationCredentialsResponse {
}
export interface DeleteVoiceProfileRequest {
    VoiceProfileId: string;
}
export interface DeleteVoiceProfileResponse {
}
export interface DeleteVoiceProfileDomainRequest {
    VoiceProfileDomainId: string;
}
export interface DeleteVoiceProfileDomainResponse {
}
export interface DisassociatePhoneNumbersFromVoiceConnectorRequest {
    VoiceConnectorId: string;
    E164PhoneNumbers: (string | redacted.Redacted<string>)[];
}
export interface DisassociatePhoneNumbersFromVoiceConnectorResponse {
    PhoneNumberErrors?: PhoneNumberError[];
}
export interface DisassociatePhoneNumbersFromVoiceConnectorGroupRequest {
    VoiceConnectorGroupId: string;
    E164PhoneNumbers: (string | redacted.Redacted<string>)[];
}
export interface DisassociatePhoneNumbersFromVoiceConnectorGroupResponse {
    PhoneNumberErrors?: PhoneNumberError[];
}
export interface GetGlobalSettingsRequest {
}
export type S3BucketName = string;
export interface VoiceConnectorSettings {
    CdrBucket?: string;
}
export interface GetGlobalSettingsResponse {
    VoiceConnector?: VoiceConnectorSettings;
}
export interface GetPhoneNumberRequest {
    PhoneNumberId: string | redacted.Redacted<string>;
}
export type Alpha2CountryCode = string;
export type PhoneNumberType = "Local" | "TollFree" | (string & {});
export type PhoneNumberStatus = "Cancelled" | "PortinCancelRequested" | "PortinInProgress" | "AcquireInProgress" | "AcquireFailed" | "Unassigned" | "Assigned" | "ReleaseInProgress" | "DeleteInProgress" | "ReleaseFailed" | "DeleteFailed" | (string & {});
export interface PhoneNumberCapabilities {
    InboundCall?: boolean;
    OutboundCall?: boolean;
    InboundSMS?: boolean;
    OutboundSMS?: boolean;
    InboundMMS?: boolean;
    OutboundMMS?: boolean;
}
export type PhoneNumberAssociationName = "VoiceConnectorId" | "VoiceConnectorGroupId" | "SipRuleId" | (string & {});
export interface PhoneNumberAssociation {
    Value?: string;
    Name?: PhoneNumberAssociationName;
    AssociatedTimestamp?: Date;
}
export type PhoneNumberAssociationList = PhoneNumberAssociation[];
export type CallingNameStatus = "Unassigned" | "UpdateInProgress" | "UpdateSucceeded" | "UpdateFailed" | (string & {});
export interface PhoneNumber {
    PhoneNumberId?: string | redacted.Redacted<string>;
    E164PhoneNumber?: string | redacted.Redacted<string>;
    PhoneNumberArn?: string;
    Country?: string;
    Type?: PhoneNumberType;
    ProductType?: PhoneNumberProductType;
    Status?: PhoneNumberStatus;
    Capabilities?: PhoneNumberCapabilities;
    Associations?: PhoneNumberAssociation[];
    CallingName?: string | redacted.Redacted<string>;
    CallingNameStatus?: CallingNameStatus;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    DeletionTimestamp?: Date;
    OrderId?: string;
    Name?: string | redacted.Redacted<string>;
}
export interface GetPhoneNumberResponse {
    PhoneNumber?: PhoneNumber;
}
export interface GetPhoneNumberOrderRequest {
    PhoneNumberOrderId: string;
}
export interface GetPhoneNumberOrderResponse {
    PhoneNumberOrder?: PhoneNumberOrder;
}
export interface GetPhoneNumberSettingsRequest {
}
export interface GetPhoneNumberSettingsResponse {
    CallingName?: string | redacted.Redacted<string>;
    CallingNameUpdatedTimestamp?: Date;
}
export interface GetProxySessionRequest {
    VoiceConnectorId: string;
    ProxySessionId: string;
}
export interface GetProxySessionResponse {
    ProxySession?: ProxySession;
}
export interface GetSipMediaApplicationRequest {
    SipMediaApplicationId: string;
}
export interface GetSipMediaApplicationResponse {
    SipMediaApplication?: SipMediaApplication;
}
export interface GetSipMediaApplicationAlexaSkillConfigurationRequest {
    SipMediaApplicationId: string;
}
export type AlexaSkillStatus = "ACTIVE" | "INACTIVE" | (string & {});
export type AlexaSkillId = string | redacted.Redacted<string>;
export type AlexaSkillIdList = (string | redacted.Redacted<string>)[];
export interface SipMediaApplicationAlexaSkillConfiguration {
    AlexaSkillStatus: AlexaSkillStatus;
    AlexaSkillIds: (string | redacted.Redacted<string>)[];
}
export interface GetSipMediaApplicationAlexaSkillConfigurationResponse {
    SipMediaApplicationAlexaSkillConfiguration?: SipMediaApplicationAlexaSkillConfiguration;
}
export interface GetSipMediaApplicationLoggingConfigurationRequest {
    SipMediaApplicationId: string;
}
export interface SipMediaApplicationLoggingConfiguration {
    EnableSipMediaApplicationMessageLogs?: boolean;
}
export interface GetSipMediaApplicationLoggingConfigurationResponse {
    SipMediaApplicationLoggingConfiguration?: SipMediaApplicationLoggingConfiguration;
}
export interface GetSipRuleRequest {
    SipRuleId: string;
}
export interface GetSipRuleResponse {
    SipRule?: SipRule;
}
export interface GetSpeakerSearchTaskRequest {
    VoiceConnectorId: string;
    SpeakerSearchTaskId: string;
}
export interface CallDetails {
    VoiceConnectorId?: string;
    TransactionId?: string;
    IsCaller?: boolean;
}
export type ConfidenceScore = number;
export interface SpeakerSearchResult {
    ConfidenceScore?: number;
    VoiceProfileId?: string;
}
export type SpeakerSearchResultList = SpeakerSearchResult[];
export interface SpeakerSearchDetails {
    Results?: SpeakerSearchResult[];
    VoiceprintGenerationStatus?: string;
}
export interface SpeakerSearchTask {
    SpeakerSearchTaskId?: string;
    SpeakerSearchTaskStatus?: string;
    CallDetails?: CallDetails;
    SpeakerSearchDetails?: SpeakerSearchDetails;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    StartedTimestamp?: Date;
    StatusMessage?: string;
}
export interface GetSpeakerSearchTaskResponse {
    SpeakerSearchTask?: SpeakerSearchTask;
}
export interface GetVoiceConnectorRequest {
    VoiceConnectorId: string;
}
export interface GetVoiceConnectorResponse {
    VoiceConnector?: VoiceConnector;
}
export interface GetVoiceConnectorEmergencyCallingConfigurationRequest {
    VoiceConnectorId: string;
}
export interface DNISEmergencyCallingConfiguration {
    EmergencyPhoneNumber: string | redacted.Redacted<string>;
    TestPhoneNumber?: string | redacted.Redacted<string>;
    CallingCountry: string;
}
export type DNISEmergencyCallingConfigurationList = DNISEmergencyCallingConfiguration[];
export interface EmergencyCallingConfiguration {
    DNIS?: DNISEmergencyCallingConfiguration[];
}
export interface GetVoiceConnectorEmergencyCallingConfigurationResponse {
    EmergencyCallingConfiguration?: EmergencyCallingConfiguration;
}
export interface GetVoiceConnectorExternalSystemsConfigurationRequest {
    VoiceConnectorId: string;
}
export type SessionBorderControllerType = "RIBBON_SBC" | "ORACLE_ACME_PACKET_SBC" | "AVAYA_SBCE" | "CISCO_UNIFIED_BORDER_ELEMENT" | "AUDIOCODES_MEDIANT_SBC" | (string & {});
export type SessionBorderControllerTypeList = SessionBorderControllerType[];
export type ContactCenterSystemType = "GENESYS_ENGAGE_ON_PREMISES" | "AVAYA_AURA_CALL_CENTER_ELITE" | "AVAYA_AURA_CONTACT_CENTER" | "CISCO_UNIFIED_CONTACT_CENTER_ENTERPRISE" | (string & {});
export type ContactCenterSystemTypeList = ContactCenterSystemType[];
export interface ExternalSystemsConfiguration {
    SessionBorderControllerTypes?: SessionBorderControllerType[];
    ContactCenterSystemTypes?: ContactCenterSystemType[];
}
export interface GetVoiceConnectorExternalSystemsConfigurationResponse {
    ExternalSystemsConfiguration?: ExternalSystemsConfiguration;
}
export interface GetVoiceConnectorGroupRequest {
    VoiceConnectorGroupId: string;
}
export interface GetVoiceConnectorGroupResponse {
    VoiceConnectorGroup?: VoiceConnectorGroup;
}
export interface GetVoiceConnectorLoggingConfigurationRequest {
    VoiceConnectorId: string;
}
export interface LoggingConfiguration {
    EnableSIPLogs?: boolean;
    EnableMediaMetricLogs?: boolean;
}
export interface GetVoiceConnectorLoggingConfigurationResponse {
    LoggingConfiguration?: LoggingConfiguration;
}
export interface GetVoiceConnectorOriginationRequest {
    VoiceConnectorId: string;
}
export type Port = number;
export type OriginationRouteProtocol = "TCP" | "UDP" | (string & {});
export type OriginationRoutePriority = number;
export type OriginationRouteWeight = number;
export interface OriginationRoute {
    Host?: string;
    Port?: number;
    Protocol?: OriginationRouteProtocol;
    Priority?: number;
    Weight?: number;
}
export type OriginationRouteList = OriginationRoute[];
export interface Origination {
    Routes?: OriginationRoute[];
    Disabled?: boolean;
}
export interface GetVoiceConnectorOriginationResponse {
    Origination?: Origination;
}
export interface GetVoiceConnectorProxyRequest {
    VoiceConnectorId: string;
}
export type StringList = string[];
export interface Proxy {
    DefaultSessionExpiryMinutes?: number;
    Disabled?: boolean;
    FallBackPhoneNumber?: string | redacted.Redacted<string>;
    PhoneNumberCountries?: string[];
}
export interface GetVoiceConnectorProxyResponse {
    Proxy?: Proxy;
}
export interface GetVoiceConnectorStreamingConfigurationRequest {
    VoiceConnectorId: string;
}
export type DataRetentionInHours = number;
export type NotificationTarget = "EventBridge" | "SNS" | "SQS" | (string & {});
export interface StreamingNotificationTarget {
    NotificationTarget?: NotificationTarget;
}
export type StreamingNotificationTargetList = StreamingNotificationTarget[];
export interface MediaInsightsConfiguration {
    Disabled?: boolean;
    ConfigurationArn?: string | redacted.Redacted<string>;
}
export interface StreamingConfiguration {
    DataRetentionInHours: number;
    Disabled: boolean;
    StreamingNotificationTargets?: StreamingNotificationTarget[];
    MediaInsightsConfiguration?: MediaInsightsConfiguration;
}
export interface GetVoiceConnectorStreamingConfigurationResponse {
    StreamingConfiguration?: StreamingConfiguration;
}
export interface GetVoiceConnectorTerminationRequest {
    VoiceConnectorId: string;
}
export type CpsLimit = number;
export type CallingRegion = string;
export type CallingRegionList = string[];
export interface Termination {
    CpsLimit?: number;
    DefaultPhoneNumber?: string | redacted.Redacted<string>;
    CallingRegions?: string[];
    CidrAllowedList?: string[];
    Disabled?: boolean;
}
export interface GetVoiceConnectorTerminationResponse {
    Termination?: Termination;
}
export interface GetVoiceConnectorTerminationHealthRequest {
    VoiceConnectorId: string;
}
export interface TerminationHealth {
    Timestamp?: Date;
    Source?: string;
}
export interface GetVoiceConnectorTerminationHealthResponse {
    TerminationHealth?: TerminationHealth;
}
export interface GetVoiceProfileRequest {
    VoiceProfileId: string;
}
export interface GetVoiceProfileResponse {
    VoiceProfile?: VoiceProfile;
}
export interface GetVoiceProfileDomainRequest {
    VoiceProfileDomainId: string;
}
export interface GetVoiceProfileDomainResponse {
    VoiceProfileDomain?: VoiceProfileDomain;
}
export interface GetVoiceToneAnalysisTaskRequest {
    VoiceConnectorId: string;
    VoiceToneAnalysisTaskId: string;
    IsCaller: boolean;
}
export interface VoiceToneAnalysisTask {
    VoiceToneAnalysisTaskId?: string;
    VoiceToneAnalysisTaskStatus?: string;
    CallDetails?: CallDetails;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    StartedTimestamp?: Date;
    StatusMessage?: string;
}
export interface GetVoiceToneAnalysisTaskResponse {
    VoiceToneAnalysisTask?: VoiceToneAnalysisTask;
}
export interface ListAvailableVoiceConnectorRegionsRequest {
}
export type VoiceConnectorAwsRegionList = VoiceConnectorAwsRegion[];
export interface ListAvailableVoiceConnectorRegionsResponse {
    VoiceConnectorRegions?: VoiceConnectorAwsRegion[];
}
export type NextTokenString = string;
export type ResultMax = number;
export interface ListPhoneNumberOrdersRequest {
    NextToken?: string;
    MaxResults?: number;
}
export type PhoneNumberOrderList = PhoneNumberOrder[];
export interface ListPhoneNumberOrdersResponse {
    PhoneNumberOrders?: PhoneNumberOrder[];
    NextToken?: string;
}
export interface ListPhoneNumbersRequest {
    Status?: string;
    ProductType?: PhoneNumberProductType;
    FilterName?: PhoneNumberAssociationName;
    FilterValue?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type PhoneNumberList = PhoneNumber[];
export interface ListPhoneNumbersResponse {
    PhoneNumbers?: PhoneNumber[];
    NextToken?: string;
}
export interface ListProxySessionsRequest {
    VoiceConnectorId: string;
    Status?: ProxySessionStatus;
    NextToken?: string;
    MaxResults?: number;
}
export type ProxySessions = ProxySession[];
export interface ListProxySessionsResponse {
    ProxySessions?: ProxySession[];
    NextToken?: string;
}
export interface ListSipMediaApplicationsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export type SipMediaApplicationList = SipMediaApplication[];
export interface ListSipMediaApplicationsResponse {
    SipMediaApplications?: SipMediaApplication[];
    NextToken?: string;
}
export interface ListSipRulesRequest {
    SipMediaApplicationId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type SipRuleList = SipRule[];
export interface ListSipRulesResponse {
    SipRules?: SipRule[];
    NextToken?: string;
}
export interface ListSupportedPhoneNumberCountriesRequest {
    ProductType: PhoneNumberProductType;
}
export type PhoneNumberTypeList = PhoneNumberType[];
export interface PhoneNumberCountry {
    CountryCode?: string;
    SupportedPhoneNumberTypes?: PhoneNumberType[];
}
export type PhoneNumberCountriesList = PhoneNumberCountry[];
export interface ListSupportedPhoneNumberCountriesResponse {
    PhoneNumberCountries?: PhoneNumberCountry[];
}
export interface ListTagsForResourceRequest {
    ResourceARN: string | redacted.Redacted<string>;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export interface ListVoiceConnectorGroupsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export type VoiceConnectorGroupList = VoiceConnectorGroup[];
export interface ListVoiceConnectorGroupsResponse {
    VoiceConnectorGroups?: VoiceConnectorGroup[];
    NextToken?: string;
}
export interface ListVoiceConnectorsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export type VoiceConnectorList = VoiceConnector[];
export interface ListVoiceConnectorsResponse {
    VoiceConnectors?: VoiceConnector[];
    NextToken?: string;
}
export interface ListVoiceConnectorTerminationCredentialsRequest {
    VoiceConnectorId: string;
}
export interface ListVoiceConnectorTerminationCredentialsResponse {
    Usernames?: (string | redacted.Redacted<string>)[];
}
export interface ListVoiceProfileDomainsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface VoiceProfileDomainSummary {
    VoiceProfileDomainId?: string;
    VoiceProfileDomainArn?: string | redacted.Redacted<string>;
    Name?: string;
    Description?: string;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
}
export type VoiceProfileDomainSummaryList = VoiceProfileDomainSummary[];
export interface ListVoiceProfileDomainsResponse {
    VoiceProfileDomains?: VoiceProfileDomainSummary[];
    NextToken?: string;
}
export interface ListVoiceProfilesRequest {
    VoiceProfileDomainId: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface VoiceProfileSummary {
    VoiceProfileId?: string;
    VoiceProfileArn?: string | redacted.Redacted<string>;
    VoiceProfileDomainId?: string;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    ExpirationTimestamp?: Date;
}
export type VoiceProfileSummaryList = VoiceProfileSummary[];
export interface ListVoiceProfilesResponse {
    VoiceProfiles?: VoiceProfileSummary[];
    NextToken?: string;
}
export interface PutSipMediaApplicationAlexaSkillConfigurationRequest {
    SipMediaApplicationId: string;
    SipMediaApplicationAlexaSkillConfiguration?: SipMediaApplicationAlexaSkillConfiguration;
}
export interface PutSipMediaApplicationAlexaSkillConfigurationResponse {
    SipMediaApplicationAlexaSkillConfiguration?: SipMediaApplicationAlexaSkillConfiguration;
}
export interface PutSipMediaApplicationLoggingConfigurationRequest {
    SipMediaApplicationId: string;
    SipMediaApplicationLoggingConfiguration?: SipMediaApplicationLoggingConfiguration;
}
export interface PutSipMediaApplicationLoggingConfigurationResponse {
    SipMediaApplicationLoggingConfiguration?: SipMediaApplicationLoggingConfiguration;
}
export interface PutVoiceConnectorEmergencyCallingConfigurationRequest {
    VoiceConnectorId: string;
    EmergencyCallingConfiguration: EmergencyCallingConfiguration;
}
export interface PutVoiceConnectorEmergencyCallingConfigurationResponse {
    EmergencyCallingConfiguration?: EmergencyCallingConfiguration;
}
export interface PutVoiceConnectorExternalSystemsConfigurationRequest {
    VoiceConnectorId: string;
    SessionBorderControllerTypes?: SessionBorderControllerType[];
    ContactCenterSystemTypes?: ContactCenterSystemType[];
}
export interface PutVoiceConnectorExternalSystemsConfigurationResponse {
    ExternalSystemsConfiguration?: ExternalSystemsConfiguration;
}
export interface PutVoiceConnectorLoggingConfigurationRequest {
    VoiceConnectorId: string;
    LoggingConfiguration: LoggingConfiguration;
}
export interface PutVoiceConnectorLoggingConfigurationResponse {
    LoggingConfiguration?: LoggingConfiguration;
}
export interface PutVoiceConnectorOriginationRequest {
    VoiceConnectorId: string;
    Origination: Origination;
}
export interface PutVoiceConnectorOriginationResponse {
    Origination?: Origination;
}
export type CountryList = string[];
export interface PutVoiceConnectorProxyRequest {
    VoiceConnectorId: string;
    DefaultSessionExpiryMinutes: number;
    PhoneNumberPoolCountries: string[];
    FallBackPhoneNumber?: string | redacted.Redacted<string>;
    Disabled?: boolean;
}
export interface PutVoiceConnectorProxyResponse {
    Proxy?: Proxy;
}
export interface PutVoiceConnectorStreamingConfigurationRequest {
    VoiceConnectorId: string;
    StreamingConfiguration: StreamingConfiguration;
}
export interface PutVoiceConnectorStreamingConfigurationResponse {
    StreamingConfiguration?: StreamingConfiguration;
}
export interface PutVoiceConnectorTerminationRequest {
    VoiceConnectorId: string;
    Termination: Termination;
}
export interface PutVoiceConnectorTerminationResponse {
    Termination?: Termination;
}
export interface Credential {
    Username?: string | redacted.Redacted<string>;
    Password?: string | redacted.Redacted<string>;
}
export type CredentialList = Credential[];
export interface PutVoiceConnectorTerminationCredentialsRequest {
    VoiceConnectorId: string;
    Credentials?: Credential[];
}
export interface PutVoiceConnectorTerminationCredentialsResponse {
}
export interface RestorePhoneNumberRequest {
    PhoneNumberId: string | redacted.Redacted<string>;
}
export interface RestorePhoneNumberResponse {
    PhoneNumber?: PhoneNumber;
}
export type TollFreePrefix = string;
export type PhoneNumberMaxResults = number;
export interface SearchAvailablePhoneNumbersRequest {
    AreaCode?: string;
    City?: string;
    Country?: string;
    State?: string;
    TollFreePrefix?: string;
    PhoneNumberType?: PhoneNumberType;
    MaxResults?: number;
    NextToken?: string;
}
export interface SearchAvailablePhoneNumbersResponse {
    E164PhoneNumbers?: (string | redacted.Redacted<string>)[];
    NextToken?: string;
}
export type CallLegType = "Caller" | "Callee" | (string & {});
export interface StartSpeakerSearchTaskRequest {
    VoiceConnectorId: string;
    TransactionId: string;
    VoiceProfileDomainId: string;
    ClientRequestToken?: string;
    CallLeg?: CallLegType;
}
export interface StartSpeakerSearchTaskResponse {
    SpeakerSearchTask?: SpeakerSearchTask;
}
export type LanguageCode = "en-US" | (string & {});
export interface StartVoiceToneAnalysisTaskRequest {
    VoiceConnectorId: string;
    TransactionId: string;
    LanguageCode: LanguageCode;
    ClientRequestToken?: string;
}
export interface StartVoiceToneAnalysisTaskResponse {
    VoiceToneAnalysisTask?: VoiceToneAnalysisTask;
}
export interface StopSpeakerSearchTaskRequest {
    VoiceConnectorId: string;
    SpeakerSearchTaskId: string;
}
export interface StopSpeakerSearchTaskResponse {
}
export interface StopVoiceToneAnalysisTaskRequest {
    VoiceConnectorId: string;
    VoiceToneAnalysisTaskId: string;
}
export interface StopVoiceToneAnalysisTaskResponse {
}
export interface TagResourceRequest {
    ResourceARN: string | redacted.Redacted<string>;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = (string | redacted.Redacted<string>)[];
export interface UntagResourceRequest {
    ResourceARN: string | redacted.Redacted<string>;
    TagKeys: (string | redacted.Redacted<string>)[];
}
export interface UntagResourceResponse {
}
export interface UpdateGlobalSettingsRequest {
    VoiceConnector: VoiceConnectorSettings;
}
export interface UpdateGlobalSettingsResponse {
}
export interface UpdatePhoneNumberRequest {
    PhoneNumberId: string | redacted.Redacted<string>;
    ProductType?: PhoneNumberProductType;
    CallingName?: string | redacted.Redacted<string>;
    Name?: string | redacted.Redacted<string>;
}
export interface UpdatePhoneNumberResponse {
    PhoneNumber?: PhoneNumber;
}
export interface UpdatePhoneNumberSettingsRequest {
    CallingName: string | redacted.Redacted<string>;
}
export interface UpdatePhoneNumberSettingsResponse {
}
export interface UpdateProxySessionRequest {
    VoiceConnectorId: string;
    ProxySessionId: string;
    Capabilities: Capability[];
    ExpiryMinutes?: number;
}
export interface UpdateProxySessionResponse {
    ProxySession?: ProxySession;
}
export interface UpdateSipMediaApplicationRequest {
    SipMediaApplicationId: string;
    Name?: string;
    Endpoints?: SipMediaApplicationEndpoint[];
}
export interface UpdateSipMediaApplicationResponse {
    SipMediaApplication?: SipMediaApplication;
}
export type SMAUpdateCallArgumentsMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export interface UpdateSipMediaApplicationCallRequest {
    SipMediaApplicationId: string;
    TransactionId: string;
    Arguments: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export interface UpdateSipMediaApplicationCallResponse {
    SipMediaApplicationCall?: SipMediaApplicationCall;
}
export interface UpdateSipRuleRequest {
    SipRuleId: string;
    Name: string;
    Disabled?: boolean;
    TargetApplications?: SipRuleTargetApplication[];
}
export interface UpdateSipRuleResponse {
    SipRule?: SipRule;
}
export interface UpdateVoiceConnectorRequest {
    VoiceConnectorId: string;
    Name: string;
    RequireEncryption: boolean;
}
export interface UpdateVoiceConnectorResponse {
    VoiceConnector?: VoiceConnector;
}
export interface UpdateVoiceConnectorGroupRequest {
    VoiceConnectorGroupId: string;
    Name: string;
    VoiceConnectorItems: VoiceConnectorItem[];
    CallDistributionType?: CallDistributionType;
}
export interface UpdateVoiceConnectorGroupResponse {
    VoiceConnectorGroup?: VoiceConnectorGroup;
}
export interface UpdateVoiceProfileRequest {
    VoiceProfileId: string;
    SpeakerSearchTaskId: string;
}
export interface UpdateVoiceProfileResponse {
    VoiceProfile?: VoiceProfile;
}
export interface UpdateVoiceProfileDomainRequest {
    VoiceProfileDomainId: string;
    Name?: string;
    Description?: string;
}
export interface UpdateVoiceProfileDomainResponse {
    VoiceProfileDomain?: VoiceProfileDomain;
}
export interface ValidateE911AddressRequest {
    AwsAccountId: string;
    StreetNumber: string | redacted.Redacted<string>;
    StreetInfo: string | redacted.Redacted<string>;
    City: string | redacted.Redacted<string>;
    State: string | redacted.Redacted<string>;
    Country: string | redacted.Redacted<string>;
    PostalCode: string | redacted.Redacted<string>;
}
export type ValidationResult = number;
export interface Address {
    streetName?: string | redacted.Redacted<string>;
    streetSuffix?: string | redacted.Redacted<string>;
    postDirectional?: string | redacted.Redacted<string>;
    preDirectional?: string | redacted.Redacted<string>;
    streetNumber?: string | redacted.Redacted<string>;
    city?: string | redacted.Redacted<string>;
    state?: string | redacted.Redacted<string>;
    postalCode?: string | redacted.Redacted<string>;
    postalCodePlus4?: string | redacted.Redacted<string>;
    country?: string | redacted.Redacted<string>;
}
export interface CandidateAddress {
    streetInfo?: string | redacted.Redacted<string>;
    streetNumber?: string | redacted.Redacted<string>;
    city?: string | redacted.Redacted<string>;
    state?: string | redacted.Redacted<string>;
    postalCode?: string | redacted.Redacted<string>;
    postalCodePlus4?: string | redacted.Redacted<string>;
    country?: string | redacted.Redacted<string>;
}
export type CandidateAddressList = CandidateAddress[];
export interface ValidateE911AddressResponse {
    ValidationResult?: number;
    AddressExternalId?: string;
    Address?: Address;
    CandidateAddressList?: CandidateAddress[];
}
export type AssociatePhoneNumbersWithVoiceConnectorError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Associates phone numbers with the specified Amazon Chime SDK Voice Connector.
 */
export declare const associatePhoneNumbersWithVoiceConnector: API.OperationMethod<AssociatePhoneNumbersWithVoiceConnectorRequest, AssociatePhoneNumbersWithVoiceConnectorResponse, AssociatePhoneNumbersWithVoiceConnectorError, Credentials | HttpClient.HttpClient>;
export type AssociatePhoneNumbersWithVoiceConnectorGroupError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Associates phone numbers with the specified Amazon Chime SDK Voice Connector group.
 */
export declare const associatePhoneNumbersWithVoiceConnectorGroup: API.OperationMethod<AssociatePhoneNumbersWithVoiceConnectorGroupRequest, AssociatePhoneNumbersWithVoiceConnectorGroupResponse, AssociatePhoneNumbersWithVoiceConnectorGroupError, Credentials | HttpClient.HttpClient>;
export type BatchDeletePhoneNumberError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Moves phone numbers into the
 * **Deletion queue**. Phone numbers must be disassociated from any users or Amazon Chime SDK Voice Connectors before they can be deleted.
 *
 * Phone numbers remain in the
 * **Deletion queue** for 7 days before they are deleted permanently.
 */
export declare const batchDeletePhoneNumber: API.OperationMethod<BatchDeletePhoneNumberRequest, BatchDeletePhoneNumberResponse, BatchDeletePhoneNumberError, Credentials | HttpClient.HttpClient>;
export type BatchUpdatePhoneNumberError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates phone number product types, calling names, or phone number names. You can update one attribute at a time for each
 * `UpdatePhoneNumberRequestItem`. For example, you can update the product type, the calling name, or phone name.
 *
 * You cannot have a duplicate `phoneNumberId` in a request.
 */
export declare const batchUpdatePhoneNumber: API.OperationMethod<BatchUpdatePhoneNumberRequest, BatchUpdatePhoneNumberResponse, BatchUpdatePhoneNumberError, Credentials | HttpClient.HttpClient>;
export type CreatePhoneNumberOrderError = AccessDeniedException | BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates an order for phone numbers to be provisioned. For numbers outside the U.S., you must use the Amazon Chime SDK SIP media application dial-in product type.
 */
export declare const createPhoneNumberOrder: API.OperationMethod<CreatePhoneNumberOrderRequest, CreatePhoneNumberOrderResponse, CreatePhoneNumberOrderError, Credentials | HttpClient.HttpClient>;
export type CreateProxySessionError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a proxy session for the specified Amazon Chime SDK Voice Connector for
 * the specified participant phone numbers.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const createProxySession: API.OperationMethod<CreateProxySessionRequest, CreateProxySessionResponse, CreateProxySessionError, Credentials | HttpClient.HttpClient>;
export type CreateSipMediaApplicationError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a SIP media application. For more information about SIP media applications, see Managing SIP media applications
 * and rules in the *Amazon Chime SDK Administrator Guide*.
 */
export declare const createSipMediaApplication: API.OperationMethod<CreateSipMediaApplicationRequest, CreateSipMediaApplicationResponse, CreateSipMediaApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateSipMediaApplicationCallError = AccessDeniedException | BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates an outbound call to a phone number from the phone number specified
 * in the request, and it invokes the endpoint of the specified
 * `sipMediaApplicationId`.
 */
export declare const createSipMediaApplicationCall: API.OperationMethod<CreateSipMediaApplicationCallRequest, CreateSipMediaApplicationCallResponse, CreateSipMediaApplicationCallError, Credentials | HttpClient.HttpClient>;
export type CreateSipRuleError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a SIP rule, which can be used to run a SIP media application as a target for a specific trigger type. For more information about SIP rules, see Managing SIP media applications
 * and rules in the *Amazon Chime SDK Administrator Guide*.
 */
export declare const createSipRule: API.OperationMethod<CreateSipRuleRequest, CreateSipRuleResponse, CreateSipRuleError, Credentials | HttpClient.HttpClient>;
export type CreateVoiceConnectorError = AccessDeniedException | BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates an Amazon Chime SDK Voice Connector. For more information about
 * Voice Connectors,
 * see Managing Amazon Chime SDK Voice Connector groups in the Amazon Chime SDK
 * Administrator Guide.
 */
export declare const createVoiceConnector: API.OperationMethod<CreateVoiceConnectorRequest, CreateVoiceConnectorResponse, CreateVoiceConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateVoiceConnectorGroupError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates an Amazon Chime SDK Voice Connector group under the administrator's
 * AWS account. You can associate Amazon Chime SDK Voice Connectors with the
 * Voice Connector group by including `VoiceConnectorItems` in the
 * request.
 *
 * You can include Voice Connectors from different AWS Regions in your group.
 * This creates a fault tolerant mechanism for fallback in case of availability events.
 */
export declare const createVoiceConnectorGroup: API.OperationMethod<CreateVoiceConnectorGroupRequest, CreateVoiceConnectorGroupResponse, CreateVoiceConnectorGroupError, Credentials | HttpClient.HttpClient>;
export type CreateVoiceProfileError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | GoneException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a voice profile, which consists of an enrolled user and their latest voice print.
 *
 * Before creating any voice profiles, you must provide all notices and obtain all consents from the speaker as required under applicable privacy and biometrics laws, and as required under the
 * AWS service terms for the Amazon Chime SDK.
 *
 * For more information about voice profiles and voice analytics, see Using Amazon Chime SDK Voice Analytics
 * in the *Amazon Chime SDK Developer Guide*.
 */
export declare const createVoiceProfile: API.OperationMethod<CreateVoiceProfileRequest, CreateVoiceProfileResponse, CreateVoiceProfileError, Credentials | HttpClient.HttpClient>;
export type CreateVoiceProfileDomainError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a voice profile domain, a collection of voice profiles, their voice prints, and encrypted enrollment audio.
 *
 * Before creating any voice profiles, you must provide all notices and obtain all consents from the speaker as required under applicable privacy and biometrics laws, and as required under the
 * AWS service terms for the Amazon Chime SDK.
 *
 * For more information about voice profile domains, see Using Amazon Chime SDK Voice Analytics
 * in the *Amazon Chime SDK Developer Guide*.
 */
export declare const createVoiceProfileDomain: API.OperationMethod<CreateVoiceProfileDomainRequest, CreateVoiceProfileDomainResponse, CreateVoiceProfileDomainError, Credentials | HttpClient.HttpClient>;
export type DeletePhoneNumberError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Moves the specified phone number into the
 * **Deletion queue**. A phone number must
 * be disassociated from any users or Amazon Chime SDK Voice Connectors before it can be
 * deleted.
 *
 * Deleted phone numbers remain in the
 * **Deletion queue** queue for 7 days before
 * they are deleted permanently.
 */
export declare const deletePhoneNumber: API.OperationMethod<DeletePhoneNumberRequest, DeletePhoneNumberResponse, DeletePhoneNumberError, Credentials | HttpClient.HttpClient>;
export type DeleteProxySessionError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the specified proxy session from the specified Amazon Chime SDK Voice
 * Connector.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const deleteProxySession: API.OperationMethod<DeleteProxySessionRequest, DeleteProxySessionResponse, DeleteProxySessionError, Credentials | HttpClient.HttpClient>;
export type DeleteSipMediaApplicationError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes a SIP media application.
 */
export declare const deleteSipMediaApplication: API.OperationMethod<DeleteSipMediaApplicationRequest, DeleteSipMediaApplicationResponse, DeleteSipMediaApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteSipRuleError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes a SIP rule.
 */
export declare const deleteSipRule: API.OperationMethod<DeleteSipRuleRequest, DeleteSipRuleResponse, DeleteSipRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes an Amazon Chime SDK Voice Connector. Any phone numbers associated
 * with the Amazon Chime SDK Voice Connector must be disassociated from it before it
 * can be deleted.
 */
export declare const deleteVoiceConnector: API.OperationMethod<DeleteVoiceConnectorRequest, DeleteVoiceConnectorResponse, DeleteVoiceConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorEmergencyCallingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the emergency calling details from the specified Amazon Chime SDK Voice
 * Connector.
 */
export declare const deleteVoiceConnectorEmergencyCallingConfiguration: API.OperationMethod<DeleteVoiceConnectorEmergencyCallingConfigurationRequest, DeleteVoiceConnectorEmergencyCallingConfigurationResponse, DeleteVoiceConnectorEmergencyCallingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorExternalSystemsConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the external systems configuration for a Voice Connector.
 */
export declare const deleteVoiceConnectorExternalSystemsConfiguration: API.OperationMethod<DeleteVoiceConnectorExternalSystemsConfigurationRequest, DeleteVoiceConnectorExternalSystemsConfigurationResponse, DeleteVoiceConnectorExternalSystemsConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorGroupError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes an Amazon Chime SDK Voice Connector group. Any `VoiceConnectorItems`
 * and phone numbers associated with the group must be removed before it can be
 * deleted.
 */
export declare const deleteVoiceConnectorGroup: API.OperationMethod<DeleteVoiceConnectorGroupRequest, DeleteVoiceConnectorGroupResponse, DeleteVoiceConnectorGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorOriginationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the origination settings for the specified Amazon Chime SDK Voice Connector.
 *
 * If emergency calling is configured for the Voice Connector, it must be
 * deleted prior to deleting the origination settings.
 */
export declare const deleteVoiceConnectorOrigination: API.OperationMethod<DeleteVoiceConnectorOriginationRequest, DeleteVoiceConnectorOriginationResponse, DeleteVoiceConnectorOriginationError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorProxyError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the proxy configuration from the specified Amazon Chime SDK Voice Connector.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const deleteVoiceConnectorProxy: API.OperationMethod<DeleteVoiceConnectorProxyRequest, DeleteVoiceConnectorProxyResponse, DeleteVoiceConnectorProxyError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorStreamingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes a Voice Connector's streaming configuration.
 */
export declare const deleteVoiceConnectorStreamingConfiguration: API.OperationMethod<DeleteVoiceConnectorStreamingConfigurationRequest, DeleteVoiceConnectorStreamingConfigurationResponse, DeleteVoiceConnectorStreamingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorTerminationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the termination settings for the specified Amazon Chime SDK Voice Connector.
 *
 * If emergency calling is configured for the Voice Connector, it must be
 * deleted prior to deleting the termination settings.
 */
export declare const deleteVoiceConnectorTermination: API.OperationMethod<DeleteVoiceConnectorTerminationRequest, DeleteVoiceConnectorTerminationResponse, DeleteVoiceConnectorTerminationError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorTerminationCredentialsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the specified SIP credentials used by your equipment to
 * authenticate during call termination.
 */
export declare const deleteVoiceConnectorTerminationCredentials: API.OperationMethod<DeleteVoiceConnectorTerminationCredentialsRequest, DeleteVoiceConnectorTerminationCredentialsResponse, DeleteVoiceConnectorTerminationCredentialsError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceProfileError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes a voice profile, including its voice print and enrollment data. WARNING: This action is not reversible.
 */
export declare const deleteVoiceProfile: API.OperationMethod<DeleteVoiceProfileRequest, DeleteVoiceProfileResponse, DeleteVoiceProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceProfileDomainError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes all voice profiles in the domain. WARNING: This action is not reversible.
 */
export declare const deleteVoiceProfileDomain: API.OperationMethod<DeleteVoiceProfileDomainRequest, DeleteVoiceProfileDomainResponse, DeleteVoiceProfileDomainError, Credentials | HttpClient.HttpClient>;
export type DisassociatePhoneNumbersFromVoiceConnectorError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Disassociates the specified phone numbers from the specified
 * Amazon Chime SDK Voice Connector.
 */
export declare const disassociatePhoneNumbersFromVoiceConnector: API.OperationMethod<DisassociatePhoneNumbersFromVoiceConnectorRequest, DisassociatePhoneNumbersFromVoiceConnectorResponse, DisassociatePhoneNumbersFromVoiceConnectorError, Credentials | HttpClient.HttpClient>;
export type DisassociatePhoneNumbersFromVoiceConnectorGroupError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Disassociates the specified phone numbers from the specified Amazon Chime SDK Voice
 * Connector group.
 */
export declare const disassociatePhoneNumbersFromVoiceConnectorGroup: API.OperationMethod<DisassociatePhoneNumbersFromVoiceConnectorGroupRequest, DisassociatePhoneNumbersFromVoiceConnectorGroupResponse, DisassociatePhoneNumbersFromVoiceConnectorGroupError, Credentials | HttpClient.HttpClient>;
export type GetGlobalSettingsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the global settings for the Amazon Chime SDK Voice Connectors in an AWS account.
 */
export declare const getGlobalSettings: API.OperationMethod<GetGlobalSettingsRequest, GetGlobalSettingsResponse, GetGlobalSettingsError, Credentials | HttpClient.HttpClient>;
export type GetPhoneNumberError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves details for the specified phone number ID, such as associations,
 * capabilities, and product type.
 */
export declare const getPhoneNumber: API.OperationMethod<GetPhoneNumberRequest, GetPhoneNumberResponse, GetPhoneNumberError, Credentials | HttpClient.HttpClient>;
export type GetPhoneNumberOrderError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves details for the specified phone number order, such as the order
 * creation timestamp, phone numbers in E.164 format, product type, and
 * order status.
 */
export declare const getPhoneNumberOrder: API.OperationMethod<GetPhoneNumberOrderRequest, GetPhoneNumberOrderResponse, GetPhoneNumberOrderError, Credentials | HttpClient.HttpClient>;
export type GetPhoneNumberSettingsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the phone number settings for the administrator's AWS account,
 * such as the default outbound calling name.
 */
export declare const getPhoneNumberSettings: API.OperationMethod<GetPhoneNumberSettingsRequest, GetPhoneNumberSettingsResponse, GetPhoneNumberSettingsError, Credentials | HttpClient.HttpClient>;
export type GetProxySessionError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the specified proxy session details for the specified Amazon Chime SDK Voice Connector.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const getProxySession: API.OperationMethod<GetProxySessionRequest, GetProxySessionResponse, GetProxySessionError, Credentials | HttpClient.HttpClient>;
export type GetSipMediaApplicationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the information for a SIP media application, including name,
 * AWS Region, and endpoints.
 */
export declare const getSipMediaApplication: API.OperationMethod<GetSipMediaApplicationRequest, GetSipMediaApplicationResponse, GetSipMediaApplicationError, Credentials | HttpClient.HttpClient>;
export type GetSipMediaApplicationAlexaSkillConfigurationError = BadRequestException | ForbiddenException | GoneException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Gets the Alexa Skill configuration for the SIP media application.
 *
 * Due to changes made by the Amazon Alexa service, this API is no longer available for use. For more information, refer to
 * the Alexa Smart Properties page.
 */
export declare const getSipMediaApplicationAlexaSkillConfiguration: API.OperationMethod<GetSipMediaApplicationAlexaSkillConfigurationRequest, GetSipMediaApplicationAlexaSkillConfigurationResponse, GetSipMediaApplicationAlexaSkillConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetSipMediaApplicationLoggingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the logging configuration for the specified SIP media application.
 */
export declare const getSipMediaApplicationLoggingConfiguration: API.OperationMethod<GetSipMediaApplicationLoggingConfigurationRequest, GetSipMediaApplicationLoggingConfigurationResponse, GetSipMediaApplicationLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetSipRuleError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the details of a SIP rule, such as the rule ID, name, triggers, and
 * target endpoints.
 */
export declare const getSipRule: API.OperationMethod<GetSipRuleRequest, GetSipRuleResponse, GetSipRuleError, Credentials | HttpClient.HttpClient>;
export type GetSpeakerSearchTaskError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the details of the specified speaker search task.
 */
export declare const getSpeakerSearchTask: API.OperationMethod<GetSpeakerSearchTaskRequest, GetSpeakerSearchTaskResponse, GetSpeakerSearchTaskError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves details for the specified Amazon Chime SDK Voice Connector, such as
 * timestamps,name, outbound host, and encryption requirements.
 */
export declare const getVoiceConnector: API.OperationMethod<GetVoiceConnectorRequest, GetVoiceConnectorResponse, GetVoiceConnectorError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorEmergencyCallingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the emergency calling configuration details for the specified Voice Connector.
 */
export declare const getVoiceConnectorEmergencyCallingConfiguration: API.OperationMethod<GetVoiceConnectorEmergencyCallingConfigurationRequest, GetVoiceConnectorEmergencyCallingConfigurationResponse, GetVoiceConnectorEmergencyCallingConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorExternalSystemsConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Gets information about an external systems configuration for a Voice
 * Connector.
 */
export declare const getVoiceConnectorExternalSystemsConfiguration: API.OperationMethod<GetVoiceConnectorExternalSystemsConfigurationRequest, GetVoiceConnectorExternalSystemsConfigurationResponse, GetVoiceConnectorExternalSystemsConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorGroupError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves details for the specified Amazon Chime SDK Voice Connector group,
 * such as timestamps,name, and associated `VoiceConnectorItems`.
 */
export declare const getVoiceConnectorGroup: API.OperationMethod<GetVoiceConnectorGroupRequest, GetVoiceConnectorGroupResponse, GetVoiceConnectorGroupError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorLoggingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the logging configuration settings for the specified Voice Connector.
 * Shows whether SIP message logs are enabled for sending to Amazon CloudWatch Logs.
 */
export declare const getVoiceConnectorLoggingConfiguration: API.OperationMethod<GetVoiceConnectorLoggingConfigurationRequest, GetVoiceConnectorLoggingConfigurationResponse, GetVoiceConnectorLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorOriginationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the origination settings for the specified Voice Connector.
 */
export declare const getVoiceConnectorOrigination: API.OperationMethod<GetVoiceConnectorOriginationRequest, GetVoiceConnectorOriginationResponse, GetVoiceConnectorOriginationError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorProxyError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the proxy configuration details for the specified Amazon Chime SDK Voice
 * Connector.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const getVoiceConnectorProxy: API.OperationMethod<GetVoiceConnectorProxyRequest, GetVoiceConnectorProxyResponse, GetVoiceConnectorProxyError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorStreamingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the streaming configuration details for the specified Amazon Chime SDK
 * Voice Connector. Shows whether media streaming is enabled for sending to Amazon
 * Kinesis. It also shows the retention period, in hours, for the Amazon Kinesis data.
 */
export declare const getVoiceConnectorStreamingConfiguration: API.OperationMethod<GetVoiceConnectorStreamingConfigurationRequest, GetVoiceConnectorStreamingConfigurationResponse, GetVoiceConnectorStreamingConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorTerminationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the termination setting details for the specified Voice Connector.
 */
export declare const getVoiceConnectorTermination: API.OperationMethod<GetVoiceConnectorTerminationRequest, GetVoiceConnectorTerminationResponse, GetVoiceConnectorTerminationError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorTerminationHealthError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves information about the last time a `SIP OPTIONS` ping
 * was received from your SIP infrastructure for the specified Amazon Chime SDK Voice
 * Connector.
 */
export declare const getVoiceConnectorTerminationHealth: API.OperationMethod<GetVoiceConnectorTerminationHealthRequest, GetVoiceConnectorTerminationHealthResponse, GetVoiceConnectorTerminationHealthError, Credentials | HttpClient.HttpClient>;
export type GetVoiceProfileError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the details of the specified voice profile.
 */
export declare const getVoiceProfile: API.OperationMethod<GetVoiceProfileRequest, GetVoiceProfileResponse, GetVoiceProfileError, Credentials | HttpClient.HttpClient>;
export type GetVoiceProfileDomainError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the details of the specified voice profile domain.
 */
export declare const getVoiceProfileDomain: API.OperationMethod<GetVoiceProfileDomainRequest, GetVoiceProfileDomainResponse, GetVoiceProfileDomainError, Credentials | HttpClient.HttpClient>;
export type GetVoiceToneAnalysisTaskError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the details of a voice tone analysis task.
 */
export declare const getVoiceToneAnalysisTask: API.OperationMethod<GetVoiceToneAnalysisTaskRequest, GetVoiceToneAnalysisTaskResponse, GetVoiceToneAnalysisTaskError, Credentials | HttpClient.HttpClient>;
export type ListAvailableVoiceConnectorRegionsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the available AWS Regions in which you can create an Amazon Chime SDK Voice Connector.
 */
export declare const listAvailableVoiceConnectorRegions: API.OperationMethod<ListAvailableVoiceConnectorRegionsRequest, ListAvailableVoiceConnectorRegionsResponse, ListAvailableVoiceConnectorRegionsError, Credentials | HttpClient.HttpClient>;
export type ListPhoneNumberOrdersError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the phone numbers for an administrator's Amazon Chime SDK account.
 */
export declare const listPhoneNumberOrders: API.PaginatedOperationMethod<ListPhoneNumberOrdersRequest, ListPhoneNumberOrdersResponse, ListPhoneNumberOrdersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPhoneNumbersError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the phone numbers for the specified Amazon Chime SDK account,
 * Amazon Chime SDK user, Amazon Chime SDK Voice Connector, or Amazon Chime SDK Voice
 * Connector group.
 */
export declare const listPhoneNumbers: API.PaginatedOperationMethod<ListPhoneNumbersRequest, ListPhoneNumbersResponse, ListPhoneNumbersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListProxySessionsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the proxy sessions for the specified Amazon Chime SDK Voice Connector.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const listProxySessions: API.PaginatedOperationMethod<ListProxySessionsRequest, ListProxySessionsResponse, ListProxySessionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSipMediaApplicationsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the SIP media applications under the administrator's AWS account.
 */
export declare const listSipMediaApplications: API.PaginatedOperationMethod<ListSipMediaApplicationsRequest, ListSipMediaApplicationsResponse, ListSipMediaApplicationsError, Credentials | HttpClient.HttpClient, SipMediaApplication>;
export type ListSipRulesError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the SIP rules under the administrator's AWS account.
 */
export declare const listSipRules: API.PaginatedOperationMethod<ListSipRulesRequest, ListSipRulesResponse, ListSipRulesError, Credentials | HttpClient.HttpClient, SipRule>;
export type ListSupportedPhoneNumberCountriesError = AccessDeniedException | BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the countries that you can order phone numbers from.
 */
export declare const listSupportedPhoneNumberCountries: API.OperationMethod<ListSupportedPhoneNumberCountriesRequest, ListSupportedPhoneNumberCountriesResponse, ListSupportedPhoneNumberCountriesError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | UnauthorizedClientException | CommonErrors;
/**
 * Returns a list of the tags in a given resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVoiceConnectorGroupsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the Amazon Chime SDK Voice Connector groups in the administrator's AWS
 * account.
 */
export declare const listVoiceConnectorGroups: API.PaginatedOperationMethod<ListVoiceConnectorGroupsRequest, ListVoiceConnectorGroupsResponse, ListVoiceConnectorGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListVoiceConnectorsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the Amazon Chime SDK Voice Connectors in the administrators
 * AWS account.
 */
export declare const listVoiceConnectors: API.PaginatedOperationMethod<ListVoiceConnectorsRequest, ListVoiceConnectorsResponse, ListVoiceConnectorsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListVoiceConnectorTerminationCredentialsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the SIP credentials for the specified Amazon Chime SDK Voice Connector.
 */
export declare const listVoiceConnectorTerminationCredentials: API.OperationMethod<ListVoiceConnectorTerminationCredentialsRequest, ListVoiceConnectorTerminationCredentialsResponse, ListVoiceConnectorTerminationCredentialsError, Credentials | HttpClient.HttpClient>;
export type ListVoiceProfileDomainsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the specified voice profile domains in the administrator's AWS account.
 */
export declare const listVoiceProfileDomains: API.PaginatedOperationMethod<ListVoiceProfileDomainsRequest, ListVoiceProfileDomainsResponse, ListVoiceProfileDomainsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListVoiceProfilesError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the voice profiles in a voice profile domain.
 */
export declare const listVoiceProfiles: API.PaginatedOperationMethod<ListVoiceProfilesRequest, ListVoiceProfilesResponse, ListVoiceProfilesError, Credentials | HttpClient.HttpClient, unknown>;
export type PutSipMediaApplicationAlexaSkillConfigurationError = BadRequestException | ForbiddenException | GoneException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the Alexa Skill configuration for the SIP media application.
 *
 * Due to changes made by the Amazon Alexa service, this API is no longer available for use. For more information, refer to
 * the Alexa Smart Properties page.
 */
export declare const putSipMediaApplicationAlexaSkillConfiguration: API.OperationMethod<PutSipMediaApplicationAlexaSkillConfigurationRequest, PutSipMediaApplicationAlexaSkillConfigurationResponse, PutSipMediaApplicationAlexaSkillConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutSipMediaApplicationLoggingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the logging configuration for the specified SIP media application.
 */
export declare const putSipMediaApplicationLoggingConfiguration: API.OperationMethod<PutSipMediaApplicationLoggingConfigurationRequest, PutSipMediaApplicationLoggingConfigurationResponse, PutSipMediaApplicationLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorEmergencyCallingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates a Voice Connector's emergency calling configuration.
 */
export declare const putVoiceConnectorEmergencyCallingConfiguration: API.OperationMethod<PutVoiceConnectorEmergencyCallingConfigurationRequest, PutVoiceConnectorEmergencyCallingConfigurationResponse, PutVoiceConnectorEmergencyCallingConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorExternalSystemsConfigurationError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Adds an external systems configuration to a Voice Connector.
 */
export declare const putVoiceConnectorExternalSystemsConfiguration: API.OperationMethod<PutVoiceConnectorExternalSystemsConfigurationRequest, PutVoiceConnectorExternalSystemsConfigurationResponse, PutVoiceConnectorExternalSystemsConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorLoggingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates a Voice Connector's logging configuration.
 */
export declare const putVoiceConnectorLoggingConfiguration: API.OperationMethod<PutVoiceConnectorLoggingConfigurationRequest, PutVoiceConnectorLoggingConfigurationResponse, PutVoiceConnectorLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorOriginationError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates a Voice Connector's origination settings.
 */
export declare const putVoiceConnectorOrigination: API.OperationMethod<PutVoiceConnectorOriginationRequest, PutVoiceConnectorOriginationResponse, PutVoiceConnectorOriginationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorProxyError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Puts the specified proxy configuration to the specified Amazon Chime SDK Voice Connector.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const putVoiceConnectorProxy: API.OperationMethod<PutVoiceConnectorProxyRequest, PutVoiceConnectorProxyResponse, PutVoiceConnectorProxyError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorStreamingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates a Voice Connector's streaming configuration settings.
 */
export declare const putVoiceConnectorStreamingConfiguration: API.OperationMethod<PutVoiceConnectorStreamingConfigurationRequest, PutVoiceConnectorStreamingConfigurationResponse, PutVoiceConnectorStreamingConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorTerminationError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates a Voice Connector's termination settings.
 */
export declare const putVoiceConnectorTermination: API.OperationMethod<PutVoiceConnectorTerminationRequest, PutVoiceConnectorTerminationResponse, PutVoiceConnectorTerminationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorTerminationCredentialsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates a Voice Connector's termination credentials.
 */
export declare const putVoiceConnectorTerminationCredentials: API.OperationMethod<PutVoiceConnectorTerminationCredentialsRequest, PutVoiceConnectorTerminationCredentialsResponse, PutVoiceConnectorTerminationCredentialsError, Credentials | HttpClient.HttpClient>;
export type RestorePhoneNumberError = BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Restores a deleted phone number.
 */
export declare const restorePhoneNumber: API.OperationMethod<RestorePhoneNumberRequest, RestorePhoneNumberResponse, RestorePhoneNumberError, Credentials | HttpClient.HttpClient>;
export type SearchAvailablePhoneNumbersError = AccessDeniedException | BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Searches the provisioned phone numbers in an organization.
 */
export declare const searchAvailablePhoneNumbers: API.PaginatedOperationMethod<SearchAvailablePhoneNumbersRequest, SearchAvailablePhoneNumbersResponse, SearchAvailablePhoneNumbersError, Credentials | HttpClient.HttpClient, unknown>;
export type StartSpeakerSearchTaskError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | GoneException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | UnprocessableEntityException | CommonErrors;
/**
 * Starts a speaker search task.
 *
 * Before starting any speaker search tasks, you must provide all notices and obtain all consents from the speaker as required under applicable privacy and biometrics laws, and as required under the
 * AWS service terms for the Amazon Chime SDK.
 */
export declare const startSpeakerSearchTask: API.OperationMethod<StartSpeakerSearchTaskRequest, StartSpeakerSearchTaskResponse, StartSpeakerSearchTaskError, Credentials | HttpClient.HttpClient>;
export type StartVoiceToneAnalysisTaskError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | GoneException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | UnprocessableEntityException | CommonErrors;
/**
 * Starts a voice tone analysis task. For more information about voice tone analysis, see
 * Using Amazon Chime SDK voice analytics
 * in the *Amazon Chime SDK Developer Guide*.
 *
 * Before starting any voice tone analysis tasks, you must provide all notices and obtain all consents from the speaker as required under applicable privacy and biometrics laws, and as required under the
 * AWS service terms for the Amazon Chime SDK.
 */
export declare const startVoiceToneAnalysisTask: API.OperationMethod<StartVoiceToneAnalysisTaskRequest, StartVoiceToneAnalysisTaskResponse, StartVoiceToneAnalysisTaskError, Credentials | HttpClient.HttpClient>;
export type StopSpeakerSearchTaskError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | UnprocessableEntityException | CommonErrors;
/**
 * Stops a speaker search task.
 */
export declare const stopSpeakerSearchTask: API.OperationMethod<StopSpeakerSearchTaskRequest, StopSpeakerSearchTaskResponse, StopSpeakerSearchTaskError, Credentials | HttpClient.HttpClient>;
export type StopVoiceToneAnalysisTaskError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | UnprocessableEntityException | CommonErrors;
/**
 * Stops a voice tone analysis task.
 */
export declare const stopVoiceToneAnalysisTask: API.OperationMethod<StopVoiceToneAnalysisTaskRequest, StopVoiceToneAnalysisTaskResponse, StopVoiceToneAnalysisTaskError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | UnauthorizedClientException | CommonErrors;
/**
 * Adds a tag to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | UnauthorizedClientException | CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateGlobalSettingsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates global settings for the Amazon Chime SDK Voice Connectors in an AWS account.
 */
export declare const updateGlobalSettings: API.OperationMethod<UpdateGlobalSettingsRequest, UpdateGlobalSettingsResponse, UpdateGlobalSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdatePhoneNumberError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates phone number details, such as product type, calling name, or phone number name for the
 * specified phone number ID. You can update one phone number detail at a time. For
 * example, you can update either the product type, calling name, or phone number name in one action.
 *
 * For numbers outside the U.S., you must use the Amazon Chime SDK SIP Media
 * Application Dial-In product type.
 *
 * Updates to outbound calling names can take 72 hours to complete. Pending
 * updates to outbound calling names must be complete before you can request another
 * update.
 */
export declare const updatePhoneNumber: API.OperationMethod<UpdatePhoneNumberRequest, UpdatePhoneNumberResponse, UpdatePhoneNumberError, Credentials | HttpClient.HttpClient>;
export type UpdatePhoneNumberSettingsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the phone number settings for the administrator's AWS account, such
 * as the default outbound calling name. You can update the default outbound calling
 * name once every seven days. Outbound calling names can take up to 72 hours to
 * update.
 */
export declare const updatePhoneNumberSettings: API.OperationMethod<UpdatePhoneNumberSettingsRequest, UpdatePhoneNumberSettingsResponse, UpdatePhoneNumberSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateProxySessionError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the specified proxy session details, such as voice or SMS capabilities.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const updateProxySession: API.OperationMethod<UpdateProxySessionRequest, UpdateProxySessionResponse, UpdateProxySessionError, Credentials | HttpClient.HttpClient>;
export type UpdateSipMediaApplicationError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the details of the specified SIP media application.
 */
export declare const updateSipMediaApplication: API.OperationMethod<UpdateSipMediaApplicationRequest, UpdateSipMediaApplicationResponse, UpdateSipMediaApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateSipMediaApplicationCallError = BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Invokes the AWS Lambda function associated with the SIP media application and
 * transaction ID in an update request. The Lambda function can then return a new set
 * of actions.
 */
export declare const updateSipMediaApplicationCall: API.OperationMethod<UpdateSipMediaApplicationCallRequest, UpdateSipMediaApplicationCallResponse, UpdateSipMediaApplicationCallError, Credentials | HttpClient.HttpClient>;
export type UpdateSipRuleError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the details of the specified SIP rule.
 */
export declare const updateSipRule: API.OperationMethod<UpdateSipRuleRequest, UpdateSipRuleResponse, UpdateSipRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateVoiceConnectorError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the details for the specified Amazon Chime SDK Voice Connector.
 */
export declare const updateVoiceConnector: API.OperationMethod<UpdateVoiceConnectorRequest, UpdateVoiceConnectorResponse, UpdateVoiceConnectorError, Credentials | HttpClient.HttpClient>;
export type UpdateVoiceConnectorGroupError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the settings for the specified Amazon Chime SDK Voice Connector group.
 */
export declare const updateVoiceConnectorGroup: API.OperationMethod<UpdateVoiceConnectorGroupRequest, UpdateVoiceConnectorGroupResponse, UpdateVoiceConnectorGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateVoiceProfileError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | GoneException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the specified voice profile's voice print and refreshes its expiration timestamp.
 *
 * As a condition of using this feature, you acknowledge that the collection, use, storage, and retention of
 * your caller's biometric identifiers and biometric information ("biometric data") in the form of a digital voiceprint
 * requires the caller's informed consent via a written release. Such consent is required under various state laws,
 * including biometrics laws in Illinois, Texas, Washington and other state privacy laws.
 *
 * You must provide a written release to each caller through a process that clearly reflects each caller's informed
 * consent before using Amazon Chime SDK Voice Insights service, as required under the terms of your agreement
 * with AWS governing your use of the service.
 */
export declare const updateVoiceProfile: API.OperationMethod<UpdateVoiceProfileRequest, UpdateVoiceProfileResponse, UpdateVoiceProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateVoiceProfileDomainError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the settings for the specified voice profile domain.
 */
export declare const updateVoiceProfileDomain: API.OperationMethod<UpdateVoiceProfileDomainRequest, UpdateVoiceProfileDomainResponse, UpdateVoiceProfileDomainError, Credentials | HttpClient.HttpClient>;
export type ValidateE911AddressError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Validates an address to be used for 911 calls made with Amazon Chime SDK Voice
 * Connectors. You can use validated addresses in a Presence Information Data Format
 * Location Object file that you include in SIP requests. That helps ensure that addresses
 * are routed to the appropriate Public Safety Answering Point.
 */
export declare const validateE911Address: API.OperationMethod<ValidateE911AddressRequest, ValidateE911AddressResponse, ValidateE911AddressError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=chime-sdk-voice.d.ts.map