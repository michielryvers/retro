import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnprocessableEntityException_base: S.TaggedErrorClass<"UnprocessableEntityException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableEntityException extends /*@__PURE__*/ UnprocessableEntityException_base {
}
export interface EgressAccessLogs {
    LogGroupName?: string;
}
export interface ConfigureLogsRequest {
    EgressAccessLogs?: EgressAccessLogs;
    Id: string;
}
export interface Authorization {
    CdnIdentifierSecret?: string;
    SecretsRoleArn?: string;
}
export type Tags = {
    [key: string]: string | undefined;
};
export interface ConfigureLogsResponse {
    Arn?: string;
    Authorization?: Authorization & {
        CdnIdentifierSecret: string;
        SecretsRoleArn: string;
    };
    CreatedAt?: string;
    DomainName?: string;
    EgressAccessLogs?: EgressAccessLogs;
    Id?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateAssetRequest {
    Id?: string;
    PackagingGroupId?: string;
    ResourceId?: string;
    SourceArn?: string;
    SourceRoleArn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface EgressEndpoint {
    PackagingConfigurationId?: string;
    Status?: string;
    Url?: string;
}
export type __listOfEgressEndpoint = EgressEndpoint[];
export interface CreateAssetResponse {
    Arn?: string;
    CreatedAt?: string;
    EgressEndpoints?: EgressEndpoint[];
    Id?: string;
    PackagingGroupId?: string;
    ResourceId?: string;
    SourceArn?: string;
    SourceRoleArn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type PresetSpeke20Audio = "PRESET-AUDIO-1" | "PRESET-AUDIO-2" | "PRESET-AUDIO-3" | "SHARED" | "UNENCRYPTED" | (string & {});
export type PresetSpeke20Video = "PRESET-VIDEO-1" | "PRESET-VIDEO-2" | "PRESET-VIDEO-3" | "PRESET-VIDEO-4" | "PRESET-VIDEO-5" | "PRESET-VIDEO-6" | "PRESET-VIDEO-7" | "PRESET-VIDEO-8" | "SHARED" | "UNENCRYPTED" | (string & {});
export interface EncryptionContractConfiguration {
    PresetSpeke20Audio?: PresetSpeke20Audio;
    PresetSpeke20Video?: PresetSpeke20Video;
}
export type __listOf__string = string[];
export interface SpekeKeyProvider {
    EncryptionContractConfiguration?: EncryptionContractConfiguration;
    RoleArn?: string;
    SystemIds?: string[];
    Url?: string;
}
export interface CmafEncryption {
    ConstantInitializationVector?: string;
    SpekeKeyProvider?: SpekeKeyProvider;
}
export type AdMarkers = "NONE" | "SCTE35_ENHANCED" | "PASSTHROUGH" | (string & {});
export type StreamOrder = "ORIGINAL" | "VIDEO_BITRATE_ASCENDING" | "VIDEO_BITRATE_DESCENDING" | (string & {});
export interface StreamSelection {
    MaxVideoBitsPerSecond?: number;
    MinVideoBitsPerSecond?: number;
    StreamOrder?: StreamOrder;
}
export interface HlsManifest {
    AdMarkers?: AdMarkers;
    IncludeIframeOnlyStream?: boolean;
    ManifestName?: string;
    ProgramDateTimeIntervalSeconds?: number;
    RepeatExtXKey?: boolean;
    StreamSelection?: StreamSelection;
}
export type __listOfHlsManifest = HlsManifest[];
export interface CmafPackage {
    Encryption?: CmafEncryption;
    HlsManifests?: HlsManifest[];
    IncludeEncoderConfigurationInSegments?: boolean;
    SegmentDurationSeconds?: number;
}
export type ManifestLayout = "FULL" | "COMPACT" | (string & {});
export type Profile = "NONE" | "HBBTV_1_5" | (string & {});
export type ScteMarkersSource = "SEGMENTS" | "MANIFEST" | (string & {});
export interface DashManifest {
    ManifestLayout?: ManifestLayout;
    ManifestName?: string;
    MinBufferTimeSeconds?: number;
    Profile?: Profile;
    ScteMarkersSource?: ScteMarkersSource;
    StreamSelection?: StreamSelection;
}
export type __listOfDashManifest = DashManifest[];
export interface DashEncryption {
    SpekeKeyProvider?: SpekeKeyProvider;
}
export type __PeriodTriggersElement = "ADS" | (string & {});
export type __listOf__PeriodTriggersElement = __PeriodTriggersElement[];
export type SegmentTemplateFormat = "NUMBER_WITH_TIMELINE" | "TIME_WITH_TIMELINE" | "NUMBER_WITH_DURATION" | (string & {});
export interface DashPackage {
    DashManifests?: DashManifest[];
    Encryption?: DashEncryption;
    IncludeEncoderConfigurationInSegments?: boolean;
    IncludeIframeOnlyStream?: boolean;
    PeriodTriggers?: __PeriodTriggersElement[];
    SegmentDurationSeconds?: number;
    SegmentTemplateFormat?: SegmentTemplateFormat;
}
export type EncryptionMethod = "AES_128" | "SAMPLE_AES" | (string & {});
export interface HlsEncryption {
    ConstantInitializationVector?: string;
    EncryptionMethod?: EncryptionMethod;
    SpekeKeyProvider?: SpekeKeyProvider;
}
export interface HlsPackage {
    Encryption?: HlsEncryption;
    HlsManifests?: HlsManifest[];
    IncludeDvbSubtitles?: boolean;
    SegmentDurationSeconds?: number;
    UseAudioRenditionGroup?: boolean;
}
export interface MssEncryption {
    SpekeKeyProvider?: SpekeKeyProvider;
}
export interface MssManifest {
    ManifestName?: string;
    StreamSelection?: StreamSelection;
}
export type __listOfMssManifest = MssManifest[];
export interface MssPackage {
    Encryption?: MssEncryption;
    MssManifests?: MssManifest[];
    SegmentDurationSeconds?: number;
}
export interface CreatePackagingConfigurationRequest {
    CmafPackage?: CmafPackage;
    DashPackage?: DashPackage;
    HlsPackage?: HlsPackage;
    Id?: string;
    MssPackage?: MssPackage;
    PackagingGroupId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreatePackagingConfigurationResponse {
    Arn?: string;
    CmafPackage?: CmafPackage & {
        HlsManifests: __listOfHlsManifest;
        Encryption: CmafEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    };
    CreatedAt?: string;
    DashPackage?: DashPackage & {
        DashManifests: __listOfDashManifest;
        Encryption: DashEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    };
    HlsPackage?: HlsPackage & {
        HlsManifests: __listOfHlsManifest;
        Encryption: HlsEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    };
    Id?: string;
    MssPackage?: MssPackage & {
        MssManifests: __listOfMssManifest;
        Encryption: MssEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    };
    PackagingGroupId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreatePackagingGroupRequest {
    Authorization?: Authorization;
    EgressAccessLogs?: EgressAccessLogs;
    Id?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreatePackagingGroupResponse {
    Arn?: string;
    Authorization?: Authorization & {
        CdnIdentifierSecret: string;
        SecretsRoleArn: string;
    };
    CreatedAt?: string;
    DomainName?: string;
    EgressAccessLogs?: EgressAccessLogs;
    Id?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DeleteAssetRequest {
    Id: string;
}
export interface DeleteAssetResponse {
}
export interface DeletePackagingConfigurationRequest {
    Id: string;
}
export interface DeletePackagingConfigurationResponse {
}
export interface DeletePackagingGroupRequest {
    Id: string;
}
export interface DeletePackagingGroupResponse {
}
export interface DescribeAssetRequest {
    Id: string;
}
export interface DescribeAssetResponse {
    Arn?: string;
    CreatedAt?: string;
    EgressEndpoints?: EgressEndpoint[];
    Id?: string;
    PackagingGroupId?: string;
    ResourceId?: string;
    SourceArn?: string;
    SourceRoleArn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribePackagingConfigurationRequest {
    Id: string;
}
export interface DescribePackagingConfigurationResponse {
    Arn?: string;
    CmafPackage?: CmafPackage & {
        HlsManifests: __listOfHlsManifest;
        Encryption: CmafEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    };
    CreatedAt?: string;
    DashPackage?: DashPackage & {
        DashManifests: __listOfDashManifest;
        Encryption: DashEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    };
    HlsPackage?: HlsPackage & {
        HlsManifests: __listOfHlsManifest;
        Encryption: HlsEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    };
    Id?: string;
    MssPackage?: MssPackage & {
        MssManifests: __listOfMssManifest;
        Encryption: MssEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    };
    PackagingGroupId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribePackagingGroupRequest {
    Id: string;
}
export interface DescribePackagingGroupResponse {
    ApproximateAssetCount?: number;
    Arn?: string;
    Authorization?: Authorization & {
        CdnIdentifierSecret: string;
        SecretsRoleArn: string;
    };
    CreatedAt?: string;
    DomainName?: string;
    EgressAccessLogs?: EgressAccessLogs;
    Id?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type MaxResults = number;
export interface ListAssetsRequest {
    MaxResults?: number;
    NextToken?: string;
    PackagingGroupId?: string;
}
export interface AssetShallow {
    Arn?: string;
    CreatedAt?: string;
    Id?: string;
    PackagingGroupId?: string;
    ResourceId?: string;
    SourceArn?: string;
    SourceRoleArn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfAssetShallow = AssetShallow[];
export interface ListAssetsResponse {
    Assets?: AssetShallow[];
    NextToken?: string;
}
export interface ListPackagingConfigurationsRequest {
    MaxResults?: number;
    NextToken?: string;
    PackagingGroupId?: string;
}
export interface PackagingConfiguration {
    Arn?: string;
    CmafPackage?: CmafPackage;
    CreatedAt?: string;
    DashPackage?: DashPackage;
    HlsPackage?: HlsPackage;
    Id?: string;
    MssPackage?: MssPackage;
    PackagingGroupId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfPackagingConfiguration = PackagingConfiguration[];
export interface ListPackagingConfigurationsResponse {
    NextToken?: string;
    PackagingConfigurations?: (PackagingConfiguration & {
        CmafPackage: CmafPackage & {
            HlsManifests: __listOfHlsManifest;
            Encryption: CmafEncryption & {
                SpekeKeyProvider: SpekeKeyProvider & {
                    RoleArn: string;
                    SystemIds: __listOf__string;
                    Url: string;
                    EncryptionContractConfiguration: EncryptionContractConfiguration & {
                        PresetSpeke20Audio: PresetSpeke20Audio;
                        PresetSpeke20Video: PresetSpeke20Video;
                    };
                };
            };
        };
        DashPackage: DashPackage & {
            DashManifests: __listOfDashManifest;
            Encryption: DashEncryption & {
                SpekeKeyProvider: SpekeKeyProvider & {
                    RoleArn: string;
                    SystemIds: __listOf__string;
                    Url: string;
                    EncryptionContractConfiguration: EncryptionContractConfiguration & {
                        PresetSpeke20Audio: PresetSpeke20Audio;
                        PresetSpeke20Video: PresetSpeke20Video;
                    };
                };
            };
        };
        HlsPackage: HlsPackage & {
            HlsManifests: __listOfHlsManifest;
            Encryption: HlsEncryption & {
                SpekeKeyProvider: SpekeKeyProvider & {
                    RoleArn: string;
                    SystemIds: __listOf__string;
                    Url: string;
                    EncryptionContractConfiguration: EncryptionContractConfiguration & {
                        PresetSpeke20Audio: PresetSpeke20Audio;
                        PresetSpeke20Video: PresetSpeke20Video;
                    };
                };
            };
        };
        MssPackage: MssPackage & {
            MssManifests: __listOfMssManifest;
            Encryption: MssEncryption & {
                SpekeKeyProvider: SpekeKeyProvider & {
                    RoleArn: string;
                    SystemIds: __listOf__string;
                    Url: string;
                    EncryptionContractConfiguration: EncryptionContractConfiguration & {
                        PresetSpeke20Audio: PresetSpeke20Audio;
                        PresetSpeke20Video: PresetSpeke20Video;
                    };
                };
            };
        };
    })[];
}
export interface ListPackagingGroupsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface PackagingGroup {
    ApproximateAssetCount?: number;
    Arn?: string;
    Authorization?: Authorization;
    CreatedAt?: string;
    DomainName?: string;
    EgressAccessLogs?: EgressAccessLogs;
    Id?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfPackagingGroup = PackagingGroup[];
export interface ListPackagingGroupsResponse {
    NextToken?: string;
    PackagingGroups?: (PackagingGroup & {
        Authorization: Authorization & {
            CdnIdentifierSecret: string;
            SecretsRoleArn: string;
        };
    })[];
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export type __mapOf__string = {
    [key: string]: string | undefined;
};
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[];
}
export interface UntagResourceResponse {
}
export interface UpdatePackagingGroupRequest {
    Authorization?: Authorization;
    Id: string;
}
export interface UpdatePackagingGroupResponse {
    ApproximateAssetCount?: number;
    Arn?: string;
    Authorization?: Authorization & {
        CdnIdentifierSecret: string;
        SecretsRoleArn: string;
    };
    CreatedAt?: string;
    DomainName?: string;
    EgressAccessLogs?: EgressAccessLogs;
    Id?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type ConfigureLogsError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Changes the packaging group's properities to configure log subscription
 */
export declare const configureLogs: API.OperationMethod<ConfigureLogsRequest, ConfigureLogsResponse, ConfigureLogsError, Credentials | HttpClient.HttpClient>;
export type CreateAssetError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Creates a new MediaPackage VOD Asset resource.
 */
export declare const createAsset: API.OperationMethod<CreateAssetRequest, CreateAssetResponse, CreateAssetError, Credentials | HttpClient.HttpClient>;
export type CreatePackagingConfigurationError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Creates a new MediaPackage VOD PackagingConfiguration resource.
 */
export declare const createPackagingConfiguration: API.OperationMethod<CreatePackagingConfigurationRequest, CreatePackagingConfigurationResponse, CreatePackagingConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreatePackagingGroupError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Creates a new MediaPackage VOD PackagingGroup resource.
 */
export declare const createPackagingGroup: API.OperationMethod<CreatePackagingGroupRequest, CreatePackagingGroupResponse, CreatePackagingGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Deletes an existing MediaPackage VOD Asset resource.
 */
export declare const deleteAsset: API.OperationMethod<DeleteAssetRequest, DeleteAssetResponse, DeleteAssetError, Credentials | HttpClient.HttpClient>;
export type DeletePackagingConfigurationError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Deletes a MediaPackage VOD PackagingConfiguration resource.
 */
export declare const deletePackagingConfiguration: API.OperationMethod<DeletePackagingConfigurationRequest, DeletePackagingConfigurationResponse, DeletePackagingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeletePackagingGroupError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Deletes a MediaPackage VOD PackagingGroup resource.
 */
export declare const deletePackagingGroup: API.OperationMethod<DeletePackagingGroupRequest, DeletePackagingGroupResponse, DeletePackagingGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeAssetError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Returns a description of a MediaPackage VOD Asset resource.
 */
export declare const describeAsset: API.OperationMethod<DescribeAssetRequest, DescribeAssetResponse, DescribeAssetError, Credentials | HttpClient.HttpClient>;
export type DescribePackagingConfigurationError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Returns a description of a MediaPackage VOD PackagingConfiguration resource.
 */
export declare const describePackagingConfiguration: API.OperationMethod<DescribePackagingConfigurationRequest, DescribePackagingConfigurationResponse, DescribePackagingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribePackagingGroupError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Returns a description of a MediaPackage VOD PackagingGroup resource.
 */
export declare const describePackagingGroup: API.OperationMethod<DescribePackagingGroupRequest, DescribePackagingGroupResponse, DescribePackagingGroupError, Credentials | HttpClient.HttpClient>;
export type ListAssetsError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Returns a collection of MediaPackage VOD Asset resources.
 */
export declare const listAssets: API.PaginatedOperationMethod<ListAssetsRequest, ListAssetsResponse, ListAssetsError, Credentials | HttpClient.HttpClient, AssetShallow>;
export type ListPackagingConfigurationsError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Returns a collection of MediaPackage VOD PackagingConfiguration resources.
 */
export declare const listPackagingConfigurations: API.PaginatedOperationMethod<ListPackagingConfigurationsRequest, ListPackagingConfigurationsResponse, ListPackagingConfigurationsError, Credentials | HttpClient.HttpClient, PackagingConfiguration>;
export type ListPackagingGroupsError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Returns a collection of MediaPackage VOD PackagingGroup resources.
 */
export declare const listPackagingGroups: API.PaginatedOperationMethod<ListPackagingGroupsRequest, ListPackagingGroupsResponse, ListPackagingGroupsError, Credentials | HttpClient.HttpClient, PackagingGroup>;
export type ListTagsForResourceError = CommonErrors;
/**
 * Returns a list of the tags assigned to the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = CommonErrors;
/**
 * Adds tags to the specified resource. You can specify one or more tags to add.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = CommonErrors;
/**
 * Removes tags from the specified resource. You can specify one or more tags to remove.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdatePackagingGroupError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Updates a specific packaging group. You can't change the id attribute or any other system-generated attributes.
 */
export declare const updatePackagingGroup: API.OperationMethod<UpdatePackagingGroupRequest, UpdatePackagingGroupResponse, UpdatePackagingGroupError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=mediapackage-vod.d.ts.map