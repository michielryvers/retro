import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DryRunException_base: S.TaggedErrorClass<"DryRunException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DryRunException extends /*@__PURE__*/ DryRunException_base {
}
declare const InsufficientCapacityException_base: S.TaggedErrorClass<"InsufficientCapacityException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InsufficientCapacityException extends /*@__PURE__*/ InsufficientCapacityException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidPaginationException_base: S.TaggedErrorClass<"InvalidPaginationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidPaginationException extends /*@__PURE__*/ InvalidPaginationException_base {
}
declare const Ipv6CidrBlockNotFoundException_base: S.TaggedErrorClass<"Ipv6CidrBlockNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class Ipv6CidrBlockNotFoundException extends /*@__PURE__*/ Ipv6CidrBlockNotFoundException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
    readonly resourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagList = Tag[];
export interface ConvertRecoveryPointToSnapshotRequest {
    recoveryPointId: string;
    snapshotName: string;
    retentionPeriod?: number;
    tags?: Tag[];
}
export type SnapshotStatus = string;
export type KmsKeyId = string;
export type AccountIdList = string[];
export interface Snapshot {
    namespaceName?: string;
    namespaceArn?: string;
    snapshotName?: string;
    snapshotCreateTime?: Date;
    adminUsername?: string;
    status?: string;
    kmsKeyId?: string;
    ownerAccount?: string;
    totalBackupSizeInMegaBytes?: number;
    actualIncrementalBackupSizeInMegaBytes?: number;
    backupProgressInMegaBytes?: number;
    currentBackupRateInMegaBytesPerSecond?: number;
    estimatedSecondsToCompletion?: number;
    elapsedTimeInSeconds?: number;
    snapshotRetentionPeriod?: number;
    snapshotRemainingDays?: number;
    snapshotRetentionStartTime?: Date;
    snapshotArn?: string;
    accountsWithRestoreAccess?: string[];
    accountsWithProvisionedRestoreAccess?: string[];
    adminPasswordSecretArn?: string;
    adminPasswordSecretKmsKeyId?: string;
}
export interface ConvertRecoveryPointToSnapshotResponse {
    snapshot?: Snapshot;
}
export type WorkgroupName = string;
export type CustomDomainName = string;
export type CustomDomainCertificateArnString = string;
export interface CreateCustomDomainAssociationRequest {
    workgroupName: string;
    customDomainName: string;
    customDomainCertificateArn: string;
}
export interface CreateCustomDomainAssociationResponse {
    customDomainName?: string;
    workgroupName?: string;
    customDomainCertificateArn?: string;
    customDomainCertificateExpiryTime?: Date;
}
export type SubnetId = string;
export type SubnetIdList = string[];
export type VpcSecurityGroupId = string;
export type VpcSecurityGroupIdList = string[];
export type OwnerAccount = string;
export interface CreateEndpointAccessRequest {
    endpointName: string;
    subnetIds: string[];
    workgroupName: string;
    vpcSecurityGroupIds?: string[];
    ownerAccount?: string;
}
export interface VpcSecurityGroupMembership {
    vpcSecurityGroupId?: string;
    status?: string;
}
export type VpcSecurityGroupMembershipList = VpcSecurityGroupMembership[];
export interface NetworkInterface {
    networkInterfaceId?: string;
    subnetId?: string;
    privateIpAddress?: string;
    availabilityZone?: string;
    ipv6Address?: string;
}
export type NetworkInterfaceList = NetworkInterface[];
export interface VpcEndpoint {
    vpcEndpointId?: string;
    vpcId?: string;
    networkInterfaces?: NetworkInterface[];
}
export interface EndpointAccess {
    endpointName?: string;
    endpointStatus?: string;
    workgroupName?: string;
    endpointCreateTime?: Date;
    port?: number;
    address?: string;
    subnetIds?: string[];
    vpcSecurityGroups?: VpcSecurityGroupMembership[];
    vpcEndpoint?: VpcEndpoint;
    endpointArn?: string;
}
export interface CreateEndpointAccessResponse {
    endpoint?: EndpointAccess;
}
export type NamespaceName = string;
export type DbUser = string | redacted.Redacted<string>;
export type DbPassword = string | redacted.Redacted<string>;
export type IamRoleArn = string;
export type IamRoleArnList = string[];
export type LogExport = string;
export type LogExportList = string[];
export type RedshiftIdcApplicationArn = string;
export interface CreateNamespaceRequest {
    namespaceName: string;
    adminUsername?: string | redacted.Redacted<string>;
    adminUserPassword?: string | redacted.Redacted<string>;
    dbName?: string;
    kmsKeyId?: string;
    defaultIamRoleArn?: string;
    iamRoles?: string[];
    logExports?: string[];
    tags?: Tag[];
    manageAdminPassword?: boolean;
    adminPasswordSecretKmsKeyId?: string;
    redshiftIdcApplicationArn?: string;
}
export type NamespaceStatus = string;
export type S3TableName = string;
export type S3TableNameList = string[];
export type S3TableGranularity = string;
export type S3TableLastIngestionTimeMap = {
    [key: string]: string | undefined;
};
export interface S3TablePublishStatus {
    s3Tables?: string[];
    s3TableNamespace?: string;
    s3TableGranularity?: string;
    enabledAll?: boolean;
    lastIngestionTimes?: {
        [key: string]: string | undefined;
    };
}
export interface Namespace {
    namespaceArn?: string;
    namespaceId?: string;
    namespaceName?: string;
    adminUsername?: string | redacted.Redacted<string>;
    dbName?: string;
    kmsKeyId?: string;
    defaultIamRoleArn?: string;
    iamRoles?: string[];
    logExports?: string[];
    status?: string;
    creationDate?: Date;
    adminPasswordSecretArn?: string;
    adminPasswordSecretKmsKeyId?: string;
    lakehouseRegistrationStatus?: string;
    catalogArn?: string;
    s3TablePublishStatus?: S3TablePublishStatus;
}
export interface CreateNamespaceResponse {
    namespace?: Namespace;
}
export type Capacity = number;
export type OfferingId = string;
export interface CreateReservationRequest {
    capacity: number;
    offeringId: string;
    clientToken?: string;
}
export type ReservationId = string;
export type ReservationArn = string;
export type Duration = number;
export type Charge = number;
export type CurrencyCode = string;
export type OfferingType = string;
export interface ReservationOffering {
    offeringId?: string;
    duration?: number;
    upfrontCharge?: number;
    hourlyCharge?: number;
    currencyCode?: string;
    offeringType?: string;
}
export type Status = string;
export interface Reservation {
    reservationId?: string;
    reservationArn?: string;
    startDate?: Date;
    endDate?: Date;
    capacity?: number;
    offering?: ReservationOffering;
    status?: string;
}
export interface CreateReservationResponse {
    reservation?: Reservation;
}
export type ScheduledActionName = string;
export type SnapshotNamePrefix = string;
export interface CreateSnapshotScheduleActionParameters {
    namespaceName: string;
    snapshotNamePrefix: string;
    retentionPeriod?: number;
    tags?: Tag[];
}
export type TargetAction = {
    createSnapshot: CreateSnapshotScheduleActionParameters;
};
export type Schedule = {
    at: Date;
    cron?: never;
} | {
    at?: never;
    cron: string;
};
export interface CreateScheduledActionRequest {
    scheduledActionName: string;
    targetAction: TargetAction;
    schedule: Schedule;
    roleArn: string;
    namespaceName: string;
    enabled?: boolean;
    scheduledActionDescription?: string;
    startTime?: Date;
    endTime?: Date;
}
export type NextInvocationsList = Date[];
export type State = string;
export interface ScheduledActionResponse {
    scheduledActionName?: string;
    schedule?: Schedule;
    scheduledActionDescription?: string;
    nextInvocations?: Date[];
    roleArn?: string;
    state?: string;
    startTime?: Date;
    endTime?: Date;
    targetAction?: TargetAction;
    namespaceName?: string;
    scheduledActionUuid?: string;
}
export interface CreateScheduledActionResponse {
    scheduledAction?: ScheduledActionResponse;
}
export interface CreateSnapshotRequest {
    namespaceName: string;
    snapshotName: string;
    retentionPeriod?: number;
    tags?: Tag[];
}
export interface CreateSnapshotResponse {
    snapshot?: Snapshot;
}
export interface CreateSnapshotCopyConfigurationRequest {
    namespaceName: string;
    destinationRegion: string;
    snapshotRetentionPeriod?: number;
    destinationKmsKeyId?: string;
}
export interface SnapshotCopyConfiguration {
    snapshotCopyConfigurationId?: string;
    snapshotCopyConfigurationArn?: string;
    namespaceName?: string;
    destinationRegion?: string;
    snapshotRetentionPeriod?: number;
    destinationKmsKeyId?: string;
}
export interface CreateSnapshotCopyConfigurationResponse {
    snapshotCopyConfiguration: SnapshotCopyConfiguration;
}
export type UsageLimitUsageType = string;
export type UsageLimitPeriod = string;
export type UsageLimitBreachAction = string;
export interface CreateUsageLimitRequest {
    resourceArn: string;
    usageType: string;
    amount: number;
    period?: string;
    breachAction?: string;
}
export interface UsageLimit {
    usageLimitId?: string;
    usageLimitArn?: string;
    resourceArn?: string;
    usageType?: string;
    amount?: number;
    period?: string;
    breachAction?: string;
}
export interface CreateUsageLimitResponse {
    usageLimit?: UsageLimit;
}
export type ParameterKey = string;
export type ParameterValue = string;
export interface ConfigParameter {
    parameterKey?: string;
    parameterValue?: string;
}
export type ConfigParameterList = ConfigParameter[];
export type SecurityGroupId = string;
export type SecurityGroupIdList = string[];
export type PerformanceTargetStatus = string;
export interface PerformanceTarget {
    status?: string;
    level?: number;
}
export type IpAddressType = string;
export type TrackName = string;
export interface CreateWorkgroupRequest {
    workgroupName: string;
    namespaceName: string;
    baseCapacity?: number;
    enhancedVpcRouting?: boolean;
    configParameters?: ConfigParameter[];
    securityGroupIds?: string[];
    subnetIds?: string[];
    publiclyAccessible?: boolean;
    tags?: Tag[];
    port?: number;
    maxCapacity?: number;
    pricePerformanceTarget?: PerformanceTarget;
    ipAddressType?: string;
    trackName?: string;
    extraComputeForAutomaticOptimization?: boolean;
}
export type WorkgroupStatus = string;
export type VpcEndpointList = VpcEndpoint[];
export interface Endpoint {
    address?: string;
    port?: number;
    vpcEndpoints?: VpcEndpoint[];
}
export type VpcIds = string[];
export interface Workgroup {
    workgroupId?: string;
    workgroupArn?: string;
    workgroupName?: string;
    namespaceName?: string;
    baseCapacity?: number;
    enhancedVpcRouting?: boolean;
    configParameters?: ConfigParameter[];
    securityGroupIds?: string[];
    subnetIds?: string[];
    status?: string;
    endpoint?: Endpoint;
    publiclyAccessible?: boolean;
    creationDate?: Date;
    port?: number;
    customDomainName?: string;
    customDomainCertificateArn?: string;
    customDomainCertificateExpiryTime?: Date;
    workgroupVersion?: string;
    patchVersion?: string;
    maxCapacity?: number;
    crossAccountVpcs?: string[];
    ipAddressType?: string;
    pricePerformanceTarget?: PerformanceTarget;
    trackName?: string;
    pendingTrackName?: string;
    extraComputeForAutomaticOptimization?: boolean;
}
export interface CreateWorkgroupResponse {
    workgroup?: Workgroup;
}
export interface DeleteCustomDomainAssociationRequest {
    workgroupName: string;
    customDomainName: string;
}
export interface DeleteCustomDomainAssociationResponse {
}
export interface DeleteEndpointAccessRequest {
    endpointName: string;
}
export interface DeleteEndpointAccessResponse {
    endpoint?: EndpointAccess;
}
export interface DeleteNamespaceRequest {
    namespaceName: string;
    finalSnapshotName?: string;
    finalSnapshotRetentionPeriod?: number;
}
export interface DeleteNamespaceResponse {
    namespace: Namespace;
}
export interface DeleteResourcePolicyRequest {
    resourceArn: string;
}
export interface DeleteResourcePolicyResponse {
}
export interface DeleteScheduledActionRequest {
    scheduledActionName: string;
}
export interface DeleteScheduledActionResponse {
    scheduledAction?: ScheduledActionResponse;
}
export interface DeleteSnapshotRequest {
    snapshotName: string;
}
export interface DeleteSnapshotResponse {
    snapshot?: Snapshot;
}
export interface DeleteSnapshotCopyConfigurationRequest {
    snapshotCopyConfigurationId: string;
}
export interface DeleteSnapshotCopyConfigurationResponse {
    snapshotCopyConfiguration: SnapshotCopyConfiguration;
}
export interface DeleteUsageLimitRequest {
    usageLimitId: string;
}
export interface DeleteUsageLimitResponse {
    usageLimit?: UsageLimit;
}
export interface DeleteWorkgroupRequest {
    workgroupName: string;
}
export interface DeleteWorkgroupResponse {
    workgroup: Workgroup;
}
export type DbName = string;
export interface GetCredentialsRequest {
    dbName?: string;
    durationSeconds?: number;
    workgroupName?: string;
    customDomainName?: string;
}
export interface GetCredentialsResponse {
    dbUser?: string | redacted.Redacted<string>;
    dbPassword?: string | redacted.Redacted<string>;
    expiration?: Date;
    nextRefreshTime?: Date;
}
export interface GetCustomDomainAssociationRequest {
    customDomainName: string;
    workgroupName: string;
}
export interface GetCustomDomainAssociationResponse {
    customDomainName?: string;
    workgroupName?: string;
    customDomainCertificateArn?: string;
    customDomainCertificateExpiryTime?: Date;
}
export interface GetEndpointAccessRequest {
    endpointName: string;
}
export interface GetEndpointAccessResponse {
    endpoint?: EndpointAccess;
}
export type WorkgroupNameList = string[];
export interface GetIdentityCenterAuthTokenRequest {
    workgroupNames: string[];
}
export interface GetIdentityCenterAuthTokenResponse {
    token?: string | redacted.Redacted<string>;
    expirationTime?: Date;
}
export interface GetNamespaceRequest {
    namespaceName: string;
}
export interface GetNamespaceResponse {
    namespace: Namespace;
}
export interface GetRecoveryPointRequest {
    recoveryPointId: string;
}
export interface RecoveryPoint {
    recoveryPointId?: string;
    recoveryPointCreateTime?: Date;
    totalSizeInMegaBytes?: number;
    namespaceName?: string;
    workgroupName?: string;
    namespaceArn?: string;
}
export interface GetRecoveryPointResponse {
    recoveryPoint?: RecoveryPoint;
}
export interface GetReservationRequest {
    reservationId: string;
}
export interface GetReservationResponse {
    reservation: Reservation;
}
export interface GetReservationOfferingRequest {
    offeringId: string;
}
export interface GetReservationOfferingResponse {
    reservationOffering: ReservationOffering;
}
export interface GetResourcePolicyRequest {
    resourceArn: string;
}
export interface ResourcePolicy {
    resourceArn?: string;
    policy?: string;
}
export interface GetResourcePolicyResponse {
    resourcePolicy?: ResourcePolicy;
}
export interface GetScheduledActionRequest {
    scheduledActionName: string;
}
export interface GetScheduledActionResponse {
    scheduledAction?: ScheduledActionResponse;
}
export interface GetSnapshotRequest {
    snapshotName?: string;
    ownerAccount?: string;
    snapshotArn?: string;
}
export interface GetSnapshotResponse {
    snapshot?: Snapshot;
}
export interface GetTableRestoreStatusRequest {
    tableRestoreRequestId: string;
}
export interface TableRestoreStatus {
    tableRestoreRequestId?: string;
    status?: string;
    message?: string;
    requestTime?: Date;
    namespaceName?: string;
    workgroupName?: string;
    snapshotName?: string;
    progressInMegaBytes?: number;
    totalDataInMegaBytes?: number;
    sourceDatabaseName?: string;
    sourceSchemaName?: string;
    sourceTableName?: string;
    targetDatabaseName?: string;
    targetSchemaName?: string;
    newTableName?: string;
    recoveryPointId?: string;
}
export interface GetTableRestoreStatusResponse {
    tableRestoreStatus?: TableRestoreStatus;
}
export interface GetTrackRequest {
    trackName: string;
}
export interface UpdateTarget {
    trackName?: string;
    workgroupVersion?: string;
}
export type UpdateTargetsList = UpdateTarget[];
export interface ServerlessTrack {
    trackName?: string;
    workgroupVersion?: string;
    updateTargets?: UpdateTarget[];
}
export interface GetTrackResponse {
    track?: ServerlessTrack;
}
export interface GetUsageLimitRequest {
    usageLimitId: string;
}
export interface GetUsageLimitResponse {
    usageLimit?: UsageLimit;
}
export interface GetWorkgroupRequest {
    workgroupName: string;
}
export interface GetWorkgroupResponse {
    workgroup: Workgroup;
}
export type PaginationToken = string;
export interface ListCustomDomainAssociationsRequest {
    nextToken?: string;
    maxResults?: number;
    customDomainName?: string;
    customDomainCertificateArn?: string;
}
export interface Association {
    customDomainCertificateArn?: string;
    customDomainCertificateExpiryTime?: Date;
    customDomainName?: string;
    workgroupName?: string;
}
export type AssociationList = Association[];
export interface ListCustomDomainAssociationsResponse {
    nextToken?: string;
    associations?: Association[];
}
export interface ListEndpointAccessRequest {
    nextToken?: string;
    maxResults?: number;
    workgroupName?: string;
    vpcId?: string;
    ownerAccount?: string;
}
export type EndpointAccessList = EndpointAccess[];
export interface ListEndpointAccessResponse {
    nextToken?: string;
    endpoints: EndpointAccess[];
}
export type SourceArn = string;
export interface ListManagedWorkgroupsRequest {
    sourceArn?: string;
    nextToken?: string;
    maxResults?: number;
}
export type ManagedWorkgroupName = string;
export type ManagedWorkgroupStatus = "CREATING" | "DELETING" | "MODIFYING" | "AVAILABLE" | "NOT_AVAILABLE" | (string & {});
export interface ManagedWorkgroupListItem {
    managedWorkgroupName?: string;
    managedWorkgroupId?: string;
    sourceArn?: string;
    status?: ManagedWorkgroupStatus;
    creationDate?: Date;
}
export type ManagedWorkgroups = ManagedWorkgroupListItem[];
export interface ListManagedWorkgroupsResponse {
    nextToken?: string;
    managedWorkgroups?: ManagedWorkgroupListItem[];
}
export interface ListNamespacesRequest {
    nextToken?: string;
    maxResults?: number;
}
export type NamespaceList = Namespace[];
export interface ListNamespacesResponse {
    nextToken?: string;
    namespaces: Namespace[];
}
export interface ListRecoveryPointsRequest {
    nextToken?: string;
    maxResults?: number;
    startTime?: Date;
    endTime?: Date;
    namespaceName?: string;
    namespaceArn?: string;
}
export type RecoveryPointList = RecoveryPoint[];
export interface ListRecoveryPointsResponse {
    recoveryPoints?: RecoveryPoint[];
    nextToken?: string;
}
export interface ListReservationOfferingsRequest {
    nextToken?: string;
    maxResults?: number;
}
export type ReservationOfferingsList = ReservationOffering[];
export interface ListReservationOfferingsResponse {
    reservationOfferingsList: ReservationOffering[];
    nextToken?: string;
}
export interface ListReservationsRequest {
    nextToken?: string;
    maxResults?: number;
}
export type ReservationsList = Reservation[];
export interface ListReservationsResponse {
    reservationsList: Reservation[];
    nextToken?: string;
}
export interface ListScheduledActionsRequest {
    nextToken?: string;
    maxResults?: number;
    namespaceName?: string;
}
export interface ScheduledActionAssociation {
    namespaceName?: string;
    scheduledActionName?: string;
}
export type ScheduledActionsList = ScheduledActionAssociation[];
export interface ListScheduledActionsResponse {
    nextToken?: string;
    scheduledActions?: ScheduledActionAssociation[];
}
export interface ListSnapshotCopyConfigurationsRequest {
    namespaceName?: string;
    nextToken?: string;
    maxResults?: number;
}
export type SnapshotCopyConfigurations = SnapshotCopyConfiguration[];
export interface ListSnapshotCopyConfigurationsResponse {
    nextToken?: string;
    snapshotCopyConfigurations: SnapshotCopyConfiguration[];
}
export interface ListSnapshotsRequest {
    nextToken?: string;
    maxResults?: number;
    namespaceName?: string;
    namespaceArn?: string;
    ownerAccount?: string;
    startTime?: Date;
    endTime?: Date;
}
export type SnapshotList = Snapshot[];
export interface ListSnapshotsResponse {
    nextToken?: string;
    snapshots?: Snapshot[];
}
export interface ListTableRestoreStatusRequest {
    nextToken?: string;
    maxResults?: number;
    namespaceName?: string;
    workgroupName?: string;
}
export type TableRestoreStatusList = TableRestoreStatus[];
export interface ListTableRestoreStatusResponse {
    nextToken?: string;
    tableRestoreStatuses?: TableRestoreStatus[];
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[];
}
export interface ListTracksRequest {
    nextToken?: string;
    maxResults?: number;
}
export type TrackList = ServerlessTrack[];
export interface ListTracksResponse {
    tracks?: ServerlessTrack[];
    nextToken?: string;
}
export interface ListUsageLimitsRequest {
    resourceArn?: string;
    usageType?: string;
    nextToken?: string;
    maxResults?: number;
}
export type UsageLimits = UsageLimit[];
export interface ListUsageLimitsResponse {
    usageLimits?: UsageLimit[];
    nextToken?: string;
}
export interface ListWorkgroupsRequest {
    nextToken?: string;
    maxResults?: number;
    ownerAccount?: string;
}
export type WorkgroupList = Workgroup[];
export interface ListWorkgroupsResponse {
    nextToken?: string;
    workgroups: Workgroup[];
}
export interface PutResourcePolicyRequest {
    resourceArn: string;
    policy: string;
}
export interface PutResourcePolicyResponse {
    resourcePolicy?: ResourcePolicy;
}
export interface RestoreFromRecoveryPointRequest {
    recoveryPointId: string;
    namespaceName: string;
    workgroupName: string;
    maintainIntegration?: boolean;
}
export interface RestoreFromRecoveryPointResponse {
    recoveryPointId?: string;
    namespace?: Namespace;
}
export interface RestoreFromSnapshotRequest {
    namespaceName: string;
    workgroupName: string;
    snapshotName?: string;
    snapshotArn?: string;
    ownerAccount?: string;
    manageAdminPassword?: boolean;
    adminPasswordSecretKmsKeyId?: string;
    maintainIntegration?: boolean;
}
export interface RestoreFromSnapshotResponse {
    snapshotName?: string;
    ownerAccount?: string;
    namespace?: Namespace;
}
export interface RestoreTableFromRecoveryPointRequest {
    namespaceName: string;
    workgroupName: string;
    recoveryPointId: string;
    sourceDatabaseName: string;
    sourceSchemaName?: string;
    sourceTableName: string;
    targetDatabaseName?: string;
    targetSchemaName?: string;
    newTableName: string;
    activateCaseSensitiveIdentifier?: boolean;
}
export interface RestoreTableFromRecoveryPointResponse {
    tableRestoreStatus?: TableRestoreStatus;
}
export interface RestoreTableFromSnapshotRequest {
    namespaceName: string;
    workgroupName: string;
    snapshotName: string;
    sourceDatabaseName: string;
    sourceSchemaName?: string;
    sourceTableName: string;
    targetDatabaseName?: string;
    targetSchemaName?: string;
    newTableName: string;
    activateCaseSensitiveIdentifier?: boolean;
}
export interface RestoreTableFromSnapshotResponse {
    tableRestoreStatus?: TableRestoreStatus;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateCustomDomainAssociationRequest {
    workgroupName: string;
    customDomainName: string;
    customDomainCertificateArn: string;
}
export interface UpdateCustomDomainAssociationResponse {
    customDomainName?: string;
    workgroupName?: string;
    customDomainCertificateArn?: string;
    customDomainCertificateExpiryTime?: Date;
}
export interface UpdateEndpointAccessRequest {
    endpointName: string;
    vpcSecurityGroupIds?: string[];
}
export interface UpdateEndpointAccessResponse {
    endpoint?: EndpointAccess;
}
export type LakehouseRegistration = string;
export type CatalogNameString = string;
export type LakehouseIdcRegistration = string;
export interface UpdateLakehouseConfigurationRequest {
    namespaceName: string;
    lakehouseRegistration?: string;
    catalogName?: string;
    lakehouseIdcRegistration?: string;
    lakehouseIdcApplicationArn?: string;
    dryRun?: boolean;
}
export interface UpdateLakehouseConfigurationResponse {
    namespaceName?: string;
    lakehouseIdcApplicationArn?: string;
    lakehouseRegistrationStatus?: string;
    catalogArn?: string;
}
export type LogDestinationType = string;
export type S3TableAction = string;
export interface UpdateNamespaceRequest {
    namespaceName: string;
    adminUserPassword?: string | redacted.Redacted<string>;
    adminUsername?: string | redacted.Redacted<string>;
    kmsKeyId?: string;
    defaultIamRoleArn?: string;
    iamRoles?: string[];
    logExports?: string[];
    manageAdminPassword?: boolean;
    adminPasswordSecretKmsKeyId?: string;
    logDestinationType?: string;
    s3TableAction?: string;
    s3TableNames?: string[];
    s3TableKmsKeyId?: string;
    s3TableGranularity?: string;
}
export interface UpdateNamespaceResponse {
    namespace: Namespace;
}
export interface UpdateScheduledActionRequest {
    scheduledActionName: string;
    targetAction?: TargetAction;
    schedule?: Schedule;
    roleArn?: string;
    enabled?: boolean;
    scheduledActionDescription?: string;
    startTime?: Date;
    endTime?: Date;
}
export interface UpdateScheduledActionResponse {
    scheduledAction?: ScheduledActionResponse;
}
export interface UpdateSnapshotRequest {
    snapshotName: string;
    retentionPeriod?: number;
}
export interface UpdateSnapshotResponse {
    snapshot?: Snapshot;
}
export interface UpdateSnapshotCopyConfigurationRequest {
    snapshotCopyConfigurationId: string;
    snapshotRetentionPeriod?: number;
}
export interface UpdateSnapshotCopyConfigurationResponse {
    snapshotCopyConfiguration: SnapshotCopyConfiguration;
}
export interface UpdateUsageLimitRequest {
    usageLimitId: string;
    amount?: number;
    breachAction?: string;
}
export interface UpdateUsageLimitResponse {
    usageLimit?: UsageLimit;
}
export interface UpdateWorkgroupRequest {
    workgroupName: string;
    baseCapacity?: number;
    enhancedVpcRouting?: boolean;
    configParameters?: ConfigParameter[];
    publiclyAccessible?: boolean;
    subnetIds?: string[];
    securityGroupIds?: string[];
    port?: number;
    maxCapacity?: number;
    ipAddressType?: string;
    pricePerformanceTarget?: PerformanceTarget;
    trackName?: string;
    extraComputeForAutomaticOptimization?: boolean;
}
export interface UpdateWorkgroupResponse {
    workgroup: Workgroup;
}
export type ConvertRecoveryPointToSnapshotError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Converts a recovery point to a snapshot. For more information about recovery points and snapshots, see Working with snapshots and recovery points.
 */
export declare const convertRecoveryPointToSnapshot: API.OperationMethod<ConvertRecoveryPointToSnapshotRequest, ConvertRecoveryPointToSnapshotResponse, ConvertRecoveryPointToSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateCustomDomainAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a custom domain association for Amazon Redshift Serverless.
 */
export declare const createCustomDomainAssociation: API.OperationMethod<CreateCustomDomainAssociationRequest, CreateCustomDomainAssociationResponse, CreateCustomDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateEndpointAccessError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Redshift Serverless managed VPC endpoint.
 */
export declare const createEndpointAccess: API.OperationMethod<CreateEndpointAccessRequest, CreateEndpointAccessResponse, CreateEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type CreateNamespaceError = ConflictException | InternalServerException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates a namespace in Amazon Redshift Serverless.
 */
export declare const createNamespace: API.OperationMethod<CreateNamespaceRequest, CreateNamespaceResponse, CreateNamespaceError, Credentials | HttpClient.HttpClient>;
export type CreateReservationError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Redshift Serverless reservation, which gives you the option to commit to a specified number of Redshift Processing Units (RPUs) for a year at a discount from Serverless on-demand (OD) rates.
 */
export declare const createReservation: API.OperationMethod<CreateReservationRequest, CreateReservationResponse, CreateReservationError, Credentials | HttpClient.HttpClient>;
export type CreateScheduledActionError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates a scheduled action. A scheduled action contains a schedule and an Amazon Redshift API action. For example, you can create a schedule of when to run the `CreateSnapshot` API operation.
 */
export declare const createScheduledAction: API.OperationMethod<CreateScheduledActionRequest, CreateScheduledActionResponse, CreateScheduledActionError, Credentials | HttpClient.HttpClient>;
export type CreateSnapshotError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates a snapshot of all databases in a namespace. For more information about snapshots, see Working with snapshots and recovery points.
 */
export declare const createSnapshot: API.OperationMethod<CreateSnapshotRequest, CreateSnapshotResponse, CreateSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateSnapshotCopyConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a snapshot copy configuration that lets you copy snapshots to another Amazon Web Services Region.
 */
export declare const createSnapshotCopyConfiguration: API.OperationMethod<CreateSnapshotCopyConfigurationRequest, CreateSnapshotCopyConfigurationResponse, CreateSnapshotCopyConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateUsageLimitError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a usage limit for a specified Amazon Redshift Serverless usage type. The usage limit is identified by the returned usage limit identifier.
 */
export declare const createUsageLimit: API.OperationMethod<CreateUsageLimitRequest, CreateUsageLimitResponse, CreateUsageLimitError, Credentials | HttpClient.HttpClient>;
export type CreateWorkgroupError = ConflictException | InsufficientCapacityException | InternalServerException | Ipv6CidrBlockNotFoundException | ResourceNotFoundException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates an workgroup in Amazon Redshift Serverless.
 *
 * VPC Block Public Access (BPA) enables you to block resources in VPCs and subnets that you own in a Region from reaching or being reached from the internet through internet gateways and egress-only internet gateways. If a workgroup is in an account with VPC BPA turned on, the following capabilities are blocked:
 *
 * - Creating a public access workgroup
 *
 * - Modifying a private workgroup to public
 *
 * - Adding a subnet with VPC BPA turned on to the workgroup when the workgroup is public
 *
 * For more information about VPC BPA, see Block public access to VPCs and subnets in the *Amazon VPC User Guide*.
 */
export declare const createWorkgroup: API.OperationMethod<CreateWorkgroupRequest, CreateWorkgroupResponse, CreateWorkgroupError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomDomainAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a custom domain association for Amazon Redshift Serverless.
 */
export declare const deleteCustomDomainAssociation: API.OperationMethod<DeleteCustomDomainAssociationRequest, DeleteCustomDomainAssociationResponse, DeleteCustomDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteEndpointAccessError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Redshift Serverless managed VPC endpoint.
 */
export declare const deleteEndpointAccess: API.OperationMethod<DeleteEndpointAccessRequest, DeleteEndpointAccessResponse, DeleteEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type DeleteNamespaceError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a namespace from Amazon Redshift Serverless. Before you delete the namespace, you can create a final snapshot that has all of the data within the namespace.
 */
export declare const deleteNamespace: API.OperationMethod<DeleteNamespaceRequest, DeleteNamespaceResponse, DeleteNamespaceError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the specified resource policy.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteScheduledActionError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a scheduled action.
 */
export declare const deleteScheduledAction: API.OperationMethod<DeleteScheduledActionRequest, DeleteScheduledActionResponse, DeleteScheduledActionError, Credentials | HttpClient.HttpClient>;
export type DeleteSnapshotError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a snapshot from Amazon Redshift Serverless.
 */
export declare const deleteSnapshot: API.OperationMethod<DeleteSnapshotRequest, DeleteSnapshotResponse, DeleteSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteSnapshotCopyConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a snapshot copy configuration
 */
export declare const deleteSnapshotCopyConfiguration: API.OperationMethod<DeleteSnapshotCopyConfigurationRequest, DeleteSnapshotCopyConfigurationResponse, DeleteSnapshotCopyConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteUsageLimitError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a usage limit from Amazon Redshift Serverless.
 */
export declare const deleteUsageLimit: API.OperationMethod<DeleteUsageLimitRequest, DeleteUsageLimitResponse, DeleteUsageLimitError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkgroupError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a workgroup.
 */
export declare const deleteWorkgroup: API.OperationMethod<DeleteWorkgroupRequest, DeleteWorkgroupResponse, DeleteWorkgroupError, Credentials | HttpClient.HttpClient>;
export type GetCredentialsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a database user name and temporary password with temporary authorization to log in to Amazon Redshift Serverless.
 *
 * By default, the temporary credentials expire in 900 seconds. You can optionally specify a duration between 900 seconds (15 minutes) and 3600 seconds (60 minutes).
 *
 * The Identity and Access Management (IAM) user or role that runs GetCredentials must have an IAM policy attached that allows access to all necessary actions and resources.
 *
 * If the `DbName` parameter is specified, the IAM policy must allow access to the resource dbname for the specified database name.
 */
export declare const getCredentials: API.OperationMethod<GetCredentialsRequest, GetCredentialsResponse, GetCredentialsError, Credentials | HttpClient.HttpClient>;
export type GetCustomDomainAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a specific custom domain association.
 */
export declare const getCustomDomainAssociation: API.OperationMethod<GetCustomDomainAssociationRequest, GetCustomDomainAssociationResponse, GetCustomDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type GetEndpointAccessError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information, such as the name, about a VPC endpoint.
 */
export declare const getEndpointAccess: API.OperationMethod<GetEndpointAccessRequest, GetEndpointAccessResponse, GetEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type GetIdentityCenterAuthTokenError = AccessDeniedException | ConflictException | DryRunException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns an Identity Center authentication token for accessing Amazon Redshift Serverless workgroups.
 *
 * The token provides secure access to data within the specified workgroups using Identity Center identity propagation. The token expires after a specified duration and must be refreshed for continued access.
 *
 * The Identity and Access Management (IAM) user or role that runs GetIdentityCenterAuthToken must have appropriate permissions to access the specified workgroups and Identity Center integration must be configured for the workgroups.
 */
export declare const getIdentityCenterAuthToken: API.OperationMethod<GetIdentityCenterAuthTokenRequest, GetIdentityCenterAuthTokenResponse, GetIdentityCenterAuthTokenError, Credentials | HttpClient.HttpClient>;
export type GetNamespaceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a namespace in Amazon Redshift Serverless.
 */
export declare const getNamespace: API.OperationMethod<GetNamespaceRequest, GetNamespaceResponse, GetNamespaceError, Credentials | HttpClient.HttpClient>;
export type GetRecoveryPointError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a recovery point.
 */
export declare const getRecoveryPoint: API.OperationMethod<GetRecoveryPointRequest, GetRecoveryPointResponse, GetRecoveryPointError, Credentials | HttpClient.HttpClient>;
export type GetReservationError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an Amazon Redshift Serverless reservation. A reservation gives you the option to commit to a specified number of Redshift Processing Units (RPUs) for a year at a discount from Serverless on-demand (OD) rates.
 */
export declare const getReservation: API.OperationMethod<GetReservationRequest, GetReservationResponse, GetReservationError, Credentials | HttpClient.HttpClient>;
export type GetReservationOfferingError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the reservation offering. The offering determines the payment schedule for the reservation.
 */
export declare const getReservationOffering: API.OperationMethod<GetReservationOfferingRequest, GetReservationOfferingResponse, GetReservationOfferingError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a resource policy.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetScheduledActionError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a scheduled action.
 */
export declare const getScheduledAction: API.OperationMethod<GetScheduledActionRequest, GetScheduledActionResponse, GetScheduledActionError, Credentials | HttpClient.HttpClient>;
export type GetSnapshotError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a specific snapshot.
 */
export declare const getSnapshot: API.OperationMethod<GetSnapshotRequest, GetSnapshotResponse, GetSnapshotError, Credentials | HttpClient.HttpClient>;
export type GetTableRestoreStatusError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a `TableRestoreStatus` object.
 */
export declare const getTableRestoreStatus: API.OperationMethod<GetTableRestoreStatusRequest, GetTableRestoreStatusResponse, GetTableRestoreStatusError, Credentials | HttpClient.HttpClient>;
export type GetTrackError = AccessDeniedException | ConflictException | DryRunException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the Redshift Serverless version for a specified track.
 */
export declare const getTrack: API.OperationMethod<GetTrackRequest, GetTrackResponse, GetTrackError, Credentials | HttpClient.HttpClient>;
export type GetUsageLimitError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a usage limit.
 */
export declare const getUsageLimit: API.OperationMethod<GetUsageLimitRequest, GetUsageLimitResponse, GetUsageLimitError, Credentials | HttpClient.HttpClient>;
export type GetWorkgroupError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a specific workgroup.
 */
export declare const getWorkgroup: API.OperationMethod<GetWorkgroupRequest, GetWorkgroupResponse, GetWorkgroupError, Credentials | HttpClient.HttpClient>;
export type ListCustomDomainAssociationsError = AccessDeniedException | InternalServerException | InvalidPaginationException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists custom domain associations for Amazon Redshift Serverless.
 */
export declare const listCustomDomainAssociations: API.PaginatedOperationMethod<ListCustomDomainAssociationsRequest, ListCustomDomainAssociationsResponse, ListCustomDomainAssociationsError, Credentials | HttpClient.HttpClient, Association>;
export type ListEndpointAccessError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns an array of `EndpointAccess` objects and relevant information.
 */
export declare const listEndpointAccess: API.PaginatedOperationMethod<ListEndpointAccessRequest, ListEndpointAccessResponse, ListEndpointAccessError, Credentials | HttpClient.HttpClient, EndpointAccess>;
export type ListManagedWorkgroupsError = AccessDeniedException | InternalServerException | CommonErrors;
/**
 * Returns information about a list of specified managed workgroups in your account.
 */
export declare const listManagedWorkgroups: API.PaginatedOperationMethod<ListManagedWorkgroupsRequest, ListManagedWorkgroupsResponse, ListManagedWorkgroupsError, Credentials | HttpClient.HttpClient, ManagedWorkgroupListItem>;
export type ListNamespacesError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns information about a list of specified namespaces.
 */
export declare const listNamespaces: API.PaginatedOperationMethod<ListNamespacesRequest, ListNamespacesResponse, ListNamespacesError, Credentials | HttpClient.HttpClient, Namespace>;
export type ListRecoveryPointsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns an array of recovery points.
 */
export declare const listRecoveryPoints: API.PaginatedOperationMethod<ListRecoveryPointsRequest, ListRecoveryPointsResponse, ListRecoveryPointsError, Credentials | HttpClient.HttpClient, RecoveryPoint>;
export type ListReservationOfferingsError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the current reservation offerings in your account.
 */
export declare const listReservationOfferings: API.PaginatedOperationMethod<ListReservationOfferingsRequest, ListReservationOfferingsResponse, ListReservationOfferingsError, Credentials | HttpClient.HttpClient, ReservationOffering>;
export type ListReservationsError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of Reservation objects.
 */
export declare const listReservations: API.PaginatedOperationMethod<ListReservationsRequest, ListReservationsResponse, ListReservationsError, Credentials | HttpClient.HttpClient, Reservation>;
export type ListScheduledActionsError = InternalServerException | InvalidPaginationException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of scheduled actions. You can use the flags to filter the list of returned scheduled actions.
 */
export declare const listScheduledActions: API.PaginatedOperationMethod<ListScheduledActionsRequest, ListScheduledActionsResponse, ListScheduledActionsError, Credentials | HttpClient.HttpClient, ScheduledActionAssociation>;
export type ListSnapshotCopyConfigurationsError = ConflictException | InternalServerException | InvalidPaginationException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of snapshot copy configurations.
 */
export declare const listSnapshotCopyConfigurations: API.PaginatedOperationMethod<ListSnapshotCopyConfigurationsRequest, ListSnapshotCopyConfigurationsResponse, ListSnapshotCopyConfigurationsError, Credentials | HttpClient.HttpClient, SnapshotCopyConfiguration>;
export type ListSnapshotsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of snapshots.
 */
export declare const listSnapshots: API.PaginatedOperationMethod<ListSnapshotsRequest, ListSnapshotsResponse, ListSnapshotsError, Credentials | HttpClient.HttpClient, Snapshot>;
export type ListTableRestoreStatusError = InvalidPaginationException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about an array of `TableRestoreStatus` objects.
 */
export declare const listTableRestoreStatus: API.PaginatedOperationMethod<ListTableRestoreStatusRequest, ListTableRestoreStatusResponse, ListTableRestoreStatusError, Credentials | HttpClient.HttpClient, TableRestoreStatus>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags assigned to a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTracksError = AccessDeniedException | InternalServerException | InvalidPaginationException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the Amazon Redshift Serverless versions.
 */
export declare const listTracks: API.PaginatedOperationMethod<ListTracksRequest, ListTracksResponse, ListTracksError, Credentials | HttpClient.HttpClient, ServerlessTrack>;
export type ListUsageLimitsError = ConflictException | InternalServerException | InvalidPaginationException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all usage limits within Amazon Redshift Serverless.
 */
export declare const listUsageLimits: API.PaginatedOperationMethod<ListUsageLimitsRequest, ListUsageLimitsResponse, ListUsageLimitsError, Credentials | HttpClient.HttpClient, UsageLimit>;
export type ListWorkgroupsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns information about a list of specified workgroups.
 */
export declare const listWorkgroups: API.PaginatedOperationMethod<ListWorkgroupsRequest, ListWorkgroupsResponse, ListWorkgroupsError, Credentials | HttpClient.HttpClient, Workgroup>;
export type PutResourcePolicyError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates or updates a resource policy. Currently, you can use policies to share snapshots across Amazon Web Services accounts.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type RestoreFromRecoveryPointError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Restore the data from a recovery point.
 */
export declare const restoreFromRecoveryPoint: API.OperationMethod<RestoreFromRecoveryPointRequest, RestoreFromRecoveryPointResponse, RestoreFromRecoveryPointError, Credentials | HttpClient.HttpClient>;
export type RestoreFromSnapshotError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Restores a namespace from a snapshot.
 */
export declare const restoreFromSnapshot: API.OperationMethod<RestoreFromSnapshotRequest, RestoreFromSnapshotResponse, RestoreFromSnapshotError, Credentials | HttpClient.HttpClient>;
export type RestoreTableFromRecoveryPointError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Restores a table from a recovery point to your Amazon Redshift Serverless instance. You can't use this operation to restore tables with interleaved sort keys.
 */
export declare const restoreTableFromRecoveryPoint: API.OperationMethod<RestoreTableFromRecoveryPointRequest, RestoreTableFromRecoveryPointResponse, RestoreTableFromRecoveryPointError, Credentials | HttpClient.HttpClient>;
export type RestoreTableFromSnapshotError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Restores a table from a snapshot to your Amazon Redshift Serverless instance. You can't use this operation to restore tables with interleaved sort keys.
 */
export declare const restoreTableFromSnapshot: API.OperationMethod<RestoreTableFromSnapshotRequest, RestoreTableFromSnapshotResponse, RestoreTableFromSnapshotError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Assigns one or more tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a tag or set of tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCustomDomainAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an Amazon Redshift Serverless certificate associated with a custom domain.
 */
export declare const updateCustomDomainAssociation: API.OperationMethod<UpdateCustomDomainAssociationRequest, UpdateCustomDomainAssociationResponse, UpdateCustomDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateEndpointAccessError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates an Amazon Redshift Serverless managed endpoint.
 */
export declare const updateEndpointAccess: API.OperationMethod<UpdateEndpointAccessRequest, UpdateEndpointAccessResponse, UpdateEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type UpdateLakehouseConfigurationError = ConflictException | DryRunException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Modifies the lakehouse configuration for a namespace. This operation allows you to manage Amazon Redshift federated permissions and Amazon Web Services IAM Identity Center trusted identity propagation.
 */
export declare const updateLakehouseConfiguration: API.OperationMethod<UpdateLakehouseConfigurationRequest, UpdateLakehouseConfigurationResponse, UpdateLakehouseConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateNamespaceError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a namespace with the specified settings. Unless required, you can't update multiple parameters in one request. For example, you must specify both `adminUsername` and `adminUserPassword` to update either field, but you can't update both `kmsKeyId` and `logExports` in a single request.
 *
 * Similarly, an S3 Tables log-publishing update (a request where `logDestinationType` is `s3table`) cannot be combined with any other namespace configuration change and must be submitted as its own request.
 */
export declare const updateNamespace: API.OperationMethod<UpdateNamespaceRequest, UpdateNamespaceResponse, UpdateNamespaceError, Credentials | HttpClient.HttpClient>;
export type UpdateScheduledActionError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a scheduled action.
 */
export declare const updateScheduledAction: API.OperationMethod<UpdateScheduledActionRequest, UpdateScheduledActionResponse, UpdateScheduledActionError, Credentials | HttpClient.HttpClient>;
export type UpdateSnapshotError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a snapshot.
 */
export declare const updateSnapshot: API.OperationMethod<UpdateSnapshotRequest, UpdateSnapshotResponse, UpdateSnapshotError, Credentials | HttpClient.HttpClient>;
export type UpdateSnapshotCopyConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a snapshot copy configuration.
 */
export declare const updateSnapshotCopyConfiguration: API.OperationMethod<UpdateSnapshotCopyConfigurationRequest, UpdateSnapshotCopyConfigurationResponse, UpdateSnapshotCopyConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateUsageLimitError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Update a usage limit in Amazon Redshift Serverless. You can't update the usage type or period of a usage limit.
 */
export declare const updateUsageLimit: API.OperationMethod<UpdateUsageLimitRequest, UpdateUsageLimitResponse, UpdateUsageLimitError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkgroupError = ConflictException | InsufficientCapacityException | InternalServerException | Ipv6CidrBlockNotFoundException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a workgroup with the specified configuration settings. You can't update multiple parameters in one request. For example, you can update `baseCapacity` or `port` in a single request, but you can't update both in the same request.
 *
 * VPC Block Public Access (BPA) enables you to block resources in VPCs and subnets that you own in a Region from reaching or being reached from the internet through internet gateways and egress-only internet gateways. If a workgroup is in an account with VPC BPA turned on, the following capabilities are blocked:
 *
 * - Creating a public access workgroup
 *
 * - Modifying a private workgroup to public
 *
 * - Adding a subnet with VPC BPA turned on to the workgroup when the workgroup is public
 *
 * For more information about VPC BPA, see Block public access to VPCs and subnets in the *Amazon VPC User Guide*.
 */
export declare const updateWorkgroup: API.OperationMethod<UpdateWorkgroupRequest, UpdateWorkgroupResponse, UpdateWorkgroupError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=redshift-serverless.d.ts.map