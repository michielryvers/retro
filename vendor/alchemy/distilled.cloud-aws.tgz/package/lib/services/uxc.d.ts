import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly fieldList: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export interface GetAccountCustomizationsInput {
}
export type AccountColor = "none" | "pink" | "purple" | "darkBlue" | "lightBlue" | "teal" | "green" | "yellow" | "orange" | "red" | (string & {});
export type Service = string;
export type ServiceList = string[];
export type Region = string;
export type RegionsList = string[];
export interface GetAccountCustomizationsOutput {
    accountColor?: AccountColor;
    visibleServices?: string[];
    visibleRegions?: string[];
}
export type NextToken = string;
export type MaxResults = number;
export interface ListServicesInput {
    nextToken?: string;
    maxResults?: number;
}
export interface ListServicesOutput {
    nextToken?: string;
    services?: string[];
}
export interface UpdateAccountCustomizationsInput {
    accountColor?: AccountColor;
    visibleServices?: string[];
    visibleRegions?: string[];
}
export interface UpdateAccountCustomizationsOutput {
    accountColor?: AccountColor;
    visibleServices?: string[];
    visibleRegions?: string[];
}
export interface ValidationExceptionField {
    path: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type GetAccountCustomizationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the current account customization settings, including account color, visible services, and visible Regions. Settings that you have not configured return their default values: visible Regions and visible services return `null`, and account color returns `none`.
 *
 * The `visibleServices` and `visibleRegions` settings control only the appearance of services and Regions in the Amazon Web Services Management Console. They do not restrict access through the CLI, SDKs, or other APIs.
 */
export declare const getAccountCustomizations: API.OperationMethod<GetAccountCustomizationsInput, GetAccountCustomizationsOutput, GetAccountCustomizationsError, Credentials | HttpClient.HttpClient>;
export type ListServicesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of Amazon Web Services service identifiers that you can use as values for the `visibleServices` setting in UpdateAccountCustomizations. The available services vary by Amazon Web Services partition. Use pagination to retrieve all results.
 *
 * The `visibleServices` setting controls only the appearance of services in the Amazon Web Services Management Console. It does not restrict access through the CLI, SDKs, or other APIs.
 */
export declare const listServices: API.PaginatedOperationMethod<ListServicesInput, ListServicesOutput, ListServicesError, Credentials | HttpClient.HttpClient, Service>;
export type UpdateAccountCustomizationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates one or more account customization settings. You can update account color, visible services, and visible Regions in a single request. Only the settings that you include in the request body are modified. Omitted settings remain unchanged. To reset a setting to its default behavior, set the value to `null` for visible Regions and visible services, or `none` for account color. This operation is idempotent.
 *
 * The `visibleServices` and `visibleRegions` settings control only the appearance of services and Regions in the Amazon Web Services Management Console. They do not restrict access through the CLI, SDKs, or other APIs.
 */
export declare const updateAccountCustomizations: API.OperationMethod<UpdateAccountCustomizationsInput, UpdateAccountCustomizationsOutput, UpdateAccountCustomizationsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=uxc.d.ts.map