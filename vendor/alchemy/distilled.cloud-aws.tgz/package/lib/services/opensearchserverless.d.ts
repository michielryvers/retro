import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const OcuLimitExceededException_base: S.TaggedErrorClass<"OcuLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class OcuLimitExceededException extends /*@__PURE__*/ OcuLimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type CollectionId = string;
export type CollectionIds = string[];
export type CollectionName = string;
export type CollectionNames = string[];
export interface BatchGetCollectionRequest {
    ids?: string[];
    names?: string[];
}
export type CollectionStatus = string;
export type CollectionType = string;
export type StandbyReplicas = string;
export type DeletionProtection = string;
export type ServerlessVectorAccelerationStatus = string;
export interface VectorOptions {
    ServerlessVectorAcceleration: string;
}
export interface FipsEndpoints {
    collectionEndpoint?: string;
    dashboardEndpoint?: string;
}
export type CollectionGroupName = string;
export interface CollectionDetail {
    id?: string;
    name?: string;
    status?: string;
    type?: string;
    description?: string;
    arn?: string;
    kmsKeyArn?: string;
    standbyReplicas?: string;
    deletionProtection?: string;
    vectorOptions?: VectorOptions;
    createdDate?: number;
    lastModifiedDate?: number;
    collectionEndpoint?: string;
    dashboardEndpoint?: string;
    fipsEndpoints?: FipsEndpoints;
    failureCode?: string;
    failureMessage?: string;
    collectionGroupName?: string;
}
export type CollectionDetails = CollectionDetail[];
export interface CollectionErrorDetail {
    id?: string;
    name?: string;
    errorMessage?: string;
    errorCode?: string;
}
export type CollectionErrorDetails = CollectionErrorDetail[];
export interface BatchGetCollectionResponse {
    collectionDetails?: CollectionDetail[];
    collectionErrorDetails?: CollectionErrorDetail[];
}
export type CollectionGroupId = string;
export type CollectionGroupIds = string[];
export type CollectionGroupNames = string[];
export interface BatchGetCollectionGroupRequest {
    ids?: string[];
    names?: string[];
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type Tags = Tag[];
export type CollectionGroupMaxIndexingCapacityValue = number;
export type CollectionGroupMaxSearchCapacityValue = number;
export type CollectionGroupMinIndexingCapacityValue = number;
export type CollectionGroupMinSearchCapacityValue = number;
export interface CollectionGroupCapacityLimits {
    maxIndexingCapacityInOCU?: number;
    maxSearchCapacityInOCU?: number;
    minIndexingCapacityInOCU?: number;
    minSearchCapacityInOCU?: number;
}
export type AutoscalingStatus = string;
export interface CapacityDetails {
    capacityInOcu?: number;
    autoscalingStatus?: string;
}
export interface CurrentCapacity {
    search?: CapacityDetails;
    indexing?: CapacityDetails;
}
export type ServerlessGeneration = string;
export interface CollectionGroupDetail {
    id?: string;
    arn?: string;
    name?: string;
    standbyReplicas?: string;
    description?: string;
    tags?: Tag[];
    createdDate?: number;
    capacityLimits?: CollectionGroupCapacityLimits;
    currentCapacity?: CurrentCapacity;
    numberOfCollections?: number;
    generation?: string;
}
export type CollectionGroupDetails = CollectionGroupDetail[];
export interface CollectionGroupErrorDetail {
    id?: string;
    name?: string;
    errorMessage?: string;
    errorCode?: string;
}
export type CollectionGroupErrorDetails = CollectionGroupErrorDetail[];
export interface BatchGetCollectionGroupResponse {
    collectionGroupDetails?: CollectionGroupDetail[];
    collectionGroupErrorDetails?: CollectionGroupErrorDetail[];
}
export type LifecyclePolicyType = string;
export type ResourceName = string;
export interface LifecyclePolicyResourceIdentifier {
    type: string;
    resource: string;
}
export type LifecyclePolicyResourceIdentifiers = LifecyclePolicyResourceIdentifier[];
export interface BatchGetEffectiveLifecyclePolicyRequest {
    resourceIdentifiers: LifecyclePolicyResourceIdentifier[];
}
export type Resource = string;
export type PolicyName = string;
export type ResourceType = string;
export interface EffectiveLifecyclePolicyDetail {
    type?: string;
    resource?: string;
    policyName?: string;
    resourceType?: string;
    retentionPeriod?: string;
    noMinRetentionPeriod?: boolean;
}
export type EffectiveLifecyclePolicyDetails = EffectiveLifecyclePolicyDetail[];
export interface EffectiveLifecyclePolicyErrorDetail {
    type?: string;
    resource?: string;
    errorMessage?: string;
    errorCode?: string;
}
export type EffectiveLifecyclePolicyErrorDetails = EffectiveLifecyclePolicyErrorDetail[];
export interface BatchGetEffectiveLifecyclePolicyResponse {
    effectiveLifecyclePolicyDetails?: EffectiveLifecyclePolicyDetail[];
    effectiveLifecyclePolicyErrorDetails?: EffectiveLifecyclePolicyErrorDetail[];
}
export interface LifecyclePolicyIdentifier {
    type: string;
    name: string;
}
export type LifecyclePolicyIdentifiers = LifecyclePolicyIdentifier[];
export interface BatchGetLifecyclePolicyRequest {
    identifiers: LifecyclePolicyIdentifier[];
}
export type PolicyVersion = string;
export type PolicyDescription = string;
export interface LifecyclePolicyDetail {
    type?: string;
    name?: string;
    policyVersion?: string;
    description?: string;
    policy?: any;
    createdDate?: number;
    lastModifiedDate?: number;
}
export type LifecyclePolicyDetails = LifecyclePolicyDetail[];
export interface LifecyclePolicyErrorDetail {
    type?: string;
    name?: string;
    errorMessage?: string;
    errorCode?: string;
}
export type LifecyclePolicyErrorDetails = LifecyclePolicyErrorDetail[];
export interface BatchGetLifecyclePolicyResponse {
    lifecyclePolicyDetails?: LifecyclePolicyDetail[];
    lifecyclePolicyErrorDetails?: LifecyclePolicyErrorDetail[];
}
export type VpcEndpointId = string;
export type VpcEndpointIds = string[];
export interface BatchGetVpcEndpointRequest {
    ids: string[];
}
export type VpcEndpointName = string;
export type VpcId = string;
export type SubnetId = string;
export type SubnetIds = string[];
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export type VpcEndpointStatus = string;
export interface VpcEndpointDetail {
    id?: string;
    name?: string;
    vpcId?: string;
    subnetIds?: string[];
    securityGroupIds?: string[];
    status?: string;
    createdDate?: number;
    failureCode?: string;
    failureMessage?: string;
}
export type VpcEndpointDetails = VpcEndpointDetail[];
export interface VpcEndpointErrorDetail {
    id?: string;
    errorMessage?: string;
    errorCode?: string;
}
export type VpcEndpointErrorDetails = VpcEndpointErrorDetail[];
export interface BatchGetVpcEndpointResponse {
    vpcEndpointDetails?: VpcEndpointDetail[];
    vpcEndpointErrorDetails?: VpcEndpointErrorDetail[];
}
export type AccessPolicyType = string;
export type PolicyDocument = string;
export type ClientToken = string;
export interface CreateAccessPolicyRequest {
    type: string;
    name: string;
    description?: string;
    policy: string;
    clientToken?: string;
}
export interface AccessPolicyDetail {
    type?: string;
    name?: string;
    policyVersion?: string;
    description?: string;
    policy?: any;
    createdDate?: number;
    lastModifiedDate?: number;
}
export interface CreateAccessPolicyResponse {
    accessPolicyDetail?: AccessPolicyDetail;
}
export interface EncryptionConfig {
    aWSOwnedKey?: boolean;
    kmsKeyArn?: string;
}
export interface CreateCollectionRequest {
    name: string;
    type?: string;
    description?: string;
    tags?: Tag[];
    standbyReplicas?: string;
    vectorOptions?: VectorOptions;
    collectionGroupName?: string;
    encryptionConfig?: EncryptionConfig;
    deletionProtection?: string;
    clientToken?: string;
}
export interface CreateCollectionDetail {
    id?: string;
    name?: string;
    status?: string;
    type?: string;
    description?: string;
    arn?: string;
    kmsKeyArn?: string;
    standbyReplicas?: string;
    deletionProtection?: string;
    vectorOptions?: VectorOptions;
    createdDate?: number;
    lastModifiedDate?: number;
    collectionGroupName?: string;
}
export interface CreateCollectionResponse {
    createCollectionDetail?: CreateCollectionDetail;
}
export interface CreateCollectionGroupRequest {
    name: string;
    standbyReplicas: string;
    description?: string;
    tags?: Tag[];
    capacityLimits?: CollectionGroupCapacityLimits;
    generation?: string;
    clientToken?: string;
}
export interface CreateCollectionGroupDetail {
    id?: string;
    arn?: string;
    name?: string;
    standbyReplicas?: string;
    description?: string;
    tags?: Tag[];
    createdDate?: number;
    capacityLimits?: CollectionGroupCapacityLimits;
    generation?: string;
}
export interface CreateCollectionGroupResponse {
    createCollectionGroupDetail?: CreateCollectionGroupDetail;
}
export type IndexName = string;
export type IndexSchema = unknown;
export interface CreateIndexRequest {
    id: string;
    indexName: string;
    indexSchema?: any;
}
export interface CreateIndexResponse {
}
export interface CreateLifecyclePolicyRequest {
    type: string;
    name: string;
    description?: string;
    policy: string;
    clientToken?: string;
}
export interface CreateLifecyclePolicyResponse {
    lifecyclePolicyDetail?: LifecyclePolicyDetail;
}
export type SecurityConfigType = string;
export type ConfigName = string;
export type ConfigDescription = string;
export type SamlMetadata = string;
export type SamlUserAttribute = string;
export type SamlGroupAttribute = string;
export type OpenSearchServerlessEntityId = string;
export interface SamlConfigOptions {
    metadata: string;
    userAttribute?: string;
    groupAttribute?: string;
    openSearchServerlessEntityId?: string;
    sessionTimeout?: number;
}
export type IamIdentityCenterInstanceArn = string;
export type IamIdentityCenterUserAttribute = string;
export type IamIdentityCenterGroupAttribute = string;
export interface CreateIamIdentityCenterConfigOptions {
    instanceArn: string;
    userAttribute?: string;
    groupAttribute?: string;
}
export type IamFederationGroupAttribute = string;
export type IamFederationUserAttribute = string;
export interface IamFederationConfigOptions {
    groupAttribute?: string;
    userAttribute?: string;
}
export interface CreateSecurityConfigRequest {
    type: string;
    name: string;
    description?: string;
    samlOptions?: SamlConfigOptions;
    iamIdentityCenterOptions?: CreateIamIdentityCenterConfigOptions;
    iamFederationOptions?: IamFederationConfigOptions;
    clientToken?: string;
}
export type SecurityConfigId = string;
export type IamIdentityCenterApplicationArn = string;
export interface IamIdentityCenterConfigOptions {
    instanceArn?: string;
    applicationArn?: string;
    applicationName?: string;
    applicationDescription?: string;
    userAttribute?: string;
    groupAttribute?: string;
}
export interface SecurityConfigDetail {
    id?: string;
    type?: string;
    configVersion?: string;
    description?: string;
    samlOptions?: SamlConfigOptions;
    iamIdentityCenterOptions?: IamIdentityCenterConfigOptions;
    iamFederationOptions?: IamFederationConfigOptions;
    createdDate?: number;
    lastModifiedDate?: number;
}
export interface CreateSecurityConfigResponse {
    securityConfigDetail?: SecurityConfigDetail;
}
export type SecurityPolicyType = string;
export interface CreateSecurityPolicyRequest {
    type: string;
    name: string;
    description?: string;
    policy: string;
    clientToken?: string;
}
export interface SecurityPolicyDetail {
    type?: string;
    name?: string;
    policyVersion?: string;
    description?: string;
    policy?: any;
    createdDate?: number;
    lastModifiedDate?: number;
}
export interface CreateSecurityPolicyResponse {
    securityPolicyDetail?: SecurityPolicyDetail;
}
export interface CreateVpcEndpointRequest {
    name: string;
    vpcId: string;
    subnetIds: string[];
    securityGroupIds?: string[];
    clientToken?: string;
}
export interface CreateVpcEndpointDetail {
    id?: string;
    name?: string;
    status?: string;
}
export interface CreateVpcEndpointResponse {
    createVpcEndpointDetail?: CreateVpcEndpointDetail;
}
export interface DeleteAccessPolicyRequest {
    type: string;
    name: string;
    clientToken?: string;
}
export interface DeleteAccessPolicyResponse {
}
export interface DeleteCollectionRequest {
    id: string;
    clientToken?: string;
}
export interface DeleteCollectionDetail {
    id?: string;
    name?: string;
    status?: string;
    deletionProtection?: string;
}
export interface DeleteCollectionResponse {
    deleteCollectionDetail?: DeleteCollectionDetail;
}
export interface DeleteCollectionGroupRequest {
    id: string;
    clientToken?: string;
}
export interface DeleteCollectionGroupResponse {
}
export interface DeleteIndexRequest {
    id: string;
    indexName: string;
}
export interface DeleteIndexResponse {
}
export interface DeleteLifecyclePolicyRequest {
    type: string;
    name: string;
    clientToken?: string;
}
export interface DeleteLifecyclePolicyResponse {
}
export interface DeleteSecurityConfigRequest {
    id: string;
    clientToken?: string;
}
export interface DeleteSecurityConfigResponse {
}
export interface DeleteSecurityPolicyRequest {
    type: string;
    name: string;
    clientToken?: string;
}
export interface DeleteSecurityPolicyResponse {
}
export interface DeleteVpcEndpointRequest {
    id: string;
    clientToken?: string;
}
export interface DeleteVpcEndpointDetail {
    id?: string;
    name?: string;
    status?: string;
}
export interface DeleteVpcEndpointResponse {
    deleteVpcEndpointDetail?: DeleteVpcEndpointDetail;
}
export interface GetAccessPolicyRequest {
    type: string;
    name: string;
}
export interface GetAccessPolicyResponse {
    accessPolicyDetail?: AccessPolicyDetail;
}
export interface GetAccountSettingsRequest {
}
export type IndexingCapacityValue = number;
export type SearchCapacityValue = number;
export interface CapacityLimits {
    maxIndexingCapacityInOCU?: number;
    maxSearchCapacityInOCU?: number;
}
export interface AccountSettingsDetail {
    capacityLimits?: CapacityLimits;
}
export interface GetAccountSettingsResponse {
    accountSettingsDetail?: AccountSettingsDetail;
}
export interface GetIndexRequest {
    id: string;
    indexName: string;
}
export interface GetIndexResponse {
    indexSchema?: any;
}
export interface GetPoliciesStatsRequest {
}
export interface AccessPolicyStats {
    DataPolicyCount?: number;
}
export interface SecurityPolicyStats {
    EncryptionPolicyCount?: number;
    NetworkPolicyCount?: number;
}
export interface SecurityConfigStats {
    SamlConfigCount?: number;
}
export interface LifecyclePolicyStats {
    RetentionPolicyCount?: number;
}
export interface GetPoliciesStatsResponse {
    AccessPolicyStats?: AccessPolicyStats;
    SecurityPolicyStats?: SecurityPolicyStats;
    SecurityConfigStats?: SecurityConfigStats;
    LifecyclePolicyStats?: LifecyclePolicyStats;
    TotalPolicyCount?: number;
}
export interface GetSecurityConfigRequest {
    id: string;
}
export interface GetSecurityConfigResponse {
    securityConfigDetail?: SecurityConfigDetail;
}
export interface GetSecurityPolicyRequest {
    type: string;
    name: string;
}
export interface GetSecurityPolicyResponse {
    securityPolicyDetail?: SecurityPolicyDetail;
}
export type ResourceFilter = string[];
export interface ListAccessPoliciesRequest {
    type: string;
    resource?: string[];
    nextToken?: string;
    maxResults?: number;
}
export interface AccessPolicySummary {
    type?: string;
    name?: string;
    policyVersion?: string;
    description?: string;
    createdDate?: number;
    lastModifiedDate?: number;
}
export type AccessPolicySummaries = AccessPolicySummary[];
export interface ListAccessPoliciesResponse {
    accessPolicySummaries?: AccessPolicySummary[];
    nextToken?: string;
}
export interface ListCollectionGroupsRequest {
    nextToken?: string;
    maxResults?: number;
}
export interface CollectionGroupSummary {
    id?: string;
    arn?: string;
    name?: string;
    numberOfCollections?: number;
    createdDate?: number;
    capacityLimits?: CollectionGroupCapacityLimits;
    generation?: string;
}
export type CollectionGroupSummaries = CollectionGroupSummary[];
export interface ListCollectionGroupsResponse {
    collectionGroupSummaries?: CollectionGroupSummary[];
    nextToken?: string;
}
export interface CollectionFilters {
    name?: string;
    status?: string;
    collectionGroupName?: string;
}
export interface ListCollectionsRequest {
    collectionFilters?: CollectionFilters;
    nextToken?: string;
    maxResults?: number;
}
export interface CollectionSummary {
    id?: string;
    name?: string;
    status?: string;
    arn?: string;
    kmsKeyArn?: string;
    collectionGroupName?: string;
}
export type CollectionSummaries = CollectionSummary[];
export interface ListCollectionsResponse {
    collectionSummaries?: CollectionSummary[];
    nextToken?: string;
}
export type LifecycleResource = string;
export type LifecycleResourceFilter = string[];
export interface ListLifecyclePoliciesRequest {
    type: string;
    resources?: string[];
    nextToken?: string;
    maxResults?: number;
}
export interface LifecyclePolicySummary {
    type?: string;
    name?: string;
    policyVersion?: string;
    description?: string;
    createdDate?: number;
    lastModifiedDate?: number;
}
export type LifecyclePolicySummaries = LifecyclePolicySummary[];
export interface ListLifecyclePoliciesResponse {
    lifecyclePolicySummaries?: LifecyclePolicySummary[];
    nextToken?: string;
}
export interface ListSecurityConfigsRequest {
    type: string;
    nextToken?: string;
    maxResults?: number;
}
export interface SecurityConfigSummary {
    id?: string;
    type?: string;
    configVersion?: string;
    description?: string;
    createdDate?: number;
    lastModifiedDate?: number;
}
export type SecurityConfigSummaries = SecurityConfigSummary[];
export interface ListSecurityConfigsResponse {
    securityConfigSummaries?: SecurityConfigSummary[];
    nextToken?: string;
}
export interface ListSecurityPoliciesRequest {
    type: string;
    resource?: string[];
    nextToken?: string;
    maxResults?: number;
}
export interface SecurityPolicySummary {
    type?: string;
    name?: string;
    policyVersion?: string;
    description?: string;
    createdDate?: number;
    lastModifiedDate?: number;
}
export type SecurityPolicySummaries = SecurityPolicySummary[];
export interface ListSecurityPoliciesResponse {
    securityPolicySummaries?: SecurityPolicySummary[];
    nextToken?: string;
}
export type Arn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[];
}
export interface VpcEndpointFilters {
    status?: string;
}
export interface ListVpcEndpointsRequest {
    vpcEndpointFilters?: VpcEndpointFilters;
    nextToken?: string;
    maxResults?: number;
}
export interface VpcEndpointSummary {
    id?: string;
    name?: string;
    status?: string;
}
export type VpcEndpointSummaries = VpcEndpointSummary[];
export interface ListVpcEndpointsResponse {
    vpcEndpointSummaries?: VpcEndpointSummary[];
    nextToken?: string;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAccessPolicyRequest {
    type: string;
    name: string;
    policyVersion: string;
    description?: string;
    policy?: string;
    clientToken?: string;
}
export interface UpdateAccessPolicyResponse {
    accessPolicyDetail?: AccessPolicyDetail;
}
export interface UpdateAccountSettingsRequest {
    capacityLimits?: CapacityLimits;
}
export interface UpdateAccountSettingsResponse {
    accountSettingsDetail?: AccountSettingsDetail;
}
export interface UpdateCollectionRequest {
    id: string;
    description?: string;
    vectorOptions?: VectorOptions;
    deletionProtection?: string;
    clientToken?: string;
}
export interface UpdateCollectionDetail {
    id?: string;
    name?: string;
    status?: string;
    type?: string;
    description?: string;
    vectorOptions?: VectorOptions;
    arn?: string;
    createdDate?: number;
    lastModifiedDate?: number;
    deletionProtection?: string;
}
export interface UpdateCollectionResponse {
    updateCollectionDetail?: UpdateCollectionDetail;
}
export interface UpdateCollectionGroupRequest {
    id: string;
    description?: string;
    capacityLimits?: CollectionGroupCapacityLimits;
    clientToken?: string;
}
export interface UpdateCollectionGroupDetail {
    id?: string;
    arn?: string;
    name?: string;
    description?: string;
    capacityLimits?: CollectionGroupCapacityLimits;
    createdDate?: number;
    lastModifiedDate?: number;
    generation?: string;
}
export interface UpdateCollectionGroupResponse {
    updateCollectionGroupDetail?: UpdateCollectionGroupDetail;
}
export interface UpdateIndexRequest {
    id: string;
    indexName: string;
    indexSchema?: any;
}
export interface UpdateIndexResponse {
}
export interface UpdateLifecyclePolicyRequest {
    type: string;
    name: string;
    policyVersion: string;
    description?: string;
    policy?: string;
    clientToken?: string;
}
export interface UpdateLifecyclePolicyResponse {
    lifecyclePolicyDetail?: LifecyclePolicyDetail;
}
export interface UpdateIamIdentityCenterConfigOptions {
    userAttribute?: string;
    groupAttribute?: string;
}
export interface UpdateSecurityConfigRequest {
    id: string;
    configVersion: string;
    description?: string;
    samlOptions?: SamlConfigOptions;
    iamIdentityCenterOptionsUpdates?: UpdateIamIdentityCenterConfigOptions;
    iamFederationOptions?: IamFederationConfigOptions;
    clientToken?: string;
}
export interface UpdateSecurityConfigResponse {
    securityConfigDetail?: SecurityConfigDetail;
}
export interface UpdateSecurityPolicyRequest {
    type: string;
    name: string;
    policyVersion: string;
    description?: string;
    policy?: string;
    clientToken?: string;
}
export interface UpdateSecurityPolicyResponse {
    securityPolicyDetail?: SecurityPolicyDetail;
}
export interface UpdateVpcEndpointRequest {
    id: string;
    addSubnetIds?: string[];
    removeSubnetIds?: string[];
    addSecurityGroupIds?: string[];
    removeSecurityGroupIds?: string[];
    clientToken?: string;
}
export interface UpdateVpcEndpointDetail {
    id?: string;
    name?: string;
    status?: string;
    subnetIds?: string[];
    securityGroupIds?: string[];
    lastModifiedDate?: number;
}
export interface UpdateVpcEndpointResponse {
    UpdateVpcEndpointDetail?: UpdateVpcEndpointDetail;
}
export type BatchGetCollectionError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns attributes for one or more collections, including the collection endpoint, the OpenSearch Dashboards endpoint, and FIPS-compliant endpoints. For more information, see Creating and managing Amazon OpenSearch Serverless collections.
 */
export declare const batchGetCollection: API.OperationMethod<BatchGetCollectionRequest, BatchGetCollectionResponse, BatchGetCollectionError, Credentials | HttpClient.HttpClient>;
export type BatchGetCollectionGroupError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns attributes for one or more collection groups, including capacity limits and the number of collections in each group. For more information, see Creating and managing Amazon OpenSearch Serverless collections.
 */
export declare const batchGetCollectionGroup: API.OperationMethod<BatchGetCollectionGroupRequest, BatchGetCollectionGroupResponse, BatchGetCollectionGroupError, Credentials | HttpClient.HttpClient>;
export type BatchGetEffectiveLifecyclePolicyError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of successful and failed retrievals for the OpenSearch Serverless indexes. For more information, see Viewing data lifecycle policies.
 */
export declare const batchGetEffectiveLifecyclePolicy: API.OperationMethod<BatchGetEffectiveLifecyclePolicyRequest, BatchGetEffectiveLifecyclePolicyResponse, BatchGetEffectiveLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type BatchGetLifecyclePolicyError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns one or more configured OpenSearch Serverless lifecycle policies. For more information, see Viewing data lifecycle policies.
 */
export declare const batchGetLifecyclePolicy: API.OperationMethod<BatchGetLifecyclePolicyRequest, BatchGetLifecyclePolicyResponse, BatchGetLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type BatchGetVpcEndpointError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns attributes for one or more VPC endpoints associated with the current account. For more information, see Access Amazon OpenSearch Serverless using an interface endpoint.
 */
export declare const batchGetVpcEndpoint: API.OperationMethod<BatchGetVpcEndpointRequest, BatchGetVpcEndpointResponse, BatchGetVpcEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateAccessPolicyError = ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a data access policy for OpenSearch Serverless. Access policies limit access to collections and the resources within them, and allow a user to access that data irrespective of the access mechanism or network source. For more information, see Data access control for Amazon OpenSearch Serverless.
 */
export declare const createAccessPolicy: API.OperationMethod<CreateAccessPolicyRequest, CreateAccessPolicyResponse, CreateAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateCollectionError = ConflictException | InternalServerException | OcuLimitExceededException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a new OpenSearch Serverless collection. For more information, see Creating and managing Amazon OpenSearch Serverless collections.
 */
export declare const createCollection: API.OperationMethod<CreateCollectionRequest, CreateCollectionResponse, CreateCollectionError, Credentials | HttpClient.HttpClient>;
export type CreateCollectionGroupError = ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a collection group within OpenSearch Serverless. Collection groups let you manage OpenSearch Compute Units (OCUs) at a group level, with multiple collections sharing the group's capacity limits.
 *
 * For more information, see Managing collection groups.
 */
export declare const createCollectionGroup: API.OperationMethod<CreateCollectionGroupRequest, CreateCollectionGroupResponse, CreateCollectionGroupError, Credentials | HttpClient.HttpClient>;
export type CreateIndexError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates an index within an OpenSearch Serverless collection. Unlike other OpenSearch indexes, indexes created by this API are automatically configured to conduct automatic semantic enrichment ingestion and search. For more information, see About automatic semantic enrichment in the *OpenSearch User Guide*.
 */
export declare const createIndex: API.OperationMethod<CreateIndexRequest, CreateIndexResponse, CreateIndexError, Credentials | HttpClient.HttpClient>;
export type CreateLifecyclePolicyError = ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a lifecyle policy to be applied to OpenSearch Serverless indexes. Lifecycle policies define the number of days or hours to retain the data on an OpenSearch Serverless index. For more information, see Creating data lifecycle policies.
 */
export declare const createLifecyclePolicy: API.OperationMethod<CreateLifecyclePolicyRequest, CreateLifecyclePolicyResponse, CreateLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type CreateSecurityConfigError = ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Specifies a security configuration for OpenSearch Serverless. For more information, see SAML authentication for Amazon OpenSearch Serverless.
 */
export declare const createSecurityConfig: API.OperationMethod<CreateSecurityConfigRequest, CreateSecurityConfigResponse, CreateSecurityConfigError, Credentials | HttpClient.HttpClient>;
export type CreateSecurityPolicyError = ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a security policy to be used by one or more OpenSearch Serverless collections. Security policies provide access to a collection and its OpenSearch Dashboards endpoint from public networks or specific VPC endpoints. They also allow you to secure a collection with a KMS encryption key. For more information, see Network access for Amazon OpenSearch Serverless and Encryption at rest for Amazon OpenSearch Serverless.
 */
export declare const createSecurityPolicy: API.OperationMethod<CreateSecurityPolicyRequest, CreateSecurityPolicyResponse, CreateSecurityPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateVpcEndpointError = ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates an OpenSearch Serverless-managed interface VPC endpoint. For more information, see Access Amazon OpenSearch Serverless using an interface endpoint.
 */
export declare const createVpcEndpoint: API.OperationMethod<CreateVpcEndpointRequest, CreateVpcEndpointResponse, CreateVpcEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessPolicyError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an OpenSearch Serverless access policy. For more information, see Data access control for Amazon OpenSearch Serverless.
 */
export declare const deleteAccessPolicy: API.OperationMethod<DeleteAccessPolicyRequest, DeleteAccessPolicyResponse, DeleteAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteCollectionError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an OpenSearch Serverless collection. For more information, see Creating and managing Amazon OpenSearch Serverless collections.
 */
export declare const deleteCollection: API.OperationMethod<DeleteCollectionRequest, DeleteCollectionResponse, DeleteCollectionError, Credentials | HttpClient.HttpClient>;
export type DeleteCollectionGroupError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a collection group. You can only delete empty collection groups that contain no collections. For more information, see Creating and managing Amazon OpenSearch Serverless collections.
 */
export declare const deleteCollectionGroup: API.OperationMethod<DeleteCollectionGroupRequest, DeleteCollectionGroupResponse, DeleteCollectionGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteIndexError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an index from an OpenSearch Serverless collection. Be aware that the index might be configured to conduct automatic semantic enrichment ingestion and search. For more information, see About automatic semantic enrichment.
 */
export declare const deleteIndex: API.OperationMethod<DeleteIndexRequest, DeleteIndexResponse, DeleteIndexError, Credentials | HttpClient.HttpClient>;
export type DeleteLifecyclePolicyError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an OpenSearch Serverless lifecycle policy. For more information, see Deleting data lifecycle policies.
 */
export declare const deleteLifecyclePolicy: API.OperationMethod<DeleteLifecyclePolicyRequest, DeleteLifecyclePolicyResponse, DeleteLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteSecurityConfigError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a security configuration for OpenSearch Serverless. For more information, see SAML authentication for Amazon OpenSearch Serverless.
 */
export declare const deleteSecurityConfig: API.OperationMethod<DeleteSecurityConfigRequest, DeleteSecurityConfigResponse, DeleteSecurityConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteSecurityPolicyError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an OpenSearch Serverless security policy.
 */
export declare const deleteSecurityPolicy: API.OperationMethod<DeleteSecurityPolicyRequest, DeleteSecurityPolicyResponse, DeleteSecurityPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcEndpointError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an OpenSearch Serverless-managed interface endpoint. For more information, see Access Amazon OpenSearch Serverless using an interface endpoint.
 */
export declare const deleteVpcEndpoint: API.OperationMethod<DeleteVpcEndpointRequest, DeleteVpcEndpointResponse, DeleteVpcEndpointError, Credentials | HttpClient.HttpClient>;
export type GetAccessPolicyError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns an OpenSearch Serverless access policy. For more information, see Data access control for Amazon OpenSearch Serverless.
 */
export declare const getAccessPolicy: API.OperationMethod<GetAccessPolicyRequest, GetAccessPolicyResponse, GetAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type GetAccountSettingsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns account-level settings related to OpenSearch Serverless.
 */
export declare const getAccountSettings: API.OperationMethod<GetAccountSettingsRequest, GetAccountSettingsResponse, GetAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type GetIndexError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves information about an index in an OpenSearch Serverless collection, including its schema definition. The index might be configured to conduct automatic semantic enrichment ingestion and search. For more information, see About automatic semantic enrichment.
 */
export declare const getIndex: API.OperationMethod<GetIndexRequest, GetIndexResponse, GetIndexError, Credentials | HttpClient.HttpClient>;
export type GetPoliciesStatsError = InternalServerException | CommonErrors;
/**
 * Returns statistical information about your OpenSearch Serverless access policies, security configurations, and security policies.
 */
export declare const getPoliciesStats: API.OperationMethod<GetPoliciesStatsRequest, GetPoliciesStatsResponse, GetPoliciesStatsError, Credentials | HttpClient.HttpClient>;
export type GetSecurityConfigError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about an OpenSearch Serverless security configuration. For more information, see SAML authentication for Amazon OpenSearch Serverless.
 */
export declare const getSecurityConfig: API.OperationMethod<GetSecurityConfigRequest, GetSecurityConfigResponse, GetSecurityConfigError, Credentials | HttpClient.HttpClient>;
export type GetSecurityPolicyError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a configured OpenSearch Serverless security policy. For more information, see Network access for Amazon OpenSearch Serverless and Encryption at rest for Amazon OpenSearch Serverless.
 */
export declare const getSecurityPolicy: API.OperationMethod<GetSecurityPolicyRequest, GetSecurityPolicyResponse, GetSecurityPolicyError, Credentials | HttpClient.HttpClient>;
export type ListAccessPoliciesError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns information about a list of OpenSearch Serverless access policies.
 */
export declare const listAccessPolicies: API.PaginatedOperationMethod<ListAccessPoliciesRequest, ListAccessPoliciesResponse, ListAccessPoliciesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListCollectionGroupsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of collection groups. For more information, see Creating and managing Amazon OpenSearch Serverless collections.
 */
export declare const listCollectionGroups: API.PaginatedOperationMethod<ListCollectionGroupsRequest, ListCollectionGroupsResponse, ListCollectionGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListCollectionsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists all OpenSearch Serverless collections. For more information, see Creating and managing Amazon OpenSearch Serverless collections.
 *
 * Make sure to include an empty request body {} if you don't include any collection filters in the request.
 */
export declare const listCollections: API.PaginatedOperationMethod<ListCollectionsRequest, ListCollectionsResponse, ListCollectionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListLifecyclePoliciesError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of OpenSearch Serverless lifecycle policies. For more information, see Viewing data lifecycle policies.
 */
export declare const listLifecyclePolicies: API.PaginatedOperationMethod<ListLifecyclePoliciesRequest, ListLifecyclePoliciesResponse, ListLifecyclePoliciesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSecurityConfigsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns information about configured OpenSearch Serverless security configurations. For more information, see SAML authentication for Amazon OpenSearch Serverless.
 */
export declare const listSecurityConfigs: API.PaginatedOperationMethod<ListSecurityConfigsRequest, ListSecurityConfigsResponse, ListSecurityConfigsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSecurityPoliciesError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns information about configured OpenSearch Serverless security policies.
 */
export declare const listSecurityPolicies: API.PaginatedOperationMethod<ListSecurityPoliciesRequest, ListSecurityPoliciesResponse, ListSecurityPoliciesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the tags for an OpenSearch Serverless resource. For more information, see Tagging Amazon OpenSearch Serverless collections.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVpcEndpointsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns the OpenSearch Serverless-managed interface VPC endpoints associated with the current account. For more information, see Access Amazon OpenSearch Serverless using an interface endpoint.
 */
export declare const listVpcEndpoints: API.PaginatedOperationMethod<ListVpcEndpointsRequest, ListVpcEndpointsResponse, ListVpcEndpointsError, Credentials | HttpClient.HttpClient, unknown>;
export type TagResourceError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Associates tags with an OpenSearch Serverless resource. For more information, see Tagging Amazon OpenSearch Serverless collections.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a tag or set of tags from an OpenSearch Serverless resource. For more information, see Tagging Amazon OpenSearch Serverless collections.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccessPolicyError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates an OpenSearch Serverless access policy. For more information, see Data access control for Amazon OpenSearch Serverless.
 */
export declare const updateAccessPolicy: API.OperationMethod<UpdateAccessPolicyRequest, UpdateAccessPolicyResponse, UpdateAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountSettingsError = InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Update the OpenSearch Serverless settings for the current Amazon Web Services account. For more information, see Managing capacity limits for Amazon OpenSearch Serverless.
 */
export declare const updateAccountSettings: API.OperationMethod<UpdateAccountSettingsRequest, UpdateAccountSettingsResponse, UpdateAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateCollectionError = ConflictException | InternalServerException | ValidationException | CommonErrors;
/**
 * Updates an OpenSearch Serverless collection.
 */
export declare const updateCollection: API.OperationMethod<UpdateCollectionRequest, UpdateCollectionResponse, UpdateCollectionError, Credentials | HttpClient.HttpClient>;
export type UpdateCollectionGroupError = ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Updates the description and capacity limits of a collection group.
 */
export declare const updateCollectionGroup: API.OperationMethod<UpdateCollectionGroupRequest, UpdateCollectionGroupResponse, UpdateCollectionGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateIndexError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates an existing index in an OpenSearch Serverless collection. This operation allows you to modify the index schema, including adding new fields or changing field mappings. You can also enable automatic semantic enrichment ingestion and search. For more information, see About automatic semantic enrichment.
 */
export declare const updateIndex: API.OperationMethod<UpdateIndexRequest, UpdateIndexResponse, UpdateIndexError, Credentials | HttpClient.HttpClient>;
export type UpdateLifecyclePolicyError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Updates an OpenSearch Serverless access policy. For more information, see Updating data lifecycle policies.
 */
export declare const updateLifecyclePolicy: API.OperationMethod<UpdateLifecyclePolicyRequest, UpdateLifecyclePolicyResponse, UpdateLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateSecurityConfigError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a security configuration for OpenSearch Serverless. For more information, see SAML authentication for Amazon OpenSearch Serverless.
 */
export declare const updateSecurityConfig: API.OperationMethod<UpdateSecurityConfigRequest, UpdateSecurityConfigResponse, UpdateSecurityConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateSecurityPolicyError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Updates an OpenSearch Serverless security policy. For more information, see Network access for Amazon OpenSearch Serverless and Encryption at rest for Amazon OpenSearch Serverless.
 */
export declare const updateSecurityPolicy: API.OperationMethod<UpdateSecurityPolicyRequest, UpdateSecurityPolicyResponse, UpdateSecurityPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateVpcEndpointError = ConflictException | InternalServerException | ValidationException | CommonErrors;
/**
 * Updates an OpenSearch Serverless-managed interface endpoint. For more information, see Access Amazon OpenSearch Serverless using an interface endpoint.
 */
export declare const updateVpcEndpoint: API.OperationMethod<UpdateVpcEndpointRequest, UpdateVpcEndpointResponse, UpdateVpcEndpointError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=opensearchserverless.d.ts.map