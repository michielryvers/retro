import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SavingsPlanOfferingId = string;
export type Amount = string;
export type ClientToken = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateSavingsPlanRequest {
    savingsPlanOfferingId: string;
    commitment: string;
    upfrontPaymentAmount?: string;
    purchaseTime?: Date;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type SavingsPlanId = string;
export interface CreateSavingsPlanResponse {
    savingsPlanId?: string;
}
export interface DeleteQueuedSavingsPlanRequest {
    savingsPlanId: string;
}
export interface DeleteQueuedSavingsPlanResponse {
}
export type SavingsPlanRateFilterName = "region" | "instanceType" | "productDescription" | "tenancy" | "productType" | "serviceCode" | "usageType" | "operation" | (string & {});
export type ListOfStrings = string[];
export interface SavingsPlanRateFilter {
    name?: SavingsPlanRateFilterName;
    values?: string[];
}
export type SavingsPlanRateFilterList = SavingsPlanRateFilter[];
export type PaginationToken = string;
export type MaxResults = number;
export interface DescribeSavingsPlanRatesRequest {
    savingsPlanId: string;
    filters?: SavingsPlanRateFilter[];
    nextToken?: string;
    maxResults?: number;
}
export type CurrencyCode = "CNY" | "USD" | "EUR" | (string & {});
export type SavingsPlanRateUnit = "Hrs" | "Lambda-GB-Second" | "Request" | "ACU-Hr" | "ReadRequestUnits" | "WriteRequestUnits" | "ReadCapacityUnit-Hrs" | "WriteCapacityUnit-Hrs" | "ReplicatedWriteRequestUnits" | "ReplicatedWriteCapacityUnit-Hrs" | "GB-Hours" | "DPU" | "ElastiCacheProcessingUnit" | "DCU-Hr" | "NCU-hr" | "OCU-hours" | "Jobs" | (string & {});
export type SavingsPlanProductType = "EC2" | "Fargate" | "Lambda" | "SageMaker" | "RDS" | "DSQL" | "DynamoDB" | "ElastiCache" | "DocDB" | "Neptune" | "Timestream" | "Keyspaces" | "DMS" | "OpenSearch" | (string & {});
export type SavingsPlanRateServiceCode = "AmazonEC2" | "AmazonECS" | "AmazonEKS" | "AWSLambda" | "AmazonSageMaker" | "AmazonRDS" | "AuroraDSQL" | "AmazonDynamoDB" | "AmazonElastiCache" | "AmazonDocDB" | "AmazonNeptune" | "AmazonTimestream" | "AmazonMCS" | "AWSDatabaseMigrationSvc" | "AmazonES" | (string & {});
export type SavingsPlanRateUsageType = string;
export type SavingsPlanRateOperation = string;
export type SavingsPlanRatePropertyKey = "region" | "instanceType" | "instanceFamily" | "productDescription" | "tenancy" | (string & {});
export type JsonSafeFilterValueString = string;
export interface SavingsPlanRateProperty {
    name?: SavingsPlanRatePropertyKey;
    value?: string;
}
export type SavingsPlanRatePropertyList = SavingsPlanRateProperty[];
export interface SavingsPlanRate {
    rate?: string;
    currency?: CurrencyCode;
    unit?: SavingsPlanRateUnit;
    productType?: SavingsPlanProductType;
    serviceCode?: SavingsPlanRateServiceCode;
    usageType?: string;
    operation?: string;
    properties?: SavingsPlanRateProperty[];
}
export type SavingsPlanRateList = SavingsPlanRate[];
export interface DescribeSavingsPlanRatesResponse {
    savingsPlanId?: string;
    searchResults?: SavingsPlanRate[];
    nextToken?: string;
}
export type SavingsPlanArn = string;
export type SavingsPlanArnList = string[];
export type SavingsPlanIdList = string[];
export type SavingsPlanState = "payment-pending" | "payment-failed" | "active" | "retired" | "queued" | "queued-deleted" | "pending-return" | "returned" | (string & {});
export type SavingsPlanStateList = SavingsPlanState[];
export type SavingsPlansFilterName = "region" | "ec2-instance-family" | "commitment" | "upfront" | "term" | "savings-plan-type" | "payment-option" | "start" | "end" | "instance-family" | (string & {});
export interface SavingsPlanFilter {
    name?: SavingsPlansFilterName;
    values?: string[];
}
export type SavingsPlanFilterList = SavingsPlanFilter[];
export interface DescribeSavingsPlansRequest {
    savingsPlanArns?: string[];
    savingsPlanIds?: string[];
    nextToken?: string;
    maxResults?: number;
    states?: SavingsPlanState[];
    filters?: SavingsPlanFilter[];
}
export type Region = string;
export type EC2InstanceFamily = string;
export type SavingsPlanType = "Compute" | "EC2Instance" | "SageMaker" | "Database" | (string & {});
export type SavingsPlanPaymentOption = "All Upfront" | "Partial Upfront" | "No Upfront" | (string & {});
export type SavingsPlanProductTypeList = SavingsPlanProductType[];
export type TermDurationInSeconds = number;
export interface SavingsPlan {
    offeringId?: string;
    savingsPlanId?: string;
    savingsPlanArn?: string;
    description?: string;
    start?: string;
    end?: string;
    state?: SavingsPlanState;
    region?: string;
    ec2InstanceFamily?: string;
    savingsPlanType?: SavingsPlanType;
    paymentOption?: SavingsPlanPaymentOption;
    productTypes?: SavingsPlanProductType[];
    currency?: CurrencyCode;
    commitment?: string;
    upfrontPaymentAmount?: string;
    recurringPaymentAmount?: string;
    termDurationInSeconds?: number;
    tags?: {
        [key: string]: string | undefined;
    };
    returnableUntil?: string;
}
export type SavingsPlanList = SavingsPlan[];
export interface DescribeSavingsPlansResponse {
    savingsPlans?: SavingsPlan[];
    nextToken?: string;
}
export type UUID = string;
export type UUIDs = string[];
export type SavingsPlanPaymentOptionList = SavingsPlanPaymentOption[];
export type SavingsPlanTypeList = SavingsPlanType[];
export type SavingsPlanRateServiceCodeList = SavingsPlanRateServiceCode[];
export type SavingsPlanRateUsageTypeList = string[];
export type SavingsPlanRateOperationList = string[];
export type SavingsPlanRateFilterAttribute = "region" | "instanceFamily" | "instanceType" | "productDescription" | "tenancy" | "productId" | (string & {});
export type FilterValuesList = string[];
export interface SavingsPlanOfferingRateFilterElement {
    name?: SavingsPlanRateFilterAttribute;
    values?: string[];
}
export type SavingsPlanOfferingRateFiltersList = SavingsPlanOfferingRateFilterElement[];
export type PageSize = number;
export interface DescribeSavingsPlansOfferingRatesRequest {
    savingsPlanOfferingIds?: string[];
    savingsPlanPaymentOptions?: SavingsPlanPaymentOption[];
    savingsPlanTypes?: SavingsPlanType[];
    products?: SavingsPlanProductType[];
    serviceCodes?: SavingsPlanRateServiceCode[];
    usageTypes?: string[];
    operations?: string[];
    filters?: SavingsPlanOfferingRateFilterElement[];
    nextToken?: string;
    maxResults?: number;
}
export type SavingsPlansDuration = number;
export type SavingsPlanDescription = string;
export interface ParentSavingsPlanOffering {
    offeringId?: string;
    paymentOption?: SavingsPlanPaymentOption;
    planType?: SavingsPlanType;
    durationSeconds?: number;
    currency?: CurrencyCode;
    planDescription?: string;
}
export type SavingsPlanRatePricePerUnit = string;
export interface SavingsPlanOfferingRateProperty {
    name?: string;
    value?: string;
}
export type SavingsPlanOfferingRatePropertyList = SavingsPlanOfferingRateProperty[];
export interface SavingsPlanOfferingRate {
    savingsPlanOffering?: ParentSavingsPlanOffering;
    rate?: string;
    unit?: SavingsPlanRateUnit;
    productType?: SavingsPlanProductType;
    serviceCode?: SavingsPlanRateServiceCode;
    usageType?: string;
    operation?: string;
    properties?: SavingsPlanOfferingRateProperty[];
}
export type SavingsPlanOfferingRatesList = SavingsPlanOfferingRate[];
export interface DescribeSavingsPlansOfferingRatesResponse {
    searchResults?: SavingsPlanOfferingRate[];
    nextToken?: string;
}
export type DurationsList = number[];
export type CurrencyList = CurrencyCode[];
export type SavingsPlanDescriptionsList = string[];
export type SavingsPlanServiceCode = string;
export type SavingsPlanServiceCodeList = string[];
export type SavingsPlanUsageType = string;
export type SavingsPlanUsageTypeList = string[];
export type SavingsPlanOperation = string;
export type SavingsPlanOperationList = string[];
export type SavingsPlanOfferingFilterAttribute = "region" | "instanceFamily" | (string & {});
export interface SavingsPlanOfferingFilterElement {
    name?: SavingsPlanOfferingFilterAttribute;
    values?: string[];
}
export type SavingsPlanOfferingFiltersList = SavingsPlanOfferingFilterElement[];
export interface DescribeSavingsPlansOfferingsRequest {
    offeringIds?: string[];
    paymentOptions?: SavingsPlanPaymentOption[];
    productType?: SavingsPlanProductType;
    planTypes?: SavingsPlanType[];
    durations?: number[];
    currencies?: CurrencyCode[];
    descriptions?: string[];
    serviceCodes?: string[];
    usageTypes?: string[];
    operations?: string[];
    filters?: SavingsPlanOfferingFilterElement[];
    nextToken?: string;
    maxResults?: number;
}
export type SavingsPlanOfferingPropertyKey = "region" | "instanceFamily" | (string & {});
export interface SavingsPlanOfferingProperty {
    name?: SavingsPlanOfferingPropertyKey;
    value?: string;
}
export type SavingsPlanOfferingPropertyList = SavingsPlanOfferingProperty[];
export interface SavingsPlanOffering {
    offeringId?: string;
    productTypes?: SavingsPlanProductType[];
    planType?: SavingsPlanType;
    description?: string;
    paymentOption?: SavingsPlanPaymentOption;
    durationSeconds?: number;
    currency?: CurrencyCode;
    serviceCode?: string;
    usageType?: string;
    operation?: string;
    properties?: SavingsPlanOfferingProperty[];
}
export type SavingsPlanOfferingsList = SavingsPlanOffering[];
export interface DescribeSavingsPlansOfferingsResponse {
    searchResults?: SavingsPlanOffering[];
    nextToken?: string;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface ReturnSavingsPlanRequest {
    savingsPlanId: string;
    clientToken?: string;
}
export interface ReturnSavingsPlanResponse {
    savingsPlanId?: string;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export type CreateSavingsPlanError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a Savings Plan.
 */
export declare const createSavingsPlan: API.OperationMethod<CreateSavingsPlanRequest, CreateSavingsPlanResponse, CreateSavingsPlanError, Credentials | HttpClient.HttpClient>;
export type DeleteQueuedSavingsPlanError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Deletes the queued purchase for the specified Savings Plan.
 */
export declare const deleteQueuedSavingsPlan: API.OperationMethod<DeleteQueuedSavingsPlanRequest, DeleteQueuedSavingsPlanResponse, DeleteQueuedSavingsPlanError, Credentials | HttpClient.HttpClient>;
export type DescribeSavingsPlanRatesError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the rates for a specific, existing Savings Plan.
 */
export declare const describeSavingsPlanRates: API.OperationMethod<DescribeSavingsPlanRatesRequest, DescribeSavingsPlanRatesResponse, DescribeSavingsPlanRatesError, Credentials | HttpClient.HttpClient>;
export type DescribeSavingsPlansError = InternalServerException | ValidationException | CommonErrors;
/**
 * Describes the specified Savings Plans.
 */
export declare const describeSavingsPlans: API.OperationMethod<DescribeSavingsPlansRequest, DescribeSavingsPlansResponse, DescribeSavingsPlansError, Credentials | HttpClient.HttpClient>;
export type DescribeSavingsPlansOfferingRatesError = InternalServerException | ValidationException | CommonErrors;
/**
 * Describes the offering rates for Savings Plans you might want to purchase.
 */
export declare const describeSavingsPlansOfferingRates: API.OperationMethod<DescribeSavingsPlansOfferingRatesRequest, DescribeSavingsPlansOfferingRatesResponse, DescribeSavingsPlansOfferingRatesError, Credentials | HttpClient.HttpClient>;
export type DescribeSavingsPlansOfferingsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Describes the offerings for the specified Savings Plans.
 */
export declare const describeSavingsPlansOfferings: API.OperationMethod<DescribeSavingsPlansOfferingsRequest, DescribeSavingsPlansOfferingsResponse, DescribeSavingsPlansOfferingsError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ReturnSavingsPlanError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Returns the specified Savings Plan.
 */
export declare const returnSavingsPlan: API.OperationMethod<ReturnSavingsPlanRequest, ReturnSavingsPlanResponse, ReturnSavingsPlanError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Adds the specified tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes the specified tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=savingsplans.d.ts.map