import * as API from "@distilled.cloud/core/api";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
export type MetricName = string;
export type SageMakerResourceArn = string;
export type MetricStatistic = "Min" | "Max" | "Avg" | "Count" | "StdDev" | "Last" | (string & {});
export type Period = "OneMinute" | "FiveMinute" | "OneHour" | "IterationNumber" | (string & {});
export type XAxisType = "IterationNumber" | "Timestamp" | (string & {});
export interface MetricQuery {
    MetricName?: string;
    ResourceArn?: string;
    MetricStat?: MetricStatistic;
    Period?: Period;
    XAxisType?: XAxisType;
    Start?: number;
    End?: number;
}
export type MetricQueryList = MetricQuery[];
export interface BatchGetMetricsRequest {
    MetricQueries?: MetricQuery[];
}
export type MetricQueryResultStatus = "Complete" | "Truncated" | "InternalError" | "ValidationError" | (string & {});
export type Message = string;
export type XAxisValues = number[];
export type MetricValues = number[];
export interface MetricQueryResult {
    Status?: MetricQueryResultStatus;
    Message?: string;
    XAxisValues?: number[];
    MetricValues?: number[];
}
export type MetricQueryResultList = MetricQueryResult[];
export interface BatchGetMetricsResponse {
    MetricQueryResults?: (MetricQueryResult & {
        Status: MetricQueryResultStatus;
        XAxisValues: XAxisValues;
        MetricValues: MetricValues;
    })[];
}
export type ExperimentEntityName = string;
export type Step = number;
export interface RawMetricData {
    MetricName?: string;
    Timestamp?: Date;
    Step?: number;
    Value?: number;
}
export type RawMetricDataList = RawMetricData[];
export interface BatchPutMetricsRequest {
    TrialComponentName?: string;
    MetricData?: RawMetricData[];
}
export type PutMetricsErrorCode = "METRIC_LIMIT_EXCEEDED" | "INTERNAL_ERROR" | "VALIDATION_ERROR" | "CONFLICT_ERROR" | (string & {});
export interface BatchPutMetricsError_ {
    Code?: PutMetricsErrorCode;
    MetricIndex?: number;
}
export type BatchPutMetricsErrorList = BatchPutMetricsError_[];
export interface BatchPutMetricsResponse {
    Errors?: BatchPutMetricsError_[];
}
export type BatchGetMetricsError = CommonErrors;
/**
 * Used to retrieve training metrics from SageMaker.
 */
export declare const batchGetMetrics: API.OperationMethod<BatchGetMetricsRequest, BatchGetMetricsResponse, BatchGetMetricsError, Credentials | HttpClient.HttpClient>;
export type BatchPutMetricsError = CommonErrors;
/**
 * Used to ingest training metrics into SageMaker. These metrics can be visualized in SageMaker Studio.
 */
export declare const batchPutMetrics: API.OperationMethod<BatchPutMetricsRequest, BatchPutMetricsResponse, BatchPutMetricsError, Credentials | HttpClient.HttpClient>;
//# sourceMappingURL=sagemaker-metrics.d.ts.map