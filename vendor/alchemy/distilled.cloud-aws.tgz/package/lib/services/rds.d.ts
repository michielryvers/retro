import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AuthorizationAlreadyExistsFault_base: S.TaggedErrorClass<"AuthorizationAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AuthorizationAlreadyExistsFault extends /*@__PURE__*/ AuthorizationAlreadyExistsFault_base {
}
declare const AuthorizationNotFoundFault_base: S.TaggedErrorClass<"AuthorizationNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AuthorizationNotFoundFault extends /*@__PURE__*/ AuthorizationNotFoundFault_base {
}
declare const AuthorizationQuotaExceededFault_base: S.TaggedErrorClass<"AuthorizationQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AuthorizationQuotaExceededFault extends /*@__PURE__*/ AuthorizationQuotaExceededFault_base {
}
declare const BackupPolicyNotFoundFault_base: S.TaggedErrorClass<"BackupPolicyNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BackupPolicyNotFoundFault extends /*@__PURE__*/ BackupPolicyNotFoundFault_base {
}
declare const BlueGreenDeploymentAlreadyExistsFault_base: S.TaggedErrorClass<"BlueGreenDeploymentAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class BlueGreenDeploymentAlreadyExistsFault extends /*@__PURE__*/ BlueGreenDeploymentAlreadyExistsFault_base {
}
declare const BlueGreenDeploymentNotFoundFault_base: S.TaggedErrorClass<"BlueGreenDeploymentNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BlueGreenDeploymentNotFoundFault extends /*@__PURE__*/ BlueGreenDeploymentNotFoundFault_base {
}
declare const CertificateNotFoundFault_base: S.TaggedErrorClass<"CertificateNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CertificateNotFoundFault extends /*@__PURE__*/ CertificateNotFoundFault_base {
}
declare const CreateCustomDBEngineVersionFault_base: S.TaggedErrorClass<"CreateCustomDBEngineVersionFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CreateCustomDBEngineVersionFault extends /*@__PURE__*/ CreateCustomDBEngineVersionFault_base {
}
declare const CustomAvailabilityZoneNotFoundFault_base: S.TaggedErrorClass<"CustomAvailabilityZoneNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CustomAvailabilityZoneNotFoundFault extends /*@__PURE__*/ CustomAvailabilityZoneNotFoundFault_base {
}
declare const CustomDBEngineVersionAlreadyExistsFault_base: S.TaggedErrorClass<"CustomDBEngineVersionAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CustomDBEngineVersionAlreadyExistsFault extends /*@__PURE__*/ CustomDBEngineVersionAlreadyExistsFault_base {
}
declare const CustomDBEngineVersionNotFoundFault_base: S.TaggedErrorClass<"CustomDBEngineVersionNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CustomDBEngineVersionNotFoundFault extends /*@__PURE__*/ CustomDBEngineVersionNotFoundFault_base {
}
declare const CustomDBEngineVersionQuotaExceededFault_base: S.TaggedErrorClass<"CustomDBEngineVersionQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CustomDBEngineVersionQuotaExceededFault extends /*@__PURE__*/ CustomDBEngineVersionQuotaExceededFault_base {
}
declare const DBClusterAlreadyExistsFault_base: S.TaggedErrorClass<"DBClusterAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBClusterAlreadyExistsFault extends /*@__PURE__*/ DBClusterAlreadyExistsFault_base {
}
declare const DBClusterAutomatedBackupNotFoundFault_base: S.TaggedErrorClass<"DBClusterAutomatedBackupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterAutomatedBackupNotFoundFault extends /*@__PURE__*/ DBClusterAutomatedBackupNotFoundFault_base {
}
declare const DBClusterAutomatedBackupQuotaExceededFault_base: S.TaggedErrorClass<"DBClusterAutomatedBackupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterAutomatedBackupQuotaExceededFault extends /*@__PURE__*/ DBClusterAutomatedBackupQuotaExceededFault_base {
}
declare const DBClusterBacktrackNotFoundFault_base: S.TaggedErrorClass<"DBClusterBacktrackNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterBacktrackNotFoundFault extends /*@__PURE__*/ DBClusterBacktrackNotFoundFault_base {
}
declare const DBClusterEndpointAlreadyExistsFault_base: S.TaggedErrorClass<"DBClusterEndpointAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBClusterEndpointAlreadyExistsFault extends /*@__PURE__*/ DBClusterEndpointAlreadyExistsFault_base {
}
declare const DBClusterEndpointNotFoundFault_base: S.TaggedErrorClass<"DBClusterEndpointNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterEndpointNotFoundFault extends /*@__PURE__*/ DBClusterEndpointNotFoundFault_base {
}
declare const DBClusterEndpointQuotaExceededFault_base: S.TaggedErrorClass<"DBClusterEndpointQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class DBClusterEndpointQuotaExceededFault extends /*@__PURE__*/ DBClusterEndpointQuotaExceededFault_base {
}
declare const DBClusterNotFoundFault_base: S.TaggedErrorClass<"DBClusterNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class DBClusterNotFoundFault extends /*@__PURE__*/ DBClusterNotFoundFault_base {
}
declare const DBClusterParameterGroupNotFoundFault_base: S.TaggedErrorClass<"DBClusterParameterGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterParameterGroupNotFoundFault extends /*@__PURE__*/ DBClusterParameterGroupNotFoundFault_base {
}
declare const DBClusterQuotaExceededFault_base: S.TaggedErrorClass<"DBClusterQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class DBClusterQuotaExceededFault extends /*@__PURE__*/ DBClusterQuotaExceededFault_base {
}
declare const DBClusterRoleAlreadyExistsFault_base: S.TaggedErrorClass<"DBClusterRoleAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBClusterRoleAlreadyExistsFault extends /*@__PURE__*/ DBClusterRoleAlreadyExistsFault_base {
}
declare const DBClusterRoleNotFoundFault_base: S.TaggedErrorClass<"DBClusterRoleNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterRoleNotFoundFault extends /*@__PURE__*/ DBClusterRoleNotFoundFault_base {
}
declare const DBClusterRoleQuotaExceededFault_base: S.TaggedErrorClass<"DBClusterRoleQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterRoleQuotaExceededFault extends /*@__PURE__*/ DBClusterRoleQuotaExceededFault_base {
}
declare const DBClusterSnapshotAlreadyExistsFault_base: S.TaggedErrorClass<"DBClusterSnapshotAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBClusterSnapshotAlreadyExistsFault extends /*@__PURE__*/ DBClusterSnapshotAlreadyExistsFault_base {
}
declare const DBClusterSnapshotNotFoundFault_base: S.TaggedErrorClass<"DBClusterSnapshotNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterSnapshotNotFoundFault extends /*@__PURE__*/ DBClusterSnapshotNotFoundFault_base {
}
declare const DBInstanceAlreadyExistsFault_base: S.TaggedErrorClass<"DBInstanceAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBInstanceAlreadyExistsFault extends /*@__PURE__*/ DBInstanceAlreadyExistsFault_base {
}
declare const DBInstanceAutomatedBackupNotFoundFault_base: S.TaggedErrorClass<"DBInstanceAutomatedBackupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBInstanceAutomatedBackupNotFoundFault extends /*@__PURE__*/ DBInstanceAutomatedBackupNotFoundFault_base {
}
declare const DBInstanceAutomatedBackupQuotaExceededFault_base: S.TaggedErrorClass<"DBInstanceAutomatedBackupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBInstanceAutomatedBackupQuotaExceededFault extends /*@__PURE__*/ DBInstanceAutomatedBackupQuotaExceededFault_base {
}
declare const DBInstanceNotFoundFault_base: S.TaggedErrorClass<"DBInstanceNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBInstanceNotFoundFault extends /*@__PURE__*/ DBInstanceNotFoundFault_base {
}
declare const DBInstanceNotReadyFault_base: S.TaggedErrorClass<"DBInstanceNotReadyFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBInstanceNotReadyFault extends /*@__PURE__*/ DBInstanceNotReadyFault_base {
}
declare const DBInstanceRoleAlreadyExistsFault_base: S.TaggedErrorClass<"DBInstanceRoleAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBInstanceRoleAlreadyExistsFault extends /*@__PURE__*/ DBInstanceRoleAlreadyExistsFault_base {
}
declare const DBInstanceRoleNotFoundFault_base: S.TaggedErrorClass<"DBInstanceRoleNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBInstanceRoleNotFoundFault extends /*@__PURE__*/ DBInstanceRoleNotFoundFault_base {
}
declare const DBInstanceRoleQuotaExceededFault_base: S.TaggedErrorClass<"DBInstanceRoleQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBInstanceRoleQuotaExceededFault extends /*@__PURE__*/ DBInstanceRoleQuotaExceededFault_base {
}
declare const DBLogFileNotFoundFault_base: S.TaggedErrorClass<"DBLogFileNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBLogFileNotFoundFault extends /*@__PURE__*/ DBLogFileNotFoundFault_base {
}
declare const DBParameterGroupAlreadyExistsFault_base: S.TaggedErrorClass<"DBParameterGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBParameterGroupAlreadyExistsFault extends /*@__PURE__*/ DBParameterGroupAlreadyExistsFault_base {
}
declare const DBParameterGroupNotFoundFault_base: S.TaggedErrorClass<"DBParameterGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class DBParameterGroupNotFoundFault extends /*@__PURE__*/ DBParameterGroupNotFoundFault_base {
}
declare const DBParameterGroupQuotaExceededFault_base: S.TaggedErrorClass<"DBParameterGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBParameterGroupQuotaExceededFault extends /*@__PURE__*/ DBParameterGroupQuotaExceededFault_base {
}
declare const DBProxyAlreadyExistsFault_base: S.TaggedErrorClass<"DBProxyAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBProxyAlreadyExistsFault extends /*@__PURE__*/ DBProxyAlreadyExistsFault_base {
}
declare const DBProxyEndpointAlreadyExistsFault_base: S.TaggedErrorClass<"DBProxyEndpointAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBProxyEndpointAlreadyExistsFault extends /*@__PURE__*/ DBProxyEndpointAlreadyExistsFault_base {
}
declare const DBProxyEndpointNotFoundFault_base: S.TaggedErrorClass<"DBProxyEndpointNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBProxyEndpointNotFoundFault extends /*@__PURE__*/ DBProxyEndpointNotFoundFault_base {
}
declare const DBProxyEndpointQuotaExceededFault_base: S.TaggedErrorClass<"DBProxyEndpointQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBProxyEndpointQuotaExceededFault extends /*@__PURE__*/ DBProxyEndpointQuotaExceededFault_base {
}
declare const DBProxyNotFoundFault_base: S.TaggedErrorClass<"DBProxyNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBProxyNotFoundFault extends /*@__PURE__*/ DBProxyNotFoundFault_base {
}
declare const DBProxyQuotaExceededFault_base: S.TaggedErrorClass<"DBProxyQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBProxyQuotaExceededFault extends /*@__PURE__*/ DBProxyQuotaExceededFault_base {
}
declare const DBProxyTargetAlreadyRegisteredFault_base: S.TaggedErrorClass<"DBProxyTargetAlreadyRegisteredFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBProxyTargetAlreadyRegisteredFault extends /*@__PURE__*/ DBProxyTargetAlreadyRegisteredFault_base {
}
declare const DBProxyTargetGroupNotFoundFault_base: S.TaggedErrorClass<"DBProxyTargetGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBProxyTargetGroupNotFoundFault extends /*@__PURE__*/ DBProxyTargetGroupNotFoundFault_base {
}
declare const DBProxyTargetNotFoundFault_base: S.TaggedErrorClass<"DBProxyTargetNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBProxyTargetNotFoundFault extends /*@__PURE__*/ DBProxyTargetNotFoundFault_base {
}
declare const DBSecurityGroupAlreadyExistsFault_base: S.TaggedErrorClass<"DBSecurityGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBSecurityGroupAlreadyExistsFault extends /*@__PURE__*/ DBSecurityGroupAlreadyExistsFault_base {
}
declare const DBSecurityGroupNotFoundFault_base: S.TaggedErrorClass<"DBSecurityGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class DBSecurityGroupNotFoundFault extends /*@__PURE__*/ DBSecurityGroupNotFoundFault_base {
}
declare const DBSecurityGroupNotSupportedFault_base: S.TaggedErrorClass<"DBSecurityGroupNotSupportedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSecurityGroupNotSupportedFault extends /*@__PURE__*/ DBSecurityGroupNotSupportedFault_base {
}
declare const DBSecurityGroupQuotaExceededFault_base: S.TaggedErrorClass<"DBSecurityGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSecurityGroupQuotaExceededFault extends /*@__PURE__*/ DBSecurityGroupQuotaExceededFault_base {
}
declare const DBShardGroupAlreadyExistsFault_base: S.TaggedErrorClass<"DBShardGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBShardGroupAlreadyExistsFault extends /*@__PURE__*/ DBShardGroupAlreadyExistsFault_base {
}
declare const DBShardGroupNotFoundFault_base: S.TaggedErrorClass<"DBShardGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBShardGroupNotFoundFault extends /*@__PURE__*/ DBShardGroupNotFoundFault_base {
}
declare const DBSnapshotAlreadyExistsFault_base: S.TaggedErrorClass<"DBSnapshotAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBSnapshotAlreadyExistsFault extends /*@__PURE__*/ DBSnapshotAlreadyExistsFault_base {
}
declare const DBSnapshotNotFoundFault_base: S.TaggedErrorClass<"DBSnapshotNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSnapshotNotFoundFault extends /*@__PURE__*/ DBSnapshotNotFoundFault_base {
}
declare const DBSnapshotTenantDatabaseNotFoundFault_base: S.TaggedErrorClass<"DBSnapshotTenantDatabaseNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSnapshotTenantDatabaseNotFoundFault extends /*@__PURE__*/ DBSnapshotTenantDatabaseNotFoundFault_base {
}
declare const DBSubnetGroupAlreadyExistsFault_base: S.TaggedErrorClass<"DBSubnetGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBSubnetGroupAlreadyExistsFault extends /*@__PURE__*/ DBSubnetGroupAlreadyExistsFault_base {
}
declare const DBSubnetGroupDoesNotCoverEnoughAZs_base: S.TaggedErrorClass<"DBSubnetGroupDoesNotCoverEnoughAZs", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSubnetGroupDoesNotCoverEnoughAZs extends /*@__PURE__*/ DBSubnetGroupDoesNotCoverEnoughAZs_base {
}
declare const DBSubnetGroupNotAllowedFault_base: S.TaggedErrorClass<"DBSubnetGroupNotAllowedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSubnetGroupNotAllowedFault extends /*@__PURE__*/ DBSubnetGroupNotAllowedFault_base {
}
declare const DBSubnetGroupNotFoundFault_base: S.TaggedErrorClass<"DBSubnetGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class DBSubnetGroupNotFoundFault extends /*@__PURE__*/ DBSubnetGroupNotFoundFault_base {
}
declare const DBSubnetGroupQuotaExceededFault_base: S.TaggedErrorClass<"DBSubnetGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class DBSubnetGroupQuotaExceededFault extends /*@__PURE__*/ DBSubnetGroupQuotaExceededFault_base {
}
declare const DBSubnetQuotaExceededFault_base: S.TaggedErrorClass<"DBSubnetQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSubnetQuotaExceededFault extends /*@__PURE__*/ DBSubnetQuotaExceededFault_base {
}
declare const DBUpgradeDependencyFailureFault_base: S.TaggedErrorClass<"DBUpgradeDependencyFailureFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBUpgradeDependencyFailureFault extends /*@__PURE__*/ DBUpgradeDependencyFailureFault_base {
}
declare const DomainNotFoundFault_base: S.TaggedErrorClass<"DomainNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DomainNotFoundFault extends /*@__PURE__*/ DomainNotFoundFault_base {
}
declare const Ec2ImagePropertiesNotSupportedFault_base: S.TaggedErrorClass<"Ec2ImagePropertiesNotSupportedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class Ec2ImagePropertiesNotSupportedFault extends /*@__PURE__*/ Ec2ImagePropertiesNotSupportedFault_base {
}
declare const EventSubscriptionQuotaExceededFault_base: S.TaggedErrorClass<"EventSubscriptionQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EventSubscriptionQuotaExceededFault extends /*@__PURE__*/ EventSubscriptionQuotaExceededFault_base {
}
declare const ExportTaskAlreadyExistsFault_base: S.TaggedErrorClass<"ExportTaskAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ExportTaskAlreadyExistsFault extends /*@__PURE__*/ ExportTaskAlreadyExistsFault_base {
}
declare const ExportTaskNotFoundFault_base: S.TaggedErrorClass<"ExportTaskNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ExportTaskNotFoundFault extends /*@__PURE__*/ ExportTaskNotFoundFault_base {
}
declare const GlobalClusterAlreadyExistsFault_base: S.TaggedErrorClass<"GlobalClusterAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class GlobalClusterAlreadyExistsFault extends /*@__PURE__*/ GlobalClusterAlreadyExistsFault_base {
}
declare const GlobalClusterNotFoundFault_base: S.TaggedErrorClass<"GlobalClusterNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GlobalClusterNotFoundFault extends /*@__PURE__*/ GlobalClusterNotFoundFault_base {
}
declare const GlobalClusterQuotaExceededFault_base: S.TaggedErrorClass<"GlobalClusterQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GlobalClusterQuotaExceededFault extends /*@__PURE__*/ GlobalClusterQuotaExceededFault_base {
}
declare const IamRoleMissingPermissionsFault_base: S.TaggedErrorClass<"IamRoleMissingPermissionsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IamRoleMissingPermissionsFault extends /*@__PURE__*/ IamRoleMissingPermissionsFault_base {
}
declare const IamRoleNotFoundFault_base: S.TaggedErrorClass<"IamRoleNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IamRoleNotFoundFault extends /*@__PURE__*/ IamRoleNotFoundFault_base {
}
declare const InstanceQuotaExceededFault_base: S.TaggedErrorClass<"InstanceQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InstanceQuotaExceededFault extends /*@__PURE__*/ InstanceQuotaExceededFault_base {
}
declare const InsufficientAvailableIPsInSubnetFault_base: S.TaggedErrorClass<"InsufficientAvailableIPsInSubnetFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientAvailableIPsInSubnetFault extends /*@__PURE__*/ InsufficientAvailableIPsInSubnetFault_base {
}
declare const InsufficientDBClusterCapacityFault_base: S.TaggedErrorClass<"InsufficientDBClusterCapacityFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class InsufficientDBClusterCapacityFault extends /*@__PURE__*/ InsufficientDBClusterCapacityFault_base {
}
declare const InsufficientDBInstanceCapacityFault_base: S.TaggedErrorClass<"InsufficientDBInstanceCapacityFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientDBInstanceCapacityFault extends /*@__PURE__*/ InsufficientDBInstanceCapacityFault_base {
}
declare const InsufficientStorageClusterCapacityFault_base: S.TaggedErrorClass<"InsufficientStorageClusterCapacityFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientStorageClusterCapacityFault extends /*@__PURE__*/ InsufficientStorageClusterCapacityFault_base {
}
declare const IntegrationAlreadyExistsFault_base: S.TaggedErrorClass<"IntegrationAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class IntegrationAlreadyExistsFault extends /*@__PURE__*/ IntegrationAlreadyExistsFault_base {
}
declare const IntegrationConflictOperationFault_base: S.TaggedErrorClass<"IntegrationConflictOperationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IntegrationConflictOperationFault extends /*@__PURE__*/ IntegrationConflictOperationFault_base {
}
declare const IntegrationNotFoundFault_base: S.TaggedErrorClass<"IntegrationNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IntegrationNotFoundFault extends /*@__PURE__*/ IntegrationNotFoundFault_base {
}
declare const IntegrationQuotaExceededFault_base: S.TaggedErrorClass<"IntegrationQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IntegrationQuotaExceededFault extends /*@__PURE__*/ IntegrationQuotaExceededFault_base {
}
declare const InvalidBlueGreenDeploymentStateFault_base: S.TaggedErrorClass<"InvalidBlueGreenDeploymentStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidBlueGreenDeploymentStateFault extends /*@__PURE__*/ InvalidBlueGreenDeploymentStateFault_base {
}
declare const InvalidCustomDBEngineVersionStateFault_base: S.TaggedErrorClass<"InvalidCustomDBEngineVersionStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidCustomDBEngineVersionStateFault extends /*@__PURE__*/ InvalidCustomDBEngineVersionStateFault_base {
}
declare const InvalidDBClusterAutomatedBackupStateFault_base: S.TaggedErrorClass<"InvalidDBClusterAutomatedBackupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBClusterAutomatedBackupStateFault extends /*@__PURE__*/ InvalidDBClusterAutomatedBackupStateFault_base {
}
declare const InvalidDBClusterCapacityFault_base: S.TaggedErrorClass<"InvalidDBClusterCapacityFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBClusterCapacityFault extends /*@__PURE__*/ InvalidDBClusterCapacityFault_base {
}
declare const InvalidDBClusterEndpointStateFault_base: S.TaggedErrorClass<"InvalidDBClusterEndpointStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBClusterEndpointStateFault extends /*@__PURE__*/ InvalidDBClusterEndpointStateFault_base {
}
declare const InvalidDBClusterSnapshotStateFault_base: S.TaggedErrorClass<"InvalidDBClusterSnapshotStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBClusterSnapshotStateFault extends /*@__PURE__*/ InvalidDBClusterSnapshotStateFault_base {
}
declare const InvalidDBClusterStateFault_base: S.TaggedErrorClass<"InvalidDBClusterStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InvalidDBClusterStateFault extends /*@__PURE__*/ InvalidDBClusterStateFault_base {
}
declare const InvalidDBInstanceAutomatedBackupStateFault_base: S.TaggedErrorClass<"InvalidDBInstanceAutomatedBackupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBInstanceAutomatedBackupStateFault extends /*@__PURE__*/ InvalidDBInstanceAutomatedBackupStateFault_base {
}
declare const InvalidDBInstanceStateFault_base: S.TaggedErrorClass<"InvalidDBInstanceStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBInstanceStateFault extends /*@__PURE__*/ InvalidDBInstanceStateFault_base {
}
declare const InvalidDBParameterGroupStateFault_base: S.TaggedErrorClass<"InvalidDBParameterGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBParameterGroupStateFault extends /*@__PURE__*/ InvalidDBParameterGroupStateFault_base {
}
declare const InvalidDBProxyEndpointStateFault_base: S.TaggedErrorClass<"InvalidDBProxyEndpointStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBProxyEndpointStateFault extends /*@__PURE__*/ InvalidDBProxyEndpointStateFault_base {
}
declare const InvalidDBProxyStateFault_base: S.TaggedErrorClass<"InvalidDBProxyStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBProxyStateFault extends /*@__PURE__*/ InvalidDBProxyStateFault_base {
}
declare const InvalidDBSecurityGroupStateFault_base: S.TaggedErrorClass<"InvalidDBSecurityGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBSecurityGroupStateFault extends /*@__PURE__*/ InvalidDBSecurityGroupStateFault_base {
}
declare const InvalidDBShardGroupStateFault_base: S.TaggedErrorClass<"InvalidDBShardGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBShardGroupStateFault extends /*@__PURE__*/ InvalidDBShardGroupStateFault_base {
}
declare const InvalidDBSnapshotStateFault_base: S.TaggedErrorClass<"InvalidDBSnapshotStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBSnapshotStateFault extends /*@__PURE__*/ InvalidDBSnapshotStateFault_base {
}
declare const InvalidDBSubnetGroupFault_base: S.TaggedErrorClass<"InvalidDBSubnetGroupFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBSubnetGroupFault extends /*@__PURE__*/ InvalidDBSubnetGroupFault_base {
}
declare const InvalidDBSubnetGroupStateFault_base: S.TaggedErrorClass<"InvalidDBSubnetGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBSubnetGroupStateFault extends /*@__PURE__*/ InvalidDBSubnetGroupStateFault_base {
}
declare const InvalidDBSubnetStateFault_base: S.TaggedErrorClass<"InvalidDBSubnetStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBSubnetStateFault extends /*@__PURE__*/ InvalidDBSubnetStateFault_base {
}
declare const InvalidEventSubscriptionStateFault_base: S.TaggedErrorClass<"InvalidEventSubscriptionStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEventSubscriptionStateFault extends /*@__PURE__*/ InvalidEventSubscriptionStateFault_base {
}
declare const InvalidExportOnlyFault_base: S.TaggedErrorClass<"InvalidExportOnlyFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidExportOnlyFault extends /*@__PURE__*/ InvalidExportOnlyFault_base {
}
declare const InvalidExportSourceStateFault_base: S.TaggedErrorClass<"InvalidExportSourceStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidExportSourceStateFault extends /*@__PURE__*/ InvalidExportSourceStateFault_base {
}
declare const InvalidExportTaskStateFault_base: S.TaggedErrorClass<"InvalidExportTaskStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidExportTaskStateFault extends /*@__PURE__*/ InvalidExportTaskStateFault_base {
}
declare const InvalidGlobalClusterStateFault_base: S.TaggedErrorClass<"InvalidGlobalClusterStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidGlobalClusterStateFault extends /*@__PURE__*/ InvalidGlobalClusterStateFault_base {
}
declare const InvalidIntegrationStateFault_base: S.TaggedErrorClass<"InvalidIntegrationStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidIntegrationStateFault extends /*@__PURE__*/ InvalidIntegrationStateFault_base {
}
declare const InvalidOptionGroupStateFault_base: S.TaggedErrorClass<"InvalidOptionGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidOptionGroupStateFault extends /*@__PURE__*/ InvalidOptionGroupStateFault_base {
}
declare const InvalidParameterCombination_base: S.TaggedErrorClass<"InvalidParameterCombination", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterCombination extends /*@__PURE__*/ InvalidParameterCombination_base {
}
declare const InvalidParameterValue_base: S.TaggedErrorClass<"InvalidParameterValue", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValue extends /*@__PURE__*/ InvalidParameterValue_base {
}
declare const InvalidResourceStateFault_base: S.TaggedErrorClass<"InvalidResourceStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidResourceStateFault extends /*@__PURE__*/ InvalidResourceStateFault_base {
}
declare const InvalidRestoreFault_base: S.TaggedErrorClass<"InvalidRestoreFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRestoreFault extends /*@__PURE__*/ InvalidRestoreFault_base {
}
declare const InvalidS3BucketFault_base: S.TaggedErrorClass<"InvalidS3BucketFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidS3BucketFault extends /*@__PURE__*/ InvalidS3BucketFault_base {
}
declare const InvalidSubnet_base: S.TaggedErrorClass<"InvalidSubnet", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSubnet extends /*@__PURE__*/ InvalidSubnet_base {
}
declare const InvalidVPCNetworkStateFault_base: S.TaggedErrorClass<"InvalidVPCNetworkStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidVPCNetworkStateFault extends /*@__PURE__*/ InvalidVPCNetworkStateFault_base {
}
declare const KMSKeyNotAccessibleFault_base: S.TaggedErrorClass<"KMSKeyNotAccessibleFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KMSKeyNotAccessibleFault extends /*@__PURE__*/ KMSKeyNotAccessibleFault_base {
}
declare const MaxDBShardGroupLimitReached_base: S.TaggedErrorClass<"MaxDBShardGroupLimitReached", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MaxDBShardGroupLimitReached extends /*@__PURE__*/ MaxDBShardGroupLimitReached_base {
}
declare const NetworkTypeNotSupported_base: S.TaggedErrorClass<"NetworkTypeNotSupported", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NetworkTypeNotSupported extends /*@__PURE__*/ NetworkTypeNotSupported_base {
}
declare const OptionGroupAlreadyExistsFault_base: S.TaggedErrorClass<"OptionGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class OptionGroupAlreadyExistsFault extends /*@__PURE__*/ OptionGroupAlreadyExistsFault_base {
}
declare const OptionGroupNotFoundFault_base: S.TaggedErrorClass<"OptionGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OptionGroupNotFoundFault extends /*@__PURE__*/ OptionGroupNotFoundFault_base {
}
declare const OptionGroupQuotaExceededFault_base: S.TaggedErrorClass<"OptionGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OptionGroupQuotaExceededFault extends /*@__PURE__*/ OptionGroupQuotaExceededFault_base {
}
declare const PointInTimeRestoreNotEnabledFault_base: S.TaggedErrorClass<"PointInTimeRestoreNotEnabledFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PointInTimeRestoreNotEnabledFault extends /*@__PURE__*/ PointInTimeRestoreNotEnabledFault_base {
}
declare const ProvisionedIopsNotAvailableInAZFault_base: S.TaggedErrorClass<"ProvisionedIopsNotAvailableInAZFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ProvisionedIopsNotAvailableInAZFault extends /*@__PURE__*/ ProvisionedIopsNotAvailableInAZFault_base {
}
declare const ReservedDBInstanceAlreadyExistsFault_base: S.TaggedErrorClass<"ReservedDBInstanceAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ReservedDBInstanceAlreadyExistsFault extends /*@__PURE__*/ ReservedDBInstanceAlreadyExistsFault_base {
}
declare const ReservedDBInstanceNotFoundFault_base: S.TaggedErrorClass<"ReservedDBInstanceNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedDBInstanceNotFoundFault extends /*@__PURE__*/ ReservedDBInstanceNotFoundFault_base {
}
declare const ReservedDBInstanceQuotaExceededFault_base: S.TaggedErrorClass<"ReservedDBInstanceQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedDBInstanceQuotaExceededFault extends /*@__PURE__*/ ReservedDBInstanceQuotaExceededFault_base {
}
declare const ReservedDBInstancesOfferingNotFoundFault_base: S.TaggedErrorClass<"ReservedDBInstancesOfferingNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedDBInstancesOfferingNotFoundFault extends /*@__PURE__*/ ReservedDBInstancesOfferingNotFoundFault_base {
}
declare const ResourceNotFoundFault_base: S.TaggedErrorClass<"ResourceNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundFault extends /*@__PURE__*/ ResourceNotFoundFault_base {
}
declare const SharedSnapshotQuotaExceededFault_base: S.TaggedErrorClass<"SharedSnapshotQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SharedSnapshotQuotaExceededFault extends /*@__PURE__*/ SharedSnapshotQuotaExceededFault_base {
}
declare const SnapshotQuotaExceededFault_base: S.TaggedErrorClass<"SnapshotQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotQuotaExceededFault extends /*@__PURE__*/ SnapshotQuotaExceededFault_base {
}
declare const SNSInvalidTopicFault_base: S.TaggedErrorClass<"SNSInvalidTopicFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SNSInvalidTopicFault extends /*@__PURE__*/ SNSInvalidTopicFault_base {
}
declare const SNSNoAuthorizationFault_base: S.TaggedErrorClass<"SNSNoAuthorizationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SNSNoAuthorizationFault extends /*@__PURE__*/ SNSNoAuthorizationFault_base {
}
declare const SNSTopicArnNotFoundFault_base: S.TaggedErrorClass<"SNSTopicArnNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SNSTopicArnNotFoundFault extends /*@__PURE__*/ SNSTopicArnNotFoundFault_base {
}
declare const SourceClusterNotSupportedFault_base: S.TaggedErrorClass<"SourceClusterNotSupportedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SourceClusterNotSupportedFault extends /*@__PURE__*/ SourceClusterNotSupportedFault_base {
}
declare const SourceDatabaseNotSupportedFault_base: S.TaggedErrorClass<"SourceDatabaseNotSupportedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SourceDatabaseNotSupportedFault extends /*@__PURE__*/ SourceDatabaseNotSupportedFault_base {
}
declare const SourceNotFoundFault_base: S.TaggedErrorClass<"SourceNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SourceNotFoundFault extends /*@__PURE__*/ SourceNotFoundFault_base {
}
declare const StorageQuotaExceededFault_base: S.TaggedErrorClass<"StorageQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StorageQuotaExceededFault extends /*@__PURE__*/ StorageQuotaExceededFault_base {
}
declare const StorageTypeNotAvailableFault_base: S.TaggedErrorClass<"StorageTypeNotAvailableFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StorageTypeNotAvailableFault extends /*@__PURE__*/ StorageTypeNotAvailableFault_base {
}
declare const StorageTypeNotSupportedFault_base: S.TaggedErrorClass<"StorageTypeNotSupportedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StorageTypeNotSupportedFault extends /*@__PURE__*/ StorageTypeNotSupportedFault_base {
}
declare const SubnetAlreadyInUse_base: S.TaggedErrorClass<"SubnetAlreadyInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class SubnetAlreadyInUse extends /*@__PURE__*/ SubnetAlreadyInUse_base {
}
declare const SubscriptionAlreadyExistFault_base: S.TaggedErrorClass<"SubscriptionAlreadyExistFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubscriptionAlreadyExistFault extends /*@__PURE__*/ SubscriptionAlreadyExistFault_base {
}
declare const SubscriptionCategoryNotFoundFault_base: S.TaggedErrorClass<"SubscriptionCategoryNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubscriptionCategoryNotFoundFault extends /*@__PURE__*/ SubscriptionCategoryNotFoundFault_base {
}
declare const SubscriptionNotFoundFault_base: S.TaggedErrorClass<"SubscriptionNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubscriptionNotFoundFault extends /*@__PURE__*/ SubscriptionNotFoundFault_base {
}
declare const TenantDatabaseAlreadyExistsFault_base: S.TaggedErrorClass<"TenantDatabaseAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class TenantDatabaseAlreadyExistsFault extends /*@__PURE__*/ TenantDatabaseAlreadyExistsFault_base {
}
declare const TenantDatabaseNotFoundFault_base: S.TaggedErrorClass<"TenantDatabaseNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TenantDatabaseNotFoundFault extends /*@__PURE__*/ TenantDatabaseNotFoundFault_base {
}
declare const TenantDatabaseQuotaExceededFault_base: S.TaggedErrorClass<"TenantDatabaseQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TenantDatabaseQuotaExceededFault extends /*@__PURE__*/ TenantDatabaseQuotaExceededFault_base {
}
declare const UnsupportedDBEngineVersionFault_base: S.TaggedErrorClass<"UnsupportedDBEngineVersionFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedDBEngineVersionFault extends /*@__PURE__*/ UnsupportedDBEngineVersionFault_base {
}
declare const VpcEncryptionControlViolationException_base: S.TaggedErrorClass<"VpcEncryptionControlViolationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class VpcEncryptionControlViolationException extends /*@__PURE__*/ VpcEncryptionControlViolationException_base {
}
export type IAMRoleArn = string;
export interface AddRoleToDBClusterMessage {
    DBClusterIdentifier?: string;
    RoleArn?: string;
    FeatureName?: string;
}
export interface AddRoleToDBClusterResponse {
}
export interface AddRoleToDBInstanceMessage {
    DBInstanceIdentifier?: string;
    RoleArn?: string;
    FeatureName?: string;
}
export interface AddRoleToDBInstanceResponse {
}
export interface AddSourceIdentifierToSubscriptionMessage {
    SubscriptionName?: string;
    SourceIdentifier?: string;
}
export type SourceIdsList = string[];
export type EventCategoriesList = string[];
export interface EventSubscription {
    CustomerAwsId?: string;
    CustSubscriptionId?: string;
    SnsTopicArn?: string;
    Status?: string;
    SubscriptionCreationTime?: string;
    SourceType?: string;
    SourceIdsList?: string[];
    EventCategoriesList?: string[];
    Enabled?: boolean;
    EventSubscriptionArn?: string;
}
export interface AddSourceIdentifierToSubscriptionResult {
    EventSubscription?: EventSubscription;
}
export interface Tag {
    Key?: string;
    Value?: string;
}
export type TagList = Tag[];
export interface AddTagsToResourceMessage {
    ResourceName?: string;
    Tags?: Tag[];
}
export interface AddTagsToResourceResponse {
}
export interface ApplyPendingMaintenanceActionMessage {
    ResourceIdentifier?: string;
    ApplyAction?: string;
    OptInType?: string;
}
export interface PendingMaintenanceAction {
    Action?: string;
    AutoAppliedAfterDate?: Date;
    ForcedApplyDate?: Date;
    OptInStatus?: string;
    CurrentApplyDate?: Date;
    Description?: string;
}
export type PendingMaintenanceActionDetails = PendingMaintenanceAction[];
export interface ResourcePendingMaintenanceActions {
    ResourceIdentifier?: string;
    PendingMaintenanceActionDetails?: PendingMaintenanceAction[];
}
export interface ApplyPendingMaintenanceActionResult {
    ResourcePendingMaintenanceActions?: ResourcePendingMaintenanceActions;
}
export interface AuthorizeDBSecurityGroupIngressMessage {
    DBSecurityGroupName?: string;
    CIDRIP?: string;
    EC2SecurityGroupName?: string;
    EC2SecurityGroupId?: string;
    EC2SecurityGroupOwnerId?: string;
}
export interface EC2SecurityGroup {
    Status?: string;
    EC2SecurityGroupName?: string;
    EC2SecurityGroupId?: string;
    EC2SecurityGroupOwnerId?: string;
}
export type EC2SecurityGroupList = EC2SecurityGroup[];
export interface IPRange {
    Status?: string;
    CIDRIP?: string;
}
export type IPRangeList = IPRange[];
export interface DBSecurityGroup {
    OwnerId?: string;
    DBSecurityGroupName?: string;
    DBSecurityGroupDescription?: string;
    VpcId?: string;
    EC2SecurityGroups?: EC2SecurityGroup[];
    IPRanges?: IPRange[];
    DBSecurityGroupArn?: string;
}
export interface AuthorizeDBSecurityGroupIngressResult {
    DBSecurityGroup?: DBSecurityGroup;
}
export interface BacktrackDBClusterMessage {
    DBClusterIdentifier?: string;
    BacktrackTo?: Date;
    Force?: boolean;
    UseEarliestTimeOnPointInTimeUnavailable?: boolean;
}
export interface DBClusterBacktrack {
    DBClusterIdentifier?: string;
    BacktrackIdentifier?: string;
    BacktrackTo?: Date;
    BacktrackedFrom?: Date;
    BacktrackRequestCreationTime?: Date;
    Status?: string;
}
export interface CancelExportTaskMessage {
    ExportTaskIdentifier?: string;
}
export type StringList = string[];
export type ExportSourceType = "SNAPSHOT" | "CLUSTER" | (string & {});
export interface ExportTask {
    ExportTaskIdentifier?: string;
    SourceArn?: string;
    ExportOnly?: string[];
    SnapshotTime?: Date;
    TaskStartTime?: Date;
    TaskEndTime?: Date;
    S3Bucket?: string;
    S3Prefix?: string;
    IamRoleArn?: string;
    KmsKeyId?: string;
    Status?: string;
    PercentProgress?: number;
    TotalExtractedDataInGB?: number;
    FailureCause?: string;
    WarningMessage?: string;
    SourceType?: ExportSourceType;
}
export interface CopyDBClusterParameterGroupMessage {
    SourceDBClusterParameterGroupIdentifier?: string;
    TargetDBClusterParameterGroupIdentifier?: string;
    TargetDBClusterParameterGroupDescription?: string;
    Tags?: Tag[];
}
export interface DBClusterParameterGroup {
    DBClusterParameterGroupName?: string;
    DBParameterGroupFamily?: string;
    Description?: string;
    DBClusterParameterGroupArn?: string;
}
export interface CopyDBClusterParameterGroupResult {
    DBClusterParameterGroup?: DBClusterParameterGroup;
}
export type SensitiveString = string | redacted.Redacted<string>;
export interface CopyDBClusterSnapshotMessage {
    SourceDBClusterSnapshotIdentifier?: string;
    TargetDBClusterSnapshotIdentifier?: string;
    KmsKeyId?: string;
    PreSignedUrl?: string | redacted.Redacted<string>;
    CopyTags?: boolean;
    Tags?: Tag[];
}
export type AvailabilityZones = string[];
export type StorageEncryptionType = "none" | "sse-kms" | "sse-rds" | (string & {});
export interface DBClusterSnapshot {
    AvailabilityZones?: string[];
    DBClusterSnapshotIdentifier?: string;
    DBClusterIdentifier?: string;
    SnapshotCreateTime?: Date;
    Engine?: string;
    EngineMode?: string;
    AllocatedStorage?: number;
    Status?: string;
    Port?: number;
    VpcId?: string;
    ClusterCreateTime?: Date;
    MasterUsername?: string;
    EngineVersion?: string;
    LicenseModel?: string;
    SnapshotType?: string;
    PercentProgress?: number;
    StorageEncrypted?: boolean;
    StorageEncryptionType?: StorageEncryptionType;
    BackupRetentionPeriod?: number;
    PreferredBackupWindow?: string;
    KmsKeyId?: string;
    DBClusterSnapshotArn?: string;
    SourceDBClusterSnapshotArn?: string;
    IAMDatabaseAuthenticationEnabled?: boolean;
    TagList?: Tag[];
    StorageType?: string;
    StorageThroughput?: number;
    DbClusterResourceId?: string;
    DBSystemId?: string;
}
export interface CopyDBClusterSnapshotResult {
    DBClusterSnapshot?: DBClusterSnapshot;
}
export interface CopyDBParameterGroupMessage {
    SourceDBParameterGroupIdentifier?: string;
    TargetDBParameterGroupIdentifier?: string;
    TargetDBParameterGroupDescription?: string;
    Tags?: Tag[];
}
export interface DBParameterGroup {
    DBParameterGroupName?: string;
    DBParameterGroupFamily?: string;
    Description?: string;
    DBParameterGroupArn?: string;
}
export interface CopyDBParameterGroupResult {
    DBParameterGroup?: DBParameterGroup;
}
export interface CopyDBSnapshotMessage {
    SourceDBSnapshotIdentifier?: string;
    TargetDBSnapshotIdentifier?: string;
    KmsKeyId?: string;
    Tags?: Tag[];
    CopyTags?: boolean;
    PreSignedUrl?: string | redacted.Redacted<string>;
    OptionGroupName?: string;
    TargetCustomAvailabilityZone?: string;
    SnapshotTarget?: string;
    CopyOptionGroup?: boolean;
    SnapshotAvailabilityZone?: string;
}
export interface ProcessorFeature {
    Name?: string;
    Value?: string;
}
export type ProcessorFeatureList = ProcessorFeature[];
export interface AdditionalStorageVolume {
    VolumeName?: string;
    AllocatedStorage?: number;
    IOPS?: number;
    MaxAllocatedStorage?: number;
    StorageThroughput?: number;
    StorageType?: string;
}
export type AdditionalStorageVolumesList = AdditionalStorageVolume[];
export interface DBSnapshot {
    DBSnapshotIdentifier?: string;
    DBInstanceIdentifier?: string;
    SnapshotCreateTime?: Date;
    Engine?: string;
    AllocatedStorage?: number;
    Status?: string;
    Port?: number;
    AvailabilityZone?: string;
    VpcId?: string;
    InstanceCreateTime?: Date;
    MasterUsername?: string;
    EngineVersion?: string;
    LicenseModel?: string;
    SnapshotType?: string;
    Iops?: number;
    StorageThroughput?: number;
    OptionGroupName?: string;
    PercentProgress?: number;
    SourceRegion?: string;
    SourceDBSnapshotIdentifier?: string;
    StorageType?: string;
    TdeCredentialArn?: string;
    Encrypted?: boolean;
    StorageEncryptionType?: StorageEncryptionType;
    BackupRetentionPeriod?: number;
    PreferredBackupWindow?: string;
    KmsKeyId?: string;
    DBSnapshotArn?: string;
    Timezone?: string;
    IAMDatabaseAuthenticationEnabled?: boolean;
    ProcessorFeatures?: ProcessorFeature[];
    DbiResourceId?: string;
    TagList?: Tag[];
    SnapshotTarget?: string;
    OriginalSnapshotCreateTime?: Date;
    SnapshotDatabaseTime?: Date;
    DBSystemId?: string;
    MultiTenant?: boolean;
    DedicatedLogVolume?: boolean;
    AdditionalStorageVolumes?: AdditionalStorageVolume[];
    SnapshotAvailabilityZone?: string;
    FullSnapshotSizeInBytes?: number;
}
export interface CopyDBSnapshotResult {
    DBSnapshot?: DBSnapshot & {
        AdditionalStorageVolumes: (AdditionalStorageVolume & {
            VolumeName: string;
        })[];
    };
}
export interface CopyOptionGroupMessage {
    SourceOptionGroupIdentifier?: string;
    TargetOptionGroupIdentifier?: string;
    TargetOptionGroupDescription?: string;
    Tags?: Tag[];
}
export type PotentiallySensitiveOptionSettingValue = string | redacted.Redacted<string>;
export interface OptionSetting {
    Name?: string;
    Value?: string | redacted.Redacted<string>;
    DefaultValue?: string;
    Description?: string;
    ApplyType?: string;
    DataType?: string;
    AllowedValues?: string;
    IsModifiable?: boolean;
    IsCollection?: boolean;
}
export type OptionSettingConfigurationList = OptionSetting[];
export interface DBSecurityGroupMembership {
    DBSecurityGroupName?: string;
    Status?: string;
}
export type DBSecurityGroupMembershipList = DBSecurityGroupMembership[];
export interface VpcSecurityGroupMembership {
    VpcSecurityGroupId?: string;
    Status?: string;
}
export type VpcSecurityGroupMembershipList = VpcSecurityGroupMembership[];
export interface Option {
    OptionName?: string;
    OptionDescription?: string;
    Persistent?: boolean;
    Permanent?: boolean;
    Port?: number;
    OptionVersion?: string;
    OptionSettings?: OptionSetting[];
    DBSecurityGroupMemberships?: DBSecurityGroupMembership[];
    VpcSecurityGroupMemberships?: VpcSecurityGroupMembership[];
}
export type OptionsList = Option[];
export interface OptionGroup {
    OptionGroupName?: string;
    OptionGroupDescription?: string;
    EngineName?: string;
    MajorEngineVersion?: string;
    Options?: Option[];
    AllowsVpcAndNonVpcInstanceMemberships?: boolean;
    VpcId?: string;
    OptionGroupArn?: string;
    SourceOptionGroup?: string;
    SourceAccountId?: string;
    CopyTimestamp?: Date;
}
export interface CopyOptionGroupResult {
    OptionGroup?: OptionGroup;
}
export type BlueGreenDeploymentName = string;
export type DatabaseArn = string;
export type TargetEngineVersion = string;
export type TargetDBParameterGroupName = string;
export type TargetDBClusterParameterGroupName = string;
export type TargetDBInstanceClass = string;
export type TargetStorageType = string;
export type DBAndClusterArn = string;
export type KmsKeyIdOrArn = string;
export interface TargetResourceConfiguration {
    SourceArn: string;
    TargetKmsKeyId?: string;
}
export type TargetResourceConfigurationList = TargetResourceConfiguration[];
export interface CreateBlueGreenDeploymentRequest {
    BlueGreenDeploymentName?: string;
    Source?: string;
    TargetEngineVersion?: string;
    TargetDBParameterGroupName?: string;
    TargetDBClusterParameterGroupName?: string;
    Tags?: Tag[];
    TargetDBInstanceClass?: string;
    UpgradeTargetStorageConfig?: boolean;
    TargetIops?: number;
    TargetStorageType?: string;
    TargetAllocatedStorage?: number;
    TargetStorageThroughput?: number;
    TargetResourceConfigurations?: TargetResourceConfiguration[];
}
export type BlueGreenDeploymentIdentifier = string;
export type SwitchoverDetailStatus = string;
export interface SwitchoverDetail {
    SourceMember?: string;
    TargetMember?: string;
    Status?: string;
}
export type SwitchoverDetailList = SwitchoverDetail[];
export type BlueGreenDeploymentTaskName = string;
export type BlueGreenDeploymentTaskStatus = string;
export interface BlueGreenDeploymentTask {
    Name?: string;
    Status?: string;
}
export type BlueGreenDeploymentTaskList = BlueGreenDeploymentTask[];
export type BlueGreenDeploymentStatus = string;
export type BlueGreenDeploymentStatusDetails = string;
export interface BlueGreenDeployment {
    BlueGreenDeploymentIdentifier?: string;
    BlueGreenDeploymentName?: string;
    Source?: string;
    Target?: string;
    SwitchoverDetails?: SwitchoverDetail[];
    Tasks?: BlueGreenDeploymentTask[];
    Status?: string;
    StatusDetails?: string;
    CreateTime?: Date;
    DeleteTime?: Date;
    TagList?: Tag[];
}
export interface CreateBlueGreenDeploymentResponse {
    BlueGreenDeployment?: BlueGreenDeployment;
}
export type CustomEngineName = string;
export type CustomEngineVersion = string;
export type BucketName = string;
export type String255 = string;
export type Description = string;
export type CustomDBEngineVersionManifest = string;
export interface CreateCustomDBEngineVersionMessage {
    Engine?: string;
    EngineVersion?: string;
    DatabaseInstallationFilesS3BucketName?: string;
    DatabaseInstallationFilesS3Prefix?: string;
    DatabaseInstallationFiles?: string[];
    ImageId?: string;
    KMSKeyId?: string;
    SourceCustomDbEngineVersionIdentifier?: string;
    UseAwsProvidedLatestImage?: boolean;
    Description?: string;
    Manifest?: string;
    Tags?: Tag[];
}
export interface CharacterSet {
    CharacterSetName?: string;
    CharacterSetDescription?: string;
}
export interface CustomDBEngineVersionAMI {
    ImageId?: string;
    Status?: string;
}
export type SupportedCharacterSetsList = CharacterSet[];
export type EngineModeList = string[];
export interface UpgradeTarget {
    Engine?: string;
    EngineVersion?: string;
    Description?: string;
    AutoUpgrade?: boolean;
    IsMajorVersionUpgrade?: boolean;
    SupportedEngineModes?: string[];
    SupportsParallelQuery?: boolean;
    SupportsGlobalDatabases?: boolean;
    SupportsBabelfish?: boolean;
    SupportsLimitlessDatabase?: boolean;
    SupportsLocalWriteForwarding?: boolean;
    SupportsIntegrations?: boolean;
}
export type ValidUpgradeTargetList = UpgradeTarget[];
export interface Timezone {
    TimezoneName?: string;
}
export type SupportedTimezonesList = Timezone[];
export type LogTypeList = string[];
export type FeatureNameList = string[];
export type CACertificateIdentifiersList = string[];
export interface ServerlessV2FeaturesSupport {
    MinCapacity?: number;
    MaxCapacity?: number;
}
export interface DBEngineVersion {
    Engine?: string;
    MajorEngineVersion?: string;
    EngineVersion?: string;
    DatabaseInstallationFilesS3BucketName?: string;
    DatabaseInstallationFilesS3Prefix?: string;
    DatabaseInstallationFiles?: string[];
    CustomDBEngineVersionManifest?: string;
    DBParameterGroupFamily?: string;
    DBEngineDescription?: string;
    DBEngineVersionArn?: string;
    DBEngineVersionDescription?: string;
    DefaultCharacterSet?: CharacterSet;
    FailureReason?: string;
    Image?: CustomDBEngineVersionAMI;
    DBEngineMediaType?: string;
    KMSKeyId?: string;
    CreateTime?: Date;
    SupportedCharacterSets?: CharacterSet[];
    SupportedNcharCharacterSets?: CharacterSet[];
    ValidUpgradeTarget?: UpgradeTarget[];
    SupportedTimezones?: Timezone[];
    ExportableLogTypes?: string[];
    SupportsLogExportsToCloudwatchLogs?: boolean;
    SupportsReadReplica?: boolean;
    SupportedEngineModes?: string[];
    SupportedFeatureNames?: string[];
    Status?: string;
    SupportsParallelQuery?: boolean;
    SupportsGlobalDatabases?: boolean;
    TagList?: Tag[];
    SupportsBabelfish?: boolean;
    SupportsLimitlessDatabase?: boolean;
    SupportsCertificateRotationWithoutRestart?: boolean;
    SupportedCACertificateIdentifiers?: string[];
    SupportsLocalWriteForwarding?: boolean;
    SupportsIntegrations?: boolean;
    ServerlessV2FeaturesSupport?: ServerlessV2FeaturesSupport;
}
export type VpcSecurityGroupIdList = string[];
export interface ScalingConfiguration {
    MinCapacity?: number;
    MaxCapacity?: number;
    AutoPause?: boolean;
    SecondsUntilAutoPause?: number;
    TimeoutAction?: string;
    SecondsBeforeTimeout?: number;
}
export type ReplicaMode = "open-read-only" | "mounted" | (string & {});
export interface RdsCustomClusterConfiguration {
    InterconnectSubnetId?: string;
    TransitGatewayMulticastDomainId?: string;
    ReplicaMode?: ReplicaMode;
}
export type GlobalClusterIdentifier = string;
export interface ServerlessV2ScalingConfiguration {
    MinCapacity?: number;
    MaxCapacity?: number;
    SecondsUntilAutoPause?: number;
}
export type DatabaseInsightsMode = "standard" | "advanced" | (string & {});
export type ClusterScalabilityType = "standard" | "limitless" | (string & {});
export interface TagSpecification {
    ResourceType?: string;
    Tags?: Tag[];
}
export type TagSpecificationList = TagSpecification[];
export type MasterUserAuthenticationType = "password" | "iam-db-auth" | (string & {});
export interface DBClusterAssociatedRole {
    RoleArn: string;
    FeatureName?: string;
}
export type DBClusterAssociatedRoles = DBClusterAssociatedRole[];
export interface CreateDBClusterMessage {
    AvailabilityZones?: string[];
    BackupRetentionPeriod?: number;
    CharacterSetName?: string;
    DatabaseName?: string;
    DBClusterIdentifier?: string;
    DBClusterParameterGroupName?: string;
    VpcSecurityGroupIds?: string[];
    DBSubnetGroupName?: string;
    Engine?: string;
    EngineVersion?: string;
    Port?: number;
    MasterUsername?: string;
    MasterUserPassword?: string | redacted.Redacted<string>;
    OptionGroupName?: string;
    PreferredBackupWindow?: string;
    PreferredMaintenanceWindow?: string;
    ReplicationSourceIdentifier?: string;
    Tags?: Tag[];
    StorageEncrypted?: boolean;
    KmsKeyId?: string;
    PreSignedUrl?: string | redacted.Redacted<string>;
    EnableIAMDatabaseAuthentication?: boolean;
    BacktrackWindow?: number;
    EnableCloudwatchLogsExports?: string[];
    EngineMode?: string;
    ScalingConfiguration?: ScalingConfiguration;
    RdsCustomClusterConfiguration?: RdsCustomClusterConfiguration;
    DBClusterInstanceClass?: string;
    AllocatedStorage?: number;
    StorageType?: string;
    Iops?: number;
    PubliclyAccessible?: boolean;
    AutoMinorVersionUpgrade?: boolean;
    DeletionProtection?: boolean;
    GlobalClusterIdentifier?: string;
    EnableHttpEndpoint?: boolean;
    CopyTagsToSnapshot?: boolean;
    Domain?: string;
    DomainIAMRoleName?: string;
    EnableGlobalWriteForwarding?: boolean;
    NetworkType?: string;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfiguration;
    MonitoringInterval?: number;
    MonitoringRoleArn?: string;
    DatabaseInsightsMode?: DatabaseInsightsMode;
    EnablePerformanceInsights?: boolean;
    PerformanceInsightsKMSKeyId?: string;
    PerformanceInsightsRetentionPeriod?: number;
    EnableLimitlessDatabase?: boolean;
    ClusterScalabilityType?: ClusterScalabilityType;
    DBSystemId?: string;
    ManageMasterUserPassword?: boolean;
    EnableLocalWriteForwarding?: boolean;
    MasterUserSecretKmsKeyId?: string;
    CACertificateIdentifier?: string;
    EngineLifecycleSupport?: string;
    TagSpecifications?: TagSpecification[];
    MasterUserAuthenticationType?: MasterUserAuthenticationType;
    WithExpressConfiguration?: boolean;
    AssociatedRoles?: DBClusterAssociatedRole[];
}
export interface DBClusterOptionGroupStatus {
    DBClusterOptionGroupName?: string;
    Status?: string;
}
export type DBClusterOptionGroupMemberships = DBClusterOptionGroupStatus[];
export type UpgradeRolloutOrder = "first" | "second" | "last" | (string & {});
export type ReadReplicaIdentifierList = string[];
export interface DBClusterStatusInfo {
    StatusType?: string;
    Normal?: boolean;
    Status?: string;
    Message?: string;
}
export type DBClusterStatusInfoList = DBClusterStatusInfo[];
export interface DBClusterMember {
    DBInstanceIdentifier?: string;
    IsClusterWriter?: boolean;
    DBClusterParameterGroupStatus?: string;
    PromotionTier?: number;
}
export type DBClusterMemberList = DBClusterMember[];
export interface DBClusterRole {
    RoleArn?: string;
    Status?: string;
    FeatureName?: string;
}
export type DBClusterRoles = DBClusterRole[];
export interface PendingCloudwatchLogsExports {
    LogTypesToEnable?: string[];
    LogTypesToDisable?: string[];
}
export interface CertificateDetails {
    CAIdentifier?: string;
    ValidTill?: Date;
}
export interface ClusterPendingModifiedValues {
    PendingCloudwatchLogsExports?: PendingCloudwatchLogsExports;
    DBClusterIdentifier?: string;
    MasterUserPassword?: string | redacted.Redacted<string>;
    IAMDatabaseAuthenticationEnabled?: boolean;
    EngineVersion?: string;
    BackupRetentionPeriod?: number;
    StorageType?: string;
    AllocatedStorage?: number;
    RdsCustomClusterConfiguration?: RdsCustomClusterConfiguration;
    Iops?: number;
    CertificateDetails?: CertificateDetails;
}
export interface ScalingConfigurationInfo {
    MinCapacity?: number;
    MaxCapacity?: number;
    AutoPause?: boolean;
    SecondsUntilAutoPause?: number;
    TimeoutAction?: string;
    SecondsBeforeTimeout?: number;
}
export type ActivityStreamMode = "sync" | "async" | (string & {});
export type ActivityStreamStatus = "stopped" | "starting" | "started" | "stopping" | (string & {});
export interface DomainMembership {
    Domain?: string;
    Status?: string;
    FQDN?: string;
    IAMRoleName?: string;
    OU?: string;
    AuthSecretArn?: string;
    DnsIps?: string[];
}
export type DomainMembershipList = DomainMembership[];
export type WriteForwardingStatus = "enabled" | "disabled" | "enabling" | "disabling" | "unknown" | (string & {});
export interface ServerlessV2ScalingConfigurationInfo {
    MinCapacity?: number;
    MaxCapacity?: number;
    SecondsUntilAutoPause?: number;
}
export interface MasterUserSecret {
    SecretArn?: string;
    SecretStatus?: string;
    KmsKeyId?: string;
}
export type LocalWriteForwardingStatus = "enabled" | "disabled" | "enabling" | "disabling" | "requested" | (string & {});
export type LimitlessDatabaseStatus = "active" | "not-in-use" | "enabled" | "disabled" | "enabling" | "disabling" | "modifying-max-capacity" | "error" | (string & {});
export interface LimitlessDatabase {
    Status?: LimitlessDatabaseStatus;
    MinRequiredACU?: number;
}
export interface DBCluster {
    AllocatedStorage?: number;
    AvailabilityZones?: string[];
    BackupRetentionPeriod?: number;
    CharacterSetName?: string;
    DatabaseName?: string;
    DBClusterIdentifier?: string;
    DBClusterParameterGroup?: string;
    DBSubnetGroup?: string;
    Status?: string;
    PercentProgress?: string;
    EarliestRestorableTime?: Date;
    Endpoint?: string;
    ReaderEndpoint?: string;
    CustomEndpoints?: string[];
    MultiAZ?: boolean;
    Engine?: string;
    EngineVersion?: string;
    LatestRestorableTime?: Date;
    Port?: number;
    MasterUsername?: string;
    DBClusterOptionGroupMemberships?: DBClusterOptionGroupStatus[];
    PreferredBackupWindow?: string;
    PreferredMaintenanceWindow?: string;
    UpgradeRolloutOrder?: UpgradeRolloutOrder;
    ReplicationSourceIdentifier?: string;
    ReadReplicaIdentifiers?: string[];
    StatusInfos?: DBClusterStatusInfo[];
    DBClusterMembers?: DBClusterMember[];
    VpcSecurityGroups?: VpcSecurityGroupMembership[];
    HostedZoneId?: string;
    StorageEncrypted?: boolean;
    StorageEncryptionType?: StorageEncryptionType;
    KmsKeyId?: string;
    DbClusterResourceId?: string;
    DBClusterArn?: string;
    AssociatedRoles?: DBClusterRole[];
    IAMDatabaseAuthenticationEnabled?: boolean;
    CloneGroupId?: string;
    ClusterCreateTime?: Date;
    EarliestBacktrackTime?: Date;
    BacktrackWindow?: number;
    BacktrackConsumedChangeRecords?: number;
    EnabledCloudwatchLogsExports?: string[];
    Capacity?: number;
    PendingModifiedValues?: ClusterPendingModifiedValues;
    EngineMode?: string;
    ScalingConfigurationInfo?: ScalingConfigurationInfo;
    RdsCustomClusterConfiguration?: RdsCustomClusterConfiguration;
    DBClusterInstanceClass?: string;
    StorageType?: string;
    Iops?: number;
    StorageThroughput?: number;
    IOOptimizedNextAllowedModificationTime?: Date;
    PubliclyAccessible?: boolean;
    AutoMinorVersionUpgrade?: boolean;
    DeletionProtection?: boolean;
    HttpEndpointEnabled?: boolean;
    ActivityStreamMode?: ActivityStreamMode;
    ActivityStreamStatus?: ActivityStreamStatus;
    ActivityStreamKmsKeyId?: string;
    ActivityStreamKinesisStreamName?: string;
    CopyTagsToSnapshot?: boolean;
    CrossAccountClone?: boolean;
    DomainMemberships?: DomainMembership[];
    TagList?: Tag[];
    GlobalClusterIdentifier?: string;
    GlobalWriteForwardingStatus?: WriteForwardingStatus;
    GlobalWriteForwardingRequested?: boolean;
    NetworkType?: string;
    AutomaticRestartTime?: Date;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfigurationInfo;
    ServerlessV2PlatformVersion?: string;
    MonitoringInterval?: number;
    MonitoringRoleArn?: string;
    DatabaseInsightsMode?: DatabaseInsightsMode;
    PerformanceInsightsEnabled?: boolean;
    PerformanceInsightsKMSKeyId?: string;
    PerformanceInsightsRetentionPeriod?: number;
    DBSystemId?: string;
    MasterUserSecret?: MasterUserSecret;
    LocalWriteForwardingStatus?: LocalWriteForwardingStatus;
    AwsBackupRecoveryPointArn?: string;
    LimitlessDatabase?: LimitlessDatabase;
    ClusterScalabilityType?: ClusterScalabilityType;
    CertificateDetails?: CertificateDetails;
    EngineLifecycleSupport?: string;
    VPCNetworkingEnabled?: boolean;
    InternetAccessGatewayEnabled?: boolean;
}
export interface CreateDBClusterResult {
    DBCluster?: DBCluster;
}
export interface CreateDBClusterEndpointMessage {
    DBClusterIdentifier?: string;
    DBClusterEndpointIdentifier?: string;
    EndpointType?: string;
    StaticMembers?: string[];
    ExcludedMembers?: string[];
    Tags?: Tag[];
}
export interface DBClusterEndpoint {
    DBClusterEndpointIdentifier?: string;
    DBClusterIdentifier?: string;
    DBClusterEndpointResourceIdentifier?: string;
    Endpoint?: string;
    Status?: string;
    EndpointType?: string;
    CustomEndpointType?: string;
    StaticMembers?: string[];
    ExcludedMembers?: string[];
    DBClusterEndpointArn?: string;
}
export interface CreateDBClusterParameterGroupMessage {
    DBClusterParameterGroupName?: string;
    DBParameterGroupFamily?: string;
    Description?: string;
    Tags?: Tag[];
}
export interface CreateDBClusterParameterGroupResult {
    DBClusterParameterGroup?: DBClusterParameterGroup;
}
export interface CreateDBClusterSnapshotMessage {
    DBClusterSnapshotIdentifier?: string;
    DBClusterIdentifier?: string;
    Tags?: Tag[];
}
export interface CreateDBClusterSnapshotResult {
    DBClusterSnapshot?: DBClusterSnapshot;
}
export type DBSecurityGroupNameList = string[];
export interface CreateDBInstanceMessage {
    DBName?: string;
    DBInstanceIdentifier?: string;
    AllocatedStorage?: number;
    DBInstanceClass?: string;
    Engine?: string;
    MasterUsername?: string;
    MasterUserPassword?: string | redacted.Redacted<string>;
    DBSecurityGroups?: string[];
    VpcSecurityGroupIds?: string[];
    AvailabilityZone?: string;
    DBSubnetGroupName?: string;
    PreferredMaintenanceWindow?: string;
    DBParameterGroupName?: string;
    BackupRetentionPeriod?: number;
    PreferredBackupWindow?: string;
    Port?: number;
    MultiAZ?: boolean;
    EngineVersion?: string;
    AutoMinorVersionUpgrade?: boolean;
    LicenseModel?: string;
    Iops?: number;
    StorageThroughput?: number;
    OptionGroupName?: string;
    CharacterSetName?: string;
    NcharCharacterSetName?: string;
    PubliclyAccessible?: boolean;
    Tags?: Tag[];
    DBClusterIdentifier?: string;
    StorageType?: string;
    TdeCredentialArn?: string;
    TdeCredentialPassword?: string | redacted.Redacted<string>;
    StorageEncrypted?: boolean;
    KmsKeyId?: string;
    Domain?: string;
    DomainFqdn?: string;
    DomainOu?: string;
    DomainAuthSecretArn?: string;
    DomainDnsIps?: string[];
    CopyTagsToSnapshot?: boolean;
    MonitoringInterval?: number;
    MonitoringRoleArn?: string;
    DomainIAMRoleName?: string;
    PromotionTier?: number;
    Timezone?: string;
    EnableIAMDatabaseAuthentication?: boolean;
    DatabaseInsightsMode?: DatabaseInsightsMode;
    EnablePerformanceInsights?: boolean;
    PerformanceInsightsKMSKeyId?: string;
    PerformanceInsightsRetentionPeriod?: number;
    EnableCloudwatchLogsExports?: string[];
    ProcessorFeatures?: ProcessorFeature[];
    DeletionProtection?: boolean;
    MaxAllocatedStorage?: number;
    EnableCustomerOwnedIp?: boolean;
    NetworkType?: string;
    BackupTarget?: string;
    CustomIamInstanceProfile?: string;
    DBSystemId?: string;
    CACertificateIdentifier?: string;
    ManageMasterUserPassword?: boolean;
    MasterUserSecretKmsKeyId?: string;
    MultiTenant?: boolean;
    DedicatedLogVolume?: boolean;
    EngineLifecycleSupport?: string;
    AdditionalStorageVolumes?: AdditionalStorageVolume[];
    TagSpecifications?: TagSpecification[];
    MasterUserAuthenticationType?: MasterUserAuthenticationType;
}
export interface Endpoint {
    Address?: string;
    Port?: number;
    HostedZoneId?: string;
}
export interface DBParameterGroupStatus {
    DBParameterGroupName?: string;
    ParameterApplyStatus?: string;
}
export type DBParameterGroupStatusList = DBParameterGroupStatus[];
export interface AvailabilityZone {
    Name?: string;
}
export interface Outpost {
    Arn?: string;
}
export interface Subnet {
    SubnetIdentifier?: string;
    SubnetAvailabilityZone?: AvailabilityZone;
    SubnetOutpost?: Outpost;
    SubnetStatus?: string;
}
export type SubnetList = Subnet[];
export interface DBSubnetGroup {
    DBSubnetGroupName?: string;
    DBSubnetGroupDescription?: string;
    VpcId?: string;
    SubnetGroupStatus?: string;
    Subnets?: Subnet[];
    DBSubnetGroupArn?: string;
    SupportedNetworkTypes?: string[];
}
export type AutomationMode = "full" | "all-paused" | (string & {});
export interface PendingModifiedValues {
    DBInstanceClass?: string;
    AllocatedStorage?: number;
    MasterUserPassword?: string | redacted.Redacted<string>;
    Port?: number;
    BackupRetentionPeriod?: number;
    MultiAZ?: boolean;
    EngineVersion?: string;
    LicenseModel?: string;
    Iops?: number;
    StorageThroughput?: number;
    DBInstanceIdentifier?: string;
    StorageType?: string;
    CACertificateIdentifier?: string;
    DBSubnetGroupName?: string;
    PendingCloudwatchLogsExports?: PendingCloudwatchLogsExports;
    ProcessorFeatures?: ProcessorFeature[];
    AutomationMode?: AutomationMode;
    ResumeFullAutomationModeTime?: Date;
    MultiTenant?: boolean;
    IAMDatabaseAuthenticationEnabled?: boolean;
    DedicatedLogVolume?: boolean;
    Engine?: string;
    AdditionalStorageVolumes?: AdditionalStorageVolume[];
}
export type ReadReplicaDBInstanceIdentifierList = string[];
export type ReadReplicaDBClusterIdentifierList = string[];
export interface OptionGroupMembership {
    OptionGroupName?: string;
    Status?: string;
}
export type OptionGroupMembershipList = OptionGroupMembership[];
export interface DBInstanceStatusInfo {
    StatusType?: string;
    Normal?: boolean;
    Status?: string;
    Message?: string;
}
export type DBInstanceStatusInfoList = DBInstanceStatusInfo[];
export interface DBInstanceRole {
    RoleArn?: string;
    FeatureName?: string;
    Status?: string;
}
export type DBInstanceRoles = DBInstanceRole[];
export interface DBInstanceAutomatedBackupsReplication {
    DBInstanceAutomatedBackupsArn?: string;
}
export type DBInstanceAutomatedBackupsReplicationList = DBInstanceAutomatedBackupsReplication[];
export type ActivityStreamPolicyStatus = "locked" | "unlocked" | "locking-policy" | "unlocking-policy" | (string & {});
export interface AdditionalStorageVolumeOutput {
    VolumeName?: string;
    StorageVolumeStatus?: string;
    StorageOperationStatus?: string;
    StorageOperationPercentProgress?: number;
    AllocatedStorage?: number;
    IOPS?: number;
    MaxAllocatedStorage?: number;
    StorageThroughput?: number;
    StorageType?: string;
}
export type AdditionalStorageVolumesOutputList = AdditionalStorageVolumeOutput[];
export interface DBInstance {
    DBInstanceIdentifier?: string;
    DBInstanceClass?: string;
    Engine?: string;
    DBInstanceStatus?: string;
    MasterUsername?: string;
    DBName?: string;
    Endpoint?: Endpoint;
    AllocatedStorage?: number;
    InstanceCreateTime?: Date;
    PreferredBackupWindow?: string;
    BackupRetentionPeriod?: number;
    DBSecurityGroups?: DBSecurityGroupMembership[];
    VpcSecurityGroups?: VpcSecurityGroupMembership[];
    DBParameterGroups?: DBParameterGroupStatus[];
    AvailabilityZone?: string;
    DBSubnetGroup?: DBSubnetGroup;
    PreferredMaintenanceWindow?: string;
    UpgradeRolloutOrder?: UpgradeRolloutOrder;
    PendingModifiedValues?: PendingModifiedValues;
    LatestRestorableTime?: Date;
    MultiAZ?: boolean;
    EngineVersion?: string;
    AutoMinorVersionUpgrade?: boolean;
    ReadReplicaSourceDBInstanceIdentifier?: string;
    ReadReplicaDBInstanceIdentifiers?: string[];
    ReadReplicaDBClusterIdentifiers?: string[];
    ReplicaMode?: ReplicaMode;
    LicenseModel?: string;
    Iops?: number;
    StorageThroughput?: number;
    OptionGroupMemberships?: OptionGroupMembership[];
    CharacterSetName?: string;
    NcharCharacterSetName?: string;
    SecondaryAvailabilityZone?: string;
    PubliclyAccessible?: boolean;
    StatusInfos?: DBInstanceStatusInfo[];
    StorageType?: string;
    StorageEncryptionType?: StorageEncryptionType;
    TdeCredentialArn?: string;
    DbInstancePort?: number;
    DBClusterIdentifier?: string;
    StorageEncrypted?: boolean;
    KmsKeyId?: string;
    DbiResourceId?: string;
    CACertificateIdentifier?: string;
    DomainMemberships?: DomainMembership[];
    CopyTagsToSnapshot?: boolean;
    MonitoringInterval?: number;
    EnhancedMonitoringResourceArn?: string;
    MonitoringRoleArn?: string;
    PromotionTier?: number;
    DBInstanceArn?: string;
    Timezone?: string;
    IAMDatabaseAuthenticationEnabled?: boolean;
    DatabaseInsightsMode?: DatabaseInsightsMode;
    PerformanceInsightsEnabled?: boolean;
    PerformanceInsightsKMSKeyId?: string;
    PerformanceInsightsRetentionPeriod?: number;
    EnabledCloudwatchLogsExports?: string[];
    ProcessorFeatures?: ProcessorFeature[];
    DeletionProtection?: boolean;
    AssociatedRoles?: DBInstanceRole[];
    ListenerEndpoint?: Endpoint;
    MaxAllocatedStorage?: number;
    TagList?: Tag[];
    AutomationMode?: AutomationMode;
    ResumeFullAutomationModeTime?: Date;
    CustomerOwnedIpEnabled?: boolean;
    NetworkType?: string;
    ActivityStreamStatus?: ActivityStreamStatus;
    ActivityStreamKmsKeyId?: string;
    ActivityStreamKinesisStreamName?: string;
    ActivityStreamMode?: ActivityStreamMode;
    ActivityStreamEngineNativeAuditFieldsIncluded?: boolean;
    AwsBackupRecoveryPointArn?: string;
    DBInstanceAutomatedBackupsReplications?: DBInstanceAutomatedBackupsReplication[];
    BackupTarget?: string;
    AutomaticRestartTime?: Date;
    CustomIamInstanceProfile?: string;
    ActivityStreamPolicyStatus?: ActivityStreamPolicyStatus;
    CertificateDetails?: CertificateDetails;
    DBSystemId?: string;
    MasterUserSecret?: MasterUserSecret;
    ReadReplicaSourceDBClusterIdentifier?: string;
    PercentProgress?: string;
    MultiTenant?: boolean;
    DedicatedLogVolume?: boolean;
    IsStorageConfigUpgradeAvailable?: boolean;
    EngineLifecycleSupport?: string;
    AdditionalStorageVolumes?: AdditionalStorageVolumeOutput[];
    StorageVolumeStatus?: string;
    StorageOperationStatus?: string;
    StorageOperationPercentProgress?: number;
}
export interface CreateDBInstanceResult {
    DBInstance?: DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    };
}
export interface CreateDBInstanceReadReplicaMessage {
    DBInstanceIdentifier?: string;
    SourceDBInstanceIdentifier?: string;
    DBInstanceClass?: string;
    AvailabilityZone?: string;
    Port?: number;
    MultiAZ?: boolean;
    AutoMinorVersionUpgrade?: boolean;
    Iops?: number;
    StorageThroughput?: number;
    OptionGroupName?: string;
    DBParameterGroupName?: string;
    PubliclyAccessible?: boolean;
    Tags?: Tag[];
    DBSubnetGroupName?: string;
    VpcSecurityGroupIds?: string[];
    StorageType?: string;
    CopyTagsToSnapshot?: boolean;
    MonitoringInterval?: number;
    MonitoringRoleArn?: string;
    KmsKeyId?: string;
    PreSignedUrl?: string | redacted.Redacted<string>;
    EnableIAMDatabaseAuthentication?: boolean;
    DatabaseInsightsMode?: DatabaseInsightsMode;
    EnablePerformanceInsights?: boolean;
    PerformanceInsightsKMSKeyId?: string;
    PerformanceInsightsRetentionPeriod?: number;
    EnableCloudwatchLogsExports?: string[];
    ProcessorFeatures?: ProcessorFeature[];
    UseDefaultProcessorFeatures?: boolean;
    DeletionProtection?: boolean;
    Domain?: string;
    DomainIAMRoleName?: string;
    DomainFqdn?: string;
    DomainOu?: string;
    DomainAuthSecretArn?: string;
    DomainDnsIps?: string[];
    ReplicaMode?: ReplicaMode;
    EnableCustomerOwnedIp?: boolean;
    NetworkType?: string;
    MaxAllocatedStorage?: number;
    BackupTarget?: string;
    CustomIamInstanceProfile?: string;
    AllocatedStorage?: number;
    SourceDBClusterIdentifier?: string;
    DedicatedLogVolume?: boolean;
    UpgradeStorageConfig?: boolean;
    CACertificateIdentifier?: string;
    AdditionalStorageVolumes?: AdditionalStorageVolume[];
    TagSpecifications?: TagSpecification[];
}
export interface CreateDBInstanceReadReplicaResult {
    DBInstance?: DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    };
}
export interface CreateDBParameterGroupMessage {
    DBParameterGroupName?: string;
    DBParameterGroupFamily?: string;
    Description?: string;
    Tags?: Tag[];
}
export interface CreateDBParameterGroupResult {
    DBParameterGroup?: DBParameterGroup;
}
export type DBProxyName = string;
export type EngineFamily = "MYSQL" | "POSTGRESQL" | "SQLSERVER" | (string & {});
export type DefaultAuthScheme = "IAM_AUTH" | "NONE" | (string & {});
export type AuthUserName = string;
export type AuthScheme = "SECRETS" | (string & {});
export type Arn = string;
export type IAMAuthMode = "DISABLED" | "REQUIRED" | "ENABLED" | (string & {});
export type ClientPasswordAuthType = "MYSQL_NATIVE_PASSWORD" | "MYSQL_CACHING_SHA2_PASSWORD" | "POSTGRES_SCRAM_SHA_256" | "POSTGRES_MD5" | "SQL_SERVER_AUTHENTICATION" | (string & {});
export interface UserAuthConfig {
    Description?: string;
    UserName?: string;
    AuthScheme?: AuthScheme;
    SecretArn?: string;
    IAMAuth?: IAMAuthMode;
    ClientPasswordAuthType?: ClientPasswordAuthType;
}
export type UserAuthConfigList = UserAuthConfig[];
export type EndpointNetworkType = "IPV4" | "IPV6" | "DUAL" | (string & {});
export type TargetConnectionNetworkType = "IPV4" | "IPV6" | (string & {});
export interface CreateDBProxyRequest {
    DBProxyName?: string;
    EngineFamily?: EngineFamily;
    DefaultAuthScheme?: DefaultAuthScheme;
    Auth?: UserAuthConfig[];
    RoleArn?: string;
    VpcSubnetIds?: string[];
    VpcSecurityGroupIds?: string[];
    RequireTLS?: boolean;
    IdleClientTimeout?: number;
    DebugLogging?: boolean;
    Tags?: Tag[];
    EndpointNetworkType?: EndpointNetworkType;
    TargetConnectionNetworkType?: TargetConnectionNetworkType;
}
export type DBProxyStatus = "available" | "modifying" | "incompatible-network" | "insufficient-resource-limits" | "creating" | "deleting" | "suspended" | "suspending" | "reactivating" | (string & {});
export interface UserAuthConfigInfo {
    Description?: string;
    UserName?: string;
    AuthScheme?: AuthScheme;
    SecretArn?: string;
    IAMAuth?: IAMAuthMode;
    ClientPasswordAuthType?: ClientPasswordAuthType;
}
export type UserAuthConfigInfoList = UserAuthConfigInfo[];
export interface DBProxy {
    DBProxyName?: string;
    DBProxyArn?: string;
    Status?: DBProxyStatus;
    EngineFamily?: string;
    VpcId?: string;
    VpcSecurityGroupIds?: string[];
    VpcSubnetIds?: string[];
    DefaultAuthScheme?: string;
    Auth?: UserAuthConfigInfo[];
    RoleArn?: string;
    Endpoint?: string;
    RequireTLS?: boolean;
    IdleClientTimeout?: number;
    DebugLogging?: boolean;
    CreatedDate?: Date;
    UpdatedDate?: Date;
    EndpointNetworkType?: EndpointNetworkType;
    TargetConnectionNetworkType?: TargetConnectionNetworkType;
}
export interface CreateDBProxyResponse {
    DBProxy?: DBProxy;
}
export type DBProxyEndpointName = string;
export type DBProxyEndpointTargetRole = "READ_WRITE" | "READ_ONLY" | (string & {});
export interface CreateDBProxyEndpointRequest {
    DBProxyName?: string;
    DBProxyEndpointName?: string;
    VpcSubnetIds?: string[];
    VpcSecurityGroupIds?: string[];
    TargetRole?: DBProxyEndpointTargetRole;
    Tags?: Tag[];
    EndpointNetworkType?: EndpointNetworkType;
}
export type DBProxyEndpointStatus = "available" | "modifying" | "incompatible-network" | "insufficient-resource-limits" | "creating" | "deleting" | (string & {});
export interface DBProxyEndpoint {
    DBProxyEndpointName?: string;
    DBProxyEndpointArn?: string;
    DBProxyName?: string;
    Status?: DBProxyEndpointStatus;
    VpcId?: string;
    VpcSecurityGroupIds?: string[];
    VpcSubnetIds?: string[];
    Endpoint?: string;
    CreatedDate?: Date;
    TargetRole?: DBProxyEndpointTargetRole;
    IsDefault?: boolean;
    EndpointNetworkType?: EndpointNetworkType;
}
export interface CreateDBProxyEndpointResponse {
    DBProxyEndpoint?: DBProxyEndpoint;
}
export interface CreateDBSecurityGroupMessage {
    DBSecurityGroupName?: string;
    DBSecurityGroupDescription?: string;
    Tags?: Tag[];
}
export interface CreateDBSecurityGroupResult {
    DBSecurityGroup?: DBSecurityGroup;
}
export interface CreateDBShardGroupMessage {
    DBShardGroupIdentifier?: string;
    DBClusterIdentifier?: string;
    ComputeRedundancy?: number;
    MaxACU?: number;
    MinACU?: number;
    PubliclyAccessible?: boolean;
    Tags?: Tag[];
}
export type DBShardGroupIdentifier = string;
export interface DBShardGroup {
    DBShardGroupResourceId?: string;
    DBShardGroupIdentifier?: string;
    DBClusterIdentifier?: string;
    MaxACU?: number;
    MinACU?: number;
    ComputeRedundancy?: number;
    Status?: string;
    PubliclyAccessible?: boolean;
    Endpoint?: string;
    DBShardGroupArn?: string;
    TagList?: Tag[];
}
export interface CreateDBSnapshotMessage {
    DBSnapshotIdentifier?: string;
    DBInstanceIdentifier?: string;
    Tags?: Tag[];
}
export interface CreateDBSnapshotResult {
    DBSnapshot?: DBSnapshot & {
        AdditionalStorageVolumes: (AdditionalStorageVolume & {
            VolumeName: string;
        })[];
    };
}
export type SubnetIdentifierList = string[];
export interface CreateDBSubnetGroupMessage {
    DBSubnetGroupName?: string;
    DBSubnetGroupDescription?: string;
    SubnetIds?: string[];
    Tags?: Tag[];
}
export interface CreateDBSubnetGroupResult {
    DBSubnetGroup?: DBSubnetGroup;
}
export interface CreateEventSubscriptionMessage {
    SubscriptionName?: string;
    SnsTopicArn?: string;
    SourceType?: string;
    EventCategories?: string[];
    SourceIds?: string[];
    Enabled?: boolean;
    Tags?: Tag[];
}
export interface CreateEventSubscriptionResult {
    EventSubscription?: EventSubscription;
}
export interface CreateGlobalClusterMessage {
    GlobalClusterIdentifier?: string;
    SourceDBClusterIdentifier?: string;
    Engine?: string;
    EngineVersion?: string;
    EngineLifecycleSupport?: string;
    DeletionProtection?: boolean;
    DatabaseName?: string;
    StorageEncrypted?: boolean;
    Tags?: Tag[];
}
export type ReadersArnList = string[];
export type GlobalClusterMemberSynchronizationStatus = "connected" | "pending-resync" | (string & {});
export interface GlobalClusterMember {
    DBClusterArn?: string;
    Readers?: string[];
    IsWriter?: boolean;
    GlobalWriteForwardingStatus?: WriteForwardingStatus;
    SynchronizationStatus?: GlobalClusterMemberSynchronizationStatus;
}
export type GlobalClusterMemberList = GlobalClusterMember[];
export type FailoverStatus = "pending" | "failing-over" | "cancelling" | (string & {});
export interface FailoverState {
    Status?: FailoverStatus;
    FromDbClusterArn?: string;
    ToDbClusterArn?: string;
    IsDataLossAllowed?: boolean;
}
export interface GlobalCluster {
    GlobalClusterIdentifier?: string;
    GlobalClusterResourceId?: string;
    GlobalClusterArn?: string;
    Status?: string;
    Engine?: string;
    EngineVersion?: string;
    EngineLifecycleSupport?: string;
    DatabaseName?: string;
    StorageEncrypted?: boolean;
    StorageEncryptionType?: StorageEncryptionType;
    DeletionProtection?: boolean;
    GlobalClusterMembers?: GlobalClusterMember[];
    Endpoint?: string;
    FailoverState?: FailoverState;
    TagList?: Tag[];
}
export interface CreateGlobalClusterResult {
    GlobalCluster?: GlobalCluster;
}
export type SourceArn = string;
export type IntegrationName = string;
export type EncryptionContextMap = {
    [key: string]: string | undefined;
};
export type DataFilter = string;
export type IntegrationDescription = string;
export interface CreateIntegrationMessage {
    SourceArn?: string;
    TargetArn?: string;
    IntegrationName?: string;
    KMSKeyId?: string;
    AdditionalEncryptionContext?: {
        [key: string]: string | undefined;
    };
    Tags?: Tag[];
    DataFilter?: string;
    Description?: string;
}
export type IntegrationArn = string;
export type IntegrationStatus = "creating" | "active" | "modifying" | "failed" | "deleting" | "syncing" | "needs_attention" | (string & {});
export interface IntegrationError {
    ErrorCode?: string;
    ErrorMessage?: string;
}
export type IntegrationErrorList = IntegrationError[];
export interface Integration {
    SourceArn?: string;
    TargetArn?: string;
    IntegrationName?: string;
    IntegrationArn?: string;
    KMSKeyId?: string;
    AdditionalEncryptionContext?: {
        [key: string]: string | undefined;
    };
    Status?: IntegrationStatus;
    Tags?: Tag[];
    DataFilter?: string;
    Description?: string;
    CreateTime?: Date;
    Errors?: (IntegrationError & {
        ErrorCode: string;
    })[];
}
export interface CreateOptionGroupMessage {
    OptionGroupName?: string;
    EngineName?: string;
    MajorEngineVersion?: string;
    OptionGroupDescription?: string;
    Tags?: Tag[];
}
export interface CreateOptionGroupResult {
    OptionGroup?: OptionGroup;
}
export interface CreateTenantDatabaseMessage {
    DBInstanceIdentifier?: string;
    TenantDBName?: string;
    MasterUsername?: string;
    MasterUserPassword?: string | redacted.Redacted<string>;
    CharacterSetName?: string;
    NcharCharacterSetName?: string;
    ManageMasterUserPassword?: boolean;
    MasterUserSecretKmsKeyId?: string;
    Tags?: Tag[];
}
export interface TenantDatabasePendingModifiedValues {
    MasterUserPassword?: string | redacted.Redacted<string>;
    TenantDBName?: string;
}
export interface TenantDatabase {
    TenantDatabaseCreateTime?: Date;
    DBInstanceIdentifier?: string;
    TenantDBName?: string;
    Status?: string;
    MasterUsername?: string;
    DbiResourceId?: string;
    TenantDatabaseResourceId?: string;
    TenantDatabaseARN?: string;
    CharacterSetName?: string;
    NcharCharacterSetName?: string;
    DeletionProtection?: boolean;
    PendingModifiedValues?: TenantDatabasePendingModifiedValues;
    MasterUserSecret?: MasterUserSecret;
    TagList?: Tag[];
}
export interface CreateTenantDatabaseResult {
    TenantDatabase?: TenantDatabase;
}
export interface DeleteBlueGreenDeploymentRequest {
    BlueGreenDeploymentIdentifier?: string;
    DeleteTarget?: boolean;
}
export interface DeleteBlueGreenDeploymentResponse {
    BlueGreenDeployment?: BlueGreenDeployment;
}
export interface DeleteCustomDBEngineVersionMessage {
    Engine?: string;
    EngineVersion?: string;
}
export interface DeleteDBClusterMessage {
    DBClusterIdentifier?: string;
    SkipFinalSnapshot?: boolean;
    FinalDBSnapshotIdentifier?: string;
    DeleteAutomatedBackups?: boolean;
}
export interface DeleteDBClusterResult {
    DBCluster?: DBCluster;
}
export interface DeleteDBClusterAutomatedBackupMessage {
    DbClusterResourceId?: string;
}
export interface RestoreWindow {
    EarliestTime?: Date;
    LatestTime?: Date;
}
export interface DBClusterAutomatedBackup {
    Engine?: string;
    VpcId?: string;
    DBClusterAutomatedBackupsArn?: string;
    DBClusterIdentifier?: string;
    RestoreWindow?: RestoreWindow;
    MasterUsername?: string;
    DbClusterResourceId?: string;
    Region?: string;
    LicenseModel?: string;
    Status?: string;
    IAMDatabaseAuthenticationEnabled?: boolean;
    ClusterCreateTime?: Date;
    StorageEncrypted?: boolean;
    StorageEncryptionType?: StorageEncryptionType;
    AllocatedStorage?: number;
    EngineVersion?: string;
    DBClusterArn?: string;
    BackupRetentionPeriod?: number;
    PreferredBackupWindow?: string;
    EngineMode?: string;
    AvailabilityZones?: string[];
    Port?: number;
    KmsKeyId?: string;
    StorageType?: string;
    Iops?: number;
    StorageThroughput?: number;
    AwsBackupRecoveryPointArn?: string;
    TagList?: Tag[];
}
export interface DeleteDBClusterAutomatedBackupResult {
    DBClusterAutomatedBackup?: DBClusterAutomatedBackup;
}
export interface DeleteDBClusterEndpointMessage {
    DBClusterEndpointIdentifier?: string;
}
export interface DeleteDBClusterParameterGroupMessage {
    DBClusterParameterGroupName?: string;
}
export interface DeleteDBClusterParameterGroupResponse {
}
export interface DeleteDBClusterSnapshotMessage {
    DBClusterSnapshotIdentifier?: string;
}
export interface DeleteDBClusterSnapshotResult {
    DBClusterSnapshot?: DBClusterSnapshot;
}
export interface DeleteDBInstanceMessage {
    DBInstanceIdentifier?: string;
    SkipFinalSnapshot?: boolean;
    FinalDBSnapshotIdentifier?: string;
    DeleteAutomatedBackups?: boolean;
}
export interface DeleteDBInstanceResult {
    DBInstance?: DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    };
}
export interface DeleteDBInstanceAutomatedBackupMessage {
    DbiResourceId?: string;
    DBInstanceAutomatedBackupsArn?: string;
}
export interface DBInstanceAutomatedBackup {
    DBInstanceArn?: string;
    DbiResourceId?: string;
    Region?: string;
    DBInstanceIdentifier?: string;
    RestoreWindow?: RestoreWindow;
    AllocatedStorage?: number;
    Status?: string;
    Port?: number;
    AvailabilityZone?: string;
    VpcId?: string;
    InstanceCreateTime?: Date;
    MasterUsername?: string;
    Engine?: string;
    EngineVersion?: string;
    LicenseModel?: string;
    Iops?: number;
    StorageThroughput?: number;
    OptionGroupName?: string;
    TdeCredentialArn?: string;
    Encrypted?: boolean;
    StorageEncryptionType?: StorageEncryptionType;
    StorageType?: string;
    KmsKeyId?: string;
    Timezone?: string;
    IAMDatabaseAuthenticationEnabled?: boolean;
    BackupRetentionPeriod?: number;
    PreferredBackupWindow?: string;
    DBInstanceAutomatedBackupsArn?: string;
    DBInstanceAutomatedBackupsReplications?: DBInstanceAutomatedBackupsReplication[];
    BackupTarget?: string;
    MultiTenant?: boolean;
    AwsBackupRecoveryPointArn?: string;
    TagList?: Tag[];
    DedicatedLogVolume?: boolean;
    AdditionalStorageVolumes?: AdditionalStorageVolume[];
}
export interface DeleteDBInstanceAutomatedBackupResult {
    DBInstanceAutomatedBackup?: DBInstanceAutomatedBackup & {
        AdditionalStorageVolumes: (AdditionalStorageVolume & {
            VolumeName: string;
        })[];
    };
}
export interface DeleteDBParameterGroupMessage {
    DBParameterGroupName?: string;
}
export interface DeleteDBParameterGroupResponse {
}
export interface DeleteDBProxyRequest {
    DBProxyName?: string;
}
export interface DeleteDBProxyResponse {
    DBProxy?: DBProxy;
}
export interface DeleteDBProxyEndpointRequest {
    DBProxyEndpointName?: string;
}
export interface DeleteDBProxyEndpointResponse {
    DBProxyEndpoint?: DBProxyEndpoint;
}
export interface DeleteDBSecurityGroupMessage {
    DBSecurityGroupName?: string;
}
export interface DeleteDBSecurityGroupResponse {
}
export interface DeleteDBShardGroupMessage {
    DBShardGroupIdentifier?: string;
}
export interface DeleteDBSnapshotMessage {
    DBSnapshotIdentifier?: string;
}
export interface DeleteDBSnapshotResult {
    DBSnapshot?: DBSnapshot & {
        AdditionalStorageVolumes: (AdditionalStorageVolume & {
            VolumeName: string;
        })[];
    };
}
export interface DeleteDBSubnetGroupMessage {
    DBSubnetGroupName?: string;
}
export interface DeleteDBSubnetGroupResponse {
}
export interface DeleteEventSubscriptionMessage {
    SubscriptionName?: string;
}
export interface DeleteEventSubscriptionResult {
    EventSubscription?: EventSubscription;
}
export interface DeleteGlobalClusterMessage {
    GlobalClusterIdentifier?: string;
}
export interface DeleteGlobalClusterResult {
    GlobalCluster?: GlobalCluster;
}
export type IntegrationIdentifier = string;
export interface DeleteIntegrationMessage {
    IntegrationIdentifier?: string;
}
export interface DeleteOptionGroupMessage {
    OptionGroupName?: string;
}
export interface DeleteOptionGroupResponse {
}
export interface DeleteTenantDatabaseMessage {
    DBInstanceIdentifier?: string;
    TenantDBName?: string;
    SkipFinalSnapshot?: boolean;
    FinalDBSnapshotIdentifier?: string;
}
export interface DeleteTenantDatabaseResult {
    TenantDatabase?: TenantDatabase;
}
export type DBProxyTargetGroupName = string;
export interface DeregisterDBProxyTargetsRequest {
    DBProxyName?: string;
    TargetGroupName?: string;
    DBInstanceIdentifiers?: string[];
    DBClusterIdentifiers?: string[];
}
export interface DeregisterDBProxyTargetsResponse {
}
export interface DescribeAccountAttributesMessage {
}
export interface AccountQuota {
    AccountQuotaName?: string;
    Used?: number;
    Max?: number;
}
export type AccountQuotaList = AccountQuota[];
export interface AccountAttributesMessage {
    AccountQuotas?: AccountQuota[];
}
export type FilterValueList = string[];
export interface Filter {
    Name?: string;
    Values?: string[];
}
export type FilterList = Filter[];
export type MaxRecords = number;
export interface DescribeBlueGreenDeploymentsRequest {
    BlueGreenDeploymentIdentifier?: string;
    Filters?: Filter[];
    Marker?: string;
    MaxRecords?: number;
}
export type BlueGreenDeploymentList = BlueGreenDeployment[];
export interface DescribeBlueGreenDeploymentsResponse {
    BlueGreenDeployments?: BlueGreenDeployment[];
    Marker?: string;
}
export interface DescribeCertificatesMessage {
    CertificateIdentifier?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export interface Certificate {
    CertificateIdentifier?: string;
    CertificateType?: string;
    Thumbprint?: string;
    ValidFrom?: Date;
    ValidTill?: Date;
    CertificateArn?: string;
    CustomerOverride?: boolean;
    CustomerOverrideValidTill?: Date;
}
export type CertificateList = Certificate[];
export interface CertificateMessage {
    DefaultCertificateForNewLaunches?: string;
    Certificates?: Certificate[];
    Marker?: string;
}
export interface DescribeDBClusterAutomatedBackupsMessage {
    DbClusterResourceId?: string;
    DBClusterIdentifier?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type DBClusterAutomatedBackupList = DBClusterAutomatedBackup[];
export interface DBClusterAutomatedBackupMessage {
    Marker?: string;
    DBClusterAutomatedBackups?: DBClusterAutomatedBackup[];
}
export interface DescribeDBClusterBacktracksMessage {
    DBClusterIdentifier?: string;
    BacktrackIdentifier?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type DBClusterBacktrackList = DBClusterBacktrack[];
export interface DBClusterBacktrackMessage {
    Marker?: string;
    DBClusterBacktracks?: DBClusterBacktrack[];
}
export interface DescribeDBClusterEndpointsMessage {
    DBClusterIdentifier?: string;
    DBClusterEndpointIdentifier?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type DBClusterEndpointList = DBClusterEndpoint[];
export interface DBClusterEndpointMessage {
    Marker?: string;
    DBClusterEndpoints?: DBClusterEndpoint[];
}
export interface DescribeDBClusterParameterGroupsMessage {
    DBClusterParameterGroupName?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type DBClusterParameterGroupList = DBClusterParameterGroup[];
export interface DBClusterParameterGroupsMessage {
    Marker?: string;
    DBClusterParameterGroups?: DBClusterParameterGroup[];
}
export interface DescribeDBClusterParametersMessage {
    DBClusterParameterGroupName?: string;
    Source?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type PotentiallySensitiveParameterValue = string;
export type ApplyMethod = "immediate" | "pending-reboot" | (string & {});
export interface Parameter {
    ParameterName?: string;
    ParameterValue?: string;
    Description?: string;
    Source?: string;
    ApplyType?: string;
    DataType?: string;
    AllowedValues?: string;
    IsModifiable?: boolean;
    MinimumEngineVersion?: string;
    ApplyMethod?: ApplyMethod;
    SupportedEngineModes?: string[];
}
export type ParametersList = Parameter[];
export interface DBClusterParameterGroupDetails {
    Parameters?: Parameter[];
    Marker?: string;
}
export interface DescribeDBClustersMessage {
    DBClusterIdentifier?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
    IncludeShared?: boolean;
}
export type DBClusterList = DBCluster[];
export interface DBClusterMessage {
    Marker?: string;
    DBClusters?: DBCluster[];
}
export interface DescribeDBClusterSnapshotAttributesMessage {
    DBClusterSnapshotIdentifier?: string;
}
export type AttributeValueList = string[];
export interface DBClusterSnapshotAttribute {
    AttributeName?: string;
    AttributeValues?: string[];
}
export type DBClusterSnapshotAttributeList = DBClusterSnapshotAttribute[];
export interface DBClusterSnapshotAttributesResult {
    DBClusterSnapshotIdentifier?: string;
    DBClusterSnapshotAttributes?: DBClusterSnapshotAttribute[];
}
export interface DescribeDBClusterSnapshotAttributesResult {
    DBClusterSnapshotAttributesResult?: DBClusterSnapshotAttributesResult;
}
export interface DescribeDBClusterSnapshotsMessage {
    DBClusterIdentifier?: string;
    DBClusterSnapshotIdentifier?: string;
    SnapshotType?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
    IncludeShared?: boolean;
    IncludePublic?: boolean;
    DbClusterResourceId?: string;
}
export type DBClusterSnapshotList = DBClusterSnapshot[];
export interface DBClusterSnapshotMessage {
    Marker?: string;
    DBClusterSnapshots?: DBClusterSnapshot[];
}
export interface DescribeDBEngineVersionsMessage {
    Engine?: string;
    EngineVersion?: string;
    DBParameterGroupFamily?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
    DefaultOnly?: boolean;
    ListSupportedCharacterSets?: boolean;
    ListSupportedTimezones?: boolean;
    IncludeAll?: boolean;
}
export type DBEngineVersionList = DBEngineVersion[];
export interface DBEngineVersionMessage {
    Marker?: string;
    DBEngineVersions?: DBEngineVersion[];
}
export interface DescribeDBInstanceAutomatedBackupsMessage {
    DbiResourceId?: string;
    DBInstanceIdentifier?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
    DBInstanceAutomatedBackupsArn?: string;
}
export type DBInstanceAutomatedBackupList = DBInstanceAutomatedBackup[];
export interface DBInstanceAutomatedBackupMessage {
    Marker?: string;
    DBInstanceAutomatedBackups?: (DBInstanceAutomatedBackup & {
        AdditionalStorageVolumes: (AdditionalStorageVolume & {
            VolumeName: string;
        })[];
    })[];
}
export interface DescribeDBInstancesMessage {
    DBInstanceIdentifier?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type DBInstanceList = DBInstance[];
export interface DBInstanceMessage {
    Marker?: string;
    DBInstances?: (DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    })[];
}
export interface DescribeDBLogFilesMessage {
    DBInstanceIdentifier?: string;
    FilenameContains?: string;
    FileLastWritten?: number;
    FileSize?: number;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export interface DescribeDBLogFilesDetails {
    LogFileName?: string;
    LastWritten?: number;
    Size?: number;
}
export type DescribeDBLogFilesList = DescribeDBLogFilesDetails[];
export interface DescribeDBLogFilesResponse {
    DescribeDBLogFiles?: DescribeDBLogFilesDetails[];
    Marker?: string;
}
export type Engine = string;
export type MajorEngineVersion = string;
export type Marker = string;
export interface DescribeDBMajorEngineVersionsRequest {
    Engine?: string;
    MajorEngineVersion?: string;
    Marker?: string;
    MaxRecords?: number;
}
export type LifecycleSupportName = "open-source-rds-standard-support" | "open-source-rds-extended-support" | (string & {});
export interface SupportedEngineLifecycle {
    LifecycleSupportName?: LifecycleSupportName;
    LifecycleSupportStartDate?: Date;
    LifecycleSupportEndDate?: Date;
}
export type SupportedEngineLifecycleList = SupportedEngineLifecycle[];
export interface DBMajorEngineVersion {
    Engine?: string;
    MajorEngineVersion?: string;
    SupportedEngineLifecycles?: SupportedEngineLifecycle[];
}
export type DBMajorEngineVersionsList = DBMajorEngineVersion[];
export interface DescribeDBMajorEngineVersionsResponse {
    DBMajorEngineVersions?: (DBMajorEngineVersion & {
        SupportedEngineLifecycles: (SupportedEngineLifecycle & {
            LifecycleSupportName: LifecycleSupportName;
            LifecycleSupportStartDate: Date;
            LifecycleSupportEndDate: Date;
        })[];
    })[];
    Marker?: string;
}
export interface DescribeDBParameterGroupsMessage {
    DBParameterGroupName?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type DBParameterGroupList = DBParameterGroup[];
export interface DBParameterGroupsMessage {
    Marker?: string;
    DBParameterGroups?: DBParameterGroup[];
}
export interface DescribeDBParametersMessage {
    DBParameterGroupName?: string;
    Source?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export interface DBParameterGroupDetails {
    Parameters?: Parameter[];
    Marker?: string;
}
export interface DescribeDBProxiesRequest {
    DBProxyName?: string;
    Filters?: Filter[];
    Marker?: string;
    MaxRecords?: number;
}
export type DBProxyList = DBProxy[];
export interface DescribeDBProxiesResponse {
    DBProxies?: DBProxy[];
    Marker?: string;
}
export interface DescribeDBProxyEndpointsRequest {
    DBProxyName?: string;
    DBProxyEndpointName?: string;
    Filters?: Filter[];
    Marker?: string;
    MaxRecords?: number;
}
export type DBProxyEndpointList = DBProxyEndpoint[];
export interface DescribeDBProxyEndpointsResponse {
    DBProxyEndpoints?: DBProxyEndpoint[];
    Marker?: string;
}
export interface DescribeDBProxyTargetGroupsRequest {
    DBProxyName?: string;
    TargetGroupName?: string;
    Filters?: Filter[];
    Marker?: string;
    MaxRecords?: number;
}
export type OperatorSensitiveString = string | redacted.Redacted<string>;
export interface ConnectionPoolConfigurationInfo {
    MaxConnectionsPercent?: number;
    MaxIdleConnectionsPercent?: number;
    ConnectionBorrowTimeout?: number;
    SessionPinningFilters?: string[];
    InitQuery?: string | redacted.Redacted<string>;
}
export interface DBProxyTargetGroup {
    DBProxyName?: string;
    TargetGroupName?: string;
    TargetGroupArn?: string;
    IsDefault?: boolean;
    Status?: string;
    ConnectionPoolConfig?: ConnectionPoolConfigurationInfo;
    CreatedDate?: Date;
    UpdatedDate?: Date;
}
export type TargetGroupList = DBProxyTargetGroup[];
export interface DescribeDBProxyTargetGroupsResponse {
    TargetGroups?: DBProxyTargetGroup[];
    Marker?: string;
}
export interface DescribeDBProxyTargetsRequest {
    DBProxyName?: string;
    TargetGroupName?: string;
    Filters?: Filter[];
    Marker?: string;
    MaxRecords?: number;
}
export type TargetType = "RDS_INSTANCE" | "RDS_SERVERLESS_ENDPOINT" | "TRACKED_CLUSTER" | (string & {});
export type TargetRole = "READ_WRITE" | "READ_ONLY" | "UNKNOWN" | (string & {});
export type TargetState = "REGISTERING" | "AVAILABLE" | "UNAVAILABLE" | "UNUSED" | (string & {});
export type TargetHealthReason = "UNREACHABLE" | "CONNECTION_FAILED" | "AUTH_FAILURE" | "PENDING_PROXY_CAPACITY" | "INVALID_REPLICATION_STATE" | "PROMOTED" | (string & {});
export interface TargetHealth {
    State?: TargetState;
    Reason?: TargetHealthReason;
    Description?: string;
}
export interface DBProxyTarget {
    TargetArn?: string;
    Endpoint?: string;
    TrackedClusterId?: string;
    RdsResourceId?: string;
    Port?: number;
    Type?: TargetType;
    Role?: TargetRole;
    TargetHealth?: TargetHealth;
}
export type TargetList = DBProxyTarget[];
export interface DescribeDBProxyTargetsResponse {
    Targets?: DBProxyTarget[];
    Marker?: string;
}
export interface DescribeDBRecommendationsMessage {
    LastUpdatedAfter?: Date;
    LastUpdatedBefore?: Date;
    Locale?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export interface RecommendedActionParameter {
    Key?: string;
    Value?: string;
}
export type RecommendedActionParameterList = RecommendedActionParameter[];
export interface ScalarReferenceDetails {
    Value?: number;
}
export interface ReferenceDetails {
    ScalarReferenceDetails?: ScalarReferenceDetails;
}
export interface MetricReference {
    Name?: string;
    ReferenceDetails?: ReferenceDetails;
}
export type MetricReferenceList = MetricReference[];
export interface PerformanceInsightsMetricDimensionGroup {
    Dimensions?: string[];
    Group?: string;
    Limit?: number;
}
export interface PerformanceInsightsMetricQuery {
    GroupBy?: PerformanceInsightsMetricDimensionGroup;
    Metric?: string;
}
export interface MetricQuery {
    PerformanceInsightsMetricQuery?: PerformanceInsightsMetricQuery;
}
export interface Metric {
    Name?: string;
    References?: MetricReference[];
    StatisticsDetails?: string;
    MetricQuery?: MetricQuery;
}
export type MetricList = Metric[];
export interface PerformanceIssueDetails {
    StartTime?: Date;
    EndTime?: Date;
    Metrics?: Metric[];
    Analysis?: string;
}
export interface IssueDetails {
    PerformanceIssueDetails?: PerformanceIssueDetails;
}
export interface ContextAttribute {
    Key?: string;
    Value?: string;
}
export type ContextAttributeList = ContextAttribute[];
export interface RecommendedAction {
    ActionId?: string;
    Title?: string;
    Description?: string;
    Operation?: string;
    Parameters?: RecommendedActionParameter[];
    ApplyModes?: string[];
    Status?: string;
    IssueDetails?: IssueDetails;
    ContextAttributes?: ContextAttribute[];
}
export type RecommendedActionList = RecommendedAction[];
export interface DocLink {
    Text?: string;
    Url?: string;
}
export type DocLinkList = DocLink[];
export interface DBRecommendation {
    RecommendationId?: string;
    TypeId?: string;
    Severity?: string;
    ResourceArn?: string;
    Status?: string;
    CreatedTime?: Date;
    UpdatedTime?: Date;
    Detection?: string;
    Recommendation?: string;
    Description?: string;
    Reason?: string;
    RecommendedActions?: RecommendedAction[];
    Category?: string;
    Source?: string;
    TypeDetection?: string;
    TypeRecommendation?: string;
    Impact?: string;
    AdditionalInfo?: string;
    Links?: DocLink[];
    IssueDetails?: IssueDetails;
}
export type DBRecommendationList = DBRecommendation[];
export interface DBRecommendationsMessage {
    DBRecommendations?: DBRecommendation[];
    Marker?: string;
}
export interface DescribeDBSecurityGroupsMessage {
    DBSecurityGroupName?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type DBSecurityGroups = DBSecurityGroup[];
export interface DBSecurityGroupMessage {
    Marker?: string;
    DBSecurityGroups?: DBSecurityGroup[];
}
export interface DescribeDBShardGroupsMessage {
    DBShardGroupIdentifier?: string;
    Filters?: Filter[];
    Marker?: string;
    MaxRecords?: number;
}
export type DBShardGroupsList = DBShardGroup[];
export interface DescribeDBShardGroupsResponse {
    DBShardGroups?: DBShardGroup[];
    Marker?: string;
}
export interface DescribeDBSnapshotAttributesMessage {
    DBSnapshotIdentifier?: string;
}
export interface DBSnapshotAttribute {
    AttributeName?: string;
    AttributeValues?: string[];
}
export type DBSnapshotAttributeList = DBSnapshotAttribute[];
export interface DBSnapshotAttributesResult {
    DBSnapshotIdentifier?: string;
    DBSnapshotAttributes?: DBSnapshotAttribute[];
}
export interface DescribeDBSnapshotAttributesResult {
    DBSnapshotAttributesResult?: DBSnapshotAttributesResult;
}
export interface DescribeDBSnapshotsMessage {
    DBInstanceIdentifier?: string;
    DBSnapshotIdentifier?: string;
    SnapshotType?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
    IncludeShared?: boolean;
    IncludePublic?: boolean;
    DbiResourceId?: string;
}
export type DBSnapshotList = DBSnapshot[];
export interface DBSnapshotMessage {
    Marker?: string;
    DBSnapshots?: (DBSnapshot & {
        AdditionalStorageVolumes: (AdditionalStorageVolume & {
            VolumeName: string;
        })[];
    })[];
}
export interface DescribeDBSnapshotTenantDatabasesMessage {
    DBInstanceIdentifier?: string;
    DBSnapshotIdentifier?: string;
    SnapshotType?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
    DbiResourceId?: string;
}
export interface DBSnapshotTenantDatabase {
    DBSnapshotIdentifier?: string;
    DBInstanceIdentifier?: string;
    DbiResourceId?: string;
    EngineName?: string;
    SnapshotType?: string;
    TenantDatabaseCreateTime?: Date;
    TenantDBName?: string;
    MasterUsername?: string;
    TenantDatabaseResourceId?: string;
    CharacterSetName?: string;
    DBSnapshotTenantDatabaseARN?: string;
    NcharCharacterSetName?: string;
    TagList?: Tag[];
}
export type DBSnapshotTenantDatabasesList = DBSnapshotTenantDatabase[];
export interface DBSnapshotTenantDatabasesMessage {
    Marker?: string;
    DBSnapshotTenantDatabases?: DBSnapshotTenantDatabase[];
}
export interface DescribeDBSubnetGroupsMessage {
    DBSubnetGroupName?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type DBSubnetGroups = DBSubnetGroup[];
export interface DBSubnetGroupMessage {
    Marker?: string;
    DBSubnetGroups?: DBSubnetGroup[];
}
export interface DescribeEngineDefaultClusterParametersMessage {
    DBParameterGroupFamily?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export interface EngineDefaults {
    DBParameterGroupFamily?: string;
    Marker?: string;
    Parameters?: Parameter[];
}
export interface DescribeEngineDefaultClusterParametersResult {
    EngineDefaults?: EngineDefaults;
}
export interface DescribeEngineDefaultParametersMessage {
    DBParameterGroupFamily?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export interface DescribeEngineDefaultParametersResult {
    EngineDefaults?: EngineDefaults;
}
export interface DescribeEventCategoriesMessage {
    SourceType?: string;
    Filters?: Filter[];
}
export interface EventCategoriesMap {
    SourceType?: string;
    EventCategories?: string[];
}
export type EventCategoriesMapList = EventCategoriesMap[];
export interface EventCategoriesMessage {
    EventCategoriesMapList?: EventCategoriesMap[];
}
export type SourceType = "db-instance" | "db-parameter-group" | "db-security-group" | "db-snapshot" | "db-cluster" | "db-cluster-snapshot" | "custom-engine-version" | "db-proxy" | "blue-green-deployment" | "db-shard-group" | "zero-etl" | (string & {});
export interface DescribeEventsMessage {
    SourceIdentifier?: string;
    SourceType?: SourceType;
    StartTime?: Date;
    EndTime?: Date;
    Duration?: number;
    EventCategories?: string[];
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export interface Event {
    SourceIdentifier?: string;
    SourceType?: SourceType;
    Message?: string;
    EventCategories?: string[];
    Date?: Date;
    SourceArn?: string;
}
export type EventList = Event[];
export interface EventsMessage {
    Marker?: string;
    Events?: Event[];
}
export interface DescribeEventSubscriptionsMessage {
    SubscriptionName?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type EventSubscriptionsList = EventSubscription[];
export interface EventSubscriptionsMessage {
    Marker?: string;
    EventSubscriptionsList?: EventSubscription[];
}
export interface DescribeExportTasksMessage {
    ExportTaskIdentifier?: string;
    SourceArn?: string;
    Filters?: Filter[];
    Marker?: string;
    MaxRecords?: number;
    SourceType?: ExportSourceType;
}
export type ExportTasksList = ExportTask[];
export interface ExportTasksMessage {
    Marker?: string;
    ExportTasks?: ExportTask[];
}
export interface DescribeGlobalClustersMessage {
    GlobalClusterIdentifier?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type GlobalClusterList = GlobalCluster[];
export interface GlobalClustersMessage {
    Marker?: string;
    GlobalClusters?: GlobalCluster[];
}
export interface DescribeIntegrationsMessage {
    IntegrationIdentifier?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type IntegrationList = Integration[];
export interface DescribeIntegrationsResponse {
    Marker?: string;
    Integrations?: (Integration & {
        Errors: (IntegrationError & {
            ErrorCode: string;
        })[];
    })[];
}
export interface DescribeOptionGroupOptionsMessage {
    EngineName?: string;
    MajorEngineVersion?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type OptionsDependedOn = string[];
export type OptionsConflictsWith = string[];
export interface MinimumEngineVersionPerAllowedValue {
    AllowedValue?: string;
    MinimumEngineVersion?: string;
}
export type MinimumEngineVersionPerAllowedValueList = MinimumEngineVersionPerAllowedValue[];
export interface OptionGroupOptionSetting {
    SettingName?: string;
    SettingDescription?: string;
    DefaultValue?: string;
    ApplyType?: string;
    AllowedValues?: string;
    IsModifiable?: boolean;
    IsRequired?: boolean;
    MinimumEngineVersionPerAllowedValue?: MinimumEngineVersionPerAllowedValue[];
}
export type OptionGroupOptionSettingsList = OptionGroupOptionSetting[];
export interface OptionVersion {
    Version?: string;
    IsDefault?: boolean;
}
export type OptionGroupOptionVersionsList = OptionVersion[];
export interface OptionGroupOption {
    Name?: string;
    Description?: string;
    EngineName?: string;
    MajorEngineVersion?: string;
    MinimumRequiredMinorEngineVersion?: string;
    PortRequired?: boolean;
    DefaultPort?: number;
    OptionsDependedOn?: string[];
    OptionsConflictsWith?: string[];
    Persistent?: boolean;
    Permanent?: boolean;
    RequiresAutoMinorEngineVersionUpgrade?: boolean;
    VpcOnly?: boolean;
    SupportsOptionVersionDowngrade?: boolean;
    OptionGroupOptionSettings?: OptionGroupOptionSetting[];
    OptionGroupOptionVersions?: OptionVersion[];
    CopyableCrossAccount?: boolean;
}
export type OptionGroupOptionsList = OptionGroupOption[];
export interface OptionGroupOptionsMessage {
    OptionGroupOptions?: OptionGroupOption[];
    Marker?: string;
}
export interface DescribeOptionGroupsMessage {
    OptionGroupName?: string;
    Filters?: Filter[];
    Marker?: string;
    MaxRecords?: number;
    EngineName?: string;
    MajorEngineVersion?: string;
}
export type OptionGroupsList = OptionGroup[];
export interface OptionGroups {
    OptionGroupsList?: OptionGroup[];
    Marker?: string;
}
export interface DescribeOrderableDBInstanceOptionsMessage {
    Engine?: string;
    EngineVersion?: string;
    DBInstanceClass?: string;
    LicenseModel?: string;
    AvailabilityZoneGroup?: string;
    Vpc?: boolean;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type AvailabilityZoneList = AvailabilityZone[];
export interface AvailableProcessorFeature {
    Name?: string;
    DefaultValue?: string;
    AllowedValues?: string;
}
export type AvailableProcessorFeatureList = AvailableProcessorFeature[];
export type ActivityStreamModeList = string[];
export interface AvailableAdditionalStorageVolumesOption {
    SupportsStorageAutoscaling?: boolean;
    SupportsStorageThroughput?: boolean;
    SupportsIops?: boolean;
    StorageType?: string;
    MinStorageSize?: number;
    MaxStorageSize?: number;
    MinIops?: number;
    MaxIops?: number;
    MinIopsPerGib?: number;
    MaxIopsPerGib?: number;
    MinStorageThroughput?: number;
    MaxStorageThroughput?: number;
}
export type AvailableAdditionalStorageVolumesOptionList = AvailableAdditionalStorageVolumesOption[];
export interface OrderableDBInstanceOption {
    Engine?: string;
    EngineVersion?: string;
    DBInstanceClass?: string;
    LicenseModel?: string;
    AvailabilityZoneGroup?: string;
    AvailabilityZones?: AvailabilityZone[];
    MultiAZCapable?: boolean;
    ReadReplicaCapable?: boolean;
    Vpc?: boolean;
    SupportsStorageEncryption?: boolean;
    StorageType?: string;
    SupportsIops?: boolean;
    SupportsStorageThroughput?: boolean;
    SupportsEnhancedMonitoring?: boolean;
    SupportsIAMDatabaseAuthentication?: boolean;
    SupportsPerformanceInsights?: boolean;
    MinStorageSize?: number;
    MaxStorageSize?: number;
    MinIopsPerDbInstance?: number;
    MaxIopsPerDbInstance?: number;
    MinIopsPerGib?: number;
    MaxIopsPerGib?: number;
    MinStorageThroughputPerDbInstance?: number;
    MaxStorageThroughputPerDbInstance?: number;
    MinStorageThroughputPerIops?: number;
    MaxStorageThroughputPerIops?: number;
    AvailableProcessorFeatures?: AvailableProcessorFeature[];
    SupportedEngineModes?: string[];
    SupportsStorageAutoscaling?: boolean;
    SupportsKerberosAuthentication?: boolean;
    OutpostCapable?: boolean;
    SupportedActivityStreamModes?: string[];
    SupportsGlobalDatabases?: boolean;
    SupportedNetworkTypes?: string[];
    SupportsClusters?: boolean;
    SupportsDedicatedLogVolume?: boolean;
    SupportsAdditionalStorageVolumes?: boolean;
    SupportsHttpEndpoint?: boolean;
    AvailableAdditionalStorageVolumesOptions?: AvailableAdditionalStorageVolumesOption[];
}
export type OrderableDBInstanceOptionsList = OrderableDBInstanceOption[];
export interface OrderableDBInstanceOptionsMessage {
    OrderableDBInstanceOptions?: OrderableDBInstanceOption[];
    Marker?: string;
}
export interface DescribePendingMaintenanceActionsMessage {
    ResourceIdentifier?: string;
    Filters?: Filter[];
    Marker?: string;
    MaxRecords?: number;
}
export type PendingMaintenanceActions = ResourcePendingMaintenanceActions[];
export interface PendingMaintenanceActionsMessage {
    PendingMaintenanceActions?: ResourcePendingMaintenanceActions[];
    Marker?: string;
}
export interface DescribeReservedDBInstancesMessage {
    ReservedDBInstanceId?: string;
    ReservedDBInstancesOfferingId?: string;
    DBInstanceClass?: string;
    Duration?: string;
    ProductDescription?: string;
    OfferingType?: string;
    MultiAZ?: boolean;
    LeaseId?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export interface RecurringCharge {
    RecurringChargeAmount?: number;
    RecurringChargeFrequency?: string;
}
export type RecurringChargeList = RecurringCharge[];
export interface ReservedDBInstance {
    ReservedDBInstanceId?: string;
    ReservedDBInstancesOfferingId?: string;
    DBInstanceClass?: string;
    StartTime?: Date;
    Duration?: number;
    FixedPrice?: number;
    UsagePrice?: number;
    CurrencyCode?: string;
    DBInstanceCount?: number;
    ProductDescription?: string;
    OfferingType?: string;
    MultiAZ?: boolean;
    State?: string;
    RecurringCharges?: RecurringCharge[];
    ReservedDBInstanceArn?: string;
    LeaseId?: string;
}
export type ReservedDBInstanceList = ReservedDBInstance[];
export interface ReservedDBInstanceMessage {
    Marker?: string;
    ReservedDBInstances?: ReservedDBInstance[];
}
export interface DescribeReservedDBInstancesOfferingsMessage {
    ReservedDBInstancesOfferingId?: string;
    DBInstanceClass?: string;
    Duration?: string;
    ProductDescription?: string;
    OfferingType?: string;
    MultiAZ?: boolean;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export interface ReservedDBInstancesOffering {
    ReservedDBInstancesOfferingId?: string;
    DBInstanceClass?: string;
    Duration?: number;
    FixedPrice?: number;
    UsagePrice?: number;
    CurrencyCode?: string;
    ProductDescription?: string;
    OfferingType?: string;
    MultiAZ?: boolean;
    RecurringCharges?: RecurringCharge[];
}
export type ReservedDBInstancesOfferingList = ReservedDBInstancesOffering[];
export interface ReservedDBInstancesOfferingMessage {
    Marker?: string;
    ReservedDBInstancesOfferings?: ReservedDBInstancesOffering[];
}
export interface DescribeServerlessV2PlatformVersionsMessage {
    ServerlessV2PlatformVersion?: string;
    Engine?: string;
    Filters?: Filter[];
    DefaultOnly?: boolean;
    IncludeAll?: boolean;
    MaxRecords?: number;
    Marker?: string;
}
export interface ServerlessV2PlatformVersionInfo {
    ServerlessV2PlatformVersion?: string;
    ServerlessV2PlatformVersionDescription?: string;
    Engine?: string;
    ServerlessV2FeaturesSupport?: ServerlessV2FeaturesSupport;
    Status?: string;
    IsDefault?: boolean;
}
export type ServerlessV2PlatformVersionList = ServerlessV2PlatformVersionInfo[];
export interface ServerlessV2PlatformVersionsMessage {
    Marker?: string;
    ServerlessV2PlatformVersions?: ServerlessV2PlatformVersionInfo[];
}
export interface DescribeSourceRegionsMessage {
    RegionName?: string;
    MaxRecords?: number;
    Marker?: string;
    Filters?: Filter[];
}
export interface SourceRegion {
    RegionName?: string;
    Endpoint?: string;
    Status?: string;
    SupportsDBInstanceAutomatedBackupsReplication?: boolean;
}
export type SourceRegionList = SourceRegion[];
export interface SourceRegionMessage {
    Marker?: string;
    SourceRegions?: SourceRegion[];
}
export interface DescribeTenantDatabasesMessage {
    DBInstanceIdentifier?: string;
    TenantDBName?: string;
    Filters?: Filter[];
    Marker?: string;
    MaxRecords?: number;
}
export type TenantDatabasesList = TenantDatabase[];
export interface TenantDatabasesMessage {
    Marker?: string;
    TenantDatabases?: TenantDatabase[];
}
export interface DescribeValidDBInstanceModificationsMessage {
    DBInstanceIdentifier?: string;
}
export interface Range {
    From?: number;
    To?: number;
    Step?: number;
}
export type RangeList = Range[];
export interface DoubleRange {
    From?: number;
    To?: number;
}
export type DoubleRangeList = DoubleRange[];
export interface ValidStorageOptions {
    StorageType?: string;
    StorageSize?: Range[];
    ProvisionedIops?: Range[];
    IopsToStorageRatio?: DoubleRange[];
    ProvisionedStorageThroughput?: Range[];
    StorageThroughputToIopsRatio?: DoubleRange[];
    SupportsStorageAutoscaling?: boolean;
}
export type ValidStorageOptionsList = ValidStorageOptions[];
export interface ValidVolumeOptions {
    VolumeName?: string;
    Storage?: ValidStorageOptions[];
}
export type ValidVolumeOptionsList = ValidVolumeOptions[];
export interface ValidAdditionalStorageOptions {
    SupportsAdditionalStorageVolumes?: boolean;
    Volumes?: ValidVolumeOptions[];
}
export interface ValidDBInstanceModificationsMessage {
    Storage?: ValidStorageOptions[];
    ValidProcessorFeatures?: AvailableProcessorFeature[];
    SupportsDedicatedLogVolume?: boolean;
    AdditionalStorage?: ValidAdditionalStorageOptions;
}
export interface DescribeValidDBInstanceModificationsResult {
    ValidDBInstanceModificationsMessage?: ValidDBInstanceModificationsMessage;
}
export interface DisableHttpEndpointRequest {
    ResourceArn?: string;
}
export interface DisableHttpEndpointResponse {
    ResourceArn?: string;
    HttpEndpointEnabled?: boolean;
}
export interface DownloadDBLogFilePortionMessage {
    DBInstanceIdentifier?: string;
    LogFileName?: string;
    Marker?: string;
    NumberOfLines?: number;
}
export interface DownloadDBLogFilePortionDetails {
    LogFileData?: string | redacted.Redacted<string>;
    Marker?: string;
    AdditionalDataPending?: boolean;
}
export interface EnableHttpEndpointRequest {
    ResourceArn?: string;
}
export interface EnableHttpEndpointResponse {
    ResourceArn?: string;
    HttpEndpointEnabled?: boolean;
}
export interface FailoverDBClusterMessage {
    DBClusterIdentifier?: string;
    TargetDBInstanceIdentifier?: string;
}
export interface FailoverDBClusterResult {
    DBCluster?: DBCluster;
}
export type DBClusterIdentifier = string;
export interface FailoverGlobalClusterMessage {
    GlobalClusterIdentifier?: string;
    TargetDbClusterIdentifier?: string;
    AllowDataLoss?: boolean;
    Switchover?: boolean;
}
export interface FailoverGlobalClusterResult {
    GlobalCluster?: GlobalCluster;
}
export interface ListTagsForResourceMessage {
    ResourceName?: string;
    Filters?: Filter[];
}
export interface TagListMessage {
    TagList?: Tag[];
}
export type AuditPolicyState = "locked" | "unlocked" | (string & {});
export interface ModifyActivityStreamRequest {
    ResourceArn?: string;
    AuditPolicyState?: AuditPolicyState;
}
export interface ModifyActivityStreamResponse {
    KmsKeyId?: string;
    KinesisStreamName?: string;
    Status?: ActivityStreamStatus;
    Mode?: ActivityStreamMode;
    EngineNativeAuditFieldsIncluded?: boolean;
    PolicyStatus?: ActivityStreamPolicyStatus;
}
export interface ModifyCertificatesMessage {
    CertificateIdentifier?: string;
    RemoveCustomerOverride?: boolean;
}
export interface ModifyCertificatesResult {
    Certificate?: Certificate;
}
export interface ModifyCurrentDBClusterCapacityMessage {
    DBClusterIdentifier?: string;
    Capacity?: number;
    SecondsBeforeTimeout?: number;
    TimeoutAction?: string;
}
export interface DBClusterCapacityInfo {
    DBClusterIdentifier?: string;
    PendingCapacity?: number;
    CurrentCapacity?: number;
    SecondsBeforeTimeout?: number;
    TimeoutAction?: string;
}
export type CustomEngineVersionStatus = "available" | "inactive" | "inactive-except-restore" | (string & {});
export interface ModifyCustomDBEngineVersionMessage {
    Engine?: string;
    EngineVersion?: string;
    Description?: string;
    Status?: CustomEngineVersionStatus;
}
export interface CloudwatchLogsExportConfiguration {
    EnableLogTypes?: string[];
    DisableLogTypes?: string[];
}
export type AwsBackupRecoveryPointArn = string;
export interface ModifyDBClusterMessage {
    DBClusterIdentifier?: string;
    NewDBClusterIdentifier?: string;
    ApplyImmediately?: boolean;
    BackupRetentionPeriod?: number;
    DBClusterParameterGroupName?: string;
    VpcSecurityGroupIds?: string[];
    Port?: number;
    MasterUserPassword?: string | redacted.Redacted<string>;
    OptionGroupName?: string;
    PreferredBackupWindow?: string;
    PreferredMaintenanceWindow?: string;
    EnableIAMDatabaseAuthentication?: boolean;
    BacktrackWindow?: number;
    CloudwatchLogsExportConfiguration?: CloudwatchLogsExportConfiguration;
    EngineVersion?: string;
    AllowMajorVersionUpgrade?: boolean;
    DBInstanceParameterGroupName?: string;
    Domain?: string;
    DomainIAMRoleName?: string;
    ScalingConfiguration?: ScalingConfiguration;
    DeletionProtection?: boolean;
    EnableHttpEndpoint?: boolean;
    CopyTagsToSnapshot?: boolean;
    EnableGlobalWriteForwarding?: boolean;
    DBClusterInstanceClass?: string;
    AllocatedStorage?: number;
    StorageType?: string;
    Iops?: number;
    AutoMinorVersionUpgrade?: boolean;
    NetworkType?: string;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfiguration;
    MonitoringInterval?: number;
    MonitoringRoleArn?: string;
    DatabaseInsightsMode?: DatabaseInsightsMode;
    EnablePerformanceInsights?: boolean;
    PerformanceInsightsKMSKeyId?: string;
    PerformanceInsightsRetentionPeriod?: number;
    ManageMasterUserPassword?: boolean;
    RotateMasterUserPassword?: boolean;
    EnableLocalWriteForwarding?: boolean;
    MasterUserSecretKmsKeyId?: string;
    EngineMode?: string;
    AllowEngineModeChange?: boolean;
    AwsBackupRecoveryPointArn?: string;
    EnableLimitlessDatabase?: boolean;
    CACertificateIdentifier?: string;
    MasterUserAuthenticationType?: MasterUserAuthenticationType;
    EngineLifecycleSupport?: string;
}
export interface ModifyDBClusterResult {
    DBCluster?: DBCluster;
}
export interface ModifyDBClusterEndpointMessage {
    DBClusterEndpointIdentifier?: string;
    EndpointType?: string;
    StaticMembers?: string[];
    ExcludedMembers?: string[];
}
export interface ModifyDBClusterParameterGroupMessage {
    DBClusterParameterGroupName?: string;
    Parameters?: Parameter[];
}
export interface DBClusterParameterGroupNameMessage {
    DBClusterParameterGroupName?: string;
}
export interface ModifyDBClusterSnapshotAttributeMessage {
    DBClusterSnapshotIdentifier?: string;
    AttributeName?: string;
    ValuesToAdd?: string[];
    ValuesToRemove?: string[];
}
export interface ModifyDBClusterSnapshotAttributeResult {
    DBClusterSnapshotAttributesResult?: DBClusterSnapshotAttributesResult;
}
export interface ModifyAdditionalStorageVolume {
    VolumeName?: string;
    AllocatedStorage?: number;
    IOPS?: number;
    MaxAllocatedStorage?: number;
    StorageThroughput?: number;
    StorageType?: string;
    SetForDelete?: boolean;
}
export type ModifyAdditionalStorageVolumesList = ModifyAdditionalStorageVolume[];
export interface ModifyDBInstanceMessage {
    DBInstanceIdentifier?: string;
    AllocatedStorage?: number;
    DBInstanceClass?: string;
    DBSubnetGroupName?: string;
    DBSecurityGroups?: string[];
    VpcSecurityGroupIds?: string[];
    ApplyImmediately?: boolean;
    MasterUserPassword?: string | redacted.Redacted<string>;
    DBParameterGroupName?: string;
    BackupRetentionPeriod?: number;
    PreferredBackupWindow?: string;
    PreferredMaintenanceWindow?: string;
    MultiAZ?: boolean;
    EngineVersion?: string;
    AllowMajorVersionUpgrade?: boolean;
    AutoMinorVersionUpgrade?: boolean;
    LicenseModel?: string;
    Iops?: number;
    StorageThroughput?: number;
    OptionGroupName?: string;
    NewDBInstanceIdentifier?: string;
    StorageType?: string;
    TdeCredentialArn?: string;
    TdeCredentialPassword?: string | redacted.Redacted<string>;
    CACertificateIdentifier?: string;
    Domain?: string;
    DomainFqdn?: string;
    DomainOu?: string;
    DomainAuthSecretArn?: string;
    DomainDnsIps?: string[];
    DisableDomain?: boolean;
    CopyTagsToSnapshot?: boolean;
    MonitoringInterval?: number;
    DBPortNumber?: number;
    PubliclyAccessible?: boolean;
    MonitoringRoleArn?: string;
    DomainIAMRoleName?: string;
    PromotionTier?: number;
    EnableIAMDatabaseAuthentication?: boolean;
    DatabaseInsightsMode?: DatabaseInsightsMode;
    EnablePerformanceInsights?: boolean;
    PerformanceInsightsKMSKeyId?: string;
    PerformanceInsightsRetentionPeriod?: number;
    CloudwatchLogsExportConfiguration?: CloudwatchLogsExportConfiguration;
    ProcessorFeatures?: ProcessorFeature[];
    UseDefaultProcessorFeatures?: boolean;
    DeletionProtection?: boolean;
    MaxAllocatedStorage?: number;
    CertificateRotationRestart?: boolean;
    ReplicaMode?: ReplicaMode;
    AutomationMode?: AutomationMode;
    ResumeFullAutomationModeMinutes?: number;
    EnableCustomerOwnedIp?: boolean;
    NetworkType?: string;
    AwsBackupRecoveryPointArn?: string;
    ManageMasterUserPassword?: boolean;
    RotateMasterUserPassword?: boolean;
    MasterUserSecretKmsKeyId?: string;
    MultiTenant?: boolean;
    DedicatedLogVolume?: boolean;
    Engine?: string;
    AdditionalStorageVolumes?: ModifyAdditionalStorageVolume[];
    TagSpecifications?: TagSpecification[];
    MasterUserAuthenticationType?: MasterUserAuthenticationType;
    EngineLifecycleSupport?: string;
}
export interface ModifyDBInstanceResult {
    DBInstance?: DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    };
}
export interface ModifyDBParameterGroupMessage {
    DBParameterGroupName?: string;
    Parameters?: Parameter[];
}
export interface DBParameterGroupNameMessage {
    DBParameterGroupName?: string;
}
export interface ModifyDBProxyRequest {
    DBProxyName?: string;
    NewDBProxyName?: string;
    DefaultAuthScheme?: DefaultAuthScheme;
    Auth?: UserAuthConfig[];
    RequireTLS?: boolean;
    IdleClientTimeout?: number;
    DebugLogging?: boolean;
    RoleArn?: string;
    SecurityGroups?: string[];
}
export interface ModifyDBProxyResponse {
    DBProxy?: DBProxy;
}
export interface ModifyDBProxyEndpointRequest {
    DBProxyEndpointName?: string;
    NewDBProxyEndpointName?: string;
    VpcSecurityGroupIds?: string[];
}
export interface ModifyDBProxyEndpointResponse {
    DBProxyEndpoint?: DBProxyEndpoint;
}
export interface ConnectionPoolConfiguration {
    MaxConnectionsPercent?: number;
    MaxIdleConnectionsPercent?: number;
    ConnectionBorrowTimeout?: number;
    SessionPinningFilters?: string[];
    InitQuery?: string | redacted.Redacted<string>;
}
export interface ModifyDBProxyTargetGroupRequest {
    TargetGroupName?: string;
    DBProxyName?: string;
    ConnectionPoolConfig?: ConnectionPoolConfiguration;
    NewName?: string;
}
export interface ModifyDBProxyTargetGroupResponse {
    DBProxyTargetGroup?: DBProxyTargetGroup;
}
export interface RecommendedActionUpdate {
    ActionId?: string;
    Status?: string;
}
export type RecommendedActionUpdateList = RecommendedActionUpdate[];
export interface ModifyDBRecommendationMessage {
    RecommendationId?: string;
    Locale?: string;
    Status?: string;
    RecommendedActionUpdates?: RecommendedActionUpdate[];
}
export interface DBRecommendationMessage {
    DBRecommendation?: DBRecommendation;
}
export interface ModifyDBShardGroupMessage {
    DBShardGroupIdentifier?: string;
    MaxACU?: number;
    MinACU?: number;
    ComputeRedundancy?: number;
}
export interface ModifyDBSnapshotMessage {
    DBSnapshotIdentifier?: string;
    EngineVersion?: string;
    OptionGroupName?: string;
}
export interface ModifyDBSnapshotResult {
    DBSnapshot?: DBSnapshot & {
        AdditionalStorageVolumes: (AdditionalStorageVolume & {
            VolumeName: string;
        })[];
    };
}
export interface ModifyDBSnapshotAttributeMessage {
    DBSnapshotIdentifier?: string;
    AttributeName?: string;
    ValuesToAdd?: string[];
    ValuesToRemove?: string[];
}
export interface ModifyDBSnapshotAttributeResult {
    DBSnapshotAttributesResult?: DBSnapshotAttributesResult;
}
export interface ModifyDBSubnetGroupMessage {
    DBSubnetGroupName?: string;
    DBSubnetGroupDescription?: string;
    SubnetIds?: string[];
}
export interface ModifyDBSubnetGroupResult {
    DBSubnetGroup?: DBSubnetGroup;
}
export interface ModifyEventSubscriptionMessage {
    SubscriptionName?: string;
    SnsTopicArn?: string;
    SourceType?: string;
    EventCategories?: string[];
    Enabled?: boolean;
}
export interface ModifyEventSubscriptionResult {
    EventSubscription?: EventSubscription;
}
export interface ModifyGlobalClusterMessage {
    GlobalClusterIdentifier?: string;
    NewGlobalClusterIdentifier?: string;
    DeletionProtection?: boolean;
    EngineVersion?: string;
    AllowMajorVersionUpgrade?: boolean;
}
export interface ModifyGlobalClusterResult {
    GlobalCluster?: GlobalCluster;
}
export interface ModifyIntegrationMessage {
    IntegrationIdentifier?: string;
    IntegrationName?: string;
    DataFilter?: string;
    Description?: string;
}
export type OptionSettingsList = OptionSetting[];
export interface OptionConfiguration {
    OptionName?: string;
    Port?: number;
    OptionVersion?: string;
    DBSecurityGroupMemberships?: string[];
    VpcSecurityGroupMemberships?: string[];
    OptionSettings?: OptionSetting[];
}
export type OptionConfigurationList = OptionConfiguration[];
export type OptionNamesList = string[];
export interface ModifyOptionGroupMessage {
    OptionGroupName?: string;
    OptionsToInclude?: OptionConfiguration[];
    OptionsToRemove?: string[];
    ApplyImmediately?: boolean;
}
export interface ModifyOptionGroupResult {
    OptionGroup?: OptionGroup;
}
export interface ModifyTenantDatabaseMessage {
    DBInstanceIdentifier?: string;
    TenantDBName?: string;
    MasterUserPassword?: string | redacted.Redacted<string>;
    NewTenantDBName?: string;
    ManageMasterUserPassword?: boolean;
    RotateMasterUserPassword?: boolean;
    MasterUserSecretKmsKeyId?: string;
}
export interface ModifyTenantDatabaseResult {
    TenantDatabase?: TenantDatabase;
}
export interface PromoteReadReplicaMessage {
    DBInstanceIdentifier?: string;
    BackupRetentionPeriod?: number;
    PreferredBackupWindow?: string;
    TagSpecifications?: TagSpecification[];
}
export interface PromoteReadReplicaResult {
    DBInstance?: DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    };
}
export interface PromoteReadReplicaDBClusterMessage {
    DBClusterIdentifier?: string;
}
export interface PromoteReadReplicaDBClusterResult {
    DBCluster?: DBCluster;
}
export interface PurchaseReservedDBInstancesOfferingMessage {
    ReservedDBInstancesOfferingId?: string;
    ReservedDBInstanceId?: string;
    DBInstanceCount?: number;
    Tags?: Tag[];
}
export interface PurchaseReservedDBInstancesOfferingResult {
    ReservedDBInstance?: ReservedDBInstance;
}
export interface RebootDBClusterMessage {
    DBClusterIdentifier?: string;
}
export interface RebootDBClusterResult {
    DBCluster?: DBCluster;
}
export interface RebootDBInstanceMessage {
    DBInstanceIdentifier?: string;
    ForceFailover?: boolean;
}
export interface RebootDBInstanceResult {
    DBInstance?: DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    };
}
export interface RebootDBShardGroupMessage {
    DBShardGroupIdentifier?: string;
}
export interface RegisterDBProxyTargetsRequest {
    DBProxyName?: string;
    TargetGroupName?: string;
    DBInstanceIdentifiers?: string[];
    DBClusterIdentifiers?: string[];
}
export interface RegisterDBProxyTargetsResponse {
    DBProxyTargets?: DBProxyTarget[];
}
export interface RemoveFromGlobalClusterMessage {
    GlobalClusterIdentifier?: string;
    DbClusterIdentifier?: string;
}
export interface RemoveFromGlobalClusterResult {
    GlobalCluster?: GlobalCluster;
}
export interface RemoveRoleFromDBClusterMessage {
    DBClusterIdentifier?: string;
    RoleArn?: string;
    FeatureName?: string;
}
export interface RemoveRoleFromDBClusterResponse {
}
export interface RemoveRoleFromDBInstanceMessage {
    DBInstanceIdentifier?: string;
    RoleArn?: string;
    FeatureName?: string;
}
export interface RemoveRoleFromDBInstanceResponse {
}
export interface RemoveSourceIdentifierFromSubscriptionMessage {
    SubscriptionName?: string;
    SourceIdentifier?: string;
}
export interface RemoveSourceIdentifierFromSubscriptionResult {
    EventSubscription?: EventSubscription;
}
export type KeyList = string[];
export interface RemoveTagsFromResourceMessage {
    ResourceName?: string;
    TagKeys?: string[];
}
export interface RemoveTagsFromResourceResponse {
}
export interface ResetDBClusterParameterGroupMessage {
    DBClusterParameterGroupName?: string;
    ResetAllParameters?: boolean;
    Parameters?: Parameter[];
}
export interface ResetDBParameterGroupMessage {
    DBParameterGroupName?: string;
    ResetAllParameters?: boolean;
    Parameters?: Parameter[];
}
export interface RestoreDBClusterFromS3Message {
    AvailabilityZones?: string[];
    BackupRetentionPeriod?: number;
    CharacterSetName?: string;
    DatabaseName?: string;
    DBClusterIdentifier?: string;
    DBClusterParameterGroupName?: string;
    VpcSecurityGroupIds?: string[];
    DBSubnetGroupName?: string;
    Engine?: string;
    EngineVersion?: string;
    Port?: number;
    MasterUsername?: string;
    MasterUserPassword?: string | redacted.Redacted<string>;
    OptionGroupName?: string;
    PreferredBackupWindow?: string;
    PreferredMaintenanceWindow?: string;
    Tags?: Tag[];
    StorageEncrypted?: boolean;
    KmsKeyId?: string;
    EnableIAMDatabaseAuthentication?: boolean;
    SourceEngine?: string;
    SourceEngineVersion?: string;
    S3BucketName?: string;
    S3Prefix?: string;
    S3IngestionRoleArn?: string;
    BacktrackWindow?: number;
    EnableCloudwatchLogsExports?: string[];
    DeletionProtection?: boolean;
    CopyTagsToSnapshot?: boolean;
    Domain?: string;
    DomainIAMRoleName?: string;
    StorageType?: string;
    NetworkType?: string;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfiguration;
    ManageMasterUserPassword?: boolean;
    MasterUserSecretKmsKeyId?: string;
    EngineLifecycleSupport?: string;
    TagSpecifications?: TagSpecification[];
    AssociatedRoles?: DBClusterAssociatedRole[];
}
export interface RestoreDBClusterFromS3Result {
    DBCluster?: DBCluster;
}
export interface RestoreDBClusterFromSnapshotMessage {
    AvailabilityZones?: string[];
    DBClusterIdentifier?: string;
    SnapshotIdentifier?: string;
    Engine?: string;
    EngineVersion?: string;
    Port?: number;
    DBSubnetGroupName?: string;
    DatabaseName?: string;
    OptionGroupName?: string;
    VpcSecurityGroupIds?: string[];
    Tags?: Tag[];
    KmsKeyId?: string;
    EnableIAMDatabaseAuthentication?: boolean;
    BacktrackWindow?: number;
    EnableCloudwatchLogsExports?: string[];
    EngineMode?: string;
    ScalingConfiguration?: ScalingConfiguration;
    DBClusterParameterGroupName?: string;
    DeletionProtection?: boolean;
    CopyTagsToSnapshot?: boolean;
    Domain?: string;
    DomainIAMRoleName?: string;
    DBClusterInstanceClass?: string;
    StorageType?: string;
    Iops?: number;
    PubliclyAccessible?: boolean;
    NetworkType?: string;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfiguration;
    RdsCustomClusterConfiguration?: RdsCustomClusterConfiguration;
    MonitoringInterval?: number;
    MonitoringRoleArn?: string;
    EnablePerformanceInsights?: boolean;
    PerformanceInsightsKMSKeyId?: string;
    PerformanceInsightsRetentionPeriod?: number;
    BackupRetentionPeriod?: number;
    PreferredBackupWindow?: string;
    EngineLifecycleSupport?: string;
    TagSpecifications?: TagSpecification[];
    EnableVPCNetworking?: boolean;
    EnableInternetAccessGateway?: boolean;
    AssociatedRoles?: DBClusterAssociatedRole[];
}
export interface RestoreDBClusterFromSnapshotResult {
    DBCluster?: DBCluster;
}
export interface RestoreDBClusterToPointInTimeMessage {
    DBClusterIdentifier?: string;
    RestoreType?: string;
    SourceDBClusterIdentifier?: string;
    RestoreToTime?: Date;
    UseLatestRestorableTime?: boolean;
    Port?: number;
    DBSubnetGroupName?: string;
    OptionGroupName?: string;
    VpcSecurityGroupIds?: string[];
    Tags?: Tag[];
    KmsKeyId?: string;
    EnableIAMDatabaseAuthentication?: boolean;
    BacktrackWindow?: number;
    EnableCloudwatchLogsExports?: string[];
    DBClusterParameterGroupName?: string;
    DeletionProtection?: boolean;
    CopyTagsToSnapshot?: boolean;
    Domain?: string;
    DomainIAMRoleName?: string;
    DBClusterInstanceClass?: string;
    StorageType?: string;
    PubliclyAccessible?: boolean;
    Iops?: number;
    NetworkType?: string;
    SourceDbClusterResourceId?: string;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfiguration;
    ScalingConfiguration?: ScalingConfiguration;
    EngineMode?: string;
    RdsCustomClusterConfiguration?: RdsCustomClusterConfiguration;
    MonitoringInterval?: number;
    MonitoringRoleArn?: string;
    EnablePerformanceInsights?: boolean;
    PerformanceInsightsKMSKeyId?: string;
    PerformanceInsightsRetentionPeriod?: number;
    BackupRetentionPeriod?: number;
    PreferredBackupWindow?: string;
    EngineLifecycleSupport?: string;
    TagSpecifications?: TagSpecification[];
    EnableVPCNetworking?: boolean;
    EnableInternetAccessGateway?: boolean;
    AssociatedRoles?: DBClusterAssociatedRole[];
}
export interface RestoreDBClusterToPointInTimeResult {
    DBCluster?: DBCluster;
}
export interface RestoreDBInstanceFromDBSnapshotMessage {
    DBInstanceIdentifier?: string;
    DBSnapshotIdentifier?: string;
    DBInstanceClass?: string;
    Port?: number;
    AvailabilityZone?: string;
    DBSubnetGroupName?: string;
    MultiAZ?: boolean;
    PubliclyAccessible?: boolean;
    AutoMinorVersionUpgrade?: boolean;
    LicenseModel?: string;
    DBName?: string;
    Engine?: string;
    Iops?: number;
    StorageThroughput?: number;
    OptionGroupName?: string;
    Tags?: Tag[];
    StorageType?: string;
    TdeCredentialArn?: string;
    TdeCredentialPassword?: string | redacted.Redacted<string>;
    VpcSecurityGroupIds?: string[];
    Domain?: string;
    DomainFqdn?: string;
    DomainOu?: string;
    DomainAuthSecretArn?: string;
    DomainDnsIps?: string[];
    CopyTagsToSnapshot?: boolean;
    DomainIAMRoleName?: string;
    EnableIAMDatabaseAuthentication?: boolean;
    EnableCloudwatchLogsExports?: string[];
    ProcessorFeatures?: ProcessorFeature[];
    UseDefaultProcessorFeatures?: boolean;
    DBParameterGroupName?: string;
    DeletionProtection?: boolean;
    EnableCustomerOwnedIp?: boolean;
    NetworkType?: string;
    BackupTarget?: string;
    CustomIamInstanceProfile?: string;
    AllocatedStorage?: number;
    DBClusterSnapshotIdentifier?: string;
    BackupRetentionPeriod?: number;
    PreferredBackupWindow?: string;
    DedicatedLogVolume?: boolean;
    CACertificateIdentifier?: string;
    EngineLifecycleSupport?: string;
    AdditionalStorageVolumes?: AdditionalStorageVolume[];
    TagSpecifications?: TagSpecification[];
    ManageMasterUserPassword?: boolean;
    MasterUserSecretKmsKeyId?: string;
}
export interface RestoreDBInstanceFromDBSnapshotResult {
    DBInstance?: DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    };
}
export interface RestoreDBInstanceFromS3Message {
    DBName?: string;
    DBInstanceIdentifier?: string;
    AllocatedStorage?: number;
    DBInstanceClass?: string;
    Engine?: string;
    MasterUsername?: string;
    MasterUserPassword?: string | redacted.Redacted<string>;
    DBSecurityGroups?: string[];
    VpcSecurityGroupIds?: string[];
    AvailabilityZone?: string;
    DBSubnetGroupName?: string;
    PreferredMaintenanceWindow?: string;
    DBParameterGroupName?: string;
    BackupRetentionPeriod?: number;
    PreferredBackupWindow?: string;
    Port?: number;
    MultiAZ?: boolean;
    EngineVersion?: string;
    AutoMinorVersionUpgrade?: boolean;
    LicenseModel?: string;
    Iops?: number;
    StorageThroughput?: number;
    OptionGroupName?: string;
    PubliclyAccessible?: boolean;
    Tags?: Tag[];
    StorageType?: string;
    StorageEncrypted?: boolean;
    KmsKeyId?: string;
    CopyTagsToSnapshot?: boolean;
    MonitoringInterval?: number;
    MonitoringRoleArn?: string;
    EnableIAMDatabaseAuthentication?: boolean;
    SourceEngine?: string;
    SourceEngineVersion?: string;
    S3BucketName?: string;
    S3Prefix?: string;
    S3IngestionRoleArn?: string;
    DatabaseInsightsMode?: DatabaseInsightsMode;
    EnablePerformanceInsights?: boolean;
    PerformanceInsightsKMSKeyId?: string;
    PerformanceInsightsRetentionPeriod?: number;
    EnableCloudwatchLogsExports?: string[];
    ProcessorFeatures?: ProcessorFeature[];
    UseDefaultProcessorFeatures?: boolean;
    DeletionProtection?: boolean;
    MaxAllocatedStorage?: number;
    NetworkType?: string;
    ManageMasterUserPassword?: boolean;
    MasterUserSecretKmsKeyId?: string;
    DedicatedLogVolume?: boolean;
    CACertificateIdentifier?: string;
    EngineLifecycleSupport?: string;
    AdditionalStorageVolumes?: AdditionalStorageVolume[];
    TagSpecifications?: TagSpecification[];
}
export interface RestoreDBInstanceFromS3Result {
    DBInstance?: DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    };
}
export interface RestoreDBInstanceToPointInTimeMessage {
    SourceDBInstanceIdentifier?: string;
    TargetDBInstanceIdentifier?: string;
    RestoreTime?: Date;
    UseLatestRestorableTime?: boolean;
    DBInstanceClass?: string;
    Port?: number;
    AvailabilityZone?: string;
    DBSubnetGroupName?: string;
    MultiAZ?: boolean;
    PubliclyAccessible?: boolean;
    AutoMinorVersionUpgrade?: boolean;
    LicenseModel?: string;
    DBName?: string;
    Engine?: string;
    Iops?: number;
    StorageThroughput?: number;
    OptionGroupName?: string;
    CopyTagsToSnapshot?: boolean;
    Tags?: Tag[];
    StorageType?: string;
    TdeCredentialArn?: string;
    TdeCredentialPassword?: string | redacted.Redacted<string>;
    VpcSecurityGroupIds?: string[];
    Domain?: string;
    DomainIAMRoleName?: string;
    DomainFqdn?: string;
    DomainOu?: string;
    DomainAuthSecretArn?: string;
    DomainDnsIps?: string[];
    EnableIAMDatabaseAuthentication?: boolean;
    EnableCloudwatchLogsExports?: string[];
    ProcessorFeatures?: ProcessorFeature[];
    UseDefaultProcessorFeatures?: boolean;
    DBParameterGroupName?: string;
    DeletionProtection?: boolean;
    SourceDbiResourceId?: string;
    MaxAllocatedStorage?: number;
    EnableCustomerOwnedIp?: boolean;
    NetworkType?: string;
    SourceDBInstanceAutomatedBackupsArn?: string;
    BackupTarget?: string;
    CustomIamInstanceProfile?: string;
    AllocatedStorage?: number;
    BackupRetentionPeriod?: number;
    PreferredBackupWindow?: string;
    DedicatedLogVolume?: boolean;
    CACertificateIdentifier?: string;
    EngineLifecycleSupport?: string;
    AdditionalStorageVolumes?: AdditionalStorageVolume[];
    TagSpecifications?: TagSpecification[];
    ManageMasterUserPassword?: boolean;
    MasterUserSecretKmsKeyId?: string;
}
export interface RestoreDBInstanceToPointInTimeResult {
    DBInstance?: DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    };
}
export interface RevokeDBSecurityGroupIngressMessage {
    DBSecurityGroupName?: string;
    CIDRIP?: string;
    EC2SecurityGroupName?: string;
    EC2SecurityGroupId?: string;
    EC2SecurityGroupOwnerId?: string;
}
export interface RevokeDBSecurityGroupIngressResult {
    DBSecurityGroup?: DBSecurityGroup;
}
export interface StartActivityStreamRequest {
    ResourceArn?: string;
    Mode?: ActivityStreamMode;
    KmsKeyId?: string;
    ApplyImmediately?: boolean;
    EngineNativeAuditFieldsIncluded?: boolean;
}
export interface StartActivityStreamResponse {
    KmsKeyId?: string;
    KinesisStreamName?: string;
    Status?: ActivityStreamStatus;
    Mode?: ActivityStreamMode;
    EngineNativeAuditFieldsIncluded?: boolean;
    ApplyImmediately?: boolean;
}
export interface StartDBClusterMessage {
    DBClusterIdentifier?: string;
}
export interface StartDBClusterResult {
    DBCluster?: DBCluster;
}
export interface StartDBInstanceMessage {
    DBInstanceIdentifier?: string;
}
export interface StartDBInstanceResult {
    DBInstance?: DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    };
}
export interface StartDBInstanceAutomatedBackupsReplicationMessage {
    SourceDBInstanceArn?: string;
    BackupRetentionPeriod?: number;
    KmsKeyId?: string;
    PreSignedUrl?: string | redacted.Redacted<string>;
    Tags?: Tag[];
}
export interface StartDBInstanceAutomatedBackupsReplicationResult {
    DBInstanceAutomatedBackup?: DBInstanceAutomatedBackup & {
        AdditionalStorageVolumes: (AdditionalStorageVolume & {
            VolumeName: string;
        })[];
    };
}
export interface StartExportTaskMessage {
    ExportTaskIdentifier?: string;
    SourceArn?: string;
    S3BucketName?: string;
    IamRoleArn?: string;
    KmsKeyId?: string;
    S3Prefix?: string;
    ExportOnly?: string[];
}
export interface StopActivityStreamRequest {
    ResourceArn?: string;
    ApplyImmediately?: boolean;
}
export interface StopActivityStreamResponse {
    KmsKeyId?: string;
    KinesisStreamName?: string;
    Status?: ActivityStreamStatus;
}
export interface StopDBClusterMessage {
    DBClusterIdentifier?: string;
}
export interface StopDBClusterResult {
    DBCluster?: DBCluster;
}
export interface StopDBInstanceMessage {
    DBInstanceIdentifier?: string;
    DBSnapshotIdentifier?: string;
}
export interface StopDBInstanceResult {
    DBInstance?: DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    };
}
export interface StopDBInstanceAutomatedBackupsReplicationMessage {
    SourceDBInstanceArn?: string;
}
export interface StopDBInstanceAutomatedBackupsReplicationResult {
    DBInstanceAutomatedBackup?: DBInstanceAutomatedBackup & {
        AdditionalStorageVolumes: (AdditionalStorageVolume & {
            VolumeName: string;
        })[];
    };
}
export type SwitchoverTimeout = number;
export interface SwitchoverBlueGreenDeploymentRequest {
    BlueGreenDeploymentIdentifier?: string;
    SwitchoverTimeout?: number;
}
export interface SwitchoverBlueGreenDeploymentResponse {
    BlueGreenDeployment?: BlueGreenDeployment;
}
export interface SwitchoverGlobalClusterMessage {
    GlobalClusterIdentifier?: string;
    TargetDbClusterIdentifier?: string;
}
export interface SwitchoverGlobalClusterResult {
    GlobalCluster?: GlobalCluster;
}
export interface SwitchoverReadReplicaMessage {
    DBInstanceIdentifier?: string;
}
export interface SwitchoverReadReplicaResult {
    DBInstance?: DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    };
}
export type ExceptionMessage = string;
export type AddRoleToDBClusterError = DBClusterNotFoundFault | DBClusterRoleAlreadyExistsFault | DBClusterRoleQuotaExceededFault | InvalidDBClusterStateFault | CommonErrors;
/**
 * Associates an Identity and Access Management (IAM) role with a DB cluster.
 */
export declare const addRoleToDBCluster: API.OperationMethod<AddRoleToDBClusterMessage, AddRoleToDBClusterResponse, AddRoleToDBClusterError, Credentials | HttpClient.HttpClient>;
export type AddRoleToDBInstanceError = DBInstanceNotFoundFault | DBInstanceRoleAlreadyExistsFault | DBInstanceRoleQuotaExceededFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Associates an Amazon Web Services Identity and Access Management (IAM) role with a DB instance.
 *
 * To add a role to a DB instance, the status of the DB instance must be `available`.
 *
 * This command doesn't apply to RDS Custom.
 */
export declare const addRoleToDBInstance: API.OperationMethod<AddRoleToDBInstanceMessage, AddRoleToDBInstanceResponse, AddRoleToDBInstanceError, Credentials | HttpClient.HttpClient>;
export type AddSourceIdentifierToSubscriptionError = SourceNotFoundFault | SubscriptionNotFoundFault | CommonErrors;
/**
 * Adds a source identifier to an existing RDS event notification subscription.
 */
export declare const addSourceIdentifierToSubscription: API.OperationMethod<AddSourceIdentifierToSubscriptionMessage, AddSourceIdentifierToSubscriptionResult, AddSourceIdentifierToSubscriptionError, Credentials | HttpClient.HttpClient>;
export type AddTagsToResourceError = BlueGreenDeploymentNotFoundFault | DBClusterNotFoundFault | DBInstanceNotFoundFault | DBProxyEndpointNotFoundFault | DBProxyNotFoundFault | DBProxyTargetGroupNotFoundFault | DBShardGroupNotFoundFault | DBSnapshotNotFoundFault | DBSnapshotTenantDatabaseNotFoundFault | IntegrationNotFoundFault | InvalidDBClusterEndpointStateFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | TenantDatabaseNotFoundFault | CommonErrors;
/**
 * Adds metadata tags to an Amazon RDS resource. These tags can also be used with cost allocation reporting to track cost associated with Amazon RDS resources, or used in a Condition statement in an IAM policy for Amazon RDS.
 *
 * For an overview on tagging your relational database resources, see Tagging Amazon RDS Resources or Tagging Amazon Aurora and Amazon RDS Resources.
 */
export declare const addTagsToResource: API.OperationMethod<AddTagsToResourceMessage, AddTagsToResourceResponse, AddTagsToResourceError, Credentials | HttpClient.HttpClient>;
export type ApplyPendingMaintenanceActionError = InvalidDBClusterStateFault | InvalidDBInstanceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Applies a pending maintenance action to a resource (for example, to a DB instance).
 */
export declare const applyPendingMaintenanceAction: API.OperationMethod<ApplyPendingMaintenanceActionMessage, ApplyPendingMaintenanceActionResult, ApplyPendingMaintenanceActionError, Credentials | HttpClient.HttpClient>;
export type AuthorizeDBSecurityGroupIngressError = AuthorizationAlreadyExistsFault | AuthorizationQuotaExceededFault | DBSecurityGroupNotFoundFault | InvalidDBSecurityGroupStateFault | CommonErrors;
/**
 * Enables ingress to a DBSecurityGroup using one of two forms of authorization. First, EC2 or VPC security groups can be added to the DBSecurityGroup if the application using the database is running on EC2 or VPC instances. Second, IP ranges are available if the application accessing your database is running on the internet. Required parameters for this API are one of CIDR range, EC2SecurityGroupId for VPC, or (EC2SecurityGroupOwnerId and either EC2SecurityGroupName or EC2SecurityGroupId for non-VPC).
 *
 * You can't authorize ingress from an EC2 security group in one Amazon Web Services Region to an Amazon RDS DB instance in another. You can't authorize ingress from a VPC security group in one VPC to an Amazon RDS DB instance in another.
 *
 * For an overview of CIDR ranges, go to the Wikipedia Tutorial.
 *
 * EC2-Classic was retired on August 15, 2022. If you haven't migrated from EC2-Classic to a VPC, we recommend that you migrate as soon as possible. For more information, see Migrate from EC2-Classic to a VPC in the *Amazon EC2 User Guide*, the blog EC2-Classic Networking is Retiring - Here's How to Prepare, and Moving a DB instance not in a VPC into a VPC in the *Amazon RDS User Guide*.
 */
export declare const authorizeDBSecurityGroupIngress: API.OperationMethod<AuthorizeDBSecurityGroupIngressMessage, AuthorizeDBSecurityGroupIngressResult, AuthorizeDBSecurityGroupIngressError, Credentials | HttpClient.HttpClient>;
export type BacktrackDBClusterError = DBClusterNotFoundFault | InvalidDBClusterStateFault | CommonErrors;
/**
 * Backtracks a DB cluster to a specific time, without creating a new DB cluster.
 *
 * For more information on backtracking, see Backtracking an Aurora DB Cluster in the *Amazon Aurora User Guide*.
 *
 * This action applies only to Aurora MySQL DB clusters.
 */
export declare const backtrackDBCluster: API.OperationMethod<BacktrackDBClusterMessage, DBClusterBacktrack, BacktrackDBClusterError, Credentials | HttpClient.HttpClient>;
export type CancelExportTaskError = ExportTaskNotFoundFault | InvalidExportTaskStateFault | CommonErrors;
/**
 * Cancels an export task in progress that is exporting a snapshot or cluster to Amazon S3. Any data that has already been written to the S3 bucket isn't removed.
 */
export declare const cancelExportTask: API.OperationMethod<CancelExportTaskMessage, ExportTask, CancelExportTaskError, Credentials | HttpClient.HttpClient>;
export type CopyDBClusterParameterGroupError = DBParameterGroupAlreadyExistsFault | DBParameterGroupNotFoundFault | DBParameterGroupQuotaExceededFault | CommonErrors;
/**
 * Copies the specified DB cluster parameter group.
 *
 * You can't copy a default DB cluster parameter group. Instead, create a new custom DB cluster parameter group, which copies the default parameters and values for the specified DB cluster parameter group family.
 */
export declare const copyDBClusterParameterGroup: API.OperationMethod<CopyDBClusterParameterGroupMessage, CopyDBClusterParameterGroupResult, CopyDBClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type CopyDBClusterSnapshotError = DBClusterSnapshotAlreadyExistsFault | DBClusterSnapshotNotFoundFault | InvalidDBClusterSnapshotStateFault | InvalidDBClusterStateFault | KMSKeyNotAccessibleFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Copies a snapshot of a DB cluster.
 *
 * To copy a DB cluster snapshot from a shared manual DB cluster snapshot, `SourceDBClusterSnapshotIdentifier` must be the Amazon Resource Name (ARN) of the shared DB cluster snapshot.
 *
 * You can copy an encrypted DB cluster snapshot from another Amazon Web Services Region. In that case, the Amazon Web Services Region where you call the `CopyDBClusterSnapshot` operation is the destination Amazon Web Services Region for the encrypted DB cluster snapshot to be copied to. To copy an encrypted DB cluster snapshot from another Amazon Web Services Region, you must provide the following values:
 *
 * - `KmsKeyId` - The Amazon Web Services Key Management System (Amazon Web Services KMS) key identifier for the key to use to encrypt the copy of the DB cluster snapshot in the destination Amazon Web Services Region.
 *
 * - `TargetDBClusterSnapshotIdentifier` - The identifier for the new copy of the DB cluster snapshot in the destination Amazon Web Services Region.
 *
 * - `SourceDBClusterSnapshotIdentifier` - The DB cluster snapshot identifier for the encrypted DB cluster snapshot to be copied. This identifier must be in the ARN format for the source Amazon Web Services Region and is the same value as the `SourceDBClusterSnapshotIdentifier` in the presigned URL.
 *
 * To cancel the copy operation once it is in progress, delete the target DB cluster snapshot identified by `TargetDBClusterSnapshotIdentifier` while that DB cluster snapshot is in "copying" status.
 *
 * For more information on copying encrypted Amazon Aurora DB cluster snapshots from one Amazon Web Services Region to another, see Copying a Snapshot in the *Amazon Aurora User Guide*.
 *
 * For more information on Amazon Aurora DB clusters, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const copyDBClusterSnapshot: API.OperationMethod<CopyDBClusterSnapshotMessage, CopyDBClusterSnapshotResult, CopyDBClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type CopyDBParameterGroupError = DBParameterGroupAlreadyExistsFault | DBParameterGroupNotFoundFault | DBParameterGroupQuotaExceededFault | CommonErrors;
/**
 * Copies the specified DB parameter group.
 *
 * You can't copy a default DB parameter group. Instead, create a new custom DB parameter group, which copies the default parameters and values for the specified DB parameter group family.
 */
export declare const copyDBParameterGroup: API.OperationMethod<CopyDBParameterGroupMessage, CopyDBParameterGroupResult, CopyDBParameterGroupError, Credentials | HttpClient.HttpClient>;
export type CopyDBSnapshotError = CustomAvailabilityZoneNotFoundFault | DBSnapshotAlreadyExistsFault | DBSnapshotNotFoundFault | InvalidDBSnapshotStateFault | KMSKeyNotAccessibleFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Copies the specified DB snapshot. The source DB snapshot must be in the `available` state.
 *
 * You can copy a snapshot from one Amazon Web Services Region to another. In that case, the Amazon Web Services Region where you call the `CopyDBSnapshot` operation is the destination Amazon Web Services Region for the DB snapshot copy.
 *
 * This command doesn't apply to RDS Custom.
 *
 * For more information about copying snapshots, see Copying a DB Snapshot in the *Amazon RDS User Guide*.
 */
export declare const copyDBSnapshot: API.OperationMethod<CopyDBSnapshotMessage, CopyDBSnapshotResult, CopyDBSnapshotError, Credentials | HttpClient.HttpClient>;
export type CopyOptionGroupError = OptionGroupAlreadyExistsFault | OptionGroupNotFoundFault | OptionGroupQuotaExceededFault | CommonErrors;
/**
 * Copies the specified option group.
 */
export declare const copyOptionGroup: API.OperationMethod<CopyOptionGroupMessage, CopyOptionGroupResult, CopyOptionGroupError, Credentials | HttpClient.HttpClient>;
export type CreateBlueGreenDeploymentError = BlueGreenDeploymentAlreadyExistsFault | DBClusterNotFoundFault | DBClusterParameterGroupNotFoundFault | DBClusterQuotaExceededFault | DBInstanceNotFoundFault | DBParameterGroupNotFoundFault | InstanceQuotaExceededFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | SourceClusterNotSupportedFault | SourceDatabaseNotSupportedFault | StorageQuotaExceededFault | CommonErrors;
/**
 * Creates a blue/green deployment.
 *
 * A blue/green deployment creates a staging environment that copies the production environment. In a blue/green deployment, the blue environment is the current production environment. The green environment is the staging environment, and it stays in sync with the current production environment.
 *
 * You can make changes to the databases in the green environment without affecting production workloads. For example, you can upgrade the major or minor DB engine version, change database parameters, or make schema changes in the staging environment. You can thoroughly test changes in the green environment. When ready, you can switch over the environments to promote the green environment to be the new production environment. The switchover typically takes under a minute.
 *
 * For more information, see Using Amazon RDS Blue/Green Deployments for database updates in the *Amazon RDS User Guide* and Using Amazon RDS Blue/Green Deployments for database updates in the *Amazon Aurora User Guide*.
 */
export declare const createBlueGreenDeployment: API.OperationMethod<CreateBlueGreenDeploymentRequest, CreateBlueGreenDeploymentResponse, CreateBlueGreenDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateCustomDBEngineVersionError = CreateCustomDBEngineVersionFault | CustomDBEngineVersionAlreadyExistsFault | CustomDBEngineVersionNotFoundFault | CustomDBEngineVersionQuotaExceededFault | Ec2ImagePropertiesNotSupportedFault | InvalidCustomDBEngineVersionStateFault | KMSKeyNotAccessibleFault | CommonErrors;
/**
 * Creates a custom DB engine version (CEV).
 */
export declare const createCustomDBEngineVersion: API.OperationMethod<CreateCustomDBEngineVersionMessage, DBEngineVersion, CreateCustomDBEngineVersionError, Credentials | HttpClient.HttpClient>;
export type CreateDBClusterError = DBClusterAlreadyExistsFault | DBClusterNotFoundFault | DBClusterParameterGroupNotFoundFault | DBClusterQuotaExceededFault | DBClusterRoleQuotaExceededFault | DBInstanceNotFoundFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | DomainNotFoundFault | GlobalClusterNotFoundFault | InsufficientDBInstanceCapacityFault | InsufficientStorageClusterCapacityFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidDBSubnetGroupFault | InvalidDBSubnetGroupStateFault | InvalidGlobalClusterStateFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | OptionGroupNotFoundFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | VpcEncryptionControlViolationException | InvalidParameterCombination | InvalidParameterValue | CommonErrors;
/**
 * Creates a new Amazon Aurora DB cluster or Multi-AZ DB cluster.
 *
 * If you create an Aurora DB cluster, the request creates an empty cluster. You must explicitly create the writer instance for your DB cluster using the CreateDBInstance operation. If you create a Multi-AZ DB cluster, the request creates a writer and two reader DB instances for you, each in a different Availability Zone.
 *
 * You can use the `ReplicationSourceIdentifier` parameter to create an Amazon Aurora DB cluster as a read replica of another DB cluster or Amazon RDS for MySQL or PostgreSQL DB instance. For more information about Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * You can also use the `ReplicationSourceIdentifier` parameter to create a Multi-AZ DB cluster read replica with an RDS for MySQL or PostgreSQL DB instance as the source. For more information about Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 *
 * You can use the `WithExpressConfiguration` parameter to create an Aurora DB Cluster with express configuration and create cluster in seconds. Express configuration provides a cluster with a writer instance and feature specific values set to all other input parameters of this API.
 *
 * You can use the `AssociatedRoles` parameter to associate one or more Amazon Web Services Identity and Access Management (IAM) roles with an Aurora DB cluster. Each associated role lets the DB cluster access other Amazon Web Services on your behalf, such as Amazon S3 for data import and export, or Amazon Web Services Lambda for invoking functions.
 */
export declare const createDBCluster: API.OperationMethod<CreateDBClusterMessage, CreateDBClusterResult, CreateDBClusterError, Credentials | HttpClient.HttpClient>;
export type CreateDBClusterEndpointError = DBClusterEndpointAlreadyExistsFault | DBClusterEndpointQuotaExceededFault | DBClusterNotFoundFault | DBInstanceNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Creates a new custom endpoint and associates it with an Amazon Aurora DB cluster.
 *
 * This action applies only to Aurora DB clusters.
 */
export declare const createDBClusterEndpoint: API.OperationMethod<CreateDBClusterEndpointMessage, DBClusterEndpoint, CreateDBClusterEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateDBClusterParameterGroupError = DBParameterGroupAlreadyExistsFault | DBParameterGroupQuotaExceededFault | CommonErrors;
/**
 * Creates a new DB cluster parameter group.
 *
 * Parameters in a DB cluster parameter group apply to all of the instances in a DB cluster.
 *
 * A DB cluster parameter group is initially created with the default parameters for the database engine used by instances in the DB cluster. To provide custom values for any of the parameters, you must modify the group after creating it using `ModifyDBClusterParameterGroup`. Once you've created a DB cluster parameter group, you need to associate it with your DB cluster using `ModifyDBCluster`.
 *
 * When you associate a new DB cluster parameter group with a running Aurora DB cluster, reboot the DB instances in the DB cluster without failover for the new DB cluster parameter group and associated settings to take effect.
 *
 * When you associate a new DB cluster parameter group with a running Multi-AZ DB cluster, reboot the DB cluster without failover for the new DB cluster parameter group and associated settings to take effect.
 *
 * After you create a DB cluster parameter group, you should wait at least 5 minutes before creating your first DB cluster that uses that DB cluster parameter group as the default parameter group. This allows Amazon RDS to fully complete the create action before the DB cluster parameter group is used as the default for a new DB cluster. This is especially important for parameters that are critical when creating the default database for a DB cluster, such as the character set for the default database defined by the `character_set_database` parameter. You can use the *Parameter Groups* option of the Amazon RDS console or the `DescribeDBClusterParameters` operation to verify that your DB cluster parameter group has been created or modified.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const createDBClusterParameterGroup: API.OperationMethod<CreateDBClusterParameterGroupMessage, CreateDBClusterParameterGroupResult, CreateDBClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type CreateDBClusterSnapshotError = DBClusterNotFoundFault | DBClusterSnapshotAlreadyExistsFault | InvalidDBClusterSnapshotStateFault | InvalidDBClusterStateFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Creates a snapshot of a DB cluster.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const createDBClusterSnapshot: API.OperationMethod<CreateDBClusterSnapshotMessage, CreateDBClusterSnapshotResult, CreateDBClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateDBInstanceError = AuthorizationNotFoundFault | BackupPolicyNotFoundFault | CertificateNotFoundFault | DBClusterNotFoundFault | DBInstanceAlreadyExistsFault | DBParameterGroupNotFoundFault | DBSecurityGroupNotFoundFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | DomainNotFoundFault | InstanceQuotaExceededFault | InsufficientDBInstanceCapacityFault | InvalidDBClusterStateFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | OptionGroupNotFoundFault | ProvisionedIopsNotAvailableInAZFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | TenantDatabaseQuotaExceededFault | VpcEncryptionControlViolationException | InvalidParameterCombination | InvalidParameterValue | CommonErrors;
/**
 * Creates a new DB instance.
 *
 * The new DB instance can be an RDS DB instance, or it can be a DB instance in an Aurora DB cluster. For an Aurora DB cluster, you can call this operation multiple times to add more than one DB instance to the cluster.
 *
 * For more information about creating an RDS DB instance, see Creating an Amazon RDS DB instance in the *Amazon RDS User Guide*.
 *
 * For more information about creating a DB instance in an Aurora DB cluster, see Creating an Amazon Aurora DB cluster in the *Amazon Aurora User Guide*.
 */
export declare const createDBInstance: API.OperationMethod<CreateDBInstanceMessage, CreateDBInstanceResult, CreateDBInstanceError, Credentials | HttpClient.HttpClient>;
export type CreateDBInstanceReadReplicaError = CertificateNotFoundFault | DBClusterNotFoundFault | DBInstanceAlreadyExistsFault | DBInstanceNotFoundFault | DBParameterGroupNotFoundFault | DBSecurityGroupNotFoundFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotAllowedFault | DBSubnetGroupNotFoundFault | DomainNotFoundFault | InstanceQuotaExceededFault | InsufficientDBInstanceCapacityFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidDBSubnetGroupFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | OptionGroupNotFoundFault | ProvisionedIopsNotAvailableInAZFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | TenantDatabaseQuotaExceededFault | VpcEncryptionControlViolationException | CommonErrors;
/**
 * Creates a new DB instance that acts as a read replica for an existing source DB instance or Multi-AZ DB cluster. You can create a read replica for a DB instance running Db2, MariaDB, MySQL, Oracle, PostgreSQL, or SQL Server. You can create a read replica for a Multi-AZ DB cluster running MySQL or PostgreSQL. For more information, see Working with read replicas and Migrating from a Multi-AZ DB cluster to a DB instance using a read replica in the *Amazon RDS User Guide*.
 *
 * Amazon Aurora doesn't support this operation. To create a DB instance for an Aurora DB cluster, use the `CreateDBInstance` operation.
 *
 * RDS creates read replicas with backups disabled. All other attributes (including DB security groups and DB parameter groups) are inherited from the source DB instance or cluster, except as specified.
 *
 * Your source DB instance or cluster must have backup retention enabled.
 */
export declare const createDBInstanceReadReplica: API.OperationMethod<CreateDBInstanceReadReplicaMessage, CreateDBInstanceReadReplicaResult, CreateDBInstanceReadReplicaError, Credentials | HttpClient.HttpClient>;
export type CreateDBParameterGroupError = DBParameterGroupAlreadyExistsFault | DBParameterGroupQuotaExceededFault | CommonErrors;
/**
 * Creates a new DB parameter group.
 *
 * A DB parameter group is initially created with the default parameters for the database engine used by the DB instance. To provide custom values for any of the parameters, you must modify the group after creating it using `ModifyDBParameterGroup`. Once you've created a DB parameter group, you need to associate it with your DB instance using `ModifyDBInstance`. When you associate a new DB parameter group with a running DB instance, you need to reboot the DB instance without failover for the new DB parameter group and associated settings to take effect.
 *
 * This command doesn't apply to RDS Custom.
 */
export declare const createDBParameterGroup: API.OperationMethod<CreateDBParameterGroupMessage, CreateDBParameterGroupResult, CreateDBParameterGroupError, Credentials | HttpClient.HttpClient>;
export type CreateDBProxyError = DBProxyAlreadyExistsFault | DBProxyQuotaExceededFault | InvalidSubnet | CommonErrors;
/**
 * Creates a new DB proxy.
 */
export declare const createDBProxy: API.OperationMethod<CreateDBProxyRequest, CreateDBProxyResponse, CreateDBProxyError, Credentials | HttpClient.HttpClient>;
export type CreateDBProxyEndpointError = DBProxyEndpointAlreadyExistsFault | DBProxyEndpointQuotaExceededFault | DBProxyNotFoundFault | InvalidDBProxyStateFault | InvalidSubnet | CommonErrors;
/**
 * Creates a `DBProxyEndpoint`. Only applies to proxies that are associated with Aurora DB clusters. You can use DB proxy endpoints to specify read/write or read-only access to the DB cluster. You can also use DB proxy endpoints to access a DB proxy through a different VPC than the proxy's default VPC.
 */
export declare const createDBProxyEndpoint: API.OperationMethod<CreateDBProxyEndpointRequest, CreateDBProxyEndpointResponse, CreateDBProxyEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateDBSecurityGroupError = DBSecurityGroupAlreadyExistsFault | DBSecurityGroupNotSupportedFault | DBSecurityGroupQuotaExceededFault | CommonErrors;
/**
 * Creates a new DB security group. DB security groups control access to a DB instance.
 *
 * A DB security group controls access to EC2-Classic DB instances that are not in a VPC.
 *
 * EC2-Classic was retired on August 15, 2022. If you haven't migrated from EC2-Classic to a VPC, we recommend that you migrate as soon as possible. For more information, see Migrate from EC2-Classic to a VPC in the *Amazon EC2 User Guide*, the blog EC2-Classic Networking is Retiring - Here's How to Prepare, and Moving a DB instance not in a VPC into a VPC in the *Amazon RDS User Guide*.
 */
export declare const createDBSecurityGroup: API.OperationMethod<CreateDBSecurityGroupMessage, CreateDBSecurityGroupResult, CreateDBSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type CreateDBShardGroupError = DBClusterNotFoundFault | DBShardGroupAlreadyExistsFault | InvalidDBClusterStateFault | InvalidVPCNetworkStateFault | MaxDBShardGroupLimitReached | NetworkTypeNotSupported | UnsupportedDBEngineVersionFault | CommonErrors;
/**
 * Creates a new DB shard group for Aurora Limitless Database. You must enable Aurora Limitless Database to create a DB shard group.
 *
 * Valid for: Aurora DB clusters only
 */
export declare const createDBShardGroup: API.OperationMethod<CreateDBShardGroupMessage, DBShardGroup, CreateDBShardGroupError, Credentials | HttpClient.HttpClient>;
export type CreateDBSnapshotError = DBInstanceNotFoundFault | DBSnapshotAlreadyExistsFault | InvalidDBInstanceStateFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Creates a snapshot of a DB instance. The source DB instance must be in the `available` or `storage-optimization` state.
 */
export declare const createDBSnapshot: API.OperationMethod<CreateDBSnapshotMessage, CreateDBSnapshotResult, CreateDBSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateDBSubnetGroupError = DBSubnetGroupAlreadyExistsFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupQuotaExceededFault | DBSubnetQuotaExceededFault | InvalidSubnet | CommonErrors;
/**
 * Creates a new DB subnet group. DB subnet groups must contain at least one subnet in at least two AZs in the Amazon Web Services Region.
 */
export declare const createDBSubnetGroup: API.OperationMethod<CreateDBSubnetGroupMessage, CreateDBSubnetGroupResult, CreateDBSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type CreateEventSubscriptionError = EventSubscriptionQuotaExceededFault | SNSInvalidTopicFault | SNSNoAuthorizationFault | SNSTopicArnNotFoundFault | SourceNotFoundFault | SubscriptionAlreadyExistFault | SubscriptionCategoryNotFoundFault | CommonErrors;
/**
 * Creates an RDS event notification subscription. This operation requires a topic Amazon Resource Name (ARN) created by either the RDS console, the SNS console, or the SNS API. To obtain an ARN with SNS, you must create a topic in Amazon SNS and subscribe to the topic. The ARN is displayed in the SNS console.
 *
 * You can specify the type of source (`SourceType`) that you want to be notified of and provide a list of RDS sources (`SourceIds`) that triggers the events. You can also provide a list of event categories (`EventCategories`) for events that you want to be notified of. For example, you can specify `SourceType` = `db-instance`, `SourceIds` = `mydbinstance1`, `mydbinstance2` and `EventCategories` = `Availability`, `Backup`.
 *
 * If you specify both the `SourceType` and `SourceIds`, such as `SourceType` = `db-instance` and `SourceIds` = `myDBInstance1`, you are notified of all the `db-instance` events for the specified source. If you specify a `SourceType` but do not specify `SourceIds`, you receive notice of the events for that source type for all your RDS sources. If you don't specify either the SourceType or the `SourceIds`, you are notified of events generated from all RDS sources belonging to your customer account.
 *
 * For more information about subscribing to an event for RDS DB engines, see Subscribing to Amazon RDS event notification in the *Amazon RDS User Guide*.
 *
 * For more information about subscribing to an event for Aurora DB engines, see Subscribing to Amazon RDS event notification in the *Amazon Aurora User Guide*.
 */
export declare const createEventSubscription: API.OperationMethod<CreateEventSubscriptionMessage, CreateEventSubscriptionResult, CreateEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateGlobalClusterError = DBClusterNotFoundFault | GlobalClusterAlreadyExistsFault | GlobalClusterQuotaExceededFault | InvalidDBClusterStateFault | InvalidDBShardGroupStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Creates an Aurora global database spread across multiple Amazon Web Services Regions. The global database contains a single primary cluster with read-write capability, and a read-only secondary cluster that receives data from the primary cluster through high-speed replication performed by the Aurora storage subsystem.
 *
 * You can create a global database that is initially empty, and then create the primary and secondary DB clusters in the global database. Or you can specify an existing Aurora cluster during the create operation, and this cluster becomes the primary cluster of the global database.
 *
 * This operation applies only to Aurora DB clusters.
 */
export declare const createGlobalCluster: API.OperationMethod<CreateGlobalClusterMessage, CreateGlobalClusterResult, CreateGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type CreateIntegrationError = DBClusterNotFoundFault | DBInstanceNotFoundFault | IntegrationAlreadyExistsFault | IntegrationConflictOperationFault | IntegrationQuotaExceededFault | KMSKeyNotAccessibleFault | CommonErrors;
/**
 * Creates a zero-ETL integration with Amazon Redshift.
 */
export declare const createIntegration: API.OperationMethod<CreateIntegrationMessage, Integration, CreateIntegrationError, Credentials | HttpClient.HttpClient>;
export type CreateOptionGroupError = OptionGroupAlreadyExistsFault | OptionGroupQuotaExceededFault | CommonErrors;
/**
 * Creates a new option group. You can create up to 20 option groups.
 *
 * This command doesn't apply to RDS Custom.
 */
export declare const createOptionGroup: API.OperationMethod<CreateOptionGroupMessage, CreateOptionGroupResult, CreateOptionGroupError, Credentials | HttpClient.HttpClient>;
export type CreateTenantDatabaseError = DBInstanceNotFoundFault | InvalidDBInstanceStateFault | KMSKeyNotAccessibleFault | TenantDatabaseAlreadyExistsFault | TenantDatabaseQuotaExceededFault | CommonErrors;
/**
 * Creates a tenant database in a DB instance that uses the multi-tenant configuration. Only RDS for Oracle container database (CDB) instances are supported.
 */
export declare const createTenantDatabase: API.OperationMethod<CreateTenantDatabaseMessage, CreateTenantDatabaseResult, CreateTenantDatabaseError, Credentials | HttpClient.HttpClient>;
export type DeleteBlueGreenDeploymentError = BlueGreenDeploymentNotFoundFault | InvalidBlueGreenDeploymentStateFault | CommonErrors;
/**
 * Deletes a blue/green deployment.
 *
 * For more information, see Using Amazon RDS Blue/Green Deployments for database updates in the *Amazon RDS User Guide* and Using Amazon RDS Blue/Green Deployments for database updates in the *Amazon Aurora User Guide*.
 */
export declare const deleteBlueGreenDeployment: API.OperationMethod<DeleteBlueGreenDeploymentRequest, DeleteBlueGreenDeploymentResponse, DeleteBlueGreenDeploymentError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomDBEngineVersionError = CustomDBEngineVersionNotFoundFault | InvalidCustomDBEngineVersionStateFault | CommonErrors;
/**
 * Deletes a custom engine version. To run this command, make sure you meet the following prerequisites:
 *
 * - The CEV must not be the default for RDS Custom. If it is, change the default before running this command.
 *
 * - The CEV must not be associated with an RDS Custom DB instance, RDS Custom instance snapshot, or automated backup of your RDS Custom instance.
 *
 * Typically, deletion takes a few minutes.
 *
 * The MediaImport service that imports files from Amazon S3 to create CEVs isn't integrated with Amazon Web Services CloudTrail. If you turn on data logging for Amazon RDS in CloudTrail, calls to the `DeleteCustomDbEngineVersion` event aren't logged. However, you might see calls from the API gateway that accesses your Amazon S3 bucket. These calls originate from the MediaImport service for the `DeleteCustomDbEngineVersion` event.
 *
 * For more information, see Deleting a CEV in the *Amazon RDS User Guide*.
 */
export declare const deleteCustomDBEngineVersion: API.OperationMethod<DeleteCustomDBEngineVersionMessage, DBEngineVersion, DeleteCustomDBEngineVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteDBClusterError = DBClusterAutomatedBackupQuotaExceededFault | DBClusterNotFoundFault | DBClusterSnapshotAlreadyExistsFault | InvalidDBClusterSnapshotStateFault | InvalidDBClusterStateFault | InvalidGlobalClusterStateFault | KMSKeyNotAccessibleFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * The DeleteDBCluster action deletes a previously provisioned DB cluster. When you delete a DB cluster, all automated backups for that DB cluster are deleted and can't be recovered. Manual DB cluster snapshots of the specified DB cluster are not deleted.
 *
 * If you're deleting a Multi-AZ DB cluster with read replicas, all cluster members are terminated and read replicas are promoted to standalone instances.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const deleteDBCluster: API.OperationMethod<DeleteDBClusterMessage, DeleteDBClusterResult, DeleteDBClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteDBClusterAutomatedBackupError = DBClusterAutomatedBackupNotFoundFault | InvalidDBClusterAutomatedBackupStateFault | CommonErrors;
/**
 * Deletes automated backups using the `DbClusterResourceId` value of the source DB cluster or the Amazon Resource Name (ARN) of the automated backups.
 */
export declare const deleteDBClusterAutomatedBackup: API.OperationMethod<DeleteDBClusterAutomatedBackupMessage, DeleteDBClusterAutomatedBackupResult, DeleteDBClusterAutomatedBackupError, Credentials | HttpClient.HttpClient>;
export type DeleteDBClusterEndpointError = DBClusterEndpointNotFoundFault | InvalidDBClusterEndpointStateFault | InvalidDBClusterStateFault | CommonErrors;
/**
 * Deletes a custom endpoint and removes it from an Amazon Aurora DB cluster.
 *
 * This action only applies to Aurora DB clusters.
 */
export declare const deleteDBClusterEndpoint: API.OperationMethod<DeleteDBClusterEndpointMessage, DBClusterEndpoint, DeleteDBClusterEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteDBClusterParameterGroupError = DBParameterGroupNotFoundFault | InvalidDBParameterGroupStateFault | CommonErrors;
/**
 * Deletes a specified DB cluster parameter group. The DB cluster parameter group to be deleted can't be associated with any DB clusters.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const deleteDBClusterParameterGroup: API.OperationMethod<DeleteDBClusterParameterGroupMessage, DeleteDBClusterParameterGroupResponse, DeleteDBClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteDBClusterSnapshotError = DBClusterSnapshotNotFoundFault | InvalidDBClusterSnapshotStateFault | CommonErrors;
/**
 * Deletes a DB cluster snapshot. If the snapshot is being copied, the copy operation is terminated.
 *
 * The DB cluster snapshot must be in the `available` state to be deleted.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const deleteDBClusterSnapshot: API.OperationMethod<DeleteDBClusterSnapshotMessage, DeleteDBClusterSnapshotResult, DeleteDBClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteDBInstanceError = DBInstanceAutomatedBackupQuotaExceededFault | DBInstanceNotFoundFault | DBSnapshotAlreadyExistsFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | KMSKeyNotAccessibleFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Deletes a previously provisioned DB instance. When you delete a DB instance, all automated backups for that instance are deleted and can't be recovered. However, manual DB snapshots of the DB instance aren't deleted.
 *
 * If you request a final DB snapshot, the status of the Amazon RDS DB instance is `deleting` until the DB snapshot is created. This operation can't be canceled or reverted after it begins. To monitor the status of this operation, use `DescribeDBInstance`.
 *
 * When a DB instance is in a failure state and has a status of `failed`, `incompatible-restore`, or `incompatible-network`, you can only delete it when you skip creation of the final snapshot with the `SkipFinalSnapshot` parameter.
 *
 * If the specified DB instance is part of an Amazon Aurora DB cluster, you can't delete the DB instance if both of the following conditions are true:
 *
 * - The DB cluster is a read replica of another Amazon Aurora DB cluster.
 *
 * - The DB instance is the only instance in the DB cluster.
 *
 * To delete a DB instance in this case, first use the `PromoteReadReplicaDBCluster` operation to promote the DB cluster so that it's no longer a read replica. After the promotion completes, use the `DeleteDBInstance` operation to delete the final instance in the DB cluster.
 *
 * For RDS Custom DB instances, deleting the DB instance permanently deletes the EC2 instance and the associated EBS volumes. Make sure that you don't terminate or delete these resources before you delete the DB instance. Otherwise, deleting the DB instance and creation of the final snapshot might fail.
 */
export declare const deleteDBInstance: API.OperationMethod<DeleteDBInstanceMessage, DeleteDBInstanceResult, DeleteDBInstanceError, Credentials | HttpClient.HttpClient>;
export type DeleteDBInstanceAutomatedBackupError = DBInstanceAutomatedBackupNotFoundFault | InvalidDBInstanceAutomatedBackupStateFault | CommonErrors;
/**
 * Deletes automated backups using the `DbiResourceId` value of the source DB instance or the Amazon Resource Name (ARN) of the automated backups.
 */
export declare const deleteDBInstanceAutomatedBackup: API.OperationMethod<DeleteDBInstanceAutomatedBackupMessage, DeleteDBInstanceAutomatedBackupResult, DeleteDBInstanceAutomatedBackupError, Credentials | HttpClient.HttpClient>;
export type DeleteDBParameterGroupError = DBParameterGroupNotFoundFault | InvalidDBParameterGroupStateFault | CommonErrors;
/**
 * Deletes a specified DB parameter group. The DB parameter group to be deleted can't be associated with any DB instances.
 */
export declare const deleteDBParameterGroup: API.OperationMethod<DeleteDBParameterGroupMessage, DeleteDBParameterGroupResponse, DeleteDBParameterGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteDBProxyError = DBProxyNotFoundFault | InvalidDBProxyStateFault | CommonErrors;
/**
 * Deletes an existing DB proxy.
 */
export declare const deleteDBProxy: API.OperationMethod<DeleteDBProxyRequest, DeleteDBProxyResponse, DeleteDBProxyError, Credentials | HttpClient.HttpClient>;
export type DeleteDBProxyEndpointError = DBProxyEndpointNotFoundFault | InvalidDBProxyEndpointStateFault | CommonErrors;
/**
 * Deletes a `DBProxyEndpoint`. Doing so removes the ability to access the DB proxy using the endpoint that you defined. The endpoint that you delete might have provided capabilities such as read/write or read-only operations, or using a different VPC than the DB proxy's default VPC.
 */
export declare const deleteDBProxyEndpoint: API.OperationMethod<DeleteDBProxyEndpointRequest, DeleteDBProxyEndpointResponse, DeleteDBProxyEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteDBSecurityGroupError = DBSecurityGroupNotFoundFault | InvalidDBSecurityGroupStateFault | CommonErrors;
/**
 * Deletes a DB security group.
 *
 * The specified DB security group must not be associated with any DB instances.
 *
 * EC2-Classic was retired on August 15, 2022. If you haven't migrated from EC2-Classic to a VPC, we recommend that you migrate as soon as possible. For more information, see Migrate from EC2-Classic to a VPC in the *Amazon EC2 User Guide*, the blog EC2-Classic Networking is Retiring - Here's How to Prepare, and Moving a DB instance not in a VPC into a VPC in the *Amazon RDS User Guide*.
 */
export declare const deleteDBSecurityGroup: API.OperationMethod<DeleteDBSecurityGroupMessage, DeleteDBSecurityGroupResponse, DeleteDBSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteDBShardGroupError = DBShardGroupNotFoundFault | InvalidDBClusterStateFault | InvalidDBShardGroupStateFault | CommonErrors;
/**
 * Deletes an Aurora Limitless Database DB shard group.
 */
export declare const deleteDBShardGroup: API.OperationMethod<DeleteDBShardGroupMessage, DBShardGroup, DeleteDBShardGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteDBSnapshotError = DBSnapshotNotFoundFault | InvalidDBSnapshotStateFault | CommonErrors;
/**
 * Deletes a DB snapshot. If the snapshot is being copied, the copy operation is terminated.
 *
 * The DB snapshot must be in the `available` state to be deleted.
 */
export declare const deleteDBSnapshot: API.OperationMethod<DeleteDBSnapshotMessage, DeleteDBSnapshotResult, DeleteDBSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteDBSubnetGroupError = DBSubnetGroupNotFoundFault | InvalidDBSubnetGroupStateFault | InvalidDBSubnetStateFault | CommonErrors;
/**
 * Deletes a DB subnet group.
 *
 * The specified database subnet group must not be associated with any DB instances.
 */
export declare const deleteDBSubnetGroup: API.OperationMethod<DeleteDBSubnetGroupMessage, DeleteDBSubnetGroupResponse, DeleteDBSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteEventSubscriptionError = InvalidEventSubscriptionStateFault | SubscriptionNotFoundFault | CommonErrors;
/**
 * Deletes an RDS event notification subscription.
 */
export declare const deleteEventSubscription: API.OperationMethod<DeleteEventSubscriptionMessage, DeleteEventSubscriptionResult, DeleteEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteGlobalClusterError = GlobalClusterNotFoundFault | InvalidGlobalClusterStateFault | CommonErrors;
/**
 * Deletes a global database cluster. The primary and secondary clusters must already be detached or destroyed first.
 *
 * This action only applies to Aurora DB clusters.
 */
export declare const deleteGlobalCluster: API.OperationMethod<DeleteGlobalClusterMessage, DeleteGlobalClusterResult, DeleteGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationError = IntegrationConflictOperationFault | IntegrationNotFoundFault | InvalidIntegrationStateFault | CommonErrors;
/**
 * Deletes a zero-ETL integration with Amazon Redshift.
 */
export declare const deleteIntegration: API.OperationMethod<DeleteIntegrationMessage, Integration, DeleteIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteOptionGroupError = InvalidOptionGroupStateFault | OptionGroupNotFoundFault | CommonErrors;
/**
 * Deletes an existing option group.
 */
export declare const deleteOptionGroup: API.OperationMethod<DeleteOptionGroupMessage, DeleteOptionGroupResponse, DeleteOptionGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteTenantDatabaseError = DBInstanceNotFoundFault | DBSnapshotAlreadyExistsFault | InvalidDBInstanceStateFault | TenantDatabaseNotFoundFault | CommonErrors;
/**
 * Deletes a tenant database from your DB instance. This command only applies to RDS for Oracle container database (CDB) instances.
 *
 * You can't delete a tenant database when it is the only tenant in the DB instance.
 */
export declare const deleteTenantDatabase: API.OperationMethod<DeleteTenantDatabaseMessage, DeleteTenantDatabaseResult, DeleteTenantDatabaseError, Credentials | HttpClient.HttpClient>;
export type DeregisterDBProxyTargetsError = DBProxyNotFoundFault | DBProxyTargetGroupNotFoundFault | DBProxyTargetNotFoundFault | InvalidDBProxyStateFault | CommonErrors;
/**
 * Remove the association between one or more `DBProxyTarget` data structures and a `DBProxyTargetGroup`.
 */
export declare const deregisterDBProxyTargets: API.OperationMethod<DeregisterDBProxyTargetsRequest, DeregisterDBProxyTargetsResponse, DeregisterDBProxyTargetsError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountAttributesError = CommonErrors;
/**
 * Lists all of the attributes for a customer account. The attributes include Amazon RDS quotas for the account, such as the number of DB instances allowed. The description for a quota includes the quota name, current usage toward that quota, and the quota's maximum value.
 *
 * This command doesn't take any parameters.
 */
export declare const describeAccountAttributes: API.OperationMethod<DescribeAccountAttributesMessage, AccountAttributesMessage, DescribeAccountAttributesError, Credentials | HttpClient.HttpClient>;
export type DescribeBlueGreenDeploymentsError = BlueGreenDeploymentNotFoundFault | CommonErrors;
/**
 * Describes one or more blue/green deployments.
 *
 * For more information, see Using Amazon RDS Blue/Green Deployments for database updates in the *Amazon RDS User Guide* and Using Amazon RDS Blue/Green Deployments for database updates in the *Amazon Aurora User Guide*.
 */
export declare const describeBlueGreenDeployments: API.PaginatedOperationMethod<DescribeBlueGreenDeploymentsRequest, DescribeBlueGreenDeploymentsResponse, DescribeBlueGreenDeploymentsError, Credentials | HttpClient.HttpClient, BlueGreenDeployment>;
export type DescribeCertificatesError = CertificateNotFoundFault | CommonErrors;
/**
 * Lists the set of certificate authority (CA) certificates provided by Amazon RDS for this Amazon Web Services account.
 *
 * For more information, see Using SSL/TLS to encrypt a connection to a DB instance in the *Amazon RDS User Guide* and Using SSL/TLS to encrypt a connection to a DB cluster in the *Amazon Aurora User Guide*.
 */
export declare const describeCertificates: API.PaginatedOperationMethod<DescribeCertificatesMessage, CertificateMessage, DescribeCertificatesError, Credentials | HttpClient.HttpClient, Certificate>;
export type DescribeDBClusterAutomatedBackupsError = DBClusterAutomatedBackupNotFoundFault | CommonErrors;
/**
 * Displays backups for both current and deleted DB clusters. For example, use this operation to find details about automated backups for previously deleted clusters. Current clusters are returned for both the `DescribeDBClusterAutomatedBackups` and `DescribeDBClusters` operations.
 *
 * All parameters are optional.
 */
export declare const describeDBClusterAutomatedBackups: API.PaginatedOperationMethod<DescribeDBClusterAutomatedBackupsMessage, DBClusterAutomatedBackupMessage, DescribeDBClusterAutomatedBackupsError, Credentials | HttpClient.HttpClient, DBClusterAutomatedBackup>;
export type DescribeDBClusterBacktracksError = DBClusterBacktrackNotFoundFault | DBClusterNotFoundFault | CommonErrors;
/**
 * Returns information about backtracks for a DB cluster.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * This action only applies to Aurora MySQL DB clusters.
 */
export declare const describeDBClusterBacktracks: API.PaginatedOperationMethod<DescribeDBClusterBacktracksMessage, DBClusterBacktrackMessage, DescribeDBClusterBacktracksError, Credentials | HttpClient.HttpClient, DBClusterBacktrack>;
export type DescribeDBClusterEndpointsError = DBClusterNotFoundFault | CommonErrors;
/**
 * Returns information about endpoints for an Amazon Aurora DB cluster.
 *
 * This action only applies to Aurora DB clusters.
 */
export declare const describeDBClusterEndpoints: API.PaginatedOperationMethod<DescribeDBClusterEndpointsMessage, DBClusterEndpointMessage, DescribeDBClusterEndpointsError, Credentials | HttpClient.HttpClient, DBClusterEndpoint>;
export type DescribeDBClusterParameterGroupsError = DBParameterGroupNotFoundFault | CommonErrors;
/**
 * Returns a list of `DBClusterParameterGroup` descriptions. If a `DBClusterParameterGroupName` parameter is specified, the list will contain only the description of the specified DB cluster parameter group.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const describeDBClusterParameterGroups: API.PaginatedOperationMethod<DescribeDBClusterParameterGroupsMessage, DBClusterParameterGroupsMessage, DescribeDBClusterParameterGroupsError, Credentials | HttpClient.HttpClient, DBClusterParameterGroup>;
export type DescribeDBClusterParametersError = DBParameterGroupNotFoundFault | CommonErrors;
/**
 * Returns the detailed parameter list for a particular DB cluster parameter group.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const describeDBClusterParameters: API.PaginatedOperationMethod<DescribeDBClusterParametersMessage, DBClusterParameterGroupDetails, DescribeDBClusterParametersError, Credentials | HttpClient.HttpClient, Parameter>;
export type DescribeDBClustersError = DBClusterNotFoundFault | CommonErrors;
/**
 * Describes existing Amazon Aurora DB clusters and Multi-AZ DB clusters. This API supports pagination.
 *
 * For more information on Amazon Aurora DB clusters, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 *
 * This operation can also return information for Amazon Neptune DB instances and Amazon DocumentDB instances.
 */
export declare const describeDBClusters: API.PaginatedOperationMethod<DescribeDBClustersMessage, DBClusterMessage, DescribeDBClustersError, Credentials | HttpClient.HttpClient, DBCluster>;
export type DescribeDBClusterSnapshotAttributesError = DBClusterSnapshotNotFoundFault | CommonErrors;
/**
 * Returns a list of DB cluster snapshot attribute names and values for a manual DB cluster snapshot.
 *
 * When sharing snapshots with other Amazon Web Services accounts, `DescribeDBClusterSnapshotAttributes` returns the `restore` attribute and a list of IDs for the Amazon Web Services accounts that are authorized to copy or restore the manual DB cluster snapshot. If `all` is included in the list of values for the `restore` attribute, then the manual DB cluster snapshot is public and can be copied or restored by all Amazon Web Services accounts.
 *
 * To add or remove access for an Amazon Web Services account to copy or restore a manual DB cluster snapshot, or to make the manual DB cluster snapshot public or private, use the `ModifyDBClusterSnapshotAttribute` API action.
 */
export declare const describeDBClusterSnapshotAttributes: API.OperationMethod<DescribeDBClusterSnapshotAttributesMessage, DescribeDBClusterSnapshotAttributesResult, DescribeDBClusterSnapshotAttributesError, Credentials | HttpClient.HttpClient>;
export type DescribeDBClusterSnapshotsError = DBClusterSnapshotNotFoundFault | CommonErrors;
/**
 * Returns information about DB cluster snapshots. This API action supports pagination.
 *
 * For more information on Amazon Aurora DB clusters, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const describeDBClusterSnapshots: API.PaginatedOperationMethod<DescribeDBClusterSnapshotsMessage, DBClusterSnapshotMessage, DescribeDBClusterSnapshotsError, Credentials | HttpClient.HttpClient, DBClusterSnapshot>;
export type DescribeDBEngineVersionsError = InvalidParameterCombination | CommonErrors;
/**
 * Describes the properties of specific versions of DB engines.
 */
export declare const describeDBEngineVersions: API.PaginatedOperationMethod<DescribeDBEngineVersionsMessage, DBEngineVersionMessage, DescribeDBEngineVersionsError, Credentials | HttpClient.HttpClient, DBEngineVersion>;
export type DescribeDBInstanceAutomatedBackupsError = DBInstanceAutomatedBackupNotFoundFault | CommonErrors;
/**
 * Displays backups for both current and deleted instances. For example, use this operation to find details about automated backups for previously deleted instances. Current instances with retention periods greater than zero (0) are returned for both the `DescribeDBInstanceAutomatedBackups` and `DescribeDBInstances` operations.
 *
 * All parameters are optional.
 */
export declare const describeDBInstanceAutomatedBackups: API.PaginatedOperationMethod<DescribeDBInstanceAutomatedBackupsMessage, DBInstanceAutomatedBackupMessage, DescribeDBInstanceAutomatedBackupsError, Credentials | HttpClient.HttpClient, DBInstanceAutomatedBackup>;
export type DescribeDBInstancesError = DBInstanceNotFoundFault | CommonErrors;
/**
 * Describes provisioned RDS instances. This API supports pagination.
 *
 * This operation can also return information for Amazon Neptune DB instances and Amazon DocumentDB instances.
 */
export declare const describeDBInstances: API.PaginatedOperationMethod<DescribeDBInstancesMessage, DBInstanceMessage, DescribeDBInstancesError, Credentials | HttpClient.HttpClient, DBInstance>;
export type DescribeDBLogFilesError = DBInstanceNotFoundFault | DBInstanceNotReadyFault | CommonErrors;
/**
 * Returns a list of DB log files for the DB instance.
 *
 * This command doesn't apply to RDS Custom.
 */
export declare const describeDBLogFiles: API.PaginatedOperationMethod<DescribeDBLogFilesMessage, DescribeDBLogFilesResponse, DescribeDBLogFilesError, Credentials | HttpClient.HttpClient, DescribeDBLogFilesDetails>;
export type DescribeDBMajorEngineVersionsError = CommonErrors;
/**
 * Describes the properties of specific major versions of DB engines.
 */
export declare const describeDBMajorEngineVersions: API.PaginatedOperationMethod<DescribeDBMajorEngineVersionsRequest, DescribeDBMajorEngineVersionsResponse, DescribeDBMajorEngineVersionsError, Credentials | HttpClient.HttpClient, DBMajorEngineVersion>;
export type DescribeDBParameterGroupsError = DBParameterGroupNotFoundFault | CommonErrors;
/**
 * Returns a list of `DBParameterGroup` descriptions. If a `DBParameterGroupName` is specified, the list will contain only the description of the specified DB parameter group.
 */
export declare const describeDBParameterGroups: API.PaginatedOperationMethod<DescribeDBParameterGroupsMessage, DBParameterGroupsMessage, DescribeDBParameterGroupsError, Credentials | HttpClient.HttpClient, DBParameterGroup>;
export type DescribeDBParametersError = DBParameterGroupNotFoundFault | CommonErrors;
/**
 * Returns the detailed parameter list for a particular DB parameter group.
 */
export declare const describeDBParameters: API.PaginatedOperationMethod<DescribeDBParametersMessage, DBParameterGroupDetails, DescribeDBParametersError, Credentials | HttpClient.HttpClient, Parameter>;
export type DescribeDBProxiesError = DBProxyNotFoundFault | CommonErrors;
/**
 * Returns information about DB proxies.
 */
export declare const describeDBProxies: API.PaginatedOperationMethod<DescribeDBProxiesRequest, DescribeDBProxiesResponse, DescribeDBProxiesError, Credentials | HttpClient.HttpClient, DBProxy>;
export type DescribeDBProxyEndpointsError = DBProxyEndpointNotFoundFault | DBProxyNotFoundFault | CommonErrors;
/**
 * Returns information about DB proxy endpoints.
 */
export declare const describeDBProxyEndpoints: API.PaginatedOperationMethod<DescribeDBProxyEndpointsRequest, DescribeDBProxyEndpointsResponse, DescribeDBProxyEndpointsError, Credentials | HttpClient.HttpClient, DBProxyEndpoint>;
export type DescribeDBProxyTargetGroupsError = DBProxyNotFoundFault | DBProxyTargetGroupNotFoundFault | InvalidDBProxyStateFault | CommonErrors;
/**
 * Returns information about DB proxy target groups, represented by `DBProxyTargetGroup` data structures.
 */
export declare const describeDBProxyTargetGroups: API.PaginatedOperationMethod<DescribeDBProxyTargetGroupsRequest, DescribeDBProxyTargetGroupsResponse, DescribeDBProxyTargetGroupsError, Credentials | HttpClient.HttpClient, DBProxyTargetGroup>;
export type DescribeDBProxyTargetsError = DBProxyNotFoundFault | DBProxyTargetGroupNotFoundFault | DBProxyTargetNotFoundFault | InvalidDBProxyStateFault | CommonErrors;
/**
 * Returns information about `DBProxyTarget` objects. This API supports pagination.
 */
export declare const describeDBProxyTargets: API.PaginatedOperationMethod<DescribeDBProxyTargetsRequest, DescribeDBProxyTargetsResponse, DescribeDBProxyTargetsError, Credentials | HttpClient.HttpClient, DBProxyTarget>;
export type DescribeDBRecommendationsError = CommonErrors;
/**
 * Describes the recommendations to resolve the issues for your DB instances, DB clusters, and DB parameter groups.
 */
export declare const describeDBRecommendations: API.PaginatedOperationMethod<DescribeDBRecommendationsMessage, DBRecommendationsMessage, DescribeDBRecommendationsError, Credentials | HttpClient.HttpClient, DBRecommendation>;
export type DescribeDBSecurityGroupsError = DBSecurityGroupNotFoundFault | CommonErrors;
/**
 * Returns a list of `DBSecurityGroup` descriptions. If a `DBSecurityGroupName` is specified, the list will contain only the descriptions of the specified DB security group.
 *
 * EC2-Classic was retired on August 15, 2022. If you haven't migrated from EC2-Classic to a VPC, we recommend that you migrate as soon as possible. For more information, see Migrate from EC2-Classic to a VPC in the *Amazon EC2 User Guide*, the blog EC2-Classic Networking is Retiring - Here's How to Prepare, and Moving a DB instance not in a VPC into a VPC in the *Amazon RDS User Guide*.
 */
export declare const describeDBSecurityGroups: API.PaginatedOperationMethod<DescribeDBSecurityGroupsMessage, DBSecurityGroupMessage, DescribeDBSecurityGroupsError, Credentials | HttpClient.HttpClient, DBSecurityGroup>;
export type DescribeDBShardGroupsError = DBClusterNotFoundFault | DBShardGroupNotFoundFault | CommonErrors;
/**
 * Describes existing Aurora Limitless Database DB shard groups.
 */
export declare const describeDBShardGroups: API.OperationMethod<DescribeDBShardGroupsMessage, DescribeDBShardGroupsResponse, DescribeDBShardGroupsError, Credentials | HttpClient.HttpClient>;
export type DescribeDBSnapshotAttributesError = DBSnapshotNotFoundFault | CommonErrors;
/**
 * Returns a list of DB snapshot attribute names and values for a manual DB snapshot.
 *
 * When sharing snapshots with other Amazon Web Services accounts, `DescribeDBSnapshotAttributes` returns the `restore` attribute and a list of IDs for the Amazon Web Services accounts that are authorized to copy or restore the manual DB snapshot. If `all` is included in the list of values for the `restore` attribute, then the manual DB snapshot is public and can be copied or restored by all Amazon Web Services accounts.
 *
 * To add or remove access for an Amazon Web Services account to copy or restore a manual DB snapshot, or to make the manual DB snapshot public or private, use the `ModifyDBSnapshotAttribute` API action.
 */
export declare const describeDBSnapshotAttributes: API.OperationMethod<DescribeDBSnapshotAttributesMessage, DescribeDBSnapshotAttributesResult, DescribeDBSnapshotAttributesError, Credentials | HttpClient.HttpClient>;
export type DescribeDBSnapshotsError = DBSnapshotNotFoundFault | CommonErrors;
/**
 * Returns information about DB snapshots. This API action supports pagination.
 */
export declare const describeDBSnapshots: API.PaginatedOperationMethod<DescribeDBSnapshotsMessage, DBSnapshotMessage, DescribeDBSnapshotsError, Credentials | HttpClient.HttpClient, DBSnapshot>;
export type DescribeDBSnapshotTenantDatabasesError = DBSnapshotNotFoundFault | CommonErrors;
/**
 * Describes the tenant databases that exist in a DB snapshot. This command only applies to RDS for Oracle DB instances in the multi-tenant configuration.
 *
 * You can use this command to inspect the tenant databases within a snapshot before restoring it. You can't directly interact with the tenant databases in a DB snapshot. If you restore a snapshot that was taken from DB instance using the multi-tenant configuration, you restore all its tenant databases.
 */
export declare const describeDBSnapshotTenantDatabases: API.PaginatedOperationMethod<DescribeDBSnapshotTenantDatabasesMessage, DBSnapshotTenantDatabasesMessage, DescribeDBSnapshotTenantDatabasesError, Credentials | HttpClient.HttpClient, DBSnapshotTenantDatabase>;
export type DescribeDBSubnetGroupsError = DBSubnetGroupNotFoundFault | CommonErrors;
/**
 * Returns a list of DBSubnetGroup descriptions. If a DBSubnetGroupName is specified, the list will contain only the descriptions of the specified DBSubnetGroup.
 *
 * For an overview of CIDR ranges, go to the Wikipedia Tutorial.
 */
export declare const describeDBSubnetGroups: API.PaginatedOperationMethod<DescribeDBSubnetGroupsMessage, DBSubnetGroupMessage, DescribeDBSubnetGroupsError, Credentials | HttpClient.HttpClient, DBSubnetGroup>;
export type DescribeEngineDefaultClusterParametersError = CommonErrors;
/**
 * Returns the default engine and system parameter information for the cluster database engine.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 */
export declare const describeEngineDefaultClusterParameters: API.PaginatedOperationMethod<DescribeEngineDefaultClusterParametersMessage, DescribeEngineDefaultClusterParametersResult, DescribeEngineDefaultClusterParametersError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEngineDefaultParametersError = CommonErrors;
/**
 * Returns the default engine and system parameter information for the specified database engine.
 */
export declare const describeEngineDefaultParameters: API.PaginatedOperationMethod<DescribeEngineDefaultParametersMessage, DescribeEngineDefaultParametersResult, DescribeEngineDefaultParametersError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEventCategoriesError = CommonErrors;
/**
 * Displays a list of categories for all event source types, or, if specified, for a specified source type. You can also see this list in the "Amazon RDS event categories and event messages" section of the *Amazon RDS User Guide* or the *Amazon Aurora User Guide* .
 */
export declare const describeEventCategories: API.OperationMethod<DescribeEventCategoriesMessage, EventCategoriesMessage, DescribeEventCategoriesError, Credentials | HttpClient.HttpClient>;
export type DescribeEventsError = CommonErrors;
/**
 * Returns events related to DB instances, DB clusters, DB parameter groups, DB security groups, DB snapshots, DB cluster snapshots, and RDS Proxies for the past 14 days. Events specific to a particular DB instance, DB cluster, DB parameter group, DB security group, DB snapshot, DB cluster snapshot group, or RDS Proxy can be obtained by providing the name as a parameter.
 *
 * For more information on working with events, see Monitoring Amazon RDS events in the *Amazon RDS User Guide* and Monitoring Amazon Aurora events in the *Amazon Aurora User Guide*.
 *
 * By default, RDS returns events that were generated in the past hour.
 */
export declare const describeEvents: API.PaginatedOperationMethod<DescribeEventsMessage, EventsMessage, DescribeEventsError, Credentials | HttpClient.HttpClient, Event>;
export type DescribeEventSubscriptionsError = SubscriptionNotFoundFault | CommonErrors;
/**
 * Lists all the subscription descriptions for a customer account. The description for a subscription includes `SubscriptionName`, `SNSTopicARN`, `CustomerID`, `SourceType`, `SourceID`, `CreationTime`, and `Status`.
 *
 * If you specify a `SubscriptionName`, lists the description for that subscription.
 */
export declare const describeEventSubscriptions: API.PaginatedOperationMethod<DescribeEventSubscriptionsMessage, EventSubscriptionsMessage, DescribeEventSubscriptionsError, Credentials | HttpClient.HttpClient, EventSubscription>;
export type DescribeExportTasksError = ExportTaskNotFoundFault | CommonErrors;
/**
 * Returns information about a snapshot or cluster export to Amazon S3. This API operation supports pagination.
 */
export declare const describeExportTasks: API.PaginatedOperationMethod<DescribeExportTasksMessage, ExportTasksMessage, DescribeExportTasksError, Credentials | HttpClient.HttpClient, ExportTask>;
export type DescribeGlobalClustersError = GlobalClusterNotFoundFault | CommonErrors;
/**
 * Returns information about Aurora global database clusters. This API supports pagination.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * This action only applies to Aurora DB clusters.
 */
export declare const describeGlobalClusters: API.PaginatedOperationMethod<DescribeGlobalClustersMessage, GlobalClustersMessage, DescribeGlobalClustersError, Credentials | HttpClient.HttpClient, GlobalCluster>;
export type DescribeIntegrationsError = IntegrationNotFoundFault | CommonErrors;
/**
 * Describe one or more zero-ETL integrations with Amazon Redshift.
 */
export declare const describeIntegrations: API.PaginatedOperationMethod<DescribeIntegrationsMessage, DescribeIntegrationsResponse, DescribeIntegrationsError, Credentials | HttpClient.HttpClient, Integration>;
export type DescribeOptionGroupOptionsError = CommonErrors;
/**
 * Describes all available options for the specified engine.
 */
export declare const describeOptionGroupOptions: API.PaginatedOperationMethod<DescribeOptionGroupOptionsMessage, OptionGroupOptionsMessage, DescribeOptionGroupOptionsError, Credentials | HttpClient.HttpClient, OptionGroupOption>;
export type DescribeOptionGroupsError = OptionGroupNotFoundFault | CommonErrors;
/**
 * Describes the available option groups.
 */
export declare const describeOptionGroups: API.PaginatedOperationMethod<DescribeOptionGroupsMessage, OptionGroups, DescribeOptionGroupsError, Credentials | HttpClient.HttpClient, OptionGroup>;
export type DescribeOrderableDBInstanceOptionsError = CommonErrors;
/**
 * Describes the orderable DB instance options for a specified DB engine.
 */
export declare const describeOrderableDBInstanceOptions: API.PaginatedOperationMethod<DescribeOrderableDBInstanceOptionsMessage, OrderableDBInstanceOptionsMessage, DescribeOrderableDBInstanceOptionsError, Credentials | HttpClient.HttpClient, OrderableDBInstanceOption>;
export type DescribePendingMaintenanceActionsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns a list of resources (for example, DB instances) that have at least one pending maintenance action.
 *
 * This API follows an eventual consistency model. This means that the result of the `DescribePendingMaintenanceActions` command might not be immediately visible to all subsequent RDS commands. Keep this in mind when you use `DescribePendingMaintenanceActions` immediately after using a previous API command such as `ApplyPendingMaintenanceActions`.
 */
export declare const describePendingMaintenanceActions: API.PaginatedOperationMethod<DescribePendingMaintenanceActionsMessage, PendingMaintenanceActionsMessage, DescribePendingMaintenanceActionsError, Credentials | HttpClient.HttpClient, ResourcePendingMaintenanceActions>;
export type DescribeReservedDBInstancesError = ReservedDBInstanceNotFoundFault | CommonErrors;
/**
 * Returns information about reserved DB instances for this account, or about a specified reserved DB instance.
 */
export declare const describeReservedDBInstances: API.PaginatedOperationMethod<DescribeReservedDBInstancesMessage, ReservedDBInstanceMessage, DescribeReservedDBInstancesError, Credentials | HttpClient.HttpClient, ReservedDBInstance>;
export type DescribeReservedDBInstancesOfferingsError = ReservedDBInstancesOfferingNotFoundFault | CommonErrors;
/**
 * Lists available reserved DB instance offerings.
 */
export declare const describeReservedDBInstancesOfferings: API.PaginatedOperationMethod<DescribeReservedDBInstancesOfferingsMessage, ReservedDBInstancesOfferingMessage, DescribeReservedDBInstancesOfferingsError, Credentials | HttpClient.HttpClient, ReservedDBInstancesOffering>;
export type DescribeServerlessV2PlatformVersionsError = CommonErrors;
/**
 * Describes the properties of specific platform versions for Aurora Serverless v2.
 */
export declare const describeServerlessV2PlatformVersions: API.PaginatedOperationMethod<DescribeServerlessV2PlatformVersionsMessage, ServerlessV2PlatformVersionsMessage, DescribeServerlessV2PlatformVersionsError, Credentials | HttpClient.HttpClient, ServerlessV2PlatformVersionInfo>;
export type DescribeSourceRegionsError = CommonErrors;
/**
 * Returns a list of the source Amazon Web Services Regions where the current Amazon Web Services Region can create a read replica, copy a DB snapshot from, or replicate automated backups from.
 *
 * Use this operation to determine whether cross-Region features are supported between other Regions and your current Region. This operation supports pagination.
 *
 * To return information about the Regions that are enabled for your account, or all Regions, use the EC2 operation `DescribeRegions`. For more information, see DescribeRegions in the *Amazon EC2 API Reference*.
 */
export declare const describeSourceRegions: API.PaginatedOperationMethod<DescribeSourceRegionsMessage, SourceRegionMessage, DescribeSourceRegionsError, Credentials | HttpClient.HttpClient, SourceRegion>;
export type DescribeTenantDatabasesError = DBInstanceNotFoundFault | CommonErrors;
/**
 * Describes the tenant databases in a DB instance that uses the multi-tenant configuration. Only RDS for Oracle CDB instances are supported.
 */
export declare const describeTenantDatabases: API.PaginatedOperationMethod<DescribeTenantDatabasesMessage, TenantDatabasesMessage, DescribeTenantDatabasesError, Credentials | HttpClient.HttpClient, TenantDatabase>;
export type DescribeValidDBInstanceModificationsError = DBInstanceNotFoundFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * You can call `DescribeValidDBInstanceModifications` to learn what modifications you can make to your DB instance. You can use this information when you call `ModifyDBInstance`.
 *
 * This command doesn't apply to RDS Custom.
 */
export declare const describeValidDBInstanceModifications: API.OperationMethod<DescribeValidDBInstanceModificationsMessage, DescribeValidDBInstanceModificationsResult, DescribeValidDBInstanceModificationsError, Credentials | HttpClient.HttpClient>;
export type DisableHttpEndpointError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Disables the HTTP endpoint for the specified DB cluster. Disabling this endpoint disables RDS Data API.
 *
 * For more information, see Using RDS Data API in the *Amazon Aurora User Guide*.
 *
 * This operation applies only to Aurora Serverless v2 and provisioned DB clusters. To disable the HTTP endpoint for Aurora Serverless v1 DB clusters, use the `EnableHttpEndpoint` parameter of the `ModifyDBCluster` operation.
 */
export declare const disableHttpEndpoint: API.OperationMethod<DisableHttpEndpointRequest, DisableHttpEndpointResponse, DisableHttpEndpointError, Credentials | HttpClient.HttpClient>;
export type DownloadDBLogFilePortionError = DBInstanceNotFoundFault | DBInstanceNotReadyFault | DBLogFileNotFoundFault | CommonErrors;
/**
 * Downloads all or a portion of the specified log file, up to 1 MB in size.
 *
 * This command doesn't apply to RDS Custom.
 *
 * This operation uses resources on database instances. Because of this, we recommend publishing database logs to CloudWatch and then using the GetLogEvents operation. For more information, see GetLogEvents in the *Amazon CloudWatch Logs API Reference*.
 */
export declare const downloadDBLogFilePortion: API.PaginatedOperationMethod<DownloadDBLogFilePortionMessage, DownloadDBLogFilePortionDetails, DownloadDBLogFilePortionError, Credentials | HttpClient.HttpClient, unknown>;
export type EnableHttpEndpointError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Enables the HTTP endpoint for the DB cluster. By default, the HTTP endpoint isn't enabled.
 *
 * When enabled, this endpoint provides a connectionless web service API (RDS Data API) for running SQL queries on the Aurora DB cluster. You can also query your database from inside the RDS console with the RDS query editor.
 *
 * For more information, see Using RDS Data API in the *Amazon Aurora User Guide*.
 *
 * This operation applies only to Aurora Serverless v2 and provisioned DB clusters. To enable the HTTP endpoint for Aurora Serverless v1 DB clusters, use the `EnableHttpEndpoint` parameter of the `ModifyDBCluster` operation.
 */
export declare const enableHttpEndpoint: API.OperationMethod<EnableHttpEndpointRequest, EnableHttpEndpointResponse, EnableHttpEndpointError, Credentials | HttpClient.HttpClient>;
export type FailoverDBClusterError = DBClusterNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Forces a failover for a DB cluster.
 *
 * For an Aurora DB cluster, failover for a DB cluster promotes one of the Aurora Replicas (read-only instances) in the DB cluster to be the primary DB instance (the cluster writer).
 *
 * For a Multi-AZ DB cluster, after RDS terminates the primary DB instance, the internal monitoring system detects that the primary DB instance is unhealthy and promotes a readable standby (read-only instances) in the DB cluster to be the primary DB instance (the cluster writer). Failover times are typically less than 35 seconds.
 *
 * An Amazon Aurora DB cluster automatically fails over to an Aurora Replica, if one exists, when the primary DB instance fails. A Multi-AZ DB cluster automatically fails over to a readable standby DB instance when the primary DB instance fails.
 *
 * To simulate a failure of a primary instance for testing, you can force a failover. Because each instance in a DB cluster has its own endpoint address, make sure to clean up and re-establish any existing connections that use those endpoint addresses when the failover is complete.
 *
 * For more information on Amazon Aurora DB clusters, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const failoverDBCluster: API.OperationMethod<FailoverDBClusterMessage, FailoverDBClusterResult, FailoverDBClusterError, Credentials | HttpClient.HttpClient>;
export type FailoverGlobalClusterError = DBClusterNotFoundFault | GlobalClusterNotFoundFault | InvalidDBClusterStateFault | InvalidGlobalClusterStateFault | CommonErrors;
/**
 * Promotes the specified secondary DB cluster to be the primary DB cluster in the global database cluster to fail over or switch over a global database. Switchover operations were previously called "managed planned failovers."
 *
 * Although this operation can be used either to fail over or to switch over a global database cluster, its intended use is for global database failover. To switch over a global database cluster, we recommend that you use the SwitchoverGlobalCluster operation instead.
 *
 * How you use this operation depends on whether you are failing over or switching over your global database cluster:
 *
 * - Failing over - Specify the `AllowDataLoss` parameter and don't specify the `Switchover` parameter.
 *
 * - Switching over - Specify the `Switchover` parameter or omit it, but don't specify the `AllowDataLoss` parameter.
 *
 * **About failing over and switching over**
 *
 * While failing over and switching over a global database cluster both change the primary DB cluster, you use these operations for different reasons:
 *
 * - *Failing over* - Use this operation to respond to an unplanned event, such as a Regional disaster in the primary Region. Failing over can result in a loss of write transaction data that wasn't replicated to the chosen secondary before the failover event occurred. However, the recovery process that promotes a DB instance on the chosen seconday DB cluster to be the primary writer DB instance guarantees that the data is in a transactionally consistent state.
 *
 * For more information about failing over an Amazon Aurora global database, see Performing managed failovers for Aurora global databases in the *Amazon Aurora User Guide*.
 *
 * - *Switching over* - Use this operation on a healthy global database cluster for planned events, such as Regional rotation or to fail back to the original primary DB cluster after a failover operation. With this operation, there is no data loss.
 *
 * For more information about switching over an Amazon Aurora global database, see Performing switchovers for Aurora global databases in the *Amazon Aurora User Guide*.
 */
export declare const failoverGlobalCluster: API.OperationMethod<FailoverGlobalClusterMessage, FailoverGlobalClusterResult, FailoverGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = BlueGreenDeploymentNotFoundFault | DBClusterNotFoundFault | DBInstanceNotFoundFault | DBProxyEndpointNotFoundFault | DBProxyNotFoundFault | DBProxyTargetGroupNotFoundFault | DBShardGroupNotFoundFault | DBSnapshotNotFoundFault | DBSnapshotTenantDatabaseNotFoundFault | IntegrationNotFoundFault | TenantDatabaseNotFoundFault | CommonErrors;
/**
 * Lists all tags on an Amazon RDS resource.
 *
 * For an overview on tagging an Amazon RDS resource, see Tagging Amazon RDS Resources in the *Amazon RDS User Guide* or Tagging Amazon Aurora and Amazon RDS Resources in the *Amazon Aurora User Guide*.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceMessage, TagListMessage, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ModifyActivityStreamError = DBInstanceNotFoundFault | InvalidDBInstanceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Changes the audit policy state of a database activity stream to either locked (default) or unlocked. A locked policy is read-only, whereas an unlocked policy is read/write. If your activity stream is started and locked, you can unlock it, customize your audit policy, and then lock your activity stream. Restarting the activity stream isn't required. For more information, see Modifying a database activity stream in the *Amazon RDS User Guide*.
 *
 * This operation is supported for RDS for Oracle and Microsoft SQL Server.
 */
export declare const modifyActivityStream: API.OperationMethod<ModifyActivityStreamRequest, ModifyActivityStreamResponse, ModifyActivityStreamError, Credentials | HttpClient.HttpClient>;
export type ModifyCertificatesError = CertificateNotFoundFault | CommonErrors;
/**
 * Override the system-default Secure Sockets Layer/Transport Layer Security (SSL/TLS) certificate for Amazon RDS for new DB instances, or remove the override.
 *
 * By using this operation, you can specify an RDS-approved SSL/TLS certificate for new DB instances that is different from the default certificate provided by RDS. You can also use this operation to remove the override, so that new DB instances use the default certificate provided by RDS.
 *
 * You might need to override the default certificate in the following situations:
 *
 * - You already migrated your applications to support the latest certificate authority (CA) certificate, but the new CA certificate is not yet the RDS default CA certificate for the specified Amazon Web Services Region.
 *
 * - RDS has already moved to a new default CA certificate for the specified Amazon Web Services Region, but you are still in the process of supporting the new CA certificate. In this case, you temporarily need additional time to finish your application changes.
 *
 * For more information about rotating your SSL/TLS certificate for RDS DB engines, see Rotating Your SSL/TLS Certificate in the *Amazon RDS User Guide*.
 *
 * For more information about rotating your SSL/TLS certificate for Aurora DB engines, see Rotating Your SSL/TLS Certificate in the *Amazon Aurora User Guide*.
 */
export declare const modifyCertificates: API.OperationMethod<ModifyCertificatesMessage, ModifyCertificatesResult, ModifyCertificatesError, Credentials | HttpClient.HttpClient>;
export type ModifyCurrentDBClusterCapacityError = DBClusterNotFoundFault | InvalidDBClusterCapacityFault | InvalidDBClusterStateFault | CommonErrors;
/**
 * Set the capacity of an Aurora Serverless v1 DB cluster to a specific value.
 *
 * Aurora Serverless v1 scales seamlessly based on the workload on the DB cluster. In some cases, the capacity might not scale fast enough to meet a sudden change in workload, such as a large number of new transactions. Call `ModifyCurrentDBClusterCapacity` to set the capacity explicitly.
 *
 * After this call sets the DB cluster capacity, Aurora Serverless v1 can automatically scale the DB cluster based on the cooldown period for scaling up and the cooldown period for scaling down.
 *
 * For more information about Aurora Serverless v1, see Using Amazon Aurora Serverless v1 in the *Amazon Aurora User Guide*.
 *
 * If you call `ModifyCurrentDBClusterCapacity` with the default `TimeoutAction`, connections that prevent Aurora Serverless v1 from finding a scaling point might be dropped. For more information about scaling points, see Autoscaling for Aurora Serverless v1 in the *Amazon Aurora User Guide*.
 *
 * This operation only applies to Aurora Serverless v1 DB clusters.
 */
export declare const modifyCurrentDBClusterCapacity: API.OperationMethod<ModifyCurrentDBClusterCapacityMessage, DBClusterCapacityInfo, ModifyCurrentDBClusterCapacityError, Credentials | HttpClient.HttpClient>;
export type ModifyCustomDBEngineVersionError = CustomDBEngineVersionNotFoundFault | InvalidCustomDBEngineVersionStateFault | CommonErrors;
/**
 * Modifies the status of a custom engine version (CEV). You can find CEVs to modify by calling `DescribeDBEngineVersions`.
 *
 * The MediaImport service that imports files from Amazon S3 to create CEVs isn't integrated with Amazon Web Services CloudTrail. If you turn on data logging for Amazon RDS in CloudTrail, calls to the `ModifyCustomDbEngineVersion` event aren't logged. However, you might see calls from the API gateway that accesses your Amazon S3 bucket. These calls originate from the MediaImport service for the `ModifyCustomDbEngineVersion` event.
 *
 * For more information, see Modifying CEV status in the *Amazon RDS User Guide*.
 */
export declare const modifyCustomDBEngineVersion: API.OperationMethod<ModifyCustomDBEngineVersionMessage, DBEngineVersion, ModifyCustomDBEngineVersionError, Credentials | HttpClient.HttpClient>;
export type ModifyDBClusterError = DBClusterAlreadyExistsFault | DBClusterNotFoundFault | DBClusterParameterGroupNotFoundFault | DBInstanceAlreadyExistsFault | DBParameterGroupNotFoundFault | DBSubnetGroupNotFoundFault | DomainNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidDBSecurityGroupStateFault | InvalidDBSubnetGroupStateFault | InvalidGlobalClusterStateFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | OptionGroupNotFoundFault | StorageQuotaExceededFault | StorageTypeNotAvailableFault | StorageTypeNotSupportedFault | VpcEncryptionControlViolationException | InvalidParameterCombination | InvalidParameterValue | CommonErrors;
/**
 * Modifies the settings of an Amazon Aurora DB cluster or a Multi-AZ DB cluster. You can change one or more settings by specifying these parameters and the new values in the request.
 *
 * For more information on Amazon Aurora DB clusters, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const modifyDBCluster: API.OperationMethod<ModifyDBClusterMessage, ModifyDBClusterResult, ModifyDBClusterError, Credentials | HttpClient.HttpClient>;
export type ModifyDBClusterEndpointError = DBClusterEndpointNotFoundFault | DBInstanceNotFoundFault | InvalidDBClusterEndpointStateFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Modifies the properties of an endpoint in an Amazon Aurora DB cluster.
 *
 * This operation only applies to Aurora DB clusters.
 */
export declare const modifyDBClusterEndpoint: API.OperationMethod<ModifyDBClusterEndpointMessage, DBClusterEndpoint, ModifyDBClusterEndpointError, Credentials | HttpClient.HttpClient>;
export type ModifyDBClusterParameterGroupError = DBParameterGroupNotFoundFault | InvalidDBParameterGroupStateFault | CommonErrors;
/**
 * Modifies the parameters of a DB cluster parameter group. To modify more than one parameter, submit a list of the following: `ParameterName`, `ParameterValue`, and `ApplyMethod`. A maximum of 20 parameters can be modified in a single request.
 *
 * There are two types of parameters - dynamic parameters and static parameters. Changes to dynamic parameters are applied to the DB cluster immediately without a reboot. Changes to static parameters are applied only after the DB cluster is rebooted, which can be done using `RebootDBCluster` operation. You can use the *Parameter Groups* option of the Amazon RDS console or the `DescribeDBClusterParameters` operation to verify that your DB cluster parameter group has been created or modified.
 *
 * For more information on Amazon Aurora DB clusters, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide.*
 */
export declare const modifyDBClusterParameterGroup: API.OperationMethod<ModifyDBClusterParameterGroupMessage, DBClusterParameterGroupNameMessage, ModifyDBClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyDBClusterSnapshotAttributeError = DBClusterSnapshotNotFoundFault | InvalidDBClusterSnapshotStateFault | SharedSnapshotQuotaExceededFault | CommonErrors;
/**
 * Adds an attribute and values to, or removes an attribute and values from, a manual DB cluster snapshot.
 *
 * To share a manual DB cluster snapshot with other Amazon Web Services accounts, specify `restore` as the `AttributeName` and use the `ValuesToAdd` parameter to add a list of IDs of the Amazon Web Services accounts that are authorized to restore the manual DB cluster snapshot. Use the value `all` to make the manual DB cluster snapshot public, which means that it can be copied or restored by all Amazon Web Services accounts.
 *
 * Don't add the `all` value for any manual DB cluster snapshots that contain private information that you don't want available to all Amazon Web Services accounts.
 *
 * If a manual DB cluster snapshot is encrypted, it can be shared, but only by specifying a list of authorized Amazon Web Services account IDs for the `ValuesToAdd` parameter. You can't use `all` as a value for that parameter in this case.
 *
 * To view which Amazon Web Services accounts have access to copy or restore a manual DB cluster snapshot, or whether a manual DB cluster snapshot is public or private, use the DescribeDBClusterSnapshotAttributes API operation. The accounts are returned as values for the `restore` attribute.
 */
export declare const modifyDBClusterSnapshotAttribute: API.OperationMethod<ModifyDBClusterSnapshotAttributeMessage, ModifyDBClusterSnapshotAttributeResult, ModifyDBClusterSnapshotAttributeError, Credentials | HttpClient.HttpClient>;
export type ModifyDBInstanceError = AuthorizationNotFoundFault | BackupPolicyNotFoundFault | CertificateNotFoundFault | DBInstanceAlreadyExistsFault | DBInstanceNotFoundFault | DBParameterGroupNotFoundFault | DBSecurityGroupNotFoundFault | DBUpgradeDependencyFailureFault | DomainNotFoundFault | InsufficientDBInstanceCapacityFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidDBSecurityGroupStateFault | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | OptionGroupNotFoundFault | ProvisionedIopsNotAvailableInAZFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | TenantDatabaseQuotaExceededFault | VpcEncryptionControlViolationException | InvalidParameterCombination | InvalidParameterValue | CommonErrors;
/**
 * Modifies settings for a DB instance. You can change one or more database configuration parameters by specifying these parameters and the new values in the request. To learn what modifications you can make to your DB instance, call `DescribeValidDBInstanceModifications` before you call `ModifyDBInstance`.
 */
export declare const modifyDBInstance: API.OperationMethod<ModifyDBInstanceMessage, ModifyDBInstanceResult, ModifyDBInstanceError, Credentials | HttpClient.HttpClient>;
export type ModifyDBParameterGroupError = DBParameterGroupNotFoundFault | InvalidDBParameterGroupStateFault | CommonErrors;
/**
 * Modifies the parameters of a DB parameter group. To modify more than one parameter, submit a list of the following: `ParameterName`, `ParameterValue`, and `ApplyMethod`. A maximum of 20 parameters can be modified in a single request.
 *
 * After you modify a DB parameter group, you should wait at least 5 minutes before creating your first DB instance that uses that DB parameter group as the default parameter group. This allows Amazon RDS to fully complete the modify operation before the parameter group is used as the default for a new DB instance. This is especially important for parameters that are critical when creating the default database for a DB instance, such as the character set for the default database defined by the `character_set_database` parameter. You can use the *Parameter Groups* option of the Amazon RDS console or the *DescribeDBParameters* command to verify that your DB parameter group has been created or modified.
 */
export declare const modifyDBParameterGroup: API.OperationMethod<ModifyDBParameterGroupMessage, DBParameterGroupNameMessage, ModifyDBParameterGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyDBProxyError = DBProxyAlreadyExistsFault | DBProxyNotFoundFault | InvalidDBProxyStateFault | CommonErrors;
/**
 * Changes the settings for an existing DB proxy.
 */
export declare const modifyDBProxy: API.OperationMethod<ModifyDBProxyRequest, ModifyDBProxyResponse, ModifyDBProxyError, Credentials | HttpClient.HttpClient>;
export type ModifyDBProxyEndpointError = DBProxyEndpointAlreadyExistsFault | DBProxyEndpointNotFoundFault | InvalidDBProxyEndpointStateFault | InvalidDBProxyStateFault | CommonErrors;
/**
 * Changes the settings for an existing DB proxy endpoint.
 */
export declare const modifyDBProxyEndpoint: API.OperationMethod<ModifyDBProxyEndpointRequest, ModifyDBProxyEndpointResponse, ModifyDBProxyEndpointError, Credentials | HttpClient.HttpClient>;
export type ModifyDBProxyTargetGroupError = DBProxyNotFoundFault | DBProxyTargetGroupNotFoundFault | InvalidDBProxyStateFault | CommonErrors;
/**
 * Modifies the properties of a `DBProxyTargetGroup`.
 */
export declare const modifyDBProxyTargetGroup: API.OperationMethod<ModifyDBProxyTargetGroupRequest, ModifyDBProxyTargetGroupResponse, ModifyDBProxyTargetGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyDBRecommendationError = CommonErrors;
/**
 * Updates the recommendation status and recommended action status for the specified recommendation.
 */
export declare const modifyDBRecommendation: API.OperationMethod<ModifyDBRecommendationMessage, DBRecommendationMessage, ModifyDBRecommendationError, Credentials | HttpClient.HttpClient>;
export type ModifyDBShardGroupError = DBShardGroupAlreadyExistsFault | DBShardGroupNotFoundFault | InvalidDBClusterStateFault | CommonErrors;
/**
 * Modifies the settings of an Aurora Limitless Database DB shard group. You can change one or more settings by specifying these parameters and the new values in the request.
 */
export declare const modifyDBShardGroup: API.OperationMethod<ModifyDBShardGroupMessage, DBShardGroup, ModifyDBShardGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyDBSnapshotError = DBSnapshotNotFoundFault | InvalidDBSnapshotStateFault | KMSKeyNotAccessibleFault | CommonErrors;
/**
 * Updates a manual DB snapshot with a new engine version. The snapshot can be encrypted or unencrypted, but not shared or public.
 *
 * Amazon RDS supports upgrading DB snapshots for MariaDB, MySQL, PostgreSQL, and Oracle. This operation doesn't apply to RDS Custom or RDS for Db2.
 */
export declare const modifyDBSnapshot: API.OperationMethod<ModifyDBSnapshotMessage, ModifyDBSnapshotResult, ModifyDBSnapshotError, Credentials | HttpClient.HttpClient>;
export type ModifyDBSnapshotAttributeError = DBSnapshotNotFoundFault | InvalidDBSnapshotStateFault | SharedSnapshotQuotaExceededFault | CommonErrors;
/**
 * Adds an attribute and values to, or removes an attribute and values from, a manual DB snapshot.
 *
 * To share a manual DB snapshot with other Amazon Web Services accounts, specify `restore` as the `AttributeName` and use the `ValuesToAdd` parameter to add a list of IDs of the Amazon Web Services accounts that are authorized to restore the manual DB snapshot. Uses the value `all` to make the manual DB snapshot public, which means it can be copied or restored by all Amazon Web Services accounts.
 *
 * Don't add the `all` value for any manual DB snapshots that contain private information that you don't want available to all Amazon Web Services accounts.
 *
 * If the manual DB snapshot is encrypted, it can be shared, but only by specifying a list of authorized Amazon Web Services account IDs for the `ValuesToAdd` parameter. You can't use `all` as a value for that parameter in this case.
 *
 * To view which Amazon Web Services accounts have access to copy or restore a manual DB snapshot, or whether a manual DB snapshot public or private, use the DescribeDBSnapshotAttributes API operation. The accounts are returned as values for the `restore` attribute.
 */
export declare const modifyDBSnapshotAttribute: API.OperationMethod<ModifyDBSnapshotAttributeMessage, ModifyDBSnapshotAttributeResult, ModifyDBSnapshotAttributeError, Credentials | HttpClient.HttpClient>;
export type ModifyDBSubnetGroupError = DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | DBSubnetQuotaExceededFault | InvalidDBSubnetGroupStateFault | InvalidSubnet | SubnetAlreadyInUse | CommonErrors;
/**
 * Modifies an existing DB subnet group. DB subnet groups must contain at least one subnet in at least two AZs in the Amazon Web Services Region.
 */
export declare const modifyDBSubnetGroup: API.OperationMethod<ModifyDBSubnetGroupMessage, ModifyDBSubnetGroupResult, ModifyDBSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyEventSubscriptionError = EventSubscriptionQuotaExceededFault | SNSInvalidTopicFault | SNSNoAuthorizationFault | SNSTopicArnNotFoundFault | SubscriptionCategoryNotFoundFault | SubscriptionNotFoundFault | CommonErrors;
/**
 * Modifies an existing RDS event notification subscription. You can't modify the source identifiers using this call. To change source identifiers for a subscription, use the `AddSourceIdentifierToSubscription` and `RemoveSourceIdentifierFromSubscription` calls.
 *
 * You can see a list of the event categories for a given source type (`SourceType`) in Events in the *Amazon RDS User Guide* or by using the `DescribeEventCategories` operation.
 */
export declare const modifyEventSubscription: API.OperationMethod<ModifyEventSubscriptionMessage, ModifyEventSubscriptionResult, ModifyEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type ModifyGlobalClusterError = GlobalClusterAlreadyExistsFault | GlobalClusterNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidGlobalClusterStateFault | CommonErrors;
/**
 * Modifies a setting for an Amazon Aurora global database cluster. You can change one or more database configuration parameters by specifying these parameters and the new values in the request. For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * This operation only applies to Aurora global database clusters.
 */
export declare const modifyGlobalCluster: API.OperationMethod<ModifyGlobalClusterMessage, ModifyGlobalClusterResult, ModifyGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type ModifyIntegrationError = IntegrationConflictOperationFault | IntegrationNotFoundFault | InvalidIntegrationStateFault | CommonErrors;
/**
 * Modifies a zero-ETL integration with Amazon Redshift.
 */
export declare const modifyIntegration: API.OperationMethod<ModifyIntegrationMessage, Integration, ModifyIntegrationError, Credentials | HttpClient.HttpClient>;
export type ModifyOptionGroupError = InvalidOptionGroupStateFault | OptionGroupNotFoundFault | CommonErrors;
/**
 * Modifies an existing option group.
 */
export declare const modifyOptionGroup: API.OperationMethod<ModifyOptionGroupMessage, ModifyOptionGroupResult, ModifyOptionGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyTenantDatabaseError = DBInstanceNotFoundFault | InvalidDBInstanceStateFault | KMSKeyNotAccessibleFault | TenantDatabaseAlreadyExistsFault | TenantDatabaseNotFoundFault | CommonErrors;
/**
 * Modifies an existing tenant database in a DB instance. You can change the tenant database name or the master user password. This operation is supported only for RDS for Oracle CDB instances using the multi-tenant configuration.
 */
export declare const modifyTenantDatabase: API.OperationMethod<ModifyTenantDatabaseMessage, ModifyTenantDatabaseResult, ModifyTenantDatabaseError, Credentials | HttpClient.HttpClient>;
export type PromoteReadReplicaError = DBInstanceNotFoundFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Promotes a read replica DB instance to a standalone DB instance.
 *
 * - Backup duration is a function of the amount of changes to the database since the previous backup. If you plan to promote a read replica to a standalone instance, we recommend that you enable backups and complete at least one backup prior to promotion. In addition, a read replica cannot be promoted to a standalone instance when it is in the `backing-up` status. If you have enabled backups on your read replica, configure the automated backup window so that daily backups do not interfere with read replica promotion.
 *
 * - This command doesn't apply to Aurora MySQL, Aurora PostgreSQL, or RDS Custom.
 */
export declare const promoteReadReplica: API.OperationMethod<PromoteReadReplicaMessage, PromoteReadReplicaResult, PromoteReadReplicaError, Credentials | HttpClient.HttpClient>;
export type PromoteReadReplicaDBClusterError = DBClusterNotFoundFault | InvalidDBClusterStateFault | CommonErrors;
/**
 * Promotes a read replica DB cluster to a standalone DB cluster.
 */
export declare const promoteReadReplicaDBCluster: API.OperationMethod<PromoteReadReplicaDBClusterMessage, PromoteReadReplicaDBClusterResult, PromoteReadReplicaDBClusterError, Credentials | HttpClient.HttpClient>;
export type PurchaseReservedDBInstancesOfferingError = ReservedDBInstanceAlreadyExistsFault | ReservedDBInstanceQuotaExceededFault | ReservedDBInstancesOfferingNotFoundFault | CommonErrors;
/**
 * Purchases a reserved DB instance offering.
 */
export declare const purchaseReservedDBInstancesOffering: API.OperationMethod<PurchaseReservedDBInstancesOfferingMessage, PurchaseReservedDBInstancesOfferingResult, PurchaseReservedDBInstancesOfferingError, Credentials | HttpClient.HttpClient>;
export type RebootDBClusterError = DBClusterNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * You might need to reboot your DB cluster, usually for maintenance reasons. For example, if you make certain modifications, or if you change the DB cluster parameter group associated with the DB cluster, reboot the DB cluster for the changes to take effect.
 *
 * Rebooting a DB cluster restarts the database engine service. Rebooting a DB cluster results in a momentary outage, during which the DB cluster status is set to rebooting.
 *
 * Use this operation only for a non-Aurora Multi-AZ DB cluster.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide.*
 */
export declare const rebootDBCluster: API.OperationMethod<RebootDBClusterMessage, RebootDBClusterResult, RebootDBClusterError, Credentials | HttpClient.HttpClient>;
export type RebootDBInstanceError = DBInstanceNotFoundFault | InvalidDBInstanceStateFault | KMSKeyNotAccessibleFault | CommonErrors;
/**
 * You might need to reboot your DB instance, usually for maintenance reasons. For example, if you make certain modifications, or if you change the DB parameter group associated with the DB instance, you must reboot the instance for the changes to take effect.
 *
 * Rebooting a DB instance restarts the database engine service. Rebooting a DB instance results in a momentary outage, during which the DB instance status is set to rebooting.
 *
 * For more information about rebooting, see Rebooting a DB Instance in the *Amazon RDS User Guide.*
 *
 * This command doesn't apply to RDS Custom.
 *
 * If your DB instance is part of a Multi-AZ DB cluster, you can reboot the DB cluster with the `RebootDBCluster` operation.
 */
export declare const rebootDBInstance: API.OperationMethod<RebootDBInstanceMessage, RebootDBInstanceResult, RebootDBInstanceError, Credentials | HttpClient.HttpClient>;
export type RebootDBShardGroupError = DBShardGroupNotFoundFault | InvalidDBShardGroupStateFault | CommonErrors;
/**
 * You might need to reboot your DB shard group, usually for maintenance reasons. For example, if you make certain modifications, reboot the DB shard group for the changes to take effect.
 *
 * This operation applies only to Aurora Limitless Database DBb shard groups.
 */
export declare const rebootDBShardGroup: API.OperationMethod<RebootDBShardGroupMessage, DBShardGroup, RebootDBShardGroupError, Credentials | HttpClient.HttpClient>;
export type RegisterDBProxyTargetsError = DBClusterNotFoundFault | DBInstanceNotFoundFault | DBProxyNotFoundFault | DBProxyTargetAlreadyRegisteredFault | DBProxyTargetGroupNotFoundFault | InsufficientAvailableIPsInSubnetFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidDBProxyStateFault | CommonErrors;
/**
 * Associate one or more `DBProxyTarget` data structures with a `DBProxyTargetGroup`.
 */
export declare const registerDBProxyTargets: API.OperationMethod<RegisterDBProxyTargetsRequest, RegisterDBProxyTargetsResponse, RegisterDBProxyTargetsError, Credentials | HttpClient.HttpClient>;
export type RemoveFromGlobalClusterError = DBClusterNotFoundFault | GlobalClusterNotFoundFault | InvalidDBClusterStateFault | InvalidGlobalClusterStateFault | CommonErrors;
/**
 * Detaches an Aurora secondary cluster from an Aurora global database cluster. The cluster becomes a standalone cluster with read-write capability instead of being read-only and receiving data from a primary cluster in a different Region.
 *
 * This operation only applies to Aurora DB clusters.
 */
export declare const removeFromGlobalCluster: API.OperationMethod<RemoveFromGlobalClusterMessage, RemoveFromGlobalClusterResult, RemoveFromGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type RemoveRoleFromDBClusterError = DBClusterNotFoundFault | DBClusterRoleNotFoundFault | InvalidDBClusterStateFault | CommonErrors;
/**
 * Removes the asssociation of an Amazon Web Services Identity and Access Management (IAM) role from a DB cluster.
 *
 * For more information on Amazon Aurora DB clusters, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide.*
 */
export declare const removeRoleFromDBCluster: API.OperationMethod<RemoveRoleFromDBClusterMessage, RemoveRoleFromDBClusterResponse, RemoveRoleFromDBClusterError, Credentials | HttpClient.HttpClient>;
export type RemoveRoleFromDBInstanceError = DBInstanceNotFoundFault | DBInstanceRoleNotFoundFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Disassociates an Amazon Web Services Identity and Access Management (IAM) role from a DB instance.
 */
export declare const removeRoleFromDBInstance: API.OperationMethod<RemoveRoleFromDBInstanceMessage, RemoveRoleFromDBInstanceResponse, RemoveRoleFromDBInstanceError, Credentials | HttpClient.HttpClient>;
export type RemoveSourceIdentifierFromSubscriptionError = SourceNotFoundFault | SubscriptionNotFoundFault | CommonErrors;
/**
 * Removes a source identifier from an existing RDS event notification subscription.
 */
export declare const removeSourceIdentifierFromSubscription: API.OperationMethod<RemoveSourceIdentifierFromSubscriptionMessage, RemoveSourceIdentifierFromSubscriptionResult, RemoveSourceIdentifierFromSubscriptionError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsFromResourceError = BlueGreenDeploymentNotFoundFault | DBClusterNotFoundFault | DBInstanceNotFoundFault | DBProxyEndpointNotFoundFault | DBProxyNotFoundFault | DBProxyTargetGroupNotFoundFault | DBShardGroupNotFoundFault | DBSnapshotNotFoundFault | DBSnapshotTenantDatabaseNotFoundFault | IntegrationNotFoundFault | InvalidDBClusterEndpointStateFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | TenantDatabaseNotFoundFault | CommonErrors;
/**
 * Removes metadata tags from an Amazon RDS resource.
 *
 * For an overview on tagging an Amazon RDS resource, see Tagging Amazon RDS Resources in the *Amazon RDS User Guide* or Tagging Amazon Aurora and Amazon RDS Resources in the *Amazon Aurora User Guide*.
 */
export declare const removeTagsFromResource: API.OperationMethod<RemoveTagsFromResourceMessage, RemoveTagsFromResourceResponse, RemoveTagsFromResourceError, Credentials | HttpClient.HttpClient>;
export type ResetDBClusterParameterGroupError = DBParameterGroupNotFoundFault | InvalidDBParameterGroupStateFault | CommonErrors;
/**
 * Modifies the parameters of a DB cluster parameter group to the default value. To reset specific parameters submit a list of the following: `ParameterName` and `ApplyMethod`. To reset the entire DB cluster parameter group, specify the `DBClusterParameterGroupName` and `ResetAllParameters` parameters.
 *
 * When resetting the entire group, dynamic parameters are updated immediately and static parameters are set to `pending-reboot` to take effect on the next DB instance restart or `RebootDBInstance` request. You must call `RebootDBInstance` for every DB instance in your DB cluster that you want the updated static parameter to apply to.
 *
 * For more information on Amazon Aurora DB clusters, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide.*
 */
export declare const resetDBClusterParameterGroup: API.OperationMethod<ResetDBClusterParameterGroupMessage, DBClusterParameterGroupNameMessage, ResetDBClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type ResetDBParameterGroupError = DBParameterGroupNotFoundFault | InvalidDBParameterGroupStateFault | CommonErrors;
/**
 * Modifies the parameters of a DB parameter group to the engine/system default value. To reset specific parameters, provide a list of the following: `ParameterName` and `ApplyMethod`. To reset the entire DB parameter group, specify the `DBParameterGroup` name and `ResetAllParameters` parameters. When resetting the entire group, dynamic parameters are updated immediately and static parameters are set to `pending-reboot` to take effect on the next DB instance restart or `RebootDBInstance` request.
 */
export declare const resetDBParameterGroup: API.OperationMethod<ResetDBParameterGroupMessage, DBParameterGroupNameMessage, ResetDBParameterGroupError, Credentials | HttpClient.HttpClient>;
export type RestoreDBClusterFromS3Error = DBClusterAlreadyExistsFault | DBClusterNotFoundFault | DBClusterParameterGroupNotFoundFault | DBClusterQuotaExceededFault | DBClusterRoleQuotaExceededFault | DBSubnetGroupNotFoundFault | DomainNotFoundFault | InsufficientStorageClusterCapacityFault | InvalidDBClusterStateFault | InvalidDBSubnetGroupStateFault | InvalidS3BucketFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | StorageQuotaExceededFault | StorageTypeNotSupportedFault | CommonErrors;
/**
 * Creates an Amazon Aurora DB cluster from MySQL data stored in an Amazon S3 bucket. Amazon RDS must be authorized to access the Amazon S3 bucket and the data must be created using the Percona XtraBackup utility as described in Migrating Data from MySQL by Using an Amazon S3 Bucket in the *Amazon Aurora User Guide*.
 *
 * This operation only restores the DB cluster, not the DB instances for that DB cluster. You must invoke the `CreateDBInstance` operation to create DB instances for the restored DB cluster, specifying the identifier of the restored DB cluster in `DBClusterIdentifier`. You can create DB instances only after the `RestoreDBClusterFromS3` operation has completed and the DB cluster is available.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * This operation only applies to Aurora DB clusters. The source DB engine must be MySQL.
 *
 * You can use the `AssociatedRoles` parameter to associate one or more Amazon Web Services Identity and Access Management (IAM) roles with the Aurora DB cluster when you restore it from Amazon S3.
 */
export declare const restoreDBClusterFromS3: API.OperationMethod<RestoreDBClusterFromS3Message, RestoreDBClusterFromS3Result, RestoreDBClusterFromS3Error, Credentials | HttpClient.HttpClient>;
export type RestoreDBClusterFromSnapshotError = DBClusterAlreadyExistsFault | DBClusterParameterGroupNotFoundFault | DBClusterQuotaExceededFault | DBClusterRoleQuotaExceededFault | DBClusterSnapshotNotFoundFault | DBSnapshotNotFoundFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | DomainNotFoundFault | InsufficientDBClusterCapacityFault | InsufficientDBInstanceCapacityFault | InsufficientStorageClusterCapacityFault | InvalidDBClusterSnapshotStateFault | InvalidDBInstanceStateFault | InvalidDBSnapshotStateFault | InvalidRestoreFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | OptionGroupNotFoundFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | VpcEncryptionControlViolationException | CommonErrors;
/**
 * Creates a new DB cluster from a DB snapshot or DB cluster snapshot.
 *
 * The target DB cluster is created from the source snapshot with a default configuration. If you don't specify a security group, the new DB cluster is associated with the default security group.
 *
 * You can use the `EnableVPCNetworking` and `EnableInternetAccessGateway` parameters together to restore an Aurora PostgreSQL cluster without VPC networking and with internet-based connectivity. These two parameters must always be specified together. Set `EnableVPCNetworking` to `false` to disable the VPC network interface (ENI) for the cluster. `EnableInternetAccessGateway` enables internet-based connectivity through an internet access gateway. IAM database authentication is required and must be enabled using `EnableIAMDatabaseAuthentication`. Once the cluster is restored, you need to modify the DB cluster to update `MasterUserAuthenticationType` to `iam-db-auth`.
 *
 * You can use the `AssociatedRoles` parameter to associate one or more Amazon Web Services Identity and Access Management (IAM) roles with an Aurora DB cluster when you restore it from a snapshot.
 *
 * This operation only restores the DB cluster, not the DB instances for that DB cluster. You must invoke the `CreateDBInstance` operation to create DB instances for the restored DB cluster, specifying the identifier of the restored DB cluster in `DBClusterIdentifier`. You can create DB instances only after the `RestoreDBClusterFromSnapshot` operation has completed and the DB cluster is available.
 *
 * For more information on Amazon Aurora DB clusters, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide.*
 */
export declare const restoreDBClusterFromSnapshot: API.OperationMethod<RestoreDBClusterFromSnapshotMessage, RestoreDBClusterFromSnapshotResult, RestoreDBClusterFromSnapshotError, Credentials | HttpClient.HttpClient>;
export type RestoreDBClusterToPointInTimeError = DBClusterAlreadyExistsFault | DBClusterAutomatedBackupNotFoundFault | DBClusterNotFoundFault | DBClusterParameterGroupNotFoundFault | DBClusterQuotaExceededFault | DBClusterRoleQuotaExceededFault | DBClusterSnapshotNotFoundFault | DBSubnetGroupNotFoundFault | DomainNotFoundFault | InsufficientDBClusterCapacityFault | InsufficientDBInstanceCapacityFault | InsufficientStorageClusterCapacityFault | InvalidDBClusterSnapshotStateFault | InvalidDBClusterStateFault | InvalidDBSnapshotStateFault | InvalidRestoreFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | OptionGroupNotFoundFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | VpcEncryptionControlViolationException | CommonErrors;
/**
 * Restores a DB cluster to an arbitrary point in time. Users can restore to any point in time before `LatestRestorableTime` for up to `BackupRetentionPeriod` days. The target DB cluster is created from the source DB cluster with the same configuration as the original DB cluster, except that the new DB cluster is created with the default DB security group. Unless the `RestoreType` is set to `copy-on-write`, the restore may occur in a different Availability Zone (AZ) from the original DB cluster. The AZ where RDS restores the DB cluster depends on the AZs in the specified subnet group.
 *
 * You can use the `EnableVPCNetworking` and `EnableInternetAccessGateway` parameters together to restore an Aurora PostgreSQL cluster without VPC networking and with internet-based connectivity. These two parameters must always be specified together. Set `EnableVPCNetworking` to `false` to disable the VPC network interface (ENI) for the cluster. `EnableInternetAccessGateway` enables internet-based connectivity through an internet access gateway. IAM database authentication is required and must be enabled using `EnableIAMDatabaseAuthentication`. Once the cluster is restored, you need to modify the DB cluster to update `MasterUserAuthenticationType` to `iam-db-auth`.
 *
 * You can use the `AssociatedRoles` parameter to associate one or more Amazon Web Services Identity and Access Management (IAM) roles with an Aurora DB cluster when you restore it to a point in time.
 *
 * For Aurora, this operation only restores the DB cluster, not the DB instances for that DB cluster. You must invoke the `CreateDBInstance` operation to create DB instances for the restored DB cluster, specifying the identifier of the restored DB cluster in `DBClusterIdentifier`. You can create DB instances only after the `RestoreDBClusterToPointInTime` operation has completed and the DB cluster is available.
 *
 * For more information on Amazon Aurora DB clusters, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide.*
 */
export declare const restoreDBClusterToPointInTime: API.OperationMethod<RestoreDBClusterToPointInTimeMessage, RestoreDBClusterToPointInTimeResult, RestoreDBClusterToPointInTimeError, Credentials | HttpClient.HttpClient>;
export type RestoreDBInstanceFromDBSnapshotError = AuthorizationNotFoundFault | BackupPolicyNotFoundFault | CertificateNotFoundFault | DBClusterSnapshotNotFoundFault | DBInstanceAlreadyExistsFault | DBParameterGroupNotFoundFault | DBSecurityGroupNotFoundFault | DBSnapshotNotFoundFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | DomainNotFoundFault | InstanceQuotaExceededFault | InsufficientDBInstanceCapacityFault | InvalidDBSnapshotStateFault | InvalidRestoreFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | OptionGroupNotFoundFault | ProvisionedIopsNotAvailableInAZFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | TenantDatabaseQuotaExceededFault | VpcEncryptionControlViolationException | CommonErrors;
/**
 * Creates a new DB instance from a DB snapshot. The target database is created from the source database restore point with most of the source's original configuration, including the default security group and DB parameter group. By default, the new DB instance is created as a Single-AZ deployment, except when the instance is a SQL Server instance that has an option group associated with mirroring. In this case, the instance becomes a Multi-AZ deployment, not a Single-AZ deployment.
 *
 * If you want to replace your original DB instance with the new, restored DB instance, then rename your original DB instance before you call the `RestoreDBInstanceFromDBSnapshot` operation. RDS doesn't allow two DB instances with the same name. After you have renamed your original DB instance with a different identifier, then you can pass the original name of the DB instance as the `DBInstanceIdentifier` in the call to the `RestoreDBInstanceFromDBSnapshot` operation. The result is that you replace the original DB instance with the DB instance created from the snapshot.
 *
 * If you are restoring from a shared manual DB snapshot, the `DBSnapshotIdentifier` must be the ARN of the shared DB snapshot.
 *
 * To restore from a DB snapshot with an unsupported engine version, you must first upgrade the engine version of the snapshot. For more information about upgrading a RDS for MySQL DB snapshot engine version, see Upgrading a MySQL DB snapshot engine version. For more information about upgrading a RDS for PostgreSQL DB snapshot engine version, Upgrading a PostgreSQL DB snapshot engine version.
 *
 * This command doesn't apply to Aurora MySQL and Aurora PostgreSQL. For Aurora, use `RestoreDBClusterFromSnapshot`.
 */
export declare const restoreDBInstanceFromDBSnapshot: API.OperationMethod<RestoreDBInstanceFromDBSnapshotMessage, RestoreDBInstanceFromDBSnapshotResult, RestoreDBInstanceFromDBSnapshotError, Credentials | HttpClient.HttpClient>;
export type RestoreDBInstanceFromS3Error = AuthorizationNotFoundFault | BackupPolicyNotFoundFault | CertificateNotFoundFault | DBInstanceAlreadyExistsFault | DBParameterGroupNotFoundFault | DBSecurityGroupNotFoundFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | InstanceQuotaExceededFault | InsufficientDBInstanceCapacityFault | InvalidS3BucketFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | OptionGroupNotFoundFault | ProvisionedIopsNotAvailableInAZFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | VpcEncryptionControlViolationException | CommonErrors;
/**
 * Amazon Relational Database Service (Amazon RDS) supports importing MySQL databases by using backup files. You can create a backup of your on-premises database, store it on Amazon Simple Storage Service (Amazon S3), and then restore the backup file onto a new Amazon RDS DB instance running MySQL. For more information, see Restoring a backup into an Amazon RDS for MySQL DB instance in the *Amazon RDS User Guide.*
 *
 * This operation doesn't apply to RDS Custom.
 */
export declare const restoreDBInstanceFromS3: API.OperationMethod<RestoreDBInstanceFromS3Message, RestoreDBInstanceFromS3Result, RestoreDBInstanceFromS3Error, Credentials | HttpClient.HttpClient>;
export type RestoreDBInstanceToPointInTimeError = AuthorizationNotFoundFault | BackupPolicyNotFoundFault | CertificateNotFoundFault | DBInstanceAlreadyExistsFault | DBInstanceAutomatedBackupNotFoundFault | DBInstanceNotFoundFault | DBParameterGroupNotFoundFault | DBSecurityGroupNotFoundFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | DomainNotFoundFault | InstanceQuotaExceededFault | InsufficientDBInstanceCapacityFault | InvalidDBInstanceStateFault | InvalidRestoreFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | OptionGroupNotFoundFault | PointInTimeRestoreNotEnabledFault | ProvisionedIopsNotAvailableInAZFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | TenantDatabaseQuotaExceededFault | VpcEncryptionControlViolationException | CommonErrors;
/**
 * Restores a DB instance to an arbitrary point in time. You can restore to any point in time before the time identified by the `LatestRestorableTime` property. You can restore to a point up to the number of days specified by the `BackupRetentionPeriod` property.
 *
 * The target database is created with most of the original configuration, but in a system-selected Availability Zone, with the default security group, the default subnet group, and the default DB parameter group. By default, the new DB instance is created as a single-AZ deployment except when the instance is a SQL Server instance that has an option group that is associated with mirroring; in this case, the instance becomes a mirrored deployment and not a single-AZ deployment.
 *
 * This operation doesn't apply to Aurora MySQL and Aurora PostgreSQL. For Aurora, use `RestoreDBClusterToPointInTime`.
 */
export declare const restoreDBInstanceToPointInTime: API.OperationMethod<RestoreDBInstanceToPointInTimeMessage, RestoreDBInstanceToPointInTimeResult, RestoreDBInstanceToPointInTimeError, Credentials | HttpClient.HttpClient>;
export type RevokeDBSecurityGroupIngressError = AuthorizationNotFoundFault | DBSecurityGroupNotFoundFault | InvalidDBSecurityGroupStateFault | CommonErrors;
/**
 * Revokes ingress from a DBSecurityGroup for previously authorized IP ranges or EC2 or VPC security groups. Required parameters for this API are one of CIDRIP, EC2SecurityGroupId for VPC, or (EC2SecurityGroupOwnerId and either EC2SecurityGroupName or EC2SecurityGroupId).
 *
 * EC2-Classic was retired on August 15, 2022. If you haven't migrated from EC2-Classic to a VPC, we recommend that you migrate as soon as possible. For more information, see Migrate from EC2-Classic to a VPC in the *Amazon EC2 User Guide*, the blog EC2-Classic Networking is Retiring - Here's How to Prepare, and Moving a DB instance not in a VPC into a VPC in the *Amazon RDS User Guide*.
 */
export declare const revokeDBSecurityGroupIngress: API.OperationMethod<RevokeDBSecurityGroupIngressMessage, RevokeDBSecurityGroupIngressResult, RevokeDBSecurityGroupIngressError, Credentials | HttpClient.HttpClient>;
export type StartActivityStreamError = DBClusterNotFoundFault | DBInstanceNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | KMSKeyNotAccessibleFault | ResourceNotFoundFault | CommonErrors;
/**
 * Starts a database activity stream to monitor activity on the database. For more information, see Monitoring Amazon Aurora with Database Activity Streams in the *Amazon Aurora User Guide* or Monitoring Amazon RDS with Database Activity Streams in the *Amazon RDS User Guide*.
 */
export declare const startActivityStream: API.OperationMethod<StartActivityStreamRequest, StartActivityStreamResponse, StartActivityStreamError, Credentials | HttpClient.HttpClient>;
export type StartDBClusterError = DBClusterNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidDBShardGroupStateFault | KMSKeyNotAccessibleFault | VpcEncryptionControlViolationException | CommonErrors;
/**
 * Starts an Amazon Aurora DB cluster that was stopped using the Amazon Web Services console, the stop-db-cluster CLI command, or the `StopDBCluster` operation.
 *
 * For more information, see Stopping and Starting an Aurora Cluster in the *Amazon Aurora User Guide*.
 *
 * This operation only applies to Aurora DB clusters.
 */
export declare const startDBCluster: API.OperationMethod<StartDBClusterMessage, StartDBClusterResult, StartDBClusterError, Credentials | HttpClient.HttpClient>;
export type StartDBInstanceError = AuthorizationNotFoundFault | DBClusterNotFoundFault | DBInstanceNotFoundFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | InsufficientDBInstanceCapacityFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | VpcEncryptionControlViolationException | CommonErrors;
/**
 * Starts an Amazon RDS DB instance that was stopped using the Amazon Web Services console, the stop-db-instance CLI command, or the `StopDBInstance` operation.
 *
 * For more information, see Starting an Amazon RDS DB instance That Was Previously Stopped in the *Amazon RDS User Guide.*
 *
 * This command doesn't apply to RDS Custom, Aurora MySQL, and Aurora PostgreSQL. For Aurora DB clusters, use `StartDBCluster` instead.
 */
export declare const startDBInstance: API.OperationMethod<StartDBInstanceMessage, StartDBInstanceResult, StartDBInstanceError, Credentials | HttpClient.HttpClient>;
export type StartDBInstanceAutomatedBackupsReplicationError = DBInstanceAutomatedBackupQuotaExceededFault | DBInstanceNotFoundFault | InvalidDBInstanceAutomatedBackupStateFault | InvalidDBInstanceStateFault | KMSKeyNotAccessibleFault | StorageTypeNotSupportedFault | CommonErrors;
/**
 * Enables replication of automated backups to a different Amazon Web Services Region.
 *
 * This command doesn't apply to RDS Custom.
 *
 * For more information, see Replicating Automated Backups to Another Amazon Web Services Region in the *Amazon RDS User Guide.*
 */
export declare const startDBInstanceAutomatedBackupsReplication: API.OperationMethod<StartDBInstanceAutomatedBackupsReplicationMessage, StartDBInstanceAutomatedBackupsReplicationResult, StartDBInstanceAutomatedBackupsReplicationError, Credentials | HttpClient.HttpClient>;
export type StartExportTaskError = DBClusterNotFoundFault | DBClusterSnapshotNotFoundFault | DBSnapshotNotFoundFault | ExportTaskAlreadyExistsFault | IamRoleMissingPermissionsFault | IamRoleNotFoundFault | InvalidExportOnlyFault | InvalidExportSourceStateFault | InvalidS3BucketFault | KMSKeyNotAccessibleFault | CommonErrors;
/**
 * Starts an export of DB snapshot or DB cluster data to Amazon S3. The provided IAM role must have access to the S3 bucket.
 *
 * You can't export snapshot data from RDS Custom DB instances. For more information, see Supported Regions and DB engines for exporting snapshots to S3 in Amazon RDS.
 *
 * For more information on exporting DB snapshot data, see Exporting DB snapshot data to Amazon S3 in the *Amazon RDS User Guide* or Exporting DB cluster snapshot data to Amazon S3 in the *Amazon Aurora User Guide*.
 *
 * For more information on exporting DB cluster data, see Exporting DB cluster data to Amazon S3 in the *Amazon Aurora User Guide*.
 */
export declare const startExportTask: API.OperationMethod<StartExportTaskMessage, ExportTask, StartExportTaskError, Credentials | HttpClient.HttpClient>;
export type StopActivityStreamError = DBClusterNotFoundFault | DBInstanceNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Stops a database activity stream that was started using the Amazon Web Services console, the `start-activity-stream` CLI command, or the `StartActivityStream` operation.
 *
 * For more information, see Monitoring Amazon Aurora with Database Activity Streams in the *Amazon Aurora User Guide* or Monitoring Amazon RDS with Database Activity Streams in the *Amazon RDS User Guide*.
 */
export declare const stopActivityStream: API.OperationMethod<StopActivityStreamRequest, StopActivityStreamResponse, StopActivityStreamError, Credentials | HttpClient.HttpClient>;
export type StopDBClusterError = DBClusterNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidDBShardGroupStateFault | CommonErrors;
/**
 * Stops an Amazon Aurora DB cluster. When you stop a DB cluster, Aurora retains the DB cluster's metadata, including its endpoints and DB parameter groups. Aurora also retains the transaction logs so you can do a point-in-time restore if necessary.
 *
 * For more information, see Stopping and Starting an Aurora Cluster in the *Amazon Aurora User Guide*.
 *
 * This operation only applies to Aurora DB clusters.
 */
export declare const stopDBCluster: API.OperationMethod<StopDBClusterMessage, StopDBClusterResult, StopDBClusterError, Credentials | HttpClient.HttpClient>;
export type StopDBInstanceError = DBInstanceNotFoundFault | DBSnapshotAlreadyExistsFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Stops an Amazon RDS DB instance temporarily. When you stop a DB instance, Amazon RDS retains the DB instance's metadata, including its endpoint, DB parameter group, and option group membership. Amazon RDS also retains the transaction logs so you can do a point-in-time restore if necessary. The instance restarts automatically after 7 days.
 *
 * For more information, see Stopping an Amazon RDS DB Instance Temporarily in the *Amazon RDS User Guide.*
 *
 * This command doesn't apply to RDS Custom, Aurora MySQL, and Aurora PostgreSQL. For Aurora clusters, use `StopDBCluster` instead.
 */
export declare const stopDBInstance: API.OperationMethod<StopDBInstanceMessage, StopDBInstanceResult, StopDBInstanceError, Credentials | HttpClient.HttpClient>;
export type StopDBInstanceAutomatedBackupsReplicationError = DBInstanceNotFoundFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Stops automated backup replication for a DB instance.
 *
 * This command doesn't apply to RDS Custom, Aurora MySQL, and Aurora PostgreSQL.
 *
 * For more information, see Replicating Automated Backups to Another Amazon Web Services Region in the *Amazon RDS User Guide.*
 */
export declare const stopDBInstanceAutomatedBackupsReplication: API.OperationMethod<StopDBInstanceAutomatedBackupsReplicationMessage, StopDBInstanceAutomatedBackupsReplicationResult, StopDBInstanceAutomatedBackupsReplicationError, Credentials | HttpClient.HttpClient>;
export type SwitchoverBlueGreenDeploymentError = BlueGreenDeploymentNotFoundFault | InvalidBlueGreenDeploymentStateFault | CommonErrors;
/**
 * Switches over a blue/green deployment.
 *
 * Before you switch over, production traffic is routed to the databases in the blue environment. After you switch over, production traffic is routed to the databases in the green environment.
 *
 * For more information, see Using Amazon RDS Blue/Green Deployments for database updates in the *Amazon RDS User Guide* and Using Amazon RDS Blue/Green Deployments for database updates in the *Amazon Aurora User Guide*.
 */
export declare const switchoverBlueGreenDeployment: API.OperationMethod<SwitchoverBlueGreenDeploymentRequest, SwitchoverBlueGreenDeploymentResponse, SwitchoverBlueGreenDeploymentError, Credentials | HttpClient.HttpClient>;
export type SwitchoverGlobalClusterError = DBClusterNotFoundFault | GlobalClusterNotFoundFault | InvalidDBClusterStateFault | InvalidGlobalClusterStateFault | CommonErrors;
/**
 * Switches over the specified secondary DB cluster to be the new primary DB cluster in the global database cluster. Switchover operations were previously called "managed planned failovers."
 *
 * Aurora promotes the specified secondary cluster to assume full read/write capabilities and demotes the current primary cluster to a secondary (read-only) cluster, maintaining the orginal replication topology. All secondary clusters are synchronized with the primary at the beginning of the process so the new primary continues operations for the Aurora global database without losing any data. Your database is unavailable for a short time while the primary and selected secondary clusters are assuming their new roles. For more information about switching over an Aurora global database, see Performing switchovers for Amazon Aurora global databases in the *Amazon Aurora User Guide*.
 *
 * This operation is intended for controlled environments, for operations such as "regional rotation" or to fall back to the original primary after a global database failover.
 */
export declare const switchoverGlobalCluster: API.OperationMethod<SwitchoverGlobalClusterMessage, SwitchoverGlobalClusterResult, SwitchoverGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type SwitchoverReadReplicaError = DBInstanceNotFoundFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Switches over an Oracle standby database in an Oracle Data Guard environment, making it the new primary database. Issue this command in the Region that hosts the current standby database.
 */
export declare const switchoverReadReplica: API.OperationMethod<SwitchoverReadReplicaMessage, SwitchoverReadReplicaResult, SwitchoverReadReplicaError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=rds.d.ts.map