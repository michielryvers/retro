import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InternalServiceErrorException_base: S.TaggedErrorClass<"InternalServiceErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServiceErrorException extends /*@__PURE__*/ InternalServiceErrorException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const InvalidStateException_base: S.TaggedErrorClass<"InvalidStateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidStateException extends /*@__PURE__*/ InvalidStateException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
export type AppRunnerResourceArn = string;
export type DomainName = string;
export interface AssociateCustomDomainRequest {
    ServiceArn: string;
    DomainName: string;
    EnableWWWSubdomain?: boolean;
}
export type CertificateValidationRecordStatus = "PENDING_VALIDATION" | "SUCCESS" | "FAILED" | (string & {});
export interface CertificateValidationRecord {
    Name?: string;
    Type?: string;
    Value?: string;
    Status?: CertificateValidationRecordStatus;
}
export type CertificateValidationRecordList = CertificateValidationRecord[];
export type CustomDomainAssociationStatus = "CREATING" | "CREATE_FAILED" | "ACTIVE" | "DELETING" | "DELETE_FAILED" | "PENDING_CERTIFICATE_DNS_VALIDATION" | "BINDING_CERTIFICATE" | (string & {});
export interface CustomDomain {
    DomainName: string;
    EnableWWWSubdomain: boolean;
    CertificateValidationRecords?: CertificateValidationRecord[];
    Status: CustomDomainAssociationStatus;
}
export interface VpcDNSTarget {
    VpcIngressConnectionArn?: string;
    VpcId?: string;
    DomainName?: string;
}
export type VpcDNSTargetList = VpcDNSTarget[];
export interface AssociateCustomDomainResponse {
    DNSTarget: string;
    ServiceArn: string;
    CustomDomain: CustomDomain;
    VpcDNSTargets: VpcDNSTarget[];
}
export type AutoScalingConfigurationName = string;
export type ASConfigMaxConcurrency = number;
export type ASConfigMinSize = number;
export type ASConfigMaxSize = number;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string;
    Value?: string;
}
export type TagList = Tag[];
export interface CreateAutoScalingConfigurationRequest {
    AutoScalingConfigurationName: string;
    MaxConcurrency?: number;
    MinSize?: number;
    MaxSize?: number;
    Tags?: Tag[];
}
export type AutoScalingConfigurationRevision = number;
export type Latest = boolean;
export type AutoScalingConfigurationStatus = "ACTIVE" | "INACTIVE" | "active" | "inactive" | (string & {});
export type MaxConcurrency = number;
export type MinSize = number;
export type MaxSize = number;
export type HasAssociatedService = boolean;
export type IsDefault = boolean;
export interface AutoScalingConfiguration {
    AutoScalingConfigurationArn?: string;
    AutoScalingConfigurationName?: string;
    AutoScalingConfigurationRevision?: number;
    Latest?: boolean;
    Status?: AutoScalingConfigurationStatus;
    MaxConcurrency?: number;
    MinSize?: number;
    MaxSize?: number;
    CreatedAt?: Date;
    DeletedAt?: Date;
    HasAssociatedService?: boolean;
    IsDefault?: boolean;
}
export interface CreateAutoScalingConfigurationResponse {
    AutoScalingConfiguration: AutoScalingConfiguration;
}
export type ConnectionName = string;
export type ProviderType = "GITHUB" | "BITBUCKET" | (string & {});
export interface CreateConnectionRequest {
    ConnectionName: string;
    ProviderType: ProviderType;
    Tags?: Tag[];
}
export type ConnectionStatus = "PENDING_HANDSHAKE" | "AVAILABLE" | "ERROR" | "DELETED" | (string & {});
export interface Connection {
    ConnectionName?: string;
    ConnectionArn?: string;
    ProviderType?: ProviderType;
    Status?: ConnectionStatus;
    CreatedAt?: Date;
}
export interface CreateConnectionResponse {
    Connection: Connection;
}
export type ObservabilityConfigurationName = string;
export type TracingVendor = "AWSXRAY" | (string & {});
export interface TraceConfiguration {
    Vendor: TracingVendor;
}
export interface CreateObservabilityConfigurationRequest {
    ObservabilityConfigurationName: string;
    TraceConfiguration?: TraceConfiguration;
    Tags?: Tag[];
}
export type ObservabilityConfigurationStatus = "ACTIVE" | "INACTIVE" | (string & {});
export interface ObservabilityConfiguration {
    ObservabilityConfigurationArn?: string;
    ObservabilityConfigurationName?: string;
    TraceConfiguration?: TraceConfiguration;
    ObservabilityConfigurationRevision?: number;
    Latest?: boolean;
    Status?: ObservabilityConfigurationStatus;
    CreatedAt?: Date;
    DeletedAt?: Date;
}
export interface CreateObservabilityConfigurationResponse {
    ObservabilityConfiguration: ObservabilityConfiguration;
}
export type ServiceName = string;
export type SourceCodeVersionType = "BRANCH" | (string & {});
export interface SourceCodeVersion {
    Type: SourceCodeVersionType;
    Value: string;
}
export type ConfigurationSource = "REPOSITORY" | "API" | (string & {});
export type Runtime = "PYTHON_3" | "NODEJS_12" | "NODEJS_14" | "CORRETTO_8" | "CORRETTO_11" | "NODEJS_16" | "GO_1" | "DOTNET_6" | "PHP_81" | "RUBY_31" | "PYTHON_311" | "NODEJS_18" | "NODEJS_22" | (string & {});
export type BuildCommand = string | redacted.Redacted<string>;
export type StartCommand = string | redacted.Redacted<string>;
export type RuntimeEnvironmentVariablesKey = string | redacted.Redacted<string>;
export type RuntimeEnvironmentVariablesValue = string | redacted.Redacted<string>;
export type RuntimeEnvironmentVariables = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export type RuntimeEnvironmentSecretsName = string | redacted.Redacted<string>;
export type RuntimeEnvironmentSecretsValue = string | redacted.Redacted<string>;
export type RuntimeEnvironmentSecrets = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export interface CodeConfigurationValues {
    Runtime: Runtime;
    BuildCommand?: string | redacted.Redacted<string>;
    StartCommand?: string | redacted.Redacted<string>;
    Port?: string;
    RuntimeEnvironmentVariables?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    RuntimeEnvironmentSecrets?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export interface CodeConfiguration {
    ConfigurationSource: ConfigurationSource;
    CodeConfigurationValues?: CodeConfigurationValues;
}
export type SourceDirectory = string;
export interface CodeRepository {
    RepositoryUrl: string;
    SourceCodeVersion: SourceCodeVersion;
    CodeConfiguration?: CodeConfiguration;
    SourceDirectory?: string;
}
export type ImageIdentifier = string;
export interface ImageConfiguration {
    RuntimeEnvironmentVariables?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    StartCommand?: string | redacted.Redacted<string>;
    Port?: string;
    RuntimeEnvironmentSecrets?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export type ImageRepositoryType = "ECR" | "ECR_PUBLIC" | (string & {});
export interface ImageRepository {
    ImageIdentifier: string;
    ImageConfiguration?: ImageConfiguration;
    ImageRepositoryType: ImageRepositoryType;
}
export type RoleArn = string;
export interface AuthenticationConfiguration {
    ConnectionArn?: string;
    AccessRoleArn?: string;
}
export interface SourceConfiguration {
    CodeRepository?: CodeRepository;
    ImageRepository?: ImageRepository;
    AutoDeploymentsEnabled?: boolean;
    AuthenticationConfiguration?: AuthenticationConfiguration;
}
export type Cpu = string;
export type Memory = string;
export interface InstanceConfiguration {
    Cpu?: string;
    Memory?: string;
    InstanceRoleArn?: string;
}
export type KmsKeyArn = string;
export interface EncryptionConfiguration {
    KmsKey: string;
}
export type HealthCheckProtocol = "TCP" | "HTTP" | (string & {});
export type HealthCheckPath = string;
export type HealthCheckInterval = number;
export type HealthCheckTimeout = number;
export type HealthCheckHealthyThreshold = number;
export type HealthCheckUnhealthyThreshold = number;
export interface HealthCheckConfiguration {
    Protocol?: HealthCheckProtocol;
    Path?: string;
    Interval?: number;
    Timeout?: number;
    HealthyThreshold?: number;
    UnhealthyThreshold?: number;
}
export type EgressType = "DEFAULT" | "VPC" | (string & {});
export interface EgressConfiguration {
    EgressType?: EgressType;
    VpcConnectorArn?: string;
}
export interface IngressConfiguration {
    IsPubliclyAccessible?: boolean;
}
export type IpAddressType = "IPV4" | "DUAL_STACK" | (string & {});
export interface NetworkConfiguration {
    EgressConfiguration?: EgressConfiguration;
    IngressConfiguration?: IngressConfiguration;
    IpAddressType?: IpAddressType;
}
export interface ServiceObservabilityConfiguration {
    ObservabilityEnabled: boolean;
    ObservabilityConfigurationArn?: string;
}
export interface CreateServiceRequest {
    ServiceName: string;
    SourceConfiguration: SourceConfiguration;
    InstanceConfiguration?: InstanceConfiguration;
    Tags?: Tag[];
    EncryptionConfiguration?: EncryptionConfiguration;
    HealthCheckConfiguration?: HealthCheckConfiguration;
    AutoScalingConfigurationArn?: string;
    NetworkConfiguration?: NetworkConfiguration;
    ObservabilityConfiguration?: ServiceObservabilityConfiguration;
}
export type ServiceId = string;
export type ServiceStatus = "CREATE_FAILED" | "RUNNING" | "DELETED" | "DELETE_FAILED" | "PAUSED" | "OPERATION_IN_PROGRESS" | (string & {});
export interface AutoScalingConfigurationSummary {
    AutoScalingConfigurationArn?: string;
    AutoScalingConfigurationName?: string;
    AutoScalingConfigurationRevision?: number;
    Status?: AutoScalingConfigurationStatus;
    CreatedAt?: Date;
    HasAssociatedService?: boolean;
    IsDefault?: boolean;
}
export interface Service {
    ServiceName: string;
    ServiceId: string;
    ServiceArn: string;
    ServiceUrl?: string;
    CreatedAt: Date;
    UpdatedAt: Date;
    DeletedAt?: Date;
    Status: ServiceStatus;
    SourceConfiguration: SourceConfiguration;
    InstanceConfiguration: InstanceConfiguration;
    EncryptionConfiguration?: EncryptionConfiguration;
    HealthCheckConfiguration?: HealthCheckConfiguration;
    AutoScalingConfigurationSummary: AutoScalingConfigurationSummary;
    NetworkConfiguration: NetworkConfiguration;
    ObservabilityConfiguration?: ServiceObservabilityConfiguration;
}
export type UUID = string;
export interface CreateServiceResponse {
    Service: Service;
    OperationId: string;
}
export type VpcConnectorName = string;
export type StringList = string[];
export interface CreateVpcConnectorRequest {
    VpcConnectorName: string;
    Subnets: string[];
    SecurityGroups?: string[];
    Tags?: Tag[];
}
export type VpcConnectorStatus = "ACTIVE" | "INACTIVE" | "active" | "inactive" | (string & {});
export interface VpcConnector {
    VpcConnectorName?: string;
    VpcConnectorArn?: string;
    VpcConnectorRevision?: number;
    Subnets?: string[];
    SecurityGroups?: string[];
    Status?: VpcConnectorStatus;
    CreatedAt?: Date;
    DeletedAt?: Date;
}
export interface CreateVpcConnectorResponse {
    VpcConnector: VpcConnector;
}
export type VpcIngressConnectionName = string;
export interface IngressVpcConfiguration {
    VpcId?: string;
    VpcEndpointId?: string;
}
export interface CreateVpcIngressConnectionRequest {
    ServiceArn: string;
    VpcIngressConnectionName: string;
    IngressVpcConfiguration: IngressVpcConfiguration;
    Tags?: Tag[];
}
export type VpcIngressConnectionStatus = "AVAILABLE" | "PENDING_CREATION" | "PENDING_UPDATE" | "PENDING_DELETION" | "FAILED_CREATION" | "FAILED_UPDATE" | "FAILED_DELETION" | "DELETED" | (string & {});
export type CustomerAccountId = string;
export interface VpcIngressConnection {
    VpcIngressConnectionArn?: string;
    VpcIngressConnectionName?: string;
    ServiceArn?: string;
    Status?: VpcIngressConnectionStatus;
    AccountId?: string;
    DomainName?: string;
    IngressVpcConfiguration?: IngressVpcConfiguration;
    CreatedAt?: Date;
    DeletedAt?: Date;
}
export interface CreateVpcIngressConnectionResponse {
    VpcIngressConnection: VpcIngressConnection;
}
export interface DeleteAutoScalingConfigurationRequest {
    AutoScalingConfigurationArn: string;
    DeleteAllRevisions?: boolean;
}
export interface DeleteAutoScalingConfigurationResponse {
    AutoScalingConfiguration: AutoScalingConfiguration;
}
export interface DeleteConnectionRequest {
    ConnectionArn: string;
}
export interface DeleteConnectionResponse {
    Connection?: Connection;
}
export interface DeleteObservabilityConfigurationRequest {
    ObservabilityConfigurationArn: string;
}
export interface DeleteObservabilityConfigurationResponse {
    ObservabilityConfiguration: ObservabilityConfiguration;
}
export interface DeleteServiceRequest {
    ServiceArn: string;
}
export interface DeleteServiceResponse {
    Service: Service;
    OperationId: string;
}
export interface DeleteVpcConnectorRequest {
    VpcConnectorArn: string;
}
export interface DeleteVpcConnectorResponse {
    VpcConnector: VpcConnector;
}
export interface DeleteVpcIngressConnectionRequest {
    VpcIngressConnectionArn: string;
}
export interface DeleteVpcIngressConnectionResponse {
    VpcIngressConnection: VpcIngressConnection;
}
export interface DescribeAutoScalingConfigurationRequest {
    AutoScalingConfigurationArn: string;
}
export interface DescribeAutoScalingConfigurationResponse {
    AutoScalingConfiguration: AutoScalingConfiguration;
}
export type DescribeCustomDomainsMaxResults = number;
export interface DescribeCustomDomainsRequest {
    ServiceArn: string;
    NextToken?: string;
    MaxResults?: number;
}
export type CustomDomainList = CustomDomain[];
export interface DescribeCustomDomainsResponse {
    DNSTarget: string;
    ServiceArn: string;
    CustomDomains: CustomDomain[];
    VpcDNSTargets: VpcDNSTarget[];
    NextToken?: string;
}
export interface DescribeObservabilityConfigurationRequest {
    ObservabilityConfigurationArn: string;
}
export interface DescribeObservabilityConfigurationResponse {
    ObservabilityConfiguration: ObservabilityConfiguration;
}
export interface DescribeServiceRequest {
    ServiceArn: string;
}
export interface DescribeServiceResponse {
    Service: Service;
}
export interface DescribeVpcConnectorRequest {
    VpcConnectorArn: string;
}
export interface DescribeVpcConnectorResponse {
    VpcConnector: VpcConnector;
}
export interface DescribeVpcIngressConnectionRequest {
    VpcIngressConnectionArn: string;
}
export interface DescribeVpcIngressConnectionResponse {
    VpcIngressConnection: VpcIngressConnection;
}
export interface DisassociateCustomDomainRequest {
    ServiceArn: string;
    DomainName: string;
}
export interface DisassociateCustomDomainResponse {
    DNSTarget: string;
    ServiceArn: string;
    CustomDomain: CustomDomain;
    VpcDNSTargets: VpcDNSTarget[];
}
export type MaxResults = number;
export type NextToken = string;
export interface ListAutoScalingConfigurationsRequest {
    AutoScalingConfigurationName?: string;
    LatestOnly?: boolean;
    MaxResults?: number;
    NextToken?: string;
}
export type AutoScalingConfigurationSummaryList = AutoScalingConfigurationSummary[];
export interface ListAutoScalingConfigurationsResponse {
    AutoScalingConfigurationSummaryList: AutoScalingConfigurationSummary[];
    NextToken?: string;
}
export interface ListConnectionsRequest {
    ConnectionName?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface ConnectionSummary {
    ConnectionName?: string;
    ConnectionArn?: string;
    ProviderType?: ProviderType;
    Status?: ConnectionStatus;
    CreatedAt?: Date;
}
export type ConnectionSummaryList = ConnectionSummary[];
export interface ListConnectionsResponse {
    ConnectionSummaryList: ConnectionSummary[];
    NextToken?: string;
}
export interface ListObservabilityConfigurationsRequest {
    ObservabilityConfigurationName?: string;
    LatestOnly?: boolean;
    MaxResults?: number;
    NextToken?: string;
}
export interface ObservabilityConfigurationSummary {
    ObservabilityConfigurationArn?: string;
    ObservabilityConfigurationName?: string;
    ObservabilityConfigurationRevision?: number;
}
export type ObservabilityConfigurationSummaryList = ObservabilityConfigurationSummary[];
export interface ListObservabilityConfigurationsResponse {
    ObservabilityConfigurationSummaryList: ObservabilityConfigurationSummary[];
    NextToken?: string;
}
export type ListOperationsMaxResults = number;
export interface ListOperationsRequest {
    ServiceArn: string;
    NextToken?: string;
    MaxResults?: number;
}
export type OperationType = "START_DEPLOYMENT" | "CREATE_SERVICE" | "PAUSE_SERVICE" | "RESUME_SERVICE" | "DELETE_SERVICE" | "UPDATE_SERVICE" | (string & {});
export type OperationStatus = "PENDING" | "IN_PROGRESS" | "FAILED" | "SUCCEEDED" | "ROLLBACK_IN_PROGRESS" | "ROLLBACK_FAILED" | "ROLLBACK_SUCCEEDED" | (string & {});
export interface OperationSummary {
    Id?: string;
    Type?: OperationType;
    Status?: OperationStatus;
    TargetArn?: string;
    StartedAt?: Date;
    EndedAt?: Date;
    UpdatedAt?: Date;
}
export type OperationSummaryList = OperationSummary[];
export interface ListOperationsResponse {
    OperationSummaryList?: OperationSummary[];
    NextToken?: string;
}
export type ServiceMaxResults = number;
export interface ListServicesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface ServiceSummary {
    ServiceName?: string;
    ServiceId?: string;
    ServiceArn?: string;
    ServiceUrl?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    Status?: ServiceStatus;
}
export type ServiceSummaryList = ServiceSummary[];
export interface ListServicesResponse {
    ServiceSummaryList: ServiceSummary[];
    NextToken?: string;
}
export interface ListServicesForAutoScalingConfigurationRequest {
    AutoScalingConfigurationArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export type ServiceArnList = string[];
export interface ListServicesForAutoScalingConfigurationResponse {
    ServiceArnList: string[];
    NextToken?: string;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export interface ListVpcConnectorsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export type VpcConnectors = VpcConnector[];
export interface ListVpcConnectorsResponse {
    VpcConnectors: VpcConnector[];
    NextToken?: string;
}
export interface ListVpcIngressConnectionsFilter {
    ServiceArn?: string;
    VpcEndpointId?: string;
}
export interface ListVpcIngressConnectionsRequest {
    Filter?: ListVpcIngressConnectionsFilter;
    MaxResults?: number;
    NextToken?: string;
}
export interface VpcIngressConnectionSummary {
    VpcIngressConnectionArn?: string;
    ServiceArn?: string;
}
export type VpcIngressConnectionSummaryList = VpcIngressConnectionSummary[];
export interface ListVpcIngressConnectionsResponse {
    VpcIngressConnectionSummaryList: VpcIngressConnectionSummary[];
    NextToken?: string;
}
export interface PauseServiceRequest {
    ServiceArn: string;
}
export interface PauseServiceResponse {
    Service: Service;
    OperationId?: string;
}
export interface ResumeServiceRequest {
    ServiceArn: string;
}
export interface ResumeServiceResponse {
    Service: Service;
    OperationId?: string;
}
export interface StartDeploymentRequest {
    ServiceArn: string;
}
export interface StartDeploymentResponse {
    OperationId: string;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateDefaultAutoScalingConfigurationRequest {
    AutoScalingConfigurationArn: string;
}
export interface UpdateDefaultAutoScalingConfigurationResponse {
    AutoScalingConfiguration: AutoScalingConfiguration;
}
export interface UpdateServiceRequest {
    ServiceArn: string;
    SourceConfiguration?: SourceConfiguration;
    InstanceConfiguration?: InstanceConfiguration;
    AutoScalingConfigurationArn?: string;
    HealthCheckConfiguration?: HealthCheckConfiguration;
    NetworkConfiguration?: NetworkConfiguration;
    ObservabilityConfiguration?: ServiceObservabilityConfiguration;
}
export interface UpdateServiceResponse {
    Service: Service;
    OperationId: string;
}
export interface UpdateVpcIngressConnectionRequest {
    VpcIngressConnectionArn: string;
    IngressVpcConfiguration: IngressVpcConfiguration;
}
export interface UpdateVpcIngressConnectionResponse {
    VpcIngressConnection: VpcIngressConnection;
}
export type ErrorMessage = string;
export type AssociateCustomDomainError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | CommonErrors;
/**
 * Associate your own domain name with the App Runner subdomain URL of your App Runner service.
 *
 * After you call `AssociateCustomDomain` and receive a successful response, use the information in the CustomDomain record
 * that's returned to add CNAME records to your Domain Name System (DNS). For each mapped domain name, add a mapping to the target App Runner subdomain and one or
 * more certificate validation records. App Runner then performs DNS validation to verify that you own or control the domain name that you associated. App Runner tracks
 * domain validity in a certificate stored in AWS Certificate Manager (ACM).
 */
export declare const associateCustomDomain: API.OperationMethod<AssociateCustomDomainRequest, AssociateCustomDomainResponse, AssociateCustomDomainError, Credentials | HttpClient.HttpClient>;
export type CreateAutoScalingConfigurationError = InternalServiceErrorException | InvalidRequestException | ServiceQuotaExceededException | CommonErrors;
/**
 * Create an App Runner automatic scaling configuration resource. App Runner requires this resource when you create or update App Runner services and you require
 * non-default auto scaling settings. You can share an auto scaling configuration across multiple services.
 *
 * Create multiple revisions of a configuration by calling this action multiple times using the same `AutoScalingConfigurationName`. The call
 * returns incremental `AutoScalingConfigurationRevision` values. When you create a service and configure an auto scaling configuration resource,
 * the service uses the latest active revision of the auto scaling configuration by default. You can optionally configure the service to use a specific
 * revision.
 *
 * Configure a higher `MinSize` to increase the spread of your App Runner service over more Availability Zones in the Amazon Web Services Region. The
 * tradeoff is a higher minimal cost.
 *
 * Configure a lower `MaxSize` to control your cost. The tradeoff is lower responsiveness during peak demand.
 */
export declare const createAutoScalingConfiguration: API.OperationMethod<CreateAutoScalingConfigurationRequest, CreateAutoScalingConfigurationResponse, CreateAutoScalingConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateConnectionError = InternalServiceErrorException | InvalidRequestException | ServiceQuotaExceededException | CommonErrors;
/**
 * Create an App Runner connection resource. App Runner requires a connection resource when you create App Runner services that access private repositories from
 * certain third-party providers. You can share a connection across multiple services.
 *
 * A connection resource is needed to access GitHub and Bitbucket repositories. Both require
 * a user interface approval process through the App Runner console before you can use the
 * connection.
 */
export declare const createConnection: API.OperationMethod<CreateConnectionRequest, CreateConnectionResponse, CreateConnectionError, Credentials | HttpClient.HttpClient>;
export type CreateObservabilityConfigurationError = InternalServiceErrorException | InvalidRequestException | ServiceQuotaExceededException | CommonErrors;
/**
 * Create an App Runner observability configuration resource. App Runner requires this resource when you create or update App Runner services and you want to enable
 * non-default observability features. You can share an observability configuration across multiple services.
 *
 * Create multiple revisions of a configuration by calling this action multiple times using the same `ObservabilityConfigurationName`. The
 * call returns incremental `ObservabilityConfigurationRevision` values. When you create a service and configure an observability configuration
 * resource, the service uses the latest active revision of the observability configuration by default. You can optionally configure the service to use a
 * specific revision.
 *
 * The observability configuration resource is designed to configure multiple features (currently one feature, tracing). This action takes optional
 * parameters that describe the configuration of these features (currently one parameter, `TraceConfiguration`). If you don't specify a feature
 * parameter, App Runner doesn't enable the feature.
 */
export declare const createObservabilityConfiguration: API.OperationMethod<CreateObservabilityConfigurationRequest, CreateObservabilityConfigurationResponse, CreateObservabilityConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateServiceError = InternalServiceErrorException | InvalidRequestException | ServiceQuotaExceededException | CommonErrors;
/**
 * Create an App Runner service. After the service is created, the action also automatically starts a deployment.
 *
 * This is an asynchronous operation. On a successful call, you can use the returned `OperationId` and the ListOperations call to track the operation's progress.
 */
export declare const createService: API.OperationMethod<CreateServiceRequest, CreateServiceResponse, CreateServiceError, Credentials | HttpClient.HttpClient>;
export type CreateVpcConnectorError = InternalServiceErrorException | InvalidRequestException | ServiceQuotaExceededException | CommonErrors;
/**
 * Create an App Runner VPC connector resource. App Runner requires this resource when you want to associate your App Runner service to a custom Amazon Virtual Private Cloud
 * (Amazon VPC).
 */
export declare const createVpcConnector: API.OperationMethod<CreateVpcConnectorRequest, CreateVpcConnectorResponse, CreateVpcConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateVpcIngressConnectionError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ServiceQuotaExceededException | CommonErrors;
/**
 * Create an App Runner VPC Ingress Connection resource. App Runner requires this resource when you want to associate your App Runner service with an Amazon VPC endpoint.
 */
export declare const createVpcIngressConnection: API.OperationMethod<CreateVpcIngressConnectionRequest, CreateVpcIngressConnectionResponse, CreateVpcIngressConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteAutoScalingConfigurationError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Delete an App Runner automatic scaling configuration resource. You can delete a top level auto scaling configuration, a specific revision of one, or all
 * revisions associated with the top level configuration. You can't delete the default auto scaling configuration or a configuration that's used by one or
 * more App Runner services.
 */
export declare const deleteAutoScalingConfiguration: API.OperationMethod<DeleteAutoScalingConfigurationRequest, DeleteAutoScalingConfigurationResponse, DeleteAutoScalingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Delete an App Runner connection. You must first ensure that there are no running App Runner services that use this connection. If there are any, the
 * `DeleteConnection` action fails.
 */
export declare const deleteConnection: API.OperationMethod<DeleteConnectionRequest, DeleteConnectionResponse, DeleteConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteObservabilityConfigurationError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Delete an App Runner observability configuration resource. You can delete a specific revision or the latest active revision. You can't delete a
 * configuration that's used by one or more App Runner services.
 */
export declare const deleteObservabilityConfiguration: API.OperationMethod<DeleteObservabilityConfigurationRequest, DeleteObservabilityConfigurationResponse, DeleteObservabilityConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Delete an App Runner service.
 *
 * This is an asynchronous operation. On a successful call, you can use the returned `OperationId` and the ListOperations
 * call to track the operation's progress.
 *
 * Make sure that you don't have any active VPCIngressConnections associated with the service you want to delete.
 */
export declare const deleteService: API.OperationMethod<DeleteServiceRequest, DeleteServiceResponse, DeleteServiceError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcConnectorError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Delete an App Runner VPC connector resource. You can't delete a
 * connector that's used by one or more App Runner services.
 */
export declare const deleteVpcConnector: API.OperationMethod<DeleteVpcConnectorRequest, DeleteVpcConnectorResponse, DeleteVpcConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcIngressConnectionError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Delete an App Runner VPC Ingress Connection resource that's associated with an App Runner service. The VPC Ingress Connection must be in one of the following states to be deleted:
 *
 * - `AVAILABLE`
 *
 * - `FAILED_CREATION`
 *
 * - `FAILED_UPDATE`
 *
 * - `FAILED_DELETION`
 */
export declare const deleteVpcIngressConnection: API.OperationMethod<DeleteVpcIngressConnectionRequest, DeleteVpcIngressConnectionResponse, DeleteVpcIngressConnectionError, Credentials | HttpClient.HttpClient>;
export type DescribeAutoScalingConfigurationError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Return a full description of an App Runner automatic scaling configuration resource.
 */
export declare const describeAutoScalingConfiguration: API.OperationMethod<DescribeAutoScalingConfigurationRequest, DescribeAutoScalingConfigurationResponse, DescribeAutoScalingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeCustomDomainsError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Return a description of custom domain names that are associated with an App Runner service.
 */
export declare const describeCustomDomains: API.PaginatedOperationMethod<DescribeCustomDomainsRequest, DescribeCustomDomainsResponse, DescribeCustomDomainsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeObservabilityConfigurationError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Return a full description of an App Runner observability configuration resource.
 */
export declare const describeObservabilityConfiguration: API.OperationMethod<DescribeObservabilityConfigurationRequest, DescribeObservabilityConfigurationResponse, DescribeObservabilityConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeServiceError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Return a full description of an App Runner service.
 */
export declare const describeService: API.OperationMethod<DescribeServiceRequest, DescribeServiceResponse, DescribeServiceError, Credentials | HttpClient.HttpClient>;
export type DescribeVpcConnectorError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Return a description of an App Runner VPC connector resource.
 */
export declare const describeVpcConnector: API.OperationMethod<DescribeVpcConnectorRequest, DescribeVpcConnectorResponse, DescribeVpcConnectorError, Credentials | HttpClient.HttpClient>;
export type DescribeVpcIngressConnectionError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Return a full description of an App Runner VPC Ingress Connection resource.
 */
export declare const describeVpcIngressConnection: API.OperationMethod<DescribeVpcIngressConnectionRequest, DescribeVpcIngressConnectionResponse, DescribeVpcIngressConnectionError, Credentials | HttpClient.HttpClient>;
export type DisassociateCustomDomainError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociate a custom domain name from an App Runner service.
 *
 * Certificates tracking domain validity are associated with a custom domain and are stored in AWS
 * Certificate Manager (ACM). These certificates aren't deleted as part of this action. App Runner delays certificate deletion for
 * 30 days after a domain is disassociated from your service.
 */
export declare const disassociateCustomDomain: API.OperationMethod<DisassociateCustomDomainRequest, DisassociateCustomDomainResponse, DisassociateCustomDomainError, Credentials | HttpClient.HttpClient>;
export type ListAutoScalingConfigurationsError = InternalServiceErrorException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of active App Runner automatic scaling configurations in your Amazon Web Services account. You can query the revisions for a specific
 * configuration name or the revisions for all active configurations in your account. You can optionally query only the latest revision of each requested
 * name.
 *
 * To retrieve a full description of a particular configuration revision, call and provide one of
 * the ARNs returned by `ListAutoScalingConfigurations`.
 */
export declare const listAutoScalingConfigurations: API.PaginatedOperationMethod<ListAutoScalingConfigurationsRequest, ListAutoScalingConfigurationsResponse, ListAutoScalingConfigurationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListConnectionsError = InternalServiceErrorException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of App Runner connections that are associated with your Amazon Web Services account.
 */
export declare const listConnections: API.PaginatedOperationMethod<ListConnectionsRequest, ListConnectionsResponse, ListConnectionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListObservabilityConfigurationsError = InternalServiceErrorException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of active App Runner observability configurations in your Amazon Web Services account. You can query the revisions for a specific
 * configuration name or the revisions for all active configurations in your account. You can optionally query only the latest revision of each requested
 * name.
 *
 * To retrieve a full description of a particular configuration revision, call and provide one
 * of the ARNs returned by `ListObservabilityConfigurations`.
 */
export declare const listObservabilityConfigurations: API.PaginatedOperationMethod<ListObservabilityConfigurationsRequest, ListObservabilityConfigurationsResponse, ListObservabilityConfigurationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListOperationsError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Return a list of operations that occurred on an App Runner service.
 *
 * The resulting list of OperationSummary objects is sorted in reverse chronological order. The first object on the list represents the
 * last started operation.
 */
export declare const listOperations: API.PaginatedOperationMethod<ListOperationsRequest, ListOperationsResponse, ListOperationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListServicesError = InternalServiceErrorException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of running App Runner services in your Amazon Web Services account.
 */
export declare const listServices: API.PaginatedOperationMethod<ListServicesRequest, ListServicesResponse, ListServicesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListServicesForAutoScalingConfigurationError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of the associated App Runner services using an auto scaling configuration.
 */
export declare const listServicesForAutoScalingConfiguration: API.PaginatedOperationMethod<ListServicesForAutoScalingConfigurationRequest, ListServicesForAutoScalingConfigurationResponse, ListServicesForAutoScalingConfigurationError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * List tags that are associated with for an App Runner resource. The response contains a list of tag key-value pairs.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVpcConnectorsError = InternalServiceErrorException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of App Runner VPC connectors in your Amazon Web Services account.
 */
export declare const listVpcConnectors: API.PaginatedOperationMethod<ListVpcConnectorsRequest, ListVpcConnectorsResponse, ListVpcConnectorsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListVpcIngressConnectionsError = InternalServiceErrorException | InvalidRequestException | CommonErrors;
/**
 * Return a list of App Runner VPC Ingress Connections in your Amazon Web Services account.
 */
export declare const listVpcIngressConnections: API.PaginatedOperationMethod<ListVpcIngressConnectionsRequest, ListVpcIngressConnectionsResponse, ListVpcIngressConnectionsError, Credentials | HttpClient.HttpClient, unknown>;
export type PauseServiceError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Pause an active App Runner service. App Runner reduces compute capacity for the service to zero and loses state (for example, ephemeral storage is
 * removed).
 *
 * This is an asynchronous operation. On a successful call, you can use the returned `OperationId` and the ListOperations
 * call to track the operation's progress.
 */
export declare const pauseService: API.OperationMethod<PauseServiceRequest, PauseServiceResponse, PauseServiceError, Credentials | HttpClient.HttpClient>;
export type ResumeServiceError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Resume an active App Runner service. App Runner provisions compute capacity for the service.
 *
 * This is an asynchronous operation. On a successful call, you can use the returned `OperationId` and the ListOperations
 * call to track the operation's progress.
 */
export declare const resumeService: API.OperationMethod<ResumeServiceRequest, ResumeServiceResponse, ResumeServiceError, Credentials | HttpClient.HttpClient>;
export type StartDeploymentError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Initiate a manual deployment of the latest commit in a source code repository or the latest image in a source image repository to an App Runner
 * service.
 *
 * For a source code repository, App Runner retrieves the commit and builds a Docker image. For a source image repository, App Runner retrieves the latest Docker
 * image. In both cases, App Runner then deploys the new image to your service and starts a new container instance.
 *
 * This is an asynchronous operation. On a successful call, you can use the returned `OperationId` and the ListOperations
 * call to track the operation's progress.
 */
export declare const startDeployment: API.OperationMethod<StartDeploymentRequest, StartDeploymentResponse, StartDeploymentError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Add tags to, or update the tag values of, an App Runner resource. A tag is a key-value pair.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Remove tags from an App Runner resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDefaultAutoScalingConfigurationError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Update an auto scaling configuration to be the default. The existing default auto scaling configuration will be set to non-default
 * automatically.
 */
export declare const updateDefaultAutoScalingConfiguration: API.OperationMethod<UpdateDefaultAutoScalingConfigurationRequest, UpdateDefaultAutoScalingConfigurationResponse, UpdateDefaultAutoScalingConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Update an App Runner service. You can update the source configuration and instance configuration of the service. You can also update the ARN of the auto
 * scaling configuration resource that's associated with the service. However, you can't change the name or the encryption configuration of the service.
 * These can be set only when you create the service.
 *
 * To update the tags applied to your service, use the separate actions TagResource and UntagResource.
 *
 * This is an asynchronous operation. On a successful call, you can use the returned `OperationId` and the ListOperations
 * call to track the operation's progress.
 */
export declare const updateService: API.OperationMethod<UpdateServiceRequest, UpdateServiceResponse, UpdateServiceError, Credentials | HttpClient.HttpClient>;
export type UpdateVpcIngressConnectionError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Update an existing App Runner VPC Ingress Connection resource. The VPC Ingress Connection must be in one of the following states to be updated:
 *
 * - AVAILABLE
 *
 * - FAILED_CREATION
 *
 * - FAILED_UPDATE
 */
export declare const updateVpcIngressConnection: API.OperationMethod<UpdateVpcIngressConnectionRequest, UpdateVpcIngressConnectionResponse, UpdateVpcIngressConnectionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=apprunner.d.ts.map