import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const RequestAlreadyInProgressException_base: S.TaggedErrorClass<"RequestAlreadyInProgressException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RequestAlreadyInProgressException extends /*@__PURE__*/ RequestAlreadyInProgressException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly quotaCode: any;
    readonly serviceCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly quotaCode: any;
    readonly serviceCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fields: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export interface AssociateServiceRoleToAccountRequest {
    roleArn: string;
}
export interface AssociateServiceRoleToAccountResponse {
    associatedAt?: string;
}
export type IoTThingName = string;
export interface AssociateClientDeviceWithCoreDeviceEntry {
    thingName: string;
}
export type AssociateClientDeviceWithCoreDeviceEntryList = AssociateClientDeviceWithCoreDeviceEntry[];
export interface BatchAssociateClientDeviceWithCoreDeviceRequest {
    entries?: AssociateClientDeviceWithCoreDeviceEntry[];
    coreDeviceThingName: string;
}
export type NonEmptyString = string;
export interface AssociateClientDeviceWithCoreDeviceErrorEntry {
    thingName?: string;
    code?: string;
    message?: string;
}
export type AssociateClientDeviceWithCoreDeviceErrorList = AssociateClientDeviceWithCoreDeviceErrorEntry[];
export interface BatchAssociateClientDeviceWithCoreDeviceResponse {
    errorEntries?: AssociateClientDeviceWithCoreDeviceErrorEntry[];
}
export interface DisassociateClientDeviceFromCoreDeviceEntry {
    thingName: string;
}
export type DisassociateClientDeviceFromCoreDeviceEntryList = DisassociateClientDeviceFromCoreDeviceEntry[];
export interface BatchDisassociateClientDeviceFromCoreDeviceRequest {
    entries?: DisassociateClientDeviceFromCoreDeviceEntry[];
    coreDeviceThingName: string;
}
export interface DisassociateClientDeviceFromCoreDeviceErrorEntry {
    thingName?: string;
    code?: string;
    message?: string;
}
export type DisassociateClientDeviceFromCoreDeviceErrorList = DisassociateClientDeviceFromCoreDeviceErrorEntry[];
export interface BatchDisassociateClientDeviceFromCoreDeviceResponse {
    errorEntries?: DisassociateClientDeviceFromCoreDeviceErrorEntry[];
}
export interface CancelDeploymentRequest {
    deploymentId: string;
}
export interface CancelDeploymentResponse {
    message?: string;
}
export type RecipeBlob = Uint8Array;
export type ComponentNameString = string;
export type ComponentVersionString = string;
export type PlatformAttributesMap = {
    [key: string]: string | undefined;
};
export interface ComponentPlatform {
    name?: string;
    attributes?: {
        [key: string]: string | undefined;
    };
}
export type ComponentPlatformList = ComponentPlatform[];
export type ComponentDependencyType = "HARD" | "SOFT" | (string & {});
export interface ComponentDependencyRequirement {
    versionRequirement?: string;
    dependencyType?: ComponentDependencyType;
}
export type ComponentDependencyMap = {
    [key: string]: ComponentDependencyRequirement | undefined;
};
export type TopicString = string;
export type LambdaEventSourceType = "PUB_SUB" | "IOT_CORE" | (string & {});
export interface LambdaEventSource {
    topic: string;
    type: LambdaEventSourceType;
}
export type LambdaEventSourceList = LambdaEventSource[];
export type OptionalInteger = number;
export type OptionalBoolean = boolean;
export type LambdaInputPayloadEncodingType = "json" | "binary" | (string & {});
export type LambdaExecArg = string;
export type LambdaExecArgsList = string[];
export type LambdaEnvironmentVariables = {
    [key: string]: string | undefined;
};
export type LambdaIsolationMode = "GreengrassContainer" | "NoContainer" | (string & {});
export type FileSystemPath = string;
export type LambdaFilesystemPermission = "ro" | "rw" | (string & {});
export interface LambdaVolumeMount {
    sourcePath: string;
    destinationPath: string;
    permission?: LambdaFilesystemPermission;
    addGroupOwner?: boolean;
}
export type LambdaVolumeList = LambdaVolumeMount[];
export interface LambdaDeviceMount {
    path: string;
    permission?: LambdaFilesystemPermission;
    addGroupOwner?: boolean;
}
export type LambdaDeviceList = LambdaDeviceMount[];
export interface LambdaContainerParams {
    memorySizeInKB?: number;
    mountROSysfs?: boolean;
    volumes?: LambdaVolumeMount[];
    devices?: LambdaDeviceMount[];
}
export interface LambdaLinuxProcessParams {
    isolationMode?: LambdaIsolationMode;
    containerParams?: LambdaContainerParams;
}
export interface LambdaExecutionParameters {
    eventSources?: LambdaEventSource[];
    maxQueueSize?: number;
    maxInstancesCount?: number;
    maxIdleTimeInSeconds?: number;
    timeoutInSeconds?: number;
    statusTimeoutInSeconds?: number;
    pinned?: boolean;
    inputPayloadEncodingType?: LambdaInputPayloadEncodingType;
    execArgs?: string[];
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    linuxProcessParams?: LambdaLinuxProcessParams;
}
export interface LambdaFunctionRecipeSource {
    lambdaArn: string;
    componentName?: string;
    componentVersion?: string;
    componentPlatforms?: ComponentPlatform[];
    componentDependencies?: {
        [key: string]: ComponentDependencyRequirement | undefined;
    };
    componentLambdaParameters?: LambdaExecutionParameters;
}
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type ClientTokenString = string;
export interface CreateComponentVersionRequest {
    inlineRecipe?: Uint8Array;
    lambdaFunction?: LambdaFunctionRecipeSource;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export type ComponentVersionARN = string;
export type CloudComponentState = "REQUESTED" | "INITIATED" | "DEPLOYABLE" | "FAILED" | "DEPRECATED" | (string & {});
export type StringMap = {
    [key: string]: string | undefined;
};
export type VendorGuidance = "ACTIVE" | "DISCONTINUED" | "DELETED" | (string & {});
export interface CloudComponentStatus {
    componentState?: CloudComponentState;
    message?: string;
    errors?: {
        [key: string]: string | undefined;
    };
    vendorGuidance?: VendorGuidance;
    vendorGuidanceMessage?: string;
}
export interface CreateComponentVersionResponse {
    arn?: string;
    componentName: string;
    componentVersion: string;
    creationTimestamp: Date;
    status: CloudComponentStatus;
}
export type TargetARN = string;
export type DeploymentNameString = string;
export type ComponentConfigurationString = string;
export type ComponentConfigurationPath = string;
export type ComponentConfigurationPathList = string[];
export interface ComponentConfigurationUpdate {
    merge?: string;
    reset?: string[];
}
export type Memory = number;
export type CPU = number;
export interface SystemResourceLimits {
    memory?: number;
    cpus?: number;
}
export interface ComponentRunWith {
    posixUser?: string;
    systemResourceLimits?: SystemResourceLimits;
    windowsUser?: string;
}
export interface ComponentDeploymentSpecification {
    componentVersion: string;
    configurationUpdate?: ComponentConfigurationUpdate;
    runWith?: ComponentRunWith;
}
export type ComponentDeploymentSpecifications = {
    [key: string]: ComponentDeploymentSpecification | undefined;
};
export type IoTJobRolloutBaseRatePerMinute = number;
export type IoTJobRolloutIncrementFactor = number;
export type IoTJobNumberOfThings = number;
export interface IoTJobRateIncreaseCriteria {
    numberOfNotifiedThings?: number;
    numberOfSucceededThings?: number;
}
export interface IoTJobExponentialRolloutRate {
    baseRatePerMinute: number;
    incrementFactor: number;
    rateIncreaseCriteria: IoTJobRateIncreaseCriteria;
}
export type IoTJobMaxExecutionsPerMin = number;
export interface IoTJobExecutionsRolloutConfig {
    exponentialRate?: IoTJobExponentialRolloutRate;
    maximumPerMinute?: number;
}
export type IoTJobExecutionFailureType = "FAILED" | "REJECTED" | "TIMED_OUT" | "ALL" | (string & {});
export type IoTJobAbortAction = "CANCEL" | (string & {});
export type IoTJobAbortThresholdPercentage = number;
export type IoTJobMinimumNumberOfExecutedThings = number;
export interface IoTJobAbortCriteria {
    failureType: IoTJobExecutionFailureType;
    action: IoTJobAbortAction;
    thresholdPercentage: number;
    minNumberOfExecutedThings: number;
}
export type IoTJobAbortCriteriaList = IoTJobAbortCriteria[];
export interface IoTJobAbortConfig {
    criteriaList: IoTJobAbortCriteria[];
}
export type IoTJobInProgressTimeoutInMinutes = number;
export interface IoTJobTimeoutConfig {
    inProgressTimeoutInMinutes?: number;
}
export interface DeploymentIoTJobConfiguration {
    jobExecutionsRolloutConfig?: IoTJobExecutionsRolloutConfig;
    abortConfig?: IoTJobAbortConfig;
    timeoutConfig?: IoTJobTimeoutConfig;
}
export type DeploymentFailureHandlingPolicy = "ROLLBACK" | "DO_NOTHING" | (string & {});
export type DeploymentComponentUpdatePolicyAction = "NOTIFY_COMPONENTS" | "SKIP_NOTIFY_COMPONENTS" | (string & {});
export interface DeploymentComponentUpdatePolicy {
    timeoutInSeconds?: number;
    action?: DeploymentComponentUpdatePolicyAction;
}
export interface DeploymentConfigurationValidationPolicy {
    timeoutInSeconds?: number;
}
export interface DeploymentPolicies {
    failureHandlingPolicy?: DeploymentFailureHandlingPolicy;
    componentUpdatePolicy?: DeploymentComponentUpdatePolicy;
    configurationValidationPolicy?: DeploymentConfigurationValidationPolicy;
}
export type ThingGroupARN = string;
export interface CreateDeploymentRequest {
    targetArn: string;
    deploymentName?: string;
    components?: {
        [key: string]: ComponentDeploymentSpecification | undefined;
    };
    iotJobConfiguration?: DeploymentIoTJobConfiguration;
    deploymentPolicies?: DeploymentPolicies;
    parentTargetArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export type IoTJobARN = string;
export interface CreateDeploymentResponse {
    deploymentId?: string;
    iotJobId?: string;
    iotJobArn?: string;
}
export interface DeleteComponentRequest {
    arn: string;
}
export interface DeleteComponentResponse {
}
export type CoreDeviceThingName = string;
export interface DeleteCoreDeviceRequest {
    coreDeviceThingName: string;
}
export interface DeleteCoreDeviceResponse {
}
export interface DeleteDeploymentRequest {
    deploymentId: string;
}
export interface DeleteDeploymentResponse {
}
export interface DescribeComponentRequest {
    arn: string;
}
export type PublisherString = string;
export type DescriptionString = string;
export interface DescribeComponentResponse {
    arn?: string;
    componentName?: string;
    componentVersion?: string;
    creationTimestamp?: Date;
    publisher?: string;
    description?: string;
    status?: CloudComponentStatus;
    platforms?: ComponentPlatform[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface DisassociateServiceRoleFromAccountRequest {
}
export interface DisassociateServiceRoleFromAccountResponse {
    disassociatedAt?: string;
}
export type RecipeOutputFormat = "JSON" | "YAML" | (string & {});
export interface GetComponentRequest {
    recipeOutputFormat?: RecipeOutputFormat;
    arn: string;
}
export interface GetComponentResponse {
    recipeOutputFormat: RecipeOutputFormat;
    recipe: Uint8Array;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type S3EndpointType = "REGIONAL" | "GLOBAL" | (string & {});
export type IotEndpointType = "fips" | "standard" | (string & {});
export interface GetComponentVersionArtifactRequest {
    arn: string;
    artifactName: string;
    s3EndpointType?: S3EndpointType;
    iotEndpointType?: IotEndpointType;
}
export interface GetComponentVersionArtifactResponse {
    preSignedUrl: string;
}
export interface GetConnectivityInfoRequest {
    thingName: string;
}
export type PortNumberInt = number;
export interface ConnectivityInfo {
    id?: string;
    hostAddress?: string;
    portNumber?: number;
    metadata?: string;
}
export type ConnectivityInfoList = ConnectivityInfo[];
export interface GetConnectivityInfoResponse {
    connectivityInfo?: ConnectivityInfo[];
    message?: string;
}
export interface GetCoreDeviceRequest {
    coreDeviceThingName: string;
}
export type GGCVersion = string;
export type CoreDevicePlatformString = string;
export type CoreDeviceArchitectureString = string;
export type CoreDeviceRuntimeString = string;
export type CoreDeviceStatus = "HEALTHY" | "UNHEALTHY" | (string & {});
export interface GetCoreDeviceResponse {
    coreDeviceThingName?: string;
    coreVersion?: string;
    platform?: string;
    architecture?: string;
    runtime?: string;
    status?: CoreDeviceStatus;
    lastStatusUpdateTimestamp?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetDeploymentRequest {
    deploymentId: string;
}
export type NullableString = string;
export type DeploymentStatus = "ACTIVE" | "COMPLETED" | "CANCELED" | "FAILED" | "INACTIVE" | (string & {});
export type IsLatestForTarget = boolean;
export interface GetDeploymentResponse {
    targetArn?: string;
    revisionId?: string;
    deploymentId?: string;
    deploymentName?: string;
    deploymentStatus?: DeploymentStatus;
    iotJobId?: string;
    iotJobArn?: string;
    components?: {
        [key: string]: ComponentDeploymentSpecification | undefined;
    };
    deploymentPolicies?: DeploymentPolicies;
    iotJobConfiguration?: DeploymentIoTJobConfiguration;
    creationTimestamp?: Date;
    isLatestForTarget?: boolean;
    parentTargetArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetServiceRoleForAccountRequest {
}
export interface GetServiceRoleForAccountResponse {
    associatedAt?: string;
    roleArn?: string;
}
export type DefaultMaxResults = number;
export type NextTokenString = string;
export interface ListClientDevicesAssociatedWithCoreDeviceRequest {
    coreDeviceThingName: string;
    maxResults?: number;
    nextToken?: string;
}
export interface AssociatedClientDevice {
    thingName?: string;
    associationTimestamp?: Date;
}
export type AssociatedClientDeviceList = AssociatedClientDevice[];
export interface ListClientDevicesAssociatedWithCoreDeviceResponse {
    associatedClientDevices?: AssociatedClientDevice[];
    nextToken?: string;
}
export type ComponentVisibilityScope = "PRIVATE" | "PUBLIC" | (string & {});
export interface ListComponentsRequest {
    scope?: ComponentVisibilityScope;
    maxResults?: number;
    nextToken?: string;
}
export type ComponentARN = string;
export interface ComponentLatestVersion {
    arn?: string;
    componentVersion?: string;
    creationTimestamp?: Date;
    description?: string;
    publisher?: string;
    platforms?: ComponentPlatform[];
}
export interface Component {
    arn?: string;
    componentName?: string;
    latestVersion?: ComponentLatestVersion;
}
export type ComponentList = Component[];
export interface ListComponentsResponse {
    components?: Component[];
    nextToken?: string;
}
export interface ListComponentVersionsRequest {
    arn: string;
    maxResults?: number;
    nextToken?: string;
}
export interface ComponentVersionListItem {
    componentName?: string;
    componentVersion?: string;
    arn?: string;
}
export type ComponentVersionList = ComponentVersionListItem[];
export interface ListComponentVersionsResponse {
    componentVersions?: ComponentVersionListItem[];
    nextToken?: string;
}
export interface ListCoreDevicesRequest {
    thingGroupArn?: string;
    status?: CoreDeviceStatus;
    maxResults?: number;
    nextToken?: string;
    runtime?: string;
}
export interface CoreDevice {
    coreDeviceThingName?: string;
    status?: CoreDeviceStatus;
    lastStatusUpdateTimestamp?: Date;
    platform?: string;
    architecture?: string;
    runtime?: string;
}
export type CoreDevicesList = CoreDevice[];
export interface ListCoreDevicesResponse {
    coreDevices?: CoreDevice[];
    nextToken?: string;
}
export type DeploymentHistoryFilter = "ALL" | "LATEST_ONLY" | (string & {});
export interface ListDeploymentsRequest {
    targetArn?: string;
    historyFilter?: DeploymentHistoryFilter;
    parentTargetArn?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface Deployment {
    targetArn?: string;
    revisionId?: string;
    deploymentId?: string;
    deploymentName?: string;
    creationTimestamp?: Date;
    deploymentStatus?: DeploymentStatus;
    isLatestForTarget?: boolean;
    parentTargetArn?: string;
}
export type DeploymentList = Deployment[];
export interface ListDeploymentsResponse {
    deployments?: Deployment[];
    nextToken?: string;
}
export interface ListEffectiveDeploymentsRequest {
    coreDeviceThingName: string;
    maxResults?: number;
    nextToken?: string;
}
export type DeploymentID = string;
export type DeploymentName = string;
export type IoTJobId = string;
export type Description = string;
export type EffectiveDeploymentExecutionStatus = "IN_PROGRESS" | "QUEUED" | "FAILED" | "COMPLETED" | "TIMED_OUT" | "CANCELED" | "REJECTED" | "SUCCEEDED" | (string & {});
export type Reason = string;
export type EffectiveDeploymentErrorCode = string;
export type EffectiveDeploymentErrorStack = string[];
export type EffectiveDeploymentErrorType = string;
export type EffectiveDeploymentErrorTypeList = string[];
export interface EffectiveDeploymentStatusDetails {
    errorStack?: string[];
    errorTypes?: string[];
}
export interface EffectiveDeployment {
    deploymentId: string;
    deploymentName: string;
    iotJobId?: string;
    iotJobArn?: string;
    description?: string;
    targetArn: string;
    coreDeviceExecutionStatus: EffectiveDeploymentExecutionStatus;
    reason?: string;
    creationTimestamp: Date;
    modifiedTimestamp: Date;
    statusDetails?: EffectiveDeploymentStatusDetails;
}
export type EffectiveDeploymentsList = EffectiveDeployment[];
export interface ListEffectiveDeploymentsResponse {
    effectiveDeployments?: EffectiveDeployment[];
    nextToken?: string;
}
export type InstalledComponentTopologyFilter = "ALL" | "ROOT" | (string & {});
export interface ListInstalledComponentsRequest {
    coreDeviceThingName: string;
    maxResults?: number;
    nextToken?: string;
    topologyFilter?: InstalledComponentTopologyFilter;
}
export type InstalledComponentLifecycleState = "NEW" | "INSTALLED" | "STARTING" | "RUNNING" | "STOPPING" | "ERRORED" | "BROKEN" | "FINISHED" | (string & {});
export type LifecycleStateDetails = string;
export type IsRoot = boolean;
export type InstalledComponentLifecycleStatusCode = string;
export type InstalledComponentLifecycleStatusCodeList = string[];
export interface InstalledComponent {
    componentName?: string;
    componentVersion?: string;
    lifecycleState?: InstalledComponentLifecycleState;
    lifecycleStateDetails?: string;
    isRoot?: boolean;
    lastStatusChangeTimestamp?: Date;
    lastReportedTimestamp?: Date;
    lastInstallationSource?: string;
    lifecycleStatusCodes?: string[];
}
export type InstalledComponentList = InstalledComponent[];
export interface ListInstalledComponentsResponse {
    installedComponents?: InstalledComponent[];
    nextToken?: string;
}
export type GenericV2ARN = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export type ComponentVersionRequirementMap = {
    [key: string]: string | undefined;
};
export interface ComponentCandidate {
    componentName?: string;
    componentVersion?: string;
    versionRequirements?: {
        [key: string]: string | undefined;
    };
}
export type ComponentCandidateList = ComponentCandidate[];
export interface ResolveComponentCandidatesRequest {
    platform?: ComponentPlatform;
    componentCandidates?: ComponentCandidate[];
}
export interface ResolvedComponentVersion {
    arn?: string;
    componentName?: string;
    componentVersion?: string;
    recipe?: Uint8Array;
    vendorGuidance?: VendorGuidance;
    message?: string;
}
export type ResolvedComponentVersionsList = ResolvedComponentVersion[];
export interface ResolveComponentCandidatesResponse {
    resolvedComponentVersions?: ResolvedComponentVersion[];
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateConnectivityInfoRequest {
    thingName: string;
    connectivityInfo: ConnectivityInfo[];
}
export interface UpdateConnectivityInfoResponse {
    version?: string;
    message?: string;
}
export type RetryAfterSeconds = number;
export type ValidationExceptionReason = "UNKNOWN_OPERATION" | "CANNOT_PARSE" | "FIELD_VALIDATION_FAILED" | "OTHER" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AssociateServiceRoleToAccountError = InternalServerException | ValidationException | CommonErrors;
/**
 * Associates a Greengrass service role with IoT Greengrass for your Amazon Web Services account in this Amazon Web Services Region. IoT Greengrass
 * uses this role to verify the identity of client devices and manage core device connectivity
 * information. The role must include the AWSGreengrassResourceAccessRolePolicy managed policy or a custom policy that
 * defines equivalent permissions for the IoT Greengrass features that you use. For more information, see
 * Greengrass service role in the *IoT Greengrass Version 2 Developer Guide*.
 */
export declare const associateServiceRoleToAccount: API.OperationMethod<AssociateServiceRoleToAccountRequest, AssociateServiceRoleToAccountResponse, AssociateServiceRoleToAccountError, Credentials | HttpClient.HttpClient>;
export type BatchAssociateClientDeviceWithCoreDeviceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a list of client devices with a core device. Use this API operation to specify
 * which client devices can discover a core device through cloud discovery. With cloud discovery,
 * client devices connect to IoT Greengrass to retrieve associated core devices' connectivity information
 * and certificates. For more information, see Configure cloud
 * discovery in the *IoT Greengrass V2 Developer Guide*.
 *
 * Client devices are local IoT devices that connect to and communicate with an IoT Greengrass core
 * device over MQTT. You can connect client devices to a core device to sync MQTT messages and
 * data to Amazon Web Services IoT Core and interact with client devices in Greengrass components. For more information,
 * see Interact with
 * local IoT devices in the *IoT Greengrass V2 Developer Guide*.
 */
export declare const batchAssociateClientDeviceWithCoreDevice: API.OperationMethod<BatchAssociateClientDeviceWithCoreDeviceRequest, BatchAssociateClientDeviceWithCoreDeviceResponse, BatchAssociateClientDeviceWithCoreDeviceError, Credentials | HttpClient.HttpClient>;
export type BatchDisassociateClientDeviceFromCoreDeviceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a list of client devices from a core device. After you disassociate a client
 * device from a core device, the client device won't be able to use cloud discovery to retrieve
 * the core device's connectivity information and certificates.
 */
export declare const batchDisassociateClientDeviceFromCoreDevice: API.OperationMethod<BatchDisassociateClientDeviceFromCoreDeviceRequest, BatchDisassociateClientDeviceFromCoreDeviceResponse, BatchDisassociateClientDeviceFromCoreDeviceError, Credentials | HttpClient.HttpClient>;
export type CancelDeploymentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels a deployment. This operation cancels the deployment for devices that haven't yet
 * received it. If a device already received the deployment, this operation doesn't change
 * anything for that device.
 */
export declare const cancelDeployment: API.OperationMethod<CancelDeploymentRequest, CancelDeploymentResponse, CancelDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateComponentVersionError = AccessDeniedException | ConflictException | InternalServerException | RequestAlreadyInProgressException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a component. Components are software that run on Greengrass core devices. After you
 * develop and test a component on your core device, you can use this operation to upload your
 * component to IoT Greengrass. Then, you can deploy the component to other core devices.
 *
 * You can use this operation to do the following:
 *
 * - **Create components from recipes**
 *
 * Create a component from a recipe, which is a file that defines the component's
 * metadata, parameters, dependencies, lifecycle, artifacts, and platform capability. For
 * more information, see IoT Greengrass component recipe
 * reference in the *IoT Greengrass V2 Developer Guide*.
 *
 * To create a component from a recipe, specify `inlineRecipe` when you call
 * this operation.
 *
 * - **Create components from Lambda functions**
 *
 * Create a component from an Lambda function that runs on IoT Greengrass. This creates a recipe
 * and artifacts from the Lambda function's deployment package. You can use this operation to
 * migrate Lambda functions from IoT Greengrass V1 to IoT Greengrass V2.
 *
 * This function accepts Lambda functions in all supported versions of Python, Node.js,
 * and Java runtimes. IoT Greengrass doesn't apply any additional restrictions on deprecated Lambda
 * runtime versions.
 *
 * To create a component from a Lambda function, specify `lambdaFunction` when
 * you call this operation.
 *
 * IoT Greengrass currently supports Lambda functions on only Linux core devices.
 */
export declare const createComponentVersion: API.OperationMethod<CreateComponentVersionRequest, CreateComponentVersionResponse, CreateComponentVersionError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentError = AccessDeniedException | ConflictException | InternalServerException | RequestAlreadyInProgressException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a continuous deployment for a target, which is a Greengrass core device or group of core
 * devices. When you add a new core device to a group of core devices that has a deployment, IoT Greengrass
 * deploys that group's deployment to the new device.
 *
 * You can define one deployment for each target. When you create a new deployment for a
 * target that has an existing deployment, you replace the previous deployment. IoT Greengrass applies the
 * new deployment to the target devices.
 *
 * Every deployment has a revision number that indicates how many deployment revisions you
 * define for a target. Use this operation to create a new revision of an existing
 * deployment.
 *
 * For more information, see the Create deployments in the
 * *IoT Greengrass V2 Developer Guide*.
 */
export declare const createDeployment: API.OperationMethod<CreateDeploymentRequest, CreateDeploymentResponse, CreateDeploymentError, Credentials | HttpClient.HttpClient>;
export type DeleteComponentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a version of a component from IoT Greengrass.
 *
 * This operation deletes the component's recipe and artifacts. As a result, deployments
 * that refer to this component version will fail. If you have deployments that use this
 * component version, you can remove the component from the deployment or update the deployment
 * to use a valid version.
 */
export declare const deleteComponent: API.OperationMethod<DeleteComponentRequest, DeleteComponentResponse, DeleteComponentError, Credentials | HttpClient.HttpClient>;
export type DeleteCoreDeviceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Greengrass core device, which is an IoT thing. This operation removes the core
 * device from the list of core devices. This operation doesn't delete the IoT thing. For more
 * information about how to delete the IoT thing, see DeleteThing in the
 * *IoT API Reference*.
 */
export declare const deleteCoreDevice: API.OperationMethod<DeleteCoreDeviceRequest, DeleteCoreDeviceResponse, DeleteCoreDeviceError, Credentials | HttpClient.HttpClient>;
export type DeleteDeploymentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a deployment. To delete an active deployment, you must first cancel it. For more
 * information, see CancelDeployment.
 *
 * Deleting a deployment doesn't affect core devices that run that deployment, because core
 * devices store the deployment's configuration on the device. Additionally, core devices can
 * roll back to a previous deployment that has been deleted.
 */
export declare const deleteDeployment: API.OperationMethod<DeleteDeploymentRequest, DeleteDeploymentResponse, DeleteDeploymentError, Credentials | HttpClient.HttpClient>;
export type DescribeComponentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves metadata for a version of a component.
 */
export declare const describeComponent: API.OperationMethod<DescribeComponentRequest, DescribeComponentResponse, DescribeComponentError, Credentials | HttpClient.HttpClient>;
export type DisassociateServiceRoleFromAccountError = InternalServerException | CommonErrors;
/**
 * Disassociates the Greengrass service role from IoT Greengrass for your Amazon Web Services account in this Amazon Web Services Region.
 * Without a service role, IoT Greengrass can't verify the identity of client devices or manage core device
 * connectivity information. For more information, see Greengrass service role in
 * the *IoT Greengrass Version 2 Developer Guide*.
 */
export declare const disassociateServiceRoleFromAccount: API.OperationMethod<DisassociateServiceRoleFromAccountRequest, DisassociateServiceRoleFromAccountResponse, DisassociateServiceRoleFromAccountError, Credentials | HttpClient.HttpClient>;
export type GetComponentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the recipe for a version of a component.
 */
export declare const getComponent: API.OperationMethod<GetComponentRequest, GetComponentResponse, GetComponentError, Credentials | HttpClient.HttpClient>;
export type GetComponentVersionArtifactError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the pre-signed URL to download a public or a Lambda component artifact. Core devices
 * call this operation to identify the URL that they can use to download an artifact to
 * install.
 */
export declare const getComponentVersionArtifact: API.OperationMethod<GetComponentVersionArtifactRequest, GetComponentVersionArtifactResponse, GetComponentVersionArtifactError, Credentials | HttpClient.HttpClient>;
export type GetConnectivityInfoError = InternalServerException | ValidationException | CommonErrors;
/**
 * Retrieves connectivity information for a Greengrass core device.
 *
 * Connectivity information includes endpoints and ports where client devices
 * can connect to an MQTT broker on the core device. When a client device
 * calls the IoT Greengrass discovery API,
 * IoT Greengrass returns connectivity information for all of the core devices where the client device can
 * connect. For more information, see Connect client devices to
 * core devices in the *IoT Greengrass Version 2 Developer Guide*.
 */
export declare const getConnectivityInfo: API.OperationMethod<GetConnectivityInfoRequest, GetConnectivityInfoResponse, GetConnectivityInfoError, Credentials | HttpClient.HttpClient>;
export type GetCoreDeviceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves metadata for a Greengrass core device.
 *
 * IoT Greengrass relies on individual devices to send status updates to the Amazon Web Services Cloud. If the
 * IoT Greengrass Core software isn't running on the device, or if device isn't connected to the Amazon Web Services Cloud,
 * then the reported status of that device might not reflect its current status. The status
 * timestamp indicates when the device status was last updated.
 *
 * Core devices send status updates at the following times:
 *
 * - When the IoT Greengrass Core software starts
 *
 * - When the core device receives a deployment from the Amazon Web Services Cloud
 *
 * - When the status of any component on the core device becomes
 * `BROKEN`
 *
 * - At a regular interval that you can configure, which defaults to 24 hours
 *
 * - For IoT Greengrass Core v2.7.0, the core device sends status updates upon local deployment and
 * cloud deployment
 */
export declare const getCoreDevice: API.OperationMethod<GetCoreDeviceRequest, GetCoreDeviceResponse, GetCoreDeviceError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a deployment. Deployments define the components that run on Greengrass core devices.
 */
export declare const getDeployment: API.OperationMethod<GetDeploymentRequest, GetDeploymentResponse, GetDeploymentError, Credentials | HttpClient.HttpClient>;
export type GetServiceRoleForAccountError = InternalServerException | CommonErrors;
/**
 * Gets the service role associated with IoT Greengrass for your Amazon Web Services account in this Amazon Web Services Region.
 * IoT Greengrass uses this role to verify the identity of client devices and manage core device
 * connectivity information. For more information, see Greengrass service role in
 * the *IoT Greengrass Version 2 Developer Guide*.
 */
export declare const getServiceRoleForAccount: API.OperationMethod<GetServiceRoleForAccountRequest, GetServiceRoleForAccountResponse, GetServiceRoleForAccountError, Credentials | HttpClient.HttpClient>;
export type ListClientDevicesAssociatedWithCoreDeviceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of client devices that are associated with a core
 * device.
 */
export declare const listClientDevicesAssociatedWithCoreDevice: API.PaginatedOperationMethod<ListClientDevicesAssociatedWithCoreDeviceRequest, ListClientDevicesAssociatedWithCoreDeviceResponse, ListClientDevicesAssociatedWithCoreDeviceError, Credentials | HttpClient.HttpClient, AssociatedClientDevice>;
export type ListComponentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of component summaries. This list includes components that you
 * have permission to view.
 */
export declare const listComponents: API.PaginatedOperationMethod<ListComponentsRequest, ListComponentsResponse, ListComponentsError, Credentials | HttpClient.HttpClient, Component>;
export type ListComponentVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of all versions for a component. Greater versions are listed
 * first.
 */
export declare const listComponentVersions: API.PaginatedOperationMethod<ListComponentVersionsRequest, ListComponentVersionsResponse, ListComponentVersionsError, Credentials | HttpClient.HttpClient, ComponentVersionListItem>;
export type ListCoreDevicesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of Greengrass core devices.
 *
 * IoT Greengrass relies on individual devices to send status updates to the Amazon Web Services Cloud. If the
 * IoT Greengrass Core software isn't running on the device, or if device isn't connected to the Amazon Web Services Cloud,
 * then the reported status of that device might not reflect its current status. The status
 * timestamp indicates when the device status was last updated.
 *
 * Core devices send status updates at the following times:
 *
 * - When the IoT Greengrass Core software starts
 *
 * - When the core device receives a deployment from the Amazon Web Services Cloud
 *
 * - For Greengrass nucleus 2.12.2 and earlier, the core device sends status updates when the
 * status of any component on the core device becomes `ERRORED` or
 * `BROKEN`.
 *
 * - For Greengrass nucleus 2.12.3 and later, the core device sends status updates when the
 * status of any component on the core device becomes `ERRORED`,
 * `BROKEN`, `RUNNING`, or `FINISHED`.
 *
 * - At a regular interval that you can configure, which defaults to 24 hours
 *
 * - For IoT Greengrass Core v2.7.0, the core device sends status updates upon local deployment and
 * cloud deployment
 */
export declare const listCoreDevices: API.PaginatedOperationMethod<ListCoreDevicesRequest, ListCoreDevicesResponse, ListCoreDevicesError, Credentials | HttpClient.HttpClient, CoreDevice>;
export type ListDeploymentsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of deployments.
 */
export declare const listDeployments: API.PaginatedOperationMethod<ListDeploymentsRequest, ListDeploymentsResponse, ListDeploymentsError, Credentials | HttpClient.HttpClient, Deployment>;
export type ListEffectiveDeploymentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of deployment jobs that IoT Greengrass sends to Greengrass core devices.
 */
export declare const listEffectiveDeployments: API.PaginatedOperationMethod<ListEffectiveDeploymentsRequest, ListEffectiveDeploymentsResponse, ListEffectiveDeploymentsError, Credentials | HttpClient.HttpClient, EffectiveDeployment>;
export type ListInstalledComponentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of the components that a Greengrass core device runs. By default,
 * this list doesn't include components that are deployed as dependencies of other components. To
 * include dependencies in the response, set the `topologyFilter` parameter to
 * `ALL`.
 *
 * IoT Greengrass relies on individual devices to send status updates to the Amazon Web Services Cloud. If the
 * IoT Greengrass Core software isn't running on the device, or if device isn't connected to the Amazon Web Services Cloud,
 * then the reported status of that device might not reflect its current status. The status
 * timestamp indicates when the device status was last updated.
 *
 * Core devices send status updates at the following times:
 *
 * - When the IoT Greengrass Core software starts
 *
 * - When the core device receives a deployment from the Amazon Web Services Cloud
 *
 * - When the status of any component on the core device becomes
 * `BROKEN`
 *
 * - At a regular interval that you can configure, which defaults to 24 hours
 *
 * - For IoT Greengrass Core v2.7.0, the core device sends status updates upon local deployment and
 * cloud deployment
 */
export declare const listInstalledComponents: API.PaginatedOperationMethod<ListInstalledComponentsRequest, ListInstalledComponentsResponse, ListInstalledComponentsError, Credentials | HttpClient.HttpClient, InstalledComponent>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the list of tags for an IoT Greengrass resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ResolveComponentCandidatesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of components that meet the component, version, and platform requirements
 * of a deployment. Greengrass core devices call this operation when they receive a deployment to
 * identify the components to install.
 *
 * This operation identifies components that meet all dependency requirements for a
 * deployment. If the requirements conflict, then this operation returns an error and the
 * deployment fails. For example, this occurs if component `A` requires version
 * `>2.0.0` and component `B` requires version `<2.0.0`
 * of a component dependency.
 *
 * When you specify the component candidates to resolve, IoT Greengrass compares each component's
 * digest from the core device with the component's digest in the Amazon Web Services Cloud. If the digests
 * don't match, then IoT Greengrass specifies to use the version from the Amazon Web Services Cloud.
 *
 * To use this operation, you must use the data plane API endpoint and authenticate with an
 * IoT device certificate. For more information, see IoT Greengrass endpoints and quotas.
 */
export declare const resolveComponentCandidates: API.OperationMethod<ResolveComponentCandidatesRequest, ResolveComponentCandidatesResponse, ResolveComponentCandidatesError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds tags to an IoT Greengrass resource. If a tag already exists for the resource, this operation
 * updates the tag's value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a tag from an IoT Greengrass resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectivityInfoError = InternalServerException | ValidationException | CommonErrors;
/**
 * Updates connectivity information for a Greengrass core device.
 *
 * Connectivity information includes endpoints and ports where client devices
 * can connect to an MQTT broker on the core device. When a client device
 * calls the IoT Greengrass discovery API,
 * IoT Greengrass returns connectivity information for all of the core devices where the client device can
 * connect. For more information, see Connect client devices to
 * core devices in the *IoT Greengrass Version 2 Developer Guide*.
 */
export declare const updateConnectivityInfo: API.OperationMethod<UpdateConnectivityInfoRequest, UpdateConnectivityInfoResponse, UpdateConnectivityInfoError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=greengrassv2.d.ts.map