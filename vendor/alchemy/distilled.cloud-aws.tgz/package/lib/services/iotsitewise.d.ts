import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type * as stream from "effect/Stream";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictingOperationException_base: S.TaggedErrorClass<"ConflictingOperationException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceArn: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictingOperationException extends /*@__PURE__*/ ConflictingOperationException_base {
}
declare const InternalFailureException_base: S.TaggedErrorClass<"InternalFailureException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const PreconditionFailedException_base: S.TaggedErrorClass<"PreconditionFailedException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceArn: any;
}>;
export declare class PreconditionFailedException extends /*@__PURE__*/ PreconditionFailedException_base {
}
declare const QueryTimeoutException_base: S.TaggedErrorClass<"QueryTimeoutException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class QueryTimeoutException extends /*@__PURE__*/ QueryTimeoutException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceArn: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
    readonly resourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type CustomID = string;
export type ClientToken = string;
export interface AssociateAssetsRequest {
    assetId: string;
    hierarchyId: string;
    childAssetId: string;
    clientToken?: string;
}
export interface AssociateAssetsResponse {
}
export type PropertyAlias = string;
export interface AssociateTimeSeriesToAssetPropertyRequest {
    alias: string;
    assetId: string;
    propertyId: string;
    clientToken?: string;
}
export interface AssociateTimeSeriesToAssetPropertyResponse {
}
export type ID = string;
export type WorkspaceName = string;
export type TimeSeriesId = string;
export type TimeInSeconds = number;
export type OffsetInNanos = number;
export interface TimeInNanos {
    timeInSeconds: number;
    offsetInNanos?: number;
}
export interface AssociateDataSegmentEntry {
    sourceDatasetId: string;
    timeSeriesId: string;
    startTimestamp: TimeInNanos;
    endTimestamp: TimeInNanos;
}
export type AssociateDataSegmentEntries = AssociateDataSegmentEntry[];
export interface BatchAssociateDataSegmentsToDatasetRequest {
    datasetId: string;
    workspaceName: string;
    associateDataSegmentEntries: AssociateDataSegmentEntry[];
    clientToken?: string;
}
export type Version = string;
export type DataSegmentErrorCode = "INTERNAL_FAILURE" | "VALIDATION_ERROR" | "RESOURCE_NOT_FOUND" | "LIMIT_EXCEEDED" | "CONFLICTING_OPERATION" | (string & {});
export type DataSegmentErrorMessage = string;
export interface FailedDataSegmentAssociation {
    sourceDatasetId: string;
    timeSeriesId: string;
    startTimestamp: TimeInNanos;
    endTimestamp: TimeInNanos;
    errorCode: DataSegmentErrorCode;
    errorMessage: string;
}
export type FailedDataSegmentAssociations = FailedDataSegmentAssociation[];
export interface BatchAssociateDataSegmentsToDatasetResponse {
    datasetId: string;
    datasetVersion: string;
    failedAssociations: FailedDataSegmentAssociation[];
}
export type IDs = string[];
export interface BatchAssociateProjectAssetsRequest {
    projectId: string;
    assetIds: string[];
    clientToken?: string;
}
export type AssetErrorCode = "INTERNAL_FAILURE" | (string & {});
export type AssetErrorMessage = string;
export interface AssetErrorDetails {
    assetId: string;
    code: AssetErrorCode;
    message: string;
}
export type BatchAssociateProjectAssetsErrors = AssetErrorDetails[];
export interface BatchAssociateProjectAssetsResponse {
    errors?: AssetErrorDetails[];
}
export interface DeleteDataSegmentEntry {
    timeSeriesId: string;
    startTimestamp: TimeInNanos;
    endTimestamp: TimeInNanos;
}
export type DeleteDataSegmentEntries = DeleteDataSegmentEntry[];
export interface BatchDeleteDatasetDataSegmentsRequest {
    datasetId: string;
    workspaceName: string;
    deleteDataSegmentEntries: DeleteDataSegmentEntry[];
    clientToken?: string;
}
export interface FailedDataSegmentDeletion {
    timeSeriesId: string;
    startTimestamp: TimeInNanos;
    endTimestamp: TimeInNanos;
    errorCode: DataSegmentErrorCode;
    errorMessage: string;
}
export type FailedDataSegmentDeletions = FailedDataSegmentDeletion[];
export interface BatchDeleteDatasetDataSegmentsResponse {
    datasetId: string;
    datasetVersion: string;
    errors: FailedDataSegmentDeletion[];
}
export interface DisassociateDataSegmentEntry {
    sourceDatasetId: string;
    timeSeriesId: string;
    startTimestamp: TimeInNanos;
    endTimestamp: TimeInNanos;
}
export type DisassociateDataSegmentEntries = DisassociateDataSegmentEntry[];
export interface BatchDisassociateDataSegmentsFromDatasetRequest {
    datasetId: string;
    workspaceName: string;
    disassociateDataSegmentEntries: DisassociateDataSegmentEntry[];
    clientToken?: string;
}
export interface FailedDataSegmentDisassociation {
    sourceDatasetId: string;
    timeSeriesId: string;
    startTimestamp: TimeInNanos;
    endTimestamp: TimeInNanos;
    errorCode: DataSegmentErrorCode;
    errorMessage: string;
}
export type FailedDataSegmentDisassociations = FailedDataSegmentDisassociation[];
export interface BatchDisassociateDataSegmentsFromDatasetResponse {
    datasetId: string;
    datasetVersion: string;
    failedDisassociations: FailedDataSegmentDisassociation[];
}
export interface BatchDisassociateProjectAssetsRequest {
    projectId: string;
    assetIds: string[];
    clientToken?: string;
}
export type BatchDisassociateProjectAssetsErrors = AssetErrorDetails[];
export interface BatchDisassociateProjectAssetsResponse {
    errors?: AssetErrorDetails[];
}
export type EntryId = string;
export type AssetPropertyAlias = string;
export type AggregateType = "AVERAGE" | "COUNT" | "MAXIMUM" | "MINIMUM" | "SUM" | "STANDARD_DEVIATION" | (string & {});
export type AggregateTypes = AggregateType[];
export type Resolution = string;
export type Quality = "GOOD" | "BAD" | "UNCERTAIN" | (string & {});
export type Qualities = Quality[];
export type TimeOrdering = "ASCENDING" | "DESCENDING" | (string & {});
export interface BatchGetAssetPropertyAggregatesEntry {
    entryId: string;
    assetId?: string;
    propertyId?: string;
    propertyAlias?: string;
    aggregateTypes: AggregateType[];
    resolution: string;
    startDate: Date;
    endDate: Date;
    qualities?: Quality[];
    timeOrdering?: TimeOrdering;
}
export type BatchGetAssetPropertyAggregatesEntries = BatchGetAssetPropertyAggregatesEntry[];
export type NextToken = string;
export type BatchGetAssetPropertyAggregatesMaxResults = number;
export interface BatchGetAssetPropertyAggregatesRequest {
    entries: BatchGetAssetPropertyAggregatesEntry[];
    nextToken?: string;
    maxResults?: number;
}
export type BatchGetAssetPropertyAggregatesErrorCode = "ResourceNotFoundException" | "InvalidRequestException" | "AccessDeniedException" | (string & {});
export type ErrorMessage = string;
export interface BatchGetAssetPropertyAggregatesErrorEntry {
    errorCode: BatchGetAssetPropertyAggregatesErrorCode;
    errorMessage: string;
    entryId: string;
}
export type BatchGetAssetPropertyAggregatesErrorEntries = BatchGetAssetPropertyAggregatesErrorEntry[];
export type AggregatedDoubleValue = number;
export interface Aggregates {
    average?: number;
    count?: number;
    maximum?: number;
    minimum?: number;
    sum?: number;
    standardDeviation?: number;
}
export interface AggregatedValue {
    timestamp: Date;
    quality?: Quality;
    value: Aggregates;
}
export type AggregatedValues = AggregatedValue[];
export interface BatchGetAssetPropertyAggregatesSuccessEntry {
    entryId: string;
    aggregatedValues: AggregatedValue[];
}
export type BatchGetAssetPropertyAggregatesSuccessEntries = BatchGetAssetPropertyAggregatesSuccessEntry[];
export type BatchEntryCompletionStatus = "SUCCESS" | "ERROR" | (string & {});
export interface BatchGetAssetPropertyAggregatesErrorInfo {
    errorCode: BatchGetAssetPropertyAggregatesErrorCode;
    errorTimestamp: Date;
}
export interface BatchGetAssetPropertyAggregatesSkippedEntry {
    entryId: string;
    completionStatus: BatchEntryCompletionStatus;
    errorInfo?: BatchGetAssetPropertyAggregatesErrorInfo;
}
export type BatchGetAssetPropertyAggregatesSkippedEntries = BatchGetAssetPropertyAggregatesSkippedEntry[];
export interface BatchGetAssetPropertyAggregatesResponse {
    errorEntries: BatchGetAssetPropertyAggregatesErrorEntry[];
    successEntries: BatchGetAssetPropertyAggregatesSuccessEntry[];
    skippedEntries: BatchGetAssetPropertyAggregatesSkippedEntry[];
    nextToken?: string;
}
export interface BatchGetAssetPropertyValueEntry {
    entryId: string;
    assetId?: string;
    propertyId?: string;
    propertyAlias?: string;
}
export type BatchGetAssetPropertyValueEntries = BatchGetAssetPropertyValueEntry[];
export interface BatchGetAssetPropertyValueRequest {
    entries: BatchGetAssetPropertyValueEntry[];
    nextToken?: string;
}
export type BatchGetAssetPropertyValueErrorCode = "ResourceNotFoundException" | "InvalidRequestException" | "AccessDeniedException" | (string & {});
export interface BatchGetAssetPropertyValueErrorEntry {
    errorCode: BatchGetAssetPropertyValueErrorCode;
    errorMessage: string;
    entryId: string;
}
export type BatchGetAssetPropertyValueErrorEntries = BatchGetAssetPropertyValueErrorEntry[];
export type PropertyValueStringValue = string;
export type PropertyValueIntegerValue = number;
export type PropertyValueDoubleValue = number;
export type PropertyValueBooleanValue = boolean;
export type RawValueType = "D" | "B" | "S" | "I" | "U" | (string & {});
export interface PropertyValueNullValue {
    valueType: RawValueType;
}
export interface Variant {
    stringValue?: string;
    integerValue?: number;
    doubleValue?: number;
    booleanValue?: boolean;
    nullValue?: PropertyValueNullValue;
}
export interface AssetPropertyValue {
    value: Variant;
    timestamp: TimeInNanos;
    quality?: Quality;
}
export interface BatchGetAssetPropertyValueSuccessEntry {
    entryId: string;
    assetPropertyValue?: AssetPropertyValue;
}
export type BatchGetAssetPropertyValueSuccessEntries = BatchGetAssetPropertyValueSuccessEntry[];
export interface BatchGetAssetPropertyValueErrorInfo {
    errorCode: BatchGetAssetPropertyValueErrorCode;
    errorTimestamp: Date;
}
export interface BatchGetAssetPropertyValueSkippedEntry {
    entryId: string;
    completionStatus: BatchEntryCompletionStatus;
    errorInfo?: BatchGetAssetPropertyValueErrorInfo;
}
export type BatchGetAssetPropertyValueSkippedEntries = BatchGetAssetPropertyValueSkippedEntry[];
export interface BatchGetAssetPropertyValueResponse {
    errorEntries: BatchGetAssetPropertyValueErrorEntry[];
    successEntries: BatchGetAssetPropertyValueSuccessEntry[];
    skippedEntries: BatchGetAssetPropertyValueSkippedEntry[];
    nextToken?: string;
}
export interface BatchGetAssetPropertyValueHistoryEntry {
    entryId: string;
    assetId?: string;
    propertyId?: string;
    propertyAlias?: string;
    startDate?: Date;
    endDate?: Date;
    qualities?: Quality[];
    timeOrdering?: TimeOrdering;
}
export type BatchGetAssetPropertyValueHistoryEntries = BatchGetAssetPropertyValueHistoryEntry[];
export type BatchGetAssetPropertyValueHistoryMaxResults = number;
export interface BatchGetAssetPropertyValueHistoryRequest {
    entries: BatchGetAssetPropertyValueHistoryEntry[];
    nextToken?: string;
    maxResults?: number;
}
export type BatchGetAssetPropertyValueHistoryErrorCode = "ResourceNotFoundException" | "InvalidRequestException" | "AccessDeniedException" | (string & {});
export interface BatchGetAssetPropertyValueHistoryErrorEntry {
    errorCode: BatchGetAssetPropertyValueHistoryErrorCode;
    errorMessage: string;
    entryId: string;
}
export type BatchGetAssetPropertyValueHistoryErrorEntries = BatchGetAssetPropertyValueHistoryErrorEntry[];
export type AssetPropertyValueHistory = AssetPropertyValue[];
export interface BatchGetAssetPropertyValueHistorySuccessEntry {
    entryId: string;
    assetPropertyValueHistory: AssetPropertyValue[];
}
export type BatchGetAssetPropertyValueHistorySuccessEntries = BatchGetAssetPropertyValueHistorySuccessEntry[];
export interface BatchGetAssetPropertyValueHistoryErrorInfo {
    errorCode: BatchGetAssetPropertyValueHistoryErrorCode;
    errorTimestamp: Date;
}
export interface BatchGetAssetPropertyValueHistorySkippedEntry {
    entryId: string;
    completionStatus: BatchEntryCompletionStatus;
    errorInfo?: BatchGetAssetPropertyValueHistoryErrorInfo;
}
export type BatchGetAssetPropertyValueHistorySkippedEntries = BatchGetAssetPropertyValueHistorySkippedEntry[];
export interface BatchGetAssetPropertyValueHistoryResponse {
    errorEntries: BatchGetAssetPropertyValueHistoryErrorEntry[];
    successEntries: BatchGetAssetPropertyValueHistorySuccessEntry[];
    skippedEntries: BatchGetAssetPropertyValueHistorySkippedEntry[];
    nextToken?: string;
}
export type AssetPropertyValues = AssetPropertyValue[];
export interface PutAssetPropertyValueEntry {
    entryId: string;
    assetId?: string;
    propertyId?: string;
    propertyAlias?: string;
    propertyValues: AssetPropertyValue[];
}
export type PutAssetPropertyValueEntries = PutAssetPropertyValueEntry[];
export interface BatchPutAssetPropertyValueRequest {
    enablePartialEntryProcessing?: boolean;
    entries: PutAssetPropertyValueEntry[];
}
export type BatchPutAssetPropertyValueErrorCode = "ResourceNotFoundException" | "InvalidRequestException" | "InternalFailureException" | "ServiceUnavailableException" | "ThrottlingException" | "LimitExceededException" | "ConflictingOperationException" | "TimestampOutOfRangeException" | "AccessDeniedException" | (string & {});
export type Timestamps = TimeInNanos[];
export interface BatchPutAssetPropertyError {
    errorCode: BatchPutAssetPropertyValueErrorCode;
    errorMessage: string;
    timestamps: TimeInNanos[];
}
export type BatchPutAssetPropertyErrors = BatchPutAssetPropertyError[];
export interface BatchPutAssetPropertyErrorEntry {
    entryId: string;
    errors: BatchPutAssetPropertyError[];
}
export type BatchPutAssetPropertyErrorEntries = BatchPutAssetPropertyErrorEntry[];
export interface BatchPutAssetPropertyValueResponse {
    errorEntries: BatchPutAssetPropertyErrorEntry[];
}
export interface CancelEnrichmentJobRequest {
    workspaceName: string;
    jobId: string;
}
export type EnrichmentJobStatus = "PENDING" | "RUNNING" | "COMPLETED" | "FAILED" | "TIMED_OUT" | "CANCELLED" | (string & {});
export interface CancelEnrichmentJobResponse {
    jobId: string;
    status: EnrichmentJobStatus;
}
export type ResourceName = string;
export type CancelPipelineExecutionRequestReasonString = string;
export interface CancelPipelineExecutionRequest {
    workspaceName: string;
    pipelineName: string;
    pipelineExecutionId: string;
    reason?: string;
}
export type PipelineExecutionState = "NOT_STARTED" | "RUNNING" | "SUCCEEDED" | "FAILED" | "CANCELLING" | "CANCELLED" | (string & {});
export interface CancelPipelineExecutionResponse {
    state: PipelineExecutionState;
}
export type QueryId = string;
export interface CancelQueryRequest {
    workspaceName: string;
    queryId: string;
}
export type QueryStatus = "SUBMITTED" | "RUNNING" | "COMPLETED" | "FAILED" | "CANCELED" | "CANCELING" | (string & {});
export interface CancelQueryResponse {
    queryId: string;
    status: QueryStatus;
}
export type IdentityId = string;
export interface UserIdentity {
    id: string;
}
export interface GroupIdentity {
    id: string;
}
export type IamArn = string;
export interface IAMUserIdentity {
    arn: string;
}
export interface IAMRoleIdentity {
    arn: string;
}
export interface Identity {
    user?: UserIdentity;
    group?: GroupIdentity;
    iamUser?: IAMUserIdentity;
    iamRole?: IAMRoleIdentity;
}
export interface PortalResource {
    id: string;
}
export interface ProjectResource {
    id: string;
}
export interface Resource {
    portal?: PortalResource;
    project?: ProjectResource;
}
export type Permission = "ADMINISTRATOR" | "VIEWER" | (string & {});
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateAccessPolicyRequest {
    accessPolicyIdentity: Identity;
    accessPolicyResource: Resource;
    accessPolicyPermission: Permission;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type ARN = string;
export interface CreateAccessPolicyResponse {
    accessPolicyId: string;
    accessPolicyArn: string;
}
export type ApplicationName = string;
export type Description = string;
export interface CreateApplicationRequest {
    clientToken?: string;
    idcInstanceArn: string;
    workspaceName: string;
    name: string;
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type ApplicationId = string;
export type DnsSubdomain = string;
export type ApplicationStatus = "CREATING" | "ACTIVE" | "DELETING" | (string & {});
export interface CreateApplicationResponse {
    arn: string;
    id: string;
    dnsSubdomain: string;
    name: string;
    status: ApplicationStatus;
}
export type Name = string;
export type ExternalId = string;
export interface CreateAssetRequest {
    assetName: string;
    assetModelId: string;
    assetId?: string;
    assetExternalId?: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    assetDescription?: string;
}
export type AssetState = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export type ErrorCode = "VALIDATION_ERROR" | "INTERNAL_FAILURE" | (string & {});
export type DetailedErrorCode = "INCOMPATIBLE_COMPUTE_LOCATION" | "INCOMPATIBLE_FORWARDING_CONFIGURATION" | (string & {});
export type DetailedErrorMessage = string;
export interface DetailedError {
    code: DetailedErrorCode;
    message: string;
}
export type DetailedErrors = DetailedError[];
export interface ErrorDetails {
    code: ErrorCode;
    message: string;
    details?: DetailedError[];
}
export interface AssetStatus {
    state: AssetState;
    error?: ErrorDetails;
}
export interface CreateAssetResponse {
    assetId: string;
    assetArn: string;
    assetStatus: AssetStatus;
}
export type AssetModelType = "ASSET_MODEL" | "COMPONENT_MODEL" | "INTERFACE" | (string & {});
export type PropertyDataType = "STRING" | "INTEGER" | "DOUBLE" | "BOOLEAN" | "STRUCT" | "VIDEO" | "ANNOTATION" | "JSON" | (string & {});
export type PropertyUnit = string;
export type DefaultValue = string;
export interface Attribute {
    defaultValue?: string;
}
export type ForwardingConfigState = "DISABLED" | "ENABLED" | (string & {});
export interface ForwardingConfig {
    state: ForwardingConfigState;
}
export interface MeasurementProcessingConfig {
    forwardingConfig: ForwardingConfig;
}
export interface Measurement {
    processingConfig?: MeasurementProcessingConfig;
}
export type Expression = string;
export type VariableName = string;
export type Macro = string;
export interface AssetModelPropertyPathSegment {
    id?: string;
    name?: string;
}
export type AssetModelPropertyPath = AssetModelPropertyPathSegment[];
export interface VariableValue {
    propertyId?: string;
    hierarchyId?: string;
    propertyPath?: AssetModelPropertyPathSegment[];
}
export interface ExpressionVariable {
    name: string;
    value: VariableValue;
}
export type ExpressionVariables = ExpressionVariable[];
export type ComputeLocation = "EDGE" | "CLOUD" | (string & {});
export interface TransformProcessingConfig {
    computeLocation: ComputeLocation;
    forwardingConfig?: ForwardingConfig;
}
export interface Transform {
    expression: string;
    variables: ExpressionVariable[];
    processingConfig?: TransformProcessingConfig;
}
export type Interval = string;
export type Offset = string;
export interface TumblingWindow {
    interval: string;
    offset?: string;
}
export interface MetricWindow {
    tumbling?: TumblingWindow;
}
export interface MetricProcessingConfig {
    computeLocation: ComputeLocation;
}
export interface Metric {
    expression?: string;
    variables?: ExpressionVariable[];
    window: MetricWindow;
    processingConfig?: MetricProcessingConfig;
}
export interface PropertyType {
    attribute?: Attribute;
    measurement?: Measurement;
    transform?: Transform;
    metric?: Metric;
}
export interface AssetModelPropertyDefinition {
    id?: string;
    externalId?: string;
    name: string;
    dataType: PropertyDataType;
    dataTypeSpec?: string;
    unit?: string;
    type: PropertyType;
}
export type AssetModelPropertyDefinitions = AssetModelPropertyDefinition[];
export interface AssetModelHierarchyDefinition {
    id?: string;
    externalId?: string;
    name: string;
    childAssetModelId: string;
}
export type AssetModelHierarchyDefinitions = AssetModelHierarchyDefinition[];
export interface AssetModelCompositeModelDefinition {
    id?: string;
    externalId?: string;
    name: string;
    description?: string;
    type: string;
    properties?: AssetModelPropertyDefinition[];
}
export type AssetModelCompositeModelDefinitions = AssetModelCompositeModelDefinition[];
export interface CreateAssetModelRequest {
    assetModelName: string;
    assetModelType?: AssetModelType;
    assetModelId?: string;
    assetModelExternalId?: string;
    assetModelDescription?: string;
    assetModelProperties?: AssetModelPropertyDefinition[];
    assetModelHierarchies?: AssetModelHierarchyDefinition[];
    assetModelCompositeModels?: AssetModelCompositeModelDefinition[];
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type AssetModelState = "CREATING" | "ACTIVE" | "UPDATING" | "PROPAGATING" | "DELETING" | "FAILED" | (string & {});
export interface AssetModelStatus {
    state: AssetModelState;
    error?: ErrorDetails;
}
export interface CreateAssetModelResponse {
    assetModelId: string;
    assetModelArn: string;
    assetModelStatus: AssetModelStatus;
}
export type ETag = string;
export type SelectAll = string;
export type AssetModelVersionType = "LATEST" | "ACTIVE" | (string & {});
export interface CreateAssetModelCompositeModelRequest {
    assetModelId: string;
    assetModelCompositeModelExternalId?: string;
    parentAssetModelCompositeModelId?: string;
    assetModelCompositeModelId?: string;
    assetModelCompositeModelDescription?: string;
    assetModelCompositeModelName: string;
    assetModelCompositeModelType: string;
    clientToken?: string;
    composedAssetModelId?: string;
    assetModelCompositeModelProperties?: AssetModelPropertyDefinition[];
    ifMatch?: string;
    ifNoneMatch?: string;
    matchForVersionType?: AssetModelVersionType;
}
export interface AssetModelCompositeModelPathSegment {
    id?: string;
    name?: string;
}
export type AssetModelCompositeModelPath = AssetModelCompositeModelPathSegment[];
export interface CreateAssetModelCompositeModelResponse {
    assetModelCompositeModelId: string;
    assetModelCompositeModelPath: AssetModelCompositeModelPathSegment[];
    assetModelStatus: AssetModelStatus;
    assetModelId?: string;
}
export type BulkImportJobName = string;
export type Bucket = string;
export type ColumnName = "ALIAS" | "ASSET_ID" | "PROPERTY_ID" | "DATA_TYPE" | "TIMESTAMP_SECONDS" | "TIMESTAMP_NANO_OFFSET" | "QUALITY" | "VALUE" | (string & {});
export type ColumnNames = ColumnName[];
export interface Csv {
    columnNames: ColumnName[];
}
export interface Parquet {
}
export interface Mp4 {
}
export interface Annotation {
}
export interface FileFormat {
    csv?: Csv;
    parquet?: Parquet;
    mp4?: Mp4;
    annotation?: Annotation;
}
export interface File {
    bucket: string;
    key: string;
    versionId?: string;
    alias?: string;
    startTime?: TimeInNanos;
    fileFormat?: FileFormat;
}
export type Files = File[];
export interface ErrorReportLocation {
    bucket: string;
    prefix: string;
}
export interface JobConfiguration {
    fileFormat?: FileFormat;
}
export type AdaptiveIngestion = boolean;
export type DeleteFilesAfterImport = boolean;
export interface CreateBulkImportJobRequest {
    jobName: string;
    jobRoleArn: string;
    files: File[];
    errorReportLocation: ErrorReportLocation;
    jobConfiguration?: JobConfiguration;
    adaptiveIngestion?: boolean;
    deleteFilesAfterImport?: boolean;
    datasetId?: string;
    workspaceName?: string;
}
export type JobStatus = "PENDING" | "CANCELLED" | "RUNNING" | "COMPLETED" | "FAILED" | "COMPLETED_WITH_FAILURES" | (string & {});
export interface CreateBulkImportJobResponse {
    jobId: string;
    jobName: string;
    jobStatus: JobStatus;
}
export type RestrictedName = string;
export type RestrictedDescription = string;
export type InputProperties = string;
export type ResultProperty = string;
export interface ComputationModelAnomalyDetectionConfiguration {
    inputProperties: string;
    resultProperty: string;
}
export interface ComputationModelConfiguration {
    anomalyDetection?: ComputationModelAnomalyDetectionConfiguration;
}
export type ComputationModelDataBindingVariable = string;
export interface AssetModelPropertyBindingValue {
    assetModelId: string;
    propertyId: string;
}
export interface AssetPropertyBindingValue {
    assetId: string;
    propertyId: string;
}
export type BindingValueList = ComputationModelDataBindingValue[];
export interface ComputationModelDataBindingValue {
    assetModelProperty?: AssetModelPropertyBindingValue;
    assetProperty?: AssetPropertyBindingValue;
    list?: ComputationModelDataBindingValue[];
}
export type ComputationModelDataBinding = {
    [key: string]: ComputationModelDataBindingValue | undefined;
};
export interface CreateComputationModelRequest {
    computationModelName: string;
    computationModelDescription?: string;
    computationModelConfiguration: ComputationModelConfiguration;
    computationModelDataBinding: {
        [key: string]: ComputationModelDataBindingValue | undefined;
    };
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type ComputationModelState = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export interface ComputationModelStatus {
    state: ComputationModelState;
    error?: ErrorDetails;
}
export interface CreateComputationModelResponse {
    computationModelId: string;
    computationModelArn: string;
    computationModelStatus: ComputationModelStatus;
}
export type DashboardDefinition = string;
export interface CreateDashboardRequest {
    projectId: string;
    dashboardName: string;
    dashboardDescription?: string;
    dashboardDefinition: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateDashboardResponse {
    dashboardId: string;
    dashboardArn: string;
}
export type DatasetTypeEnum = "SESSION" | "CURATED" | "EXTERNAL" | (string & {});
export interface SessionConfig {
    sessionStartTimestamp: TimeInNanos;
    sessionEndTimestamp: TimeInNanos;
}
export interface DatasetConfig {
    session?: SessionConfig;
}
export type MetadataKey = string;
export type MetadataValue = string;
export type Metadata = {
    [key: string]: string | undefined;
};
export type DatasetSourceType = "KENDRA" | "SITEWISE" | (string & {});
export type DatasetSourceFormat = "KNOWLEDGE_BASE" | "TIMESERIES" | (string & {});
export interface KendraSourceDetail {
    knowledgeBaseArn: string;
    roleArn: string;
}
export interface SourceDetail {
    kendra?: KendraSourceDetail;
}
export interface DatasetSource {
    sourceType: DatasetSourceType;
    sourceFormat: DatasetSourceFormat;
    sourceDetail?: SourceDetail;
}
export interface CreateDatasetRequest {
    datasetId?: string;
    datasetName: string;
    datasetDescription?: string;
    datasetType?: DatasetTypeEnum;
    datasetConfig?: DatasetConfig;
    workspaceName?: string;
    metadata?: {
        [key: string]: string | undefined;
    };
    datasetSource: DatasetSource;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type DatasetState = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export interface DatasetStatus {
    state: DatasetState;
    error?: ErrorDetails;
}
export interface CreateDatasetResponse {
    datasetId: string;
    datasetArn: string;
    datasetStatus: DatasetStatus;
}
export type S3Uri = string;
export interface TrimSettings {
    startTime: TimeInNanos;
    endTime: TimeInNanos;
}
export type PositiveInteger = number;
export interface FormatSettings {
    framesPerSecond?: number;
    widthInPixels?: number;
    heightInPixels?: number;
}
export interface TimeseriesItem {
    timeSeriesId?: string;
    propertyAlias?: string;
    trimSettings?: TrimSettings;
    formatSettings?: FormatSettings;
}
export type TimeseriesList = TimeseriesItem[];
export type DatasetId = string;
export type ExportDataType = "VIDEO" | "TELEMETRY" | "ANNOTATION" | (string & {});
export type ExportDataTypeList = ExportDataType[];
export interface DatasetItem {
    datasetId: string;
    trimSettings?: TrimSettings;
    exportDataTypes?: ExportDataType[];
}
export type ProcessingInput = {
    timeseries: TimeseriesItem[];
    dataset?: never;
} | {
    timeseries?: never;
    dataset: DatasetItem;
};
export interface ExportErrorReportLocation {
    s3Uri: string;
}
export interface CreateDatasetExportJobRequest {
    workspaceName: string;
    clientToken?: string;
    destinationS3Uri: string;
    input: ProcessingInput;
    errorReportLocation: ExportErrorReportLocation;
}
export type DatasetExportJobId = string;
export interface CreateDatasetExportJobResponse {
    jobId: string;
    workspaceName: string;
}
export interface EnrichmentTrimSettings {
    startTime: TimeInNanos;
    endTime: TimeInNanos;
}
export interface EventDetection {
    datasetId: string;
    timeSeriesId?: string;
    propertyAlias?: string;
    trimSettings: EnrichmentTrimSettings;
}
export type EnrichmentJobConfiguration = {
    eventDetection: EventDetection;
};
export interface CreateEnrichmentJobRequest {
    workspaceName: string;
    jobConfiguration: EnrichmentJobConfiguration;
    clientToken?: string;
}
export interface CreateEnrichmentJobResponse {
    jobId: string;
    status: EnrichmentJobStatus;
    createdAt: Date;
}
export type GatewayName = string;
export interface Greengrass {
    groupArn: string;
}
export type CoreDeviceThingName = string;
export type CoreDeviceOperatingSystem = "LINUX_AARCH64" | "LINUX_AMD64" | "WINDOWS_AMD64" | (string & {});
export interface GreengrassV2 {
    coreDeviceThingName: string;
    coreDeviceOperatingSystem?: CoreDeviceOperatingSystem;
}
export type IotCoreThingName = string;
export interface SiemensIE {
    iotCoreThingName: string;
}
export interface GatewayPlatform {
    greengrass?: Greengrass;
    greengrassV2?: GreengrassV2;
    siemensIE?: SiemensIE;
}
export type GatewayVersion = string;
export interface CreateGatewayRequest {
    gatewayName: string;
    gatewayPlatform: GatewayPlatform;
    gatewayVersion?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateGatewayResponse {
    gatewayId: string;
    gatewayArn: string;
}
export type EnvironmentVariableName = string;
export type EnvironmentVariableValue = string;
export type EnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export type ComputeNodeNameList = string[];
export interface ComputeNode {
    computeNodeName: string;
    taskName: string;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    dependsOn?: string[];
}
export type ComputeNodeList = ComputeNode[];
export interface CreatePipelineRequest {
    workspaceName: string;
    pipelineName: string;
    description?: string;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    computations: ComputeNode[];
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export type ResourceErrorCode = "VALIDATION_ERROR" | "INTERNAL_FAILURE" | (string & {});
export interface ResourceError {
    code?: ResourceErrorCode;
    message?: string;
}
export type ResourceState = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export interface ResourceStatus {
    error?: ResourceError;
    state?: ResourceState;
}
export interface CreatePipelineResponse {
    pipelineName: string;
    pipelineArn: string;
    version: string;
    status: ResourceStatus;
}
export type Email = string | redacted.Redacted<string>;
export type ImageFileData = Uint8Array;
export type ImageFileType = "PNG" | (string & {});
export interface ImageFile {
    data: Uint8Array;
    type: ImageFileType;
}
export type AuthMode = "IAM" | "SSO" | (string & {});
export interface Alarms {
    alarmRoleArn: string;
    notificationLambdaArn?: string;
}
export type PortalType = "SITEWISE_PORTAL_V1" | "SITEWISE_PORTAL_V2" | (string & {});
export type PortalTypeKey = string;
export type PortalTools = string[];
export interface PortalTypeEntry {
    portalTools?: string[];
}
export type PortalTypeConfiguration = {
    [key: string]: PortalTypeEntry | undefined;
};
export interface CreatePortalRequest {
    portalName: string;
    portalDescription?: string;
    portalContactEmail: string | redacted.Redacted<string>;
    clientToken?: string;
    portalLogoImageFile?: ImageFile;
    roleArn: string;
    tags?: {
        [key: string]: string | undefined;
    };
    portalAuthMode?: AuthMode;
    notificationSenderEmail?: string | redacted.Redacted<string>;
    alarms?: Alarms;
    portalType?: PortalType;
    portalTypeConfiguration?: {
        [key: string]: PortalTypeEntry | undefined;
    };
}
export type Url = string;
export type PortalState = "CREATING" | "PENDING" | "UPDATING" | "DELETING" | "ACTIVE" | "FAILED" | (string & {});
export type MonitorErrorCode = "INTERNAL_FAILURE" | "VALIDATION_ERROR" | "LIMIT_EXCEEDED" | (string & {});
export type MonitorErrorMessage = string;
export interface MonitorErrorDetails {
    code?: MonitorErrorCode;
    message?: string;
}
export interface PortalStatus {
    state: PortalState;
    error?: MonitorErrorDetails;
}
export type SSOApplicationId = string;
export interface CreatePortalResponse {
    portalId: string;
    portalArn: string;
    portalStartUrl: string;
    portalStatus: PortalStatus;
    ssoApplicationId: string;
}
export interface CreateProjectRequest {
    portalId: string;
    projectName: string;
    projectDescription?: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateProjectResponse {
    projectId: string;
    projectArn: string;
}
export type EcrUri = string | redacted.Redacted<string>;
export type IamRoleArn = string | redacted.Redacted<string>;
export type ProcessingType = "GENERIC_COMPUTE_PROCESSING" | "HARDWARE_ACCELERATED_PROCESSING" | (string & {});
export type ProcessingUnit = "UNITS_2" | "UNITS_4" | "UNITS_8" | "UNITS_12" | "UNITS_16" | "UNITS_24" | "UNITS_32" | "UNITS_36" | "UNITS_48" | "UNITS_60" | "UNITS_64" | "UNITS_72" | "UNITS_84" | "UNITS_96" | (string & {});
export type StorageClass = "STANDARD_1" | "STANDARD_2" | "THROUGHPUT_1" | "THROUGHPUT_2" | (string & {});
export type EphemeralStorageConfigurationStorageSizeInGiBInteger = number;
export interface EphemeralStorageConfiguration {
    storageClass: StorageClass;
    storageSizeInGiB: number;
}
export type CommandList = string[];
export type TimeoutSeconds = number;
export type MountRelativePath = string;
export type MountS3AccessPointArn = string;
export type MountS3KeyPrefix = string;
export interface S3AccessPointSource {
    accessPointArn: string;
    prefix?: string;
}
export type MountSource = {
    s3AccessPoint: S3AccessPointSource;
};
export type MountStorageType = "SHARED_STORAGE" | (string & {});
export interface Mount {
    name: string;
    relativePath: string;
    source: MountSource;
    storageType: MountStorageType;
}
export type MountList = Mount[];
export interface ContainerTaskConfiguration {
    ecrUri: string | redacted.Redacted<string>;
    taskExecutionRole: string | redacted.Redacted<string>;
    processingType: ProcessingType;
    processingUnit: ProcessingUnit;
    ephemeralStorageConfiguration?: EphemeralStorageConfiguration;
    command?: string[];
    timeoutSeconds?: number;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    mounts?: Mount[];
}
export type TaskConfiguration = {
    containerTaskConfiguration: ContainerTaskConfiguration;
};
export interface CreateTaskRequest {
    workspaceName: string;
    taskName: string;
    description?: string;
    taskConfiguration: TaskConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export interface CreateTaskResponse {
    taskName: string;
    taskArn: string;
    version: string;
    status: ResourceStatus;
}
export type EncryptionType = "SITEWISE_DEFAULT_ENCRYPTION" | "KMS_BASED_ENCRYPTION" | (string & {});
export type KmsKeyId = string;
export interface WorkspaceEncryptionConfiguration {
    encryptionType: EncryptionType;
    kmsKeyId?: string;
}
export interface CreateWorkspaceRequest {
    workspaceName: string;
    workspaceDescription?: string;
    encryptionConfiguration: WorkspaceEncryptionConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export type WorkspaceState = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export interface WorkspaceErrorDetails {
    code: ErrorCode;
    message: string;
}
export interface WorkspaceStatus {
    state: WorkspaceState;
    error?: WorkspaceErrorDetails;
}
export interface CreateWorkspaceResponse {
    workspaceName: string;
    workspaceArn: string;
    workspaceStatus: WorkspaceStatus;
}
export interface DeleteAccessPolicyRequest {
    accessPolicyId: string;
    clientToken?: string;
}
export interface DeleteAccessPolicyResponse {
}
export interface DeleteApplicationRequest {
    workspaceName: string;
    id: string;
}
export interface DeleteApplicationResponse {
}
export interface DeleteAssetRequest {
    assetId: string;
    clientToken?: string;
}
export interface DeleteAssetResponse {
    assetId?: string;
    assetStatus: AssetStatus;
}
export interface DeleteAssetModelRequest {
    assetModelId: string;
    clientToken?: string;
    ifMatch?: string;
    ifNoneMatch?: string;
    matchForVersionType?: AssetModelVersionType;
}
export interface DeleteAssetModelResponse {
    assetModelId?: string;
    assetModelStatus: AssetModelStatus;
}
export interface DeleteAssetModelCompositeModelRequest {
    assetModelId: string;
    assetModelCompositeModelId: string;
    clientToken?: string;
    ifMatch?: string;
    ifNoneMatch?: string;
    matchForVersionType?: AssetModelVersionType;
}
export interface DeleteAssetModelCompositeModelResponse {
    assetModelStatus: AssetModelStatus;
    assetModelId?: string;
}
export interface DeleteAssetModelInterfaceRelationshipRequest {
    assetModelId: string;
    interfaceAssetModelId: string;
    clientToken?: string;
}
export interface DeleteAssetModelInterfaceRelationshipResponse {
    assetModelId: string;
    interfaceAssetModelId: string;
    assetModelArn: string;
    assetModelStatus: AssetModelStatus;
}
export interface DeleteComputationModelRequest {
    computationModelId: string;
    clientToken?: string;
}
export interface DeleteComputationModelResponse {
    computationModelStatus: ComputationModelStatus;
}
export interface DeleteDashboardRequest {
    dashboardId: string;
    clientToken?: string;
}
export interface DeleteDashboardResponse {
}
export interface DeleteDatasetRequest {
    datasetId: string;
    workspaceName?: string;
    clientToken?: string;
}
export interface DeleteDatasetResponse {
    datasetStatus: DatasetStatus;
}
export interface DeleteGatewayRequest {
    gatewayId: string;
}
export interface DeleteGatewayResponse {
}
export interface DeletePipelineRequest {
    workspaceName: string;
    pipelineName: string;
}
export interface DeletePipelineResponse {
    status: ResourceStatus;
}
export interface DeletePortalRequest {
    portalId: string;
    clientToken?: string;
}
export interface DeletePortalResponse {
    portalStatus: PortalStatus;
}
export interface DeleteProjectRequest {
    projectId: string;
    clientToken?: string;
}
export interface DeleteProjectResponse {
}
export interface DeleteTaskRequest {
    workspaceName: string;
    taskName: string;
}
export interface DeleteTaskResponse {
    status: ResourceStatus;
}
export interface DeleteTimeSeriesRequest {
    alias?: string;
    assetId?: string;
    propertyId?: string;
    clientToken?: string;
    workspaceName?: string;
}
export interface DeleteTimeSeriesResponse {
}
export interface DeleteWorkspaceRequest {
    workspaceName: string;
    clientToken?: string;
}
export interface DeleteWorkspaceResponse {
    workspaceStatus: WorkspaceStatus;
}
export interface DescribeAccessPolicyRequest {
    accessPolicyId: string;
}
export interface DescribeAccessPolicyResponse {
    accessPolicyId: string;
    accessPolicyArn: string;
    accessPolicyIdentity: Identity;
    accessPolicyResource: Resource;
    accessPolicyPermission: Permission;
    accessPolicyCreationDate: Date;
    accessPolicyLastUpdateDate: Date;
}
export interface DescribeActionRequest {
    actionId: string;
}
export interface TargetResource {
    assetId?: string;
    computationModelId?: string;
}
export type ActionPayloadString = string;
export interface ActionPayload {
    stringValue: string;
}
export interface ResolveTo {
    assetId: string;
}
export interface DescribeActionResponse {
    actionId: string;
    targetResource: TargetResource;
    actionDefinitionId: string;
    actionPayload: ActionPayload;
    executionTime: Date;
    resolveTo?: ResolveTo;
}
export interface DescribeApplicationRequest {
    workspaceName: string;
    id: string;
}
export type ApplicationDescription = string;
export interface DescribeApplicationResponse {
    arn: string;
    createdAt: Date;
    dnsSubdomain: string;
    description?: string;
    id: string;
    idcApplicationArn: string;
    name: string;
    status: ApplicationStatus;
    updatedAt: Date;
    workspaceName: string;
}
export type ExcludeProperties = boolean;
export interface DescribeAssetRequest {
    assetId: string;
    excludeProperties?: boolean;
}
export type PropertyNotificationTopic = string;
export type PropertyNotificationState = "ENABLED" | "DISABLED" | (string & {});
export interface PropertyNotification {
    topic: string;
    state: PropertyNotificationState;
}
export interface AssetPropertyPathSegment {
    id?: string;
    name?: string;
}
export type AssetPropertyPath = AssetPropertyPathSegment[];
export interface AssetProperty {
    id: string;
    externalId?: string;
    name: string;
    alias?: string;
    notification?: PropertyNotification;
    dataType: PropertyDataType;
    dataTypeSpec?: string;
    unit?: string;
    path?: AssetPropertyPathSegment[];
}
export type AssetProperties = AssetProperty[];
export interface AssetHierarchy {
    id?: string;
    externalId?: string;
    name: string;
}
export type AssetHierarchies = AssetHierarchy[];
export interface AssetCompositeModel {
    name: string;
    description?: string;
    type: string;
    properties: AssetProperty[];
    id?: string;
    externalId?: string;
}
export type AssetCompositeModels = AssetCompositeModel[];
export interface AssetCompositeModelPathSegment {
    id?: string;
    name?: string;
}
export type AssetCompositeModelPath = AssetCompositeModelPathSegment[];
export interface AssetCompositeModelSummary {
    id: string;
    externalId?: string;
    name: string;
    type: string;
    description: string;
    path: AssetCompositeModelPathSegment[];
}
export type AssetCompositeModelSummaries = AssetCompositeModelSummary[];
export interface DescribeAssetResponse {
    assetId: string;
    assetExternalId?: string;
    assetArn: string;
    assetName: string;
    assetModelId: string;
    assetProperties: AssetProperty[];
    assetHierarchies: AssetHierarchy[];
    assetCompositeModels?: AssetCompositeModel[];
    assetCreationDate: Date;
    assetLastUpdateDate: Date;
    assetStatus: AssetStatus;
    assetDescription?: string;
    assetCompositeModelSummaries?: AssetCompositeModelSummary[];
}
export interface DescribeAssetCompositeModelRequest {
    assetId: string;
    assetCompositeModelId: string;
}
export interface ActionDefinition {
    actionDefinitionId: string;
    actionName: string;
    actionType: string;
}
export type ActionDefinitions = ActionDefinition[];
export interface DescribeAssetCompositeModelResponse {
    assetId: string;
    assetCompositeModelId: string;
    assetCompositeModelExternalId?: string;
    assetCompositeModelPath: AssetCompositeModelPathSegment[];
    assetCompositeModelName: string;
    assetCompositeModelDescription: string;
    assetCompositeModelType: string;
    assetCompositeModelProperties: AssetProperty[];
    assetCompositeModelSummaries: AssetCompositeModelSummary[];
    actionDefinitions?: ActionDefinition[];
}
export type AssetModelVersionFilter = string;
export interface DescribeAssetModelRequest {
    assetModelId: string;
    excludeProperties?: boolean;
    assetModelVersion?: string;
}
export interface AssetModelProperty {
    id?: string;
    externalId?: string;
    name: string;
    dataType: PropertyDataType;
    dataTypeSpec?: string;
    unit?: string;
    type: PropertyType;
    path?: AssetModelPropertyPathSegment[];
}
export type AssetModelProperties = AssetModelProperty[];
export interface AssetModelHierarchy {
    id?: string;
    externalId?: string;
    name: string;
    childAssetModelId: string;
}
export type AssetModelHierarchies = AssetModelHierarchy[];
export interface AssetModelCompositeModel {
    name: string;
    description?: string;
    type: string;
    properties?: AssetModelProperty[];
    id?: string;
    externalId?: string;
}
export type AssetModelCompositeModels = AssetModelCompositeModel[];
export interface AssetModelCompositeModelSummary {
    id: string;
    externalId?: string;
    name: string;
    type: string;
    description?: string;
    path?: AssetModelCompositeModelPathSegment[];
}
export type AssetModelCompositeModelSummaries = AssetModelCompositeModelSummary[];
export interface InterfaceRelationship {
    id: string;
}
export type InterfaceDetails = InterfaceRelationship[];
export interface DescribeAssetModelResponse {
    assetModelId: string;
    assetModelExternalId?: string;
    assetModelArn: string;
    assetModelName: string;
    assetModelType?: AssetModelType;
    assetModelDescription: string;
    assetModelProperties: AssetModelProperty[];
    assetModelHierarchies: AssetModelHierarchy[];
    assetModelCompositeModels?: AssetModelCompositeModel[];
    assetModelCompositeModelSummaries?: AssetModelCompositeModelSummary[];
    assetModelCreationDate: Date;
    assetModelLastUpdateDate: Date;
    assetModelStatus: AssetModelStatus;
    assetModelVersion?: string;
    interfaceDetails?: InterfaceRelationship[];
    eTag?: string;
}
export interface DescribeAssetModelCompositeModelRequest {
    assetModelId: string;
    assetModelCompositeModelId: string;
    assetModelVersion?: string;
}
export interface CompositionRelationshipItem {
    id?: string;
}
export type CompositionRelationship = CompositionRelationshipItem[];
export interface CompositionDetails {
    compositionRelationship?: CompositionRelationshipItem[];
}
export interface DescribeAssetModelCompositeModelResponse {
    assetModelId: string;
    assetModelCompositeModelId: string;
    assetModelCompositeModelExternalId?: string;
    assetModelCompositeModelPath: AssetModelCompositeModelPathSegment[];
    assetModelCompositeModelName: string;
    assetModelCompositeModelDescription: string;
    assetModelCompositeModelType: string;
    assetModelCompositeModelProperties: AssetModelProperty[];
    compositionDetails?: CompositionDetails;
    assetModelCompositeModelSummaries: AssetModelCompositeModelSummary[];
    actionDefinitions?: ActionDefinition[];
}
export interface DescribeAssetModelInterfaceRelationshipRequest {
    assetModelId: string;
    interfaceAssetModelId: string;
}
export interface PropertyMapping {
    assetModelPropertyId: string;
    interfaceAssetModelPropertyId: string;
}
export type PropertyMappings = PropertyMapping[];
export interface HierarchyMapping {
    assetModelHierarchyId: string;
    interfaceAssetModelHierarchyId: string;
}
export type HierarchyMappings = HierarchyMapping[];
export interface DescribeAssetModelInterfaceRelationshipResponse {
    assetModelId: string;
    interfaceAssetModelId: string;
    propertyMappings: PropertyMapping[];
    hierarchyMappings: HierarchyMapping[];
}
export interface DescribeAssetPropertyRequest {
    assetId: string;
    propertyId: string;
}
export interface Property {
    id: string;
    externalId?: string;
    name: string;
    alias?: string;
    notification?: PropertyNotification;
    dataType: PropertyDataType;
    unit?: string;
    type?: PropertyType;
    path?: AssetPropertyPathSegment[];
}
export interface CompositeModelProperty {
    name: string;
    type: string;
    assetProperty: Property;
    id?: string;
    externalId?: string;
}
export interface DescribeAssetPropertyResponse {
    assetId: string;
    assetExternalId?: string;
    assetName: string;
    assetModelId: string;
    assetProperty?: Property;
    compositeModel?: CompositeModelProperty;
}
export interface DescribeBulkImportJobRequest {
    jobId: string;
    workspaceName?: string;
}
export interface DescribeBulkImportJobResponse {
    jobId: string;
    jobName: string;
    jobStatus: JobStatus;
    jobRoleArn: string;
    files: File[];
    errorReportLocation: ErrorReportLocation;
    jobConfiguration?: JobConfiguration;
    jobCreationDate: Date;
    jobLastUpdateDate: Date;
    adaptiveIngestion?: boolean;
    deleteFilesAfterImport?: boolean;
    datasetId?: string;
    workspaceName?: string;
}
export type ComputationModelVersionFilter = string;
export interface DescribeComputationModelRequest {
    computationModelId: string;
    computationModelVersion?: string;
}
export interface DescribeComputationModelResponse {
    computationModelId: string;
    computationModelArn: string;
    computationModelName: string;
    computationModelDescription?: string;
    computationModelConfiguration: ComputationModelConfiguration;
    computationModelDataBinding: {
        [key: string]: ComputationModelDataBindingValue | undefined;
    };
    computationModelCreationDate: Date;
    computationModelLastUpdateDate: Date;
    computationModelStatus: ComputationModelStatus;
    computationModelVersion: string;
    actionDefinitions: ActionDefinition[];
}
export type ResolveToResourceType = "ASSET" | (string & {});
export interface DescribeComputationModelExecutionSummaryRequest {
    computationModelId: string;
    resolveToResourceType?: ResolveToResourceType;
    resolveToResourceId?: string;
}
export type ComputationModelExecutionSummaryKey = string;
export type ComputationModelExecutionSummaryValue = string;
export type ComputationModelExecutionSummary = {
    [key: string]: string | undefined;
};
export interface DescribeComputationModelExecutionSummaryResponse {
    computationModelId: string;
    resolveTo?: ResolveTo;
    computationModelExecutionSummary: {
        [key: string]: string | undefined;
    };
}
export interface DescribeDashboardRequest {
    dashboardId: string;
}
export interface DescribeDashboardResponse {
    dashboardId: string;
    dashboardArn: string;
    dashboardName: string;
    projectId: string;
    dashboardDescription?: string;
    dashboardDefinition: string;
    dashboardCreationDate: Date;
    dashboardLastUpdateDate: Date;
}
export interface DescribeDatasetRequest {
    datasetId: string;
    workspaceName?: string;
    datasetVersion?: string;
}
export type DatasetEnrichmentStatus = "FULLY_ENRICHED" | "PARTIALLY_ENRICHED" | "NOT_ENRICHED" | (string & {});
export interface DatasetEnrichmentEntry {
    status: DatasetEnrichmentStatus;
    lastEnrichedAt?: Date;
}
export interface DatasetEnrichment {
    video?: DatasetEnrichmentEntry;
}
export interface DescribeDatasetResponse {
    datasetId: string;
    datasetArn: string;
    datasetName: string;
    datasetDescription: string;
    datasetType?: DatasetTypeEnum;
    datasetConfig?: DatasetConfig;
    workspaceName?: string;
    metadata?: {
        [key: string]: string | undefined;
    };
    datasetSource: DatasetSource;
    datasetStatus: DatasetStatus;
    datasetCreationDate: Date;
    datasetLastUpdateDate: Date;
    datasetVersion?: string;
    enrichmentStatus?: DatasetEnrichment;
}
export interface DescribeDatasetExportJobRequest {
    workspaceName: string;
    jobId: string;
}
export type DatasetExportJobStatus = "SUBMITTED" | "RUNNING" | "COMPLETED" | "COMPLETED_WITH_ERRORS" | "FAILED" | (string & {});
export interface DescribeDatasetExportJobResponse {
    jobId: string;
    workspaceName: string;
    status: DatasetExportJobStatus;
    startedAt: Date;
    completedAt?: Date;
    destinationS3Uri: string;
    errorReportLocation: ExportErrorReportLocation;
    input: ProcessingInput;
}
export interface DescribeDefaultEncryptionConfigurationRequest {
}
export type ConfigurationState = "ACTIVE" | "UPDATE_IN_PROGRESS" | "UPDATE_FAILED" | (string & {});
export interface ConfigurationErrorDetails {
    code: ErrorCode;
    message: string;
}
export interface ConfigurationStatus {
    state: ConfigurationState;
    error?: ConfigurationErrorDetails;
}
export interface DescribeDefaultEncryptionConfigurationResponse {
    encryptionType: EncryptionType;
    kmsKeyArn?: string;
    configurationStatus: ConfigurationStatus;
}
export interface DescribeEnrichmentJobRequest {
    workspaceName: string;
    jobId: string;
}
export type JobType = "EVENT_DETECTION" | (string & {});
export interface DescribeEnrichmentJobResponse {
    jobId: string;
    status: EnrichmentJobStatus;
    workspaceName: string;
    jobType: JobType;
    jobConfiguration: EnrichmentJobConfiguration;
    createdAt: Date;
    updatedAt?: Date;
    completedAt?: Date;
    cancelledAt?: Date;
    failureMessage?: string;
}
export interface DescribeExecutionRequest {
    executionId: string;
}
export type ExecutionState = "RUNNING" | "COMPLETED" | "FAILED" | (string & {});
export interface ExecutionStatus {
    state: ExecutionState;
}
export type ExecutionResultKey = string;
export type ExecutionResultValue = string;
export type ExecutionResult = {
    [key: string]: string | undefined;
};
export type ExecutionDetailsKey = string;
export type ExecutionDetailsValue = string;
export type ExecutionDetails = {
    [key: string]: string | undefined;
};
export interface DescribeExecutionResponse {
    executionId: string;
    actionType?: string;
    targetResource: TargetResource;
    targetResourceVersion: string;
    resolveTo?: ResolveTo;
    executionStartTime: Date;
    executionEndTime?: Date;
    executionStatus: ExecutionStatus;
    executionResult?: {
        [key: string]: string | undefined;
    };
    executionDetails?: {
        [key: string]: string | undefined;
    };
    executionEntityVersion?: string;
}
export interface DescribeGatewayRequest {
    gatewayId: string;
}
export type CapabilityNamespace = string;
export type CapabilitySyncStatus = "IN_SYNC" | "OUT_OF_SYNC" | "SYNC_FAILED" | "UNKNOWN" | "NOT_APPLICABLE" | (string & {});
export interface GatewayCapabilitySummary {
    capabilityNamespace: string;
    capabilitySyncStatus: CapabilitySyncStatus;
}
export type GatewayCapabilitySummaries = GatewayCapabilitySummary[];
export interface DescribeGatewayResponse {
    gatewayId: string;
    gatewayName: string;
    gatewayArn: string;
    gatewayPlatform?: GatewayPlatform;
    gatewayVersion?: string;
    gatewayCapabilitySummaries: GatewayCapabilitySummary[];
    creationDate: Date;
    lastUpdateDate: Date;
}
export interface DescribeGatewayCapabilityConfigurationRequest {
    gatewayId: string;
    capabilityNamespace: string;
}
export type CapabilityConfiguration = string;
export interface DescribeGatewayCapabilityConfigurationResponse {
    gatewayId: string;
    capabilityNamespace: string;
    capabilityConfiguration: string;
    capabilitySyncStatus: CapabilitySyncStatus;
}
export interface DescribeLoggingOptionsRequest {
    workspaceName?: string;
}
export type LoggingLevel = "ERROR" | "INFO" | "OFF" | (string & {});
export interface LoggingOptions {
    level: LoggingLevel;
}
export interface DescribeLoggingOptionsResponse {
    loggingOptions: LoggingOptions;
}
export interface DescribePipelineRequest {
    workspaceName: string;
    pipelineName: string;
    pipelineVersion?: string;
}
export interface DescribePipelineResponse {
    pipelineName: string;
    workspaceName: string;
    description?: string;
    pipelineArn: string;
    version: string;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    computations: ComputeNode[];
    status: ResourceStatus;
    createdAt: Date;
    updatedAt: Date;
}
export type PaginationToken = string;
export type DescribePipelineExecutionRequestMaxResultsInteger = number;
export interface DescribePipelineExecutionRequest {
    workspaceName: string;
    pipelineName: string;
    pipelineExecutionId: string;
    nextToken?: string;
    maxResults?: number;
}
export type PipelineErrorCode = "VALIDATION_ERROR" | "INTERNAL_FAILURE" | "EXECUTION_ERROR" | "TIMED_OUT" | (string & {});
export type DetailedPipelineErrorCode = "VALIDATION_ERROR" | "INTERNAL_FAILURE" | "EXECUTION_ERROR" | "TIMED_OUT" | (string & {});
export interface DetailedPipelineError {
    code: DetailedPipelineErrorCode;
    message: string;
}
export type DetailedErrorList = DetailedPipelineError[];
export interface PipelineExecutionStateDetails {
    code?: PipelineErrorCode;
    message: string;
    details?: DetailedPipelineError[];
}
export interface PipelineExecutionStatus {
    state: PipelineExecutionState;
    stateDetails?: PipelineExecutionStateDetails;
}
export type ComputeNodeEnvironmentVariablesMap = {
    [key: string]: {
        [key: string]: string | undefined;
    } | undefined;
};
export interface ExecutionEnvironmentVariables {
    global?: {
        [key: string]: string | undefined;
    };
    computeNodes?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
}
export type ComputeNodeMountsMap = {
    [key: string]: Mount[] | undefined;
};
export interface MountOverrides {
    computeNodes: {
        [key: string]: Mount[] | undefined;
    };
}
export type ExecutionPriority = number;
export type ComputeNodeExecutionState = "NOT_STARTED" | "QUEUED" | "RUNNING" | "SUCCEEDED" | "FAILED" | (string & {});
export type ComputeNodeErrorCode = "VALIDATION_ERROR" | "INTERNAL_FAILURE" | "EXECUTION_ERROR" | "TIMED_OUT" | (string & {});
export interface ComputeNodeExecutionStateDetails {
    code: ComputeNodeErrorCode;
    message: string;
    details?: DetailedPipelineError[];
}
export interface ComputeNodeExecutionStatus {
    state: ComputeNodeExecutionState;
    stateDetails?: ComputeNodeExecutionStateDetails;
}
export type ExecutionEnvironmentVariablesMapKeyString = string;
export type ExecutionEnvironmentVariablesMapValueString = string;
export type ExecutionEnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export interface ComputeNodeExecutionDetails {
    computeNodeName: string;
    taskName: string;
    taskArn: string;
    taskVersion: string;
    dependsOn: string[];
    status: ComputeNodeExecutionStatus;
    startTime?: Date;
    endTime?: Date;
    executionEnvironmentVariables?: {
        [key: string]: string | undefined;
    };
    executionMounts?: Mount[];
}
export type ComputeNodeExecutionDetailsList = ComputeNodeExecutionDetails[];
export interface DescribePipelineExecutionResponse {
    pipelineExecutionId: string;
    pipelineName: string;
    workspaceName: string;
    pipelineVersion: string;
    status: PipelineExecutionStatus;
    startTime?: Date;
    endTime?: Date;
    requestEnvironmentVariables: ExecutionEnvironmentVariables;
    requestMountOverrides?: MountOverrides;
    executionPriority?: number;
    computeNodeExecutionDetails: ComputeNodeExecutionDetails[];
    nextToken?: string;
}
export interface DescribePortalRequest {
    portalId: string;
}
export type PortalClientId = string;
export interface ImageLocation {
    id: string;
    url: string;
}
export interface DescribePortalResponse {
    portalId: string;
    portalArn: string;
    portalName: string;
    portalDescription?: string;
    portalClientId: string;
    portalStartUrl: string;
    portalContactEmail: string | redacted.Redacted<string>;
    portalStatus: PortalStatus;
    portalCreationDate: Date;
    portalLastUpdateDate: Date;
    portalLogoImageLocation?: ImageLocation;
    roleArn?: string;
    portalAuthMode?: AuthMode;
    notificationSenderEmail?: string | redacted.Redacted<string>;
    alarms?: Alarms;
    portalType?: PortalType;
    portalTypeConfiguration?: {
        [key: string]: PortalTypeEntry | undefined;
    };
}
export interface DescribeProjectRequest {
    projectId: string;
}
export interface DescribeProjectResponse {
    projectId: string;
    projectArn: string;
    projectName: string;
    portalId: string;
    projectDescription?: string;
    projectCreationDate: Date;
    projectLastUpdateDate: Date;
}
export interface DescribeQueryRequest {
    workspaceName: string;
    queryId: string;
}
export interface QueryStatistics {
    rowCount: number;
    bytesScanned: number;
    executionTimeInMillis: number;
}
export type QueryErrorMessage = string;
export interface DescribeQueryResponse {
    queryId: string;
    status: QueryStatus;
    submittedAt: Date;
    completedAt?: Date;
    statistics?: QueryStatistics;
    errorMessage?: string;
}
export type SearchId = string;
export interface DescribeSearchRequest {
    workspaceName: string;
    searchId: string;
}
export type SearchStatus = "QUEUED" | "RUNNING" | "SUCCEEDED" | "FAILED" | (string & {});
export type SearchQueryStatement = string | redacted.Redacted<string>;
export type SearchType = "DEEP" | "QUICK" | (string & {});
export type GroupId = string;
export interface DescribeSearchResponse {
    searchId: string;
    workspaceName: string;
    status: SearchStatus;
    queryStatement: string | redacted.Redacted<string>;
    searchType: SearchType;
    statusReason?: string;
    startedAt?: Date;
    groupId?: string;
}
export interface DescribeStorageConfigurationRequest {
}
export type StorageType = "SITEWISE_DEFAULT_STORAGE" | "MULTI_LAYER_STORAGE" | (string & {});
export interface CustomerManagedS3Storage {
    s3ResourceArn: string;
    roleArn: string;
}
export interface MultiLayerStorage {
    customerManagedS3Storage: CustomerManagedS3Storage;
}
export type DisassociatedDataStorageState = "ENABLED" | "DISABLED" | (string & {});
export type NumberOfDays = number;
export type Unlimited = boolean;
export interface RetentionPeriod {
    numberOfDays?: number;
    unlimited?: boolean;
}
export type WarmTierState = "ENABLED" | "DISABLED" | (string & {});
export interface WarmTierRetentionPeriod {
    numberOfDays?: number;
    unlimited?: boolean;
}
export type DisallowIngestNullNaN = boolean;
export interface DescribeStorageConfigurationResponse {
    storageType: StorageType;
    multiLayerStorage?: MultiLayerStorage;
    disassociatedDataStorage?: DisassociatedDataStorageState;
    retentionPeriod?: RetentionPeriod;
    configurationStatus: ConfigurationStatus;
    lastUpdateDate?: Date;
    warmTier?: WarmTierState;
    warmTierRetentionPeriod?: WarmTierRetentionPeriod;
    disallowIngestNullNaN?: boolean;
}
export interface DescribeTaskRequest {
    workspaceName: string;
    taskName: string;
    taskVersion?: string;
}
export interface DescribeTaskResponse {
    workspaceName: string;
    taskName: string;
    description?: string;
    taskArn: string;
    version: string;
    taskConfiguration: TaskConfiguration;
    status: ResourceStatus;
    createdAt: Date;
    updatedAt: Date;
}
export interface DescribeTimeSeriesRequest {
    alias?: string;
    assetId?: string;
    propertyId?: string;
    workspaceName?: string;
}
export interface DescribeTimeSeriesResponse {
    assetId?: string;
    propertyId?: string;
    alias?: string;
    timeSeriesId: string;
    dataType: PropertyDataType;
    dataTypeSpec?: string;
    timeSeriesCreationDate: Date;
    timeSeriesLastUpdateDate: Date;
    timeSeriesArn: string;
    workspaceName?: string;
}
export interface DescribeWorkspaceRequest {
    workspaceName: string;
}
export interface WorkspaceEncryptionConfigurationInfo {
    encryptionType: EncryptionType;
    kmsKeyArn?: string;
}
export interface DescribeWorkspaceResponse {
    workspaceArn: string;
    workspaceName: string;
    workspaceDescription?: string;
    workspaceStatus: WorkspaceStatus;
    encryptionConfiguration?: WorkspaceEncryptionConfigurationInfo;
    createdAt: Date;
    updatedAt: Date;
}
export interface DisassociateAssetsRequest {
    assetId: string;
    hierarchyId: string;
    childAssetId: string;
    clientToken?: string;
}
export interface DisassociateAssetsResponse {
}
export interface DisassociateTimeSeriesFromAssetPropertyRequest {
    alias: string;
    assetId: string;
    propertyId: string;
    clientToken?: string;
}
export interface DisassociateTimeSeriesFromAssetPropertyResponse {
}
export interface ExecuteActionRequest {
    targetResource: TargetResource;
    actionDefinitionId: string;
    actionPayload: ActionPayload;
    clientToken?: string;
    resolveTo?: ResolveTo;
}
export interface ExecuteActionResponse {
    actionId: string;
}
export type QueryStatement = string | redacted.Redacted<string>;
export type ExecuteQueryNextToken = string;
export type ExecuteQueryMaxResults = number;
export interface ExecuteQueryRequest {
    queryStatement: string | redacted.Redacted<string>;
    nextToken?: string;
    maxResults?: number;
    clientToken?: string;
}
export type ScalarType = "BOOLEAN" | "INT" | "DOUBLE" | "TIMESTAMP" | "STRING" | (string & {});
export interface ColumnType {
    scalarType?: ScalarType;
}
export interface ColumnInfo {
    name?: string;
    type?: ColumnType;
}
export type ColumnsList = ColumnInfo[];
export type ScalarValue = string;
export interface Datum {
    scalarValue?: string;
    arrayValue?: Datum[];
    rowValue?: Row;
    nullValue?: boolean;
}
export type DatumList = Datum[];
export interface Row {
    data: Datum[];
}
export type Rows = Row[];
export interface ExecuteQueryResponse {
    columns?: ColumnInfo[];
    rows?: Row[];
    nextToken?: string;
}
export type GetAssetPropertyValueAggregatesMaxResults = number;
export interface GetAssetPropertyAggregatesRequest {
    assetId?: string;
    propertyId?: string;
    propertyAlias?: string;
    aggregateTypes: AggregateType[];
    resolution: string;
    qualities?: Quality[];
    startDate: Date;
    endDate: Date;
    timeOrdering?: TimeOrdering;
    nextToken?: string;
    maxResults?: number;
}
export interface GetAssetPropertyAggregatesResponse {
    aggregatedValues: AggregatedValue[];
    nextToken?: string;
}
export interface GetAssetPropertyValueRequest {
    assetId?: string;
    propertyId?: string;
    propertyAlias?: string;
}
export interface GetAssetPropertyValueResponse {
    propertyValue?: AssetPropertyValue;
}
export type GetAssetPropertyValueHistoryMaxResults = number;
export interface GetAssetPropertyValueHistoryRequest {
    assetId?: string;
    propertyId?: string;
    propertyAlias?: string;
    startDate?: Date;
    endDate?: Date;
    qualities?: Quality[];
    timeOrdering?: TimeOrdering;
    nextToken?: string;
    maxResults?: number;
}
export interface GetAssetPropertyValueHistoryResponse {
    assetPropertyValueHistory: AssetPropertyValue[];
    nextToken?: string;
}
export type GetCaptureDataNextToken = string;
export interface GetCaptureDataRequest {
    workspaceName: string;
    startTime: TimeInNanos;
    endTime: TimeInNanos;
    timeSeriesId?: string;
    propertyAlias?: string;
    formatSettings?: FormatSettings;
    nextToken?: string;
}
export type CaptureBlob = Uint8Array;
export type VideoDataType = "VIDEO-MP4" | (string & {});
export interface GetCaptureDataResponse {
    data: Uint8Array;
    startTime: TimeInNanos;
    endTime: TimeInNanos;
    dataType: VideoDataType;
    nextToken?: string;
}
export type IntervalInSeconds = number;
export type MaxInterpolatedResults = number;
export type InterpolationType = string;
export type IntervalWindowInSeconds = number;
export interface GetInterpolatedAssetPropertyValuesRequest {
    assetId?: string;
    propertyId?: string;
    propertyAlias?: string;
    startTimeInSeconds: number;
    startTimeOffsetInNanos?: number;
    endTimeInSeconds: number;
    endTimeOffsetInNanos?: number;
    quality: Quality;
    intervalInSeconds: number;
    nextToken?: string;
    maxResults?: number;
    type: string;
    intervalWindowInSeconds?: number;
}
export interface InterpolatedAssetPropertyValue {
    timestamp: TimeInNanos;
    value: Variant;
}
export type InterpolatedAssetPropertyValues = InterpolatedAssetPropertyValue[];
export interface GetInterpolatedAssetPropertyValuesResponse {
    interpolatedAssetPropertyValues: InterpolatedAssetPropertyValue[];
    nextToken?: string;
}
export type QueryMaxResults = number;
export type QueryNextToken = string;
export interface GetQueryResultsRequest {
    workspaceName: string;
    queryId: string;
    maxResults?: number;
    nextToken?: string;
}
export type ColumnLabel = string;
export type ColumnDataType = string;
export interface ColumnInformation {
    name: string;
    type: string;
}
export type ColumnInformationList = ColumnInformation[];
export type ColumnValue = string;
export type Result = string[];
export type RowList = string[][];
export interface GetQueryResultsResponse {
    columnInfo?: ColumnInformation[];
    rows?: string[][];
    nextToken?: string;
}
export type GetSearchResultsRequestMaxResultsInteger = number;
export interface GetSearchResultsRequest {
    searchId: string;
    workspaceName: string;
    maxResults?: number;
    nextToken?: string;
}
export interface SearchResult {
    searchId: string;
    workspaceName: string;
    datasetId: string;
    timeSeriesId: string;
    startTimestamp: TimeInNanos;
    endTimestamp: TimeInNanos;
    topTimestamp: TimeInNanos;
    score: number;
}
export type SearchResultList = SearchResult[];
export interface GetSearchResultsResponse {
    searchResults: SearchResult[];
    nextToken?: string;
}
export type ConversationId = string;
export type MessageInput = string | redacted.Redacted<string>;
export interface InvokeAssistantRequest {
    conversationId?: string;
    message: string | redacted.Redacted<string>;
    enableTrace?: boolean;
}
export interface Trace {
    text?: string;
}
export interface Location {
    uri?: string;
}
export interface Source {
    arn?: string;
    location?: Location;
}
export interface DataSetReference {
    datasetArn?: string;
    source?: Source;
}
export interface Reference {
    dataset?: DataSetReference;
}
export interface Content {
    text?: string;
}
export interface Citation {
    reference?: Reference;
    content?: Content;
}
export type Citations = Citation[];
export interface InvocationOutput {
    message?: string;
    citations?: Citation[];
}
export type ResourceId = string;
export type ResourceArn = string;
export type ResponseStream = {
    trace: Trace;
    output?: never;
    accessDeniedException?: never;
    conflictingOperationException?: never;
    internalFailureException?: never;
    invalidRequestException?: never;
    limitExceededException?: never;
    resourceNotFoundException?: never;
    throttlingException?: never;
} | {
    trace?: never;
    output: InvocationOutput;
    accessDeniedException?: never;
    conflictingOperationException?: never;
    internalFailureException?: never;
    invalidRequestException?: never;
    limitExceededException?: never;
    resourceNotFoundException?: never;
    throttlingException?: never;
} | {
    trace?: never;
    output?: never;
    accessDeniedException: AccessDeniedException;
    conflictingOperationException?: never;
    internalFailureException?: never;
    invalidRequestException?: never;
    limitExceededException?: never;
    resourceNotFoundException?: never;
    throttlingException?: never;
} | {
    trace?: never;
    output?: never;
    accessDeniedException?: never;
    conflictingOperationException: ConflictingOperationException;
    internalFailureException?: never;
    invalidRequestException?: never;
    limitExceededException?: never;
    resourceNotFoundException?: never;
    throttlingException?: never;
} | {
    trace?: never;
    output?: never;
    accessDeniedException?: never;
    conflictingOperationException?: never;
    internalFailureException: InternalFailureException;
    invalidRequestException?: never;
    limitExceededException?: never;
    resourceNotFoundException?: never;
    throttlingException?: never;
} | {
    trace?: never;
    output?: never;
    accessDeniedException?: never;
    conflictingOperationException?: never;
    internalFailureException?: never;
    invalidRequestException: InvalidRequestException;
    limitExceededException?: never;
    resourceNotFoundException?: never;
    throttlingException?: never;
} | {
    trace?: never;
    output?: never;
    accessDeniedException?: never;
    conflictingOperationException?: never;
    internalFailureException?: never;
    invalidRequestException?: never;
    limitExceededException: LimitExceededException;
    resourceNotFoundException?: never;
    throttlingException?: never;
} | {
    trace?: never;
    output?: never;
    accessDeniedException?: never;
    conflictingOperationException?: never;
    internalFailureException?: never;
    invalidRequestException?: never;
    limitExceededException?: never;
    resourceNotFoundException: ResourceNotFoundException;
    throttlingException?: never;
} | {
    trace?: never;
    output?: never;
    accessDeniedException?: never;
    conflictingOperationException?: never;
    internalFailureException?: never;
    invalidRequestException?: never;
    limitExceededException?: never;
    resourceNotFoundException?: never;
    throttlingException: ThrottlingException;
};
export interface InvokeAssistantResponse {
    body: stream.Stream<ResponseStream, Error, never>;
    conversationId: string;
}
export type IdentityType = "USER" | "GROUP" | "IAM" | (string & {});
export type ResourceType = "PORTAL" | "PROJECT" | (string & {});
export type MaxResults = number;
export interface ListAccessPoliciesRequest {
    identityType?: IdentityType;
    identityId?: string;
    resourceType?: ResourceType;
    resourceId?: string;
    iamArn?: string;
    nextToken?: string;
    maxResults?: number;
}
export interface AccessPolicySummary {
    id: string;
    identity: Identity;
    resource: Resource;
    permission: Permission;
    creationDate?: Date;
    lastUpdateDate?: Date;
}
export type AccessPolicySummaries = AccessPolicySummary[];
export interface ListAccessPoliciesResponse {
    accessPolicySummaries: AccessPolicySummary[];
    nextToken?: string;
}
export type TargetResourceType = "ASSET" | "COMPUTATION_MODEL" | (string & {});
export interface ListActionsRequest {
    targetResourceType: TargetResourceType;
    targetResourceId: string;
    nextToken?: string;
    maxResults?: number;
    resolveToResourceType?: ResolveToResourceType;
    resolveToResourceId?: string;
}
export interface ActionSummary {
    actionId?: string;
    actionDefinitionId?: string;
    targetResource?: TargetResource;
    resolveTo?: ResolveTo;
}
export type ActionSummaries = ActionSummary[];
export interface ListActionsResponse {
    actionSummaries: ActionSummary[];
    nextToken: string;
}
export interface ListApplicationsRequest {
    maxResults?: number;
    nextToken?: string;
}
export interface ApplicationSummary {
    arn: string;
    id: string;
    name: string;
    status: ApplicationStatus;
    createdAt: Date;
    workspaceName: string;
}
export type ApplicationList = ApplicationSummary[];
export interface ListApplicationsResponse {
    nextToken?: string;
    applications: ApplicationSummary[];
}
export interface ListAssetModelCompositeModelsRequest {
    assetModelId: string;
    nextToken?: string;
    maxResults?: number;
    assetModelVersion?: string;
}
export interface ListAssetModelCompositeModelsResponse {
    assetModelCompositeModelSummaries: AssetModelCompositeModelSummary[];
    nextToken?: string;
}
export type ListAssetModelPropertiesFilter = "ALL" | "BASE" | (string & {});
export interface ListAssetModelPropertiesRequest {
    assetModelId: string;
    nextToken?: string;
    maxResults?: number;
    filter?: ListAssetModelPropertiesFilter;
    assetModelVersion?: string;
}
export interface InterfaceSummary {
    interfaceAssetModelId: string;
    interfaceAssetModelPropertyId: string;
}
export type InterfaceSummaries = InterfaceSummary[];
export interface AssetModelPropertySummary {
    id?: string;
    externalId?: string;
    name: string;
    dataType: PropertyDataType;
    dataTypeSpec?: string;
    unit?: string;
    type: PropertyType;
    assetModelCompositeModelId?: string;
    path?: AssetModelPropertyPathSegment[];
    interfaceSummaries?: InterfaceSummary[];
}
export type AssetModelPropertySummaries = AssetModelPropertySummary[];
export interface ListAssetModelPropertiesResponse {
    assetModelPropertySummaries: AssetModelPropertySummary[];
    nextToken?: string;
}
export type ListAssetModelsTypeFilter = AssetModelType[];
export interface ListAssetModelsRequest {
    assetModelTypes?: AssetModelType[];
    nextToken?: string;
    maxResults?: number;
    assetModelVersion?: string;
}
export interface AssetModelSummary {
    id: string;
    externalId?: string;
    arn: string;
    name: string;
    assetModelType?: AssetModelType;
    description?: string;
    creationDate: Date;
    lastUpdateDate: Date;
    status: AssetModelStatus;
    version?: string;
}
export type AssetModelSummaries = AssetModelSummary[];
export interface ListAssetModelsResponse {
    assetModelSummaries: AssetModelSummary[];
    nextToken?: string;
}
export type ListAssetPropertiesFilter = "ALL" | "BASE" | (string & {});
export interface ListAssetPropertiesRequest {
    assetId: string;
    nextToken?: string;
    maxResults?: number;
    filter?: ListAssetPropertiesFilter;
}
export interface AssetPropertySummary {
    id: string;
    externalId?: string;
    alias?: string;
    unit?: string;
    notification?: PropertyNotification;
    assetCompositeModelId?: string;
    path?: AssetPropertyPathSegment[];
}
export type AssetPropertySummaries = AssetPropertySummary[];
export interface ListAssetPropertiesResponse {
    assetPropertySummaries: AssetPropertySummary[];
    nextToken?: string;
}
export type TraversalType = "PATH_TO_ROOT" | (string & {});
export interface ListAssetRelationshipsRequest {
    assetId: string;
    traversalType: TraversalType;
    nextToken?: string;
    maxResults?: number;
}
export interface AssetHierarchyInfo {
    parentAssetId?: string;
    childAssetId?: string;
}
export type AssetRelationshipType = "HIERARCHY" | (string & {});
export interface AssetRelationshipSummary {
    hierarchyInfo?: AssetHierarchyInfo;
    relationshipType: AssetRelationshipType;
}
export type AssetRelationshipSummaries = AssetRelationshipSummary[];
export interface ListAssetRelationshipsResponse {
    assetRelationshipSummaries: AssetRelationshipSummary[];
    nextToken?: string;
}
export type ListAssetsFilter = "ALL" | "TOP_LEVEL" | (string & {});
export interface ListAssetsRequest {
    nextToken?: string;
    maxResults?: number;
    assetModelId?: string;
    filter?: ListAssetsFilter;
}
export interface AssetSummary {
    id: string;
    externalId?: string;
    arn: string;
    name: string;
    assetModelId: string;
    creationDate: Date;
    lastUpdateDate: Date;
    status: AssetStatus;
    hierarchies: AssetHierarchy[];
    description?: string;
}
export type AssetSummaries = AssetSummary[];
export interface ListAssetsResponse {
    assetSummaries: AssetSummary[];
    nextToken?: string;
}
export type TraversalDirection = "PARENT" | "CHILD" | (string & {});
export interface ListAssociatedAssetsRequest {
    assetId: string;
    hierarchyId?: string;
    traversalDirection?: TraversalDirection;
    nextToken?: string;
    maxResults?: number;
}
export interface AssociatedAssetsSummary {
    id: string;
    externalId?: string;
    arn: string;
    name: string;
    assetModelId: string;
    creationDate: Date;
    lastUpdateDate: Date;
    status: AssetStatus;
    hierarchies: AssetHierarchy[];
    description?: string;
}
export type AssociatedAssetsSummaries = AssociatedAssetsSummary[];
export interface ListAssociatedAssetsResponse {
    assetSummaries: AssociatedAssetsSummary[];
    nextToken?: string;
}
export type ListBulkImportJobsFilter = "ALL" | "PENDING" | "RUNNING" | "CANCELLED" | "FAILED" | "COMPLETED_WITH_FAILURES" | "COMPLETED" | (string & {});
export interface ListBulkImportJobsRequest {
    nextToken?: string;
    maxResults?: number;
    filter?: ListBulkImportJobsFilter;
    workspaceName?: string;
}
export interface JobSummary {
    id: string;
    name: string;
    status: JobStatus;
}
export type JobSummaries = JobSummary[];
export interface ListBulkImportJobsResponse {
    jobSummaries: JobSummary[];
    nextToken?: string;
}
export interface ListCompositionRelationshipsRequest {
    assetModelId: string;
    nextToken?: string;
    maxResults?: number;
}
export interface CompositionRelationshipSummary {
    assetModelId: string;
    assetModelCompositeModelId: string;
    assetModelCompositeModelType: string;
}
export type CompositionRelationshipSummaries = CompositionRelationshipSummary[];
export interface ListCompositionRelationshipsResponse {
    compositionRelationshipSummaries: CompositionRelationshipSummary[];
    nextToken?: string;
}
export interface AssetBindingValueFilter {
    assetId: string;
}
export interface AssetModelBindingValueFilter {
    assetModelId: string;
}
export interface AssetPropertyBindingValueFilter {
    assetId: string;
    propertyId: string;
}
export interface AssetModelPropertyBindingValueFilter {
    assetModelId: string;
    propertyId: string;
}
export interface DataBindingValueFilter {
    asset?: AssetBindingValueFilter;
    assetModel?: AssetModelBindingValueFilter;
    assetProperty?: AssetPropertyBindingValueFilter;
    assetModelProperty?: AssetModelPropertyBindingValueFilter;
}
export interface ListComputationModelDataBindingUsagesRequest {
    dataBindingValueFilter: DataBindingValueFilter;
    nextToken?: string;
    maxResults?: number;
}
export type ComputationModelIdList = string[];
export interface DataBindingValue {
    assetModelProperty?: AssetModelPropertyBindingValue;
    assetProperty?: AssetPropertyBindingValue;
}
export interface MatchedDataBinding {
    value: DataBindingValue;
}
export interface ComputationModelDataBindingUsageSummary {
    computationModelIds: string[];
    matchedDataBinding: MatchedDataBinding;
}
export type ComputationModelDataBindingUsageSummaries = ComputationModelDataBindingUsageSummary[];
export interface ListComputationModelDataBindingUsagesResponse {
    dataBindingUsageSummaries: ComputationModelDataBindingUsageSummary[];
    nextToken?: string;
}
export interface ListComputationModelResolveToResourcesRequest {
    computationModelId: string;
    nextToken?: string;
    maxResults?: number;
}
export interface ComputationModelResolveToResourceSummary {
    resolveTo?: ResolveTo;
}
export type ComputationModelResolveToResourceSummaries = ComputationModelResolveToResourceSummary[];
export interface ListComputationModelResolveToResourcesResponse {
    computationModelResolveToResourceSummaries: ComputationModelResolveToResourceSummary[];
    nextToken?: string;
}
export type ComputationModelType = "ANOMALY_DETECTION" | (string & {});
export interface ListComputationModelsRequest {
    computationModelType?: ComputationModelType;
    nextToken?: string;
    maxResults?: number;
}
export interface ComputationModelSummary {
    id: string;
    arn: string;
    name: string;
    description?: string;
    type: ComputationModelType;
    creationDate: Date;
    lastUpdateDate: Date;
    status: ComputationModelStatus;
    version: string;
}
export type ComputationModelSummaries = ComputationModelSummary[];
export interface ListComputationModelsResponse {
    computationModelSummaries: ComputationModelSummary[];
    nextToken?: string;
}
export interface ListDashboardsRequest {
    projectId: string;
    nextToken?: string;
    maxResults?: number;
}
export interface DashboardSummary {
    id: string;
    name: string;
    description?: string;
    creationDate?: Date;
    lastUpdateDate?: Date;
}
export type DashboardSummaries = DashboardSummary[];
export interface ListDashboardsResponse {
    dashboardSummaries: DashboardSummary[];
    nextToken?: string;
}
export interface ListDatasetDataSegmentRelationshipsRequest {
    datasetId: string;
    workspaceName: string;
    maxResults?: number;
    nextToken?: string;
}
export interface DataSegmentRelationshipSummary {
    targetDatasetId: string;
    sourceDatasetId: string;
    timeSeriesId: string;
    startTimestamp: TimeInNanos;
    endTimestamp: TimeInNanos;
}
export type DataSegmentRelationshipSummaries = DataSegmentRelationshipSummary[];
export interface ListDatasetDataSegmentRelationshipsResponse {
    dataSegmentRelationshipSummaries: DataSegmentRelationshipSummary[];
    nextToken?: string;
}
export interface ListDatasetDataSegmentsRequest {
    datasetId: string;
    workspaceName: string;
    datasetVersion?: string;
    maxResults?: number;
    nextToken?: string;
}
export type EnrichmentStatus = "ENRICHED" | "NOT_ENRICHED" | (string & {});
export interface DataSegmentEnrichment {
    status: EnrichmentStatus;
    lastEnrichedAt?: Date;
}
export interface DataSegmentSummary {
    sourceDatasetId: string;
    timeSeriesId: string;
    startTimestamp: TimeInNanos;
    endTimestamp: TimeInNanos;
    alias: string;
    dataType: PropertyDataType;
    enrichment?: DataSegmentEnrichment;
}
export type DataSegmentSummaries = DataSegmentSummary[];
export interface ListDatasetDataSegmentsResponse {
    dataSegments: DataSegmentSummary[];
    nextToken?: string;
}
export type DatasetExportJobFilter = "ALL" | "SUBMITTED" | "RUNNING" | "COMPLETED" | "COMPLETED_WITH_ERRORS" | "FAILED" | (string & {});
export type ListExportJobsMaxResults = number;
export type ListExportJobsNextToken = string;
export interface ListDatasetExportJobsRequest {
    workspaceName: string;
    filter?: DatasetExportJobFilter;
    maxResults?: number;
    nextToken?: string;
}
export interface ExportJobSummary {
    jobId: string;
    status: DatasetExportJobStatus;
    startedAt: Date;
    completedAt?: Date;
    destinationS3Uri: string;
}
export type ExportJobSummaryList = ExportJobSummary[];
export interface ListDatasetExportJobsResponse {
    jobs: ExportJobSummary[];
    nextToken?: string;
}
export interface ListDatasetsRequest {
    sourceType: DatasetSourceType;
    workspaceName?: string;
    datasetType?: DatasetTypeEnum;
    nextToken?: string;
    maxResults?: number;
}
export interface DatasetSummary {
    id: string;
    arn: string;
    name: string;
    description: string;
    sourceType?: DatasetSourceType;
    datasetType?: DatasetTypeEnum;
    creationDate: Date;
    lastUpdateDate: Date;
    status: DatasetStatus;
    enrichmentStatus?: DatasetEnrichment;
}
export type DatasetSummaries = DatasetSummary[];
export interface ListDatasetsResponse {
    datasetSummaries: DatasetSummary[];
    nextToken?: string;
    workspaceName?: string;
}
export interface ListEnrichmentJobsRequest {
    workspaceName: string;
    datasetId?: string;
    propertyAlias?: string;
    timeSeriesId?: string;
    status?: EnrichmentJobStatus;
    jobType?: JobType;
    startDate?: Date;
    endDate?: Date;
    maxResults?: number;
    nextToken?: string;
}
export interface EnrichmentJobSummary {
    jobId: string;
    status: EnrichmentJobStatus;
    workspaceName: string;
    jobType: JobType;
    datasetId: string;
    propertyAlias?: string;
    timeSeriesId?: string;
    createdAt: Date;
    updatedAt?: Date;
}
export type EnrichmentJobSummaries = EnrichmentJobSummary[];
export interface ListEnrichmentJobsResponse {
    jobs: EnrichmentJobSummary[];
    nextToken?: string;
}
export interface ListExecutionsRequest {
    targetResourceType: TargetResourceType;
    targetResourceId: string;
    resolveToResourceType?: ResolveToResourceType;
    resolveToResourceId?: string;
    nextToken?: string;
    maxResults?: number;
    actionType?: string;
}
export interface ExecutionSummary {
    executionId: string;
    actionType?: string;
    targetResource: TargetResource;
    targetResourceVersion: string;
    resolveTo?: ResolveTo;
    executionStartTime: Date;
    executionEndTime?: Date;
    executionStatus: ExecutionStatus;
    executionEntityVersion?: string;
}
export type ExecutionSummaries = ExecutionSummary[];
export interface ListExecutionsResponse {
    executionSummaries: ExecutionSummary[];
    nextToken?: string;
}
export interface ListGatewaysRequest {
    nextToken?: string;
    maxResults?: number;
}
export interface GatewaySummary {
    gatewayId: string;
    gatewayName: string;
    gatewayPlatform?: GatewayPlatform;
    gatewayVersion?: string;
    gatewayCapabilitySummaries?: GatewayCapabilitySummary[];
    creationDate: Date;
    lastUpdateDate: Date;
}
export type GatewaySummaries = GatewaySummary[];
export interface ListGatewaysResponse {
    gatewaySummaries: GatewaySummary[];
    nextToken?: string;
}
export interface ListInterfaceRelationshipsRequest {
    interfaceAssetModelId: string;
    nextToken?: string;
    maxResults?: number;
}
export interface InterfaceRelationshipSummary {
    id: string;
}
export type InterfaceRelationshipSummaries = InterfaceRelationshipSummary[];
export interface ListInterfaceRelationshipsResponse {
    interfaceRelationshipSummaries: InterfaceRelationshipSummary[];
    nextToken?: string;
}
export type ListPipelineExecutionsRequestMaxResultsInteger = number;
export interface ListPipelineExecutionsRequest {
    workspaceName: string;
    pipelineName: string;
    nextToken?: string;
    maxResults?: number;
    state?: PipelineExecutionState;
    startTimeAfter?: Date;
    startTimeBefore?: Date;
    endTimeAfter?: Date;
    endTimeBefore?: Date;
}
export interface PipelineExecutionSummary {
    pipelineExecutionId: string;
    pipelineVersion: string;
    status: PipelineExecutionStatus;
    executionPriority?: number;
    startTime?: Date;
    endTime?: Date;
}
export type PipelineExecutionSummaryList = PipelineExecutionSummary[];
export interface ListPipelineExecutionsResponse {
    pipelineExecutionSummaries: PipelineExecutionSummary[];
    nextToken?: string;
}
export type ListPipelinesRequestMaxResultsInteger = number;
export interface ListPipelinesRequest {
    workspaceName: string;
    nextToken?: string;
    maxResults?: number;
}
export interface PipelineSummary {
    pipelineName: string;
    description?: string;
    pipelineArn: string;
    version: string;
    status: ResourceStatus;
    createdAt: Date;
    updatedAt: Date;
}
export type PipelineSummaries = PipelineSummary[];
export interface ListPipelinesResponse {
    pipelineSummaries: PipelineSummary[];
    nextToken?: string;
}
export interface ListPortalsRequest {
    nextToken?: string;
    maxResults?: number;
}
export interface PortalSummary {
    id: string;
    name: string;
    description?: string;
    startUrl: string;
    creationDate?: Date;
    lastUpdateDate?: Date;
    roleArn?: string;
    status: PortalStatus;
    portalType?: PortalType;
}
export type PortalSummaries = PortalSummary[];
export interface ListPortalsResponse {
    portalSummaries?: PortalSummary[];
    nextToken?: string;
}
export interface ListProjectAssetsRequest {
    projectId: string;
    nextToken?: string;
    maxResults?: number;
}
export type AssetIDs = string[];
export interface ListProjectAssetsResponse {
    assetIds: string[];
    nextToken?: string;
}
export interface ListProjectsRequest {
    portalId: string;
    nextToken?: string;
    maxResults?: number;
}
export interface ProjectSummary {
    id: string;
    name: string;
    description?: string;
    creationDate?: Date;
    lastUpdateDate?: Date;
}
export type ProjectSummaries = ProjectSummary[];
export interface ListProjectsResponse {
    projectSummaries: ProjectSummary[];
    nextToken?: string;
}
export type QueryFilter = string;
export type QueryListNextToken = string;
export interface ListQueriesRequest {
    workspaceName: string;
    filter?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface QuerySummary {
    queryId: string;
    status: QueryStatus;
    submittedAt: Date;
    completedAt?: Date;
}
export type QuerySummaryList = QuerySummary[];
export interface ListQueriesResponse {
    queries: QuerySummary[];
    nextToken?: string;
}
export type ListSearchesRequestMaxResultsInteger = number;
export type SearchStatusFilterList = SearchStatus[];
export type GroupIdFilterList = string[];
export type SearchTypeFilterList = SearchType[];
export interface ListSearchesFilters {
    statusFilter?: SearchStatus[];
    startedAfter?: Date;
    startedBefore?: Date;
    groupIdFilter?: string[];
    searchTypeFilter?: SearchType[];
}
export interface ListSearchesRequest {
    workspaceName: string;
    maxResults?: number;
    nextToken?: string;
    listSearchesFilters?: ListSearchesFilters;
}
export interface SearchSummary {
    searchId: string;
    workspaceName: string;
    status: SearchStatus;
    queryStatement: string | redacted.Redacted<string>;
    searchType: SearchType;
    statusReason?: string;
    startedAt?: Date;
    groupId?: string;
}
export type SearchSummaries = SearchSummary[];
export interface ListSearchesResponse {
    searchSummaries: SearchSummary[];
    nextToken?: string;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export type ListTasksRequestMaxResultsInteger = number;
export interface ListTasksRequest {
    workspaceName: string;
    nextToken?: string;
    maxResults?: number;
}
export interface TaskSummary {
    taskName: string;
    description?: string;
    taskArn: string;
    version: string;
    status: ResourceStatus;
    createdAt: Date;
    updatedAt: Date;
}
export type TaskSummaries = TaskSummary[];
export interface ListTasksResponse {
    taskSummaries: TaskSummary[];
    nextToken?: string;
}
export type ListTimeSeriesType = "ASSOCIATED" | "DISASSOCIATED" | (string & {});
export interface ListTimeSeriesRequest {
    nextToken?: string;
    maxResults?: number;
    assetId?: string;
    aliasPrefix?: string;
    timeSeriesType?: ListTimeSeriesType;
    workspaceName?: string;
}
export interface TimeSeriesSummary {
    assetId?: string;
    propertyId?: string;
    alias?: string;
    timeSeriesId: string;
    dataType: PropertyDataType;
    dataTypeSpec?: string;
    timeSeriesCreationDate: Date;
    timeSeriesLastUpdateDate: Date;
    timeSeriesArn: string;
}
export type TimeSeriesSummaries = TimeSeriesSummary[];
export interface ListTimeSeriesResponse {
    TimeSeriesSummaries: TimeSeriesSummary[];
    nextToken?: string;
    workspaceName?: string;
}
export interface ListWorkspacesRequest {
    nextToken?: string;
    maxResults?: number;
}
export interface WorkspaceSummary {
    name: string;
    arn: string;
    status: WorkspaceStatus;
    createdAt: Date;
    updatedAt: Date;
}
export type WorkspaceSummaries = WorkspaceSummary[];
export interface ListWorkspacesResponse {
    workspaceSummaries: WorkspaceSummary[];
    nextToken?: string;
}
export type MatchByPropertyName = boolean;
export type CreateMissingProperty = boolean;
export interface PropertyMappingConfiguration {
    matchByPropertyName?: boolean;
    createMissingProperty?: boolean;
    overrides?: PropertyMapping[];
}
export interface PutAssetModelInterfaceRelationshipRequest {
    assetModelId: string;
    interfaceAssetModelId: string;
    propertyMappingConfiguration: PropertyMappingConfiguration;
    clientToken?: string;
}
export interface PutAssetModelInterfaceRelationshipResponse {
    assetModelId: string;
    interfaceAssetModelId: string;
    assetModelArn: string;
    assetModelStatus: AssetModelStatus;
}
export interface PutDefaultEncryptionConfigurationRequest {
    encryptionType: EncryptionType;
    kmsKeyId?: string;
}
export interface PutDefaultEncryptionConfigurationResponse {
    encryptionType: EncryptionType;
    kmsKeyArn?: string;
    configurationStatus: ConfigurationStatus;
}
export interface PutLoggingOptionsRequest {
    loggingOptions: LoggingOptions;
    workspaceName?: string;
}
export interface PutLoggingOptionsResponse {
}
export interface PutStorageConfigurationRequest {
    storageType: StorageType;
    multiLayerStorage?: MultiLayerStorage;
    disassociatedDataStorage?: DisassociatedDataStorageState;
    retentionPeriod?: RetentionPeriod;
    warmTier?: WarmTierState;
    warmTierRetentionPeriod?: WarmTierRetentionPeriod;
    disallowIngestNullNaN?: boolean;
}
export interface PutStorageConfigurationResponse {
    storageType: StorageType;
    multiLayerStorage?: MultiLayerStorage;
    disassociatedDataStorage?: DisassociatedDataStorageState;
    retentionPeriod?: RetentionPeriod;
    configurationStatus: ConfigurationStatus;
    warmTier?: WarmTierState;
    warmTierRetentionPeriod?: WarmTierRetentionPeriod;
    disallowIngestNullNaN?: boolean;
}
export interface StartPipelineExecutionRequest {
    workspaceName: string;
    pipelineName: string;
    executionEnvironmentVariableOverrides?: ExecutionEnvironmentVariables;
    executionMountOverrides?: MountOverrides;
    executionPriority?: number;
    clientToken?: string;
}
export interface StartPipelineExecutionResponse {
    pipelineExecutionId: string;
}
export type QueryString = string | redacted.Redacted<string>;
export interface StartQueryRequest {
    clientToken?: string;
    workspaceName: string;
    queryStatement: string | redacted.Redacted<string>;
}
export interface StartQueryResponse {
    queryId: string;
    status: QueryStatus;
}
export type TimeSeriesIdList = string[];
export type DataSetIdList = string[];
export interface TimeInterval {
    startTime: TimeInNanos;
    endTime: TimeInNanos;
}
export type TimeIntervalList = TimeInterval[];
export interface SearchFilters {
    timeSeriesIds?: string[];
    datasetIds?: string[];
    timeIntervals?: TimeInterval[];
}
export interface StartSearchRequest {
    workspaceName: string;
    queryStatement: string | redacted.Redacted<string>;
    clientToken?: string;
    searchType?: SearchType;
    searchFilters?: SearchFilters;
    groupId?: string;
}
export interface StartSearchResponse {
    searchId: string;
    workspaceName: string;
    status: SearchStatus;
    groupId?: string;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAccessPolicyRequest {
    accessPolicyId: string;
    accessPolicyIdentity: Identity;
    accessPolicyResource: Resource;
    accessPolicyPermission: Permission;
    clientToken?: string;
}
export interface UpdateAccessPolicyResponse {
}
export interface UpdateAssetRequest {
    assetId: string;
    assetExternalId?: string;
    assetName: string;
    clientToken?: string;
    assetDescription?: string;
}
export interface UpdateAssetResponse {
    assetId?: string;
    assetStatus: AssetStatus;
}
export interface UpdateAssetModelRequest {
    assetModelId: string;
    assetModelExternalId?: string;
    assetModelName: string;
    assetModelDescription?: string;
    assetModelProperties?: AssetModelProperty[];
    assetModelHierarchies?: AssetModelHierarchy[];
    assetModelCompositeModels?: AssetModelCompositeModel[];
    clientToken?: string;
    ifMatch?: string;
    ifNoneMatch?: string;
    matchForVersionType?: AssetModelVersionType;
}
export interface UpdateAssetModelResponse {
    assetModelId?: string;
    assetModelStatus: AssetModelStatus;
}
export interface UpdateAssetModelCompositeModelRequest {
    assetModelId: string;
    assetModelCompositeModelId: string;
    assetModelCompositeModelExternalId?: string;
    assetModelCompositeModelDescription?: string;
    assetModelCompositeModelName: string;
    clientToken?: string;
    assetModelCompositeModelProperties?: AssetModelProperty[];
    ifMatch?: string;
    ifNoneMatch?: string;
    matchForVersionType?: AssetModelVersionType;
}
export interface UpdateAssetModelCompositeModelResponse {
    assetModelCompositeModelPath: AssetModelCompositeModelPathSegment[];
    assetModelStatus: AssetModelStatus;
    assetModelId?: string;
}
export interface UpdateAssetPropertyRequest {
    assetId: string;
    propertyId: string;
    propertyAlias?: string;
    propertyNotificationState?: PropertyNotificationState;
    clientToken?: string;
    propertyUnit?: string;
}
export interface UpdateAssetPropertyResponse {
}
export interface UpdateComputationModelRequest {
    computationModelId: string;
    computationModelName: string;
    computationModelDescription?: string;
    computationModelConfiguration: ComputationModelConfiguration;
    computationModelDataBinding: {
        [key: string]: ComputationModelDataBindingValue | undefined;
    };
    clientToken?: string;
}
export interface UpdateComputationModelResponse {
    computationModelStatus: ComputationModelStatus;
}
export interface UpdateDashboardRequest {
    dashboardId: string;
    dashboardName: string;
    dashboardDescription?: string;
    dashboardDefinition: string;
    clientToken?: string;
}
export interface UpdateDashboardResponse {
}
export interface UpdateDatasetRequest {
    datasetId: string;
    workspaceName?: string;
    datasetName: string;
    datasetDescription?: string;
    datasetConfig?: DatasetConfig;
    metadata?: {
        [key: string]: string | undefined;
    };
    datasetSource: DatasetSource;
    clientToken?: string;
}
export interface UpdateDatasetResponse {
    datasetId?: string;
    datasetArn?: string;
    datasetStatus?: DatasetStatus;
}
export interface UpdateGatewayRequest {
    gatewayId: string;
    gatewayName: string;
}
export interface UpdateGatewayResponse {
}
export interface UpdateGatewayCapabilityConfigurationRequest {
    gatewayId: string;
    capabilityNamespace: string;
    capabilityConfiguration: string;
}
export interface UpdateGatewayCapabilityConfigurationResponse {
    capabilityNamespace: string;
    capabilitySyncStatus: CapabilitySyncStatus;
}
export interface UpdatePipelineRequest {
    workspaceName: string;
    pipelineName: string;
    description?: string;
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    computations?: ComputeNode[];
}
export interface UpdatePipelineResponse {
    version: string;
    status: ResourceStatus;
}
export interface Image {
    id?: string;
    file?: ImageFile;
}
export interface UpdatePortalRequest {
    portalId: string;
    portalName: string;
    portalDescription?: string;
    portalContactEmail: string | redacted.Redacted<string>;
    portalLogoImage?: Image;
    roleArn: string;
    clientToken?: string;
    notificationSenderEmail?: string | redacted.Redacted<string>;
    alarms?: Alarms;
    portalType?: PortalType;
    portalTypeConfiguration?: {
        [key: string]: PortalTypeEntry | undefined;
    };
}
export interface UpdatePortalResponse {
    portalStatus: PortalStatus;
}
export interface UpdateProjectRequest {
    projectId: string;
    projectName: string;
    projectDescription?: string;
    clientToken?: string;
}
export interface UpdateProjectResponse {
}
export interface UpdateTaskRequest {
    workspaceName: string;
    taskName: string;
    description?: string;
    taskConfiguration?: TaskConfiguration;
}
export interface UpdateTaskResponse {
    version: string;
    status: ResourceStatus;
}
export interface UpdateWorkspaceRequest {
    workspaceName: string;
    workspaceDescription?: string;
    encryptionConfiguration?: WorkspaceEncryptionConfiguration;
    clientToken?: string;
}
export interface UpdateWorkspaceResponse {
    workspaceStatus: WorkspaceStatus;
}
export type ExceptionMessage = string;
export type AssociateAssetsError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a child asset with the given parent asset through a hierarchy defined in the
 * parent asset's model. For more information, see Associating assets in the
 * *IoT SiteWise User Guide*.
 */
export declare const associateAssets: API.OperationMethod<AssociateAssetsRequest, AssociateAssetsResponse, AssociateAssetsError, Credentials | HttpClient.HttpClient>;
export type AssociateTimeSeriesToAssetPropertyError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a time series (data stream) with an asset property.
 */
export declare const associateTimeSeriesToAssetProperty: API.OperationMethod<AssociateTimeSeriesToAssetPropertyRequest, AssociateTimeSeriesToAssetPropertyResponse, AssociateTimeSeriesToAssetPropertyError, Credentials | HttpClient.HttpClient>;
export type BatchAssociateDataSegmentsToDatasetError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a batch of data segments with a curated dataset. Data segments are
 * time-bounded slices of time series data selected from source session datasets. Data segments
 * that belong to the same time series can't overlap in time, regardless of which dataset they
 * belong to.
 */
export declare const batchAssociateDataSegmentsToDataset: API.OperationMethod<BatchAssociateDataSegmentsToDatasetRequest, BatchAssociateDataSegmentsToDatasetResponse, BatchAssociateDataSegmentsToDatasetError, Credentials | HttpClient.HttpClient>;
export type BatchAssociateProjectAssetsError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The IoT SiteWise Monitor feature will no longer be open to new
 * customers starting November 7, 2025. If you would like to use the IoT SiteWise Monitor feature, sign up prior to that date. Existing customers can
 * continue to use the service as normal. For more information, see
 * IoT SiteWise Monitor availability change.
 *
 * Associates a group (batch) of assets with an IoT SiteWise Monitor project.
 */
export declare const batchAssociateProjectAssets: API.OperationMethod<BatchAssociateProjectAssetsRequest, BatchAssociateProjectAssetsResponse, BatchAssociateProjectAssetsError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteDatasetDataSegmentsError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a batch of data segments from a session dataset. Deleting a data segment deletes
 * the underlying time series data for the segment's time range.
 */
export declare const batchDeleteDatasetDataSegments: API.OperationMethod<BatchDeleteDatasetDataSegmentsRequest, BatchDeleteDatasetDataSegmentsResponse, BatchDeleteDatasetDataSegmentsError, Credentials | HttpClient.HttpClient>;
export type BatchDisassociateDataSegmentsFromDatasetError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates a batch of data segments from a curated dataset. Disassociating a data
 * segment doesn't delete the underlying data in the source session dataset.
 */
export declare const batchDisassociateDataSegmentsFromDataset: API.OperationMethod<BatchDisassociateDataSegmentsFromDatasetRequest, BatchDisassociateDataSegmentsFromDatasetResponse, BatchDisassociateDataSegmentsFromDatasetError, Credentials | HttpClient.HttpClient>;
export type BatchDisassociateProjectAssetsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates a group (batch) of assets from an IoT SiteWise Monitor project.
 */
export declare const batchDisassociateProjectAssets: API.OperationMethod<BatchDisassociateProjectAssetsRequest, BatchDisassociateProjectAssetsResponse, BatchDisassociateProjectAssetsError, Credentials | HttpClient.HttpClient>;
export type BatchGetAssetPropertyAggregatesError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Gets aggregated values (for example, average, minimum, and maximum) for one or more asset
 * properties. For more information, see Querying aggregates in the
 * *IoT SiteWise User Guide*.
 */
export declare const batchGetAssetPropertyAggregates: API.PaginatedOperationMethod<BatchGetAssetPropertyAggregatesRequest, BatchGetAssetPropertyAggregatesResponse, BatchGetAssetPropertyAggregatesError, Credentials | HttpClient.HttpClient, unknown>;
export type BatchGetAssetPropertyValueError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Gets the current value for one or more asset properties. For more information, see Querying
 * current values in the *IoT SiteWise User Guide*.
 */
export declare const batchGetAssetPropertyValue: API.PaginatedOperationMethod<BatchGetAssetPropertyValueRequest, BatchGetAssetPropertyValueResponse, BatchGetAssetPropertyValueError, Credentials | HttpClient.HttpClient, unknown>;
export type BatchGetAssetPropertyValueHistoryError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Gets the historical values for one or more asset properties. For more information, see
 * Querying historical values in the *IoT SiteWise User Guide*.
 */
export declare const batchGetAssetPropertyValueHistory: API.PaginatedOperationMethod<BatchGetAssetPropertyValueHistoryRequest, BatchGetAssetPropertyValueHistoryResponse, BatchGetAssetPropertyValueHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type BatchPutAssetPropertyValueError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Sends a list of asset property values to IoT SiteWise. Each value is a timestamp-quality-value
 * (TQV) data point. For more information, see Ingesting data using the API in the
 * *IoT SiteWise User Guide*.
 *
 * To identify an asset property, you must specify one of the following:
 *
 * - The `assetId` and `propertyId` of an asset property.
 *
 * - A `propertyAlias`, which is a data stream alias (for example,
 * `/company/windfarm/3/turbine/7/temperature`). To define an asset property's alias, see UpdateAssetProperty.
 *
 * With respect to Unix epoch time, IoT SiteWise accepts only TQVs that have a timestamp of no more
 * than 7 days in the past and no more than 10 minutes in the future. IoT SiteWise rejects timestamps
 * outside of the inclusive range of [-7 days, +10 minutes] and returns a
 * `TimestampOutOfRangeException` error.
 *
 * For each asset property, IoT SiteWise overwrites TQVs with duplicate timestamps unless the newer
 * TQV has a different quality. For example, if you store a TQV `{T1, GOOD, V1}`,
 * then storing `{T1, GOOD, V2}` replaces the existing TQV.
 *
 * IoT SiteWise authorizes access to each `BatchPutAssetPropertyValue` entry individually.
 * For more information, see BatchPutAssetPropertyValue authorization in the
 * *IoT SiteWise User Guide*.
 */
export declare const batchPutAssetPropertyValue: API.OperationMethod<BatchPutAssetPropertyValueRequest, BatchPutAssetPropertyValueResponse, BatchPutAssetPropertyValueError, Credentials | HttpClient.HttpClient>;
export type CancelEnrichmentJobError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Cancels a running or pending enrichment job. This is an idempotent operation--calling it multiple
 * times with the same jobId is safe and returns the current status.
 *
 * Behavior
 *
 * - Jobs in PENDING or RUNNING status transition to CANCELLED
 *
 * - Jobs in RUNNING state may not be cancellable once they have progressed to certain processing stages
 *
 * - Jobs already in terminal states (COMPLETED, FAILED, TIMED_OUT) cannot be cancelled;
 * the operation returns a ConflictingOperationException
 *
 * - Cancelling an already-CANCELLED job is a no-op and returns the current status (idempotent behavior)
 *
 * - The API responds immediately after recording the cancellation
 *
 * - Cleanup of job resources happens asynchronously in the background
 *
 * When to Cancel
 *
 * Cancel a job when:
 *
 * - The job is taking longer than expected
 *
 * - The job was created with incorrect parameters
 *
 * - You no longer need the results
 *
 * Idempotency
 *
 * You can safely retry cancellation requests. Calling CancelEnrichmentJob multiple times for the same
 * job returns the current status without error as long as the job is not in a terminal state other
 * than CANCELLED.
 */
export declare const cancelEnrichmentJob: API.OperationMethod<CancelEnrichmentJobRequest, CancelEnrichmentJobResponse, CancelEnrichmentJobError, Credentials | HttpClient.HttpClient>;
export type CancelPipelineExecutionError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Cancels a pipeline execution in the specified workspace. If the execution
 * is not in a terminal state (such as NOT_STARTED or RUNNING), it transitions to
 * CANCELLING and asynchronously to CANCELLED. This operation is idempotent: calling
 * it on an execution that is already CANCELLING or CANCELLED returns success with
 * the current state. Calling it on a terminal execution (SUCCEEDED or FAILED)
 * returns a conflict error. You can optionally provide a reason; it is returned in
 * the stateDetails field when you describe the execution.
 */
export declare const cancelPipelineExecution: API.OperationMethod<CancelPipelineExecutionRequest, CancelPipelineExecutionResponse, CancelPipelineExecutionError, Credentials | HttpClient.HttpClient>;
export type CancelQueryError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Cancels a running query.
 */
export declare const cancelQuery: API.OperationMethod<CancelQueryRequest, CancelQueryResponse, CancelQueryError, Credentials | HttpClient.HttpClient>;
export type CreateAccessPolicyError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The IoT SiteWise Monitor feature will no longer be open to new
 * customers starting November 7, 2025. If you would like to use the IoT SiteWise Monitor feature, sign up prior to that date. Existing customers can
 * continue to use the service as normal. For more information, see
 * IoT SiteWise Monitor availability change.
 *
 * Creates an access policy that grants the specified identity (IAM Identity Center user, IAM Identity Center group, or
 * IAM user) access to the specified IoT SiteWise Monitor portal or project resource.
 *
 * Support for access policies that use an SSO Group as the identity is not supported at this time.
 */
export declare const createAccessPolicy: API.OperationMethod<CreateAccessPolicyRequest, CreateAccessPolicyResponse, CreateAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new application for the workspace and IdC application provided
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateAssetError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an asset from an existing asset model. For more information, see Creating assets in the
 * *IoT SiteWise User Guide*.
 */
export declare const createAsset: API.OperationMethod<CreateAssetRequest, CreateAssetResponse, CreateAssetError, Credentials | HttpClient.HttpClient>;
export type CreateAssetModelError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an asset model from specified property and hierarchy definitions. You create
 * assets from asset models. With asset models, you can easily create assets of the same type
 * that have standardized definitions. Each asset created from a model inherits the asset model's
 * property and hierarchy definitions. For more information, see Defining asset models in the
 * *IoT SiteWise User Guide*.
 *
 * You can create three types of asset models, `ASSET_MODEL`,
 * `COMPONENT_MODEL`, or an `INTERFACE`.
 *
 * - **ASSET_MODEL** - (default) An asset model that
 * you can use to create assets. Can't be included as a component in another asset
 * model.
 *
 * - **COMPONENT_MODEL** - A reusable component that
 * you can include in the composite models of other asset models. You can't create
 * assets directly from this type of asset model.
 *
 * - **INTERFACE** - An interface is a type of model
 * that defines a standard structure that can be applied to different asset models.
 */
export declare const createAssetModel: API.OperationMethod<CreateAssetModelRequest, CreateAssetModelResponse, CreateAssetModelError, Credentials | HttpClient.HttpClient>;
export type CreateAssetModelCompositeModelError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | PreconditionFailedException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a custom composite model from specified property and hierarchy definitions. There
 * are two types of custom composite models, `inline` and
 * `component-model-based`.
 *
 * Use component-model-based custom composite models to define standard, reusable components.
 * A component-model-based custom composite model consists of a name, a description, and the ID
 * of the component model it references. A component-model-based custom composite model has no
 * properties of its own; its referenced component model provides its associated properties to
 * any created assets. For more information, see Custom composite models (Components)
 * in the *IoT SiteWise User Guide*.
 *
 * Use inline custom composite models to organize the properties of an asset model. The
 * properties of inline custom composite models are local to the asset model where they are
 * included and can't be used to create multiple assets.
 *
 * To create a component-model-based model, specify the `composedAssetModelId` of
 * an existing asset model with `assetModelType` of
 * `COMPONENT_MODEL`.
 *
 * To create an inline model, specify the `assetModelCompositeModelProperties` and
 * don't include an `composedAssetModelId`.
 */
export declare const createAssetModelCompositeModel: API.OperationMethod<CreateAssetModelCompositeModelRequest, CreateAssetModelCompositeModelResponse, CreateAssetModelCompositeModelError, Credentials | HttpClient.HttpClient>;
export type CreateBulkImportJobError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Defines a job to ingest data to IoT SiteWise from Amazon S3. For more information, see Create a
 * bulk import job (CLI) in the *Amazon Simple Storage Service User Guide*.
 *
 * Before you create a bulk import job that ingests data into time series outside of a
 * workspace, you must enable IoT SiteWise warm tier or IoT SiteWise cold tier. For more information about how
 * to configure storage settings, see PutStorageConfiguration. This requirement doesn't apply to bulk import jobs that
 * ingest data into a session dataset in a workspace (jobs that specify a
 * `workspaceName` and `datasetId`). Those jobs don't use IoT SiteWise warm or
 * cold tier storage.
 *
 * Bulk import is designed to store historical data to IoT SiteWise.
 *
 * - Newly ingested data in the hot tier triggers notifications and computations.
 *
 * - After data moves from the hot tier to the warm or cold tier based on retention
 * settings, it does not trigger computations or notifications.
 *
 * - Data older than 7 days does not trigger computations or notifications.
 */
export declare const createBulkImportJob: API.OperationMethod<CreateBulkImportJobRequest, CreateBulkImportJobResponse, CreateBulkImportJobError, Credentials | HttpClient.HttpClient>;
export type CreateComputationModelError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Create a computation model with a configuration and data binding.
 */
export declare const createComputationModel: API.OperationMethod<CreateComputationModelRequest, CreateComputationModelResponse, CreateComputationModelError, Credentials | HttpClient.HttpClient>;
export type CreateDashboardError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The IoT SiteWise Monitor feature will no longer be open to new
 * customers starting November 7, 2025. If you would like to use the IoT SiteWise Monitor feature, sign up prior to that date. Existing customers can
 * continue to use the service as normal. For more information, see
 * IoT SiteWise Monitor availability change.
 *
 * Creates a dashboard in an IoT SiteWise Monitor project.
 */
export declare const createDashboard: API.OperationMethod<CreateDashboardRequest, CreateDashboardResponse, CreateDashboardError, Credentials | HttpClient.HttpClient>;
export type CreateDatasetError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a dataset. Session and curated datasets are created in a workspace. A session dataset contains data segments of time series data, and a curated dataset curates data segments selected from source session datasets. A dataset that connects to an external datasource is created outside of a workspace.
 */
export declare const createDataset: API.OperationMethod<CreateDatasetRequest, CreateDatasetResponse, CreateDatasetError, Credentials | HttpClient.HttpClient>;
export type CreateDatasetExportJobError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Starts an asynchronous job that exports dataset and time-series data from a workspace to Amazon
 * S3. The operation returns a jobId immediately; poll DescribeDatasetExportJob to track progress and
 * ListDatasetExportJobs to enumerate a workspace's jobs.
 */
export declare const createDatasetExportJob: API.OperationMethod<CreateDatasetExportJobRequest, CreateDatasetExportJobResponse, CreateDatasetExportJobError, Credentials | HttpClient.HttpClient>;
export type CreateEnrichmentJobError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an asynchronous enrichment job to analyze time-series sensor data. The operation returns
 * immediately with job details while processing continues in the background.
 *
 * Idempotency
 *
 * Include a clientToken to make the operation idempotent. If you submit the same request with the same
 * token within the idempotency window, you receive the original job details without creating a duplicate.
 *
 * Prerequisites
 *
 * Before creating a job, ensure:
 *
 * - The workspace is in ACTIVE state (not being deleted)
 *
 * - You have IAM permissions for the workspace, dataset, and time-series resources
 *
 * - You have KMS Decrypt permission on the workspace's customer-managed encryption key
 *
 * - No duplicate job (same workspace, dataset, property, and job type) is currently running
 *
 * Workflow
 *
 * - Submit the job with configuration specifying which video data to analyze and the time range
 *
 * - Capture the jobId from the response
 *
 * - Use DescribeEnrichmentJob to monitor progress and check job status
 *
 * - When status reaches a terminal state (COMPLETED, FAILED, TIMED_OUT, CANCELLED), check results
 *
 * - For COMPLETED jobs, query IoT SiteWise for semantic search on video events
 *
 * Error Handling
 *
 * - ConflictingOperationException: A duplicate job is already running for the same configuration
 *
 * - InvalidRequestException: Invalid parameters (e.g., both timeSeriesId and propertyAlias specified)
 *
 * - AccessDeniedException: Insufficient IAM or KMS permissions
 *
 * - LimitExceededException: Too many concurrent jobs or requests
 */
export declare const createEnrichmentJob: API.OperationMethod<CreateEnrichmentJobRequest, CreateEnrichmentJobResponse, CreateEnrichmentJobError, Credentials | HttpClient.HttpClient>;
export type CreateGatewayError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ThrottlingException | CommonErrors;
/**
 * Creates a gateway, which is a virtual or edge device that delivers industrial data streams
 * from local servers to IoT SiteWise. For more information, see Ingesting data using a gateway in the
 * *IoT SiteWise User Guide*.
 */
export declare const createGateway: API.OperationMethod<CreateGatewayRequest, CreateGatewayResponse, CreateGatewayError, Credentials | HttpClient.HttpClient>;
export type CreatePipelineError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new pipeline in the specified workspace. A pipeline defines a
 * directed acyclic graph (DAG) of compute nodes, where each node references a task
 * and can declare dependencies on other nodes. Cyclic dependencies are not
 * allowed. Nodes without dependencies run in parallel, while nodes with dependencies
 * wait for all upstream nodes to complete successfully before starting.
 *
 * You can set environment variables at the pipeline level that are shared across all
 * compute nodes, and override them at the individual compute node level.
 */
export declare const createPipeline: API.OperationMethod<CreatePipelineRequest, CreatePipelineResponse, CreatePipelineError, Credentials | HttpClient.HttpClient>;
export type CreatePortalError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The IoT SiteWise Monitor feature will no longer be open to new
 * customers starting November 7, 2025. If you would like to use the IoT SiteWise Monitor feature, sign up prior to that date. Existing customers can
 * continue to use the service as normal. For more information, see
 * IoT SiteWise Monitor availability change.
 *
 * Creates a portal, which can contain projects and dashboards. IoT SiteWise Monitor uses IAM Identity Center or IAM
 * to authenticate portal users and manage user permissions.
 *
 * Before you can sign in to a new portal, you must add at least one identity to that
 * portal. For more information, see Adding or removing portal
 * administrators in the *IoT SiteWise User Guide*.
 */
export declare const createPortal: API.OperationMethod<CreatePortalRequest, CreatePortalResponse, CreatePortalError, Credentials | HttpClient.HttpClient>;
export type CreateProjectError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The IoT SiteWise Monitor feature will no longer be open to new
 * customers starting November 7, 2025. If you would like to use the IoT SiteWise Monitor feature, sign up prior to that date. Existing customers can
 * continue to use the service as normal. For more information, see
 * IoT SiteWise Monitor availability change.
 *
 * Creates a project in the specified portal.
 *
 * Make sure that the project name and description don't contain confidential
 * information.
 */
export declare const createProject: API.OperationMethod<CreateProjectRequest, CreateProjectResponse, CreateProjectError, Credentials | HttpClient.HttpClient>;
export type CreateTaskError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new task in the specified workspace. A task defines a reusable
 * containerized compute workload that can be referenced by one or more pipeline compute nodes.
 *
 * Specify a `containerTaskConfiguration` for custom container workloads with
 * configurable ECR image, processing type, processing unit, and environment variables.
 */
export declare const createTask: API.OperationMethod<CreateTaskRequest, CreateTaskResponse, CreateTaskError, Credentials | HttpClient.HttpClient>;
export type CreateWorkspaceError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a workspace in IoT SiteWise. A workspace isolates its resources, such as datasets, time
 * series, pipelines, and tasks, and their data from other workspaces, and has its own quotas
 * and throttling limits. You must specify an encryption configuration when you create
 * a workspace. The operation returns immediately with the workspace in the
 * `CREATING` state. Provisioning completes asynchronously, after which the workspace
 * state is `ACTIVE`, or `FAILED` if provisioning doesn't complete.
 */
export declare const createWorkspace: API.OperationMethod<CreateWorkspaceRequest, CreateWorkspaceResponse, CreateWorkspaceError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessPolicyError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an access policy that grants the specified identity access to the specified
 * IoT SiteWise Monitor resource. You can use this operation to revoke access to an IoT SiteWise Monitor
 * resource.
 */
export declare const deleteAccessPolicy: API.OperationMethod<DeleteAccessPolicyRequest, DeleteAccessPolicyResponse, DeleteAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an application by ID
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an asset. This action can't be undone. For more information, see Deleting assets and
 * models in the *IoT SiteWise User Guide*.
 *
 * You can't delete an asset that's associated to another asset. For more information, see
 * DisassociateAssets.
 */
export declare const deleteAsset: API.OperationMethod<DeleteAssetRequest, DeleteAssetResponse, DeleteAssetError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetModelError = ConflictingOperationException | InternalFailureException | InvalidRequestException | PreconditionFailedException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an asset model. This action can't be undone. You must delete all assets created
 * from an asset model before you can delete the model. Also, you can't delete an asset model if
 * a parent asset model exists that contains a property formula expression that depends on the
 * asset model that you want to delete. For more information, see Deleting assets and models in the
 * *IoT SiteWise User Guide*.
 */
export declare const deleteAssetModel: API.OperationMethod<DeleteAssetModelRequest, DeleteAssetModelResponse, DeleteAssetModelError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetModelCompositeModelError = ConflictingOperationException | InternalFailureException | InvalidRequestException | PreconditionFailedException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a composite model. This action can't be undone. You must delete all assets created
 * from a composite model before you can delete the model. Also, you can't delete a composite
 * model if a parent asset model exists that contains a property formula expression that depends
 * on the asset model that you want to delete. For more information, see Deleting assets and
 * models in the *IoT SiteWise User Guide*.
 */
export declare const deleteAssetModelCompositeModel: API.OperationMethod<DeleteAssetModelCompositeModelRequest, DeleteAssetModelCompositeModelResponse, DeleteAssetModelCompositeModelError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetModelInterfaceRelationshipError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an interface relationship between an asset model and an interface asset
 * model.
 */
export declare const deleteAssetModelInterfaceRelationship: API.OperationMethod<DeleteAssetModelInterfaceRelationshipRequest, DeleteAssetModelInterfaceRelationshipResponse, DeleteAssetModelInterfaceRelationshipError, Credentials | HttpClient.HttpClient>;
export type DeleteComputationModelError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a computation model. This action can't be undone.
 */
export declare const deleteComputationModel: API.OperationMethod<DeleteComputationModelRequest, DeleteComputationModelResponse, DeleteComputationModelError, Credentials | HttpClient.HttpClient>;
export type DeleteDashboardError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a dashboard from IoT SiteWise Monitor.
 */
export declare const deleteDashboard: API.OperationMethod<DeleteDashboardRequest, DeleteDashboardResponse, DeleteDashboardError, Credentials | HttpClient.HttpClient>;
export type DeleteDatasetError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a dataset. This can't be undone. Deleting a session dataset also deletes the underlying time series data in the session. You can't delete a session dataset while a curated dataset references its data segments. First delete the curated dataset or disassociate the data segments. Deleting a curated dataset doesn't delete the underlying data in the source session datasets.
 */
export declare const deleteDataset: API.OperationMethod<DeleteDatasetRequest, DeleteDatasetResponse, DeleteDatasetError, Credentials | HttpClient.HttpClient>;
export type DeleteGatewayError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a gateway from IoT SiteWise. When you delete a gateway, some of the gateway's files remain
 * in your gateway's file system.
 */
export declare const deleteGateway: API.OperationMethod<DeleteGatewayRequest, DeleteGatewayResponse, DeleteGatewayError, Credentials | HttpClient.HttpClient>;
export type DeletePipelineError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a pipeline from the specified workspace. A pipeline cannot be
 * deleted if it has any active executions. Wait for all executions to complete before
 * attempting to delete the pipeline, or use CancelPipelineExecution to stop a running
 * execution.
 */
export declare const deletePipeline: API.OperationMethod<DeletePipelineRequest, DeletePipelineResponse, DeletePipelineError, Credentials | HttpClient.HttpClient>;
export type DeletePortalError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a portal from IoT SiteWise Monitor.
 */
export declare const deletePortal: API.OperationMethod<DeletePortalRequest, DeletePortalResponse, DeletePortalError, Credentials | HttpClient.HttpClient>;
export type DeleteProjectError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a project from IoT SiteWise Monitor.
 */
export declare const deleteProject: API.OperationMethod<DeleteProjectRequest, DeleteProjectResponse, DeleteProjectError, Credentials | HttpClient.HttpClient>;
export type DeleteTaskError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a task from the specified workspace. A task cannot be deleted
 * if it is currently referenced by any existing pipeline. Remove the task from all
 * pipelines before attempting to delete it.
 */
export declare const deleteTask: API.OperationMethod<DeleteTaskRequest, DeleteTaskResponse, DeleteTaskError, Credentials | HttpClient.HttpClient>;
export type DeleteTimeSeriesError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a time series (data stream). If you delete a time series that's associated with an
 * asset property, the asset property still exists, but the time series will no longer be
 * associated with this asset property. You can't delete a time series until all of its data
 * segments have been deleted from session datasets.
 *
 * To identify a time series, do one of the following:
 *
 * - If the time series isn't associated with an asset property,
 * specify the `alias` of the time series.
 *
 * - If the time series is associated with an asset property,
 * specify one of the following:
 *
 * - The `alias` of the time series.
 *
 * - The `assetId` and `propertyId` that identifies the asset property.
 */
export declare const deleteTimeSeries: API.OperationMethod<DeleteTimeSeriesRequest, DeleteTimeSeriesResponse, DeleteTimeSeriesError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkspaceError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a workspace. Before you delete a workspace, you must delete all resources
 * contained in or associated with the workspace, such as datasets, time series, pipelines,
 * and tasks.
 */
export declare const deleteWorkspace: API.OperationMethod<DeleteWorkspaceRequest, DeleteWorkspaceResponse, DeleteWorkspaceError, Credentials | HttpClient.HttpClient>;
export type DescribeAccessPolicyError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes an access policy, which specifies an identity's access to an IoT SiteWise Monitor portal or
 * project.
 */
export declare const describeAccessPolicy: API.OperationMethod<DescribeAccessPolicyRequest, DescribeAccessPolicyResponse, DescribeAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeActionError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about an action.
 */
export declare const describeAction: API.OperationMethod<DescribeActionRequest, DescribeActionResponse, DescribeActionError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves Application details based on the ID
 */
export declare const describeApplication: API.OperationMethod<DescribeApplicationRequest, DescribeApplicationResponse, DescribeApplicationError, Credentials | HttpClient.HttpClient>;
export type DescribeAssetError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about an asset.
 */
export declare const describeAsset: API.OperationMethod<DescribeAssetRequest, DescribeAssetResponse, DescribeAssetError, Credentials | HttpClient.HttpClient>;
export type DescribeAssetCompositeModelError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about an asset composite model (also known as an asset component).
 * An `AssetCompositeModel` is an instance of an
 * `AssetModelCompositeModel`. If you want to see information about the model this is
 * based on, call DescribeAssetModelCompositeModel.
 */
export declare const describeAssetCompositeModel: API.OperationMethod<DescribeAssetCompositeModelRequest, DescribeAssetCompositeModelResponse, DescribeAssetCompositeModelError, Credentials | HttpClient.HttpClient>;
export type DescribeAssetModelError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about an asset model. This includes details about the asset model's
 * properties, hierarchies, composite models, and any interface relationships if the asset model
 * implements interfaces.
 */
export declare const describeAssetModel: API.OperationMethod<DescribeAssetModelRequest, DescribeAssetModelResponse, DescribeAssetModelError, Credentials | HttpClient.HttpClient>;
export type DescribeAssetModelCompositeModelError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about an asset model composite model (also known as an asset model
 * component). For more information, see Custom composite models
 * (Components) in the *IoT SiteWise User Guide*.
 */
export declare const describeAssetModelCompositeModel: API.OperationMethod<DescribeAssetModelCompositeModelRequest, DescribeAssetModelCompositeModelResponse, DescribeAssetModelCompositeModelError, Credentials | HttpClient.HttpClient>;
export type DescribeAssetModelInterfaceRelationshipError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about an interface relationship between an asset model and an
 * interface asset model.
 */
export declare const describeAssetModelInterfaceRelationship: API.OperationMethod<DescribeAssetModelInterfaceRelationshipRequest, DescribeAssetModelInterfaceRelationshipResponse, DescribeAssetModelInterfaceRelationshipError, Credentials | HttpClient.HttpClient>;
export type DescribeAssetPropertyError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about an asset property.
 *
 * When you call this operation for an attribute property, this response includes the
 * default attribute value that you define in the asset model. If you update the default value
 * in the model, this operation's response includes the new default value.
 *
 * This operation doesn't return the value of the asset property. To get the value of an
 * asset property, use GetAssetPropertyValue.
 */
export declare const describeAssetProperty: API.OperationMethod<DescribeAssetPropertyRequest, DescribeAssetPropertyResponse, DescribeAssetPropertyError, Credentials | HttpClient.HttpClient>;
export type DescribeBulkImportJobError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a bulk import job request. For more information, see Describe
 * a bulk import job (CLI) in the *Amazon Simple Storage Service User Guide*.
 */
export declare const describeBulkImportJob: API.OperationMethod<DescribeBulkImportJobRequest, DescribeBulkImportJobResponse, DescribeBulkImportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeComputationModelError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a computation model.
 */
export declare const describeComputationModel: API.OperationMethod<DescribeComputationModelRequest, DescribeComputationModelResponse, DescribeComputationModelError, Credentials | HttpClient.HttpClient>;
export type DescribeComputationModelExecutionSummaryError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about the execution summary of a computation model.
 */
export declare const describeComputationModelExecutionSummary: API.OperationMethod<DescribeComputationModelExecutionSummaryRequest, DescribeComputationModelExecutionSummaryResponse, DescribeComputationModelExecutionSummaryError, Credentials | HttpClient.HttpClient>;
export type DescribeDashboardError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a dashboard.
 */
export declare const describeDashboard: API.OperationMethod<DescribeDashboardRequest, DescribeDashboardResponse, DescribeDashboardError, Credentials | HttpClient.HttpClient>;
export type DescribeDatasetError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a dataset.
 */
export declare const describeDataset: API.OperationMethod<DescribeDatasetRequest, DescribeDatasetResponse, DescribeDatasetError, Credentials | HttpClient.HttpClient>;
export type DescribeDatasetExportJobError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a dataset export job.
 */
export declare const describeDatasetExportJob: API.OperationMethod<DescribeDatasetExportJobRequest, DescribeDatasetExportJobResponse, DescribeDatasetExportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeDefaultEncryptionConfigurationError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about the default encryption configuration for the Amazon Web Services account in
 * the default or specified Region. For more information, see Key management in the
 * *IoT SiteWise User Guide*.
 */
export declare const describeDefaultEncryptionConfiguration: API.OperationMethod<DescribeDefaultEncryptionConfigurationRequest, DescribeDefaultEncryptionConfigurationResponse, DescribeDefaultEncryptionConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeEnrichmentJobError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves detailed information about a specific enrichment job, including its current status,
 * configuration, and timestamps.
 *
 * Use Cases
 *
 * - Monitor job progress by checking status updates with DescribeEnrichmentJob
 *
 * - Retrieve the complete job configuration submitted during creation
 *
 * - Debug failed jobs by examining the failureMessage field
 *
 * - Track job lifecycle with creation, update, completion, and cancellation timestamps
 *
 * Status Monitoring
 *
 * Jobs progress through statuses: PENDING -> RUNNING -> terminal state
 *
 * Terminal states:
 *
 * - COMPLETED: Job finished successfully; query IoT SiteWise for semantic search results
 *
 * - FAILED: Job encountered an error; check failureMessage for details
 *
 * - TIMED_OUT: Job exceeded maximum processing time
 *
 * - CANCELLED: Job was cancelled via CancelEnrichmentJob
 *
 * Response Fields
 *
 * The response includes:
 *
 * - Current job status and type
 *
 * - Full job configuration as originally submitted
 *
 * - Lifecycle timestamps (created, updated, completed, cancelled)
 *
 * - Failure details if status is FAILED
 */
export declare const describeEnrichmentJob: API.OperationMethod<DescribeEnrichmentJobRequest, DescribeEnrichmentJobResponse, DescribeEnrichmentJobError, Credentials | HttpClient.HttpClient>;
export type DescribeExecutionError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about the execution.
 */
export declare const describeExecution: API.OperationMethod<DescribeExecutionRequest, DescribeExecutionResponse, DescribeExecutionError, Credentials | HttpClient.HttpClient>;
export type DescribeGatewayError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a gateway.
 */
export declare const describeGateway: API.OperationMethod<DescribeGatewayRequest, DescribeGatewayResponse, DescribeGatewayError, Credentials | HttpClient.HttpClient>;
export type DescribeGatewayCapabilityConfigurationError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Each gateway capability defines data sources for a gateway. This is the namespace of the gateway capability.
 *
 * . The namespace follows the format `service:capability:version`, where:
 *
 * - `service` - The service providing the capability, or `iotsitewise`.
 *
 * - `capability` - The specific capability type. Options include: `opcuacollector` for the OPC UA data source collector, or `publisher` for data publisher capability.
 *
 * - `version` - The version number of the capability. Option include `2` for Classic streams, V2 gateways, and `3` for MQTT-enabled, V3 gateways.
 *
 * After updating a capability configuration, the sync status becomes `OUT_OF_SYNC` until the gateway processes the configuration.Use `DescribeGatewayCapabilityConfiguration` to check the sync status and verify the configuration was applied.
 *
 * A gateway can have multiple capability configurations with different namespaces.
 */
export declare const describeGatewayCapabilityConfiguration: API.OperationMethod<DescribeGatewayCapabilityConfigurationRequest, DescribeGatewayCapabilityConfigurationResponse, DescribeGatewayCapabilityConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeLoggingOptionsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the current IoT SiteWise logging options.
 */
export declare const describeLoggingOptions: API.OperationMethod<DescribeLoggingOptionsRequest, DescribeLoggingOptionsResponse, DescribeLoggingOptionsError, Credentials | HttpClient.HttpClient>;
export type DescribePipelineError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves detailed information about a specific pipeline in a workspace.
 */
export declare const describePipeline: API.OperationMethod<DescribePipelineRequest, DescribePipelineResponse, DescribePipelineError, Credentials | HttpClient.HttpClient>;
export type DescribePipelineExecutionError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves detailed information about a specific pipeline execution, including the
 * overall execution status and the status of each individual compute node. Use this
 * operation to monitor execution progress and inspect per-node results, environment
 * variables, and error details.
 */
export declare const describePipelineExecution: API.PaginatedOperationMethod<DescribePipelineExecutionRequest, DescribePipelineExecutionResponse, DescribePipelineExecutionError, Credentials | HttpClient.HttpClient, ComputeNodeExecutionDetails>;
export type DescribePortalError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a portal.
 */
export declare const describePortal: API.OperationMethod<DescribePortalRequest, DescribePortalResponse, DescribePortalError, Credentials | HttpClient.HttpClient>;
export type DescribeProjectError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a project.
 */
export declare const describeProject: API.OperationMethod<DescribeProjectRequest, DescribeProjectResponse, DescribeProjectError, Credentials | HttpClient.HttpClient>;
export type DescribeQueryError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a query, including its status.
 */
export declare const describeQuery: API.OperationMethod<DescribeQueryRequest, DescribeQueryResponse, DescribeQueryError, Credentials | HttpClient.HttpClient>;
export type DescribeSearchError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns the current status and metadata of a single search, including the query that was
 * submitted, the search type, and -- when the search has failed -- the reason. Use this to poll a
 * search started with `StartSearch` until it reaches a terminal status (`SUCCEEDED` or
 * `FAILED`).
 */
export declare const describeSearch: API.OperationMethod<DescribeSearchRequest, DescribeSearchResponse, DescribeSearchError, Credentials | HttpClient.HttpClient>;
export type DescribeStorageConfigurationError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about the storage configuration for IoT SiteWise.
 */
export declare const describeStorageConfiguration: API.OperationMethod<DescribeStorageConfigurationRequest, DescribeStorageConfigurationResponse, DescribeStorageConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeTaskError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves detailed information about a specific task in a workspace.
 */
export declare const describeTask: API.OperationMethod<DescribeTaskRequest, DescribeTaskResponse, DescribeTaskError, Credentials | HttpClient.HttpClient>;
export type DescribeTimeSeriesError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a time series (data stream).
 *
 * To identify a time series, do one of the following:
 *
 * - If the time series isn't associated with an asset property,
 * specify the `alias` of the time series.
 *
 * - If the time series is associated with an asset property,
 * specify one of the following:
 *
 * - The `alias` of the time series.
 *
 * - The `assetId` and `propertyId` that identifies the asset property.
 */
export declare const describeTimeSeries: API.OperationMethod<DescribeTimeSeriesRequest, DescribeTimeSeriesResponse, DescribeTimeSeriesError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkspaceError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a workspace.
 */
export declare const describeWorkspace: API.OperationMethod<DescribeWorkspaceRequest, DescribeWorkspaceResponse, DescribeWorkspaceError, Credentials | HttpClient.HttpClient>;
export type DisassociateAssetsError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates a child asset from the given parent asset through a hierarchy defined in the
 * parent asset's model.
 */
export declare const disassociateAssets: API.OperationMethod<DisassociateAssetsRequest, DisassociateAssetsResponse, DisassociateAssetsError, Credentials | HttpClient.HttpClient>;
export type DisassociateTimeSeriesFromAssetPropertyError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates a time series (data stream) from an asset property.
 */
export declare const disassociateTimeSeriesFromAssetProperty: API.OperationMethod<DisassociateTimeSeriesFromAssetPropertyRequest, DisassociateTimeSeriesFromAssetPropertyResponse, DisassociateTimeSeriesFromAssetPropertyError, Credentials | HttpClient.HttpClient>;
export type ExecuteActionError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Executes an action on a target resource.
 */
export declare const executeAction: API.OperationMethod<ExecuteActionRequest, ExecuteActionResponse, ExecuteActionError, Credentials | HttpClient.HttpClient>;
export type ExecuteQueryError = AccessDeniedException | InternalFailureException | InvalidRequestException | QueryTimeoutException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Run SQL queries to retrieve metadata and time-series data from asset models, assets,
 * measurements, metrics, transforms, and aggregates.
 */
export declare const executeQuery: API.PaginatedOperationMethod<ExecuteQueryRequest, ExecuteQueryResponse, ExecuteQueryError, Credentials | HttpClient.HttpClient, Row>;
export type GetAssetPropertyAggregatesError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Gets aggregated values for an asset property. For more information, see Querying
 * aggregates in the *IoT SiteWise User Guide*.
 *
 * To identify an asset property, you must specify one of the following:
 *
 * - The `assetId` and `propertyId` of an asset property.
 *
 * - A `propertyAlias`, which is a data stream alias (for example,
 * `/company/windfarm/3/turbine/7/temperature`). To define an asset property's alias, see UpdateAssetProperty.
 */
export declare const getAssetPropertyAggregates: API.PaginatedOperationMethod<GetAssetPropertyAggregatesRequest, GetAssetPropertyAggregatesResponse, GetAssetPropertyAggregatesError, Credentials | HttpClient.HttpClient, AggregatedValue>;
export type GetAssetPropertyValueError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Gets an asset property's current value. For more information, see Querying
 * current values in the *IoT SiteWise User Guide*.
 *
 * To identify an asset property, you must specify one of the following:
 *
 * - The `assetId` and `propertyId` of an asset property.
 *
 * - A `propertyAlias`, which is a data stream alias (for example,
 * `/company/windfarm/3/turbine/7/temperature`). To define an asset property's alias, see UpdateAssetProperty.
 */
export declare const getAssetPropertyValue: API.OperationMethod<GetAssetPropertyValueRequest, GetAssetPropertyValueResponse, GetAssetPropertyValueError, Credentials | HttpClient.HttpClient>;
export type GetAssetPropertyValueHistoryError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Gets the history of an asset property's values. For more information, see Querying
 * historical values in the *IoT SiteWise User Guide*.
 *
 * To identify an asset property, you must specify one of the following:
 *
 * - The `assetId` and `propertyId` of an asset property.
 *
 * - A `propertyAlias`, which is a data stream alias (for example,
 * `/company/windfarm/3/turbine/7/temperature`). To define an asset property's alias, see UpdateAssetProperty.
 */
export declare const getAssetPropertyValueHistory: API.PaginatedOperationMethod<GetAssetPropertyValueHistoryRequest, GetAssetPropertyValueHistoryResponse, GetAssetPropertyValueHistoryError, Credentials | HttpClient.HttpClient, AssetPropertyValue>;
export type GetCaptureDataError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves video data for a specific time range.
 */
export declare const getCaptureData: API.OperationMethod<GetCaptureDataRequest, GetCaptureDataResponse, GetCaptureDataError, Credentials | HttpClient.HttpClient>;
export type GetInterpolatedAssetPropertyValuesError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Get interpolated values for an asset property for a specified time interval, during a
 * period of time. If your time series is missing data points during the specified time interval,
 * you can use interpolation to estimate the missing data.
 *
 * For example, you can use this operation to return the interpolated temperature values for
 * a wind turbine every 24 hours over a duration of 7 days.
 *
 * To identify an asset property, you must specify one of the following:
 *
 * - The `assetId` and `propertyId` of an asset property.
 *
 * - A `propertyAlias`, which is a data stream alias (for example,
 * `/company/windfarm/3/turbine/7/temperature`). To define an asset property's alias, see UpdateAssetProperty.
 */
export declare const getInterpolatedAssetPropertyValues: API.PaginatedOperationMethod<GetInterpolatedAssetPropertyValuesRequest, GetInterpolatedAssetPropertyValuesResponse, GetInterpolatedAssetPropertyValuesError, Credentials | HttpClient.HttpClient, InterpolatedAssetPropertyValue>;
export type GetQueryResultsError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the paginated results of a query. Returns empty rows if the query is not yet complete.
 */
export declare const getQueryResults: API.PaginatedOperationMethod<GetQueryResultsRequest, GetQueryResultsResponse, GetQueryResultsError, Credentials | HttpClient.HttpClient, ColumnValue[]>;
export type GetSearchResultsError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the ranked results of a search, ordered by descending relevance score. Results are
 * available only after the search has reached the `SUCCEEDED` status. Calling this on a search
 * that exists but has not yet completed returns `InvalidRequestException`, while calling it on a
 * search that does not exist returns `ResourceNotFoundException`. The response is paginated: when
 * `nextToken` is present, pass it on a subsequent call to retrieve the next page.
 */
export declare const getSearchResults: API.PaginatedOperationMethod<GetSearchResultsRequest, GetSearchResultsResponse, GetSearchResultsError, Credentials | HttpClient.HttpClient, SearchResult>;
export type InvokeAssistantError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Invokes SiteWise Assistant to start or continue a conversation.
 */
export declare const invokeAssistant: API.OperationMethod<InvokeAssistantRequest, InvokeAssistantResponse, InvokeAssistantError, Credentials | HttpClient.HttpClient>;
export type ListAccessPoliciesError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of access policies for an identity (an IAM Identity Center user, an IAM Identity Center
 * group, or an IAM user) or an IoT SiteWise Monitor resource (a portal or project).
 */
export declare const listAccessPolicies: API.PaginatedOperationMethod<ListAccessPoliciesRequest, ListAccessPoliciesResponse, ListAccessPoliciesError, Credentials | HttpClient.HttpClient, AccessPolicySummary>;
export type ListActionsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of actions for a specific target resource.
 */
export declare const listActions: API.PaginatedOperationMethod<ListActionsRequest, ListActionsResponse, ListActionsError, Credentials | HttpClient.HttpClient, ActionSummary>;
export type ListApplicationsError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of existing applications
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationSummary>;
export type ListAssetModelCompositeModelsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of composite models associated with the asset model
 */
export declare const listAssetModelCompositeModels: API.PaginatedOperationMethod<ListAssetModelCompositeModelsRequest, ListAssetModelCompositeModelsResponse, ListAssetModelCompositeModelsError, Credentials | HttpClient.HttpClient, AssetModelCompositeModelSummary>;
export type ListAssetModelPropertiesError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of properties associated with an asset model.
 * If you update properties associated with the model before you finish listing all the properties,
 * you need to start all over again.
 */
export declare const listAssetModelProperties: API.PaginatedOperationMethod<ListAssetModelPropertiesRequest, ListAssetModelPropertiesResponse, ListAssetModelPropertiesError, Credentials | HttpClient.HttpClient, AssetModelPropertySummary>;
export type ListAssetModelsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of summaries of all asset models.
 */
export declare const listAssetModels: API.PaginatedOperationMethod<ListAssetModelsRequest, ListAssetModelsResponse, ListAssetModelsError, Credentials | HttpClient.HttpClient, AssetModelSummary>;
export type ListAssetPropertiesError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of properties associated with an asset.
 * If you update properties associated with the model before you finish listing all the properties,
 * you need to start all over again.
 */
export declare const listAssetProperties: API.PaginatedOperationMethod<ListAssetPropertiesRequest, ListAssetPropertiesResponse, ListAssetPropertiesError, Credentials | HttpClient.HttpClient, AssetPropertySummary>;
export type ListAssetRelationshipsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of asset relationships for an asset. You can use this operation
 * to identify an asset's root asset and all associated assets between that asset and its
 * root.
 */
export declare const listAssetRelationships: API.PaginatedOperationMethod<ListAssetRelationshipsRequest, ListAssetRelationshipsResponse, ListAssetRelationshipsError, Credentials | HttpClient.HttpClient, AssetRelationshipSummary>;
export type ListAssetsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of asset summaries.
 *
 * You can use this operation to do the following:
 *
 * - List assets based on a specific asset model.
 *
 * - List top-level assets.
 *
 * You can't use this operation to list all assets. To retrieve summaries for all of your
 * assets, use ListAssetModels to get all of your asset model IDs. Then, use ListAssets to get all
 * assets for each asset model.
 */
export declare const listAssets: API.PaginatedOperationMethod<ListAssetsRequest, ListAssetsResponse, ListAssetsError, Credentials | HttpClient.HttpClient, AssetSummary>;
export type ListAssociatedAssetsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of associated assets.
 *
 * You can use this operation to do the following:
 *
 * - `CHILD` - List all child assets associated to the asset.
 *
 * - `PARENT` - List the asset's parent asset.
 */
export declare const listAssociatedAssets: API.PaginatedOperationMethod<ListAssociatedAssetsRequest, ListAssociatedAssetsResponse, ListAssociatedAssetsError, Credentials | HttpClient.HttpClient, AssociatedAssetsSummary>;
export type ListBulkImportJobsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of bulk import job requests. For more information, see List bulk
 * import jobs (CLI) in the *IoT SiteWise User Guide*.
 */
export declare const listBulkImportJobs: API.PaginatedOperationMethod<ListBulkImportJobsRequest, ListBulkImportJobsResponse, ListBulkImportJobsError, Credentials | HttpClient.HttpClient, JobSummary>;
export type ListCompositionRelationshipsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of composition relationships for an asset model of type
 * `COMPONENT_MODEL`.
 */
export declare const listCompositionRelationships: API.PaginatedOperationMethod<ListCompositionRelationshipsRequest, ListCompositionRelationshipsResponse, ListCompositionRelationshipsError, Credentials | HttpClient.HttpClient, CompositionRelationshipSummary>;
export type ListComputationModelDataBindingUsagesError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Lists all data binding usages for computation models. This allows to identify where
 * specific data bindings are being utilized across the computation models. This track
 * dependencies between data sources and computation models.
 */
export declare const listComputationModelDataBindingUsages: API.PaginatedOperationMethod<ListComputationModelDataBindingUsagesRequest, ListComputationModelDataBindingUsagesResponse, ListComputationModelDataBindingUsagesError, Credentials | HttpClient.HttpClient, ComputationModelDataBindingUsageSummary>;
export type ListComputationModelResolveToResourcesError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all distinct resources that are resolved from the executed actions of the
 * computation model.
 */
export declare const listComputationModelResolveToResources: API.PaginatedOperationMethod<ListComputationModelResolveToResourcesRequest, ListComputationModelResolveToResourcesResponse, ListComputationModelResolveToResourcesError, Credentials | HttpClient.HttpClient, ComputationModelResolveToResourceSummary>;
export type ListComputationModelsError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of summaries of all computation models.
 */
export declare const listComputationModels: API.PaginatedOperationMethod<ListComputationModelsRequest, ListComputationModelsResponse, ListComputationModelsError, Credentials | HttpClient.HttpClient, ComputationModelSummary>;
export type ListDashboardsError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of dashboards for an IoT SiteWise Monitor project.
 */
export declare const listDashboards: API.PaginatedOperationMethod<ListDashboardsRequest, ListDashboardsResponse, ListDashboardsError, Credentials | HttpClient.HttpClient, DashboardSummary>;
export type ListDatasetDataSegmentRelationshipsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of data segment relationships for a session dataset. Use this
 * operation to find the curated datasets that reference data segments of the specified session
 * dataset. Use the `nextToken` parameter to retrieve additional results.
 */
export declare const listDatasetDataSegmentRelationships: API.PaginatedOperationMethod<ListDatasetDataSegmentRelationshipsRequest, ListDatasetDataSegmentRelationshipsResponse, ListDatasetDataSegmentRelationshipsError, Credentials | HttpClient.HttpClient, DataSegmentRelationshipSummary>;
export type ListDatasetDataSegmentsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of data segments associated with a dataset. Use the `nextToken` parameter to retrieve additional results.
 */
export declare const listDatasetDataSegments: API.PaginatedOperationMethod<ListDatasetDataSegmentsRequest, ListDatasetDataSegmentsResponse, ListDatasetDataSegmentsError, Credentials | HttpClient.HttpClient, DataSegmentSummary>;
export type ListDatasetExportJobsError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of dataset export jobs for a workspace.
 */
export declare const listDatasetExportJobs: API.PaginatedOperationMethod<ListDatasetExportJobsRequest, ListDatasetExportJobsResponse, ListDatasetExportJobsError, Credentials | HttpClient.HttpClient, ExportJobSummary>;
export type ListDatasetsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of datasets for a specific target resource.
 */
export declare const listDatasets: API.PaginatedOperationMethod<ListDatasetsRequest, ListDatasetsResponse, ListDatasetsError, Credentials | HttpClient.HttpClient, DatasetSummary>;
export type ListEnrichmentJobsError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists enrichment jobs within a workspace with optional filtering and pagination. Results are ordered
 * by createdAt timestamp descending (newest first).
 *
 * Filtering
 *
 * Combine filters to narrow results:
 *
 * - datasetId: Filter by dataset
 *
 * - propertyAlias OR timeSeriesId: Filter by time series (specify one, not both)
 *
 * - status: Filter by job status (e.g., RUNNING to find active jobs)
 *
 * - jobType: Filter by enrichment type (currently only EVENT_DETECTION)
 *
 * - startDate and endDate: Filter by job creation time range
 *
 * Important Constraints
 *
 * - You must specify either propertyAlias OR timeSeriesId, but not both
 *
 * - Attempting to specify both results in an InvalidRequestException
 *
 * - Date filters use ISO 8601 format
 *
 * - startDate is exclusive, endDate is inclusive
 *
 * Pagination
 *
 * The operation returns up to maxResults jobs per page (default 50). If more results exist, the
 * response includes a nextToken. Submit this token in a subsequent request to retrieve the next page.
 *
 * Common Use Cases
 *
 * - Find all running jobs: Filter by status=RUNNING
 *
 * - List recent jobs for a dataset: Filter by datasetId with optional date range
 *
 * - Monitor jobs for a specific sensor: Filter by propertyAlias or timeSeriesId
 *
 * - Track all event detection jobs: Filter by jobType=EVENT_DETECTION
 *
 * Performance
 *
 * Performance is optimal when filtering by supported fields (datasetId, propertyAlias, timeSeriesId, status, jobType).
 */
export declare const listEnrichmentJobs: API.PaginatedOperationMethod<ListEnrichmentJobsRequest, ListEnrichmentJobsResponse, ListEnrichmentJobsError, Credentials | HttpClient.HttpClient, EnrichmentJobSummary>;
export type ListExecutionsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of summaries of all executions.
 */
export declare const listExecutions: API.PaginatedOperationMethod<ListExecutionsRequest, ListExecutionsResponse, ListExecutionsError, Credentials | HttpClient.HttpClient, ExecutionSummary>;
export type ListGatewaysError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of gateways.
 */
export declare const listGateways: API.PaginatedOperationMethod<ListGatewaysRequest, ListGatewaysResponse, ListGatewaysError, Credentials | HttpClient.HttpClient, GatewaySummary>;
export type ListInterfaceRelationshipsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of asset models that have a specific interface asset model
 * applied to them.
 */
export declare const listInterfaceRelationships: API.PaginatedOperationMethod<ListInterfaceRelationshipsRequest, ListInterfaceRelationshipsResponse, ListInterfaceRelationshipsError, Credentials | HttpClient.HttpClient, InterfaceRelationshipSummary>;
export type ListPipelineExecutionsError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists pipeline executions for a specific pipeline in a workspace.
 * Supports filtering by state and time range. State can be combined with either
 * startTime or endTime filters. Time range filters are grouped: use startTime filters
 * (startTimeAfter, startTimeBefore) or endTime filters (endTimeAfter, endTimeBefore),
 * but not both. Combining startTime and endTime filters returns an InvalidRequestException.
 * Note: endTime filters only return executions in terminal states, as in-progress
 * executions have no endTime.
 */
export declare const listPipelineExecutions: API.PaginatedOperationMethod<ListPipelineExecutionsRequest, ListPipelineExecutionsResponse, ListPipelineExecutionsError, Credentials | HttpClient.HttpClient, PipelineExecutionSummary>;
export type ListPipelinesError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists pipelines in a workspace. To get complete details about a pipeline, use DescribePipeline.
 */
export declare const listPipelines: API.PaginatedOperationMethod<ListPipelinesRequest, ListPipelinesResponse, ListPipelinesError, Credentials | HttpClient.HttpClient, PipelineSummary>;
export type ListPortalsError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of IoT SiteWise Monitor portals.
 */
export declare const listPortals: API.PaginatedOperationMethod<ListPortalsRequest, ListPortalsResponse, ListPortalsError, Credentials | HttpClient.HttpClient, PortalSummary>;
export type ListProjectAssetsError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of assets associated with an IoT SiteWise Monitor project.
 */
export declare const listProjectAssets: API.PaginatedOperationMethod<ListProjectAssetsRequest, ListProjectAssetsResponse, ListProjectAssetsError, Credentials | HttpClient.HttpClient, ID>;
export type ListProjectsError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of projects for an IoT SiteWise Monitor portal.
 */
export declare const listProjects: API.PaginatedOperationMethod<ListProjectsRequest, ListProjectsResponse, ListProjectsError, Credentials | HttpClient.HttpClient, ProjectSummary>;
export type ListQueriesError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of queries for a workspace.
 */
export declare const listQueries: API.PaginatedOperationMethod<ListQueriesRequest, ListQueriesResponse, ListQueriesError, Credentials | HttpClient.HttpClient, QuerySummary>;
export type ListSearchesError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the searches in a workspace, most recently started first. Results can be narrowed with
 * optional filters (status, search type, group, and started-at time range) and are paginated: when
 * `nextToken` is present, pass it on a subsequent call to retrieve the next page.
 */
export declare const listSearches: API.PaginatedOperationMethod<ListSearchesRequest, ListSearchesResponse, ListSearchesError, Credentials | HttpClient.HttpClient, SearchSummary>;
export type ListTagsForResourceError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Retrieves the list of tags for an IoT SiteWise resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTasksError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists tasks in a workspace. To get complete details about a task, use DescribeTask.
 */
export declare const listTasks: API.PaginatedOperationMethod<ListTasksRequest, ListTasksResponse, ListTasksError, Credentials | HttpClient.HttpClient, TaskSummary>;
export type ListTimeSeriesError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of time series (data streams).
 */
export declare const listTimeSeries: API.PaginatedOperationMethod<ListTimeSeriesRequest, ListTimeSeriesResponse, ListTimeSeriesError, Credentials | HttpClient.HttpClient, TimeSeriesSummary>;
export type ListWorkspacesError = AccessDeniedException | InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of workspaces. Use the `nextToken` parameter to retrieve additional results.
 */
export declare const listWorkspaces: API.PaginatedOperationMethod<ListWorkspacesRequest, ListWorkspacesResponse, ListWorkspacesError, Credentials | HttpClient.HttpClient, WorkspaceSummary>;
export type PutAssetModelInterfaceRelationshipError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates or updates an interface relationship between an asset model and an interface asset
 * model. This operation applies an interface to an asset model.
 */
export declare const putAssetModelInterfaceRelationship: API.OperationMethod<PutAssetModelInterfaceRelationshipRequest, PutAssetModelInterfaceRelationshipResponse, PutAssetModelInterfaceRelationshipError, Credentials | HttpClient.HttpClient>;
export type PutDefaultEncryptionConfigurationError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Sets the default encryption configuration for the Amazon Web Services account. For more information, see
 * Key management in
 * the *IoT SiteWise User Guide*.
 */
export declare const putDefaultEncryptionConfiguration: API.OperationMethod<PutDefaultEncryptionConfigurationRequest, PutDefaultEncryptionConfigurationResponse, PutDefaultEncryptionConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutLoggingOptionsError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Sets logging options for IoT SiteWise.
 */
export declare const putLoggingOptions: API.OperationMethod<PutLoggingOptionsRequest, PutLoggingOptionsResponse, PutLoggingOptionsError, Credentials | HttpClient.HttpClient>;
export type PutStorageConfigurationError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Configures storage settings for IoT SiteWise.
 */
export declare const putStorageConfiguration: API.OperationMethod<PutStorageConfigurationRequest, PutStorageConfigurationResponse, PutStorageConfigurationError, Credentials | HttpClient.HttpClient>;
export type StartPipelineExecutionError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Starts execution of a pipeline in the specified workspace. Each compute node runs
 * according to the DAG dependency order defined in the pipeline. Nodes without
 * dependencies start immediately, while dependent nodes wait for all upstream nodes
 * to complete successfully.
 *
 * You can provide runtime environment variable overrides that take the highest priority
 * in the environment variable hierarchy, without modifying the pipeline definition.
 */
export declare const startPipelineExecution: API.OperationMethod<StartPipelineExecutionRequest, StartPipelineExecutionResponse, StartPipelineExecutionError, Credentials | HttpClient.HttpClient>;
export type StartQueryError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Starts an asynchronous SQL query against workspace telemetry, annotations, data segment, and dataset data.
 */
export declare const startQuery: API.OperationMethod<StartQueryRequest, StartQueryResponse, StartQueryError, Credentials | HttpClient.HttpClient>;
export type StartSearchError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Starts an asynchronous search over the data in a workspace. The search runs in the background;
 * the response returns immediately with a `searchId` and an initial status of `QUEUED`. Use
 * `DescribeSearch` to poll for completion and `GetSearchResults` to retrieve the results once the
 * search reaches `SUCCEEDED`. The request is idempotent on `clientToken`: repeating a call with the
 * same token returns the original search instead of starting a new one.
 */
export declare const startSearch: API.OperationMethod<StartSearchRequest, StartSearchResponse, StartSearchError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | TooManyTagsException | UnauthorizedException | CommonErrors;
/**
 * Adds tags to an IoT SiteWise resource. If a tag already exists for the resource, this operation
 * updates the tag's value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Removes a tag from an IoT SiteWise resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccessPolicyError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The IoT SiteWise Monitor feature will no longer be open to new
 * customers starting November 7, 2025. If you would like to use the IoT SiteWise Monitor feature, sign up prior to that date. Existing customers can
 * continue to use the service as normal. For more information, see
 * IoT SiteWise Monitor availability change.
 *
 * Updates an existing access policy that specifies an identity's access to an IoT SiteWise Monitor
 * portal or project resource.
 */
export declare const updateAccessPolicy: API.OperationMethod<UpdateAccessPolicyRequest, UpdateAccessPolicyResponse, UpdateAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an asset's name. For more information, see Updating assets and models in the
 * *IoT SiteWise User Guide*.
 */
export declare const updateAsset: API.OperationMethod<UpdateAssetRequest, UpdateAssetResponse, UpdateAssetError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetModelError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | PreconditionFailedException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an asset model and all of the assets that were created from the model. Each asset
 * created from the model inherits the updated asset model's property and hierarchy definitions.
 * For more information, see Updating assets and models in the
 * *IoT SiteWise User Guide*.
 *
 * If you remove a property from an asset model, IoT SiteWise deletes all previous data for that
 * property. You can't change the type or data type of an existing property.
 *
 * To replace an existing asset model property with a new one with the same
 * `name`, do the following:
 *
 * - Submit an `UpdateAssetModel` request with the entire existing property
 * removed.
 *
 * - Submit a second `UpdateAssetModel` request that includes the new
 * property. The new asset property will have the same `name` as the previous
 * one and IoT SiteWise will generate a new unique `id`.
 */
export declare const updateAssetModel: API.OperationMethod<UpdateAssetModelRequest, UpdateAssetModelResponse, UpdateAssetModelError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetModelCompositeModelError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | PreconditionFailedException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a composite model and all of the assets that were created from the model. Each
 * asset created from the model inherits the updated asset model's property and hierarchy
 * definitions. For more information, see Updating assets and models in the
 * *IoT SiteWise User Guide*.
 *
 * If you remove a property from a composite asset model, IoT SiteWise deletes all previous data
 * for that property. You can't change the type or data type of an existing property.
 *
 * To replace an existing composite asset model property with a new one with the same
 * `name`, do the following:
 *
 * - Submit an `UpdateAssetModelCompositeModel` request with the entire
 * existing property removed.
 *
 * - Submit a second `UpdateAssetModelCompositeModel` request that includes
 * the new property. The new asset property will have the same `name` as the
 * previous one and IoT SiteWise will generate a new unique `id`.
 */
export declare const updateAssetModelCompositeModel: API.OperationMethod<UpdateAssetModelCompositeModelRequest, UpdateAssetModelCompositeModelResponse, UpdateAssetModelCompositeModelError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetPropertyError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an asset property's alias and notification state.
 *
 * This operation overwrites the property's existing alias and notification state. To keep
 * your existing property's alias or notification state, you must include the existing values
 * in the UpdateAssetProperty request. For more information, see DescribeAssetProperty.
 */
export declare const updateAssetProperty: API.OperationMethod<UpdateAssetPropertyRequest, UpdateAssetPropertyResponse, UpdateAssetPropertyError, Credentials | HttpClient.HttpClient>;
export type UpdateComputationModelError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the computation model.
 */
export declare const updateComputationModel: API.OperationMethod<UpdateComputationModelRequest, UpdateComputationModelResponse, UpdateComputationModelError, Credentials | HttpClient.HttpClient>;
export type UpdateDashboardError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The IoT SiteWise Monitor feature will no longer be open to new
 * customers starting November 7, 2025. If you would like to use the IoT SiteWise Monitor feature, sign up prior to that date. Existing customers can
 * continue to use the service as normal. For more information, see
 * IoT SiteWise Monitor availability change.
 *
 * Updates an IoT SiteWise Monitor dashboard.
 */
export declare const updateDashboard: API.OperationMethod<UpdateDashboardRequest, UpdateDashboardResponse, UpdateDashboardError, Credentials | HttpClient.HttpClient>;
export type UpdateDatasetError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a dataset.
 */
export declare const updateDataset: API.OperationMethod<UpdateDatasetRequest, UpdateDatasetResponse, UpdateDatasetError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewayError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a gateway's name.
 */
export declare const updateGateway: API.OperationMethod<UpdateGatewayRequest, UpdateGatewayResponse, UpdateGatewayError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewayCapabilityConfigurationError = ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a gateway capability configuration or defines a new capability configuration. Each gateway capability defines data sources for a gateway.
 *
 * Important workflow notes:
 *
 * Each gateway capability defines data sources for a gateway. This is the namespace of the gateway capability.
 *
 * . The namespace follows the format `service:capability:version`, where:
 *
 * - `service` - The service providing the capability, or `iotsitewise`.
 *
 * - `capability` - The specific capability type. Options include: `opcuacollector` for the OPC UA data source collector, or `publisher` for data publisher capability.
 *
 * - `version` - The version number of the capability. Option include `2` for Classic streams, V2 gateways, and `3` for MQTT-enabled, V3 gateways.
 *
 * After updating a capability configuration, the sync status becomes `OUT_OF_SYNC` until the gateway processes the configuration.Use `DescribeGatewayCapabilityConfiguration` to check the sync status and verify the configuration was applied.
 *
 * A gateway can have multiple capability configurations with different namespaces.
 */
export declare const updateGatewayCapabilityConfiguration: API.OperationMethod<UpdateGatewayCapabilityConfigurationRequest, UpdateGatewayCapabilityConfigurationResponse, UpdateGatewayCapabilityConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdatePipelineError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an existing pipeline in the specified workspace. Only the fields
 * provided in the request are updated; fields not included in the request are preserved
 * unchanged. You can update the pipeline description, environment variables, and the
 * list of compute nodes independently.
 */
export declare const updatePipeline: API.OperationMethod<UpdatePipelineRequest, UpdatePipelineResponse, UpdatePipelineError, Credentials | HttpClient.HttpClient>;
export type UpdatePortalError = ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The IoT SiteWise Monitor feature will no longer be open to new
 * customers starting November 7, 2025. If you would like to use the IoT SiteWise Monitor feature, sign up prior to that date. Existing customers can
 * continue to use the service as normal. For more information, see
 * IoT SiteWise Monitor availability change.
 *
 * Updates an IoT SiteWise Monitor portal.
 */
export declare const updatePortal: API.OperationMethod<UpdatePortalRequest, UpdatePortalResponse, UpdatePortalError, Credentials | HttpClient.HttpClient>;
export type UpdateProjectError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The IoT SiteWise Monitor feature will no longer be open to new
 * customers starting November 7, 2025. If you would like to use the IoT SiteWise Monitor feature, sign up prior to that date. Existing customers can
 * continue to use the service as normal. For more information, see
 * IoT SiteWise Monitor availability change.
 *
 * Updates an IoT SiteWise Monitor project.
 */
export declare const updateProject: API.OperationMethod<UpdateProjectRequest, UpdateProjectResponse, UpdateProjectError, Credentials | HttpClient.HttpClient>;
export type UpdateTaskError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an existing task in the specified workspace. Only the fields
 * provided in the request are updated; fields not included in the request are preserved
 * unchanged.
 */
export declare const updateTask: API.OperationMethod<UpdateTaskRequest, UpdateTaskResponse, UpdateTaskError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkspaceError = AccessDeniedException | ConflictingOperationException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a workspace. You can update only workspaces in the `ACTIVE` or
 * `FAILED` state. Fields that you omit from the request are left unchanged. To
 * recover a workspace in the `FAILED` state, call this operation and supply its
 * encryption configuration again.
 */
export declare const updateWorkspace: API.OperationMethod<UpdateWorkspaceRequest, UpdateWorkspaceResponse, UpdateWorkspaceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iotsitewise.d.ts.map