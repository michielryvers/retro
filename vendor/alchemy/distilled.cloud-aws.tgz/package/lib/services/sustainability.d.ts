import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export interface TimePeriod {
    Start: Date;
    End: Date;
}
export type Dimension = "USAGE_ACCOUNT_ID" | "REGION" | "SERVICE" | (string & {});
export type DimensionList = Dimension[];
export type DimensionValue = string;
export type DimensionValueList = string[];
export type DimensionListMap = {
    [key in Dimension]?: string[];
};
export interface FilterExpression {
    Dimensions?: {
        [key: string]: string[] | undefined;
    };
}
export type EmissionsType = "TOTAL_LBM_CARBON_EMISSIONS" | "TOTAL_MBM_CARBON_EMISSIONS" | "TOTAL_SCOPE_1_CARBON_EMISSIONS" | "TOTAL_SCOPE_2_LBM_CARBON_EMISSIONS" | "TOTAL_SCOPE_2_MBM_CARBON_EMISSIONS" | "TOTAL_SCOPE_3_LBM_CARBON_EMISSIONS" | "TOTAL_SCOPE_3_MBM_CARBON_EMISSIONS" | (string & {});
export type EmissionsTypeList = EmissionsType[];
export type TimeGranularity = "YEARLY_CALENDAR" | "YEARLY_FISCAL" | "QUARTERLY_CALENDAR" | "QUARTERLY_FISCAL" | "MONTHLY" | (string & {});
export type Month = number;
export interface GranularityConfiguration {
    FiscalYearStartMonth?: number;
}
export type MaxResults = number;
export type NextToken = string;
export interface GetEstimatedCarbonEmissionsRequest {
    TimePeriod: TimePeriod;
    GroupBy?: Dimension[];
    FilterBy?: FilterExpression;
    EmissionsTypes?: EmissionsType[];
    Granularity?: TimeGranularity;
    GranularityConfiguration?: GranularityConfiguration;
    MaxResults?: number;
    NextToken?: string;
}
export type DimensionsMap = {
    [key in Dimension]?: string;
};
export type ModelVersion = string;
export type EmissionsUnit = "MTCO2e" | (string & {});
export interface Emissions {
    Value: number;
    Unit: EmissionsUnit;
}
export type EmissionsMap = {
    [key in EmissionsType]?: Emissions;
};
export interface EstimatedCarbonEmissions {
    TimePeriod: TimePeriod;
    DimensionsValues: {
        [key: string]: string | undefined;
    };
    ModelVersion: string;
    EmissionsValues: {
        [key: string]: Emissions | undefined;
    };
}
export type EstimatedCarbonEmissionsList = EstimatedCarbonEmissions[];
export interface GetEstimatedCarbonEmissionsResponse {
    Results: EstimatedCarbonEmissions[];
    NextToken?: string;
}
export interface GetEstimatedCarbonEmissionsDimensionValuesRequest {
    TimePeriod: TimePeriod;
    Dimensions: Dimension[];
    MaxResults?: number;
    NextToken?: string;
}
export interface DimensionEntry {
    Dimension: Dimension;
    Value: string;
}
export type DimensionEntryList = DimensionEntry[];
export interface GetEstimatedCarbonEmissionsDimensionValuesResponse {
    Results?: DimensionEntry[];
    NextToken?: string;
}
export type WaterAllocationType = "TOTAL_WATER_WITHDRAWALS" | (string & {});
export type WaterAllocationTypeList = WaterAllocationType[];
export interface GetEstimatedWaterAllocationRequest {
    TimePeriod: TimePeriod;
    GroupBy?: Dimension[];
    FilterBy?: FilterExpression;
    AllocationTypes?: WaterAllocationType[];
    Granularity?: TimeGranularity;
    MaxResults?: number;
    NextToken?: string;
}
export type WaterAllocationUnit = "m3" | (string & {});
export interface WaterAllocation {
    Value: number;
    Unit: WaterAllocationUnit;
}
export type WaterAllocationMap = {
    [key in WaterAllocationType]?: WaterAllocation;
};
export interface EstimatedWaterAllocation {
    TimePeriod: TimePeriod;
    DimensionsValues: {
        [key: string]: string | undefined;
    };
    ModelVersion: string;
    AllocationValues: {
        [key: string]: WaterAllocation | undefined;
    };
}
export type EstimatedWaterAllocationList = EstimatedWaterAllocation[];
export interface GetEstimatedWaterAllocationResponse {
    Results: EstimatedWaterAllocation[];
    NextToken?: string;
}
export interface GetEstimatedWaterAllocationDimensionValuesRequest {
    TimePeriod: TimePeriod;
    Dimensions: Dimension[];
    MaxResults?: number;
    NextToken?: string;
}
export interface GetEstimatedWaterAllocationDimensionValuesResponse {
    Results: DimensionEntry[];
    NextToken?: string;
}
export type GetEstimatedCarbonEmissionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns estimated carbon emission values based on customer grouping and filtering parameters. We recommend using pagination to ensure that the operation returns quickly and successfully.
 */
export declare const getEstimatedCarbonEmissions: API.PaginatedOperationMethod<GetEstimatedCarbonEmissionsRequest, GetEstimatedCarbonEmissionsResponse, GetEstimatedCarbonEmissionsError, Credentials | HttpClient.HttpClient, EstimatedCarbonEmissions>;
export type GetEstimatedCarbonEmissionsDimensionValuesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the possible dimension values available for a customer's account. We recommend using pagination to ensure that the operation returns quickly and successfully.
 */
export declare const getEstimatedCarbonEmissionsDimensionValues: API.PaginatedOperationMethod<GetEstimatedCarbonEmissionsDimensionValuesRequest, GetEstimatedCarbonEmissionsDimensionValuesResponse, GetEstimatedCarbonEmissionsDimensionValuesError, Credentials | HttpClient.HttpClient, DimensionEntry>;
export type GetEstimatedWaterAllocationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns estimated water allocation values based on customer grouping and filtering parameters. We recommend using pagination to ensure that the operation returns quickly and successfully.
 */
export declare const getEstimatedWaterAllocation: API.PaginatedOperationMethod<GetEstimatedWaterAllocationRequest, GetEstimatedWaterAllocationResponse, GetEstimatedWaterAllocationError, Credentials | HttpClient.HttpClient, EstimatedWaterAllocation>;
export type GetEstimatedWaterAllocationDimensionValuesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the possible dimension values available for a customer's account. We recommend using pagination to ensure that the operation returns quickly and successfully.
 */
export declare const getEstimatedWaterAllocationDimensionValues: API.PaginatedOperationMethod<GetEstimatedWaterAllocationDimensionValuesRequest, GetEstimatedWaterAllocationDimensionValuesResponse, GetEstimatedWaterAllocationDimensionValuesError, Credentials | HttpClient.HttpClient, DimensionEntry>;
export {};
//# sourceMappingURL=sustainability.d.ts.map