import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema";
import * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InternalFailureException_base: S.Class<InternalFailureException, S.TaggedStruct<"InternalFailureException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.Class<ResourceAlreadyExistsException, S.TaggedStruct<"ResourceAlreadyExistsException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceArn: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceInUseException_base: S.Class<ResourceInUseException, S.TaggedStruct<"ResourceInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnsupportedOperationException_base: S.Class<UnsupportedOperationException, S.TaggedStruct<"UnsupportedOperationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
export type AlarmModelName = string;
export type AlarmModelDescription = string;
export type AmazonResourceName = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type Tags = Tag[];
export type AttributeJsonPath = string;
export type Severity = number;
export type InputProperty = string;
export type ComparisonOperator = "GREATER" | "GREATER_OR_EQUAL" | "LESS" | "LESS_OR_EQUAL" | "EQUAL" | "NOT_EQUAL" | (string & {});
export type Threshold = string;
export interface SimpleRule {
    inputProperty: string;
    comparisonOperator: ComparisonOperator;
    threshold: string;
}
export interface AlarmRule {
    simpleRule?: SimpleRule;
}
export type ContentExpression = string;
export type PayloadType = "STRING" | "JSON" | (string & {});
export interface Payload {
    contentExpression: string;
    type: PayloadType;
}
export interface LambdaAction {
    functionArn: string;
    payload?: Payload;
}
export interface NotificationTargetActions {
    lambdaAction?: LambdaAction;
}
export type SMSSenderId = string;
export type NotificationAdditionalMessage = string;
export type IdentityStoreId = string;
export type SSOReferenceId = string;
export interface SSOIdentity {
    identityStoreId: string;
    userId?: string;
}
export interface RecipientDetail {
    ssoIdentity?: SSOIdentity;
}
export type RecipientDetails = RecipientDetail[];
export interface SMSConfiguration {
    senderId?: string;
    additionalMessage?: string;
    recipients: RecipientDetail[];
}
export type SMSConfigurations = SMSConfiguration[];
export type FromEmail = string;
export type EmailSubject = string;
export interface EmailContent {
    subject?: string;
    additionalMessage?: string;
}
export interface EmailRecipients {
    to?: RecipientDetail[];
}
export interface EmailConfiguration {
    from: string;
    content?: EmailContent;
    recipients: EmailRecipients;
}
export type EmailConfigurations = EmailConfiguration[];
export interface NotificationAction {
    action: NotificationTargetActions;
    smsConfigurations?: SMSConfiguration[];
    emailConfigurations?: EmailConfiguration[];
}
export type NotificationActions = NotificationAction[];
export interface AlarmNotification {
    notificationActions?: NotificationAction[];
}
export interface SNSTopicPublishAction {
    targetArn: string;
    payload?: Payload;
}
export type MQTTTopic = string;
export interface IotTopicPublishAction {
    mqttTopic: string;
    payload?: Payload;
}
export type InputName = string;
export interface IotEventsAction {
    inputName: string;
    payload?: Payload;
}
export type QueueUrl = string;
export type UseBase64 = boolean;
export interface SqsAction {
    queueUrl: string;
    useBase64?: boolean;
    payload?: Payload;
}
export type DeliveryStreamName = string;
export type FirehoseSeparator = string;
export interface FirehoseAction {
    deliveryStreamName: string;
    separator?: string;
    payload?: Payload;
}
export type DynamoKeyType = string;
export type DynamoKeyField = string;
export type DynamoKeyValue = string;
export type DynamoOperation = string;
export type DynamoTableName = string;
export interface DynamoDBAction {
    hashKeyType?: string;
    hashKeyField: string;
    hashKeyValue: string;
    rangeKeyType?: string;
    rangeKeyField?: string;
    rangeKeyValue?: string;
    operation?: string;
    payloadField?: string;
    tableName: string;
    payload?: Payload;
}
export interface DynamoDBv2Action {
    tableName: string;
    payload?: Payload;
}
export type AssetPropertyEntryId = string;
export type AssetId = string;
export type AssetPropertyId = string;
export type AssetPropertyAlias = string;
export type AssetPropertyStringValue = string;
export type AssetPropertyIntegerValue = string;
export type AssetPropertyDoubleValue = string;
export type AssetPropertyBooleanValue = string;
export interface AssetPropertyVariant {
    stringValue?: string;
    integerValue?: string;
    doubleValue?: string;
    booleanValue?: string;
}
export type AssetPropertyTimeInSeconds = string;
export type AssetPropertyOffsetInNanos = string;
export interface AssetPropertyTimestamp {
    timeInSeconds: string;
    offsetInNanos?: string;
}
export type AssetPropertyQuality = string;
export interface AssetPropertyValue {
    value?: AssetPropertyVariant;
    timestamp?: AssetPropertyTimestamp;
    quality?: string;
}
export interface IotSiteWiseAction {
    entryId?: string;
    assetId?: string;
    propertyId?: string;
    propertyAlias?: string;
    propertyValue?: AssetPropertyValue;
}
export interface AlarmAction {
    sns?: SNSTopicPublishAction;
    iotTopicPublish?: IotTopicPublishAction;
    lambda?: LambdaAction;
    iotEvents?: IotEventsAction;
    sqs?: SqsAction;
    firehose?: FirehoseAction;
    dynamoDB?: DynamoDBAction;
    dynamoDBv2?: DynamoDBv2Action;
    iotSiteWise?: IotSiteWiseAction;
}
export type AlarmActions = AlarmAction[];
export interface AlarmEventActions {
    alarmActions?: AlarmAction[];
}
export type DisabledOnInitialization = boolean;
export interface InitializationConfiguration {
    disabledOnInitialization: boolean;
}
export type AcknowledgeFlowEnabled = boolean;
export interface AcknowledgeFlow {
    enabled: boolean;
}
export interface AlarmCapabilities {
    initializationConfiguration?: InitializationConfiguration;
    acknowledgeFlow?: AcknowledgeFlow;
}
export interface CreateAlarmModelRequest {
    alarmModelName: string;
    alarmModelDescription?: string;
    roleArn: string;
    tags?: Tag[];
    key?: string;
    severity?: number;
    alarmRule: AlarmRule;
    alarmNotification?: AlarmNotification;
    alarmEventActions?: AlarmEventActions;
    alarmCapabilities?: AlarmCapabilities;
}
export type AlarmModelArn = string;
export type AlarmModelVersion = string;
export type AlarmModelVersionStatus = "ACTIVE" | "ACTIVATING" | "INACTIVE" | "FAILED" | (string & {});
export interface CreateAlarmModelResponse {
    creationTime?: Date;
    alarmModelArn?: string;
    alarmModelVersion?: string;
    lastUpdateTime?: Date;
    status?: AlarmModelVersionStatus;
}
export type DetectorModelName = string;
export type StateName = string;
export type EventName = string;
export type Condition = string;
export type VariableName = string;
export type VariableValue = string;
export interface SetVariableAction {
    variableName: string;
    value: string;
}
export type TimerName = string;
export type Seconds = number;
export interface SetTimerAction {
    timerName: string;
    seconds?: number;
    durationExpression?: string;
}
export interface ClearTimerAction {
    timerName: string;
}
export interface ResetTimerAction {
    timerName: string;
}
export interface Action {
    setVariable?: SetVariableAction;
    sns?: SNSTopicPublishAction;
    iotTopicPublish?: IotTopicPublishAction;
    setTimer?: SetTimerAction;
    clearTimer?: ClearTimerAction;
    resetTimer?: ResetTimerAction;
    lambda?: LambdaAction;
    iotEvents?: IotEventsAction;
    sqs?: SqsAction;
    firehose?: FirehoseAction;
    dynamoDB?: DynamoDBAction;
    dynamoDBv2?: DynamoDBv2Action;
    iotSiteWise?: IotSiteWiseAction;
}
export type Actions = Action[];
export interface Event {
    eventName: string;
    condition?: string;
    actions?: Action[];
}
export type Events = Event[];
export interface TransitionEvent {
    eventName: string;
    condition: string;
    actions?: Action[];
    nextState: string;
}
export type TransitionEvents = TransitionEvent[];
export interface OnInputLifecycle {
    events?: Event[];
    transitionEvents?: TransitionEvent[];
}
export interface OnEnterLifecycle {
    events?: Event[];
}
export interface OnExitLifecycle {
    events?: Event[];
}
export interface State {
    stateName: string;
    onInput?: OnInputLifecycle;
    onEnter?: OnEnterLifecycle;
    onExit?: OnExitLifecycle;
}
export type States = State[];
export interface DetectorModelDefinition {
    states: State[];
    initialStateName: string;
}
export type DetectorModelDescription = string;
export type EvaluationMethod = "BATCH" | "SERIAL" | (string & {});
export interface CreateDetectorModelRequest {
    detectorModelName: string;
    detectorModelDefinition: DetectorModelDefinition;
    detectorModelDescription?: string;
    key?: string;
    roleArn: string;
    tags?: Tag[];
    evaluationMethod?: EvaluationMethod;
}
export type DetectorModelVersion = string;
export type DetectorModelArn = string;
export type DetectorModelVersionStatus = "ACTIVE" | "ACTIVATING" | "INACTIVE" | "DEPRECATED" | "DRAFT" | "PAUSED" | "FAILED" | (string & {});
export interface DetectorModelConfiguration {
    detectorModelName?: string;
    detectorModelVersion?: string;
    detectorModelDescription?: string;
    detectorModelArn?: string;
    roleArn?: string;
    creationTime?: Date;
    lastUpdateTime?: Date;
    status?: DetectorModelVersionStatus;
    key?: string;
    evaluationMethod?: EvaluationMethod;
}
export interface CreateDetectorModelResponse {
    detectorModelConfiguration?: DetectorModelConfiguration;
}
export type InputDescription = string;
export interface Attribute {
    jsonPath: string;
}
export type Attributes = Attribute[];
export interface InputDefinition {
    attributes: Attribute[];
}
export interface CreateInputRequest {
    inputName: string;
    inputDescription?: string;
    inputDefinition: InputDefinition;
    tags?: Tag[];
}
export type InputArn = string;
export type InputStatus = "CREATING" | "UPDATING" | "ACTIVE" | "DELETING" | (string & {});
export interface InputConfiguration {
    inputName: string;
    inputDescription?: string;
    inputArn: string;
    creationTime: Date;
    lastUpdateTime: Date;
    status: InputStatus;
}
export interface CreateInputResponse {
    inputConfiguration?: InputConfiguration;
}
export interface DeleteAlarmModelRequest {
    alarmModelName: string;
}
export interface DeleteAlarmModelResponse {
}
export interface DeleteDetectorModelRequest {
    detectorModelName: string;
}
export interface DeleteDetectorModelResponse {
}
export interface DeleteInputRequest {
    inputName: string;
}
export interface DeleteInputResponse {
}
export interface DescribeAlarmModelRequest {
    alarmModelName: string;
    alarmModelVersion?: string;
}
export type StatusMessage = string;
export interface DescribeAlarmModelResponse {
    creationTime?: Date;
    alarmModelArn?: string;
    alarmModelVersion?: string;
    lastUpdateTime?: Date;
    status?: AlarmModelVersionStatus;
    statusMessage?: string;
    alarmModelName?: string;
    alarmModelDescription?: string;
    roleArn?: string;
    key?: string;
    severity?: number;
    alarmRule?: AlarmRule;
    alarmNotification?: AlarmNotification;
    alarmEventActions?: AlarmEventActions;
    alarmCapabilities?: AlarmCapabilities;
}
export interface DescribeDetectorModelRequest {
    detectorModelName: string;
    detectorModelVersion?: string;
}
export interface DetectorModel {
    detectorModelDefinition?: DetectorModelDefinition;
    detectorModelConfiguration?: DetectorModelConfiguration;
}
export interface DescribeDetectorModelResponse {
    detectorModel?: DetectorModel;
}
export type AnalysisId = string;
export interface DescribeDetectorModelAnalysisRequest {
    analysisId: string;
}
export type AnalysisStatus = "RUNNING" | "COMPLETE" | "FAILED" | (string & {});
export interface DescribeDetectorModelAnalysisResponse {
    status?: AnalysisStatus;
}
export interface DescribeInputRequest {
    inputName: string;
}
export interface Input {
    inputConfiguration?: InputConfiguration;
    inputDefinition?: InputDefinition;
}
export interface DescribeInputResponse {
    input?: Input;
}
export interface DescribeLoggingOptionsRequest {
}
export type LoggingLevel = "ERROR" | "INFO" | "DEBUG" | (string & {});
export type LoggingEnabled = boolean;
export type KeyValue = string;
export interface DetectorDebugOption {
    detectorModelName: string;
    keyValue?: string;
}
export type DetectorDebugOptions = DetectorDebugOption[];
export interface LoggingOptions {
    roleArn: string;
    level: LoggingLevel;
    enabled: boolean;
    detectorDebugOptions?: DetectorDebugOption[];
}
export interface DescribeLoggingOptionsResponse {
    loggingOptions?: LoggingOptions;
}
export type NextToken = string;
export type MaxAnalysisResults = number;
export interface GetDetectorModelAnalysisResultsRequest {
    analysisId: string;
    nextToken?: string;
    maxResults?: number;
}
export type AnalysisType = string;
export type AnalysisResultLevel = "INFO" | "WARNING" | "ERROR" | (string & {});
export type AnalysisMessage = string;
export type AnalysisResultLocationPath = string;
export interface AnalysisResultLocation {
    path?: string;
}
export type AnalysisResultLocations = AnalysisResultLocation[];
export interface AnalysisResult {
    type?: string;
    level?: AnalysisResultLevel;
    message?: string;
    locations?: AnalysisResultLocation[];
}
export type AnalysisResults = AnalysisResult[];
export interface GetDetectorModelAnalysisResultsResponse {
    analysisResults?: AnalysisResult[];
    nextToken?: string;
}
export type MaxResults = number;
export interface ListAlarmModelsRequest {
    nextToken?: string;
    maxResults?: number;
}
export interface AlarmModelSummary {
    creationTime?: Date;
    alarmModelDescription?: string;
    alarmModelName?: string;
}
export type AlarmModelSummaries = AlarmModelSummary[];
export interface ListAlarmModelsResponse {
    alarmModelSummaries?: AlarmModelSummary[];
    nextToken?: string;
}
export interface ListAlarmModelVersionsRequest {
    alarmModelName: string;
    nextToken?: string;
    maxResults?: number;
}
export interface AlarmModelVersionSummary {
    alarmModelName?: string;
    alarmModelArn?: string;
    alarmModelVersion?: string;
    roleArn?: string;
    creationTime?: Date;
    lastUpdateTime?: Date;
    status?: AlarmModelVersionStatus;
    statusMessage?: string;
}
export type AlarmModelVersionSummaries = AlarmModelVersionSummary[];
export interface ListAlarmModelVersionsResponse {
    alarmModelVersionSummaries?: AlarmModelVersionSummary[];
    nextToken?: string;
}
export interface ListDetectorModelsRequest {
    nextToken?: string;
    maxResults?: number;
}
export interface DetectorModelSummary {
    detectorModelName?: string;
    detectorModelDescription?: string;
    creationTime?: Date;
}
export type DetectorModelSummaries = DetectorModelSummary[];
export interface ListDetectorModelsResponse {
    detectorModelSummaries?: DetectorModelSummary[];
    nextToken?: string;
}
export interface ListDetectorModelVersionsRequest {
    detectorModelName: string;
    nextToken?: string;
    maxResults?: number;
}
export interface DetectorModelVersionSummary {
    detectorModelName?: string;
    detectorModelVersion?: string;
    detectorModelArn?: string;
    roleArn?: string;
    creationTime?: Date;
    lastUpdateTime?: Date;
    status?: DetectorModelVersionStatus;
    evaluationMethod?: EvaluationMethod;
}
export type DetectorModelVersionSummaries = DetectorModelVersionSummary[];
export interface ListDetectorModelVersionsResponse {
    detectorModelVersionSummaries?: DetectorModelVersionSummary[];
    nextToken?: string;
}
export interface IotEventsInputIdentifier {
    inputName: string;
}
export type AssetModelId = string;
export interface IotSiteWiseAssetModelPropertyIdentifier {
    assetModelId: string;
    propertyId: string;
}
export interface IotSiteWiseInputIdentifier {
    iotSiteWiseAssetModelPropertyIdentifier?: IotSiteWiseAssetModelPropertyIdentifier;
}
export interface InputIdentifier {
    iotEventsInputIdentifier?: IotEventsInputIdentifier;
    iotSiteWiseInputIdentifier?: IotSiteWiseInputIdentifier;
}
export interface ListInputRoutingsRequest {
    inputIdentifier: InputIdentifier;
    maxResults?: number;
    nextToken?: string;
}
export type ResourceName = string;
export interface RoutedResource {
    name?: string;
    arn?: string;
}
export type RoutedResources = RoutedResource[];
export interface ListInputRoutingsResponse {
    routedResources?: RoutedResource[];
    nextToken?: string;
}
export interface ListInputsRequest {
    nextToken?: string;
    maxResults?: number;
}
export interface InputSummary {
    inputName?: string;
    inputDescription?: string;
    inputArn?: string;
    creationTime?: Date;
    lastUpdateTime?: Date;
    status?: InputStatus;
}
export type InputSummaries = InputSummary[];
export interface ListInputsResponse {
    inputSummaries?: InputSummary[];
    nextToken?: string;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[];
}
export interface PutLoggingOptionsRequest {
    loggingOptions: LoggingOptions;
}
export interface PutLoggingOptionsResponse {
}
export interface StartDetectorModelAnalysisRequest {
    detectorModelDefinition: DetectorModelDefinition;
}
export interface StartDetectorModelAnalysisResponse {
    analysisId?: string;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAlarmModelRequest {
    alarmModelName: string;
    alarmModelDescription?: string;
    roleArn: string;
    severity?: number;
    alarmRule: AlarmRule;
    alarmNotification?: AlarmNotification;
    alarmEventActions?: AlarmEventActions;
    alarmCapabilities?: AlarmCapabilities;
}
export interface UpdateAlarmModelResponse {
    creationTime?: Date;
    alarmModelArn?: string;
    alarmModelVersion?: string;
    lastUpdateTime?: Date;
    status?: AlarmModelVersionStatus;
}
export interface UpdateDetectorModelRequest {
    detectorModelName: string;
    detectorModelDefinition: DetectorModelDefinition;
    detectorModelDescription?: string;
    roleArn: string;
    evaluationMethod?: EvaluationMethod;
}
export interface UpdateDetectorModelResponse {
    detectorModelConfiguration?: DetectorModelConfiguration;
}
export interface UpdateInputRequest {
    inputName: string;
    inputDescription?: string;
    inputDefinition: InputDefinition;
}
export interface UpdateInputResponse {
    inputConfiguration?: InputConfiguration;
}
export type ErrorMessage = string;
export type ResourceId = string;
export type ResourceArn = string;
export type CreateAlarmModelError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Creates an alarm model to monitor an AWS IoT Events input attribute. You can use the alarm to get
 * notified when the value is outside a specified range. For more information, see Create an
 * alarm model in the *AWS IoT Events Developer Guide*.
 */
export declare const createAlarmModel: API.OperationMethod<CreateAlarmModelRequest, CreateAlarmModelResponse, CreateAlarmModelError, Credentials | HttpClient.HttpClient>;
export type CreateDetectorModelError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Creates a detector model.
 */
export declare const createDetectorModel: API.OperationMethod<CreateDetectorModelRequest, CreateDetectorModelResponse, CreateDetectorModelError, Credentials | HttpClient.HttpClient>;
export type CreateInputError = InternalFailureException | InvalidRequestException | ResourceAlreadyExistsException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Creates an input.
 */
export declare const createInput: API.OperationMethod<CreateInputRequest, CreateInputResponse, CreateInputError, Credentials | HttpClient.HttpClient>;
export type DeleteAlarmModelError = InternalFailureException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes an alarm model. Any alarm instances that were created based on this alarm model
 * are also deleted. This action can't be undone.
 */
export declare const deleteAlarmModel: API.OperationMethod<DeleteAlarmModelRequest, DeleteAlarmModelResponse, DeleteAlarmModelError, Credentials | HttpClient.HttpClient>;
export type DeleteDetectorModelError = InternalFailureException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes a detector model. Any active instances of the detector model are also
 * deleted.
 */
export declare const deleteDetectorModel: API.OperationMethod<DeleteDetectorModelRequest, DeleteDetectorModelResponse, DeleteDetectorModelError, Credentials | HttpClient.HttpClient>;
export type DeleteInputError = InternalFailureException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes an input.
 */
export declare const deleteInput: API.OperationMethod<DeleteInputRequest, DeleteInputResponse, DeleteInputError, Credentials | HttpClient.HttpClient>;
export type DescribeAlarmModelError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about an alarm model. If you don't specify a value for the
 * `alarmModelVersion` parameter, the latest version is returned.
 */
export declare const describeAlarmModel: API.OperationMethod<DescribeAlarmModelRequest, DescribeAlarmModelResponse, DescribeAlarmModelError, Credentials | HttpClient.HttpClient>;
export type DescribeDetectorModelError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Describes a detector model. If the `version` parameter is not specified,
 * information about the latest version is returned.
 */
export declare const describeDetectorModel: API.OperationMethod<DescribeDetectorModelRequest, DescribeDetectorModelResponse, DescribeDetectorModelError, Credentials | HttpClient.HttpClient>;
export type DescribeDetectorModelAnalysisError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Retrieves runtime information about a detector model analysis.
 *
 * After AWS IoT Events starts analyzing your detector model, you have up to 24 hours to retrieve the analysis results.
 */
export declare const describeDetectorModelAnalysis: API.OperationMethod<DescribeDetectorModelAnalysisRequest, DescribeDetectorModelAnalysisResponse, DescribeDetectorModelAnalysisError, Credentials | HttpClient.HttpClient>;
export type DescribeInputError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Describes an input.
 */
export declare const describeInput: API.OperationMethod<DescribeInputRequest, DescribeInputResponse, DescribeInputError, Credentials | HttpClient.HttpClient>;
export type DescribeLoggingOptionsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves the current settings of the AWS IoT Events logging options.
 */
export declare const describeLoggingOptions: API.OperationMethod<DescribeLoggingOptionsRequest, DescribeLoggingOptionsResponse, DescribeLoggingOptionsError, Credentials | HttpClient.HttpClient>;
export type GetDetectorModelAnalysisResultsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Retrieves one or more analysis results of the detector model.
 *
 * After AWS IoT Events starts analyzing your detector model, you have up to 24 hours to retrieve the analysis results.
 */
export declare const getDetectorModelAnalysisResults: API.OperationMethod<GetDetectorModelAnalysisResultsRequest, GetDetectorModelAnalysisResultsResponse, GetDetectorModelAnalysisResultsError, Credentials | HttpClient.HttpClient>;
export type ListAlarmModelsError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists the alarm models that you created. The operation returns only the metadata
 * associated with each alarm model.
 */
export declare const listAlarmModels: API.OperationMethod<ListAlarmModelsRequest, ListAlarmModelsResponse, ListAlarmModelsError, Credentials | HttpClient.HttpClient>;
export type ListAlarmModelVersionsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists all the versions of an alarm model. The operation returns only the metadata
 * associated with each alarm model version.
 */
export declare const listAlarmModelVersions: API.OperationMethod<ListAlarmModelVersionsRequest, ListAlarmModelVersionsResponse, ListAlarmModelVersionsError, Credentials | HttpClient.HttpClient>;
export type ListDetectorModelsError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists the detector models you have created. Only the metadata associated with each
 * detector model is returned.
 */
export declare const listDetectorModels: API.OperationMethod<ListDetectorModelsRequest, ListDetectorModelsResponse, ListDetectorModelsError, Credentials | HttpClient.HttpClient>;
export type ListDetectorModelVersionsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists all the versions of a detector model. Only the metadata associated with each
 * detector model version is returned.
 */
export declare const listDetectorModelVersions: API.OperationMethod<ListDetectorModelVersionsRequest, ListDetectorModelVersionsResponse, ListDetectorModelVersionsError, Credentials | HttpClient.HttpClient>;
export type ListInputRoutingsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists one or more input routings.
 */
export declare const listInputRoutings: API.OperationMethod<ListInputRoutingsRequest, ListInputRoutingsResponse, ListInputRoutingsError, Credentials | HttpClient.HttpClient>;
export type ListInputsError = InternalFailureException | InvalidRequestException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists the inputs you have created.
 */
export declare const listInputs: API.OperationMethod<ListInputsRequest, ListInputsResponse, ListInputsError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InternalFailureException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the tags (metadata) you have assigned to the resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutLoggingOptionsError = InternalFailureException | InvalidRequestException | ResourceInUseException | ServiceUnavailableException | ThrottlingException | UnsupportedOperationException | CommonErrors;
/**
 * Sets or updates the AWS IoT Events logging options.
 *
 * If you update the value of any `loggingOptions` field, it takes up to one
 * minute for the change to take effect. If you change the policy attached to the role you
 * specified in the `roleArn` field (for example, to correct an invalid policy), it
 * takes up to five minutes for that change to take effect.
 */
export declare const putLoggingOptions: API.OperationMethod<PutLoggingOptionsRequest, PutLoggingOptionsResponse, PutLoggingOptionsError, Credentials | HttpClient.HttpClient>;
export type StartDetectorModelAnalysisError = InternalFailureException | InvalidRequestException | LimitExceededException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Performs an analysis of your detector model. For more information,
 * see Troubleshooting a detector model
 * in the *AWS IoT Events Developer Guide*.
 */
export declare const startDetectorModelAnalysis: API.OperationMethod<StartDetectorModelAnalysisRequest, StartDetectorModelAnalysisResponse, StartDetectorModelAnalysisError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Adds to or modifies the tags of the given resource. Tags are metadata that can be used to
 * manage a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalFailureException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the given tags (metadata) from the resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAlarmModelError = InternalFailureException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates an alarm model. Any alarms that were created based on the previous version are
 * deleted and then created again as new data arrives.
 */
export declare const updateAlarmModel: API.OperationMethod<UpdateAlarmModelRequest, UpdateAlarmModelResponse, UpdateAlarmModelError, Credentials | HttpClient.HttpClient>;
export type UpdateDetectorModelError = InternalFailureException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates a detector model. Detectors (instances) spawned by the previous version are
 * deleted and then re-created as new inputs arrive.
 */
export declare const updateDetectorModel: API.OperationMethod<UpdateDetectorModelRequest, UpdateDetectorModelResponse, UpdateDetectorModelError, Credentials | HttpClient.HttpClient>;
export type UpdateInputError = InternalFailureException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates an input.
 */
export declare const updateInput: API.OperationMethod<UpdateInputRequest, UpdateInputResponse, UpdateInputError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iot-events.d.ts.map