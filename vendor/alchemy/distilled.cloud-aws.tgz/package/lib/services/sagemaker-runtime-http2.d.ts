import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type * as stream from "effect/Stream";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InputValidationError_base: S.TaggedErrorClass<"InputValidationError", {
    readonly message: any;
    readonly ErrorCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InputValidationError extends /*@__PURE__*/ InputValidationError_base {
}
declare const InternalServerError_base: S.TaggedErrorClass<"InternalServerError", {
    readonly message: any;
    readonly ErrorCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerError extends /*@__PURE__*/ InternalServerError_base {
}
declare const InternalStreamFailure_base: S.TaggedErrorClass<"InternalStreamFailure", {
    readonly message: any;
}>;
export declare class InternalStreamFailure extends /*@__PURE__*/ InternalStreamFailure_base {
}
declare const ModelError_base: S.TaggedErrorClass<"ModelError", {
    readonly message: any;
    readonly OriginalStatusCode: any;
    readonly OriginalMessage: any;
    readonly LogStreamArn: any;
    readonly ErrorCode: any;
}>;
export declare class ModelError extends /*@__PURE__*/ ModelError_base {
}
declare const ModelStreamError_base: S.TaggedErrorClass<"ModelStreamError", {
    readonly message: any;
    readonly ErrorCode: any;
}>;
export declare class ModelStreamError extends /*@__PURE__*/ ModelStreamError_base {
}
declare const ServiceUnavailableError_base: S.TaggedErrorClass<"ServiceUnavailableError", {
    readonly message: any;
    readonly ErrorCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableError extends /*@__PURE__*/ ServiceUnavailableError_base {
}
export type SensitiveBlob = Uint8Array | redacted.Redacted<Uint8Array>;
export interface RequestPayloadPart {
    Bytes?: Uint8Array | redacted.Redacted<Uint8Array>;
    DataType?: string;
    CompletionState?: string;
    P?: string;
}
export type RequestStreamEvent = {
    PayloadPart: RequestPayloadPart;
};
export interface InvokeEndpointWithBidirectionalStreamInput {
    EndpointName: string;
    Body: stream.Stream<RequestStreamEvent, Error, never>;
    TargetVariant?: string;
    ModelInvocationPath?: string;
    ModelQueryString?: string;
}
export interface ResponsePayloadPart {
    Bytes?: Uint8Array | redacted.Redacted<Uint8Array>;
    DataType?: string;
    CompletionState?: string;
    P?: string;
}
export type ResponseStreamEvent = {
    PayloadPart: ResponsePayloadPart;
    ModelStreamError?: never;
    InternalStreamFailure?: never;
} | {
    PayloadPart?: never;
    ModelStreamError: ModelStreamError;
    InternalStreamFailure?: never;
} | {
    PayloadPart?: never;
    ModelStreamError?: never;
    InternalStreamFailure: InternalStreamFailure;
};
export interface InvokeEndpointWithBidirectionalStreamOutput {
    Body: stream.Stream<ResponseStreamEvent, Error, never>;
    InvokedProductionVariant?: string;
}
export type InvokeEndpointWithBidirectionalStreamError = InputValidationError | InternalServerError | InternalStreamFailure | ModelError | ModelStreamError | ServiceUnavailableError | CommonErrors;
/**
 * Invokes a model endpoint with bidirectional streaming capabilities. This operation establishes a persistent connection that allows you to send multiple requests and receive streaming responses from the model in real-time.
 *
 * Bidirectional streaming is useful for interactive applications such as chatbots, real-time translation, or any scenario where you need to maintain a conversation-like interaction with the model. The connection remains open, allowing you to send additional input and receive responses without establishing a new connection for each request.
 *
 * For an overview of Amazon SageMaker AI, see How It Works.
 *
 * Amazon SageMaker AI strips all POST headers except those supported by the API. Amazon SageMaker AI might add additional headers. You should not rely on the behavior of headers outside those enumerated in the request syntax.
 *
 * Calls to `InvokeEndpointWithBidirectionalStream` are authenticated by using Amazon Web Services Signature Version 4. For information, see Authenticating Requests (Amazon Web Services Signature Version 4) in the *Amazon S3 API Reference*.
 *
 * The bidirectional stream maintains the connection until either the client closes it or the model indicates completion. Each request and response in the stream is sent as an event with optional headers for data type and completion state.
 *
 * Endpoints are scoped to an individual account, and are not public. The URL does not contain the account ID, but Amazon SageMaker AI determines the account ID from the authentication token that is supplied by the caller.
 */
export declare const invokeEndpointWithBidirectionalStream: API.OperationMethod<InvokeEndpointWithBidirectionalStreamInput, InvokeEndpointWithBidirectionalStreamOutput, InvokeEndpointWithBidirectionalStreamError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=sagemaker-runtime-http2.d.ts.map