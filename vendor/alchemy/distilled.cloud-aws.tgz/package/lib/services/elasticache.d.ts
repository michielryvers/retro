import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const APICallRateForCustomerExceededFault_base: S.TaggedErrorClass<"APICallRateForCustomerExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class APICallRateForCustomerExceededFault extends /*@__PURE__*/ APICallRateForCustomerExceededFault_base {
}
declare const AuthorizationAlreadyExistsFault_base: S.TaggedErrorClass<"AuthorizationAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AuthorizationAlreadyExistsFault extends /*@__PURE__*/ AuthorizationAlreadyExistsFault_base {
}
declare const AuthorizationNotFoundFault_base: S.TaggedErrorClass<"AuthorizationNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AuthorizationNotFoundFault extends /*@__PURE__*/ AuthorizationNotFoundFault_base {
}
declare const CacheClusterAlreadyExistsFault_base: S.TaggedErrorClass<"CacheClusterAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CacheClusterAlreadyExistsFault extends /*@__PURE__*/ CacheClusterAlreadyExistsFault_base {
}
declare const CacheClusterNotFoundFault_base: S.TaggedErrorClass<"CacheClusterNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheClusterNotFoundFault extends /*@__PURE__*/ CacheClusterNotFoundFault_base {
}
declare const CacheParameterGroupAlreadyExistsFault_base: S.TaggedErrorClass<"CacheParameterGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CacheParameterGroupAlreadyExistsFault extends /*@__PURE__*/ CacheParameterGroupAlreadyExistsFault_base {
}
declare const CacheParameterGroupNotFoundFault_base: S.TaggedErrorClass<"CacheParameterGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheParameterGroupNotFoundFault extends /*@__PURE__*/ CacheParameterGroupNotFoundFault_base {
}
declare const CacheParameterGroupQuotaExceededFault_base: S.TaggedErrorClass<"CacheParameterGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheParameterGroupQuotaExceededFault extends /*@__PURE__*/ CacheParameterGroupQuotaExceededFault_base {
}
declare const CacheSecurityGroupAlreadyExistsFault_base: S.TaggedErrorClass<"CacheSecurityGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CacheSecurityGroupAlreadyExistsFault extends /*@__PURE__*/ CacheSecurityGroupAlreadyExistsFault_base {
}
declare const CacheSecurityGroupNotFoundFault_base: S.TaggedErrorClass<"CacheSecurityGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheSecurityGroupNotFoundFault extends /*@__PURE__*/ CacheSecurityGroupNotFoundFault_base {
}
declare const CacheSecurityGroupQuotaExceededFault_base: S.TaggedErrorClass<"CacheSecurityGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheSecurityGroupQuotaExceededFault extends /*@__PURE__*/ CacheSecurityGroupQuotaExceededFault_base {
}
declare const CacheSubnetGroupAlreadyExistsFault_base: S.TaggedErrorClass<"CacheSubnetGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CacheSubnetGroupAlreadyExistsFault extends /*@__PURE__*/ CacheSubnetGroupAlreadyExistsFault_base {
}
declare const CacheSubnetGroupInUse_base: S.TaggedErrorClass<"CacheSubnetGroupInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class CacheSubnetGroupInUse extends /*@__PURE__*/ CacheSubnetGroupInUse_base {
}
declare const CacheSubnetGroupNotFoundFault_base: S.TaggedErrorClass<"CacheSubnetGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheSubnetGroupNotFoundFault extends /*@__PURE__*/ CacheSubnetGroupNotFoundFault_base {
}
declare const CacheSubnetGroupQuotaExceededFault_base: S.TaggedErrorClass<"CacheSubnetGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheSubnetGroupQuotaExceededFault extends /*@__PURE__*/ CacheSubnetGroupQuotaExceededFault_base {
}
declare const CacheSubnetQuotaExceededFault_base: S.TaggedErrorClass<"CacheSubnetQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheSubnetQuotaExceededFault extends /*@__PURE__*/ CacheSubnetQuotaExceededFault_base {
}
declare const ClusterQuotaForCustomerExceededFault_base: S.TaggedErrorClass<"ClusterQuotaForCustomerExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClusterQuotaForCustomerExceededFault extends /*@__PURE__*/ ClusterQuotaForCustomerExceededFault_base {
}
declare const DefaultUserAssociatedToUserGroupFault_base: S.TaggedErrorClass<"DefaultUserAssociatedToUserGroupFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DefaultUserAssociatedToUserGroupFault extends /*@__PURE__*/ DefaultUserAssociatedToUserGroupFault_base {
}
declare const DefaultUserRequired_base: S.TaggedErrorClass<"DefaultUserRequired", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DefaultUserRequired extends /*@__PURE__*/ DefaultUserRequired_base {
}
declare const DuplicateUserNameFault_base: S.TaggedErrorClass<"DuplicateUserNameFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicateUserNameFault extends /*@__PURE__*/ DuplicateUserNameFault_base {
}
declare const GlobalReplicationGroupAlreadyExistsFault_base: S.TaggedErrorClass<"GlobalReplicationGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class GlobalReplicationGroupAlreadyExistsFault extends /*@__PURE__*/ GlobalReplicationGroupAlreadyExistsFault_base {
}
declare const GlobalReplicationGroupNotFoundFault_base: S.TaggedErrorClass<"GlobalReplicationGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GlobalReplicationGroupNotFoundFault extends /*@__PURE__*/ GlobalReplicationGroupNotFoundFault_base {
}
declare const InsufficientCacheClusterCapacityFault_base: S.TaggedErrorClass<"InsufficientCacheClusterCapacityFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientCacheClusterCapacityFault extends /*@__PURE__*/ InsufficientCacheClusterCapacityFault_base {
}
declare const InvalidARNFault_base: S.TaggedErrorClass<"InvalidARNFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidARNFault extends /*@__PURE__*/ InvalidARNFault_base {
}
declare const InvalidCacheClusterStateFault_base: S.TaggedErrorClass<"InvalidCacheClusterStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidCacheClusterStateFault extends /*@__PURE__*/ InvalidCacheClusterStateFault_base {
}
declare const InvalidCacheParameterGroupStateFault_base: S.TaggedErrorClass<"InvalidCacheParameterGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidCacheParameterGroupStateFault extends /*@__PURE__*/ InvalidCacheParameterGroupStateFault_base {
}
declare const InvalidCacheSecurityGroupStateFault_base: S.TaggedErrorClass<"InvalidCacheSecurityGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidCacheSecurityGroupStateFault extends /*@__PURE__*/ InvalidCacheSecurityGroupStateFault_base {
}
declare const InvalidCredentialsException_base: S.TaggedErrorClass<"InvalidCredentialsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class InvalidCredentialsException extends /*@__PURE__*/ InvalidCredentialsException_base {
}
declare const InvalidGlobalReplicationGroupStateFault_base: S.TaggedErrorClass<"InvalidGlobalReplicationGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidGlobalReplicationGroupStateFault extends /*@__PURE__*/ InvalidGlobalReplicationGroupStateFault_base {
}
declare const InvalidKMSKeyFault_base: S.TaggedErrorClass<"InvalidKMSKeyFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidKMSKeyFault extends /*@__PURE__*/ InvalidKMSKeyFault_base {
}
declare const InvalidParameterCombinationException_base: S.TaggedErrorClass<"InvalidParameterCombinationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterCombinationException extends /*@__PURE__*/ InvalidParameterCombinationException_base {
}
declare const InvalidParameterValueException_base: S.TaggedErrorClass<"InvalidParameterValueException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const InvalidReplicationGroupStateFault_base: S.TaggedErrorClass<"InvalidReplicationGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidReplicationGroupStateFault extends /*@__PURE__*/ InvalidReplicationGroupStateFault_base {
}
declare const InvalidServerlessCacheSnapshotStateFault_base: S.TaggedErrorClass<"InvalidServerlessCacheSnapshotStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidServerlessCacheSnapshotStateFault extends /*@__PURE__*/ InvalidServerlessCacheSnapshotStateFault_base {
}
declare const InvalidServerlessCacheStateFault_base: S.TaggedErrorClass<"InvalidServerlessCacheStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidServerlessCacheStateFault extends /*@__PURE__*/ InvalidServerlessCacheStateFault_base {
}
declare const InvalidSnapshotStateFault_base: S.TaggedErrorClass<"InvalidSnapshotStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSnapshotStateFault extends /*@__PURE__*/ InvalidSnapshotStateFault_base {
}
declare const InvalidSubnet_base: S.TaggedErrorClass<"InvalidSubnet", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSubnet extends /*@__PURE__*/ InvalidSubnet_base {
}
declare const InvalidUserGroupStateFault_base: S.TaggedErrorClass<"InvalidUserGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidUserGroupStateFault extends /*@__PURE__*/ InvalidUserGroupStateFault_base {
}
declare const InvalidUserStateFault_base: S.TaggedErrorClass<"InvalidUserStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidUserStateFault extends /*@__PURE__*/ InvalidUserStateFault_base {
}
declare const InvalidVPCNetworkStateFault_base: S.TaggedErrorClass<"InvalidVPCNetworkStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidVPCNetworkStateFault extends /*@__PURE__*/ InvalidVPCNetworkStateFault_base {
}
declare const NodeGroupNotFoundFault_base: S.TaggedErrorClass<"NodeGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NodeGroupNotFoundFault extends /*@__PURE__*/ NodeGroupNotFoundFault_base {
}
declare const NodeGroupsPerReplicationGroupQuotaExceededFault_base: S.TaggedErrorClass<"NodeGroupsPerReplicationGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NodeGroupsPerReplicationGroupQuotaExceededFault extends /*@__PURE__*/ NodeGroupsPerReplicationGroupQuotaExceededFault_base {
}
declare const NodeQuotaForClusterExceededFault_base: S.TaggedErrorClass<"NodeQuotaForClusterExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NodeQuotaForClusterExceededFault extends /*@__PURE__*/ NodeQuotaForClusterExceededFault_base {
}
declare const NodeQuotaForCustomerExceededFault_base: S.TaggedErrorClass<"NodeQuotaForCustomerExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NodeQuotaForCustomerExceededFault extends /*@__PURE__*/ NodeQuotaForCustomerExceededFault_base {
}
declare const NoOperationFault_base: S.TaggedErrorClass<"NoOperationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoOperationFault extends /*@__PURE__*/ NoOperationFault_base {
}
declare const ReplicationGroupAlreadyExistsFault_base: S.TaggedErrorClass<"ReplicationGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ReplicationGroupAlreadyExistsFault extends /*@__PURE__*/ ReplicationGroupAlreadyExistsFault_base {
}
declare const ReplicationGroupAlreadyUnderMigrationFault_base: S.TaggedErrorClass<"ReplicationGroupAlreadyUnderMigrationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReplicationGroupAlreadyUnderMigrationFault extends /*@__PURE__*/ ReplicationGroupAlreadyUnderMigrationFault_base {
}
declare const ReplicationGroupNotFoundFault_base: S.TaggedErrorClass<"ReplicationGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReplicationGroupNotFoundFault extends /*@__PURE__*/ ReplicationGroupNotFoundFault_base {
}
declare const ReplicationGroupNotUnderMigrationFault_base: S.TaggedErrorClass<"ReplicationGroupNotUnderMigrationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReplicationGroupNotUnderMigrationFault extends /*@__PURE__*/ ReplicationGroupNotUnderMigrationFault_base {
}
declare const ReservedCacheNodeAlreadyExistsFault_base: S.TaggedErrorClass<"ReservedCacheNodeAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ReservedCacheNodeAlreadyExistsFault extends /*@__PURE__*/ ReservedCacheNodeAlreadyExistsFault_base {
}
declare const ReservedCacheNodeNotFoundFault_base: S.TaggedErrorClass<"ReservedCacheNodeNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedCacheNodeNotFoundFault extends /*@__PURE__*/ ReservedCacheNodeNotFoundFault_base {
}
declare const ReservedCacheNodeQuotaExceededFault_base: S.TaggedErrorClass<"ReservedCacheNodeQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedCacheNodeQuotaExceededFault extends /*@__PURE__*/ ReservedCacheNodeQuotaExceededFault_base {
}
declare const ReservedCacheNodesOfferingNotFoundFault_base: S.TaggedErrorClass<"ReservedCacheNodesOfferingNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedCacheNodesOfferingNotFoundFault extends /*@__PURE__*/ ReservedCacheNodesOfferingNotFoundFault_base {
}
declare const ServerlessCacheAlreadyExistsFault_base: S.TaggedErrorClass<"ServerlessCacheAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ServerlessCacheAlreadyExistsFault extends /*@__PURE__*/ ServerlessCacheAlreadyExistsFault_base {
}
declare const ServerlessCacheNotFoundFault_base: S.TaggedErrorClass<"ServerlessCacheNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServerlessCacheNotFoundFault extends /*@__PURE__*/ ServerlessCacheNotFoundFault_base {
}
declare const ServerlessCacheQuotaForCustomerExceededFault_base: S.TaggedErrorClass<"ServerlessCacheQuotaForCustomerExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServerlessCacheQuotaForCustomerExceededFault extends /*@__PURE__*/ ServerlessCacheQuotaForCustomerExceededFault_base {
}
declare const ServerlessCacheSnapshotAlreadyExistsFault_base: S.TaggedErrorClass<"ServerlessCacheSnapshotAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ServerlessCacheSnapshotAlreadyExistsFault extends /*@__PURE__*/ ServerlessCacheSnapshotAlreadyExistsFault_base {
}
declare const ServerlessCacheSnapshotNotFoundFault_base: S.TaggedErrorClass<"ServerlessCacheSnapshotNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServerlessCacheSnapshotNotFoundFault extends /*@__PURE__*/ ServerlessCacheSnapshotNotFoundFault_base {
}
declare const ServerlessCacheSnapshotQuotaExceededFault_base: S.TaggedErrorClass<"ServerlessCacheSnapshotQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServerlessCacheSnapshotQuotaExceededFault extends /*@__PURE__*/ ServerlessCacheSnapshotQuotaExceededFault_base {
}
declare const ServiceLinkedRoleNotFoundFault_base: S.TaggedErrorClass<"ServiceLinkedRoleNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceLinkedRoleNotFoundFault extends /*@__PURE__*/ ServiceLinkedRoleNotFoundFault_base {
}
declare const ServiceUpdateNotFoundFault_base: S.TaggedErrorClass<"ServiceUpdateNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceUpdateNotFoundFault extends /*@__PURE__*/ ServiceUpdateNotFoundFault_base {
}
declare const SnapshotAlreadyExistsFault_base: S.TaggedErrorClass<"SnapshotAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class SnapshotAlreadyExistsFault extends /*@__PURE__*/ SnapshotAlreadyExistsFault_base {
}
declare const SnapshotFeatureNotSupportedFault_base: S.TaggedErrorClass<"SnapshotFeatureNotSupportedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotFeatureNotSupportedFault extends /*@__PURE__*/ SnapshotFeatureNotSupportedFault_base {
}
declare const SnapshotNotFoundFault_base: S.TaggedErrorClass<"SnapshotNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotNotFoundFault extends /*@__PURE__*/ SnapshotNotFoundFault_base {
}
declare const SnapshotQuotaExceededFault_base: S.TaggedErrorClass<"SnapshotQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotQuotaExceededFault extends /*@__PURE__*/ SnapshotQuotaExceededFault_base {
}
declare const SubnetInUse_base: S.TaggedErrorClass<"SubnetInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class SubnetInUse extends /*@__PURE__*/ SubnetInUse_base {
}
declare const SubnetNotAllowedFault_base: S.TaggedErrorClass<"SubnetNotAllowedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubnetNotAllowedFault extends /*@__PURE__*/ SubnetNotAllowedFault_base {
}
declare const TagNotFoundFault_base: S.TaggedErrorClass<"TagNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagNotFoundFault extends /*@__PURE__*/ TagNotFoundFault_base {
}
declare const TagQuotaPerResourceExceeded_base: S.TaggedErrorClass<"TagQuotaPerResourceExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagQuotaPerResourceExceeded extends /*@__PURE__*/ TagQuotaPerResourceExceeded_base {
}
declare const TestFailoverNotAvailableFault_base: S.TaggedErrorClass<"TestFailoverNotAvailableFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TestFailoverNotAvailableFault extends /*@__PURE__*/ TestFailoverNotAvailableFault_base {
}
declare const UserAlreadyExistsFault_base: S.TaggedErrorClass<"UserAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class UserAlreadyExistsFault extends /*@__PURE__*/ UserAlreadyExistsFault_base {
}
declare const UserGroupAlreadyExistsFault_base: S.TaggedErrorClass<"UserGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class UserGroupAlreadyExistsFault extends /*@__PURE__*/ UserGroupAlreadyExistsFault_base {
}
declare const UserGroupNotFoundFault_base: S.TaggedErrorClass<"UserGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserGroupNotFoundFault extends /*@__PURE__*/ UserGroupNotFoundFault_base {
}
declare const UserGroupQuotaExceededFault_base: S.TaggedErrorClass<"UserGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserGroupQuotaExceededFault extends /*@__PURE__*/ UserGroupQuotaExceededFault_base {
}
declare const UserNotFoundFault_base: S.TaggedErrorClass<"UserNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserNotFoundFault extends /*@__PURE__*/ UserNotFoundFault_base {
}
declare const UserQuotaExceededFault_base: S.TaggedErrorClass<"UserQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserQuotaExceededFault extends /*@__PURE__*/ UserQuotaExceededFault_base {
}
export interface Tag {
    Key?: string;
    Value?: string;
}
export type TagList = Tag[];
export interface AddTagsToResourceMessage {
    ResourceName?: string;
    Tags?: Tag[];
}
export interface TagListMessage {
    TagList?: Tag[];
}
export interface AuthorizeCacheSecurityGroupIngressMessage {
    CacheSecurityGroupName?: string;
    EC2SecurityGroupName?: string;
    EC2SecurityGroupOwnerId?: string;
}
export interface EC2SecurityGroup {
    Status?: string;
    EC2SecurityGroupName?: string;
    EC2SecurityGroupOwnerId?: string;
}
export type EC2SecurityGroupList = EC2SecurityGroup[];
export interface CacheSecurityGroup {
    OwnerId?: string;
    CacheSecurityGroupName?: string;
    Description?: string;
    EC2SecurityGroups?: EC2SecurityGroup[];
    ARN?: string;
}
export interface AuthorizeCacheSecurityGroupIngressResult {
    CacheSecurityGroup?: CacheSecurityGroup;
}
export type ReplicationGroupIdList = string[];
export type CacheClusterIdList = string[];
export interface BatchApplyUpdateActionMessage {
    ReplicationGroupIds?: string[];
    CacheClusterIds?: string[];
    ServiceUpdateName?: string;
}
export type UpdateActionStatus = "not-applied" | "waiting-to-start" | "in-progress" | "stopping" | "stopped" | "complete" | "scheduling" | "scheduled" | "not-applicable" | (string & {});
export interface ProcessedUpdateAction {
    ReplicationGroupId?: string;
    CacheClusterId?: string;
    ServiceUpdateName?: string;
    UpdateActionStatus?: UpdateActionStatus;
}
export type ProcessedUpdateActionList = ProcessedUpdateAction[];
export interface UnprocessedUpdateAction {
    ReplicationGroupId?: string;
    CacheClusterId?: string;
    ServiceUpdateName?: string;
    ErrorType?: string;
    ErrorMessage?: string;
}
export type UnprocessedUpdateActionList = UnprocessedUpdateAction[];
export interface UpdateActionResultsMessage {
    ProcessedUpdateActions?: ProcessedUpdateAction[];
    UnprocessedUpdateActions?: UnprocessedUpdateAction[];
}
export interface BatchStopUpdateActionMessage {
    ReplicationGroupIds?: string[];
    CacheClusterIds?: string[];
    ServiceUpdateName?: string;
}
export interface CompleteMigrationMessage {
    ReplicationGroupId?: string;
    Force?: boolean;
}
export interface GlobalReplicationGroupInfo {
    GlobalReplicationGroupId?: string;
    GlobalReplicationGroupMemberRole?: string;
}
export type PendingAutomaticFailoverStatus = "enabled" | "disabled" | (string & {});
export interface SlotMigration {
    ProgressPercentage?: number;
}
export interface ReshardingStatus {
    SlotMigration?: SlotMigration;
}
export type AuthTokenUpdateStatus = "SETTING" | "ROTATING" | (string & {});
export type UserGroupId = string;
export type UserGroupIdList = string[];
export interface UserGroupsUpdateStatus {
    UserGroupIdsToAdd?: string[];
    UserGroupIdsToRemove?: string[];
}
export type LogType = "slow-log" | "engine-log" | (string & {});
export type DestinationType = "cloudwatch-logs" | "kinesis-firehose" | (string & {});
export interface CloudWatchLogsDestinationDetails {
    LogGroup?: string;
}
export interface KinesisFirehoseDestinationDetails {
    DeliveryStream?: string;
}
export interface DestinationDetails {
    CloudWatchLogsDetails?: CloudWatchLogsDestinationDetails;
    KinesisFirehoseDetails?: KinesisFirehoseDestinationDetails;
}
export type LogFormat = "text" | "json" | (string & {});
export interface PendingLogDeliveryConfiguration {
    LogType?: LogType;
    DestinationType?: DestinationType;
    DestinationDetails?: DestinationDetails;
    LogFormat?: LogFormat;
}
export type PendingLogDeliveryConfigurationList = PendingLogDeliveryConfiguration[];
export type TransitEncryptionMode = "preferred" | "required" | (string & {});
export type ClusterMode = "enabled" | "disabled" | "compatible" | (string & {});
export interface ReplicationGroupPendingModifiedValues {
    PrimaryClusterId?: string;
    AutomaticFailoverStatus?: PendingAutomaticFailoverStatus;
    Resharding?: ReshardingStatus;
    AuthTokenStatus?: AuthTokenUpdateStatus;
    UserGroups?: UserGroupsUpdateStatus;
    LogDeliveryConfigurations?: PendingLogDeliveryConfiguration[];
    TransitEncryptionEnabled?: boolean;
    TransitEncryptionMode?: TransitEncryptionMode;
    ClusterMode?: ClusterMode;
}
export type ClusterIdList = string[];
export interface Endpoint {
    Address?: string;
    Port?: number;
}
export interface NodeGroupMember {
    CacheClusterId?: string;
    CacheNodeId?: string;
    ReadEndpoint?: Endpoint;
    PreferredAvailabilityZone?: string;
    PreferredOutpostArn?: string;
    CurrentRole?: string;
}
export type NodeGroupMemberList = NodeGroupMember[];
export interface NodeGroup {
    NodeGroupId?: string;
    Status?: string;
    PrimaryEndpoint?: Endpoint;
    ReaderEndpoint?: Endpoint;
    Slots?: string;
    NodeGroupMembers?: NodeGroupMember[];
}
export type NodeGroupList = NodeGroup[];
export type AutomaticFailoverStatus = "enabled" | "disabled" | "enabling" | "disabling" | (string & {});
export type MultiAZStatus = "enabled" | "disabled" | (string & {});
export type ReplicationGroupOutpostArnList = string[];
export type StorageEncryptionType = "none" | "sse-elasticache" | "sse-kms" | (string & {});
export type LogDeliveryConfigurationStatus = "active" | "enabling" | "modifying" | "disabling" | "error" | (string & {});
export interface LogDeliveryConfiguration {
    LogType?: LogType;
    DestinationType?: DestinationType;
    DestinationDetails?: DestinationDetails;
    LogFormat?: LogFormat;
    Status?: LogDeliveryConfigurationStatus;
    Message?: string;
}
export type LogDeliveryConfigurationList = LogDeliveryConfiguration[];
export type DataTieringStatus = "enabled" | "disabled" | (string & {});
export type NetworkType = "ipv4" | "ipv6" | "dual_stack" | (string & {});
export type IpDiscovery = "ipv4" | "ipv6" | (string & {});
export type Durability = "default" | "async" | "sync" | "disabled" | (string & {});
export type EffectiveDurability = "async" | "sync" | "disabled" | (string & {});
export interface ReplicationGroup {
    ReplicationGroupId?: string;
    Description?: string;
    GlobalReplicationGroupInfo?: GlobalReplicationGroupInfo;
    Status?: string;
    PendingModifiedValues?: ReplicationGroupPendingModifiedValues;
    MemberClusters?: string[];
    NodeGroups?: NodeGroup[];
    SnapshottingClusterId?: string;
    AutomaticFailover?: AutomaticFailoverStatus;
    MultiAZ?: MultiAZStatus;
    ConfigurationEndpoint?: Endpoint;
    SnapshotRetentionLimit?: number;
    SnapshotWindow?: string;
    ClusterEnabled?: boolean;
    CacheNodeType?: string;
    AuthTokenEnabled?: boolean;
    AuthTokenLastModifiedDate?: Date;
    TransitEncryptionEnabled?: boolean;
    AtRestEncryptionEnabled?: boolean;
    MemberClustersOutpostArns?: string[];
    KmsKeyId?: string;
    StorageEncryptionType?: StorageEncryptionType;
    ARN?: string;
    UserGroupIds?: string[];
    LogDeliveryConfigurations?: LogDeliveryConfiguration[];
    ReplicationGroupCreateTime?: Date;
    DataTiering?: DataTieringStatus;
    AutoMinorVersionUpgrade?: boolean;
    NetworkType?: NetworkType;
    IpDiscovery?: IpDiscovery;
    TransitEncryptionMode?: TransitEncryptionMode;
    ClusterMode?: ClusterMode;
    Engine?: string;
    Durability?: Durability;
    EffectiveDurability?: EffectiveDurability;
}
export interface CompleteMigrationResponse {
    ReplicationGroup?: ReplicationGroup;
}
export interface CopyServerlessCacheSnapshotRequest {
    SourceServerlessCacheSnapshotName?: string;
    TargetServerlessCacheSnapshotName?: string;
    KmsKeyId?: string;
    Tags?: Tag[];
}
export interface ServerlessCacheConfiguration {
    ServerlessCacheName?: string;
    Engine?: string;
    MajorEngineVersion?: string;
}
export interface ServerlessCacheSnapshot {
    ServerlessCacheSnapshotName?: string;
    ARN?: string;
    KmsKeyId?: string;
    SnapshotType?: string;
    Status?: string;
    CreateTime?: Date;
    ExpiryTime?: Date;
    BytesUsedForCache?: string;
    ServerlessCacheConfiguration?: ServerlessCacheConfiguration;
}
export interface CopyServerlessCacheSnapshotResponse {
    ServerlessCacheSnapshot?: ServerlessCacheSnapshot;
}
export interface CopySnapshotMessage {
    SourceSnapshotName?: string;
    TargetSnapshotName?: string;
    TargetBucket?: string;
    KmsKeyId?: string;
    Tags?: Tag[];
}
export type AllowedNodeGroupId = string;
export type AvailabilityZonesList = string[];
export type OutpostArnsList = string[];
export interface NodeGroupConfiguration {
    NodeGroupId?: string;
    Slots?: string;
    ReplicaCount?: number;
    PrimaryAvailabilityZone?: string;
    ReplicaAvailabilityZones?: string[];
    PrimaryOutpostArn?: string;
    ReplicaOutpostArns?: string[];
}
export interface NodeSnapshot {
    CacheClusterId?: string;
    NodeGroupId?: string;
    CacheNodeId?: string;
    NodeGroupConfiguration?: NodeGroupConfiguration;
    CacheSize?: string;
    CacheNodeCreateTime?: Date;
    SnapshotCreateTime?: Date;
}
export type NodeSnapshotList = NodeSnapshot[];
export interface Snapshot {
    SnapshotName?: string;
    ReplicationGroupId?: string;
    ReplicationGroupDescription?: string;
    CacheClusterId?: string;
    SnapshotStatus?: string;
    SnapshotSource?: string;
    CacheNodeType?: string;
    Engine?: string;
    EngineVersion?: string;
    NumCacheNodes?: number;
    PreferredAvailabilityZone?: string;
    PreferredOutpostArn?: string;
    CacheClusterCreateTime?: Date;
    PreferredMaintenanceWindow?: string;
    TopicArn?: string;
    Port?: number;
    CacheParameterGroupName?: string;
    CacheSubnetGroupName?: string;
    VpcId?: string;
    AutoMinorVersionUpgrade?: boolean;
    SnapshotRetentionLimit?: number;
    SnapshotWindow?: string;
    NumNodeGroups?: number;
    AutomaticFailover?: AutomaticFailoverStatus;
    NodeSnapshots?: NodeSnapshot[];
    KmsKeyId?: string;
    ARN?: string;
    DataTiering?: DataTieringStatus;
    Durability?: Durability;
}
export interface CopySnapshotResult {
    Snapshot?: Snapshot;
}
export type AZMode = "single-az" | "cross-az" | (string & {});
export type PreferredAvailabilityZoneList = string[];
export type CacheSecurityGroupNameList = string[];
export type SecurityGroupIdsList = string[];
export type SnapshotArnsList = string[];
export type OutpostMode = "single-outpost" | "cross-outpost" | (string & {});
export type PreferredOutpostArnList = string[];
export interface LogDeliveryConfigurationRequest {
    LogType?: LogType;
    DestinationType?: DestinationType;
    DestinationDetails?: DestinationDetails;
    LogFormat?: LogFormat;
    Enabled?: boolean;
}
export type LogDeliveryConfigurationRequestList = LogDeliveryConfigurationRequest[];
export interface CreateCacheClusterMessage {
    CacheClusterId?: string;
    ReplicationGroupId?: string;
    AZMode?: AZMode;
    PreferredAvailabilityZone?: string;
    PreferredAvailabilityZones?: string[];
    NumCacheNodes?: number;
    CacheNodeType?: string;
    Engine?: string;
    EngineVersion?: string;
    CacheParameterGroupName?: string;
    CacheSubnetGroupName?: string;
    CacheSecurityGroupNames?: string[];
    SecurityGroupIds?: string[];
    Tags?: Tag[];
    SnapshotArns?: string[];
    SnapshotName?: string;
    PreferredMaintenanceWindow?: string;
    Port?: number;
    NotificationTopicArn?: string;
    AutoMinorVersionUpgrade?: boolean;
    SnapshotRetentionLimit?: number;
    SnapshotWindow?: string;
    AuthToken?: string | redacted.Redacted<string>;
    OutpostMode?: OutpostMode;
    PreferredOutpostArn?: string;
    PreferredOutpostArns?: string[];
    LogDeliveryConfigurations?: LogDeliveryConfigurationRequest[];
    TransitEncryptionEnabled?: boolean;
    NetworkType?: NetworkType;
    IpDiscovery?: IpDiscovery;
}
export type CacheNodeIdsList = string[];
export interface ScaleConfig {
    ScalePercentage?: number;
    ScaleIntervalMinutes?: number;
}
export interface PendingModifiedValues {
    NumCacheNodes?: number;
    CacheNodeIdsToRemove?: string[];
    EngineVersion?: string;
    CacheNodeType?: string;
    AuthTokenStatus?: AuthTokenUpdateStatus;
    LogDeliveryConfigurations?: PendingLogDeliveryConfiguration[];
    TransitEncryptionEnabled?: boolean;
    TransitEncryptionMode?: TransitEncryptionMode;
    ScaleConfig?: ScaleConfig;
}
export interface NotificationConfiguration {
    TopicArn?: string;
    TopicStatus?: string;
}
export interface CacheSecurityGroupMembership {
    CacheSecurityGroupName?: string;
    Status?: string;
}
export type CacheSecurityGroupMembershipList = CacheSecurityGroupMembership[];
export interface CacheParameterGroupStatus {
    CacheParameterGroupName?: string;
    ParameterApplyStatus?: string;
    CacheNodeIdsToReboot?: string[];
}
export interface CacheNode {
    CacheNodeId?: string;
    CacheNodeStatus?: string;
    CacheNodeCreateTime?: Date;
    Endpoint?: Endpoint;
    ParameterGroupStatus?: string;
    SourceCacheNodeId?: string;
    CustomerAvailabilityZone?: string;
    CustomerOutpostArn?: string;
}
export type CacheNodeList = CacheNode[];
export interface SecurityGroupMembership {
    SecurityGroupId?: string;
    Status?: string;
}
export type SecurityGroupMembershipList = SecurityGroupMembership[];
export interface CacheCluster {
    CacheClusterId?: string;
    ConfigurationEndpoint?: Endpoint;
    ClientDownloadLandingPage?: string;
    CacheNodeType?: string;
    Engine?: string;
    EngineVersion?: string;
    CacheClusterStatus?: string;
    NumCacheNodes?: number;
    PreferredAvailabilityZone?: string;
    PreferredOutpostArn?: string;
    CacheClusterCreateTime?: Date;
    PreferredMaintenanceWindow?: string;
    PendingModifiedValues?: PendingModifiedValues;
    NotificationConfiguration?: NotificationConfiguration;
    CacheSecurityGroups?: CacheSecurityGroupMembership[];
    CacheParameterGroup?: CacheParameterGroupStatus;
    CacheSubnetGroupName?: string;
    CacheNodes?: CacheNode[];
    AutoMinorVersionUpgrade?: boolean;
    SecurityGroups?: SecurityGroupMembership[];
    ReplicationGroupId?: string;
    SnapshotRetentionLimit?: number;
    SnapshotWindow?: string;
    AuthTokenEnabled?: boolean;
    AuthTokenLastModifiedDate?: Date;
    TransitEncryptionEnabled?: boolean;
    AtRestEncryptionEnabled?: boolean;
    ARN?: string;
    ReplicationGroupLogDeliveryEnabled?: boolean;
    LogDeliveryConfigurations?: LogDeliveryConfiguration[];
    NetworkType?: NetworkType;
    IpDiscovery?: IpDiscovery;
    TransitEncryptionMode?: TransitEncryptionMode;
}
export interface CreateCacheClusterResult {
    CacheCluster?: CacheCluster;
}
export interface CreateCacheParameterGroupMessage {
    CacheParameterGroupName?: string;
    CacheParameterGroupFamily?: string;
    Description?: string;
    Tags?: Tag[];
}
export interface CacheParameterGroup {
    CacheParameterGroupName?: string;
    CacheParameterGroupFamily?: string;
    Description?: string;
    IsGlobal?: boolean;
    ARN?: string;
}
export interface CreateCacheParameterGroupResult {
    CacheParameterGroup?: CacheParameterGroup;
}
export interface CreateCacheSecurityGroupMessage {
    CacheSecurityGroupName?: string;
    Description?: string;
    Tags?: Tag[];
}
export interface CreateCacheSecurityGroupResult {
    CacheSecurityGroup?: CacheSecurityGroup;
}
export type SubnetIdentifierList = string[];
export interface CreateCacheSubnetGroupMessage {
    CacheSubnetGroupName?: string;
    CacheSubnetGroupDescription?: string;
    SubnetIds?: string[];
    Tags?: Tag[];
}
export interface AvailabilityZone {
    Name?: string;
}
export interface SubnetOutpost {
    SubnetOutpostArn?: string;
}
export type NetworkTypeList = NetworkType[];
export interface Subnet {
    SubnetIdentifier?: string;
    SubnetAvailabilityZone?: AvailabilityZone;
    SubnetOutpost?: SubnetOutpost;
    SupportedNetworkTypes?: NetworkType[];
}
export type SubnetList = Subnet[];
export interface CacheSubnetGroup {
    CacheSubnetGroupName?: string;
    CacheSubnetGroupDescription?: string;
    VpcId?: string;
    Subnets?: Subnet[];
    ARN?: string;
    SupportedNetworkTypes?: NetworkType[];
}
export interface CreateCacheSubnetGroupResult {
    CacheSubnetGroup?: CacheSubnetGroup;
}
export interface CreateGlobalReplicationGroupMessage {
    GlobalReplicationGroupIdSuffix?: string;
    GlobalReplicationGroupDescription?: string;
    PrimaryReplicationGroupId?: string;
    Tags?: Tag[];
}
export interface GlobalReplicationGroupMember {
    ReplicationGroupId?: string;
    ReplicationGroupRegion?: string;
    Role?: string;
    AutomaticFailover?: AutomaticFailoverStatus;
    Status?: string;
}
export type GlobalReplicationGroupMemberList = GlobalReplicationGroupMember[];
export interface GlobalNodeGroup {
    GlobalNodeGroupId?: string;
    Slots?: string;
}
export type GlobalNodeGroupList = GlobalNodeGroup[];
export interface GlobalReplicationGroup {
    GlobalReplicationGroupId?: string;
    GlobalReplicationGroupDescription?: string;
    Status?: string;
    CacheNodeType?: string;
    Engine?: string;
    EngineVersion?: string;
    Members?: GlobalReplicationGroupMember[];
    ClusterEnabled?: boolean;
    GlobalNodeGroups?: GlobalNodeGroup[];
    AuthTokenEnabled?: boolean;
    TransitEncryptionEnabled?: boolean;
    AtRestEncryptionEnabled?: boolean;
    ARN?: string;
}
export interface CreateGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup;
}
export type NodeGroupConfigurationList = NodeGroupConfiguration[];
export type UserGroupIdListInput = string[];
export interface CreateReplicationGroupMessage {
    ReplicationGroupId?: string;
    ReplicationGroupDescription?: string;
    GlobalReplicationGroupId?: string;
    PrimaryClusterId?: string;
    AutomaticFailoverEnabled?: boolean;
    MultiAZEnabled?: boolean;
    NumCacheClusters?: number;
    PreferredCacheClusterAZs?: string[];
    NumNodeGroups?: number;
    ReplicasPerNodeGroup?: number;
    NodeGroupConfiguration?: NodeGroupConfiguration[];
    CacheNodeType?: string;
    Engine?: string;
    EngineVersion?: string;
    CacheParameterGroupName?: string;
    CacheSubnetGroupName?: string;
    CacheSecurityGroupNames?: string[];
    SecurityGroupIds?: string[];
    Tags?: Tag[];
    SnapshotArns?: string[];
    SnapshotName?: string;
    PreferredMaintenanceWindow?: string;
    Port?: number;
    NotificationTopicArn?: string;
    AutoMinorVersionUpgrade?: boolean;
    SnapshotRetentionLimit?: number;
    SnapshotWindow?: string;
    AuthToken?: string | redacted.Redacted<string>;
    TransitEncryptionEnabled?: boolean;
    AtRestEncryptionEnabled?: boolean;
    KmsKeyId?: string;
    UserGroupIds?: string[];
    LogDeliveryConfigurations?: LogDeliveryConfigurationRequest[];
    DataTieringEnabled?: boolean;
    NetworkType?: NetworkType;
    IpDiscovery?: IpDiscovery;
    TransitEncryptionMode?: TransitEncryptionMode;
    ClusterMode?: ClusterMode;
    ServerlessCacheSnapshotName?: string;
    Durability?: Durability;
}
export interface CreateReplicationGroupResult {
    ReplicationGroup?: ReplicationGroup;
}
export type DataStorageUnit = "GB" | (string & {});
export interface DataStorage {
    Maximum?: number;
    Minimum?: number;
    Unit?: DataStorageUnit;
}
export interface ECPUPerSecond {
    Maximum?: number;
    Minimum?: number;
}
export interface CacheUsageLimits {
    DataStorage?: DataStorage;
    ECPUPerSecond?: ECPUPerSecond;
}
export type SubnetIdsList = string[];
export type ConnectionType = "vpc" | "public" | (string & {});
export interface CreateServerlessCacheRequest {
    ServerlessCacheName?: string;
    Description?: string;
    Engine?: string;
    MajorEngineVersion?: string;
    CacheUsageLimits?: CacheUsageLimits;
    KmsKeyId?: string;
    SecurityGroupIds?: string[];
    SnapshotArnsToRestore?: string[];
    Tags?: Tag[];
    UserGroupId?: string;
    SubnetIds?: string[];
    SnapshotRetentionLimit?: number;
    DailySnapshotTime?: string;
    NetworkType?: NetworkType;
    ConnectionType?: ConnectionType;
}
export interface ServerlessCache {
    ServerlessCacheName?: string;
    Description?: string;
    CreateTime?: Date;
    Status?: string;
    Engine?: string;
    MajorEngineVersion?: string;
    FullEngineVersion?: string;
    CacheUsageLimits?: CacheUsageLimits;
    KmsKeyId?: string;
    StorageEncryptionType?: StorageEncryptionType;
    SecurityGroupIds?: string[];
    Endpoint?: Endpoint;
    ReaderEndpoint?: Endpoint;
    ARN?: string;
    UserGroupId?: string;
    SubnetIds?: string[];
    SnapshotRetentionLimit?: number;
    DailySnapshotTime?: string;
    NetworkType?: NetworkType;
    ConnectionType?: ConnectionType;
}
export interface CreateServerlessCacheResponse {
    ServerlessCache?: ServerlessCache & {
        CacheUsageLimits: CacheUsageLimits & {
            DataStorage: DataStorage & {
                Unit: DataStorageUnit;
            };
        };
    };
}
export interface CreateServerlessCacheSnapshotRequest {
    ServerlessCacheSnapshotName?: string;
    ServerlessCacheName?: string;
    KmsKeyId?: string;
    Tags?: Tag[];
}
export interface CreateServerlessCacheSnapshotResponse {
    ServerlessCacheSnapshot?: ServerlessCacheSnapshot;
}
export interface CreateSnapshotMessage {
    ReplicationGroupId?: string;
    CacheClusterId?: string;
    SnapshotName?: string;
    KmsKeyId?: string;
    Tags?: Tag[];
}
export interface CreateSnapshotResult {
    Snapshot?: Snapshot;
}
export type UserId = string;
export type UserName = string;
export type EngineType = string;
export type PasswordListInput = string[];
export type AccessString = string;
export type InputAuthenticationType = "password" | "no-password-required" | "iam" | (string & {});
export interface AuthenticationMode {
    Type?: InputAuthenticationType;
    Passwords?: Array<string | redacted.Redacted<string>>;
}
export interface CreateUserMessage {
    UserId?: string;
    UserName?: string;
    Engine?: string;
    Passwords?: Array<string | redacted.Redacted<string>>;
    AccessString?: string;
    NoPasswordRequired?: boolean;
    Tags?: Tag[];
    AuthenticationMode?: AuthenticationMode;
}
export type AuthenticationType = "password" | "no-password" | "iam" | (string & {});
export interface Authentication {
    Type?: AuthenticationType;
    PasswordCount?: number;
}
export interface User {
    UserId?: string;
    UserName?: string;
    Status?: string;
    Engine?: string;
    MinimumEngineVersion?: string;
    AccessString?: string;
    UserGroupIds?: string[];
    Authentication?: Authentication;
    ARN?: string;
}
export type UserIdListInput = string[];
export interface CreateUserGroupMessage {
    UserGroupId?: string;
    Engine?: string;
    UserIds?: string[];
    Tags?: Tag[];
}
export type UserIdList = string[];
export interface UserGroupPendingChanges {
    UserIdsToRemove?: string[];
    UserIdsToAdd?: string[];
}
export type UGReplicationGroupIdList = string[];
export type UGServerlessCacheIdList = string[];
export interface UserGroup {
    UserGroupId?: string;
    Status?: string;
    Engine?: string;
    UserIds?: string[];
    MinimumEngineVersion?: string;
    PendingChanges?: UserGroupPendingChanges;
    ReplicationGroups?: string[];
    ServerlessCaches?: string[];
    ARN?: string;
}
export type GlobalNodeGroupIdList = string[];
export interface DecreaseNodeGroupsInGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string;
    NodeGroupCount?: number;
    GlobalNodeGroupsToRemove?: string[];
    GlobalNodeGroupsToRetain?: string[];
    ApplyImmediately?: boolean;
}
export interface DecreaseNodeGroupsInGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup;
}
export interface ConfigureShard {
    NodeGroupId?: string;
    NewReplicaCount?: number;
    PreferredAvailabilityZones?: string[];
    PreferredOutpostArns?: string[];
}
export type ReplicaConfigurationList = ConfigureShard[];
export type RemoveReplicasList = string[];
export interface DecreaseReplicaCountMessage {
    ReplicationGroupId?: string;
    NewReplicaCount?: number;
    ReplicaConfiguration?: ConfigureShard[];
    ReplicasToRemove?: string[];
    ApplyImmediately?: boolean;
}
export interface DecreaseReplicaCountResult {
    ReplicationGroup?: ReplicationGroup;
}
export interface DeleteCacheClusterMessage {
    CacheClusterId?: string;
    FinalSnapshotIdentifier?: string;
}
export interface DeleteCacheClusterResult {
    CacheCluster?: CacheCluster;
}
export interface DeleteCacheParameterGroupMessage {
    CacheParameterGroupName?: string;
}
export interface DeleteCacheParameterGroupResponse {
}
export interface DeleteCacheSecurityGroupMessage {
    CacheSecurityGroupName?: string;
}
export interface DeleteCacheSecurityGroupResponse {
}
export interface DeleteCacheSubnetGroupMessage {
    CacheSubnetGroupName?: string;
}
export interface DeleteCacheSubnetGroupResponse {
}
export interface DeleteGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string;
    RetainPrimaryReplicationGroup?: boolean;
}
export interface DeleteGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup;
}
export interface DeleteReplicationGroupMessage {
    ReplicationGroupId?: string;
    RetainPrimaryCluster?: boolean;
    FinalSnapshotIdentifier?: string;
}
export interface DeleteReplicationGroupResult {
    ReplicationGroup?: ReplicationGroup;
}
export interface DeleteServerlessCacheRequest {
    ServerlessCacheName?: string;
    FinalSnapshotName?: string;
}
export interface DeleteServerlessCacheResponse {
    ServerlessCache?: ServerlessCache & {
        CacheUsageLimits: CacheUsageLimits & {
            DataStorage: DataStorage & {
                Unit: DataStorageUnit;
            };
        };
    };
}
export interface DeleteServerlessCacheSnapshotRequest {
    ServerlessCacheSnapshotName?: string;
}
export interface DeleteServerlessCacheSnapshotResponse {
    ServerlessCacheSnapshot?: ServerlessCacheSnapshot;
}
export interface DeleteSnapshotMessage {
    SnapshotName?: string;
}
export interface DeleteSnapshotResult {
    Snapshot?: Snapshot;
}
export interface DeleteUserMessage {
    UserId?: string;
}
export interface DeleteUserGroupMessage {
    UserGroupId?: string;
}
export interface DescribeCacheClustersMessage {
    CacheClusterId?: string;
    MaxRecords?: number;
    Marker?: string;
    ShowCacheNodeInfo?: boolean;
    ShowCacheClustersNotInReplicationGroups?: boolean;
}
export type CacheClusterList = CacheCluster[];
export interface CacheClusterMessage {
    Marker?: string;
    CacheClusters?: CacheCluster[];
}
export interface DescribeCacheEngineVersionsMessage {
    Engine?: string;
    EngineVersion?: string;
    CacheParameterGroupFamily?: string;
    MaxRecords?: number;
    Marker?: string;
    DefaultOnly?: boolean;
}
export interface CacheEngineVersion {
    Engine?: string;
    EngineVersion?: string;
    CacheParameterGroupFamily?: string;
    CacheEngineDescription?: string;
    CacheEngineVersionDescription?: string;
}
export type CacheEngineVersionList = CacheEngineVersion[];
export interface CacheEngineVersionMessage {
    Marker?: string;
    CacheEngineVersions?: CacheEngineVersion[];
}
export interface DescribeCacheParameterGroupsMessage {
    CacheParameterGroupName?: string;
    MaxRecords?: number;
    Marker?: string;
}
export type CacheParameterGroupList = CacheParameterGroup[];
export interface CacheParameterGroupsMessage {
    Marker?: string;
    CacheParameterGroups?: CacheParameterGroup[];
}
export interface DescribeCacheParametersMessage {
    CacheParameterGroupName?: string;
    Source?: string;
    MaxRecords?: number;
    Marker?: string;
}
export type ChangeType = "immediate" | "requires-reboot" | (string & {});
export interface Parameter {
    ParameterName?: string;
    ParameterValue?: string;
    Description?: string;
    Source?: string;
    DataType?: string;
    AllowedValues?: string;
    IsModifiable?: boolean;
    MinimumEngineVersion?: string;
    ChangeType?: ChangeType;
}
export type ParametersList = Parameter[];
export interface CacheNodeTypeSpecificValue {
    CacheNodeType?: string;
    Value?: string;
}
export type CacheNodeTypeSpecificValueList = CacheNodeTypeSpecificValue[];
export interface CacheNodeTypeSpecificParameter {
    ParameterName?: string;
    Description?: string;
    Source?: string;
    DataType?: string;
    AllowedValues?: string;
    IsModifiable?: boolean;
    MinimumEngineVersion?: string;
    CacheNodeTypeSpecificValues?: CacheNodeTypeSpecificValue[];
    ChangeType?: ChangeType;
}
export type CacheNodeTypeSpecificParametersList = CacheNodeTypeSpecificParameter[];
export interface CacheParameterGroupDetails {
    Marker?: string;
    Parameters?: Parameter[];
    CacheNodeTypeSpecificParameters?: CacheNodeTypeSpecificParameter[];
}
export interface DescribeCacheSecurityGroupsMessage {
    CacheSecurityGroupName?: string;
    MaxRecords?: number;
    Marker?: string;
}
export type CacheSecurityGroups = CacheSecurityGroup[];
export interface CacheSecurityGroupMessage {
    Marker?: string;
    CacheSecurityGroups?: CacheSecurityGroup[];
}
export interface DescribeCacheSubnetGroupsMessage {
    CacheSubnetGroupName?: string;
    MaxRecords?: number;
    Marker?: string;
}
export type CacheSubnetGroups = CacheSubnetGroup[];
export interface CacheSubnetGroupMessage {
    Marker?: string;
    CacheSubnetGroups?: CacheSubnetGroup[];
}
export interface DescribeEngineDefaultParametersMessage {
    CacheParameterGroupFamily?: string;
    MaxRecords?: number;
    Marker?: string;
}
export interface EngineDefaults {
    CacheParameterGroupFamily?: string;
    Marker?: string;
    Parameters?: Parameter[];
    CacheNodeTypeSpecificParameters?: CacheNodeTypeSpecificParameter[];
}
export interface DescribeEngineDefaultParametersResult {
    EngineDefaults?: EngineDefaults;
}
export type SourceType = "cache-cluster" | "cache-parameter-group" | "cache-security-group" | "cache-subnet-group" | "replication-group" | "serverless-cache" | "serverless-cache-snapshot" | "user" | "user-group" | (string & {});
export interface DescribeEventsMessage {
    SourceIdentifier?: string;
    SourceType?: SourceType;
    StartTime?: Date;
    EndTime?: Date;
    Duration?: number;
    MaxRecords?: number;
    Marker?: string;
}
export interface Event {
    SourceIdentifier?: string;
    SourceType?: SourceType;
    Message?: string;
    Date?: Date;
}
export type EventList = Event[];
export interface EventsMessage {
    Marker?: string;
    Events?: Event[];
}
export interface DescribeGlobalReplicationGroupsMessage {
    GlobalReplicationGroupId?: string;
    MaxRecords?: number;
    Marker?: string;
    ShowMemberInfo?: boolean;
}
export type GlobalReplicationGroupList = GlobalReplicationGroup[];
export interface DescribeGlobalReplicationGroupsResult {
    Marker?: string;
    GlobalReplicationGroups?: GlobalReplicationGroup[];
}
export interface DescribeReplicationGroupsMessage {
    ReplicationGroupId?: string;
    MaxRecords?: number;
    Marker?: string;
}
export type ReplicationGroupList = ReplicationGroup[];
export interface ReplicationGroupMessage {
    Marker?: string;
    ReplicationGroups?: ReplicationGroup[];
}
export interface DescribeReservedCacheNodesMessage {
    ReservedCacheNodeId?: string;
    ReservedCacheNodesOfferingId?: string;
    CacheNodeType?: string;
    Duration?: string;
    ProductDescription?: string;
    OfferingType?: string;
    MaxRecords?: number;
    Marker?: string;
}
export interface RecurringCharge {
    RecurringChargeAmount?: number;
    RecurringChargeFrequency?: string;
}
export type RecurringChargeList = RecurringCharge[];
export interface ReservedCacheNode {
    ReservedCacheNodeId?: string;
    ReservedCacheNodesOfferingId?: string;
    CacheNodeType?: string;
    StartTime?: Date;
    Duration?: number;
    FixedPrice?: number;
    UsagePrice?: number;
    CacheNodeCount?: number;
    ProductDescription?: string;
    OfferingType?: string;
    State?: string;
    RecurringCharges?: RecurringCharge[];
    ReservationARN?: string;
}
export type ReservedCacheNodeList = ReservedCacheNode[];
export interface ReservedCacheNodeMessage {
    Marker?: string;
    ReservedCacheNodes?: ReservedCacheNode[];
}
export interface DescribeReservedCacheNodesOfferingsMessage {
    ReservedCacheNodesOfferingId?: string;
    CacheNodeType?: string;
    Duration?: string;
    ProductDescription?: string;
    OfferingType?: string;
    MaxRecords?: number;
    Marker?: string;
}
export interface ReservedCacheNodesOffering {
    ReservedCacheNodesOfferingId?: string;
    CacheNodeType?: string;
    Duration?: number;
    FixedPrice?: number;
    UsagePrice?: number;
    ProductDescription?: string;
    OfferingType?: string;
    RecurringCharges?: RecurringCharge[];
}
export type ReservedCacheNodesOfferingList = ReservedCacheNodesOffering[];
export interface ReservedCacheNodesOfferingMessage {
    Marker?: string;
    ReservedCacheNodesOfferings?: ReservedCacheNodesOffering[];
}
export interface DescribeServerlessCachesRequest {
    ServerlessCacheName?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type ServerlessCacheList = ServerlessCache[];
export interface DescribeServerlessCachesResponse {
    NextToken?: string;
    ServerlessCaches?: (ServerlessCache & {
        CacheUsageLimits: CacheUsageLimits & {
            DataStorage: DataStorage & {
                Unit: DataStorageUnit;
            };
        };
    })[];
}
export interface DescribeServerlessCacheSnapshotsRequest {
    ServerlessCacheName?: string;
    ServerlessCacheSnapshotName?: string;
    SnapshotType?: string;
    NextToken?: string;
    MaxResults?: number;
}
export type ServerlessCacheSnapshotList = ServerlessCacheSnapshot[];
export interface DescribeServerlessCacheSnapshotsResponse {
    NextToken?: string;
    ServerlessCacheSnapshots?: ServerlessCacheSnapshot[];
}
export type ServiceUpdateStatus = "available" | "cancelled" | "expired" | (string & {});
export type ServiceUpdateStatusList = ServiceUpdateStatus[];
export interface DescribeServiceUpdatesMessage {
    ServiceUpdateName?: string;
    ServiceUpdateStatus?: ServiceUpdateStatus[];
    MaxRecords?: number;
    Marker?: string;
}
export type ServiceUpdateSeverity = "critical" | "important" | "medium" | "low" | (string & {});
export type ServiceUpdateType = "security-update" | (string & {});
export interface ServiceUpdate {
    ServiceUpdateName?: string;
    ServiceUpdateReleaseDate?: Date;
    ServiceUpdateEndDate?: Date;
    ServiceUpdateSeverity?: ServiceUpdateSeverity;
    ServiceUpdateRecommendedApplyByDate?: Date;
    ServiceUpdateStatus?: ServiceUpdateStatus;
    ServiceUpdateDescription?: string;
    ServiceUpdateType?: ServiceUpdateType;
    Engine?: string;
    EngineVersion?: string;
    AutoUpdateAfterRecommendedApplyByDate?: boolean;
    EstimatedUpdateTime?: string;
}
export type ServiceUpdateList = ServiceUpdate[];
export interface ServiceUpdatesMessage {
    Marker?: string;
    ServiceUpdates?: ServiceUpdate[];
}
export interface DescribeSnapshotsMessage {
    ReplicationGroupId?: string;
    CacheClusterId?: string;
    SnapshotName?: string;
    SnapshotSource?: string;
    Marker?: string;
    MaxRecords?: number;
    ShowNodeGroupConfig?: boolean;
}
export type SnapshotList = Snapshot[];
export interface DescribeSnapshotsListMessage {
    Marker?: string;
    Snapshots?: Snapshot[];
}
export interface TimeRangeFilter {
    StartTime?: Date;
    EndTime?: Date;
}
export type UpdateActionStatusList = UpdateActionStatus[];
export interface DescribeUpdateActionsMessage {
    ServiceUpdateName?: string;
    ReplicationGroupIds?: string[];
    CacheClusterIds?: string[];
    Engine?: string;
    ServiceUpdateStatus?: ServiceUpdateStatus[];
    ServiceUpdateTimeRange?: TimeRangeFilter;
    UpdateActionStatus?: UpdateActionStatus[];
    ShowNodeLevelUpdateStatus?: boolean;
    MaxRecords?: number;
    Marker?: string;
}
export type SlaMet = "yes" | "no" | "n/a" | (string & {});
export type NodeUpdateStatus = "not-applied" | "waiting-to-start" | "in-progress" | "stopping" | "stopped" | "complete" | (string & {});
export type NodeUpdateInitiatedBy = "system" | "customer" | (string & {});
export interface NodeGroupMemberUpdateStatus {
    CacheClusterId?: string;
    CacheNodeId?: string;
    NodeUpdateStatus?: NodeUpdateStatus;
    NodeDeletionDate?: Date;
    NodeUpdateStartDate?: Date;
    NodeUpdateEndDate?: Date;
    NodeUpdateInitiatedBy?: NodeUpdateInitiatedBy;
    NodeUpdateInitiatedDate?: Date;
    NodeUpdateStatusModifiedDate?: Date;
}
export type NodeGroupMemberUpdateStatusList = NodeGroupMemberUpdateStatus[];
export interface NodeGroupUpdateStatus {
    NodeGroupId?: string;
    NodeGroupMemberUpdateStatus?: NodeGroupMemberUpdateStatus[];
}
export type NodeGroupUpdateStatusList = NodeGroupUpdateStatus[];
export interface CacheNodeUpdateStatus {
    CacheNodeId?: string;
    NodeUpdateStatus?: NodeUpdateStatus;
    NodeDeletionDate?: Date;
    NodeUpdateStartDate?: Date;
    NodeUpdateEndDate?: Date;
    NodeUpdateInitiatedBy?: NodeUpdateInitiatedBy;
    NodeUpdateInitiatedDate?: Date;
    NodeUpdateStatusModifiedDate?: Date;
}
export type CacheNodeUpdateStatusList = CacheNodeUpdateStatus[];
export interface UpdateAction {
    ReplicationGroupId?: string;
    CacheClusterId?: string;
    ServiceUpdateName?: string;
    ServiceUpdateReleaseDate?: Date;
    ServiceUpdateSeverity?: ServiceUpdateSeverity;
    ServiceUpdateStatus?: ServiceUpdateStatus;
    ServiceUpdateRecommendedApplyByDate?: Date;
    ServiceUpdateType?: ServiceUpdateType;
    UpdateActionAvailableDate?: Date;
    UpdateActionStatus?: UpdateActionStatus;
    NodesUpdated?: string;
    UpdateActionStatusModifiedDate?: Date;
    SlaMet?: SlaMet;
    NodeGroupUpdateStatus?: NodeGroupUpdateStatus[];
    CacheNodeUpdateStatus?: CacheNodeUpdateStatus[];
    EstimatedUpdateTime?: string;
    Engine?: string;
}
export type UpdateActionList = UpdateAction[];
export interface UpdateActionsMessage {
    Marker?: string;
    UpdateActions?: UpdateAction[];
}
export interface DescribeUserGroupsMessage {
    UserGroupId?: string;
    MaxRecords?: number;
    Marker?: string;
}
export type UserGroupList = UserGroup[];
export interface DescribeUserGroupsResult {
    UserGroups?: UserGroup[];
    Marker?: string;
}
export type FilterName = string;
export type FilterValue = string;
export type FilterValueList = string[];
export interface Filter {
    Name?: string;
    Values?: string[];
}
export type FilterList = Filter[];
export interface DescribeUsersMessage {
    Engine?: string;
    UserId?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export type UserList = User[];
export interface DescribeUsersResult {
    Users?: User[];
    Marker?: string;
}
export interface DisassociateGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string;
    ReplicationGroupId?: string;
    ReplicationGroupRegion?: string;
}
export interface DisassociateGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup;
}
export interface ExportServerlessCacheSnapshotRequest {
    ServerlessCacheSnapshotName?: string;
    S3BucketName?: string;
}
export interface ExportServerlessCacheSnapshotResponse {
    ServerlessCacheSnapshot?: ServerlessCacheSnapshot;
}
export interface FailoverGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string;
    PrimaryRegion?: string;
    PrimaryReplicationGroupId?: string;
}
export interface FailoverGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup;
}
export interface ReshardingConfiguration {
    NodeGroupId?: string;
    PreferredAvailabilityZones?: string[];
}
export type ReshardingConfigurationList = ReshardingConfiguration[];
export interface RegionalConfiguration {
    ReplicationGroupId?: string;
    ReplicationGroupRegion?: string;
    ReshardingConfiguration?: ReshardingConfiguration[];
}
export type RegionalConfigurationList = RegionalConfiguration[];
export interface IncreaseNodeGroupsInGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string;
    NodeGroupCount?: number;
    RegionalConfigurations?: RegionalConfiguration[];
    ApplyImmediately?: boolean;
}
export interface IncreaseNodeGroupsInGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup;
}
export interface IncreaseReplicaCountMessage {
    ReplicationGroupId?: string;
    NewReplicaCount?: number;
    ReplicaConfiguration?: ConfigureShard[];
    ApplyImmediately?: boolean;
}
export interface IncreaseReplicaCountResult {
    ReplicationGroup?: ReplicationGroup;
}
export interface ListAllowedNodeTypeModificationsMessage {
    CacheClusterId?: string;
    ReplicationGroupId?: string;
}
export type NodeTypeList = string[];
export interface AllowedNodeTypeModificationsMessage {
    ScaleUpModifications?: string[];
    ScaleDownModifications?: string[];
}
export interface ListTagsForResourceMessage {
    ResourceName?: string;
}
export type AuthTokenUpdateStrategyType = "SET" | "ROTATE" | "DELETE" | (string & {});
export interface ModifyCacheClusterMessage {
    CacheClusterId?: string;
    NumCacheNodes?: number;
    CacheNodeIdsToRemove?: string[];
    AZMode?: AZMode;
    NewAvailabilityZones?: string[];
    CacheSecurityGroupNames?: string[];
    SecurityGroupIds?: string[];
    PreferredMaintenanceWindow?: string;
    NotificationTopicArn?: string;
    CacheParameterGroupName?: string;
    NotificationTopicStatus?: string;
    ApplyImmediately?: boolean;
    Engine?: string;
    EngineVersion?: string;
    AutoMinorVersionUpgrade?: boolean;
    SnapshotRetentionLimit?: number;
    SnapshotWindow?: string;
    CacheNodeType?: string;
    AuthToken?: string | redacted.Redacted<string>;
    AuthTokenUpdateStrategy?: AuthTokenUpdateStrategyType;
    LogDeliveryConfigurations?: LogDeliveryConfigurationRequest[];
    IpDiscovery?: IpDiscovery;
    ScaleConfig?: ScaleConfig;
}
export interface ModifyCacheClusterResult {
    CacheCluster?: CacheCluster;
}
export interface ParameterNameValue {
    ParameterName?: string;
    ParameterValue?: string;
}
export type ParameterNameValueList = ParameterNameValue[];
export interface ModifyCacheParameterGroupMessage {
    CacheParameterGroupName?: string;
    ParameterNameValues?: ParameterNameValue[];
}
export interface CacheParameterGroupNameMessage {
    CacheParameterGroupName?: string;
}
export interface ModifyCacheSubnetGroupMessage {
    CacheSubnetGroupName?: string;
    CacheSubnetGroupDescription?: string;
    SubnetIds?: string[];
}
export interface ModifyCacheSubnetGroupResult {
    CacheSubnetGroup?: CacheSubnetGroup;
}
export interface ModifyGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string;
    ApplyImmediately?: boolean;
    CacheNodeType?: string;
    Engine?: string;
    EngineVersion?: string;
    CacheParameterGroupName?: string;
    GlobalReplicationGroupDescription?: string;
    AutomaticFailoverEnabled?: boolean;
}
export interface ModifyGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup;
}
export interface ModifyReplicationGroupMessage {
    ReplicationGroupId?: string;
    ReplicationGroupDescription?: string;
    PrimaryClusterId?: string;
    SnapshottingClusterId?: string;
    AutomaticFailoverEnabled?: boolean;
    MultiAZEnabled?: boolean;
    NodeGroupId?: string;
    CacheSecurityGroupNames?: string[];
    SecurityGroupIds?: string[];
    PreferredMaintenanceWindow?: string;
    NotificationTopicArn?: string;
    CacheParameterGroupName?: string;
    NotificationTopicStatus?: string;
    ApplyImmediately?: boolean;
    Engine?: string;
    EngineVersion?: string;
    AutoMinorVersionUpgrade?: boolean;
    SnapshotRetentionLimit?: number;
    SnapshotWindow?: string;
    CacheNodeType?: string;
    AuthToken?: string | redacted.Redacted<string>;
    AuthTokenUpdateStrategy?: AuthTokenUpdateStrategyType;
    UserGroupIdsToAdd?: string[];
    UserGroupIdsToRemove?: string[];
    RemoveUserGroups?: boolean;
    LogDeliveryConfigurations?: LogDeliveryConfigurationRequest[];
    IpDiscovery?: IpDiscovery;
    TransitEncryptionEnabled?: boolean;
    TransitEncryptionMode?: TransitEncryptionMode;
    ClusterMode?: ClusterMode;
    Durability?: Durability;
}
export interface ModifyReplicationGroupResult {
    ReplicationGroup?: ReplicationGroup;
}
export type NodeGroupsToRemoveList = string[];
export type NodeGroupsToRetainList = string[];
export interface ModifyReplicationGroupShardConfigurationMessage {
    ReplicationGroupId?: string;
    NodeGroupCount?: number;
    ApplyImmediately?: boolean;
    ReshardingConfiguration?: ReshardingConfiguration[];
    NodeGroupsToRemove?: string[];
    NodeGroupsToRetain?: string[];
}
export interface ModifyReplicationGroupShardConfigurationResult {
    ReplicationGroup?: ReplicationGroup;
}
export interface ModifyServerlessCacheRequest {
    ServerlessCacheName?: string;
    Description?: string;
    CacheUsageLimits?: CacheUsageLimits;
    RemoveUserGroup?: boolean;
    UserGroupId?: string;
    SecurityGroupIds?: string[];
    SnapshotRetentionLimit?: number;
    DailySnapshotTime?: string;
    Engine?: string;
    MajorEngineVersion?: string;
}
export interface ModifyServerlessCacheResponse {
    ServerlessCache?: ServerlessCache & {
        CacheUsageLimits: CacheUsageLimits & {
            DataStorage: DataStorage & {
                Unit: DataStorageUnit;
            };
        };
    };
}
export interface ModifyUserMessage {
    UserId?: string;
    AccessString?: string;
    AppendAccessString?: string;
    Passwords?: Array<string | redacted.Redacted<string>>;
    NoPasswordRequired?: boolean;
    AuthenticationMode?: AuthenticationMode;
    Engine?: string;
}
export interface ModifyUserGroupMessage {
    UserGroupId?: string;
    UserIdsToAdd?: string[];
    UserIdsToRemove?: string[];
    Engine?: string;
}
export interface PurchaseReservedCacheNodesOfferingMessage {
    ReservedCacheNodesOfferingId?: string;
    ReservedCacheNodeId?: string;
    CacheNodeCount?: number;
    Tags?: Tag[];
}
export interface PurchaseReservedCacheNodesOfferingResult {
    ReservedCacheNode?: ReservedCacheNode;
}
export interface RebalanceSlotsInGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string;
    ApplyImmediately?: boolean;
}
export interface RebalanceSlotsInGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup;
}
export interface RebootCacheClusterMessage {
    CacheClusterId?: string;
    CacheNodeIdsToReboot?: string[];
}
export interface RebootCacheClusterResult {
    CacheCluster?: CacheCluster;
}
export type KeyList = string[];
export interface RemoveTagsFromResourceMessage {
    ResourceName?: string;
    TagKeys?: string[];
}
export interface ResetCacheParameterGroupMessage {
    CacheParameterGroupName?: string;
    ResetAllParameters?: boolean;
    ParameterNameValues?: ParameterNameValue[];
}
export interface RevokeCacheSecurityGroupIngressMessage {
    CacheSecurityGroupName?: string;
    EC2SecurityGroupName?: string;
    EC2SecurityGroupOwnerId?: string;
}
export interface RevokeCacheSecurityGroupIngressResult {
    CacheSecurityGroup?: CacheSecurityGroup;
}
export interface CustomerNodeEndpoint {
    Address?: string;
    Port?: number;
}
export type CustomerNodeEndpointList = CustomerNodeEndpoint[];
export interface StartMigrationMessage {
    ReplicationGroupId?: string;
    CustomerNodeEndpointList?: CustomerNodeEndpoint[];
}
export interface StartMigrationResponse {
    ReplicationGroup?: ReplicationGroup;
}
export interface TestFailoverMessage {
    ReplicationGroupId?: string;
    NodeGroupId?: string;
}
export interface TestFailoverResult {
    ReplicationGroup?: ReplicationGroup;
}
export interface TestMigrationMessage {
    ReplicationGroupId?: string;
    CustomerNodeEndpointList?: CustomerNodeEndpoint[];
}
export interface TestMigrationResponse {
    ReplicationGroup?: ReplicationGroup;
}
export type ExceptionMessage = string;
export type AwsQueryErrorMessage = string;
export type AddTagsToResourceError = CacheClusterNotFoundFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | CacheSubnetGroupNotFoundFault | GlobalReplicationGroupNotFoundFault | InvalidARNFault | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidServerlessCacheSnapshotStateFault | InvalidServerlessCacheStateFault | ReplicationGroupNotFoundFault | ReservedCacheNodeNotFoundFault | ServerlessCacheNotFoundFault | ServerlessCacheSnapshotNotFoundFault | SnapshotNotFoundFault | TagQuotaPerResourceExceeded | UserGroupNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * A tag is a key-value pair where the key and value are case-sensitive. You can use tags
 * to categorize and track all your ElastiCache resources.
 * When you add or remove tags on replication groups, those actions will
 * be replicated to all nodes in the replication group. For more information, see Resource-level permissions.
 *
 * For example, you can use cost-allocation tags to your ElastiCache resources, Amazon
 * generates a cost allocation report as a comma-separated value (CSV) file with your usage
 * and costs aggregated by your tags. You can apply tags that represent business categories
 * (such as cost centers, application names, or owners) to organize your costs across
 * multiple services.
 *
 * For more information, see Using Cost Allocation Tags in
 * Amazon ElastiCache in the ElastiCache User
 * Guide.
 */
export declare const addTagsToResource: API.OperationMethod<AddTagsToResourceMessage, TagListMessage, AddTagsToResourceError, Credentials | HttpClient.HttpClient>;
export type AuthorizeCacheSecurityGroupIngressError = AuthorizationAlreadyExistsFault | CacheSecurityGroupNotFoundFault | InvalidCacheSecurityGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Allows network ingress to a cache security group. Applications using ElastiCache must
 * be running on Amazon EC2, and Amazon EC2 security groups are used as the authorization
 * mechanism.
 *
 * You cannot authorize ingress from an Amazon EC2 security group in one region to an
 * ElastiCache cluster in another region.
 */
export declare const authorizeCacheSecurityGroupIngress: API.OperationMethod<AuthorizeCacheSecurityGroupIngressMessage, AuthorizeCacheSecurityGroupIngressResult, AuthorizeCacheSecurityGroupIngressError, Credentials | HttpClient.HttpClient>;
export type BatchApplyUpdateActionError = InvalidParameterValueException | ServiceUpdateNotFoundFault | CommonErrors;
/**
 * Apply the service update. For more information on service updates and applying them,
 * see Applying Service
 * Updates.
 */
export declare const batchApplyUpdateAction: API.OperationMethod<BatchApplyUpdateActionMessage, UpdateActionResultsMessage, BatchApplyUpdateActionError, Credentials | HttpClient.HttpClient>;
export type BatchStopUpdateActionError = InvalidParameterValueException | ServiceUpdateNotFoundFault | CommonErrors;
/**
 * Stop the service update. For more information on service updates and stopping them,
 * see Stopping
 * Service Updates.
 */
export declare const batchStopUpdateAction: API.OperationMethod<BatchStopUpdateActionMessage, UpdateActionResultsMessage, BatchStopUpdateActionError, Credentials | HttpClient.HttpClient>;
export type CompleteMigrationError = InvalidReplicationGroupStateFault | ReplicationGroupNotFoundFault | ReplicationGroupNotUnderMigrationFault | CommonErrors;
/**
 * Complete the migration of data.
 */
export declare const completeMigration: API.OperationMethod<CompleteMigrationMessage, CompleteMigrationResponse, CompleteMigrationError, Credentials | HttpClient.HttpClient>;
export type CopyServerlessCacheSnapshotError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidServerlessCacheSnapshotStateFault | ServerlessCacheSnapshotAlreadyExistsFault | ServerlessCacheSnapshotNotFoundFault | ServerlessCacheSnapshotQuotaExceededFault | ServiceLinkedRoleNotFoundFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a copy of an existing serverless cache's snapshot. Available for Valkey, Redis OSS and Serverless Memcached only.
 */
export declare const copyServerlessCacheSnapshot: API.OperationMethod<CopyServerlessCacheSnapshotRequest, CopyServerlessCacheSnapshotResponse, CopyServerlessCacheSnapshotError, Credentials | HttpClient.HttpClient>;
export type CopySnapshotError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidSnapshotStateFault | SnapshotAlreadyExistsFault | SnapshotNotFoundFault | SnapshotQuotaExceededFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Makes a copy of an existing snapshot.
 *
 * This operation is valid for Valkey or Redis OSS only.
 *
 * Users or groups that have permissions to use the `CopySnapshot`
 * operation can create their own Amazon S3 buckets and copy snapshots to it. To
 * control access to your snapshots, use an IAM policy to control who has the ability
 * to use the `CopySnapshot` operation. For more information about using IAM
 * to control the use of ElastiCache operations, see Exporting
 * Snapshots and Authentication & Access
 * Control.
 *
 * You could receive the following error messages.
 *
 * **Error Messages**
 *
 * - **Error Message:** The S3 bucket %s is outside of
 * the region.
 *
 * **Solution:** Create an Amazon S3 bucket in the
 * same region as your snapshot. For more information, see Step 1: Create an Amazon S3 Bucket in the ElastiCache User
 * Guide.
 *
 * - **Error Message:** The S3 bucket %s does not
 * exist.
 *
 * **Solution:** Create an Amazon S3 bucket in the
 * same region as your snapshot. For more information, see Step 1: Create an Amazon S3 Bucket in the ElastiCache User
 * Guide.
 *
 * - **Error Message:** The S3 bucket %s is not owned
 * by the authenticated user.
 *
 * **Solution:** Create an Amazon S3 bucket in the
 * same region as your snapshot. For more information, see Step 1: Create an Amazon S3 Bucket in the ElastiCache User
 * Guide.
 *
 * - **Error Message:** The authenticated user does
 * not have sufficient permissions to perform the desired activity.
 *
 * **Solution:** Contact your system administrator
 * to get the needed permissions.
 *
 * - **Error Message:** The S3 bucket %s already
 * contains an object with key %s.
 *
 * **Solution:** Give the
 * `TargetSnapshotName` a new and unique value. If exporting a
 * snapshot, you could alternatively create a new Amazon S3 bucket and use this
 * same value for `TargetSnapshotName`.
 *
 * - **Error Message: ** ElastiCache has not been
 * granted READ permissions %s on the S3 Bucket.
 *
 * **Solution:** Add List and Read permissions on
 * the bucket. For more information, see Step 2: Grant ElastiCache Access to Your Amazon S3 Bucket in the
 * ElastiCache User Guide.
 *
 * - **Error Message: ** ElastiCache has not been
 * granted WRITE permissions %s on the S3 Bucket.
 *
 * **Solution:** Add Upload/Delete permissions on
 * the bucket. For more information, see Step 2: Grant ElastiCache Access to Your Amazon S3 Bucket in the
 * ElastiCache User Guide.
 *
 * - **Error Message: ** ElastiCache has not been
 * granted READ_ACP permissions %s on the S3 Bucket.
 *
 * **Solution:** Add View Permissions on the bucket.
 * For more information, see Step 2: Grant ElastiCache Access to Your Amazon S3 Bucket in the
 * ElastiCache User Guide.
 */
export declare const copySnapshot: API.OperationMethod<CopySnapshotMessage, CopySnapshotResult, CopySnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateCacheClusterError = CacheClusterAlreadyExistsFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | CacheSubnetGroupNotFoundFault | ClusterQuotaForCustomerExceededFault | InsufficientCacheClusterCapacityFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidVPCNetworkStateFault | NodeQuotaForClusterExceededFault | NodeQuotaForCustomerExceededFault | ReplicationGroupNotFoundFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a cluster. All nodes in the cluster run the same protocol-compliant cache
 * engine software, either Memcached, Valkey or Redis OSS.
 *
 * This operation is not supported for Valkey or Redis OSS (cluster mode enabled) clusters.
 */
export declare const createCacheCluster: API.OperationMethod<CreateCacheClusterMessage, CreateCacheClusterResult, CreateCacheClusterError, Credentials | HttpClient.HttpClient>;
export type CreateCacheParameterGroupError = CacheParameterGroupAlreadyExistsFault | CacheParameterGroupQuotaExceededFault | InvalidCacheParameterGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a new Amazon ElastiCache cache parameter group. An ElastiCache cache parameter
 * group is a collection of parameters and their values that are applied to all of the
 * nodes in any cluster or replication group using the CacheParameterGroup.
 *
 * A newly created CacheParameterGroup is an exact duplicate of the default parameter
 * group for the CacheParameterGroupFamily. To customize the newly created
 * CacheParameterGroup you can change the values of specific parameters. For more
 * information, see:
 *
 * - ModifyCacheParameterGroup in the ElastiCache API Reference.
 *
 * - Parameters and
 * Parameter Groups in the ElastiCache User Guide.
 */
export declare const createCacheParameterGroup: API.OperationMethod<CreateCacheParameterGroupMessage, CreateCacheParameterGroupResult, CreateCacheParameterGroupError, Credentials | HttpClient.HttpClient>;
export type CreateCacheSecurityGroupError = CacheSecurityGroupAlreadyExistsFault | CacheSecurityGroupQuotaExceededFault | InvalidParameterCombinationException | InvalidParameterValueException | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a new cache security group. Use a cache security group to control access to
 * one or more clusters.
 *
 * Cache security groups are only used when you are creating a cluster outside of an
 * Amazon Virtual Private Cloud (Amazon VPC). If you are creating a cluster inside of a
 * VPC, use a cache subnet group instead. For more information, see CreateCacheSubnetGroup.
 */
export declare const createCacheSecurityGroup: API.OperationMethod<CreateCacheSecurityGroupMessage, CreateCacheSecurityGroupResult, CreateCacheSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type CreateCacheSubnetGroupError = CacheSubnetGroupAlreadyExistsFault | CacheSubnetGroupQuotaExceededFault | CacheSubnetQuotaExceededFault | InvalidSubnet | SubnetNotAllowedFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a new cache subnet group.
 *
 * Use this parameter only when you are creating a cluster in an Amazon Virtual Private
 * Cloud (Amazon VPC).
 */
export declare const createCacheSubnetGroup: API.OperationMethod<CreateCacheSubnetGroupMessage, CreateCacheSubnetGroupResult, CreateCacheSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type CreateGlobalReplicationGroupError = GlobalReplicationGroupAlreadyExistsFault | InvalidParameterValueException | InvalidReplicationGroupStateFault | ReplicationGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Global Datastore offers fully managed, fast, reliable and secure
 * cross-region replication. Using Global Datastore with Valkey or Redis OSS, you can create cross-region
 * read replica clusters for ElastiCache to enable low-latency reads and disaster
 * recovery across regions. For more information, see Replication
 * Across Regions Using Global Datastore.
 *
 * - The **GlobalReplicationGroupIdSuffix** is the
 * name of the Global datastore.
 *
 * - The **PrimaryReplicationGroupId** represents the
 * name of the primary cluster that accepts writes and will replicate updates to
 * the secondary cluster.
 */
export declare const createGlobalReplicationGroup: API.OperationMethod<CreateGlobalReplicationGroupMessage, CreateGlobalReplicationGroupResult, CreateGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type CreateReplicationGroupError = CacheClusterNotFoundFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | CacheSubnetGroupNotFoundFault | ClusterQuotaForCustomerExceededFault | GlobalReplicationGroupNotFoundFault | InsufficientCacheClusterCapacityFault | InvalidCacheClusterStateFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidUserGroupStateFault | InvalidVPCNetworkStateFault | NodeGroupsPerReplicationGroupQuotaExceededFault | NodeQuotaForClusterExceededFault | NodeQuotaForCustomerExceededFault | ReplicationGroupAlreadyExistsFault | TagQuotaPerResourceExceeded | UserGroupNotFoundFault | CommonErrors;
/**
 * Creates a Valkey or Redis OSS (cluster mode disabled) or a Valkey or Redis OSS (cluster mode enabled) replication
 * group.
 *
 * This API can be used to create a standalone regional replication group or a secondary
 * replication group associated with a Global datastore.
 *
 * A Valkey or Redis OSS (cluster mode disabled) replication group is a collection of nodes, where
 * one of the nodes is a read/write primary and the others are read-only replicas.
 * Writes to the primary are asynchronously propagated to the replicas.
 *
 * A Valkey or Redis OSS cluster-mode enabled cluster is comprised of from 1 to 90 shards (API/CLI:
 * node groups). Each shard has a primary node and up to 5 read-only replica nodes. The
 * configuration can range from 90 shards and 0 replicas to 15 shards and 5 replicas, which
 * is the maximum number or replicas allowed.
 *
 * The node or shard limit can be increased to a maximum of 500 per cluster if the Valkey or Redis OSS
 * engine version is 5.0.6 or higher. For example, you can choose to configure a 500 node
 * cluster that ranges between 83 shards (one primary and 5 replicas per shard) and 500
 * shards (single primary and no replicas). Make sure there are enough available IP
 * addresses to accommodate the increase. Common pitfalls include the subnets in the subnet
 * group have too small a CIDR range or the subnets are shared and heavily used by other
 * clusters. For more information, see Creating a Subnet
 * Group. For versions below 5.0.6, the limit is 250 per cluster.
 *
 * To request a limit increase, see Amazon Service Limits and
 * choose the limit type Nodes per cluster per instance
 * type.
 *
 * When a Valkey or Redis OSS (cluster mode disabled) replication group has been successfully created,
 * you can add one or more read replicas to it, up to a total of 5 read replicas. If you
 * need to increase or decrease the number of node groups (console: shards), you can use scaling.
 * For more information, see Scaling self-designed clusters in the ElastiCache User
 * Guide.
 *
 * This operation is valid for Valkey and Redis OSS only.
 */
export declare const createReplicationGroup: API.OperationMethod<CreateReplicationGroupMessage, CreateReplicationGroupResult, CreateReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type CreateServerlessCacheError = InvalidCredentialsException | InvalidParameterCombinationException | InvalidParameterValueException | InvalidServerlessCacheStateFault | InvalidUserGroupStateFault | ServerlessCacheAlreadyExistsFault | ServerlessCacheNotFoundFault | ServerlessCacheQuotaForCustomerExceededFault | ServiceLinkedRoleNotFoundFault | TagQuotaPerResourceExceeded | UserGroupNotFoundFault | CommonErrors;
/**
 * Creates a serverless cache.
 */
export declare const createServerlessCache: API.OperationMethod<CreateServerlessCacheRequest, CreateServerlessCacheResponse, CreateServerlessCacheError, Credentials | HttpClient.HttpClient>;
export type CreateServerlessCacheSnapshotError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidServerlessCacheStateFault | ServerlessCacheNotFoundFault | ServerlessCacheSnapshotAlreadyExistsFault | ServerlessCacheSnapshotQuotaExceededFault | ServiceLinkedRoleNotFoundFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * This API creates a copy of an entire ServerlessCache at a specific moment in time. Available for Valkey, Redis OSS and Serverless Memcached only.
 */
export declare const createServerlessCacheSnapshot: API.OperationMethod<CreateServerlessCacheSnapshotRequest, CreateServerlessCacheSnapshotResponse, CreateServerlessCacheSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateSnapshotError = CacheClusterNotFoundFault | InvalidCacheClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | ReplicationGroupNotFoundFault | SnapshotAlreadyExistsFault | SnapshotFeatureNotSupportedFault | SnapshotQuotaExceededFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a copy of an entire cluster or replication group at a specific moment in
 * time.
 *
 * This operation is valid for Valkey or Redis OSS only.
 */
export declare const createSnapshot: API.OperationMethod<CreateSnapshotMessage, CreateSnapshotResult, CreateSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateUserError = DuplicateUserNameFault | InvalidParameterCombinationException | InvalidParameterValueException | ServiceLinkedRoleNotFoundFault | TagQuotaPerResourceExceeded | UserAlreadyExistsFault | UserQuotaExceededFault | CommonErrors;
/**
 * For Valkey engine version 7.2 onwards and Redis OSS 6.0 to 7.1: Creates a user. For more information, see
 * Using Role Based Access Control (RBAC).
 */
export declare const createUser: API.OperationMethod<CreateUserMessage, User, CreateUserError, Credentials | HttpClient.HttpClient>;
export type CreateUserGroupError = DefaultUserRequired | DuplicateUserNameFault | InvalidParameterValueException | ServiceLinkedRoleNotFoundFault | TagQuotaPerResourceExceeded | UserGroupAlreadyExistsFault | UserGroupQuotaExceededFault | UserNotFoundFault | CommonErrors;
/**
 * For Valkey engine version 7.2 onwards and Redis OSS 6.0 to 7.1: Creates a user group. For more
 * information, see Using Role Based Access Control (RBAC)
 */
export declare const createUserGroup: API.OperationMethod<CreateUserGroupMessage, UserGroup, CreateUserGroupError, Credentials | HttpClient.HttpClient>;
export type DecreaseNodeGroupsInGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Decreases the number of node groups in a Global datastore
 */
export declare const decreaseNodeGroupsInGlobalReplicationGroup: API.OperationMethod<DecreaseNodeGroupsInGlobalReplicationGroupMessage, DecreaseNodeGroupsInGlobalReplicationGroupResult, DecreaseNodeGroupsInGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type DecreaseReplicaCountError = ClusterQuotaForCustomerExceededFault | InsufficientCacheClusterCapacityFault | InvalidCacheClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidVPCNetworkStateFault | NodeGroupsPerReplicationGroupQuotaExceededFault | NodeQuotaForCustomerExceededFault | NoOperationFault | ReplicationGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Dynamically decreases the number of replicas in a Valkey or Redis OSS (cluster mode disabled)
 * replication group or the number of replica nodes in one or more node groups (shards) of
 * a Valkey or Redis OSS (cluster mode enabled) replication group. This operation is performed with no
 * cluster down time.
 */
export declare const decreaseReplicaCount: API.OperationMethod<DecreaseReplicaCountMessage, DecreaseReplicaCountResult, DecreaseReplicaCountError, Credentials | HttpClient.HttpClient>;
export type DeleteCacheClusterError = CacheClusterNotFoundFault | InvalidCacheClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | SnapshotAlreadyExistsFault | SnapshotFeatureNotSupportedFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Deletes a previously provisioned cluster. `DeleteCacheCluster` deletes all
 * associated cache nodes, node endpoints and the cluster itself. When you receive a
 * successful response from this operation, Amazon ElastiCache immediately begins deleting
 * the cluster; you cannot cancel or revert this operation.
 *
 * This operation is not valid for:
 *
 * - Valkey or Redis OSS (cluster mode enabled) clusters
 *
 * - Valkey or Redis OSS (cluster mode disabled) clusters
 *
 * - A cluster that is the last read replica of a replication group
 *
 * - A cluster that is the primary node of a replication group
 *
 * - A node group (shard) that has Multi-AZ mode enabled
 *
 * - A cluster from a Valkey or Redis OSS (cluster mode enabled) replication group
 *
 * - A cluster that is not in the `available` state
 */
export declare const deleteCacheCluster: API.OperationMethod<DeleteCacheClusterMessage, DeleteCacheClusterResult, DeleteCacheClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteCacheParameterGroupError = CacheParameterGroupNotFoundFault | InvalidCacheParameterGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Deletes the specified cache parameter group. You cannot delete a cache parameter group
 * if it is associated with any cache clusters. You cannot delete the default cache
 * parameter groups in your account.
 */
export declare const deleteCacheParameterGroup: API.OperationMethod<DeleteCacheParameterGroupMessage, DeleteCacheParameterGroupResponse, DeleteCacheParameterGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteCacheSecurityGroupError = CacheSecurityGroupNotFoundFault | InvalidCacheSecurityGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Deletes a cache security group.
 *
 * You cannot delete a cache security group if it is associated with any
 * clusters.
 */
export declare const deleteCacheSecurityGroup: API.OperationMethod<DeleteCacheSecurityGroupMessage, DeleteCacheSecurityGroupResponse, DeleteCacheSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteCacheSubnetGroupError = CacheSubnetGroupInUse | CacheSubnetGroupNotFoundFault | CommonErrors;
/**
 * Deletes a cache subnet group.
 *
 * You cannot delete a default cache subnet group or one that is associated with any
 * clusters.
 */
export declare const deleteCacheSubnetGroup: API.OperationMethod<DeleteCacheSubnetGroupMessage, DeleteCacheSubnetGroupResponse, DeleteCacheSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterValueException | CommonErrors;
/**
 * Deleting a Global datastore is a two-step process:
 *
 * - First, you must DisassociateGlobalReplicationGroup to remove
 * the secondary clusters in the Global datastore.
 *
 * - Once the Global datastore contains only the primary cluster, you can use the
 * `DeleteGlobalReplicationGroup` API to delete the Global datastore
 * while retainining the primary cluster using
 * `RetainPrimaryReplicationGroup=true`.
 *
 * Since the Global Datastore has only a primary cluster, you can delete the Global
 * Datastore while retaining the primary by setting
 * `RetainPrimaryReplicationGroup=true`. The primary cluster is never
 * deleted when deleting a Global Datastore. It can only be deleted when it no longer is
 * associated with any Global Datastore.
 *
 * When you receive a successful response from this operation, Amazon ElastiCache
 * immediately begins deleting the selected resources; you cannot cancel or revert this
 * operation.
 */
export declare const deleteGlobalReplicationGroup: API.OperationMethod<DeleteGlobalReplicationGroupMessage, DeleteGlobalReplicationGroupResult, DeleteGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteReplicationGroupError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | ReplicationGroupNotFoundFault | SnapshotAlreadyExistsFault | SnapshotFeatureNotSupportedFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Deletes an existing replication group. By default, this operation deletes the entire
 * replication group, including the primary/primaries and all of the read replicas. If the
 * replication group has only one primary, you can optionally delete only the read
 * replicas, while retaining the primary by setting
 * `RetainPrimaryCluster=true`.
 *
 * When you receive a successful response from this operation, Amazon ElastiCache
 * immediately begins deleting the selected resources; you cannot cancel or revert this
 * operation.
 *
 * - `CreateSnapshot` permission is required to create a final snapshot.
 * Without this permission, the API call will fail with an `Access Denied` exception.
 *
 * - This operation is valid for Redis OSS only.
 */
export declare const deleteReplicationGroup: API.OperationMethod<DeleteReplicationGroupMessage, DeleteReplicationGroupResult, DeleteReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteServerlessCacheError = InvalidCredentialsException | InvalidParameterCombinationException | InvalidParameterValueException | InvalidServerlessCacheStateFault | ServerlessCacheNotFoundFault | ServerlessCacheSnapshotAlreadyExistsFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Deletes a specified existing serverless cache.
 *
 * `CreateServerlessCacheSnapshot` permission is required to create a final snapshot.
 * Without this permission, the API call will fail with an `Access Denied` exception.
 */
export declare const deleteServerlessCache: API.OperationMethod<DeleteServerlessCacheRequest, DeleteServerlessCacheResponse, DeleteServerlessCacheError, Credentials | HttpClient.HttpClient>;
export type DeleteServerlessCacheSnapshotError = InvalidParameterValueException | InvalidServerlessCacheSnapshotStateFault | ServerlessCacheSnapshotNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Deletes an existing serverless cache snapshot. Available for Valkey, Redis OSS and Serverless Memcached only.
 */
export declare const deleteServerlessCacheSnapshot: API.OperationMethod<DeleteServerlessCacheSnapshotRequest, DeleteServerlessCacheSnapshotResponse, DeleteServerlessCacheSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteSnapshotError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidSnapshotStateFault | SnapshotNotFoundFault | CommonErrors;
/**
 * Deletes an existing snapshot. When you receive a successful response from this
 * operation, ElastiCache immediately begins deleting the snapshot; you cannot cancel or
 * revert this operation.
 *
 * This operation is valid for Valkey or Redis OSS only.
 */
export declare const deleteSnapshot: API.OperationMethod<DeleteSnapshotMessage, DeleteSnapshotResult, DeleteSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = DefaultUserAssociatedToUserGroupFault | InvalidParameterValueException | InvalidUserStateFault | ServiceLinkedRoleNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * For Valkey engine version 7.2 onwards and Redis OSS 6.0 onwards: Deletes a user. The user will be removed from
 * all user groups and in turn removed from all replication groups. For more information,
 * see Using Role Based Access Control (RBAC).
 */
export declare const deleteUser: API.OperationMethod<DeleteUserMessage, User, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DeleteUserGroupError = InvalidParameterValueException | InvalidUserGroupStateFault | ServiceLinkedRoleNotFoundFault | UserGroupNotFoundFault | CommonErrors;
/**
 * For Valkey engine version 7.2 onwards and Redis OSS 6.0 onwards: Deletes a user group. The user group must first
 * be disassociated from the replication group before it can be deleted. For more
 * information, see Using Role Based Access Control (RBAC).
 */
export declare const deleteUserGroup: API.OperationMethod<DeleteUserGroupMessage, UserGroup, DeleteUserGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeCacheClustersError = CacheClusterNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns information about all provisioned clusters if no cluster identifier is
 * specified, or about a specific cache cluster if a cluster identifier is supplied.
 *
 * By default, abbreviated information about the clusters is returned. You can use the
 * optional *ShowCacheNodeInfo* flag to retrieve detailed information
 * about the cache nodes associated with the clusters. These details include the DNS
 * address and port for the cache node endpoint.
 *
 * If the cluster is in the *creating* state, only cluster-level
 * information is displayed until all of the nodes are successfully provisioned.
 *
 * If the cluster is in the *deleting* state, only cluster-level
 * information is displayed.
 *
 * If cache nodes are currently being added to the cluster, node endpoint information and
 * creation time for the additional nodes are not displayed until they are completely
 * provisioned. When the cluster state is *available*, the cluster is
 * ready for use.
 *
 * If cache nodes are currently being removed from the cluster, no endpoint information
 * for the removed nodes is displayed.
 */
export declare const describeCacheClusters: API.PaginatedOperationMethod<DescribeCacheClustersMessage, CacheClusterMessage, DescribeCacheClustersError, Credentials | HttpClient.HttpClient, CacheCluster>;
export type DescribeCacheEngineVersionsError = CommonErrors;
/**
 * Returns a list of the available cache engines and their versions.
 */
export declare const describeCacheEngineVersions: API.PaginatedOperationMethod<DescribeCacheEngineVersionsMessage, CacheEngineVersionMessage, DescribeCacheEngineVersionsError, Credentials | HttpClient.HttpClient, CacheEngineVersion>;
export type DescribeCacheParameterGroupsError = CacheParameterGroupNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns a list of cache parameter group descriptions. If a cache parameter group name
 * is specified, the list contains only the descriptions for that group.
 */
export declare const describeCacheParameterGroups: API.PaginatedOperationMethod<DescribeCacheParameterGroupsMessage, CacheParameterGroupsMessage, DescribeCacheParameterGroupsError, Credentials | HttpClient.HttpClient, CacheParameterGroup>;
export type DescribeCacheParametersError = CacheParameterGroupNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns the detailed parameter list for a particular cache parameter group.
 */
export declare const describeCacheParameters: API.PaginatedOperationMethod<DescribeCacheParametersMessage, CacheParameterGroupDetails, DescribeCacheParametersError, Credentials | HttpClient.HttpClient, Parameter>;
export type DescribeCacheSecurityGroupsError = CacheSecurityGroupNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns a list of cache security group descriptions. If a cache security group name is
 * specified, the list contains only the description of that group. This applicable only
 * when you have ElastiCache in Classic setup
 */
export declare const describeCacheSecurityGroups: API.PaginatedOperationMethod<DescribeCacheSecurityGroupsMessage, CacheSecurityGroupMessage, DescribeCacheSecurityGroupsError, Credentials | HttpClient.HttpClient, CacheSecurityGroup>;
export type DescribeCacheSubnetGroupsError = CacheSubnetGroupNotFoundFault | CommonErrors;
/**
 * Returns a list of cache subnet group descriptions. If a subnet group name is
 * specified, the list contains only the description of that group. This is applicable only
 * when you have ElastiCache in VPC setup. All ElastiCache clusters now launch in VPC by
 * default.
 */
export declare const describeCacheSubnetGroups: API.PaginatedOperationMethod<DescribeCacheSubnetGroupsMessage, CacheSubnetGroupMessage, DescribeCacheSubnetGroupsError, Credentials | HttpClient.HttpClient, CacheSubnetGroup>;
export type DescribeEngineDefaultParametersError = InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns the default engine and system parameter information for the specified cache
 * engine.
 */
export declare const describeEngineDefaultParameters: API.PaginatedOperationMethod<DescribeEngineDefaultParametersMessage, DescribeEngineDefaultParametersResult, DescribeEngineDefaultParametersError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEventsError = InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns events related to clusters, cache security groups, and cache parameter groups.
 * You can obtain events specific to a particular cluster, cache security group, or cache
 * parameter group by providing the name as a parameter.
 *
 * By default, only the events occurring within the last hour are returned; however, you
 * can retrieve up to 14 days' worth of events if necessary.
 */
export declare const describeEvents: API.PaginatedOperationMethod<DescribeEventsMessage, EventsMessage, DescribeEventsError, Credentials | HttpClient.HttpClient, Event>;
export type DescribeGlobalReplicationGroupsError = GlobalReplicationGroupNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns information about a particular global replication group. If no identifier is
 * specified, returns information about all Global datastores.
 */
export declare const describeGlobalReplicationGroups: API.PaginatedOperationMethod<DescribeGlobalReplicationGroupsMessage, DescribeGlobalReplicationGroupsResult, DescribeGlobalReplicationGroupsError, Credentials | HttpClient.HttpClient, GlobalReplicationGroup>;
export type DescribeReplicationGroupsError = InvalidParameterCombinationException | InvalidParameterValueException | ReplicationGroupNotFoundFault | CommonErrors;
/**
 * Returns information about a particular replication group. If no identifier is
 * specified, `DescribeReplicationGroups` returns information about all
 * replication groups.
 *
 * This operation is valid for Valkey or Redis OSS only.
 */
export declare const describeReplicationGroups: API.PaginatedOperationMethod<DescribeReplicationGroupsMessage, ReplicationGroupMessage, DescribeReplicationGroupsError, Credentials | HttpClient.HttpClient, ReplicationGroup>;
export type DescribeReservedCacheNodesError = InvalidParameterCombinationException | InvalidParameterValueException | ReservedCacheNodeNotFoundFault | CommonErrors;
/**
 * Returns information about reserved cache nodes for this account, or about a specified
 * reserved cache node.
 */
export declare const describeReservedCacheNodes: API.PaginatedOperationMethod<DescribeReservedCacheNodesMessage, ReservedCacheNodeMessage, DescribeReservedCacheNodesError, Credentials | HttpClient.HttpClient, ReservedCacheNode>;
export type DescribeReservedCacheNodesOfferingsError = InvalidParameterCombinationException | InvalidParameterValueException | ReservedCacheNodesOfferingNotFoundFault | CommonErrors;
/**
 * Lists available reserved cache node offerings.
 */
export declare const describeReservedCacheNodesOfferings: API.PaginatedOperationMethod<DescribeReservedCacheNodesOfferingsMessage, ReservedCacheNodesOfferingMessage, DescribeReservedCacheNodesOfferingsError, Credentials | HttpClient.HttpClient, ReservedCacheNodesOffering>;
export type DescribeServerlessCachesError = InvalidParameterCombinationException | InvalidParameterValueException | ServerlessCacheNotFoundFault | CommonErrors;
/**
 * Returns information about a specific serverless cache.
 * If no identifier is specified, then the API returns information on all the serverless caches belonging to
 * this Amazon Web Services account.
 */
export declare const describeServerlessCaches: API.PaginatedOperationMethod<DescribeServerlessCachesRequest, DescribeServerlessCachesResponse, DescribeServerlessCachesError, Credentials | HttpClient.HttpClient, ServerlessCache>;
export type DescribeServerlessCacheSnapshotsError = InvalidParameterCombinationException | InvalidParameterValueException | ServerlessCacheNotFoundFault | ServerlessCacheSnapshotNotFoundFault | CommonErrors;
/**
 * Returns information about serverless cache snapshots.
 * By default, this API lists all of the customer's serverless cache snapshots.
 * It can also describe a single serverless cache snapshot, or the snapshots associated with
 * a particular serverless cache. Available for Valkey, Redis OSS and Serverless Memcached only.
 */
export declare const describeServerlessCacheSnapshots: API.PaginatedOperationMethod<DescribeServerlessCacheSnapshotsRequest, DescribeServerlessCacheSnapshotsResponse, DescribeServerlessCacheSnapshotsError, Credentials | HttpClient.HttpClient, ServerlessCacheSnapshot>;
export type DescribeServiceUpdatesError = InvalidParameterCombinationException | InvalidParameterValueException | ServiceUpdateNotFoundFault | CommonErrors;
/**
 * Returns details of the service updates
 */
export declare const describeServiceUpdates: API.PaginatedOperationMethod<DescribeServiceUpdatesMessage, ServiceUpdatesMessage, DescribeServiceUpdatesError, Credentials | HttpClient.HttpClient, ServiceUpdate>;
export type DescribeSnapshotsError = CacheClusterNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | SnapshotNotFoundFault | CommonErrors;
/**
 * Returns information about cluster or replication group snapshots. By default,
 * `DescribeSnapshots` lists all of your snapshots; it can optionally
 * describe a single snapshot, or just the snapshots associated with a particular cache
 * cluster.
 *
 * This operation is valid for Valkey or Redis OSS only.
 */
export declare const describeSnapshots: API.PaginatedOperationMethod<DescribeSnapshotsMessage, DescribeSnapshotsListMessage, DescribeSnapshotsError, Credentials | HttpClient.HttpClient, Snapshot>;
export type DescribeUpdateActionsError = InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns details of the update actions
 */
export declare const describeUpdateActions: API.PaginatedOperationMethod<DescribeUpdateActionsMessage, UpdateActionsMessage, DescribeUpdateActionsError, Credentials | HttpClient.HttpClient, UpdateAction>;
export type DescribeUserGroupsError = InvalidParameterCombinationException | ServiceLinkedRoleNotFoundFault | UserGroupNotFoundFault | CommonErrors;
/**
 * Returns a list of user groups.
 */
export declare const describeUserGroups: API.PaginatedOperationMethod<DescribeUserGroupsMessage, DescribeUserGroupsResult, DescribeUserGroupsError, Credentials | HttpClient.HttpClient, UserGroup>;
export type DescribeUsersError = InvalidParameterCombinationException | ServiceLinkedRoleNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * Returns a list of users.
 */
export declare const describeUsers: API.PaginatedOperationMethod<DescribeUsersMessage, DescribeUsersResult, DescribeUsersError, Credentials | HttpClient.HttpClient, User>;
export type DisassociateGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Remove a secondary cluster from the Global datastore using the Global datastore name.
 * The secondary cluster will no longer receive updates from the primary cluster, but will
 * remain as a standalone cluster in that Amazon region.
 */
export declare const disassociateGlobalReplicationGroup: API.OperationMethod<DisassociateGlobalReplicationGroupMessage, DisassociateGlobalReplicationGroupResult, DisassociateGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type ExportServerlessCacheSnapshotError = InvalidParameterValueException | InvalidServerlessCacheSnapshotStateFault | ServerlessCacheSnapshotNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Provides the functionality to export the serverless cache snapshot data to Amazon S3. Available for Valkey and Redis OSS only.
 */
export declare const exportServerlessCacheSnapshot: API.OperationMethod<ExportServerlessCacheSnapshotRequest, ExportServerlessCacheSnapshotResponse, ExportServerlessCacheSnapshotError, Credentials | HttpClient.HttpClient>;
export type FailoverGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Used to failover the primary region to a secondary region. The secondary region will
 * become primary, and all other clusters will become secondary.
 */
export declare const failoverGlobalReplicationGroup: API.OperationMethod<FailoverGlobalReplicationGroupMessage, FailoverGlobalReplicationGroupResult, FailoverGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type IncreaseNodeGroupsInGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterValueException | CommonErrors;
/**
 * Increase the number of node groups in the Global datastore
 */
export declare const increaseNodeGroupsInGlobalReplicationGroup: API.OperationMethod<IncreaseNodeGroupsInGlobalReplicationGroupMessage, IncreaseNodeGroupsInGlobalReplicationGroupResult, IncreaseNodeGroupsInGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type IncreaseReplicaCountError = ClusterQuotaForCustomerExceededFault | InsufficientCacheClusterCapacityFault | InvalidCacheClusterStateFault | InvalidKMSKeyFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidVPCNetworkStateFault | NodeGroupsPerReplicationGroupQuotaExceededFault | NodeQuotaForCustomerExceededFault | NoOperationFault | ReplicationGroupNotFoundFault | CommonErrors;
/**
 * Dynamically increases the number of replicas in a Valkey or Redis OSS (cluster mode disabled)
 * replication group or the number of replica nodes in one or more node groups (shards) of
 * a Valkey or Redis OSS (cluster mode enabled) replication group. This operation is performed with no
 * cluster down time.
 */
export declare const increaseReplicaCount: API.OperationMethod<IncreaseReplicaCountMessage, IncreaseReplicaCountResult, IncreaseReplicaCountError, Credentials | HttpClient.HttpClient>;
export type ListAllowedNodeTypeModificationsError = CacheClusterNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | ReplicationGroupNotFoundFault | CommonErrors;
/**
 * Lists all available node types that you can scale with your cluster's replication
 * group's current node type.
 *
 * When you use the `ModifyCacheCluster` or
 * `ModifyReplicationGroup` operations to scale your cluster or replication
 * group, the value of the `CacheNodeType` parameter must be one of the node
 * types returned by this operation.
 */
export declare const listAllowedNodeTypeModifications: API.OperationMethod<ListAllowedNodeTypeModificationsMessage, AllowedNodeTypeModificationsMessage, ListAllowedNodeTypeModificationsError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = CacheClusterNotFoundFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | CacheSubnetGroupNotFoundFault | GlobalReplicationGroupNotFoundFault | InvalidARNFault | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidServerlessCacheSnapshotStateFault | InvalidServerlessCacheStateFault | ReplicationGroupNotFoundFault | ReservedCacheNodeNotFoundFault | ServerlessCacheNotFoundFault | ServerlessCacheSnapshotNotFoundFault | SnapshotNotFoundFault | UserGroupNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * Lists all tags currently on a named resource.
 *
 * A tag is a key-value pair where the key and value are case-sensitive. You can use
 * tags to categorize and track all your ElastiCache resources.
 * When you add or remove tags on replication groups, those
 * actions will be replicated to all nodes in the replication group. For more information,
 * see Resource-level permissions.
 *
 * If the cluster is not in the *available* state,
 * `ListTagsForResource` returns an error.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceMessage, TagListMessage, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ModifyCacheClusterError = CacheClusterNotFoundFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | InsufficientCacheClusterCapacityFault | InvalidCacheClusterStateFault | InvalidCacheSecurityGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidVPCNetworkStateFault | NodeQuotaForClusterExceededFault | NodeQuotaForCustomerExceededFault | CommonErrors;
/**
 * Modifies the settings for a cluster. You can use this operation to change one or more
 * cluster configuration parameters by specifying the parameters and the new values.
 */
export declare const modifyCacheCluster: API.OperationMethod<ModifyCacheClusterMessage, ModifyCacheClusterResult, ModifyCacheClusterError, Credentials | HttpClient.HttpClient>;
export type ModifyCacheParameterGroupError = CacheParameterGroupNotFoundFault | InvalidCacheParameterGroupStateFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Modifies the parameters of a cache parameter group. You can modify up to 20 parameters
 * in a single request by submitting a list parameter name and value pairs.
 */
export declare const modifyCacheParameterGroup: API.OperationMethod<ModifyCacheParameterGroupMessage, CacheParameterGroupNameMessage, ModifyCacheParameterGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyCacheSubnetGroupError = CacheSubnetGroupNotFoundFault | CacheSubnetQuotaExceededFault | InvalidSubnet | SubnetInUse | SubnetNotAllowedFault | CommonErrors;
/**
 * Modifies an existing cache subnet group.
 */
export declare const modifyCacheSubnetGroup: API.OperationMethod<ModifyCacheSubnetGroupMessage, ModifyCacheSubnetGroupResult, ModifyCacheSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterValueException | CommonErrors;
/**
 * Modifies the settings for a Global datastore.
 */
export declare const modifyGlobalReplicationGroup: API.OperationMethod<ModifyGlobalReplicationGroupMessage, ModifyGlobalReplicationGroupResult, ModifyGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyReplicationGroupError = CacheClusterNotFoundFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | InsufficientCacheClusterCapacityFault | InvalidCacheClusterStateFault | InvalidCacheSecurityGroupStateFault | InvalidKMSKeyFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidUserGroupStateFault | InvalidVPCNetworkStateFault | NodeQuotaForClusterExceededFault | NodeQuotaForCustomerExceededFault | ReplicationGroupNotFoundFault | UserGroupNotFoundFault | CommonErrors;
/**
 * Modifies the settings for a replication group. This is limited to Valkey and Redis OSS 7 and above.
 *
 * - Scaling for Valkey or Redis OSS (cluster mode enabled) in
 * the ElastiCache User Guide
 *
 * - ModifyReplicationGroupShardConfiguration in the ElastiCache API
 * Reference
 *
 * This operation is valid for Valkey or Redis OSS only.
 */
export declare const modifyReplicationGroup: API.OperationMethod<ModifyReplicationGroupMessage, ModifyReplicationGroupResult, ModifyReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyReplicationGroupShardConfigurationError = InsufficientCacheClusterCapacityFault | InvalidCacheClusterStateFault | InvalidKMSKeyFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidVPCNetworkStateFault | NodeGroupsPerReplicationGroupQuotaExceededFault | NodeQuotaForCustomerExceededFault | ReplicationGroupNotFoundFault | CommonErrors;
/**
 * Modifies a replication group's shards (node groups) by allowing you to add shards,
 * remove shards, or rebalance the keyspaces among existing shards.
 */
export declare const modifyReplicationGroupShardConfiguration: API.OperationMethod<ModifyReplicationGroupShardConfigurationMessage, ModifyReplicationGroupShardConfigurationResult, ModifyReplicationGroupShardConfigurationError, Credentials | HttpClient.HttpClient>;
export type ModifyServerlessCacheError = InvalidCredentialsException | InvalidParameterCombinationException | InvalidParameterValueException | InvalidServerlessCacheStateFault | InvalidUserGroupStateFault | ServerlessCacheNotFoundFault | ServiceLinkedRoleNotFoundFault | UserGroupNotFoundFault | CommonErrors;
/**
 * This API modifies the attributes of a serverless cache.
 */
export declare const modifyServerlessCache: API.OperationMethod<ModifyServerlessCacheRequest, ModifyServerlessCacheResponse, ModifyServerlessCacheError, Credentials | HttpClient.HttpClient>;
export type ModifyUserError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidUserStateFault | ServiceLinkedRoleNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * Changes user password(s) and/or access string.
 */
export declare const modifyUser: API.OperationMethod<ModifyUserMessage, User, ModifyUserError, Credentials | HttpClient.HttpClient>;
export type ModifyUserGroupError = DefaultUserRequired | DuplicateUserNameFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidUserGroupStateFault | ServiceLinkedRoleNotFoundFault | UserGroupNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * Changes the list of users that belong to the user group.
 */
export declare const modifyUserGroup: API.OperationMethod<ModifyUserGroupMessage, UserGroup, ModifyUserGroupError, Credentials | HttpClient.HttpClient>;
export type PurchaseReservedCacheNodesOfferingError = InvalidParameterCombinationException | InvalidParameterValueException | ReservedCacheNodeAlreadyExistsFault | ReservedCacheNodeQuotaExceededFault | ReservedCacheNodesOfferingNotFoundFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Allows you to purchase a reserved cache node offering. Reserved nodes are not eligible
 * for cancellation and are non-refundable. For more information, see Managing Costs with Reserved Nodes.
 */
export declare const purchaseReservedCacheNodesOffering: API.OperationMethod<PurchaseReservedCacheNodesOfferingMessage, PurchaseReservedCacheNodesOfferingResult, PurchaseReservedCacheNodesOfferingError, Credentials | HttpClient.HttpClient>;
export type RebalanceSlotsInGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterValueException | CommonErrors;
/**
 * Redistribute slots to ensure uniform distribution across existing shards in the
 * cluster.
 */
export declare const rebalanceSlotsInGlobalReplicationGroup: API.OperationMethod<RebalanceSlotsInGlobalReplicationGroupMessage, RebalanceSlotsInGlobalReplicationGroupResult, RebalanceSlotsInGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type RebootCacheClusterError = CacheClusterNotFoundFault | InvalidCacheClusterStateFault | CommonErrors;
/**
 * Reboots some, or all, of the cache nodes within a provisioned cluster. This operation
 * applies any modified cache parameter groups to the cluster. The reboot operation takes
 * place as soon as possible, and results in a momentary outage to the cluster. During the
 * reboot, the cluster status is set to REBOOTING.
 *
 * The reboot causes the contents of the cache (for each cache node being rebooted) to be
 * lost.
 *
 * When the reboot is complete, a cluster event is created.
 *
 * Rebooting a cluster is currently supported on Memcached, Valkey and Redis OSS (cluster mode
 * disabled) clusters. Rebooting is not supported on Valkey or Redis OSS (cluster mode enabled)
 * clusters.
 *
 * If you make changes to parameters that require a Valkey or Redis OSS (cluster mode enabled) cluster
 * reboot for the changes to be applied, see Rebooting a Cluster for an alternate process.
 */
export declare const rebootCacheCluster: API.OperationMethod<RebootCacheClusterMessage, RebootCacheClusterResult, RebootCacheClusterError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsFromResourceError = CacheClusterNotFoundFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | CacheSubnetGroupNotFoundFault | GlobalReplicationGroupNotFoundFault | InvalidARNFault | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidServerlessCacheSnapshotStateFault | InvalidServerlessCacheStateFault | ReplicationGroupNotFoundFault | ReservedCacheNodeNotFoundFault | ServerlessCacheNotFoundFault | ServerlessCacheSnapshotNotFoundFault | SnapshotNotFoundFault | TagNotFoundFault | UserGroupNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * Removes the tags identified by the `TagKeys` list from the named resource.
 * A tag is a key-value pair where the key and value are case-sensitive. You can use tags
 * to categorize and track all your ElastiCache resources.
 * When you add or remove tags on replication groups, those actions will
 * be replicated to all nodes in the replication group. For more information, see Resource-level permissions.
 */
export declare const removeTagsFromResource: API.OperationMethod<RemoveTagsFromResourceMessage, TagListMessage, RemoveTagsFromResourceError, Credentials | HttpClient.HttpClient>;
export type ResetCacheParameterGroupError = CacheParameterGroupNotFoundFault | InvalidCacheParameterGroupStateFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Modifies the parameters of a cache parameter group to the engine or system default
 * value. You can reset specific parameters by submitting a list of parameter names. To
 * reset the entire cache parameter group, specify the `ResetAllParameters` and
 * `CacheParameterGroupName` parameters.
 */
export declare const resetCacheParameterGroup: API.OperationMethod<ResetCacheParameterGroupMessage, CacheParameterGroupNameMessage, ResetCacheParameterGroupError, Credentials | HttpClient.HttpClient>;
export type RevokeCacheSecurityGroupIngressError = AuthorizationNotFoundFault | CacheSecurityGroupNotFoundFault | InvalidCacheSecurityGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Revokes ingress from a cache security group. Use this operation to disallow access
 * from an Amazon EC2 security group that had been previously authorized.
 */
export declare const revokeCacheSecurityGroupIngress: API.OperationMethod<RevokeCacheSecurityGroupIngressMessage, RevokeCacheSecurityGroupIngressResult, RevokeCacheSecurityGroupIngressError, Credentials | HttpClient.HttpClient>;
export type StartMigrationError = InvalidParameterValueException | InvalidReplicationGroupStateFault | ReplicationGroupAlreadyUnderMigrationFault | ReplicationGroupNotFoundFault | CommonErrors;
/**
 * Start the migration of data.
 */
export declare const startMigration: API.OperationMethod<StartMigrationMessage, StartMigrationResponse, StartMigrationError, Credentials | HttpClient.HttpClient>;
export type TestFailoverError = APICallRateForCustomerExceededFault | InvalidCacheClusterStateFault | InvalidKMSKeyFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | NodeGroupNotFoundFault | ReplicationGroupNotFoundFault | TestFailoverNotAvailableFault | CommonErrors;
/**
 * Represents the input of a `TestFailover` operation which tests automatic
 * failover on a specified node group (called shard in the console) in a replication group
 * (called cluster in the console).
 *
 * This API is designed for testing the behavior of your application in case of
 * ElastiCache failover. It is not designed to be an operational tool for initiating a
 * failover to overcome a problem you may have with the cluster. Moreover, in certain
 * conditions such as large-scale operational events, Amazon may block this API.
 *
 * **Note the following**
 *
 * - A customer can use this operation to test automatic failover on up to 15 shards
 * (called node groups in the ElastiCache API and Amazon CLI) in any rolling
 * 24-hour period.
 *
 * - If calling this operation on shards in different clusters (called replication
 * groups in the API and CLI), the calls can be made concurrently.
 *
 * - If calling this operation multiple times on different shards in the same Valkey or Redis OSS (cluster mode enabled) replication group, the first node replacement must
 * complete before a subsequent call can be made.
 *
 * - To determine whether the node replacement is complete you can check Events
 * using the Amazon ElastiCache console, the Amazon CLI, or the ElastiCache API.
 * Look for the following automatic failover related events, listed here in order
 * of occurrance:
 *
 * - Replication group message: Test Failover API called for node
 * group
 *
 * - Cache cluster message: Failover from primary node
 * to replica node
 * completed
 *
 * - Replication group message: Failover from primary node
 * to replica node
 * completed
 *
 * - Cache cluster message: Recovering cache nodes
 *
 * - Cache cluster message: Finished recovery for cache nodes
 *
 * For more information see:
 *
 * - Viewing
 * ElastiCache Events in the ElastiCache User
 * Guide
 *
 * - DescribeEvents in the ElastiCache API Reference
 *
 * Also see, Testing
 * Multi-AZ in the *ElastiCache User Guide*.
 */
export declare const testFailover: API.OperationMethod<TestFailoverMessage, TestFailoverResult, TestFailoverError, Credentials | HttpClient.HttpClient>;
export type TestMigrationError = InvalidParameterValueException | InvalidReplicationGroupStateFault | ReplicationGroupAlreadyUnderMigrationFault | ReplicationGroupNotFoundFault | CommonErrors;
/**
 * Async API to test connection between source and target replication group.
 */
export declare const testMigration: API.OperationMethod<TestMigrationMessage, TestMigrationResponse, TestMigrationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=elasticache.d.ts.map