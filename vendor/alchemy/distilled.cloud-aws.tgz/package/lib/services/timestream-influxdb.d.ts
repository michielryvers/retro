import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DbBackupName = string;
export type DbResourceId = string;
export type RetentionDays = number;
export type TagKey = string;
export type TagValue = string;
export type RequestTagMap = {
    [key: string]: string | undefined;
};
export interface CreateDbBackupInput {
    name: string;
    dbResourceId: string;
    retentionDays?: number;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type DbBackupId = string;
export type Arn = string;
export type DbBackupStatus = "IN_PROGRESS" | "COMPLETED" | "FAILED" | "DELETING" | "DELETED" | (string & {});
export type DbBackupType = "HOURLY" | "DAILY" | "WEEKLY" | "MONTHLY" | "CUSTOM_SCHEDULE" | "ON_DEMAND" | "CONTINUOUS" | (string & {});
export type EngineType = "INFLUXDB_V2" | "INFLUXDB_V3_CORE" | "INFLUXDB_V3_ENTERPRISE" | (string & {});
export type ResourceDeploymentType = "SINGLE_AZ" | "WITH_MULTIAZ_STANDBY" | "MULTI_NODE_READ_REPLICAS" | (string & {});
export type KmsKeyId = string;
export interface ClusterConfiguration {
    ingestQueryInstances?: number;
    queryOnlyInstances?: number;
    dedicatedCompactor?: boolean;
}
export type DbParameterGroupId = string;
export type DbInstanceType = "db.influx.medium" | "db.influx.large" | "db.influx.xlarge" | "db.influx.2xlarge" | "db.influx.4xlarge" | "db.influx.8xlarge" | "db.influx.12xlarge" | "db.influx.16xlarge" | "db.influx.24xlarge" | (string & {});
export interface S3Configuration {
    bucketName: string;
    enabled: boolean;
}
export interface LogDeliveryConfiguration {
    s3Configuration: S3Configuration;
}
export type FailoverMode = "AUTOMATIC" | "NO_FAILOVER" | (string & {});
export type DbStorageType = "InfluxIOIncludedT1" | "InfluxIOIncludedT2" | "InfluxIOIncludedT3" | (string & {});
export type AllocatedStorage = number;
export type VpcSubnetId = string;
export type VpcSubnetIdList = string[];
export type VpcSecurityGroupId = string;
export type VpcSecurityGroupIdList = string[];
export type NetworkType = "IPV4" | "DUAL" | (string & {});
export type IanaTimezone = string;
export type MaintenanceWindow = string;
export interface MaintenanceSchedule {
    timezone: string;
    preferredMaintenanceWindow: string;
}
export interface CreateDbBackupOutput {
    id: string;
    name?: string;
    arn: string;
    status?: DbBackupStatus;
    createdAt?: Date;
    expiresAfter?: string;
    dbResourceId?: string;
    type?: DbBackupType;
    engineType?: EngineType;
    deploymentType?: ResourceDeploymentType;
    kmsKeyId?: string;
    clusterConfiguration?: ClusterConfiguration;
    dbParameterGroupId?: string;
    dbInstanceType?: DbInstanceType;
    logDeliveryConfiguration?: LogDeliveryConfiguration;
    failoverMode?: FailoverMode;
    dbStorageType?: DbStorageType;
    allocatedStorage?: number;
    vpcSubnetIds?: string[];
    vpcSecurityGroupIds?: string[];
    publiclyAccessible?: boolean;
    port?: number;
    networkType?: NetworkType;
    influxAuthParametersSecretArn?: string;
    maintenanceSchedule?: MaintenanceSchedule;
}
export type DbClusterName = string;
export type Username = string | redacted.Redacted<string>;
export type Password = string | redacted.Redacted<string>;
export type Organization = string;
export type Bucket = string;
export type Port = number;
export type DbParameterGroupIdentifier = string;
export type ClusterDeploymentType = "MULTI_NODE_READ_REPLICAS" | (string & {});
export type AutomatedDbBackupType = "HOURLY" | "DAILY" | "WEEKLY" | "MONTHLY" | "CUSTOM_SCHEDULE" | "CONTINUOUS" | (string & {});
export type AutomatedBackupRetentionDays = number;
export type AwsCronSchedule = string;
export interface DbBackupConfiguration {
    type: AutomatedDbBackupType;
    retentionDays: number;
    enabled: boolean;
    customSchedule?: string;
}
export type DbBackupConfigurationInputList = DbBackupConfiguration[];
export interface CreateDbClusterInput {
    name: string;
    username?: string | redacted.Redacted<string>;
    password?: string | redacted.Redacted<string>;
    organization?: string;
    bucket?: string;
    port?: number;
    dbParameterGroupIdentifier?: string;
    dbInstanceType: DbInstanceType;
    dbStorageType?: DbStorageType;
    allocatedStorage?: number;
    networkType?: NetworkType;
    publiclyAccessible?: boolean;
    vpcSubnetIds: string[];
    vpcSecurityGroupIds: string[];
    deploymentType?: ClusterDeploymentType;
    failoverMode?: FailoverMode;
    logDeliveryConfiguration?: LogDeliveryConfiguration;
    maintenanceSchedule?: MaintenanceSchedule;
    dbBackupConfigurations?: DbBackupConfiguration[];
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type DbClusterId = string;
export type ClusterStatus = "CREATING" | "UPDATING" | "DELETING" | "AVAILABLE" | "FAILED" | "DELETED" | "MAINTENANCE" | "UPDATING_INSTANCE_TYPE" | "REBOOTING" | "REBOOT_FAILED" | "PARTIALLY_AVAILABLE" | "RESTORING" | "RESTORE_FAILED" | (string & {});
export interface CreateDbClusterOutput {
    dbClusterId?: string;
    dbClusterStatus?: ClusterStatus;
}
export type DbInstanceName = string;
export type DeploymentType = "SINGLE_AZ" | "WITH_MULTIAZ_STANDBY" | (string & {});
export interface CreateDbInstanceInput {
    name: string;
    username?: string | redacted.Redacted<string>;
    password: string | redacted.Redacted<string>;
    organization?: string;
    bucket?: string;
    dbInstanceType: DbInstanceType;
    vpcSubnetIds: string[];
    vpcSecurityGroupIds: string[];
    publiclyAccessible?: boolean;
    dbStorageType?: DbStorageType;
    allocatedStorage: number;
    dbParameterGroupIdentifier?: string;
    deploymentType?: DeploymentType;
    logDeliveryConfiguration?: LogDeliveryConfiguration;
    maintenanceSchedule?: MaintenanceSchedule;
    tags?: {
        [key: string]: string | undefined;
    };
    port?: number;
    networkType?: NetworkType;
    dbBackupConfigurations?: DbBackupConfiguration[];
    kmsKeyId?: string;
}
export type DbInstanceId = string;
export type Status = "CREATING" | "AVAILABLE" | "DELETING" | "MODIFYING" | "UPDATING" | "DELETED" | "FAILED" | "UPDATING_DEPLOYMENT_TYPE" | "UPDATING_INSTANCE_TYPE" | "MAINTENANCE" | "REBOOTING" | "REBOOT_FAILED" | "RESTORING" | "RESTORE_FAILED" | (string & {});
export type InstanceMode = "PRIMARY" | "STANDBY" | "REPLICA" | "INGEST" | "QUERY" | "COMPACT" | "PROCESS" | (string & {});
export type InstanceModeList = InstanceMode[];
export interface DbBackupConfigurationOutput {
    type: AutomatedDbBackupType;
    retentionDays: number;
    enabled: boolean;
    customSchedule?: string;
    nextAutomatedBackupTime?: Date;
}
export type DbBackupConfigurationOutputList = DbBackupConfigurationOutput[];
export interface CreateDbInstanceOutput {
    id: string;
    name: string;
    arn: string;
    status?: Status;
    endpoint?: string;
    port?: number;
    networkType?: NetworkType;
    dbInstanceType?: DbInstanceType;
    dbStorageType?: DbStorageType;
    allocatedStorage?: number;
    deploymentType?: DeploymentType;
    vpcSubnetIds: string[];
    publiclyAccessible?: boolean;
    vpcSecurityGroupIds?: string[];
    dbParameterGroupIdentifier?: string;
    availabilityZone?: string;
    secondaryAvailabilityZone?: string;
    logDeliveryConfiguration?: LogDeliveryConfiguration;
    influxAuthParametersSecretArn?: string;
    dbClusterId?: string;
    instanceMode?: InstanceMode;
    instanceModes?: InstanceMode[];
    maintenanceSchedule?: MaintenanceSchedule;
    lastMaintenanceTime?: Date;
    nextMaintenanceTime?: Date;
    dbBackupConfigurations?: DbBackupConfigurationOutput[];
    kmsKeyId?: string;
}
export type DbParameterGroupName = string;
export type LogLevel = "debug" | "info" | "error" | (string & {});
export type TracingType = "log" | "jaeger" | "disabled" | (string & {});
export type DurationType = "hours" | "minutes" | "seconds" | "milliseconds" | "days" | (string & {});
export interface Duration {
    durationType: DurationType;
    value: number;
}
export interface InfluxDBv2Parameters {
    fluxLogEnabled?: boolean;
    logLevel?: LogLevel;
    noTasks?: boolean;
    queryConcurrency?: number;
    queryQueueSize?: number;
    tracingType?: TracingType;
    metricsDisabled?: boolean;
    httpIdleTimeout?: Duration;
    httpReadHeaderTimeout?: Duration;
    httpReadTimeout?: Duration;
    httpWriteTimeout?: Duration;
    influxqlMaxSelectBuckets?: number;
    influxqlMaxSelectPoint?: number;
    influxqlMaxSelectSeries?: number;
    pprofDisabled?: boolean;
    queryInitialMemoryBytes?: number;
    queryMaxMemoryBytes?: number;
    queryMemoryBytes?: number;
    sessionLength?: number;
    sessionRenewDisabled?: boolean;
    storageCacheMaxMemorySize?: number;
    storageCacheSnapshotMemorySize?: number;
    storageCacheSnapshotWriteColdDuration?: Duration;
    storageCompactFullWriteColdDuration?: Duration;
    storageCompactThroughputBurst?: number;
    storageMaxConcurrentCompactions?: number;
    storageMaxIndexLogFileSize?: number;
    storageNoValidateFieldSize?: boolean;
    storageRetentionCheckInterval?: Duration;
    storageSeriesFileMaxConcurrentSnapshotCompactions?: number;
    storageSeriesIdSetCacheSize?: number;
    storageWalMaxConcurrentWrites?: number;
    storageWalMaxWriteDelay?: Duration;
    uiDisabled?: boolean;
}
export type LogFormats = "full" | (string & {});
export type DataFusionRuntimeType = "multi-thread" | "multi-thread-alt" | (string & {});
export type PercentOrAbsoluteLong = {
    percent: string;
    absolute?: never;
} | {
    percent?: never;
    absolute: number;
};
export type PluginRepositorySecretArn = string;
export interface InfluxDBv3CoreParameters {
    queryFileLimit?: number;
    queryLogSize?: number;
    logFilter?: string;
    logFormat?: LogFormats;
    dataFusionNumThreads?: number;
    dataFusionRuntimeType?: DataFusionRuntimeType;
    dataFusionRuntimeDisableLifoSlot?: boolean;
    dataFusionRuntimeEventInterval?: number;
    dataFusionRuntimeGlobalQueueInterval?: number;
    dataFusionRuntimeMaxBlockingThreads?: number;
    dataFusionRuntimeMaxIoEventsPerTick?: number;
    dataFusionRuntimeThreadKeepAlive?: Duration;
    dataFusionRuntimeThreadPriority?: number;
    dataFusionMaxParquetFanout?: number;
    dataFusionUseCachedParquetLoader?: boolean;
    dataFusionConfig?: string;
    maxHttpRequestSize?: number;
    forceSnapshotMemThreshold?: PercentOrAbsoluteLong;
    walSnapshotSize?: number;
    walMaxWriteBufferSize?: number;
    snapshottedWalFilesToKeep?: number;
    preemptiveCacheAge?: Duration;
    parquetMemCachePrunePercentage?: number;
    parquetMemCachePruneInterval?: Duration;
    disableParquetMemCache?: boolean;
    parquetMemCacheQueryPathDuration?: Duration;
    lastCacheEvictionInterval?: Duration;
    distinctCacheEvictionInterval?: Duration;
    gen1Duration?: Duration;
    execMemPoolBytes?: PercentOrAbsoluteLong;
    parquetMemCacheSize?: PercentOrAbsoluteLong;
    walReplayFailOnError?: boolean;
    walReplayConcurrencyLimit?: number;
    tableIndexCacheMaxEntries?: number;
    tableIndexCacheConcurrencyLimit?: number;
    gen1LookbackDuration?: Duration;
    retentionCheckInterval?: Duration;
    deleteGracePeriod?: Duration;
    hardDeleteDefaultDuration?: Duration;
    pluginRepositoryUrl?: string;
    pluginRepositorySecretArn?: string;
}
export interface InfluxDBv3EnterpriseParameters {
    queryFileLimit?: number;
    queryLogSize?: number;
    logFilter?: string;
    logFormat?: LogFormats;
    dataFusionNumThreads?: number;
    dataFusionRuntimeType?: DataFusionRuntimeType;
    dataFusionRuntimeDisableLifoSlot?: boolean;
    dataFusionRuntimeEventInterval?: number;
    dataFusionRuntimeGlobalQueueInterval?: number;
    dataFusionRuntimeMaxBlockingThreads?: number;
    dataFusionRuntimeMaxIoEventsPerTick?: number;
    dataFusionRuntimeThreadKeepAlive?: Duration;
    dataFusionRuntimeThreadPriority?: number;
    dataFusionMaxParquetFanout?: number;
    dataFusionUseCachedParquetLoader?: boolean;
    dataFusionConfig?: string;
    maxHttpRequestSize?: number;
    forceSnapshotMemThreshold?: PercentOrAbsoluteLong;
    walSnapshotSize?: number;
    walMaxWriteBufferSize?: number;
    snapshottedWalFilesToKeep?: number;
    preemptiveCacheAge?: Duration;
    parquetMemCachePrunePercentage?: number;
    parquetMemCachePruneInterval?: Duration;
    disableParquetMemCache?: boolean;
    parquetMemCacheQueryPathDuration?: Duration;
    lastCacheEvictionInterval?: Duration;
    distinctCacheEvictionInterval?: Duration;
    gen1Duration?: Duration;
    execMemPoolBytes?: PercentOrAbsoluteLong;
    parquetMemCacheSize?: PercentOrAbsoluteLong;
    walReplayFailOnError?: boolean;
    walReplayConcurrencyLimit?: number;
    tableIndexCacheMaxEntries?: number;
    tableIndexCacheConcurrencyLimit?: number;
    gen1LookbackDuration?: Duration;
    retentionCheckInterval?: Duration;
    deleteGracePeriod?: Duration;
    hardDeleteDefaultDuration?: Duration;
    pluginRepositoryUrl?: string;
    pluginRepositorySecretArn?: string;
    ingestQueryInstances: number;
    queryOnlyInstances: number;
    dedicatedCompactor: boolean;
    compactionRowLimit?: number;
    compactionMaxNumFilesPerPlan?: number;
    compactionGen2Duration?: Duration;
    compactionMultipliers?: string;
    compactionCleanupWait?: Duration;
    compactionCheckInterval?: Duration;
    lastValueCacheDisableFromHistory?: boolean;
    distinctValueCacheDisableFromHistory?: boolean;
    replicationInterval?: Duration;
    catalogSyncInterval?: Duration;
}
export type Parameters = {
    InfluxDBv2: InfluxDBv2Parameters;
    InfluxDBv3Core?: never;
    InfluxDBv3Enterprise?: never;
} | {
    InfluxDBv2?: never;
    InfluxDBv3Core: InfluxDBv3CoreParameters;
    InfluxDBv3Enterprise?: never;
} | {
    InfluxDBv2?: never;
    InfluxDBv3Core?: never;
    InfluxDBv3Enterprise: InfluxDBv3EnterpriseParameters;
};
export interface CreateDbParameterGroupInput {
    name: string;
    description?: string;
    parameters?: Parameters;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateDbParameterGroupOutput {
    id: string;
    name: string;
    arn: string;
    description?: string;
    parameters?: Parameters;
}
export interface DeleteDbBackupInput {
    identifier: string;
}
export interface DeleteDbBackupOutput {
    id: string;
    name?: string;
    arn: string;
    status?: DbBackupStatus;
    createdAt?: Date;
    expiresAfter?: string;
    dbResourceId?: string;
    type?: DbBackupType;
    engineType?: EngineType;
    deploymentType?: ResourceDeploymentType;
    kmsKeyId?: string;
    clusterConfiguration?: ClusterConfiguration;
    dbParameterGroupId?: string;
    dbInstanceType?: DbInstanceType;
    logDeliveryConfiguration?: LogDeliveryConfiguration;
    failoverMode?: FailoverMode;
    dbStorageType?: DbStorageType;
    allocatedStorage?: number;
    vpcSubnetIds?: string[];
    vpcSecurityGroupIds?: string[];
    publiclyAccessible?: boolean;
    port?: number;
    networkType?: NetworkType;
    influxAuthParametersSecretArn?: string;
    maintenanceSchedule?: MaintenanceSchedule;
}
export interface DeleteDbClusterInput {
    dbClusterId: string;
    retainAutomatedBackups?: boolean;
}
export interface DeleteDbClusterOutput {
    dbClusterStatus?: ClusterStatus;
}
export type DbInstanceIdentifier = string;
export interface DeleteDbInstanceInput {
    identifier: string;
    retainAutomatedBackups?: boolean;
}
export interface DeleteDbInstanceOutput {
    id: string;
    name: string;
    arn: string;
    status?: Status;
    endpoint?: string;
    port?: number;
    networkType?: NetworkType;
    dbInstanceType?: DbInstanceType;
    dbStorageType?: DbStorageType;
    allocatedStorage?: number;
    deploymentType?: DeploymentType;
    vpcSubnetIds: string[];
    publiclyAccessible?: boolean;
    vpcSecurityGroupIds?: string[];
    dbParameterGroupIdentifier?: string;
    availabilityZone?: string;
    secondaryAvailabilityZone?: string;
    logDeliveryConfiguration?: LogDeliveryConfiguration;
    influxAuthParametersSecretArn?: string;
    dbClusterId?: string;
    instanceMode?: InstanceMode;
    instanceModes?: InstanceMode[];
    maintenanceSchedule?: MaintenanceSchedule;
    lastMaintenanceTime?: Date;
    nextMaintenanceTime?: Date;
    dbBackupConfigurations?: DbBackupConfigurationOutput[];
    kmsKeyId?: string;
}
export interface GetDbBackupInput {
    identifier: string;
}
export interface GetDbBackupOutput {
    id: string;
    name?: string;
    arn: string;
    status?: DbBackupStatus;
    createdAt?: Date;
    expiresAfter?: string;
    dbResourceId?: string;
    type?: DbBackupType;
    engineType?: EngineType;
    deploymentType?: ResourceDeploymentType;
    kmsKeyId?: string;
    clusterConfiguration?: ClusterConfiguration;
    dbParameterGroupId?: string;
    dbInstanceType?: DbInstanceType;
    logDeliveryConfiguration?: LogDeliveryConfiguration;
    failoverMode?: FailoverMode;
    dbStorageType?: DbStorageType;
    allocatedStorage?: number;
    vpcSubnetIds?: string[];
    vpcSecurityGroupIds?: string[];
    publiclyAccessible?: boolean;
    port?: number;
    networkType?: NetworkType;
    influxAuthParametersSecretArn?: string;
    maintenanceSchedule?: MaintenanceSchedule;
}
export interface GetDbClusterInput {
    dbClusterId: string;
}
export interface GetDbClusterOutput {
    id: string;
    name: string;
    arn: string;
    status?: ClusterStatus;
    endpoint?: string;
    readerEndpoint?: string;
    port?: number;
    deploymentType?: ClusterDeploymentType;
    dbInstanceType?: DbInstanceType;
    networkType?: NetworkType;
    dbStorageType?: DbStorageType;
    allocatedStorage?: number;
    engineType?: EngineType;
    publiclyAccessible?: boolean;
    dbParameterGroupIdentifier?: string;
    effectiveDbParameterGroupIdentifier?: string;
    logDeliveryConfiguration?: LogDeliveryConfiguration;
    maintenanceSchedule?: MaintenanceSchedule;
    lastMaintenanceTime?: Date;
    nextMaintenanceTime?: Date;
    influxAuthParametersSecretArn?: string;
    vpcSubnetIds?: string[];
    vpcSecurityGroupIds?: string[];
    failoverMode?: FailoverMode;
    clusterConfiguration?: ClusterConfiguration;
    dbBackupConfigurations?: DbBackupConfigurationOutput[];
    kmsKeyId?: string;
}
export interface GetDbInstanceInput {
    identifier: string;
}
export interface GetDbInstanceOutput {
    id: string;
    name: string;
    arn: string;
    status?: Status;
    endpoint?: string;
    port?: number;
    networkType?: NetworkType;
    dbInstanceType?: DbInstanceType;
    dbStorageType?: DbStorageType;
    allocatedStorage?: number;
    deploymentType?: DeploymentType;
    vpcSubnetIds: string[];
    publiclyAccessible?: boolean;
    vpcSecurityGroupIds?: string[];
    dbParameterGroupIdentifier?: string;
    availabilityZone?: string;
    secondaryAvailabilityZone?: string;
    logDeliveryConfiguration?: LogDeliveryConfiguration;
    influxAuthParametersSecretArn?: string;
    dbClusterId?: string;
    instanceMode?: InstanceMode;
    instanceModes?: InstanceMode[];
    maintenanceSchedule?: MaintenanceSchedule;
    lastMaintenanceTime?: Date;
    nextMaintenanceTime?: Date;
    dbBackupConfigurations?: DbBackupConfigurationOutput[];
    kmsKeyId?: string;
}
export interface GetDbParameterGroupInput {
    identifier: string;
}
export interface GetDbParameterGroupOutput {
    id: string;
    name: string;
    arn: string;
    description?: string;
    parameters?: Parameters;
}
export type NextToken = string;
export type MaxResults = number;
export interface ListDbBackupsInput {
    dbResourceId?: string;
    nextToken?: string;
    maxResults?: number;
}
export interface DbBackupSummary {
    id: string;
    name?: string;
    arn: string;
    status?: DbBackupStatus;
    createdAt?: Date;
    expiresAfter?: string;
    dbResourceId?: string;
    type?: DbBackupType;
    engineType?: EngineType;
    deploymentType?: ResourceDeploymentType;
    kmsKeyId?: string;
}
export type DbBackupSummaryList = DbBackupSummary[];
export interface ListDbBackupsOutput {
    items: DbBackupSummary[];
    nextToken?: string;
}
export interface ListDbClustersInput {
    nextToken?: string;
    maxResults?: number;
}
export interface DbClusterSummary {
    id: string;
    name: string;
    arn: string;
    status?: ClusterStatus;
    endpoint?: string;
    readerEndpoint?: string;
    port?: number;
    deploymentType?: ClusterDeploymentType;
    dbInstanceType?: DbInstanceType;
    networkType?: NetworkType;
    dbStorageType?: DbStorageType;
    allocatedStorage?: number;
    engineType?: EngineType;
}
export type DbClusterSummaryList = DbClusterSummary[];
export interface ListDbClustersOutput {
    items: DbClusterSummary[];
    nextToken?: string;
}
export interface ListDbInstancesInput {
    nextToken?: string;
    maxResults?: number;
}
export interface DbInstanceSummary {
    id: string;
    name: string;
    arn: string;
    status?: Status;
    endpoint?: string;
    port?: number;
    networkType?: NetworkType;
    dbInstanceType?: DbInstanceType;
    dbStorageType?: DbStorageType;
    allocatedStorage?: number;
    deploymentType?: DeploymentType;
}
export type DbInstanceSummaryList = DbInstanceSummary[];
export interface ListDbInstancesOutput {
    items: DbInstanceSummary[];
    nextToken?: string;
}
export interface ListDbInstancesForClusterInput {
    dbClusterId: string;
    nextToken?: string;
    maxResults?: number;
}
export interface DbInstanceForClusterSummary {
    id: string;
    name: string;
    arn: string;
    status?: Status;
    endpoint?: string;
    port?: number;
    networkType?: NetworkType;
    dbInstanceType?: DbInstanceType;
    dbStorageType?: DbStorageType;
    allocatedStorage?: number;
    deploymentType?: DeploymentType;
    instanceMode?: InstanceMode;
    instanceModes?: InstanceMode[];
}
export type DbInstanceForClusterSummaryList = DbInstanceForClusterSummary[];
export interface ListDbInstancesForClusterOutput {
    items: DbInstanceForClusterSummary[];
    nextToken?: string;
}
export interface ListDbParameterGroupsInput {
    nextToken?: string;
    maxResults?: number;
}
export interface DbParameterGroupSummary {
    id: string;
    name: string;
    arn: string;
    description?: string;
}
export type DbParameterGroupSummaryList = DbParameterGroupSummary[];
export interface ListDbParameterGroupsOutput {
    items: DbParameterGroupSummary[];
    nextToken?: string;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export type ResponseTagMap = {
    [key: string]: string | undefined;
};
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export type DbInstanceIdList = string[];
export interface RebootDbClusterInput {
    dbClusterId: string;
    instanceIds?: string[];
}
export interface RebootDbClusterOutput {
    dbClusterStatus?: ClusterStatus;
}
export interface RebootDbInstanceInput {
    identifier: string;
}
export interface RebootDbInstanceOutput {
    id: string;
    name: string;
    arn: string;
    status?: Status;
    endpoint?: string;
    port?: number;
    networkType?: NetworkType;
    dbInstanceType?: DbInstanceType;
    dbStorageType?: DbStorageType;
    allocatedStorage?: number;
    deploymentType?: DeploymentType;
    vpcSubnetIds: string[];
    publiclyAccessible?: boolean;
    vpcSecurityGroupIds?: string[];
    dbParameterGroupIdentifier?: string;
    availabilityZone?: string;
    secondaryAvailabilityZone?: string;
    logDeliveryConfiguration?: LogDeliveryConfiguration;
    influxAuthParametersSecretArn?: string;
    dbClusterId?: string;
    instanceMode?: InstanceMode;
    instanceModes?: InstanceMode[];
    maintenanceSchedule?: MaintenanceSchedule;
    lastMaintenanceTime?: Date;
    nextMaintenanceTime?: Date;
    dbBackupConfigurations?: DbBackupConfigurationOutput[];
    kmsKeyId?: string;
}
export type DbResourceName = string;
export type RestoreMode = "NEW_RESOURCE" | "REPLACE_EXISTING" | (string & {});
export interface RestoreFromDbBackupInput {
    name: string;
    dbBackupId: string;
    restoreToTime?: Date;
    restoreMode?: RestoreMode;
    vpcSubnetIds?: string[];
    vpcSecurityGroupIds?: string[];
    publiclyAccessible?: boolean;
    logDeliveryConfiguration?: LogDeliveryConfiguration;
    maintenanceSchedule?: MaintenanceSchedule;
    tags?: {
        [key: string]: string | undefined;
    };
    port?: number;
    networkType?: NetworkType;
    deploymentType?: ResourceDeploymentType;
    dbBackupConfigurations?: DbBackupConfiguration[];
    kmsKeyId?: string;
}
export type RestoreStatus = "RESTORING" | (string & {});
export type ResourceType = "DB_INSTANCE" | "DB_CLUSTER" | (string & {});
export interface RestoreFromDbBackupOutput {
    restoredDbResourceId?: string;
    restoreStatus?: RestoreStatus;
    resourceType?: ResourceType;
    engineType?: EngineType;
    deploymentType?: ResourceDeploymentType;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateDbClusterInput {
    dbClusterId: string;
    logDeliveryConfiguration?: LogDeliveryConfiguration;
    dbParameterGroupIdentifier?: string;
    port?: number;
    dbInstanceType?: DbInstanceType;
    failoverMode?: FailoverMode;
    maintenanceSchedule?: MaintenanceSchedule;
    dbBackupConfigurations?: DbBackupConfiguration[];
}
export interface UpdateDbClusterOutput {
    dbClusterStatus?: ClusterStatus;
}
export interface UpdateDbInstanceInput {
    identifier: string;
    logDeliveryConfiguration?: LogDeliveryConfiguration;
    dbParameterGroupIdentifier?: string;
    port?: number;
    dbInstanceType?: DbInstanceType;
    deploymentType?: DeploymentType;
    dbStorageType?: DbStorageType;
    allocatedStorage?: number;
    maintenanceSchedule?: MaintenanceSchedule;
    dbBackupConfigurations?: DbBackupConfiguration[];
}
export interface UpdateDbInstanceOutput {
    id: string;
    name: string;
    arn: string;
    status?: Status;
    endpoint?: string;
    port?: number;
    networkType?: NetworkType;
    dbInstanceType?: DbInstanceType;
    dbStorageType?: DbStorageType;
    allocatedStorage?: number;
    deploymentType?: DeploymentType;
    vpcSubnetIds: string[];
    publiclyAccessible?: boolean;
    vpcSecurityGroupIds?: string[];
    dbParameterGroupIdentifier?: string;
    availabilityZone?: string;
    secondaryAvailabilityZone?: string;
    logDeliveryConfiguration?: LogDeliveryConfiguration;
    influxAuthParametersSecretArn?: string;
    dbClusterId?: string;
    instanceMode?: InstanceMode;
    instanceModes?: InstanceMode[];
    maintenanceSchedule?: MaintenanceSchedule;
    lastMaintenanceTime?: Date;
    nextMaintenanceTime?: Date;
    dbBackupConfigurations?: DbBackupConfigurationOutput[];
    kmsKeyId?: string;
}
export type ValidationExceptionReason = "FIELD_VALIDATION_FAILED" | "OTHER" | (string & {});
export type CreateDbBackupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new on-demand backup of a Timestream for InfluxDB resource.
 */
export declare const createDbBackup: API.OperationMethod<CreateDbBackupInput, CreateDbBackupOutput, CreateDbBackupError, Credentials | HttpClient.HttpClient>;
export type CreateDbClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Timestream for InfluxDB cluster.
 */
export declare const createDbCluster: API.OperationMethod<CreateDbClusterInput, CreateDbClusterOutput, CreateDbClusterError, Credentials | HttpClient.HttpClient>;
export type CreateDbInstanceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Timestream for InfluxDB DB instance.
 */
export declare const createDbInstance: API.OperationMethod<CreateDbInstanceInput, CreateDbInstanceOutput, CreateDbInstanceError, Credentials | HttpClient.HttpClient>;
export type CreateDbParameterGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Timestream for InfluxDB DB parameter group to associate with DB instances.
 */
export declare const createDbParameterGroup: API.OperationMethod<CreateDbParameterGroupInput, CreateDbParameterGroupOutput, CreateDbParameterGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteDbBackupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Timestream for InfluxDB backup.
 */
export declare const deleteDbBackup: API.OperationMethod<DeleteDbBackupInput, DeleteDbBackupOutput, DeleteDbBackupError, Credentials | HttpClient.HttpClient>;
export type DeleteDbClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Timestream for InfluxDB cluster.
 */
export declare const deleteDbCluster: API.OperationMethod<DeleteDbClusterInput, DeleteDbClusterOutput, DeleteDbClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteDbInstanceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Timestream for InfluxDB DB instance.
 */
export declare const deleteDbInstance: API.OperationMethod<DeleteDbInstanceInput, DeleteDbInstanceOutput, DeleteDbInstanceError, Credentials | HttpClient.HttpClient>;
export type GetDbBackupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specific Timestream for InfluxDB backup.
 */
export declare const getDbBackup: API.OperationMethod<GetDbBackupInput, GetDbBackupOutput, GetDbBackupError, Credentials | HttpClient.HttpClient>;
export type GetDbClusterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a Timestream for InfluxDB cluster.
 */
export declare const getDbCluster: API.OperationMethod<GetDbClusterInput, GetDbClusterOutput, GetDbClusterError, Credentials | HttpClient.HttpClient>;
export type GetDbInstanceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a Timestream for InfluxDB DB instance.
 */
export declare const getDbInstance: API.OperationMethod<GetDbInstanceInput, GetDbInstanceOutput, GetDbInstanceError, Credentials | HttpClient.HttpClient>;
export type GetDbParameterGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a Timestream for InfluxDB DB parameter group.
 */
export declare const getDbParameterGroup: API.OperationMethod<GetDbParameterGroupInput, GetDbParameterGroupOutput, GetDbParameterGroupError, Credentials | HttpClient.HttpClient>;
export type ListDbBackupsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of Timestream for InfluxDB backups.
 */
export declare const listDbBackups: API.PaginatedOperationMethod<ListDbBackupsInput, ListDbBackupsOutput, ListDbBackupsError, Credentials | HttpClient.HttpClient, DbBackupSummary>;
export type ListDbClustersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of Timestream for InfluxDB DB clusters.
 */
export declare const listDbClusters: API.PaginatedOperationMethod<ListDbClustersInput, ListDbClustersOutput, ListDbClustersError, Credentials | HttpClient.HttpClient, DbClusterSummary>;
export type ListDbInstancesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of Timestream for InfluxDB DB instances.
 */
export declare const listDbInstances: API.PaginatedOperationMethod<ListDbInstancesInput, ListDbInstancesOutput, ListDbInstancesError, Credentials | HttpClient.HttpClient, DbInstanceSummary>;
export type ListDbInstancesForClusterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of Timestream for InfluxDB clusters.
 */
export declare const listDbInstancesForCluster: API.PaginatedOperationMethod<ListDbInstancesForClusterInput, ListDbInstancesForClusterOutput, ListDbInstancesForClusterError, Credentials | HttpClient.HttpClient, DbInstanceForClusterSummary>;
export type ListDbParameterGroupsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of Timestream for InfluxDB DB parameter groups.
 */
export declare const listDbParameterGroups: API.PaginatedOperationMethod<ListDbParameterGroupsInput, ListDbParameterGroupsOutput, ListDbParameterGroupsError, Credentials | HttpClient.HttpClient, DbParameterGroupSummary>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * A list of tags applied to the resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RebootDbClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Reboots a Timestream for InfluxDB cluster.
 */
export declare const rebootDbCluster: API.OperationMethod<RebootDbClusterInput, RebootDbClusterOutput, RebootDbClusterError, Credentials | HttpClient.HttpClient>;
export type RebootDbInstanceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Reboots a Timestream for InfluxDB instance.
 */
export declare const rebootDbInstance: API.OperationMethod<RebootDbInstanceInput, RebootDbInstanceOutput, RebootDbInstanceError, Credentials | HttpClient.HttpClient>;
export type RestoreFromDbBackupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Restores a Timestream for InfluxDB resource from a backup. By default, a new resource is created. You can optionally restore to the same resource using the REPLACE_EXISTING restore mode.
 */
export declare const restoreFromDbBackup: API.OperationMethod<RestoreFromDbBackupInput, RestoreFromDbBackupOutput, RestoreFromDbBackupError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Tags are composed of a Key/Value pairs. You can use tags to categorize and track your Timestream for InfluxDB resources.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Removes the tag from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDbClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a Timestream for InfluxDB cluster.
 */
export declare const updateDbCluster: API.OperationMethod<UpdateDbClusterInput, UpdateDbClusterOutput, UpdateDbClusterError, Credentials | HttpClient.HttpClient>;
export type UpdateDbInstanceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a Timestream for InfluxDB DB instance.
 */
export declare const updateDbInstance: API.OperationMethod<UpdateDbInstanceInput, UpdateDbInstanceOutput, UpdateDbInstanceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=timestream-influxdb.d.ts.map