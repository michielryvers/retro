import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DeviceOfflineException_base: S.TaggedErrorClass<"DeviceOfflineException", {
    readonly message: any;
}>;
export declare class DeviceOfflineException extends /*@__PURE__*/ DeviceOfflineException_base {
}
declare const DeviceRetiredException_base: S.TaggedErrorClass<"DeviceRetiredException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DeviceRetiredException extends /*@__PURE__*/ DeviceRetiredException_base {
}
declare const InternalServiceException_base: S.TaggedErrorClass<"InternalServiceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServiceException extends /*@__PURE__*/ InternalServiceException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly programSetValidationFailures: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type JobArn = string;
export interface CancelJobRequest {
    jobArn: string;
}
export type CancellationStatus = string;
export interface CancelJobResponse {
    jobArn: string;
    cancellationStatus: string;
}
export type QuantumTaskArn = string;
export type String64 = string;
export interface CancelQuantumTaskRequest {
    quantumTaskArn: string;
    clientToken: string;
}
export interface CancelQuantumTaskResponse {
    quantumTaskArn: string;
    cancellationStatus: string;
}
export type S3Path = string;
export type CompressionType = string;
export interface ScriptModeConfig {
    entryPoint: string;
    s3Uri: string;
    compressionType?: string;
}
export type Uri = string;
export interface ContainerImage {
    uri: string;
}
export interface AlgorithmSpecification {
    scriptModeConfig?: ScriptModeConfig;
    containerImage?: ContainerImage;
}
export type String256 = string;
export interface S3DataSource {
    s3Uri: string;
}
export interface DataSource {
    s3DataSource: S3DataSource;
}
export interface InputFileConfig {
    channelName: string;
    contentType?: string;
    dataSource: DataSource;
}
export type InputConfigList = InputFileConfig[];
export type String2048 = string;
export interface JobOutputDataConfig {
    kmsKeyId?: string;
    s3Path: string;
}
export type String4096 = string;
export interface JobCheckpointConfig {
    localPath?: string;
    s3Uri: string;
}
export type RoleArn = string;
export interface JobStoppingCondition {
    maxRuntimeInSeconds?: number;
}
export type InstanceType = string;
export interface InstanceConfig {
    instanceType: string;
    volumeSizeInGb: number;
    instanceCount?: number;
}
export type HyperParameters = {
    [key: string]: string | undefined;
};
export interface DeviceConfig {
    device: string;
}
export type TagsMap = {
    [key: string]: string | undefined;
};
export type BraketResourceArn = string;
export type AssociationType = string;
export interface Association {
    arn: string;
    type: string;
}
export type Associations = Association[];
export interface CreateJobRequest {
    clientToken: string;
    algorithmSpecification: AlgorithmSpecification;
    inputDataConfig?: InputFileConfig[];
    outputDataConfig: JobOutputDataConfig;
    checkpointConfig?: JobCheckpointConfig;
    jobName: string;
    roleArn: string;
    stoppingCondition?: JobStoppingCondition;
    instanceConfig: InstanceConfig;
    hyperParameters?: {
        [key: string]: string | undefined;
    };
    deviceConfig: DeviceConfig;
    tags?: {
        [key: string]: string | undefined;
    };
    associations?: Association[];
}
export interface CreateJobResponse {
    jobArn: string;
}
export type DeviceArn = string;
export type JsonValue = string;
export type JobToken = string;
export type ExperimentalCapabilitiesEnablementType = string;
export type ExperimentalCapabilities = {
    enabled: string;
};
export interface CreateQuantumTaskRequest {
    clientToken: string;
    deviceArn: string;
    deviceParameters?: string;
    shots: number;
    outputS3Bucket: string;
    outputS3KeyPrefix: string;
    action: string;
    tags?: {
        [key: string]: string | undefined;
    };
    jobToken?: string;
    associations?: Association[];
    experimentalCapabilities?: ExperimentalCapabilities;
}
export interface CreateQuantumTaskResponse {
    quantumTaskArn: string;
}
export interface TimePeriod {
    startAt: Date;
    endAt: Date;
}
export interface CreateSpendingLimitRequest {
    clientToken: string;
    deviceArn: string;
    spendingLimit: string;
    timePeriod?: TimePeriod;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type SpendingLimitArn = string;
export interface CreateSpendingLimitResponse {
    spendingLimitArn: string;
}
export interface DeleteSpendingLimitRequest {
    spendingLimitArn: string;
}
export interface DeleteSpendingLimitResponse {
}
export interface GetDeviceRequest {
    deviceArn: string;
}
export type DeviceType = string;
export type DeviceStatus = string;
export type QueueName = string;
export type QueuePriority = string;
export interface DeviceQueueInfo {
    queue: string;
    queueSize: string;
    queuePriority?: string;
}
export type DeviceQueueInfoList = DeviceQueueInfo[];
export interface GetDeviceResponse {
    deviceArn: string;
    deviceName: string;
    providerName: string;
    deviceType: string;
    deviceStatus: string;
    deviceCapabilities: string;
    deviceQueueInfo?: DeviceQueueInfo[];
}
export type HybridJobAdditionalAttributeName = string;
export type HybridJobAdditionalAttributeNamesList = string[];
export interface GetJobRequest {
    jobArn: string;
    additionalAttributeNames?: string[];
}
export type JobPrimaryStatus = string;
export type String1024 = string;
export type JobEventType = string;
export interface JobEventDetails {
    eventType?: string;
    timeOfEvent?: Date;
    message?: string;
}
export type JobEvents = JobEventDetails[];
export interface HybridJobQueueInfo {
    queue: string;
    position: string;
    message?: string;
}
export interface GetJobResponse {
    status: string;
    jobArn: string;
    roleArn: string;
    failureReason?: string;
    jobName: string;
    hyperParameters?: {
        [key: string]: string | undefined;
    };
    inputDataConfig?: InputFileConfig[];
    outputDataConfig: JobOutputDataConfig;
    stoppingCondition?: JobStoppingCondition;
    checkpointConfig?: JobCheckpointConfig;
    algorithmSpecification: AlgorithmSpecification;
    instanceConfig: InstanceConfig;
    createdAt: Date;
    startedAt?: Date;
    endedAt?: Date;
    billableDuration?: number;
    deviceConfig?: DeviceConfig;
    events?: JobEventDetails[];
    tags?: {
        [key: string]: string | undefined;
    };
    queueInfo?: HybridJobQueueInfo;
    associations?: Association[];
}
export type QuantumTaskAdditionalAttributeName = string;
export type QuantumTaskAdditionalAttributeNamesList = string[];
export interface GetQuantumTaskRequest {
    quantumTaskArn: string;
    additionalAttributeNames?: string[];
}
export type QuantumTaskStatus = string;
export interface QuantumTaskQueueInfo {
    queue: string;
    position: string;
    queuePriority?: string;
    message?: string;
}
export interface ActionMetadata {
    actionType: string;
    programCount?: number;
    executableCount?: number;
}
export interface GetQuantumTaskResponse {
    quantumTaskArn: string;
    status: string;
    failureReason?: string;
    deviceArn: string;
    deviceParameters: string;
    shots: number;
    outputS3Bucket: string;
    outputS3Directory: string;
    createdAt: Date;
    endedAt?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    jobArn?: string;
    queueInfo?: QuantumTaskQueueInfo;
    associations?: Association[];
    numSuccessfulShots?: number;
    actionMetadata?: ActionMetadata;
    experimentalCapabilities?: ExperimentalCapabilities;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export type String256List = string[];
export interface SearchDevicesFilter {
    name: string;
    values: string[];
}
export type SearchDevicesFilterList = SearchDevicesFilter[];
export interface SearchDevicesRequest {
    nextToken?: string;
    maxResults?: number;
    filters: SearchDevicesFilter[];
}
export interface DeviceSummary {
    deviceArn: string;
    deviceName: string;
    providerName: string;
    deviceType: string;
    deviceStatus: string;
}
export type DeviceSummaryList = DeviceSummary[];
export interface SearchDevicesResponse {
    devices: DeviceSummary[];
    nextToken?: string;
}
export type SearchJobsFilterOperator = string;
export interface SearchJobsFilter {
    name: string;
    values: string[];
    operator: string;
}
export type SearchJobsFilterList = SearchJobsFilter[];
export interface SearchJobsRequest {
    nextToken?: string;
    maxResults?: number;
    filters: SearchJobsFilter[];
}
export interface JobSummary {
    status: string;
    jobArn: string;
    jobName: string;
    device: string;
    createdAt: Date;
    startedAt?: Date;
    endedAt?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type JobSummaryList = JobSummary[];
export interface SearchJobsResponse {
    jobs: JobSummary[];
    nextToken?: string;
}
export type SearchQuantumTasksFilterOperator = string;
export interface SearchQuantumTasksFilter {
    name: string;
    values: string[];
    operator: string;
}
export type SearchQuantumTasksFilterList = SearchQuantumTasksFilter[];
export interface SearchQuantumTasksRequest {
    nextToken?: string;
    maxResults?: number;
    filters: SearchQuantumTasksFilter[];
}
export interface QuantumTaskSummary {
    quantumTaskArn: string;
    status: string;
    deviceArn: string;
    shots: number;
    outputS3Bucket: string;
    outputS3Directory: string;
    createdAt: Date;
    endedAt?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type QuantumTaskSummaryList = QuantumTaskSummary[];
export interface SearchQuantumTasksResponse {
    quantumTasks: QuantumTaskSummary[];
    nextToken?: string;
}
export type SearchSpendingLimitsFilterOperator = string;
export interface SearchSpendingLimitsFilter {
    name: string;
    values: string[];
    operator: string;
}
export type SearchSpendingLimitsFilterList = SearchSpendingLimitsFilter[];
export interface SearchSpendingLimitsRequest {
    nextToken?: string;
    maxResults?: number;
    filters?: SearchSpendingLimitsFilter[];
}
export interface SpendingLimitSummary {
    spendingLimitArn: string;
    deviceArn: string;
    timePeriod: TimePeriod;
    spendingLimit: string;
    queuedSpend: string;
    totalSpend: string;
    createdAt: Date;
    updatedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type SpendingLimitSummaryList = SpendingLimitSummary[];
export interface SearchSpendingLimitsResponse {
    spendingLimits: SpendingLimitSummary[];
    nextToken?: string;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateSpendingLimitRequest {
    spendingLimitArn: string;
    clientToken: string;
    spendingLimit?: string;
    timePeriod?: TimePeriod;
}
export interface UpdateSpendingLimitResponse {
}
export type ValidationExceptionReason = string;
export type ProgramValidationFailuresList = string[];
export interface ProgramSetValidationFailure {
    programIndex: number;
    inputsIndex?: number;
    errors?: string[];
}
export type ProgramSetValidationFailuresList = ProgramSetValidationFailure[];
export type CancelJobError = AccessDeniedException | ConflictException | InternalServiceException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels an Amazon Braket hybrid job.
 */
export declare const cancelJob: API.OperationMethod<CancelJobRequest, CancelJobResponse, CancelJobError, Credentials | HttpClient.HttpClient>;
export type CancelQuantumTaskError = AccessDeniedException | ConflictException | InternalServiceException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels the specified task.
 */
export declare const cancelQuantumTask: API.OperationMethod<CancelQuantumTaskRequest, CancelQuantumTaskResponse, CancelQuantumTaskError, Credentials | HttpClient.HttpClient>;
export type CreateJobError = AccessDeniedException | ConflictException | DeviceOfflineException | DeviceRetiredException | InternalServiceException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Braket hybrid job.
 */
export declare const createJob: API.OperationMethod<CreateJobRequest, CreateJobResponse, CreateJobError, Credentials | HttpClient.HttpClient>;
export type CreateQuantumTaskError = AccessDeniedException | DeviceOfflineException | DeviceRetiredException | InternalServiceException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a quantum task.
 */
export declare const createQuantumTask: API.OperationMethod<CreateQuantumTaskRequest, CreateQuantumTaskResponse, CreateQuantumTaskError, Credentials | HttpClient.HttpClient>;
export type CreateSpendingLimitError = AccessDeniedException | DeviceRetiredException | InternalServiceException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a spending limit for a specified quantum device. Spending limits help you control costs by setting maximum amounts that can be spent on quantum computing tasks within a specified time period. Simulators do not support spending limits.
 */
export declare const createSpendingLimit: API.OperationMethod<CreateSpendingLimitRequest, CreateSpendingLimitResponse, CreateSpendingLimitError, Credentials | HttpClient.HttpClient>;
export type DeleteSpendingLimitError = AccessDeniedException | InternalServiceException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing spending limit. This operation permanently removes the spending limit and cannot be undone. After deletion, the associated device becomes unrestricted for spending.
 */
export declare const deleteSpendingLimit: API.OperationMethod<DeleteSpendingLimitRequest, DeleteSpendingLimitResponse, DeleteSpendingLimitError, Credentials | HttpClient.HttpClient>;
export type GetDeviceError = AccessDeniedException | InternalServiceException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the devices available in Amazon Braket.
 *
 * For backwards compatibility with older versions of BraketSchemas, OpenQASM information is omitted from GetDevice API calls. To get this information the user-agent needs to present a recent version of the BraketSchemas (1.8.0 or later). The Braket SDK automatically reports this for you. If you do not see OpenQASM results in the GetDevice response when using a Braket SDK, you may need to set AWS_EXECUTION_ENV environment variable to configure user-agent. See the code examples provided below for how to do this for the AWS CLI, Boto3, and the Go, Java, and JavaScript/TypeScript SDKs.
 */
export declare const getDevice: API.OperationMethod<GetDeviceRequest, GetDeviceResponse, GetDeviceError, Credentials | HttpClient.HttpClient>;
export type GetJobError = AccessDeniedException | InternalServiceException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the specified Amazon Braket hybrid job.
 */
export declare const getJob: API.OperationMethod<GetJobRequest, GetJobResponse, GetJobError, Credentials | HttpClient.HttpClient>;
export type GetQuantumTaskError = AccessDeniedException | InternalServiceException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the specified quantum task.
 */
export declare const getQuantumTask: API.OperationMethod<GetQuantumTaskRequest, GetQuantumTaskResponse, GetQuantumTaskError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InternalServiceException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Shows the tags associated with this resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type SearchDevicesError = AccessDeniedException | InternalServiceException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches for devices using the specified filters.
 */
export declare const searchDevices: API.PaginatedOperationMethod<SearchDevicesRequest, SearchDevicesResponse, SearchDevicesError, Credentials | HttpClient.HttpClient, DeviceSummary>;
export type SearchJobsError = AccessDeniedException | InternalServiceException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches for Amazon Braket hybrid jobs that match the specified filter values.
 */
export declare const searchJobs: API.PaginatedOperationMethod<SearchJobsRequest, SearchJobsResponse, SearchJobsError, Credentials | HttpClient.HttpClient, JobSummary>;
export type SearchQuantumTasksError = AccessDeniedException | InternalServiceException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches for tasks that match the specified filter values.
 */
export declare const searchQuantumTasks: API.PaginatedOperationMethod<SearchQuantumTasksRequest, SearchQuantumTasksResponse, SearchQuantumTasksError, Credentials | HttpClient.HttpClient, QuantumTaskSummary>;
export type SearchSpendingLimitsError = AccessDeniedException | InternalServiceException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches and lists spending limits based on specified filters. This operation supports pagination and allows filtering by various criteria to find specific spending limits. We recommend using pagination to ensure that the operation returns quickly and successfully.
 */
export declare const searchSpendingLimits: API.PaginatedOperationMethod<SearchSpendingLimitsRequest, SearchSpendingLimitsResponse, SearchSpendingLimitsError, Credentials | HttpClient.HttpClient, SpendingLimitSummary>;
export type TagResourceError = InternalServiceException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Add a tag to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServiceException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Remove tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateSpendingLimitError = AccessDeniedException | InternalServiceException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing spending limit. You can modify the spending amount or time period. Changes take effect immediately.
 */
export declare const updateSpendingLimit: API.OperationMethod<UpdateSpendingLimitRequest, UpdateSpendingLimitResponse, UpdateSpendingLimitError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=braket.d.ts.map