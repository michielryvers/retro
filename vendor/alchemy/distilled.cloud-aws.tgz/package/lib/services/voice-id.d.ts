import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly ConflictType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DomainId = string;
export type WatchlistId = string;
export type FraudsterId = string | redacted.Redacted<string>;
export interface AssociateFraudsterRequest {
    DomainId: string;
    WatchlistId: string;
    FraudsterId: string | redacted.Redacted<string>;
}
export type GeneratedFraudsterId = string;
export type ResponseWatchlistIds = string[];
export interface Fraudster {
    DomainId?: string;
    GeneratedFraudsterId?: string;
    CreatedAt?: Date;
    WatchlistIds?: string[];
}
export interface AssociateFraudsterResponse {
    Fraudster?: Fraudster;
}
export type DomainName = string | redacted.Redacted<string>;
export type Description = string | redacted.Redacted<string>;
export type KmsKeyId = string;
export interface ServerSideEncryptionConfiguration {
    KmsKeyId: string;
}
export type ClientTokenString = string;
export type TagKey = string | redacted.Redacted<string>;
export type TagValue = string | redacted.Redacted<string>;
export interface Tag {
    Key: string | redacted.Redacted<string>;
    Value: string | redacted.Redacted<string>;
}
export type TagList = Tag[];
export interface CreateDomainRequest {
    Name: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    ServerSideEncryptionConfiguration: ServerSideEncryptionConfiguration;
    ClientToken?: string;
    Tags?: Tag[];
}
export type Arn = string;
export type DomainStatus = string;
export type ServerSideEncryptionUpdateStatus = string;
export interface ServerSideEncryptionUpdateDetails {
    OldKmsKeyId?: string;
    UpdateStatus?: string;
    Message?: string;
}
export interface WatchlistDetails {
    DefaultWatchlistId: string;
}
export interface Domain {
    DomainId?: string;
    Arn?: string;
    Name?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    DomainStatus?: string;
    ServerSideEncryptionConfiguration?: ServerSideEncryptionConfiguration;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    ServerSideEncryptionUpdateDetails?: ServerSideEncryptionUpdateDetails;
    WatchlistDetails?: WatchlistDetails;
}
export interface CreateDomainResponse {
    Domain?: Domain;
}
export type WatchlistName = string | redacted.Redacted<string>;
export type WatchlistDescription = string | redacted.Redacted<string>;
export interface CreateWatchlistRequest {
    DomainId: string;
    Name: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    ClientToken?: string;
}
export interface Watchlist {
    DomainId?: string;
    WatchlistId?: string;
    Name?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    DefaultWatchlist?: boolean;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export interface CreateWatchlistResponse {
    Watchlist?: Watchlist;
}
export interface DeleteDomainRequest {
    DomainId: string;
}
export interface DeleteDomainResponse {
}
export interface DeleteFraudsterRequest {
    DomainId: string;
    FraudsterId: string | redacted.Redacted<string>;
}
export interface DeleteFraudsterResponse {
}
export type SpeakerId = string | redacted.Redacted<string>;
export interface DeleteSpeakerRequest {
    DomainId: string;
    SpeakerId: string | redacted.Redacted<string>;
}
export interface DeleteSpeakerResponse {
}
export interface DeleteWatchlistRequest {
    DomainId: string;
    WatchlistId: string;
}
export interface DeleteWatchlistResponse {
}
export interface DescribeDomainRequest {
    DomainId: string;
}
export interface DescribeDomainResponse {
    Domain?: Domain;
}
export interface DescribeFraudsterRequest {
    DomainId: string;
    FraudsterId: string | redacted.Redacted<string>;
}
export interface DescribeFraudsterResponse {
    Fraudster?: Fraudster;
}
export type JobId = string;
export interface DescribeFraudsterRegistrationJobRequest {
    DomainId: string;
    JobId: string;
}
export type JobName = string | redacted.Redacted<string>;
export type FraudsterRegistrationJobStatus = string;
export type IamRoleArn = string;
export type DuplicateRegistrationAction = string;
export type Score = number;
export type RegistrationConfigWatchlistIds = string[];
export interface RegistrationConfig {
    DuplicateRegistrationAction?: string;
    FraudsterSimilarityThreshold?: number;
    WatchlistIds?: string[];
}
export type S3Uri = string;
export interface InputDataConfig {
    S3Uri: string;
}
export interface OutputDataConfig {
    S3Uri: string;
    KmsKeyId?: string;
}
export interface FailureDetails {
    StatusCode?: number;
    Message?: string;
}
export interface JobProgress {
    PercentComplete?: number;
}
export interface FraudsterRegistrationJob {
    JobName?: string | redacted.Redacted<string>;
    JobId?: string;
    JobStatus?: string;
    DomainId?: string;
    DataAccessRoleArn?: string;
    RegistrationConfig?: RegistrationConfig;
    InputDataConfig?: InputDataConfig;
    OutputDataConfig?: OutputDataConfig;
    CreatedAt?: Date;
    EndedAt?: Date;
    FailureDetails?: FailureDetails;
    JobProgress?: JobProgress;
}
export interface DescribeFraudsterRegistrationJobResponse {
    Job?: FraudsterRegistrationJob;
}
export interface DescribeSpeakerRequest {
    DomainId: string;
    SpeakerId: string | redacted.Redacted<string>;
}
export type CustomerSpeakerId = string | redacted.Redacted<string>;
export type GeneratedSpeakerId = string;
export type SpeakerStatus = string;
export interface Speaker {
    DomainId?: string;
    CustomerSpeakerId?: string | redacted.Redacted<string>;
    GeneratedSpeakerId?: string;
    Status?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    LastAccessedAt?: Date;
}
export interface DescribeSpeakerResponse {
    Speaker?: Speaker;
}
export interface DescribeSpeakerEnrollmentJobRequest {
    DomainId: string;
    JobId: string;
}
export type SpeakerEnrollmentJobStatus = string;
export type ExistingEnrollmentAction = string;
export type FraudDetectionAction = string;
export type EnrollmentJobFraudDetectionConfigWatchlistIds = string[];
export interface EnrollmentJobFraudDetectionConfig {
    FraudDetectionAction?: string;
    RiskThreshold?: number;
    WatchlistIds?: string[];
}
export interface EnrollmentConfig {
    ExistingEnrollmentAction?: string;
    FraudDetectionConfig?: EnrollmentJobFraudDetectionConfig;
}
export interface SpeakerEnrollmentJob {
    JobName?: string | redacted.Redacted<string>;
    JobId?: string;
    JobStatus?: string;
    DomainId?: string;
    DataAccessRoleArn?: string;
    EnrollmentConfig?: EnrollmentConfig;
    InputDataConfig?: InputDataConfig;
    OutputDataConfig?: OutputDataConfig;
    CreatedAt?: Date;
    EndedAt?: Date;
    FailureDetails?: FailureDetails;
    JobProgress?: JobProgress;
}
export interface DescribeSpeakerEnrollmentJobResponse {
    Job?: SpeakerEnrollmentJob;
}
export interface DescribeWatchlistRequest {
    DomainId: string;
    WatchlistId: string;
}
export interface DescribeWatchlistResponse {
    Watchlist?: Watchlist;
}
export interface DisassociateFraudsterRequest {
    DomainId: string;
    WatchlistId: string;
    FraudsterId: string | redacted.Redacted<string>;
}
export interface DisassociateFraudsterResponse {
    Fraudster?: Fraudster;
}
export type SessionNameOrId = string;
export interface EvaluateSessionRequest {
    DomainId: string;
    SessionNameOrId: string;
}
export type SessionId = string;
export type SessionName = string;
export type StreamingStatus = string;
export type UniqueIdLarge = string;
export type AuthenticationDecision = string;
export interface AuthenticationConfiguration {
    AcceptanceThreshold: number;
}
export interface AuthenticationResult {
    AuthenticationResultId?: string;
    AudioAggregationStartedAt?: Date;
    AudioAggregationEndedAt?: Date;
    CustomerSpeakerId?: string | redacted.Redacted<string>;
    GeneratedSpeakerId?: string;
    Decision?: string;
    Score?: number;
    Configuration?: AuthenticationConfiguration;
}
export interface FraudDetectionConfiguration {
    RiskThreshold?: number;
    WatchlistId?: string;
}
export type FraudDetectionDecision = string;
export type FraudDetectionReason = string;
export type FraudDetectionReasons = string[];
export interface KnownFraudsterRisk {
    RiskScore: number;
    GeneratedFraudsterId?: string;
}
export interface VoiceSpoofingRisk {
    RiskScore: number;
}
export interface FraudRiskDetails {
    KnownFraudsterRisk: KnownFraudsterRisk;
    VoiceSpoofingRisk: VoiceSpoofingRisk;
}
export interface FraudDetectionResult {
    FraudDetectionResultId?: string;
    AudioAggregationStartedAt?: Date;
    AudioAggregationEndedAt?: Date;
    Configuration?: FraudDetectionConfiguration;
    Decision?: string;
    Reasons?: string[];
    RiskDetails?: FraudRiskDetails;
}
export interface EvaluateSessionResponse {
    DomainId?: string;
    SessionId?: string;
    SessionName?: string;
    StreamingStatus?: string;
    AuthenticationResult?: AuthenticationResult;
    FraudDetectionResult?: FraudDetectionResult;
}
export type MaxResultsForListDomainFe = number;
export type NextToken = string;
export interface ListDomainsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface DomainSummary {
    DomainId?: string;
    Arn?: string;
    Name?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    DomainStatus?: string;
    ServerSideEncryptionConfiguration?: ServerSideEncryptionConfiguration;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    ServerSideEncryptionUpdateDetails?: ServerSideEncryptionUpdateDetails;
    WatchlistDetails?: WatchlistDetails;
}
export type DomainSummaries = DomainSummary[];
export interface ListDomainsResponse {
    DomainSummaries?: DomainSummary[];
    NextToken?: string;
}
export type MaxResultsForList = number;
export interface ListFraudsterRegistrationJobsRequest {
    DomainId: string;
    JobStatus?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface FraudsterRegistrationJobSummary {
    JobName?: string | redacted.Redacted<string>;
    JobId?: string;
    JobStatus?: string;
    DomainId?: string;
    CreatedAt?: Date;
    EndedAt?: Date;
    FailureDetails?: FailureDetails;
    JobProgress?: JobProgress;
}
export type FraudsterRegistrationJobSummaries = FraudsterRegistrationJobSummary[];
export interface ListFraudsterRegistrationJobsResponse {
    JobSummaries?: FraudsterRegistrationJobSummary[];
    NextToken?: string;
}
export interface ListFraudstersRequest {
    DomainId: string;
    WatchlistId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface FraudsterSummary {
    DomainId?: string;
    GeneratedFraudsterId?: string;
    CreatedAt?: Date;
    WatchlistIds?: string[];
}
export type FraudsterSummaries = FraudsterSummary[];
export interface ListFraudstersResponse {
    FraudsterSummaries?: FraudsterSummary[];
    NextToken?: string;
}
export interface ListSpeakerEnrollmentJobsRequest {
    DomainId: string;
    JobStatus?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface SpeakerEnrollmentJobSummary {
    JobName?: string | redacted.Redacted<string>;
    JobId?: string;
    JobStatus?: string;
    DomainId?: string;
    CreatedAt?: Date;
    EndedAt?: Date;
    FailureDetails?: FailureDetails;
    JobProgress?: JobProgress;
}
export type SpeakerEnrollmentJobSummaries = SpeakerEnrollmentJobSummary[];
export interface ListSpeakerEnrollmentJobsResponse {
    JobSummaries?: SpeakerEnrollmentJobSummary[];
    NextToken?: string;
}
export interface ListSpeakersRequest {
    DomainId: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface SpeakerSummary {
    DomainId?: string;
    CustomerSpeakerId?: string | redacted.Redacted<string>;
    GeneratedSpeakerId?: string;
    Status?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    LastAccessedAt?: Date;
}
export type SpeakerSummaries = SpeakerSummary[];
export interface ListSpeakersResponse {
    SpeakerSummaries?: SpeakerSummary[];
    NextToken?: string;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export interface ListWatchlistsRequest {
    DomainId: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface WatchlistSummary {
    DomainId?: string;
    WatchlistId?: string;
    Name?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    DefaultWatchlist?: boolean;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export type WatchlistSummaries = WatchlistSummary[];
export interface ListWatchlistsResponse {
    WatchlistSummaries?: WatchlistSummary[];
    NextToken?: string;
}
export interface OptOutSpeakerRequest {
    DomainId: string;
    SpeakerId: string | redacted.Redacted<string>;
}
export interface OptOutSpeakerResponse {
    Speaker?: Speaker;
}
export interface StartFraudsterRegistrationJobRequest {
    ClientToken?: string;
    JobName?: string | redacted.Redacted<string>;
    DomainId: string;
    DataAccessRoleArn: string;
    RegistrationConfig?: RegistrationConfig;
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
}
export interface StartFraudsterRegistrationJobResponse {
    Job?: FraudsterRegistrationJob;
}
export interface StartSpeakerEnrollmentJobRequest {
    ClientToken?: string;
    JobName?: string | redacted.Redacted<string>;
    DomainId: string;
    DataAccessRoleArn: string;
    EnrollmentConfig?: EnrollmentConfig;
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
}
export interface StartSpeakerEnrollmentJobResponse {
    Job?: SpeakerEnrollmentJob;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = (string | redacted.Redacted<string>)[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: (string | redacted.Redacted<string>)[];
}
export interface UntagResourceResponse {
}
export interface UpdateDomainRequest {
    DomainId: string;
    Name: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    ServerSideEncryptionConfiguration: ServerSideEncryptionConfiguration;
}
export interface UpdateDomainResponse {
    Domain?: Domain;
}
export interface UpdateWatchlistRequest {
    DomainId: string;
    WatchlistId: string;
    Name?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
}
export interface UpdateWatchlistResponse {
    Watchlist?: Watchlist;
}
export type ConflictType = string;
export type ResourceType = string;
export type AssociateFraudsterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates the fraudsters with the watchlist specified in the same domain.
 */
export declare const associateFraudster: API.OperationMethod<AssociateFraudsterRequest, AssociateFraudsterResponse, AssociateFraudsterError, Credentials | HttpClient.HttpClient>;
export type CreateDomainError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a domain that contains all Amazon Connect Voice ID data, such as speakers, fraudsters,
 * customer audio, and voiceprints. Every domain is created with a default watchlist that fraudsters can be a part of.
 */
export declare const createDomain: API.OperationMethod<CreateDomainRequest, CreateDomainResponse, CreateDomainError, Credentials | HttpClient.HttpClient>;
export type CreateWatchlistError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a watchlist that fraudsters can be a part of.
 */
export declare const createWatchlist: API.OperationMethod<CreateWatchlistRequest, CreateWatchlistResponse, CreateWatchlistError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified domain from Voice ID.
 */
export declare const deleteDomain: API.OperationMethod<DeleteDomainRequest, DeleteDomainResponse, DeleteDomainError, Credentials | HttpClient.HttpClient>;
export type DeleteFraudsterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified fraudster from Voice ID. This action disassociates the fraudster from any watchlists it is a part of.
 */
export declare const deleteFraudster: API.OperationMethod<DeleteFraudsterRequest, DeleteFraudsterResponse, DeleteFraudsterError, Credentials | HttpClient.HttpClient>;
export type DeleteSpeakerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified speaker from Voice ID.
 */
export declare const deleteSpeaker: API.OperationMethod<DeleteSpeakerRequest, DeleteSpeakerResponse, DeleteSpeakerError, Credentials | HttpClient.HttpClient>;
export type DeleteWatchlistError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified watchlist from Voice ID. This API throws an exception when
 * there are fraudsters in the watchlist that you are trying to delete. You must delete the
 * fraudsters, and then delete the watchlist. Every domain has a default watchlist which cannot be deleted.
 */
export declare const deleteWatchlist: API.OperationMethod<DeleteWatchlistRequest, DeleteWatchlistResponse, DeleteWatchlistError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the specified domain.
 */
export declare const describeDomain: API.OperationMethod<DescribeDomainRequest, DescribeDomainResponse, DescribeDomainError, Credentials | HttpClient.HttpClient>;
export type DescribeFraudsterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the specified fraudster.
 */
export declare const describeFraudster: API.OperationMethod<DescribeFraudsterRequest, DescribeFraudsterResponse, DescribeFraudsterError, Credentials | HttpClient.HttpClient>;
export type DescribeFraudsterRegistrationJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the specified fraudster registration job.
 */
export declare const describeFraudsterRegistrationJob: API.OperationMethod<DescribeFraudsterRegistrationJobRequest, DescribeFraudsterRegistrationJobResponse, DescribeFraudsterRegistrationJobError, Credentials | HttpClient.HttpClient>;
export type DescribeSpeakerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the specified speaker.
 */
export declare const describeSpeaker: API.OperationMethod<DescribeSpeakerRequest, DescribeSpeakerResponse, DescribeSpeakerError, Credentials | HttpClient.HttpClient>;
export type DescribeSpeakerEnrollmentJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the specified speaker enrollment job.
 */
export declare const describeSpeakerEnrollmentJob: API.OperationMethod<DescribeSpeakerEnrollmentJobRequest, DescribeSpeakerEnrollmentJobResponse, DescribeSpeakerEnrollmentJobError, Credentials | HttpClient.HttpClient>;
export type DescribeWatchlistError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the specified watchlist.
 */
export declare const describeWatchlist: API.OperationMethod<DescribeWatchlistRequest, DescribeWatchlistResponse, DescribeWatchlistError, Credentials | HttpClient.HttpClient>;
export type DisassociateFraudsterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates the fraudsters from the watchlist specified. Voice ID always expects a
 * fraudster to be a part of at least one watchlist. If
 * you try to disassociate a fraudster from its only watchlist, a `ValidationException` is thrown.
 */
export declare const disassociateFraudster: API.OperationMethod<DisassociateFraudsterRequest, DisassociateFraudsterResponse, DisassociateFraudsterError, Credentials | HttpClient.HttpClient>;
export type EvaluateSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Evaluates a specified session based on audio data accumulated during a streaming
 * Amazon Connect Voice ID call.
 */
export declare const evaluateSession: API.OperationMethod<EvaluateSessionRequest, EvaluateSessionResponse, EvaluateSessionError, Credentials | HttpClient.HttpClient>;
export type ListDomainsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the domains in the Amazon Web Services account.
 */
export declare const listDomains: API.PaginatedOperationMethod<ListDomainsRequest, ListDomainsResponse, ListDomainsError, Credentials | HttpClient.HttpClient, DomainSummary>;
export type ListFraudsterRegistrationJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the fraudster registration jobs in the domain with the given
 * `JobStatus`. If `JobStatus` is not provided, this lists all
 * fraudster registration jobs in the given domain.
 */
export declare const listFraudsterRegistrationJobs: API.PaginatedOperationMethod<ListFraudsterRegistrationJobsRequest, ListFraudsterRegistrationJobsResponse, ListFraudsterRegistrationJobsError, Credentials | HttpClient.HttpClient, FraudsterRegistrationJobSummary>;
export type ListFraudstersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all fraudsters in a specified watchlist or domain.
 */
export declare const listFraudsters: API.PaginatedOperationMethod<ListFraudstersRequest, ListFraudstersResponse, ListFraudstersError, Credentials | HttpClient.HttpClient, FraudsterSummary>;
export type ListSpeakerEnrollmentJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the speaker enrollment jobs in the domain with the specified
 * `JobStatus`. If `JobStatus` is not provided, this lists all
 * jobs with all possible speaker enrollment job statuses.
 */
export declare const listSpeakerEnrollmentJobs: API.PaginatedOperationMethod<ListSpeakerEnrollmentJobsRequest, ListSpeakerEnrollmentJobsResponse, ListSpeakerEnrollmentJobsError, Credentials | HttpClient.HttpClient, SpeakerEnrollmentJobSummary>;
export type ListSpeakersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all speakers in a specified domain.
 */
export declare const listSpeakers: API.PaginatedOperationMethod<ListSpeakersRequest, ListSpeakersResponse, ListSpeakersError, Credentials | HttpClient.HttpClient, SpeakerSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all tags associated with a specified Voice ID resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWatchlistsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all watchlists in a specified domain.
 */
export declare const listWatchlists: API.PaginatedOperationMethod<ListWatchlistsRequest, ListWatchlistsResponse, ListWatchlistsError, Credentials | HttpClient.HttpClient, WatchlistSummary>;
export type OptOutSpeakerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Opts out a speaker from Voice ID. A speaker can be opted out regardless of whether or
 * not they already exist in Voice ID. If they don't yet exist, a new speaker is created
 * in an opted out state. If they already exist, their existing status is overridden and
 * they are opted out. Enrollment and evaluation authentication requests are rejected for
 * opted out speakers, and opted out speakers have no voice embeddings stored in
 * Voice ID.
 */
export declare const optOutSpeaker: API.OperationMethod<OptOutSpeakerRequest, OptOutSpeakerResponse, OptOutSpeakerError, Credentials | HttpClient.HttpClient>;
export type StartFraudsterRegistrationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a new batch fraudster registration job using provided details.
 */
export declare const startFraudsterRegistrationJob: API.OperationMethod<StartFraudsterRegistrationJobRequest, StartFraudsterRegistrationJobResponse, StartFraudsterRegistrationJobError, Credentials | HttpClient.HttpClient>;
export type StartSpeakerEnrollmentJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a new batch speaker enrollment job using specified details.
 */
export declare const startSpeakerEnrollmentJob: API.OperationMethod<StartSpeakerEnrollmentJobRequest, StartSpeakerEnrollmentJobResponse, StartSpeakerEnrollmentJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Tags a Voice ID resource with the provided list of tags.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes specified tags from a specified Amazon Connect Voice ID resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified domain. This API has clobber behavior, and clears and replaces
 * all attributes. If an optional field, such as 'Description' is not provided, it is
 * removed from the domain.
 */
export declare const updateDomain: API.OperationMethod<UpdateDomainRequest, UpdateDomainResponse, UpdateDomainError, Credentials | HttpClient.HttpClient>;
export type UpdateWatchlistError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified watchlist. Every domain has a default watchlist which cannot be updated.
 */
export declare const updateWatchlist: API.OperationMethod<UpdateWatchlistRequest, UpdateWatchlistResponse, UpdateWatchlistError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=voice-id.d.ts.map