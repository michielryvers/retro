import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly RequestId: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly ResourceType: any;
    readonly ResourceId: any;
    readonly Reason: any;
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly RequestId: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type IdentityStoreId = string;
export type GroupDisplayName = string | redacted.Redacted<string>;
export type SensitiveStringType = string | redacted.Redacted<string>;
export interface CreateGroupRequest {
    IdentityStoreId: string;
    DisplayName?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
}
export type ResourceId = string;
export type ResourceArn = string;
export type ResourceRevision = string;
export interface CreateGroupResponse {
    IdentityStoreId: string;
    GroupId: string;
    GroupArn: string;
    Revision: string;
}
export type MemberId = {
    UserId: string;
};
export interface CreateGroupMembershipRequest {
    IdentityStoreId: string;
    GroupId: string;
    MemberId: MemberId;
}
export interface CreateGroupMembershipResponse {
    IdentityStoreId: string;
    MembershipId: string;
    MembershipArn: string;
}
export type UserName = string | redacted.Redacted<string>;
export interface Name {
    Formatted?: string | redacted.Redacted<string>;
    FamilyName?: string | redacted.Redacted<string>;
    GivenName?: string | redacted.Redacted<string>;
    MiddleName?: string | redacted.Redacted<string>;
    HonorificPrefix?: string | redacted.Redacted<string>;
    HonorificSuffix?: string | redacted.Redacted<string>;
}
export interface Email {
    Value?: string | redacted.Redacted<string>;
    Type?: string | redacted.Redacted<string>;
    Primary?: boolean;
}
export type Emails = Email[];
export interface Address {
    StreetAddress?: string | redacted.Redacted<string>;
    Locality?: string | redacted.Redacted<string>;
    Region?: string | redacted.Redacted<string>;
    PostalCode?: string | redacted.Redacted<string>;
    Country?: string | redacted.Redacted<string>;
    Formatted?: string | redacted.Redacted<string>;
    Type?: string | redacted.Redacted<string>;
    Primary?: boolean;
}
export type Addresses = Address[];
export interface PhoneNumber {
    Value?: string | redacted.Redacted<string>;
    Type?: string | redacted.Redacted<string>;
    Primary?: boolean;
}
export type PhoneNumbers = PhoneNumber[];
export interface Photo {
    Value: string | redacted.Redacted<string>;
    Type?: string | redacted.Redacted<string>;
    Display?: string | redacted.Redacted<string>;
    Primary?: boolean;
}
export type Photos = Photo[];
export interface Role {
    Value?: string | redacted.Redacted<string>;
    Type?: string | redacted.Redacted<string>;
    Primary?: boolean;
}
export type Roles = Role[];
export type ExtensionName = string;
export type AttributeValue = unknown;
export type Extensions = {
    [key: string]: any | undefined;
};
export interface CreateUserRequest {
    IdentityStoreId: string;
    UserName?: string | redacted.Redacted<string>;
    Name?: Name;
    DisplayName?: string | redacted.Redacted<string>;
    NickName?: string | redacted.Redacted<string>;
    ProfileUrl?: string | redacted.Redacted<string>;
    Emails?: Email[];
    Addresses?: Address[];
    PhoneNumbers?: PhoneNumber[];
    UserType?: string | redacted.Redacted<string>;
    Title?: string | redacted.Redacted<string>;
    PreferredLanguage?: string | redacted.Redacted<string>;
    Locale?: string | redacted.Redacted<string>;
    Timezone?: string | redacted.Redacted<string>;
    Photos?: Photo[];
    Website?: string | redacted.Redacted<string>;
    Birthdate?: string | redacted.Redacted<string>;
    Roles?: Role[];
    Extensions?: {
        [key: string]: any | undefined;
    };
}
export interface CreateUserResponse {
    IdentityStoreId: string;
    UserId: string;
    UserArn: string;
    Revision: string;
}
export interface DeleteGroupRequest {
    IdentityStoreId: string;
    GroupId: string;
    Revision?: string;
}
export interface DeleteGroupResponse {
}
export interface DeleteGroupMembershipRequest {
    IdentityStoreId: string;
    MembershipId: string;
}
export interface DeleteGroupMembershipResponse {
}
export interface DeleteUserRequest {
    IdentityStoreId: string;
    UserId: string;
    Revision?: string;
}
export interface DeleteUserResponse {
}
export interface DescribeGroupRequest {
    IdentityStoreId: string;
    GroupId: string;
}
export type ExternalIdIssuer = string | redacted.Redacted<string>;
export type ExternalIdIdentifier = string | redacted.Redacted<string>;
export interface ExternalId {
    Issuer: string | redacted.Redacted<string>;
    Id: string | redacted.Redacted<string>;
}
export type ExternalIds = ExternalId[];
export type StringType = string;
export interface DescribeGroupResponse {
    IdentityStoreId: string;
    GroupId: string;
    GroupArn: string;
    Revision: string;
    DisplayName?: string | redacted.Redacted<string>;
    ExternalIds?: ExternalId[];
    Description?: string | redacted.Redacted<string>;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    CreatedBy?: string;
    UpdatedBy?: string;
}
export interface DescribeGroupMembershipRequest {
    IdentityStoreId: string;
    MembershipId: string;
}
export interface DescribeGroupMembershipResponse {
    IdentityStoreId: string;
    MembershipId: string;
    MembershipArn: string;
    GroupId: string;
    MemberId: MemberId;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    CreatedBy?: string;
    UpdatedBy?: string;
}
export interface DescribeIdentityStoreRequest {
    IdentityStoreId: string;
}
export type IdentityStoreArn = string;
export type VpcIdType = string;
export type VpcIdList = string[];
export type IpCidrType = string;
export type IpCidrList = string[];
export interface NetworkConfigurationDetails {
    VpceAccessRequired: boolean;
    ApiRestrictSourceVpcs?: string[];
    ApiAllowSourceIps?: string[];
    ScimAllowSourceIps?: string[];
}
export interface DescribeIdentityStoreResponse {
    IdentityStoreId: string;
    IdentityStoreArn: string;
    NetworkConfiguration?: NetworkConfigurationDetails;
}
export type ExtensionNames = string[];
export interface DescribeUserRequest {
    IdentityStoreId: string;
    UserId: string;
    Extensions?: string[];
}
export type UserStatus = "ENABLED" | "DISABLED" | (string & {});
export interface DescribeUserResponse {
    IdentityStoreId: string;
    UserId: string;
    UserArn: string;
    Revision: string;
    UserName?: string | redacted.Redacted<string>;
    ExternalIds?: ExternalId[];
    Name?: Name;
    DisplayName?: string | redacted.Redacted<string>;
    NickName?: string | redacted.Redacted<string>;
    ProfileUrl?: string | redacted.Redacted<string>;
    Emails?: Email[];
    Addresses?: Address[];
    PhoneNumbers?: PhoneNumber[];
    UserType?: string | redacted.Redacted<string>;
    Title?: string | redacted.Redacted<string>;
    PreferredLanguage?: string | redacted.Redacted<string>;
    Locale?: string | redacted.Redacted<string>;
    Timezone?: string | redacted.Redacted<string>;
    UserStatus?: UserStatus;
    Photos?: Photo[];
    Website?: string | redacted.Redacted<string>;
    Birthdate?: string | redacted.Redacted<string>;
    Roles?: Role[];
    CreatedAt?: Date;
    CreatedBy?: string;
    UpdatedAt?: Date;
    UpdatedBy?: string;
    Extensions?: {
        [key: string]: any | undefined;
    };
}
export type AttributePath = string;
export interface UniqueAttribute {
    AttributePath: string;
    AttributeValue: any;
}
export type AlternateIdentifier = {
    ExternalId: ExternalId;
    UniqueAttribute?: never;
} | {
    ExternalId?: never;
    UniqueAttribute: UniqueAttribute;
};
export interface GetGroupIdRequest {
    IdentityStoreId: string;
    AlternateIdentifier: AlternateIdentifier;
}
export interface GetGroupIdResponse {
    IdentityStoreId: string;
    GroupId: string;
    GroupArn: string;
}
export interface GetGroupMembershipIdRequest {
    IdentityStoreId: string;
    GroupId: string;
    MemberId: MemberId;
}
export interface GetGroupMembershipIdResponse {
    IdentityStoreId: string;
    MembershipId: string;
    MembershipArn: string;
}
export interface GetUserIdRequest {
    IdentityStoreId: string;
    AlternateIdentifier: AlternateIdentifier;
}
export interface GetUserIdResponse {
    IdentityStoreId: string;
    UserId: string;
    UserArn: string;
}
export type GroupIds = string[];
export interface IsMemberInGroupsRequest {
    IdentityStoreId: string;
    MemberId: MemberId;
    GroupIds: string[];
}
export interface GroupMembershipExistenceResult {
    GroupId?: string;
    MemberId?: MemberId;
    MembershipExists?: boolean;
}
export type GroupMembershipExistenceResults = GroupMembershipExistenceResult[];
export interface IsMemberInGroupsResponse {
    Results: GroupMembershipExistenceResult[];
}
export type MaxResults = number;
export type NextToken = string;
export interface ListGroupMembershipsRequest {
    IdentityStoreId: string;
    GroupId: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface GroupMembership {
    IdentityStoreId: string;
    MembershipId: string;
    MembershipArn: string;
    GroupId?: string;
    MemberId?: MemberId;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    CreatedBy?: string;
    UpdatedBy?: string;
}
export type GroupMemberships = GroupMembership[];
export interface ListGroupMembershipsResponse {
    GroupMemberships: GroupMembership[];
    NextToken?: string;
}
export interface ListGroupMembershipsForMemberRequest {
    IdentityStoreId: string;
    MemberId: MemberId;
    MaxResults?: number;
    NextToken?: string;
}
export interface ListGroupMembershipsForMemberResponse {
    GroupMemberships: GroupMembership[];
    NextToken?: string;
}
export interface Filter {
    AttributePath: string;
    AttributeValue: string | redacted.Redacted<string>;
}
export type Filters = Filter[];
export interface ListGroupsRequest {
    IdentityStoreId: string;
    MaxResults?: number;
    NextToken?: string;
    Filters?: Filter[];
}
export interface Group {
    IdentityStoreId: string;
    GroupId: string;
    GroupArn: string;
    Revision: string;
    DisplayName?: string | redacted.Redacted<string>;
    ExternalIds?: ExternalId[];
    Description?: string | redacted.Redacted<string>;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    CreatedBy?: string;
    UpdatedBy?: string;
}
export type Groups = Group[];
export interface ListGroupsResponse {
    Groups: Group[];
    NextToken?: string;
}
export interface ListIdentityStoresRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface IdentityStore {
    IdentityStoreId: string;
    IdentityStoreArn: string;
}
export type IdentityStores = IdentityStore[];
export interface ListIdentityStoresResponse {
    IdentityStores: IdentityStore[];
    NextToken?: string;
}
export interface ListUsersRequest {
    IdentityStoreId: string;
    Extensions?: string[];
    MaxResults?: number;
    NextToken?: string;
    Filters?: Filter[];
}
export interface User {
    IdentityStoreId: string;
    UserId: string;
    UserArn: string;
    Revision: string;
    UserName?: string | redacted.Redacted<string>;
    ExternalIds?: ExternalId[];
    Name?: Name;
    DisplayName?: string | redacted.Redacted<string>;
    NickName?: string | redacted.Redacted<string>;
    ProfileUrl?: string | redacted.Redacted<string>;
    Emails?: Email[];
    Addresses?: Address[];
    PhoneNumbers?: PhoneNumber[];
    UserType?: string | redacted.Redacted<string>;
    Title?: string | redacted.Redacted<string>;
    PreferredLanguage?: string | redacted.Redacted<string>;
    Locale?: string | redacted.Redacted<string>;
    Timezone?: string | redacted.Redacted<string>;
    UserStatus?: UserStatus;
    Photos?: Photo[];
    Website?: string | redacted.Redacted<string>;
    Birthdate?: string | redacted.Redacted<string>;
    Roles?: Role[];
    CreatedAt?: Date;
    CreatedBy?: string;
    UpdatedAt?: Date;
    UpdatedBy?: string;
    Extensions?: {
        [key: string]: any | undefined;
    };
}
export type Users = User[];
export interface ListUsersResponse {
    Users: User[];
    NextToken?: string;
}
export interface AttributeOperation {
    AttributePath: string;
    AttributeValue?: any;
}
export type AttributeOperations = AttributeOperation[];
export interface UpdateGroupRequest {
    IdentityStoreId: string;
    GroupId: string;
    Operations: AttributeOperation[];
    Revision?: string;
}
export interface UpdateGroupResponse {
    IdentityStoreId: string;
    GroupId: string;
    GroupArn: string;
    Revision: string;
}
export interface NetworkConfiguration {
    VpceAccessRequired: boolean;
    ApiRestrictSourceVpcs?: string[];
    ApiAllowSourceIps?: string[];
    ScimAllowSourceIps?: string[];
}
export interface UpdateIdentityStoreRequest {
    IdentityStoreId: string;
    NetworkConfiguration?: NetworkConfiguration;
}
export interface UpdateIdentityStoreResponse {
    IdentityStoreId: string;
    IdentityStoreArn: string;
}
export interface UpdateUserRequest {
    IdentityStoreId: string;
    UserId: string;
    Operations: AttributeOperation[];
    Revision?: string;
}
export interface UpdateUserResponse {
    IdentityStoreId: string;
    UserId: string;
    UserArn: string;
    Revision: string;
}
export type ExceptionMessage = string;
export type RequestId = string;
export type ConflictExceptionReason = "UNIQUENESS_CONSTRAINT_VIOLATION" | "CONCURRENT_MODIFICATION" | (string & {});
export type ResourceType = "GROUP" | "USER" | "IDENTITY_STORE" | "GROUP_MEMBERSHIP" | "RESOURCE_POLICY" | (string & {});
export type ResourceNotFoundExceptionReason = "KMS_KEY_NOT_FOUND" | (string & {});
export type ValidationExceptionReason = "KMS_INVALID_ARN" | "KMS_INVALID_KEY_USAGE" | "KMS_INVALID_STATE" | "KMS_DISABLED" | (string & {});
export type CreateGroupError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a group within the specified identity store.
 */
export declare const createGroup: API.OperationMethod<CreateGroupRequest, CreateGroupResponse, CreateGroupError, Credentials | HttpClient.HttpClient>;
export type CreateGroupMembershipError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a relationship between a member and a group. The following identifiers must be specified: `GroupId`, `IdentityStoreId`, and `MemberId`.
 */
export declare const createGroupMembership: API.OperationMethod<CreateGroupMembershipRequest, CreateGroupMembershipResponse, CreateGroupMembershipError, Credentials | HttpClient.HttpClient>;
export type CreateUserError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a user within the specified identity store.
 */
export declare const createUser: API.OperationMethod<CreateUserRequest, CreateUserResponse, CreateUserError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Delete a group within an identity store given `GroupId`.
 */
export declare const deleteGroup: API.OperationMethod<DeleteGroupRequest, DeleteGroupResponse, DeleteGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupMembershipError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Delete a membership within a group given `MembershipId`.
 */
export declare const deleteGroupMembership: API.OperationMethod<DeleteGroupMembershipRequest, DeleteGroupMembershipResponse, DeleteGroupMembershipError, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a user within an identity store given `UserId`.
 */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest, DeleteUserResponse, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DescribeGroupError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the group metadata and attributes from `GroupId` in an identity store.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const describeGroup: API.OperationMethod<DescribeGroupRequest, DescribeGroupResponse, DescribeGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeGroupMembershipError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves membership metadata and attributes from `MembershipId` in an identity store.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const describeGroupMembership: API.OperationMethod<DescribeGroupMembershipRequest, DescribeGroupMembershipResponse, DescribeGroupMembershipError, Credentials | HttpClient.HttpClient>;
export type DescribeIdentityStoreError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves details about the specified identity store, including its Amazon Resource Name (ARN) and network configuration.
 */
export declare const describeIdentityStore: API.OperationMethod<DescribeIdentityStoreRequest, DescribeIdentityStoreResponse, DescribeIdentityStoreError, Credentials | HttpClient.HttpClient>;
export type DescribeUserError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the user metadata and attributes from the `UserId` in an identity store.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const describeUser: API.OperationMethod<DescribeUserRequest, DescribeUserResponse, DescribeUserError, Credentials | HttpClient.HttpClient>;
export type GetGroupIdError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves `GroupId` in an identity store.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const getGroupId: API.OperationMethod<GetGroupIdRequest, GetGroupIdResponse, GetGroupIdError, Credentials | HttpClient.HttpClient>;
export type GetGroupMembershipIdError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the `MembershipId` in an identity store.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const getGroupMembershipId: API.OperationMethod<GetGroupMembershipIdRequest, GetGroupMembershipIdResponse, GetGroupMembershipIdError, Credentials | HttpClient.HttpClient>;
export type GetUserIdError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the `UserId` in an identity store.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const getUserId: API.OperationMethod<GetUserIdRequest, GetUserIdResponse, GetUserIdError, Credentials | HttpClient.HttpClient>;
export type IsMemberInGroupsError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Checks the user's membership in all requested groups and returns if the member exists in all queried groups.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const isMemberInGroups: API.OperationMethod<IsMemberInGroupsRequest, IsMemberInGroupsResponse, IsMemberInGroupsError, Credentials | HttpClient.HttpClient>;
export type ListGroupMembershipsError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * For the specified group in the specified identity store, returns the list of all ` GroupMembership` objects and returns results in paginated form.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const listGroupMemberships: API.PaginatedOperationMethod<ListGroupMembershipsRequest, ListGroupMembershipsResponse, ListGroupMembershipsError, Credentials | HttpClient.HttpClient, GroupMembership>;
export type ListGroupMembershipsForMemberError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * For the specified member in the specified identity store, returns the list of all ` GroupMembership` objects and returns results in paginated form.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const listGroupMembershipsForMember: API.PaginatedOperationMethod<ListGroupMembershipsForMemberRequest, ListGroupMembershipsForMemberResponse, ListGroupMembershipsForMemberError, Credentials | HttpClient.HttpClient, GroupMembership>;
export type ListGroupsError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all groups in the identity store. Returns a paginated list of complete `Group` objects. Filtering for a `Group` by the `DisplayName` attribute is deprecated. Instead, use the `GetGroupId` API action.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const listGroups: API.PaginatedOperationMethod<ListGroupsRequest, ListGroupsResponse, ListGroupsError, Credentials | HttpClient.HttpClient, Group>;
export type ListIdentityStoresError = ValidationException | CommonErrors;
/**
 * Lists the identity stores that you have access to. This operation returns only the identity store ID and Amazon Resource Name (ARN) of each identity store. To obtain additional information about an identity store, call `DescribeIdentityStore`.
 *
 * This operation returns results in paginated form. Use the `NextToken` parameter to retrieve additional pages of results.
 */
export declare const listIdentityStores: API.PaginatedOperationMethod<ListIdentityStoresRequest, ListIdentityStoresResponse, ListIdentityStoresError, Credentials | HttpClient.HttpClient, IdentityStore>;
export type ListUsersError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all users in the identity store. Returns a paginated list of complete `User` objects. Filtering for a `User` by the `UserName` attribute is deprecated. Instead, use the `GetUserId` API action.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const listUsers: API.PaginatedOperationMethod<ListUsersRequest, ListUsersResponse, ListUsersError, Credentials | HttpClient.HttpClient, User>;
export type UpdateGroupError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Updates the specified group metadata and attributes in the specified identity store.
 */
export declare const updateGroup: API.OperationMethod<UpdateGroupRequest, UpdateGroupResponse, UpdateGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateIdentityStoreError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the configuration of the specified identity store, including its network configuration.
 */
export declare const updateIdentityStore: API.OperationMethod<UpdateIdentityStoreRequest, UpdateIdentityStoreResponse, UpdateIdentityStoreError, Credentials | HttpClient.HttpClient>;
export type UpdateUserError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Updates the specified user metadata and attributes in the specified identity store.
 */
export declare const updateUser: API.OperationMethod<UpdateUserRequest, UpdateUserResponse, UpdateUserError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=identitystore.d.ts.map