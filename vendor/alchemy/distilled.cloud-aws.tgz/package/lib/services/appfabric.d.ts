import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Identifier = string;
export type UUID = string;
export type TaskIdList = string[];
export interface BatchGetUserAccessTasksRequest {
    appBundleIdentifier: string;
    taskIdList: string[];
}
export type String255 = string;
export type TenantIdentifier = string;
export type String2048 = string;
export type ResultStatus = "IN_PROGRESS" | "COMPLETED" | "FAILED" | "EXPIRED" | (string & {});
export type Email = string | redacted.Redacted<string>;
export type SensitiveString2048 = string | redacted.Redacted<string>;
export interface TaskError {
    errorCode?: string;
    errorMessage?: string;
}
export interface UserAccessResultItem {
    app?: string;
    tenantId?: string;
    tenantDisplayName?: string;
    taskId?: string;
    resultStatus?: ResultStatus;
    email?: string | redacted.Redacted<string>;
    userId?: string | redacted.Redacted<string>;
    userFullName?: string | redacted.Redacted<string>;
    userFirstName?: string | redacted.Redacted<string>;
    userLastName?: string | redacted.Redacted<string>;
    userStatus?: string;
    taskError?: TaskError;
}
export type UserAccessResultsList = UserAccessResultItem[];
export interface BatchGetUserAccessTasksResponse {
    userAccessResultsList?: UserAccessResultItem[];
}
export type RedirectUri = string;
export interface AuthRequest {
    redirectUri: string;
    code: string | redacted.Redacted<string>;
}
export interface ConnectAppAuthorizationRequest {
    appBundleIdentifier: string;
    appAuthorizationIdentifier: string;
    authRequest?: AuthRequest;
}
export type Arn = string;
export interface Tenant {
    tenantIdentifier: string;
    tenantDisplayName: string;
}
export type AppAuthorizationStatus = "PendingConnect" | "Connected" | "ConnectionValidationFailed" | "TokenAutoRotationFailed" | (string & {});
export interface AppAuthorizationSummary {
    appAuthorizationArn: string;
    appBundleArn: string;
    app: string;
    tenant: Tenant;
    status: AppAuthorizationStatus;
    updatedAt: Date;
}
export interface ConnectAppAuthorizationResponse {
    appAuthorizationSummary: AppAuthorizationSummary;
}
export interface Oauth2Credential {
    clientId: string;
    clientSecret: string | redacted.Redacted<string>;
}
export interface ApiKeyCredential {
    apiKey: string | redacted.Redacted<string>;
}
export type Credential = {
    oauth2Credential: Oauth2Credential;
    apiKeyCredential?: never;
} | {
    oauth2Credential?: never;
    apiKeyCredential: ApiKeyCredential;
};
export type AuthType = "oauth2" | "apiKey" | (string & {});
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagList = Tag[];
export interface CreateAppAuthorizationRequest {
    appBundleIdentifier: string;
    app: string;
    credential: Credential;
    tenant: Tenant;
    authType: AuthType;
    clientToken?: string;
    tags?: Tag[];
}
export type Persona = "admin" | "endUser" | (string & {});
export interface AppAuthorization {
    appAuthorizationArn: string;
    appBundleArn: string;
    app: string;
    tenant: Tenant;
    authType: AuthType;
    status: AppAuthorizationStatus;
    createdAt: Date;
    updatedAt: Date;
    persona?: Persona;
    authUrl?: string;
}
export interface CreateAppAuthorizationResponse {
    appAuthorization: AppAuthorization;
}
export interface CreateAppBundleRequest {
    clientToken?: string;
    customerManagedKeyIdentifier?: string;
    tags?: Tag[];
}
export interface AppBundle {
    arn: string;
    customerManagedKeyArn?: string;
}
export interface CreateAppBundleResponse {
    appBundle: AppBundle;
}
export type IngestionType = "auditLog" | (string & {});
export interface CreateIngestionRequest {
    appBundleIdentifier: string;
    app: string;
    tenantId: string;
    ingestionType: IngestionType;
    clientToken?: string;
    tags?: Tag[];
}
export type IngestionState = "enabled" | "disabled" | (string & {});
export interface Ingestion {
    arn: string;
    appBundleArn: string;
    app: string;
    tenantId: string;
    createdAt: Date;
    updatedAt: Date;
    state: IngestionState;
    ingestionType: IngestionType;
}
export interface CreateIngestionResponse {
    ingestion: Ingestion;
}
export type Schema = "ocsf" | "raw" | (string & {});
export type Format = "json" | "parquet" | (string & {});
export interface AuditLogProcessingConfiguration {
    schema: Schema;
    format: Format;
}
export type ProcessingConfiguration = {
    auditLog: AuditLogProcessingConfiguration;
};
export type String63 = string;
export type String120 = string;
export interface S3Bucket {
    bucketName: string;
    prefix?: string;
}
export type String64 = string;
export interface FirehoseStream {
    streamName: string;
}
export type Destination = {
    s3Bucket: S3Bucket;
    firehoseStream?: never;
} | {
    s3Bucket?: never;
    firehoseStream: FirehoseStream;
};
export interface AuditLogDestinationConfiguration {
    destination: Destination;
}
export type DestinationConfiguration = {
    auditLog: AuditLogDestinationConfiguration;
};
export interface CreateIngestionDestinationRequest {
    appBundleIdentifier: string;
    ingestionIdentifier: string;
    processingConfiguration: ProcessingConfiguration;
    destinationConfiguration: DestinationConfiguration;
    clientToken?: string;
    tags?: Tag[];
}
export type IngestionDestinationStatus = "Active" | "Failed" | (string & {});
export interface IngestionDestination {
    arn: string;
    ingestionArn: string;
    processingConfiguration: ProcessingConfiguration;
    destinationConfiguration: DestinationConfiguration;
    status?: IngestionDestinationStatus;
    statusReason?: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export interface CreateIngestionDestinationResponse {
    ingestionDestination: IngestionDestination;
}
export interface DeleteAppAuthorizationRequest {
    appBundleIdentifier: string;
    appAuthorizationIdentifier: string;
}
export interface DeleteAppAuthorizationResponse {
}
export interface DeleteAppBundleRequest {
    appBundleIdentifier: string;
}
export interface DeleteAppBundleResponse {
}
export interface DeleteIngestionRequest {
    appBundleIdentifier: string;
    ingestionIdentifier: string;
}
export interface DeleteIngestionResponse {
}
export interface DeleteIngestionDestinationRequest {
    appBundleIdentifier: string;
    ingestionIdentifier: string;
    ingestionDestinationIdentifier: string;
}
export interface DeleteIngestionDestinationResponse {
}
export interface GetAppAuthorizationRequest {
    appBundleIdentifier: string;
    appAuthorizationIdentifier: string;
}
export interface GetAppAuthorizationResponse {
    appAuthorization: AppAuthorization;
}
export interface GetAppBundleRequest {
    appBundleIdentifier: string;
}
export interface GetAppBundleResponse {
    appBundle: AppBundle;
}
export interface GetIngestionRequest {
    appBundleIdentifier: string;
    ingestionIdentifier: string;
}
export interface GetIngestionResponse {
    ingestion: Ingestion;
}
export interface GetIngestionDestinationRequest {
    appBundleIdentifier: string;
    ingestionIdentifier: string;
    ingestionDestinationIdentifier: string;
}
export interface GetIngestionDestinationResponse {
    ingestionDestination: IngestionDestination;
}
export type MaxResults = number;
export interface ListAppAuthorizationsRequest {
    appBundleIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export type AppAuthorizationSummaryList = AppAuthorizationSummary[];
export interface ListAppAuthorizationsResponse {
    appAuthorizationSummaryList: AppAuthorizationSummary[];
    nextToken?: string;
}
export interface ListAppBundlesRequest {
    maxResults?: number;
    nextToken?: string;
}
export interface AppBundleSummary {
    arn: string;
}
export type AppBundleSummaryList = AppBundleSummary[];
export interface ListAppBundlesResponse {
    appBundleSummaryList: AppBundleSummary[];
    nextToken?: string;
}
export interface ListIngestionDestinationsRequest {
    appBundleIdentifier: string;
    ingestionIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export interface IngestionDestinationSummary {
    arn: string;
}
export type IngestionDestinationList = IngestionDestinationSummary[];
export interface ListIngestionDestinationsResponse {
    ingestionDestinations: IngestionDestinationSummary[];
    nextToken?: string;
}
export interface ListIngestionsRequest {
    appBundleIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export interface IngestionSummary {
    arn: string;
    app: string;
    tenantId: string;
    state: IngestionState;
}
export type IngestionList = IngestionSummary[];
export interface ListIngestionsResponse {
    ingestions: IngestionSummary[];
    nextToken?: string;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[];
}
export interface StartIngestionRequest {
    ingestionIdentifier: string;
    appBundleIdentifier: string;
}
export interface StartIngestionResponse {
}
export interface StartUserAccessTasksRequest {
    appBundleIdentifier: string;
    email: string | redacted.Redacted<string>;
}
export interface UserAccessTaskItem {
    app: string;
    tenantId: string;
    taskId?: string;
    error?: TaskError;
}
export type UserAccessTasksList = UserAccessTaskItem[];
export interface StartUserAccessTasksResponse {
    userAccessTasksList?: UserAccessTaskItem[];
}
export interface StopIngestionRequest {
    ingestionIdentifier: string;
    appBundleIdentifier: string;
}
export interface StopIngestionResponse {
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAppAuthorizationRequest {
    appBundleIdentifier: string;
    appAuthorizationIdentifier: string;
    credential?: Credential;
    tenant?: Tenant;
}
export interface UpdateAppAuthorizationResponse {
    appAuthorization: AppAuthorization;
}
export interface UpdateIngestionDestinationRequest {
    appBundleIdentifier: string;
    ingestionIdentifier: string;
    ingestionDestinationIdentifier: string;
    destinationConfiguration: DestinationConfiguration;
}
export interface UpdateIngestionDestinationResponse {
    ingestionDestination: IngestionDestination;
}
export type ValidationExceptionReason = "unknownOperation" | "cannotParse" | "fieldValidationFailed" | "other" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type BatchGetUserAccessTasksError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets user access details in a batch request.
 *
 * This action polls data from the tasks that are kicked off by the
 * `StartUserAccessTasks` action.
 */
export declare const batchGetUserAccessTasks: API.OperationMethod<BatchGetUserAccessTasksRequest, BatchGetUserAccessTasksResponse, BatchGetUserAccessTasksError, Credentials | HttpClient.HttpClient>;
export type ConnectAppAuthorizationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Establishes a connection between Amazon Web Services AppFabric and an application, which allows AppFabric to
 * call the APIs of the application.
 */
export declare const connectAppAuthorization: API.OperationMethod<ConnectAppAuthorizationRequest, ConnectAppAuthorizationResponse, ConnectAppAuthorizationError, Credentials | HttpClient.HttpClient>;
export type CreateAppAuthorizationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an app authorization within an app bundle, which allows AppFabric to connect to an
 * application.
 */
export declare const createAppAuthorization: API.OperationMethod<CreateAppAuthorizationRequest, CreateAppAuthorizationResponse, CreateAppAuthorizationError, Credentials | HttpClient.HttpClient>;
export type CreateAppBundleError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an app bundle to collect data from an application using AppFabric.
 */
export declare const createAppBundle: API.OperationMethod<CreateAppBundleRequest, CreateAppBundleResponse, CreateAppBundleError, Credentials | HttpClient.HttpClient>;
export type CreateIngestionError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a data ingestion for an application.
 */
export declare const createIngestion: API.OperationMethod<CreateIngestionRequest, CreateIngestionResponse, CreateIngestionError, Credentials | HttpClient.HttpClient>;
export type CreateIngestionDestinationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an ingestion destination, which specifies how an application's ingested data is
 * processed by Amazon Web Services AppFabric and where it's delivered.
 */
export declare const createIngestionDestination: API.OperationMethod<CreateIngestionDestinationRequest, CreateIngestionDestinationResponse, CreateIngestionDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteAppAuthorizationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an app authorization. You must delete the associated ingestion before you can
 * delete an app authorization.
 */
export declare const deleteAppAuthorization: API.OperationMethod<DeleteAppAuthorizationRequest, DeleteAppAuthorizationResponse, DeleteAppAuthorizationError, Credentials | HttpClient.HttpClient>;
export type DeleteAppBundleError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an app bundle. You must delete all associated app authorizations before you can
 * delete an app bundle.
 */
export declare const deleteAppBundle: API.OperationMethod<DeleteAppBundleRequest, DeleteAppBundleResponse, DeleteAppBundleError, Credentials | HttpClient.HttpClient>;
export type DeleteIngestionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an ingestion. You must stop (disable) the ingestion and you must delete all
 * associated ingestion destinations before you can delete an app ingestion.
 */
export declare const deleteIngestion: API.OperationMethod<DeleteIngestionRequest, DeleteIngestionResponse, DeleteIngestionError, Credentials | HttpClient.HttpClient>;
export type DeleteIngestionDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an ingestion destination.
 *
 * This deletes the association between an ingestion and it's destination. It doesn't
 * delete previously ingested data or the storage destination, such as the Amazon S3
 * bucket where the data is delivered. If the ingestion destination is deleted while the
 * associated ingestion is enabled, the ingestion will fail and is eventually disabled.
 */
export declare const deleteIngestionDestination: API.OperationMethod<DeleteIngestionDestinationRequest, DeleteIngestionDestinationResponse, DeleteIngestionDestinationError, Credentials | HttpClient.HttpClient>;
export type GetAppAuthorizationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about an app authorization.
 */
export declare const getAppAuthorization: API.OperationMethod<GetAppAuthorizationRequest, GetAppAuthorizationResponse, GetAppAuthorizationError, Credentials | HttpClient.HttpClient>;
export type GetAppBundleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about an app bundle.
 */
export declare const getAppBundle: API.OperationMethod<GetAppBundleRequest, GetAppBundleResponse, GetAppBundleError, Credentials | HttpClient.HttpClient>;
export type GetIngestionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about an ingestion.
 */
export declare const getIngestion: API.OperationMethod<GetIngestionRequest, GetIngestionResponse, GetIngestionError, Credentials | HttpClient.HttpClient>;
export type GetIngestionDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about an ingestion destination.
 */
export declare const getIngestionDestination: API.OperationMethod<GetIngestionDestinationRequest, GetIngestionDestinationResponse, GetIngestionDestinationError, Credentials | HttpClient.HttpClient>;
export type ListAppAuthorizationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all app authorizations configured for an app bundle.
 */
export declare const listAppAuthorizations: API.PaginatedOperationMethod<ListAppAuthorizationsRequest, ListAppAuthorizationsResponse, ListAppAuthorizationsError, Credentials | HttpClient.HttpClient, AppAuthorizationSummary>;
export type ListAppBundlesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of app bundles.
 */
export declare const listAppBundles: API.PaginatedOperationMethod<ListAppBundlesRequest, ListAppBundlesResponse, ListAppBundlesError, Credentials | HttpClient.HttpClient, AppBundleSummary>;
export type ListIngestionDestinationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all ingestion destinations configured for an ingestion.
 */
export declare const listIngestionDestinations: API.PaginatedOperationMethod<ListIngestionDestinationsRequest, ListIngestionDestinationsResponse, ListIngestionDestinationsError, Credentials | HttpClient.HttpClient, IngestionDestinationSummary>;
export type ListIngestionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all ingestions configured for an app bundle.
 */
export declare const listIngestions: API.PaginatedOperationMethod<ListIngestionsRequest, ListIngestionsResponse, ListIngestionsError, Credentials | HttpClient.HttpClient, IngestionSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartIngestionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts (enables) an ingestion, which collects data from an application.
 */
export declare const startIngestion: API.OperationMethod<StartIngestionRequest, StartIngestionResponse, StartIngestionError, Credentials | HttpClient.HttpClient>;
export type StartUserAccessTasksError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the tasks to search user access status for a specific email address.
 *
 * The tasks are stopped when the user access status data is found. The tasks are
 * terminated when the API calls to the application time out.
 */
export declare const startUserAccessTasks: API.OperationMethod<StartUserAccessTasksRequest, StartUserAccessTasksResponse, StartUserAccessTasksError, Credentials | HttpClient.HttpClient>;
export type StopIngestionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops (disables) an ingestion.
 */
export declare const stopIngestion: API.OperationMethod<StopIngestionRequest, StopIngestionResponse, StopIngestionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a tag or tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAppAuthorizationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an app authorization within an app bundle, which allows AppFabric to connect to an
 * application.
 *
 * If the app authorization was in a `connected` state, updating the app
 * authorization will set it back to a `PendingConnect` state.
 */
export declare const updateAppAuthorization: API.OperationMethod<UpdateAppAuthorizationRequest, UpdateAppAuthorizationResponse, UpdateAppAuthorizationError, Credentials | HttpClient.HttpClient>;
export type UpdateIngestionDestinationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an ingestion destination, which specifies how an application's ingested data is
 * processed by Amazon Web Services AppFabric and where it's delivered.
 */
export declare const updateIngestionDestination: API.OperationMethod<UpdateIngestionDestinationRequest, UpdateIngestionDestinationResponse, UpdateIngestionDestinationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=appfabric.d.ts.map