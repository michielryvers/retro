import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BillingViewHealthStatusException_base: S.TaggedErrorClass<"BillingViewHealthStatusException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BillingViewHealthStatusException extends /*@__PURE__*/ BillingViewHealthStatusException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type BillingViewArn = string;
export type BillingViewSourceViewsList = string[];
export interface AssociateSourceViewsRequest {
    arn: string;
    sourceViews: string[];
}
export interface AssociateSourceViewsResponse {
    arn: string;
}
export type BillingViewName = string | redacted.Redacted<string>;
export type BillingViewDescription = string | redacted.Redacted<string>;
export type Dimension = "LINKED_ACCOUNT" | (string & {});
export type Value = string;
export type Values = string[];
export interface DimensionValues {
    key: Dimension;
    values: string[];
}
export type TagKey = string;
export interface TagValues {
    key: string;
    values: string[];
}
export type CostCategoryName = string;
export interface CostCategoryValues {
    key: string;
    values: string[];
}
export interface TimeRange {
    beginDateInclusive?: Date;
    endDateInclusive?: Date;
}
export interface Expression {
    dimensions?: DimensionValues;
    tags?: TagValues;
    costCategories?: CostCategoryValues;
    timeRange?: TimeRange;
}
export type ClientToken = string;
export type ResourceTagKey = string;
export type ResourceTagValue = string;
export interface ResourceTag {
    key: string;
    value?: string;
}
export type ResourceTagList = ResourceTag[];
export interface CreateBillingViewRequest {
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    sourceViews: string[];
    dataFilterExpression?: Expression;
    clientToken?: string;
    resourceTags?: ResourceTag[];
}
export interface CreateBillingViewResponse {
    arn: string;
    createdAt?: Date;
}
export interface DeleteBillingViewRequest {
    arn: string;
    force?: boolean;
}
export interface DeleteBillingViewResponse {
    arn: string;
}
export interface DisassociateSourceViewsRequest {
    arn: string;
    sourceViews: string[];
}
export interface DisassociateSourceViewsResponse {
    arn: string;
}
export type PageToken = string;
export type BillingFeature = "RI_SHARING" | "RI_SHARING_HISTORY" | "CREDIT_SHARING" | "CREDIT_SHARING_HISTORY" | "CREDIT_LEVEL_SHARING" | "BILLING_ALERTS" | "CREDIT_PREFERENCE_OPTIONS" | (string & {});
export type BillingFeatures = BillingFeature[];
export type BillingFeatureFilterName = "PREFERENCE_KEY" | (string & {});
export type BillingFeatureFilterValue = string;
export type BillingFeatureFilterValues = string[];
export interface BillingFeatureFilter {
    name?: BillingFeatureFilterName;
    value?: string[];
}
export type BillingFeatureFilters = BillingFeatureFilter[];
export interface GetBillingPreferencesRequest {
    nextToken?: string;
    maxResults?: number;
    features: BillingFeature[];
    filters?: BillingFeatureFilter[];
}
export type PreferenceKey = string;
export type PreferenceValue = "ENABLED" | "DISABLED" | (string & {});
export type AccountName = string;
export type AccountId = string;
export type BillingYear = number;
export type Month = number;
export interface BillingPeriod {
    year: number;
    month: number;
}
export interface BillingPreferenceSummary {
    feature: BillingFeature;
    key: string;
    value: PreferenceValue;
    accountName?: string;
    accountId?: string;
    billingPeriod?: BillingPeriod;
}
export type BillingPreferences = BillingPreferenceSummary[];
export interface GetBillingPreferencesResponse {
    billingPreferences: BillingPreferenceSummary[];
    nextToken?: string;
}
export interface GetBillingViewRequest {
    arn: string;
}
export type BillingViewType = "PRIMARY" | "BILLING_GROUP" | "CUSTOM" | "BILLING_TRANSFER" | "BILLING_TRANSFER_SHOWBACK" | (string & {});
export type BillingViewStatus = "HEALTHY" | "UNHEALTHY" | "CREATING" | "UPDATING" | (string & {});
export type BillingViewStatusReason = "SOURCE_VIEW_UNHEALTHY" | "SOURCE_VIEW_UPDATING" | "SOURCE_VIEW_ACCESS_DENIED" | "SOURCE_VIEW_NOT_FOUND" | "CYCLIC_DEPENDENCY" | "SOURCE_VIEW_DEPTH_EXCEEDED" | "AGGREGATE_SOURCE" | "VIEW_OWNER_NOT_MANAGEMENT_ACCOUNT" | (string & {});
export type BillingViewStatusReasons = BillingViewStatusReason[];
export interface BillingViewHealthStatus {
    statusCode?: BillingViewStatus;
    statusReasons?: BillingViewStatusReason[];
}
export interface BillingViewElement {
    arn?: string;
    name?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    billingViewType?: BillingViewType;
    ownerAccountId?: string;
    sourceAccountId?: string;
    dataFilterExpression?: Expression;
    createdAt?: Date;
    updatedAt?: Date;
    derivedViewCount?: number;
    sourceViewCount?: number;
    viewDefinitionLastUpdatedAt?: Date;
    healthStatus?: BillingViewHealthStatus;
}
export interface GetBillingViewResponse {
    billingView: BillingViewElement;
}
export interface GetCreditAllocationHistoryRequest {
    accountId: string;
    creditId?: number;
    startDate: Date;
    endDate: Date;
    nextToken?: string;
    maxResults?: number;
}
export type CreditId = string;
export type CurrencyCode = string;
export type CurrencyAmount = string;
export interface Amount {
    currencyCode: string;
    currencyAmount: string;
}
export type BillingMonth = string;
export interface CreditAllocationHistoryEntry {
    creditId: string;
    creditAmount: Amount;
    description?: string;
    accountId: string;
    appliedServiceName: string;
    billingMonth: string;
    isEstimatedBill: boolean;
}
export type CreditAllocationHistoryList = CreditAllocationHistoryEntry[];
export type FailedMonthsList = string[];
export interface GetCreditAllocationHistoryResponse {
    creditAllocationHistoryList?: CreditAllocationHistoryEntry[];
    partialResults: boolean;
    failedMonths?: string[];
    nextToken?: string;
}
export interface GetCreditsRequest {
    accountId: string;
    startDate: Date;
    endDate?: Date;
    payerAccountFlag?: boolean;
}
export type ProductName = string;
export type ProductNames = string[];
export type ApplicationType = "BEFORE_CROSS_SERVICE_DISCOUNTS" | "AFTER_DISCOUNTS" | (string & {});
export type ShareableAccountIds = string[];
export type CreditSharingType = "DEFAULT" | "DISABLED" | "CUSTOM" | "COST_CATEGORY_RULE" | (string & {});
export type CreditStatus = "ENABLED" | "DISABLED" | (string & {});
export type PurchaseType = string;
export type PurchaseTypeApplications = string[];
export interface CreditData {
    creditId: string;
    accountId: string;
    creditType: string;
    initialAmount: Amount;
    remainingAmount: Amount;
    estimatedAmount?: Amount;
    applicableProductNames?: string[];
    description: string;
    startDate: Date;
    endDate?: Date;
    exhaustDate?: Date;
    applicationType?: ApplicationType;
    shareableAccounts?: string[];
    accountHasCreditSharingEnabled?: boolean;
    creditConsoleVisibility?: string;
    creditSharingType?: CreditSharingType;
    costCategoryArn?: string;
    ruleName?: string;
    creditStatus?: CreditStatus;
    purchaseTypeApplications?: string[];
}
export type CreditDataList = CreditData[];
export interface GetCreditsResponse {
    credits?: CreditData[];
}
export type EnterpriseSupportBillingMonth = string;
export interface GetEnterpriseSupportChargeSummaryRequest {
    billingMonth: string;
}
export interface PricingPlanTier {
    tierMinimum: string;
    tierMaximum?: string;
    baseCharge: string;
    additionalPercentageOfAggregateCharges: string;
    aggregateChargesAdjustment: string;
    incremental: boolean;
    increment?: string;
    incrementCharge?: string;
}
export type PricingPlanTierList = PricingPlanTier[];
export interface PricingPlan {
    pricingPlanId?: string;
    name?: string;
    description?: string;
    startDate?: Date;
    endDate?: Date;
    planDiscountPercent?: string;
    discountAppliesToMinimumCharge?: boolean;
    minimumCharge?: string;
    tiered?: string;
    tiers: PricingPlanTier[];
}
export interface GetEnterpriseSupportChargeSummaryResponse {
    payerAccountId: string;
    billingMonth: string;
    billingPeriodStartDate: Date;
    billingPeriodEndDate: Date;
    isEstimated: boolean;
    billDate: Date;
    supportCharge: string;
    totalSupportCharge: string;
    supportDiscount: string;
    totalSupportEligibleSpend: string;
    totalSupportEligibleUsageSpend: string;
    totalSupportEligibleReservedInstanceSpend: string;
    totalSupportEligibleSavingsPlanSpend: string;
    supportChargePercentage: string;
    supportEffectivePricingPlan: PricingPlan;
}
export interface GetEnterpriseSupportContractDetailsRequest {
    billingMonth: string;
}
export interface ContractAccount {
    accountId: string;
    isGdn: boolean;
}
export type ContractAccountList = ContractAccount[];
export interface ChargeAccount {
    accountId: string;
    chargePercentage: string;
}
export type ChargeAccountList = ChargeAccount[];
export interface AdditionalCharge {
    description: string;
    amount?: string;
    chargeType?: string;
}
export type AdditionalChargeList = AdditionalCharge[];
export type PricingPlanList = PricingPlan[];
export interface GetEnterpriseSupportContractDetailsResponse {
    isContractActive?: boolean;
    supportAllocationMethod: string;
    supportReservedInstanceAmortizationStartDate?: Date;
    supportReservedInstanceTreatmentMethod?: string;
    supportSavingsPlansAmortizationStartDate?: Date;
    supportSavingsPlansTreatmentMethod?: string;
    supportProrateStartDate?: Date;
    contractPayerAccountIds: ContractAccount[];
    chargedPayerAccountIds: ChargeAccount[];
    additionalSupportCharge?: AdditionalCharge[];
    additionalSupportEligibleUsageSpend?: AdditionalCharge[];
    pricingPlans: PricingPlan[];
}
export type ResourceArn = string;
export interface GetResourcePolicyRequest {
    resourceArn: string;
}
export type PolicyDocument = string;
export interface GetResourcePolicyResponse {
    resourceArn: string;
    policy?: string;
}
export interface ActiveTimeRange {
    activeAfterInclusive: Date;
    activeBeforeInclusive: Date;
}
export type BillingViewArnList = string[];
export type BillingViewTypeList = BillingViewType[];
export type SearchOption = "STARTS_WITH" | (string & {});
export type SearchValue = string;
export interface StringSearch {
    searchOption: SearchOption;
    searchValue: string;
}
export type StringSearches = StringSearch[];
export type BillingViewsMaxResults = number;
export interface ListBillingViewsRequest {
    activeTimeRange?: ActiveTimeRange;
    arns?: string[];
    billingViewTypes?: BillingViewType[];
    names?: StringSearch[];
    ownerAccountId?: string;
    sourceAccountId?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface BillingViewListElement {
    arn?: string;
    name?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    ownerAccountId?: string;
    sourceAccountId?: string;
    billingViewType?: BillingViewType;
    healthStatus?: BillingViewHealthStatus;
}
export type BillingViewList = BillingViewListElement[];
export interface ListBillingViewsResponse {
    billingViews: BillingViewListElement[];
    nextToken?: string;
}
export interface BillingViewSegmentTimeRange {
    beginDateInclusive?: Date;
    endDateExclusive?: Date;
}
export interface ListBillingViewSegmentsRequest {
    timeRange?: BillingViewSegmentTimeRange;
    arn?: string;
    maxResults?: number;
    nextToken?: string;
}
export type BillingDomain = "BILLABLE" | "PRO_FORMA" | (string & {});
export interface BillingViewSegmentsListElement {
    domain?: BillingDomain;
    timeRange?: BillingViewSegmentTimeRange;
    billingTransferAccountId?: string;
    managementAccountId?: string;
    billingGroupPrimaryAccountId?: string;
}
export type BillingViewSegmentsList = BillingViewSegmentsListElement[];
export interface ListBillingViewSegmentsResponse {
    items: BillingViewSegmentsListElement[];
    nextToken?: string;
}
export type BusinessSupportBillingMonth = string;
export interface ListBusinessSupportAccountChargesRequest {
    billingMonth: string;
    accountId?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface BusinessSupportTierCharge {
    tierDescription: string;
    tierRate: string;
    usageSlice: string;
    tierCharge: string;
    chargePeriodStartDate?: Date;
    chargePeriodEndDate?: Date;
}
export type BusinessSupportTierChargeList = BusinessSupportTierCharge[];
export interface BusinessSupportDiscount {
    discountAmount?: string;
    discountPercentage?: string;
    discountType?: string;
    discountSource?: string;
}
export interface BusinessSupportServiceSpend {
    contributingService: string;
    itemType: string;
    description?: string;
    chargeAmount: string;
    currency: string;
}
export type BusinessSupportServiceSpendList = BusinessSupportServiceSpend[];
export interface BusinessSupportAccountCharge {
    accountId: string;
    supportPlanName: string;
    totalCharge: string;
    totalUsageBasis: string;
    tierCharges?: BusinessSupportTierCharge[];
    supportDiscount?: BusinessSupportDiscount;
    supportEligibleSpendByService?: BusinessSupportServiceSpend[];
}
export type BusinessSupportAccountChargeList = BusinessSupportAccountCharge[];
export interface ListBusinessSupportAccountChargesResponse {
    billingMonth: string;
    isEstimated: boolean;
    totalSupportCharge: string;
    totalSupportEligibleSpend: string;
    accountCount: number;
    accountCharges: BusinessSupportAccountCharge[];
    nextToken?: string;
}
export interface ListBusinessSupportSubscriptionHistoryRequest {
    billingMonth?: string;
    accountId?: string;
    startDate?: Date;
    endDate?: Date;
    maxResults?: number;
    nextToken?: string;
}
export interface BusinessSupportSubscriptionContract {
    accountId: string;
    planName: string;
    contractStartDate: Date;
    contractEndDate: Date;
}
export type BusinessSupportSubscriptionContractList = BusinessSupportSubscriptionContract[];
export interface ListBusinessSupportSubscriptionHistoryResponse {
    subscriptionContracts: BusinessSupportSubscriptionContract[];
    nextToken?: string;
}
export interface ListEnterpriseSupportLinkedAccountChargesRequest {
    billingMonth: string;
    accountId?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface EnterpriseSupportTimePeriod {
    beginDate: Date;
    endDate?: Date;
}
export type TimePeriodList = EnterpriseSupportTimePeriod[];
export interface ServiceLevelAccountUsage {
    serviceCode?: string;
    totalSupportEligibleSpend?: string;
}
export type ServiceLevelAccountUsageList = ServiceLevelAccountUsage[];
export interface LinkedAccountCharge {
    accountId: string;
    payerAccountId: string;
    accountType?: string;
    billableSeconds: number;
    totalSeconds: number;
    totalSupportEligibleSpend: string;
    proratedTotalSupportEligibleSpend: string;
    linkedTimePeriods?: EnterpriseSupportTimePeriod[];
    subscriptionTimePeriods?: EnterpriseSupportTimePeriod[];
    totalSupportEligibleReservedInstanceSpend?: string;
    totalSupportEligibleSavingsPlanSpend?: string;
    supportEligibleSpendByService?: ServiceLevelAccountUsage[];
}
export type LinkedAccountChargeList = LinkedAccountCharge[];
export interface ListEnterpriseSupportLinkedAccountChargesResponse {
    linkedAccount: LinkedAccountCharge[];
    nextToken?: string;
}
export interface ListSourceViewsForBillingViewRequest {
    arn: string;
    maxResults?: number;
    nextToken?: string;
}
export interface ListSourceViewsForBillingViewResponse {
    sourceViews: string[];
    nextToken?: string;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    resourceTags?: ResourceTag[];
}
export type PromoCode = string;
export interface RedeemCreditsRequest {
    promoCode: string;
}
export interface RedeemCreditsResponse {
}
export interface TagResourceRequest {
    resourceArn: string;
    resourceTags: ResourceTag[];
}
export interface TagResourceResponse {
}
export type ResourceTagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    resourceTagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface BillingPreferenceForKey {
    key: string;
    value: PreferenceValue;
}
export type BillingPreferencesPerKey = BillingPreferenceForKey[];
export interface UpdateBillingPreferencesRequest {
    feature: BillingFeature;
    billingPreferencesPerKey: BillingPreferenceForKey[];
}
export interface UpdateBillingPreferencesResponse {
}
export interface UpdateBillingViewRequest {
    arn: string;
    name?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    dataFilterExpression?: Expression;
}
export interface UpdateBillingViewResponse {
    arn: string;
    updatedAt?: Date;
}
export type ErrorMessage = string;
export type ResourceId = string;
export type ResourceType = string;
export type ServiceCode = string;
export type QuotaCode = string;
export type ValidationExceptionReason = "unknownOperation" | "cannotParse" | "fieldValidationFailed" | "other" | (string & {});
export type FieldName = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AssociateSourceViewsError = AccessDeniedException | BillingViewHealthStatusException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates one or more source billing views with an existing billing view. This allows creating aggregate billing views that combine data from multiple sources.
 */
export declare const associateSourceViews: API.OperationMethod<AssociateSourceViewsRequest, AssociateSourceViewsResponse, AssociateSourceViewsError, Credentials | HttpClient.HttpClient>;
export type CreateBillingViewError = AccessDeniedException | BillingViewHealthStatusException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a billing view with the specified billing view attributes.
 */
export declare const createBillingView: API.OperationMethod<CreateBillingViewRequest, CreateBillingViewResponse, CreateBillingViewError, Credentials | HttpClient.HttpClient>;
export type DeleteBillingViewError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified billing view.
 */
export declare const deleteBillingView: API.OperationMethod<DeleteBillingViewRequest, DeleteBillingViewResponse, DeleteBillingViewError, Credentials | HttpClient.HttpClient>;
export type DisassociateSourceViewsError = AccessDeniedException | BillingViewHealthStatusException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the association between one or more source billing views and an existing billing view. This allows modifying the composition of aggregate billing views.
 */
export declare const disassociateSourceViews: API.OperationMethod<DisassociateSourceViewsRequest, DisassociateSourceViewsResponse, DisassociateSourceViewsError, Credentials | HttpClient.HttpClient>;
export type GetBillingPreferencesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves billing preferences for the specified feature. Each feature controls a distinct billing capability: which accounts can share Reserved Instances or credits, whether billing alerts are enabled, the historical record of sharing changes, and per-credit options.
 */
export declare const getBillingPreferences: API.OperationMethod<GetBillingPreferencesRequest, GetBillingPreferencesResponse, GetBillingPreferencesError, Credentials | HttpClient.HttpClient>;
export type GetBillingViewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the metadata associated to the specified billing view ARN.
 */
export declare const getBillingView: API.OperationMethod<GetBillingViewRequest, GetBillingViewResponse, GetBillingViewError, Credentials | HttpClient.HttpClient>;
export type GetCreditAllocationHistoryError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the per-billing-month allocation history for credits applied to an Amazon Web Services account's bills. Traverses the consolidated billing family to capture cross-account credit applications. Supports pagination and optional filtering to a single credit.
 */
export declare const getCreditAllocationHistory: API.PaginatedOperationMethod<GetCreditAllocationHistoryRequest, GetCreditAllocationHistoryResponse, GetCreditAllocationHistoryError, Credentials | HttpClient.HttpClient, CreditAllocationHistoryEntry>;
export type GetCreditsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the list of Amazon Web Services account credits for the specified account. Each credit includes its identifier, type, monetary amounts, applicable products, expiration, sharing configuration, and current enabled status.
 *
 * When the caller is the management account of a consolidated billing family and `payerAccountFlag` is `true`, the response aggregates credits across the entire family. Otherwise, the response includes only credits owned by the account specified in `accountId`.
 */
export declare const getCredits: API.OperationMethod<GetCreditsRequest, GetCreditsResponse, GetCreditsError, Credentials | HttpClient.HttpClient>;
export type GetEnterpriseSupportChargeSummaryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a summary of Enterprise Support data aggregated across all accounts in the Enterprise Support profile.
 */
export declare const getEnterpriseSupportChargeSummary: API.OperationMethod<GetEnterpriseSupportChargeSummaryRequest, GetEnterpriseSupportChargeSummaryResponse, GetEnterpriseSupportChargeSummaryError, Credentials | HttpClient.HttpClient>;
export type GetEnterpriseSupportContractDetailsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns Enterprise Support contract details.
 */
export declare const getEnterpriseSupportContractDetails: API.OperationMethod<GetEnterpriseSupportContractDetailsRequest, GetEnterpriseSupportContractDetailsResponse, GetEnterpriseSupportContractDetailsError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the resource-based policy document attached to the resource in `JSON` format.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type ListBillingViewsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the billing views available for a given time period.
 *
 * Every Amazon Web Services account has a unique `PRIMARY` billing view that represents the billing data available by default. Accounts that use Billing Conductor also have `BILLING_GROUP` billing views representing pro forma costs associated with each created billing group.
 */
export declare const listBillingViews: API.PaginatedOperationMethod<ListBillingViewsRequest, ListBillingViewsResponse, ListBillingViewsError, Credentials | HttpClient.HttpClient, BillingViewListElement>;
export type ListBillingViewSegmentsError = AccessDeniedException | BillingViewHealthStatusException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the segments of a billing view over a given time period. Each segment identifies the billing domain (`PRO_FORMA` or `BILLABLE`) and the account relationships that apply during its time range.
 *
 * If you don't provide an `arn`, the response includes segments for the caller's `PRIMARY` billing view.
 *
 * If a mid-period change occurs, the response includes multiple segments, each with its own time range. The response omits hidden segments, so the segments it returns might not cover the entire requested time period.
 */
export declare const listBillingViewSegments: API.PaginatedOperationMethod<ListBillingViewSegmentsRequest, ListBillingViewSegmentsResponse, ListBillingViewSegmentsError, Credentials | HttpClient.HttpClient, BillingViewSegmentsListElement>;
export type ListBusinessSupportAccountChargesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns Business Support charges broken down at the linked account level for a given billing month.
 */
export declare const listBusinessSupportAccountCharges: API.PaginatedOperationMethod<ListBusinessSupportAccountChargesRequest, ListBusinessSupportAccountChargesResponse, ListBusinessSupportAccountChargesError, Credentials | HttpClient.HttpClient, BusinessSupportAccountCharge>;
export type ListBusinessSupportSubscriptionHistoryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the history of Business Support subscription contracts across accounts.
 */
export declare const listBusinessSupportSubscriptionHistory: API.PaginatedOperationMethod<ListBusinessSupportSubscriptionHistoryRequest, ListBusinessSupportSubscriptionHistoryResponse, ListBusinessSupportSubscriptionHistoryError, Credentials | HttpClient.HttpClient, BusinessSupportSubscriptionContract>;
export type ListEnterpriseSupportLinkedAccountChargesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns Support-eligible spend broken down at linked account level.
 */
export declare const listEnterpriseSupportLinkedAccountCharges: API.PaginatedOperationMethod<ListEnterpriseSupportLinkedAccountChargesRequest, ListEnterpriseSupportLinkedAccountChargesResponse, ListEnterpriseSupportLinkedAccountChargesError, Credentials | HttpClient.HttpClient, LinkedAccountCharge>;
export type ListSourceViewsForBillingViewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the source views (managed Amazon Web Services billing views) associated with the billing view.
 */
export declare const listSourceViewsForBillingView: API.PaginatedOperationMethod<ListSourceViewsForBillingViewRequest, ListSourceViewsForBillingViewResponse, ListSourceViewsForBillingViewError, Credentials | HttpClient.HttpClient, BillingViewArn>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists tags associated with the billing view resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RedeemCreditsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Redeems an Amazon Web Services promotional credit code on behalf of the calling account. On success, a new credit is added to the account's credit ledger with the amount, validity period, and applicable products defined by the promotion. The credit is then automatically applied to subsequent bills according to the standard credit application order.
 */
export declare const redeemCredits: API.OperationMethod<RedeemCreditsRequest, RedeemCreditsResponse, RedeemCreditsError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * An API operation for adding one or more tags (key-value pairs) to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from a resource. Specify only tag keys in your request. Don't specify the value.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBillingPreferencesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates billing preferences for the specified feature. Each feature targets a distinct billing capability and has its own set of supported keys. The action sets the value for each provided key; keys not present in the request are unchanged.
 *
 * Sharing keys (`RI_SHARING`, `CREDIT_SHARING`, `CREDIT_LEVEL_SHARING`, and sharing keys under `CREDIT_PREFERENCE_OPTIONS`) may only be set by the management account of a consolidated billing family. The `credit/{creditId}/status` key may be set by member accounts for credits they own, or by the management account for any credit in the family.
 */
export declare const updateBillingPreferences: API.OperationMethod<UpdateBillingPreferencesRequest, UpdateBillingPreferencesResponse, UpdateBillingPreferencesError, Credentials | HttpClient.HttpClient>;
export type UpdateBillingViewError = AccessDeniedException | BillingViewHealthStatusException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * An API to update the attributes of the billing view.
 */
export declare const updateBillingView: API.OperationMethod<UpdateBillingViewRequest, UpdateBillingViewResponse, UpdateBillingViewError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=billing.d.ts.map