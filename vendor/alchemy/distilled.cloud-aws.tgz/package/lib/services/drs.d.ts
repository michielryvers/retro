import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly code: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly code: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly code: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UninitializedAccountException_base: S.TaggedErrorClass<"UninitializedAccountException", {
    readonly message: any;
    readonly code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UninitializedAccountException extends /*@__PURE__*/ UninitializedAccountException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly code: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SourceNetworkID = string;
export type CfnStackName = string | redacted.Redacted<string>;
export interface AssociateSourceNetworkStackRequest {
    sourceNetworkID: string;
    cfnStackName: string | redacted.Redacted<string>;
}
export type JobID = string;
export type ARN = string;
export type JobType = string;
export type InitiatedBy = string;
export type ISO8601DatetimeString = string;
export type JobStatus = string;
export type SourceServerID = string;
export type RecoveryInstanceID = string;
export type LaunchStatus = string;
export type LaunchActionId = string;
export type SsmDocumentName = string;
export type LaunchActionType = string;
export type LaunchActionName = string;
export type LaunchActionOrder = number;
export type LaunchActionVersion = string;
export type LaunchActionParameterName = string;
export type LaunchActionParameterValue = string;
export type LaunchActionParameterType = string;
export interface LaunchActionParameter {
    value?: string;
    type?: string;
}
export type LaunchActionParameters = {
    [key: string]: LaunchActionParameter | undefined;
};
export type LaunchActionDescription = string;
export type LaunchActionCategory = string;
export interface LaunchAction {
    actionId?: string;
    actionCode?: string;
    type?: string;
    name?: string;
    active?: boolean;
    order?: number;
    actionVersion?: string;
    optional?: boolean;
    parameters?: {
        [key: string]: LaunchActionParameter | undefined;
    };
    description?: string;
    category?: string;
}
export type LaunchActionRunId = string;
export type LaunchActionRunStatus = string;
export type FailureReason = string;
export interface LaunchActionRun {
    action?: LaunchAction;
    runId?: string;
    status?: string;
    failureReason?: string;
}
export type LaunchActionRuns = LaunchActionRun[];
export interface LaunchActionsStatus {
    ssmAgentDiscoveryDatetime?: string;
    runs?: LaunchActionRun[];
}
export interface ParticipatingServer {
    sourceServerID?: string;
    recoveryInstanceID?: string;
    launchStatus?: string;
    launchActionsStatus?: LaunchActionsStatus;
}
export type ParticipatingServers = ParticipatingServer[];
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export type ParticipatingResourceID = {
    sourceNetworkID: string;
};
export interface ParticipatingResource {
    participatingResourceID?: ParticipatingResourceID;
    launchStatus?: string;
}
export type ParticipatingResources = ParticipatingResource[];
export interface Job {
    jobID: string;
    arn?: string;
    type?: string;
    initiatedBy?: string;
    creationDateTime?: string;
    endDateTime?: string;
    status?: string;
    participatingServers?: ParticipatingServer[];
    tags?: {
        [key: string]: string | undefined;
    };
    participatingResources?: ParticipatingResource[];
}
export interface AssociateSourceNetworkStackResponse {
    job?: Job;
}
export type StrictDRSARN = string;
export interface CancelRecoveryPlanExecutionRequest {
    recoveryPlanExecutionArn: string;
}
export type RecoveryPlanExecutionMode = string;
export type RecoveryPlanExecutionStatus = string;
export interface ErrorDetail {
    message: string;
    code: string;
}
export interface RecoveryPlanExecution {
    recoveryPlanExecutionArn: string;
    recoveryPlanArn: string;
    mode: string;
    status: string;
    startedAt: string;
    completedAt?: string;
    errorDetail?: ErrorDetail;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CancelRecoveryPlanExecutionResponse {
    recoveryPlanExecution: RecoveryPlanExecution;
}
export type SourceServerARN = string;
export interface CreateExtendedSourceServerRequest {
    sourceServerArn: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type LastLaunchResult = string;
export type ISO8601DurationString = string;
export type BoundedString = string;
export type PositiveInteger = number;
export type VolumeStatus = string;
export interface DataReplicationInfoReplicatedDisk {
    deviceName?: string;
    totalStorageBytes?: number;
    replicatedStorageBytes?: number;
    rescannedStorageBytes?: number;
    backloggedStorageBytes?: number;
    volumeStatus?: string;
}
export type DataReplicationInfoReplicatedDisks = DataReplicationInfoReplicatedDisk[];
export type DataReplicationState = string;
export type DataReplicationInitiationStepName = string;
export type DataReplicationInitiationStepStatus = string;
export interface DataReplicationInitiationStep {
    name?: string;
    status?: string;
}
export type DataReplicationInitiationSteps = DataReplicationInitiationStep[];
export interface DataReplicationInitiation {
    startDateTime?: string;
    nextAttemptDateTime?: string;
    steps?: DataReplicationInitiationStep[];
}
export type DataReplicationErrorString = string;
export type LargeBoundedString = string;
export interface DataReplicationError {
    error?: string;
    rawError?: string;
}
export type AwsAvailabilityZone = string;
export type OutpostARN = string;
export interface DataReplicationInfo {
    lagDuration?: string;
    etaDateTime?: string;
    replicatedDisks?: DataReplicationInfoReplicatedDisk[];
    dataReplicationState?: string;
    dataReplicationInitiation?: DataReplicationInitiation;
    dataReplicationError?: DataReplicationError;
    stagingAvailabilityZone?: string;
    stagingOutpostArn?: string;
}
export type LastLaunchType = string;
export interface LifeCycleLastLaunchInitiated {
    apiCallDateTime?: string;
    jobID?: string;
    type?: string;
}
export interface LifeCycleLastLaunch {
    initiated?: LifeCycleLastLaunchInitiated;
    status?: string;
}
export interface LifeCycle {
    addedToServiceDateTime?: string;
    firstByteDateTime?: string;
    elapsedReplicationDuration?: string;
    lastSeenByServiceDateTime?: string;
    lastLaunch?: LifeCycleLastLaunch;
}
export type EC2InstanceType = string;
export type EC2InstanceID = string;
export interface IdentificationHints {
    fqdn?: string;
    hostname?: string;
    vmWareUuid?: string;
    awsInstanceID?: string;
}
export type IPsList = string[];
export interface NetworkInterface {
    macAddress?: string;
    ips?: string[];
    isPrimary?: boolean;
}
export type NetworkInterfaces = NetworkInterface[];
export interface Disk {
    deviceName?: string;
    bytes?: number;
}
export type Disks = Disk[];
export interface CPU {
    cores?: number;
    modelName?: string;
}
export type Cpus = CPU[];
export interface OS {
    fullString?: string;
}
export type SourceServerArchitecture = string;
export interface SourceProperties {
    lastUpdatedDateTime?: string;
    recommendedInstanceType?: string;
    identificationHints?: IdentificationHints;
    networkInterfaces?: NetworkInterface[];
    disks?: Disk[];
    cpus?: CPU[];
    ramBytes?: number;
    os?: OS;
    supportsNitroInstances?: boolean;
    architecture?: string;
}
export type ExtensionStatus = string;
export type AccountID = string;
export interface StagingArea {
    status?: string;
    stagingAccountID?: string;
    stagingSourceServerArn?: string;
    errorMessage?: string;
}
export type AwsRegion = string;
export interface SourceCloudProperties {
    originAccountID?: string;
    originRegion?: string;
    originAvailabilityZone?: string;
    sourceOutpostArn?: string;
}
export type ReplicationDirection = string;
export type AgentVersion = string;
export interface SourceServer {
    sourceServerID?: string;
    arn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    recoveryInstanceId?: string;
    lastLaunchResult?: string;
    dataReplicationInfo?: DataReplicationInfo;
    lifeCycle?: LifeCycle;
    sourceProperties?: SourceProperties;
    stagingArea?: StagingArea;
    sourceCloudProperties?: SourceCloudProperties;
    replicationDirection?: string;
    reversedDirectionSourceServerArn?: string;
    sourceNetworkID?: string;
    agentVersion?: string;
}
export interface CreateExtendedSourceServerResponse {
    sourceServer?: SourceServer;
}
export type LaunchDisposition = string;
export type TargetInstanceTypeRightSizingMethod = string;
export interface Licensing {
    osByol?: boolean;
}
export type RecoveryMode = string;
export interface CreateLaunchConfigurationTemplateRequest {
    tags?: {
        [key: string]: string | undefined;
    };
    launchDisposition?: string;
    targetInstanceTypeRightSizingMethod?: string;
    copyPrivateIp?: boolean;
    copyTags?: boolean;
    licensing?: Licensing;
    exportBucketArn?: string;
    postLaunchEnabled?: boolean;
    launchIntoSourceInstance?: boolean;
    recoveryMode?: string;
}
export type LaunchConfigurationTemplateID = string;
export interface LaunchConfigurationTemplate {
    launchConfigurationTemplateID?: string;
    arn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    launchDisposition?: string;
    targetInstanceTypeRightSizingMethod?: string;
    copyPrivateIp?: boolean;
    copyTags?: boolean;
    licensing?: Licensing;
    exportBucketArn?: string;
    postLaunchEnabled?: boolean;
    launchIntoSourceInstance?: boolean;
    recoveryMode?: string;
}
export interface CreateLaunchConfigurationTemplateResponse {
    launchConfigurationTemplate?: LaunchConfigurationTemplate;
}
export type RecoveryPlanName = string;
export type RecoveryPlanDescription = string;
export type ClientIdempotencyToken = string;
export interface CreateRecoveryPlanRequest {
    name: string;
    description?: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type RecoveryPlanStatus = string;
export interface RecoveryPlan {
    recoveryPlanArn: string;
    name: string;
    description?: string;
    status: string;
    createdAt: string;
    updatedAt: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateRecoveryPlanResponse {
    recoveryPlan: RecoveryPlan;
}
export type RecoveryPlanStepName = string;
export type RecoveryPlanStepOrder = number;
export type RecoveryPlanServerImpactLevel = string;
export interface RecoveryPlanServer {
    serverArn: string;
    impactLevel?: string;
}
export type RecoveryPlanServers = RecoveryPlanServer[];
export interface ServerStepConfiguration {
    servers: RecoveryPlanServer[];
}
export type WaitDurationMinutes = number;
export interface WaitStepConfiguration {
    waitDurationMinutes: number;
}
export type RecoveryPlanStepConfiguration = {
    serverStepConfiguration: ServerStepConfiguration;
    waitStepConfiguration?: never;
} | {
    serverStepConfiguration?: never;
    waitStepConfiguration: WaitStepConfiguration;
};
export interface CreateRecoveryPlanStepRequest {
    recoveryPlanArn: string;
    stepName: string;
    stepOrder?: number;
    configuration: RecoveryPlanStepConfiguration;
    clientToken?: string;
}
export interface RecoveryPlanStep {
    recoveryPlanStepArn: string;
    stepOrder: number;
    stepName: string;
    configuration: RecoveryPlanStepConfiguration;
    createdAt: string;
    updatedAt: string;
}
export interface CreateRecoveryPlanStepResponse {
    recoveryPlanStep: RecoveryPlanStep;
}
export type SubnetID = string;
export type SecurityGroupID = string;
export type ReplicationServersSecurityGroupsIDs = string[];
export type ReplicationConfigurationDefaultLargeStagingDiskType = string;
export type ReplicationConfigurationEbsEncryption = string;
export type ReplicationConfigurationDataPlaneRouting = string;
export type PITPolicyRuleUnits = string;
export type StrictlyPositiveInteger = number;
export interface PITPolicyRule {
    ruleID?: number;
    units: string;
    interval: number;
    retentionDuration: number;
    enabled?: boolean;
}
export type PITPolicy = PITPolicyRule[];
export type InternetProtocol = string;
export interface CreateReplicationConfigurationTemplateRequest {
    stagingAreaSubnetId: string;
    associateDefaultSecurityGroup?: boolean;
    replicationServersSecurityGroupsIDs: string[];
    replicationServerInstanceType?: string;
    useDedicatedReplicationServer?: boolean;
    defaultLargeStagingDiskType?: string;
    ebsEncryption: string;
    ebsEncryptionKeyArn?: string;
    bandwidthThrottling: number;
    dataPlaneRouting?: string;
    createPublicIP?: boolean;
    stagingAreaTags: {
        [key: string]: string | undefined;
    };
    pitPolicy: PITPolicyRule[];
    tags?: {
        [key: string]: string | undefined;
    };
    autoReplicateNewDisks?: boolean;
    internetProtocol?: string;
}
export type ReplicationConfigurationTemplateID = string;
export interface ReplicationConfigurationTemplate {
    replicationConfigurationTemplateID: string;
    arn?: string;
    stagingAreaSubnetId?: string;
    associateDefaultSecurityGroup?: boolean;
    replicationServersSecurityGroupsIDs?: string[];
    replicationServerInstanceType?: string;
    useDedicatedReplicationServer?: boolean;
    defaultLargeStagingDiskType?: string;
    ebsEncryption?: string;
    ebsEncryptionKeyArn?: string;
    bandwidthThrottling?: number;
    dataPlaneRouting?: string;
    createPublicIP?: boolean;
    stagingAreaTags?: {
        [key: string]: string | undefined;
    };
    tags?: {
        [key: string]: string | undefined;
    };
    pitPolicy?: PITPolicyRule[];
    autoReplicateNewDisks?: boolean;
    internetProtocol?: string;
}
export type VpcID = string;
export interface CreateSourceNetworkRequest {
    vpcID: string;
    originAccountID: string;
    originRegion: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateSourceNetworkResponse {
    sourceNetworkID?: string;
}
export interface DeleteJobRequest {
    jobID: string;
}
export interface DeleteJobResponse {
}
export type LaunchActionResourceId = string;
export interface DeleteLaunchActionRequest {
    resourceId: string;
    actionId: string;
}
export interface DeleteLaunchActionResponse {
}
export interface DeleteLaunchConfigurationTemplateRequest {
    launchConfigurationTemplateID: string;
}
export interface DeleteLaunchConfigurationTemplateResponse {
}
export interface DeleteRecoveryInstanceRequest {
    recoveryInstanceID: string;
}
export interface DeleteRecoveryInstanceResponse {
}
export interface DeleteRecoveryPlanRequest {
    recoveryPlanArn: string;
}
export interface DeleteRecoveryPlanResponse {
    recoveryPlanArn: string;
}
export interface DeleteRecoveryPlanExecutionRequest {
    recoveryPlanExecutionArn: string;
}
export interface DeleteRecoveryPlanExecutionResponse {
    recoveryPlanExecutionArn: string;
}
export interface DeleteRecoveryPlanStepRequest {
    recoveryPlanStepArn: string;
}
export interface DeleteRecoveryPlanStepResponse {
    recoveryPlanStepArn: string;
}
export interface DeleteReplicationConfigurationTemplateRequest {
    replicationConfigurationTemplateID: string;
}
export interface DeleteReplicationConfigurationTemplateResponse {
}
export interface DeleteSourceNetworkRequest {
    sourceNetworkID: string;
}
export interface DeleteSourceNetworkResponse {
}
export interface DeleteSourceServerRequest {
    sourceServerID: string;
}
export interface DeleteSourceServerResponse {
}
export type PaginationToken = string;
export interface DescribeJobLogItemsRequest {
    jobID: string;
    maxResults?: number;
    nextToken?: string;
}
export type JobLogEvent = string;
export type EbsSnapshot = string;
export type ConversionMap = {
    [key: string]: string | undefined;
};
export type VolumeToConversionMap = {
    [key: string]: {
        [key: string]: string | undefined;
    } | undefined;
};
export type VolumeToSizeMap = {
    [key: string]: number | undefined;
};
export type ProductCodeId = string;
export type ProductCodeMode = string;
export interface ProductCode {
    productCodeId?: string;
    productCodeMode?: string;
}
export type ProductCodes = ProductCode[];
export type VolumeToProductCodes = {
    [key: string]: ProductCode[] | undefined;
};
export interface ConversionProperties {
    volumeToConversionMap?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    rootVolumeName?: string;
    forceUefi?: boolean;
    dataTimestamp?: string;
    volumeToVolumeSize?: {
        [key: string]: number | undefined;
    };
    volumeToProductCodes?: {
        [key: string]: ProductCode[] | undefined;
    };
}
export interface SourceNetworkData {
    sourceNetworkID?: string;
    sourceVpc?: string;
    targetVpc?: string;
    stackName?: string;
}
export type EventResourceData = {
    sourceNetworkData: SourceNetworkData;
};
export type JobEventAttemptCount = number;
export interface JobLogEventData {
    sourceServerID?: string;
    conversionServerID?: string;
    targetInstanceID?: string;
    rawError?: string;
    conversionProperties?: ConversionProperties;
    eventResourceData?: EventResourceData;
    attemptCount?: number;
    maxAttemptsCount?: number;
}
export interface JobLog {
    logDateTime?: string;
    event?: string;
    eventData?: JobLogEventData;
}
export type JobLogs = JobLog[];
export interface DescribeJobLogItemsResponse {
    items?: JobLog[];
    nextToken?: string;
}
export type DescribeJobsRequestFiltersJobIDs = string[];
export interface DescribeJobsRequestFilters {
    jobIDs?: string[];
    fromDate?: string;
    toDate?: string;
}
export interface DescribeJobsRequest {
    filters?: DescribeJobsRequestFilters;
    maxResults?: number;
    nextToken?: string;
}
export type JobsList = Job[];
export interface DescribeJobsResponse {
    items?: Job[];
    nextToken?: string;
}
export type LaunchConfigurationTemplateIDs = string[];
export type MaxResultsType = number;
export interface DescribeLaunchConfigurationTemplatesRequest {
    launchConfigurationTemplateIDs?: string[];
    maxResults?: number;
    nextToken?: string;
}
export type LaunchConfigurationTemplates = LaunchConfigurationTemplate[];
export interface DescribeLaunchConfigurationTemplatesResponse {
    items?: LaunchConfigurationTemplate[];
    nextToken?: string;
}
export type RecoveryInstanceIDs = string[];
export type SourceServerIDs = string[];
export interface DescribeRecoveryInstancesRequestFilters {
    recoveryInstanceIDs?: string[];
    sourceServerIDs?: string[];
}
export interface DescribeRecoveryInstancesRequest {
    filters?: DescribeRecoveryInstancesRequestFilters;
    maxResults?: number;
    nextToken?: string;
}
export type EC2InstanceState = string;
export type FailbackState = string;
export type FailbackLaunchType = string;
export interface RecoveryInstanceFailback {
    failbackClientID?: string;
    failbackJobID?: string;
    failbackInitiationTime?: string;
    state?: string;
    agentLastSeenByServiceDateTime?: string;
    failbackClientLastSeenByServiceDateTime?: string;
    failbackToOriginalServer?: boolean;
    firstByteDateTime?: string;
    elapsedReplicationDuration?: string;
    failbackLaunchType?: string;
}
export interface RecoveryInstanceDataReplicationInfoReplicatedDisk {
    deviceName?: string;
    totalStorageBytes?: number;
    replicatedStorageBytes?: number;
    rescannedStorageBytes?: number;
    backloggedStorageBytes?: number;
}
export type RecoveryInstanceDataReplicationInfoReplicatedDisks = RecoveryInstanceDataReplicationInfoReplicatedDisk[];
export type RecoveryInstanceDataReplicationState = string;
export type RecoveryInstanceDataReplicationInitiationStepName = string;
export type RecoveryInstanceDataReplicationInitiationStepStatus = string;
export interface RecoveryInstanceDataReplicationInitiationStep {
    name?: string;
    status?: string;
}
export type RecoveryInstanceDataReplicationInitiationSteps = RecoveryInstanceDataReplicationInitiationStep[];
export interface RecoveryInstanceDataReplicationInitiation {
    startDateTime?: string;
    steps?: RecoveryInstanceDataReplicationInitiationStep[];
}
export type FailbackReplicationError = string;
export interface RecoveryInstanceDataReplicationError {
    error?: string;
    rawError?: string;
}
export interface RecoveryInstanceDataReplicationInfo {
    lagDuration?: string;
    etaDateTime?: string;
    replicatedDisks?: RecoveryInstanceDataReplicationInfoReplicatedDisk[];
    dataReplicationState?: string;
    dataReplicationInitiation?: RecoveryInstanceDataReplicationInitiation;
    dataReplicationError?: RecoveryInstanceDataReplicationError;
    stagingAvailabilityZone?: string;
    stagingOutpostArn?: string;
}
export type EbsVolumeID = string;
export interface RecoveryInstanceDisk {
    internalDeviceName?: string;
    bytes?: number;
    ebsVolumeID?: string;
}
export type RecoveryInstanceDisks = RecoveryInstanceDisk[];
export interface RecoveryInstanceProperties {
    lastUpdatedDateTime?: string;
    identificationHints?: IdentificationHints;
    networkInterfaces?: NetworkInterface[];
    disks?: RecoveryInstanceDisk[];
    cpus?: CPU[];
    ramBytes?: number;
    os?: OS;
}
export type OriginEnvironment = string;
export interface RecoveryInstance {
    ec2InstanceID?: string;
    ec2InstanceState?: string;
    jobID?: string;
    recoveryInstanceID?: string;
    sourceServerID?: string;
    arn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    failback?: RecoveryInstanceFailback;
    dataReplicationInfo?: RecoveryInstanceDataReplicationInfo;
    recoveryInstanceProperties?: RecoveryInstanceProperties;
    pointInTimeSnapshotDateTime?: string;
    isDrill?: boolean;
    originEnvironment?: string;
    originAvailabilityZone?: string;
    agentVersion?: string;
    sourceOutpostArn?: string;
}
export type DescribeRecoveryInstancesItems = RecoveryInstance[];
export interface DescribeRecoveryInstancesResponse {
    nextToken?: string;
    items?: RecoveryInstance[];
}
export interface DescribeRecoverySnapshotsRequestFilters {
    fromDateTime?: string;
    toDateTime?: string;
}
export type RecoverySnapshotsOrder = string;
export interface DescribeRecoverySnapshotsRequest {
    sourceServerID: string;
    filters?: DescribeRecoverySnapshotsRequestFilters;
    order?: string;
    maxResults?: number;
    nextToken?: string;
}
export type RecoverySnapshotID = string;
export type EbsSnapshotsList = string[];
export interface RecoverySnapshot {
    snapshotID: string;
    sourceServerID: string;
    expectedTimestamp: string;
    timestamp?: string;
    ebsSnapshots?: string[];
}
export type RecoverySnapshotsList = RecoverySnapshot[];
export interface DescribeRecoverySnapshotsResponse {
    items?: RecoverySnapshot[];
    nextToken?: string;
}
export type ReplicationConfigurationTemplateIDs = string[];
export interface DescribeReplicationConfigurationTemplatesRequest {
    replicationConfigurationTemplateIDs?: string[];
    maxResults?: number;
    nextToken?: string;
}
export type ReplicationConfigurationTemplates = ReplicationConfigurationTemplate[];
export interface DescribeReplicationConfigurationTemplatesResponse {
    items?: ReplicationConfigurationTemplate[];
    nextToken?: string;
}
export type DescribeSourceNetworksRequestFiltersIDs = string[];
export interface DescribeSourceNetworksRequestFilters {
    sourceNetworkIDs?: string[];
    originAccountID?: string;
    originRegion?: string;
}
export interface DescribeSourceNetworksRequest {
    filters?: DescribeSourceNetworksRequestFilters;
    maxResults?: number;
    nextToken?: string;
}
export type ReplicationStatus = string;
export type SensitiveBoundedString = string | redacted.Redacted<string>;
export type RecoveryResult = string;
export interface RecoveryLifeCycle {
    apiCallDateTime?: Date;
    jobID?: string;
    lastRecoveryResult?: string;
}
export interface SourceNetwork {
    sourceNetworkID?: string;
    sourceVpcID?: string;
    arn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    replicationStatus?: string;
    replicationStatusDetails?: string | redacted.Redacted<string>;
    cfnStackName?: string | redacted.Redacted<string>;
    sourceRegion?: string;
    sourceAccountID?: string;
    lastRecovery?: RecoveryLifeCycle;
    launchedVpcID?: string;
}
export type SourceNetworksList = SourceNetwork[];
export interface DescribeSourceNetworksResponse {
    items?: SourceNetwork[];
    nextToken?: string;
}
export type DescribeSourceServersRequestFiltersIDs = string[];
export type AccountIDs = string[];
export interface DescribeSourceServersRequestFilters {
    sourceServerIDs?: string[];
    hardwareId?: string;
    stagingAccountIDs?: string[];
}
export interface DescribeSourceServersRequest {
    filters?: DescribeSourceServersRequestFilters;
    maxResults?: number;
    nextToken?: string;
}
export type SourceServersList = SourceServer[];
export interface DescribeSourceServersResponse {
    items?: SourceServer[];
    nextToken?: string;
}
export interface DisconnectRecoveryInstanceRequest {
    recoveryInstanceID: string;
}
export interface DisconnectRecoveryInstanceResponse {
}
export interface DisconnectSourceServerRequest {
    sourceServerID: string;
}
export interface ExportSourceNetworkCfnTemplateRequest {
    sourceNetworkID: string;
}
export interface ExportSourceNetworkCfnTemplateResponse {
    s3DestinationUrl?: string;
}
export interface GetFailbackReplicationConfigurationRequest {
    recoveryInstanceID: string;
}
export interface GetFailbackReplicationConfigurationResponse {
    recoveryInstanceID: string;
    name?: string;
    bandwidthThrottling?: number;
    usePrivateIP?: boolean;
    internetProtocol?: string;
}
export interface GetLaunchConfigurationRequest {
    sourceServerID: string;
}
export type SmallBoundedString = string;
export interface LaunchIntoInstanceProperties {
    launchIntoEC2InstanceID?: string;
}
export interface LaunchConfiguration {
    sourceServerID?: string;
    name?: string;
    ec2LaunchTemplateID?: string;
    launchDisposition?: string;
    targetInstanceTypeRightSizingMethod?: string;
    copyPrivateIp?: boolean;
    copyTags?: boolean;
    licensing?: Licensing;
    postLaunchEnabled?: boolean;
    launchIntoInstanceProperties?: LaunchIntoInstanceProperties;
    recoveryMode?: string;
}
export interface GetRecoveryPlanRequest {
    recoveryPlanArn: string;
}
export interface GetRecoveryPlanResponse {
    recoveryPlan: RecoveryPlan;
}
export interface GetRecoveryPlanExecutionRequest {
    recoveryPlanExecutionArn: string;
}
export interface GetRecoveryPlanExecutionResponse {
    recoveryPlanExecution: RecoveryPlanExecution;
}
export interface GetRecoveryPlanExecutionStepRequest {
    recoveryPlanExecutionStepArn: string;
}
export type RecoveryPlanExecutionStepStatus = string;
export interface RecoveryPlanExecutionServer {
    serverArn: string;
    impactLevel?: string;
    jobID?: string;
}
export type RecoveryPlanExecutionServers = RecoveryPlanExecutionServer[];
export interface ExecutionServerStepConfiguration {
    servers: RecoveryPlanExecutionServer[];
}
export type RecoveryPlanExecutionStepConfiguration = {
    executionServerStepConfiguration: ExecutionServerStepConfiguration;
    waitStepConfiguration?: never;
} | {
    executionServerStepConfiguration?: never;
    waitStepConfiguration: WaitStepConfiguration;
};
export interface RecoveryPlanExecutionStep {
    recoveryPlanExecutionStepArn: string;
    stepIndex: number;
    status: string;
    stepName: string;
    configuration: RecoveryPlanExecutionStepConfiguration;
    errorDetail?: ErrorDetail;
    attempt: number;
    createdAt: string;
    updatedAt: string;
}
export interface GetRecoveryPlanExecutionStepResponse {
    recoveryPlanExecutionStep: RecoveryPlanExecutionStep;
}
export interface GetRecoveryPlanStepRequest {
    recoveryPlanStepArn: string;
}
export interface GetRecoveryPlanStepResponse {
    recoveryPlanStep: RecoveryPlanStep;
}
export interface GetReplicationConfigurationRequest {
    sourceServerID: string;
}
export type ReplicationConfigurationReplicatedDiskStagingDiskType = string;
export interface ReplicationConfigurationReplicatedDisk {
    deviceName?: string;
    isBootDisk?: boolean;
    stagingDiskType?: string;
    iops?: number;
    throughput?: number;
    optimizedStagingDiskType?: string;
}
export type ReplicationConfigurationReplicatedDisks = ReplicationConfigurationReplicatedDisk[];
export interface ReplicationConfiguration {
    sourceServerID?: string;
    name?: string;
    stagingAreaSubnetId?: string;
    associateDefaultSecurityGroup?: boolean;
    replicationServersSecurityGroupsIDs?: string[];
    replicationServerInstanceType?: string;
    useDedicatedReplicationServer?: boolean;
    defaultLargeStagingDiskType?: string;
    replicatedDisks?: ReplicationConfigurationReplicatedDisk[];
    ebsEncryption?: string;
    ebsEncryptionKeyArn?: string;
    bandwidthThrottling?: number;
    dataPlaneRouting?: string;
    createPublicIP?: boolean;
    stagingAreaTags?: {
        [key: string]: string | undefined;
    };
    pitPolicy?: PITPolicyRule[];
    autoReplicateNewDisks?: boolean;
    internetProtocol?: string;
}
export interface InitializeServiceRequest {
}
export interface InitializeServiceResponse {
}
export type MaxResultsReplicatingSourceServers = number;
export interface ListExtensibleSourceServersRequest {
    stagingAccountID: string;
    maxResults?: number;
    nextToken?: string;
}
export interface StagingSourceServer {
    hostname?: string;
    arn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type StagingSourceServersList = StagingSourceServer[];
export interface ListExtensibleSourceServersResponse {
    items?: StagingSourceServer[];
    nextToken?: string;
}
export type LaunchActionIds = string[];
export interface LaunchActionsRequestFilters {
    actionIds?: string[];
}
export interface ListLaunchActionsRequest {
    resourceId: string;
    filters?: LaunchActionsRequestFilters;
    maxResults?: number;
    nextToken?: string;
}
export type LaunchActions = LaunchAction[];
export interface ListLaunchActionsResponse {
    items?: LaunchAction[];
    nextToken?: string;
}
export interface ListRecoveryPlanExecutionsRequest {
    recoveryPlanArn?: string;
    status?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface RecoveryPlanExecutionSummary {
    recoveryPlanExecutionArn: string;
    recoveryPlanArn: string;
    mode: string;
    status: string;
    startedAt: string;
    errorDetail?: ErrorDetail;
}
export type RecoveryPlanExecutionSummaryList = RecoveryPlanExecutionSummary[];
export interface ListRecoveryPlanExecutionsResponse {
    recoveryPlanExecutions: RecoveryPlanExecutionSummary[];
    nextToken?: string;
}
export interface ListRecoveryPlanExecutionStepsFilter {
    status?: string;
}
export interface ListRecoveryPlanExecutionStepsRequest {
    recoveryPlanExecutionArn: string;
    filter?: ListRecoveryPlanExecutionStepsFilter;
    maxResults?: number;
    nextToken?: string;
}
export interface RecoveryPlanExecutionStepSummary {
    recoveryPlanExecutionStepArn: string;
    stepName: string;
    stepIndex: number;
    status: string;
    configuration: RecoveryPlanExecutionStepConfiguration;
    errorDetail?: ErrorDetail;
}
export type RecoveryPlanExecutionStepSummaryList = RecoveryPlanExecutionStepSummary[];
export interface ListRecoveryPlanExecutionStepsResponse {
    recoveryPlanExecutionSteps: RecoveryPlanExecutionStepSummary[];
    nextToken?: string;
}
export interface ListRecoveryPlansRequest {
    maxResults?: number;
    nextToken?: string;
}
export interface RecoveryPlanSummary {
    recoveryPlanArn: string;
    name: string;
    status: string;
    createdAt: string;
    updatedAt: string;
}
export type RecoveryPlanSummaryList = RecoveryPlanSummary[];
export interface ListRecoveryPlansResponse {
    recoveryPlans: RecoveryPlanSummary[];
    nextToken?: string;
}
export interface ListRecoveryPlanStepsRequest {
    recoveryPlanArn: string;
    maxResults?: number;
    nextToken?: string;
}
export type RecoveryPlanStepList = RecoveryPlanStep[];
export interface ListRecoveryPlanStepsResponse {
    recoveryPlanSteps: RecoveryPlanStep[];
    nextToken?: string;
}
export interface ListStagingAccountsRequest {
    maxResults?: number;
    nextToken?: string;
}
export interface Account {
    accountID?: string;
}
export type Accounts = Account[];
export interface ListStagingAccountsResponse {
    accounts?: Account[];
    nextToken?: string;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface PutLaunchActionRequest {
    resourceId: string;
    actionCode: string;
    order: number;
    actionId: string;
    optional: boolean;
    active: boolean;
    name: string;
    actionVersion: string;
    category: string;
    parameters?: {
        [key: string]: LaunchActionParameter | undefined;
    };
    description: string;
}
export interface PutLaunchActionResponse {
    resourceId?: string;
    actionId?: string;
    actionCode?: string;
    type?: string;
    name?: string;
    active?: boolean;
    order?: number;
    actionVersion?: string;
    optional?: boolean;
    parameters?: {
        [key: string]: LaunchActionParameter | undefined;
    };
    description?: string;
    category?: string;
}
export type RecoveryPlanStepArnList = string[];
export interface ReorderRecoveryPlanStepsRequest {
    recoveryPlanArn: string;
    orderedStepArns: string[];
}
export interface ReorderRecoveryPlanStepsResponse {
    recoveryPlanSteps: RecoveryPlanStep[];
}
export interface RetryDataReplicationRequest {
    sourceServerID: string;
}
export interface RetryRecoveryPlanExecutionStepRequest {
    recoveryPlanExecutionStepArn: string;
}
export interface RetryRecoveryPlanExecutionStepResponse {
    recoveryPlanExecutionStep: RecoveryPlanExecutionStep;
}
export interface ReverseReplicationRequest {
    recoveryInstanceID: string;
}
export interface ReverseReplicationResponse {
    reversedDirectionSourceServerArn?: string;
}
export type StartFailbackRequestRecoveryInstanceIDs = string[];
export interface StartFailbackLaunchRequest {
    recoveryInstanceIDs: string[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface StartFailbackLaunchResponse {
    job?: Job;
}
export interface StartRecoveryRequestSourceServer {
    sourceServerID: string;
    recoverySnapshotID?: string;
}
export type StartRecoveryRequestSourceServers = StartRecoveryRequestSourceServer[];
export interface StartRecoveryRequest {
    sourceServers: StartRecoveryRequestSourceServer[];
    isDrill?: boolean;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface StartRecoveryResponse {
    job?: Job;
}
export interface RecoveryPlanExecutionSourceServer {
    sourceServerID: string;
    recoverySnapshotID: string;
}
export type RecoveryPlanExecutionSourceServerList = RecoveryPlanExecutionSourceServer[];
export interface StartRecoveryPlanExecutionRequest {
    recoveryPlanArn: string;
    mode: string;
    clientToken?: string;
    sourceServers?: RecoveryPlanExecutionSourceServer[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface StartRecoveryPlanExecutionResponse {
    recoveryPlanExecution: RecoveryPlanExecution;
}
export interface StartReplicationRequest {
    sourceServerID: string;
}
export interface StartReplicationResponse {
    sourceServer?: SourceServer;
}
export interface StartSourceNetworkRecoveryRequestNetworkEntry {
    sourceNetworkID: string;
    cfnStackName?: string | redacted.Redacted<string>;
}
export type StartSourceNetworkRecoveryRequestNetworkEntries = StartSourceNetworkRecoveryRequestNetworkEntry[];
export interface StartSourceNetworkRecoveryRequest {
    sourceNetworks: StartSourceNetworkRecoveryRequestNetworkEntry[];
    deployAsNew?: boolean;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface StartSourceNetworkRecoveryResponse {
    job?: Job;
}
export interface StartSourceNetworkReplicationRequest {
    sourceNetworkID: string;
}
export interface StartSourceNetworkReplicationResponse {
    sourceNetwork?: SourceNetwork;
}
export interface StopFailbackRequest {
    recoveryInstanceID: string;
}
export interface StopFailbackResponse {
}
export interface StopReplicationRequest {
    sourceServerID: string;
}
export interface StopReplicationResponse {
    sourceServer?: SourceServer;
}
export interface StopSourceNetworkReplicationRequest {
    sourceNetworkID: string;
}
export interface StopSourceNetworkReplicationResponse {
    sourceNetwork?: SourceNetwork;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type RecoveryInstancesForTerminationRequest = string[];
export interface TerminateRecoveryInstancesRequest {
    recoveryInstanceIDs: string[];
}
export interface TerminateRecoveryInstancesResponse {
    job?: Job;
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateFailbackReplicationConfigurationRequest {
    recoveryInstanceID: string;
    name?: string;
    bandwidthThrottling?: number;
    usePrivateIP?: boolean;
    internetProtocol?: string;
}
export interface UpdateFailbackReplicationConfigurationResponse {
}
export interface UpdateLaunchConfigurationRequest {
    sourceServerID: string;
    name?: string;
    launchDisposition?: string;
    targetInstanceTypeRightSizingMethod?: string;
    copyPrivateIp?: boolean;
    copyTags?: boolean;
    licensing?: Licensing;
    postLaunchEnabled?: boolean;
    launchIntoInstanceProperties?: LaunchIntoInstanceProperties;
    recoveryMode?: string;
}
export interface UpdateLaunchConfigurationTemplateRequest {
    launchConfigurationTemplateID: string;
    launchDisposition?: string;
    targetInstanceTypeRightSizingMethod?: string;
    copyPrivateIp?: boolean;
    copyTags?: boolean;
    licensing?: Licensing;
    exportBucketArn?: string;
    postLaunchEnabled?: boolean;
    launchIntoSourceInstance?: boolean;
    recoveryMode?: string;
}
export interface UpdateLaunchConfigurationTemplateResponse {
    launchConfigurationTemplate?: LaunchConfigurationTemplate;
}
export interface UpdateRecoveryPlanRequest {
    recoveryPlanArn: string;
    name?: string;
    description?: string;
}
export interface UpdateRecoveryPlanResponse {
    recoveryPlan: RecoveryPlan;
}
export interface UpdateRecoveryPlanExecutionStepRequest {
    recoveryPlanExecutionStepArn: string;
    status?: string;
    servers?: RecoveryPlanServer[];
    waitDurationMinutes?: number;
}
export interface UpdateRecoveryPlanExecutionStepResponse {
    recoveryPlanExecutionStep: RecoveryPlanExecutionStep;
}
export interface UpdateRecoveryPlanStepRequest {
    recoveryPlanStepArn: string;
    stepName?: string;
    configuration?: RecoveryPlanStepConfiguration;
}
export interface UpdateRecoveryPlanStepResponse {
    recoveryPlanStep: RecoveryPlanStep;
}
export interface UpdateReplicationConfigurationRequest {
    sourceServerID: string;
    name?: string;
    stagingAreaSubnetId?: string;
    associateDefaultSecurityGroup?: boolean;
    replicationServersSecurityGroupsIDs?: string[];
    replicationServerInstanceType?: string;
    useDedicatedReplicationServer?: boolean;
    defaultLargeStagingDiskType?: string;
    replicatedDisks?: ReplicationConfigurationReplicatedDisk[];
    ebsEncryption?: string;
    ebsEncryptionKeyArn?: string;
    bandwidthThrottling?: number;
    dataPlaneRouting?: string;
    createPublicIP?: boolean;
    stagingAreaTags?: {
        [key: string]: string | undefined;
    };
    pitPolicy?: PITPolicyRule[];
    autoReplicateNewDisks?: boolean;
    internetProtocol?: string;
}
export interface UpdateReplicationConfigurationTemplateRequest {
    replicationConfigurationTemplateID: string;
    arn?: string;
    stagingAreaSubnetId?: string;
    associateDefaultSecurityGroup?: boolean;
    replicationServersSecurityGroupsIDs?: string[];
    replicationServerInstanceType?: string;
    useDedicatedReplicationServer?: boolean;
    defaultLargeStagingDiskType?: string;
    ebsEncryption?: string;
    ebsEncryptionKeyArn?: string;
    bandwidthThrottling?: number;
    dataPlaneRouting?: string;
    createPublicIP?: boolean;
    stagingAreaTags?: {
        [key: string]: string | undefined;
    };
    pitPolicy?: PITPolicyRule[];
    autoReplicateNewDisks?: boolean;
    internetProtocol?: string;
}
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    name?: string;
    message?: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AssociateSourceNetworkStackError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Associate a Source Network to an existing CloudFormation Stack and modify launch templates to use this network. Can be used for reverting to previously deployed CloudFormation stacks.
 */
export declare const associateSourceNetworkStack: API.OperationMethod<AssociateSourceNetworkStackRequest, AssociateSourceNetworkStackResponse, AssociateSourceNetworkStackError, Credentials | HttpClient.HttpClient>;
export type CancelRecoveryPlanExecutionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Cancels an in-progress Recovery Plan execution. Remaining steps are skipped.
 */
export declare const cancelRecoveryPlanExecution: API.OperationMethod<CancelRecoveryPlanExecutionRequest, CancelRecoveryPlanExecutionResponse, CancelRecoveryPlanExecutionError, Credentials | HttpClient.HttpClient>;
export type CreateExtendedSourceServerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Create an extended source server in the target Account based on the source server in staging account.
 */
export declare const createExtendedSourceServer: API.OperationMethod<CreateExtendedSourceServerRequest, CreateExtendedSourceServerResponse, CreateExtendedSourceServerError, Credentials | HttpClient.HttpClient>;
export type CreateLaunchConfigurationTemplateError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Creates a new Launch Configuration Template.
 */
export declare const createLaunchConfigurationTemplate: API.OperationMethod<CreateLaunchConfigurationTemplateRequest, CreateLaunchConfigurationTemplateResponse, CreateLaunchConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateRecoveryPlanError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Creates a Recovery Plan to orchestrate multi-server disaster recovery.
 */
export declare const createRecoveryPlan: API.OperationMethod<CreateRecoveryPlanRequest, CreateRecoveryPlanResponse, CreateRecoveryPlanError, Credentials | HttpClient.HttpClient>;
export type CreateRecoveryPlanStepError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Creates a step in a Recovery Plan. A step is either `SERVER` type (servers to recover in parallel) or `WAIT` type (timed pause between steps).
 */
export declare const createRecoveryPlanStep: API.OperationMethod<CreateRecoveryPlanStepRequest, CreateRecoveryPlanStepResponse, CreateRecoveryPlanStepError, Credentials | HttpClient.HttpClient>;
export type CreateReplicationConfigurationTemplateError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Creates a new ReplicationConfigurationTemplate.
 */
export declare const createReplicationConfigurationTemplate: API.OperationMethod<CreateReplicationConfigurationTemplateRequest, ReplicationConfigurationTemplate, CreateReplicationConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateSourceNetworkError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Create a new Source Network resource for a provided VPC ID.
 */
export declare const createSourceNetwork: API.OperationMethod<CreateSourceNetworkRequest, CreateSourceNetworkResponse, CreateSourceNetworkError, Credentials | HttpClient.HttpClient>;
export type DeleteJobError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Deletes a single Job by ID.
 */
export declare const deleteJob: API.OperationMethod<DeleteJobRequest, DeleteJobResponse, DeleteJobError, Credentials | HttpClient.HttpClient>;
export type DeleteLaunchActionError = InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Deletes a resource launch action.
 */
export declare const deleteLaunchAction: API.OperationMethod<DeleteLaunchActionRequest, DeleteLaunchActionResponse, DeleteLaunchActionError, Credentials | HttpClient.HttpClient>;
export type DeleteLaunchConfigurationTemplateError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Deletes a single Launch Configuration Template by ID.
 */
export declare const deleteLaunchConfigurationTemplate: API.OperationMethod<DeleteLaunchConfigurationTemplateRequest, DeleteLaunchConfigurationTemplateResponse, DeleteLaunchConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteRecoveryInstanceError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Deletes a single Recovery Instance by ID. This deletes the Recovery Instance resource from Elastic Disaster Recovery. The Recovery Instance must be disconnected first in order to delete it.
 */
export declare const deleteRecoveryInstance: API.OperationMethod<DeleteRecoveryInstanceRequest, DeleteRecoveryInstanceResponse, DeleteRecoveryInstanceError, Credentials | HttpClient.HttpClient>;
export type DeleteRecoveryPlanError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Deletes a Recovery Plan. Cannot delete a plan that has an execution in a non-terminal status (`CREATED`, `IN_PROGRESS`).
 */
export declare const deleteRecoveryPlan: API.OperationMethod<DeleteRecoveryPlanRequest, DeleteRecoveryPlanResponse, DeleteRecoveryPlanError, Credentials | HttpClient.HttpClient>;
export type DeleteRecoveryPlanExecutionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Deletes a Recovery Plan execution record. Must be in a terminal status.
 */
export declare const deleteRecoveryPlanExecution: API.OperationMethod<DeleteRecoveryPlanExecutionRequest, DeleteRecoveryPlanExecutionResponse, DeleteRecoveryPlanExecutionError, Credentials | HttpClient.HttpClient>;
export type DeleteRecoveryPlanStepError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Deletes a step from a Recovery Plan.
 */
export declare const deleteRecoveryPlanStep: API.OperationMethod<DeleteRecoveryPlanStepRequest, DeleteRecoveryPlanStepResponse, DeleteRecoveryPlanStepError, Credentials | HttpClient.HttpClient>;
export type DeleteReplicationConfigurationTemplateError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Deletes a single Replication Configuration Template by ID
 */
export declare const deleteReplicationConfigurationTemplate: API.OperationMethod<DeleteReplicationConfigurationTemplateRequest, DeleteReplicationConfigurationTemplateResponse, DeleteReplicationConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteSourceNetworkError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Delete Source Network resource.
 */
export declare const deleteSourceNetwork: API.OperationMethod<DeleteSourceNetworkRequest, DeleteSourceNetworkResponse, DeleteSourceNetworkError, Credentials | HttpClient.HttpClient>;
export type DeleteSourceServerError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Deletes a single Source Server by ID. The Source Server must be disconnected first.
 */
export declare const deleteSourceServer: API.OperationMethod<DeleteSourceServerRequest, DeleteSourceServerResponse, DeleteSourceServerError, Credentials | HttpClient.HttpClient>;
export type DescribeJobLogItemsError = InternalServerException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Retrieves a detailed Job log with pagination.
 */
export declare const describeJobLogItems: API.PaginatedOperationMethod<DescribeJobLogItemsRequest, DescribeJobLogItemsResponse, DescribeJobLogItemsError, Credentials | HttpClient.HttpClient, JobLog>;
export type DescribeJobsError = InternalServerException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Returns a list of Jobs. Use the JobsID and fromDate and toDate filters to limit which jobs are returned. The response is sorted by creationDataTime - latest date first. Jobs are created by the StartRecovery, TerminateRecoveryInstances and StartFailbackLaunch APIs. Jobs are also created by DiagnosticLaunch and TerminateDiagnosticInstances, which are APIs available only to *Support* and only used in response to relevant support tickets.
 */
export declare const describeJobs: API.PaginatedOperationMethod<DescribeJobsRequest, DescribeJobsResponse, DescribeJobsError, Credentials | HttpClient.HttpClient, Job>;
export type DescribeLaunchConfigurationTemplatesError = InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Lists all Launch Configuration Templates, filtered by Launch Configuration Template IDs
 */
export declare const describeLaunchConfigurationTemplates: API.PaginatedOperationMethod<DescribeLaunchConfigurationTemplatesRequest, DescribeLaunchConfigurationTemplatesResponse, DescribeLaunchConfigurationTemplatesError, Credentials | HttpClient.HttpClient, LaunchConfigurationTemplate>;
export type DescribeRecoveryInstancesError = AccessDeniedException | InternalServerException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Lists all Recovery Instances or multiple Recovery Instances by ID.
 */
export declare const describeRecoveryInstances: API.PaginatedOperationMethod<DescribeRecoveryInstancesRequest, DescribeRecoveryInstancesResponse, DescribeRecoveryInstancesError, Credentials | HttpClient.HttpClient, RecoveryInstance>;
export type DescribeRecoverySnapshotsError = AccessDeniedException | InternalServerException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Lists all Recovery Snapshots for a single Source Server.
 */
export declare const describeRecoverySnapshots: API.PaginatedOperationMethod<DescribeRecoverySnapshotsRequest, DescribeRecoverySnapshotsResponse, DescribeRecoverySnapshotsError, Credentials | HttpClient.HttpClient, RecoverySnapshot>;
export type DescribeReplicationConfigurationTemplatesError = InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Lists all ReplicationConfigurationTemplates, filtered by Source Server IDs.
 */
export declare const describeReplicationConfigurationTemplates: API.PaginatedOperationMethod<DescribeReplicationConfigurationTemplatesRequest, DescribeReplicationConfigurationTemplatesResponse, DescribeReplicationConfigurationTemplatesError, Credentials | HttpClient.HttpClient, ReplicationConfigurationTemplate>;
export type DescribeSourceNetworksError = InternalServerException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Lists all Source Networks or multiple Source Networks filtered by ID.
 */
export declare const describeSourceNetworks: API.PaginatedOperationMethod<DescribeSourceNetworksRequest, DescribeSourceNetworksResponse, DescribeSourceNetworksError, Credentials | HttpClient.HttpClient, SourceNetwork>;
export type DescribeSourceServersError = InternalServerException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Lists all Source Servers or multiple Source Servers filtered by ID.
 */
export declare const describeSourceServers: API.PaginatedOperationMethod<DescribeSourceServersRequest, DescribeSourceServersResponse, DescribeSourceServersError, Credentials | HttpClient.HttpClient, SourceServer>;
export type DisconnectRecoveryInstanceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Disconnect a Recovery Instance from Elastic Disaster Recovery. Data replication is stopped immediately. All AWS resources created by Elastic Disaster Recovery for enabling the replication of the Recovery Instance will be terminated / deleted within 90 minutes. If the agent on the Recovery Instance has not been prevented from communicating with the Elastic Disaster Recovery service, then it will receive a command to uninstall itself (within approximately 10 minutes). The following properties of the Recovery Instance will be changed immediately: dataReplicationInfo.dataReplicationState will be set to DISCONNECTED; The totalStorageBytes property for each of dataReplicationInfo.replicatedDisks will be set to zero; dataReplicationInfo.lagDuration and dataReplicationInfo.lagDuration will be nullified.
 */
export declare const disconnectRecoveryInstance: API.OperationMethod<DisconnectRecoveryInstanceRequest, DisconnectRecoveryInstanceResponse, DisconnectRecoveryInstanceError, Credentials | HttpClient.HttpClient>;
export type DisconnectSourceServerError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Disconnects a specific Source Server from Elastic Disaster Recovery. Data replication is stopped immediately. All AWS resources created by Elastic Disaster Recovery for enabling the replication of the Source Server will be terminated / deleted within 90 minutes. You cannot disconnect a Source Server if it has a Recovery Instance. If the agent on the Source Server has not been prevented from communicating with the Elastic Disaster Recovery service, then it will receive a command to uninstall itself (within approximately 10 minutes). The following properties of the SourceServer will be changed immediately: dataReplicationInfo.dataReplicationState will be set to DISCONNECTED; The totalStorageBytes property for each of dataReplicationInfo.replicatedDisks will be set to zero; dataReplicationInfo.lagDuration and dataReplicationInfo.lagDuration will be nullified.
 */
export declare const disconnectSourceServer: API.OperationMethod<DisconnectSourceServerRequest, SourceServer, DisconnectSourceServerError, Credentials | HttpClient.HttpClient>;
export type ExportSourceNetworkCfnTemplateError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Export the Source Network CloudFormation template to an S3 bucket.
 */
export declare const exportSourceNetworkCfnTemplate: API.OperationMethod<ExportSourceNetworkCfnTemplateRequest, ExportSourceNetworkCfnTemplateResponse, ExportSourceNetworkCfnTemplateError, Credentials | HttpClient.HttpClient>;
export type GetFailbackReplicationConfigurationError = InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Lists all Failback ReplicationConfigurations, filtered by Recovery Instance ID.
 */
export declare const getFailbackReplicationConfiguration: API.OperationMethod<GetFailbackReplicationConfigurationRequest, GetFailbackReplicationConfigurationResponse, GetFailbackReplicationConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetLaunchConfigurationError = InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Gets a LaunchConfiguration, filtered by Source Server IDs.
 */
export declare const getLaunchConfiguration: API.OperationMethod<GetLaunchConfigurationRequest, LaunchConfiguration, GetLaunchConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetRecoveryPlanError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Gets a Recovery Plan by ARN.
 */
export declare const getRecoveryPlan: API.OperationMethod<GetRecoveryPlanRequest, GetRecoveryPlanResponse, GetRecoveryPlanError, Credentials | HttpClient.HttpClient>;
export type GetRecoveryPlanExecutionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Gets the details of a Recovery Plan execution.
 */
export declare const getRecoveryPlanExecution: API.OperationMethod<GetRecoveryPlanExecutionRequest, GetRecoveryPlanExecutionResponse, GetRecoveryPlanExecutionError, Credentials | HttpClient.HttpClient>;
export type GetRecoveryPlanExecutionStepError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Gets the details of a step within a Recovery Plan execution.
 */
export declare const getRecoveryPlanExecutionStep: API.OperationMethod<GetRecoveryPlanExecutionStepRequest, GetRecoveryPlanExecutionStepResponse, GetRecoveryPlanExecutionStepError, Credentials | HttpClient.HttpClient>;
export type GetRecoveryPlanStepError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Gets a Recovery Plan step by ARN.
 */
export declare const getRecoveryPlanStep: API.OperationMethod<GetRecoveryPlanStepRequest, GetRecoveryPlanStepResponse, GetRecoveryPlanStepError, Credentials | HttpClient.HttpClient>;
export type GetReplicationConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Gets a ReplicationConfiguration, filtered by Source Server ID.
 */
export declare const getReplicationConfiguration: API.OperationMethod<GetReplicationConfigurationRequest, ReplicationConfiguration, GetReplicationConfigurationError, Credentials | HttpClient.HttpClient>;
export type InitializeServiceError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initialize Elastic Disaster Recovery.
 */
export declare const initializeService: API.OperationMethod<InitializeServiceRequest, InitializeServiceResponse, InitializeServiceError, Credentials | HttpClient.HttpClient>;
export type ListExtensibleSourceServersError = AccessDeniedException | InternalServerException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Returns a list of source servers on a staging account that are extensible, which means that: a. The source server is not already extended into this Account. b. The source server on the Account we're reading from is not an extension of another source server.
 */
export declare const listExtensibleSourceServers: API.PaginatedOperationMethod<ListExtensibleSourceServersRequest, ListExtensibleSourceServersResponse, ListExtensibleSourceServersError, Credentials | HttpClient.HttpClient, StagingSourceServer>;
export type ListLaunchActionsError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Lists resource launch actions.
 */
export declare const listLaunchActions: API.PaginatedOperationMethod<ListLaunchActionsRequest, ListLaunchActionsResponse, ListLaunchActionsError, Credentials | HttpClient.HttpClient, LaunchAction>;
export type ListRecoveryPlanExecutionsError = AccessDeniedException | InternalServerException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Lists executions of Recovery Plans, optionally filtered by plan or status.
 */
export declare const listRecoveryPlanExecutions: API.PaginatedOperationMethod<ListRecoveryPlanExecutionsRequest, ListRecoveryPlanExecutionsResponse, ListRecoveryPlanExecutionsError, Credentials | HttpClient.HttpClient, RecoveryPlanExecutionSummary>;
export type ListRecoveryPlanExecutionStepsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Lists all steps within a Recovery Plan execution.
 */
export declare const listRecoveryPlanExecutionSteps: API.PaginatedOperationMethod<ListRecoveryPlanExecutionStepsRequest, ListRecoveryPlanExecutionStepsResponse, ListRecoveryPlanExecutionStepsError, Credentials | HttpClient.HttpClient, RecoveryPlanExecutionStepSummary>;
export type ListRecoveryPlansError = AccessDeniedException | InternalServerException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Lists all Recovery Plans in the account.
 */
export declare const listRecoveryPlans: API.PaginatedOperationMethod<ListRecoveryPlansRequest, ListRecoveryPlansResponse, ListRecoveryPlansError, Credentials | HttpClient.HttpClient, RecoveryPlanSummary>;
export type ListRecoveryPlanStepsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Lists all steps in a Recovery Plan.
 */
export declare const listRecoveryPlanSteps: API.PaginatedOperationMethod<ListRecoveryPlanStepsRequest, ListRecoveryPlanStepsResponse, ListRecoveryPlanStepsError, Credentials | HttpClient.HttpClient, RecoveryPlanStep>;
export type ListStagingAccountsError = AccessDeniedException | InternalServerException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Returns an array of staging accounts for existing extended source servers.
 */
export declare const listStagingAccounts: API.PaginatedOperationMethod<ListStagingAccountsRequest, ListStagingAccountsResponse, ListStagingAccountsError, Credentials | HttpClient.HttpClient, Account>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all tags for your Elastic Disaster Recovery resources.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutLaunchActionError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Puts a resource launch action.
 */
export declare const putLaunchAction: API.OperationMethod<PutLaunchActionRequest, PutLaunchActionResponse, PutLaunchActionError, Credentials | HttpClient.HttpClient>;
export type ReorderRecoveryPlanStepsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Reorders steps in a Recovery Plan. Accepts a complete ordered list of step ARNs.
 */
export declare const reorderRecoveryPlanSteps: API.OperationMethod<ReorderRecoveryPlanStepsRequest, ReorderRecoveryPlanStepsResponse, ReorderRecoveryPlanStepsError, Credentials | HttpClient.HttpClient>;
export type RetryDataReplicationError = InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * WARNING: RetryDataReplication is deprecated. Causes the data replication initiation sequence to begin immediately upon next Handshake for the specified Source Server ID, regardless of when the previous initiation started. This command will work only if the Source Server is stalled or is in a DISCONNECTED or STOPPED state.
 */
export declare const retryDataReplication: API.OperationMethod<RetryDataReplicationRequest, SourceServer, RetryDataReplicationError, Credentials | HttpClient.HttpClient>;
export type RetryRecoveryPlanExecutionStepError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Retries a failed `SERVER` type execution step.
 */
export declare const retryRecoveryPlanExecutionStep: API.OperationMethod<RetryRecoveryPlanExecutionStepRequest, RetryRecoveryPlanExecutionStepResponse, RetryRecoveryPlanExecutionStepError, Credentials | HttpClient.HttpClient>;
export type ReverseReplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Start replication to origin / target region - applies only to protected instances that originated in EC2. For recovery instances on target region - starts replication back to origin region. For failback instances on origin region - starts replication to target region to re-protect them.
 */
export declare const reverseReplication: API.OperationMethod<ReverseReplicationRequest, ReverseReplicationResponse, ReverseReplicationError, Credentials | HttpClient.HttpClient>;
export type StartFailbackLaunchError = ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Initiates a Job for launching the machine that is being failed back to from the specified Recovery Instance. This will run conversion on the failback client and will reboot your machine, thus completing the failback process.
 */
export declare const startFailbackLaunch: API.OperationMethod<StartFailbackLaunchRequest, StartFailbackLaunchResponse, StartFailbackLaunchError, Credentials | HttpClient.HttpClient>;
export type StartRecoveryError = ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Launches Recovery Instances for the specified Source Servers. For each Source Server you may choose a point in time snapshot to launch from, or use an on demand snapshot.
 */
export declare const startRecovery: API.OperationMethod<StartRecoveryRequest, StartRecoveryResponse, StartRecoveryError, Credentials | HttpClient.HttpClient>;
export type StartRecoveryPlanExecutionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Starts executing a Recovery Plan in `DRILL` or `RECOVERY` mode. A plan cannot have more than one execution in a non-terminal status at a time.
 */
export declare const startRecoveryPlanExecution: API.OperationMethod<StartRecoveryPlanExecutionRequest, StartRecoveryPlanExecutionResponse, StartRecoveryPlanExecutionError, Credentials | HttpClient.HttpClient>;
export type StartReplicationError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Starts replication for a stopped Source Server. This action would make the Source Server protected again and restart billing for it.
 */
export declare const startReplication: API.OperationMethod<StartReplicationRequest, StartReplicationResponse, StartReplicationError, Credentials | HttpClient.HttpClient>;
export type StartSourceNetworkRecoveryError = ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Deploy VPC for the specified Source Network and modify launch templates to use this network. The VPC will be deployed using a dedicated CloudFormation stack.
 */
export declare const startSourceNetworkRecovery: API.OperationMethod<StartSourceNetworkRecoveryRequest, StartSourceNetworkRecoveryResponse, StartSourceNetworkRecoveryError, Credentials | HttpClient.HttpClient>;
export type StartSourceNetworkReplicationError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Starts replication for a Source Network. This action would make the Source Network protected.
 */
export declare const startSourceNetworkReplication: API.OperationMethod<StartSourceNetworkReplicationRequest, StartSourceNetworkReplicationResponse, StartSourceNetworkReplicationError, Credentials | HttpClient.HttpClient>;
export type StopFailbackError = InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Stops the failback process for a specified Recovery Instance. This changes the Failback State of the Recovery Instance back to FAILBACK_NOT_STARTED.
 */
export declare const stopFailback: API.OperationMethod<StopFailbackRequest, StopFailbackResponse, StopFailbackError, Credentials | HttpClient.HttpClient>;
export type StopReplicationError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Stops replication for a Source Server. This action would make the Source Server unprotected, delete its existing snapshots and stop billing for it.
 */
export declare const stopReplication: API.OperationMethod<StopReplicationRequest, StopReplicationResponse, StopReplicationError, Credentials | HttpClient.HttpClient>;
export type StopSourceNetworkReplicationError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Stops replication for a Source Network. This action would make the Source Network unprotected.
 */
export declare const stopSourceNetworkReplication: API.OperationMethod<StopSourceNetworkReplicationRequest, StopSourceNetworkReplicationResponse, StopSourceNetworkReplicationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds or overwrites only the specified tags for the specified Elastic Disaster Recovery resource or resources. When you specify an existing tag key, the value is overwritten with the new value. Each resource can have a maximum of 50 tags. Each tag consists of a key and optional value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TerminateRecoveryInstancesError = ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Initiates a Job for terminating the EC2 resources associated with the specified Recovery Instances, and then will delete the Recovery Instances from the Elastic Disaster Recovery service.
 */
export declare const terminateRecoveryInstances: API.OperationMethod<TerminateRecoveryInstancesRequest, TerminateRecoveryInstancesResponse, TerminateRecoveryInstancesError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified set of tags from the specified set of Elastic Disaster Recovery resources.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateFailbackReplicationConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | CommonErrors;
/**
 * Allows you to update the failback replication configuration of a Recovery Instance by ID.
 */
export declare const updateFailbackReplicationConfiguration: API.OperationMethod<UpdateFailbackReplicationConfigurationRequest, UpdateFailbackReplicationConfigurationResponse, UpdateFailbackReplicationConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateLaunchConfigurationError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Updates a LaunchConfiguration by Source Server ID.
 */
export declare const updateLaunchConfiguration: API.OperationMethod<UpdateLaunchConfigurationRequest, LaunchConfiguration, UpdateLaunchConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateLaunchConfigurationTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Updates an existing Launch Configuration Template by ID.
 */
export declare const updateLaunchConfigurationTemplate: API.OperationMethod<UpdateLaunchConfigurationTemplateRequest, UpdateLaunchConfigurationTemplateResponse, UpdateLaunchConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateRecoveryPlanError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Updates a Recovery Plan's name or description.
 */
export declare const updateRecoveryPlan: API.OperationMethod<UpdateRecoveryPlanRequest, UpdateRecoveryPlanResponse, UpdateRecoveryPlanError, Credentials | HttpClient.HttpClient>;
export type UpdateRecoveryPlanExecutionStepError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Updates an execution step. Supports two actions: (1) skip a step that is in `NOT_STARTED` or `FAILED` status; (2) update the wait duration of a `WAIT` type step that is in `NOT_STARTED` status.
 */
export declare const updateRecoveryPlanExecutionStep: API.OperationMethod<UpdateRecoveryPlanExecutionStepRequest, UpdateRecoveryPlanExecutionStepResponse, UpdateRecoveryPlanExecutionStepError, Credentials | HttpClient.HttpClient>;
export type UpdateRecoveryPlanStepError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Updates a Recovery Plan step's name or configuration. Step type is immutable.
 */
export declare const updateRecoveryPlanStep: API.OperationMethod<UpdateRecoveryPlanStepRequest, UpdateRecoveryPlanStepResponse, UpdateRecoveryPlanStepError, Credentials | HttpClient.HttpClient>;
export type UpdateReplicationConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Allows you to update a ReplicationConfiguration by Source Server ID.
 */
export declare const updateReplicationConfiguration: API.OperationMethod<UpdateReplicationConfigurationRequest, ReplicationConfiguration, UpdateReplicationConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateReplicationConfigurationTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Updates a ReplicationConfigurationTemplate by ID.
 */
export declare const updateReplicationConfigurationTemplate: API.OperationMethod<UpdateReplicationConfigurationTemplateRequest, ReplicationConfigurationTemplate, UpdateReplicationConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=drs.d.ts.map