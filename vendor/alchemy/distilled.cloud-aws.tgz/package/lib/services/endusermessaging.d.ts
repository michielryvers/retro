import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly fieldList: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type BrandProfileName = string;
export type ClientToken = string | redacted.Redacted<string>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagList = Tag[];
export interface CreateBrandProfileInput {
    brandProfileName: string;
    clientToken?: string | redacted.Redacted<string>;
    deletionProtectionEnabled?: boolean;
    tags?: Tag[];
}
export type BrandProfileIdOrArn = string;
export type AmazonResourceName = string;
export type Status = "ACTIVE" | "BLOCKED" | "PAUSED" | "CANCELLED" | "FAILED" | (string & {});
export interface CreateBrandProfileOutput {
    brandProfileId: string;
    brandProfileArn: string;
    brandProfileName: string;
    status: Status;
    deletionProtectionEnabled: boolean;
    createdAt: Date;
    updatedAt: Date;
    attributesCreated: number;
}
export type BrandProfileAttributeName = string | redacted.Redacted<string>;
export type BrandProfileAttributeType = "TEXT" | "IMAGE" | "DOCUMENT" | (string & {});
export type BrandProfileAttributeValue = string | redacted.Redacted<string>;
export type AttachmentBody = Uint8Array | redacted.Redacted<Uint8Array>;
export type BrandProfileAttributeDescription = string | redacted.Redacted<string>;
export type BrandProfileAttributeCategory = string;
export interface BrandProfileAttributeInput {
    attributeName: string | redacted.Redacted<string>;
    attributeType: BrandProfileAttributeType;
    attributeValue?: string | redacted.Redacted<string>;
    attachmentBody?: Uint8Array | redacted.Redacted<Uint8Array>;
    description?: string | redacted.Redacted<string>;
    category?: string;
}
export type BrandProfileAttributeInputList = BrandProfileAttributeInput[];
export interface CreateBrandProfileAttributesInput {
    brandProfileId: string;
    attributes: BrandProfileAttributeInput[];
    clientToken?: string | redacted.Redacted<string>;
}
export type MediaDownloadUrl = string | redacted.Redacted<string>;
export interface BrandProfileAttributeOutput {
    attributeName: string | redacted.Redacted<string>;
    attributeType: BrandProfileAttributeType;
    mediaDownloadUrl?: string | redacted.Redacted<string>;
}
export type BrandProfileAttributeOutputList = BrandProfileAttributeOutput[];
export interface CreateBrandProfileAttributesOutput {
    attributes: BrandProfileAttributeOutput[];
}
export type RegistrationIdOrArn = string;
export interface CreateBrandProfileFromRegistrationInput {
    registrationId: string;
    brandProfileName: string;
    smartMatch?: boolean;
    tags?: Tag[];
    clientToken?: string | redacted.Redacted<string>;
}
export type JobId = string;
export type JobResourceIdentifier = string;
export interface JobResult {
    jobId: string;
    resourceIdentifier: string;
}
export type JobResults = JobResult[];
export interface CreateBrandProfileFromRegistrationOutput {
    results: JobResult[];
}
export type NotifyCodeConfigurationName = string;
export type CodeType = "NUMERIC" | "ALPHA" | "ALPHANUMERIC" | (string & {});
export type CodeLength = number;
export type ValidityPeriodMinutes = number;
export type MaxVerificationAttempts = number;
export interface CodeConfigurationParameters {
    codeType?: CodeType;
    codeLength?: number;
    validityPeriodMinutes?: number;
    maxAttempts?: number;
}
export type InlineTemplateBody = string | redacted.Redacted<string>;
export type DestinationCountryParameterKey = string;
export type DestinationCountryParameterValue = string | redacted.Redacted<string>;
export type DestinationCountryParameters = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export interface TextParameters {
    inlineTemplateBody?: string | redacted.Redacted<string>;
    destinationCountryParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export type LanguageCode = string;
export type VoiceId = string;
export type VoiceMessageBodyTextType = "TEXT" | "SSML" | (string & {});
export interface VoiceParameters {
    inlineTemplateBody?: string | redacted.Redacted<string>;
    languageCode?: string;
    voiceId?: string;
    voiceMessageBodyTextType?: VoiceMessageBodyTextType;
}
export type NotifyTemplateId = string;
export interface NotifyParameters {
    notifyTemplateId?: string;
    voiceId?: string;
}
export type WhatsAppTemplateName = string;
export interface WhatsAppParameters {
    whatsAppTemplateName?: string;
    languageCode?: string;
}
export interface ChannelParameters {
    text?: TextParameters;
    voice?: VoiceParameters;
    notify?: NotifyParameters;
    whatsApp?: WhatsAppParameters;
}
export interface CreateNotifyCodeConfigurationInput {
    notifyCodeConfigurationName: string;
    codeConfigurationParameters?: CodeConfigurationParameters;
    channelParameters?: ChannelParameters;
    deletionProtectionEnabled?: boolean;
    clientToken?: string | redacted.Redacted<string>;
    tags?: Tag[];
}
export type NotifyCodeConfigurationId = string;
export interface NotifyCodeConfiguration {
    notifyCodeConfigurationId: string;
    notifyCodeConfigurationArn: string;
    notifyCodeConfigurationName: string;
    codeConfigurationParameters?: CodeConfigurationParameters;
    channelParameters?: ChannelParameters;
    deletionProtectionEnabled: boolean;
    createdAt: Date;
    updatedAt: Date;
}
export interface CreateNotifyCodeConfigurationOutput {
    notifyCodeConfiguration: NotifyCodeConfiguration;
}
export type RegistrationType = string;
export type RegistrationTypeList = string[];
export interface CreateRegistrationsFromBrandProfileInput {
    brandProfileId: string;
    registrationTypes: string[];
    smartMatch?: boolean;
    clientToken?: string | redacted.Redacted<string>;
}
export interface CreateRegistrationsFromBrandProfileOutput {
    results: JobResult[];
}
export interface DeleteBrandProfileInput {
    brandProfileId: string;
}
export interface DeleteBrandProfileOutput {
    brandProfileId: string;
    brandProfileArn: string;
}
export interface DeleteBrandProfileAttributeInput {
    brandProfileId: string;
    attributeName: string | redacted.Redacted<string>;
}
export interface DeleteBrandProfileAttributeOutput {
    brandProfileId: string;
    attributeName: string | redacted.Redacted<string>;
}
export type NotifyCodeConfigurationIdOrArn = string;
export interface DeleteNotifyCodeConfigurationInput {
    notifyCodeConfigurationId: string;
}
export interface DeleteNotifyCodeConfigurationOutput {
}
export interface GetBrandProfileInput {
    brandProfileId: string;
}
export interface GetBrandProfileOutput {
    brandProfileId: string;
    brandProfileArn: string;
    brandProfileName: string;
    status: Status;
    deletionProtectionEnabled: boolean;
    createdAt: Date;
    updatedAt: Date;
}
export interface GetBrandProfileAttributeInput {
    brandProfileId: string;
    attributeName: string | redacted.Redacted<string>;
}
export interface GetBrandProfileAttributeOutput {
    attributeName: string | redacted.Redacted<string>;
    attributeType: BrandProfileAttributeType;
    attributeValue?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    category?: string;
    mediaContentType?: string;
    mediaSizeBytes?: number;
    mediaDownloadUrl?: string | redacted.Redacted<string>;
    createdAt: Date;
    updatedAt: Date;
}
export interface GetJobInput {
    jobId: string;
}
export type JobStatus = "SUCCESS" | "PROCESSING" | "FAILED" | (string & {});
export type JobOperationType = string;
export type JobErrorCode = string;
export type JobErrorMessage = string;
export type JobResourceType = "REGISTRATION" | "BRAND_PROFILE" | (string & {});
export type JobResourceId = string;
export interface JobResource {
    resourceType: JobResourceType;
    resourceId: string;
    resourceArn: string;
}
export type JobResourceList = JobResource[];
export interface Job {
    jobId: string;
    status: JobStatus;
    operationType: string;
    createdAt: Date;
    updatedAt: Date;
    brandProfileId?: string;
    errorCode?: string;
    errorMessage?: string;
    resources?: JobResource[];
}
export interface GetNotifyCodeConfigurationInput {
    notifyCodeConfigurationId: string;
}
export interface GetNotifyCodeConfigurationOutput {
    notifyCodeConfiguration: NotifyCodeConfiguration;
}
export type NextToken = string;
export type MaxResults = number;
export interface ListBrandProfileAttributesInput {
    brandProfileId: string;
    nextToken?: string;
    maxResults?: number;
}
export interface BrandProfileAttributeSummary {
    attributeName: string | redacted.Redacted<string>;
    attributeType: BrandProfileAttributeType;
    description?: string | redacted.Redacted<string>;
    category?: string;
    createdAt: Date;
    updatedAt: Date;
}
export type BrandProfileAttributeSummaryList = BrandProfileAttributeSummary[];
export interface ListBrandProfileAttributesOutput {
    brandProfileAttributes: BrandProfileAttributeSummary[];
    nextToken?: string;
}
export interface ListBrandProfilesInput {
    nextToken?: string;
    maxResults?: number;
}
export interface BrandProfileInfo {
    brandProfileId: string;
    brandProfileArn: string;
    brandProfileName: string;
    status: Status;
    deletionProtectionEnabled: boolean;
    createdAt: Date;
    updatedAt: Date;
}
export type BrandProfileInfoList = BrandProfileInfo[];
export interface ListBrandProfilesOutput {
    brandProfiles: BrandProfileInfo[];
    nextToken?: string;
}
export interface ListJobsInput {
    maxResults?: number;
    nextToken?: string;
    status?: JobStatus;
    brandProfileId?: string;
    operationType?: string;
}
export interface JobSummary {
    jobId: string;
    status: JobStatus;
    operationType: string;
    createdAt: Date;
    updatedAt: Date;
    brandProfileId?: string;
    errorCode?: string;
    errorMessage?: string;
    resources?: JobResource[];
}
export type JobSummaryList = JobSummary[];
export interface ListJobsOutput {
    jobs: JobSummary[];
    nextToken?: string;
}
export interface ListNotifyCodeConfigurationsInput {
    maxResults?: number;
    nextToken?: string;
}
export type NotifyCodeConfigurationList = NotifyCodeConfiguration[];
export interface ListNotifyCodeConfigurationsOutput {
    notifyCodeConfigurations: NotifyCodeConfiguration[];
    nextToken?: string;
}
export interface ListRegistrationsFromBrandProfileInput {
    brandProfileId: string;
    maxResults?: number;
    nextToken?: string;
}
export type RegistrationId = string;
export interface RegistrationAssociationSummary {
    registrationId: string;
    registrationType: string;
    createdAt: Date;
    smartMatchUsed: boolean;
}
export type RegistrationAssociationSummaryList = RegistrationAssociationSummary[];
export interface ListRegistrationsFromBrandProfileOutput {
    registrationAssociations: RegistrationAssociationSummary[];
    nextToken?: string;
}
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags?: Tag[];
}
export type NotifyChannel = "TEXT" | "VOICE" | "WHATSAPP" | (string & {});
export type DestinationIdentity = string | redacted.Redacted<string>;
export type OriginationIdentity = string;
export type ConfigurationSetName = string;
export type ContextKey = string | redacted.Redacted<string>;
export type ContextValue = string | redacted.Redacted<string>;
export type ContextMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export type ReferenceId = string;
export interface SendNotifyCodeVerificationInput {
    channel: NotifyChannel;
    destinationIdentity: string | redacted.Redacted<string>;
    originationIdentity: string;
    notifyCodeConfiguration?: string;
    overrideChannelParameters?: ChannelParameters;
    overrideCodeConfigurationParameters?: CodeConfigurationParameters;
    configurationSetName?: string;
    context?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    referenceId?: string;
}
export type VerificationId = string;
export type MessageId = string;
export interface SendNotifyCodeVerificationOutput {
    verificationId: string;
    messageId: string;
}
export interface TagResourceInput {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateBrandProfileInput {
    brandProfileId: string;
    brandProfileName?: string;
    deletionProtectionEnabled?: boolean;
}
export interface UpdateBrandProfileOutput {
    brandProfileId: string;
    brandProfileArn: string;
    brandProfileName: string;
    status: Status;
    deletionProtectionEnabled: boolean;
    createdAt: Date;
    updatedAt: Date;
}
export interface UpdateBrandProfileAttributeInput {
    brandProfileId: string;
    attributeName: string | redacted.Redacted<string>;
    attributeValue?: string | redacted.Redacted<string>;
    attachmentBody?: Uint8Array;
    description?: string | redacted.Redacted<string>;
    category?: string;
}
export interface UpdateBrandProfileAttributeOutput {
    attributeName: string | redacted.Redacted<string>;
    attributeType: BrandProfileAttributeType;
    attributeValue?: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string>;
    category?: string;
    mediaContentType?: string;
    mediaSizeBytes?: number;
    createdAt: Date;
    updatedAt: Date;
}
export type OnAttributeConflict = "REPLACE" | "PRESERVE" | (string & {});
export interface UpdateBrandProfileFromRegistrationInput {
    brandProfileId: string;
    registrationId: string;
    smartMatch?: boolean;
    onAttributeConflict?: OnAttributeConflict;
    clientToken?: string | redacted.Redacted<string>;
}
export interface UpdateBrandProfileFromRegistrationOutput {
    results: JobResult[];
}
export interface UpdateCodeConfigurationParameters {
    codeType?: CodeType;
    codeLength?: number;
    validityPeriodMinutes?: number;
    maxAttempts?: number;
}
export type UpdateInlineTemplateBody = string | redacted.Redacted<string>;
export type UpdateDestinationCountryParameters = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export interface UpdateTextParameters {
    inlineTemplateBody?: string | redacted.Redacted<string>;
    destinationCountryParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export type UpdateLanguageCode = string;
export type UpdateVoiceId = string;
export interface UpdateVoiceParameters {
    inlineTemplateBody?: string | redacted.Redacted<string>;
    languageCode?: string;
    voiceId?: string;
    voiceMessageBodyTextType?: VoiceMessageBodyTextType;
}
export type UpdateNotifyTemplateId = string;
export interface UpdateNotifyParameters {
    notifyTemplateId?: string;
    voiceId?: string;
}
export type UpdateWhatsAppTemplateName = string;
export interface UpdateWhatsAppParameters {
    whatsAppTemplateName?: string;
    languageCode?: string;
}
export interface UpdateChannelParameters {
    text?: UpdateTextParameters;
    voice?: UpdateVoiceParameters;
    notify?: UpdateNotifyParameters;
    whatsApp?: UpdateWhatsAppParameters;
}
export interface UpdateNotifyCodeConfigurationInput {
    notifyCodeConfigurationId: string;
    notifyCodeConfigurationName?: string;
    codeConfigurationParameters?: UpdateCodeConfigurationParameters;
    channelParameters?: UpdateChannelParameters;
    deletionProtectionEnabled?: boolean;
}
export interface UpdateNotifyCodeConfigurationOutput {
    notifyCodeConfiguration: NotifyCodeConfiguration;
}
export type RegistrationIdList = string[];
export interface UpdateRegistrationsFromBrandProfileInput {
    brandProfileId: string;
    registrationIds: string[];
    smartMatch?: boolean;
    onAttributeConflict?: OnAttributeConflict;
    clientToken?: string | redacted.Redacted<string>;
}
export interface UpdateRegistrationsFromBrandProfileOutput {
    results: JobResult[];
}
export type VerificationCode = string | redacted.Redacted<string>;
export interface ValidateNotifyCodeVerificationInput {
    destinationIdentity: string | redacted.Redacted<string>;
    referenceId?: string;
    code: string | redacted.Redacted<string>;
}
export type VerificationStatus = "VALID" | "INVALID" | (string & {});
export interface ValidateNotifyCodeVerificationOutput {
    status: VerificationStatus;
}
export interface ValidationExceptionField {
    path: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type CreateBrandProfileError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a brand profile. A brand profile is a lightweight container that holds your brand identity information as flexible attributes. After you create a brand profile, use the CreateBrandProfileAttributes operation to add company information, addresses, compliance documents, and logos.
 */
export declare const createBrandProfile: API.OperationMethod<CreateBrandProfileInput, CreateBrandProfileOutput, CreateBrandProfileError, Credentials | HttpClient.HttpClient>;
export type CreateBrandProfileAttributesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates up to 10 attributes for a brand profile in a single request. For attributes of type IMAGE or DOCUMENT, the response includes a presigned Amazon S3 URL that you use to upload the media. This operation is atomic: either all of the attributes are created, or none of them are.
 */
export declare const createBrandProfileAttributes: API.OperationMethod<CreateBrandProfileAttributesInput, CreateBrandProfileAttributesOutput, CreateBrandProfileAttributesError, Credentials | HttpClient.HttpClient>;
export type CreateBrandProfileFromRegistrationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a brand profile and populates its attributes from an existing registration. This operation runs asynchronously. Use the GetJob operation to track its progress.
 */
export declare const createBrandProfileFromRegistration: API.OperationMethod<CreateBrandProfileFromRegistrationInput, CreateBrandProfileFromRegistrationOutput, CreateBrandProfileFromRegistrationError, Credentials | HttpClient.HttpClient>;
export type CreateNotifyCodeConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a notify code configuration. A notify code configuration is a reusable policy that defines how one-time passcodes are generated and rendered, including the code type, length, validity period, maximum number of attempts, and channel templates.
 */
export declare const createNotifyCodeConfiguration: API.OperationMethod<CreateNotifyCodeConfigurationInput, CreateNotifyCodeConfigurationOutput, CreateNotifyCodeConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateRegistrationsFromBrandProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates one or more registrations in the DRAFT state and prefills their fields from the attributes of a brand profile. This operation runs asynchronously. Use the GetJob operation to track its progress.
 */
export declare const createRegistrationsFromBrandProfile: API.OperationMethod<CreateRegistrationsFromBrandProfileInput, CreateRegistrationsFromBrandProfileOutput, CreateRegistrationsFromBrandProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteBrandProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a brand profile. This operation also deletes the attributes of the profile and any associated media. The request fails if deletion protection is enabled for the profile.
 */
export declare const deleteBrandProfile: API.OperationMethod<DeleteBrandProfileInput, DeleteBrandProfileOutput, DeleteBrandProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteBrandProfileAttributeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a brand profile attribute. If the attribute stores media, this operation also deletes the associated media.
 */
export declare const deleteBrandProfileAttribute: API.OperationMethod<DeleteBrandProfileAttributeInput, DeleteBrandProfileAttributeOutput, DeleteBrandProfileAttributeError, Credentials | HttpClient.HttpClient>;
export type DeleteNotifyCodeConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a notify code configuration. Verifications that are already in progress are not affected, because they capture the policy at the time that the passcode was sent.
 */
export declare const deleteNotifyCodeConfiguration: API.OperationMethod<DeleteNotifyCodeConfigurationInput, DeleteNotifyCodeConfigurationOutput, DeleteNotifyCodeConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetBrandProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the metadata for a brand profile, including its name, status, deletion protection setting, and timestamps. To retrieve the attributes of the profile, use the ListBrandProfileAttributes operation.
 */
export declare const getBrandProfile: API.OperationMethod<GetBrandProfileInput, GetBrandProfileOutput, GetBrandProfileError, Credentials | HttpClient.HttpClient>;
export type GetBrandProfileAttributeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a single brand profile attribute.
 */
export declare const getBrandProfileAttribute: API.OperationMethod<GetBrandProfileAttributeInput, GetBrandProfileAttributeOutput, GetBrandProfileAttributeError, Credentials | HttpClient.HttpClient>;
export type GetJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the current state of an asynchronous job, including its status and any resources that it created or updated.
 */
export declare const getJob: API.OperationMethod<GetJobInput, Job, GetJobError, Credentials | HttpClient.HttpClient>;
export type GetNotifyCodeConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a notify code configuration.
 */
export declare const getNotifyCodeConfiguration: API.OperationMethod<GetNotifyCodeConfigurationInput, GetNotifyCodeConfigurationOutput, GetNotifyCodeConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListBrandProfileAttributesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of the attributes for a brand profile.
 */
export declare const listBrandProfileAttributes: API.PaginatedOperationMethod<ListBrandProfileAttributesInput, ListBrandProfileAttributesOutput, ListBrandProfileAttributesError, Credentials | HttpClient.HttpClient, BrandProfileAttributeSummary>;
export type ListBrandProfilesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of the brand profiles in your account. Use the nextToken parameter to retrieve additional results.
 */
export declare const listBrandProfiles: API.PaginatedOperationMethod<ListBrandProfilesInput, ListBrandProfilesOutput, ListBrandProfilesError, Credentials | HttpClient.HttpClient, BrandProfileInfo>;
export type ListJobsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of the asynchronous jobs in your account. You can filter the results by status, brand profile, or operation type.
 */
export declare const listJobs: API.PaginatedOperationMethod<ListJobsInput, ListJobsOutput, ListJobsError, Credentials | HttpClient.HttpClient, JobSummary>;
export type ListNotifyCodeConfigurationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of the notify code configurations in your account.
 */
export declare const listNotifyCodeConfigurations: API.PaginatedOperationMethod<ListNotifyCodeConfigurationsInput, ListNotifyCodeConfigurationsOutput, ListNotifyCodeConfigurationsError, Credentials | HttpClient.HttpClient, NotifyCodeConfiguration>;
export type ListRegistrationsFromBrandProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of the registrations that were created from a brand profile through the synchronization operations.
 */
export declare const listRegistrationsFromBrandProfile: API.PaginatedOperationMethod<ListRegistrationsFromBrandProfileInput, ListRegistrationsFromBrandProfileOutput, ListRegistrationsFromBrandProfileError, Credentials | HttpClient.HttpClient, RegistrationAssociationSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the tags that are associated with a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type SendNotifyCodeVerificationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Generates a one-time passcode and delivers it to a recipient over the requested channel. The passcode policy is captured from the referenced notify code configuration at the time of the request, so later updates to the configuration do not affect verifications that are already in progress.
 */
export declare const sendNotifyCodeVerification: API.OperationMethod<SendNotifyCodeVerificationInput, SendNotifyCodeVerificationOutput, SendNotifyCodeVerificationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds or overwrites the tags on a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the specified tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBrandProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the name or the deletion protection setting of a brand profile. To change the information that is stored in the profile, use the brand profile attribute operations.
 */
export declare const updateBrandProfile: API.OperationMethod<UpdateBrandProfileInput, UpdateBrandProfileOutput, UpdateBrandProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateBrandProfileAttributeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the value, description, or category of an existing brand profile attribute.
 */
export declare const updateBrandProfileAttribute: API.OperationMethod<UpdateBrandProfileAttributeInput, UpdateBrandProfileAttributeOutput, UpdateBrandProfileAttributeError, Credentials | HttpClient.HttpClient>;
export type UpdateBrandProfileFromRegistrationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Imports or refreshes the attributes of an existing brand profile from an existing registration. This operation runs asynchronously. Use the GetJob operation to track its progress.
 */
export declare const updateBrandProfileFromRegistration: API.OperationMethod<UpdateBrandProfileFromRegistrationInput, UpdateBrandProfileFromRegistrationOutput, UpdateBrandProfileFromRegistrationError, Credentials | HttpClient.HttpClient>;
export type UpdateNotifyCodeConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the mutable fields of a notify code configuration. Only the fields that you supply are changed. For the template and language fields, supplying an empty value clears the currently stored value.
 */
export declare const updateNotifyCodeConfiguration: API.OperationMethod<UpdateNotifyCodeConfigurationInput, UpdateNotifyCodeConfigurationOutput, UpdateNotifyCodeConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateRegistrationsFromBrandProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Repushes the attributes of a brand profile into existing DRAFT registrations. This operation runs asynchronously. Use the GetJob operation to track its progress.
 */
export declare const updateRegistrationsFromBrandProfile: API.OperationMethod<UpdateRegistrationsFromBrandProfileInput, UpdateRegistrationsFromBrandProfileOutput, UpdateRegistrationsFromBrandProfileError, Credentials | HttpClient.HttpClient>;
export type ValidateNotifyCodeVerificationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Validates a one-time passcode that a recipient submitted. Validation succeeds when the passcode matches, the validity period has not elapsed, and the maximum number of attempts has not been exceeded.
 */
export declare const validateNotifyCodeVerification: API.OperationMethod<ValidateNotifyCodeVerificationInput, ValidateNotifyCodeVerificationOutput, ValidateNotifyCodeVerificationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=endusermessaging.d.ts.map