import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type LandingZoneVersion = string;
export type RemediationType = "INHERITANCE_DRIFT" | (string & {});
export type RemediationTypes = RemediationType[];
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type Manifest = unknown;
export interface CreateLandingZoneInput {
    version: string;
    remediationTypes?: RemediationType[];
    tags?: {
        [key: string]: string | undefined;
    };
    manifest?: any;
}
export type Arn = string;
export type OperationIdentifier = string;
export interface CreateLandingZoneOutput {
    arn: string;
    operationIdentifier: string;
}
export interface DeleteLandingZoneInput {
    landingZoneIdentifier: string;
}
export interface DeleteLandingZoneOutput {
    operationIdentifier: string;
}
export interface DisableBaselineInput {
    enabledBaselineIdentifier: string;
}
export interface DisableBaselineOutput {
    operationIdentifier: string;
}
export type ControlIdentifier = string;
export type TargetIdentifier = string;
export interface DisableControlInput {
    controlIdentifier?: string;
    targetIdentifier?: string;
    enabledControlIdentifier?: string;
}
export interface DisableControlOutput {
    operationIdentifier: string;
}
export type BaselineVersion = string;
export type EnabledBaselineParameterDocument = unknown;
export interface EnabledBaselineParameter {
    key: string;
    value: any;
}
export type EnabledBaselineParameters = EnabledBaselineParameter[];
export interface EnableBaselineInput {
    baselineVersion: string;
    parameters?: EnabledBaselineParameter[];
    baselineIdentifier: string;
    targetIdentifier: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface EnableBaselineOutput {
    operationIdentifier: string;
    arn: string;
}
export interface EnabledControlParameter {
    key: string;
    value: any;
}
export type EnabledControlParameters = EnabledControlParameter[];
export interface EnableControlInput {
    controlIdentifier: string;
    targetIdentifier: string;
    tags?: {
        [key: string]: string | undefined;
    };
    parameters?: EnabledControlParameter[];
}
export interface EnableControlOutput {
    operationIdentifier: string;
    arn?: string;
}
export type BaselineArn = string;
export interface GetBaselineInput {
    baselineIdentifier: string;
}
export interface GetBaselineOutput {
    arn: string;
    name: string;
    description?: string;
}
export interface GetBaselineOperationInput {
    operationIdentifier: string;
}
export type BaselineOperationType = "ENABLE_BASELINE" | "DISABLE_BASELINE" | "UPDATE_ENABLED_BASELINE" | "RESET_ENABLED_BASELINE" | (string & {});
export type BaselineOperationStatus = "SUCCEEDED" | "FAILED" | "IN_PROGRESS" | (string & {});
export interface BaselineOperation {
    operationIdentifier?: string;
    operationType?: BaselineOperationType;
    status?: BaselineOperationStatus;
    startTime?: Date;
    endTime?: Date;
    statusMessage?: string;
}
export interface GetBaselineOperationOutput {
    baselineOperation: BaselineOperation;
}
export interface GetControlOperationInput {
    operationIdentifier: string;
}
export type ControlOperationType = "ENABLE_CONTROL" | "DISABLE_CONTROL" | "UPDATE_ENABLED_CONTROL" | "RESET_ENABLED_CONTROL" | (string & {});
export type ControlOperationStatus = "SUCCEEDED" | "FAILED" | "IN_PROGRESS" | (string & {});
export interface ControlOperation {
    operationType?: ControlOperationType;
    startTime?: Date;
    endTime?: Date;
    status?: ControlOperationStatus;
    statusMessage?: string;
    operationIdentifier?: string;
    controlIdentifier?: string;
    targetIdentifier?: string;
    enabledControlIdentifier?: string;
}
export interface GetControlOperationOutput {
    controlOperation: ControlOperation;
}
export interface GetEnabledBaselineInput {
    enabledBaselineIdentifier: string;
}
export type EnabledBaselineDriftStatus = "IN_SYNC" | "DRIFTED" | (string & {});
export interface EnabledBaselineInheritanceDrift {
    status?: EnabledBaselineDriftStatus;
}
export interface EnabledBaselineDriftTypes {
    inheritance?: EnabledBaselineInheritanceDrift;
}
export interface EnabledBaselineDriftStatusSummary {
    types?: EnabledBaselineDriftTypes;
}
export type EnablementStatus = "SUCCEEDED" | "FAILED" | "UNDER_CHANGE" | (string & {});
export interface EnablementStatusSummary {
    status?: EnablementStatus;
    lastOperationIdentifier?: string;
}
export interface EnabledBaselineParameterSummary {
    key: string;
    value: any;
}
export type EnabledBaselineParameterSummaries = EnabledBaselineParameterSummary[];
export interface EnabledBaselineDetails {
    arn: string;
    baselineIdentifier: string;
    baselineVersion?: string;
    driftStatusSummary?: EnabledBaselineDriftStatusSummary;
    targetIdentifier: string;
    parentIdentifier?: string;
    statusSummary: EnablementStatusSummary;
    parameters?: EnabledBaselineParameterSummary[];
}
export interface GetEnabledBaselineOutput {
    enabledBaselineDetails?: EnabledBaselineDetails;
}
export interface GetEnabledControlInput {
    enabledControlIdentifier: string;
}
export type DriftStatus = "DRIFTED" | "IN_SYNC" | "NOT_CHECKING" | "UNKNOWN" | (string & {});
export interface EnabledControlInheritanceDrift {
    status?: DriftStatus;
}
export interface EnabledControlResourceDrift {
    status?: DriftStatus;
}
export interface EnabledControlDriftTypes {
    inheritance?: EnabledControlInheritanceDrift;
    resource?: EnabledControlResourceDrift;
}
export interface DriftStatusSummary {
    driftStatus?: DriftStatus;
    types?: EnabledControlDriftTypes;
}
export type ParentIdentifier = string;
export type RegionName = string;
export interface Region {
    name?: string;
}
export type TargetRegions = Region[];
export interface EnabledControlParameterSummary {
    key: string;
    value: any;
}
export type EnabledControlParameterSummaries = EnabledControlParameterSummary[];
export interface EnabledControlDetails {
    arn?: string;
    controlIdentifier?: string;
    targetIdentifier?: string;
    statusSummary?: EnablementStatusSummary;
    driftStatusSummary?: DriftStatusSummary;
    parentIdentifier?: string;
    targetRegions?: Region[];
    parameters?: EnabledControlParameterSummary[];
}
export interface GetEnabledControlOutput {
    enabledControlDetails: EnabledControlDetails;
}
export interface GetLandingZoneInput {
    landingZoneIdentifier: string;
}
export type LandingZoneStatus = "ACTIVE" | "PROCESSING" | "FAILED" | (string & {});
export type LandingZoneDriftStatus = "DRIFTED" | "IN_SYNC" | (string & {});
export interface LandingZoneDriftStatusSummary {
    status?: LandingZoneDriftStatus;
}
export interface LandingZoneDetail {
    version: string;
    remediationTypes?: RemediationType[];
    arn?: string;
    status?: LandingZoneStatus;
    latestAvailableVersion?: string;
    driftStatus?: LandingZoneDriftStatusSummary;
    manifest: any;
}
export interface GetLandingZoneOutput {
    landingZone: LandingZoneDetail;
}
export interface GetLandingZoneOperationInput {
    operationIdentifier: string;
}
export type LandingZoneOperationType = "DELETE" | "CREATE" | "UPDATE" | "RESET" | (string & {});
export type LandingZoneOperationStatus = "SUCCEEDED" | "FAILED" | "IN_PROGRESS" | (string & {});
export interface LandingZoneOperationDetail {
    operationType?: LandingZoneOperationType;
    operationIdentifier?: string;
    status?: LandingZoneOperationStatus;
    startTime?: Date;
    endTime?: Date;
    statusMessage?: string;
}
export interface GetLandingZoneOperationOutput {
    operationDetails: LandingZoneOperationDetail;
}
export type ListBaselinesMaxResults = number;
export interface ListBaselinesInput {
    nextToken?: string;
    maxResults?: number;
}
export interface BaselineSummary {
    arn: string;
    name: string;
    description?: string;
}
export type Baselines = BaselineSummary[];
export interface ListBaselinesOutput {
    baselines: BaselineSummary[];
    nextToken?: string;
}
export type ControlIdentifiers = string[];
export type TargetIdentifiers = string[];
export type EnabledControlIdentifiers = string[];
export type ControlOperationStatuses = ControlOperationStatus[];
export type ControlOperationTypes = ControlOperationType[];
export interface ControlOperationFilter {
    controlIdentifiers?: string[];
    targetIdentifiers?: string[];
    enabledControlIdentifiers?: string[];
    statuses?: ControlOperationStatus[];
    controlOperationTypes?: ControlOperationType[];
}
export type ListControlOperationsNextToken = string;
export type ListControlOperationsMaxResults = number;
export interface ListControlOperationsInput {
    filter?: ControlOperationFilter;
    nextToken?: string;
    maxResults?: number;
}
export interface ControlOperationSummary {
    operationType?: ControlOperationType;
    startTime?: Date;
    endTime?: Date;
    status?: ControlOperationStatus;
    statusMessage?: string;
    operationIdentifier?: string;
    controlIdentifier?: string;
    targetIdentifier?: string;
    enabledControlIdentifier?: string;
}
export type ControlOperations = ControlOperationSummary[];
export interface ListControlOperationsOutput {
    controlOperations: ControlOperationSummary[];
    nextToken?: string;
}
export type EnabledBaselineTargetIdentifiers = string[];
export type EnabledBaselineBaselineIdentifiers = string[];
export type EnabledBaselineParentIdentifiers = string[];
export type EnabledBaselineEnablementStatuses = EnablementStatus[];
export type EnabledBaselineDriftStatuses = EnabledBaselineDriftStatus[];
export interface EnabledBaselineFilter {
    targetIdentifiers?: string[];
    baselineIdentifiers?: string[];
    parentIdentifiers?: string[];
    statuses?: EnablementStatus[];
    inheritanceDriftStatuses?: EnabledBaselineDriftStatus[];
}
export type ListEnabledBaselinesNextToken = string;
export type ListEnabledBaselinesMaxResults = number;
export interface ListEnabledBaselinesInput {
    filter?: EnabledBaselineFilter;
    nextToken?: string;
    maxResults?: number;
    includeChildren?: boolean;
}
export interface EnabledBaselineSummary {
    arn: string;
    baselineIdentifier: string;
    baselineVersion?: string;
    driftStatusSummary?: EnabledBaselineDriftStatusSummary;
    targetIdentifier: string;
    parentIdentifier?: string;
    statusSummary: EnablementStatusSummary;
}
export type EnabledBaselines = EnabledBaselineSummary[];
export interface ListEnabledBaselinesOutput {
    enabledBaselines: EnabledBaselineSummary[];
    nextToken?: string;
}
export type MaxResults = number;
export type EnablementStatuses = EnablementStatus[];
export type DriftStatuses = DriftStatus[];
export type ParentIdentifiers = string[];
export interface EnabledControlFilter {
    controlIdentifiers?: string[];
    statuses?: EnablementStatus[];
    driftStatuses?: DriftStatus[];
    parentIdentifiers?: string[];
    inheritanceDriftStatuses?: DriftStatus[];
    resourceDriftStatuses?: DriftStatus[];
}
export interface ListEnabledControlsInput {
    targetIdentifier?: string;
    nextToken?: string;
    maxResults?: number;
    filter?: EnabledControlFilter;
    includeChildren?: boolean;
}
export interface EnabledControlSummary {
    arn?: string;
    controlIdentifier?: string;
    targetIdentifier?: string;
    statusSummary?: EnablementStatusSummary;
    driftStatusSummary?: DriftStatusSummary;
    parentIdentifier?: string;
}
export type EnabledControls = EnabledControlSummary[];
export interface ListEnabledControlsOutput {
    enabledControls: EnabledControlSummary[];
    nextToken?: string;
}
export type LandingZoneOperationTypes = LandingZoneOperationType[];
export type LandingZoneOperationStatuses = LandingZoneOperationStatus[];
export interface LandingZoneOperationFilter {
    types?: LandingZoneOperationType[];
    statuses?: LandingZoneOperationStatus[];
}
export type ListLandingZoneOperationsMaxResults = number;
export interface ListLandingZoneOperationsInput {
    filter?: LandingZoneOperationFilter;
    nextToken?: string;
    maxResults?: number;
}
export interface LandingZoneOperationSummary {
    operationType?: LandingZoneOperationType;
    operationIdentifier?: string;
    status?: LandingZoneOperationStatus;
}
export type LandingZoneOperations = LandingZoneOperationSummary[];
export interface ListLandingZoneOperationsOutput {
    landingZoneOperations: LandingZoneOperationSummary[];
    nextToken?: string;
}
export type ListLandingZonesMaxResults = number;
export interface ListLandingZonesInput {
    nextToken?: string;
    maxResults?: number;
}
export interface LandingZoneSummary {
    arn?: string;
}
export type LandingZoneSummaries = LandingZoneSummary[];
export interface ListLandingZonesOutput {
    landingZones: LandingZoneSummary[];
    nextToken?: string;
}
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags: {
        [key: string]: string | undefined;
    };
}
export interface ResetEnabledBaselineInput {
    enabledBaselineIdentifier: string;
}
export interface ResetEnabledBaselineOutput {
    operationIdentifier: string;
}
export interface ResetEnabledControlInput {
    enabledControlIdentifier: string;
}
export interface ResetEnabledControlOutput {
    operationIdentifier: string;
}
export interface ResetLandingZoneInput {
    landingZoneIdentifier: string;
}
export interface ResetLandingZoneOutput {
    operationIdentifier: string;
}
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type TagKeys = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateEnabledBaselineInput {
    baselineVersion: string;
    parameters?: EnabledBaselineParameter[];
    enabledBaselineIdentifier: string;
}
export interface UpdateEnabledBaselineOutput {
    operationIdentifier: string;
}
export interface UpdateEnabledControlInput {
    parameters: EnabledControlParameter[];
    enabledControlIdentifier: string;
}
export interface UpdateEnabledControlOutput {
    operationIdentifier: string;
}
export interface UpdateLandingZoneInput {
    version: string;
    remediationTypes?: RemediationType[];
    landingZoneIdentifier: string;
    manifest?: any;
}
export interface UpdateLandingZoneOutput {
    operationIdentifier: string;
}
export type CreateLandingZoneError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates a new landing zone. This API call starts an asynchronous operation that creates and configures a landing zone, based on the parameters specified in the manifest JSON file.
 */
export declare const createLandingZone: API.OperationMethod<CreateLandingZoneInput, CreateLandingZoneOutput, CreateLandingZoneError, Credentials | HttpClient.HttpClient>;
export type DeleteLandingZoneError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Decommissions a landing zone. This API call starts an asynchronous operation that deletes Amazon Web Services Control Tower resources deployed in accounts managed by Amazon Web Services Control Tower.
 *
 * Decommissioning a landing zone is a process with significant consequences, and it cannot be undone. We strongly recommend that you perform this decommissioning process only if you intend to stop using your landing zone.
 */
export declare const deleteLandingZone: API.OperationMethod<DeleteLandingZoneInput, DeleteLandingZoneOutput, DeleteLandingZoneError, Credentials | HttpClient.HttpClient>;
export type DisableBaselineError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Disable an `EnabledBaseline` resource on the specified Target. This API starts an asynchronous operation to remove all resources deployed as part of the baseline enablement. The resource will vary depending on the enabled baseline. For usage examples, see *the Amazon Web Services Control Tower User Guide* .
 */
export declare const disableBaseline: API.OperationMethod<DisableBaselineInput, DisableBaselineOutput, DisableBaselineError, Credentials | HttpClient.HttpClient>;
export type DisableControlError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This API call turns off a control. It starts an asynchronous operation that deletes Amazon Web Services resources on the specified organizational unit and the accounts it contains. The resources will vary according to the control that you specify. For usage examples, see the *Controls Reference Guide* .
 */
export declare const disableControl: API.OperationMethod<DisableControlInput, DisableControlOutput, DisableControlError, Credentials | HttpClient.HttpClient>;
export type EnableBaselineError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Enable (apply) a `Baseline` to a Target. This API starts an asynchronous operation to deploy resources specified by the `Baseline` to the specified Target. For usage examples, see *the Amazon Web Services Control Tower User Guide* .
 */
export declare const enableBaseline: API.OperationMethod<EnableBaselineInput, EnableBaselineOutput, EnableBaselineError, Credentials | HttpClient.HttpClient>;
export type EnableControlError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This API call activates a control. It starts an asynchronous operation that creates Amazon Web Services resources on the specified organizational unit and the accounts it contains. The resources created will vary according to the control that you specify. For usage examples, see the *Controls Reference Guide* .
 */
export declare const enableControl: API.OperationMethod<EnableControlInput, EnableControlOutput, EnableControlError, Credentials | HttpClient.HttpClient>;
export type GetBaselineError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Retrieve details about an existing `Baseline` resource by specifying its identifier. For usage examples, see *the Amazon Web Services Control Tower User Guide* .
 */
export declare const getBaseline: API.OperationMethod<GetBaselineInput, GetBaselineOutput, GetBaselineError, Credentials | HttpClient.HttpClient>;
export type GetBaselineOperationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Returns the details of an asynchronous baseline operation, as initiated by any of these APIs: `EnableBaseline`, `DisableBaseline`, `UpdateEnabledBaseline`, `ResetEnabledBaseline`. A status message is displayed in case of operation failure. For usage examples, see *the Amazon Web Services Control Tower User Guide* .
 */
export declare const getBaselineOperation: API.OperationMethod<GetBaselineOperationInput, GetBaselineOperationOutput, GetBaselineOperationError, Credentials | HttpClient.HttpClient>;
export type GetControlOperationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the status of a particular `EnableControl` or `DisableControl` operation. Displays a message in case of error. Details for an operation are available for 90 days. For usage examples, see the *Controls Reference Guide* .
 */
export declare const getControlOperation: API.OperationMethod<GetControlOperationInput, GetControlOperationOutput, GetControlOperationError, Credentials | HttpClient.HttpClient>;
export type GetEnabledBaselineError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Retrieve details of an `EnabledBaseline` resource by specifying its identifier.
 */
export declare const getEnabledBaseline: API.OperationMethod<GetEnabledBaselineInput, GetEnabledBaselineOutput, GetEnabledBaselineError, Credentials | HttpClient.HttpClient>;
export type GetEnabledControlError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about an enabled control. For usage examples, see the *Controls Reference Guide* .
 */
export declare const getEnabledControl: API.OperationMethod<GetEnabledControlInput, GetEnabledControlOutput, GetEnabledControlError, Credentials | HttpClient.HttpClient>;
export type GetLandingZoneError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Returns details about the landing zone. Displays a message in case of error.
 */
export declare const getLandingZone: API.OperationMethod<GetLandingZoneInput, GetLandingZoneOutput, GetLandingZoneError, Credentials | HttpClient.HttpClient>;
export type GetLandingZoneOperationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Returns the status of the specified landing zone operation. Details for an operation are available for 90 days.
 */
export declare const getLandingZoneOperation: API.OperationMethod<GetLandingZoneOperationInput, GetLandingZoneOperationOutput, GetLandingZoneOperationError, Credentials | HttpClient.HttpClient>;
export type ListBaselinesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Returns a summary list of all available baselines. For usage examples, see *the Amazon Web Services Control Tower User Guide* .
 */
export declare const listBaselines: API.PaginatedOperationMethod<ListBaselinesInput, ListBaselinesOutput, ListBaselinesError, Credentials | HttpClient.HttpClient, BaselineSummary>;
export type ListControlOperationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides a list of operations in progress or queued. For usage examples, see ListControlOperation examples.
 */
export declare const listControlOperations: API.PaginatedOperationMethod<ListControlOperationsInput, ListControlOperationsOutput, ListControlOperationsError, Credentials | HttpClient.HttpClient, ControlOperationSummary>;
export type ListEnabledBaselinesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of summaries describing `EnabledBaseline` resources. You can filter the list by the corresponding `Baseline` or `Target` of the `EnabledBaseline` resources. For usage examples, see *the Amazon Web Services Control Tower User Guide* .
 */
export declare const listEnabledBaselines: API.PaginatedOperationMethod<ListEnabledBaselinesInput, ListEnabledBaselinesOutput, ListEnabledBaselinesError, Credentials | HttpClient.HttpClient, EnabledBaselineSummary>;
export type ListEnabledControlsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the controls enabled by Amazon Web Services Control Tower on the specified organizational unit and the accounts it contains. For usage examples, see the *Controls Reference Guide* .
 */
export declare const listEnabledControls: API.PaginatedOperationMethod<ListEnabledControlsInput, ListEnabledControlsOutput, ListEnabledControlsError, Credentials | HttpClient.HttpClient, EnabledControlSummary>;
export type ListLandingZoneOperationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists all landing zone operations from the past 90 days. Results are sorted by time, with the most recent operation first.
 */
export declare const listLandingZoneOperations: API.PaginatedOperationMethod<ListLandingZoneOperationsInput, ListLandingZoneOperationsOutput, ListLandingZoneOperationsError, Credentials | HttpClient.HttpClient, LandingZoneOperationSummary>;
export type ListLandingZonesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Returns the landing zone ARN for the landing zone deployed in your managed account. This API also creates an ARN for existing accounts that do not yet have a landing zone ARN.
 *
 * Returns one landing zone ARN.
 */
export declare const listLandingZones: API.PaginatedOperationMethod<ListLandingZonesInput, ListLandingZonesOutput, ListLandingZonesError, Credentials | HttpClient.HttpClient, LandingZoneSummary>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | BadRequestException | CommonErrors;
/**
 * Returns a list of tags associated with the resource. For usage examples, see the *Controls Reference Guide* .
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ResetEnabledBaselineError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Re-enables an `EnabledBaseline` resource. For example, this API can re-apply the existing `Baseline` after a new member account is moved to the target OU. For usage examples, see *the Amazon Web Services Control Tower User Guide* .
 */
export declare const resetEnabledBaseline: API.OperationMethod<ResetEnabledBaselineInput, ResetEnabledBaselineOutput, ResetEnabledBaselineError, Credentials | HttpClient.HttpClient>;
export type ResetEnabledControlError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Resets an enabled control. Does not work for controls implemented with SCPs.
 */
export declare const resetEnabledControl: API.OperationMethod<ResetEnabledControlInput, ResetEnabledControlOutput, ResetEnabledControlError, Credentials | HttpClient.HttpClient>;
export type ResetLandingZoneError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * This API call resets a landing zone. It starts an asynchronous operation that resets the landing zone to the parameters specified in the original configuration, which you specified in the manifest file. Nothing in the manifest file's original landing zone configuration is changed during the reset process, by default. This API is not the same as a rollback of a landing zone version, which is not a supported operation.
 */
export declare const resetLandingZone: API.OperationMethod<ResetLandingZoneInput, ResetLandingZoneOutput, ResetLandingZoneError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | BadRequestException | CommonErrors;
/**
 * Applies tags to a resource. For usage examples, see the *Controls Reference Guide* .
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | BadRequestException | CommonErrors;
/**
 * Removes tags from a resource. For usage examples, see the *Controls Reference Guide* .
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateEnabledBaselineError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates an `EnabledBaseline` resource's applied parameters or version. For usage examples, see *the Amazon Web Services Control Tower User Guide* .
 */
export declare const updateEnabledBaseline: API.OperationMethod<UpdateEnabledBaselineInput, UpdateEnabledBaselineOutput, UpdateEnabledBaselineError, Credentials | HttpClient.HttpClient>;
export type UpdateEnabledControlError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of an already enabled control.
 *
 * If the enabled control shows an `EnablementStatus` of SUCCEEDED, supply parameters that are different from the currently configured parameters. Otherwise, Amazon Web Services Control Tower will not accept the request.
 *
 * If the enabled control shows an `EnablementStatus` of FAILED, Amazon Web Services Control Tower updates the control to match any valid parameters that you supply.
 *
 * If the `DriftSummary` status for the control shows as `DRIFTED`, you cannot call this API. Instead, you can update the control by calling the `ResetEnabledControl` API. Alternatively, you can call `DisableControl` and then call `EnableControl` again. Also, you can run an extending governance operation to repair drift. For usage examples, see the *Controls Reference Guide* .
 */
export declare const updateEnabledControl: API.OperationMethod<UpdateEnabledControlInput, UpdateEnabledControlOutput, UpdateEnabledControlError, Credentials | HttpClient.HttpClient>;
export type UpdateLandingZoneError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * This API call updates the landing zone. It starts an asynchronous operation that updates the landing zone based on the new landing zone version, or on the changed parameters specified in the updated manifest file.
 */
export declare const updateLandingZone: API.OperationMethod<UpdateLandingZoneInput, UpdateLandingZoneOutput, UpdateLandingZoneError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=controltower.d.ts.map