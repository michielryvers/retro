import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const PendingVerification_base: S.TaggedErrorClass<"PendingVerification", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class PendingVerification extends /*@__PURE__*/ PendingVerification_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly limit: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly limit: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type RoomIdentifier = string;
export type UserID = string | redacted.Redacted<string>;
export type ChatTokenCapability = string;
export type ChatTokenCapabilities = string[];
export type SessionDurationInMinutes = number;
export type ChatTokenAttributes = {
    [key: string]: string | undefined;
};
export interface CreateChatTokenRequest {
    roomIdentifier: string;
    userId: string | redacted.Redacted<string>;
    capabilities?: string[];
    sessionDurationInMinutes?: number;
    attributes?: {
        [key: string]: string | undefined;
    };
}
export type ChatToken = string | redacted.Redacted<string>;
export interface CreateChatTokenResponse {
    token?: string | redacted.Redacted<string>;
    tokenExpirationTime?: Date;
    sessionExpirationTime?: Date;
}
export type LoggingConfigurationName = string;
export type BucketName = string;
export interface S3DestinationConfiguration {
    bucketName: string;
}
export type LogGroupName = string;
export interface CloudWatchLogsDestinationConfiguration {
    logGroupName: string;
}
export type DeliveryStreamName = string;
export interface FirehoseDestinationConfiguration {
    deliveryStreamName: string;
}
export type DestinationConfiguration = {
    s3: S3DestinationConfiguration;
    cloudWatchLogs?: never;
    firehose?: never;
} | {
    s3?: never;
    cloudWatchLogs: CloudWatchLogsDestinationConfiguration;
    firehose?: never;
} | {
    s3?: never;
    cloudWatchLogs?: never;
    firehose: FirehoseDestinationConfiguration;
};
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export interface CreateLoggingConfigurationRequest {
    name?: string;
    destinationConfiguration: DestinationConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type LoggingConfigurationArn = string;
export type LoggingConfigurationID = string;
export type CreateLoggingConfigurationState = string;
export interface CreateLoggingConfigurationResponse {
    arn?: string;
    id?: string;
    createTime?: Date;
    updateTime?: Date;
    name?: string;
    destinationConfiguration?: DestinationConfiguration;
    state?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type RoomName = string;
export type RoomMaxMessageRatePerSecond = number;
export type RoomMaxMessageLength = number;
export type LambdaArn = string;
export type FallbackResult = string;
export interface MessageReviewHandler {
    uri?: string;
    fallbackResult?: string;
}
export type LoggingConfigurationIdentifier = string;
export type LoggingConfigurationIdentifierList = string[];
export interface CreateRoomRequest {
    name?: string;
    maximumMessageRatePerSecond?: number;
    maximumMessageLength?: number;
    messageReviewHandler?: MessageReviewHandler;
    tags?: {
        [key: string]: string | undefined;
    };
    loggingConfigurationIdentifiers?: string[];
}
export type RoomArn = string;
export type RoomID = string;
export interface CreateRoomResponse {
    arn?: string;
    id?: string;
    name?: string;
    createTime?: Date;
    updateTime?: Date;
    maximumMessageRatePerSecond?: number;
    maximumMessageLength?: number;
    messageReviewHandler?: MessageReviewHandler;
    tags?: {
        [key: string]: string | undefined;
    };
    loggingConfigurationIdentifiers?: string[];
}
export interface DeleteLoggingConfigurationRequest {
    identifier: string;
}
export interface DeleteLoggingConfigurationResponse {
}
export type MessageID = string;
export type Reason = string;
export interface DeleteMessageRequest {
    roomIdentifier: string;
    id: string;
    reason?: string;
}
export type ID = string;
export interface DeleteMessageResponse {
    id?: string;
}
export interface DeleteRoomRequest {
    identifier: string;
}
export interface DeleteRoomResponse {
}
export interface DisconnectUserRequest {
    roomIdentifier: string;
    userId: string | redacted.Redacted<string>;
    reason?: string;
}
export interface DisconnectUserResponse {
}
export interface GetLoggingConfigurationRequest {
    identifier: string;
}
export type LoggingConfigurationState = string;
export interface GetLoggingConfigurationResponse {
    arn?: string;
    id?: string;
    createTime?: Date;
    updateTime?: Date;
    name?: string;
    destinationConfiguration?: DestinationConfiguration;
    state?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetRoomRequest {
    identifier: string;
}
export interface GetRoomResponse {
    arn?: string;
    id?: string;
    name?: string;
    createTime?: Date;
    updateTime?: Date;
    maximumMessageRatePerSecond?: number;
    maximumMessageLength?: number;
    messageReviewHandler?: MessageReviewHandler;
    tags?: {
        [key: string]: string | undefined;
    };
    loggingConfigurationIdentifiers?: string[];
}
export type PaginationToken = string;
export type MaxLoggingConfigurationResults = number;
export interface ListLoggingConfigurationsRequest {
    nextToken?: string;
    maxResults?: number;
}
export interface LoggingConfigurationSummary {
    arn?: string;
    id?: string;
    createTime?: Date;
    updateTime?: Date;
    name?: string;
    destinationConfiguration?: DestinationConfiguration;
    state?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type LoggingConfigurationList = LoggingConfigurationSummary[];
export interface ListLoggingConfigurationsResponse {
    loggingConfigurations: LoggingConfigurationSummary[];
    nextToken?: string;
}
export type MaxRoomResults = number;
export interface ListRoomsRequest {
    name?: string;
    nextToken?: string;
    maxResults?: number;
    messageReviewHandlerUri?: string;
    loggingConfigurationIdentifier?: string;
}
export interface RoomSummary {
    arn?: string;
    id?: string;
    name?: string;
    messageReviewHandler?: MessageReviewHandler;
    createTime?: Date;
    updateTime?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    loggingConfigurationIdentifiers?: string[];
}
export type RoomList = RoomSummary[];
export interface ListRoomsResponse {
    rooms: RoomSummary[];
    nextToken?: string;
}
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags: {
        [key: string]: string | undefined;
    };
}
export type EventName = string;
export type EventAttributes = {
    [key: string]: string | undefined;
};
export interface SendEventRequest {
    roomIdentifier: string;
    eventName: string;
    attributes?: {
        [key: string]: string | undefined;
    };
}
export interface SendEventResponse {
    id?: string;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateLoggingConfigurationRequest {
    identifier: string;
    name?: string;
    destinationConfiguration?: DestinationConfiguration;
}
export type UpdateLoggingConfigurationState = string;
export interface UpdateLoggingConfigurationResponse {
    arn?: string;
    id?: string;
    createTime?: Date;
    updateTime?: Date;
    name?: string;
    destinationConfiguration?: DestinationConfiguration;
    state?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface UpdateRoomRequest {
    identifier: string;
    name?: string;
    maximumMessageRatePerSecond?: number;
    maximumMessageLength?: number;
    messageReviewHandler?: MessageReviewHandler;
    loggingConfigurationIdentifiers?: string[];
}
export interface UpdateRoomResponse {
    arn?: string;
    id?: string;
    name?: string;
    createTime?: Date;
    updateTime?: Date;
    maximumMessageRatePerSecond?: number;
    maximumMessageLength?: number;
    messageReviewHandler?: MessageReviewHandler;
    tags?: {
        [key: string]: string | undefined;
    };
    loggingConfigurationIdentifiers?: string[];
}
export type ErrorMessage = string;
export type ResourceId = string;
export type ResourceType = string;
export type ValidationExceptionReason = string;
export type FieldName = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type Limit = number;
export type CreateChatTokenError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates an encrypted token that is used by a chat participant to establish an individual
 * WebSocket chat connection to a room. When the token is used to connect to chat, the
 * connection is valid for the session duration specified in the request. The token becomes
 * invalid at the token-expiration timestamp included in the response.
 *
 * Use the `capabilities` field to permit an end user to send messages or
 * moderate a room.
 *
 * The `attributes` field securely attaches structured data to the chat session; the data is
 * included within each message sent by the end user and received by other participants in the
 * room. Common use cases for attributes include passing end-user profile data like an icon,
 * display name, colors, badges, and other display features.
 *
 * Encryption keys are owned by Amazon IVS Chat and never used directly by your
 * application.
 */
export declare const createChatToken: API.OperationMethod<CreateChatTokenRequest, CreateChatTokenResponse, CreateChatTokenError, Credentials | HttpClient.HttpClient>;
export type CreateLoggingConfigurationError = AccessDeniedException | ConflictException | PendingVerification | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Creates a logging configuration that allows clients to store and record sent
 * messages.
 */
export declare const createLoggingConfiguration: API.OperationMethod<CreateLoggingConfigurationRequest, CreateLoggingConfigurationResponse, CreateLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateRoomError = AccessDeniedException | ConflictException | PendingVerification | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Creates a room that allows clients to connect and pass messages.
 */
export declare const createRoom: API.OperationMethod<CreateRoomRequest, CreateRoomResponse, CreateRoomError, Credentials | HttpClient.HttpClient>;
export type DeleteLoggingConfigurationError = AccessDeniedException | ConflictException | PendingVerification | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified logging configuration.
 */
export declare const deleteLoggingConfiguration: API.OperationMethod<DeleteLoggingConfigurationRequest, DeleteLoggingConfigurationResponse, DeleteLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteMessageError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends an event to a specific room which directs clients to delete a specific message;
 * that is, unrender it from view and delete it from the client's chat history. This event's
 * `EventName` is `aws:DELETE_MESSAGE`. This replicates the
 * DeleteMessage WebSocket operation in the Amazon IVS Chat Messaging API.
 */
export declare const deleteMessage: API.OperationMethod<DeleteMessageRequest, DeleteMessageResponse, DeleteMessageError, Credentials | HttpClient.HttpClient>;
export type DeleteRoomError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified room.
 */
export declare const deleteRoom: API.OperationMethod<DeleteRoomRequest, DeleteRoomResponse, DeleteRoomError, Credentials | HttpClient.HttpClient>;
export type DisconnectUserError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disconnects all connections using a specified user ID from a room. This replicates the
 *
 * DisconnectUser WebSocket operation in the Amazon IVS Chat Messaging API.
 */
export declare const disconnectUser: API.OperationMethod<DisconnectUserRequest, DisconnectUserResponse, DisconnectUserError, Credentials | HttpClient.HttpClient>;
export type GetLoggingConfigurationError = AccessDeniedException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets the specified logging configuration.
 */
export declare const getLoggingConfiguration: API.OperationMethod<GetLoggingConfigurationRequest, GetLoggingConfigurationResponse, GetLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetRoomError = AccessDeniedException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets the specified room.
 */
export declare const getRoom: API.OperationMethod<GetRoomRequest, GetRoomResponse, GetRoomError, Credentials | HttpClient.HttpClient>;
export type ListLoggingConfigurationsError = AccessDeniedException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets summary information about all your logging configurations in the AWS region where
 * the API request is processed.
 */
export declare const listLoggingConfigurations: API.PaginatedOperationMethod<ListLoggingConfigurationsRequest, ListLoggingConfigurationsResponse, ListLoggingConfigurationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRoomsError = AccessDeniedException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets summary information about all your rooms in the AWS region where the API request is
 * processed. Results are sorted in descending order of `updateTime`.
 */
export declare const listRooms: API.PaginatedOperationMethod<ListRoomsRequest, ListRoomsResponse, ListRoomsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets information about AWS tags for the specified ARN.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type SendEventError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends an event to a room. Use this within your application's business logic to send
 * events to clients of a room; e.g., to notify clients to change the way the chat UI is
 * rendered.
 */
export declare const sendEvent: API.OperationMethod<SendEventRequest, SendEventResponse, SendEventError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Adds or updates tags for the AWS resource with the specified ARN.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Removes tags from the resource with the specified ARN.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateLoggingConfigurationError = AccessDeniedException | ConflictException | PendingVerification | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Updates a specified logging configuration.
 */
export declare const updateLoggingConfiguration: API.OperationMethod<UpdateLoggingConfigurationRequest, UpdateLoggingConfigurationResponse, UpdateLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateRoomError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Updates a room's configuration.
 */
export declare const updateRoom: API.OperationMethod<UpdateRoomRequest, UpdateRoomResponse, UpdateRoomError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ivschat.d.ts.map