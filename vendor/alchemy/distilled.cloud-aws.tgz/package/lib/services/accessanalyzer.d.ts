import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnprocessableEntityException_base: S.TaggedErrorClass<"UnprocessableEntityException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class UnprocessableEntityException extends /*@__PURE__*/ UnprocessableEntityException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type AnalyzerArn = string;
export type Name = string;
export interface ApplyArchiveRuleRequest {
    analyzerArn: string;
    ruleName: string;
    clientToken?: string;
}
export interface ApplyArchiveRuleResponse {
}
export type JobId = string;
export interface CancelPolicyGenerationRequest {
    jobId: string;
}
export interface CancelPolicyGenerationResponse {
}
export type AccessCheckPolicyDocument = string | redacted.Redacted<string>;
export type Action = string;
export type ActionsList = string[];
export type Resource = string;
export type ResourcesList = string[];
export interface Access {
    actions?: string[];
    resources?: string[];
}
export type AccessList = Access[];
export type AccessCheckPolicyType = string;
export interface CheckAccessNotGrantedRequest {
    policyDocument: string | redacted.Redacted<string>;
    access: Access[];
    policyType: string;
}
export type CheckAccessNotGrantedResult = string;
export interface ReasonSummary {
    description?: string;
    statementIndex?: number;
    statementId?: string;
}
export type ReasonSummaryList = ReasonSummary[];
export interface CheckAccessNotGrantedResponse {
    result?: string;
    message?: string;
    reasons?: ReasonSummary[];
}
export interface CheckNoNewAccessRequest {
    newPolicyDocument: string | redacted.Redacted<string>;
    existingPolicyDocument: string | redacted.Redacted<string>;
    policyType: string;
}
export type CheckNoNewAccessResult = string;
export interface CheckNoNewAccessResponse {
    result?: string;
    message?: string;
    reasons?: ReasonSummary[];
}
export type AccessCheckResourceType = string;
export interface CheckNoPublicAccessRequest {
    policyDocument: string | redacted.Redacted<string>;
    resourceType: string;
}
export type CheckNoPublicAccessResult = string;
export interface CheckNoPublicAccessResponse {
    result?: string;
    message?: string;
    reasons?: ReasonSummary[];
}
export type ConfigurationsMapKey = string;
export type EbsUserId = string;
export type EbsUserIdList = string[];
export type EbsGroup = string;
export type EbsGroupList = string[];
export type EbsSnapshotDataEncryptionKeyId = string;
export interface EbsSnapshotConfiguration {
    userIds?: string[];
    groups?: string[];
    kmsKeyId?: string;
}
export type EcrRepositoryPolicy = string;
export interface EcrRepositoryConfiguration {
    repositoryPolicy?: string;
}
export type IamTrustPolicy = string;
export interface IamRoleConfiguration {
    trustPolicy?: string;
}
export type EfsFileSystemPolicy = string;
export interface EfsFileSystemConfiguration {
    fileSystemPolicy?: string;
}
export type PolicyName = string;
export type KmsKeyPolicy = string;
export type KmsKeyPoliciesMap = {
    [key: string]: string | undefined;
};
export type KmsGrantOperation = string;
export type KmsGrantOperationsList = string[];
export type GranteePrincipal = string;
export type RetiringPrincipal = string;
export type KmsConstraintsKey = string;
export type KmsConstraintsValue = string;
export type KmsConstraintsMap = {
    [key: string]: string | undefined;
};
export interface KmsGrantConstraints {
    encryptionContextEquals?: {
        [key: string]: string | undefined;
    };
    encryptionContextSubset?: {
        [key: string]: string | undefined;
    };
}
export type IssuingAccount = string;
export interface KmsGrantConfiguration {
    operations: string[];
    granteePrincipal: string;
    retiringPrincipal?: string;
    constraints?: KmsGrantConstraints;
    issuingAccount: string;
}
export type KmsGrantConfigurationsList = KmsGrantConfiguration[];
export interface KmsKeyConfiguration {
    keyPolicies?: {
        [key: string]: string | undefined;
    };
    grants?: KmsGrantConfiguration[];
}
export type RdsDbClusterSnapshotAttributeName = string;
export type RdsDbClusterSnapshotAccountId = string;
export type RdsDbClusterSnapshotAccountIdsList = string[];
export type RdsDbClusterSnapshotAttributeValue = {
    accountIds: string[];
};
export type RdsDbClusterSnapshotAttributesMap = {
    [key: string]: RdsDbClusterSnapshotAttributeValue | undefined;
};
export type RdsDbClusterSnapshotKmsKeyId = string;
export interface RdsDbClusterSnapshotConfiguration {
    attributes?: {
        [key: string]: RdsDbClusterSnapshotAttributeValue | undefined;
    };
    kmsKeyId?: string;
}
export type RdsDbSnapshotAttributeName = string;
export type RdsDbSnapshotAccountId = string;
export type RdsDbSnapshotAccountIdsList = string[];
export type RdsDbSnapshotAttributeValue = {
    accountIds: string[];
};
export type RdsDbSnapshotAttributesMap = {
    [key: string]: RdsDbSnapshotAttributeValue | undefined;
};
export type RdsDbSnapshotKmsKeyId = string;
export interface RdsDbSnapshotConfiguration {
    attributes?: {
        [key: string]: RdsDbSnapshotAttributeValue | undefined;
    };
    kmsKeyId?: string;
}
export type SecretsManagerSecretKmsId = string;
export type SecretsManagerSecretPolicy = string;
export interface SecretsManagerSecretConfiguration {
    kmsKeyId?: string;
    secretPolicy?: string;
}
export type S3BucketPolicy = string;
export type AclPermission = string;
export type AclCanonicalId = string;
export type AclUri = string;
export type AclGrantee = {
    id: string;
    uri?: never;
} | {
    id?: never;
    uri: string;
};
export interface S3BucketAclGrantConfiguration {
    permission: string;
    grantee: AclGrantee;
}
export type S3BucketAclGrantConfigurationsList = S3BucketAclGrantConfiguration[];
export interface S3PublicAccessBlockConfiguration {
    ignorePublicAcls: boolean;
    restrictPublicBuckets: boolean;
}
export type AccessPointArn = string;
export type AccessPointPolicy = string;
export type VpcId = string;
export interface VpcConfiguration {
    vpcId: string;
}
export interface InternetConfiguration {
}
export type NetworkOriginConfiguration = {
    vpcConfiguration: VpcConfiguration;
    internetConfiguration?: never;
} | {
    vpcConfiguration?: never;
    internetConfiguration: InternetConfiguration;
};
export interface S3AccessPointConfiguration {
    accessPointPolicy?: string;
    publicAccessBlock?: S3PublicAccessBlockConfiguration;
    networkOrigin?: NetworkOriginConfiguration;
}
export type S3AccessPointConfigurationsMap = {
    [key: string]: S3AccessPointConfiguration | undefined;
};
export interface S3BucketConfiguration {
    bucketPolicy?: string;
    bucketAclGrants?: S3BucketAclGrantConfiguration[];
    bucketPublicAccessBlock?: S3PublicAccessBlockConfiguration;
    accessPoints?: {
        [key: string]: S3AccessPointConfiguration | undefined;
    };
}
export type SnsTopicPolicy = string;
export interface SnsTopicConfiguration {
    topicPolicy?: string;
}
export type SqsQueuePolicy = string;
export interface SqsQueueConfiguration {
    queuePolicy?: string;
}
export type S3ExpressDirectoryBucketPolicy = string;
export type S3ExpressDirectoryAccessPointArn = string;
export interface S3ExpressDirectoryAccessPointConfiguration {
    accessPointPolicy?: string;
    networkOrigin?: NetworkOriginConfiguration;
}
export type S3ExpressDirectoryAccessPointConfigurationsMap = {
    [key: string]: S3ExpressDirectoryAccessPointConfiguration | undefined;
};
export interface S3ExpressDirectoryBucketConfiguration {
    bucketPolicy?: string;
    accessPoints?: {
        [key: string]: S3ExpressDirectoryAccessPointConfiguration | undefined;
    };
}
export type DynamodbStreamPolicy = string;
export interface DynamodbStreamConfiguration {
    streamPolicy?: string;
}
export type DynamodbTablePolicy = string;
export interface DynamodbTableConfiguration {
    tablePolicy?: string;
}
export type Configuration = {
    ebsSnapshot: EbsSnapshotConfiguration;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository: EcrRepositoryConfiguration;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole: IamRoleConfiguration;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem: EfsFileSystemConfiguration;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey: KmsKeyConfiguration;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot: RdsDbClusterSnapshotConfiguration;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot: RdsDbSnapshotConfiguration;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret: SecretsManagerSecretConfiguration;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket: S3BucketConfiguration;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic: SnsTopicConfiguration;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue: SqsQueueConfiguration;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket: S3ExpressDirectoryBucketConfiguration;
    dynamodbStream?: never;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream: DynamodbStreamConfiguration;
    dynamodbTable?: never;
} | {
    ebsSnapshot?: never;
    ecrRepository?: never;
    iamRole?: never;
    efsFileSystem?: never;
    kmsKey?: never;
    rdsDbClusterSnapshot?: never;
    rdsDbSnapshot?: never;
    secretsManagerSecret?: never;
    s3Bucket?: never;
    snsTopic?: never;
    sqsQueue?: never;
    s3ExpressDirectoryBucket?: never;
    dynamodbStream?: never;
    dynamodbTable: DynamodbTableConfiguration;
};
export type ConfigurationsMap = {
    [key: string]: Configuration | undefined;
};
export interface CreateAccessPreviewRequest {
    analyzerArn: string;
    configurations: {
        [key: string]: Configuration | undefined;
    };
    clientToken?: string;
}
export type AccessPreviewId = string;
export interface CreateAccessPreviewResponse {
    id: string;
}
export type AnalyzerName = string;
export type Type = string;
export type ValueList = string[];
export interface Criterion {
    eq?: string[];
    neq?: string[];
    contains?: string[];
    exists?: boolean;
}
export type FilterCriteriaMap = {
    [key: string]: Criterion | undefined;
};
export interface InlineArchiveRule {
    ruleName: string;
    filter: {
        [key: string]: Criterion | undefined;
    };
}
export type InlineArchiveRulesList = InlineArchiveRule[];
export type TagsMap = {
    [key: string]: string | undefined;
};
export type AccountIdsList = string[];
export type TagsList = {
    [key: string]: string | undefined;
}[];
export interface AnalysisRuleCriteria {
    accountIds?: string[];
    resourceTags?: {
        [key: string]: string | undefined;
    }[];
}
export type AnalysisRuleCriteriaList = AnalysisRuleCriteria[];
export interface AnalysisRule {
    exclusions?: AnalysisRuleCriteria[];
}
export interface UnusedAccessConfiguration {
    unusedAccessAge?: number;
    analysisRule?: AnalysisRule;
}
export type ResourceType = string;
export type ResourceTypeList = string[];
export type ResourceArnsList = string[];
export interface InternalAccessAnalysisRuleCriteria {
    accountIds?: string[];
    resourceTypes?: string[];
    resourceArns?: string[];
}
export type InternalAccessAnalysisRuleCriteriaList = InternalAccessAnalysisRuleCriteria[];
export interface InternalAccessAnalysisRule {
    inclusions?: InternalAccessAnalysisRuleCriteria[];
}
export interface InternalAccessConfiguration {
    analysisRule?: InternalAccessAnalysisRule;
}
export type AnalyzerConfiguration = {
    unusedAccess: UnusedAccessConfiguration;
    internalAccess?: never;
} | {
    unusedAccess?: never;
    internalAccess: InternalAccessConfiguration;
};
export interface CreateAnalyzerRequest {
    analyzerName: string;
    type: string;
    archiveRules?: InlineArchiveRule[];
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
    configuration?: AnalyzerConfiguration;
}
export interface CreateAnalyzerResponse {
    arn?: string;
}
export interface CreateArchiveRuleRequest {
    analyzerName: string;
    ruleName: string;
    filter: {
        [key: string]: Criterion | undefined;
    };
    clientToken?: string;
}
export interface CreateArchiveRuleResponse {
}
export interface CreateServiceLinkedAnalyzerRequest {
    type: string;
    archiveRules?: InlineArchiveRule[];
    clientToken?: string;
    configuration?: AnalyzerConfiguration;
}
export interface CreateServiceLinkedAnalyzerResponse {
    arn?: string;
}
export interface DeleteAnalyzerRequest {
    analyzerName: string;
    clientToken?: string;
}
export interface DeleteAnalyzerResponse {
}
export interface DeleteArchiveRuleRequest {
    analyzerName: string;
    ruleName: string;
    clientToken?: string;
}
export interface DeleteArchiveRuleResponse {
}
export interface DeleteServiceLinkedAnalyzerRequest {
    analyzerName: string;
    clientToken?: string;
}
export interface DeleteServiceLinkedAnalyzerResponse {
}
export interface GenerateFindingRecommendationRequest {
    analyzerArn: string;
    id: string;
}
export interface GenerateFindingRecommendationResponse {
}
export interface GetAccessPreviewRequest {
    accessPreviewId: string;
    analyzerArn: string;
}
export type AccessPreviewStatus = string;
export type AccessPreviewStatusReasonCode = string;
export interface AccessPreviewStatusReason {
    code: string;
}
export interface AccessPreview {
    id: string;
    analyzerArn: string;
    configurations: {
        [key: string]: Configuration | undefined;
    };
    createdAt: Date;
    status: string;
    statusReason?: AccessPreviewStatusReason;
}
export interface GetAccessPreviewResponse {
    accessPreview: AccessPreview;
}
export type ResourceArn = string;
export interface GetAnalyzedResourceRequest {
    analyzerArn: string;
    resourceArn: string;
}
export type ActionList = string[];
export type SharedViaList = string[];
export type FindingStatus = string;
export interface AnalyzedResource {
    resourceArn: string;
    resourceType: string;
    createdAt: Date;
    analyzedAt: Date;
    updatedAt: Date;
    isPublic: boolean;
    actions?: string[];
    sharedVia?: string[];
    status?: string;
    resourceOwnerAccount: string;
    error?: string;
}
export interface GetAnalyzedResourceResponse {
    resource?: AnalyzedResource;
}
export interface GetAnalyzerRequest {
    analyzerName: string;
}
export type AnalyzerStatus = string;
export type ReasonCode = string;
export interface StatusReason {
    code: string;
}
export interface AnalyzerSummary {
    arn: string;
    name: string;
    type: string;
    createdAt: Date;
    lastResourceAnalyzed?: string;
    lastResourceAnalyzedAt?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    status: string;
    statusReason?: StatusReason;
    configuration?: AnalyzerConfiguration;
    managedBy?: string;
}
export interface GetAnalyzerResponse {
    analyzer: AnalyzerSummary;
}
export interface GetArchiveRuleRequest {
    analyzerName: string;
    ruleName: string;
}
export interface ArchiveRuleSummary {
    ruleName: string;
    filter: {
        [key: string]: Criterion | undefined;
    };
    createdAt: Date;
    updatedAt: Date;
}
export interface GetArchiveRuleResponse {
    archiveRule: ArchiveRuleSummary;
}
export type FindingId = string;
export interface GetFindingRequest {
    analyzerArn: string;
    id: string;
}
export type PrincipalMap = {
    [key: string]: string | undefined;
};
export type ConditionKeyMap = {
    [key: string]: string | undefined;
};
export type FindingSourceType = string;
export interface FindingSourceDetail {
    accessPointArn?: string;
    accessPointAccount?: string;
}
export interface FindingSource {
    type: string;
    detail?: FindingSourceDetail;
}
export type FindingSourceList = FindingSource[];
export type ResourceControlPolicyRestriction = string;
export interface Finding {
    id: string;
    principal?: {
        [key: string]: string | undefined;
    };
    action?: string[];
    resource?: string;
    isPublic?: boolean;
    resourceType: string;
    condition: {
        [key: string]: string | undefined;
    };
    createdAt: Date;
    analyzedAt: Date;
    updatedAt: Date;
    status: string;
    resourceOwnerAccount: string;
    error?: string;
    sources?: FindingSource[];
    resourceControlPolicyRestriction?: string;
}
export interface GetFindingResponse {
    finding?: Finding;
}
export type Token = string;
export interface GetFindingRecommendationRequest {
    analyzerArn: string;
    id: string;
    maxResults?: number;
    nextToken?: string;
}
export interface RecommendationError {
    code: string;
    message: string;
}
export type RecommendedRemediationAction = string;
export interface UnusedPermissionsRecommendedStep {
    policyUpdatedAt?: Date;
    recommendedAction: string;
    recommendedPolicy?: string;
    existingPolicyId?: string;
}
export type RecommendedStep = {
    unusedPermissionsRecommendedStep: UnusedPermissionsRecommendedStep;
};
export type RecommendedStepList = RecommendedStep[];
export type RecommendationType = string;
export type Status = string;
export interface GetFindingRecommendationResponse {
    startedAt: Date;
    completedAt?: Date;
    nextToken?: string;
    error?: RecommendationError;
    resourceArn: string;
    recommendedSteps?: RecommendedStep[];
    recommendationType: string;
    status: string;
}
export interface GetFindingsStatisticsRequest {
    analyzerArn: string;
}
export interface ResourceTypeDetails {
    totalActivePublic?: number;
    totalActiveCrossAccount?: number;
    totalActiveErrors?: number;
}
export type ResourceTypeStatisticsMap = {
    [key: string]: ResourceTypeDetails | undefined;
};
export interface ExternalAccessFindingsStatistics {
    resourceTypeStatistics?: {
        [key: string]: ResourceTypeDetails | undefined;
    };
    totalActiveFindings?: number;
    totalArchivedFindings?: number;
    totalResolvedFindings?: number;
}
export interface InternalAccessResourceTypeDetails {
    totalActiveFindings?: number;
    totalResolvedFindings?: number;
    totalArchivedFindings?: number;
}
export type InternalAccessResourceTypeStatisticsMap = {
    [key: string]: InternalAccessResourceTypeDetails | undefined;
};
export interface InternalAccessFindingsStatistics {
    resourceTypeStatistics?: {
        [key: string]: InternalAccessResourceTypeDetails | undefined;
    };
    totalActiveFindings?: number;
    totalArchivedFindings?: number;
    totalResolvedFindings?: number;
}
export interface UnusedAccessTypeStatistics {
    unusedAccessType?: string;
    total?: number;
}
export type UnusedAccessTypeStatisticsList = UnusedAccessTypeStatistics[];
export type FindingAggregationAccountDetailsMap = {
    [key: string]: number | undefined;
};
export interface FindingAggregationAccountDetails {
    account?: string;
    numberOfActiveFindings?: number;
    details?: {
        [key: string]: number | undefined;
    };
}
export type AccountAggregations = FindingAggregationAccountDetails[];
export interface UnusedAccessFindingsStatistics {
    unusedAccessTypeStatistics?: UnusedAccessTypeStatistics[];
    topAccounts?: FindingAggregationAccountDetails[];
    totalActiveFindings?: number;
    totalArchivedFindings?: number;
    totalResolvedFindings?: number;
}
export type FindingsStatistics = {
    externalAccessFindingsStatistics: ExternalAccessFindingsStatistics;
    internalAccessFindingsStatistics?: never;
    unusedAccessFindingsStatistics?: never;
} | {
    externalAccessFindingsStatistics?: never;
    internalAccessFindingsStatistics: InternalAccessFindingsStatistics;
    unusedAccessFindingsStatistics?: never;
} | {
    externalAccessFindingsStatistics?: never;
    internalAccessFindingsStatistics?: never;
    unusedAccessFindingsStatistics: UnusedAccessFindingsStatistics;
};
export type FindingsStatisticsList = FindingsStatistics[];
export interface GetFindingsStatisticsResponse {
    findingsStatistics?: FindingsStatistics[];
    lastUpdatedAt?: Date;
}
export interface GetFindingV2Request {
    analyzerArn: string;
    id: string;
    maxResults?: number;
    nextToken?: string;
}
export type InternalAccessType = string;
export type PrincipalType = string;
export type ServiceControlPolicyRestriction = string;
export interface InternalAccessDetails {
    action?: string[];
    condition?: {
        [key: string]: string | undefined;
    };
    principal?: {
        [key: string]: string | undefined;
    };
    principalOwnerAccount?: string;
    accessType?: string;
    principalType?: string;
    sources?: FindingSource[];
    resourceControlPolicyRestriction?: string;
    serviceControlPolicyRestriction?: string;
}
export interface ExternalAccessDetails {
    action?: string[];
    condition: {
        [key: string]: string | undefined;
    };
    isPublic?: boolean;
    principal?: {
        [key: string]: string | undefined;
    };
    sources?: FindingSource[];
    resourceControlPolicyRestriction?: string;
}
export interface UnusedAction {
    action: string;
    lastAccessed?: Date;
}
export type UnusedActionList = UnusedAction[];
export interface UnusedPermissionDetails {
    actions?: UnusedAction[];
    serviceNamespace: string;
    lastAccessed?: Date;
}
export interface UnusedIamUserAccessKeyDetails {
    accessKeyId: string;
    lastAccessed?: Date;
}
export interface UnusedIamRoleDetails {
    lastAccessed?: Date;
}
export interface UnusedIamUserPasswordDetails {
    lastAccessed?: Date;
}
export type FindingDetails = {
    internalAccessDetails: InternalAccessDetails;
    externalAccessDetails?: never;
    unusedPermissionDetails?: never;
    unusedIamUserAccessKeyDetails?: never;
    unusedIamRoleDetails?: never;
    unusedIamUserPasswordDetails?: never;
} | {
    internalAccessDetails?: never;
    externalAccessDetails: ExternalAccessDetails;
    unusedPermissionDetails?: never;
    unusedIamUserAccessKeyDetails?: never;
    unusedIamRoleDetails?: never;
    unusedIamUserPasswordDetails?: never;
} | {
    internalAccessDetails?: never;
    externalAccessDetails?: never;
    unusedPermissionDetails: UnusedPermissionDetails;
    unusedIamUserAccessKeyDetails?: never;
    unusedIamRoleDetails?: never;
    unusedIamUserPasswordDetails?: never;
} | {
    internalAccessDetails?: never;
    externalAccessDetails?: never;
    unusedPermissionDetails?: never;
    unusedIamUserAccessKeyDetails: UnusedIamUserAccessKeyDetails;
    unusedIamRoleDetails?: never;
    unusedIamUserPasswordDetails?: never;
} | {
    internalAccessDetails?: never;
    externalAccessDetails?: never;
    unusedPermissionDetails?: never;
    unusedIamUserAccessKeyDetails?: never;
    unusedIamRoleDetails: UnusedIamRoleDetails;
    unusedIamUserPasswordDetails?: never;
} | {
    internalAccessDetails?: never;
    externalAccessDetails?: never;
    unusedPermissionDetails?: never;
    unusedIamUserAccessKeyDetails?: never;
    unusedIamRoleDetails?: never;
    unusedIamUserPasswordDetails: UnusedIamUserPasswordDetails;
};
export type FindingDetailsList = FindingDetails[];
export type FindingType = string;
export interface GetFindingV2Response {
    analyzedAt: Date;
    createdAt: Date;
    error?: string;
    id: string;
    nextToken?: string;
    resource?: string;
    resourceType: string;
    resourceOwnerAccount: string;
    status: string;
    updatedAt: Date;
    findingDetails: FindingDetails[];
    findingType?: string;
}
export interface GetGeneratedPolicyRequest {
    jobId: string;
    includeResourcePlaceholders?: boolean;
    includeServiceLevelTemplate?: boolean;
}
export type JobStatus = string;
export type JobErrorCode = string;
export interface JobError {
    code: string;
    message: string;
}
export interface JobDetails {
    jobId: string;
    status: string;
    startedOn: Date;
    completedOn?: Date;
    jobError?: JobError;
}
export type PrincipalArn = string;
export type CloudTrailArn = string;
export type RegionList = string[];
export interface TrailProperties {
    cloudTrailArn: string;
    regions?: string[];
    allRegions?: boolean;
}
export type TrailPropertiesList = TrailProperties[];
export interface CloudTrailProperties {
    trailProperties: TrailProperties[];
    startTime: Date;
    endTime: Date;
}
export interface GeneratedPolicyProperties {
    isComplete?: boolean;
    principalArn: string;
    cloudTrailProperties?: CloudTrailProperties;
}
export interface GeneratedPolicy {
    policy: string;
}
export type GeneratedPolicyList = GeneratedPolicy[];
export interface GeneratedPolicyResult {
    properties: GeneratedPolicyProperties;
    generatedPolicies?: GeneratedPolicy[];
}
export interface GetGeneratedPolicyResponse {
    jobDetails: JobDetails;
    generatedPolicyResult: GeneratedPolicyResult;
}
export interface ListAccessPreviewFindingsRequest {
    accessPreviewId: string;
    analyzerArn: string;
    filter?: {
        [key: string]: Criterion | undefined;
    };
    nextToken?: string;
    maxResults?: number;
}
export type AccessPreviewFindingId = string;
export type FindingChangeType = string;
export interface AccessPreviewFinding {
    id: string;
    existingFindingId?: string;
    existingFindingStatus?: string;
    principal?: {
        [key: string]: string | undefined;
    };
    action?: string[];
    condition?: {
        [key: string]: string | undefined;
    };
    resource?: string;
    isPublic?: boolean;
    resourceType: string;
    createdAt: Date;
    changeType: string;
    status: string;
    resourceOwnerAccount: string;
    error?: string;
    sources?: FindingSource[];
    resourceControlPolicyRestriction?: string;
}
export type AccessPreviewFindingsList = AccessPreviewFinding[];
export interface ListAccessPreviewFindingsResponse {
    findings: AccessPreviewFinding[];
    nextToken?: string;
}
export interface ListAccessPreviewsRequest {
    analyzerArn: string;
    nextToken?: string;
    maxResults?: number;
}
export interface AccessPreviewSummary {
    id: string;
    analyzerArn: string;
    createdAt: Date;
    status: string;
    statusReason?: AccessPreviewStatusReason;
}
export type AccessPreviewsList = AccessPreviewSummary[];
export interface ListAccessPreviewsResponse {
    accessPreviews: AccessPreviewSummary[];
    nextToken?: string;
}
export interface ListAnalyzedResourcesRequest {
    analyzerArn: string;
    resourceType?: string;
    nextToken?: string;
    maxResults?: number;
}
export interface AnalyzedResourceSummary {
    resourceArn: string;
    resourceOwnerAccount: string;
    resourceType: string;
}
export type AnalyzedResourcesList = AnalyzedResourceSummary[];
export interface ListAnalyzedResourcesResponse {
    analyzedResources: AnalyzedResourceSummary[];
    nextToken?: string;
}
export interface ListAnalyzersRequest {
    nextToken?: string;
    maxResults?: number;
    type?: string;
}
export type AnalyzersList = AnalyzerSummary[];
export interface ListAnalyzersResponse {
    analyzers: AnalyzerSummary[];
    nextToken?: string;
}
export interface ListArchiveRulesRequest {
    analyzerName: string;
    nextToken?: string;
    maxResults?: number;
}
export type ArchiveRulesList = ArchiveRuleSummary[];
export interface ListArchiveRulesResponse {
    archiveRules: ArchiveRuleSummary[];
    nextToken?: string;
}
export type OrderBy = string;
export interface SortCriteria {
    attributeName?: string;
    orderBy?: string;
}
export interface ListFindingsRequest {
    analyzerArn: string;
    filter?: {
        [key: string]: Criterion | undefined;
    };
    sort?: SortCriteria;
    nextToken?: string;
    maxResults?: number;
}
export interface FindingSummary {
    id: string;
    principal?: {
        [key: string]: string | undefined;
    };
    action?: string[];
    resource?: string;
    isPublic?: boolean;
    resourceType: string;
    condition: {
        [key: string]: string | undefined;
    };
    createdAt: Date;
    analyzedAt: Date;
    updatedAt: Date;
    status: string;
    resourceOwnerAccount: string;
    error?: string;
    sources?: FindingSource[];
    resourceControlPolicyRestriction?: string;
}
export type FindingsList = FindingSummary[];
export interface ListFindingsResponse {
    findings: FindingSummary[];
    nextToken?: string;
}
export interface ListFindingsV2Request {
    analyzerArn: string;
    filter?: {
        [key: string]: Criterion | undefined;
    };
    maxResults?: number;
    nextToken?: string;
    sort?: SortCriteria;
}
export interface FindingSummaryV2 {
    analyzedAt: Date;
    createdAt: Date;
    error?: string;
    id: string;
    resource?: string;
    resourceType: string;
    resourceOwnerAccount: string;
    status: string;
    updatedAt: Date;
    findingType?: string;
}
export type FindingsListV2 = FindingSummaryV2[];
export interface ListFindingsV2Response {
    findings: FindingSummaryV2[];
    nextToken?: string;
}
export interface ListPolicyGenerationsRequest {
    principalArn?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface PolicyGeneration {
    jobId: string;
    principalArn: string;
    status: string;
    startedOn: Date;
    completedOn?: Date;
}
export type PolicyGenerationList = PolicyGeneration[];
export interface ListPolicyGenerationsResponse {
    policyGenerations: PolicyGeneration[];
    nextToken?: string;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface PolicyGenerationDetails {
    principalArn: string;
}
export interface Trail {
    cloudTrailArn: string;
    regions?: string[];
    allRegions?: boolean;
}
export type TrailList = Trail[];
export type RoleArn = string;
export interface CloudTrailDetails {
    trails: Trail[];
    accessRole: string;
    startTime: Date;
    endTime?: Date;
}
export interface StartPolicyGenerationRequest {
    policyGenerationDetails: PolicyGenerationDetails;
    cloudTrailDetails?: CloudTrailDetails;
    clientToken?: string;
}
export interface StartPolicyGenerationResponse {
    jobId: string;
}
export interface StartResourceScanRequest {
    analyzerArn: string;
    resourceArn: string;
    resourceOwnerAccount?: string;
}
export interface StartResourceScanResponse {
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAnalyzerRequest {
    analyzerName: string;
    configuration?: AnalyzerConfiguration;
}
export interface UpdateAnalyzerResponse {
    configuration?: AnalyzerConfiguration;
}
export interface UpdateArchiveRuleRequest {
    analyzerName: string;
    ruleName: string;
    filter: {
        [key: string]: Criterion | undefined;
    };
    clientToken?: string;
}
export interface UpdateArchiveRuleResponse {
}
export type FindingStatusUpdate = string;
export type FindingIdList = string[];
export interface UpdateFindingsRequest {
    analyzerArn: string;
    status: string;
    ids?: string[];
    resourceArn?: string;
    clientToken?: string;
}
export interface UpdateFindingsResponse {
}
export type Locale = string;
export type PolicyDocument = string;
export type PolicyType = string;
export type ValidatePolicyResourceType = string;
export interface ValidatePolicyRequest {
    locale?: string;
    maxResults?: number;
    nextToken?: string;
    policyDocument: string;
    policyType: string;
    validatePolicyResourceType?: string;
}
export type ValidatePolicyFindingType = string;
export type IssueCode = string;
export type LearnMoreLink = string;
export interface Substring {
    start: number;
    length: number;
}
export type PathElement = {
    index: number;
    key?: never;
    substring?: never;
    value?: never;
} | {
    index?: never;
    key: string;
    substring?: never;
    value?: never;
} | {
    index?: never;
    key?: never;
    substring: Substring;
    value?: never;
} | {
    index?: never;
    key?: never;
    substring?: never;
    value: string;
};
export type PathElementList = PathElement[];
export interface Position {
    line: number;
    column: number;
    offset: number;
}
export interface Span {
    start: Position;
    end: Position;
}
export interface Location {
    path: PathElement[];
    span: Span;
}
export type LocationList = Location[];
export interface ValidatePolicyFinding {
    findingDetails: string;
    findingType: string;
    issueCode: string;
    learnMoreLink: string;
    locations: Location[];
}
export type ValidatePolicyFindingList = ValidatePolicyFinding[];
export interface ValidatePolicyResponse {
    findings: ValidatePolicyFinding[];
    nextToken?: string;
}
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type ApplyArchiveRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retroactively applies the archive rule to existing findings that meet the archive rule criteria.
 */
export declare const applyArchiveRule: API.OperationMethod<ApplyArchiveRuleRequest, ApplyArchiveRuleResponse, ApplyArchiveRuleError, Credentials | HttpClient.HttpClient>;
export type CancelPolicyGenerationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels the requested policy generation.
 */
export declare const cancelPolicyGeneration: API.OperationMethod<CancelPolicyGenerationRequest, CancelPolicyGenerationResponse, CancelPolicyGenerationError, Credentials | HttpClient.HttpClient>;
export type CheckAccessNotGrantedError = AccessDeniedException | InternalServerException | InvalidParameterException | ThrottlingException | UnprocessableEntityException | ValidationException | CommonErrors;
/**
 * Checks whether the specified access isn't allowed by a policy.
 */
export declare const checkAccessNotGranted: API.OperationMethod<CheckAccessNotGrantedRequest, CheckAccessNotGrantedResponse, CheckAccessNotGrantedError, Credentials | HttpClient.HttpClient>;
export type CheckNoNewAccessError = AccessDeniedException | InternalServerException | InvalidParameterException | ThrottlingException | UnprocessableEntityException | ValidationException | CommonErrors;
/**
 * Checks whether new access is allowed for an updated policy when compared to the existing policy.
 *
 * You can find examples for reference policies and learn how to set up and run a custom policy check for new access in the IAM Access Analyzer custom policy checks samples repository on GitHub. The reference policies in this repository are meant to be passed to the `existingPolicyDocument` request parameter.
 */
export declare const checkNoNewAccess: API.OperationMethod<CheckNoNewAccessRequest, CheckNoNewAccessResponse, CheckNoNewAccessError, Credentials | HttpClient.HttpClient>;
export type CheckNoPublicAccessError = AccessDeniedException | InternalServerException | InvalidParameterException | ThrottlingException | UnprocessableEntityException | ValidationException | CommonErrors;
/**
 * Checks whether a resource policy can grant public access to the specified resource type.
 */
export declare const checkNoPublicAccess: API.OperationMethod<CheckNoPublicAccessRequest, CheckNoPublicAccessResponse, CheckNoPublicAccessError, Credentials | HttpClient.HttpClient>;
export type CreateAccessPreviewError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an access preview that allows you to preview IAM Access Analyzer findings for your resource before deploying resource permissions.
 */
export declare const createAccessPreview: API.OperationMethod<CreateAccessPreviewRequest, CreateAccessPreviewResponse, CreateAccessPreviewError, Credentials | HttpClient.HttpClient>;
export type CreateAnalyzerError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an analyzer for your account.
 */
export declare const createAnalyzer: API.OperationMethod<CreateAnalyzerRequest, CreateAnalyzerResponse, CreateAnalyzerError, Credentials | HttpClient.HttpClient>;
export type CreateArchiveRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an archive rule for the specified analyzer. Archive rules automatically archive new findings that meet the criteria you define when you create the rule.
 *
 * To learn about filter keys that you can use to create an archive rule, see IAM Access Analyzer filter keys in the **IAM User Guide**.
 */
export declare const createArchiveRule: API.OperationMethod<CreateArchiveRuleRequest, CreateArchiveRuleResponse, CreateArchiveRuleError, Credentials | HttpClient.HttpClient>;
export type CreateServiceLinkedAnalyzerError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a service-linked analyzer managed by an Amazon Web Services service. This operation can only be invoked by authorized Amazon Web Services services. Direct customer invocation returns `AccessDeniedException`.
 *
 * Service-linked analyzers enable Amazon Web Services services to create and manage analyzers on behalf of customers. The lifecycle of these analyzers is managed by the calling service.
 */
export declare const createServiceLinkedAnalyzer: API.OperationMethod<CreateServiceLinkedAnalyzerRequest, CreateServiceLinkedAnalyzerResponse, CreateServiceLinkedAnalyzerError, Credentials | HttpClient.HttpClient>;
export type DeleteAnalyzerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified analyzer. When you delete an analyzer, IAM Access Analyzer is disabled for the account or organization in the current or specific Region. All findings that were generated by the analyzer are deleted. You cannot undo this action.
 */
export declare const deleteAnalyzer: API.OperationMethod<DeleteAnalyzerRequest, DeleteAnalyzerResponse, DeleteAnalyzerError, Credentials | HttpClient.HttpClient>;
export type DeleteArchiveRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified archive rule.
 */
export declare const deleteArchiveRule: API.OperationMethod<DeleteArchiveRuleRequest, DeleteArchiveRuleResponse, DeleteArchiveRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceLinkedAnalyzerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a service-linked analyzer. This operation can be invoked by both authorized Amazon Web Services services and customers.
 *
 * When invoked by a customer, IAM Access Analyzer performs a callback to the managing service to verify whether the analyzer is still in use and can be deleted. If the service indicates the analyzer is still in use, the deletion is rejected with `ConflictException`.
 */
export declare const deleteServiceLinkedAnalyzer: API.OperationMethod<DeleteServiceLinkedAnalyzerRequest, DeleteServiceLinkedAnalyzerResponse, DeleteServiceLinkedAnalyzerError, Credentials | HttpClient.HttpClient>;
export type GenerateFindingRecommendationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a recommendation for an unused permissions finding.
 */
export declare const generateFindingRecommendation: API.OperationMethod<GenerateFindingRecommendationRequest, GenerateFindingRecommendationResponse, GenerateFindingRecommendationError, Credentials | HttpClient.HttpClient>;
export type GetAccessPreviewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an access preview for the specified analyzer.
 */
export declare const getAccessPreview: API.OperationMethod<GetAccessPreviewRequest, GetAccessPreviewResponse, GetAccessPreviewError, Credentials | HttpClient.HttpClient>;
export type GetAnalyzedResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a resource that was analyzed.
 *
 * This action is supported only for external access analyzers.
 */
export declare const getAnalyzedResource: API.OperationMethod<GetAnalyzedResourceRequest, GetAnalyzedResourceResponse, GetAnalyzedResourceError, Credentials | HttpClient.HttpClient>;
export type GetAnalyzerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified analyzer.
 */
export declare const getAnalyzer: API.OperationMethod<GetAnalyzerRequest, GetAnalyzerResponse, GetAnalyzerError, Credentials | HttpClient.HttpClient>;
export type GetArchiveRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an archive rule.
 *
 * To learn about filter keys that you can use to create an archive rule, see IAM Access Analyzer filter keys in the **IAM User Guide**.
 */
export declare const getArchiveRule: API.OperationMethod<GetArchiveRuleRequest, GetArchiveRuleResponse, GetArchiveRuleError, Credentials | HttpClient.HttpClient>;
export type GetFindingError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified finding. GetFinding and GetFindingV2 both use `access-analyzer:GetFinding` in the `Action` element of an IAM policy statement. You must have permission to perform the `access-analyzer:GetFinding` action.
 *
 * GetFinding is supported only for external access analyzers. You must use GetFindingV2 for internal and unused access analyzers.
 */
export declare const getFinding: API.OperationMethod<GetFindingRequest, GetFindingResponse, GetFindingError, Credentials | HttpClient.HttpClient>;
export type GetFindingRecommendationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a finding recommendation for the specified analyzer.
 */
export declare const getFindingRecommendation: API.PaginatedOperationMethod<GetFindingRecommendationRequest, GetFindingRecommendationResponse, GetFindingRecommendationError, Credentials | HttpClient.HttpClient, RecommendedStep>;
export type GetFindingsStatisticsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of aggregated finding statistics for an external access or unused access analyzer.
 */
export declare const getFindingsStatistics: API.OperationMethod<GetFindingsStatisticsRequest, GetFindingsStatisticsResponse, GetFindingsStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetFindingV2Error = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified finding. GetFinding and GetFindingV2 both use `access-analyzer:GetFinding` in the `Action` element of an IAM policy statement. You must have permission to perform the `access-analyzer:GetFinding` action.
 */
export declare const getFindingV2: API.PaginatedOperationMethod<GetFindingV2Request, GetFindingV2Response, GetFindingV2Error, Credentials | HttpClient.HttpClient, FindingDetails>;
export type GetGeneratedPolicyError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the policy that was generated using `StartPolicyGeneration`.
 */
export declare const getGeneratedPolicy: API.OperationMethod<GetGeneratedPolicyRequest, GetGeneratedPolicyResponse, GetGeneratedPolicyError, Credentials | HttpClient.HttpClient>;
export type ListAccessPreviewFindingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of access preview findings generated by the specified access preview.
 */
export declare const listAccessPreviewFindings: API.PaginatedOperationMethod<ListAccessPreviewFindingsRequest, ListAccessPreviewFindingsResponse, ListAccessPreviewFindingsError, Credentials | HttpClient.HttpClient, AccessPreviewFinding>;
export type ListAccessPreviewsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of access previews for the specified analyzer.
 */
export declare const listAccessPreviews: API.PaginatedOperationMethod<ListAccessPreviewsRequest, ListAccessPreviewsResponse, ListAccessPreviewsError, Credentials | HttpClient.HttpClient, AccessPreviewSummary>;
export type ListAnalyzedResourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of resources of the specified type that have been analyzed by the specified analyzer.
 */
export declare const listAnalyzedResources: API.PaginatedOperationMethod<ListAnalyzedResourcesRequest, ListAnalyzedResourcesResponse, ListAnalyzedResourcesError, Credentials | HttpClient.HttpClient, AnalyzedResourceSummary>;
export type ListAnalyzersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of analyzers.
 */
export declare const listAnalyzers: API.PaginatedOperationMethod<ListAnalyzersRequest, ListAnalyzersResponse, ListAnalyzersError, Credentials | HttpClient.HttpClient, AnalyzerSummary>;
export type ListArchiveRulesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of archive rules created for the specified analyzer.
 */
export declare const listArchiveRules: API.PaginatedOperationMethod<ListArchiveRulesRequest, ListArchiveRulesResponse, ListArchiveRulesError, Credentials | HttpClient.HttpClient, ArchiveRuleSummary>;
export type ListFindingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of findings generated by the specified analyzer. ListFindings and ListFindingsV2 both use `access-analyzer:ListFindings` in the `Action` element of an IAM policy statement. You must have permission to perform the `access-analyzer:ListFindings` action.
 *
 * To learn about filter keys that you can use to retrieve a list of findings, see IAM Access Analyzer filter keys in the **IAM User Guide**.
 *
 * ListFindings is supported only for external access analyzers. You must use ListFindingsV2 for internal and unused access analyzers.
 */
export declare const listFindings: API.PaginatedOperationMethod<ListFindingsRequest, ListFindingsResponse, ListFindingsError, Credentials | HttpClient.HttpClient, FindingSummary>;
export type ListFindingsV2Error = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of findings generated by the specified analyzer. ListFindings and ListFindingsV2 both use `access-analyzer:ListFindings` in the `Action` element of an IAM policy statement. You must have permission to perform the `access-analyzer:ListFindings` action.
 *
 * To learn about filter keys that you can use to retrieve a list of findings, see IAM Access Analyzer filter keys in the **IAM User Guide**.
 */
export declare const listFindingsV2: API.PaginatedOperationMethod<ListFindingsV2Request, ListFindingsV2Response, ListFindingsV2Error, Credentials | HttpClient.HttpClient, FindingSummaryV2>;
export type ListPolicyGenerationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all of the policy generations requested in the last seven days.
 */
export declare const listPolicyGenerations: API.PaginatedOperationMethod<ListPolicyGenerationsRequest, ListPolicyGenerationsResponse, ListPolicyGenerationsError, Credentials | HttpClient.HttpClient, PolicyGeneration>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of tags applied to the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartPolicyGenerationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the policy generation request.
 */
export declare const startPolicyGeneration: API.OperationMethod<StartPolicyGenerationRequest, StartPolicyGenerationResponse, StartPolicyGenerationError, Credentials | HttpClient.HttpClient>;
export type StartResourceScanError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Immediately starts a scan of the policies applied to the specified resource.
 *
 * This action is supported only for external access analyzers.
 */
export declare const startResourceScan: API.OperationMethod<StartResourceScanRequest, StartResourceScanResponse, StartResourceScanError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a tag to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a tag from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAnalyzerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies the configuration of an existing analyzer.
 *
 * This action is not supported for external access analyzers.
 */
export declare const updateAnalyzer: API.OperationMethod<UpdateAnalyzerRequest, UpdateAnalyzerResponse, UpdateAnalyzerError, Credentials | HttpClient.HttpClient>;
export type UpdateArchiveRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the criteria and values for the specified archive rule.
 */
export declare const updateArchiveRule: API.OperationMethod<UpdateArchiveRuleRequest, UpdateArchiveRuleResponse, UpdateArchiveRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateFindingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the status for the specified findings.
 */
export declare const updateFindings: API.OperationMethod<UpdateFindingsRequest, UpdateFindingsResponse, UpdateFindingsError, Credentials | HttpClient.HttpClient>;
export type ValidatePolicyError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Requests the validation of a policy and returns a list of findings. The findings help you identify issues and provide actionable recommendations to resolve the issue and enable you to author functional policies that meet security best practices.
 */
export declare const validatePolicy: API.PaginatedOperationMethod<ValidatePolicyRequest, ValidatePolicyResponse, ValidatePolicyError, Credentials | HttpClient.HttpClient, ValidatePolicyFinding>;
export {};
//# sourceMappingURL=accessanalyzer.d.ts.map