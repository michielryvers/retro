import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const GatewayTimedOutException_base: S.TaggedErrorClass<"GatewayTimedOutException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class GatewayTimedOutException extends /*@__PURE__*/ GatewayTimedOutException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestException_base: S.TaggedErrorClass<"TooManyRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestException extends /*@__PURE__*/ TooManyRequestException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type FeedId = string;
export type AssociatedResourceName = string;
export type ResourceName = string;
export type S3Uri = string;
export type TemplateUriList = string[];
export interface TemplateGroup {
    name: string;
    templateUris: string[];
}
export type TemplateGroupList = TemplateGroup[];
export interface CroppingConfig {
    templateGroups?: TemplateGroup[];
}
export type ResourceDescription = string;
export type FixtureId = string;
export interface DataSourceConfiguration {
    fixtureId: string;
}
export interface ClippingConfig {
    callbackMetadata?: string;
    dataSourceConfiguration?: DataSourceConfiguration;
}
export type TranscriptionLanguage = "eng" | "eng-au" | "eng-gb" | "eng-us" | "fra" | "ita" | "deu" | "spa" | "por" | (string & {});
export interface AspectRatio {
    width: number;
    height: number;
}
export type DictionaryId = string;
export type ProfanityFilterMode = "DISABLED" | "CENSOR" | "DROP" | (string & {});
export interface SubtitlingConfig {
    language: TranscriptionLanguage;
    aspectRatio?: AspectRatio;
    dictionary?: string;
    profanityFilter?: ProfanityFilterMode;
}
export type SummaryGenerationMode = "ENABLED" | "DISABLED" | (string & {});
export type ExtendedAnalysisMode = "ENABLED" | "DISABLED" | (string & {});
export interface ContextualMetadataConfig {
    summaryGeneration?: SummaryGenerationMode;
    extendedAnalysis?: ExtendedAnalysisMode;
}
export type OutputConfig = {
    cropping: CroppingConfig;
    clipping?: never;
    subtitling?: never;
    contextualMetadata?: never;
} | {
    cropping?: never;
    clipping: ClippingConfig;
    subtitling?: never;
    contextualMetadata?: never;
} | {
    cropping?: never;
    clipping?: never;
    subtitling: SubtitlingConfig;
    contextualMetadata?: never;
} | {
    cropping?: never;
    clipping?: never;
    subtitling?: never;
    contextualMetadata: ContextualMetadataConfig;
};
export type OutputStatus = "ENABLED" | "DISABLED" | (string & {});
export interface CreateOutput {
    name: string;
    outputConfig: OutputConfig;
    status: OutputStatus;
    description?: string;
}
export type CreateOutputList = CreateOutput[];
export interface AssociateFeedRequest {
    id: string;
    associatedResourceName: string;
    outputs: CreateOutput[];
    dryRun?: boolean;
}
export type FeedArn = string;
export interface AssociateFeedResponse {
    arn: string;
    id: string;
}
export type DictionaryLanguage = "eng" | "fra" | "ita" | "deu" | "spa" | "por" | (string & {});
export type DictionaryEntriesPayload = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateDictionaryRequest {
    name: string;
    language: DictionaryLanguage;
    entries?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type DictionaryArn = string;
export type DictionaryStatus = "CREATING" | "AVAILABLE" | "REFERENCED" | "DELETING" | "DELETED" | (string & {});
export type FeedReferences = string[];
export interface CreateDictionaryResponse {
    name: string;
    arn: string;
    id: string;
    language: DictionaryLanguage;
    status: DictionaryStatus;
    references?: string[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export type IamRoleArn = string;
export interface CreateFeedRequest {
    name: string;
    accessRoleArn?: string;
    outputs: CreateOutput[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export type StringList = string[];
export interface GetOutput {
    name: string;
    outputConfig: OutputConfig;
    status: OutputStatus;
    description?: string;
    fromAssociation?: boolean;
}
export type GetOutputList = GetOutput[];
export type FeedStatus = "CREATING" | "AVAILABLE" | "ACTIVE" | "UPDATING" | "DELETING" | "DELETED" | "ARCHIVED" | (string & {});
export interface FeedAssociation {
    associatedResourceName: string;
}
export interface CreateFeedResponse {
    arn: string;
    name: string;
    id: string;
    dataEndpoints: string[];
    outputs: GetOutput[];
    accessRoleArn?: string;
    status: FeedStatus;
    association?: FeedAssociation;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface DeleteDictionaryRequest {
    id: string;
}
export interface DeleteDictionaryResponse {
    arn: string;
    id: string;
    status: DictionaryStatus;
}
export interface DeleteFeedRequest {
    id: string;
}
export interface DeleteFeedResponse {
    arn: string;
    id: string;
    status: FeedStatus;
}
export interface DeleteFeedPolicyRequest {
    id: string;
}
export interface DeleteFeedPolicyResponse {
}
export interface DisassociateFeedRequest {
    id: string;
    associatedResourceName: string;
    dryRun?: boolean;
}
export interface DisassociateFeedResponse {
    arn: string;
    id: string;
}
export interface ExportDictionaryEntriesRequest {
    id: string;
}
export interface ExportDictionaryEntriesResponse {
    entries?: string;
}
export interface GetDictionaryRequest {
    id: string;
}
export interface GetDictionaryResponse {
    name: string;
    arn: string;
    id: string;
    language: DictionaryLanguage;
    status: DictionaryStatus;
    references?: string[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetFeedRequest {
    id: string;
}
export interface GetFeedResponse {
    arn: string;
    name: string;
    id: string;
    dataEndpoints: string[];
    outputs: GetOutput[];
    accessRoleArn?: string;
    status: FeedStatus;
    association?: FeedAssociation;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetFeedPolicyRequest {
    id: string;
}
export type PolicyDocument = string;
export interface GetFeedPolicyResponse {
    policy: string;
}
export interface GetFixtureRequest {
    fixtureId: string;
}
export interface Competitor {
    name?: string;
    isHome?: boolean;
}
export type CompetitorList = Competitor[];
export interface GetFixtureResponse {
    fixtureId: string;
    name: string;
    fixtureGroup?: string;
    scheduledStart?: Date;
    status: string;
    competitors: Competitor[];
}
export interface ListDictionariesRequest {
    maxResults?: number;
    nextToken?: string;
}
export interface DictionarySummary {
    arn: string;
    id: string;
    name: string;
    language: DictionaryLanguage;
    status: DictionaryStatus;
}
export type DictionarySummaryList = DictionarySummary[];
export interface ListDictionariesResponse {
    dictionaries: DictionarySummary[];
    nextToken?: string;
}
export interface ListFeedsRequest {
    maxResults?: number;
    nextToken?: string;
}
export interface FeedSummary {
    arn: string;
    id: string;
    name: string;
    association?: FeedAssociation;
    status: FeedStatus;
}
export type FeedSummaryList = FeedSummary[];
export interface ListFeedsResponse {
    feeds: FeedSummary[];
    nextToken?: string;
}
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface PutFeedPolicyRequest {
    id: string;
    policy: string;
}
export interface PutFeedPolicyResponse {
}
export type DataSourceSport = "basketball" | "american-football" | (string & {});
export type FixtureDate = string;
export type FilterName = "COMPETITOR" | (string & {});
export type FilterValue = string;
export type FilterValueList = string[];
export interface SearchFilter {
    name: FilterName;
    values: string[];
}
export type SearchFilterList = SearchFilter[];
export interface SearchFixturesRequest {
    sport: DataSourceSport;
    startDate: string;
    endDate?: string;
    filters?: SearchFilter[];
    maxResults?: number;
    nextToken?: string;
}
export interface FixtureSummary {
    fixtureId: string;
    name: string;
    fixtureGroup?: string;
    scheduledStart?: Date;
    status: string;
    competitors: Competitor[];
}
export type FixtureSummaryList = FixtureSummary[];
export interface SearchFixturesResponse {
    fixtures: FixtureSummary[];
    nextToken?: string;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateDictionaryRequest {
    id: string;
    name?: string;
    language?: DictionaryLanguage;
    entries?: string;
}
export interface UpdateDictionaryResponse {
    name: string;
    arn: string;
    id: string;
    language: DictionaryLanguage;
    status: DictionaryStatus;
    references?: string[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface UpdateOutput {
    name: string;
    outputConfig: OutputConfig;
    status: OutputStatus;
    description?: string;
    fromAssociation?: boolean;
}
export type UpdateOutputList = UpdateOutput[];
export interface UpdateFeedRequest {
    name: string;
    accessRoleArn?: string;
    id: string;
    outputs: UpdateOutput[];
}
export interface UpdateFeedResponse {
    arn: string;
    name: string;
    id: string;
    dataEndpoints: string[];
    outputs: GetOutput[];
    accessRoleArn?: string;
    status: FeedStatus;
    association?: FeedAssociation;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type AssociateFeedError = AccessDeniedException | ConflictException | InternalServerErrorException | ResourceNotFoundException | ServiceQuotaExceededException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Associates a resource with the feed. The resource provides the input that Elemental Inference needs in order to perform an Elemental Inference feature, such as cropping video. You always provide the resource by associating it with a feed. You can associate only one resource with each feed. With an association, a specific source media is claiming ownership of the feed.
 *
 * AssociateFeed is a PATCH operation, which means that you can include only parameters that you want to change. Parameters that you don't include will not be affected by the operation.
 *
 * Specifically:
 *
 * - You can add more outputs to the existing outputs. New outputs will be appended.
 *
 * - You can't modify an existing output (for example to change its name). Instead, use UpdateFeed.
 *
 * - You can't delete an existing output. Instead, use UpdateFeed.
 *
 * Also note that you can't change the feed name with AssociateFeed. Instead, use UpdateFeed.
 */
export declare const associateFeed: API.OperationMethod<AssociateFeedRequest, AssociateFeedResponse, AssociateFeedError, Credentials | HttpClient.HttpClient>;
export type CreateDictionaryError = AccessDeniedException | ConflictException | InternalServerErrorException | ServiceQuotaExceededException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Creates a custom dictionary for improving transcription accuracy. A dictionary contains custom words and phrases that the ASR engine might not recognize, such as brand names, technical terms, or proper nouns. You can reference a dictionary when configuring a smart subtitles output.
 */
export declare const createDictionary: API.OperationMethod<CreateDictionaryRequest, CreateDictionaryResponse, CreateDictionaryError, Credentials | HttpClient.HttpClient>;
export type CreateFeedError = AccessDeniedException | ConflictException | InternalServerErrorException | ServiceQuotaExceededException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Creates a feed. The feed is the target for the live media stream that is being sent by the calling application. An example of a calling application is AWS Elemental MediaLive.
 *
 * The key contents of the feed is an array of outputs. Each output represents an Elemental Inference feature. After you create the feed, you must associate a resource with the feed. At that point, you will have a useable feed: resource - feed - output or outputs.
 */
export declare const createFeed: API.OperationMethod<CreateFeedRequest, CreateFeedResponse, CreateFeedError, Credentials | HttpClient.HttpClient>;
export type DeleteDictionaryError = AccessDeniedException | ConflictException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Deletes the specified dictionary. You cannot delete a dictionary that is referenced by a feed. You must first remove the dictionary reference from the feed's subtitling configuration.
 */
export declare const deleteDictionary: API.OperationMethod<DeleteDictionaryRequest, DeleteDictionaryResponse, DeleteDictionaryError, Credentials | HttpClient.HttpClient>;
export type DeleteFeedError = AccessDeniedException | ConflictException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Deletes the specified feed. You can delete the feed at any time. Elemental Inference doesn't block you from deleting a feed when the calling application is calling PutMedia or GetMetadata on that feed, although both these calls will start to fail. For more information about managing inactive feeds, see the Elemental Inference User Guide.
 */
export declare const deleteFeed: API.OperationMethod<DeleteFeedRequest, DeleteFeedResponse, DeleteFeedError, Credentials | HttpClient.HttpClient>;
export type DeleteFeedPolicyError = AccessDeniedException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Deletes the resource-based policy attached to the specified feed. After you delete the policy, the operation revokes the cross-account access that the policy granted.
 */
export declare const deleteFeedPolicy: API.OperationMethod<DeleteFeedPolicyRequest, DeleteFeedPolicyResponse, DeleteFeedPolicyError, Credentials | HttpClient.HttpClient>;
export type DisassociateFeedError = AccessDeniedException | ConflictException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Releases the resource (the source media) that is associated with this feed. The outputs in the feed become DISABLED.
 */
export declare const disassociateFeed: API.OperationMethod<DisassociateFeedRequest, DisassociateFeedResponse, DisassociateFeedError, Credentials | HttpClient.HttpClient>;
export type ExportDictionaryEntriesError = AccessDeniedException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Exports the entries from the specified dictionary.
 */
export declare const exportDictionaryEntries: API.OperationMethod<ExportDictionaryEntriesRequest, ExportDictionaryEntriesResponse, ExportDictionaryEntriesError, Credentials | HttpClient.HttpClient>;
export type GetDictionaryError = AccessDeniedException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified dictionary.
 */
export declare const getDictionary: API.OperationMethod<GetDictionaryRequest, GetDictionaryResponse, GetDictionaryError, Credentials | HttpClient.HttpClient>;
export type GetFeedError = AccessDeniedException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | CommonErrors;
/**
 * Retrieves information about the specified feed.
 */
export declare const getFeed: API.OperationMethod<GetFeedRequest, GetFeedResponse, GetFeedError, Credentials | HttpClient.HttpClient>;
export type GetFeedPolicyError = AccessDeniedException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Retrieves the resource-based policy attached to the specified feed.
 */
export declare const getFeedPolicy: API.OperationMethod<GetFeedPolicyRequest, GetFeedPolicyResponse, GetFeedPolicyError, Credentials | HttpClient.HttpClient>;
export type GetFixtureError = AccessDeniedException | GatewayTimedOutException | InternalServerErrorException | ResourceNotFoundException | ServiceUnavailableException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified fixture (a sports event, such as a specific basketball game). You obtain a fixtureId from SearchFixtures, or from the clipping output of a feed.
 */
export declare const getFixture: API.OperationMethod<GetFixtureRequest, GetFixtureResponse, GetFixtureError, Credentials | HttpClient.HttpClient>;
export type ListDictionariesError = AccessDeniedException | InternalServerErrorException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Lists the dictionaries in your account.
 */
export declare const listDictionaries: API.PaginatedOperationMethod<ListDictionariesRequest, ListDictionariesResponse, ListDictionariesError, Credentials | HttpClient.HttpClient, DictionarySummary>;
export type ListFeedsError = AccessDeniedException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Displays a list of feeds that belong to this AWS account.
 */
export declare const listFeeds: API.PaginatedOperationMethod<ListFeedsRequest, ListFeedsResponse, ListFeedsError, Credentials | HttpClient.HttpClient, FeedSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * List all tags that are on an Elemental Inference resource in the current region.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutFeedPolicyError = AccessDeniedException | ConflictException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Attaches or replaces a resource-based policy on the specified feed. A resource-based policy grants cross-account access to the feed.
 */
export declare const putFeedPolicy: API.OperationMethod<PutFeedPolicyRequest, PutFeedPolicyResponse, PutFeedPolicyError, Credentials | HttpClient.HttpClient>;
export type SearchFixturesError = AccessDeniedException | GatewayTimedOutException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Searches for the fixtures (sports events, such as a specific basketball game) that are available for a sport in a date window. Each fixture in the response includes a fixtureId that you specify in the clipping output of a feed, so that Elemental Inference maps the event data for that fixture onto the clipping metadata. This operation is paginated: if there are more fixtures than fit in one page, the response includes a nextToken that you pass in a subsequent request.
 */
export declare const searchFixtures: API.PaginatedOperationMethod<SearchFixturesRequest, SearchFixturesResponse, SearchFixturesError, Credentials | HttpClient.HttpClient, FixtureSummary>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Associates the specified tags to the resource identified by the specified resourceArn in the current region. If existing tags on a resource are not specified in the request parameters, they are not changed. When a resource is deleted, the tags associated with that resource are also deleted.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Deletes specified tags from the specified resource in the current region.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDictionaryError = AccessDeniedException | ConflictException | InternalServerErrorException | ResourceNotFoundException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Updates the specified dictionary.
 */
export declare const updateDictionary: API.OperationMethod<UpdateDictionaryRequest, UpdateDictionaryResponse, UpdateDictionaryError, Credentials | HttpClient.HttpClient>;
export type UpdateFeedError = AccessDeniedException | ConflictException | InternalServerErrorException | ResourceNotFoundException | ServiceQuotaExceededException | TooManyRequestException | ValidationException | CommonErrors;
/**
 * Updates the name and/or outputs in a feed.
 *
 * UpdateFeed is a PUT operation, which means that the payload that you specify completely overwrites the existing payload.
 *
 * This means that if you want to touch the array of outputs, you must pass in the full new list. So you must omit outputs you want to delete, and include outputs you want to add or modify.
 *
 * If you want to patch the array of outputs to make selective additions, use AssociateFeed.
 */
export declare const updateFeed: API.OperationMethod<UpdateFeedRequest, UpdateFeedResponse, UpdateFeedError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=elementalinference.d.ts.map