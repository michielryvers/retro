import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type TunnelId = string;
export type DeleteFlag = boolean;
export interface CloseTunnelRequest {
    tunnelId: string;
    delete?: boolean;
}
export interface CloseTunnelResponse {
}
export interface DescribeTunnelRequest {
    tunnelId: string;
}
export type TunnelArn = string;
export type TunnelStatus = "OPEN" | "CLOSED" | (string & {});
export type ConnectionStatus = "CONNECTED" | "DISCONNECTED" | (string & {});
export interface ConnectionState {
    status?: ConnectionStatus;
    lastUpdatedAt?: Date;
}
export type Description = string;
export type ThingName = string;
export type Service = string;
export type ServiceList = string[];
export interface DestinationConfig {
    thingName?: string;
    services: string[];
}
export type TimeoutInMin = number;
export interface TimeoutConfig {
    maxLifetimeTimeoutMinutes?: number;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagList = Tag[];
export interface Tunnel {
    tunnelId?: string;
    tunnelArn?: string;
    status?: TunnelStatus;
    sourceConnectionState?: ConnectionState;
    destinationConnectionState?: ConnectionState;
    description?: string;
    destinationConfig?: DestinationConfig;
    timeoutConfig?: TimeoutConfig;
    tags?: Tag[];
    createdAt?: Date;
    lastUpdatedAt?: Date;
}
export interface DescribeTunnelResponse {
    tunnel?: Tunnel;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[];
}
export type MaxResults = number;
export type NextToken = string;
export interface ListTunnelsRequest {
    thingName?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface TunnelSummary {
    tunnelId?: string;
    tunnelArn?: string;
    status?: TunnelStatus;
    description?: string;
    createdAt?: Date;
    lastUpdatedAt?: Date;
}
export type TunnelSummaryList = TunnelSummary[];
export interface ListTunnelsResponse {
    tunnelSummaries?: TunnelSummary[];
    nextToken?: string;
}
export interface OpenTunnelRequest {
    description?: string;
    tags?: Tag[];
    destinationConfig?: DestinationConfig;
    timeoutConfig?: TimeoutConfig;
}
export type ClientAccessToken = string | redacted.Redacted<string>;
export interface OpenTunnelResponse {
    tunnelId?: string;
    tunnelArn?: string;
    sourceAccessToken?: string | redacted.Redacted<string>;
    destinationAccessToken?: string | redacted.Redacted<string>;
}
export type ClientMode = "SOURCE" | "DESTINATION" | "ALL" | (string & {});
export interface RotateTunnelAccessTokenRequest {
    tunnelId: string;
    clientMode: ClientMode;
    destinationConfig?: DestinationConfig;
}
export interface RotateTunnelAccessTokenResponse {
    tunnelArn?: string;
    sourceAccessToken?: string | redacted.Redacted<string>;
    destinationAccessToken?: string | redacted.Redacted<string>;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export type ErrorMessage = string;
export type CloseTunnelError = ResourceNotFoundException | CommonErrors;
/**
 * Closes a tunnel identified by the unique tunnel id. When a `CloseTunnel`
 * request is received, we close the WebSocket connections between the client and proxy
 * server so no data can be transmitted.
 *
 * Requires permission to access the CloseTunnel action.
 */
export declare const closeTunnel: API.OperationMethod<CloseTunnelRequest, CloseTunnelResponse, CloseTunnelError, Credentials | HttpClient.HttpClient>;
export type DescribeTunnelError = ResourceNotFoundException | CommonErrors;
/**
 * Gets information about a tunnel identified by the unique tunnel id.
 *
 * Requires permission to access the DescribeTunnel action.
 */
export declare const describeTunnel: API.OperationMethod<DescribeTunnelRequest, DescribeTunnelResponse, DescribeTunnelError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Lists the tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTunnelsError = CommonErrors;
/**
 * List all tunnels for an Amazon Web Services account. Tunnels are listed by creation time in
 * descending order, newer tunnels will be listed before older tunnels.
 *
 * Requires permission to access the ListTunnels action.
 */
export declare const listTunnels: API.PaginatedOperationMethod<ListTunnelsRequest, ListTunnelsResponse, ListTunnelsError, Credentials | HttpClient.HttpClient, unknown>;
export type OpenTunnelError = LimitExceededException | CommonErrors;
/**
 * Creates a new tunnel, and returns two client access tokens for clients to use to
 * connect to the IoT Secure Tunneling proxy server.
 *
 * Requires permission to access the OpenTunnel action.
 */
export declare const openTunnel: API.OperationMethod<OpenTunnelRequest, OpenTunnelResponse, OpenTunnelError, Credentials | HttpClient.HttpClient>;
export type RotateTunnelAccessTokenError = ResourceNotFoundException | CommonErrors;
/**
 * Revokes the current client access token (CAT) and returns new CAT for clients to
 * use when reconnecting to secure tunneling to access the same tunnel.
 *
 * Requires permission to access the RotateTunnelAccessToken action.
 *
 * Rotating the CAT doesn't extend the tunnel duration. For example, say the tunnel
 * duration is 12 hours and the tunnel has already been open for 4 hours. When you
 * rotate the access tokens, the new tokens that are generated can only be used for the
 * remaining 8 hours.
 */
export declare const rotateTunnelAccessToken: API.OperationMethod<RotateTunnelAccessTokenRequest, RotateTunnelAccessTokenResponse, RotateTunnelAccessTokenError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * A resource tag.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Removes a tag from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iotsecuretunneling.d.ts.map