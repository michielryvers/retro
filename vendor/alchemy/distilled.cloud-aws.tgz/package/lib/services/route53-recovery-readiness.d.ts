import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type __listOf__string = string[];
export type Tags = {
    [key: string]: string | undefined;
};
export interface CreateCellRequest {
    CellName?: string;
    Cells?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __stringMax256 = string;
export type __stringMax64PatternAAZAZ09Z = string;
export interface CreateCellResponse {
    CellArn?: string;
    CellName?: string;
    Cells?: string[];
    ParentReadinessScopes?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type CrossAccountAuthorization = string;
export interface CreateCrossAccountAuthorizationRequest {
    CrossAccountAuthorization?: string;
}
export interface CreateCrossAccountAuthorizationResponse {
    CrossAccountAuthorization?: string;
}
export interface CreateReadinessCheckRequest {
    ReadinessCheckName?: string;
    ResourceSetName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateReadinessCheckResponse {
    ReadinessCheckArn?: string;
    ReadinessCheckName?: string;
    ResourceSet?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateRecoveryGroupRequest {
    Cells?: string[];
    RecoveryGroupName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateRecoveryGroupResponse {
    Cells?: string[];
    RecoveryGroupArn?: string;
    RecoveryGroupName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __stringPatternAWSAZaZ09AZaZ09 = string;
export interface NLBResource {
    Arn?: string;
}
export interface R53ResourceRecord {
    DomainName?: string;
    RecordSetId?: string;
}
export interface TargetResource {
    NLBResource?: NLBResource;
    R53Resource?: R53ResourceRecord;
}
export interface DNSTargetResource {
    DomainName?: string;
    HostedZoneArn?: string;
    RecordSetId?: string;
    RecordType?: string;
    TargetResource?: TargetResource;
}
export interface Resource {
    ComponentId?: string;
    DnsTargetResource?: DNSTargetResource;
    ReadinessScopes?: string[];
    ResourceArn?: string;
}
export type __listOfResource = Resource[];
export interface CreateResourceSetRequest {
    ResourceSetName?: string;
    ResourceSetType?: string;
    Resources?: Resource[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateResourceSetResponse {
    ResourceSetArn?: string;
    ResourceSetName?: string;
    ResourceSetType?: string;
    Resources?: Resource[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DeleteCellRequest {
    CellName: string;
}
export interface DeleteCellResponse {
}
export interface DeleteCrossAccountAuthorizationRequest {
    CrossAccountAuthorization: string;
}
export interface DeleteCrossAccountAuthorizationResponse {
}
export interface DeleteReadinessCheckRequest {
    ReadinessCheckName: string;
}
export interface DeleteReadinessCheckResponse {
}
export interface DeleteRecoveryGroupRequest {
    RecoveryGroupName: string;
}
export interface DeleteRecoveryGroupResponse {
}
export interface DeleteResourceSetRequest {
    ResourceSetName: string;
}
export interface DeleteResourceSetResponse {
}
export type MaxResults = number;
export interface GetArchitectureRecommendationsRequest {
    MaxResults?: number;
    NextToken?: string;
    RecoveryGroupName: string;
}
export type LastAuditTimestamp = Date;
export interface Recommendation {
    RecommendationText?: string;
}
export type __listOfRecommendation = Recommendation[];
export interface GetArchitectureRecommendationsResponse {
    LastAuditTimestamp?: Date;
    NextToken?: string;
    Recommendations?: (Recommendation & {
        RecommendationText: string;
    })[];
}
export interface GetCellRequest {
    CellName: string;
}
export interface GetCellResponse {
    CellArn?: string;
    CellName?: string;
    Cells?: string[];
    ParentReadinessScopes?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetCellReadinessSummaryRequest {
    CellName: string;
    MaxResults?: number;
    NextToken?: string;
}
export type Readiness = "READY" | "NOT_READY" | "UNKNOWN" | "NOT_AUTHORIZED" | (string & {});
export interface ReadinessCheckSummary {
    Readiness?: Readiness;
    ReadinessCheckName?: string;
}
export type __listOfReadinessCheckSummary = ReadinessCheckSummary[];
export interface GetCellReadinessSummaryResponse {
    NextToken?: string;
    Readiness?: Readiness;
    ReadinessChecks?: ReadinessCheckSummary[];
}
export interface GetReadinessCheckRequest {
    ReadinessCheckName: string;
}
export interface GetReadinessCheckResponse {
    ReadinessCheckArn?: string;
    ReadinessCheckName?: string;
    ResourceSet?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetReadinessCheckResourceStatusRequest {
    MaxResults?: number;
    NextToken?: string;
    ReadinessCheckName: string;
    ResourceIdentifier: string;
}
export type ReadinessCheckTimestamp = Date;
export interface Message {
    MessageText?: string;
}
export type __listOfMessage = Message[];
export interface RuleResult {
    LastCheckedTimestamp?: Date;
    Messages?: Message[];
    Readiness?: Readiness;
    RuleId?: string;
}
export type __listOfRuleResult = RuleResult[];
export interface GetReadinessCheckResourceStatusResponse {
    NextToken?: string;
    Readiness?: Readiness;
    Rules?: (RuleResult & {
        LastCheckedTimestamp: ReadinessCheckTimestamp;
        Messages: __listOfMessage;
        Readiness: Readiness;
        RuleId: string;
    })[];
}
export interface GetReadinessCheckStatusRequest {
    MaxResults?: number;
    NextToken?: string;
    ReadinessCheckName: string;
}
export interface ResourceResult {
    ComponentId?: string;
    LastCheckedTimestamp?: Date;
    Readiness?: Readiness;
    ResourceArn?: string;
}
export type __listOfResourceResult = ResourceResult[];
export interface GetReadinessCheckStatusResponse {
    Messages?: Message[];
    NextToken?: string;
    Readiness?: Readiness;
    Resources?: (ResourceResult & {
        LastCheckedTimestamp: ReadinessCheckTimestamp;
        Readiness: Readiness;
    })[];
}
export interface GetRecoveryGroupRequest {
    RecoveryGroupName: string;
}
export interface GetRecoveryGroupResponse {
    Cells?: string[];
    RecoveryGroupArn?: string;
    RecoveryGroupName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetRecoveryGroupReadinessSummaryRequest {
    MaxResults?: number;
    NextToken?: string;
    RecoveryGroupName: string;
}
export interface GetRecoveryGroupReadinessSummaryResponse {
    NextToken?: string;
    Readiness?: Readiness;
    ReadinessChecks?: ReadinessCheckSummary[];
}
export interface GetResourceSetRequest {
    ResourceSetName: string;
}
export interface GetResourceSetResponse {
    ResourceSetArn?: string;
    ResourceSetName?: string;
    ResourceSetType?: string;
    Resources?: Resource[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListCellsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface CellOutput {
    CellArn?: string;
    CellName?: string;
    Cells?: string[];
    ParentReadinessScopes?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfCellOutput = CellOutput[];
export interface ListCellsResponse {
    Cells?: (CellOutput & {
        CellArn: __stringMax256;
        CellName: __stringMax64PatternAAZAZ09Z;
        Cells: __listOf__string;
        ParentReadinessScopes: __listOf__string;
    })[];
    NextToken?: string;
}
export interface ListCrossAccountAuthorizationsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export type __listOfCrossAccountAuthorization = string[];
export interface ListCrossAccountAuthorizationsResponse {
    CrossAccountAuthorizations?: string[];
    NextToken?: string;
}
export interface ListReadinessChecksRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface ReadinessCheckOutput {
    ReadinessCheckArn?: string;
    ReadinessCheckName?: string;
    ResourceSet?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfReadinessCheckOutput = ReadinessCheckOutput[];
export interface ListReadinessChecksResponse {
    NextToken?: string;
    ReadinessChecks?: (ReadinessCheckOutput & {
        ReadinessCheckArn: __stringMax256;
        ResourceSet: __stringMax64PatternAAZAZ09Z;
    })[];
}
export interface ListRecoveryGroupsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface RecoveryGroupOutput {
    Cells?: string[];
    RecoveryGroupArn?: string;
    RecoveryGroupName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfRecoveryGroupOutput = RecoveryGroupOutput[];
export interface ListRecoveryGroupsResponse {
    NextToken?: string;
    RecoveryGroups?: (RecoveryGroupOutput & {
        Cells: __listOf__string;
        RecoveryGroupArn: __stringMax256;
        RecoveryGroupName: __stringMax64PatternAAZAZ09Z;
    })[];
}
export interface ListResourceSetsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface ResourceSetOutput {
    ResourceSetArn?: string;
    ResourceSetName?: string;
    ResourceSetType?: string;
    Resources?: Resource[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfResourceSetOutput = ResourceSetOutput[];
export interface ListResourceSetsResponse {
    NextToken?: string;
    ResourceSets?: (ResourceSetOutput & {
        ResourceSetArn: __stringMax256;
        ResourceSetName: __stringMax64PatternAAZAZ09Z;
        ResourceSetType: __stringPatternAWSAZaZ09AZaZ09;
        Resources: __listOfResource;
    })[];
}
export interface ListRulesRequest {
    MaxResults?: number;
    NextToken?: string;
    ResourceType?: string;
}
export type __stringMax64 = string;
export interface ListRulesOutput {
    ResourceType?: string;
    RuleDescription?: string;
    RuleId?: string;
}
export type __listOfListRulesOutput = ListRulesOutput[];
export interface ListRulesResponse {
    NextToken?: string;
    Rules?: (ListRulesOutput & {
        ResourceType: __stringMax64;
        RuleDescription: __stringMax256;
        RuleId: __stringMax64;
    })[];
}
export interface ListTagsForResourcesRequest {
    ResourceArn: string;
}
export interface ListTagsForResourcesResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateCellRequest {
    CellName: string;
    Cells?: string[];
}
export interface UpdateCellResponse {
    CellArn?: string;
    CellName?: string;
    Cells?: string[];
    ParentReadinessScopes?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface UpdateReadinessCheckRequest {
    ReadinessCheckName: string;
    ResourceSetName?: string;
}
export interface UpdateReadinessCheckResponse {
    ReadinessCheckArn?: string;
    ReadinessCheckName?: string;
    ResourceSet?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface UpdateRecoveryGroupRequest {
    Cells?: string[];
    RecoveryGroupName: string;
}
export interface UpdateRecoveryGroupResponse {
    Cells?: string[];
    RecoveryGroupArn?: string;
    RecoveryGroupName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface UpdateResourceSetRequest {
    ResourceSetName: string;
    ResourceSetType?: string;
    Resources?: Resource[];
}
export interface UpdateResourceSetResponse {
    ResourceSetArn?: string;
    ResourceSetName?: string;
    ResourceSetType?: string;
    Resources?: Resource[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type CreateCellError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a cell in an account.
 */
export declare const createCell: API.OperationMethod<CreateCellRequest, CreateCellResponse, CreateCellError, Credentials | HttpClient.HttpClient>;
export type CreateCrossAccountAuthorizationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a cross-account readiness authorization. This lets you authorize another account to work with Route 53 Application Recovery Controller, for example, to check the readiness status of resources in a separate account.
 */
export declare const createCrossAccountAuthorization: API.OperationMethod<CreateCrossAccountAuthorizationRequest, CreateCrossAccountAuthorizationResponse, CreateCrossAccountAuthorizationError, Credentials | HttpClient.HttpClient>;
export type CreateReadinessCheckError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a readiness check in an account. A readiness check monitors a resource set in your application, such as a set of Amazon Aurora instances, that Application Recovery Controller is auditing recovery readiness for. The audits run once every minute on every resource that's associated with a readiness check.
 */
export declare const createReadinessCheck: API.OperationMethod<CreateReadinessCheckRequest, CreateReadinessCheckResponse, CreateReadinessCheckError, Credentials | HttpClient.HttpClient>;
export type CreateRecoveryGroupError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a recovery group in an account. A recovery group corresponds to an application and includes a list of the cells that make up the application.
 */
export declare const createRecoveryGroup: API.OperationMethod<CreateRecoveryGroupRequest, CreateRecoveryGroupResponse, CreateRecoveryGroupError, Credentials | HttpClient.HttpClient>;
export type CreateResourceSetError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a resource set. A resource set is a set of resources of one type that span multiple cells. You can associate a resource set with a readiness check to monitor the resources for failover readiness.
 */
export declare const createResourceSet: API.OperationMethod<CreateResourceSetRequest, CreateResourceSetResponse, CreateResourceSetError, Credentials | HttpClient.HttpClient>;
export type DeleteCellError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a cell. When successful, the response code is 204, with no response body.
 */
export declare const deleteCell: API.OperationMethod<DeleteCellRequest, DeleteCellResponse, DeleteCellError, Credentials | HttpClient.HttpClient>;
export type DeleteCrossAccountAuthorizationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes cross account readiness authorization.
 */
export declare const deleteCrossAccountAuthorization: API.OperationMethod<DeleteCrossAccountAuthorizationRequest, DeleteCrossAccountAuthorizationResponse, DeleteCrossAccountAuthorizationError, Credentials | HttpClient.HttpClient>;
export type DeleteReadinessCheckError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a readiness check.
 */
export declare const deleteReadinessCheck: API.OperationMethod<DeleteReadinessCheckRequest, DeleteReadinessCheckResponse, DeleteReadinessCheckError, Credentials | HttpClient.HttpClient>;
export type DeleteRecoveryGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a recovery group.
 */
export declare const deleteRecoveryGroup: API.OperationMethod<DeleteRecoveryGroupRequest, DeleteRecoveryGroupResponse, DeleteRecoveryGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a resource set.
 */
export declare const deleteResourceSet: API.OperationMethod<DeleteResourceSetRequest, DeleteResourceSetResponse, DeleteResourceSetError, Credentials | HttpClient.HttpClient>;
export type GetArchitectureRecommendationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets recommendations about architecture designs for improving resiliency for an application, based on a recovery group.
 */
export declare const getArchitectureRecommendations: API.OperationMethod<GetArchitectureRecommendationsRequest, GetArchitectureRecommendationsResponse, GetArchitectureRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetCellError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a cell including cell name, cell Amazon Resource Name (ARN), ARNs of nested cells for this cell, and a list of those cell ARNs with their associated recovery group ARNs.
 */
export declare const getCell: API.OperationMethod<GetCellRequest, GetCellResponse, GetCellError, Credentials | HttpClient.HttpClient>;
export type GetCellReadinessSummaryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets readiness for a cell. Aggregates the readiness of all the resources that are associated with the cell into a single value.
 */
export declare const getCellReadinessSummary: API.PaginatedOperationMethod<GetCellReadinessSummaryRequest, GetCellReadinessSummaryResponse, GetCellReadinessSummaryError, Credentials | HttpClient.HttpClient, ReadinessCheckSummary>;
export type GetReadinessCheckError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets details about a readiness check.
 */
export declare const getReadinessCheck: API.OperationMethod<GetReadinessCheckRequest, GetReadinessCheckResponse, GetReadinessCheckError, Credentials | HttpClient.HttpClient>;
export type GetReadinessCheckResourceStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets individual readiness status for a readiness check. To see the overall readiness status for a recovery group, that considers the readiness status for all the readiness checks in the recovery group, use GetRecoveryGroupReadinessSummary.
 */
export declare const getReadinessCheckResourceStatus: API.PaginatedOperationMethod<GetReadinessCheckResourceStatusRequest, GetReadinessCheckResourceStatusResponse, GetReadinessCheckResourceStatusError, Credentials | HttpClient.HttpClient, RuleResult>;
export type GetReadinessCheckStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the readiness status for an individual readiness check. To see the overall readiness status for a recovery group, that considers the readiness status for all the readiness checks in a recovery group, use GetRecoveryGroupReadinessSummary.
 */
export declare const getReadinessCheckStatus: API.PaginatedOperationMethod<GetReadinessCheckStatusRequest, GetReadinessCheckStatusResponse, GetReadinessCheckStatusError, Credentials | HttpClient.HttpClient, ResourceResult>;
export type GetRecoveryGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets details about a recovery group, including a list of the cells that are included in it.
 */
export declare const getRecoveryGroup: API.OperationMethod<GetRecoveryGroupRequest, GetRecoveryGroupResponse, GetRecoveryGroupError, Credentials | HttpClient.HttpClient>;
export type GetRecoveryGroupReadinessSummaryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Displays a summary of information about a recovery group's readiness status. Includes the readiness checks for resources in the recovery group and the readiness status of each one.
 */
export declare const getRecoveryGroupReadinessSummary: API.PaginatedOperationMethod<GetRecoveryGroupReadinessSummaryRequest, GetRecoveryGroupReadinessSummaryResponse, GetRecoveryGroupReadinessSummaryError, Credentials | HttpClient.HttpClient, ReadinessCheckSummary>;
export type GetResourceSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Displays the details about a resource set, including a list of the resources in the set.
 */
export declare const getResourceSet: API.OperationMethod<GetResourceSetRequest, GetResourceSetResponse, GetResourceSetError, Credentials | HttpClient.HttpClient>;
export type ListCellsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the cells for an account.
 */
export declare const listCells: API.PaginatedOperationMethod<ListCellsRequest, ListCellsResponse, ListCellsError, Credentials | HttpClient.HttpClient, CellOutput>;
export type ListCrossAccountAuthorizationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the cross-account readiness authorizations that are in place for an account.
 */
export declare const listCrossAccountAuthorizations: API.PaginatedOperationMethod<ListCrossAccountAuthorizationsRequest, ListCrossAccountAuthorizationsResponse, ListCrossAccountAuthorizationsError, Credentials | HttpClient.HttpClient, CrossAccountAuthorization>;
export type ListReadinessChecksError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the readiness checks for an account.
 */
export declare const listReadinessChecks: API.PaginatedOperationMethod<ListReadinessChecksRequest, ListReadinessChecksResponse, ListReadinessChecksError, Credentials | HttpClient.HttpClient, ReadinessCheckOutput>;
export type ListRecoveryGroupsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the recovery groups in an account.
 */
export declare const listRecoveryGroups: API.PaginatedOperationMethod<ListRecoveryGroupsRequest, ListRecoveryGroupsResponse, ListRecoveryGroupsError, Credentials | HttpClient.HttpClient, RecoveryGroupOutput>;
export type ListResourceSetsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the resource sets in an account.
 */
export declare const listResourceSets: API.PaginatedOperationMethod<ListResourceSetsRequest, ListResourceSetsResponse, ListResourceSetsError, Credentials | HttpClient.HttpClient, ResourceSetOutput>;
export type ListRulesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all readiness rules, or lists the readiness rules for a specific resource type.
 */
export declare const listRules: API.PaginatedOperationMethod<ListRulesRequest, ListRulesResponse, ListRulesError, Credentials | HttpClient.HttpClient, ListRulesOutput>;
export type ListTagsForResourcesError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tags for a resource.
 */
export declare const listTagsForResources: API.OperationMethod<ListTagsForResourcesRequest, ListTagsForResourcesResponse, ListTagsForResourcesError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds a tag to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a tag from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCellError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a cell to replace the list of nested cells with a new list of nested cells.
 */
export declare const updateCell: API.OperationMethod<UpdateCellRequest, UpdateCellResponse, UpdateCellError, Credentials | HttpClient.HttpClient>;
export type UpdateReadinessCheckError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a readiness check.
 */
export declare const updateReadinessCheck: API.OperationMethod<UpdateReadinessCheckRequest, UpdateReadinessCheckResponse, UpdateReadinessCheckError, Credentials | HttpClient.HttpClient>;
export type UpdateRecoveryGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a recovery group.
 */
export declare const updateRecoveryGroup: API.OperationMethod<UpdateRecoveryGroupRequest, UpdateRecoveryGroupResponse, UpdateRecoveryGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateResourceSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a resource set.
 */
export declare const updateResourceSet: API.OperationMethod<UpdateResourceSetRequest, UpdateResourceSetResponse, UpdateResourceSetError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=route53-recovery-readiness.d.ts.map