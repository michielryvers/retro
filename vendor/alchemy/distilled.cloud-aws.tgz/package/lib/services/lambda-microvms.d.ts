import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InsufficientCapacityException_base: S.TaggedErrorClass<"InsufficientCapacityException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InsufficientCapacityException extends /*@__PURE__*/ InsufficientCapacityException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidParameterValueException_base: S.TaggedErrorClass<"InvalidParameterValueException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const ResourceConflictException_base: S.TaggedErrorClass<"ResourceConflictException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceConflictException extends /*@__PURE__*/ ResourceConflictException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceType: any;
    readonly resourceId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceException_base: S.TaggedErrorClass<"ServiceException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceException extends /*@__PURE__*/ ServiceException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type MicrovmIdentifier = string;
export type PositiveInteger = number;
export type PortNumber = number;
export interface PortRange {
    startPort: number;
    endPort: number;
}
export type PortSpecification = {
    port: number;
    range?: never;
    allPorts?: never;
} | {
    port?: never;
    range: PortRange;
    allPorts?: never;
} | {
    port?: never;
    range?: never;
    allPorts: Record<string, never>;
};
export type ListOfPortSpecification = PortSpecification[];
export interface CreateMicrovmAuthTokenRequest {
    microvmIdentifier: string;
    expirationInMinutes: number;
    allowedPorts: PortSpecification[];
}
export type AuthTokenKey = string;
export type AuthTokenValue = string | redacted.Redacted<string>;
export type TokenParts = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export interface CreateMicrovmAuthTokenResponse {
    authToken: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export type NonBlankString = string;
export type Version = string;
export type RoleArn = string;
export type CodeArtifact = {
    uri: string;
};
export interface LoggingDisabled {
}
export interface CloudWatchLogging {
    logGroup?: string;
    logStream?: string;
}
export type Logging = {
    disabled: LoggingDisabled;
    cloudWatch?: never;
} | {
    disabled?: never;
    cloudWatch: CloudWatchLogging;
};
export type NetworkConnector = string;
export type NetworkConnectorList = string[];
export type Architecture = "ARM_64" | (string & {});
export interface CpuConfiguration {
    architecture: Architecture;
}
export type CpuConfigurationList = CpuConfiguration[];
export interface Resources {
    minimumMemoryInMiB: number;
}
export type ResourcesList = Resources[];
export type Capability = "ALL" | (string & {});
export type CapabilityList = Capability[];
export type HookState = "DISABLED" | "ENABLED" | (string & {});
export interface MicrovmHooks {
    run?: HookState;
    runTimeoutInSeconds?: number;
    resume?: HookState;
    resumeTimeoutInSeconds?: number;
    suspend?: HookState;
    suspendTimeoutInSeconds?: number;
    terminate?: HookState;
    terminateTimeoutInSeconds?: number;
}
export interface MicrovmImageHooks {
    ready?: HookState;
    readyTimeoutInSeconds?: number;
    validate?: HookState;
    validateTimeoutInSeconds?: number;
}
export interface Hooks {
    port?: number;
    microvmHooks?: MicrovmHooks;
    microvmImageHooks?: MicrovmImageHooks;
}
export type EnvironmentVariableKey = string;
export type EnvironmentVariableValue = string | redacted.Redacted<string>;
export type EnvironmentVariableMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export type ImageName = string;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export interface CreateMicrovmImageRequest {
    baseImageArn: string;
    baseImageVersion?: string;
    buildRoleArn: string;
    description?: string;
    codeArtifact: CodeArtifact;
    logging?: Logging;
    egressNetworkConnectors?: string[];
    cpuConfigurations?: CpuConfiguration[];
    resources?: Resources[];
    additionalOsCapabilities?: Capability[];
    hooks?: Hooks;
    environmentVariables?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    name: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export type MicrovmImageState = "CREATING" | "CREATED" | "CREATE_FAILED" | "UPDATING" | "UPDATED" | "UPDATE_FAILED" | "DELETING" | "DELETE_FAILED" | "DELETED" | (string & {});
export interface CreateMicrovmImageResponse {
    imageArn: string;
    name: string;
    state: MicrovmImageState;
    latestActiveImageVersion?: string;
    latestFailedImageVersion?: string;
    createdAt: Date;
    baseImageArn: string;
    baseImageVersion?: string;
    buildRoleArn: string;
    description?: string;
    codeArtifact: CodeArtifact;
    logging?: Logging;
    egressNetworkConnectors?: string[];
    cpuConfigurations?: CpuConfiguration[];
    resources?: Resources[];
    additionalOsCapabilities?: Capability[];
    hooks?: Hooks;
    environmentVariables?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    tags?: {
        [key: string]: string | undefined;
    };
    updatedAt?: Date;
    imageVersion: string;
}
export interface CreateMicrovmShellAuthTokenRequest {
    microvmIdentifier: string;
    expirationInMinutes: number;
}
export interface CreateMicrovmShellAuthTokenResponse {
    authToken: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export type MicrovmImageIdentifier = string;
export interface DeleteMicrovmImageInput {
    imageIdentifier: string;
}
export interface DeleteMicrovmImageOutput {
    imageIdentifier: string;
    state: MicrovmImageState;
}
export interface DeleteMicrovmImageVersionInput {
    imageIdentifier: string;
    imageVersion: string;
}
export type MicrovmImageVersionState = "PENDING" | "IN_PROGRESS" | "SUCCESSFUL" | "FAILED" | "DELETING" | "DELETED" | "DELETE_FAILED" | (string & {});
export interface DeleteMicrovmImageVersionOutput {
    imageIdentifier: string;
    imageVersion: string;
    state: MicrovmImageVersionState;
}
export interface GetMicrovmRequest {
    microvmIdentifier: string;
}
export type MicrovmState = "PENDING" | "RUNNING" | "SUSPENDING" | "SUSPENDED" | "TERMINATING" | "TERMINATED" | (string & {});
export type MicrovmImageArn = string;
export interface IdlePolicy {
    maxIdleDurationSeconds: number;
    suspendedDurationSeconds: number;
    autoResumeEnabled: boolean;
}
export interface GetMicrovmResponse {
    microvmId: string;
    state: MicrovmState;
    endpoint: string;
    imageArn: string;
    imageVersion: string;
    executionRoleArn?: string;
    idlePolicy?: IdlePolicy;
    maximumDurationInSeconds: number;
    startedAt: Date;
    terminatedAt?: Date;
    stateReason?: string;
    ingressNetworkConnectors?: string[];
    egressNetworkConnectors?: string[];
}
export interface GetMicrovmImageInput {
    imageIdentifier: string;
}
export interface GetMicrovmImageOutput {
    imageArn: string;
    name: string;
    state: MicrovmImageState;
    latestActiveImageVersion?: string;
    latestFailedImageVersion?: string;
    createdAt: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    updatedAt?: Date;
}
export interface GetMicrovmImageBuildInput {
    imageIdentifier: string;
    imageVersion: string;
    buildId: string;
}
export type BuildState = "PENDING" | "IN_PROGRESS" | "SUCCESSFUL" | "FAILED" | (string & {});
export type Chipset = "GRAVITON" | (string & {});
export interface SnapshotBuild {
    memorySnapshotSizeInBytes?: number;
    codeInstallSizeInBytes?: number;
    diskSnapshotSizeInBytes?: number;
}
export interface GetMicrovmImageBuildOutput {
    imageArn: string;
    imageVersion: string;
    buildId: string;
    buildState: BuildState;
    architecture: Architecture;
    chipset: Chipset;
    chipsetGeneration: string;
    stateReason?: string;
    createdAt: Date;
    snapshotBuild?: SnapshotBuild;
}
export interface GetMicrovmImageVersionInput {
    imageIdentifier: string;
    imageVersion: string;
}
export type MicrovmImageVersionStatus = "ACTIVE" | "INACTIVE" | (string & {});
export interface GetMicrovmImageVersionOutput {
    baseImageArn: string;
    baseImageVersion?: string;
    buildRoleArn: string;
    description?: string;
    codeArtifact: CodeArtifact;
    logging?: Logging;
    egressNetworkConnectors?: string[];
    cpuConfigurations?: CpuConfiguration[];
    resources?: Resources[];
    additionalOsCapabilities?: Capability[];
    hooks?: Hooks;
    environmentVariables?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    imageArn: string;
    imageVersion: string;
    state: MicrovmImageVersionState;
    status: MicrovmImageVersionStatus;
    createdAt: Date;
    updatedAt?: Date;
    stateReason?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListManagedMicrovmImagesInput {
    maxResults?: number;
    nextToken?: string;
}
export interface ManagedMicrovmImageSummary {
    imageArn: string;
    createdAt: Date;
    updatedAt?: Date;
}
export type ManagedMicrovmImageSummaryList = ManagedMicrovmImageSummary[];
export interface ListManagedMicrovmImagesOutput {
    nextToken?: string;
    items: ManagedMicrovmImageSummary[];
}
export interface ListManagedMicrovmImageVersionsInput {
    maxResults?: number;
    nextToken?: string;
    imageIdentifier: string;
}
export type ManagedMicrovmImageVersionStatus = "AVAILABLE" | "DEPRECATED" | (string & {});
export interface ManagedMicrovmImageVersion {
    imageArn: string;
    imageVersion: string;
    status?: ManagedMicrovmImageVersionStatus;
    createdAt: Date;
    updatedAt?: Date;
}
export type ManagedMicrovmImageVersionList = ManagedMicrovmImageVersion[];
export interface ListManagedMicrovmImageVersionsOutput {
    nextToken?: string;
    items: ManagedMicrovmImageVersion[];
}
export interface ListMicrovmImageBuildsInput {
    maxResults?: number;
    nextToken?: string;
    imageIdentifier: string;
    imageVersion: string;
    architecture?: Architecture;
    chipset?: Chipset;
    chipsetGeneration?: string;
}
export interface MicrovmImageBuildSummary {
    imageArn: string;
    imageVersion: string;
    buildId: string;
    buildState: BuildState;
    architecture: Architecture;
    chipset: Chipset;
    chipsetGeneration: string;
    stateReason?: string;
    createdAt: Date;
}
export type MicrovmImageBuildSummaries = MicrovmImageBuildSummary[];
export interface ListMicrovmImageBuildsOutput {
    nextToken?: string;
    items: MicrovmImageBuildSummary[];
}
export interface ListMicrovmImagesRequest {
    maxResults?: number;
    nextToken?: string;
    nameFilter?: string;
}
export interface MicrovmImageSummary {
    imageArn: string;
    name: string;
    state: MicrovmImageState;
    latestActiveImageVersion?: string;
    latestFailedImageVersion?: string;
    createdAt: Date;
}
export type MicrovmImageSummaries = MicrovmImageSummary[];
export interface ListMicrovmImagesResponse {
    nextToken?: string;
    items: MicrovmImageSummary[];
}
export interface ListMicrovmImageVersionsInput {
    maxResults?: number;
    nextToken?: string;
    imageIdentifier: string;
}
export interface MicrovmImageVersionSummary {
    baseImageArn: string;
    baseImageVersion?: string;
    buildRoleArn: string;
    description?: string;
    codeArtifact: CodeArtifact;
    logging?: Logging;
    egressNetworkConnectors?: string[];
    cpuConfigurations?: CpuConfiguration[];
    resources?: Resources[];
    additionalOsCapabilities?: Capability[];
    hooks?: Hooks;
    environmentVariables?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    imageArn: string;
    imageVersion: string;
    state: MicrovmImageVersionState;
    status: MicrovmImageVersionStatus;
    createdAt: Date;
    updatedAt?: Date;
    stateReason?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type MicrovmImageVersionSummaryList = MicrovmImageVersionSummary[];
export interface ListMicrovmImageVersionsOutput {
    nextToken?: string;
    items: MicrovmImageVersionSummary[];
}
export interface ListMicrovmsRequest {
    maxResults?: number;
    nextToken?: string;
    imageIdentifier?: string;
    imageVersion?: string;
}
export interface MicrovmItem {
    microvmId: string;
    state: MicrovmState;
    imageArn: string;
    imageVersion: string;
    startedAt: Date;
}
export type MicrovmItemList = MicrovmItem[];
export interface ListMicrovmsResponse {
    nextToken?: string;
    items: MicrovmItem[];
}
export type TaggableResource = string;
export interface ListTagsRequest {
    Resource: string;
}
export interface ListTagsResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface ResumeMicrovmRequest {
    microvmIdentifier: string;
}
export interface ResumeMicrovmResponse {
}
export type RunHookPayload = string | redacted.Redacted<string>;
export interface RunMicrovmRequest {
    ingressNetworkConnectors?: string[];
    egressNetworkConnectors?: string[];
    imageIdentifier: string;
    imageVersion?: string;
    executionRoleArn?: string;
    idlePolicy?: IdlePolicy;
    logging?: Logging;
    runHookPayload?: string | redacted.Redacted<string>;
    maximumDurationInSeconds?: number;
    clientToken?: string;
}
export interface RunMicrovmResponse {
    microvmId: string;
    state: MicrovmState;
    endpoint: string;
    imageArn: string;
    imageVersion: string;
    executionRoleArn?: string;
    idlePolicy?: IdlePolicy;
    maximumDurationInSeconds: number;
    startedAt: Date;
    terminatedAt?: Date;
    stateReason?: string;
    ingressNetworkConnectors?: string[];
    egressNetworkConnectors?: string[];
}
export interface SuspendMicrovmRequest {
    microvmIdentifier: string;
}
export interface SuspendMicrovmResponse {
}
export interface TagResourceRequest {
    Resource: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export interface TerminateMicrovmRequest {
    microvmIdentifier: string;
}
export interface TerminateMicrovmResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    Resource: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateMicrovmImageRequest {
    baseImageArn: string;
    baseImageVersion?: string;
    buildRoleArn: string;
    description?: string;
    codeArtifact: CodeArtifact;
    logging?: Logging;
    egressNetworkConnectors?: string[];
    cpuConfigurations?: CpuConfiguration[];
    resources?: Resources[];
    additionalOsCapabilities?: Capability[];
    hooks?: Hooks;
    environmentVariables?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    imageIdentifier: string;
    clientToken?: string;
}
export interface UpdateMicrovmImageResponse {
    imageArn: string;
    name: string;
    state: MicrovmImageState;
    latestActiveImageVersion?: string;
    latestFailedImageVersion?: string;
    createdAt: Date;
    baseImageArn: string;
    baseImageVersion?: string;
    buildRoleArn: string;
    description?: string;
    codeArtifact: CodeArtifact;
    logging?: Logging;
    egressNetworkConnectors?: string[];
    cpuConfigurations?: CpuConfiguration[];
    resources?: Resources[];
    additionalOsCapabilities?: Capability[];
    hooks?: Hooks;
    environmentVariables?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    updatedAt: Date;
    imageVersion: string;
}
export interface UpdateMicrovmImageVersionRequest {
    imageIdentifier: string;
    imageVersion: string;
    status: MicrovmImageVersionStatus;
}
export interface UpdateMicrovmImageVersionResponse {
    baseImageArn: string;
    baseImageVersion?: string;
    buildRoleArn: string;
    description?: string;
    codeArtifact: CodeArtifact;
    logging?: Logging;
    egressNetworkConnectors?: string[];
    cpuConfigurations?: CpuConfiguration[];
    resources?: Resources[];
    additionalOsCapabilities?: Capability[];
    hooks?: Hooks;
    environmentVariables?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    imageArn: string;
    imageVersion: string;
    state: MicrovmImageVersionState;
    status: MicrovmImageVersionStatus;
    createdAt: Date;
    updatedAt?: Date;
    stateReason?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type CreateMicrovmAuthTokenError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an authentication token for accessing a running MicroVM. The token grants access to the specified ports on the MicroVM endpoint.
 */
export declare const createMicrovmAuthToken: API.OperationMethod<CreateMicrovmAuthTokenRequest, CreateMicrovmAuthTokenResponse, CreateMicrovmAuthTokenError, Credentials | HttpClient.HttpClient>;
export type CreateMicrovmImageError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a MicroVM image from the specified code artifact and base image. The build is asynchronous -- the image transitions from CREATING to CREATED on success, or CREATE_FAILED on failure. Use GetMicrovmImage to poll for completion.
 */
export declare const createMicrovmImage: API.OperationMethod<CreateMicrovmImageRequest, CreateMicrovmImageResponse, CreateMicrovmImageError, Credentials | HttpClient.HttpClient>;
export type CreateMicrovmShellAuthTokenError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a shell authentication token for interactive shell access to a running MicroVM. The MicroVM must have been run with the SHELL_INGRESS network connector attached.
 */
export declare const createMicrovmShellAuthToken: API.OperationMethod<CreateMicrovmShellAuthTokenRequest, CreateMicrovmShellAuthTokenResponse, CreateMicrovmShellAuthTokenError, Credentials | HttpClient.HttpClient>;
export type DeleteMicrovmImageError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a MicroVM image. This operation is idempotent; deleting an image that has already been deleted succeeds without error.
 */
export declare const deleteMicrovmImage: API.OperationMethod<DeleteMicrovmImageInput, DeleteMicrovmImageOutput, DeleteMicrovmImageError, Credentials | HttpClient.HttpClient>;
export type DeleteMicrovmImageVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specific version of a MicroVM image. This operation is idempotent; deleting a version that has already been deleted succeeds without error.
 */
export declare const deleteMicrovmImageVersion: API.OperationMethod<DeleteMicrovmImageVersionInput, DeleteMicrovmImageVersionOutput, DeleteMicrovmImageVersionError, Credentials | HttpClient.HttpClient>;
export type GetMicrovmError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of a specific MicroVM, including its state, endpoint, image information, and configuration. The state field is eventually consistent -- determine readiness by connecting to the endpoint.
 */
export declare const getMicrovm: API.OperationMethod<GetMicrovmRequest, GetMicrovmResponse, GetMicrovmError, Credentials | HttpClient.HttpClient>;
export type GetMicrovmImageError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of a MicroVM image, including its state, versions, and configuration.
 */
export declare const getMicrovmImage: API.OperationMethod<GetMicrovmImageInput, GetMicrovmImageOutput, GetMicrovmImageError, Credentials | HttpClient.HttpClient>;
export type GetMicrovmImageBuildError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of a specific MicroVM image build, including its state, target architecture, and snapshot information.
 */
export declare const getMicrovmImageBuild: API.OperationMethod<GetMicrovmImageBuildInput, GetMicrovmImageBuildOutput, GetMicrovmImageBuildError, Credentials | HttpClient.HttpClient>;
export type GetMicrovmImageVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of a specific version of a MicroVM image, including its configuration, state, and build information.
 */
export declare const getMicrovmImageVersion: API.OperationMethod<GetMicrovmImageVersionInput, GetMicrovmImageVersionOutput, GetMicrovmImageVersionError, Credentials | HttpClient.HttpClient>;
export type ListManagedMicrovmImagesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists AWS managed MicroVM images available for use as base images. We recommend using pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listManagedMicrovmImages: API.PaginatedOperationMethod<ListManagedMicrovmImagesInput, ListManagedMicrovmImagesOutput, ListManagedMicrovmImagesError, Credentials | HttpClient.HttpClient, ManagedMicrovmImageSummary>;
export type ListManagedMicrovmImageVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists versions of a managed MicroVM image. We recommend using pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listManagedMicrovmImageVersions: API.PaginatedOperationMethod<ListManagedMicrovmImageVersionsInput, ListManagedMicrovmImageVersionsOutput, ListManagedMicrovmImageVersionsError, Credentials | HttpClient.HttpClient, ManagedMicrovmImageVersion>;
export type ListMicrovmImageBuildsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists builds for a MicroVM image version with optional filtering by architecture and chipset. We recommend using pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listMicrovmImageBuilds: API.PaginatedOperationMethod<ListMicrovmImageBuildsInput, ListMicrovmImageBuildsOutput, ListMicrovmImageBuildsError, Credentials | HttpClient.HttpClient, MicrovmImageBuildSummary>;
export type ListMicrovmImagesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists MicroVM images in the account with optional name filtering. We recommend using pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listMicrovmImages: API.PaginatedOperationMethod<ListMicrovmImagesRequest, ListMicrovmImagesResponse, ListMicrovmImagesError, Credentials | HttpClient.HttpClient, MicrovmImageSummary>;
export type ListMicrovmImageVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists versions of a MicroVM image. We recommend using pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listMicrovmImageVersions: API.PaginatedOperationMethod<ListMicrovmImageVersionsInput, ListMicrovmImageVersionsOutput, ListMicrovmImageVersionsError, Credentials | HttpClient.HttpClient, MicrovmImageVersionSummary>;
export type ListMicrovmsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists MicroVMs in the account with optional filtering by image and version. We recommend using pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listMicrovms: API.PaginatedOperationMethod<ListMicrovmsRequest, ListMicrovmsResponse, ListMicrovmsError, Credentials | HttpClient.HttpClient, MicrovmItem>;
export type ListTagsError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Lists the tags associated with a Lambda MicroVM resource.
 */
export declare const listTags: API.OperationMethod<ListTagsRequest, ListTagsResponse, ListTagsError, Credentials | HttpClient.HttpClient>;
export type ResumeMicrovmError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Resumes a suspended MicroVM, restoring it to RUNNING state with all state intact. The MicroVM must be in SUSPENDED state.
 */
export declare const resumeMicrovm: API.OperationMethod<ResumeMicrovmRequest, ResumeMicrovmResponse, ResumeMicrovmError, Credentials | HttpClient.HttpClient>;
export type RunMicrovmError = AccessDeniedException | ConflictException | InsufficientCapacityException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Runs a new MicroVM from the specified image. The MicroVM starts in PENDING state and transitions to RUNNING once provisioning completes. To connect, generate an authentication token using CreateMicrovmAuthToken.
 */
export declare const runMicrovm: API.OperationMethod<RunMicrovmRequest, RunMicrovmResponse, RunMicrovmError, Credentials | HttpClient.HttpClient>;
export type SuspendMicrovmError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Suspends a running MicroVM, preserving its full memory and disk state. The MicroVM transitions through SUSPENDING to SUSPENDED. To restore, call ResumeMicrovm or send traffic to the endpoint if autoResumeEnabled is true.
 */
export declare const suspendMicrovm: API.OperationMethod<SuspendMicrovmRequest, SuspendMicrovmResponse, SuspendMicrovmError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Adds tags to a Lambda MicroVM resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TerminateMicrovmError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Terminates a MicroVM. This operation is idempotent; terminating a MicroVM that has already been terminated succeeds without error.
 */
export declare const terminateMicrovm: API.OperationMethod<TerminateMicrovmRequest, TerminateMicrovmResponse, TerminateMicrovmError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Removes tags from a Lambda MicroVM resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateMicrovmImageError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of a MicroVM image and triggers a new version build. This operation uses PUT semantics -- all required fields (codeArtifact, baseImageArn, buildRoleArn) must be provided with every request.
 */
export declare const updateMicrovmImage: API.OperationMethod<UpdateMicrovmImageRequest, UpdateMicrovmImageResponse, UpdateMicrovmImageError, Credentials | HttpClient.HttpClient>;
export type UpdateMicrovmImageVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the status of a specific MicroVM image version.
 */
export declare const updateMicrovmImageVersion: API.OperationMethod<UpdateMicrovmImageVersionRequest, UpdateMicrovmImageVersionResponse, UpdateMicrovmImageVersionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=lambda-microvms.d.ts.map