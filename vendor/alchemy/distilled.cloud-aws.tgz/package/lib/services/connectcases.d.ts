import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DomainId = string;
export type CaseRuleId = string;
export interface CaseRuleIdentifier {
    id: string;
}
export type CaseRuleIdentifierList = CaseRuleIdentifier[];
export interface BatchGetCaseRuleRequest {
    domainId: string;
    caseRules: CaseRuleIdentifier[];
}
export type CaseRuleName = string;
export type CaseRuleArn = string;
export type FieldId = string;
export type OperandOne = {
    fieldId: string;
};
export interface EmptyOperandValue {
}
export type OperandTwo = {
    stringValue: string;
    booleanValue?: never;
    doubleValue?: never;
    emptyValue?: never;
} | {
    stringValue?: never;
    booleanValue: boolean;
    doubleValue?: never;
    emptyValue?: never;
} | {
    stringValue?: never;
    booleanValue?: never;
    doubleValue: number;
    emptyValue?: never;
} | {
    stringValue?: never;
    booleanValue?: never;
    doubleValue?: never;
    emptyValue: EmptyOperandValue;
};
export interface BooleanOperands {
    operandOne: OperandOne;
    operandTwo: OperandTwo;
    result: boolean;
}
export interface CompoundCondition {
    conditions: BooleanCondition[];
}
export type BooleanCondition = {
    equalTo: BooleanOperands;
    notEqualTo?: never;
    andAll?: never;
    orAll?: never;
} | {
    equalTo?: never;
    notEqualTo: BooleanOperands;
    andAll?: never;
    orAll?: never;
} | {
    equalTo?: never;
    notEqualTo?: never;
    andAll: CompoundCondition;
    orAll?: never;
} | {
    equalTo?: never;
    notEqualTo?: never;
    andAll?: never;
    orAll: CompoundCondition;
};
export type BooleanConditionList = BooleanCondition[];
export interface RequiredCaseRule {
    defaultValue: boolean;
    conditions: BooleanCondition[];
}
export type ParentChildFieldOptionValue = string;
export type ParentChildFieldOptionValueList = string[];
export interface ParentChildFieldOptionsMapping {
    parentFieldOptionValue: string;
    childFieldOptionValues: string[];
}
export type ParentChildFieldOptionsMappingList = ParentChildFieldOptionsMapping[];
export interface FieldOptionsCaseRule {
    parentFieldId?: string;
    childFieldId?: string;
    parentChildFieldOptionsMappings: ParentChildFieldOptionsMapping[];
}
export interface HiddenCaseRule {
    defaultValue: boolean;
    conditions: BooleanCondition[];
}
export type CaseRuleDetails = {
    required: RequiredCaseRule;
    fieldOptions?: never;
    hidden?: never;
} | {
    required?: never;
    fieldOptions: FieldOptionsCaseRule;
    hidden?: never;
} | {
    required?: never;
    fieldOptions?: never;
    hidden: HiddenCaseRule;
};
export type CaseRuleDescription = string;
export type Deleted = boolean;
export type CreatedTime = Date;
export type LastModifiedTime = Date;
export type Tags = {
    [key: string]: string | undefined;
};
export interface GetCaseRuleResponse {
    caseRuleId: string;
    name: string;
    caseRuleArn: string;
    rule: CaseRuleDetails;
    description?: string;
    deleted?: boolean;
    createdTime?: Date;
    lastModifiedTime?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type BatchGetCaseRuleList = GetCaseRuleResponse[];
export interface CaseRuleError {
    id: string;
    errorCode: string;
    message?: string;
}
export type BatchGetCaseRuleErrorList = CaseRuleError[];
export type BatchGetCaseRuleUnprocessedList = string[];
export interface BatchGetCaseRuleResponse {
    caseRules: GetCaseRuleResponse[];
    errors: CaseRuleError[];
    unprocessedCaseRules?: string[];
}
export interface FieldIdentifier {
    id: string;
}
export type BatchGetFieldIdentifierList = FieldIdentifier[];
export interface BatchGetFieldRequest {
    domainId: string;
    fields: FieldIdentifier[];
}
export type FieldName = string;
export type FieldArn = string;
export type FieldDescription = string;
export type FieldType = string;
export type FieldNamespace = string;
export interface TextAttributes {
    isMultiline: boolean;
}
export type FieldAttributes = {
    text: TextAttributes;
};
export interface GetFieldResponse {
    fieldId: string;
    name: string;
    fieldArn: string;
    description?: string;
    type: string;
    namespace: string;
    tags?: {
        [key: string]: string | undefined;
    };
    deleted?: boolean;
    createdTime?: Date;
    lastModifiedTime?: Date;
    attributes?: FieldAttributes;
}
export type BatchGetFieldList = GetFieldResponse[];
export interface FieldError {
    id: string;
    errorCode: string;
    message?: string;
}
export type BatchGetFieldErrorList = FieldError[];
export interface BatchGetFieldResponse {
    fields: GetFieldResponse[];
    errors: FieldError[];
}
export type FieldOptionName = string;
export type FieldOptionValue = string;
export interface FieldOption {
    name: string;
    value: string;
    active: boolean;
}
export type FieldOptionsList = FieldOption[];
export interface BatchPutFieldOptionsRequest {
    domainId: string;
    fieldId: string;
    options: FieldOption[];
}
export interface FieldOptionError {
    message: string;
    errorCode: string;
    value: string;
}
export type FieldOptionErrorList = FieldOptionError[];
export interface BatchPutFieldOptionsResponse {
    errors?: FieldOptionError[];
}
export type TemplateId = string;
export interface EmptyFieldValue {
}
export type FieldValueUnion = {
    stringValue: string;
    doubleValue?: never;
    booleanValue?: never;
    emptyValue?: never;
    userArnValue?: never;
} | {
    stringValue?: never;
    doubleValue: number;
    booleanValue?: never;
    emptyValue?: never;
    userArnValue?: never;
} | {
    stringValue?: never;
    doubleValue?: never;
    booleanValue: boolean;
    emptyValue?: never;
    userArnValue?: never;
} | {
    stringValue?: never;
    doubleValue?: never;
    booleanValue?: never;
    emptyValue: EmptyFieldValue;
    userArnValue?: never;
} | {
    stringValue?: never;
    doubleValue?: never;
    booleanValue?: never;
    emptyValue?: never;
    userArnValue: string;
};
export interface FieldValue {
    id: string;
    value: FieldValueUnion;
}
export type FieldValueList = FieldValue[];
export type UserArn = string;
export type CustomEntity = string | redacted.Redacted<string>;
export type UserUnion = {
    userArn: string;
    customEntity?: never;
} | {
    userArn?: never;
    customEntity: string | redacted.Redacted<string>;
};
export type MutableTagKey = string;
export type TagValueString = string;
export type MutableTags = {
    [key: string]: string | undefined;
};
export interface CreateCaseRequest {
    domainId: string;
    templateId: string;
    fields: FieldValue[];
    clientToken?: string;
    performedBy?: UserUnion;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type CaseId = string;
export type CaseArn = string;
export interface CreateCaseResponse {
    caseId: string;
    caseArn: string;
}
export interface CreateCaseRuleRequest {
    domainId: string;
    name: string;
    description?: string;
    rule: CaseRuleDetails;
}
export interface CreateCaseRuleResponse {
    caseRuleId: string;
    caseRuleArn: string;
}
export type DomainName = string;
export interface CreateDomainRequest {
    name: string;
}
export type DomainArn = string;
export type DomainStatus = string;
export interface CreateDomainResponse {
    domainId: string;
    domainArn: string;
    domainStatus: string;
}
export interface CreateFieldRequest {
    domainId: string;
    name: string;
    type: string;
    description?: string;
    attributes?: FieldAttributes;
}
export interface CreateFieldResponse {
    fieldId: string;
    fieldArn: string;
}
export type LayoutName = string;
export interface FieldItem {
    id: string;
}
export type FieldList = FieldItem[];
export interface FieldGroup {
    name?: string;
    fields: FieldItem[];
}
export type Section = {
    fieldGroup: FieldGroup;
};
export type SectionsList = Section[];
export interface LayoutSections {
    sections?: Section[];
}
export interface BasicLayout {
    topPanel?: LayoutSections;
    moreInfo?: LayoutSections;
}
export type LayoutContent = {
    basic: BasicLayout;
};
export interface CreateLayoutRequest {
    domainId: string;
    name: string;
    content: LayoutContent;
}
export type LayoutId = string;
export type LayoutArn = string;
export interface CreateLayoutResponse {
    layoutId: string;
    layoutArn: string;
}
export type RelatedItemType = string;
export type ContactArn = string;
export interface Contact {
    contactArn: string;
}
export type CommentBody = string;
export type CommentBodyTextType = string;
export interface CommentContent {
    body: string;
    contentType: string;
}
export type FileArn = string;
export interface FileContent {
    fileArn: string;
}
export type SlaName = string | redacted.Redacted<string>;
export type SlaType = string;
export type SlaFieldValueUnionList = FieldValueUnion[];
export type TargetSlaMinutes = number;
export interface SlaInputConfiguration {
    name: string | redacted.Redacted<string>;
    type: string;
    fieldId?: string;
    targetFieldValues?: FieldValueUnion[];
    targetSlaMinutes: number;
}
export type SlaInputContent = {
    slaInputConfiguration: SlaInputConfiguration;
};
export interface ConnectCaseInputContent {
    caseId: string;
}
export interface CustomInputContent {
    fields: FieldValue[];
}
export type RelatedItemInputContent = {
    contact: Contact;
    comment?: never;
    file?: never;
    sla?: never;
    connectCase?: never;
    custom?: never;
} | {
    contact?: never;
    comment: CommentContent;
    file?: never;
    sla?: never;
    connectCase?: never;
    custom?: never;
} | {
    contact?: never;
    comment?: never;
    file: FileContent;
    sla?: never;
    connectCase?: never;
    custom?: never;
} | {
    contact?: never;
    comment?: never;
    file?: never;
    sla: SlaInputContent;
    connectCase?: never;
    custom?: never;
} | {
    contact?: never;
    comment?: never;
    file?: never;
    sla?: never;
    connectCase: ConnectCaseInputContent;
    custom?: never;
} | {
    contact?: never;
    comment?: never;
    file?: never;
    sla?: never;
    connectCase?: never;
    custom: CustomInputContent;
};
export interface CreateRelatedItemRequest {
    domainId: string;
    caseId: string;
    type: string;
    content: RelatedItemInputContent;
    performedBy?: UserUnion;
}
export type RelatedItemId = string;
export type RelatedItemArn = string;
export interface CreateRelatedItemResponse {
    relatedItemId: string;
    relatedItemArn: string;
}
export type TemplateName = string;
export type TemplateDescription = string;
export interface LayoutConfiguration {
    defaultLayout?: string;
}
export interface RequiredField {
    fieldId: string;
}
export type RequiredFieldList = RequiredField[];
export type TemplateStatus = string;
export interface TemplateRule {
    caseRuleId: string;
    fieldId?: string;
}
export type TemplateCaseRuleList = TemplateRule[];
export type TagPropagationResourceType = string;
export interface TagPropagationConfiguration {
    resourceType: string;
    tagMap: {
        [key: string]: string | undefined;
    };
}
export type TagPropagationConfigurationList = TagPropagationConfiguration[];
export interface CreateTemplateRequest {
    domainId: string;
    name: string;
    description?: string;
    layoutConfiguration?: LayoutConfiguration;
    requiredFields?: RequiredField[];
    status?: string;
    rules?: TemplateRule[];
    tagPropagationConfigurations?: TagPropagationConfiguration[];
}
export type TemplateArn = string;
export interface CreateTemplateResponse {
    templateId: string;
    templateArn: string;
}
export interface DeleteCaseRequest {
    domainId: string;
    caseId: string;
}
export interface DeleteCaseResponse {
}
export interface DeleteCaseRuleRequest {
    domainId: string;
    caseRuleId: string;
}
export interface DeleteCaseRuleResponse {
}
export interface DeleteDomainRequest {
    domainId: string;
}
export interface DeleteDomainResponse {
}
export interface DeleteFieldRequest {
    domainId: string;
    fieldId: string;
}
export interface DeleteFieldResponse {
}
export interface DeleteLayoutRequest {
    domainId: string;
    layoutId: string;
}
export interface DeleteLayoutResponse {
}
export interface DeleteRelatedItemRequest {
    domainId: string;
    caseId: string;
    relatedItemId: string;
}
export interface DeleteRelatedItemResponse {
}
export interface DeleteTemplateRequest {
    domainId: string;
    templateId: string;
}
export interface DeleteTemplateResponse {
}
export type FieldIdentifierList = FieldIdentifier[];
export type NextToken = string;
export interface GetCaseRequest {
    caseId: string;
    domainId: string;
    fields: FieldIdentifier[];
    nextToken?: string;
}
export interface GetCaseResponse {
    fields: FieldValue[];
    templateId: string;
    nextToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetCaseAuditEventsRequest {
    caseId: string;
    domainId: string;
    maxResults?: number;
    nextToken?: string;
}
export type AuditEventId = string;
export type AuditEventType = string;
export type AuditEventDateTime = Date;
export type AuditEventFieldId = string;
export type AuditEventFieldValueUnion = {
    stringValue: string;
    doubleValue?: never;
    booleanValue?: never;
    emptyValue?: never;
    userArnValue?: never;
} | {
    stringValue?: never;
    doubleValue: number;
    booleanValue?: never;
    emptyValue?: never;
    userArnValue?: never;
} | {
    stringValue?: never;
    doubleValue?: never;
    booleanValue: boolean;
    emptyValue?: never;
    userArnValue?: never;
} | {
    stringValue?: never;
    doubleValue?: never;
    booleanValue?: never;
    emptyValue: EmptyFieldValue;
    userArnValue?: never;
} | {
    stringValue?: never;
    doubleValue?: never;
    booleanValue?: never;
    emptyValue?: never;
    userArnValue: string;
};
export interface AuditEventField {
    eventFieldId: string;
    oldValue?: AuditEventFieldValueUnion;
    newValue: AuditEventFieldValueUnion;
}
export type AuditEventFieldList = AuditEventField[];
export type IamPrincipalArn = string;
export interface AuditEventPerformedBy {
    user?: UserUnion;
    iamPrincipalArn: string;
}
export interface AuditEvent {
    eventId: string;
    type: string;
    relatedItemType?: string;
    performedTime: Date;
    fields: AuditEventField[];
    performedBy?: AuditEventPerformedBy;
}
export type AuditEventsList = AuditEvent[];
export interface GetCaseAuditEventsResponse {
    nextToken?: string;
    auditEvents: AuditEvent[];
}
export interface GetCaseEventConfigurationRequest {
    domainId: string;
}
export interface CaseEventIncludedData {
    fields: FieldIdentifier[];
}
export interface RelatedItemEventIncludedData {
    includeContent: boolean;
}
export interface EventIncludedData {
    caseData?: CaseEventIncludedData;
    relatedItemData?: RelatedItemEventIncludedData;
}
export interface EventBridgeConfiguration {
    enabled: boolean;
    includedData?: EventIncludedData;
}
export interface GetCaseEventConfigurationResponse {
    eventBridge: EventBridgeConfiguration;
}
export interface GetDomainRequest {
    domainId: string;
}
export interface GetDomainResponse {
    domainId: string;
    domainArn: string;
    name: string;
    createdTime: Date;
    domainStatus: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetLayoutRequest {
    domainId: string;
    layoutId: string;
}
export interface GetLayoutResponse {
    layoutId: string;
    layoutArn: string;
    name: string;
    content: LayoutContent;
    tags?: {
        [key: string]: string | undefined;
    };
    deleted?: boolean;
    createdTime?: Date;
    lastModifiedTime?: Date;
}
export interface GetTemplateRequest {
    domainId: string;
    templateId: string;
}
export interface GetTemplateResponse {
    templateId: string;
    templateArn: string;
    name: string;
    description?: string;
    layoutConfiguration?: LayoutConfiguration;
    requiredFields?: RequiredField[];
    tags?: {
        [key: string]: string | undefined;
    };
    status: string;
    deleted?: boolean;
    createdTime?: Date;
    lastModifiedTime?: Date;
    rules?: TemplateRule[];
    tagPropagationConfigurations?: TagPropagationConfiguration[];
}
export type MaxResults = number;
export interface ListCaseRulesRequest {
    domainId: string;
    maxResults?: number;
    nextToken?: string;
}
export type RuleType = string;
export interface CaseRuleSummary {
    caseRuleId: string;
    name: string;
    caseRuleArn: string;
    ruleType: string;
    description?: string;
}
export type CaseRuleSummaryList = CaseRuleSummary[];
export interface ListCaseRulesResponse {
    caseRules: CaseRuleSummary[];
    nextToken?: string;
}
export interface ListCasesForContactRequest {
    domainId: string;
    contactArn: string;
    maxResults?: number;
    nextToken?: string;
}
export interface CaseSummary {
    caseId: string;
    templateId: string;
}
export type CaseSummaryList = CaseSummary[];
export interface ListCasesForContactResponse {
    cases: CaseSummary[];
    nextToken?: string;
}
export interface ListDomainsRequest {
    maxResults?: number;
    nextToken?: string;
}
export interface DomainSummary {
    domainId: string;
    domainArn: string;
    name: string;
}
export type DomainSummaryList = DomainSummary[];
export interface ListDomainsResponse {
    domains: DomainSummary[];
    nextToken?: string;
}
export type Value = string;
export type ValuesList = string[];
export interface ListFieldOptionsRequest {
    domainId: string;
    fieldId: string;
    maxResults?: number;
    nextToken?: string;
    values?: string[];
}
export interface ListFieldOptionsResponse {
    options: FieldOption[];
    nextToken?: string;
}
export interface ListFieldsRequest {
    domainId: string;
    maxResults?: number;
    nextToken?: string;
}
export interface FieldSummary {
    fieldId: string;
    fieldArn: string;
    name: string;
    type: string;
    namespace: string;
    attributes?: FieldAttributes;
}
export type FieldSummaryList = FieldSummary[];
export interface ListFieldsResponse {
    fields: FieldSummary[];
    nextToken?: string;
}
export interface ListLayoutsRequest {
    domainId: string;
    maxResults?: number;
    nextToken?: string;
}
export interface LayoutSummary {
    layoutId: string;
    layoutArn: string;
    name: string;
}
export type LayoutSummaryList = LayoutSummary[];
export interface ListLayoutsResponse {
    layouts: LayoutSummary[];
    nextToken?: string;
}
export type Arn = string;
export interface ListTagsForResourceRequest {
    arn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export type TemplateStatusFilters = string[];
export interface ListTemplatesRequest {
    domainId: string;
    maxResults?: number;
    nextToken?: string;
    status?: string[];
}
export interface TemplateSummary {
    templateId: string;
    templateArn: string;
    name: string;
    status: string;
    tagPropagationConfigurations?: TagPropagationConfiguration[];
}
export type TemplateSummaryList = TemplateSummary[];
export interface ListTemplatesResponse {
    templates: TemplateSummary[];
    nextToken?: string;
}
export interface PutCaseEventConfigurationRequest {
    domainId: string;
    eventBridge: EventBridgeConfiguration;
}
export interface PutCaseEventConfigurationResponse {
}
export type Channel = string;
export type ChannelList = string[];
export interface ContactFilter {
    channel?: string[];
    contactArn?: string;
}
export interface CommentFilter {
}
export interface FileFilter {
    fileArn?: string;
}
export type SlaStatus = string;
export interface SlaFilter {
    name?: string | redacted.Redacted<string>;
    status?: string;
}
export interface ConnectCaseFilter {
    caseId?: string;
}
export type FieldFilter = {
    equalTo: FieldValue;
    contains?: never;
    greaterThan?: never;
    greaterThanOrEqualTo?: never;
    lessThan?: never;
    lessThanOrEqualTo?: never;
} | {
    equalTo?: never;
    contains: FieldValue;
    greaterThan?: never;
    greaterThanOrEqualTo?: never;
    lessThan?: never;
    lessThanOrEqualTo?: never;
} | {
    equalTo?: never;
    contains?: never;
    greaterThan: FieldValue;
    greaterThanOrEqualTo?: never;
    lessThan?: never;
    lessThanOrEqualTo?: never;
} | {
    equalTo?: never;
    contains?: never;
    greaterThan?: never;
    greaterThanOrEqualTo: FieldValue;
    lessThan?: never;
    lessThanOrEqualTo?: never;
} | {
    equalTo?: never;
    contains?: never;
    greaterThan?: never;
    greaterThanOrEqualTo?: never;
    lessThan: FieldValue;
    lessThanOrEqualTo?: never;
} | {
    equalTo?: never;
    contains?: never;
    greaterThan?: never;
    greaterThanOrEqualTo?: never;
    lessThan?: never;
    lessThanOrEqualTo: FieldValue;
};
export type CustomFieldsFilterList = CustomFieldsFilter[];
export type CustomFieldsFilter = {
    field: FieldFilter;
    not?: never;
    andAll?: never;
    orAll?: never;
} | {
    field?: never;
    not: CustomFieldsFilter;
    andAll?: never;
    orAll?: never;
} | {
    field?: never;
    not?: never;
    andAll: CustomFieldsFilter[];
    orAll?: never;
} | {
    field?: never;
    not?: never;
    andAll?: never;
    orAll: CustomFieldsFilter[];
};
export interface CustomFilter {
    fields?: CustomFieldsFilter;
}
export type RelatedItemTypeFilter = {
    contact: ContactFilter;
    comment?: never;
    file?: never;
    sla?: never;
    connectCase?: never;
    custom?: never;
} | {
    contact?: never;
    comment: CommentFilter;
    file?: never;
    sla?: never;
    connectCase?: never;
    custom?: never;
} | {
    contact?: never;
    comment?: never;
    file: FileFilter;
    sla?: never;
    connectCase?: never;
    custom?: never;
} | {
    contact?: never;
    comment?: never;
    file?: never;
    sla: SlaFilter;
    connectCase?: never;
    custom?: never;
} | {
    contact?: never;
    comment?: never;
    file?: never;
    sla?: never;
    connectCase: ConnectCaseFilter;
    custom?: never;
} | {
    contact?: never;
    comment?: never;
    file?: never;
    sla?: never;
    connectCase?: never;
    custom: CustomFilter;
};
export type RelatedItemFilterList = RelatedItemTypeFilter[];
export type SearchAllRelatedItemsSortProperty = string;
export type Order = string;
export interface SearchAllRelatedItemsSort {
    sortProperty: string;
    sortOrder: string;
}
export type SearchAllRelatedItemsSortList = SearchAllRelatedItemsSort[];
export interface SearchAllRelatedItemsRequest {
    domainId: string;
    maxResults?: number;
    nextToken?: string;
    filters?: RelatedItemTypeFilter[];
    sorts?: SearchAllRelatedItemsSort[];
}
export type AssociationTime = Date;
export type ConnectedToSystemTime = Date;
export interface ContactContent {
    contactArn: string;
    channel: string;
    connectedToSystemTime: Date;
}
export type SlaTargetTime = Date;
export type SlaCompletionTime = Date;
export interface SlaConfiguration {
    name: string | redacted.Redacted<string>;
    type: string;
    status: string;
    fieldId?: string;
    targetFieldValues?: FieldValueUnion[];
    targetTime: Date;
    completionTime?: Date;
}
export interface SlaContent {
    slaConfiguration: SlaConfiguration;
}
export interface ConnectCaseContent {
    caseId: string;
}
export interface CustomContent {
    fields: FieldValue[];
}
export type RelatedItemContent = {
    contact: ContactContent;
    comment?: never;
    file?: never;
    sla?: never;
    connectCase?: never;
    custom?: never;
} | {
    contact?: never;
    comment: CommentContent;
    file?: never;
    sla?: never;
    connectCase?: never;
    custom?: never;
} | {
    contact?: never;
    comment?: never;
    file: FileContent;
    sla?: never;
    connectCase?: never;
    custom?: never;
} | {
    contact?: never;
    comment?: never;
    file?: never;
    sla: SlaContent;
    connectCase?: never;
    custom?: never;
} | {
    contact?: never;
    comment?: never;
    file?: never;
    sla?: never;
    connectCase: ConnectCaseContent;
    custom?: never;
} | {
    contact?: never;
    comment?: never;
    file?: never;
    sla?: never;
    connectCase?: never;
    custom: CustomContent;
};
export interface SearchAllRelatedItemsResponseItem {
    relatedItemId: string;
    caseId: string;
    type: string;
    associationTime: Date;
    content: RelatedItemContent;
    performedBy?: UserUnion;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type SearchAllRelatedItemsResponseItemList = SearchAllRelatedItemsResponseItem[];
export interface SearchAllRelatedItemsResponse {
    nextToken?: string;
    relatedItems: SearchAllRelatedItemsResponseItem[];
}
export type SearchTagKey = string;
export interface TagValue {
    key?: string;
    value?: string;
}
export type TagFilter = {
    equalTo: TagValue;
};
export type CaseFilterList = CaseFilter[];
export type CaseFilter = {
    field: FieldFilter;
    not?: never;
    tag?: never;
    andAll?: never;
    orAll?: never;
} | {
    field?: never;
    not: CaseFilter;
    tag?: never;
    andAll?: never;
    orAll?: never;
} | {
    field?: never;
    not?: never;
    tag: TagFilter;
    andAll?: never;
    orAll?: never;
} | {
    field?: never;
    not?: never;
    tag?: never;
    andAll: CaseFilter[];
    orAll?: never;
} | {
    field?: never;
    not?: never;
    tag?: never;
    andAll?: never;
    orAll: CaseFilter[];
};
export interface Sort {
    fieldId: string;
    sortOrder: string;
}
export type SortList = Sort[];
export interface SearchCasesRequest {
    domainId: string;
    maxResults?: number;
    nextToken?: string;
    searchTerm?: string;
    filter?: CaseFilter;
    sorts?: Sort[];
    fields?: FieldIdentifier[];
}
export interface SearchCasesResponseItem {
    caseId: string;
    templateId: string;
    fields: FieldValue[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export type SearchCasesResponseItemList = SearchCasesResponseItem[];
export type TotalCount = number;
export interface SearchCasesResponse {
    nextToken?: string;
    cases: SearchCasesResponseItem[];
    totalCount?: number;
}
export interface SearchRelatedItemsRequest {
    domainId: string;
    caseId: string;
    maxResults?: number;
    nextToken?: string;
    filters?: RelatedItemTypeFilter[];
}
export interface SearchRelatedItemsResponseItem {
    relatedItemId: string;
    type: string;
    associationTime: Date;
    content: RelatedItemContent;
    tags?: {
        [key: string]: string | undefined;
    };
    performedBy?: UserUnion;
}
export type SearchRelatedItemsResponseItemList = SearchRelatedItemsResponseItem[];
export interface SearchRelatedItemsResponse {
    nextToken?: string;
    relatedItems: SearchRelatedItemsResponseItem[];
}
export interface TagResourceRequest {
    arn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKey = string;
export type TagKeyList = string[];
export interface UntagResourceRequest {
    arn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateCaseRequest {
    domainId: string;
    caseId: string;
    fields: FieldValue[];
    performedBy?: UserUnion;
}
export interface UpdateCaseResponse {
}
export interface UpdateCaseRuleRequest {
    domainId: string;
    caseRuleId: string;
    name?: string;
    description?: string;
    rule?: CaseRuleDetails;
}
export interface UpdateCaseRuleResponse {
}
export interface UpdateFieldRequest {
    domainId: string;
    fieldId: string;
    name?: string;
    description?: string;
    attributes?: FieldAttributes;
}
export interface UpdateFieldResponse {
}
export interface UpdateLayoutRequest {
    domainId: string;
    layoutId: string;
    name?: string;
    content?: LayoutContent;
}
export interface UpdateLayoutResponse {
}
export interface CommentUpdateContent {
    body: string;
    contentType: string;
}
export interface CustomUpdateContent {
    fields: FieldValue[];
}
export type RelatedItemUpdateContent = {
    comment: CommentUpdateContent;
    custom?: never;
} | {
    comment?: never;
    custom: CustomUpdateContent;
};
export interface UpdateRelatedItemRequest {
    domainId: string;
    caseId: string;
    relatedItemId: string;
    content: RelatedItemUpdateContent;
    performedBy?: UserUnion;
}
export interface UpdateRelatedItemResponse {
    relatedItemId: string;
    relatedItemArn: string;
    type: string;
    content: RelatedItemContent;
    associationTime: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    lastUpdatedUser?: UserUnion;
    createdBy?: UserUnion;
}
export interface UpdateTemplateRequest {
    domainId: string;
    templateId: string;
    name?: string;
    description?: string;
    layoutConfiguration?: LayoutConfiguration;
    requiredFields?: RequiredField[];
    status?: string;
    rules?: TemplateRule[];
    tagPropagationConfigurations?: TagPropagationConfiguration[];
}
export interface UpdateTemplateResponse {
}
export type BatchGetCaseRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a batch of case rules. In the Amazon Connect admin website, case rules are known as *case field conditions*. For more information about case field conditions, see Add case field conditions to a case template.
 */
export declare const batchGetCaseRule: API.OperationMethod<BatchGetCaseRuleRequest, BatchGetCaseRuleResponse, BatchGetCaseRuleError, Credentials | HttpClient.HttpClient>;
export type BatchGetFieldError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the description for the list of fields in the request parameters.
 */
export declare const batchGetField: API.OperationMethod<BatchGetFieldRequest, BatchGetFieldResponse, BatchGetFieldError, Credentials | HttpClient.HttpClient>;
export type BatchPutFieldOptionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates and updates a set of field options for a single select field in a Cases domain.
 */
export declare const batchPutFieldOptions: API.OperationMethod<BatchPutFieldOptionsRequest, BatchPutFieldOptionsResponse, BatchPutFieldOptionsError, Credentials | HttpClient.HttpClient>;
export type CreateCaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * If you provide a value for `PerformedBy.UserArn` you must also have connect:DescribeUser permission on the User ARN resource that you provide
 *
 * Creates a case in the specified Cases domain. Case system and custom fields are taken as an array id/value pairs with a declared data types.
 *
 * When creating a case from a template that has tag propagation configurations, the specified tags are automatically applied to the case.
 *
 * The following fields are required when creating a case:
 *
 * - `customer_id` - You must provide the full customer profile ARN in this format: `arn:aws:profile:your_AWS_Region:your_AWS_account ID:domains/your_profiles_domain_name/profiles/profile_ID`
 *
 * - `title`
 */
export declare const createCase: API.OperationMethod<CreateCaseRequest, CreateCaseResponse, CreateCaseError, Credentials | HttpClient.HttpClient>;
export type CreateCaseRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new case rule. In the Amazon Connect admin website, case rules are known as *case field conditions*. For more information about case field conditions, see Add case field conditions to a case template.
 */
export declare const createCaseRule: API.OperationMethod<CreateCaseRuleRequest, CreateCaseRuleResponse, CreateCaseRuleError, Credentials | HttpClient.HttpClient>;
export type CreateDomainError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a domain, which is a container for all case data, such as cases, fields, templates and layouts. Each Amazon Connect instance can be associated with only one Cases domain.
 *
 * This will not associate your connect instance to Cases domain. Instead, use the Amazon Connect CreateIntegrationAssociation API. You need specific IAM permissions to successfully associate the Cases domain. For more information, see Onboard to Cases.
 */
export declare const createDomain: API.OperationMethod<CreateDomainRequest, CreateDomainResponse, CreateDomainError, Credentials | HttpClient.HttpClient>;
export type CreateFieldError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a field in the Cases domain. This field is used to define the case object model (that is, defines what data can be captured on cases) in a Cases domain.
 */
export declare const createField: API.OperationMethod<CreateFieldRequest, CreateFieldResponse, CreateFieldError, Credentials | HttpClient.HttpClient>;
export type CreateLayoutError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a layout in the Cases domain. Layouts define the following configuration in the top section and More Info tab of the Cases user interface:
 *
 * - Fields to display to the users
 *
 * - Field ordering
 *
 * Title and Status fields cannot be part of layouts since they are not configurable.
 */
export declare const createLayout: API.OperationMethod<CreateLayoutRequest, CreateLayoutResponse, CreateLayoutError, Credentials | HttpClient.HttpClient>;
export type CreateRelatedItemError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a related item (comments, tasks, and contacts) and associates it with a case.
 *
 * There's a quota for the number of fields allowed in a Custom type related item. See Amazon Connect Cases quotas.
 *
 * **Use cases**
 *
 * Following are examples of related items that you may want to associate with a case:
 *
 * - Related contacts, such as calls, chats, emails tasks
 *
 * - Comments, for agent notes
 *
 * - SLAs, to capture target resolution goals
 *
 * - Cases, to capture related Amazon Connect Cases
 *
 * - Files, such as policy documentation or customer-provided attachments
 *
 * - Custom related items, which provide flexibility for you to define related items that such as bookings, orders, products, notices, and more
 *
 * **Important things to know**
 *
 * - If you are associating a contact to a case by passing in `Contact` for a `type`, you must have DescribeContact permission on the ARN of the contact that you provide in `content.contact.contactArn`.
 *
 * - A Related Item is a resource that is associated with a case. It may or may not have an external identifier linking it to an external resource (for example, a `contactArn`). All Related Items have their own internal identifier, the `relatedItemArn`. Examples of related items include `comments` and `contacts`.
 *
 * - If you provide a value for `performedBy.userArn` you must also have DescribeUser permission on the ARN of the user that you provide.
 *
 * - The `type` field is reserved for internal use only.
 *
 * **Endpoints**: See Amazon Connect endpoints and quotas.
 */
export declare const createRelatedItem: API.OperationMethod<CreateRelatedItemRequest, CreateRelatedItemResponse, CreateRelatedItemError, Credentials | HttpClient.HttpClient>;
export type CreateTemplateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a template in the Cases domain. This template is used to define the case object model (that is, to define what data can be captured on cases) in a Cases domain. A template must have a unique name within a domain, and it must reference existing field IDs and layout IDs. Additionally, multiple fields with same IDs are not allowed within the same Template. A template can be either Active or Inactive, as indicated by its status. Inactive templates cannot be used to create cases.
 *
 * Other template APIs are:
 *
 * - DeleteTemplate
 *
 * - GetTemplate
 *
 * - ListTemplates
 *
 * - UpdateTemplate
 */
export declare const createTemplate: API.OperationMethod<CreateTemplateRequest, CreateTemplateResponse, CreateTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteCaseError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The DeleteCase API permanently deletes a case and all its associated resources from the cases data store. After a successful deletion, you cannot:
 *
 * - Retrieve related items
 *
 * - Access audit history
 *
 * - Perform any operations that require the CaseID
 *
 * This action is irreversible. After you delete a case, you cannot recover its data.
 */
export declare const deleteCase: API.OperationMethod<DeleteCaseRequest, DeleteCaseResponse, DeleteCaseError, Credentials | HttpClient.HttpClient>;
export type DeleteCaseRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a case rule. In the Amazon Connect admin website, case rules are known as *case field conditions*. For more information about case field conditions, see Add case field conditions to a case template.
 */
export declare const deleteCaseRule: API.OperationMethod<DeleteCaseRuleRequest, DeleteCaseRuleResponse, DeleteCaseRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Cases domain.
 *
 * After deleting your domain you must disassociate the deleted domain from your Amazon Connect instance with another API call before being able to use Cases again with this Amazon Connect instance. See DeleteIntegrationAssociation.
 */
export declare const deleteDomain: API.OperationMethod<DeleteDomainRequest, DeleteDomainResponse, DeleteDomainError, Credentials | HttpClient.HttpClient>;
export type DeleteFieldError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a field from a cases template.
 *
 * After a field is deleted:
 *
 * - You can still retrieve the field by calling `BatchGetField`.
 *
 * - You cannot update a deleted field by calling `UpdateField`; it throws a `ValidationException`.
 *
 * - Deleted fields are not included in the `ListFields` response.
 *
 * - Calling `CreateCase` with a deleted field throws a `ValidationException` denoting which field identifiers in the request have been deleted.
 *
 * - Calling `GetCase` with a deleted field identifier returns the deleted field's value if one exists.
 *
 * - Calling `UpdateCase` with a deleted field ID throws a `ValidationException` if the case does not already contain a value for the deleted field. Otherwise it succeeds, allowing you to update or remove (using `emptyValue: {}`) the field's value from the case.
 *
 * - `GetTemplate` does not return field IDs for deleted fields.
 *
 * - `GetLayout` does not return field IDs for deleted fields.
 *
 * - Calling `SearchCases` with the deleted field ID as a filter returns any cases that have a value for the deleted field that matches the filter criteria.
 *
 * - Calling `SearchCases` with a `searchTerm` value that matches a deleted field's value on a case returns the case in the response.
 *
 * - Calling `BatchPutFieldOptions` with a deleted field ID throw a `ValidationException`.
 *
 * - Calling `GetCaseEventConfiguration` does not return field IDs for deleted fields.
 */
export declare const deleteField: API.OperationMethod<DeleteFieldRequest, DeleteFieldResponse, DeleteFieldError, Credentials | HttpClient.HttpClient>;
export type DeleteLayoutError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a layout from a cases template. You can delete up to 100 layouts per domain.
 *
 * After a layout is deleted:
 *
 * - You can still retrieve the layout by calling `GetLayout`.
 *
 * - You cannot update a deleted layout by calling `UpdateLayout`; it throws a `ValidationException`.
 *
 * - Deleted layouts are not included in the `ListLayouts` response.
 */
export declare const deleteLayout: API.OperationMethod<DeleteLayoutRequest, DeleteLayoutResponse, DeleteLayoutError, Credentials | HttpClient.HttpClient>;
export type DeleteRelatedItemError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the related item resource under a case.
 *
 * This API cannot be used on a FILE type related attachment. To delete this type of file, use the DeleteAttachedFile API
 */
export declare const deleteRelatedItem: API.OperationMethod<DeleteRelatedItemRequest, DeleteRelatedItemResponse, DeleteRelatedItemError, Credentials | HttpClient.HttpClient>;
export type DeleteTemplateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a cases template. You can delete up to 100 templates per domain.
 *
 * After a cases template is deleted:
 *
 * - You can still retrieve the template by calling `GetTemplate`.
 *
 * - You cannot update the template.
 *
 * - You cannot create a case by using the deleted template.
 *
 * - Deleted templates are not included in the `ListTemplates` response.
 */
export declare const deleteTemplate: API.OperationMethod<DeleteTemplateRequest, DeleteTemplateResponse, DeleteTemplateError, Credentials | HttpClient.HttpClient>;
export type GetCaseError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specific case if it exists.
 */
export declare const getCase: API.PaginatedOperationMethod<GetCaseRequest, GetCaseResponse, GetCaseError, Credentials | HttpClient.HttpClient, unknown>;
export type GetCaseAuditEventsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the audit history about a specific case if it exists.
 */
export declare const getCaseAuditEvents: API.PaginatedOperationMethod<GetCaseAuditEventsRequest, GetCaseAuditEventsResponse, GetCaseAuditEventsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetCaseEventConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the case event publishing configuration.
 */
export declare const getCaseEventConfiguration: API.OperationMethod<GetCaseEventConfigurationRequest, GetCaseEventConfigurationResponse, GetCaseEventConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetDomainError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specific domain if it exists.
 */
export declare const getDomain: API.OperationMethod<GetDomainRequest, GetDomainResponse, GetDomainError, Credentials | HttpClient.HttpClient>;
export type GetLayoutError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the details for the requested layout.
 */
export declare const getLayout: API.OperationMethod<GetLayoutRequest, GetLayoutResponse, GetLayoutError, Credentials | HttpClient.HttpClient>;
export type GetTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the details for the requested template. Other template APIs are:
 *
 * - CreateTemplate
 *
 * - DeleteTemplate
 *
 * - ListTemplates
 *
 * - UpdateTemplate
 */
export declare const getTemplate: API.OperationMethod<GetTemplateRequest, GetTemplateResponse, GetTemplateError, Credentials | HttpClient.HttpClient>;
export type ListCaseRulesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all case rules in a Cases domain. In the Amazon Connect admin website, case rules are known as *case field conditions*. For more information about case field conditions, see Add case field conditions to a case template.
 */
export declare const listCaseRules: API.PaginatedOperationMethod<ListCaseRulesRequest, ListCaseRulesResponse, ListCaseRulesError, Credentials | HttpClient.HttpClient, CaseRuleSummary>;
export type ListCasesForContactError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists cases for a given contact.
 */
export declare const listCasesForContact: API.PaginatedOperationMethod<ListCasesForContactRequest, ListCasesForContactResponse, ListCasesForContactError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDomainsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all cases domains in the Amazon Web Services account. Each list item is a condensed summary object of the domain.
 */
export declare const listDomains: API.PaginatedOperationMethod<ListDomainsRequest, ListDomainsResponse, ListDomainsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFieldOptionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all of the field options for a field identifier in the domain.
 */
export declare const listFieldOptions: API.PaginatedOperationMethod<ListFieldOptionsRequest, ListFieldOptionsResponse, ListFieldOptionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFieldsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all fields in a Cases domain.
 */
export declare const listFields: API.PaginatedOperationMethod<ListFieldsRequest, ListFieldsResponse, ListFieldsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListLayoutsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all layouts in the given cases domain. Each list item is a condensed summary object of the layout.
 */
export declare const listLayouts: API.PaginatedOperationMethod<ListLayoutsRequest, ListLayoutsResponse, ListLayoutsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTemplatesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all of the templates in a Cases domain. Each list item is a condensed summary object of the template.
 *
 * Other template APIs are:
 *
 * - CreateTemplate
 *
 * - DeleteTemplate
 *
 * - GetTemplate
 *
 * - UpdateTemplate
 */
export declare const listTemplates: API.PaginatedOperationMethod<ListTemplatesRequest, ListTemplatesResponse, ListTemplatesError, Credentials | HttpClient.HttpClient, unknown>;
export type PutCaseEventConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds case event publishing configuration. For a complete list of fields you can add to the event message, see Create case fields in the *Amazon Connect Administrator Guide*
 */
export declare const putCaseEventConfiguration: API.OperationMethod<PutCaseEventConfigurationRequest, PutCaseEventConfigurationResponse, PutCaseEventConfigurationError, Credentials | HttpClient.HttpClient>;
export type SearchAllRelatedItemsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches for related items across all cases within a domain. This is a global search operation that returns related items from multiple cases, unlike the case-specific SearchRelatedItems API.
 *
 * **Use cases**
 *
 * Following are common uses cases for this API:
 *
 * - Find cases with similar issues across the domain. For example, search for all cases containing comments about "product defect" to identify patterns and existing solutions.
 *
 * - Locate all cases associated with specific contacts or orders. For example, find all cases linked to a contactArn to understand the complete customer journey.
 *
 * - Monitor SLA compliance across cases. For example, search for all cases with "Active" SLA status to prioritize remediation efforts.
 *
 * **Important things to know**
 *
 * - This API returns case identifiers, not complete case objects. To retrieve full case details, you must make additional calls to the GetCase API for each returned case ID.
 *
 * - This API searches across related items content, not case fields. Use the SearchCases API to search within case field values.
 *
 * **Endpoints**: See Amazon Connect endpoints and quotas.
 */
export declare const searchAllRelatedItems: API.PaginatedOperationMethod<SearchAllRelatedItemsRequest, SearchAllRelatedItemsResponse, SearchAllRelatedItemsError, Credentials | HttpClient.HttpClient, SearchAllRelatedItemsResponseItem>;
export type SearchCasesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches for cases within their associated Cases domain. Search results are returned as a paginated list of abridged case documents.
 *
 * For `customer_id` you must provide the full customer profile ARN in this format: ` arn:aws:profile:your AWS Region:your AWS account ID:domains/profiles domain name/profiles/profile ID`.
 */
export declare const searchCases: API.PaginatedOperationMethod<SearchCasesRequest, SearchCasesResponse, SearchCasesError, Credentials | HttpClient.HttpClient, SearchCasesResponseItem>;
export type SearchRelatedItemsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches for related items that are associated with a case.
 *
 * If no filters are provided, this returns all related items associated with a case.
 */
export declare const searchRelatedItems: API.PaginatedOperationMethod<SearchRelatedItemsRequest, SearchRelatedItemsResponse, SearchRelatedItemsError, Credentials | HttpClient.HttpClient, SearchRelatedItemsResponseItem>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Untags a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCaseError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * If you provide a value for `PerformedBy.UserArn` you must also have connect:DescribeUser permission on the User ARN resource that you provide
 *
 * Updates the values of fields on a case. Fields to be updated are received as an array of id/value pairs identical to the `CreateCase` input .
 *
 * If the action is successful, the service sends back an HTTP 200 response with an empty HTTP body.
 */
export declare const updateCase: API.OperationMethod<UpdateCaseRequest, UpdateCaseResponse, UpdateCaseError, Credentials | HttpClient.HttpClient>;
export type UpdateCaseRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a case rule. In the Amazon Connect admin website, case rules are known as *case field conditions*. For more information about case field conditions, see Add case field conditions to a case template.
 */
export declare const updateCaseRule: API.OperationMethod<UpdateCaseRuleRequest, UpdateCaseRuleResponse, UpdateCaseRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateFieldError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the properties of an existing field.
 */
export declare const updateField: API.OperationMethod<UpdateFieldRequest, UpdateFieldResponse, UpdateFieldError, Credentials | HttpClient.HttpClient>;
export type UpdateLayoutError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the attributes of an existing layout.
 *
 * If the action is successful, the service sends back an HTTP 200 response with an empty HTTP body.
 *
 * A `ValidationException` is returned when you add non-existent `fieldIds` to a layout.
 *
 * Title and Status fields cannot be part of layouts because they are not configurable.
 */
export declare const updateLayout: API.OperationMethod<UpdateLayoutRequest, UpdateLayoutResponse, UpdateLayoutError, Credentials | HttpClient.HttpClient>;
export type UpdateRelatedItemError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the content of a related item associated with a case. The following related item types are supported:
 *
 * - **Comment** - Update the text content of an existing comment
 *
 * - **Custom** - Update the fields of a custom related item. You can add, modify, and remove fields from a custom related item. There's a quota for the number of fields allowed in a Custom type related item. See Amazon Connect Cases quotas.
 *
 * **Important things to know**
 *
 * - When updating a Custom related item, all existing and new fields, and their associated values should be included in the request. Fields not included as part of this request will be removed.
 *
 * - If you provide a value for `performedBy.userArn` you must also have DescribeUser permission on the ARN of the user that you provide.
 *
 * - System case fields cannot be used in a custom related item.
 *
 * **Endpoints**: See Amazon Connect endpoints and quotas.
 */
export declare const updateRelatedItem: API.OperationMethod<UpdateRelatedItemRequest, UpdateRelatedItemResponse, UpdateRelatedItemError, Credentials | HttpClient.HttpClient>;
export type UpdateTemplateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the attributes of an existing template. The template attributes that can be modified include `name`, `description`, `layoutConfiguration`, `requiredFields`, and `status`. At least one of these attributes must not be null. If a null value is provided for a given attribute, that attribute is ignored and its current value is preserved.
 *
 * Other template APIs are:
 *
 * - CreateTemplate
 *
 * - DeleteTemplate
 *
 * - GetTemplate
 *
 * - ListTemplates
 */
export declare const updateTemplate: API.OperationMethod<UpdateTemplateRequest, UpdateTemplateResponse, UpdateTemplateError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=connectcases.d.ts.map