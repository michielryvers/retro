import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly fieldList: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Action = string;
export type Actions = string[];
export type ActionSet = {
    allActions: Record<string, never>;
    actions?: never;
} | {
    allActions?: never;
    actions: string[];
};
export type Resource = string;
export type Resources = string[];
export type ResourceSet = {
    allResourcesInRegion: Record<string, never>;
    resources?: never;
} | {
    allResourcesInRegion?: never;
    resources: string[];
};
export type Condition = {
    allowAfter: Date;
    allowBefore?: never;
} | {
    allowAfter?: never;
    allowBefore: Date;
};
export type Conditions = Condition[];
export interface Permit {
    actions: ActionSet;
    resources: ResourceSet;
    conditions?: Condition[];
}
export type Name = string;
export type Description = string;
export type KmsKeyArn = string;
export type SigningKeyInfo = {
    kmsKey: string;
};
export type SupportCaseDisplayId = string;
export type ClientToken = string;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export interface CreateSupportPermitInput {
    permit: Permit;
    name: string;
    description?: string;
    signingKeyInfo: SigningKeyInfo;
    supportCaseDisplayId?: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type Arn = string;
export type SupportPermitStatus = "ACTIVE" | "INACTIVE" | "DELETING" | (string & {});
export interface CreateSupportPermitOutput {
    name: string;
    arn: string;
    description?: string;
    permit: Permit;
    status: SupportPermitStatus;
    signingKeyInfo: SigningKeyInfo;
    createdAt: Date;
    supportCaseDisplayId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface DeleteSupportPermitInput {
    supportPermitIdentifier: string;
}
export interface DeleteSupportPermitOutput {
    name: string;
    arn: string;
    description?: string;
    permit: Permit;
    status: SupportPermitStatus;
    signingKeyInfo: SigningKeyInfo;
    createdAt: Date;
    supportCaseDisplayId?: string;
}
export interface GetActionInput {
    action: string;
}
export type Service = string;
export type ActionDescription = string;
export interface GetActionOutput {
    action: string;
    service: string;
    description: string;
}
export type SupportPermitIdentifier = string;
export interface GetSupportPermitInput {
    supportPermitIdentifier: string;
}
export interface GetSupportPermitOutput {
    name: string;
    arn: string;
    description?: string;
    permit: Permit;
    status: SupportPermitStatus;
    signingKeyInfo: SigningKeyInfo;
    createdAt: Date;
    supportCaseDisplayId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type NextToken = string;
export type MaxResults = number;
export interface ListActionsInput {
    nextToken?: string;
    maxResults?: number;
    service: string;
}
export interface ActionSummary {
    action: string;
    service: string;
    description: string;
}
export type ActionSummaries = ActionSummary[];
export interface ListActionsOutput {
    actionSummaries: ActionSummary[];
    nextToken?: string;
}
export interface ListSupportPermitRequestsInput {
    nextToken?: string;
    maxResults?: number;
    supportCaseDisplayId?: string;
}
export type RequestArn = string;
export type SupportPermitRequestStatus = "PENDING" | "ACCEPTED" | "REJECTED" | "CANCELLED" | (string & {});
export interface SupportPermitRequest {
    requestArn: string;
    permit: Permit;
    supportCaseDisplayId: string;
    status: SupportPermitRequestStatus;
    createdAt: Date;
    updatedAt: Date;
}
export type SupportPermitRequests = SupportPermitRequest[];
export interface ListSupportPermitRequestsOutput {
    supportPermitRequests: SupportPermitRequest[];
    nextToken?: string;
}
export type SupportPermitStatuses = SupportPermitStatus[];
export interface ListSupportPermitsInput {
    nextToken?: string;
    maxResults?: number;
    supportPermitStatuses?: SupportPermitStatus[];
}
export interface SupportPermitSummary {
    name: string;
    arn: string;
    permit: Permit;
    status: SupportPermitStatus;
    signingKeyInfo: SigningKeyInfo;
    createdAt: Date;
    supportCaseDisplayId?: string;
}
export type SupportPermitSummaries = SupportPermitSummary[];
export interface ListSupportPermitsOutput {
    supportPermits: SupportPermitSummary[];
    nextToken?: string;
}
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface RejectSupportPermitRequestInput {
    requestArn: string;
}
export interface RejectSupportPermitRequestOutput {
    requestArn: string;
}
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface ValidationExceptionField {
    path: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type CreateSupportPermitError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a support permit that authorizes an AWS support operator to perform specified actions on specified resources. The permit is cryptographically signed using a customer-managed AWS KMS key (ECC_NIST_P384, SIGN_VERIFY) to ensure non-repudiation.
 */
export declare const createSupportPermit: API.OperationMethod<CreateSupportPermitInput, CreateSupportPermitOutput, CreateSupportPermitError, Credentials | HttpClient.HttpClient>;
export type DeleteSupportPermitError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a support permit, revoking the authorization previously granted to the AWS support operator.
 */
export declare const deleteSupportPermit: API.OperationMethod<DeleteSupportPermitInput, DeleteSupportPermitOutput, DeleteSupportPermitError, Credentials | HttpClient.HttpClient>;
export type GetActionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the description of a specific support action.
 */
export declare const getAction: API.OperationMethod<GetActionInput, GetActionOutput, GetActionError, Credentials | HttpClient.HttpClient>;
export type GetSupportPermitError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of a support permit by its ARN or name.
 */
export declare const getSupportPermit: API.OperationMethod<GetSupportPermitInput, GetSupportPermitOutput, GetSupportPermitError, Credentials | HttpClient.HttpClient>;
export type ListActionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists available support actions for a specified AWS service. Use pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listActions: API.PaginatedOperationMethod<ListActionsInput, ListActionsOutput, ListActionsError, Credentials | HttpClient.HttpClient, ActionSummary>;
export type ListSupportPermitRequestsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists permit requests from AWS support operators. Use pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listSupportPermitRequests: API.PaginatedOperationMethod<ListSupportPermitRequestsInput, ListSupportPermitRequestsOutput, ListSupportPermitRequestsError, Credentials | HttpClient.HttpClient, SupportPermitRequest>;
export type ListSupportPermitsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all support permits in the caller's account. Use pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listSupportPermits: API.PaginatedOperationMethod<ListSupportPermitsInput, ListSupportPermitsOutput, ListSupportPermitsError, Credentials | HttpClient.HttpClient, SupportPermitSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags associated with a support permit resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RejectSupportPermitRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Rejects a permit request from an AWS support operator. The operator cannot proceed with the requested action.
 */
export declare const rejectSupportPermitRequest: API.OperationMethod<RejectSupportPermitRequestInput, RejectSupportPermitRequestOutput, RejectSupportPermitRequestError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds or overwrites one or more tags for a support permit resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from a support permit resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=supportauthz.d.ts.map