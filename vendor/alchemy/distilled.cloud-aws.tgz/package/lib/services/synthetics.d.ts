import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalFailureException_base: S.TaggedErrorClass<"InternalFailureException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const RequestEntityTooLargeException_base: S.TaggedErrorClass<"RequestEntityTooLargeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RequestEntityTooLargeException extends /*@__PURE__*/ RequestEntityTooLargeException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type GroupIdentifier = string;
export type CanaryArn = string;
export interface AssociateResourceRequest {
    GroupIdentifier: string;
    ResourceArn: string;
}
export interface AssociateResourceResponse {
}
export type CanaryName = string;
export type CodeHandler = string;
export type BlueprintType = string;
export type BlueprintTypes = string[];
export type DependencyType = "LambdaLayer" | (string & {});
export interface Dependency {
    Type?: DependencyType;
    Reference: string;
}
export type Dependencies = Dependency[];
export interface CanaryCodeInput {
    S3Bucket?: string;
    S3Key?: string;
    S3Version?: string;
    ZipFile?: Uint8Array;
    Handler?: string;
    BlueprintTypes?: string[];
    Dependencies?: Dependency[];
}
export type RoleArn = string;
export type MaxOneYearInSeconds = number;
export type MaxRetries = number;
export interface RetryConfigInput {
    MaxRetries: number;
}
export interface CanaryScheduleInput {
    Expression: string;
    DurationInSeconds?: number;
    RetryConfig?: RetryConfigInput;
}
export type MaxFifteenMinutesInSeconds = number;
export type MaxSize3008 = number;
export type EnvironmentVariableName = string;
export type EnvironmentVariableValue = string;
export type EnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export type EphemeralStorageSize = number;
export interface CanaryRunConfigInput {
    TimeoutInSeconds?: number;
    MemoryInMB?: number;
    ActiveTracing?: boolean;
    EnvironmentVariables?: {
        [key: string]: string | undefined;
    };
    EphemeralStorage?: number;
}
export type MaxSize1024 = number;
export type SubnetId = string;
export type SubnetIds = string[];
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export interface VpcConfigInput {
    SubnetIds?: string[];
    SecurityGroupIds?: string[];
    Ipv6AllowedForDualStack?: boolean;
}
export type ResourceToTag = "lambda-function" | (string & {});
export type ResourceList = ResourceToTag[];
export type ProvisionedResourceCleanupSetting = "AUTOMATIC" | "OFF" | (string & {});
export type BrowserType = "CHROME" | "FIREFOX" | (string & {});
export interface BrowserConfig {
    BrowserType?: BrowserType;
}
export type BrowserConfigs = BrowserConfig[];
export type Location = string;
export type KmsKeyArn = string;
export interface AddReplicaLocationInput {
    Location: string;
    VpcConfig?: VpcConfigInput;
    KmsKeyArn?: string;
}
export type AddReplicaLocations = AddReplicaLocationInput[];
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type EncryptionMode = "SSE_S3" | "SSE_KMS" | (string & {});
export interface S3EncryptionConfig {
    EncryptionMode?: EncryptionMode;
    KmsKeyArn?: string;
}
export interface ArtifactConfigInput {
    S3Encryption?: S3EncryptionConfig;
}
export interface CreateCanaryRequest {
    Name: string;
    Code: CanaryCodeInput;
    ArtifactS3Location: string;
    ExecutionRoleArn: string;
    Schedule: CanaryScheduleInput;
    RunConfig?: CanaryRunConfigInput;
    SuccessRetentionPeriodInDays?: number;
    FailureRetentionPeriodInDays?: number;
    RuntimeVersion: string;
    VpcConfig?: VpcConfigInput;
    ResourcesToReplicateTags?: ResourceToTag[];
    ProvisionedResourceCleanup?: ProvisionedResourceCleanupSetting;
    BrowserConfigs?: BrowserConfig[];
    AddReplicaLocations?: AddReplicaLocationInput[];
    Tags?: {
        [key: string]: string | undefined;
    };
    ArtifactConfig?: ArtifactConfigInput;
    KmsKeyArn?: string;
}
export type UUID = string;
export interface CanaryCodeOutput {
    SourceLocationArn?: string;
    Handler?: string;
    BlueprintTypes?: string[];
    Dependencies?: Dependency[];
}
export interface RetryConfigOutput {
    MaxRetries?: number;
}
export interface CanaryScheduleOutput {
    Expression?: string;
    DurationInSeconds?: number;
    RetryConfig?: RetryConfigOutput;
}
export interface CanaryRunConfigOutput {
    TimeoutInSeconds?: number;
    MemoryInMB?: number;
    ActiveTracing?: boolean;
    EphemeralStorage?: number;
}
export type CanaryState = "CREATING" | "READY" | "STARTING" | "RUNNING" | "UPDATING" | "STOPPING" | "STOPPED" | "ERROR" | "DELETING" | (string & {});
export type CanaryStateReasonCode = "INVALID_PERMISSIONS" | "CREATE_PENDING" | "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "UPDATE_PENDING" | "UPDATE_IN_PROGRESS" | "UPDATE_COMPLETE" | "ROLLBACK_COMPLETE" | "ROLLBACK_FAILED" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | "SYNC_DELETE_IN_PROGRESS" | (string & {});
export interface CanaryStatus {
    State?: CanaryState;
    StateReason?: string;
    StateReasonCode?: CanaryStateReasonCode;
}
export interface CanaryTimeline {
    Created?: Date;
    LastModified?: Date;
    LastStarted?: Date;
    LastStopped?: Date;
}
export type FunctionArn = string;
export type VpcId = string;
export interface VpcConfigOutput {
    VpcId?: string;
    SubnetIds?: string[];
    SecurityGroupIds?: string[];
    Ipv6AllowedForDualStack?: boolean;
}
export type BaseScreenshotConfigIgnoreCoordinate = string;
export type BaseScreenshotIgnoreCoordinates = string[];
export interface BaseScreenshot {
    ScreenshotName: string;
    IgnoreCoordinates?: string[];
}
export type BaseScreenshots = BaseScreenshot[];
export interface VisualReferenceOutput {
    BaseScreenshots?: BaseScreenshot[];
    BaseCanaryRunId?: string;
    BrowserType?: BrowserType;
}
export interface EngineConfig {
    EngineArn?: string;
    BrowserType?: BrowserType;
}
export type EngineConfigs = EngineConfig[];
export type VisualReferencesOutput = VisualReferenceOutput[];
export type LocationType = "Primary" | "Replica" | (string & {});
export type ReplicationState = "InProgress" | "InSync" | "Inconsistent" | (string & {});
export interface ReplicationStatus {
    State?: ReplicationState;
    StateReason?: string;
    StateReasonCode?: string;
}
export interface Replica {
    Location?: string;
    ReplicationStatus?: ReplicationStatus;
    CanaryState?: CanaryState;
    LastModified?: Date;
    VpcConfig?: VpcConfigOutput;
}
export type Replicas = Replica[];
export interface MultiLocationConfig {
    LocationType?: LocationType;
    PrimaryLocation?: string;
    Replicas?: Replica[];
    ReplicationState?: ReplicationState;
}
export interface ArtifactConfigOutput {
    S3Encryption?: S3EncryptionConfig;
}
export interface DryRunConfigOutput {
    DryRunId?: string;
    LastDryRunExecutionStatus?: string;
}
export interface Canary {
    Id?: string;
    Name?: string;
    Code?: CanaryCodeOutput;
    ExecutionRoleArn?: string;
    Schedule?: CanaryScheduleOutput;
    RunConfig?: CanaryRunConfigOutput;
    SuccessRetentionPeriodInDays?: number;
    FailureRetentionPeriodInDays?: number;
    Status?: CanaryStatus;
    Timeline?: CanaryTimeline;
    ArtifactS3Location?: string;
    EngineArn?: string;
    RuntimeVersion?: string;
    VpcConfig?: VpcConfigOutput;
    VisualReference?: VisualReferenceOutput;
    ProvisionedResourceCleanup?: ProvisionedResourceCleanupSetting;
    BrowserConfigs?: BrowserConfig[];
    EngineConfigs?: EngineConfig[];
    VisualReferences?: VisualReferenceOutput[];
    MultiLocationConfig?: MultiLocationConfig;
    Tags?: {
        [key: string]: string | undefined;
    };
    ArtifactConfig?: ArtifactConfigOutput;
    KmsKeyArn?: string;
    DryRunConfig?: DryRunConfigOutput;
}
export interface CreateCanaryResponse {
    Canary?: Canary;
}
export type GroupName = string;
export interface CreateGroupRequest {
    Name: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type GroupArn = string;
export interface Group {
    Id?: string;
    Name?: string;
    Arn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    CreatedTime?: Date;
    LastModifiedTime?: Date;
}
export interface CreateGroupResponse {
    Group?: Group;
}
export interface DeleteCanaryRequest {
    Name: string;
    DeleteLambda?: boolean;
}
export interface DeleteCanaryResponse {
}
export interface DeleteGroupRequest {
    GroupIdentifier: string;
}
export interface DeleteGroupResponse {
}
export type Token = string;
export type MaxCanaryResults = number;
export type DescribeCanariesNameFilter = string[];
export interface DescribeCanariesRequest {
    NextToken?: string;
    MaxResults?: number;
    Names?: string[];
}
export type Canaries = Canary[];
export interface DescribeCanariesResponse {
    Canaries?: Canary[];
    NextToken?: string;
}
export type MaxSize100 = number;
export type DescribeCanariesLastRunNameFilter = string[];
export interface DescribeCanariesLastRunRequest {
    NextToken?: string;
    MaxResults?: number;
    Names?: string[];
    BrowserType?: BrowserType;
}
export type RetryAttempt = number;
export type CanaryRunState = "RUNNING" | "PASSED" | "FAILED" | (string & {});
export type CanaryRunStateReasonCode = "CANARY_FAILURE" | "EXECUTION_FAILURE" | (string & {});
export type CanaryRunTestResult = "PASSED" | "FAILED" | "UNKNOWN" | (string & {});
export interface CanaryRunStatus {
    State?: CanaryRunState;
    StateReason?: string;
    StateReasonCode?: CanaryRunStateReasonCode;
    TestResult?: CanaryRunTestResult;
}
export interface CanaryRunTimeline {
    Started?: Date;
    Completed?: Date;
    MetricTimestampForRunAndRetries?: Date;
}
export interface CanaryDryRunConfigOutput {
    DryRunId?: string;
}
export interface CanaryRun {
    Id?: string;
    ScheduledRunId?: string;
    RetryAttempt?: number;
    Name?: string;
    Status?: CanaryRunStatus;
    Timeline?: CanaryRunTimeline;
    ArtifactS3Location?: string;
    DryRunConfig?: CanaryDryRunConfigOutput;
    BrowserType?: BrowserType;
    Location?: string;
}
export interface CanaryLastRun {
    CanaryName?: string;
    LastRun?: CanaryRun;
}
export type CanariesLastRun = CanaryLastRun[];
export interface DescribeCanariesLastRunResponse {
    CanariesLastRun?: CanaryLastRun[];
    NextToken?: string;
}
export interface DescribeRuntimeVersionsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface RuntimeVersion {
    VersionName?: string;
    Description?: string;
    ReleaseDate?: Date;
    DeprecationDate?: Date;
}
export type RuntimeVersionList = RuntimeVersion[];
export interface DescribeRuntimeVersionsResponse {
    RuntimeVersions?: RuntimeVersion[];
    NextToken?: string;
}
export interface DisassociateResourceRequest {
    GroupIdentifier: string;
    ResourceArn: string;
}
export interface DisassociateResourceResponse {
}
export interface GetCanaryRequest {
    Name: string;
    DryRunId?: string;
}
export interface GetCanaryResponse {
    Canary?: Canary;
}
export type RunType = "CANARY_RUN" | "DRY_RUN" | (string & {});
export interface GetCanaryRunsRequest {
    Name: string;
    NextToken?: string;
    MaxResults?: number;
    DryRunId?: string;
    RunType?: RunType;
}
export type CanaryRuns = CanaryRun[];
export interface GetCanaryRunsResponse {
    CanaryRuns?: CanaryRun[];
    NextToken?: string;
}
export interface GetGroupRequest {
    GroupIdentifier: string;
}
export interface GetGroupResponse {
    Group?: Group;
}
export type PaginationToken = string;
export type MaxGroupResults = number;
export interface ListAssociatedGroupsRequest {
    NextToken?: string;
    MaxResults?: number;
    ResourceArn: string;
}
export interface GroupSummary {
    Id?: string;
    Name?: string;
    Arn?: string;
}
export type GroupSummaryList = GroupSummary[];
export interface ListAssociatedGroupsResponse {
    Groups?: GroupSummary[];
    NextToken?: string;
}
export interface ListGroupResourcesRequest {
    NextToken?: string;
    MaxResults?: number;
    GroupIdentifier: string;
}
export type StringList = string[];
export interface ListGroupResourcesResponse {
    Resources?: string[];
    NextToken?: string;
}
export interface ListGroupsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export interface ListGroupsResponse {
    Groups?: GroupSummary[];
    NextToken?: string;
}
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface StartCanaryRequest {
    Name: string;
}
export interface StartCanaryResponse {
}
export interface VisualReferenceInput {
    BaseScreenshots?: BaseScreenshot[];
    BaseCanaryRunId: string;
    BrowserType?: BrowserType;
}
export type VisualReferences = VisualReferenceInput[];
export interface StartCanaryDryRunRequest {
    Name: string;
    Code?: CanaryCodeInput;
    RuntimeVersion?: string;
    RunConfig?: CanaryRunConfigInput;
    VpcConfig?: VpcConfigInput;
    ExecutionRoleArn?: string;
    SuccessRetentionPeriodInDays?: number;
    FailureRetentionPeriodInDays?: number;
    VisualReference?: VisualReferenceInput;
    ArtifactS3Location?: string;
    ArtifactConfig?: ArtifactConfigInput;
    ProvisionedResourceCleanup?: ProvisionedResourceCleanupSetting;
    BrowserConfigs?: BrowserConfig[];
    VisualReferences?: VisualReferenceInput[];
}
export interface StartCanaryDryRunResponse {
    DryRunConfig?: DryRunConfigOutput;
}
export interface StopCanaryRequest {
    Name: string;
}
export interface StopCanaryResponse {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export type RemoveReplicaLocations = string[];
export interface UpdateCanaryRequest {
    Name: string;
    Code?: CanaryCodeInput;
    ExecutionRoleArn?: string;
    RuntimeVersion?: string;
    Schedule?: CanaryScheduleInput;
    RunConfig?: CanaryRunConfigInput;
    SuccessRetentionPeriodInDays?: number;
    FailureRetentionPeriodInDays?: number;
    VpcConfig?: VpcConfigInput;
    VisualReference?: VisualReferenceInput;
    ArtifactS3Location?: string;
    ArtifactConfig?: ArtifactConfigInput;
    ProvisionedResourceCleanup?: ProvisionedResourceCleanupSetting;
    DryRunId?: string;
    VisualReferences?: VisualReferenceInput[];
    BrowserConfigs?: BrowserConfig[];
    AddReplicaLocations?: AddReplicaLocationInput[];
    RemoveReplicaLocations?: string[];
    KmsKeyArn?: string;
}
export interface UpdateCanaryResponse {
}
export type ErrorMessage = string;
export type AssociateResourceError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Associates a canary with a group. Using groups can help you with
 * managing and automating your canaries, and you can also view aggregated run results and statistics
 * for all canaries in a group.
 *
 * You must run this operation in the Region where the canary exists.
 */
export declare const associateResource: API.OperationMethod<AssociateResourceRequest, AssociateResourceResponse, AssociateResourceError, Credentials | HttpClient.HttpClient>;
export type CreateCanaryError = InternalServerException | RequestEntityTooLargeException | ValidationException | CommonErrors;
/**
 * Creates a canary. Canaries are scripts that monitor your endpoints and APIs from the
 * outside-in. Canaries help you check the availability and latency of your web services and
 * troubleshoot anomalies by investigating load time data, screenshots of the UI, logs, and
 * metrics. You can set up a canary to run continuously or just once.
 *
 * Do not use `CreateCanary` to modify an existing canary. Use UpdateCanary instead.
 *
 * To create canaries, you must have the `CloudWatchSyntheticsFullAccess` policy.
 * If you are creating a new IAM role for the canary, you also need the
 * `iam:CreateRole`, `iam:CreatePolicy` and
 * `iam:AttachRolePolicy` permissions. For more information, see Necessary
 * Roles and Permissions.
 *
 * Do not include secrets or proprietary information in your canary names. The canary name
 * makes up part of the Amazon Resource Name (ARN) for the canary, and the ARN is included in
 * outbound calls over the internet. For more information, see Security
 * Considerations for Synthetics Canaries.
 */
export declare const createCanary: API.OperationMethod<CreateCanaryRequest, CreateCanaryResponse, CreateCanaryError, Credentials | HttpClient.HttpClient>;
export type CreateGroupError = ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a group which you can use to associate canaries with each other, including cross-Region
 * canaries. Using groups can help you with
 * managing and automating your canaries, and you can also view aggregated run results and statistics
 * for all canaries in a group.
 *
 * Groups are global resources. When you create a group, it is replicated across Amazon Web Services Regions, and
 * you can view it and add canaries to it from any Region.
 * Although the group ARN format reflects the Region name where it was created, a group is not constrained to any Region.
 * This means that you can put canaries from multiple Regions into the same group, and then use
 * that group to view and manage all of those canaries in a single view.
 *
 * Groups are supported in all Regions except the Regions that are disabled by default. For more information
 * about these Regions, see Enabling a Region.
 *
 * Each group can contain as many as 10 canaries. You can have as many as 20 groups in your account. Any single canary
 * can be a member of up to 10 groups.
 */
export declare const createGroup: API.OperationMethod<CreateGroupRequest, CreateGroupResponse, CreateGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteCanaryError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Permanently deletes the specified canary.
 *
 * If the canary's `ProvisionedResourceCleanup` field is set to `AUTOMATIC`
 * or you specify `DeleteLambda` in this operation as `true`, CloudWatch Synthetics also deletes
 * the Lambda functions and layers that are used by the canary.
 *
 * Other resources used and created by the canary are not automatically deleted.
 * After you delete a canary, you
 * should also delete the following:
 *
 * - The CloudWatch alarms created for this canary. These alarms have a name of
 * Synthetics-Alarm-*first-198-characters-of-canary-name*-*canaryId*-*alarm number*
 *
 * - Amazon S3 objects and buckets, such as the canary's artifact location.
 *
 * - IAM roles created for the canary. If they were created in the console, these roles
 * have the name
 * role/service-role/CloudWatchSyntheticsRole-*First-21-Characters-of-CanaryName*
 *
 * - CloudWatch Logs log groups created for the canary. These logs groups have the name
 * /aws/lambda/cwsyn-*First-21-Characters-of-CanaryName*
 *
 * Before you delete a canary, you might want to use `GetCanary` to display
 * the information about this canary. Make
 * note of the information returned by this operation so that you can delete these resources
 * after you delete the canary.
 */
export declare const deleteCanary: API.OperationMethod<DeleteCanaryRequest, DeleteCanaryResponse, DeleteCanaryError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a group. The group doesn't need to be empty to be deleted. If there are canaries in the group,
 * they are not deleted when you delete the group.
 *
 * Groups are a global resource that appear in all Regions, but the request to delete a group
 * must be made from its home Region. You can find the home Region of a group within its ARN.
 */
export declare const deleteGroup: API.OperationMethod<DeleteGroupRequest, DeleteGroupResponse, DeleteGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeCanariesError = InternalServerException | ValidationException | CommonErrors;
/**
 * This operation returns a list of the canaries in your account, along with full details
 * about each canary.
 *
 * This operation supports resource-level authorization using an IAM policy and
 * the `Names` parameter. If you specify the `Names` parameter, the operation is successful only if you have authorization to view
 * all the canaries that you specify in your request. If you do not have permission to view any of
 * the canaries, the request fails with a 403 response.
 *
 * You are required to use the `Names` parameter if you are logged on to a user or role that has an
 * IAM policy that restricts which canaries that you are allowed to view. For more information,
 * see
 * Limiting a user to viewing specific canaries.
 */
export declare const describeCanaries: API.PaginatedOperationMethod<DescribeCanariesRequest, DescribeCanariesResponse, DescribeCanariesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeCanariesLastRunError = InternalServerException | ValidationException | CommonErrors;
/**
 * Use this operation to see information from the most recent run of each canary that you have created.
 *
 * This operation supports resource-level authorization using an IAM policy and
 * the `Names` parameter. If you specify the `Names` parameter, the operation is successful only if you have authorization to view
 * all the canaries that you specify in your request. If you do not have permission to view any of
 * the canaries, the request fails with a 403 response.
 *
 * You are required to use the `Names` parameter if you are logged on to a user or role that has an
 * IAM policy that restricts which canaries that you are allowed to view. For more information,
 * see
 * Limiting a user to viewing specific canaries.
 */
export declare const describeCanariesLastRun: API.PaginatedOperationMethod<DescribeCanariesLastRunRequest, DescribeCanariesLastRunResponse, DescribeCanariesLastRunError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeRuntimeVersionsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of Synthetics canary runtime versions. For more information,
 * see
 * Canary Runtime Versions.
 */
export declare const describeRuntimeVersions: API.PaginatedOperationMethod<DescribeRuntimeVersionsRequest, DescribeRuntimeVersionsResponse, DescribeRuntimeVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DisassociateResourceError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a canary from a group. You must run this operation in the Region where the canary exists.
 */
export declare const disassociateResource: API.OperationMethod<DisassociateResourceRequest, DisassociateResourceResponse, DisassociateResourceError, Credentials | HttpClient.HttpClient>;
export type GetCanaryError = InternalServerException | ValidationException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves complete information about one canary. You must specify
 * the name of the canary that you want. To get a list of canaries
 * and their names, use DescribeCanaries.
 */
export declare const getCanary: API.OperationMethod<GetCanaryRequest, GetCanaryResponse, GetCanaryError, Credentials | HttpClient.HttpClient>;
export type GetCanaryRunsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a list of runs for a specified canary.
 */
export declare const getCanaryRuns: API.PaginatedOperationMethod<GetCanaryRunsRequest, GetCanaryRunsResponse, GetCanaryRunsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetGroupError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about one group. Groups are a global resource, so you can use this operation from
 * any Region.
 */
export declare const getGroup: API.OperationMethod<GetGroupRequest, GetGroupResponse, GetGroupError, Credentials | HttpClient.HttpClient>;
export type ListAssociatedGroupsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of the groups that the specified canary is associated with. The canary
 * that you specify must be in the current Region.
 */
export declare const listAssociatedGroups: API.PaginatedOperationMethod<ListAssociatedGroupsRequest, ListAssociatedGroupsResponse, ListAssociatedGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListGroupResourcesError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * This operation returns a list of the ARNs of the canaries that are associated with the specified group.
 */
export declare const listGroupResources: API.PaginatedOperationMethod<ListGroupResourcesRequest, ListGroupResourcesResponse, ListGroupResourcesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListGroupsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of all groups in the account, displaying their names, unique IDs, and ARNs. The groups
 * from all Regions are returned.
 */
export declare const listGroups: API.PaginatedOperationMethod<ListGroupsRequest, ListGroupsResponse, ListGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = BadRequestException | ConflictException | InternalFailureException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Displays the tags associated with a canary or group.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartCanaryError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Use this operation to run a canary that has already been created.
 * The frequency of the canary runs is determined by the value of the canary's `Schedule`. To see a canary's schedule,
 * use GetCanary.
 */
export declare const startCanary: API.OperationMethod<StartCanaryRequest, StartCanaryResponse, StartCanaryError, Credentials | HttpClient.HttpClient>;
export type StartCanaryDryRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Use this operation to start a dry run for a canary that has already been created
 */
export declare const startCanaryDryRun: API.OperationMethod<StartCanaryDryRunRequest, StartCanaryDryRunResponse, StartCanaryDryRunError, Credentials | HttpClient.HttpClient>;
export type StopCanaryError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Stops the canary to prevent all future runs. If the canary is currently running,the
 * run that is in progress completes on its own, publishes metrics, and uploads artifacts, but
 * it is not recorded in Synthetics as a completed run.
 *
 * You can use `StartCanary` to start it running again
 * with the canary's current schedule at any point in the future.
 */
export declare const stopCanary: API.OperationMethod<StopCanaryRequest, StopCanaryResponse, StopCanaryError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ConflictException | InternalFailureException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified canary or group.
 *
 * Tags can help you organize and categorize your
 * resources. You can also use them to scope user permissions, by granting a user permission to access or change only resources with
 * certain tag values.
 *
 * Tags don't have any semantic meaning to Amazon Web Services and are interpreted strictly as strings of characters.
 *
 * You can use the `TagResource` action with a resource that already has tags. If you specify a new
 * tag key for the resource,
 * this tag is appended to the list of tags associated
 * with the resource. If you specify a tag key that is already associated with the resource, the new tag
 * value that you specify replaces
 * the previous value for that tag.
 *
 * You can associate as many as 50 tags with a canary or group.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ConflictException | InternalFailureException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes one or more tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCanaryError = AccessDeniedException | ConflictException | InternalServerException | RequestEntityTooLargeException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the configuration of a canary that has already been created.
 *
 * For multibrowser canaries, you can add or remove browsers by updating the browserConfig list in the update call. For example:
 *
 * - To add Firefox to a canary that currently uses Chrome, specify browserConfigs as [CHROME, FIREFOX]
 *
 * - To remove Firefox and keep only Chrome, specify browserConfigs as [CHROME]
 *
 * You can't use this operation to update the tags of an existing canary. To change the tags of an existing canary, use
 * TagResource.
 *
 * When you use the `dryRunId` field when updating a canary, the only other field you can provide is the `Schedule`. Adding any other field will thrown an exception.
 */
export declare const updateCanary: API.OperationMethod<UpdateCanaryRequest, UpdateCanaryResponse, UpdateCanaryError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=synthetics.d.ts.map