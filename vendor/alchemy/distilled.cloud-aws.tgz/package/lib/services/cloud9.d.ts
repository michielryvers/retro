import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
    readonly className: any;
    readonly code: any;
}>;
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConcurrentAccessException_base: S.TaggedErrorClass<"ConcurrentAccessException", {
    readonly message: any;
    readonly className: any;
    readonly code: any;
}>;
export declare class ConcurrentAccessException extends /*@__PURE__*/ ConcurrentAccessException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly className: any;
    readonly code: any;
}>;
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
    readonly className: any;
    readonly code: any;
}>;
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
    readonly className: any;
    readonly code: any;
}>;
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
    readonly className: any;
    readonly code: any;
}>;
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
    readonly className: any;
    readonly code: any;
}>;
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
    readonly className: any;
    readonly code: any;
}>;
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type EnvironmentName = string;
export type EnvironmentDescription = string | redacted.Redacted<string>;
export type ClientRequestToken = string;
export type InstanceType = string;
export type SubnetId = string;
export type ImageId = string;
export type AutomaticStopTimeMinutes = number;
export type UserArn = string;
export type TagKey = string | redacted.Redacted<string>;
export type TagValue = string | redacted.Redacted<string>;
export interface Tag {
    Key: string | redacted.Redacted<string>;
    Value: string | redacted.Redacted<string>;
}
export type TagList = Tag[];
export type ConnectionType = "CONNECT_SSH" | "CONNECT_SSM" | (string & {});
export interface CreateEnvironmentEC2Request {
    name: string;
    description?: string | redacted.Redacted<string>;
    clientRequestToken?: string;
    instanceType: string;
    subnetId?: string;
    imageId: string;
    automaticStopTimeMinutes?: number;
    ownerArn?: string;
    tags?: Tag[];
    connectionType?: ConnectionType;
    dryRun?: boolean;
}
export type EnvironmentId = string;
export interface CreateEnvironmentEC2Result {
    environmentId?: string;
}
export type MemberPermissions = "read-write" | "read-only" | (string & {});
export interface CreateEnvironmentMembershipRequest {
    environmentId: string;
    userArn: string;
    permissions: MemberPermissions;
}
export type Permissions = "owner" | "read-write" | "read-only" | (string & {});
export interface EnvironmentMember {
    permissions: Permissions;
    userId: string;
    userArn: string;
    environmentId: string;
    lastAccess?: Date;
}
export interface CreateEnvironmentMembershipResult {
    membership: EnvironmentMember;
}
export interface DeleteEnvironmentRequest {
    environmentId: string;
}
export interface DeleteEnvironmentResult {
}
export interface DeleteEnvironmentMembershipRequest {
    environmentId: string;
    userArn: string;
}
export interface DeleteEnvironmentMembershipResult {
}
export type PermissionsList = Permissions[];
export type MaxResults = number;
export interface DescribeEnvironmentMembershipsRequest {
    userArn?: string;
    environmentId?: string;
    permissions?: Permissions[];
    nextToken?: string;
    maxResults?: number;
}
export type EnvironmentMembersList = EnvironmentMember[];
export interface DescribeEnvironmentMembershipsResult {
    memberships?: EnvironmentMember[];
    nextToken?: string;
}
export type BoundedEnvironmentIdList = string[];
export interface DescribeEnvironmentsRequest {
    environmentIds: string[];
}
export type EnvironmentType = "ssh" | "ec2" | (string & {});
export type EnvironmentLifecycleStatus = "CREATING" | "CREATED" | "CREATE_FAILED" | "DELETING" | "DELETE_FAILED" | (string & {});
export interface EnvironmentLifecycle {
    status?: EnvironmentLifecycleStatus;
    reason?: string;
    failureResource?: string;
}
export type ManagedCredentialsStatus = "ENABLED_ON_CREATE" | "ENABLED_BY_OWNER" | "DISABLED_BY_DEFAULT" | "DISABLED_BY_OWNER" | "DISABLED_BY_COLLABORATOR" | "PENDING_REMOVAL_BY_COLLABORATOR" | "PENDING_START_REMOVAL_BY_COLLABORATOR" | "PENDING_REMOVAL_BY_OWNER" | "PENDING_START_REMOVAL_BY_OWNER" | "FAILED_REMOVAL_BY_COLLABORATOR" | "FAILED_REMOVAL_BY_OWNER" | (string & {});
export interface Environment {
    id?: string;
    name?: string;
    description?: string | redacted.Redacted<string>;
    type: EnvironmentType;
    connectionType?: ConnectionType;
    arn: string;
    ownerArn: string;
    lifecycle?: EnvironmentLifecycle;
    managedCredentialsStatus?: ManagedCredentialsStatus;
}
export type EnvironmentList = Environment[];
export interface DescribeEnvironmentsResult {
    environments?: Environment[];
}
export interface DescribeEnvironmentStatusRequest {
    environmentId: string;
}
export type EnvironmentStatus = "error" | "creating" | "connecting" | "ready" | "stopping" | "stopped" | "deleting" | (string & {});
export interface DescribeEnvironmentStatusResult {
    status: EnvironmentStatus;
    message: string;
}
export interface ListEnvironmentsRequest {
    nextToken?: string;
    maxResults?: number;
}
export type EnvironmentIdList = string[];
export interface ListEnvironmentsResult {
    nextToken?: string;
    environmentIds?: string[];
}
export type EnvironmentArn = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = (string | redacted.Redacted<string>)[];
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: (string | redacted.Redacted<string>)[];
}
export interface UntagResourceResponse {
}
export type ManagedCredentialsAction = "ENABLE" | "DISABLE" | (string & {});
export interface UpdateEnvironmentRequest {
    environmentId: string;
    name?: string;
    description?: string | redacted.Redacted<string>;
    managedCredentialsAction?: ManagedCredentialsAction;
}
export interface UpdateEnvironmentResult {
}
export interface UpdateEnvironmentMembershipRequest {
    environmentId: string;
    userArn: string;
    permissions: MemberPermissions;
}
export interface UpdateEnvironmentMembershipResult {
    membership?: EnvironmentMember;
}
export type CreateEnvironmentEC2Error = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an Cloud9 development environment, launches an Amazon Elastic Compute Cloud (Amazon EC2) instance, and
 * then connects from the instance to the environment.
 *
 * Cloud9 is no longer available to new customers. Existing customers of
 * Cloud9 can continue to use the service as normal.
 * Learn more"
 */
export declare const createEnvironmentEC2: API.OperationMethod<CreateEnvironmentEC2Request, CreateEnvironmentEC2Result, CreateEnvironmentEC2Error, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentMembershipError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Adds an environment member to an Cloud9 development environment.
 *
 * Cloud9 is no longer available to new customers. Existing customers of
 * Cloud9 can continue to use the service as normal.
 * Learn more"
 */
export declare const createEnvironmentMembership: API.OperationMethod<CreateEnvironmentMembershipRequest, CreateEnvironmentMembershipResult, CreateEnvironmentMembershipError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an Cloud9 development environment. If an Amazon EC2 instance is connected to the
 * environment, also terminates the instance.
 *
 * Cloud9 is no longer available to new customers. Existing customers of
 * Cloud9 can continue to use the service as normal.
 * Learn more"
 */
export declare const deleteEnvironment: API.OperationMethod<DeleteEnvironmentRequest, DeleteEnvironmentResult, DeleteEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentMembershipError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an environment member from a development environment.
 *
 * Cloud9 is no longer available to new customers. Existing customers of
 * Cloud9 can continue to use the service as normal.
 * Learn more"
 */
export declare const deleteEnvironmentMembership: API.OperationMethod<DeleteEnvironmentMembershipRequest, DeleteEnvironmentMembershipResult, DeleteEnvironmentMembershipError, Credentials | HttpClient.HttpClient>;
export type DescribeEnvironmentMembershipsError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets information about environment members for an Cloud9 development environment.
 *
 * Cloud9 is no longer available to new customers. Existing customers of
 * Cloud9 can continue to use the service as normal.
 * Learn more"
 */
export declare const describeEnvironmentMemberships: API.PaginatedOperationMethod<DescribeEnvironmentMembershipsRequest, DescribeEnvironmentMembershipsResult, DescribeEnvironmentMembershipsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEnvironmentsError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets information about Cloud9 development environments.
 *
 * Cloud9 is no longer available to new customers. Existing customers of
 * Cloud9 can continue to use the service as normal.
 * Learn more"
 */
export declare const describeEnvironments: API.OperationMethod<DescribeEnvironmentsRequest, DescribeEnvironmentsResult, DescribeEnvironmentsError, Credentials | HttpClient.HttpClient>;
export type DescribeEnvironmentStatusError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets status information for an Cloud9 development environment.
 *
 * Cloud9 is no longer available to new customers. Existing customers of
 * Cloud9 can continue to use the service as normal.
 * Learn more"
 */
export declare const describeEnvironmentStatus: API.OperationMethod<DescribeEnvironmentStatusRequest, DescribeEnvironmentStatusResult, DescribeEnvironmentStatusError, Credentials | HttpClient.HttpClient>;
export type ListEnvironmentsError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of Cloud9 development environment identifiers.
 *
 * Cloud9 is no longer available to new customers. Existing customers of
 * Cloud9 can continue to use the service as normal.
 * Learn more"
 *
 * Cloud9 is no longer available to new customers. Existing customers of
 * Cloud9 can continue to use the service as normal.
 * Learn more"
 */
export declare const listEnvironments: API.PaginatedOperationMethod<ListEnvironmentsRequest, ListEnvironmentsResult, ListEnvironmentsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Gets a list of the tags associated with an Cloud9 development environment.
 *
 * Cloud9 is no longer available to new customers. Existing customers of
 * Cloud9 can continue to use the service as normal.
 * Learn more"
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ConcurrentAccessException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Adds tags to an Cloud9 development environment.
 *
 * Cloud9 is no longer available to new customers. Existing customers of
 * Cloud9 can continue to use the service as normal.
 * Learn more"
 *
 * Tags that you add to an Cloud9 environment by using this method will NOT be
 * automatically propagated to underlying resources.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ConcurrentAccessException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Removes tags from an Cloud9 development environment.
 *
 * Cloud9 is no longer available to new customers. Existing customers of
 * Cloud9 can continue to use the service as normal.
 * Learn more"
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Changes the settings of an existing Cloud9 development environment.
 *
 * Cloud9 is no longer available to new customers. Existing customers of
 * Cloud9 can continue to use the service as normal.
 * Learn more"
 */
export declare const updateEnvironment: API.OperationMethod<UpdateEnvironmentRequest, UpdateEnvironmentResult, UpdateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentMembershipError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Changes the settings of an existing environment member for an Cloud9 development
 * environment.
 *
 * Cloud9 is no longer available to new customers. Existing customers of
 * Cloud9 can continue to use the service as normal.
 * Learn more"
 */
export declare const updateEnvironmentMembership: API.OperationMethod<UpdateEnvironmentMembershipRequest, UpdateEnvironmentMembershipResult, UpdateEnvironmentMembershipError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cloud9.d.ts.map