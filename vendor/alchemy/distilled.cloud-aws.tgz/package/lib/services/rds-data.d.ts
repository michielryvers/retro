import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const DatabaseErrorException_base: S.TaggedErrorClass<"DatabaseErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DatabaseErrorException extends /*@__PURE__*/ DatabaseErrorException_base {
}
declare const DatabaseNotFoundException_base: S.TaggedErrorClass<"DatabaseNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DatabaseNotFoundException extends /*@__PURE__*/ DatabaseNotFoundException_base {
}
declare const DatabaseResumingException_base: S.TaggedErrorClass<"DatabaseResumingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DatabaseResumingException extends /*@__PURE__*/ DatabaseResumingException_base {
}
declare const DatabaseUnavailableException_base: S.TaggedErrorClass<"DatabaseUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class DatabaseUnavailableException extends /*@__PURE__*/ DatabaseUnavailableException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const HttpEndpointNotEnabledException_base: S.TaggedErrorClass<"HttpEndpointNotEnabledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class HttpEndpointNotEnabledException extends /*@__PURE__*/ HttpEndpointNotEnabledException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const InvalidResourceStateException_base: S.TaggedErrorClass<"InvalidResourceStateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidResourceStateException extends /*@__PURE__*/ InvalidResourceStateException_base {
}
declare const InvalidSecretException_base: S.TaggedErrorClass<"InvalidSecretException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSecretException extends /*@__PURE__*/ InvalidSecretException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const SecretsErrorException_base: S.TaggedErrorClass<"SecretsErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SecretsErrorException extends /*@__PURE__*/ SecretsErrorException_base {
}
declare const ServiceUnavailableError_base: S.TaggedErrorClass<"ServiceUnavailableError", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableError extends /*@__PURE__*/ ServiceUnavailableError_base {
}
declare const StatementTimeoutException_base: S.TaggedErrorClass<"StatementTimeoutException", {
    readonly message: any;
    readonly dbConnectionId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StatementTimeoutException extends /*@__PURE__*/ StatementTimeoutException_base {
}
declare const TransactionNotFoundException_base: S.TaggedErrorClass<"TransactionNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TransactionNotFoundException extends /*@__PURE__*/ TransactionNotFoundException_base {
}
declare const UnsupportedResultException_base: S.TaggedErrorClass<"UnsupportedResultException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedResultException extends /*@__PURE__*/ UnsupportedResultException_base {
}
export type Arn = string;
export type SqlStatement = string;
export type DbName = string;
export type ParameterName = string;
export type BoxedBoolean = boolean;
export type BoxedLong = number;
export type BoxedDouble = number;
export type BooleanArray = boolean[];
export type LongArray = number[];
export type DoubleArray = number[];
export type StringArray = string[];
export type ArrayOfArray = ArrayValue[];
export type ArrayValue = {
    booleanValues: boolean[];
    longValues?: never;
    doubleValues?: never;
    stringValues?: never;
    arrayValues?: never;
} | {
    booleanValues?: never;
    longValues: number[];
    doubleValues?: never;
    stringValues?: never;
    arrayValues?: never;
} | {
    booleanValues?: never;
    longValues?: never;
    doubleValues: number[];
    stringValues?: never;
    arrayValues?: never;
} | {
    booleanValues?: never;
    longValues?: never;
    doubleValues?: never;
    stringValues: string[];
    arrayValues?: never;
} | {
    booleanValues?: never;
    longValues?: never;
    doubleValues?: never;
    stringValues?: never;
    arrayValues: ArrayValue[];
};
export type Field = {
    isNull: boolean;
    booleanValue?: never;
    longValue?: never;
    doubleValue?: never;
    stringValue?: never;
    blobValue?: never;
    arrayValue?: never;
} | {
    isNull?: never;
    booleanValue: boolean;
    longValue?: never;
    doubleValue?: never;
    stringValue?: never;
    blobValue?: never;
    arrayValue?: never;
} | {
    isNull?: never;
    booleanValue?: never;
    longValue: number;
    doubleValue?: never;
    stringValue?: never;
    blobValue?: never;
    arrayValue?: never;
} | {
    isNull?: never;
    booleanValue?: never;
    longValue?: never;
    doubleValue: number;
    stringValue?: never;
    blobValue?: never;
    arrayValue?: never;
} | {
    isNull?: never;
    booleanValue?: never;
    longValue?: never;
    doubleValue?: never;
    stringValue: string;
    blobValue?: never;
    arrayValue?: never;
} | {
    isNull?: never;
    booleanValue?: never;
    longValue?: never;
    doubleValue?: never;
    stringValue?: never;
    blobValue: Uint8Array;
    arrayValue?: never;
} | {
    isNull?: never;
    booleanValue?: never;
    longValue?: never;
    doubleValue?: never;
    stringValue?: never;
    blobValue?: never;
    arrayValue: ArrayValue;
};
export type TypeHint = "JSON" | "UUID" | "TIMESTAMP" | "DATE" | "TIME" | "DECIMAL" | (string & {});
export interface SqlParameter {
    name?: string;
    value?: Field;
    typeHint?: TypeHint;
}
export type SqlParametersList = SqlParameter[];
export type SqlParameterSets = SqlParameter[][];
export type Id = string;
export interface BatchExecuteStatementRequest {
    resourceArn: string;
    secretArn: string;
    sql: string;
    database?: string;
    schema?: string;
    parameterSets?: SqlParameter[][];
    transactionId?: string;
}
export type FieldList = Field[];
export interface UpdateResult {
    generatedFields?: Field[];
}
export type UpdateResults = UpdateResult[];
export interface BatchExecuteStatementResponse {
    updateResults?: UpdateResult[];
}
export interface BeginTransactionRequest {
    resourceArn: string;
    secretArn: string;
    database?: string;
    schema?: string;
}
export interface BeginTransactionResponse {
    transactionId?: string;
}
export interface CommitTransactionRequest {
    resourceArn: string;
    secretArn: string;
    transactionId: string;
}
export type TransactionStatus = string;
export interface CommitTransactionResponse {
    transactionStatus?: string;
}
export interface ExecuteSqlRequest {
    dbClusterOrInstanceArn: string;
    awsSecretStoreArn: string;
    sqlStatements: string;
    database?: string;
    schema?: string;
}
export interface ColumnMetadata {
    name?: string;
    type?: number;
    typeName?: string;
    label?: string;
    schemaName?: string;
    tableName?: string;
    isAutoIncrement?: boolean;
    isSigned?: boolean;
    isCurrency?: boolean;
    isCaseSensitive?: boolean;
    nullable?: number;
    precision?: number;
    scale?: number;
    arrayBaseColumnType?: number;
}
export type Metadata = ColumnMetadata[];
export interface ResultSetMetadata {
    columnCount?: number;
    columnMetadata?: ColumnMetadata[];
}
export type BoxedInteger = number;
export type BoxedFloat = number;
export type ArrayValueList = Value[];
export interface StructValue {
    attributes?: Value[];
}
export type Value = {
    isNull: boolean;
    bitValue?: never;
    bigIntValue?: never;
    intValue?: never;
    doubleValue?: never;
    realValue?: never;
    stringValue?: never;
    blobValue?: never;
    arrayValues?: never;
    structValue?: never;
} | {
    isNull?: never;
    bitValue: boolean;
    bigIntValue?: never;
    intValue?: never;
    doubleValue?: never;
    realValue?: never;
    stringValue?: never;
    blobValue?: never;
    arrayValues?: never;
    structValue?: never;
} | {
    isNull?: never;
    bitValue?: never;
    bigIntValue: number;
    intValue?: never;
    doubleValue?: never;
    realValue?: never;
    stringValue?: never;
    blobValue?: never;
    arrayValues?: never;
    structValue?: never;
} | {
    isNull?: never;
    bitValue?: never;
    bigIntValue?: never;
    intValue: number;
    doubleValue?: never;
    realValue?: never;
    stringValue?: never;
    blobValue?: never;
    arrayValues?: never;
    structValue?: never;
} | {
    isNull?: never;
    bitValue?: never;
    bigIntValue?: never;
    intValue?: never;
    doubleValue: number;
    realValue?: never;
    stringValue?: never;
    blobValue?: never;
    arrayValues?: never;
    structValue?: never;
} | {
    isNull?: never;
    bitValue?: never;
    bigIntValue?: never;
    intValue?: never;
    doubleValue?: never;
    realValue: number;
    stringValue?: never;
    blobValue?: never;
    arrayValues?: never;
    structValue?: never;
} | {
    isNull?: never;
    bitValue?: never;
    bigIntValue?: never;
    intValue?: never;
    doubleValue?: never;
    realValue?: never;
    stringValue: string;
    blobValue?: never;
    arrayValues?: never;
    structValue?: never;
} | {
    isNull?: never;
    bitValue?: never;
    bigIntValue?: never;
    intValue?: never;
    doubleValue?: never;
    realValue?: never;
    stringValue?: never;
    blobValue: Uint8Array;
    arrayValues?: never;
    structValue?: never;
} | {
    isNull?: never;
    bitValue?: never;
    bigIntValue?: never;
    intValue?: never;
    doubleValue?: never;
    realValue?: never;
    stringValue?: never;
    blobValue?: never;
    arrayValues: Value[];
    structValue?: never;
} | {
    isNull?: never;
    bitValue?: never;
    bigIntValue?: never;
    intValue?: never;
    doubleValue?: never;
    realValue?: never;
    stringValue?: never;
    blobValue?: never;
    arrayValues?: never;
    structValue: StructValue;
};
export type Row = Value[];
export interface Record {
    values?: Value[];
}
export type Records = Record[];
export interface ResultFrame {
    resultSetMetadata?: ResultSetMetadata;
    records?: Record[];
}
export type RecordsUpdated = number;
export interface SqlStatementResult {
    resultFrame?: ResultFrame;
    numberOfRecordsUpdated?: number;
}
export type SqlStatementResults = SqlStatementResult[];
export interface ExecuteSqlResponse {
    sqlStatementResults?: SqlStatementResult[];
}
export type DecimalReturnType = "STRING" | "DOUBLE_OR_LONG" | (string & {});
export type LongReturnType = "STRING" | "LONG" | (string & {});
export interface ResultSetOptions {
    decimalReturnType?: DecimalReturnType;
    longReturnType?: LongReturnType;
}
export type RecordsFormatType = "NONE" | "JSON" | (string & {});
export interface ExecuteStatementRequest {
    resourceArn: string;
    secretArn: string;
    sql: string;
    database?: string;
    schema?: string;
    parameters?: SqlParameter[];
    transactionId?: string;
    includeResultMetadata?: boolean;
    continueAfterTimeout?: boolean;
    resultSetOptions?: ResultSetOptions;
    formatRecordsAs?: RecordsFormatType;
}
export type SqlRecords = Field[][];
export type FormattedSqlRecords = string;
export interface ExecuteStatementResponse {
    records?: Field[][];
    columnMetadata?: ColumnMetadata[];
    numberOfRecordsUpdated?: number;
    generatedFields?: Field[];
    formattedRecords?: string;
}
export interface RollbackTransactionRequest {
    resourceArn: string;
    secretArn: string;
    transactionId: string;
}
export interface RollbackTransactionResponse {
    transactionStatus?: string;
}
export type ErrorMessage = string;
export type BatchExecuteStatementError = AccessDeniedException | BadRequestException | DatabaseErrorException | DatabaseNotFoundException | DatabaseResumingException | DatabaseUnavailableException | ForbiddenException | HttpEndpointNotEnabledException | InternalServerErrorException | InvalidResourceStateException | InvalidSecretException | SecretsErrorException | ServiceUnavailableError | StatementTimeoutException | TransactionNotFoundException | CommonErrors;
/**
 * Runs a batch SQL statement over an array of data.
 *
 * You can run bulk update and insert operations for multiple records using a DML statement with different parameter sets. Bulk operations can provide a significant performance improvement over individual insert and update operations.
 *
 * If a call isn't part of a transaction because it doesn't include the `transactionID` parameter, changes that result from the call are committed automatically.
 *
 * There isn't a fixed upper limit on the number of parameter sets. However, the maximum size of the HTTP request submitted through the Data API is 4 MiB. If the request exceeds this limit, the Data API returns an error and doesn't process the request. This 4-MiB limit includes the size of the HTTP headers and the JSON notation in the request. Thus, the number of parameter sets that you can include depends on a combination of factors, such as the size of the SQL statement and the size of each parameter set.
 *
 * The response size limit is 1 MiB. If the call returns more than 1 MiB of response data, the call is terminated.
 */
export declare const batchExecuteStatement: API.OperationMethod<BatchExecuteStatementRequest, BatchExecuteStatementResponse, BatchExecuteStatementError, Credentials | HttpClient.HttpClient>;
export type BeginTransactionError = AccessDeniedException | BadRequestException | DatabaseErrorException | DatabaseNotFoundException | DatabaseResumingException | DatabaseUnavailableException | ForbiddenException | HttpEndpointNotEnabledException | InternalServerErrorException | InvalidResourceStateException | InvalidSecretException | SecretsErrorException | ServiceUnavailableError | StatementTimeoutException | TransactionNotFoundException | CommonErrors;
/**
 * Starts a SQL transaction.
 *
 * A transaction can run for a maximum of 24 hours. A transaction is terminated and rolled back automatically after 24 hours.
 *
 * A transaction times out if no calls use its transaction ID in three minutes. If a transaction times out before it's committed, it's rolled back automatically.
 *
 * For Aurora MySQL, DDL statements inside a transaction cause an implicit commit. We recommend that you run each MySQL DDL statement in a separate `ExecuteStatement` call with `continueAfterTimeout` enabled.
 */
export declare const beginTransaction: API.OperationMethod<BeginTransactionRequest, BeginTransactionResponse, BeginTransactionError, Credentials | HttpClient.HttpClient>;
export type CommitTransactionError = AccessDeniedException | BadRequestException | DatabaseErrorException | DatabaseNotFoundException | DatabaseUnavailableException | ForbiddenException | HttpEndpointNotEnabledException | InternalServerErrorException | InvalidResourceStateException | InvalidSecretException | NotFoundException | SecretsErrorException | ServiceUnavailableError | StatementTimeoutException | TransactionNotFoundException | CommonErrors;
/**
 * Ends a SQL transaction started with the `BeginTransaction` operation and commits the changes.
 */
export declare const commitTransaction: API.OperationMethod<CommitTransactionRequest, CommitTransactionResponse, CommitTransactionError, Credentials | HttpClient.HttpClient>;
export type ExecuteSqlError = AccessDeniedException | BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableError | CommonErrors;
/**
 * Runs one or more SQL statements.
 *
 * This operation is deprecated. Please use the `BatchExecuteStatement` or `ExecuteStatement` operation.
 */
export declare const executeSql: API.OperationMethod<ExecuteSqlRequest, ExecuteSqlResponse, ExecuteSqlError, Credentials | HttpClient.HttpClient>;
export type ExecuteStatementError = AccessDeniedException | BadRequestException | DatabaseErrorException | DatabaseNotFoundException | DatabaseResumingException | DatabaseUnavailableException | ForbiddenException | HttpEndpointNotEnabledException | InternalServerErrorException | InvalidResourceStateException | InvalidSecretException | SecretsErrorException | ServiceUnavailableError | StatementTimeoutException | TransactionNotFoundException | UnsupportedResultException | CommonErrors;
/**
 * Runs a SQL statement against a database.
 *
 * If a call isn't part of a transaction because it doesn't include the `transactionID` parameter, changes that result from the call are committed automatically.
 *
 * If the binary response data from the database is more than 1 MB, the call is terminated.
 */
export declare const executeStatement: API.OperationMethod<ExecuteStatementRequest, ExecuteStatementResponse, ExecuteStatementError, Credentials | HttpClient.HttpClient>;
export type RollbackTransactionError = AccessDeniedException | BadRequestException | DatabaseErrorException | DatabaseNotFoundException | DatabaseUnavailableException | ForbiddenException | HttpEndpointNotEnabledException | InternalServerErrorException | InvalidResourceStateException | InvalidSecretException | NotFoundException | SecretsErrorException | ServiceUnavailableError | StatementTimeoutException | TransactionNotFoundException | CommonErrors;
/**
 * Performs a rollback of a transaction. Rolling back a transaction cancels its changes.
 */
export declare const rollbackTransaction: API.OperationMethod<RollbackTransactionRequest, RollbackTransactionResponse, RollbackTransactionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=rds-data.d.ts.map