import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type RetentionPeriodValue = number;
export type RetentionPeriodUnit = "DAYS" | (string & {});
export interface RetentionPeriod {
    RetentionPeriodValue: number;
    RetentionPeriodUnit: RetentionPeriodUnit;
}
export type Description = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export type ResourceType = "EBS_SNAPSHOT" | "EC2_IMAGE" | "EBS_VOLUME" | (string & {});
export type ResourceTagKey = string;
export type ResourceTagValue = string;
export interface ResourceTag {
    ResourceTagKey: string;
    ResourceTagValue?: string;
}
export type ResourceTags = ResourceTag[];
export type UnlockDelayValue = number;
export type UnlockDelayUnit = "DAYS" | (string & {});
export interface UnlockDelay {
    UnlockDelayValue: number;
    UnlockDelayUnit: UnlockDelayUnit;
}
export interface LockConfiguration {
    UnlockDelay: UnlockDelay;
}
export type ExcludeResourceTags = ResourceTag[];
export interface CreateRuleRequest {
    RetentionPeriod: RetentionPeriod;
    Description?: string;
    Tags?: Tag[];
    ResourceType: ResourceType;
    ResourceTags?: ResourceTag[];
    LockConfiguration?: LockConfiguration;
    ExcludeResourceTags?: ResourceTag[];
}
export type RuleIdentifier = string;
export type RuleStatus = "pending" | "available" | (string & {});
export type LockState = "locked" | "pending_unlock" | "unlocked" | (string & {});
export type RuleArn = string;
export interface CreateRuleResponse {
    Identifier?: string;
    RetentionPeriod?: RetentionPeriod;
    Description?: string;
    Tags?: Tag[];
    ResourceType?: ResourceType;
    ResourceTags?: ResourceTag[];
    Status?: RuleStatus;
    LockConfiguration?: LockConfiguration;
    LockState?: LockState;
    RuleArn?: string;
    ExcludeResourceTags?: ResourceTag[];
}
export interface DeleteRuleRequest {
    Identifier: string;
}
export interface DeleteRuleResponse {
}
export interface GetRuleRequest {
    Identifier: string;
}
export interface GetRuleResponse {
    Identifier?: string;
    Description?: string;
    ResourceType?: ResourceType;
    RetentionPeriod?: RetentionPeriod;
    ResourceTags?: ResourceTag[];
    Status?: RuleStatus;
    LockConfiguration?: LockConfiguration;
    LockState?: LockState;
    LockEndTime?: Date;
    RuleArn?: string;
    ExcludeResourceTags?: ResourceTag[];
}
export type MaxResults = number;
export type NextToken = string;
export interface ListRulesRequest {
    MaxResults?: number;
    NextToken?: string;
    ResourceType: ResourceType;
    ResourceTags?: ResourceTag[];
    LockState?: LockState;
    ExcludeResourceTags?: ResourceTag[];
}
export interface RuleSummary {
    Identifier?: string;
    Description?: string;
    RetentionPeriod?: RetentionPeriod;
    LockState?: LockState;
    RuleArn?: string;
}
export type RuleSummaryList = RuleSummary[];
export interface ListRulesResponse {
    Rules?: RuleSummary[];
    NextToken?: string;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export interface LockRuleRequest {
    Identifier: string;
    LockConfiguration: LockConfiguration;
}
export interface LockRuleResponse {
    Identifier?: string;
    Description?: string;
    ResourceType?: ResourceType;
    RetentionPeriod?: RetentionPeriod;
    ResourceTags?: ResourceTag[];
    Status?: RuleStatus;
    LockConfiguration?: LockConfiguration;
    LockState?: LockState;
    RuleArn?: string;
    ExcludeResourceTags?: ResourceTag[];
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export interface UnlockRuleRequest {
    Identifier: string;
}
export interface UnlockRuleResponse {
    Identifier?: string;
    Description?: string;
    ResourceType?: ResourceType;
    RetentionPeriod?: RetentionPeriod;
    ResourceTags?: ResourceTag[];
    Status?: RuleStatus;
    LockConfiguration?: LockConfiguration;
    LockState?: LockState;
    LockEndTime?: Date;
    RuleArn?: string;
    ExcludeResourceTags?: ResourceTag[];
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateRuleRequest {
    Identifier: string;
    RetentionPeriod?: RetentionPeriod;
    Description?: string;
    ResourceType?: ResourceType;
    ResourceTags?: ResourceTag[];
    ExcludeResourceTags?: ResourceTag[];
}
export interface UpdateRuleResponse {
    Identifier?: string;
    RetentionPeriod?: RetentionPeriod;
    Description?: string;
    ResourceType?: ResourceType;
    ResourceTags?: ResourceTag[];
    Status?: RuleStatus;
    LockState?: LockState;
    LockEndTime?: Date;
    RuleArn?: string;
    ExcludeResourceTags?: ResourceTag[];
}
export type ErrorMessage = string;
export type ServiceQuotaExceededExceptionReason = "SERVICE_QUOTA_EXCEEDED" | (string & {});
export type ValidationExceptionReason = "INVALID_PAGE_TOKEN" | "INVALID_PARAMETER_VALUE" | (string & {});
export type ConflictExceptionReason = "INVALID_RULE_STATE" | (string & {});
export type ResourceNotFoundExceptionReason = "RULE_NOT_FOUND" | (string & {});
export type CreateRuleError = InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a Recycle Bin retention rule. You can create two types of retention rules:
 *
 * - **Tag-level retention rules** - These retention rules use
 * resource tags to identify the resources to protect. For each retention rule, you specify one or
 * more tag key and value pairs. Resources (of the specified type) that have at least one of these
 * tag key and value pairs are automatically retained in the Recycle Bin upon deletion. Use this
 * type of retention rule to protect specific resources in your account based on their tags.
 *
 * - **Region-level retention rules** - These retention rules,
 * by default, apply to all of the resources (of the specified type) in the Region, even if the
 * resources are not tagged. However, you can specify exclusion tags to exclude resources that have
 * specific tags. Use this type of retention rule to protect all resources of a specific type in a
 * Region.
 *
 * For more information, see
 * Create Recycle Bin retention rules in the *Amazon EBS User Guide*.
 */
export declare const createRule: API.OperationMethod<CreateRuleRequest, CreateRuleResponse, CreateRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteRuleError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a Recycle Bin retention rule. For more information, see
 * Delete Recycle Bin retention rules in the *Amazon Elastic Compute Cloud User Guide*.
 */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest, DeleteRuleResponse, DeleteRuleError, Credentials | HttpClient.HttpClient>;
export type GetRuleError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about a Recycle Bin retention rule.
 */
export declare const getRule: API.OperationMethod<GetRuleRequest, GetRuleResponse, GetRuleError, Credentials | HttpClient.HttpClient>;
export type ListRulesError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists the Recycle Bin retention rules in the Region.
 */
export declare const listRules: API.PaginatedOperationMethod<ListRulesRequest, ListRulesResponse, ListRulesError, Credentials | HttpClient.HttpClient, RuleSummary>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tags assigned to a retention rule.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type LockRuleError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Locks a Region-level retention rule. A locked retention rule can't be modified or
 * deleted.
 *
 * You can't lock tag-level retention rules, or Region-level retention rules that
 * have exclusion tags.
 */
export declare const lockRule: API.OperationMethod<LockRuleRequest, LockRuleResponse, LockRuleError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Assigns tags to the specified retention rule.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UnlockRuleError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Unlocks a retention rule. After a retention rule is unlocked, it can be modified or deleted
 * only after the unlock delay period expires.
 */
export declare const unlockRule: API.OperationMethod<UnlockRuleRequest, UnlockRuleResponse, UnlockRuleError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Unassigns a tag from a retention rule.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateRuleError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Updates an existing Recycle Bin retention rule. You can update a retention rule's description,
 * resource tags, and retention period at any time after creation. You can't update a retention rule's
 * resource type after creation. For more information, see
 * Update Recycle Bin retention rules in the *Amazon Elastic Compute Cloud User Guide*.
 */
export declare const updateRule: API.OperationMethod<UpdateRuleRequest, UpdateRuleResponse, UpdateRuleError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=rbin.d.ts.map