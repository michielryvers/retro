import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type InstanceArn = string;
export type RegionName = string;
export interface AddRegionRequest {
    InstanceArn: string;
    RegionName: string;
}
export type RegionStatus = "ACTIVE" | "ADDING" | "REMOVING" | (string & {});
export interface AddRegionResponse {
    Status?: RegionStatus;
}
export type PermissionSetArn = string;
export type ManagedPolicyName = string;
export type ManagedPolicyPath = string;
export interface CustomerManagedPolicyReference {
    Name: string;
    Path?: string;
}
export interface AttachCustomerManagedPolicyReferenceToPermissionSetRequest {
    InstanceArn: string;
    PermissionSetArn: string;
    CustomerManagedPolicyReference: CustomerManagedPolicyReference;
}
export interface AttachCustomerManagedPolicyReferenceToPermissionSetResponse {
}
export type ManagedPolicyArn = string;
export interface AttachManagedPolicyToPermissionSetRequest {
    InstanceArn: string;
    PermissionSetArn: string;
    ManagedPolicyArn: string;
}
export interface AttachManagedPolicyToPermissionSetResponse {
}
export type TargetId = string;
export type TargetType = "AWS_ACCOUNT" | (string & {});
export type PrincipalType = "USER" | "GROUP" | (string & {});
export type PrincipalId = string;
export interface CreateAccountAssignmentRequest {
    InstanceArn: string;
    TargetId: string;
    TargetType: TargetType;
    PermissionSetArn: string;
    PrincipalType: PrincipalType;
    PrincipalId: string;
}
export type StatusValues = "IN_PROGRESS" | "FAILED" | "SUCCEEDED" | (string & {});
export type UUId = string;
export type Reason = string;
export interface AccountAssignmentOperationStatus {
    Status?: StatusValues;
    RequestId?: string;
    FailureReason?: string;
    TargetId?: string;
    TargetType?: TargetType;
    PermissionSetArn?: string;
    PrincipalType?: PrincipalType;
    PrincipalId?: string;
    CreatedDate?: Date;
}
export interface CreateAccountAssignmentResponse {
    AccountAssignmentCreationStatus?: AccountAssignmentOperationStatus;
}
export type ApplicationProviderArn = string;
export type ApplicationNameType = string;
export type Description = string;
export type SignInOrigin = "IDENTITY_CENTER" | "APPLICATION" | (string & {});
export type ApplicationUrl = string;
export interface SignInOptions {
    Origin: SignInOrigin;
    ApplicationUrl?: string;
}
export type ApplicationVisibility = "ENABLED" | "DISABLED" | (string & {});
export interface PortalOptions {
    SignInOptions?: SignInOptions;
    Visibility?: ApplicationVisibility;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export type ApplicationStatus = "ENABLED" | "DISABLED" | (string & {});
export type ClientToken = string;
export interface CreateApplicationRequest {
    InstanceArn: string;
    ApplicationProviderArn: string;
    Name: string;
    Description?: string;
    PortalOptions?: PortalOptions;
    Tags?: Tag[];
    Status?: ApplicationStatus;
    ClientToken?: string;
}
export type ApplicationArn = string;
export type IdentityStoreArn = string;
export interface CreateApplicationResponse {
    ApplicationArn?: string;
    InstanceArn?: string;
    IdentityStoreArn?: string;
}
export interface CreateApplicationAssignmentRequest {
    ApplicationArn: string;
    PrincipalId: string;
    PrincipalType: PrincipalType;
}
export interface CreateApplicationAssignmentResponse {
}
export type NameType = string;
export interface CreateInstanceRequest {
    Name?: string;
    ClientToken?: string;
    Tags?: Tag[];
}
export interface CreateInstanceResponse {
    InstanceArn?: string;
}
export type AccessControlAttributeKey = string;
export type AccessControlAttributeValueSource = string;
export type AccessControlAttributeValueSourceList = string[];
export interface AccessControlAttributeValue {
    Source: string[];
}
export interface AccessControlAttribute {
    Key: string;
    Value: AccessControlAttributeValue;
}
export type AccessControlAttributeList = AccessControlAttribute[];
export interface InstanceAccessControlAttributeConfiguration {
    AccessControlAttributes: AccessControlAttribute[];
}
export interface CreateInstanceAccessControlAttributeConfigurationRequest {
    InstanceArn: string;
    InstanceAccessControlAttributeConfiguration: InstanceAccessControlAttributeConfiguration;
}
export interface CreateInstanceAccessControlAttributeConfigurationResponse {
}
export type PermissionSetName = string;
export type PermissionSetDescription = string;
export type Duration = string;
export type RelayState = string;
export interface CreatePermissionSetRequest {
    Name: string;
    Description?: string;
    InstanceArn: string;
    SessionDuration?: string;
    RelayState?: string;
    Tags?: Tag[];
}
export interface PermissionSet {
    Name?: string;
    PermissionSetArn?: string;
    Description?: string;
    CreatedDate?: Date;
    SessionDuration?: string;
    RelayState?: string;
}
export interface CreatePermissionSetResponse {
    PermissionSet?: PermissionSet;
}
export type TrustedTokenIssuerName = string;
export type TrustedTokenIssuerType = "OIDC_JWT" | (string & {});
export type TrustedTokenIssuerUrl = string;
export type ClaimAttributePath = string;
export type JMESPath = string;
export type JwksRetrievalOption = "OPEN_ID_DISCOVERY" | (string & {});
export interface OidcJwtConfiguration {
    IssuerUrl: string;
    ClaimAttributePath: string;
    IdentityStoreAttributePath: string;
    JwksRetrievalOption: JwksRetrievalOption;
}
export type TrustedTokenIssuerConfiguration = {
    OidcJwtConfiguration: OidcJwtConfiguration;
};
export interface CreateTrustedTokenIssuerRequest {
    InstanceArn: string;
    Name: string;
    TrustedTokenIssuerType: TrustedTokenIssuerType;
    TrustedTokenIssuerConfiguration: TrustedTokenIssuerConfiguration;
    ClientToken?: string;
    Tags?: Tag[];
}
export type TrustedTokenIssuerArn = string;
export interface CreateTrustedTokenIssuerResponse {
    TrustedTokenIssuerArn?: string;
}
export interface DeleteAccountAssignmentRequest {
    InstanceArn: string;
    TargetId: string;
    TargetType: TargetType;
    PermissionSetArn: string;
    PrincipalType: PrincipalType;
    PrincipalId: string;
}
export interface DeleteAccountAssignmentResponse {
    AccountAssignmentDeletionStatus?: AccountAssignmentOperationStatus;
}
export interface DeleteApplicationRequest {
    ApplicationArn: string;
}
export interface DeleteApplicationResponse {
}
export type Scope = string;
export interface DeleteApplicationAccessScopeRequest {
    ApplicationArn: string;
    Scope: string;
}
export interface DeleteApplicationAccessScopeResponse {
}
export interface DeleteApplicationAssignmentRequest {
    ApplicationArn: string;
    PrincipalId: string;
    PrincipalType: PrincipalType;
}
export interface DeleteApplicationAssignmentResponse {
}
export type AuthenticationMethodType = "IAM" | (string & {});
export interface DeleteApplicationAuthenticationMethodRequest {
    ApplicationArn: string;
    AuthenticationMethodType: AuthenticationMethodType;
}
export interface DeleteApplicationAuthenticationMethodResponse {
}
export type GrantType = "authorization_code" | "refresh_token" | "urn:ietf:params:oauth:grant-type:jwt-bearer" | "urn:ietf:params:oauth:grant-type:token-exchange" | (string & {});
export interface DeleteApplicationGrantRequest {
    ApplicationArn: string;
    GrantType: GrantType;
}
export interface DeleteApplicationGrantResponse {
}
export interface DeleteInlinePolicyFromPermissionSetRequest {
    InstanceArn: string;
    PermissionSetArn: string;
}
export interface DeleteInlinePolicyFromPermissionSetResponse {
}
export interface DeleteInstanceRequest {
    InstanceArn: string;
}
export interface DeleteInstanceResponse {
}
export interface DeleteInstanceAccessControlAttributeConfigurationRequest {
    InstanceArn: string;
}
export interface DeleteInstanceAccessControlAttributeConfigurationResponse {
}
export interface DeletePermissionsBoundaryFromPermissionSetRequest {
    InstanceArn: string;
    PermissionSetArn: string;
}
export interface DeletePermissionsBoundaryFromPermissionSetResponse {
}
export interface DeletePermissionSetRequest {
    InstanceArn: string;
    PermissionSetArn: string;
}
export interface DeletePermissionSetResponse {
}
export interface DeleteTrustedTokenIssuerRequest {
    TrustedTokenIssuerArn: string;
}
export interface DeleteTrustedTokenIssuerResponse {
}
export interface DescribeAccountAssignmentCreationStatusRequest {
    InstanceArn: string;
    AccountAssignmentCreationRequestId: string;
}
export interface DescribeAccountAssignmentCreationStatusResponse {
    AccountAssignmentCreationStatus?: AccountAssignmentOperationStatus;
}
export interface DescribeAccountAssignmentDeletionStatusRequest {
    InstanceArn: string;
    AccountAssignmentDeletionRequestId: string;
}
export interface DescribeAccountAssignmentDeletionStatusResponse {
    AccountAssignmentDeletionStatus?: AccountAssignmentOperationStatus;
}
export interface DescribeApplicationRequest {
    ApplicationArn: string;
}
export type AccountId = string;
export interface DescribeApplicationResponse {
    ApplicationArn?: string;
    ApplicationProviderArn?: string;
    Name?: string;
    ApplicationAccount?: string;
    InstanceArn?: string;
    IdentityStoreArn?: string;
    Status?: ApplicationStatus;
    PortalOptions?: PortalOptions;
    Description?: string;
    CreatedDate?: Date;
    CreatedFrom?: string;
}
export interface DescribeApplicationAssignmentRequest {
    ApplicationArn: string;
    PrincipalId: string;
    PrincipalType: PrincipalType;
}
export interface DescribeApplicationAssignmentResponse {
    PrincipalType?: PrincipalType;
    PrincipalId?: string;
    ApplicationArn?: string;
}
export interface DescribeApplicationProviderRequest {
    ApplicationProviderArn: string;
}
export type FederationProtocol = "SAML" | "OAUTH" | (string & {});
export type Name = string;
export type IconUrl = string;
export interface DisplayData {
    DisplayName?: string;
    IconUrl?: string;
    Description?: string;
}
export type ResourceServerScope = string;
export interface ResourceServerScopeDetails {
    LongDescription?: string;
    DetailedTitle?: string;
}
export type ResourceServerScopes = {
    [key: string]: ResourceServerScopeDetails | undefined;
};
export interface ResourceServerConfig {
    Scopes?: {
        [key: string]: ResourceServerScopeDetails | undefined;
    };
}
export interface DescribeApplicationProviderResponse {
    ApplicationProviderArn: string;
    FederationProtocol?: FederationProtocol;
    DisplayData?: DisplayData;
    ResourceServerConfig?: ResourceServerConfig;
}
export interface DescribeInstanceRequest {
    InstanceArn: string;
}
export type Id = string;
export type InstanceIdentityStoreArn = string;
export type InstanceStatus = "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "DELETE_IN_PROGRESS" | "ACTIVE" | (string & {});
export type IsPrimaryRegion = boolean;
export interface RegionMetadata {
    RegionName?: string;
    Status?: RegionStatus;
    AddedDate?: Date;
    IsPrimaryRegion?: boolean;
}
export type RegionMetadataList = RegionMetadata[];
export type KmsKeyType = "AWS_OWNED_KMS_KEY" | "CUSTOMER_MANAGED_KEY" | (string & {});
export type KmsKeyArn = string;
export type KmsKeyStatus = "UPDATING" | "ENABLED" | "UPDATE_FAILED" | (string & {});
export interface EncryptionConfigurationDetails {
    KeyType?: KmsKeyType;
    KmsKeyArn?: string;
    EncryptionStatus?: KmsKeyStatus;
    EncryptionStatusReason?: string;
}
export interface DescribeInstanceResponse {
    InstanceArn?: string;
    IdentityStoreId?: string;
    IdentityStoreArn?: string;
    OwnerAccountId?: string;
    Name?: string;
    CreatedDate?: Date;
    Status?: InstanceStatus;
    StatusReason?: string;
    PrimaryRegion?: string;
    Regions?: RegionMetadata[];
    EncryptionConfigurationDetails?: EncryptionConfigurationDetails;
    PermissionSetsEnabled?: boolean;
}
export interface DescribeInstanceAccessControlAttributeConfigurationRequest {
    InstanceArn: string;
}
export type InstanceAccessControlAttributeConfigurationStatus = "ENABLED" | "CREATION_IN_PROGRESS" | "CREATION_FAILED" | (string & {});
export type InstanceAccessControlAttributeConfigurationStatusReason = string;
export interface DescribeInstanceAccessControlAttributeConfigurationResponse {
    Status?: InstanceAccessControlAttributeConfigurationStatus;
    StatusReason?: string;
    InstanceAccessControlAttributeConfiguration?: InstanceAccessControlAttributeConfiguration;
}
export interface DescribePermissionSetRequest {
    InstanceArn: string;
    PermissionSetArn: string;
}
export interface DescribePermissionSetResponse {
    PermissionSet?: PermissionSet;
}
export interface DescribePermissionSetProvisioningStatusRequest {
    InstanceArn: string;
    ProvisionPermissionSetRequestId: string;
}
export interface PermissionSetProvisioningStatus {
    Status?: StatusValues;
    RequestId?: string;
    AccountId?: string;
    PermissionSetArn?: string;
    FailureReason?: string;
    CreatedDate?: Date;
}
export interface DescribePermissionSetProvisioningStatusResponse {
    PermissionSetProvisioningStatus?: PermissionSetProvisioningStatus;
}
export interface DescribeRegionRequest {
    InstanceArn: string;
    RegionName: string;
}
export interface DescribeRegionResponse {
    RegionName?: string;
    Status?: RegionStatus;
    AddedDate?: Date;
    IsPrimaryRegion?: boolean;
}
export interface DescribeTrustedTokenIssuerRequest {
    TrustedTokenIssuerArn: string;
}
export interface DescribeTrustedTokenIssuerResponse {
    TrustedTokenIssuerArn?: string;
    Name?: string;
    TrustedTokenIssuerType?: TrustedTokenIssuerType;
    TrustedTokenIssuerConfiguration?: TrustedTokenIssuerConfiguration;
}
export interface DetachCustomerManagedPolicyReferenceFromPermissionSetRequest {
    InstanceArn: string;
    PermissionSetArn: string;
    CustomerManagedPolicyReference: CustomerManagedPolicyReference;
}
export interface DetachCustomerManagedPolicyReferenceFromPermissionSetResponse {
}
export interface DetachManagedPolicyFromPermissionSetRequest {
    InstanceArn: string;
    PermissionSetArn: string;
    ManagedPolicyArn: string;
}
export interface DetachManagedPolicyFromPermissionSetResponse {
}
export interface GetApplicationAccessScopeRequest {
    ApplicationArn: string;
    Scope: string;
}
export type ScopeTarget = string;
export type ScopeTargets = string[];
export interface GetApplicationAccessScopeResponse {
    Scope: string;
    AuthorizedTargets?: string[];
}
export interface GetApplicationAssignmentConfigurationRequest {
    ApplicationArn: string;
}
export type AssignmentRequired = boolean;
export interface GetApplicationAssignmentConfigurationResponse {
    AssignmentRequired: boolean;
}
export interface GetApplicationAuthenticationMethodRequest {
    ApplicationArn: string;
    AuthenticationMethodType: AuthenticationMethodType;
}
export type ActorPolicyDocument = unknown;
export interface IamAuthenticationMethod {
    ActorPolicy: any;
}
export type AuthenticationMethod = {
    Iam: IamAuthenticationMethod;
};
export interface GetApplicationAuthenticationMethodResponse {
    AuthenticationMethod?: AuthenticationMethod;
}
export interface GetApplicationGrantRequest {
    ApplicationArn: string;
    GrantType: GrantType;
}
export type URI = string;
export type RedirectUris = string[];
export interface AuthorizationCodeGrant {
    RedirectUris?: string[];
}
export type TokenIssuerAudience = string;
export type TokenIssuerAudiences = string[];
export interface AuthorizedTokenIssuer {
    TrustedTokenIssuerArn?: string;
    AuthorizedAudiences?: string[];
}
export type AuthorizedTokenIssuers = AuthorizedTokenIssuer[];
export interface JwtBearerGrant {
    AuthorizedTokenIssuers?: AuthorizedTokenIssuer[];
}
export interface RefreshTokenGrant {
}
export interface TokenExchangeGrant {
}
export type Grant = {
    AuthorizationCode: AuthorizationCodeGrant;
    JwtBearer?: never;
    RefreshToken?: never;
    TokenExchange?: never;
} | {
    AuthorizationCode?: never;
    JwtBearer: JwtBearerGrant;
    RefreshToken?: never;
    TokenExchange?: never;
} | {
    AuthorizationCode?: never;
    JwtBearer?: never;
    RefreshToken: RefreshTokenGrant;
    TokenExchange?: never;
} | {
    AuthorizationCode?: never;
    JwtBearer?: never;
    RefreshToken?: never;
    TokenExchange: TokenExchangeGrant;
};
export interface GetApplicationGrantResponse {
    Grant: Grant;
}
export interface GetApplicationSessionConfigurationRequest {
    ApplicationArn: string;
}
export type UserBackgroundSessionApplicationStatus = "ENABLED" | "DISABLED" | (string & {});
export interface GetApplicationSessionConfigurationResponse {
    UserBackgroundSessionApplicationStatus?: UserBackgroundSessionApplicationStatus;
}
export interface GetInlinePolicyForPermissionSetRequest {
    InstanceArn: string;
    PermissionSetArn: string;
}
export type PermissionSetPolicyDocument = string;
export interface GetInlinePolicyForPermissionSetResponse {
    InlinePolicy?: string;
}
export interface GetPermissionsBoundaryForPermissionSetRequest {
    InstanceArn: string;
    PermissionSetArn: string;
}
export interface PermissionsBoundary {
    CustomerManagedPolicyReference?: CustomerManagedPolicyReference;
    ManagedPolicyArn?: string;
}
export interface GetPermissionsBoundaryForPermissionSetResponse {
    PermissionsBoundary?: PermissionsBoundary;
}
export type MaxResults = number;
export type Token = string;
export interface OperationStatusFilter {
    Status?: StatusValues;
}
export interface ListAccountAssignmentCreationStatusRequest {
    InstanceArn: string;
    MaxResults?: number;
    NextToken?: string;
    Filter?: OperationStatusFilter;
}
export interface AccountAssignmentOperationStatusMetadata {
    Status?: StatusValues;
    RequestId?: string;
    CreatedDate?: Date;
}
export type AccountAssignmentOperationStatusList = AccountAssignmentOperationStatusMetadata[];
export interface ListAccountAssignmentCreationStatusResponse {
    AccountAssignmentsCreationStatus?: AccountAssignmentOperationStatusMetadata[];
    NextToken?: string;
}
export interface ListAccountAssignmentDeletionStatusRequest {
    InstanceArn: string;
    MaxResults?: number;
    NextToken?: string;
    Filter?: OperationStatusFilter;
}
export interface ListAccountAssignmentDeletionStatusResponse {
    AccountAssignmentsDeletionStatus?: AccountAssignmentOperationStatusMetadata[];
    NextToken?: string;
}
export interface ListAccountAssignmentsRequest {
    InstanceArn: string;
    AccountId: string;
    PermissionSetArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface AccountAssignment {
    AccountId?: string;
    PermissionSetArn?: string;
    PrincipalType?: PrincipalType;
    PrincipalId?: string;
}
export type AccountAssignmentList = AccountAssignment[];
export interface ListAccountAssignmentsResponse {
    AccountAssignments?: AccountAssignment[];
    NextToken?: string;
}
export interface ListAccountAssignmentsFilter {
    AccountId?: string;
}
export interface ListAccountAssignmentsForPrincipalRequest {
    InstanceArn: string;
    PrincipalId: string;
    PrincipalType: PrincipalType;
    Filter?: ListAccountAssignmentsFilter;
    NextToken?: string;
    MaxResults?: number;
}
export interface AccountAssignmentForPrincipal {
    AccountId?: string;
    PermissionSetArn?: string;
    PrincipalId?: string;
    PrincipalType?: PrincipalType;
}
export type AccountAssignmentListForPrincipal = AccountAssignmentForPrincipal[];
export interface ListAccountAssignmentsForPrincipalResponse {
    AccountAssignments?: AccountAssignmentForPrincipal[];
    NextToken?: string;
}
export type ProvisioningStatus = "LATEST_PERMISSION_SET_PROVISIONED" | "LATEST_PERMISSION_SET_NOT_PROVISIONED" | (string & {});
export interface ListAccountsForProvisionedPermissionSetRequest {
    InstanceArn: string;
    PermissionSetArn: string;
    ProvisioningStatus?: ProvisioningStatus;
    MaxResults?: number;
    NextToken?: string;
}
export type AccountList = string[];
export interface ListAccountsForProvisionedPermissionSetResponse {
    AccountIds?: string[];
    NextToken?: string;
}
export interface ListApplicationAccessScopesRequest {
    ApplicationArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface ScopeDetails {
    Scope: string;
    AuthorizedTargets?: string[];
}
export type Scopes = ScopeDetails[];
export interface ListApplicationAccessScopesResponse {
    Scopes: ScopeDetails[];
    NextToken?: string;
}
export interface ListApplicationAssignmentsRequest {
    ApplicationArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface ApplicationAssignment {
    ApplicationArn: string;
    PrincipalId: string;
    PrincipalType: PrincipalType;
}
export type ApplicationAssignmentsList = ApplicationAssignment[];
export interface ListApplicationAssignmentsResponse {
    ApplicationAssignments?: ApplicationAssignment[];
    NextToken?: string;
}
export interface ListApplicationAssignmentsFilter {
    ApplicationArn?: string;
}
export interface ListApplicationAssignmentsForPrincipalRequest {
    InstanceArn: string;
    PrincipalId: string;
    PrincipalType: PrincipalType;
    Filter?: ListApplicationAssignmentsFilter;
    NextToken?: string;
    MaxResults?: number;
}
export interface ApplicationAssignmentForPrincipal {
    ApplicationArn?: string;
    PrincipalId?: string;
    PrincipalType?: PrincipalType;
}
export type ApplicationAssignmentListForPrincipal = ApplicationAssignmentForPrincipal[];
export interface ListApplicationAssignmentsForPrincipalResponse {
    ApplicationAssignments?: ApplicationAssignmentForPrincipal[];
    NextToken?: string;
}
export interface ListApplicationAuthenticationMethodsRequest {
    ApplicationArn: string;
    NextToken?: string;
}
export interface AuthenticationMethodItem {
    AuthenticationMethodType?: AuthenticationMethodType;
    AuthenticationMethod?: AuthenticationMethod;
}
export type AuthenticationMethods = AuthenticationMethodItem[];
export interface ListApplicationAuthenticationMethodsResponse {
    AuthenticationMethods?: AuthenticationMethodItem[];
    NextToken?: string;
}
export interface ListApplicationGrantsRequest {
    ApplicationArn: string;
    NextToken?: string;
}
export interface GrantItem {
    GrantType: GrantType;
    Grant: Grant;
}
export type Grants = GrantItem[];
export interface ListApplicationGrantsResponse {
    Grants: GrantItem[];
    NextToken?: string;
}
export interface ListApplicationProvidersRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface ApplicationProvider {
    ApplicationProviderArn: string;
    FederationProtocol?: FederationProtocol;
    DisplayData?: DisplayData;
    ResourceServerConfig?: ResourceServerConfig;
}
export type ApplicationProviderList = ApplicationProvider[];
export interface ListApplicationProvidersResponse {
    ApplicationProviders?: ApplicationProvider[];
    NextToken?: string;
}
export interface ListApplicationsFilter {
    ApplicationAccount?: string;
    ApplicationProvider?: string;
}
export interface ListApplicationsRequest {
    InstanceArn: string;
    MaxResults?: number;
    NextToken?: string;
    Filter?: ListApplicationsFilter;
}
export interface Application {
    ApplicationArn?: string;
    ApplicationProviderArn?: string;
    Name?: string;
    ApplicationAccount?: string;
    InstanceArn?: string;
    IdentityStoreArn?: string;
    Status?: ApplicationStatus;
    PortalOptions?: PortalOptions;
    Description?: string;
    CreatedDate?: Date;
    CreatedFrom?: string;
}
export type ApplicationList = Application[];
export interface ListApplicationsResponse {
    Applications?: Application[];
    NextToken?: string;
}
export interface ListCustomerManagedPolicyReferencesInPermissionSetRequest {
    InstanceArn: string;
    PermissionSetArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export type CustomerManagedPolicyReferenceList = CustomerManagedPolicyReference[];
export interface ListCustomerManagedPolicyReferencesInPermissionSetResponse {
    CustomerManagedPolicyReferences?: CustomerManagedPolicyReference[];
    NextToken?: string;
}
export interface ListInstancesRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface InstanceMetadata {
    InstanceArn?: string;
    IdentityStoreId?: string;
    IdentityStoreArn?: string;
    OwnerAccountId?: string;
    Name?: string;
    CreatedDate?: Date;
    Status?: InstanceStatus;
    StatusReason?: string;
    PrimaryRegion?: string;
    Regions?: RegionMetadata[];
}
export type InstanceList = InstanceMetadata[];
export interface ListInstancesResponse {
    Instances?: InstanceMetadata[];
    NextToken?: string;
}
export interface ListManagedPoliciesInPermissionSetRequest {
    InstanceArn: string;
    PermissionSetArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface AttachedManagedPolicy {
    Name?: string;
    Arn?: string;
}
export type AttachedManagedPolicyList = AttachedManagedPolicy[];
export interface ListManagedPoliciesInPermissionSetResponse {
    AttachedManagedPolicies?: AttachedManagedPolicy[];
    NextToken?: string;
}
export interface ListPermissionSetProvisioningStatusRequest {
    InstanceArn: string;
    MaxResults?: number;
    NextToken?: string;
    Filter?: OperationStatusFilter;
}
export interface PermissionSetProvisioningStatusMetadata {
    Status?: StatusValues;
    RequestId?: string;
    CreatedDate?: Date;
}
export type PermissionSetProvisioningStatusList = PermissionSetProvisioningStatusMetadata[];
export interface ListPermissionSetProvisioningStatusResponse {
    PermissionSetsProvisioningStatus?: PermissionSetProvisioningStatusMetadata[];
    NextToken?: string;
}
export interface ListPermissionSetsRequest {
    InstanceArn: string;
    NextToken?: string;
    MaxResults?: number;
}
export type PermissionSetList = string[];
export interface ListPermissionSetsResponse {
    PermissionSets?: string[];
    NextToken?: string;
}
export interface ListPermissionSetsProvisionedToAccountRequest {
    InstanceArn: string;
    AccountId: string;
    ProvisioningStatus?: ProvisioningStatus;
    MaxResults?: number;
    NextToken?: string;
}
export interface ListPermissionSetsProvisionedToAccountResponse {
    NextToken?: string;
    PermissionSets?: string[];
}
export interface ListRegionsRequest {
    InstanceArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface ListRegionsResponse {
    Regions?: RegionMetadata[];
    NextToken?: string;
}
export type TaggableResourceArn = string;
export interface ListTagsForResourceRequest {
    InstanceArn?: string;
    ResourceArn: string;
    NextToken?: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
    NextToken?: string;
}
export interface ListTrustedTokenIssuersRequest {
    InstanceArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface TrustedTokenIssuerMetadata {
    TrustedTokenIssuerArn?: string;
    Name?: string;
    TrustedTokenIssuerType?: TrustedTokenIssuerType;
}
export type TrustedTokenIssuerList = TrustedTokenIssuerMetadata[];
export interface ListTrustedTokenIssuersResponse {
    TrustedTokenIssuers?: TrustedTokenIssuerMetadata[];
    NextToken?: string;
}
export type ProvisionTargetType = "AWS_ACCOUNT" | "ALL_PROVISIONED_ACCOUNTS" | (string & {});
export interface ProvisionPermissionSetRequest {
    InstanceArn: string;
    PermissionSetArn: string;
    TargetId?: string;
    TargetType: ProvisionTargetType;
}
export interface ProvisionPermissionSetResponse {
    PermissionSetProvisioningStatus?: PermissionSetProvisioningStatus;
}
export interface PutApplicationAccessScopeRequest {
    Scope: string;
    AuthorizedTargets?: string[];
    ApplicationArn: string;
}
export interface PutApplicationAccessScopeResponse {
}
export interface PutApplicationAssignmentConfigurationRequest {
    ApplicationArn: string;
    AssignmentRequired: boolean;
}
export interface PutApplicationAssignmentConfigurationResponse {
}
export interface PutApplicationAuthenticationMethodRequest {
    ApplicationArn: string;
    AuthenticationMethodType: AuthenticationMethodType;
    AuthenticationMethod: AuthenticationMethod;
}
export interface PutApplicationAuthenticationMethodResponse {
}
export interface PutApplicationGrantRequest {
    ApplicationArn: string;
    GrantType: GrantType;
    Grant: Grant;
}
export interface PutApplicationGrantResponse {
}
export interface PutApplicationSessionConfigurationRequest {
    ApplicationArn: string;
    UserBackgroundSessionApplicationStatus?: UserBackgroundSessionApplicationStatus;
}
export interface PutApplicationSessionConfigurationResponse {
}
export interface PutInlinePolicyToPermissionSetRequest {
    InstanceArn: string;
    PermissionSetArn: string;
    InlinePolicy: string;
}
export interface PutInlinePolicyToPermissionSetResponse {
}
export interface PutPermissionsBoundaryToPermissionSetRequest {
    InstanceArn: string;
    PermissionSetArn: string;
    PermissionsBoundary: PermissionsBoundary;
}
export interface PutPermissionsBoundaryToPermissionSetResponse {
}
export interface RemoveRegionRequest {
    InstanceArn: string;
    RegionName: string;
}
export interface RemoveRegionResponse {
    Status?: RegionStatus;
}
export interface TagResourceRequest {
    InstanceArn?: string;
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    InstanceArn?: string;
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateApplicationPortalOptions {
    SignInOptions?: SignInOptions;
}
export interface UpdateApplicationRequest {
    ApplicationArn: string;
    Name?: string;
    Description?: string;
    Status?: ApplicationStatus;
    PortalOptions?: UpdateApplicationPortalOptions;
}
export interface UpdateApplicationResponse {
}
export interface EncryptionConfiguration {
    KeyType: KmsKeyType;
    KmsKeyArn?: string;
}
export interface UpdateInstanceRequest {
    Name?: string;
    InstanceArn: string;
    EncryptionConfiguration?: EncryptionConfiguration;
    PermissionSetsEnabled?: boolean;
}
export interface UpdateInstanceResponse {
}
export interface UpdateInstanceAccessControlAttributeConfigurationRequest {
    InstanceArn: string;
    InstanceAccessControlAttributeConfiguration: InstanceAccessControlAttributeConfiguration;
}
export interface UpdateInstanceAccessControlAttributeConfigurationResponse {
}
export interface UpdatePermissionSetRequest {
    InstanceArn: string;
    PermissionSetArn: string;
    Description?: string;
    SessionDuration?: string;
    RelayState?: string;
}
export interface UpdatePermissionSetResponse {
}
export interface OidcJwtUpdateConfiguration {
    ClaimAttributePath?: string;
    IdentityStoreAttributePath?: string;
    JwksRetrievalOption?: JwksRetrievalOption;
}
export type TrustedTokenIssuerUpdateConfiguration = {
    OidcJwtConfiguration: OidcJwtUpdateConfiguration;
};
export interface UpdateTrustedTokenIssuerRequest {
    TrustedTokenIssuerArn: string;
    Name?: string;
    TrustedTokenIssuerConfiguration?: TrustedTokenIssuerUpdateConfiguration;
}
export interface UpdateTrustedTokenIssuerResponse {
}
export type AccessDeniedExceptionMessage = string;
export type AccessDeniedExceptionReason = "KMS_AccessDeniedException" | (string & {});
export type ConflictExceptionMessage = string;
export type InternalFailureMessage = string;
export type ServiceQuotaExceededMessage = string;
export type ThrottlingExceptionMessage = string;
export type ThrottlingExceptionReason = "KMS_ThrottlingException" | (string & {});
export type ValidationExceptionMessage = string;
export type ValidationExceptionReason = "KMS_InvalidKeyUsageException" | "KMS_InvalidStateException" | "KMS_DisabledException" | (string & {});
export type ResourceNotFoundMessage = string;
export type ResourceNotFoundExceptionReason = "KMS_NotFoundException" | (string & {});
export type AddRegionError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a Region to an IAM Identity Center instance. This operation initiates an asynchronous workflow to replicate the IAM Identity Center instance to the target Region. The Region status is set to ADDING at first and changes to ACTIVE when the workflow completes.
 *
 * To use this operation, your IAM Identity Center instance and the target Region must meet the requirements described in the IAM Identity Center User Guide.
 *
 * The following actions are related to `AddRegion`:
 *
 * - RemoveRegion
 *
 * - DescribeRegion
 *
 * - ListRegions
 */
export declare const addRegion: API.OperationMethod<AddRegionRequest, AddRegionResponse, AddRegionError, Credentials | HttpClient.HttpClient>;
export type AttachCustomerManagedPolicyReferenceToPermissionSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Attaches the specified customer managed policy to the specified PermissionSet.
 */
export declare const attachCustomerManagedPolicyReferenceToPermissionSet: API.OperationMethod<AttachCustomerManagedPolicyReferenceToPermissionSetRequest, AttachCustomerManagedPolicyReferenceToPermissionSetResponse, AttachCustomerManagedPolicyReferenceToPermissionSetError, Credentials | HttpClient.HttpClient>;
export type AttachManagedPolicyToPermissionSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Attaches an Amazon Web Services managed policy ARN to a permission set.
 *
 * If the permission set is already referenced by one or more account assignments, you will need to call ` ProvisionPermissionSet ` after this operation. Calling `ProvisionPermissionSet` applies the corresponding IAM policy updates to all assigned accounts.
 */
export declare const attachManagedPolicyToPermissionSet: API.OperationMethod<AttachManagedPolicyToPermissionSetRequest, AttachManagedPolicyToPermissionSetResponse, AttachManagedPolicyToPermissionSetError, Credentials | HttpClient.HttpClient>;
export type CreateAccountAssignmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Assigns access to a principal for a specified Amazon Web Services account using a specified permission set.
 *
 * The term *principal* here refers to a user or group that is defined in IAM Identity Center.
 *
 * As part of a successful `CreateAccountAssignment` call, the specified permission set will automatically be provisioned to the account in the form of an IAM policy. That policy is attached to the IAM role created in IAM Identity Center. If the permission set is subsequently updated, the corresponding IAM policies attached to roles in your accounts will not be updated automatically. In this case, you must call ` ProvisionPermissionSet ` to make these updates.
 *
 * After a successful response, call `DescribeAccountAssignmentCreationStatus` to describe the status of an assignment creation request.
 */
export declare const createAccountAssignment: API.OperationMethod<CreateAccountAssignmentRequest, CreateAccountAssignmentResponse, CreateAccountAssignmentError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an OAuth 2.0 customer managed application in IAM Identity Center for the given application provider.
 *
 * This API does not support creating SAML 2.0 customer managed applications or Amazon Web Services managed applications. To learn how to create an Amazon Web Services managed application, see the application user guide. You can create a SAML 2.0 customer managed application in the Amazon Web Services Management Console only. See Setting up customer managed SAML 2.0 applications. For more information on these application types, see Amazon Web Services managed applications.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationAssignmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Grant application access to a user or group.
 */
export declare const createApplicationAssignment: API.OperationMethod<CreateApplicationAssignmentRequest, CreateApplicationAssignmentResponse, CreateApplicationAssignmentError, Credentials | HttpClient.HttpClient>;
export type CreateInstanceError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an instance of IAM Identity Center for a standalone Amazon Web Services account that is not managed by Organizations or a member Amazon Web Services account in an organization. You can create only one instance per account and across all Amazon Web Services Regions.
 *
 * The CreateInstance request is rejected if the following apply:
 *
 * - The instance is created within the organization management account.
 *
 * - An instance already exists in the same account.
 */
export declare const createInstance: API.OperationMethod<CreateInstanceRequest, CreateInstanceResponse, CreateInstanceError, Credentials | HttpClient.HttpClient>;
export type CreateInstanceAccessControlAttributeConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables the attributes-based access control (ABAC) feature for the specified IAM Identity Center instance. You can also specify new attributes to add to your ABAC configuration during the enabling process. For more information about ABAC, see Attribute-Based Access Control in the *IAM Identity Center User Guide*.
 *
 * After a successful response, call `DescribeInstanceAccessControlAttributeConfiguration` to validate that `InstanceAccessControlAttributeConfiguration` was created.
 */
export declare const createInstanceAccessControlAttributeConfiguration: API.OperationMethod<CreateInstanceAccessControlAttributeConfigurationRequest, CreateInstanceAccessControlAttributeConfigurationResponse, CreateInstanceAccessControlAttributeConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreatePermissionSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a permission set within a specified IAM Identity Center instance.
 *
 * To grant users and groups access to Amazon Web Services account resources, use ` CreateAccountAssignment `.
 */
export declare const createPermissionSet: API.OperationMethod<CreatePermissionSetRequest, CreatePermissionSetResponse, CreatePermissionSetError, Credentials | HttpClient.HttpClient>;
export type CreateTrustedTokenIssuerError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a connection to a trusted token issuer in an instance of IAM Identity Center. A trusted token issuer enables trusted identity propagation to be used with applications that authenticate outside of Amazon Web Services.
 *
 * This trusted token issuer describes an external identity provider (IdP) that can generate claims or assertions in the form of access tokens for a user. Applications enabled for IAM Identity Center can use these tokens for authentication.
 */
export declare const createTrustedTokenIssuer: API.OperationMethod<CreateTrustedTokenIssuerRequest, CreateTrustedTokenIssuerResponse, CreateTrustedTokenIssuerError, Credentials | HttpClient.HttpClient>;
export type DeleteAccountAssignmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a principal's access from a specified Amazon Web Services account using a specified permission set.
 *
 * After a successful response, call `DescribeAccountAssignmentDeletionStatus` to describe the status of an assignment deletion request.
 */
export declare const deleteAccountAssignment: API.OperationMethod<DeleteAccountAssignmentRequest, DeleteAccountAssignmentResponse, DeleteAccountAssignmentError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the association with the application. The connected service resource still exists.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationAccessScopeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an IAM Identity Center access scope from an application.
 */
export declare const deleteApplicationAccessScope: API.OperationMethod<DeleteApplicationAccessScopeRequest, DeleteApplicationAccessScopeResponse, DeleteApplicationAccessScopeError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationAssignmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Revoke application access to an application by deleting application assignments for a user or group.
 */
export declare const deleteApplicationAssignment: API.OperationMethod<DeleteApplicationAssignmentRequest, DeleteApplicationAssignmentResponse, DeleteApplicationAssignmentError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationAuthenticationMethodError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an authentication method from an application.
 */
export declare const deleteApplicationAuthenticationMethod: API.OperationMethod<DeleteApplicationAuthenticationMethodRequest, DeleteApplicationAuthenticationMethodResponse, DeleteApplicationAuthenticationMethodError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationGrantError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a grant from an application.
 */
export declare const deleteApplicationGrant: API.OperationMethod<DeleteApplicationGrantRequest, DeleteApplicationGrantResponse, DeleteApplicationGrantError, Credentials | HttpClient.HttpClient>;
export type DeleteInlinePolicyFromPermissionSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the inline policy from a specified permission set.
 */
export declare const deleteInlinePolicyFromPermissionSet: API.OperationMethod<DeleteInlinePolicyFromPermissionSetRequest, DeleteInlinePolicyFromPermissionSetResponse, DeleteInlinePolicyFromPermissionSetError, Credentials | HttpClient.HttpClient>;
export type DeleteInstanceError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the instance of IAM Identity Center. Only the account that owns the instance can call this API. Neither the delegated administrator nor member account can delete the organization instance, but those roles can delete their own instance.
 */
export declare const deleteInstance: API.OperationMethod<DeleteInstanceRequest, DeleteInstanceResponse, DeleteInstanceError, Credentials | HttpClient.HttpClient>;
export type DeleteInstanceAccessControlAttributeConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disables the attributes-based access control (ABAC) feature for the specified IAM Identity Center instance and deletes all of the attribute mappings that have been configured. Once deleted, any attributes that are received from an identity source and any custom attributes you have previously configured will not be passed. For more information about ABAC, see Attribute-Based Access Control in the *IAM Identity Center User Guide*.
 */
export declare const deleteInstanceAccessControlAttributeConfiguration: API.OperationMethod<DeleteInstanceAccessControlAttributeConfigurationRequest, DeleteInstanceAccessControlAttributeConfigurationResponse, DeleteInstanceAccessControlAttributeConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeletePermissionsBoundaryFromPermissionSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the permissions boundary from a specified PermissionSet.
 */
export declare const deletePermissionsBoundaryFromPermissionSet: API.OperationMethod<DeletePermissionsBoundaryFromPermissionSetRequest, DeletePermissionsBoundaryFromPermissionSetResponse, DeletePermissionsBoundaryFromPermissionSetError, Credentials | HttpClient.HttpClient>;
export type DeletePermissionSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified permission set.
 */
export declare const deletePermissionSet: API.OperationMethod<DeletePermissionSetRequest, DeletePermissionSetResponse, DeletePermissionSetError, Credentials | HttpClient.HttpClient>;
export type DeleteTrustedTokenIssuerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a trusted token issuer configuration from an instance of IAM Identity Center.
 *
 * Deleting this trusted token issuer configuration will cause users to lose access to any applications that are configured to use the trusted token issuer.
 */
export declare const deleteTrustedTokenIssuer: API.OperationMethod<DeleteTrustedTokenIssuerRequest, DeleteTrustedTokenIssuerResponse, DeleteTrustedTokenIssuerError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountAssignmentCreationStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the status of the assignment creation request.
 */
export declare const describeAccountAssignmentCreationStatus: API.OperationMethod<DescribeAccountAssignmentCreationStatusRequest, DescribeAccountAssignmentCreationStatusResponse, DescribeAccountAssignmentCreationStatusError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountAssignmentDeletionStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the status of the assignment deletion request.
 */
export declare const describeAccountAssignmentDeletionStatus: API.OperationMethod<DescribeAccountAssignmentDeletionStatusRequest, DescribeAccountAssignmentDeletionStatusResponse, DescribeAccountAssignmentDeletionStatusError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of an application associated with an instance of IAM Identity Center.
 */
export declare const describeApplication: API.OperationMethod<DescribeApplicationRequest, DescribeApplicationResponse, DescribeApplicationError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationAssignmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a direct assignment of a user or group to an application. If the user doesn't have a direct assignment to the application, the user may still have access to the application through a group. Therefore, don't use this API to test access to an application for a user. Instead use ListApplicationAssignmentsForPrincipal.
 */
export declare const describeApplicationAssignment: API.OperationMethod<DescribeApplicationAssignmentRequest, DescribeApplicationAssignmentResponse, DescribeApplicationAssignmentError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationProviderError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about a provider that can be used to connect an Amazon Web Services managed application or customer managed application to IAM Identity Center.
 */
export declare const describeApplicationProvider: API.OperationMethod<DescribeApplicationProviderRequest, DescribeApplicationProviderResponse, DescribeApplicationProviderError, Credentials | HttpClient.HttpClient>;
export type DescribeInstanceError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the details of an instance of IAM Identity Center. The status can be one of the following:
 *
 * - `CREATE_IN_PROGRESS` - The instance is in the process of being created. When the instance is ready for use, DescribeInstance returns the status of `ACTIVE`. While the instance is in the `CREATE_IN_PROGRESS` state, you can call only DescribeInstance and DeleteInstance operations.
 *
 * - `DELETE_IN_PROGRESS` - The instance is being deleted. Returns `AccessDeniedException` after the delete operation completes.
 *
 * - `ACTIVE` - The instance is active.
 */
export declare const describeInstance: API.OperationMethod<DescribeInstanceRequest, DescribeInstanceResponse, DescribeInstanceError, Credentials | HttpClient.HttpClient>;
export type DescribeInstanceAccessControlAttributeConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the list of IAM Identity Center identity store attributes that have been configured to work with attributes-based access control (ABAC) for the specified IAM Identity Center instance. This will not return attributes configured and sent by an external identity provider. For more information about ABAC, see Attribute-Based Access Control in the *IAM Identity Center User Guide*.
 */
export declare const describeInstanceAccessControlAttributeConfiguration: API.OperationMethod<DescribeInstanceAccessControlAttributeConfigurationRequest, DescribeInstanceAccessControlAttributeConfigurationResponse, DescribeInstanceAccessControlAttributeConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribePermissionSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of the permission set.
 */
export declare const describePermissionSet: API.OperationMethod<DescribePermissionSetRequest, DescribePermissionSetResponse, DescribePermissionSetError, Credentials | HttpClient.HttpClient>;
export type DescribePermissionSetProvisioningStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the status for the given permission set provisioning request.
 */
export declare const describePermissionSetProvisioningStatus: API.OperationMethod<DescribePermissionSetProvisioningStatusRequest, DescribePermissionSetProvisioningStatusResponse, DescribePermissionSetProvisioningStatusError, Credentials | HttpClient.HttpClient>;
export type DescribeRegionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about a specific Region enabled in an IAM Identity Center instance. Details include the Region name, current status (ACTIVE, ADDING, or REMOVING), the date when the Region was added, and whether it is the primary Region. The request must be made from one of the enabled Regions of the IAM Identity Center instance.
 *
 * The following actions are related to `DescribeRegion`:
 *
 * - AddRegion
 *
 * - RemoveRegion
 *
 * - ListRegions
 */
export declare const describeRegion: API.OperationMethod<DescribeRegionRequest, DescribeRegionResponse, DescribeRegionError, Credentials | HttpClient.HttpClient>;
export type DescribeTrustedTokenIssuerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about a trusted token issuer configuration stored in an instance of IAM Identity Center. Details include the name of the trusted token issuer, the issuer URL, and the path of the source attribute and the destination attribute for a trusted token issuer configuration.
 */
export declare const describeTrustedTokenIssuer: API.OperationMethod<DescribeTrustedTokenIssuerRequest, DescribeTrustedTokenIssuerResponse, DescribeTrustedTokenIssuerError, Credentials | HttpClient.HttpClient>;
export type DetachCustomerManagedPolicyReferenceFromPermissionSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Detaches the specified customer managed policy from the specified PermissionSet.
 */
export declare const detachCustomerManagedPolicyReferenceFromPermissionSet: API.OperationMethod<DetachCustomerManagedPolicyReferenceFromPermissionSetRequest, DetachCustomerManagedPolicyReferenceFromPermissionSetResponse, DetachCustomerManagedPolicyReferenceFromPermissionSetError, Credentials | HttpClient.HttpClient>;
export type DetachManagedPolicyFromPermissionSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Detaches the attached Amazon Web Services managed policy ARN from the specified permission set.
 */
export declare const detachManagedPolicyFromPermissionSet: API.OperationMethod<DetachManagedPolicyFromPermissionSetRequest, DetachManagedPolicyFromPermissionSetResponse, DetachManagedPolicyFromPermissionSetError, Credentials | HttpClient.HttpClient>;
export type GetApplicationAccessScopeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the authorized targets for an IAM Identity Center access scope for an application.
 */
export declare const getApplicationAccessScope: API.OperationMethod<GetApplicationAccessScopeRequest, GetApplicationAccessScopeResponse, GetApplicationAccessScopeError, Credentials | HttpClient.HttpClient>;
export type GetApplicationAssignmentConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the configuration of PutApplicationAssignmentConfiguration.
 */
export declare const getApplicationAssignmentConfiguration: API.OperationMethod<GetApplicationAssignmentConfigurationRequest, GetApplicationAssignmentConfigurationResponse, GetApplicationAssignmentConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetApplicationAuthenticationMethodError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about an authentication method used by an application.
 */
export declare const getApplicationAuthenticationMethod: API.OperationMethod<GetApplicationAuthenticationMethodRequest, GetApplicationAuthenticationMethodResponse, GetApplicationAuthenticationMethodError, Credentials | HttpClient.HttpClient>;
export type GetApplicationGrantError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about an application grant.
 */
export declare const getApplicationGrant: API.OperationMethod<GetApplicationGrantRequest, GetApplicationGrantResponse, GetApplicationGrantError, Credentials | HttpClient.HttpClient>;
export type GetApplicationSessionConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the session configuration for an application in IAM Identity Center.
 *
 * The session configuration determines how users can access an application. This includes whether user background sessions are enabled. User background sessions allow users to start a job on a supported Amazon Web Services managed application without having to remain signed in to an active session while the job runs.
 */
export declare const getApplicationSessionConfiguration: API.OperationMethod<GetApplicationSessionConfigurationRequest, GetApplicationSessionConfigurationResponse, GetApplicationSessionConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetInlinePolicyForPermissionSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Obtains the inline policy assigned to the permission set.
 */
export declare const getInlinePolicyForPermissionSet: API.OperationMethod<GetInlinePolicyForPermissionSetRequest, GetInlinePolicyForPermissionSetResponse, GetInlinePolicyForPermissionSetError, Credentials | HttpClient.HttpClient>;
export type GetPermissionsBoundaryForPermissionSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Obtains the permissions boundary for a specified PermissionSet.
 */
export declare const getPermissionsBoundaryForPermissionSet: API.OperationMethod<GetPermissionsBoundaryForPermissionSetRequest, GetPermissionsBoundaryForPermissionSetResponse, GetPermissionsBoundaryForPermissionSetError, Credentials | HttpClient.HttpClient>;
export type ListAccountAssignmentCreationStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the status of the Amazon Web Services account assignment creation requests for a specified IAM Identity Center instance.
 */
export declare const listAccountAssignmentCreationStatus: API.PaginatedOperationMethod<ListAccountAssignmentCreationStatusRequest, ListAccountAssignmentCreationStatusResponse, ListAccountAssignmentCreationStatusError, Credentials | HttpClient.HttpClient, AccountAssignmentOperationStatusMetadata>;
export type ListAccountAssignmentDeletionStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the status of the Amazon Web Services account assignment deletion requests for a specified IAM Identity Center instance.
 */
export declare const listAccountAssignmentDeletionStatus: API.PaginatedOperationMethod<ListAccountAssignmentDeletionStatusRequest, ListAccountAssignmentDeletionStatusResponse, ListAccountAssignmentDeletionStatusError, Credentials | HttpClient.HttpClient, AccountAssignmentOperationStatusMetadata>;
export type ListAccountAssignmentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the assignee of the specified Amazon Web Services account with the specified permission set.
 */
export declare const listAccountAssignments: API.PaginatedOperationMethod<ListAccountAssignmentsRequest, ListAccountAssignmentsResponse, ListAccountAssignmentsError, Credentials | HttpClient.HttpClient, AccountAssignment>;
export type ListAccountAssignmentsForPrincipalError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of the IAM Identity Center associated Amazon Web Services accounts that the principal has access to. This action must be called from the management account containing your organization instance of IAM Identity Center. This action is not valid for account instances of IAM Identity Center.
 */
export declare const listAccountAssignmentsForPrincipal: API.PaginatedOperationMethod<ListAccountAssignmentsForPrincipalRequest, ListAccountAssignmentsForPrincipalResponse, ListAccountAssignmentsForPrincipalError, Credentials | HttpClient.HttpClient, AccountAssignmentForPrincipal>;
export type ListAccountsForProvisionedPermissionSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the Amazon Web Services accounts where the specified permission set is provisioned.
 */
export declare const listAccountsForProvisionedPermissionSet: API.PaginatedOperationMethod<ListAccountsForProvisionedPermissionSetRequest, ListAccountsForProvisionedPermissionSetResponse, ListAccountsForProvisionedPermissionSetError, Credentials | HttpClient.HttpClient, AccountId>;
export type ListApplicationAccessScopesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the access scopes and authorized targets associated with an application.
 */
export declare const listApplicationAccessScopes: API.PaginatedOperationMethod<ListApplicationAccessScopesRequest, ListApplicationAccessScopesResponse, ListApplicationAccessScopesError, Credentials | HttpClient.HttpClient, ScopeDetails>;
export type ListApplicationAssignmentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists Amazon Web Services account users that are assigned to an application.
 */
export declare const listApplicationAssignments: API.PaginatedOperationMethod<ListApplicationAssignmentsRequest, ListApplicationAssignmentsResponse, ListApplicationAssignmentsError, Credentials | HttpClient.HttpClient, ApplicationAssignment>;
export type ListApplicationAssignmentsForPrincipalError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the applications to which a specified principal is assigned. You must provide a filter when calling this action from a member account against your organization instance of IAM Identity Center. A filter is not required when called from the management account against an organization instance of IAM Identity Center, or from a member account against an account instance of IAM Identity Center in the same account.
 */
export declare const listApplicationAssignmentsForPrincipal: API.PaginatedOperationMethod<ListApplicationAssignmentsForPrincipalRequest, ListApplicationAssignmentsForPrincipalResponse, ListApplicationAssignmentsForPrincipalError, Credentials | HttpClient.HttpClient, ApplicationAssignmentForPrincipal>;
export type ListApplicationAuthenticationMethodsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all of the authentication methods supported by the specified application.
 */
export declare const listApplicationAuthenticationMethods: API.PaginatedOperationMethod<ListApplicationAuthenticationMethodsRequest, ListApplicationAuthenticationMethodsResponse, ListApplicationAuthenticationMethodsError, Credentials | HttpClient.HttpClient, AuthenticationMethodItem>;
export type ListApplicationGrantsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the grants associated with an application.
 */
export declare const listApplicationGrants: API.PaginatedOperationMethod<ListApplicationGrantsRequest, ListApplicationGrantsResponse, ListApplicationGrantsError, Credentials | HttpClient.HttpClient, GrantItem>;
export type ListApplicationProvidersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the application providers configured in the IAM Identity Center identity store.
 */
export declare const listApplicationProviders: API.PaginatedOperationMethod<ListApplicationProvidersRequest, ListApplicationProvidersResponse, ListApplicationProvidersError, Credentials | HttpClient.HttpClient, ApplicationProvider>;
export type ListApplicationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all applications associated with the instance of IAM Identity Center. When listing applications for an organization instance in the management account, member accounts must use the `applicationAccount` parameter to filter the list to only applications created from that account. When listing applications for an account instance in the same member account, a filter is not required.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, Application>;
export type ListCustomerManagedPolicyReferencesInPermissionSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all customer managed policies attached to a specified PermissionSet.
 */
export declare const listCustomerManagedPolicyReferencesInPermissionSet: API.PaginatedOperationMethod<ListCustomerManagedPolicyReferencesInPermissionSetRequest, ListCustomerManagedPolicyReferencesInPermissionSetResponse, ListCustomerManagedPolicyReferencesInPermissionSetError, Credentials | HttpClient.HttpClient, CustomerManagedPolicyReference>;
export type ListInstancesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the details of the organization and account instances of IAM Identity Center that were created in or visible to the account calling this API.
 */
export declare const listInstances: API.PaginatedOperationMethod<ListInstancesRequest, ListInstancesResponse, ListInstancesError, Credentials | HttpClient.HttpClient, InstanceMetadata>;
export type ListManagedPoliciesInPermissionSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the Amazon Web Services managed policy that is attached to a specified permission set.
 */
export declare const listManagedPoliciesInPermissionSet: API.PaginatedOperationMethod<ListManagedPoliciesInPermissionSetRequest, ListManagedPoliciesInPermissionSetResponse, ListManagedPoliciesInPermissionSetError, Credentials | HttpClient.HttpClient, AttachedManagedPolicy>;
export type ListPermissionSetProvisioningStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the status of the permission set provisioning requests for a specified IAM Identity Center instance.
 */
export declare const listPermissionSetProvisioningStatus: API.PaginatedOperationMethod<ListPermissionSetProvisioningStatusRequest, ListPermissionSetProvisioningStatusResponse, ListPermissionSetProvisioningStatusError, Credentials | HttpClient.HttpClient, PermissionSetProvisioningStatusMetadata>;
export type ListPermissionSetsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the PermissionSets in an IAM Identity Center instance.
 */
export declare const listPermissionSets: API.PaginatedOperationMethod<ListPermissionSetsRequest, ListPermissionSetsResponse, ListPermissionSetsError, Credentials | HttpClient.HttpClient, PermissionSetArn>;
export type ListPermissionSetsProvisionedToAccountError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the permission sets that are provisioned to a specified Amazon Web Services account.
 */
export declare const listPermissionSetsProvisionedToAccount: API.PaginatedOperationMethod<ListPermissionSetsProvisionedToAccountRequest, ListPermissionSetsProvisionedToAccountResponse, ListPermissionSetsProvisionedToAccountError, Credentials | HttpClient.HttpClient, PermissionSetArn>;
export type ListRegionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all enabled Regions of an IAM Identity Center instance, including those that are being added or removed. This operation returns Regions with ACTIVE, ADDING, or REMOVING status.
 *
 * The following actions are related to `ListRegions`:
 *
 * - AddRegion
 *
 * - RemoveRegion
 *
 * - DescribeRegion
 */
export declare const listRegions: API.PaginatedOperationMethod<ListRegionsRequest, ListRegionsResponse, ListRegionsError, Credentials | HttpClient.HttpClient, RegionMetadata>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags that are attached to a specified resource.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient, Tag>;
export type ListTrustedTokenIssuersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the trusted token issuers configured in an instance of IAM Identity Center.
 */
export declare const listTrustedTokenIssuers: API.PaginatedOperationMethod<ListTrustedTokenIssuersRequest, ListTrustedTokenIssuersResponse, ListTrustedTokenIssuersError, Credentials | HttpClient.HttpClient, TrustedTokenIssuerMetadata>;
export type ProvisionPermissionSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The process by which a specified permission set is provisioned to the specified target.
 */
export declare const provisionPermissionSet: API.OperationMethod<ProvisionPermissionSetRequest, ProvisionPermissionSetResponse, ProvisionPermissionSetError, Credentials | HttpClient.HttpClient>;
export type PutApplicationAccessScopeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds or updates the list of authorized targets for an IAM Identity Center access scope for an application.
 */
export declare const putApplicationAccessScope: API.OperationMethod<PutApplicationAccessScopeRequest, PutApplicationAccessScopeResponse, PutApplicationAccessScopeError, Credentials | HttpClient.HttpClient>;
export type PutApplicationAssignmentConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Configure how users gain access to an application. If `AssignmentsRequired` is `true` (default value), users don't have access to the application unless an assignment is created using the CreateApplicationAssignment API. If `false`, all users have access to the application. If an assignment is created using CreateApplicationAssignment., the user retains access if `AssignmentsRequired` is set to `true`.
 */
export declare const putApplicationAssignmentConfiguration: API.OperationMethod<PutApplicationAssignmentConfigurationRequest, PutApplicationAssignmentConfigurationResponse, PutApplicationAssignmentConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutApplicationAuthenticationMethodError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds or updates an authentication method for an application.
 */
export declare const putApplicationAuthenticationMethod: API.OperationMethod<PutApplicationAuthenticationMethodRequest, PutApplicationAuthenticationMethodResponse, PutApplicationAuthenticationMethodError, Credentials | HttpClient.HttpClient>;
export type PutApplicationGrantError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a configuration for an application to use grants. Conceptually grants are authorization to request actions related to tokens. This configuration will be used when parties are requesting and receiving tokens during the trusted identity propagation process. For more information on the IAM Identity Center supported grant workflows, see SAML 2.0 and OAuth 2.0.
 *
 * A grant is created between your applications and Identity Center instance which enables an application to use specified mechanisms to obtain tokens. These tokens are used by your applications to gain access to Amazon Web Services resources on behalf of users. The following elements are within these exchanges:
 *
 * - **Requester** - The application requesting access to Amazon Web Services resources.
 *
 * - **Subject** - Typically the user that is requesting access to Amazon Web Services resources.
 *
 * - **Grant** - Conceptually, a grant is authorization to access Amazon Web Services resources. These grants authorize token generation for authenticating access to the requester and for the request to make requests on behalf of the subjects. There are four types of grants:
 *
 * - **AuthorizationCode** - Allows an application to request authorization through a series of user-agent redirects.
 *
 * - **JWT bearer ** - Authorizes an application to exchange a JSON Web Token that came from an external identity provider. To learn more, see RFC 6479.
 *
 * - **Refresh token** - Enables application to request new access tokens to replace expiring or expired access tokens.
 *
 * - **Exchange token** - A grant that requests tokens from the authorization server by providing a 'subject' token with access scope authorizing trusted identity propagation to this application. To learn more, see RFC 8693.
 *
 * - **Authorization server** - IAM Identity Center requests tokens.
 *
 * User credentials are never shared directly within these exchanges. Instead, applications use grants to request access tokens from IAM Identity Center. For more information, see RFC 6479.
 * **Use cases**
 *
 * - Connecting to custom applications.
 *
 * - Configuring an Amazon Web Services service to make calls to another Amazon Web Services services using JWT tokens.
 */
export declare const putApplicationGrant: API.OperationMethod<PutApplicationGrantRequest, PutApplicationGrantResponse, PutApplicationGrantError, Credentials | HttpClient.HttpClient>;
export type PutApplicationSessionConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the session configuration for an application in IAM Identity Center.
 *
 * The session configuration determines how users can access an application. This includes whether user background sessions are enabled. User background sessions allow users to start a job on a supported Amazon Web Services managed application without having to remain signed in to an active session while the job runs.
 */
export declare const putApplicationSessionConfiguration: API.OperationMethod<PutApplicationSessionConfigurationRequest, PutApplicationSessionConfigurationResponse, PutApplicationSessionConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutInlinePolicyToPermissionSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Attaches an inline policy to a permission set.
 *
 * If the permission set is already referenced by one or more account assignments, you will need to call ` ProvisionPermissionSet ` after this action to apply the corresponding IAM policy updates to all assigned accounts.
 */
export declare const putInlinePolicyToPermissionSet: API.OperationMethod<PutInlinePolicyToPermissionSetRequest, PutInlinePolicyToPermissionSetResponse, PutInlinePolicyToPermissionSetError, Credentials | HttpClient.HttpClient>;
export type PutPermissionsBoundaryToPermissionSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Attaches an Amazon Web Services managed or customer managed policy to the specified PermissionSet as a permissions boundary.
 */
export declare const putPermissionsBoundaryToPermissionSet: API.OperationMethod<PutPermissionsBoundaryToPermissionSetRequest, PutPermissionsBoundaryToPermissionSetResponse, PutPermissionsBoundaryToPermissionSetError, Credentials | HttpClient.HttpClient>;
export type RemoveRegionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes an additional Region from an IAM Identity Center instance. This operation initiates an asynchronous workflow to clean up IAM Identity Center resources in the specified additional Region. The Region status is set to REMOVING and the Region record is deleted when the workflow completes. The request must be made from the primary Region. The target Region cannot be the primary Region, and no other add or remove Region workflows can be in progress.
 *
 * The following actions are related to `RemoveRegion`:
 *
 * - AddRegion
 *
 * - DescribeRegion
 *
 * - ListRegions
 */
export declare const removeRegion: API.OperationMethod<RemoveRegionRequest, RemoveRegionResponse, RemoveRegionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a set of tags with a specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a set of tags from a specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates application properties.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateInstanceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the details for the instance of IAM Identity Center that is owned by the Amazon Web Services account.
 *
 * In a single `UpdateInstance` request, you can perform only one of the following operations:
 *
 * - Update the encryption configuration of the instance by specifying `EncryptionConfiguration`.
 *
 * - Enable permission sets for the instance by specifying `PermissionSetsEnabled`.
 *
 * A request that specifies both `EncryptionConfiguration` and `PermissionSetsEnabled` returns a `ValidationException`. To perform both operations, call `UpdateInstance` separately for each. The two calls can be made in parallel.
 */
export declare const updateInstance: API.OperationMethod<UpdateInstanceRequest, UpdateInstanceResponse, UpdateInstanceError, Credentials | HttpClient.HttpClient>;
export type UpdateInstanceAccessControlAttributeConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the IAM Identity Center identity store attributes that you can use with the IAM Identity Center instance for attributes-based access control (ABAC). When using an external identity provider as an identity source, you can pass attributes through the SAML assertion as an alternative to configuring attributes from the IAM Identity Center identity store. If a SAML assertion passes any of these attributes, IAM Identity Center replaces the attribute value with the value from the IAM Identity Center identity store. For more information about ABAC, see Attribute-Based Access Control in the *IAM Identity Center User Guide*.
 */
export declare const updateInstanceAccessControlAttributeConfiguration: API.OperationMethod<UpdateInstanceAccessControlAttributeConfigurationRequest, UpdateInstanceAccessControlAttributeConfigurationResponse, UpdateInstanceAccessControlAttributeConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdatePermissionSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing permission set.
 */
export declare const updatePermissionSet: API.OperationMethod<UpdatePermissionSetRequest, UpdatePermissionSetResponse, UpdatePermissionSetError, Credentials | HttpClient.HttpClient>;
export type UpdateTrustedTokenIssuerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the name of the trusted token issuer, or the path of a source attribute or destination attribute for a trusted token issuer configuration.
 *
 * Updating this trusted token issuer configuration might cause users to lose access to any applications that are configured to use the trusted token issuer.
 */
export declare const updateTrustedTokenIssuer: API.OperationMethod<UpdateTrustedTokenIssuerRequest, UpdateTrustedTokenIssuerResponse, UpdateTrustedTokenIssuerError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=sso-admin.d.ts.map