import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type StringWithPatternAndLengthLimits = string;
export type RoleArn = string;
export type EncryptionConfigurationType = "AWS_OWNED_KEY" | "CUSTOMER_MANAGED_KMS_KEY" | (string & {});
export type KmsKeyId = string;
export interface EncryptionConfiguration {
    type?: EncryptionConfigurationType;
    kmsKeyId?: string;
}
export type Retention = number;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export type TagKeyBoundaries = string[];
export type SNSTopicArn = string;
export type ChatConfigurationArn = string;
export type ChatConfigurationArns = string[];
export type ChatbotNotificationChannel = {
    [key: string]: string[] | undefined;
};
export interface CrossAccountConfiguration {
    sourceRoleArn?: string;
}
export type CrossAccountConfigurations = CrossAccountConfiguration[];
export interface CreateInvestigationGroupInput {
    name: string;
    roleArn: string;
    encryptionConfiguration?: EncryptionConfiguration;
    retentionInDays?: number;
    tags?: {
        [key: string]: string | undefined;
    };
    tagKeyBoundaries?: string[];
    chatbotNotificationChannel?: {
        [key: string]: string[] | undefined;
    };
    isCloudTrailEventHistoryEnabled?: boolean;
    crossAccountConfigurations?: CrossAccountConfiguration[];
}
export type InvestigationGroupArn = string;
export interface CreateInvestigationGroupOutput {
    arn?: string;
}
export type InvestigationGroupIdentifier = string;
export interface DeleteInvestigationGroupRequest {
    identifier: string;
}
export interface DeleteInvestigationGroupResponse {
}
export interface DeleteInvestigationGroupPolicyRequest {
    identifier: string;
}
export interface DeleteInvestigationGroupPolicyOutput {
}
export interface GetInvestigationGroupRequest {
    identifier: string;
}
export type IdentifierStringWithPatternAndLengthLimits = string;
export interface GetInvestigationGroupResponse {
    createdBy?: string;
    createdAt?: number;
    lastModifiedBy?: string;
    lastModifiedAt?: number;
    name?: string;
    arn?: string;
    roleArn?: string;
    encryptionConfiguration?: EncryptionConfiguration;
    retentionInDays?: number;
    chatbotNotificationChannel?: {
        [key: string]: string[] | undefined;
    };
    tagKeyBoundaries?: string[];
    isCloudTrailEventHistoryEnabled?: boolean;
    crossAccountConfigurations?: CrossAccountConfiguration[];
}
export interface GetInvestigationGroupPolicyRequest {
    identifier: string;
}
export type InvestigationGroupPolicyDocument = string;
export interface GetInvestigationGroupPolicyResponse {
    investigationGroupArn?: string;
    policy?: string;
}
export type SensitiveStringWithLengthLimits = string | redacted.Redacted<string>;
export interface ListInvestigationGroupsInput {
    nextToken?: string | redacted.Redacted<string>;
    maxResults?: number;
}
export interface ListInvestigationGroupsModel {
    arn?: string;
    name?: string;
}
export type InvestigationGroups = ListInvestigationGroupsModel[];
export interface ListInvestigationGroupsOutput {
    nextToken?: string | redacted.Redacted<string>;
    investigationGroups?: ListInvestigationGroupsModel[];
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface PutInvestigationGroupPolicyRequest {
    identifier: string;
    policy: string;
}
export interface PutInvestigationGroupPolicyResponse {
    investigationGroupArn?: string;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateInvestigationGroupRequest {
    identifier: string;
    roleArn?: string;
    encryptionConfiguration?: EncryptionConfiguration;
    tagKeyBoundaries?: string[];
    chatbotNotificationChannel?: {
        [key: string]: string[] | undefined;
    };
    isCloudTrailEventHistoryEnabled?: boolean;
    crossAccountConfigurations?: CrossAccountConfiguration[];
}
export interface UpdateInvestigationGroupOutput {
}
export type CreateInvestigationGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an *investigation group* in your account. Creating an investigation group is a one-time setup task for each Region in your account. It is a necessary task to be able to perform investigations.
 *
 * Settings in the investigation group help you centrally manage the common properties of your investigations, such as the following:
 *
 * - Who can access the investigations
 *
 * - Whether investigation data is encrypted with a customer managed Key Management Service key.
 *
 * - How long investigations and their data are retained by default.
 *
 * Currently, you can have one investigation group in each Region in your account. Each investigation in a Region is a part of the investigation group in that Region
 *
 * To create an investigation group and set up CloudWatch investigations, you must be signed in to an IAM principal that has either the `AIOpsConsoleAdminPolicy` or the `AdministratorAccess` IAM policy attached, or to an account that has similar permissions.
 *
 * You can configure CloudWatch alarms to start investigations and add events to investigations. If you create your investigation group with `CreateInvestigationGroup` and you want to enable alarms to do this, you must use `PutInvestigationGroupPolicy` to create a resource policy that grants this permission to CloudWatch alarms.
 *
 * For more information about configuring CloudWatch alarms, see Using Amazon CloudWatch alarms
 */
export declare const createInvestigationGroup: API.OperationMethod<CreateInvestigationGroupInput, CreateInvestigationGroupOutput, CreateInvestigationGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteInvestigationGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Deletes the specified investigation group from your account. You can currently have one investigation group per Region in your account. After you delete an investigation group, you can later create a new investigation group in the same Region.
 */
export declare const deleteInvestigationGroup: API.OperationMethod<DeleteInvestigationGroupRequest, DeleteInvestigationGroupResponse, DeleteInvestigationGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteInvestigationGroupPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Removes the IAM resource policy from being associated with the investigation group that you specify.
 */
export declare const deleteInvestigationGroupPolicy: API.OperationMethod<DeleteInvestigationGroupPolicyRequest, DeleteInvestigationGroupPolicyOutput, DeleteInvestigationGroupPolicyError, Credentials | HttpClient.HttpClient>;
export type GetInvestigationGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Returns the configuration information for the specified investigation group.
 */
export declare const getInvestigationGroup: API.OperationMethod<GetInvestigationGroupRequest, GetInvestigationGroupResponse, GetInvestigationGroupError, Credentials | HttpClient.HttpClient>;
export type GetInvestigationGroupPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Returns the JSON of the IAM resource policy associated with the specified investigation group in a string. For example, `{\"Version\":\"2012-10-17\",\"Statement\":[{\"Effect\":\"Allow\",\"Principal\":{\"Service\":\"aiops.alarms.cloudwatch.amazonaws.com\"},\"Action\":[\"aiops:CreateInvestigation\",\"aiops:CreateInvestigationEvent\"],\"Resource\":\"*\",\"Condition\":{\"StringEquals\":{\"aws:SourceAccount\":\"111122223333\"},\"ArnLike\":{\"aws:SourceArn\":\"arn:aws:cloudwatch:us-east-1:111122223333:alarm:*\"}}}]}`.
 */
export declare const getInvestigationGroupPolicy: API.OperationMethod<GetInvestigationGroupPolicyRequest, GetInvestigationGroupPolicyResponse, GetInvestigationGroupPolicyError, Credentials | HttpClient.HttpClient>;
export type ListInvestigationGroupsError = AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Returns the ARN and name of each investigation group in the account.
 */
export declare const listInvestigationGroups: API.PaginatedOperationMethod<ListInvestigationGroupsInput, ListInvestigationGroupsOutput, ListInvestigationGroupsError, Credentials | HttpClient.HttpClient, ListInvestigationGroupsModel>;
export type ListTagsForResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Displays the tags associated with a CloudWatch investigations resource. Currently, investigation groups support tagging.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutInvestigationGroupPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates an IAM resource policy and assigns it to the specified investigation group.
 *
 * If you create your investigation group with `CreateInvestigationGroup` and you want to enable CloudWatch alarms to create investigations and add events to investigations, you must use this operation to create a policy similar to this example.
 *
 * ` { "Version": "2008-10-17", "Statement": [ { "Effect": "Allow", "Principal": { "Service": "aiops.alarms.cloudwatch.amazonaws.com" }, "Action": [ "aiops:CreateInvestigation", "aiops:CreateInvestigationEvent" ], "Resource": "*", "Condition": { "StringEquals": { "aws:SourceAccount": "account-id" }, "ArnLike": { "aws:SourceArn": "arn:aws:cloudwatch:region:account-id:alarm:*" } } } ] } `
 */
export declare const putInvestigationGroupPolicy: API.OperationMethod<PutInvestigationGroupPolicyRequest, PutInvestigationGroupPolicyResponse, PutInvestigationGroupPolicyError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified resource.
 *
 * Tags can help you organize and categorize your resources. You can also use them to scope user permissions by granting a user permission to access or change only resources with certain tag values.
 *
 * Tags don't have any semantic meaning to Amazon Web Services and are interpreted strictly as strings of characters.
 *
 * You can associate as many as 50 tags with a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateInvestigationGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates the configuration of the specified investigation group.
 */
export declare const updateInvestigationGroup: API.OperationMethod<UpdateInvestigationGroupRequest, UpdateInvestigationGroupOutput, UpdateInvestigationGroupError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=aiops.d.ts.map