import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InvalidInputException_base: S.TaggedErrorClass<"InvalidInputException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type StringType = string;
export type ActionId = string | redacted.Redacted<string>;
export type UserId = string | redacted.Redacted<string>;
export type RecommendationId = string;
export type ActionImpression = (string | redacted.Redacted<string>)[];
export type SynthesizedJsonActionInteractionProperties = string | redacted.Redacted<string>;
export interface ActionInteraction {
    actionId: string | redacted.Redacted<string>;
    userId?: string | redacted.Redacted<string>;
    sessionId: string;
    timestamp: Date;
    eventType: string;
    eventId?: string;
    recommendationId?: string;
    impression?: (string | redacted.Redacted<string>)[];
    properties?: string | redacted.Redacted<string>;
}
export type ActionInteractionsList = ActionInteraction[];
export interface PutActionInteractionsRequest {
    trackingId: string;
    actionInteractions: ActionInteraction[];
}
export interface PutActionInteractionsResponse {
}
export type Arn = string;
export type SynthesizedJsonActionProperties = string | redacted.Redacted<string>;
export interface Action {
    actionId: string;
    properties?: string | redacted.Redacted<string>;
}
export type ActionList = Action[];
export interface PutActionsRequest {
    datasetArn: string;
    actions: Action[];
}
export interface PutActionsResponse {
}
export type FloatType = number;
export type ItemId = string | redacted.Redacted<string>;
export type SynthesizedJsonEventPropertiesJSON = string | redacted.Redacted<string>;
export type Impression = (string | redacted.Redacted<string>)[];
export type EventAttributionSource = string;
export interface MetricAttribution {
    eventAttributionSource: string;
}
export interface Event {
    eventId?: string;
    eventType: string;
    eventValue?: number;
    itemId?: string | redacted.Redacted<string>;
    properties?: string | redacted.Redacted<string>;
    sentAt: Date;
    recommendationId?: string;
    impression?: (string | redacted.Redacted<string>)[];
    metricAttribution?: MetricAttribution;
}
export type EventList = Event[];
export interface PutEventsRequest {
    trackingId: string;
    userId?: string | redacted.Redacted<string>;
    sessionId: string;
    eventList: Event[];
}
export interface PutEventsResponse {
}
export type SynthesizedJsonItemProperties = string | redacted.Redacted<string>;
export interface Item {
    itemId: string;
    properties?: string | redacted.Redacted<string>;
}
export type ItemList = Item[];
export interface PutItemsRequest {
    datasetArn: string;
    items: Item[];
}
export interface PutItemsResponse {
}
export type SynthesizedJsonUserProperties = string | redacted.Redacted<string>;
export interface User {
    userId: string;
    properties?: string | redacted.Redacted<string>;
}
export type UserList = User[];
export interface PutUsersRequest {
    datasetArn: string;
    users: User[];
}
export interface PutUsersResponse {
}
export type ErrorMessage = string;
export type PutActionInteractionsError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Records action interaction event data. An *action interaction* event is an interaction between a user and an *action*.
 * For example, a user taking an action, such a enrolling in a membership program or downloading your app.
 *
 * For more information about recording action interactions, see Recording action interaction events.
 * For more information about actions in an Actions dataset, see Actions dataset.
 */
export declare const putActionInteractions: API.OperationMethod<PutActionInteractionsRequest, PutActionInteractionsResponse, PutActionInteractionsError, Credentials | HttpClient.HttpClient>;
export type PutActionsError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Adds one or more actions to an Actions dataset. For more information see
 * Importing actions individually.
 */
export declare const putActions: API.OperationMethod<PutActionsRequest, PutActionsResponse, PutActionsError, Credentials | HttpClient.HttpClient>;
export type PutEventsError = InvalidInputException | CommonErrors;
/**
 * Records item interaction event data. For more information see
 * Recording item interaction events.
 */
export declare const putEvents: API.OperationMethod<PutEventsRequest, PutEventsResponse, PutEventsError, Credentials | HttpClient.HttpClient>;
export type PutItemsError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Adds one or more items to an Items dataset. For more information see
 * Importing items individually.
 */
export declare const putItems: API.OperationMethod<PutItemsRequest, PutItemsResponse, PutItemsError, Credentials | HttpClient.HttpClient>;
export type PutUsersError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Adds one or more users to a Users dataset. For more information see
 * Importing users individually.
 */
export declare const putUsers: API.OperationMethod<PutUsersRequest, PutUsersResponse, PutUsersError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=personalize-events.d.ts.map