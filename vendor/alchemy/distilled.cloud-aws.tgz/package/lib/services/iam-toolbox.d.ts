import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export interface GetRequestAuthorizationDetailsInput {
    authorizationId: string;
    nextToken?: string;
}
export type AuthorizationContext = {
    [key: string]: any | undefined;
};
export type EvaluatedEffect = "ALLOW" | "EXPLICIT_DENY" | "IMPLICIT_DENY" | (string & {});
export type StatementEffect = "ALLOW" | "DENY" | (string & {});
export interface MatchedStatement {
    sid?: string;
    evaluatedEffect?: StatementEffect;
}
export type MatchedStatementList = MatchedStatement[];
export interface MatchedPolicy {
    uri: string;
    matchedStatements?: MatchedStatement[];
}
export type MatchedPolicyList = MatchedPolicy[];
export interface Evaluation {
    action: string;
    resource: string;
    context?: {
        [key: string]: any | undefined;
    };
    evaluatedEffect?: EvaluatedEffect;
    matchedPolicies?: MatchedPolicy[];
}
export type Evaluations = Evaluation[];
export type PolicyType = "IDENTITY_BASED_POLICY" | "RESOURCE_BASED_POLICY" | "PERMISSIONS_BOUNDARY" | "SESSION_POLICY" | "SERVICE_CONTROL_POLICY" | "RESOURCE_CONTROL_POLICY" | "VPC_ENDPOINT_POLICY" | (string & {});
export interface AttachedTo {
    arn?: string;
}
export type AttachedToList = AttachedTo[];
export interface PolicyInfo {
    type?: PolicyType;
    inline?: boolean;
    uri?: string;
    attachedTo?: AttachedTo[];
}
export type PolicyInfoList = PolicyInfo[];
export interface GetRequestAuthorizationDetailsOutput {
    requestContext: {
        [key: string]: any | undefined;
    };
    evaluations: Evaluation[];
    policies: PolicyInfo[];
    nextToken?: string;
}
export type GetRequestAuthorizationDetailsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the authorization details for a specific access denied request. The details include the request context, the evaluations performed, and the policies that were evaluated.
 *
 * Use this operation to understand why a request was denied. Supported services include an authorization ID in the access denied error message. Pass that ID to this operation to retrieve the details.
 *
 * Authorization details are available for at least 24 hours after the denial.
 *
 * To use this operation, you must have the `iam:GetRequestAuthorizationDetails` permission.
 */
export declare const getRequestAuthorizationDetails: API.PaginatedOperationMethod<GetRequestAuthorizationDetailsInput, GetRequestAuthorizationDetailsOutput, GetRequestAuthorizationDetailsError, Credentials | HttpClient.HttpClient, Evaluation>;
export {};
//# sourceMappingURL=iam-toolbox.d.ts.map