import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ClientLimitExceededException_base: S.TaggedErrorClass<"ClientLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClientLimitExceededException extends /*@__PURE__*/ ClientLimitExceededException_base {
}
declare const InvalidArgumentException_base: S.TaggedErrorClass<"InvalidArgumentException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidArgumentException extends /*@__PURE__*/ InvalidArgumentException_base {
}
declare const InvalidClientException_base: S.TaggedErrorClass<"InvalidClientException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidClientException extends /*@__PURE__*/ InvalidClientException_base {
}
declare const NotAuthorizedException_base: S.TaggedErrorClass<"NotAuthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class NotAuthorizedException extends /*@__PURE__*/ NotAuthorizedException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const SessionExpiredException_base: S.TaggedErrorClass<"SessionExpiredException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SessionExpiredException extends /*@__PURE__*/ SessionExpiredException_base {
}
export type ResourceARN = string;
export type ClientId = string;
export type Service = "TURN" | (string & {});
export type Username = string;
export interface GetIceServerConfigRequest {
    ChannelARN?: string;
    ClientId?: string;
    Service?: Service;
    Username?: string;
}
export type Uri = string;
export type Uris = string[];
export type Password = string;
export type Ttl = number;
export interface IceServer {
    Uris?: string[];
    Username?: string;
    Password?: string | redacted.Redacted<string>;
    Ttl?: number;
}
export type IceServerList = IceServer[];
export interface GetIceServerConfigResponse {
    IceServerList?: IceServer[];
}
export type MessagePayload = string;
export interface SendAlexaOfferToMasterRequest {
    ChannelARN?: string;
    SenderClientId?: string;
    MessagePayload?: string;
}
export type Answer = string;
export interface SendAlexaOfferToMasterResponse {
    Answer?: string;
}
export type ErrorMessage = string;
export type GetIceServerConfigError = ClientLimitExceededException | InvalidArgumentException | InvalidClientException | NotAuthorizedException | ResourceNotFoundException | SessionExpiredException | CommonErrors;
/**
 * Gets the Interactive Connectivity Establishment (ICE) server configuration
 * information, including URIs, username, and password which can be used to configure the
 * WebRTC connection. The ICE component uses this configuration information to setup the
 * WebRTC connection, including authenticating with the Traversal Using Relays around NAT
 * (TURN) relay server.
 *
 * TURN is a protocol that is used to improve the connectivity of peer-to-peer
 * applications. By providing a cloud-based relay service, TURN ensures that a connection
 * can be established even when one or more peers are incapable of a direct peer-to-peer
 * connection. For more information, see A REST API For
 * Access To TURN Services.
 *
 * You can invoke this API to establish a fallback mechanism in case either of the peers
 * is unable to establish a direct peer-to-peer connection over a signaling channel. You
 * must specify either a signaling channel ARN or the client ID in order to invoke this
 * API.
 */
export declare const getIceServerConfig: API.OperationMethod<GetIceServerConfigRequest, GetIceServerConfigResponse, GetIceServerConfigError, Credentials | HttpClient.HttpClient>;
export type SendAlexaOfferToMasterError = ClientLimitExceededException | InvalidArgumentException | NotAuthorizedException | ResourceNotFoundException | CommonErrors;
/**
 * This API allows you to connect WebRTC-enabled devices with Alexa display devices. When
 * invoked, it sends the Alexa Session Description Protocol (SDP) offer to the master peer.
 * The offer is delivered as soon as the master is connected to the specified signaling
 * channel. This API returns the SDP answer from the connected master. If the master is not
 * connected to the signaling channel, redelivery requests are made until the message
 * expires.
 */
export declare const sendAlexaOfferToMaster: API.OperationMethod<SendAlexaOfferToMasterRequest, SendAlexaOfferToMasterResponse, SendAlexaOfferToMasterError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=kinesis-video-signaling.d.ts.map