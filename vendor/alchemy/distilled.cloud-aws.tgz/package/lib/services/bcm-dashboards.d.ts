import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DashboardName = string;
export type Description = string;
export type WidgetId = string;
export type WidgetTitle = string;
export type WidgetWidth = number;
export type WidgetHeight = number;
export type MetricName = "AmortizedCost" | "BlendedCost" | "NetAmortizedCost" | "NetUnblendedCost" | "NormalizedUsageAmount" | "UnblendedCost" | "UsageQuantity" | "SpendCoveredBySavingsPlans" | "Hour" | "Unit" | "Cost" | (string & {});
export type MetricNames = MetricName[];
export type DateTimeType = "ABSOLUTE" | "RELATIVE" | (string & {});
export interface DateTimeValue {
    type: DateTimeType;
    value: string;
}
export interface DateTimeRange {
    startTime: DateTimeValue;
    endTime: DateTimeValue;
}
export type Granularity = "HOURLY" | "DAILY" | "MONTHLY" | (string & {});
export type GroupDefinitionType = "DIMENSION" | "TAG" | "COST_CATEGORY" | (string & {});
export interface GroupDefinition {
    key: string;
    type?: GroupDefinitionType;
}
export type GroupDefinitions = GroupDefinition[];
export type Expressions = Expression[];
export type Dimension = "AZ" | "INSTANCE_TYPE" | "LINKED_ACCOUNT" | "OPERATION" | "PURCHASE_TYPE" | "REGION" | "SERVICE" | "USAGE_TYPE" | "USAGE_TYPE_GROUP" | "RECORD_TYPE" | "RESOURCE_ID" | "SUBSCRIPTION_ID" | "TAG_KEY" | "OPERATING_SYSTEM" | "TENANCY" | "BILLING_ENTITY" | "RESERVATION_ID" | "COST_CATEGORY_NAME" | "DATABASE_ENGINE" | "LEGAL_ENTITY_NAME" | "SAVINGS_PLANS_TYPE" | "INSTANCE_TYPE_FAMILY" | "CACHE_ENGINE" | "DEPLOYMENT_OPTION" | "SCOPE" | "PLATFORM" | (string & {});
export type StringList = string[];
export type MatchOption = "EQUALS" | "ABSENT" | "STARTS_WITH" | "ENDS_WITH" | "CONTAINS" | "GREATER_THAN_OR_EQUAL" | "CASE_SENSITIVE" | "CASE_INSENSITIVE" | (string & {});
export type MatchOptions = MatchOption[];
export interface DimensionValues {
    key: Dimension;
    values: string[];
    matchOptions?: MatchOption[];
}
export interface TagValues {
    key?: string;
    values?: string[];
    matchOptions?: MatchOption[];
}
export interface CostCategoryValues {
    key?: string;
    values?: string[];
    matchOptions?: MatchOption[];
}
export interface Expression {
    or?: Expression[];
    and?: Expression[];
    not?: Expression;
    dimensions?: DimensionValues;
    tags?: TagValues;
    costCategories?: CostCategoryValues;
}
export interface CostAndUsageQuery {
    metrics: MetricName[];
    timeRange: DateTimeRange;
    granularity: Granularity;
    groupBy?: GroupDefinition[];
    filter?: Expression;
}
export interface SavingsPlansCoverageQuery {
    timeRange: DateTimeRange;
    metrics?: MetricName[];
    granularity?: Granularity;
    groupBy?: GroupDefinition[];
    filter?: Expression;
}
export interface SavingsPlansUtilizationQuery {
    timeRange: DateTimeRange;
    granularity?: Granularity;
    filter?: Expression;
}
export interface ReservationCoverageQuery {
    timeRange: DateTimeRange;
    groupBy?: GroupDefinition[];
    granularity?: Granularity;
    filter?: Expression;
    metrics?: MetricName[];
}
export interface ReservationUtilizationQuery {
    timeRange: DateTimeRange;
    groupBy?: GroupDefinition[];
    granularity?: Granularity;
    filter?: Expression;
}
export type QueryParameters = {
    costAndUsage: CostAndUsageQuery;
    savingsPlansCoverage?: never;
    savingsPlansUtilization?: never;
    reservationCoverage?: never;
    reservationUtilization?: never;
} | {
    costAndUsage?: never;
    savingsPlansCoverage: SavingsPlansCoverageQuery;
    savingsPlansUtilization?: never;
    reservationCoverage?: never;
    reservationUtilization?: never;
} | {
    costAndUsage?: never;
    savingsPlansCoverage?: never;
    savingsPlansUtilization: SavingsPlansUtilizationQuery;
    reservationCoverage?: never;
    reservationUtilization?: never;
} | {
    costAndUsage?: never;
    savingsPlansCoverage?: never;
    savingsPlansUtilization?: never;
    reservationCoverage: ReservationCoverageQuery;
    reservationUtilization?: never;
} | {
    costAndUsage?: never;
    savingsPlansCoverage?: never;
    savingsPlansUtilization?: never;
    reservationCoverage?: never;
    reservationUtilization: ReservationUtilizationQuery;
};
export type VisualType = "LINE" | "BAR" | "STACK" | (string & {});
export interface GraphDisplayConfig {
    visualType: VisualType;
}
export type GraphDisplayConfigMap = {
    [key: string]: GraphDisplayConfig | undefined;
};
export interface TableDisplayConfigStruct {
}
export type DisplayConfig = {
    graph: {
        [key: string]: GraphDisplayConfig | undefined;
    };
    table?: never;
} | {
    graph?: never;
    table: TableDisplayConfigStruct;
};
export interface WidgetConfig {
    queryParameters: QueryParameters;
    displayConfig: DisplayConfig;
}
export type WidgetConfigList = WidgetConfig[];
export interface Widget {
    id?: string;
    title: string;
    description?: string;
    width?: number;
    height?: number;
    horizontalOffset?: number;
    configs: WidgetConfig[];
}
export type WidgetList = Widget[];
export type ResourceTagKey = string;
export type ResourceTagValue = string;
export interface ResourceTag {
    key: string;
    value: string;
}
export type ResourceTagList = ResourceTag[];
export interface CreateDashboardRequest {
    name: string;
    description?: string;
    widgets: Widget[];
    resourceTags?: ResourceTag[];
}
export type DashboardArn = string;
export interface CreateDashboardResponse {
    arn: string;
}
export type ScheduledReportName = string;
export type ServiceRoleArn = string;
export interface SchedulePeriod {
    startTime?: Date;
    endTime?: Date;
}
export type ScheduleState = "ENABLED" | "DISABLED" | (string & {});
export interface ScheduleConfig {
    scheduleExpression?: string;
    scheduleExpressionTimeZone?: string;
    schedulePeriod?: SchedulePeriod;
    state?: ScheduleState;
}
export type WidgetIdList = string[];
export interface ScheduledReportInput {
    name: string;
    dashboardArn: string;
    scheduledReportExecutionRoleArn: string;
    scheduleConfig: ScheduleConfig;
    description?: string;
    widgetIds?: string[];
    widgetDateRangeOverride?: DateTimeRange;
}
export type ClientToken = string;
export interface CreateScheduledReportRequest {
    scheduledReport: ScheduledReportInput;
    resourceTags?: ResourceTag[];
    clientToken?: string;
}
export type ScheduledReportArn = string;
export interface CreateScheduledReportResponse {
    arn: string;
}
export interface DeleteDashboardRequest {
    arn: string;
}
export interface DeleteDashboardResponse {
    arn: string;
}
export interface DeleteScheduledReportRequest {
    arn: string;
}
export interface DeleteScheduledReportResponse {
    arn: string;
}
export interface ExecuteScheduledReportRequest {
    arn: string;
    clientToken?: string;
    dryRun?: boolean;
}
export type HealthStatusCode = "HEALTHY" | "UNHEALTHY" | (string & {});
export type StatusReason = "DATA_SOURCE_ACCESS_DENIED" | "EXECUTION_ROLE_ASSUME_FAILED" | "EXECUTION_ROLE_INSUFFICIENT_PERMISSIONS" | "DASHBOARD_NOT_FOUND" | "DASHBOARD_ACCESS_DENIED" | "INTERNAL_FAILURE" | "WIDGET_ID_NOT_FOUND" | (string & {});
export type StatusReasonList = StatusReason[];
export interface HealthStatus {
    statusCode: HealthStatusCode;
    lastRefreshedAt?: Date;
    statusReasons?: StatusReason[];
}
export interface ExecuteScheduledReportResponse {
    healthStatus?: HealthStatus;
    executionTriggered?: boolean;
}
export interface GetDashboardRequest {
    arn: string;
}
export type DashboardType = "CUSTOM" | (string & {});
export interface GetDashboardResponse {
    arn: string;
    name: string;
    description?: string;
    type: DashboardType;
    widgets: Widget[];
    createdAt: Date;
    updatedAt: Date;
}
export interface GetResourcePolicyRequest {
    resourceArn: string;
}
export interface GetResourcePolicyResponse {
    resourceArn: string;
    policyDocument: string;
}
export interface GetScheduledReportRequest {
    arn: string;
}
export interface ScheduledReport {
    arn?: string;
    name: string;
    dashboardArn: string;
    scheduledReportExecutionRoleArn: string;
    scheduleConfig: ScheduleConfig;
    description?: string;
    widgetIds?: string[];
    widgetDateRangeOverride?: DateTimeRange;
    createdAt?: Date;
    updatedAt?: Date;
    lastExecutionAt?: Date;
    healthStatus?: HealthStatus;
}
export interface GetScheduledReportResponse {
    scheduledReport: ScheduledReport;
}
export type MaxResults = number;
export type NextPageToken = string;
export interface ListDashboardsRequest {
    maxResults?: number;
    nextToken?: string;
}
export interface DashboardReference {
    arn: string;
    name: string;
    description?: string;
    type: DashboardType;
    createdAt: Date;
    updatedAt: Date;
}
export type DashboardReferenceList = DashboardReference[];
export interface ListDashboardsResponse {
    dashboards: DashboardReference[];
    nextToken?: string;
}
export interface ListScheduledReportsRequest {
    nextToken?: string;
    maxResults?: number;
}
export interface ScheduledReportSummary {
    arn: string;
    name: string;
    dashboardArn: string;
    scheduleExpression: string;
    state: ScheduleState;
    healthStatus: HealthStatus;
    scheduleExpressionTimeZone?: string;
    widgetIds?: string[];
}
export type ScheduledReportSummaryList = ScheduledReportSummary[];
export interface ListScheduledReportsResponse {
    scheduledReports: ScheduledReportSummary[];
    nextToken?: string;
}
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    resourceTags?: ResourceTag[];
}
export interface TagResourceRequest {
    resourceArn: string;
    resourceTags: ResourceTag[];
}
export interface TagResourceResponse {
}
export type ResourceTagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    resourceTagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateDashboardRequest {
    arn: string;
    name: string;
    description?: string;
    widgets?: Widget[];
}
export interface UpdateDashboardResponse {
    arn: string;
}
export interface UpdateScheduledReportRequest {
    arn: string;
    name?: string;
    description?: string;
    dashboardArn?: string;
    scheduledReportExecutionRoleArn?: string;
    scheduleConfig?: ScheduleConfig;
    widgetIds?: string[];
    widgetDateRangeOverride?: DateTimeRange;
    clearWidgetIds?: boolean;
    clearWidgetDateRangeOverride?: boolean;
}
export interface UpdateScheduledReportResponse {
    arn: string;
}
export type CreateDashboardError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new dashboard that can contain multiple widgets displaying cost and usage data. You can add custom widgets or use predefined widgets, arranging them in your preferred layout.
 */
export declare const createDashboard: API.OperationMethod<CreateDashboardRequest, CreateDashboardResponse, CreateDashboardError, Credentials | HttpClient.HttpClient>;
export type CreateScheduledReportError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new scheduled report for a dashboard. A scheduled report automatically generates and delivers dashboard snapshots on a recurring schedule. Reports are delivered within 15 minutes of the scheduled delivery time.
 */
export declare const createScheduledReport: API.OperationMethod<CreateScheduledReportRequest, CreateScheduledReportResponse, CreateScheduledReportError, Credentials | HttpClient.HttpClient>;
export type DeleteDashboardError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specified dashboard. This action cannot be undone.
 */
export declare const deleteDashboard: API.OperationMethod<DeleteDashboardRequest, DeleteDashboardResponse, DeleteDashboardError, Credentials | HttpClient.HttpClient>;
export type DeleteScheduledReportError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specified scheduled report. This is an irreversible operation.
 */
export declare const deleteScheduledReport: API.OperationMethod<DeleteScheduledReportRequest, DeleteScheduledReportResponse, DeleteScheduledReportError, Credentials | HttpClient.HttpClient>;
export type ExecuteScheduledReportError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Triggers an immediate execution of a scheduled report, outside of its regular schedule. The scheduled report must be in `ENABLED` state. Calling this operation on a `DISABLED` scheduled report returns a `ValidationException`.
 *
 * If a `clientToken` is provided, the service uses it for idempotency. Requests with the same client token will not trigger a new execution within the same minute.
 */
export declare const executeScheduledReport: API.OperationMethod<ExecuteScheduledReportRequest, ExecuteScheduledReportResponse, ExecuteScheduledReportError, Credentials | HttpClient.HttpClient>;
export type GetDashboardError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the configuration and metadata of a specified dashboard, including its widgets and layout settings.
 */
export declare const getDashboard: API.OperationMethod<GetDashboardRequest, GetDashboardResponse, GetDashboardError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the resource-based policy attached to a dashboard, showing sharing configurations and permissions.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetScheduledReportError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the configuration and metadata of a specified scheduled report.
 */
export declare const getScheduledReport: API.OperationMethod<GetScheduledReportRequest, GetScheduledReportResponse, GetScheduledReportError, Credentials | HttpClient.HttpClient>;
export type ListDashboardsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all dashboards in your account.
 */
export declare const listDashboards: API.PaginatedOperationMethod<ListDashboardsRequest, ListDashboardsResponse, ListDashboardsError, Credentials | HttpClient.HttpClient, DashboardReference>;
export type ListScheduledReportsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of scheduled reports in your account.
 */
export declare const listScheduledReports: API.PaginatedOperationMethod<ListScheduledReportsRequest, ListScheduledReportsResponse, ListScheduledReportsError, Credentials | HttpClient.HttpClient, ScheduledReportSummary>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all tags associated with a specified dashboard resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds or updates tags for a specified dashboard resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes specified tags from a dashboard resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDashboardError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing dashboard's properties, including its name, description, and widget configurations.
 */
export declare const updateDashboard: API.OperationMethod<UpdateDashboardRequest, UpdateDashboardResponse, UpdateDashboardError, Credentials | HttpClient.HttpClient>;
export type UpdateScheduledReportError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing scheduled report's properties, including its name, description, schedule configuration, and widget settings. Only the parameters included in the request are updated; all other properties remain unchanged.
 */
export declare const updateScheduledReport: API.OperationMethod<UpdateScheduledReportRequest, UpdateScheduledReportResponse, UpdateScheduledReportError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bcm-dashboards.d.ts.map