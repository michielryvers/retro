import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ExpiredNextTokenException_base: S.TaggedErrorClass<"ExpiredNextTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ExpiredNextTokenException extends /*@__PURE__*/ ExpiredNextTokenException_base {
}
declare const InternalErrorException_base: S.TaggedErrorClass<"InternalErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalErrorException extends /*@__PURE__*/ InternalErrorException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type FormatVersion = string;
export type DescribeServicesMaxResults = number;
export interface DescribeServicesRequest {
    ServiceCode?: string;
    FormatVersion?: string;
    NextToken?: string;
    MaxResults?: number;
}
export type AttributeNameList = string[];
export interface Service {
    ServiceCode: string;
    AttributeNames?: string[];
}
export type ServiceList = Service[];
export interface DescribeServicesResponse {
    Services?: Service[];
    FormatVersion?: string;
    NextToken?: string;
}
export type GetAttributeValuesMaxResults = number;
export interface GetAttributeValuesRequest {
    ServiceCode: string;
    AttributeName: string;
    NextToken?: string;
    MaxResults?: number;
}
export interface AttributeValue {
    Value?: string;
}
export type AttributeValueList = AttributeValue[];
export interface GetAttributeValuesResponse {
    AttributeValues?: AttributeValue[];
    NextToken?: string;
}
export type PriceListArn = string;
export type FileFormat = string;
export interface GetPriceListFileUrlRequest {
    PriceListArn: string;
    FileFormat: string;
}
export interface GetPriceListFileUrlResponse {
    Url?: string;
}
export type FilterType = "TERM_MATCH" | "EQUALS" | "CONTAINS" | "ANY_OF" | "NONE_OF" | (string & {});
export type Field = string;
export type Value = string;
export interface Filter {
    Type: FilterType;
    Field: string;
    Value: string;
}
export type Filters = Filter[];
export type GetProductsMaxResults = number;
export interface GetProductsRequest {
    ServiceCode: string;
    Filters?: Filter[];
    FormatVersion?: string;
    NextToken?: string;
    MaxResults?: number;
}
export type SynthesizedJsonPriceListJsonItem = string;
export type PriceListJsonItems = string[];
export interface GetProductsResponse {
    FormatVersion?: string;
    PriceList?: string[];
    NextToken?: string;
}
export type ServiceCode = string;
export type EffectiveDate = Date;
export type RegionCode = string;
export type CurrencyCode = string;
export type MaxResults = number;
export interface ListPriceListsRequest {
    ServiceCode: string;
    EffectiveDate: Date;
    RegionCode?: string;
    CurrencyCode: string;
    NextToken?: string;
    MaxResults?: number;
}
export type FileFormats = string[];
export interface PriceList {
    PriceListArn?: string;
    RegionCode?: string;
    CurrencyCode?: string;
    FileFormats?: string[];
}
export type PriceLists = PriceList[];
export interface ListPriceListsResponse {
    PriceLists?: PriceList[];
    NextToken?: string;
}
export type ErrorMessage = string;
export type DescribeServicesError = AccessDeniedException | ExpiredNextTokenException | InternalErrorException | InvalidNextTokenException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns the metadata for one service or a list of the metadata for all services. Use this without a service code to get the service codes for all services. Use it with a service code, such as `AmazonEC2`, to get information specific to that service, such as the attribute names available for that service. For example, some of the attribute names available for EC2 are `volumeType`, `maxIopsVolume`, `operation`, `locationType`, and `instanceCapacity10xlarge`.
 */
export declare const describeServices: API.PaginatedOperationMethod<DescribeServicesRequest, DescribeServicesResponse, DescribeServicesError, Credentials | HttpClient.HttpClient, Service>;
export type GetAttributeValuesError = AccessDeniedException | ExpiredNextTokenException | InternalErrorException | InvalidNextTokenException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of attribute values. Attributes are similar to the details in a Price List API offer file. For a list of available attributes, see Offer File Definitions in the Billing and Cost Management User Guide.
 */
export declare const getAttributeValues: API.PaginatedOperationMethod<GetAttributeValuesRequest, GetAttributeValuesResponse, GetAttributeValuesError, Credentials | HttpClient.HttpClient, AttributeValue>;
export type GetPriceListFileUrlError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * * **This feature is in preview release and is subject to change. Your use of Amazon Web Services Price List API is subject to the Beta Service Participation terms of the Amazon Web Services Service Terms (Section 1.10).** *
 *
 * This returns the URL that you can retrieve your Price List file from. This URL is based on the `PriceListArn` and `FileFormat` that you retrieve from the ListPriceLists response.
 */
export declare const getPriceListFileUrl: API.OperationMethod<GetPriceListFileUrlRequest, GetPriceListFileUrlResponse, GetPriceListFileUrlError, Credentials | HttpClient.HttpClient>;
export type GetProductsError = AccessDeniedException | ExpiredNextTokenException | InternalErrorException | InvalidNextTokenException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of all products that match the filter criteria.
 */
export declare const getProducts: API.PaginatedOperationMethod<GetProductsRequest, GetProductsResponse, GetProductsError, Credentials | HttpClient.HttpClient, SynthesizedJsonPriceListJsonItem>;
export type ListPriceListsError = AccessDeniedException | ExpiredNextTokenException | InternalErrorException | InvalidNextTokenException | InvalidParameterException | NotFoundException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * * **This feature is in preview release and is subject to change. Your use of Amazon Web Services Price List API is subject to the Beta Service Participation terms of the Amazon Web Services Service Terms (Section 1.10).** *
 *
 * This returns a list of Price List references that the requester if authorized to view, given a `ServiceCode`, `CurrencyCode`, and an `EffectiveDate`. Use without a `RegionCode` filter to list Price List references from all available Amazon Web Services Regions. Use with a `RegionCode` filter to get the Price List reference that's specific to a specific Amazon Web Services Region. You can use the `PriceListArn` from the response to get your preferred Price List files through the GetPriceListFileUrl API.
 */
export declare const listPriceLists: API.PaginatedOperationMethod<ListPriceListsRequest, ListPriceListsResponse, ListPriceListsError, Credentials | HttpClient.HttpClient, PriceList>;
export {};
//# sourceMappingURL=pricing.d.ts.map