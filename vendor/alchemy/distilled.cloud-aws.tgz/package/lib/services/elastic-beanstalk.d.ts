import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const CodeBuildNotInServiceRegionException_base: S.TaggedErrorClass<"CodeBuildNotInServiceRegionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CodeBuildNotInServiceRegionException extends /*@__PURE__*/ CodeBuildNotInServiceRegionException_base {
}
declare const ElasticBeanstalkServiceException_base: S.TaggedErrorClass<"ElasticBeanstalkServiceException", {
    readonly message: any;
}>;
export declare class ElasticBeanstalkServiceException extends /*@__PURE__*/ ElasticBeanstalkServiceException_base {
}
declare const InsufficientPrivilegesException_base: S.TaggedErrorClass<"InsufficientPrivilegesException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class InsufficientPrivilegesException extends /*@__PURE__*/ InsufficientPrivilegesException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const ManagedActionInvalidStateException_base: S.TaggedErrorClass<"ManagedActionInvalidStateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ManagedActionInvalidStateException extends /*@__PURE__*/ ManagedActionInvalidStateException_base {
}
declare const OperationInProgressException_base: S.TaggedErrorClass<"OperationInProgressException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OperationInProgressException extends /*@__PURE__*/ OperationInProgressException_base {
}
declare const PlatformVersionStillReferencedException_base: S.TaggedErrorClass<"PlatformVersionStillReferencedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PlatformVersionStillReferencedException extends /*@__PURE__*/ PlatformVersionStillReferencedException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceTypeNotSupportedException_base: S.TaggedErrorClass<"ResourceTypeNotSupportedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceTypeNotSupportedException extends /*@__PURE__*/ ResourceTypeNotSupportedException_base {
}
declare const S3LocationNotInServiceRegionException_base: S.TaggedErrorClass<"S3LocationNotInServiceRegionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class S3LocationNotInServiceRegionException extends /*@__PURE__*/ S3LocationNotInServiceRegionException_base {
}
declare const S3SubscriptionRequiredException_base: S.TaggedErrorClass<"S3SubscriptionRequiredException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class S3SubscriptionRequiredException extends /*@__PURE__*/ S3SubscriptionRequiredException_base {
}
declare const SourceBundleDeletionException_base: S.TaggedErrorClass<"SourceBundleDeletionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SourceBundleDeletionException extends /*@__PURE__*/ SourceBundleDeletionException_base {
}
declare const TooManyApplicationsException_base: S.TaggedErrorClass<"TooManyApplicationsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyApplicationsException extends /*@__PURE__*/ TooManyApplicationsException_base {
}
declare const TooManyApplicationVersionsException_base: S.TaggedErrorClass<"TooManyApplicationVersionsException", {
    readonly message: any;
}>;
export declare class TooManyApplicationVersionsException extends /*@__PURE__*/ TooManyApplicationVersionsException_base {
}
declare const TooManyBucketsException_base: S.TaggedErrorClass<"TooManyBucketsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyBucketsException extends /*@__PURE__*/ TooManyBucketsException_base {
}
declare const TooManyConfigurationTemplatesException_base: S.TaggedErrorClass<"TooManyConfigurationTemplatesException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyConfigurationTemplatesException extends /*@__PURE__*/ TooManyConfigurationTemplatesException_base {
}
declare const TooManyEnvironmentsException_base: S.TaggedErrorClass<"TooManyEnvironmentsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyEnvironmentsException extends /*@__PURE__*/ TooManyEnvironmentsException_base {
}
declare const TooManyPlatformsException_base: S.TaggedErrorClass<"TooManyPlatformsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyPlatformsException extends /*@__PURE__*/ TooManyPlatformsException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
export type EnvironmentId = string;
export type EnvironmentName = string;
export interface AbortEnvironmentUpdateMessage {
    EnvironmentId?: string;
    EnvironmentName?: string;
}
export interface AbortEnvironmentUpdateResponse {
}
export interface ApplyEnvironmentManagedActionRequest {
    EnvironmentName?: string;
    EnvironmentId?: string;
    ActionId: string;
}
export type ActionType = "InstanceRefresh" | "PlatformUpdate" | "Unknown" | (string & {});
export interface ApplyEnvironmentManagedActionResult {
    ActionId?: string;
    ActionDescription?: string;
    ActionType?: ActionType;
    Status?: string;
}
export type OperationsRole = string;
export interface AssociateEnvironmentOperationsRoleMessage {
    EnvironmentName: string;
    OperationsRole: string;
}
export interface AssociateEnvironmentOperationsRoleResponse {
}
export type DNSCnamePrefix = string;
export interface CheckDNSAvailabilityMessage {
    CNAMEPrefix: string;
}
export type CnameAvailability = boolean;
export type DNSCname = string;
export interface CheckDNSAvailabilityResultMessage {
    Available?: boolean;
    FullyQualifiedCNAME?: string;
}
export type ApplicationName = string;
export type GroupName = string;
export type VersionLabel = string;
export type VersionLabels = string[];
export interface ComposeEnvironmentsMessage {
    ApplicationName?: string;
    GroupName?: string;
    VersionLabels?: string[];
}
export type SolutionStackName = string;
export type PlatformArn = string;
export type ConfigurationTemplateName = string;
export type Description = string;
export type EndpointURL = string;
export type CreationDate = Date;
export type UpdateDate = Date;
export type EnvironmentStatus = "Aborting" | "Launching" | "Updating" | "LinkingFrom" | "LinkingTo" | "Ready" | "Terminating" | "Terminated" | (string & {});
export type AbortableOperationInProgress = boolean;
export type EnvironmentHealth = "Green" | "Yellow" | "Red" | "Grey" | (string & {});
export type EnvironmentHealthStatus = "NoData" | "Unknown" | "Pending" | "Ok" | "Info" | "Warning" | "Degraded" | "Severe" | "Suspended" | (string & {});
export interface Listener {
    Protocol?: string;
    Port?: number;
}
export type LoadBalancerListenersDescription = Listener[];
export interface LoadBalancerDescription {
    LoadBalancerName?: string;
    Domain?: string;
    Listeners?: Listener[];
}
export interface EnvironmentResourcesDescription {
    LoadBalancer?: LoadBalancerDescription;
}
export interface EnvironmentTier {
    Name?: string;
    Type?: string;
    Version?: string;
}
export interface EnvironmentLink {
    LinkName?: string;
    EnvironmentName?: string;
}
export type EnvironmentLinks = EnvironmentLink[];
export type EnvironmentArn = string;
export interface EnvironmentDescription {
    EnvironmentName?: string;
    EnvironmentId?: string;
    ApplicationName?: string;
    VersionLabel?: string;
    SolutionStackName?: string;
    PlatformArn?: string;
    TemplateName?: string;
    Description?: string;
    EndpointURL?: string;
    CNAME?: string;
    DateCreated?: Date;
    DateUpdated?: Date;
    Status?: EnvironmentStatus;
    AbortableOperationInProgress?: boolean;
    Health?: EnvironmentHealth;
    HealthStatus?: EnvironmentHealthStatus;
    Resources?: EnvironmentResourcesDescription;
    Tier?: EnvironmentTier;
    EnvironmentLinks?: EnvironmentLink[];
    EnvironmentArn?: string;
    OperationsRole?: string;
}
export type EnvironmentDescriptionsList = EnvironmentDescription[];
export type Token = string;
export interface EnvironmentDescriptionsMessage {
    Environments?: EnvironmentDescription[];
    NextToken?: string;
}
export type BoxedBoolean = boolean;
export type BoxedInt = number;
export interface MaxCountRule {
    Enabled: boolean;
    MaxCount?: number;
    DeleteSourceFromS3?: boolean;
}
export interface MaxAgeRule {
    Enabled: boolean;
    MaxAgeInDays?: number;
    DeleteSourceFromS3?: boolean;
}
export interface ApplicationVersionLifecycleConfig {
    MaxCountRule?: MaxCountRule;
    MaxAgeRule?: MaxAgeRule;
}
export interface ApplicationResourceLifecycleConfig {
    ServiceRole?: string;
    VersionLifecycleConfig?: ApplicationVersionLifecycleConfig;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string;
    Value?: string;
}
export type Tags = Tag[];
export interface CreateApplicationMessage {
    ApplicationName: string;
    Description?: string;
    ResourceLifecycleConfig?: ApplicationResourceLifecycleConfig;
    Tags?: Tag[];
}
export type ApplicationArn = string;
export type VersionLabelsList = string[];
export type ConfigurationTemplateNamesList = string[];
export interface ApplicationDescription {
    ApplicationArn?: string;
    ApplicationName?: string;
    Description?: string;
    DateCreated?: Date;
    DateUpdated?: Date;
    Versions?: string[];
    ConfigurationTemplates?: string[];
    ResourceLifecycleConfig?: ApplicationResourceLifecycleConfig;
}
export interface ApplicationDescriptionMessage {
    Application?: ApplicationDescription;
}
export type SourceType = "Git" | "Zip" | (string & {});
export type SourceRepository = "CodeCommit" | "S3" | (string & {});
export type SourceLocation = string;
export interface SourceBuildInformation {
    SourceType: SourceType;
    SourceRepository: SourceRepository;
    SourceLocation: string;
}
export type S3Bucket = string;
export type S3Key = string;
export interface S3Location {
    S3Bucket?: string;
    S3Key?: string;
}
export type NonEmptyString = string;
export type ComputeType = "BUILD_GENERAL1_SMALL" | "BUILD_GENERAL1_MEDIUM" | "BUILD_GENERAL1_LARGE" | (string & {});
export interface BuildConfiguration {
    ArtifactName?: string;
    CodeBuildServiceRole: string;
    ComputeType?: ComputeType;
    Image: string;
    TimeoutInMinutes?: number;
}
export type AutoCreateApplication = boolean;
export type ApplicationVersionProccess = boolean;
export interface ImageSource {
    Uri?: string;
}
export type ImageBuildType = "docker" | "buildpack" | (string & {});
export type ArchitectureType = "amd64" | "arm64" | (string & {});
export interface ImageBuildConfiguration {
    Type?: ImageBuildType;
    DockerfileLocation?: string;
    Buildpack?: string;
    Architecture?: ArchitectureType;
    CodeBuildServiceRole?: string;
    ComputeType?: ComputeType;
    TimeoutInMinutes?: number;
}
export interface ImageConfiguration {
    Source?: ImageSource;
    Build?: ImageBuildConfiguration;
}
export interface CreateApplicationVersionMessage {
    ApplicationName: string;
    VersionLabel: string;
    Description?: string;
    SourceBuildInformation?: SourceBuildInformation;
    SourceBundle?: S3Location;
    BuildConfiguration?: BuildConfiguration;
    AutoCreateApplication?: boolean;
    Process?: boolean;
    Tags?: Tag[];
    ImageConfiguration?: ImageConfiguration;
}
export type ApplicationVersionArn = string;
export type ApplicationVersionStatus = "Processed" | "Unprocessed" | "Failed" | "Processing" | "Building" | (string & {});
export interface ApplicationVersionDescription {
    ApplicationVersionArn?: string;
    ApplicationName?: string;
    Description?: string;
    VersionLabel?: string;
    SourceBuildInformation?: SourceBuildInformation;
    BuildArn?: string;
    SourceBundle?: S3Location;
    ImageSource?: ImageSource;
    ImageBuildConfiguration?: ImageBuildConfiguration;
    Process?: boolean;
    DateCreated?: Date;
    DateUpdated?: Date;
    Status?: ApplicationVersionStatus;
}
export interface ApplicationVersionDescriptionMessage {
    ApplicationVersion?: ApplicationVersionDescription;
}
export interface SourceConfiguration {
    ApplicationName?: string;
    TemplateName?: string;
}
export type ResourceName = string;
export type OptionNamespace = string;
export type ConfigurationOptionName = string;
export type ConfigurationOptionValue = string;
export interface ConfigurationOptionSetting {
    ResourceName?: string;
    Namespace?: string;
    OptionName?: string;
    Value?: string;
}
export type ConfigurationOptionSettingsList = ConfigurationOptionSetting[];
export interface CreateConfigurationTemplateMessage {
    ApplicationName: string;
    TemplateName: string;
    SolutionStackName?: string;
    PlatformArn?: string;
    SourceConfiguration?: SourceConfiguration;
    EnvironmentId?: string;
    Description?: string;
    OptionSettings?: ConfigurationOptionSetting[];
    Tags?: Tag[];
}
export type ConfigurationDeploymentStatus = "deployed" | "pending" | "failed" | (string & {});
export interface ConfigurationSettingsDescription {
    SolutionStackName?: string;
    PlatformArn?: string;
    ApplicationName?: string;
    TemplateName?: string;
    Description?: string;
    EnvironmentName?: string;
    DeploymentStatus?: ConfigurationDeploymentStatus;
    DateCreated?: Date;
    DateUpdated?: Date;
    OptionSettings?: ConfigurationOptionSetting[];
}
export interface OptionSpecification {
    ResourceName?: string;
    Namespace?: string;
    OptionName?: string;
}
export type OptionsSpecifierList = OptionSpecification[];
export interface CreateEnvironmentMessage {
    ApplicationName: string;
    EnvironmentName?: string;
    GroupName?: string;
    Description?: string;
    CNAMEPrefix?: string;
    Tier?: EnvironmentTier;
    Tags?: Tag[];
    VersionLabel?: string;
    TemplateName?: string;
    SolutionStackName?: string;
    PlatformArn?: string;
    OptionSettings?: ConfigurationOptionSetting[];
    OptionsToRemove?: OptionSpecification[];
    OperationsRole?: string;
}
export type PlatformName = string;
export type PlatformVersion = string;
export interface CreatePlatformVersionRequest {
    PlatformName: string;
    PlatformVersion: string;
    PlatformDefinitionBundle: S3Location;
    EnvironmentName?: string;
    OptionSettings?: ConfigurationOptionSetting[];
    Tags?: Tag[];
}
export type PlatformOwner = string;
export type PlatformStatus = "Creating" | "Failed" | "Ready" | "Deleting" | "Deleted" | (string & {});
export type PlatformCategory = string;
export type OperatingSystemName = string;
export type OperatingSystemVersion = string;
export type SupportedTier = string;
export type SupportedTierList = string[];
export type SupportedAddon = string;
export type SupportedAddonList = string[];
export type PlatformLifecycleState = string;
export type BranchName = string;
export type PlatformBranchLifecycleState = string;
export interface PlatformSummary {
    PlatformArn?: string;
    PlatformOwner?: string;
    PlatformStatus?: PlatformStatus;
    PlatformCategory?: string;
    OperatingSystemName?: string;
    OperatingSystemVersion?: string;
    SupportedTierList?: string[];
    SupportedAddonList?: string[];
    PlatformLifecycleState?: string;
    PlatformVersion?: string;
    PlatformBranchName?: string;
    PlatformBranchLifecycleState?: string;
}
export type ARN = string;
export interface Builder {
    ARN?: string;
}
export interface CreatePlatformVersionResult {
    PlatformSummary?: PlatformSummary;
    Builder?: Builder;
}
export interface CreateStorageLocationRequest {
}
export interface CreateStorageLocationResultMessage {
    S3Bucket?: string;
}
export type TerminateEnvForce = boolean;
export interface DeleteApplicationMessage {
    ApplicationName: string;
    TerminateEnvByForce?: boolean;
}
export interface DeleteApplicationResponse {
}
export type DeleteSourceBundle = boolean;
export interface DeleteApplicationVersionMessage {
    ApplicationName: string;
    VersionLabel: string;
    DeleteSourceBundle?: boolean;
}
export interface DeleteApplicationVersionResponse {
}
export interface DeleteConfigurationTemplateMessage {
    ApplicationName: string;
    TemplateName: string;
}
export interface DeleteConfigurationTemplateResponse {
}
export interface DeleteEnvironmentConfigurationMessage {
    ApplicationName: string;
    EnvironmentName: string;
}
export interface DeleteEnvironmentConfigurationResponse {
}
export interface DeletePlatformVersionRequest {
    PlatformArn?: string;
}
export interface DeletePlatformVersionResult {
    PlatformSummary?: PlatformSummary;
}
export interface DescribeAccountAttributesRequest {
}
export interface ResourceQuota {
    Maximum?: number;
}
export interface ResourceQuotas {
    ApplicationQuota?: ResourceQuota;
    ApplicationVersionQuota?: ResourceQuota;
    EnvironmentQuota?: ResourceQuota;
    ConfigurationTemplateQuota?: ResourceQuota;
    CustomPlatformQuota?: ResourceQuota;
}
export interface DescribeAccountAttributesResult {
    ResourceQuotas?: ResourceQuotas;
}
export type ApplicationNamesList = string[];
export interface DescribeApplicationsMessage {
    ApplicationNames?: string[];
}
export type ApplicationDescriptionList = ApplicationDescription[];
export interface ApplicationDescriptionsMessage {
    Applications?: ApplicationDescription[];
}
export type MaxRecords = number;
export interface DescribeApplicationVersionsMessage {
    ApplicationName?: string;
    VersionLabels?: string[];
    MaxRecords?: number;
    NextToken?: string;
}
export type ApplicationVersionDescriptionList = ApplicationVersionDescription[];
export interface ApplicationVersionDescriptionsMessage {
    ApplicationVersions?: ApplicationVersionDescription[];
    NextToken?: string;
}
export interface DescribeConfigurationOptionsMessage {
    ApplicationName?: string;
    TemplateName?: string;
    EnvironmentName?: string;
    SolutionStackName?: string;
    PlatformArn?: string;
    Options?: OptionSpecification[];
}
export type ConfigurationOptionDefaultValue = string;
export type ConfigurationOptionSeverity = string;
export type UserDefinedOption = boolean;
export type ConfigurationOptionValueType = "Scalar" | "List" | (string & {});
export type ConfigurationOptionPossibleValue = string;
export type ConfigurationOptionPossibleValues = string[];
export type OptionRestrictionMinValue = number;
export type OptionRestrictionMaxValue = number;
export type OptionRestrictionMaxLength = number;
export type RegexPattern = string;
export type RegexLabel = string;
export interface OptionRestrictionRegex {
    Pattern?: string;
    Label?: string;
}
export interface ConfigurationOptionDescription {
    Namespace?: string;
    Name?: string;
    DefaultValue?: string;
    ChangeSeverity?: string;
    UserDefined?: boolean;
    ValueType?: ConfigurationOptionValueType;
    ValueOptions?: string[];
    MinValue?: number;
    MaxValue?: number;
    MaxLength?: number;
    Regex?: OptionRestrictionRegex;
}
export type ConfigurationOptionDescriptionsList = ConfigurationOptionDescription[];
export interface ConfigurationOptionsDescription {
    SolutionStackName?: string;
    PlatformArn?: string;
    Options?: ConfigurationOptionDescription[];
}
export interface DescribeConfigurationSettingsMessage {
    ApplicationName: string;
    TemplateName?: string;
    EnvironmentName?: string;
}
export type ConfigurationSettingsDescriptionList = ConfigurationSettingsDescription[];
export interface ConfigurationSettingsDescriptions {
    ConfigurationSettings?: ConfigurationSettingsDescription[];
}
export type EnvironmentHealthAttribute = "Status" | "Color" | "Causes" | "ApplicationMetrics" | "InstancesHealth" | "All" | "HealthStatus" | "RefreshedAt" | (string & {});
export type EnvironmentHealthAttributes = EnvironmentHealthAttribute[];
export interface DescribeEnvironmentHealthRequest {
    EnvironmentName?: string;
    EnvironmentId?: string;
    AttributeNames?: EnvironmentHealthAttribute[];
}
export type Cause = string;
export type Causes = string[];
export type RequestCount = number;
export interface StatusCodes {
    Status2xx?: number;
    Status3xx?: number;
    Status4xx?: number;
    Status5xx?: number;
}
export interface Latency {
    P999?: number;
    P99?: number;
    P95?: number;
    P90?: number;
    P85?: number;
    P75?: number;
    P50?: number;
    P10?: number;
}
export interface ApplicationMetrics {
    Duration?: number;
    RequestCount?: number;
    StatusCodes?: StatusCodes;
    Latency?: Latency;
}
export interface InstanceHealthSummary {
    NoData?: number;
    Unknown?: number;
    Pending?: number;
    Ok?: number;
    Info?: number;
    Warning?: number;
    Degraded?: number;
    Severe?: number;
}
export type RefreshedAt = Date;
export interface DescribeEnvironmentHealthResult {
    EnvironmentName?: string;
    HealthStatus?: string;
    Status?: EnvironmentHealth;
    Color?: string;
    Causes?: string[];
    ApplicationMetrics?: ApplicationMetrics;
    InstancesHealth?: InstanceHealthSummary;
    RefreshedAt?: Date;
}
export type ManagedActionHistoryMaxItems = number;
export interface DescribeEnvironmentManagedActionHistoryRequest {
    EnvironmentId?: string;
    EnvironmentName?: string;
    NextToken?: string;
    MaxItems?: number;
}
export type FailureType = "UpdateCancelled" | "CancellationFailed" | "RollbackFailed" | "RollbackSuccessful" | "InternalFailure" | "InvalidEnvironmentState" | "PermissionsError" | (string & {});
export type ActionHistoryStatus = "Completed" | "Failed" | "Unknown" | (string & {});
export interface ManagedActionHistoryItem {
    ActionId?: string;
    ActionType?: ActionType;
    ActionDescription?: string;
    FailureType?: FailureType;
    Status?: ActionHistoryStatus;
    FailureDescription?: string;
    ExecutedTime?: Date;
    FinishedTime?: Date;
}
export type ManagedActionHistoryItems = ManagedActionHistoryItem[];
export interface DescribeEnvironmentManagedActionHistoryResult {
    ManagedActionHistoryItems?: ManagedActionHistoryItem[];
    NextToken?: string;
}
export type ActionStatus = "Scheduled" | "Pending" | "Running" | "Unknown" | (string & {});
export interface DescribeEnvironmentManagedActionsRequest {
    EnvironmentName?: string;
    EnvironmentId?: string;
    Status?: ActionStatus;
}
export interface ManagedAction {
    ActionId?: string;
    ActionDescription?: string;
    ActionType?: ActionType;
    Status?: ActionStatus;
    WindowStartTime?: Date;
}
export type ManagedActions = ManagedAction[];
export interface DescribeEnvironmentManagedActionsResult {
    ManagedActions?: ManagedAction[];
}
export interface DescribeEnvironmentResourcesMessage {
    EnvironmentId?: string;
    EnvironmentName?: string;
}
export type ResourceId = string;
export interface AutoScalingGroup {
    Name?: string;
}
export type AutoScalingGroupList = AutoScalingGroup[];
export interface Cluster {
    ClusterArn?: string;
}
export interface Instance {
    Id?: string;
}
export type InstanceList = Instance[];
export interface LaunchConfiguration {
    Name?: string;
}
export type LaunchConfigurationList = LaunchConfiguration[];
export interface LaunchTemplate {
    Id?: string;
}
export type LaunchTemplateList = LaunchTemplate[];
export interface LoadBalancer {
    Name?: string;
}
export type LoadBalancerList = LoadBalancer[];
export interface Trigger {
    Name?: string;
}
export type TriggerList = Trigger[];
export interface Queue {
    Name?: string;
    URL?: string;
}
export type QueueList = Queue[];
export interface EnvironmentResourceDescription {
    EnvironmentName?: string;
    AutoScalingGroups?: AutoScalingGroup[];
    Cluster?: Cluster;
    Instances?: Instance[];
    LaunchConfigurations?: LaunchConfiguration[];
    LaunchTemplates?: LaunchTemplate[];
    LoadBalancers?: LoadBalancer[];
    Triggers?: Trigger[];
    Queues?: Queue[];
}
export interface EnvironmentResourceDescriptionsMessage {
    EnvironmentResources?: EnvironmentResourceDescription;
}
export type EnvironmentIdList = string[];
export type EnvironmentNamesList = string[];
export type IncludeDeleted = boolean;
export type IncludeDeletedBackTo = Date;
export interface DescribeEnvironmentsMessage {
    ApplicationName?: string;
    VersionLabel?: string;
    EnvironmentIds?: string[];
    EnvironmentNames?: string[];
    IncludeDeleted?: boolean;
    IncludedDeletedBackTo?: Date;
    MaxRecords?: number;
    NextToken?: string;
}
export type RequestId = string;
export type EventSeverity = "TRACE" | "DEBUG" | "INFO" | "WARN" | "ERROR" | "FATAL" | (string & {});
export type TimeFilterStart = Date;
export type TimeFilterEnd = Date;
export interface DescribeEventsMessage {
    ApplicationName?: string;
    VersionLabel?: string;
    TemplateName?: string;
    EnvironmentId?: string;
    EnvironmentName?: string;
    PlatformArn?: string;
    RequestId?: string;
    Severity?: EventSeverity;
    StartTime?: Date;
    EndTime?: Date;
    MaxRecords?: number;
    NextToken?: string;
}
export type EventDate = Date;
export type EventMessage = string;
export interface EventDescription {
    EventDate?: Date;
    Message?: string;
    ApplicationName?: string;
    VersionLabel?: string;
    TemplateName?: string;
    EnvironmentName?: string;
    PlatformArn?: string;
    RequestId?: string;
    Severity?: EventSeverity;
}
export type EventDescriptionList = EventDescription[];
export interface EventDescriptionsMessage {
    Events?: EventDescription[];
    NextToken?: string;
}
export type InstancesHealthAttribute = "HealthStatus" | "Color" | "Causes" | "ApplicationMetrics" | "RefreshedAt" | "LaunchedAt" | "System" | "Deployment" | "AvailabilityZone" | "InstanceType" | "All" | (string & {});
export type InstancesHealthAttributes = InstancesHealthAttribute[];
export type NextToken = string;
export interface DescribeInstancesHealthRequest {
    EnvironmentName?: string;
    EnvironmentId?: string;
    AttributeNames?: InstancesHealthAttribute[];
    NextToken?: string;
}
export type InstanceId = string;
export type LaunchedAt = Date;
export interface CPUUtilization {
    User?: number;
    Nice?: number;
    System?: number;
    Idle?: number;
    IOWait?: number;
    IRQ?: number;
    SoftIRQ?: number;
    Privileged?: number;
}
export type LoadAverageValue = number;
export type LoadAverage = number[];
export interface SystemStatus {
    CPUUtilization?: CPUUtilization;
    LoadAverage?: number[];
}
export type DeploymentTimestamp = Date;
export interface Deployment {
    VersionLabel?: string;
    DeploymentId?: number;
    Status?: string;
    DeploymentTime?: Date;
}
export interface SingleInstanceHealth {
    InstanceId?: string;
    HealthStatus?: string;
    Color?: string;
    Causes?: string[];
    LaunchedAt?: Date;
    ApplicationMetrics?: ApplicationMetrics;
    System?: SystemStatus;
    Deployment?: Deployment;
    AvailabilityZone?: string;
    InstanceType?: string;
}
export type InstanceHealthList = SingleInstanceHealth[];
export interface DescribeInstancesHealthResult {
    InstanceHealthList?: SingleInstanceHealth[];
    RefreshedAt?: Date;
    NextToken?: string;
}
export interface DescribePlatformVersionRequest {
    PlatformArn?: string;
}
export type Maintainer = string;
export interface PlatformProgrammingLanguage {
    Name?: string;
    Version?: string;
}
export type PlatformProgrammingLanguages = PlatformProgrammingLanguage[];
export interface PlatformFramework {
    Name?: string;
    Version?: string;
}
export type PlatformFrameworks = PlatformFramework[];
export type VirtualizationType = string;
export type ImageId = string;
export interface CustomAmi {
    VirtualizationType?: string;
    ImageId?: string;
}
export type CustomAmiList = CustomAmi[];
export interface PlatformDescription {
    PlatformArn?: string;
    PlatformOwner?: string;
    PlatformName?: string;
    PlatformVersion?: string;
    SolutionStackName?: string;
    PlatformStatus?: PlatformStatus;
    DateCreated?: Date;
    DateUpdated?: Date;
    PlatformCategory?: string;
    Description?: string;
    Maintainer?: string;
    OperatingSystemName?: string;
    OperatingSystemVersion?: string;
    ProgrammingLanguages?: PlatformProgrammingLanguage[];
    Frameworks?: PlatformFramework[];
    CustomAmiList?: CustomAmi[];
    SupportedTierList?: string[];
    SupportedAddonList?: string[];
    PlatformLifecycleState?: string;
    PlatformBranchName?: string;
    PlatformBranchLifecycleState?: string;
}
export interface DescribePlatformVersionResult {
    PlatformDescription?: PlatformDescription;
}
export interface DisassociateEnvironmentOperationsRoleMessage {
    EnvironmentName: string;
}
export interface DisassociateEnvironmentOperationsRoleResponse {
}
export interface ListAvailableSolutionStacksRequest {
}
export type AvailableSolutionStackNamesList = string[];
export type FileTypeExtension = string;
export type SolutionStackFileTypeList = string[];
export interface SolutionStackDescription {
    SolutionStackName?: string;
    PermittedFileTypes?: string[];
}
export type AvailableSolutionStackDetailsList = SolutionStackDescription[];
export interface ListAvailableSolutionStacksResultMessage {
    SolutionStacks?: string[];
    SolutionStackDetails?: SolutionStackDescription[];
}
export type SearchFilterAttribute = string;
export type SearchFilterOperator = string;
export type SearchFilterValue = string;
export type SearchFilterValues = string[];
export interface SearchFilter {
    Attribute?: string;
    Operator?: string;
    Values?: string[];
}
export type SearchFilters = SearchFilter[];
export type PlatformBranchMaxRecords = number;
export interface ListPlatformBranchesRequest {
    Filters?: SearchFilter[];
    MaxRecords?: number;
    NextToken?: string;
}
export type BranchOrder = number;
export interface PlatformBranchSummary {
    PlatformName?: string;
    BranchName?: string;
    LifecycleState?: string;
    BranchOrder?: number;
    SupportedTierList?: string[];
}
export type PlatformBranchSummaryList = PlatformBranchSummary[];
export interface ListPlatformBranchesResult {
    PlatformBranchSummaryList?: PlatformBranchSummary[];
    NextToken?: string;
}
export type PlatformFilterType = string;
export type PlatformFilterOperator = string;
export type PlatformFilterValue = string;
export type PlatformFilterValueList = string[];
export interface PlatformFilter {
    Type?: string;
    Operator?: string;
    Values?: string[];
}
export type PlatformFilters = PlatformFilter[];
export type PlatformMaxRecords = number;
export interface ListPlatformVersionsRequest {
    Filters?: PlatformFilter[];
    MaxRecords?: number;
    NextToken?: string;
}
export type PlatformSummaryList = PlatformSummary[];
export interface ListPlatformVersionsResult {
    PlatformSummaryList?: PlatformSummary[];
    NextToken?: string;
}
export type ResourceArn = string;
export interface ListTagsForResourceMessage {
    ResourceArn: string;
}
export type TagList = Tag[];
export interface ResourceTagsDescriptionMessage {
    ResourceArn?: string;
    ResourceTags?: Tag[];
}
export interface RebuildEnvironmentMessage {
    EnvironmentId?: string;
    EnvironmentName?: string;
}
export interface RebuildEnvironmentResponse {
}
export type EnvironmentInfoType = "tail" | "bundle" | "analyze" | (string & {});
export interface RequestEnvironmentInfoMessage {
    EnvironmentId?: string;
    EnvironmentName?: string;
    InfoType: EnvironmentInfoType;
}
export interface RequestEnvironmentInfoResponse {
}
export interface RestartAppServerMessage {
    EnvironmentId?: string;
    EnvironmentName?: string;
}
export interface RestartAppServerResponse {
}
export interface RetrieveEnvironmentInfoMessage {
    EnvironmentId?: string;
    EnvironmentName?: string;
    InfoType: EnvironmentInfoType;
}
export type Ec2InstanceId = string;
export type SampleTimestamp = Date;
export type Message = string;
export interface EnvironmentInfoDescription {
    InfoType?: EnvironmentInfoType;
    Ec2InstanceId?: string;
    SampleTimestamp?: Date;
    Message?: string;
}
export type EnvironmentInfoDescriptionList = EnvironmentInfoDescription[];
export interface RetrieveEnvironmentInfoResultMessage {
    EnvironmentInfo?: EnvironmentInfoDescription[];
}
export interface SwapEnvironmentCNAMEsMessage {
    SourceEnvironmentId?: string;
    SourceEnvironmentName?: string;
    DestinationEnvironmentId?: string;
    DestinationEnvironmentName?: string;
}
export interface SwapEnvironmentCNAMEsResponse {
}
export type TerminateEnvironmentResources = boolean;
export type ForceTerminate = boolean;
export interface TerminateEnvironmentMessage {
    EnvironmentId?: string;
    EnvironmentName?: string;
    TerminateResources?: boolean;
    ForceTerminate?: boolean;
}
export interface UpdateApplicationMessage {
    ApplicationName: string;
    Description?: string;
}
export interface UpdateApplicationResourceLifecycleMessage {
    ApplicationName: string;
    ResourceLifecycleConfig: ApplicationResourceLifecycleConfig;
}
export interface ApplicationResourceLifecycleDescriptionMessage {
    ApplicationName?: string;
    ResourceLifecycleConfig?: ApplicationResourceLifecycleConfig;
}
export interface UpdateApplicationVersionMessage {
    ApplicationName: string;
    VersionLabel: string;
    Description?: string;
}
export interface UpdateConfigurationTemplateMessage {
    ApplicationName: string;
    TemplateName: string;
    Description?: string;
    OptionSettings?: ConfigurationOptionSetting[];
    OptionsToRemove?: OptionSpecification[];
}
export interface UpdateEnvironmentMessage {
    ApplicationName?: string;
    EnvironmentId?: string;
    EnvironmentName?: string;
    GroupName?: string;
    Description?: string;
    Tier?: EnvironmentTier;
    VersionLabel?: string;
    TemplateName?: string;
    SolutionStackName?: string;
    PlatformArn?: string;
    OptionSettings?: ConfigurationOptionSetting[];
    OptionsToRemove?: OptionSpecification[];
}
export type TagKeyList = string[];
export interface UpdateTagsForResourceMessage {
    ResourceArn: string;
    TagsToAdd?: Tag[];
    TagsToRemove?: string[];
}
export interface UpdateTagsForResourceResponse {
}
export interface ValidateConfigurationSettingsMessage {
    ApplicationName: string;
    TemplateName?: string;
    EnvironmentName?: string;
    OptionSettings: ConfigurationOptionSetting[];
}
export type ValidationMessageString = string;
export type ValidationSeverity = "error" | "warning" | (string & {});
export interface ValidationMessage {
    Message?: string;
    Severity?: ValidationSeverity;
    Namespace?: string;
    OptionName?: string;
}
export type ValidationMessagesList = ValidationMessage[];
export interface ConfigurationSettingsValidationMessages {
    Messages?: ValidationMessage[];
}
export type ExceptionMessage = string;
export type AbortEnvironmentUpdateError = InsufficientPrivilegesException | CommonErrors;
/**
 * Cancels in-progress environment configuration update or application version deployment.
 */
export declare const abortEnvironmentUpdate: API.OperationMethod<AbortEnvironmentUpdateMessage, AbortEnvironmentUpdateResponse, AbortEnvironmentUpdateError, Credentials | HttpClient.HttpClient>;
export type ApplyEnvironmentManagedActionError = ElasticBeanstalkServiceException | ManagedActionInvalidStateException | CommonErrors;
/**
 * Applies a scheduled managed action immediately. A managed action can be applied only if its status is `Scheduled`. Get the status and
 * action ID of a managed action with DescribeEnvironmentManagedActions.
 */
export declare const applyEnvironmentManagedAction: API.OperationMethod<ApplyEnvironmentManagedActionRequest, ApplyEnvironmentManagedActionResult, ApplyEnvironmentManagedActionError, Credentials | HttpClient.HttpClient>;
export type AssociateEnvironmentOperationsRoleError = InsufficientPrivilegesException | CommonErrors;
/**
 * The operations role feature of Elastic Beanstalk is in beta release and is subject to change.
 *
 * Add or change the operations role used by an environment. After this call is made, Elastic Beanstalk uses the associated operations role for permissions to
 * downstream services during subsequent calls acting on this environment.
 */
export declare const associateEnvironmentOperationsRole: API.OperationMethod<AssociateEnvironmentOperationsRoleMessage, AssociateEnvironmentOperationsRoleResponse, AssociateEnvironmentOperationsRoleError, Credentials | HttpClient.HttpClient>;
export type CheckDNSAvailabilityError = CommonErrors;
/**
 * Checks if the specified CNAME is available.
 */
export declare const checkDNSAvailability: API.OperationMethod<CheckDNSAvailabilityMessage, CheckDNSAvailabilityResultMessage, CheckDNSAvailabilityError, Credentials | HttpClient.HttpClient>;
export type ComposeEnvironmentsError = InsufficientPrivilegesException | TooManyEnvironmentsException | CommonErrors;
/**
 * Create or update a group of environments that each run a separate component of a single application. Takes a list of version labels that specify
 * application source bundles for each of the environments to create or update. The name of each environment and other required information must be included
 * in the source bundles in an environment manifest named `env.yaml`. See Compose Environments for details.
 */
export declare const composeEnvironments: API.OperationMethod<ComposeEnvironmentsMessage, EnvironmentDescriptionsMessage, ComposeEnvironmentsError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = TooManyApplicationsException | CommonErrors;
/**
 * Creates an application that has one configuration template named `default` and
 * no application versions.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationMessage, ApplicationDescriptionMessage, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationVersionError = CodeBuildNotInServiceRegionException | InsufficientPrivilegesException | S3LocationNotInServiceRegionException | TooManyApplicationsException | TooManyApplicationVersionsException | CommonErrors;
/**
 * Creates an application version for the specified application. You can create an application version from a source bundle in Amazon S3, a commit in
 * CodeCommit, or the output of an CodeBuild build as follows:
 *
 * Specify a commit in an CodeCommit repository with `SourceBuildInformation`.
 *
 * Specify a build in an CodeBuild with `SourceBuildInformation` and `BuildConfiguration`.
 *
 * Specify a source bundle in Amazon S3 with `SourceBundle`
 *
 * Omit both `SourceBuildInformation` and `SourceBundle` to use the default sample application.
 *
 * After you create an application version with a specified Amazon S3 bucket and key location, you can't change that Amazon S3 location. If you change the Amazon S3
 * location, you receive an exception when you attempt to launch an environment from the application version.
 */
export declare const createApplicationVersion: API.OperationMethod<CreateApplicationVersionMessage, ApplicationVersionDescriptionMessage, CreateApplicationVersionError, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationTemplateError = InsufficientPrivilegesException | TooManyBucketsException | TooManyConfigurationTemplatesException | CommonErrors;
/**
 * Creates an Elastic Beanstalk configuration template, associated with a specific Elastic Beanstalk
 * application. You define application configuration settings in a configuration template. You
 * can then use the configuration template to deploy different versions of the application with
 * the same configuration settings.
 *
 * Templates aren't associated with any environment. The `EnvironmentName`
 * response element is always `null`.
 *
 * Related Topics
 *
 * - DescribeConfigurationOptions
 *
 * - DescribeConfigurationSettings
 *
 * - ListAvailableSolutionStacks
 */
export declare const createConfigurationTemplate: API.OperationMethod<CreateConfigurationTemplateMessage, ConfigurationSettingsDescription, CreateConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentError = InsufficientPrivilegesException | TooManyEnvironmentsException | CommonErrors;
/**
 * Launches an Elastic Beanstalk environment for the specified application using the specified configuration.
 */
export declare const createEnvironment: API.OperationMethod<CreateEnvironmentMessage, EnvironmentDescription, CreateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreatePlatformVersionError = ElasticBeanstalkServiceException | InsufficientPrivilegesException | TooManyPlatformsException | CommonErrors;
/**
 * Create a new version of your custom platform.
 */
export declare const createPlatformVersion: API.OperationMethod<CreatePlatformVersionRequest, CreatePlatformVersionResult, CreatePlatformVersionError, Credentials | HttpClient.HttpClient>;
export type CreateStorageLocationError = InsufficientPrivilegesException | S3SubscriptionRequiredException | TooManyBucketsException | CommonErrors;
/**
 * Creates a bucket in Amazon S3 to store application versions, logs, and other files used by Elastic Beanstalk environments. The Elastic Beanstalk
 * console and EB CLI call this API the first time you create an environment in a region. If the storage location already exists,
 * `CreateStorageLocation` still returns the bucket name but does not create a new bucket.
 */
export declare const createStorageLocation: API.OperationMethod<CreateStorageLocationRequest, CreateStorageLocationResultMessage, CreateStorageLocationError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = OperationInProgressException | CommonErrors;
/**
 * Deletes the specified application along with all associated versions and configurations.
 * The application versions will not be deleted from your Amazon S3 bucket.
 *
 * You cannot delete an application that has a running environment.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationMessage, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationVersionError = InsufficientPrivilegesException | OperationInProgressException | S3LocationNotInServiceRegionException | SourceBundleDeletionException | CommonErrors;
/**
 * Deletes the specified version from the specified application.
 *
 * You cannot delete an application version that is associated with a running environment.
 */
export declare const deleteApplicationVersion: API.OperationMethod<DeleteApplicationVersionMessage, DeleteApplicationVersionResponse, DeleteApplicationVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationTemplateError = OperationInProgressException | CommonErrors;
/**
 * Deletes the specified configuration template.
 *
 * When you launch an environment using a configuration template, the environment gets a
 * copy of the template. You can delete or modify the environment's copy of the template
 * without affecting the running environment.
 */
export declare const deleteConfigurationTemplate: API.OperationMethod<DeleteConfigurationTemplateMessage, DeleteConfigurationTemplateResponse, DeleteConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentConfigurationError = CommonErrors;
/**
 * Deletes the draft configuration associated with the running environment.
 *
 * Updating a running environment with any configuration changes creates a draft
 * configuration set. You can get the draft configuration using DescribeConfigurationSettings while the update is in progress or if the update
 * fails. The `DeploymentStatus` for the draft configuration indicates whether the
 * deployment is in process or has failed. The draft configuration remains in existence until it
 * is deleted with this action.
 */
export declare const deleteEnvironmentConfiguration: API.OperationMethod<DeleteEnvironmentConfigurationMessage, DeleteEnvironmentConfigurationResponse, DeleteEnvironmentConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeletePlatformVersionError = ElasticBeanstalkServiceException | InsufficientPrivilegesException | OperationInProgressException | PlatformVersionStillReferencedException | CommonErrors;
/**
 * Deletes the specified version of a custom platform.
 */
export declare const deletePlatformVersion: API.OperationMethod<DeletePlatformVersionRequest, DeletePlatformVersionResult, DeletePlatformVersionError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountAttributesError = InsufficientPrivilegesException | CommonErrors;
/**
 * Returns attributes related to Elastic Beanstalk that are associated with the calling Amazon Web Services account.
 *
 * The result currently has one set of attributes--resource quotas.
 *
 * This action only returns information about resources that the calling principle has IAM permissions to access. For example, consider a case where a
 * user only has permission to access one of three resources. When the user calls the this action, the response will only include the one resource that the
 * user has permission to access instead of all three resources. If the user doesn't have access to any of the resources an empty result is returned.
 *
 * The AWSElasticBeanstalkReadOnly
 * managed policy allows operators to view information about resources related to Elastic Beanstalk. For more information, see Managing Elastic Beanstalk user policies in the Elastic Beanstalk Developer
 * Guide. For detailed instructions to attach a policy to a user or group, see the section Controlling access with managed policies in the
 * same topic.
 */
export declare const describeAccountAttributes: API.OperationMethod<DescribeAccountAttributesRequest, DescribeAccountAttributesResult, DescribeAccountAttributesError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationsError = CommonErrors;
/**
 * Returns the descriptions of existing applications.
 *
 * This action only returns information about applications that the calling principle has IAM permissions to
 * access. For example, consider a case where a user only has permission to access two of three
 * applications. When the user calls the *DescribeApplications* action, the
 * response will only include the two applications that the user has permission to access
 * instead of all three applications. If the user doesn't have access to any of the applications
 * an empty result is returned.
 *
 * The *AWSElasticBeanstalkReadOnly* managed policy allows operators to
 * view information about resources related to Elastic Beanstalk environments. For more
 * information, see Managing Elastic Beanstalk user
 * policies in the *Elastic Beanstalk Developer Guide*. For detailed
 * instructions to attach a policy to a user or group, see the section Controlling access with managed policies in the same topic.
 */
export declare const describeApplications: API.OperationMethod<DescribeApplicationsMessage, ApplicationDescriptionsMessage, DescribeApplicationsError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationVersionsError = CommonErrors;
/**
 * Retrieve a list of application versions.
 *
 * This action only returns information about resources that the calling principle has IAM permissions to access. For example, consider a case where a
 * user only has permission to access one of three resources. When the user calls the this action, the response will only include the one resource that the
 * user has permission to access instead of all three resources. If the user doesn't have access to any of the resources an empty result is returned.
 *
 * The AWSElasticBeanstalkReadOnly
 * managed policy allows operators to view information about resources related to Elastic Beanstalk. For more information, see Managing Elastic Beanstalk user policies in the Elastic Beanstalk Developer
 * Guide. For detailed instructions to attach a policy to a user or group, see the section Controlling access with managed policies in the
 * same topic.
 */
export declare const describeApplicationVersions: API.OperationMethod<DescribeApplicationVersionsMessage, ApplicationVersionDescriptionsMessage, DescribeApplicationVersionsError, Credentials | HttpClient.HttpClient>;
export type DescribeConfigurationOptionsError = TooManyBucketsException | CommonErrors;
/**
 * Describes the configuration options that are used in a particular configuration
 * template or environment, or that a specified solution stack defines. The description includes
 * the values the options, their default values, and an indication of the required action on a
 * running environment if an option value is changed.
 *
 * This action only returns information about resources that the calling principle has IAM permissions to
 * access. For example, consider a case where a user only has permission to access one of three
 * resources. When the user calls the this action, the
 * response will only include the one resource that the user has permission to access instead
 * of all three resources. If the user doesn't have access to any of the resources an empty
 * result is returned.
 *
 * The AWSElasticBeanstalkReadOnly
 * managed policy allows operators to view information about resources related to Elastic Beanstalk. For more information, see Managing Elastic Beanstalk user policies in the Elastic Beanstalk Developer
 * Guide. For detailed instructions to attach a policy to a user or group, see the section Controlling access with managed policies in the
 * same topic.
 */
export declare const describeConfigurationOptions: API.OperationMethod<DescribeConfigurationOptionsMessage, ConfigurationOptionsDescription, DescribeConfigurationOptionsError, Credentials | HttpClient.HttpClient>;
export type DescribeConfigurationSettingsError = TooManyBucketsException | CommonErrors;
/**
 * Returns a description of the settings for the specified configuration set, that is,
 * either a configuration template or the configuration set associated with a running
 * environment.
 *
 * When describing the settings for the configuration set associated with a running
 * environment, it is possible to receive two sets of setting descriptions. One is the deployed
 * configuration set, and the other is a draft configuration of an environment that is either in
 * the process of deployment or that failed to deploy.
 *
 * This action only returns information about resources that the calling principle has IAM permissions to
 * access. For example, consider a case where a user only has permission to access one of three
 * resources. When the user calls the this action, the
 * response will only include the one resource that the user has permission to access instead
 * of all three resources. If the user doesn't have access to any of the resources an empty
 * result is returned.
 *
 * The AWSElasticBeanstalkReadOnly
 * managed policy allows operators to view information about resources related to Elastic Beanstalk. For more information, see Managing Elastic Beanstalk user policies in the Elastic Beanstalk Developer
 * Guide. For detailed instructions to attach a policy to a user or group, see the section Controlling access with managed policies in the
 * same topic.
 *
 * Related Topics
 *
 * - DeleteEnvironmentConfiguration
 */
export declare const describeConfigurationSettings: API.OperationMethod<DescribeConfigurationSettingsMessage, ConfigurationSettingsDescriptions, DescribeConfigurationSettingsError, Credentials | HttpClient.HttpClient>;
export type DescribeEnvironmentHealthError = ElasticBeanstalkServiceException | InvalidRequestException | CommonErrors;
/**
 * Returns information about the overall health of the specified environment. The **DescribeEnvironmentHealth** operation is
 * only available with Elastic Beanstalk Enhanced Health.
 *
 * This action only returns information about environments that the calling principle has IAM permissions to access. For example, consider a case where
 * a user only has permission to access one of three environments. When the user calls this action, the response will only include the one environment that
 * the user has permission to access instead of all three environments. If the user doesn't have access to any of the environments an empty result is
 * returned.
 *
 * The AWSElasticBeanstalkReadOnly
 * managed policy allows operators to view information about resources related to Elastic Beanstalk environments. For more information, see Managing Elastic Beanstalk user policies in the Elastic Beanstalk Developer
 * Guide. For detailed instructions to attach a policy to a user or group, see the section Controlling access with managed policies in the
 * same topic.
 */
export declare const describeEnvironmentHealth: API.OperationMethod<DescribeEnvironmentHealthRequest, DescribeEnvironmentHealthResult, DescribeEnvironmentHealthError, Credentials | HttpClient.HttpClient>;
export type DescribeEnvironmentManagedActionHistoryError = ElasticBeanstalkServiceException | CommonErrors;
/**
 * Lists an environment's completed and failed managed actions.
 */
export declare const describeEnvironmentManagedActionHistory: API.PaginatedOperationMethod<DescribeEnvironmentManagedActionHistoryRequest, DescribeEnvironmentManagedActionHistoryResult, DescribeEnvironmentManagedActionHistoryError, Credentials | HttpClient.HttpClient, ManagedActionHistoryItem>;
export type DescribeEnvironmentManagedActionsError = ElasticBeanstalkServiceException | CommonErrors;
/**
 * Lists an environment's upcoming and in-progress managed actions.
 *
 * This action only returns information about environments that the calling principle has IAM permissions to access. For example, consider a case where
 * a user only has permission to access one of three environments. When the user calls this action, the response will only include the one environment that
 * the user has permission to access instead of all three environments. If the user doesn't have access to any of the environments an empty result is
 * returned.
 *
 * The AWSElasticBeanstalkReadOnly
 * managed policy allows operators to view information about resources related to Elastic Beanstalk environments. For more information, see Managing Elastic Beanstalk user policies in the Elastic Beanstalk Developer
 * Guide. For detailed instructions to attach a policy to a user or group, see the section Controlling access with managed policies in the
 * same topic.
 */
export declare const describeEnvironmentManagedActions: API.OperationMethod<DescribeEnvironmentManagedActionsRequest, DescribeEnvironmentManagedActionsResult, DescribeEnvironmentManagedActionsError, Credentials | HttpClient.HttpClient>;
export type DescribeEnvironmentResourcesError = InsufficientPrivilegesException | CommonErrors;
/**
 * Returns Amazon Web Services resources for this environment.
 */
export declare const describeEnvironmentResources: API.OperationMethod<DescribeEnvironmentResourcesMessage, EnvironmentResourceDescriptionsMessage, DescribeEnvironmentResourcesError, Credentials | HttpClient.HttpClient>;
export type DescribeEnvironmentsError = CommonErrors;
/**
 * Returns descriptions for existing environments.
 *
 * This action only returns information about environments that the calling principle has IAM permissions to access. For example, consider a case where
 * a user only has permission to access one of three environments. When the user calls the *DescribeEnvironments* action, the response
 * will only include the one environment that the user has permission to access instead of all three environments. If the user doesn't have access to any of
 * the environments an empty result is returned.
 *
 * The AWSElasticBeanstalkReadOnly
 * managed policy allows operators to view information about resources related to Elastic Beanstalk environments. For more information, see Managing Elastic Beanstalk user policies in the Elastic Beanstalk Developer
 * Guide. For detailed instructions to attach a policy to a user or group, see the section Controlling access with managed policies in the
 * same topic.
 */
export declare const describeEnvironments: API.OperationMethod<DescribeEnvironmentsMessage, EnvironmentDescriptionsMessage, DescribeEnvironmentsError, Credentials | HttpClient.HttpClient>;
export type DescribeEventsError = CommonErrors;
/**
 * Returns list of event descriptions matching criteria up to the last 6 weeks.
 *
 * This action returns the most recent 1,000 events from the specified `NextToken`.
 *
 * This action only returns information about resources that the calling principle has IAM permissions to access. For example, consider a case where a
 * user only has permission to access one of three resources. When the user calls the this action, the response will only include the one resource that the
 * user has permission to access instead of all three resources. If the user doesn't have access to any of the resources an empty result is returned.
 *
 * The AWSElasticBeanstalkReadOnly
 * managed policy allows operators to view information about resources related to Elastic Beanstalk. For more information, see Managing Elastic Beanstalk user policies in the Elastic Beanstalk Developer
 * Guide. For detailed instructions to attach a policy to a user or group, see the section Controlling access with managed policies in the
 * same topic.
 */
export declare const describeEvents: API.PaginatedOperationMethod<DescribeEventsMessage, EventDescriptionsMessage, DescribeEventsError, Credentials | HttpClient.HttpClient, EventDescription>;
export type DescribeInstancesHealthError = ElasticBeanstalkServiceException | InvalidRequestException | CommonErrors;
/**
 * Retrieves detailed information about the health of instances in your Elastic Beanstalk environments. This operation requires enhanced health reporting.
 *
 * This action only returns information about environments that the calling principle has IAM permissions to access. For example, consider a case where
 * a user only has permission to access one of three environments. When the user calls this action, the response will only include the one environment that
 * the user has permission to access instead of all three environments. If the user doesn't have access to any of the environments an empty result is
 * returned.
 *
 * The AWSElasticBeanstalkReadOnly
 * managed policy allows operators to view information about resources related to Elastic Beanstalk environments. For more information, see Managing Elastic Beanstalk user policies in the Elastic Beanstalk Developer
 * Guide. For detailed instructions to attach a policy to a user or group, see the section Controlling access with managed policies in the
 * same topic.
 */
export declare const describeInstancesHealth: API.OperationMethod<DescribeInstancesHealthRequest, DescribeInstancesHealthResult, DescribeInstancesHealthError, Credentials | HttpClient.HttpClient>;
export type DescribePlatformVersionError = ElasticBeanstalkServiceException | InsufficientPrivilegesException | CommonErrors;
/**
 * Describes a platform version. Provides full details. Compare to ListPlatformVersions, which provides summary information about a
 * list of platform versions.
 *
 * For definitions of platform version and other platform-related terms, see Elastic Beanstalk Platforms Glossary.
 *
 * This action only returns information about resources that the calling principle has IAM permissions to access. For example, consider a case where a
 * user only has permission to access one of three resources. When the user calls the this action, the response will only include the one resource that the
 * user has permission to access instead of all three resources. If the user doesn't have access to any of the resources an empty result is returned.
 *
 * The AWSElasticBeanstalkReadOnly
 * managed policy allows operators to view information about resources related to Elastic Beanstalk. For more information, see Managing Elastic Beanstalk user policies in the Elastic Beanstalk Developer
 * Guide. For detailed instructions to attach a policy to a user or group, see the section Controlling access with managed policies in the
 * same topic.
 */
export declare const describePlatformVersion: API.OperationMethod<DescribePlatformVersionRequest, DescribePlatformVersionResult, DescribePlatformVersionError, Credentials | HttpClient.HttpClient>;
export type DisassociateEnvironmentOperationsRoleError = InsufficientPrivilegesException | CommonErrors;
/**
 * The operations role feature of Elastic Beanstalk is in beta release and is subject to change.
 *
 * Disassociate the operations role from an environment. After this call is made, Elastic Beanstalk uses the caller's permissions for permissions to downstream
 * services during subsequent calls acting on this environment.
 */
export declare const disassociateEnvironmentOperationsRole: API.OperationMethod<DisassociateEnvironmentOperationsRoleMessage, DisassociateEnvironmentOperationsRoleResponse, DisassociateEnvironmentOperationsRoleError, Credentials | HttpClient.HttpClient>;
export type ListAvailableSolutionStacksError = CommonErrors;
/**
 * Returns a list of the available solution stack names, with the public version first and then in reverse chronological order.
 *
 * This action only returns information about resources that the calling principle has IAM permissions to access. For example, consider a case where a
 * user only has permission to access one of three resources. When the user calls the this action, the response will only include the one resource that the
 * user has permission to access instead of all three resources. If the user doesn't have access to any of the resources an empty result is returned.
 *
 * The AWSElasticBeanstalkReadOnly
 * managed policy allows operators to view information about resources related to Elastic Beanstalk. For more information, see Managing Elastic Beanstalk user policies in the Elastic Beanstalk Developer
 * Guide. For detailed instructions to attach a policy to a user or group, see the section Controlling access with managed policies in the
 * same topic.
 */
export declare const listAvailableSolutionStacks: API.OperationMethod<ListAvailableSolutionStacksRequest, ListAvailableSolutionStacksResultMessage, ListAvailableSolutionStacksError, Credentials | HttpClient.HttpClient>;
export type ListPlatformBranchesError = CommonErrors;
/**
 * Lists the platform branches available for your account in an Amazon Web Services Region. Provides summary information about each platform branch.
 *
 * For definitions of platform branch and other platform-related terms, see Elastic Beanstalk Platforms Glossary.
 *
 * This action only returns information about resources that the calling principle has IAM permissions to access. For example, consider a case where a
 * user only has permission to access one of three resources. When the user calls the this action, the response will only include the one resource that the
 * user has permission to access instead of all three resources. If the user doesn't have access to any of the resources an empty result is returned.
 *
 * The AWSElasticBeanstalkReadOnly
 * managed policy allows operators to view information about resources related to Elastic Beanstalk. For more information, see Managing Elastic Beanstalk user policies in the Elastic Beanstalk Developer
 * Guide. For detailed instructions to attach a policy to a user or group, see the section Controlling access with managed policies in the
 * same topic.
 */
export declare const listPlatformBranches: API.PaginatedOperationMethod<ListPlatformBranchesRequest, ListPlatformBranchesResult, ListPlatformBranchesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPlatformVersionsError = ElasticBeanstalkServiceException | InsufficientPrivilegesException | CommonErrors;
/**
 * Lists the platform versions available for your account in an Amazon Web Services Region. Provides summary information about each platform version. Compare to DescribePlatformVersion, which provides full details about a single platform version.
 *
 * This action only returns information about platform versions that the calling principle has IAM permissions to access. For example, consider a case
 * where a user only has permission to access one of ten platform versions. When the user calls the *ListPlatformVersions* action, the
 * response will only include the one platform version that the user has permission to access instead of all ten platform versions. If the user doesn't have
 * access to any of the platform versions an empty result is returned.
 *
 * The *AWSElasticBeanstalkReadOnly* managed policy allows operators to view information about resources related to Elastic Beanstalk
 * environments. For more information, see Managing Elastic Beanstalk
 * user policies in the *Elastic Beanstalk Developer Guide*. For detailed instructions to attach a policy to a user or group, see the
 * section Controlling access
 * with managed policies in the same topic.
 *
 * For definitions of platform version and other platform-related terms, see Elastic Beanstalk Platforms Glossary.
 */
export declare const listPlatformVersions: API.PaginatedOperationMethod<ListPlatformVersionsRequest, ListPlatformVersionsResult, ListPlatformVersionsError, Credentials | HttpClient.HttpClient, PlatformSummary>;
export type ListTagsForResourceError = InsufficientPrivilegesException | ResourceNotFoundException | ResourceTypeNotSupportedException | CommonErrors;
/**
 * Return the tags applied to an Elastic Beanstalk resource. The response contains a list of tag key-value pairs.
 *
 * Elastic Beanstalk supports tagging of all of its resources. For details about resource tagging, see Tagging Application Resources.
 *
 * This action only returns information about resources that the calling principle has IAM permissions to access. For example, consider a case where a
 * user only has permission to access one of three resources. When the user calls the this action, the response will only include the one resource that the
 * user has permission to access instead of all three resources. If the user doesn't have access to any of the resources an empty result is returned.
 *
 * The AWSElasticBeanstalkReadOnly
 * managed policy allows operators to view information about resources related to Elastic Beanstalk. For more information, see Managing Elastic Beanstalk user policies in the Elastic Beanstalk Developer
 * Guide. For detailed instructions to attach a policy to a user or group, see the section Controlling access with managed policies in the
 * same topic.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceMessage, ResourceTagsDescriptionMessage, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RebuildEnvironmentError = InsufficientPrivilegesException | CommonErrors;
/**
 * Deletes and recreates all of the Amazon Web Services resources (for example: the Auto Scaling group, load balancer, etc.) for a specified environment and forces a
 * restart.
 */
export declare const rebuildEnvironment: API.OperationMethod<RebuildEnvironmentMessage, RebuildEnvironmentResponse, RebuildEnvironmentError, Credentials | HttpClient.HttpClient>;
export type RequestEnvironmentInfoError = CommonErrors;
/**
 * Initiates a request to compile the specified type of information of the deployed environment.
 *
 * Setting the `InfoType` to `tail` compiles the last lines from the application server log files of every Amazon EC2 instance in
 * your environment.
 *
 * Setting the `InfoType` to `bundle` compresses the application server log files for every Amazon EC2 instance into a
 * `.zip` file. Legacy and .NET containers do not support bundle logs.
 *
 * Setting the `InfoType` to `analyze` collects recent events, instance health, and logs from your environment and sends them to
 * Amazon Bedrock in your account to generate diagnostic insights and recommended next steps.
 *
 * Use RetrieveEnvironmentInfo to obtain the set of logs.
 *
 * Related Topics
 *
 * - RetrieveEnvironmentInfo
 */
export declare const requestEnvironmentInfo: API.OperationMethod<RequestEnvironmentInfoMessage, RequestEnvironmentInfoResponse, RequestEnvironmentInfoError, Credentials | HttpClient.HttpClient>;
export type RestartAppServerError = CommonErrors;
/**
 * Causes the environment to restart the application container server running on each Amazon EC2 instance.
 */
export declare const restartAppServer: API.OperationMethod<RestartAppServerMessage, RestartAppServerResponse, RestartAppServerError, Credentials | HttpClient.HttpClient>;
export type RetrieveEnvironmentInfoError = CommonErrors;
/**
 * Retrieves the compiled information from a RequestEnvironmentInfo request.
 *
 * Related Topics
 *
 * - RequestEnvironmentInfo
 */
export declare const retrieveEnvironmentInfo: API.OperationMethod<RetrieveEnvironmentInfoMessage, RetrieveEnvironmentInfoResultMessage, RetrieveEnvironmentInfoError, Credentials | HttpClient.HttpClient>;
export type SwapEnvironmentCNAMEsError = CommonErrors;
/**
 * Swaps the CNAMEs of two environments.
 */
export declare const swapEnvironmentCNAMEs: API.OperationMethod<SwapEnvironmentCNAMEsMessage, SwapEnvironmentCNAMEsResponse, SwapEnvironmentCNAMEsError, Credentials | HttpClient.HttpClient>;
export type TerminateEnvironmentError = InsufficientPrivilegesException | CommonErrors;
/**
 * Terminates the specified environment.
 */
export declare const terminateEnvironment: API.OperationMethod<TerminateEnvironmentMessage, EnvironmentDescription, TerminateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = CommonErrors;
/**
 * Updates the specified application to have the specified properties.
 *
 * If a property (for example, `description`) is not provided, the value remains
 * unchanged. To clear these properties, specify an empty string.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationMessage, ApplicationDescriptionMessage, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationResourceLifecycleError = InsufficientPrivilegesException | CommonErrors;
/**
 * Modifies lifecycle settings for an application.
 */
export declare const updateApplicationResourceLifecycle: API.OperationMethod<UpdateApplicationResourceLifecycleMessage, ApplicationResourceLifecycleDescriptionMessage, UpdateApplicationResourceLifecycleError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationVersionError = CommonErrors;
/**
 * Updates the specified application version to have the specified properties.
 *
 * If a property (for example, `description`) is not provided, the value remains unchanged. To clear properties, specify an empty
 * string.
 */
export declare const updateApplicationVersion: API.OperationMethod<UpdateApplicationVersionMessage, ApplicationVersionDescriptionMessage, UpdateApplicationVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationTemplateError = InsufficientPrivilegesException | TooManyBucketsException | CommonErrors;
/**
 * Updates the specified configuration template to have the specified properties or
 * configuration option values.
 *
 * If a property (for example, `ApplicationName`) is not provided, its value
 * remains unchanged. To clear such properties, specify an empty string.
 *
 * Related Topics
 *
 * - DescribeConfigurationOptions
 */
export declare const updateConfigurationTemplate: API.OperationMethod<UpdateConfigurationTemplateMessage, ConfigurationSettingsDescription, UpdateConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentError = InsufficientPrivilegesException | TooManyBucketsException | CommonErrors;
/**
 * Updates the environment description, deploys a new application version, updates the configuration settings to an entirely new configuration template,
 * or updates select configuration option values in the running environment.
 *
 * Attempting to update both the release and configuration is not allowed and Elastic Beanstalk returns an `InvalidParameterCombination` error.
 *
 * When updating the configuration settings to a new template or individual settings, a draft configuration is created and DescribeConfigurationSettings for this environment returns two setting descriptions with different `DeploymentStatus` values.
 */
export declare const updateEnvironment: API.OperationMethod<UpdateEnvironmentMessage, EnvironmentDescription, UpdateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateTagsForResourceError = InsufficientPrivilegesException | OperationInProgressException | ResourceNotFoundException | ResourceTypeNotSupportedException | TooManyTagsException | CommonErrors;
/**
 * Update the list of tags applied to an Elastic Beanstalk resource. Two lists can be passed: `TagsToAdd` for tags to add or update, and
 * `TagsToRemove`.
 *
 * Elastic Beanstalk supports tagging of all of its resources. For details about resource tagging, see Tagging Application Resources.
 *
 * If you create a custom policy to control permission to this operation, specify one of the following two virtual actions (or both) instead of the API
 * operation name:
 *
 * ### elasticbeanstalk:AddTags
 *
 * Controls permission to call `UpdateTagsForResource` and pass a list of tags to add in the `TagsToAdd` parameter.
 *
 * ### elasticbeanstalk:RemoveTags
 *
 * Controls permission to call `UpdateTagsForResource` and pass a list of tag keys to remove in the `TagsToRemove`
 * parameter.
 *
 * For details about creating a custom user policy, see Creating a Custom User Policy.
 */
export declare const updateTagsForResource: API.OperationMethod<UpdateTagsForResourceMessage, UpdateTagsForResourceResponse, UpdateTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ValidateConfigurationSettingsError = InsufficientPrivilegesException | TooManyBucketsException | CommonErrors;
/**
 * Takes a set of configuration settings and either a configuration template or
 * environment, and determines whether those values are valid.
 *
 * This action returns a list of messages indicating any errors or warnings associated
 * with the selection of option values.
 */
export declare const validateConfigurationSettings: API.OperationMethod<ValidateConfigurationSettingsMessage, ConfigurationSettingsValidationMessages, ValidateConfigurationSettingsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=elastic-beanstalk.d.ts.map