import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const IllegalActionException_base: S.TaggedErrorClass<"IllegalActionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IllegalActionException extends /*@__PURE__*/ IllegalActionException_base {
}
declare const InternalServiceErrorException_base: S.TaggedErrorClass<"InternalServiceErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServiceErrorException extends /*@__PURE__*/ InternalServiceErrorException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceLimitExceededException_base: S.TaggedErrorClass<"ResourceLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ResourceLimitExceededException extends /*@__PURE__*/ ResourceLimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceNotReadyException_base: S.TaggedErrorClass<"ResourceNotReadyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceNotReadyException extends /*@__PURE__*/ ResourceNotReadyException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
    readonly ResourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
export type ClientRequestTokenString = string;
export type AccessorType = "BILLING_TOKEN" | (string & {});
export type TagKey = string;
export type TagValue = string;
export type InputTagMap = {
    [key: string]: string | undefined;
};
export type AccessorNetworkType = "ETHEREUM_GOERLI" | "ETHEREUM_MAINNET" | "ETHEREUM_MAINNET_AND_GOERLI" | "POLYGON_MAINNET" | "POLYGON_MUMBAI" | (string & {});
export interface CreateAccessorInput {
    ClientRequestToken: string;
    AccessorType: AccessorType;
    Tags?: {
        [key: string]: string | undefined;
    };
    NetworkType?: AccessorNetworkType;
}
export type ResourceIdString = string;
export type AccessorBillingTokenString = string;
export interface CreateAccessorOutput {
    AccessorId?: string;
    BillingToken?: string;
    NetworkType?: AccessorNetworkType;
}
export type NetworkMemberNameString = string;
export type DescriptionString = string;
export type UsernameString = string;
export type PasswordString = string | redacted.Redacted<string>;
export interface MemberFabricConfiguration {
    AdminUsername: string;
    AdminPassword: string | redacted.Redacted<string>;
}
export interface MemberFrameworkConfiguration {
    Fabric?: MemberFabricConfiguration;
}
export type Enabled = boolean;
export interface LogConfiguration {
    Enabled?: boolean;
}
export interface LogConfigurations {
    Cloudwatch?: LogConfiguration;
}
export interface MemberFabricLogPublishingConfiguration {
    CaLogs?: LogConfigurations;
}
export interface MemberLogPublishingConfiguration {
    Fabric?: MemberFabricLogPublishingConfiguration;
}
export type ArnString = string;
export interface MemberConfiguration {
    Name: string;
    Description?: string;
    FrameworkConfiguration: MemberFrameworkConfiguration;
    LogPublishingConfiguration?: MemberLogPublishingConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    };
    KmsKeyArn?: string;
}
export interface CreateMemberInput {
    ClientRequestToken: string;
    InvitationId: string;
    NetworkId: string;
    MemberConfiguration: MemberConfiguration;
}
export interface CreateMemberOutput {
    MemberId?: string;
}
export type NameString = string;
export type Framework = "HYPERLEDGER_FABRIC" | "ETHEREUM" | (string & {});
export type FrameworkVersionString = string;
export type Edition = "STARTER" | "STANDARD" | (string & {});
export interface NetworkFabricConfiguration {
    Edition: Edition;
}
export interface NetworkFrameworkConfiguration {
    Fabric?: NetworkFabricConfiguration;
}
export type ThresholdPercentageInt = number;
export type ProposalDurationInt = number;
export type ThresholdComparator = "GREATER_THAN" | "GREATER_THAN_OR_EQUAL_TO" | (string & {});
export interface ApprovalThresholdPolicy {
    ThresholdPercentage?: number;
    ProposalDurationInHours?: number;
    ThresholdComparator?: ThresholdComparator;
}
export interface VotingPolicy {
    ApprovalThresholdPolicy?: ApprovalThresholdPolicy;
}
export interface CreateNetworkInput {
    ClientRequestToken: string;
    Name: string;
    Description?: string;
    Framework: Framework;
    FrameworkVersion: string;
    FrameworkConfiguration?: NetworkFrameworkConfiguration;
    VotingPolicy: VotingPolicy;
    MemberConfiguration: MemberConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateNetworkOutput {
    NetworkId?: string;
    MemberId?: string;
}
export type InstanceTypeString = string;
export type AvailabilityZoneString = string;
export interface NodeFabricLogPublishingConfiguration {
    ChaincodeLogs?: LogConfigurations;
    PeerLogs?: LogConfigurations;
}
export interface NodeLogPublishingConfiguration {
    Fabric?: NodeFabricLogPublishingConfiguration;
}
export type StateDBType = "LevelDB" | "CouchDB" | (string & {});
export interface NodeConfiguration {
    InstanceType: string;
    AvailabilityZone?: string;
    LogPublishingConfiguration?: NodeLogPublishingConfiguration;
    StateDB?: StateDBType;
}
export interface CreateNodeInput {
    ClientRequestToken: string;
    NetworkId: string;
    MemberId?: string;
    NodeConfiguration: NodeConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateNodeOutput {
    NodeId?: string;
}
export type PrincipalString = string;
export interface InviteAction {
    Principal: string;
}
export type InviteActionList = InviteAction[];
export interface RemoveAction {
    MemberId: string;
}
export type RemoveActionList = RemoveAction[];
export interface ProposalActions {
    Invitations?: InviteAction[];
    Removals?: RemoveAction[];
}
export interface CreateProposalInput {
    ClientRequestToken: string;
    NetworkId: string;
    MemberId: string;
    Actions: ProposalActions;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateProposalOutput {
    ProposalId?: string;
}
export interface DeleteAccessorInput {
    AccessorId: string;
}
export interface DeleteAccessorOutput {
}
export interface DeleteMemberInput {
    NetworkId: string;
    MemberId: string;
}
export interface DeleteMemberOutput {
}
export interface DeleteNodeInput {
    NetworkId: string;
    MemberId?: string;
    NodeId: string;
}
export interface DeleteNodeOutput {
}
export interface GetAccessorInput {
    AccessorId: string;
}
export type AccessorStatus = "AVAILABLE" | "PENDING_DELETION" | "DELETED" | (string & {});
export type OutputTagMap = {
    [key: string]: string | undefined;
};
export interface Accessor {
    Id?: string;
    Type?: AccessorType;
    BillingToken?: string;
    Status?: AccessorStatus;
    CreationDate?: Date;
    Arn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    NetworkType?: AccessorNetworkType;
}
export interface GetAccessorOutput {
    Accessor?: Accessor;
}
export interface GetMemberInput {
    NetworkId: string;
    MemberId: string;
}
export interface MemberFabricAttributes {
    AdminUsername?: string;
    CaEndpoint?: string;
}
export interface MemberFrameworkAttributes {
    Fabric?: MemberFabricAttributes;
}
export type MemberStatus = "CREATING" | "AVAILABLE" | "CREATE_FAILED" | "UPDATING" | "DELETING" | "DELETED" | "INACCESSIBLE_ENCRYPTION_KEY" | (string & {});
export interface Member {
    NetworkId?: string;
    Id?: string;
    Name?: string;
    Description?: string;
    FrameworkAttributes?: MemberFrameworkAttributes;
    LogPublishingConfiguration?: MemberLogPublishingConfiguration;
    Status?: MemberStatus;
    CreationDate?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
    Arn?: string;
    KmsKeyArn?: string;
}
export interface GetMemberOutput {
    Member?: Member;
}
export interface GetNetworkInput {
    NetworkId: string;
}
export interface NetworkFabricAttributes {
    OrderingServiceEndpoint?: string;
    Edition?: Edition;
}
export interface NetworkEthereumAttributes {
    ChainId?: string;
}
export interface NetworkFrameworkAttributes {
    Fabric?: NetworkFabricAttributes;
    Ethereum?: NetworkEthereumAttributes;
}
export type NetworkStatus = "CREATING" | "AVAILABLE" | "CREATE_FAILED" | "DELETING" | "DELETED" | (string & {});
export interface Network {
    Id?: string;
    Name?: string;
    Description?: string;
    Framework?: Framework;
    FrameworkVersion?: string;
    FrameworkAttributes?: NetworkFrameworkAttributes;
    VpcEndpointServiceName?: string;
    VotingPolicy?: VotingPolicy;
    Status?: NetworkStatus;
    CreationDate?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
    Arn?: string;
}
export interface GetNetworkOutput {
    Network?: Network;
}
export interface GetNodeInput {
    NetworkId: string;
    MemberId?: string;
    NodeId: string;
}
export interface NodeFabricAttributes {
    PeerEndpoint?: string;
    PeerEventEndpoint?: string;
}
export interface NodeEthereumAttributes {
    HttpEndpoint?: string;
    WebSocketEndpoint?: string;
}
export interface NodeFrameworkAttributes {
    Fabric?: NodeFabricAttributes;
    Ethereum?: NodeEthereumAttributes;
}
export type NodeStatus = "CREATING" | "AVAILABLE" | "UNHEALTHY" | "CREATE_FAILED" | "UPDATING" | "DELETING" | "DELETED" | "FAILED" | "INACCESSIBLE_ENCRYPTION_KEY" | (string & {});
export interface Node {
    NetworkId?: string;
    MemberId?: string;
    Id?: string;
    InstanceType?: string;
    AvailabilityZone?: string;
    FrameworkAttributes?: NodeFrameworkAttributes;
    LogPublishingConfiguration?: NodeLogPublishingConfiguration;
    StateDB?: StateDBType;
    Status?: NodeStatus;
    CreationDate?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
    Arn?: string;
    KmsKeyArn?: string;
}
export interface GetNodeOutput {
    Node?: Node;
}
export interface GetProposalInput {
    NetworkId: string;
    ProposalId: string;
}
export type ProposalStatus = "IN_PROGRESS" | "APPROVED" | "REJECTED" | "EXPIRED" | "ACTION_FAILED" | (string & {});
export type VoteCount = number;
export interface Proposal {
    ProposalId?: string;
    NetworkId?: string;
    Description?: string;
    Actions?: ProposalActions;
    ProposedByMemberId?: string;
    ProposedByMemberName?: string;
    Status?: ProposalStatus;
    CreationDate?: Date;
    ExpirationDate?: Date;
    YesVoteCount?: number;
    NoVoteCount?: number;
    OutstandingVoteCount?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
    Arn?: string;
}
export interface GetProposalOutput {
    Proposal?: Proposal;
}
export type AccessorListMaxResults = number;
export type PaginationToken = string;
export interface ListAccessorsInput {
    MaxResults?: number;
    NextToken?: string;
    NetworkType?: AccessorNetworkType;
}
export interface AccessorSummary {
    Id?: string;
    Type?: AccessorType;
    Status?: AccessorStatus;
    CreationDate?: Date;
    Arn?: string;
    NetworkType?: AccessorNetworkType;
}
export type AccessorSummaryList = AccessorSummary[];
export interface ListAccessorsOutput {
    Accessors?: AccessorSummary[];
    NextToken?: string;
}
export type ProposalListMaxResults = number;
export interface ListInvitationsInput {
    MaxResults?: number;
    NextToken?: string;
}
export type InvitationStatus = "PENDING" | "ACCEPTED" | "ACCEPTING" | "REJECTED" | "EXPIRED" | (string & {});
export interface NetworkSummary {
    Id?: string;
    Name?: string;
    Description?: string;
    Framework?: Framework;
    FrameworkVersion?: string;
    Status?: NetworkStatus;
    CreationDate?: Date;
    Arn?: string;
}
export interface Invitation {
    InvitationId?: string;
    CreationDate?: Date;
    ExpirationDate?: Date;
    Status?: InvitationStatus;
    NetworkSummary?: NetworkSummary;
    Arn?: string;
}
export type InvitationList = Invitation[];
export interface ListInvitationsOutput {
    Invitations?: Invitation[];
    NextToken?: string;
}
export type IsOwned = boolean;
export type MemberListMaxResults = number;
export interface ListMembersInput {
    NetworkId: string;
    Name?: string;
    Status?: MemberStatus;
    IsOwned?: boolean;
    MaxResults?: number;
    NextToken?: string;
}
export interface MemberSummary {
    Id?: string;
    Name?: string;
    Description?: string;
    Status?: MemberStatus;
    CreationDate?: Date;
    IsOwned?: boolean;
    Arn?: string;
}
export type MemberSummaryList = MemberSummary[];
export interface ListMembersOutput {
    Members?: MemberSummary[];
    NextToken?: string;
}
export type NetworkListMaxResults = number;
export interface ListNetworksInput {
    Name?: string;
    Framework?: Framework;
    Status?: NetworkStatus;
    MaxResults?: number;
    NextToken?: string;
}
export type NetworkSummaryList = NetworkSummary[];
export interface ListNetworksOutput {
    Networks?: NetworkSummary[];
    NextToken?: string;
}
export type NodeListMaxResults = number;
export interface ListNodesInput {
    NetworkId: string;
    MemberId?: string;
    Status?: NodeStatus;
    MaxResults?: number;
    NextToken?: string;
}
export interface NodeSummary {
    Id?: string;
    Status?: NodeStatus;
    CreationDate?: Date;
    AvailabilityZone?: string;
    InstanceType?: string;
    Arn?: string;
}
export type NodeSummaryList = NodeSummary[];
export interface ListNodesOutput {
    Nodes?: NodeSummary[];
    NextToken?: string;
}
export interface ListProposalsInput {
    NetworkId: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface ProposalSummary {
    ProposalId?: string;
    Description?: string;
    ProposedByMemberId?: string;
    ProposedByMemberName?: string;
    Status?: ProposalStatus;
    CreationDate?: Date;
    ExpirationDate?: Date;
    Arn?: string;
}
export type ProposalSummaryList = ProposalSummary[];
export interface ListProposalsOutput {
    Proposals?: ProposalSummary[];
    NextToken?: string;
}
export interface ListProposalVotesInput {
    NetworkId: string;
    ProposalId: string;
    MaxResults?: number;
    NextToken?: string;
}
export type VoteValue = "YES" | "NO" | (string & {});
export interface VoteSummary {
    Vote?: VoteValue;
    MemberName?: string;
    MemberId?: string;
}
export type ProposalVoteList = VoteSummary[];
export interface ListProposalVotesOutput {
    ProposalVotes?: VoteSummary[];
    NextToken?: string;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface RejectInvitationInput {
    InvitationId: string;
}
export interface RejectInvitationOutput {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateMemberInput {
    NetworkId: string;
    MemberId: string;
    LogPublishingConfiguration?: MemberLogPublishingConfiguration;
}
export interface UpdateMemberOutput {
}
export interface UpdateNodeInput {
    NetworkId: string;
    MemberId?: string;
    NodeId: string;
    LogPublishingConfiguration?: NodeLogPublishingConfiguration;
}
export interface UpdateNodeOutput {
}
export interface VoteOnProposalInput {
    NetworkId: string;
    ProposalId: string;
    VoterMemberId: string;
    Vote: VoteValue;
}
export interface VoteOnProposalOutput {
}
export type ExceptionMessage = string;
export type CreateAccessorError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceAlreadyExistsException | ResourceLimitExceededException | ThrottlingException | TooManyTagsException | CommonErrors;
/**
 * Creates a new accessor for use with Amazon Managed Blockchain service that supports token based access.
 * The accessor contains information required for token based access.
 */
export declare const createAccessor: API.OperationMethod<CreateAccessorInput, CreateAccessorOutput, CreateAccessorError, Credentials | HttpClient.HttpClient>;
export type CreateMemberError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceAlreadyExistsException | ResourceLimitExceededException | ResourceNotFoundException | ResourceNotReadyException | ThrottlingException | TooManyTagsException | CommonErrors;
/**
 * Creates a member within a Managed Blockchain network.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const createMember: API.OperationMethod<CreateMemberInput, CreateMemberOutput, CreateMemberError, Credentials | HttpClient.HttpClient>;
export type CreateNetworkError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceAlreadyExistsException | ResourceLimitExceededException | ThrottlingException | TooManyTagsException | CommonErrors;
/**
 * Creates a new blockchain network using Amazon Managed Blockchain.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const createNetwork: API.OperationMethod<CreateNetworkInput, CreateNetworkOutput, CreateNetworkError, Credentials | HttpClient.HttpClient>;
export type CreateNodeError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceAlreadyExistsException | ResourceLimitExceededException | ResourceNotFoundException | ResourceNotReadyException | ThrottlingException | TooManyTagsException | CommonErrors;
/**
 * Creates a node on the specified blockchain network.
 *
 * Applies to Hyperledger Fabric and Ethereum.
 */
export declare const createNode: API.OperationMethod<CreateNodeInput, CreateNodeOutput, CreateNodeError, Credentials | HttpClient.HttpClient>;
export type CreateProposalError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ResourceNotReadyException | ThrottlingException | TooManyTagsException | CommonErrors;
/**
 * Creates a proposal for a change to the network that other members of the network can vote on, for example, a proposal to add a new member to the network. Any member can create a proposal.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const createProposal: API.OperationMethod<CreateProposalInput, CreateProposalOutput, CreateProposalError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessorError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an accessor that your Amazon Web Services account owns. An accessor object is a container that has the
 * information required for token based access to your Ethereum nodes including, the
 * `BILLING_TOKEN`. After an accessor is deleted, the status of the accessor changes
 * from `AVAILABLE` to `PENDING_DELETION`. An accessor in the
 * `PENDING_DELETION` state can't be used for new WebSocket requests or
 * HTTP requests. However, WebSocket connections that were initiated while the accessor was in the
 * `AVAILABLE` state remain open until they expire (up to 2 hours).
 */
export declare const deleteAccessor: API.OperationMethod<DeleteAccessorInput, DeleteAccessorOutput, DeleteAccessorError, Credentials | HttpClient.HttpClient>;
export type DeleteMemberError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ResourceNotReadyException | ThrottlingException | CommonErrors;
/**
 * Deletes a member. Deleting a member removes the member and all associated resources from the network. `DeleteMember` can only be called for a specified `MemberId` if the principal performing the action is associated with the Amazon Web Services account that owns the member. In all other cases, the `DeleteMember` action is carried out as the result of an approved proposal to remove a member. If `MemberId` is the last member in a network specified by the last Amazon Web Services account, the network is deleted also.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const deleteMember: API.OperationMethod<DeleteMemberInput, DeleteMemberOutput, DeleteMemberError, Credentials | HttpClient.HttpClient>;
export type DeleteNodeError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ResourceNotReadyException | ThrottlingException | CommonErrors;
/**
 * Deletes a node that your Amazon Web Services account owns. All data on the node is lost and cannot be recovered.
 *
 * Applies to Hyperledger Fabric and Ethereum.
 */
export declare const deleteNode: API.OperationMethod<DeleteNodeInput, DeleteNodeOutput, DeleteNodeError, Credentials | HttpClient.HttpClient>;
export type GetAccessorError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns detailed information about an accessor. An accessor object is a container that has the
 * information required for token based access to your Ethereum nodes.
 */
export declare const getAccessor: API.OperationMethod<GetAccessorInput, GetAccessorOutput, GetAccessorError, Credentials | HttpClient.HttpClient>;
export type GetMemberError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns detailed information about a member.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const getMember: API.OperationMethod<GetMemberInput, GetMemberOutput, GetMemberError, Credentials | HttpClient.HttpClient>;
export type GetNetworkError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns detailed information about a network.
 *
 * Applies to Hyperledger Fabric and Ethereum.
 */
export declare const getNetwork: API.OperationMethod<GetNetworkInput, GetNetworkOutput, GetNetworkError, Credentials | HttpClient.HttpClient>;
export type GetNodeError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns detailed information about a node.
 *
 * Applies to Hyperledger Fabric and Ethereum.
 */
export declare const getNode: API.OperationMethod<GetNodeInput, GetNodeOutput, GetNodeError, Credentials | HttpClient.HttpClient>;
export type GetProposalError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns detailed information about a proposal.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const getProposal: API.OperationMethod<GetProposalInput, GetProposalOutput, GetProposalError, Credentials | HttpClient.HttpClient>;
export type ListAccessorsError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Returns a list of the accessors and their properties. Accessor objects are containers that have the
 * information required for token based access to your Ethereum nodes.
 */
export declare const listAccessors: API.PaginatedOperationMethod<ListAccessorsInput, ListAccessorsOutput, ListAccessorsError, Credentials | HttpClient.HttpClient, AccessorSummary>;
export type ListInvitationsError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceLimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of all invitations for the current Amazon Web Services account.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const listInvitations: API.PaginatedOperationMethod<ListInvitationsInput, ListInvitationsOutput, ListInvitationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMembersError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Returns a list of the members in a network and properties of their configurations.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const listMembers: API.PaginatedOperationMethod<ListMembersInput, ListMembersOutput, ListMembersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListNetworksError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Returns information about the networks in which the current Amazon Web Services account participates.
 *
 * Applies to Hyperledger Fabric and Ethereum.
 */
export declare const listNetworks: API.PaginatedOperationMethod<ListNetworksInput, ListNetworksOutput, ListNetworksError, Credentials | HttpClient.HttpClient, unknown>;
export type ListNodesError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Returns information about the nodes within a network.
 *
 * Applies to Hyperledger Fabric and Ethereum.
 */
export declare const listNodes: API.PaginatedOperationMethod<ListNodesInput, ListNodesOutput, ListNodesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListProposalsError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of proposals for the network.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const listProposals: API.PaginatedOperationMethod<ListProposalsInput, ListProposalsOutput, ListProposalsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListProposalVotesError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Returns the list of votes for a specified proposal, including the value of each vote and the unique identifier of the member that cast the vote.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const listProposalVotes: API.PaginatedOperationMethod<ListProposalVotesInput, ListProposalVotesOutput, ListProposalVotesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ResourceNotReadyException | CommonErrors;
/**
 * Returns a list of tags for the specified resource. Each tag consists of a key and optional value.
 *
 * For more information about tags, see Tagging Resources in the *Amazon Managed Blockchain Ethereum Developer Guide*, or Tagging Resources in the *Amazon Managed Blockchain Hyperledger Fabric Developer Guide*.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RejectInvitationError = AccessDeniedException | IllegalActionException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Rejects an invitation to join a network. This action can be called by a principal in an Amazon Web Services account that has received an invitation to create a member and join a network.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const rejectInvitation: API.OperationMethod<RejectInvitationInput, RejectInvitationOutput, RejectInvitationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ResourceNotReadyException | TooManyTagsException | CommonErrors;
/**
 * Adds or overwrites the specified tags for the specified Amazon Managed Blockchain resource. Each tag consists of a key and optional value.
 *
 * When you specify a tag key that already exists, the tag value is overwritten with the new value. Use `UntagResource` to remove tag keys.
 *
 * A resource can have up to 50 tags. If you try to create more than 50 tags for a resource, your request fails and returns an error.
 *
 * For more information about tags, see Tagging Resources in the *Amazon Managed Blockchain Ethereum Developer Guide*, or Tagging Resources in the *Amazon Managed Blockchain Hyperledger Fabric Developer Guide*.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ResourceNotReadyException | CommonErrors;
/**
 * Removes the specified tags from the Amazon Managed Blockchain resource.
 *
 * For more information about tags, see Tagging Resources in the *Amazon Managed Blockchain Ethereum Developer Guide*, or Tagging Resources in the *Amazon Managed Blockchain Hyperledger Fabric Developer Guide*.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateMemberError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a member configuration with new parameters.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const updateMember: API.OperationMethod<UpdateMemberInput, UpdateMemberOutput, UpdateMemberError, Credentials | HttpClient.HttpClient>;
export type UpdateNodeError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a node configuration with new parameters.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const updateNode: API.OperationMethod<UpdateNodeInput, UpdateNodeOutput, UpdateNodeError, Credentials | HttpClient.HttpClient>;
export type VoteOnProposalError = AccessDeniedException | IllegalActionException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Casts a vote for a specified `ProposalId` on behalf of a member. The member to vote as, specified by `VoterMemberId`, must be in the same Amazon Web Services account as the principal that calls the action.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const voteOnProposal: API.OperationMethod<VoteOnProposalInput, VoteOnProposalOutput, VoteOnProposalError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=managedblockchain.d.ts.map