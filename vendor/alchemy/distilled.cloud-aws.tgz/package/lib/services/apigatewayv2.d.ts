import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import * as T from "../traits.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly LimitType: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type SelectionExpression = string;
export type CorsHeaderList = string[];
export type StringWithLengthBetween1And64 = string;
export type CorsMethodList = string[];
export type CorsOriginList = string[];
export type IntegerWithLengthBetweenMinus1And86400 = number;
export interface Cors {
    AllowCredentials?: boolean;
    AllowHeaders?: string[];
    AllowMethods?: string[];
    AllowOrigins?: string[];
    ExposeHeaders?: string[];
    MaxAge?: number;
}
export type Arn = string;
export type StringWithLengthBetween0And1024 = string;
export type IpAddressType = "ipv4" | "dualstack" | (string & {});
export type StringWithLengthBetween1And128 = string;
export type ProtocolType = "WEBSOCKET" | "HTTP" | (string & {});
export type SelectionKey = string;
export type StringWithLengthBetween1And1600 = string;
export type Tags = {
    [key: string]: string | undefined;
};
export type UriWithLengthBetween1And2048 = string;
export interface CreateApiRequest {
    ApiKeySelectionExpression?: string;
    CorsConfiguration?: Cors;
    CredentialsArn?: string;
    Description?: string;
    DisableSchemaValidation?: boolean;
    DisableExecuteApiEndpoint?: boolean;
    IpAddressType?: IpAddressType;
    Name?: string;
    ProtocolType?: ProtocolType;
    RouteKey?: string;
    RouteSelectionExpression?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Target?: string;
    Version?: string;
}
export type Id = string;
export type __timestampIso8601 = Date;
export type __listOf__string = string[];
export interface CreateApiResponse {
    ApiEndpoint?: string;
    ApiGatewayManaged?: boolean;
    ApiId?: string;
    ApiKeySelectionExpression?: string;
    CorsConfiguration?: Cors;
    CreatedDate?: Date;
    Description?: string;
    DisableSchemaValidation?: boolean;
    DisableExecuteApiEndpoint?: boolean;
    ImportInfo?: string[];
    IpAddressType?: IpAddressType;
    Name?: string;
    ProtocolType?: ProtocolType;
    RouteSelectionExpression?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Version?: string;
    Warnings?: string[];
}
export interface CreateApiMappingRequest {
    ApiId?: string;
    ApiMappingKey?: string;
    DomainName: string;
    Stage?: string;
}
export interface CreateApiMappingResponse {
    ApiId?: string;
    ApiMappingId?: string;
    ApiMappingKey?: string;
    Stage?: string;
}
export type IntegerWithLengthBetween0And3600 = number;
export type AuthorizerType = "REQUEST" | "JWT" | (string & {});
export type IdentitySourceList = string[];
export interface JWTConfiguration {
    Audience?: string[];
    Issuer?: string;
}
export interface CreateAuthorizerRequest {
    ApiId: string;
    AuthorizerCredentialsArn?: string;
    AuthorizerPayloadFormatVersion?: string;
    AuthorizerResultTtlInSeconds?: number;
    AuthorizerType?: AuthorizerType;
    AuthorizerUri?: string;
    EnableSimpleResponses?: boolean;
    IdentitySource?: string[];
    IdentityValidationExpression?: string;
    JwtConfiguration?: JWTConfiguration;
    Name?: string;
}
export interface CreateAuthorizerResponse {
    AuthorizerCredentialsArn?: string;
    AuthorizerId?: string;
    AuthorizerPayloadFormatVersion?: string;
    AuthorizerResultTtlInSeconds?: number;
    AuthorizerType?: AuthorizerType;
    AuthorizerUri?: string;
    EnableSimpleResponses?: boolean;
    IdentitySource?: string[];
    IdentityValidationExpression?: string;
    JwtConfiguration?: JWTConfiguration;
    Name?: string;
}
export interface CreateDeploymentRequest {
    ApiId: string;
    Description?: string;
    StageName?: string;
}
export type DeploymentStatus = "PENDING" | "FAILED" | "DEPLOYED" | (string & {});
export interface CreateDeploymentResponse {
    AutoDeployed?: boolean;
    CreatedDate?: Date;
    DeploymentId?: string;
    DeploymentStatus?: DeploymentStatus;
    DeploymentStatusMessage?: string;
    Description?: string;
}
export type StringWithLengthBetween1And512 = string;
export type DomainNameStatus = "AVAILABLE" | "UPDATING" | "PENDING_CERTIFICATE_REIMPORT" | "PENDING_OWNERSHIP_VERIFICATION" | (string & {});
export type EndpointType = "REGIONAL" | "EDGE" | (string & {});
export type SecurityPolicy = "TLS_1_0" | "TLS_1_2" | (string & {});
export interface DomainNameConfiguration {
    ApiGatewayDomainName?: string;
    CertificateArn?: string;
    CertificateName?: string;
    CertificateUploadDate?: Date;
    DomainNameStatus?: DomainNameStatus;
    DomainNameStatusMessage?: string;
    EndpointType?: EndpointType;
    HostedZoneId?: string;
    IpAddressType?: IpAddressType;
    SecurityPolicy?: SecurityPolicy;
    OwnershipVerificationCertificateArn?: string;
}
export type DomainNameConfigurations = DomainNameConfiguration[];
export interface MutualTlsAuthenticationInput {
    TruststoreUri?: string;
    TruststoreVersion?: string;
}
export type RoutingMode = "API_MAPPING_ONLY" | "ROUTING_RULE_ONLY" | "ROUTING_RULE_THEN_API_MAPPING" | (string & {});
export interface CreateDomainNameRequest {
    DomainName?: string;
    DomainNameConfigurations?: DomainNameConfiguration[];
    MutualTlsAuthentication?: MutualTlsAuthenticationInput;
    RoutingMode?: RoutingMode;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface MutualTlsAuthentication {
    TruststoreUri?: string;
    TruststoreVersion?: string;
    TruststoreWarnings?: string[];
}
export interface CreateDomainNameResponse {
    ApiMappingSelectionExpression?: string;
    DomainName?: string;
    DomainNameArn?: string;
    DomainNameConfigurations?: DomainNameConfiguration[];
    MutualTlsAuthentication?: MutualTlsAuthentication;
    RoutingMode?: RoutingMode;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type StringWithLengthBetween1And1024 = string;
export type ConnectionType = "INTERNET" | "VPC_LINK" | (string & {});
export type ContentHandlingStrategy = "CONVERT_TO_BINARY" | "CONVERT_TO_TEXT" | (string & {});
export type IntegrationType = "AWS" | "HTTP" | "MOCK" | "HTTP_PROXY" | "AWS_PROXY" | (string & {});
export type PassthroughBehavior = "WHEN_NO_MATCH" | "NEVER" | "WHEN_NO_TEMPLATES" | (string & {});
export type IntegrationParameters = {
    [key: string]: string | undefined;
};
export type StringWithLengthBetween0And32K = string;
export type TemplateMap = {
    [key: string]: string | undefined;
};
export type ResponseParameters = {
    [key: string]: {
        [key: string]: string | undefined;
    } | undefined;
};
export type IntegerWithLengthBetween50And30000 = number;
export interface TlsConfigInput {
    ServerNameToVerify?: string;
}
export interface CreateIntegrationRequest {
    ApiId: string;
    ConnectionId?: string;
    ConnectionType?: ConnectionType;
    ContentHandlingStrategy?: ContentHandlingStrategy;
    CredentialsArn?: string;
    Description?: string;
    IntegrationMethod?: string;
    IntegrationSubtype?: string;
    IntegrationType?: IntegrationType;
    IntegrationUri?: string;
    PassthroughBehavior?: PassthroughBehavior;
    PayloadFormatVersion?: string;
    RequestParameters?: {
        [key: string]: string | undefined;
    };
    RequestTemplates?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    TemplateSelectionExpression?: string;
    TimeoutInMillis?: number;
    TlsConfig?: TlsConfigInput;
}
export interface TlsConfig {
    ServerNameToVerify?: string;
}
export interface CreateIntegrationResult {
    ApiGatewayManaged?: boolean;
    ConnectionId?: string;
    ConnectionType?: ConnectionType;
    ContentHandlingStrategy?: ContentHandlingStrategy;
    CredentialsArn?: string;
    Description?: string;
    IntegrationId?: string;
    IntegrationMethod?: string;
    IntegrationResponseSelectionExpression?: string;
    IntegrationSubtype?: string;
    IntegrationType?: IntegrationType;
    IntegrationUri?: string;
    PassthroughBehavior?: PassthroughBehavior;
    PayloadFormatVersion?: string;
    RequestParameters?: {
        [key: string]: string | undefined;
    };
    RequestTemplates?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    TemplateSelectionExpression?: string;
    TimeoutInMillis?: number;
    TlsConfig?: TlsConfig;
}
export interface CreateIntegrationResponseRequest {
    ApiId: string;
    ContentHandlingStrategy?: ContentHandlingStrategy;
    IntegrationId: string;
    IntegrationResponseKey?: string;
    ResponseParameters?: {
        [key: string]: string | undefined;
    };
    ResponseTemplates?: {
        [key: string]: string | undefined;
    };
    TemplateSelectionExpression?: string;
}
export interface CreateIntegrationResponseResponse {
    ContentHandlingStrategy?: ContentHandlingStrategy;
    IntegrationResponseId?: string;
    IntegrationResponseKey?: string;
    ResponseParameters?: {
        [key: string]: string | undefined;
    };
    ResponseTemplates?: {
        [key: string]: string | undefined;
    };
    TemplateSelectionExpression?: string;
}
export type StringWithLengthBetween1And256 = string;
export interface CreateModelRequest {
    ApiId: string;
    ContentType?: string;
    Description?: string;
    Name?: string;
    Schema?: string;
}
export interface CreateModelResponse {
    ContentType?: string;
    Description?: string;
    ModelId?: string;
    Name?: string;
    Schema?: string;
}
export type __stringMin1Max256 = string;
export type __stringMin20Max2048 = string;
export interface CognitoConfig {
    AppClientId?: string;
    UserPoolArn?: string;
    UserPoolDomain?: string;
}
export interface None {
}
export interface Authorization {
    CognitoConfig?: CognitoConfig;
    None?: None;
}
export type __stringMin10Max2048 = string;
export type __stringMin3Max256 = string;
export interface ACMManaged {
    CertificateArn?: string;
    DomainName?: string;
}
export interface EndpointConfigurationRequest {
    AcmManaged?: ACMManaged;
    None?: None;
}
export type __listOf__stringMin20Max2048 = string[];
export type __stringMin0Max1092 = string;
export type __stringMin0Max1024 = string;
export type __stringMin3Max255 = string;
export type __stringMin1Max16 = string;
export interface CustomColors {
    AccentColor?: string;
    BackgroundColor?: string;
    ErrorValidationColor?: string;
    HeaderColor?: string;
    NavigationColor?: string;
    TextColor?: string;
}
export interface PortalTheme {
    CustomColors?: CustomColors;
    LogoLastUploaded?: Date;
}
export interface PortalContent {
    Description?: string;
    DisplayName?: string;
    Theme?: PortalTheme;
}
export type __stringMin0Max255 = string;
export interface CreatePortalRequest {
    Authorization?: Authorization;
    EndpointConfiguration?: EndpointConfigurationRequest;
    IncludedPortalProductArns?: string[];
    LogoUri?: string;
    PortalContent?: PortalContent;
    RumAppMonitorName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __stringMin1Max64 = string;
export interface EndpointConfigurationResponse {
    CertificateArn?: string;
    DomainName?: string;
    PortalDefaultDomainName?: string;
    PortalDomainHostedZoneId?: string;
}
export type __stringMin10Max30PatternAZ09 = string;
export type PublishStatus = "PUBLISHED" | "PUBLISH_IN_PROGRESS" | "PUBLISH_FAILED" | "DISABLE_IN_PROGRESS" | "DISABLE_FAILED" | "DISABLED" | (string & {});
export type __stringMin1Max2048 = string;
export interface StatusException {
    Exception?: string;
    Message?: string;
}
export interface CreatePortalResponse {
    Authorization?: Authorization & {
        CognitoConfig: CognitoConfig & {
            AppClientId: __stringMin1Max256;
            UserPoolArn: __stringMin20Max2048;
            UserPoolDomain: __stringMin20Max2048;
        };
    };
    EndpointConfiguration?: EndpointConfigurationResponse & {
        PortalDefaultDomainName: __stringMin3Max256;
        PortalDomainHostedZoneId: __stringMin1Max64;
    };
    IncludedPortalProductArns?: string[];
    LastModified?: Date;
    LastPublished?: Date;
    LastPublishedDescription?: string;
    PortalArn?: string;
    PortalContent?: PortalContent & {
        DisplayName: __stringMin3Max255;
        Theme: PortalTheme & {
            CustomColors: CustomColors & {
                AccentColor: __stringMin1Max16;
                BackgroundColor: __stringMin1Max16;
                ErrorValidationColor: __stringMin1Max16;
                HeaderColor: __stringMin1Max16;
                NavigationColor: __stringMin1Max16;
                TextColor: __stringMin1Max16;
            };
        };
    };
    PortalId?: string;
    PublishStatus?: PublishStatus;
    RumAppMonitorName?: string;
    StatusException?: StatusException;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __stringMin1Max255 = string;
export interface CreatePortalProductRequest {
    Description?: string;
    DisplayName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface Section {
    ProductRestEndpointPageArns?: string[];
    SectionName?: string;
}
export type __listOfSection = Section[];
export interface DisplayOrder {
    Contents?: Section[];
    OverviewPageArn?: string;
    ProductPageArns?: string[];
}
export interface CreatePortalProductResponse {
    Description?: string;
    DisplayName?: string;
    DisplayOrder?: DisplayOrder & {
        Contents: (Section & {
            ProductRestEndpointPageArns: __listOf__stringMin20Max2048;
            SectionName: string;
        })[];
    };
    LastModified?: Date;
    PortalProductArn?: string;
    PortalProductId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __stringMin1Max32768 = string;
export interface DisplayContent {
    Body?: string;
    Title?: string;
}
export interface CreateProductPageRequest {
    DisplayContent?: DisplayContent;
    PortalProductId: string;
}
export interface CreateProductPageResponse {
    DisplayContent?: DisplayContent & {
        Body: __stringMin1Max32768;
        Title: __stringMin1Max255;
    };
    LastModified?: Date;
    ProductPageArn?: string;
    ProductPageId?: string;
}
export type __stringMin1Max1024 = string;
export interface DisplayContentOverrides {
    Body?: string;
    Endpoint?: string;
    OperationName?: string;
}
export interface EndpointDisplayContent {
    None?: None;
    Overrides?: DisplayContentOverrides;
}
export type __stringMin1Max20 = string;
export type __stringMin1Max4096 = string;
export type __stringMin1Max50 = string;
export type __stringMin1Max128 = string;
export interface IdentifierParts {
    Method?: string;
    Path?: string;
    RestApiId?: string;
    Stage?: string;
}
export interface RestEndpointIdentifier {
    IdentifierParts?: IdentifierParts;
}
export type TryItState = "ENABLED" | "DISABLED" | (string & {});
export interface CreateProductRestEndpointPageRequest {
    DisplayContent?: EndpointDisplayContent;
    PortalProductId: string;
    RestEndpointIdentifier?: RestEndpointIdentifier;
    TryItState?: TryItState;
}
export interface EndpointDisplayContentResponse {
    Body?: string;
    Endpoint?: string;
    OperationName?: string;
}
export type Status = "AVAILABLE" | "IN_PROGRESS" | "FAILED" | (string & {});
export interface CreateProductRestEndpointPageResponse {
    DisplayContent?: EndpointDisplayContentResponse & {
        Endpoint: __stringMin1Max1024;
    };
    LastModified?: Date;
    ProductRestEndpointPageArn?: string;
    ProductRestEndpointPageId?: string;
    RestEndpointIdentifier?: RestEndpointIdentifier & {
        IdentifierParts: IdentifierParts & {
            Method: __stringMin1Max20;
            Path: __stringMin1Max4096;
            RestApiId: __stringMin1Max50;
            Stage: __stringMin1Max128;
        };
    };
    Status?: Status;
    StatusException?: StatusException;
    TryItState?: TryItState;
}
export type AuthorizationScopes = string[];
export type AuthorizationType = "NONE" | "AWS_IAM" | "CUSTOM" | "JWT" | (string & {});
export type RouteModels = {
    [key: string]: string | undefined;
};
export interface ParameterConstraints {
    Required?: boolean;
}
export type RouteParameters = {
    [key: string]: ParameterConstraints | undefined;
};
export interface CreateRouteRequest {
    ApiId: string;
    ApiKeyRequired?: boolean;
    AuthorizationScopes?: string[];
    AuthorizationType?: AuthorizationType;
    AuthorizerId?: string;
    ModelSelectionExpression?: string;
    OperationName?: string;
    RequestModels?: {
        [key: string]: string | undefined;
    };
    RequestParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteKey?: string;
    RouteResponseSelectionExpression?: string;
    Target?: string;
}
export interface CreateRouteResult {
    ApiGatewayManaged?: boolean;
    ApiKeyRequired?: boolean;
    AuthorizationScopes?: string[];
    AuthorizationType?: AuthorizationType;
    AuthorizerId?: string;
    ModelSelectionExpression?: string;
    OperationName?: string;
    RequestModels?: {
        [key: string]: string | undefined;
    };
    RequestParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteId?: string;
    RouteKey?: string;
    RouteResponseSelectionExpression?: string;
    Target?: string;
}
export interface CreateRouteResponseRequest {
    ApiId: string;
    ModelSelectionExpression?: string;
    ResponseModels?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteId: string;
    RouteResponseKey?: string;
}
export interface CreateRouteResponseResponse {
    ModelSelectionExpression?: string;
    ResponseModels?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteResponseId?: string;
    RouteResponseKey?: string;
}
export interface RoutingRuleActionInvokeApi {
    ApiId?: string;
    Stage?: string;
    StripBasePath?: boolean;
}
export interface RoutingRuleAction {
    InvokeApi?: RoutingRuleActionInvokeApi;
}
export type __listOfRoutingRuleAction = RoutingRuleAction[];
export type __listOfSelectionKey = string[];
export interface RoutingRuleMatchBasePaths {
    AnyOf?: string[];
}
export interface RoutingRuleMatchHeaderValue {
    Header?: string;
    ValueGlob?: string;
}
export type __listOfRoutingRuleMatchHeaderValue = RoutingRuleMatchHeaderValue[];
export interface RoutingRuleMatchHeaders {
    AnyOf?: RoutingRuleMatchHeaderValue[];
}
export interface RoutingRuleCondition {
    MatchBasePaths?: RoutingRuleMatchBasePaths;
    MatchHeaders?: RoutingRuleMatchHeaders;
}
export type __listOfRoutingRuleCondition = RoutingRuleCondition[];
export type RoutingRulePriority = number;
export interface CreateRoutingRuleRequest {
    Actions?: RoutingRuleAction[];
    Conditions?: RoutingRuleCondition[];
    DomainName: string;
    DomainNameId?: string;
    Priority?: number;
}
export interface CreateRoutingRuleResponse {
    Actions?: (RoutingRuleAction & {
        InvokeApi: RoutingRuleActionInvokeApi & {
            ApiId: Id;
            Stage: StringWithLengthBetween1And128;
        };
    })[];
    Conditions?: (RoutingRuleCondition & {
        MatchBasePaths: RoutingRuleMatchBasePaths & {
            AnyOf: __listOfSelectionKey;
        };
        MatchHeaders: RoutingRuleMatchHeaders & {
            AnyOf: (RoutingRuleMatchHeaderValue & {
                Header: SelectionKey;
                ValueGlob: SelectionExpression;
            })[];
        };
    })[];
    Priority?: number;
    RoutingRuleArn?: string;
    RoutingRuleId?: string;
}
export interface AccessLogSettings {
    DestinationArn?: string;
    Format?: string;
}
export type LoggingLevel = "ERROR" | "INFO" | "OFF" | (string & {});
export interface RouteSettings {
    DataTraceEnabled?: boolean;
    DetailedMetricsEnabled?: boolean;
    LoggingLevel?: LoggingLevel;
    ThrottlingBurstLimit?: number;
    ThrottlingRateLimit?: number;
}
export type RouteSettingsMap = {
    [key: string]: RouteSettings | undefined;
};
export type StringWithLengthBetween0And2048 = string;
export type StageVariablesMap = {
    [key: string]: string | undefined;
};
export interface CreateStageRequest {
    AccessLogSettings?: AccessLogSettings;
    ApiId: string;
    AutoDeploy?: boolean;
    ClientCertificateId?: string;
    DefaultRouteSettings?: RouteSettings;
    DeploymentId?: string;
    Description?: string;
    RouteSettings?: {
        [key: string]: RouteSettings | undefined;
    };
    StageName?: string;
    StageVariables?: {
        [key: string]: string | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateStageResponse {
    AccessLogSettings?: AccessLogSettings;
    ApiGatewayManaged?: boolean;
    AutoDeploy?: boolean;
    ClientCertificateId?: string;
    CreatedDate?: Date;
    DefaultRouteSettings?: RouteSettings;
    DeploymentId?: string;
    Description?: string;
    LastDeploymentStatusMessage?: string;
    LastUpdatedDate?: Date;
    RouteSettings?: {
        [key: string]: RouteSettings | undefined;
    };
    StageName?: string;
    StageVariables?: {
        [key: string]: string | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type SecurityGroupIdList = string[];
export type SubnetIdList = string[];
export interface CreateVpcLinkRequest {
    Name?: string;
    SecurityGroupIds?: string[];
    SubnetIds?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type VpcLinkStatus = "PENDING" | "AVAILABLE" | "DELETING" | "FAILED" | "INACTIVE" | (string & {});
export type VpcLinkVersion = "V2" | (string & {});
export interface CreateVpcLinkResponse {
    CreatedDate?: Date;
    Name?: string;
    SecurityGroupIds?: string[];
    SubnetIds?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
    VpcLinkId?: string;
    VpcLinkStatus?: VpcLinkStatus;
    VpcLinkStatusMessage?: string;
    VpcLinkVersion?: VpcLinkVersion;
}
export interface DeleteAccessLogSettingsRequest {
    ApiId: string;
    StageName: string;
}
export interface DeleteAccessLogSettingsResponse {
}
export interface DeleteApiRequest {
    ApiId: string;
}
export interface DeleteApiResponse {
}
export interface DeleteApiMappingRequest {
    ApiMappingId: string;
    DomainName: string;
}
export interface DeleteApiMappingResponse {
}
export interface DeleteAuthorizerRequest {
    ApiId: string;
    AuthorizerId: string;
}
export interface DeleteAuthorizerResponse {
}
export interface DeleteCorsConfigurationRequest {
    ApiId: string;
}
export interface DeleteCorsConfigurationResponse {
}
export interface DeleteDeploymentRequest {
    ApiId: string;
    DeploymentId: string;
}
export interface DeleteDeploymentResponse {
}
export interface DeleteDomainNameRequest {
    DomainName: string;
}
export interface DeleteDomainNameResponse {
}
export interface DeleteIntegrationRequest {
    ApiId: string;
    IntegrationId: string;
}
export interface DeleteIntegrationResponse {
}
export interface DeleteIntegrationResponseRequest {
    ApiId: string;
    IntegrationId: string;
    IntegrationResponseId: string;
}
export interface DeleteIntegrationResponseResponse {
}
export interface DeleteModelRequest {
    ApiId: string;
    ModelId: string;
}
export interface DeleteModelResponse {
}
export interface DeletePortalRequest {
    PortalId: string;
}
export interface DeletePortalResponse {
}
export interface DeletePortalProductRequest {
    PortalProductId: string;
}
export interface DeletePortalProductResponse {
}
export interface DeletePortalProductSharingPolicyRequest {
    PortalProductId: string;
}
export interface DeletePortalProductSharingPolicyResponse {
}
export interface DeleteProductPageRequest {
    PortalProductId: string;
    ProductPageId: string;
}
export interface DeleteProductPageResponse {
}
export interface DeleteProductRestEndpointPageRequest {
    PortalProductId: string;
    ProductRestEndpointPageId: string;
}
export interface DeleteProductRestEndpointPageResponse {
}
export interface DeleteRouteRequest {
    ApiId: string;
    RouteId: string;
}
export interface DeleteRouteResponse {
}
export interface DeleteRouteRequestParameterRequest {
    ApiId: string;
    RequestParameterKey: string;
    RouteId: string;
}
export interface DeleteRouteRequestParameterResponse {
}
export interface DeleteRouteResponseRequest {
    ApiId: string;
    RouteId: string;
    RouteResponseId: string;
}
export interface DeleteRouteResponseResponse {
}
export interface DeleteRouteSettingsRequest {
    ApiId: string;
    RouteKey: string;
    StageName: string;
}
export interface DeleteRouteSettingsResponse {
}
export interface DeleteRoutingRuleRequest {
    DomainName: string;
    DomainNameId?: string;
    RoutingRuleId: string;
}
export interface DeleteRoutingRuleResponse {
}
export interface DeleteStageRequest {
    ApiId: string;
    StageName: string;
}
export interface DeleteStageResponse {
}
export interface DeleteVpcLinkRequest {
    VpcLinkId: string;
}
export interface DeleteVpcLinkResponse {
}
export interface DisablePortalRequest {
    PortalId: string;
}
export interface DisablePortalResponse {
}
export interface ExportApiRequest {
    ApiId: string;
    ExportVersion?: string;
    IncludeExtensions?: boolean;
    OutputType?: string;
    Specification: string;
    StageName?: string;
}
export interface ExportApiResponse {
    body?: T.StreamingOutputBody;
}
export interface GetApiRequest {
    ApiId: string;
}
export interface GetApiResponse {
    ApiEndpoint?: string;
    ApiGatewayManaged?: boolean;
    ApiId?: string;
    ApiKeySelectionExpression?: string;
    CorsConfiguration?: Cors;
    CreatedDate?: Date;
    Description?: string;
    DisableSchemaValidation?: boolean;
    DisableExecuteApiEndpoint?: boolean;
    ImportInfo?: string[];
    IpAddressType?: IpAddressType;
    Name?: string;
    ProtocolType?: ProtocolType;
    RouteSelectionExpression?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Version?: string;
    Warnings?: string[];
}
export interface GetApiMappingRequest {
    ApiMappingId: string;
    DomainName: string;
}
export interface GetApiMappingResponse {
    ApiId?: string;
    ApiMappingId?: string;
    ApiMappingKey?: string;
    Stage?: string;
}
export interface GetApiMappingsRequest {
    DomainName: string;
    MaxResults?: string;
    NextToken?: string;
}
export interface ApiMapping {
    ApiId?: string;
    ApiMappingId?: string;
    ApiMappingKey?: string;
    Stage?: string;
}
export type __listOfApiMapping = ApiMapping[];
export type NextToken = string;
export interface GetApiMappingsResponse {
    Items?: (ApiMapping & {
        ApiId: Id;
        Stage: StringWithLengthBetween1And128;
    })[];
    NextToken?: string;
}
export interface GetApisRequest {
    MaxResults?: string;
    NextToken?: string;
}
export interface Api {
    ApiEndpoint?: string;
    ApiGatewayManaged?: boolean;
    ApiId?: string;
    ApiKeySelectionExpression?: string;
    CorsConfiguration?: Cors;
    CreatedDate?: Date;
    Description?: string;
    DisableSchemaValidation?: boolean;
    DisableExecuteApiEndpoint?: boolean;
    ImportInfo?: string[];
    IpAddressType?: IpAddressType;
    Name?: string;
    ProtocolType?: ProtocolType;
    RouteSelectionExpression?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Version?: string;
    Warnings?: string[];
}
export type __listOfApi = Api[];
export interface GetApisResponse {
    Items?: (Api & {
        Name: StringWithLengthBetween1And128;
        ProtocolType: ProtocolType;
        RouteSelectionExpression: SelectionExpression;
    })[];
    NextToken?: string;
}
export interface GetAuthorizerRequest {
    ApiId: string;
    AuthorizerId: string;
}
export interface GetAuthorizerResponse {
    AuthorizerCredentialsArn?: string;
    AuthorizerId?: string;
    AuthorizerPayloadFormatVersion?: string;
    AuthorizerResultTtlInSeconds?: number;
    AuthorizerType?: AuthorizerType;
    AuthorizerUri?: string;
    EnableSimpleResponses?: boolean;
    IdentitySource?: string[];
    IdentityValidationExpression?: string;
    JwtConfiguration?: JWTConfiguration;
    Name?: string;
}
export interface GetAuthorizersRequest {
    ApiId: string;
    MaxResults?: string;
    NextToken?: string;
}
export interface Authorizer {
    AuthorizerCredentialsArn?: string;
    AuthorizerId?: string;
    AuthorizerPayloadFormatVersion?: string;
    AuthorizerResultTtlInSeconds?: number;
    AuthorizerType?: AuthorizerType;
    AuthorizerUri?: string;
    EnableSimpleResponses?: boolean;
    IdentitySource?: string[];
    IdentityValidationExpression?: string;
    JwtConfiguration?: JWTConfiguration;
    Name?: string;
}
export type __listOfAuthorizer = Authorizer[];
export interface GetAuthorizersResponse {
    Items?: (Authorizer & {
        Name: StringWithLengthBetween1And128;
    })[];
    NextToken?: string;
}
export interface GetDeploymentRequest {
    ApiId: string;
    DeploymentId: string;
}
export interface GetDeploymentResponse {
    AutoDeployed?: boolean;
    CreatedDate?: Date;
    DeploymentId?: string;
    DeploymentStatus?: DeploymentStatus;
    DeploymentStatusMessage?: string;
    Description?: string;
}
export interface GetDeploymentsRequest {
    ApiId: string;
    MaxResults?: string;
    NextToken?: string;
}
export interface Deployment {
    AutoDeployed?: boolean;
    CreatedDate?: Date;
    DeploymentId?: string;
    DeploymentStatus?: DeploymentStatus;
    DeploymentStatusMessage?: string;
    Description?: string;
}
export type __listOfDeployment = Deployment[];
export interface GetDeploymentsResponse {
    Items?: Deployment[];
    NextToken?: string;
}
export interface GetDomainNameRequest {
    DomainName: string;
}
export interface GetDomainNameResponse {
    ApiMappingSelectionExpression?: string;
    DomainName?: string;
    DomainNameArn?: string;
    DomainNameConfigurations?: DomainNameConfiguration[];
    MutualTlsAuthentication?: MutualTlsAuthentication;
    RoutingMode?: RoutingMode;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetDomainNamesRequest {
    MaxResults?: string;
    NextToken?: string;
}
export interface DomainName {
    ApiMappingSelectionExpression?: string;
    DomainName?: string;
    DomainNameArn?: string;
    DomainNameConfigurations?: DomainNameConfiguration[];
    MutualTlsAuthentication?: MutualTlsAuthentication;
    RoutingMode?: RoutingMode;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfDomainName = DomainName[];
export interface GetDomainNamesResponse {
    Items?: (DomainName & {
        DomainName: StringWithLengthBetween1And512;
    })[];
    NextToken?: string;
}
export interface GetIntegrationRequest {
    ApiId: string;
    IntegrationId: string;
}
export interface GetIntegrationResult {
    ApiGatewayManaged?: boolean;
    ConnectionId?: string;
    ConnectionType?: ConnectionType;
    ContentHandlingStrategy?: ContentHandlingStrategy;
    CredentialsArn?: string;
    Description?: string;
    IntegrationId?: string;
    IntegrationMethod?: string;
    IntegrationResponseSelectionExpression?: string;
    IntegrationSubtype?: string;
    IntegrationType?: IntegrationType;
    IntegrationUri?: string;
    PassthroughBehavior?: PassthroughBehavior;
    PayloadFormatVersion?: string;
    RequestParameters?: {
        [key: string]: string | undefined;
    };
    RequestTemplates?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    TemplateSelectionExpression?: string;
    TimeoutInMillis?: number;
    TlsConfig?: TlsConfig;
}
export interface GetIntegrationResponseRequest {
    ApiId: string;
    IntegrationId: string;
    IntegrationResponseId: string;
}
export interface GetIntegrationResponseResponse {
    ContentHandlingStrategy?: ContentHandlingStrategy;
    IntegrationResponseId?: string;
    IntegrationResponseKey?: string;
    ResponseParameters?: {
        [key: string]: string | undefined;
    };
    ResponseTemplates?: {
        [key: string]: string | undefined;
    };
    TemplateSelectionExpression?: string;
}
export interface GetIntegrationResponsesRequest {
    ApiId: string;
    IntegrationId: string;
    MaxResults?: string;
    NextToken?: string;
}
export interface IntegrationResponse {
    ContentHandlingStrategy?: ContentHandlingStrategy;
    IntegrationResponseId?: string;
    IntegrationResponseKey?: string;
    ResponseParameters?: {
        [key: string]: string | undefined;
    };
    ResponseTemplates?: {
        [key: string]: string | undefined;
    };
    TemplateSelectionExpression?: string;
}
export type __listOfIntegrationResponse = IntegrationResponse[];
export interface GetIntegrationResponsesResponse {
    Items?: (IntegrationResponse & {
        IntegrationResponseKey: SelectionKey;
    })[];
    NextToken?: string;
}
export interface GetIntegrationsRequest {
    ApiId: string;
    MaxResults?: string;
    NextToken?: string;
}
export interface Integration {
    ApiGatewayManaged?: boolean;
    ConnectionId?: string;
    ConnectionType?: ConnectionType;
    ContentHandlingStrategy?: ContentHandlingStrategy;
    CredentialsArn?: string;
    Description?: string;
    IntegrationId?: string;
    IntegrationMethod?: string;
    IntegrationResponseSelectionExpression?: string;
    IntegrationSubtype?: string;
    IntegrationType?: IntegrationType;
    IntegrationUri?: string;
    PassthroughBehavior?: PassthroughBehavior;
    PayloadFormatVersion?: string;
    RequestParameters?: {
        [key: string]: string | undefined;
    };
    RequestTemplates?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    TemplateSelectionExpression?: string;
    TimeoutInMillis?: number;
    TlsConfig?: TlsConfig;
}
export type __listOfIntegration = Integration[];
export interface GetIntegrationsResponse {
    Items?: Integration[];
    NextToken?: string;
}
export interface GetModelRequest {
    ApiId: string;
    ModelId: string;
}
export interface GetModelResponse {
    ContentType?: string;
    Description?: string;
    ModelId?: string;
    Name?: string;
    Schema?: string;
}
export interface GetModelsRequest {
    ApiId: string;
    MaxResults?: string;
    NextToken?: string;
}
export interface Model {
    ContentType?: string;
    Description?: string;
    ModelId?: string;
    Name?: string;
    Schema?: string;
}
export type __listOfModel = Model[];
export interface GetModelsResponse {
    Items?: (Model & {
        Name: StringWithLengthBetween1And128;
    })[];
    NextToken?: string;
}
export interface GetModelTemplateRequest {
    ApiId: string;
    ModelId: string;
}
export interface GetModelTemplateResponse {
    Value?: string;
}
export interface GetPortalRequest {
    PortalId: string;
}
export type PreviewStatus = "PREVIEW_IN_PROGRESS" | "PREVIEW_FAILED" | "PREVIEW_READY" | (string & {});
export interface Preview {
    PreviewStatus?: PreviewStatus;
    PreviewUrl?: string;
    StatusException?: StatusException;
}
export interface GetPortalResponse {
    Authorization?: Authorization & {
        CognitoConfig: CognitoConfig & {
            AppClientId: __stringMin1Max256;
            UserPoolArn: __stringMin20Max2048;
            UserPoolDomain: __stringMin20Max2048;
        };
    };
    EndpointConfiguration?: EndpointConfigurationResponse & {
        PortalDefaultDomainName: __stringMin3Max256;
        PortalDomainHostedZoneId: __stringMin1Max64;
    };
    IncludedPortalProductArns?: string[];
    LastModified?: Date;
    LastPublished?: Date;
    LastPublishedDescription?: string;
    PortalArn?: string;
    PortalContent?: PortalContent & {
        DisplayName: __stringMin3Max255;
        Theme: PortalTheme & {
            CustomColors: CustomColors & {
                AccentColor: __stringMin1Max16;
                BackgroundColor: __stringMin1Max16;
                ErrorValidationColor: __stringMin1Max16;
                HeaderColor: __stringMin1Max16;
                NavigationColor: __stringMin1Max16;
                TextColor: __stringMin1Max16;
            };
        };
    };
    PortalId?: string;
    Preview?: Preview & {
        PreviewStatus: PreviewStatus;
    };
    PublishStatus?: PublishStatus;
    RumAppMonitorName?: string;
    StatusException?: StatusException;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetPortalProductRequest {
    PortalProductId: string;
    ResourceOwnerAccountId?: string;
}
export interface GetPortalProductResponse {
    Description?: string;
    DisplayName?: string;
    DisplayOrder?: DisplayOrder & {
        Contents: (Section & {
            ProductRestEndpointPageArns: __listOf__stringMin20Max2048;
            SectionName: string;
        })[];
    };
    LastModified?: Date;
    PortalProductArn?: string;
    PortalProductId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetPortalProductSharingPolicyRequest {
    PortalProductId: string;
}
export type __stringMin1Max307200 = string;
export interface GetPortalProductSharingPolicyResponse {
    PolicyDocument?: string;
    PortalProductId?: string;
}
export interface GetProductPageRequest {
    PortalProductId: string;
    ProductPageId: string;
    ResourceOwnerAccountId?: string;
}
export interface GetProductPageResponse {
    DisplayContent?: DisplayContent & {
        Body: __stringMin1Max32768;
        Title: __stringMin1Max255;
    };
    LastModified?: Date;
    ProductPageArn?: string;
    ProductPageId?: string;
}
export interface GetProductRestEndpointPageRequest {
    IncludeRawDisplayContent?: string;
    PortalProductId: string;
    ProductRestEndpointPageId: string;
    ResourceOwnerAccountId?: string;
}
export interface GetProductRestEndpointPageResponse {
    DisplayContent?: EndpointDisplayContentResponse & {
        Endpoint: __stringMin1Max1024;
    };
    LastModified?: Date;
    ProductRestEndpointPageArn?: string;
    ProductRestEndpointPageId?: string;
    RawDisplayContent?: string;
    RestEndpointIdentifier?: RestEndpointIdentifier & {
        IdentifierParts: IdentifierParts & {
            Method: __stringMin1Max20;
            Path: __stringMin1Max4096;
            RestApiId: __stringMin1Max50;
            Stage: __stringMin1Max128;
        };
    };
    Status?: Status;
    StatusException?: StatusException;
    TryItState?: TryItState;
}
export interface GetRouteRequest {
    ApiId: string;
    RouteId: string;
}
export interface GetRouteResult {
    ApiGatewayManaged?: boolean;
    ApiKeyRequired?: boolean;
    AuthorizationScopes?: string[];
    AuthorizationType?: AuthorizationType;
    AuthorizerId?: string;
    ModelSelectionExpression?: string;
    OperationName?: string;
    RequestModels?: {
        [key: string]: string | undefined;
    };
    RequestParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteId?: string;
    RouteKey?: string;
    RouteResponseSelectionExpression?: string;
    Target?: string;
}
export interface GetRouteResponseRequest {
    ApiId: string;
    RouteId: string;
    RouteResponseId: string;
}
export interface GetRouteResponseResponse {
    ModelSelectionExpression?: string;
    ResponseModels?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteResponseId?: string;
    RouteResponseKey?: string;
}
export interface GetRouteResponsesRequest {
    ApiId: string;
    MaxResults?: string;
    NextToken?: string;
    RouteId: string;
}
export interface RouteResponse {
    ModelSelectionExpression?: string;
    ResponseModels?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteResponseId?: string;
    RouteResponseKey?: string;
}
export type __listOfRouteResponse = RouteResponse[];
export interface GetRouteResponsesResponse {
    Items?: (RouteResponse & {
        RouteResponseKey: SelectionKey;
    })[];
    NextToken?: string;
}
export interface GetRoutesRequest {
    ApiId: string;
    MaxResults?: string;
    NextToken?: string;
}
export interface Route {
    ApiGatewayManaged?: boolean;
    ApiKeyRequired?: boolean;
    AuthorizationScopes?: string[];
    AuthorizationType?: AuthorizationType;
    AuthorizerId?: string;
    ModelSelectionExpression?: string;
    OperationName?: string;
    RequestModels?: {
        [key: string]: string | undefined;
    };
    RequestParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteId?: string;
    RouteKey?: string;
    RouteResponseSelectionExpression?: string;
    Target?: string;
}
export type __listOfRoute = Route[];
export interface GetRoutesResponse {
    Items?: (Route & {
        RouteKey: SelectionKey;
    })[];
    NextToken?: string;
}
export interface GetRoutingRuleRequest {
    DomainName: string;
    DomainNameId?: string;
    RoutingRuleId: string;
}
export interface GetRoutingRuleResponse {
    Actions?: (RoutingRuleAction & {
        InvokeApi: RoutingRuleActionInvokeApi & {
            ApiId: Id;
            Stage: StringWithLengthBetween1And128;
        };
    })[];
    Conditions?: (RoutingRuleCondition & {
        MatchBasePaths: RoutingRuleMatchBasePaths & {
            AnyOf: __listOfSelectionKey;
        };
        MatchHeaders: RoutingRuleMatchHeaders & {
            AnyOf: (RoutingRuleMatchHeaderValue & {
                Header: SelectionKey;
                ValueGlob: SelectionExpression;
            })[];
        };
    })[];
    Priority?: number;
    RoutingRuleArn?: string;
    RoutingRuleId?: string;
}
export interface GetStageRequest {
    ApiId: string;
    StageName: string;
}
export interface GetStageResponse {
    AccessLogSettings?: AccessLogSettings;
    ApiGatewayManaged?: boolean;
    AutoDeploy?: boolean;
    ClientCertificateId?: string;
    CreatedDate?: Date;
    DefaultRouteSettings?: RouteSettings;
    DeploymentId?: string;
    Description?: string;
    LastDeploymentStatusMessage?: string;
    LastUpdatedDate?: Date;
    RouteSettings?: {
        [key: string]: RouteSettings | undefined;
    };
    StageName?: string;
    StageVariables?: {
        [key: string]: string | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetStagesRequest {
    ApiId: string;
    MaxResults?: string;
    NextToken?: string;
}
export interface Stage {
    AccessLogSettings?: AccessLogSettings;
    ApiGatewayManaged?: boolean;
    AutoDeploy?: boolean;
    ClientCertificateId?: string;
    CreatedDate?: Date;
    DefaultRouteSettings?: RouteSettings;
    DeploymentId?: string;
    Description?: string;
    LastDeploymentStatusMessage?: string;
    LastUpdatedDate?: Date;
    RouteSettings?: {
        [key: string]: RouteSettings | undefined;
    };
    StageName?: string;
    StageVariables?: {
        [key: string]: string | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfStage = Stage[];
export interface GetStagesResponse {
    Items?: (Stage & {
        StageName: StringWithLengthBetween1And128;
    })[];
    NextToken?: string;
}
export interface GetTagsRequest {
    ResourceArn: string;
}
export interface GetTagsResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetVpcLinkRequest {
    VpcLinkId: string;
}
export interface GetVpcLinkResponse {
    CreatedDate?: Date;
    Name?: string;
    SecurityGroupIds?: string[];
    SubnetIds?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
    VpcLinkId?: string;
    VpcLinkStatus?: VpcLinkStatus;
    VpcLinkStatusMessage?: string;
    VpcLinkVersion?: VpcLinkVersion;
}
export interface GetVpcLinksRequest {
    MaxResults?: string;
    NextToken?: string;
}
export interface VpcLink {
    CreatedDate?: Date;
    Name?: string;
    SecurityGroupIds?: string[];
    SubnetIds?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
    VpcLinkId?: string;
    VpcLinkStatus?: VpcLinkStatus;
    VpcLinkStatusMessage?: string;
    VpcLinkVersion?: VpcLinkVersion;
}
export type __listOfVpcLink = VpcLink[];
export interface GetVpcLinksResponse {
    Items?: (VpcLink & {
        Name: StringWithLengthBetween1And128;
        SecurityGroupIds: SecurityGroupIdList;
        SubnetIds: SubnetIdList;
        VpcLinkId: Id;
    })[];
    NextToken?: string;
}
export interface ImportApiRequest {
    Basepath?: string;
    Body?: string;
    FailOnWarnings?: boolean;
}
export interface ImportApiResponse {
    ApiEndpoint?: string;
    ApiGatewayManaged?: boolean;
    ApiId?: string;
    ApiKeySelectionExpression?: string;
    CorsConfiguration?: Cors;
    CreatedDate?: Date;
    Description?: string;
    DisableSchemaValidation?: boolean;
    DisableExecuteApiEndpoint?: boolean;
    ImportInfo?: string[];
    IpAddressType?: IpAddressType;
    Name?: string;
    ProtocolType?: ProtocolType;
    RouteSelectionExpression?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Version?: string;
    Warnings?: string[];
}
export interface ListPortalProductsRequest {
    MaxResults?: string;
    NextToken?: string;
    ResourceOwner?: string;
}
export interface PortalProductSummary {
    Description?: string;
    DisplayName?: string;
    LastModified?: Date;
    PortalProductArn?: string;
    PortalProductId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfPortalProductSummary = PortalProductSummary[];
export interface ListPortalProductsResponse {
    Items?: (PortalProductSummary & {
        Description: __stringMin0Max1024;
        DisplayName: __stringMin1Max255;
        LastModified: __timestampIso8601;
        PortalProductArn: __stringMin20Max2048;
        PortalProductId: __stringMin10Max30PatternAZ09;
    })[];
    NextToken?: string;
}
export interface ListPortalsRequest {
    MaxResults?: string;
    NextToken?: string;
}
export interface PortalSummary {
    Authorization?: Authorization;
    EndpointConfiguration?: EndpointConfigurationResponse;
    IncludedPortalProductArns?: string[];
    LastModified?: Date;
    LastPublished?: Date;
    LastPublishedDescription?: string;
    PortalArn?: string;
    PortalContent?: PortalContent;
    PortalId?: string;
    Preview?: Preview;
    PublishStatus?: PublishStatus;
    RumAppMonitorName?: string;
    StatusException?: StatusException;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfPortalSummary = PortalSummary[];
export interface ListPortalsResponse {
    Items?: (PortalSummary & {
        Authorization: Authorization & {
            CognitoConfig: CognitoConfig & {
                AppClientId: __stringMin1Max256;
                UserPoolArn: __stringMin20Max2048;
                UserPoolDomain: __stringMin20Max2048;
            };
        };
        EndpointConfiguration: EndpointConfigurationResponse & {
            PortalDefaultDomainName: __stringMin3Max256;
            PortalDomainHostedZoneId: __stringMin1Max64;
        };
        IncludedPortalProductArns: __listOf__stringMin20Max2048;
        LastModified: __timestampIso8601;
        PortalArn: __stringMin20Max2048;
        PortalContent: PortalContent & {
            DisplayName: __stringMin3Max255;
            Theme: PortalTheme & {
                CustomColors: CustomColors & {
                    AccentColor: __stringMin1Max16;
                    BackgroundColor: __stringMin1Max16;
                    ErrorValidationColor: __stringMin1Max16;
                    HeaderColor: __stringMin1Max16;
                    NavigationColor: __stringMin1Max16;
                    TextColor: __stringMin1Max16;
                };
            };
        };
        PortalId: __stringMin10Max30PatternAZ09;
        Preview: Preview & {
            PreviewStatus: PreviewStatus;
        };
    })[];
    NextToken?: string;
}
export interface ListProductPagesRequest {
    MaxResults?: string;
    NextToken?: string;
    PortalProductId: string;
    ResourceOwnerAccountId?: string;
}
export interface ProductPageSummaryNoBody {
    LastModified?: Date;
    PageTitle?: string;
    ProductPageArn?: string;
    ProductPageId?: string;
}
export type __listOfProductPageSummaryNoBody = ProductPageSummaryNoBody[];
export interface ListProductPagesResponse {
    Items?: (ProductPageSummaryNoBody & {
        LastModified: __timestampIso8601;
        PageTitle: __stringMin1Max255;
        ProductPageArn: __stringMin20Max2048;
        ProductPageId: __stringMin10Max30PatternAZ09;
    })[];
    NextToken?: string;
}
export interface ListProductRestEndpointPagesRequest {
    MaxResults?: string;
    NextToken?: string;
    PortalProductId: string;
    ResourceOwnerAccountId?: string;
}
export interface ProductRestEndpointPageSummaryNoBody {
    Endpoint?: string;
    LastModified?: Date;
    OperationName?: string;
    ProductRestEndpointPageArn?: string;
    ProductRestEndpointPageId?: string;
    RestEndpointIdentifier?: RestEndpointIdentifier;
    Status?: Status;
    StatusException?: StatusException;
    TryItState?: TryItState;
}
export type __listOfProductRestEndpointPageSummaryNoBody = ProductRestEndpointPageSummaryNoBody[];
export interface ListProductRestEndpointPagesResponse {
    Items?: (ProductRestEndpointPageSummaryNoBody & {
        Endpoint: __stringMin1Max1024;
        LastModified: __timestampIso8601;
        ProductRestEndpointPageArn: __stringMin20Max2048;
        ProductRestEndpointPageId: __stringMin10Max30PatternAZ09;
        RestEndpointIdentifier: RestEndpointIdentifier & {
            IdentifierParts: IdentifierParts & {
                Method: __stringMin1Max20;
                Path: __stringMin1Max4096;
                RestApiId: __stringMin1Max50;
                Stage: __stringMin1Max128;
            };
        };
        Status: Status;
        TryItState: TryItState;
    })[];
    NextToken?: string;
}
export type MaxResults = number;
export interface ListRoutingRulesRequest {
    DomainName: string;
    DomainNameId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface RoutingRule {
    Actions?: RoutingRuleAction[];
    Conditions?: RoutingRuleCondition[];
    Priority?: number;
    RoutingRuleArn?: string;
    RoutingRuleId?: string;
}
export type __listOfRoutingRule = RoutingRule[];
export interface ListRoutingRulesResponse {
    NextToken?: string;
    RoutingRules?: (RoutingRule & {
        Actions: (RoutingRuleAction & {
            InvokeApi: RoutingRuleActionInvokeApi & {
                ApiId: Id;
                Stage: StringWithLengthBetween1And128;
            };
        })[];
        Conditions: (RoutingRuleCondition & {
            MatchBasePaths: RoutingRuleMatchBasePaths & {
                AnyOf: __listOfSelectionKey;
            };
            MatchHeaders: RoutingRuleMatchHeaders & {
                AnyOf: (RoutingRuleMatchHeaderValue & {
                    Header: SelectionKey;
                    ValueGlob: SelectionExpression;
                })[];
            };
        })[];
    })[];
}
export interface PreviewPortalRequest {
    PortalId: string;
}
export interface PreviewPortalResponse {
}
export interface PublishPortalRequest {
    Description?: string;
    PortalId: string;
}
export interface PublishPortalResponse {
}
export interface PutPortalProductSharingPolicyRequest {
    PolicyDocument?: string;
    PortalProductId: string;
}
export interface PutPortalProductSharingPolicyResponse {
}
export interface PutRoutingRuleRequest {
    Actions?: RoutingRuleAction[];
    Conditions?: RoutingRuleCondition[];
    DomainName: string;
    DomainNameId?: string;
    Priority?: number;
    RoutingRuleId: string;
}
export interface PutRoutingRuleResponse {
    Actions?: (RoutingRuleAction & {
        InvokeApi: RoutingRuleActionInvokeApi & {
            ApiId: Id;
            Stage: StringWithLengthBetween1And128;
        };
    })[];
    Conditions?: (RoutingRuleCondition & {
        MatchBasePaths: RoutingRuleMatchBasePaths & {
            AnyOf: __listOfSelectionKey;
        };
        MatchHeaders: RoutingRuleMatchHeaders & {
            AnyOf: (RoutingRuleMatchHeaderValue & {
                Header: SelectionKey;
                ValueGlob: SelectionExpression;
            })[];
        };
    })[];
    Priority?: number;
    RoutingRuleArn?: string;
    RoutingRuleId?: string;
}
export interface ReimportApiRequest {
    ApiId: string;
    Basepath?: string;
    Body?: string;
    FailOnWarnings?: boolean;
}
export interface ReimportApiResponse {
    ApiEndpoint?: string;
    ApiGatewayManaged?: boolean;
    ApiId?: string;
    ApiKeySelectionExpression?: string;
    CorsConfiguration?: Cors;
    CreatedDate?: Date;
    Description?: string;
    DisableSchemaValidation?: boolean;
    DisableExecuteApiEndpoint?: boolean;
    ImportInfo?: string[];
    IpAddressType?: IpAddressType;
    Name?: string;
    ProtocolType?: ProtocolType;
    RouteSelectionExpression?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Version?: string;
    Warnings?: string[];
}
export interface ResetAuthorizersCacheRequest {
    ApiId: string;
    StageName: string;
}
export interface ResetAuthorizersCacheResponse {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateApiRequest {
    ApiId: string;
    ApiKeySelectionExpression?: string;
    CorsConfiguration?: Cors;
    CredentialsArn?: string;
    Description?: string;
    DisableSchemaValidation?: boolean;
    DisableExecuteApiEndpoint?: boolean;
    IpAddressType?: IpAddressType;
    Name?: string;
    RouteKey?: string;
    RouteSelectionExpression?: string;
    Target?: string;
    Version?: string;
}
export interface UpdateApiResponse {
    ApiEndpoint?: string;
    ApiGatewayManaged?: boolean;
    ApiId?: string;
    ApiKeySelectionExpression?: string;
    CorsConfiguration?: Cors;
    CreatedDate?: Date;
    Description?: string;
    DisableSchemaValidation?: boolean;
    DisableExecuteApiEndpoint?: boolean;
    ImportInfo?: string[];
    IpAddressType?: IpAddressType;
    Name?: string;
    ProtocolType?: ProtocolType;
    RouteSelectionExpression?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Version?: string;
    Warnings?: string[];
}
export interface UpdateApiMappingRequest {
    ApiId?: string;
    ApiMappingId: string;
    ApiMappingKey?: string;
    DomainName: string;
    Stage?: string;
}
export interface UpdateApiMappingResponse {
    ApiId?: string;
    ApiMappingId?: string;
    ApiMappingKey?: string;
    Stage?: string;
}
export interface UpdateAuthorizerRequest {
    ApiId: string;
    AuthorizerCredentialsArn?: string;
    AuthorizerId: string;
    AuthorizerPayloadFormatVersion?: string;
    AuthorizerResultTtlInSeconds?: number;
    AuthorizerType?: AuthorizerType;
    AuthorizerUri?: string;
    EnableSimpleResponses?: boolean;
    IdentitySource?: string[];
    IdentityValidationExpression?: string;
    JwtConfiguration?: JWTConfiguration;
    Name?: string;
}
export interface UpdateAuthorizerResponse {
    AuthorizerCredentialsArn?: string;
    AuthorizerId?: string;
    AuthorizerPayloadFormatVersion?: string;
    AuthorizerResultTtlInSeconds?: number;
    AuthorizerType?: AuthorizerType;
    AuthorizerUri?: string;
    EnableSimpleResponses?: boolean;
    IdentitySource?: string[];
    IdentityValidationExpression?: string;
    JwtConfiguration?: JWTConfiguration;
    Name?: string;
}
export interface UpdateDeploymentRequest {
    ApiId: string;
    DeploymentId: string;
    Description?: string;
}
export interface UpdateDeploymentResponse {
    AutoDeployed?: boolean;
    CreatedDate?: Date;
    DeploymentId?: string;
    DeploymentStatus?: DeploymentStatus;
    DeploymentStatusMessage?: string;
    Description?: string;
}
export interface UpdateDomainNameRequest {
    DomainName: string;
    DomainNameConfigurations?: DomainNameConfiguration[];
    MutualTlsAuthentication?: MutualTlsAuthenticationInput;
    RoutingMode?: RoutingMode;
}
export interface UpdateDomainNameResponse {
    ApiMappingSelectionExpression?: string;
    DomainName?: string;
    DomainNameArn?: string;
    DomainNameConfigurations?: DomainNameConfiguration[];
    MutualTlsAuthentication?: MutualTlsAuthentication;
    RoutingMode?: RoutingMode;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface UpdateIntegrationRequest {
    ApiId: string;
    ConnectionId?: string;
    ConnectionType?: ConnectionType;
    ContentHandlingStrategy?: ContentHandlingStrategy;
    CredentialsArn?: string;
    Description?: string;
    IntegrationId: string;
    IntegrationMethod?: string;
    IntegrationSubtype?: string;
    IntegrationType?: IntegrationType;
    IntegrationUri?: string;
    PassthroughBehavior?: PassthroughBehavior;
    PayloadFormatVersion?: string;
    RequestParameters?: {
        [key: string]: string | undefined;
    };
    RequestTemplates?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    TemplateSelectionExpression?: string;
    TimeoutInMillis?: number;
    TlsConfig?: TlsConfigInput;
}
export interface UpdateIntegrationResult {
    ApiGatewayManaged?: boolean;
    ConnectionId?: string;
    ConnectionType?: ConnectionType;
    ContentHandlingStrategy?: ContentHandlingStrategy;
    CredentialsArn?: string;
    Description?: string;
    IntegrationId?: string;
    IntegrationMethod?: string;
    IntegrationResponseSelectionExpression?: string;
    IntegrationSubtype?: string;
    IntegrationType?: IntegrationType;
    IntegrationUri?: string;
    PassthroughBehavior?: PassthroughBehavior;
    PayloadFormatVersion?: string;
    RequestParameters?: {
        [key: string]: string | undefined;
    };
    RequestTemplates?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    TemplateSelectionExpression?: string;
    TimeoutInMillis?: number;
    TlsConfig?: TlsConfig;
}
export interface UpdateIntegrationResponseRequest {
    ApiId: string;
    ContentHandlingStrategy?: ContentHandlingStrategy;
    IntegrationId: string;
    IntegrationResponseId: string;
    IntegrationResponseKey?: string;
    ResponseParameters?: {
        [key: string]: string | undefined;
    };
    ResponseTemplates?: {
        [key: string]: string | undefined;
    };
    TemplateSelectionExpression?: string;
}
export interface UpdateIntegrationResponseResponse {
    ContentHandlingStrategy?: ContentHandlingStrategy;
    IntegrationResponseId?: string;
    IntegrationResponseKey?: string;
    ResponseParameters?: {
        [key: string]: string | undefined;
    };
    ResponseTemplates?: {
        [key: string]: string | undefined;
    };
    TemplateSelectionExpression?: string;
}
export interface UpdateModelRequest {
    ApiId: string;
    ContentType?: string;
    Description?: string;
    ModelId: string;
    Name?: string;
    Schema?: string;
}
export interface UpdateModelResponse {
    ContentType?: string;
    Description?: string;
    ModelId?: string;
    Name?: string;
    Schema?: string;
}
export interface UpdatePortalRequest {
    Authorization?: Authorization;
    EndpointConfiguration?: EndpointConfigurationRequest;
    IncludedPortalProductArns?: string[];
    LogoUri?: string;
    PortalContent?: PortalContent;
    PortalId: string;
    RumAppMonitorName?: string;
}
export interface UpdatePortalResponse {
    Authorization?: Authorization & {
        CognitoConfig: CognitoConfig & {
            AppClientId: __stringMin1Max256;
            UserPoolArn: __stringMin20Max2048;
            UserPoolDomain: __stringMin20Max2048;
        };
    };
    EndpointConfiguration?: EndpointConfigurationResponse & {
        PortalDefaultDomainName: __stringMin3Max256;
        PortalDomainHostedZoneId: __stringMin1Max64;
    };
    IncludedPortalProductArns?: string[];
    LastModified?: Date;
    LastPublished?: Date;
    LastPublishedDescription?: string;
    PortalArn?: string;
    PortalContent?: PortalContent & {
        DisplayName: __stringMin3Max255;
        Theme: PortalTheme & {
            CustomColors: CustomColors & {
                AccentColor: __stringMin1Max16;
                BackgroundColor: __stringMin1Max16;
                ErrorValidationColor: __stringMin1Max16;
                HeaderColor: __stringMin1Max16;
                NavigationColor: __stringMin1Max16;
                TextColor: __stringMin1Max16;
            };
        };
    };
    PortalId?: string;
    Preview?: Preview & {
        PreviewStatus: PreviewStatus;
    };
    PublishStatus?: PublishStatus;
    RumAppMonitorName?: string;
    StatusException?: StatusException;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface UpdatePortalProductRequest {
    Description?: string;
    DisplayName?: string;
    DisplayOrder?: DisplayOrder;
    PortalProductId: string;
}
export interface UpdatePortalProductResponse {
    Description?: string;
    DisplayName?: string;
    DisplayOrder?: DisplayOrder & {
        Contents: (Section & {
            ProductRestEndpointPageArns: __listOf__stringMin20Max2048;
            SectionName: string;
        })[];
    };
    LastModified?: Date;
    PortalProductArn?: string;
    PortalProductId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface UpdateProductPageRequest {
    DisplayContent?: DisplayContent;
    PortalProductId: string;
    ProductPageId: string;
}
export interface UpdateProductPageResponse {
    DisplayContent?: DisplayContent & {
        Body: __stringMin1Max32768;
        Title: __stringMin1Max255;
    };
    LastModified?: Date;
    ProductPageArn?: string;
    ProductPageId?: string;
}
export interface UpdateProductRestEndpointPageRequest {
    DisplayContent?: EndpointDisplayContent;
    PortalProductId: string;
    ProductRestEndpointPageId: string;
    TryItState?: TryItState;
}
export interface UpdateProductRestEndpointPageResponse {
    DisplayContent?: EndpointDisplayContentResponse & {
        Endpoint: __stringMin1Max1024;
    };
    LastModified?: Date;
    ProductRestEndpointPageArn?: string;
    ProductRestEndpointPageId?: string;
    RestEndpointIdentifier?: RestEndpointIdentifier & {
        IdentifierParts: IdentifierParts & {
            Method: __stringMin1Max20;
            Path: __stringMin1Max4096;
            RestApiId: __stringMin1Max50;
            Stage: __stringMin1Max128;
        };
    };
    Status?: Status;
    StatusException?: StatusException;
    TryItState?: TryItState;
}
export interface UpdateRouteRequest {
    ApiId: string;
    ApiKeyRequired?: boolean;
    AuthorizationScopes?: string[];
    AuthorizationType?: AuthorizationType;
    AuthorizerId?: string;
    ModelSelectionExpression?: string;
    OperationName?: string;
    RequestModels?: {
        [key: string]: string | undefined;
    };
    RequestParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteId: string;
    RouteKey?: string;
    RouteResponseSelectionExpression?: string;
    Target?: string;
}
export interface UpdateRouteResult {
    ApiGatewayManaged?: boolean;
    ApiKeyRequired?: boolean;
    AuthorizationScopes?: string[];
    AuthorizationType?: AuthorizationType;
    AuthorizerId?: string;
    ModelSelectionExpression?: string;
    OperationName?: string;
    RequestModels?: {
        [key: string]: string | undefined;
    };
    RequestParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteId?: string;
    RouteKey?: string;
    RouteResponseSelectionExpression?: string;
    Target?: string;
}
export interface UpdateRouteResponseRequest {
    ApiId: string;
    ModelSelectionExpression?: string;
    ResponseModels?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteId: string;
    RouteResponseId: string;
    RouteResponseKey?: string;
}
export interface UpdateRouteResponseResponse {
    ModelSelectionExpression?: string;
    ResponseModels?: {
        [key: string]: string | undefined;
    };
    ResponseParameters?: {
        [key: string]: ParameterConstraints | undefined;
    };
    RouteResponseId?: string;
    RouteResponseKey?: string;
}
export interface UpdateStageRequest {
    AccessLogSettings?: AccessLogSettings;
    ApiId: string;
    AutoDeploy?: boolean;
    ClientCertificateId?: string;
    DefaultRouteSettings?: RouteSettings;
    DeploymentId?: string;
    Description?: string;
    RouteSettings?: {
        [key: string]: RouteSettings | undefined;
    };
    StageName: string;
    StageVariables?: {
        [key: string]: string | undefined;
    };
}
export interface UpdateStageResponse {
    AccessLogSettings?: AccessLogSettings;
    ApiGatewayManaged?: boolean;
    AutoDeploy?: boolean;
    ClientCertificateId?: string;
    CreatedDate?: Date;
    DefaultRouteSettings?: RouteSettings;
    DeploymentId?: string;
    Description?: string;
    LastDeploymentStatusMessage?: string;
    LastUpdatedDate?: Date;
    RouteSettings?: {
        [key: string]: RouteSettings | undefined;
    };
    StageName?: string;
    StageVariables?: {
        [key: string]: string | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface UpdateVpcLinkRequest {
    Name?: string;
    VpcLinkId: string;
}
export interface UpdateVpcLinkResponse {
    CreatedDate?: Date;
    Name?: string;
    SecurityGroupIds?: string[];
    SubnetIds?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
    VpcLinkId?: string;
    VpcLinkStatus?: VpcLinkStatus;
    VpcLinkStatusMessage?: string;
    VpcLinkVersion?: VpcLinkVersion;
}
export type CreateApiError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an Api resource.
 */
export declare const createApi: API.OperationMethod<CreateApiRequest, CreateApiResponse, CreateApiError, Credentials | HttpClient.HttpClient>;
export type CreateApiMappingError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an API mapping.
 */
export declare const createApiMapping: API.OperationMethod<CreateApiMappingRequest, CreateApiMappingResponse, CreateApiMappingError, Credentials | HttpClient.HttpClient>;
export type CreateAuthorizerError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an Authorizer for an API.
 */
export declare const createAuthorizer: API.OperationMethod<CreateAuthorizerRequest, CreateAuthorizerResponse, CreateAuthorizerError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a Deployment for an API.
 */
export declare const createDeployment: API.OperationMethod<CreateDeploymentRequest, CreateDeploymentResponse, CreateDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateDomainNameError = AccessDeniedException | BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a domain name.
 */
export declare const createDomainName: API.OperationMethod<CreateDomainNameRequest, CreateDomainNameResponse, CreateDomainNameError, Credentials | HttpClient.HttpClient>;
export type CreateIntegrationError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an Integration.
 */
export declare const createIntegration: API.OperationMethod<CreateIntegrationRequest, CreateIntegrationResult, CreateIntegrationError, Credentials | HttpClient.HttpClient>;
export type CreateIntegrationResponseError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an IntegrationResponses.
 */
export declare const createIntegrationResponse: API.OperationMethod<CreateIntegrationResponseRequest, CreateIntegrationResponseResponse, CreateIntegrationResponseError, Credentials | HttpClient.HttpClient>;
export type CreateModelError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a Model for an API.
 */
export declare const createModel: API.OperationMethod<CreateModelRequest, CreateModelResponse, CreateModelError, Credentials | HttpClient.HttpClient>;
export type CreatePortalError = AccessDeniedException | BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Creates a portal.
 */
export declare const createPortal: API.OperationMethod<CreatePortalRequest, CreatePortalResponse, CreatePortalError, Credentials | HttpClient.HttpClient>;
export type CreatePortalProductError = AccessDeniedException | BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new portal product.
 */
export declare const createPortalProduct: API.OperationMethod<CreatePortalProductRequest, CreatePortalProductResponse, CreatePortalProductError, Credentials | HttpClient.HttpClient>;
export type CreateProductPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new product page for a portal product.
 */
export declare const createProductPage: API.OperationMethod<CreateProductPageRequest, CreateProductPageResponse, CreateProductPageError, Credentials | HttpClient.HttpClient>;
export type CreateProductRestEndpointPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a product REST endpoint page for a portal product.
 */
export declare const createProductRestEndpointPage: API.OperationMethod<CreateProductRestEndpointPageRequest, CreateProductRestEndpointPageResponse, CreateProductRestEndpointPageError, Credentials | HttpClient.HttpClient>;
export type CreateRouteError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a Route for an API.
 */
export declare const createRoute: API.OperationMethod<CreateRouteRequest, CreateRouteResult, CreateRouteError, Credentials | HttpClient.HttpClient>;
export type CreateRouteResponseError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a RouteResponse for a Route.
 */
export declare const createRouteResponse: API.OperationMethod<CreateRouteResponseRequest, CreateRouteResponseResponse, CreateRouteResponseError, Credentials | HttpClient.HttpClient>;
export type CreateRoutingRuleError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a RoutingRule.
 */
export declare const createRoutingRule: API.OperationMethod<CreateRoutingRuleRequest, CreateRoutingRuleResponse, CreateRoutingRuleError, Credentials | HttpClient.HttpClient>;
export type CreateStageError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a Stage for an API.
 */
export declare const createStage: API.OperationMethod<CreateStageRequest, CreateStageResponse, CreateStageError, Credentials | HttpClient.HttpClient>;
export type CreateVpcLinkError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Creates a VPC link.
 */
export declare const createVpcLink: API.OperationMethod<CreateVpcLinkRequest, CreateVpcLinkResponse, CreateVpcLinkError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessLogSettingsError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the AccessLogSettings for a Stage. To disable access logging for a Stage, delete its AccessLogSettings.
 */
export declare const deleteAccessLogSettings: API.OperationMethod<DeleteAccessLogSettingsRequest, DeleteAccessLogSettingsResponse, DeleteAccessLogSettingsError, Credentials | HttpClient.HttpClient>;
export type DeleteApiError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an Api resource.
 */
export declare const deleteApi: API.OperationMethod<DeleteApiRequest, DeleteApiResponse, DeleteApiError, Credentials | HttpClient.HttpClient>;
export type DeleteApiMappingError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an API mapping.
 */
export declare const deleteApiMapping: API.OperationMethod<DeleteApiMappingRequest, DeleteApiMappingResponse, DeleteApiMappingError, Credentials | HttpClient.HttpClient>;
export type DeleteAuthorizerError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an Authorizer.
 */
export declare const deleteAuthorizer: API.OperationMethod<DeleteAuthorizerRequest, DeleteAuthorizerResponse, DeleteAuthorizerError, Credentials | HttpClient.HttpClient>;
export type DeleteCorsConfigurationError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a CORS configuration.
 */
export declare const deleteCorsConfiguration: API.OperationMethod<DeleteCorsConfigurationRequest, DeleteCorsConfigurationResponse, DeleteCorsConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteDeploymentError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a Deployment.
 */
export declare const deleteDeployment: API.OperationMethod<DeleteDeploymentRequest, DeleteDeploymentResponse, DeleteDeploymentError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainNameError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a domain name.
 */
export declare const deleteDomainName: API.OperationMethod<DeleteDomainNameRequest, DeleteDomainNameResponse, DeleteDomainNameError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an Integration.
 */
export declare const deleteIntegration: API.OperationMethod<DeleteIntegrationRequest, DeleteIntegrationResponse, DeleteIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationResponseError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an IntegrationResponses.
 */
export declare const deleteIntegrationResponse: API.OperationMethod<DeleteIntegrationResponseRequest, DeleteIntegrationResponseResponse, DeleteIntegrationResponseError, Credentials | HttpClient.HttpClient>;
export type DeleteModelError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a Model.
 */
export declare const deleteModel: API.OperationMethod<DeleteModelRequest, DeleteModelResponse, DeleteModelError, Credentials | HttpClient.HttpClient>;
export type DeletePortalError = AccessDeniedException | BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a portal.
 */
export declare const deletePortal: API.OperationMethod<DeletePortalRequest, DeletePortalResponse, DeletePortalError, Credentials | HttpClient.HttpClient>;
export type DeletePortalProductError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a portal product.
 */
export declare const deletePortalProduct: API.OperationMethod<DeletePortalProductRequest, DeletePortalProductResponse, DeletePortalProductError, Credentials | HttpClient.HttpClient>;
export type DeletePortalProductSharingPolicyError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the sharing policy for a portal product.
 */
export declare const deletePortalProductSharingPolicy: API.OperationMethod<DeletePortalProductSharingPolicyRequest, DeletePortalProductSharingPolicyResponse, DeletePortalProductSharingPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteProductPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a product page of a portal product.
 */
export declare const deleteProductPage: API.OperationMethod<DeleteProductPageRequest, DeleteProductPageResponse, DeleteProductPageError, Credentials | HttpClient.HttpClient>;
export type DeleteProductRestEndpointPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a product REST endpoint page.
 */
export declare const deleteProductRestEndpointPage: API.OperationMethod<DeleteProductRestEndpointPageRequest, DeleteProductRestEndpointPageResponse, DeleteProductRestEndpointPageError, Credentials | HttpClient.HttpClient>;
export type DeleteRouteError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a Route.
 */
export declare const deleteRoute: API.OperationMethod<DeleteRouteRequest, DeleteRouteResponse, DeleteRouteError, Credentials | HttpClient.HttpClient>;
export type DeleteRouteRequestParameterError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a route request parameter. Supported only for WebSocket APIs.
 */
export declare const deleteRouteRequestParameter: API.OperationMethod<DeleteRouteRequestParameterRequest, DeleteRouteRequestParameterResponse, DeleteRouteRequestParameterError, Credentials | HttpClient.HttpClient>;
export type DeleteRouteResponseError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a RouteResponse.
 */
export declare const deleteRouteResponse: API.OperationMethod<DeleteRouteResponseRequest, DeleteRouteResponseResponse, DeleteRouteResponseError, Credentials | HttpClient.HttpClient>;
export type DeleteRouteSettingsError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the RouteSettings for a stage.
 */
export declare const deleteRouteSettings: API.OperationMethod<DeleteRouteSettingsRequest, DeleteRouteSettingsResponse, DeleteRouteSettingsError, Credentials | HttpClient.HttpClient>;
export type DeleteRoutingRuleError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a routing rule.
 */
export declare const deleteRoutingRule: API.OperationMethod<DeleteRoutingRuleRequest, DeleteRoutingRuleResponse, DeleteRoutingRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteStageError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a Stage.
 */
export declare const deleteStage: API.OperationMethod<DeleteStageRequest, DeleteStageResponse, DeleteStageError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcLinkError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a VPC link.
 */
export declare const deleteVpcLink: API.OperationMethod<DeleteVpcLinkRequest, DeleteVpcLinkResponse, DeleteVpcLinkError, Credentials | HttpClient.HttpClient>;
export type DisablePortalError = AccessDeniedException | BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the publication of a portal portal.
 */
export declare const disablePortal: API.OperationMethod<DisablePortalRequest, DisablePortalResponse, DisablePortalError, Credentials | HttpClient.HttpClient>;
export type ExportApiError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 *
 */
export declare const exportApi: API.OperationMethod<ExportApiRequest, ExportApiResponse, ExportApiError, Credentials | HttpClient.HttpClient>;
export type GetApiError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets an Api resource.
 */
export declare const getApi: API.OperationMethod<GetApiRequest, GetApiResponse, GetApiError, Credentials | HttpClient.HttpClient>;
export type GetApiMappingError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets an API mapping.
 */
export declare const getApiMapping: API.OperationMethod<GetApiMappingRequest, GetApiMappingResponse, GetApiMappingError, Credentials | HttpClient.HttpClient>;
export type GetApiMappingsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets API mappings.
 */
export declare const getApiMappings: API.OperationMethod<GetApiMappingsRequest, GetApiMappingsResponse, GetApiMappingsError, Credentials | HttpClient.HttpClient>;
export type GetApisError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a collection of Api resources.
 */
export declare const getApis: API.OperationMethod<GetApisRequest, GetApisResponse, GetApisError, Credentials | HttpClient.HttpClient>;
export type GetAuthorizerError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets an Authorizer.
 */
export declare const getAuthorizer: API.OperationMethod<GetAuthorizerRequest, GetAuthorizerResponse, GetAuthorizerError, Credentials | HttpClient.HttpClient>;
export type GetAuthorizersError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the Authorizers for an API.
 */
export declare const getAuthorizers: API.OperationMethod<GetAuthorizersRequest, GetAuthorizersResponse, GetAuthorizersError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a Deployment.
 */
export declare const getDeployment: API.OperationMethod<GetDeploymentRequest, GetDeploymentResponse, GetDeploymentError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the Deployments for an API.
 */
export declare const getDeployments: API.OperationMethod<GetDeploymentsRequest, GetDeploymentsResponse, GetDeploymentsError, Credentials | HttpClient.HttpClient>;
export type GetDomainNameError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a domain name.
 */
export declare const getDomainName: API.OperationMethod<GetDomainNameRequest, GetDomainNameResponse, GetDomainNameError, Credentials | HttpClient.HttpClient>;
export type GetDomainNamesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the domain names for an AWS account.
 */
export declare const getDomainNames: API.OperationMethod<GetDomainNamesRequest, GetDomainNamesResponse, GetDomainNamesError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets an Integration.
 */
export declare const getIntegration: API.OperationMethod<GetIntegrationRequest, GetIntegrationResult, GetIntegrationError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationResponseError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets an IntegrationResponses.
 */
export declare const getIntegrationResponse: API.OperationMethod<GetIntegrationResponseRequest, GetIntegrationResponseResponse, GetIntegrationResponseError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationResponsesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the IntegrationResponses for an Integration.
 */
export declare const getIntegrationResponses: API.OperationMethod<GetIntegrationResponsesRequest, GetIntegrationResponsesResponse, GetIntegrationResponsesError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the Integrations for an API.
 */
export declare const getIntegrations: API.OperationMethod<GetIntegrationsRequest, GetIntegrationsResponse, GetIntegrationsError, Credentials | HttpClient.HttpClient>;
export type GetModelError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a Model.
 */
export declare const getModel: API.OperationMethod<GetModelRequest, GetModelResponse, GetModelError, Credentials | HttpClient.HttpClient>;
export type GetModelsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the Models for an API.
 */
export declare const getModels: API.OperationMethod<GetModelsRequest, GetModelsResponse, GetModelsError, Credentials | HttpClient.HttpClient>;
export type GetModelTemplateError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a model template.
 */
export declare const getModelTemplate: API.OperationMethod<GetModelTemplateRequest, GetModelTemplateResponse, GetModelTemplateError, Credentials | HttpClient.HttpClient>;
export type GetPortalError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a portal.
 */
export declare const getPortal: API.OperationMethod<GetPortalRequest, GetPortalResponse, GetPortalError, Credentials | HttpClient.HttpClient>;
export type GetPortalProductError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a portal product.
 */
export declare const getPortalProduct: API.OperationMethod<GetPortalProductRequest, GetPortalProductResponse, GetPortalProductError, Credentials | HttpClient.HttpClient>;
export type GetPortalProductSharingPolicyError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the sharing policy for a portal product.
 */
export declare const getPortalProductSharingPolicy: API.OperationMethod<GetPortalProductSharingPolicyRequest, GetPortalProductSharingPolicyResponse, GetPortalProductSharingPolicyError, Credentials | HttpClient.HttpClient>;
export type GetProductPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a product page of a portal product.
 */
export declare const getProductPage: API.OperationMethod<GetProductPageRequest, GetProductPageResponse, GetProductPageError, Credentials | HttpClient.HttpClient>;
export type GetProductRestEndpointPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a product REST endpoint page.
 */
export declare const getProductRestEndpointPage: API.OperationMethod<GetProductRestEndpointPageRequest, GetProductRestEndpointPageResponse, GetProductRestEndpointPageError, Credentials | HttpClient.HttpClient>;
export type GetRouteError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a Route.
 */
export declare const getRoute: API.OperationMethod<GetRouteRequest, GetRouteResult, GetRouteError, Credentials | HttpClient.HttpClient>;
export type GetRouteResponseError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a RouteResponse.
 */
export declare const getRouteResponse: API.OperationMethod<GetRouteResponseRequest, GetRouteResponseResponse, GetRouteResponseError, Credentials | HttpClient.HttpClient>;
export type GetRouteResponsesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the RouteResponses for a Route.
 */
export declare const getRouteResponses: API.OperationMethod<GetRouteResponsesRequest, GetRouteResponsesResponse, GetRouteResponsesError, Credentials | HttpClient.HttpClient>;
export type GetRoutesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the Routes for an API.
 */
export declare const getRoutes: API.OperationMethod<GetRoutesRequest, GetRoutesResponse, GetRoutesError, Credentials | HttpClient.HttpClient>;
export type GetRoutingRuleError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a routing rule.
 */
export declare const getRoutingRule: API.OperationMethod<GetRoutingRuleRequest, GetRoutingRuleResponse, GetRoutingRuleError, Credentials | HttpClient.HttpClient>;
export type GetStageError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a Stage.
 */
export declare const getStage: API.OperationMethod<GetStageRequest, GetStageResponse, GetStageError, Credentials | HttpClient.HttpClient>;
export type GetStagesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the Stages for an API.
 */
export declare const getStages: API.OperationMethod<GetStagesRequest, GetStagesResponse, GetStagesError, Credentials | HttpClient.HttpClient>;
export type GetTagsError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a collection of Tag resources.
 */
export declare const getTags: API.OperationMethod<GetTagsRequest, GetTagsResponse, GetTagsError, Credentials | HttpClient.HttpClient>;
export type GetVpcLinkError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a VPC link.
 */
export declare const getVpcLink: API.OperationMethod<GetVpcLinkRequest, GetVpcLinkResponse, GetVpcLinkError, Credentials | HttpClient.HttpClient>;
export type GetVpcLinksError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a collection of VPC links.
 */
export declare const getVpcLinks: API.OperationMethod<GetVpcLinksRequest, GetVpcLinksResponse, GetVpcLinksError, Credentials | HttpClient.HttpClient>;
export type ImportApiError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Imports an API.
 */
export declare const importApi: API.OperationMethod<ImportApiRequest, ImportApiResponse, ImportApiError, Credentials | HttpClient.HttpClient>;
export type ListPortalProductsError = AccessDeniedException | BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Lists portal products.
 */
export declare const listPortalProducts: API.OperationMethod<ListPortalProductsRequest, ListPortalProductsResponse, ListPortalProductsError, Credentials | HttpClient.HttpClient>;
export type ListPortalsError = AccessDeniedException | BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Lists portals.
 */
export declare const listPortals: API.OperationMethod<ListPortalsRequest, ListPortalsResponse, ListPortalsError, Credentials | HttpClient.HttpClient>;
export type ListProductPagesError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists the product pages for a portal product.
 */
export declare const listProductPages: API.OperationMethod<ListProductPagesRequest, ListProductPagesResponse, ListProductPagesError, Credentials | HttpClient.HttpClient>;
export type ListProductRestEndpointPagesError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists the product REST endpoint pages of a portal product.
 */
export declare const listProductRestEndpointPages: API.OperationMethod<ListProductRestEndpointPagesRequest, ListProductRestEndpointPagesResponse, ListProductRestEndpointPagesError, Credentials | HttpClient.HttpClient>;
export type ListRoutingRulesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists routing rules.
 */
export declare const listRoutingRules: API.PaginatedOperationMethod<ListRoutingRulesRequest, ListRoutingRulesResponse, ListRoutingRulesError, Credentials | HttpClient.HttpClient, RoutingRule>;
export type PreviewPortalError = AccessDeniedException | BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a portal preview.
 */
export declare const previewPortal: API.OperationMethod<PreviewPortalRequest, PreviewPortalResponse, PreviewPortalError, Credentials | HttpClient.HttpClient>;
export type PublishPortalError = AccessDeniedException | BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Publishes a portal.
 */
export declare const publishPortal: API.OperationMethod<PublishPortalRequest, PublishPortalResponse, PublishPortalError, Credentials | HttpClient.HttpClient>;
export type PutPortalProductSharingPolicyError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the sharing policy for a portal product.
 */
export declare const putPortalProductSharingPolicy: API.OperationMethod<PutPortalProductSharingPolicyRequest, PutPortalProductSharingPolicyResponse, PutPortalProductSharingPolicyError, Credentials | HttpClient.HttpClient>;
export type PutRoutingRuleError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a routing rule.
 */
export declare const putRoutingRule: API.OperationMethod<PutRoutingRuleRequest, PutRoutingRuleResponse, PutRoutingRuleError, Credentials | HttpClient.HttpClient>;
export type ReimportApiError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Puts an Api resource.
 */
export declare const reimportApi: API.OperationMethod<ReimportApiRequest, ReimportApiResponse, ReimportApiError, Credentials | HttpClient.HttpClient>;
export type ResetAuthorizersCacheError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Resets all authorizer cache entries on a stage. Supported only for HTTP APIs.
 */
export declare const resetAuthorizersCache: API.OperationMethod<ResetAuthorizersCacheRequest, ResetAuthorizersCacheResponse, ResetAuthorizersCacheError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new Tag resource to represent a tag.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a Tag.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApiError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an Api resource.
 */
export declare const updateApi: API.OperationMethod<UpdateApiRequest, UpdateApiResponse, UpdateApiError, Credentials | HttpClient.HttpClient>;
export type UpdateApiMappingError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * The API mapping.
 */
export declare const updateApiMapping: API.OperationMethod<UpdateApiMappingRequest, UpdateApiMappingResponse, UpdateApiMappingError, Credentials | HttpClient.HttpClient>;
export type UpdateAuthorizerError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an Authorizer.
 */
export declare const updateAuthorizer: API.OperationMethod<UpdateAuthorizerRequest, UpdateAuthorizerResponse, UpdateAuthorizerError, Credentials | HttpClient.HttpClient>;
export type UpdateDeploymentError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a Deployment.
 */
export declare const updateDeployment: API.OperationMethod<UpdateDeploymentRequest, UpdateDeploymentResponse, UpdateDeploymentError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainNameError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a domain name.
 */
export declare const updateDomainName: API.OperationMethod<UpdateDomainNameRequest, UpdateDomainNameResponse, UpdateDomainNameError, Credentials | HttpClient.HttpClient>;
export type UpdateIntegrationError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an Integration.
 */
export declare const updateIntegration: API.OperationMethod<UpdateIntegrationRequest, UpdateIntegrationResult, UpdateIntegrationError, Credentials | HttpClient.HttpClient>;
export type UpdateIntegrationResponseError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an IntegrationResponses.
 */
export declare const updateIntegrationResponse: API.OperationMethod<UpdateIntegrationResponseRequest, UpdateIntegrationResponseResponse, UpdateIntegrationResponseError, Credentials | HttpClient.HttpClient>;
export type UpdateModelError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a Model.
 */
export declare const updateModel: API.OperationMethod<UpdateModelRequest, UpdateModelResponse, UpdateModelError, Credentials | HttpClient.HttpClient>;
export type UpdatePortalError = AccessDeniedException | BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a portal.
 */
export declare const updatePortal: API.OperationMethod<UpdatePortalRequest, UpdatePortalResponse, UpdatePortalError, Credentials | HttpClient.HttpClient>;
export type UpdatePortalProductError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the portal product.
 */
export declare const updatePortalProduct: API.OperationMethod<UpdatePortalProductRequest, UpdatePortalProductResponse, UpdatePortalProductError, Credentials | HttpClient.HttpClient>;
export type UpdateProductPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a product page of a portal product.
 */
export declare const updateProductPage: API.OperationMethod<UpdateProductPageRequest, UpdateProductPageResponse, UpdateProductPageError, Credentials | HttpClient.HttpClient>;
export type UpdateProductRestEndpointPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a product REST endpoint page.
 */
export declare const updateProductRestEndpointPage: API.OperationMethod<UpdateProductRestEndpointPageRequest, UpdateProductRestEndpointPageResponse, UpdateProductRestEndpointPageError, Credentials | HttpClient.HttpClient>;
export type UpdateRouteError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a Route.
 */
export declare const updateRoute: API.OperationMethod<UpdateRouteRequest, UpdateRouteResult, UpdateRouteError, Credentials | HttpClient.HttpClient>;
export type UpdateRouteResponseError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a RouteResponse.
 */
export declare const updateRouteResponse: API.OperationMethod<UpdateRouteResponseRequest, UpdateRouteResponseResponse, UpdateRouteResponseError, Credentials | HttpClient.HttpClient>;
export type UpdateStageError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a Stage.
 */
export declare const updateStage: API.OperationMethod<UpdateStageRequest, UpdateStageResponse, UpdateStageError, Credentials | HttpClient.HttpClient>;
export type UpdateVpcLinkError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a VPC link.
 */
export declare const updateVpcLink: API.OperationMethod<UpdateVpcLinkRequest, UpdateVpcLinkResponse, UpdateVpcLinkError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=apigatewayv2.d.ts.map