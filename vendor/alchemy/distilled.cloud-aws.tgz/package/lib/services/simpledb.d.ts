import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AttributeDoesNotExist_base: S.TaggedErrorClass<"AttributeDoesNotExist", {
    readonly message: any;
    readonly BoxUsage: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class AttributeDoesNotExist extends /*@__PURE__*/ AttributeDoesNotExist_base {
}
declare const DuplicateItemName_base: S.TaggedErrorClass<"DuplicateItemName", {
    readonly message: any;
    readonly BoxUsage: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicateItemName extends /*@__PURE__*/ DuplicateItemName_base {
}
declare const InvalidNextToken_base: S.TaggedErrorClass<"InvalidNextToken", {
    readonly message: any;
    readonly BoxUsage: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextToken extends /*@__PURE__*/ InvalidNextToken_base {
}
declare const InvalidNumberPredicates_base: S.TaggedErrorClass<"InvalidNumberPredicates", {
    readonly message: any;
    readonly BoxUsage: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNumberPredicates extends /*@__PURE__*/ InvalidNumberPredicates_base {
}
declare const InvalidNumberValueTests_base: S.TaggedErrorClass<"InvalidNumberValueTests", {
    readonly message: any;
    readonly BoxUsage: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNumberValueTests extends /*@__PURE__*/ InvalidNumberValueTests_base {
}
declare const InvalidParameterValue_base: S.TaggedErrorClass<"InvalidParameterValue", {
    readonly message: any;
    readonly BoxUsage: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValue extends /*@__PURE__*/ InvalidParameterValue_base {
}
declare const InvalidQueryExpression_base: S.TaggedErrorClass<"InvalidQueryExpression", {
    readonly message: any;
    readonly BoxUsage: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidQueryExpression extends /*@__PURE__*/ InvalidQueryExpression_base {
}
declare const MissingParameter_base: S.TaggedErrorClass<"MissingParameter", {
    readonly message: any;
    readonly BoxUsage: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MissingParameter extends /*@__PURE__*/ MissingParameter_base {
}
declare const NoSuchDomain_base: S.TaggedErrorClass<"NoSuchDomain", {
    readonly message: any;
    readonly BoxUsage: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class NoSuchDomain extends /*@__PURE__*/ NoSuchDomain_base {
}
declare const NumberDomainAttributesExceeded_base: S.TaggedErrorClass<"NumberDomainAttributesExceeded", {
    readonly message: any;
    readonly BoxUsage: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class NumberDomainAttributesExceeded extends /*@__PURE__*/ NumberDomainAttributesExceeded_base {
}
declare const NumberDomainBytesExceeded_base: S.TaggedErrorClass<"NumberDomainBytesExceeded", {
    readonly message: any;
    readonly BoxUsage: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class NumberDomainBytesExceeded extends /*@__PURE__*/ NumberDomainBytesExceeded_base {
}
declare const NumberDomainsExceeded_base: S.TaggedErrorClass<"NumberDomainsExceeded", {
    readonly message: any;
    readonly BoxUsage: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class NumberDomainsExceeded extends /*@__PURE__*/ NumberDomainsExceeded_base {
}
declare const NumberItemAttributesExceeded_base: S.TaggedErrorClass<"NumberItemAttributesExceeded", {
    readonly message: any;
    readonly BoxUsage: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class NumberItemAttributesExceeded extends /*@__PURE__*/ NumberItemAttributesExceeded_base {
}
declare const NumberSubmittedAttributesExceeded_base: S.TaggedErrorClass<"NumberSubmittedAttributesExceeded", {
    readonly message: any;
    readonly BoxUsage: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class NumberSubmittedAttributesExceeded extends /*@__PURE__*/ NumberSubmittedAttributesExceeded_base {
}
declare const NumberSubmittedItemsExceeded_base: S.TaggedErrorClass<"NumberSubmittedItemsExceeded", {
    readonly message: any;
    readonly BoxUsage: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class NumberSubmittedItemsExceeded extends /*@__PURE__*/ NumberSubmittedItemsExceeded_base {
}
declare const RequestTimeout_base: S.TaggedErrorClass<"RequestTimeout", {
    readonly message: any;
    readonly BoxUsage: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class RequestTimeout extends /*@__PURE__*/ RequestTimeout_base {
}
declare const TooManyRequestedAttributes_base: S.TaggedErrorClass<"TooManyRequestedAttributes", {
    readonly message: any;
    readonly BoxUsage: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyRequestedAttributes extends /*@__PURE__*/ TooManyRequestedAttributes_base {
}
export type DomainName = string;
export interface DeletableAttribute {
    Name: string;
    Value?: string;
}
export type DeletableAttributeList = DeletableAttribute[];
export interface DeletableItem {
    ItemName: string;
    Attributes?: DeletableAttribute[];
}
export type DeletableItemList = DeletableItem[];
export interface BatchDeleteAttributesRequest {
    DomainName: string;
    Items: DeletableItem[];
}
export interface BatchDeleteAttributesResponse {
}
export interface ReplaceableAttribute {
    Name: string;
    Value: string;
    Replace?: boolean;
}
export type ReplaceableAttributeList = ReplaceableAttribute[];
export interface ReplaceableItem {
    ItemName: string;
    Attributes: ReplaceableAttribute[];
}
export type ReplaceableItemList = ReplaceableItem[];
export interface BatchPutAttributesRequest {
    DomainName: string;
    Items: ReplaceableItem[];
}
export interface BatchPutAttributesResponse {
}
export interface CreateDomainRequest {
    DomainName: string;
}
export interface CreateDomainResponse {
}
export interface UpdateCondition {
    Name?: string;
    Value?: string;
    Exists?: boolean;
}
export interface DeleteAttributesRequest {
    DomainName: string;
    ItemName: string;
    Attributes?: DeletableAttribute[];
    Expected?: UpdateCondition;
}
export interface DeleteAttributesResponse {
}
export interface DeleteDomainRequest {
    DomainName: string;
}
export interface DeleteDomainResponse {
}
export interface DomainMetadataRequest {
    DomainName: string;
}
export interface DomainMetadataResponse {
    ItemCount?: number;
    ItemNamesSizeBytes?: number;
    AttributeNameCount?: number;
    AttributeNamesSizeBytes?: number;
    AttributeValueCount?: number;
    AttributeValuesSizeBytes?: number;
    Timestamp?: number;
}
export type AttributeNameList = string[];
export interface GetAttributesRequest {
    DomainName: string;
    ItemName: string;
    AttributeNames?: string[];
    ConsistentRead?: boolean;
}
export interface Attribute {
    Name: string;
    AlternateNameEncoding?: string;
    Value: string;
    AlternateValueEncoding?: string;
}
export type AttributeList = Attribute[];
export interface GetAttributesResponse {
    Attributes?: Attribute[];
}
export interface ListDomainsRequest {
    MaxNumberOfDomains?: number;
    NextToken?: string;
}
export type DomainNameList = string[];
export interface ListDomainsResponse {
    DomainNames?: string[];
    NextToken?: string;
}
export interface PutAttributesRequest {
    DomainName: string;
    ItemName: string;
    Attributes: ReplaceableAttribute[];
    Expected?: UpdateCondition;
}
export interface PutAttributesResponse {
}
export interface SelectRequest {
    SelectExpression: string;
    NextToken?: string;
    ConsistentRead?: boolean;
}
export interface Item {
    Name: string;
    AlternateNameEncoding?: string;
    Attributes?: Attribute[];
}
export type ItemList = Item[];
export interface SelectResponse {
    Items?: Item[];
    NextToken?: string;
}
export type BatchDeleteAttributesError = CommonErrors;
/**
 * Deletes attributes (or whole items) on up to 25 items in a single call. Idempotent -- missing items/attributes are not an error.
 */
export declare const batchDeleteAttributes: API.OperationMethod<BatchDeleteAttributesRequest, BatchDeleteAttributesResponse, BatchDeleteAttributesError, Credentials | HttpClient.HttpClient>;
export type BatchPutAttributesError = DuplicateItemName | InvalidParameterValue | MissingParameter | NoSuchDomain | NumberDomainAttributesExceeded | NumberDomainBytesExceeded | NumberItemAttributesExceeded | NumberSubmittedAttributesExceeded | NumberSubmittedItemsExceeded | CommonErrors;
/**
 * Puts attributes on up to 25 items in a single call.
 */
export declare const batchPutAttributes: API.OperationMethod<BatchPutAttributesRequest, BatchPutAttributesResponse, BatchPutAttributesError, Credentials | HttpClient.HttpClient>;
export type CreateDomainError = InvalidParameterValue | MissingParameter | NumberDomainsExceeded | CommonErrors;
/**
 * Creates a new SimpleDB domain. Idempotent -- creating an existing domain succeeds without error.
 */
export declare const createDomain: API.OperationMethod<CreateDomainRequest, CreateDomainResponse, CreateDomainError, Credentials | HttpClient.HttpClient>;
export type DeleteAttributesError = AttributeDoesNotExist | InvalidParameterValue | MissingParameter | NoSuchDomain | CommonErrors;
/**
 * Deletes one or more attributes of a SimpleDB item -- or the whole item when no attributes are named. Idempotent: deleting a missing attribute/item succeeds.
 */
export declare const deleteAttributes: API.OperationMethod<DeleteAttributesRequest, DeleteAttributesResponse, DeleteAttributesError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainError = MissingParameter | CommonErrors;
/**
 * Deletes a SimpleDB domain and all of its items. Idempotent -- deleting a missing domain succeeds without error.
 */
export declare const deleteDomain: API.OperationMethod<DeleteDomainRequest, DeleteDomainResponse, DeleteDomainError, Credentials | HttpClient.HttpClient>;
export type DomainMetadataError = MissingParameter | NoSuchDomain | CommonErrors;
/**
 * Returns information about a SimpleDB domain (item count, sizes, timestamp).
 */
export declare const domainMetadata: API.OperationMethod<DomainMetadataRequest, DomainMetadataResponse, DomainMetadataError, Credentials | HttpClient.HttpClient>;
export type GetAttributesError = InvalidParameterValue | MissingParameter | NoSuchDomain | CommonErrors;
/**
 * Returns all (or the requested subset of) attributes of a SimpleDB item. Reads are eventually consistent unless `ConsistentRead` is set.
 */
export declare const getAttributes: API.OperationMethod<GetAttributesRequest, GetAttributesResponse, GetAttributesError, Credentials | HttpClient.HttpClient>;
export type ListDomainsError = InvalidNextToken | InvalidParameterValue | CommonErrors;
/**
 * Lists all SimpleDB domains in the account/region. Paginated.
 */
export declare const listDomains: API.PaginatedOperationMethod<ListDomainsRequest, ListDomainsResponse, ListDomainsError, Credentials | HttpClient.HttpClient, string>;
export type PutAttributesError = AttributeDoesNotExist | InvalidParameterValue | MissingParameter | NoSuchDomain | NumberDomainAttributesExceeded | NumberDomainBytesExceeded | NumberItemAttributesExceeded | CommonErrors;
/**
 * Creates or replaces attributes of a SimpleDB item. With `Replace: true` an attribute's existing values are overwritten; otherwise values accumulate.
 */
export declare const putAttributes: API.OperationMethod<PutAttributesRequest, PutAttributesResponse, PutAttributesError, Credentials | HttpClient.HttpClient>;
export type SelectError = InvalidNextToken | InvalidNumberPredicates | InvalidNumberValueTests | InvalidParameterValue | InvalidQueryExpression | MissingParameter | NoSuchDomain | RequestTimeout | TooManyRequestedAttributes | CommonErrors;
/**
 * Runs a SimpleDB select expression (`select output_list from domain [where ...]`). Paginated via `NextToken`.
 */
export declare const select: API.PaginatedOperationMethod<SelectRequest, SelectResponse, SelectError, Credentials | HttpClient.HttpClient, Item>;
export {};
//# sourceMappingURL=simpledb.d.ts.map