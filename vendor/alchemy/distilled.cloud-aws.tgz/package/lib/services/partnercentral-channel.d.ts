import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Catalog = string;
export type ChannelHandshakeIdentifier = string;
export interface AcceptChannelHandshakeRequest {
    catalog: string;
    identifier: string;
}
export type ChannelHandshakeId = string;
export type Arn = string;
export type HandshakeStatus = "PENDING" | "ACCEPTED" | "REJECTED" | "CANCELED" | "EXPIRED" | (string & {});
export interface AcceptChannelHandshakeDetail {
    id?: string;
    arn?: string;
    status?: HandshakeStatus;
}
export interface AcceptChannelHandshakeResponse {
    channelHandshakeDetail?: AcceptChannelHandshakeDetail;
}
export interface CancelChannelHandshakeRequest {
    catalog: string;
    identifier: string;
}
export interface CancelChannelHandshakeDetail {
    id?: string;
    arn?: string;
    status?: HandshakeStatus;
}
export interface CancelChannelHandshakeResponse {
    channelHandshakeDetail?: CancelChannelHandshakeDetail;
}
export type HandshakeType = "START_SERVICE_PERIOD" | "REVOKE_SERVICE_PERIOD" | "PROGRAM_MANAGEMENT_ACCOUNT" | (string & {});
export type AssociatedResourceIdentifier = string;
export type ProgramManagementAccountIdentifier = string;
export type Note = string;
export type ServicePeriodType = "MINIMUM_NOTICE_PERIOD" | "FIXED_COMMITMENT_PERIOD" | (string & {});
export type MinimumNoticeDays = string;
export interface StartServicePeriodPayload {
    programManagementAccountIdentifier: string;
    note?: string;
    servicePeriodType: ServicePeriodType;
    minimumNoticeDays?: string;
    endDate?: Date;
}
export interface RevokeServicePeriodPayload {
    programManagementAccountIdentifier: string;
    note?: string;
}
export type ChannelHandshakePayload = {
    startServicePeriodPayload: StartServicePeriodPayload;
    revokeServicePeriodPayload?: never;
} | {
    startServicePeriodPayload?: never;
    revokeServicePeriodPayload: RevokeServicePeriodPayload;
};
export type ClientToken = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagList = Tag[];
export interface CreateChannelHandshakeRequest {
    handshakeType: HandshakeType;
    catalog: string;
    associatedResourceIdentifier: string;
    payload?: ChannelHandshakePayload;
    clientToken?: string;
    tags?: Tag[];
}
export interface CreateChannelHandshakeDetail {
    id?: string;
    arn?: string;
}
export interface CreateChannelHandshakeResponse {
    channelHandshakeDetail?: CreateChannelHandshakeDetail;
}
export type Program = "SOLUTION_PROVIDER" | "DISTRIBUTION" | "DISTRIBUTION_SELLER" | (string & {});
export type ProgramManagementAccountDisplayName = string;
export type AccountId = string;
export interface CreateProgramManagementAccountRequest {
    catalog: string;
    program: Program;
    displayName: string;
    accountId: string;
    clientToken?: string;
    tags?: Tag[];
}
export type ProgramManagementAccountId = string;
export interface CreateProgramManagementAccountDetail {
    id?: string;
    arn?: string;
}
export interface CreateProgramManagementAccountResponse {
    programManagementAccountDetail?: CreateProgramManagementAccountDetail;
}
export type AssociationType = "DOWNSTREAM_SELLER" | "END_CUSTOMER" | "INTERNAL" | (string & {});
export type RelationshipDisplayName = string;
export type ResaleAccountModel = "DISTRIBUTOR" | "END_CUSTOMER" | "SOLUTION_PROVIDER" | (string & {});
export type Sector = "COMMERCIAL" | "GOVERNMENT" | "GOVERNMENT_EXCEPTION" | (string & {});
export type Coverage = "ENTIRE_ORGANIZATION" | "MANAGEMENT_ACCOUNT_ONLY" | (string & {});
export interface ResoldEnterprise {
    coverage: Coverage;
    tamLocation: string;
    chargeAccountId?: string;
}
export type Provider = "DISTRIBUTOR" | "DISTRIBUTION_SELLER" | (string & {});
export interface PartnerLedSupport {
    coverage: Coverage;
    provider?: Provider;
    tamLocation: string;
}
export interface ResoldUnifiedOperations {
    coverage: Coverage;
    tamLocation: string;
    chargeAccountId?: string;
}
export type SupportPlan = {
    resoldEnterprise: ResoldEnterprise;
    partnerLedSupport?: never;
    resoldUnifiedOperations?: never;
} | {
    resoldEnterprise?: never;
    partnerLedSupport: PartnerLedSupport;
    resoldUnifiedOperations?: never;
} | {
    resoldEnterprise?: never;
    partnerLedSupport?: never;
    resoldUnifiedOperations: ResoldUnifiedOperations;
};
export interface CreateRelationshipRequest {
    catalog: string;
    associationType: AssociationType;
    programManagementAccountIdentifier: string;
    associatedAccountId: string;
    displayName: string;
    resaleAccountModel?: ResaleAccountModel;
    sector: Sector;
    clientToken?: string;
    tags?: Tag[];
    requestedSupportPlan?: SupportPlan;
}
export type RelationshipId = string;
export interface CreateRelationshipDetail {
    arn?: string;
    id?: string;
}
export interface CreateRelationshipResponse {
    relationshipDetail?: CreateRelationshipDetail;
}
export interface DeleteProgramManagementAccountRequest {
    catalog: string;
    identifier: string;
    clientToken?: string;
}
export interface DeleteProgramManagementAccountResponse {
}
export type RelationshipIdentifier = string;
export interface DeleteRelationshipRequest {
    catalog: string;
    identifier: string;
    programManagementAccountIdentifier: string;
    clientToken?: string;
}
export interface DeleteRelationshipResponse {
}
export interface GetRelationshipRequest {
    catalog: string;
    programManagementAccountIdentifier: string;
    identifier: string;
}
export type Revision = string;
export interface RelationshipDetail {
    arn?: string;
    id?: string;
    revision?: string;
    catalog?: string;
    associationType?: AssociationType;
    programManagementAccountId?: string;
    associatedAccountId?: string;
    displayName?: string;
    resaleAccountModel?: ResaleAccountModel;
    sector?: Sector;
    createdAt?: Date;
    updatedAt?: Date;
    startDate?: Date;
}
export interface GetRelationshipResponse {
    relationshipDetail?: RelationshipDetail;
}
export type ParticipantType = "SENDER" | "RECEIVER" | (string & {});
export type HandshakeStatusList = HandshakeStatus[];
export type AssociatedResourceIdentifierList = string[];
export type ServicePeriodTypeList = ServicePeriodType[];
export interface StartServicePeriodTypeFilters {
    servicePeriodTypes?: ServicePeriodType[];
}
export interface RevokeServicePeriodTypeFilters {
    servicePeriodTypes?: ServicePeriodType[];
}
export type ProgramList = Program[];
export interface ProgramManagementAccountTypeFilters {
    programs?: Program[];
}
export type ListChannelHandshakesTypeFilters = {
    startServicePeriodTypeFilters: StartServicePeriodTypeFilters;
    revokeServicePeriodTypeFilters?: never;
    programManagementAccountTypeFilters?: never;
} | {
    startServicePeriodTypeFilters?: never;
    revokeServicePeriodTypeFilters: RevokeServicePeriodTypeFilters;
    programManagementAccountTypeFilters?: never;
} | {
    startServicePeriodTypeFilters?: never;
    revokeServicePeriodTypeFilters?: never;
    programManagementAccountTypeFilters: ProgramManagementAccountTypeFilters;
};
export type SortOrder = "Ascending" | "Descending" | (string & {});
export type StartServicePeriodTypeSortName = "UpdatedAt" | (string & {});
export interface StartServicePeriodTypeSort {
    sortOrder: SortOrder;
    sortBy: StartServicePeriodTypeSortName;
}
export type RevokeServicePeriodTypeSortName = "UpdatedAt" | (string & {});
export interface RevokeServicePeriodTypeSort {
    sortOrder: SortOrder;
    sortBy: RevokeServicePeriodTypeSortName;
}
export type ProgramManagementAccountTypeSortName = "UpdatedAt" | (string & {});
export interface ProgramManagementAccountTypeSort {
    sortOrder: SortOrder;
    sortBy: ProgramManagementAccountTypeSortName;
}
export type ListChannelHandshakesTypeSort = {
    startServicePeriodTypeSort: StartServicePeriodTypeSort;
    revokeServicePeriodTypeSort?: never;
    programManagementAccountTypeSort?: never;
} | {
    startServicePeriodTypeSort?: never;
    revokeServicePeriodTypeSort: RevokeServicePeriodTypeSort;
    programManagementAccountTypeSort?: never;
} | {
    startServicePeriodTypeSort?: never;
    revokeServicePeriodTypeSort?: never;
    programManagementAccountTypeSort: ProgramManagementAccountTypeSort;
};
export type NextToken = string;
export interface ListChannelHandshakesRequest {
    handshakeType: HandshakeType;
    catalog: string;
    participantType: ParticipantType;
    maxResults?: number;
    statuses?: HandshakeStatus[];
    associatedResourceIdentifiers?: string[];
    handshakeTypeFilters?: ListChannelHandshakesTypeFilters;
    handshakeTypeSort?: ListChannelHandshakesTypeSort;
    nextToken?: string;
}
export type PartnerProfileDisplayName = string;
export type AssociatedResourceId = string;
export interface StartServicePeriodHandshakeDetail {
    note?: string;
    servicePeriodType?: ServicePeriodType;
    minimumNoticeDays?: string;
    startDate?: Date;
    endDate?: Date;
}
export interface RevokeServicePeriodHandshakeDetail {
    note?: string;
    servicePeriodType?: ServicePeriodType;
    minimumNoticeDays?: string;
    startDate?: Date;
    endDate?: Date;
}
export interface ProgramManagementAccountHandshakeDetail {
    program?: Program;
}
export type HandshakeDetail = {
    startServicePeriodHandshakeDetail: StartServicePeriodHandshakeDetail;
    revokeServicePeriodHandshakeDetail?: never;
    programManagementAccountHandshakeDetail?: never;
} | {
    startServicePeriodHandshakeDetail?: never;
    revokeServicePeriodHandshakeDetail: RevokeServicePeriodHandshakeDetail;
    programManagementAccountHandshakeDetail?: never;
} | {
    startServicePeriodHandshakeDetail?: never;
    revokeServicePeriodHandshakeDetail?: never;
    programManagementAccountHandshakeDetail: ProgramManagementAccountHandshakeDetail;
};
export interface ChannelHandshakeSummary {
    id?: string;
    arn?: string;
    catalog?: string;
    handshakeType?: HandshakeType;
    ownerAccountId?: string;
    senderAccountId?: string;
    senderDisplayName?: string;
    receiverAccountId?: string;
    associatedResourceId?: string;
    detail?: HandshakeDetail;
    createdAt?: Date;
    updatedAt?: Date;
    status?: HandshakeStatus;
}
export type ChannelHandshakeSummaries = ChannelHandshakeSummary[];
export interface ListChannelHandshakesResponse {
    items?: ChannelHandshakeSummary[];
    nextToken?: string;
}
export type ProgramManagementAccountDisplayNameList = string[];
export type AccountIdList = string[];
export type ProgramManagementAccountStatus = "PENDING" | "ACTIVE" | "INACTIVE" | (string & {});
export type ProgramManagementAccountStatusList = ProgramManagementAccountStatus[];
export type ListProgramManagementAccountsSortName = "UpdatedAt" | (string & {});
export interface ListProgramManagementAccountsSortBase {
    sortOrder: SortOrder;
    sortBy: ListProgramManagementAccountsSortName;
}
export interface ListProgramManagementAccountsRequest {
    catalog: string;
    maxResults?: number;
    displayNames?: string[];
    programs?: Program[];
    accountIds?: string[];
    statuses?: ProgramManagementAccountStatus[];
    sort?: ListProgramManagementAccountsSortBase;
    nextToken?: string;
}
export interface ProgramManagementAccountSummary {
    id?: string;
    revision?: string;
    catalog?: string;
    program?: Program;
    displayName?: string;
    accountId?: string;
    arn?: string;
    createdAt?: Date;
    updatedAt?: Date;
    startDate?: Date;
    status?: ProgramManagementAccountStatus;
}
export type ProgramManagementAccountSummaries = ProgramManagementAccountSummary[];
export interface ListProgramManagementAccountsResponse {
    items?: ProgramManagementAccountSummary[];
    nextToken?: string;
}
export type AssociationTypeList = AssociationType[];
export type RelationshipDisplayNameList = string[];
export type ProgramManagementAccountIdentifierList = string[];
export type ListRelationshipsSortName = "UpdatedAt" | (string & {});
export interface ListRelationshipsSortBase {
    sortOrder: SortOrder;
    sortBy: ListRelationshipsSortName;
}
export interface ListRelationshipsRequest {
    catalog: string;
    maxResults?: number;
    associatedAccountIds?: string[];
    associationTypes?: AssociationType[];
    displayNames?: string[];
    programManagementAccountIdentifiers?: string[];
    sort?: ListRelationshipsSortBase;
    nextToken?: string;
}
export interface RelationshipSummary {
    arn?: string;
    id?: string;
    revision?: string;
    catalog?: string;
    associationType?: AssociationType;
    programManagementAccountId?: string;
    associatedAccountId?: string;
    displayName?: string;
    sector?: Sector;
    createdAt?: Date;
    updatedAt?: Date;
    startDate?: Date;
}
export type RelationshipSummaries = RelationshipSummary[];
export interface ListRelationshipsResponse {
    items?: RelationshipSummary[];
    nextToken?: string;
}
export type TaggableArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[];
}
export interface RejectChannelHandshakeRequest {
    catalog: string;
    identifier: string;
}
export interface RejectChannelHandshakeDetail {
    id?: string;
    arn?: string;
    status?: HandshakeStatus;
}
export interface RejectChannelHandshakeResponse {
    channelHandshakeDetail?: RejectChannelHandshakeDetail;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateProgramManagementAccountRequest {
    catalog: string;
    identifier: string;
    revision?: string;
    displayName?: string;
}
export interface UpdateProgramManagementAccountDetail {
    id?: string;
    arn?: string;
    revision?: string;
    displayName?: string;
}
export interface UpdateProgramManagementAccountResponse {
    programManagementAccountDetail?: UpdateProgramManagementAccountDetail;
}
export interface UpdateRelationshipRequest {
    catalog: string;
    identifier: string;
    programManagementAccountIdentifier: string;
    revision?: string;
    displayName?: string;
    requestedSupportPlan?: SupportPlan;
}
export interface UpdateRelationshipDetail {
    arn?: string;
    id?: string;
    revision?: string;
    displayName?: string;
}
export interface UpdateRelationshipResponse {
    relationshipDetail?: UpdateRelationshipDetail;
}
export type ValidationExceptionReason = "REQUEST_VALIDATION_FAILED" | "BUSINESS_VALIDATION_FAILED" | (string & {});
export interface ValidationExceptionField {
    name: string;
    code: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AcceptChannelHandshakeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Accepts a pending channel handshake request from another AWS account.
 */
export declare const acceptChannelHandshake: API.OperationMethod<AcceptChannelHandshakeRequest, AcceptChannelHandshakeResponse, AcceptChannelHandshakeError, Credentials | HttpClient.HttpClient>;
export type CancelChannelHandshakeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels a pending channel handshake request.
 */
export declare const cancelChannelHandshake: API.OperationMethod<CancelChannelHandshakeRequest, CancelChannelHandshakeResponse, CancelChannelHandshakeError, Credentials | HttpClient.HttpClient>;
export type CreateChannelHandshakeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new channel handshake request to establish a partnership with another AWS account.
 */
export declare const createChannelHandshake: API.OperationMethod<CreateChannelHandshakeRequest, CreateChannelHandshakeResponse, CreateChannelHandshakeError, Credentials | HttpClient.HttpClient>;
export type CreateProgramManagementAccountError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new program management account for managing partner relationships.
 */
export declare const createProgramManagementAccount: API.OperationMethod<CreateProgramManagementAccountRequest, CreateProgramManagementAccountResponse, CreateProgramManagementAccountError, Credentials | HttpClient.HttpClient>;
export type CreateRelationshipError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new partner relationship between accounts.
 */
export declare const createRelationship: API.OperationMethod<CreateRelationshipRequest, CreateRelationshipResponse, CreateRelationshipError, Credentials | HttpClient.HttpClient>;
export type DeleteProgramManagementAccountError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a program management account.
 */
export declare const deleteProgramManagementAccount: API.OperationMethod<DeleteProgramManagementAccountRequest, DeleteProgramManagementAccountResponse, DeleteProgramManagementAccountError, Credentials | HttpClient.HttpClient>;
export type DeleteRelationshipError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a partner relationship.
 */
export declare const deleteRelationship: API.OperationMethod<DeleteRelationshipRequest, DeleteRelationshipResponse, DeleteRelationshipError, Credentials | HttpClient.HttpClient>;
export type GetRelationshipError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details of a specific partner relationship.
 */
export declare const getRelationship: API.OperationMethod<GetRelationshipRequest, GetRelationshipResponse, GetRelationshipError, Credentials | HttpClient.HttpClient>;
export type ListChannelHandshakesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists channel handshakes based on specified criteria.
 */
export declare const listChannelHandshakes: API.PaginatedOperationMethod<ListChannelHandshakesRequest, ListChannelHandshakesResponse, ListChannelHandshakesError, Credentials | HttpClient.HttpClient, ChannelHandshakeSummary>;
export type ListProgramManagementAccountsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists program management accounts based on specified criteria.
 */
export declare const listProgramManagementAccounts: API.PaginatedOperationMethod<ListProgramManagementAccountsRequest, ListProgramManagementAccountsResponse, ListProgramManagementAccountsError, Credentials | HttpClient.HttpClient, ProgramManagementAccountSummary>;
export type ListRelationshipsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists partner relationships based on specified criteria.
 */
export declare const listRelationships: API.PaginatedOperationMethod<ListRelationshipsRequest, ListRelationshipsResponse, ListRelationshipsError, Credentials | HttpClient.HttpClient, RelationshipSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists tags associated with a specific resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RejectChannelHandshakeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Rejects a pending channel handshake request.
 */
export declare const rejectChannelHandshake: API.OperationMethod<RejectChannelHandshakeRequest, RejectChannelHandshakeResponse, RejectChannelHandshakeError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds or updates tags for a specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes tags from a specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateProgramManagementAccountError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the properties of a program management account.
 */
export declare const updateProgramManagementAccount: API.OperationMethod<UpdateProgramManagementAccountRequest, UpdateProgramManagementAccountResponse, UpdateProgramManagementAccountError, Credentials | HttpClient.HttpClient>;
export type UpdateRelationshipError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the properties of a partner relationship.
 */
export declare const updateRelationship: API.OperationMethod<UpdateRelationshipRequest, UpdateRelationshipResponse, UpdateRelationshipError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=partnercentral-channel.d.ts.map