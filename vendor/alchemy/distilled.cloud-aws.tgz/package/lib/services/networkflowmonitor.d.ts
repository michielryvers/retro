import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ResourceName = string;
export type MonitorLocalResourceType = "AWS::EC2::VPC" | "AWS::AvailabilityZone" | "AWS::EC2::Subnet" | "AWS::Region" | "AWS::EKS::Cluster" | (string & {});
export interface MonitorLocalResource {
    type: MonitorLocalResourceType;
    identifier: string;
}
export type MonitorLocalResources = MonitorLocalResource[];
export type MonitorRemoteResourceType = "AWS::EC2::VPC" | "AWS::AvailabilityZone" | "AWS::EC2::Subnet" | "AWS::AWSService" | "AWS::Region" | (string & {});
export interface MonitorRemoteResource {
    type: MonitorRemoteResourceType;
    identifier: string;
}
export type MonitorRemoteResources = MonitorRemoteResource[];
export type Arn = string;
export type UuidString = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateMonitorInput {
    monitorName: string;
    localResources: MonitorLocalResource[];
    remoteResources?: MonitorRemoteResource[];
    scopeArn: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type MonitorArn = string;
export type MonitorStatus = "PENDING" | "ACTIVE" | "INACTIVE" | "ERROR" | "DELETING" | (string & {});
export type Iso8601Timestamp = Date;
export interface CreateMonitorOutput {
    monitorArn: string;
    monitorName: string;
    monitorStatus: MonitorStatus;
    localResources: MonitorLocalResource[];
    remoteResources: MonitorRemoteResource[];
    createdAt: Date;
    modifiedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type AccountId = string;
export type TargetId = {
    accountId: string;
};
export type TargetType = "ACCOUNT" | (string & {});
export interface TargetIdentifier {
    targetId: TargetId;
    targetType: TargetType;
}
export type AwsRegion = string;
export interface TargetResource {
    targetIdentifier: TargetIdentifier;
    region: string;
}
export type TargetResourceList = TargetResource[];
export interface CreateScopeInput {
    targets: TargetResource[];
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type ScopeId = string;
export type ScopeStatus = "SUCCEEDED" | "IN_PROGRESS" | "FAILED" | "DEACTIVATING" | "DEACTIVATED" | (string & {});
export interface CreateScopeOutput {
    scopeId: string;
    status: ScopeStatus;
    scopeArn: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface DeleteMonitorInput {
    monitorName: string;
}
export interface DeleteMonitorOutput {
}
export interface DeleteScopeInput {
    scopeId: string;
}
export interface DeleteScopeOutput {
}
export interface GetMonitorInput {
    monitorName: string;
}
export interface GetMonitorOutput {
    monitorArn: string;
    monitorName: string;
    monitorStatus: MonitorStatus;
    localResources: MonitorLocalResource[];
    remoteResources: MonitorRemoteResource[];
    createdAt: Date;
    modifiedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetQueryResultsMonitorTopContributorsInput {
    monitorName: string;
    queryId: string;
    nextToken?: string;
    maxResults?: number;
}
export type MetricUnit = "Seconds" | "Microseconds" | "Milliseconds" | "Bytes" | "Kilobytes" | "Megabytes" | "Gigabytes" | "Terabytes" | "Bits" | "Kilobits" | "Megabits" | "Gigabits" | "Terabits" | "Percent" | "Count" | "Bytes/Second" | "Kilobytes/Second" | "Megabytes/Second" | "Gigabytes/Second" | "Terabytes/Second" | "Bits/Second" | "Kilobits/Second" | "Megabits/Second" | "Gigabits/Second" | "Terabits/Second" | "Count/Second" | "None" | (string & {});
export type InstanceId = string;
export type VpcId = string;
export type AvailabilityZone = string;
export type SubnetId = string;
export type DestinationCategory = "INTRA_AZ" | "INTER_AZ" | "INTER_VPC" | "UNCLASSIFIED" | "AMAZON_S3" | "AMAZON_DYNAMODB" | "INTER_REGION" | (string & {});
export type Component = string;
export type ComponentType = string;
export interface TraversedComponent {
    componentId?: string;
    componentType?: string;
    componentArn?: string;
    serviceName?: string;
}
export type TraversedConstructsList = TraversedComponent[];
export interface KubernetesMetadata {
    localServiceName?: string;
    localPodName?: string;
    localPodNamespace?: string;
    remoteServiceName?: string;
    remotePodName?: string;
    remotePodNamespace?: string;
}
export type InstanceArn = string;
export type SubnetArn = string;
export type VpcArn = string;
export interface MonitorTopContributorsRow {
    localIp?: string;
    snatIp?: string;
    localInstanceId?: string;
    localVpcId?: string;
    localRegion?: string;
    localAz?: string;
    localSubnetId?: string;
    targetPort?: number;
    destinationCategory?: DestinationCategory;
    remoteVpcId?: string;
    remoteRegion?: string;
    remoteAz?: string;
    remoteSubnetId?: string;
    remoteInstanceId?: string;
    remoteIp?: string;
    dnatIp?: string;
    value?: number;
    traversedConstructs?: TraversedComponent[];
    kubernetesMetadata?: KubernetesMetadata;
    localInstanceArn?: string;
    localSubnetArn?: string;
    localVpcArn?: string;
    remoteInstanceArn?: string;
    remoteSubnetArn?: string;
    remoteVpcArn?: string;
}
export type MonitorTopContributorsRowList = MonitorTopContributorsRow[];
export interface GetQueryResultsMonitorTopContributorsOutput {
    unit?: MetricUnit;
    topContributors?: MonitorTopContributorsRow[];
    nextToken?: string;
}
export interface GetQueryResultsWorkloadInsightsTopContributorsInput {
    scopeId: string;
    queryId: string;
    nextToken?: string;
    maxResults?: number;
}
export interface WorkloadInsightsTopContributorsRow {
    accountId?: string;
    localSubnetId?: string;
    localAz?: string;
    localVpcId?: string;
    localRegion?: string;
    remoteIdentifier?: string;
    value?: number;
    localSubnetArn?: string;
    localVpcArn?: string;
}
export type WorkloadInsightsTopContributorsRowList = WorkloadInsightsTopContributorsRow[];
export interface GetQueryResultsWorkloadInsightsTopContributorsOutput {
    topContributors?: WorkloadInsightsTopContributorsRow[];
    nextToken?: string;
}
export interface GetQueryResultsWorkloadInsightsTopContributorsDataInput {
    scopeId: string;
    queryId: string;
    nextToken?: string;
    maxResults?: number;
}
export type WorkloadInsightsTopContributorsTimestampsList = Date[];
export type WorkloadInsightsTopContributorsValuesList = number[];
export interface WorkloadInsightsTopContributorsDataPoint {
    timestamps: Date[];
    values: number[];
    label: string;
}
export type WorkloadInsightsTopContributorsDataPoints = WorkloadInsightsTopContributorsDataPoint[];
export interface GetQueryResultsWorkloadInsightsTopContributorsDataOutput {
    unit: MetricUnit;
    datapoints: WorkloadInsightsTopContributorsDataPoint[];
    nextToken?: string;
}
export interface GetQueryStatusMonitorTopContributorsInput {
    monitorName: string;
    queryId: string;
}
export type QueryStatus = "QUEUED" | "RUNNING" | "SUCCEEDED" | "FAILED" | "CANCELED" | (string & {});
export interface GetQueryStatusMonitorTopContributorsOutput {
    status: QueryStatus;
}
export interface GetQueryStatusWorkloadInsightsTopContributorsInput {
    scopeId: string;
    queryId: string;
}
export interface GetQueryStatusWorkloadInsightsTopContributorsOutput {
    status: QueryStatus;
}
export interface GetQueryStatusWorkloadInsightsTopContributorsDataInput {
    scopeId: string;
    queryId: string;
}
export interface GetQueryStatusWorkloadInsightsTopContributorsDataOutput {
    status: QueryStatus;
}
export interface GetScopeInput {
    scopeId: string;
}
export interface GetScopeOutput {
    scopeId: string;
    status: ScopeStatus;
    scopeArn: string;
    targets: TargetResource[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export type MaxResults = number;
export interface ListMonitorsInput {
    nextToken?: string;
    maxResults?: number;
    monitorStatus?: MonitorStatus;
}
export interface MonitorSummary {
    monitorArn: string;
    monitorName: string;
    monitorStatus: MonitorStatus;
}
export type MonitorList = MonitorSummary[];
export interface ListMonitorsOutput {
    monitors: MonitorSummary[];
    nextToken?: string;
}
export interface ListScopesInput {
    nextToken?: string;
    maxResults?: number;
}
export interface ScopeSummary {
    scopeId: string;
    status: ScopeStatus;
    scopeArn: string;
}
export type ScopeSummaryList = ScopeSummary[];
export interface ListScopesOutput {
    scopes: ScopeSummary[];
    nextToken?: string;
}
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags?: {
        [key: string]: string | undefined;
    };
}
export type MonitorMetric = "ROUND_TRIP_TIME" | "TIMEOUTS" | "RETRANSMISSIONS" | "DATA_TRANSFERRED" | (string & {});
export type Limit = number;
export interface StartQueryMonitorTopContributorsInput {
    monitorName: string;
    startTime: Date;
    endTime: Date;
    metricName: MonitorMetric;
    destinationCategory: DestinationCategory;
    limit?: number;
}
export interface StartQueryMonitorTopContributorsOutput {
    queryId: string;
}
export type WorkloadInsightsMetric = "TIMEOUTS" | "RETRANSMISSIONS" | "DATA_TRANSFERRED" | (string & {});
export interface StartQueryWorkloadInsightsTopContributorsInput {
    scopeId: string;
    startTime: Date;
    endTime: Date;
    metricName: WorkloadInsightsMetric;
    destinationCategory: DestinationCategory;
    limit?: number;
}
export interface StartQueryWorkloadInsightsTopContributorsOutput {
    queryId: string;
}
export interface StartQueryWorkloadInsightsTopContributorsDataInput {
    scopeId: string;
    startTime: Date;
    endTime: Date;
    metricName: WorkloadInsightsMetric;
    destinationCategory: DestinationCategory;
}
export interface StartQueryWorkloadInsightsTopContributorsDataOutput {
    queryId: string;
}
export interface StopQueryMonitorTopContributorsInput {
    monitorName: string;
    queryId: string;
}
export interface StopQueryMonitorTopContributorsOutput {
}
export interface StopQueryWorkloadInsightsTopContributorsInput {
    scopeId: string;
    queryId: string;
}
export interface StopQueryWorkloadInsightsTopContributorsOutput {
}
export interface StopQueryWorkloadInsightsTopContributorsDataInput {
    scopeId: string;
    queryId: string;
}
export interface StopQueryWorkloadInsightsTopContributorsDataOutput {
}
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateMonitorInput {
    monitorName: string;
    localResourcesToAdd?: MonitorLocalResource[];
    localResourcesToRemove?: MonitorLocalResource[];
    remoteResourcesToAdd?: MonitorRemoteResource[];
    remoteResourcesToRemove?: MonitorRemoteResource[];
    clientToken?: string;
}
export interface UpdateMonitorOutput {
    monitorArn: string;
    monitorName: string;
    monitorStatus: MonitorStatus;
    localResources: MonitorLocalResource[];
    remoteResources: MonitorRemoteResource[];
    createdAt: Date;
    modifiedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface UpdateScopeInput {
    scopeId: string;
    resourcesToAdd?: TargetResource[];
    resourcesToDelete?: TargetResource[];
}
export interface UpdateScopeOutput {
    scopeId: string;
    status: ScopeStatus;
    scopeArn: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type CreateMonitorError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a monitor for specific network flows between local and remote resources, so that you can monitor network performance for one or several of your workloads. For each monitor, Network Flow Monitor publishes detailed end-to-end performance metrics and a network health indicator (NHI) that informs you whether there were Amazon Web Services network issues for one or more of the network flows tracked by a monitor, during a time period that you choose.
 */
export declare const createMonitor: API.OperationMethod<CreateMonitorInput, CreateMonitorOutput, CreateMonitorError, Credentials | HttpClient.HttpClient>;
export type CreateScopeError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * In Network Flow Monitor, you specify a scope for the service to generate metrics for. By using the scope, Network Flow Monitor can generate a topology of all the resources to measure performance metrics for. When you create a scope, you enable permissions for Network Flow Monitor.
 *
 * A scope is a Region-account pair or multiple Region-account pairs. Network Flow Monitor uses your scope to determine all the resources (the topology) where Network Flow Monitor will gather network flow performance metrics for you. To provide performance metrics, Network Flow Monitor uses the data that is sent by the Network Flow Monitor agents you install on the resources.
 *
 * To define the Region-account pairs for your scope, the Network Flow Monitor API uses the following constucts, which allow for future flexibility in defining scopes:
 *
 * - *Targets*, which are arrays of targetResources.
 *
 * - *Target resources*, which are Region-targetIdentifier pairs.
 *
 * - *Target identifiers*, made up of a targetID (currently always an account ID) and a targetType (currently always an account).
 */
export declare const createScope: API.OperationMethod<CreateScopeInput, CreateScopeOutput, CreateScopeError, Credentials | HttpClient.HttpClient>;
export type DeleteMonitorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a monitor in Network Flow Monitor.
 */
export declare const deleteMonitor: API.OperationMethod<DeleteMonitorInput, DeleteMonitorOutput, DeleteMonitorError, Credentials | HttpClient.HttpClient>;
export type DeleteScopeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a scope that has been defined.
 */
export declare const deleteScope: API.OperationMethod<DeleteScopeInput, DeleteScopeOutput, DeleteScopeError, Credentials | HttpClient.HttpClient>;
export type GetMonitorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a monitor in Network Flow Monitor based on a monitor name. The information returned includes the Amazon Resource Name (ARN), create time, modified time, resources included in the monitor, and status information.
 */
export declare const getMonitor: API.OperationMethod<GetMonitorInput, GetMonitorOutput, GetMonitorError, Credentials | HttpClient.HttpClient>;
export type GetQueryResultsMonitorTopContributorsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Return the data for a query with the Network Flow Monitor query interface. You specify the query that you want to return results for by providing a query ID and a monitor name. This query returns the top contributors for a specific monitor.
 *
 * Create a query ID for this call by calling the corresponding API call to start the query, `StartQueryMonitorTopContributors`. Use the scope ID that was returned for your account by `CreateScope`.
 *
 * Top contributors in Network Flow Monitor are network flows with the highest values for a specific metric type. Top contributors can be across all workload insights, for a given scope, or for a specific monitor. Use the applicable call for the top contributors that you want to be returned.
 */
export declare const getQueryResultsMonitorTopContributors: API.PaginatedOperationMethod<GetQueryResultsMonitorTopContributorsInput, GetQueryResultsMonitorTopContributorsOutput, GetQueryResultsMonitorTopContributorsError, Credentials | HttpClient.HttpClient, MonitorTopContributorsRow>;
export type GetQueryResultsWorkloadInsightsTopContributorsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Return the data for a query with the Network Flow Monitor query interface. You specify the query that you want to return results for by providing a query ID and a monitor name.
 *
 * This query returns the top contributors for a scope for workload insights. Workload insights provide a high level view of network flow performance data collected by agents. To return the data for the top contributors, see `GetQueryResultsWorkloadInsightsTopContributorsData`.
 *
 * Create a query ID for this call by calling the corresponding API call to start the query, `StartQueryWorkloadInsightsTopContributors`. Use the scope ID that was returned for your account by `CreateScope`.
 *
 * Top contributors in Network Flow Monitor are network flows with the highest values for a specific metric type. Top contributors can be across all workload insights, for a given scope, or for a specific monitor. Use the applicable call for the top contributors that you want to be returned.
 */
export declare const getQueryResultsWorkloadInsightsTopContributors: API.PaginatedOperationMethod<GetQueryResultsWorkloadInsightsTopContributorsInput, GetQueryResultsWorkloadInsightsTopContributorsOutput, GetQueryResultsWorkloadInsightsTopContributorsError, Credentials | HttpClient.HttpClient, WorkloadInsightsTopContributorsRow>;
export type GetQueryResultsWorkloadInsightsTopContributorsDataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Return the data for a query with the Network Flow Monitor query interface. Specify the query that you want to return results for by providing a query ID and a scope ID.
 *
 * This query returns the data for top contributors for workload insights for a specific scope. Workload insights provide a high level view of network flow performance data collected by agents for a scope. To return just the top contributors, see `GetQueryResultsWorkloadInsightsTopContributors`.
 *
 * Create a query ID for this call by calling the corresponding API call to start the query, `StartQueryWorkloadInsightsTopContributorsData`. Use the scope ID that was returned for your account by `CreateScope`.
 *
 * Top contributors in Network Flow Monitor are network flows with the highest values for a specific metric type. Top contributors can be across all workload insights, for a given scope, or for a specific monitor. Use the applicable call for the top contributors that you want to be returned.
 *
 * The top contributor network flows overall are for a specific metric type, for example, the number of retransmissions.
 */
export declare const getQueryResultsWorkloadInsightsTopContributorsData: API.PaginatedOperationMethod<GetQueryResultsWorkloadInsightsTopContributorsDataInput, GetQueryResultsWorkloadInsightsTopContributorsDataOutput, GetQueryResultsWorkloadInsightsTopContributorsDataError, Credentials | HttpClient.HttpClient, WorkloadInsightsTopContributorsDataPoint>;
export type GetQueryStatusMonitorTopContributorsError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the current status of a query for the Network Flow Monitor query interface, for a specified query ID and monitor. This call returns the query status for the top contributors for a monitor.
 *
 * When you create a query, use this call to check the status of the query to make sure that it has has `SUCCEEDED` before you review the results. Use the same query ID that you used for the corresponding API call to start (create) the query, `StartQueryMonitorTopContributors`.
 *
 * When you run a query, use this call to check the status of the query to make sure that the query has `SUCCEEDED` before you review the results.
 */
export declare const getQueryStatusMonitorTopContributors: API.OperationMethod<GetQueryStatusMonitorTopContributorsInput, GetQueryStatusMonitorTopContributorsOutput, GetQueryStatusMonitorTopContributorsError, Credentials | HttpClient.HttpClient>;
export type GetQueryStatusWorkloadInsightsTopContributorsError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Return the data for a query with the Network Flow Monitor query interface. Specify the query that you want to return results for by providing a query ID and a monitor name. This query returns the top contributors for workload insights.
 *
 * When you start a query, use this call to check the status of the query to make sure that it has has `SUCCEEDED` before you review the results. Use the same query ID that you used for the corresponding API call to start the query, `StartQueryWorkloadInsightsTopContributors`.
 *
 * Top contributors in Network Flow Monitor are network flows with the highest values for a specific metric type. Top contributors can be across all workload insights, for a given scope, or for a specific monitor. Use the applicable call for the top contributors that you want to be returned.
 */
export declare const getQueryStatusWorkloadInsightsTopContributors: API.OperationMethod<GetQueryStatusWorkloadInsightsTopContributorsInput, GetQueryStatusWorkloadInsightsTopContributorsOutput, GetQueryStatusWorkloadInsightsTopContributorsError, Credentials | HttpClient.HttpClient>;
export type GetQueryStatusWorkloadInsightsTopContributorsDataError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the current status of a query for the Network Flow Monitor query interface, for a specified query ID and monitor. This call returns the query status for the top contributors data for workload insights.
 *
 * When you start a query, use this call to check the status of the query to make sure that it has has `SUCCEEDED` before you review the results. Use the same query ID that you used for the corresponding API call to start the query, `StartQueryWorkloadInsightsTopContributorsData`.
 *
 * Top contributors in Network Flow Monitor are network flows with the highest values for a specific metric type. Top contributors can be across all workload insights, for a given scope, or for a specific monitor. Use the applicable call for the top contributors that you want to be returned.
 *
 * The top contributor network flows overall are for a specific metric type, for example, the number of retransmissions.
 */
export declare const getQueryStatusWorkloadInsightsTopContributorsData: API.OperationMethod<GetQueryStatusWorkloadInsightsTopContributorsDataInput, GetQueryStatusWorkloadInsightsTopContributorsDataOutput, GetQueryStatusWorkloadInsightsTopContributorsDataError, Credentials | HttpClient.HttpClient>;
export type GetScopeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a scope, including the name, status, tags, and target details. The scope in Network Flow Monitor is an account.
 */
export declare const getScope: API.OperationMethod<GetScopeInput, GetScopeOutput, GetScopeError, Credentials | HttpClient.HttpClient>;
export type ListMonitorsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all monitors in an account. Optionally, you can list only monitors that have a specific status, by using the `STATUS` parameter.
 */
export declare const listMonitors: API.PaginatedOperationMethod<ListMonitorsInput, ListMonitorsOutput, ListMonitorsError, Credentials | HttpClient.HttpClient, MonitorSummary>;
export type ListScopesError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all the scopes for an account.
 */
export declare const listScopes: API.PaginatedOperationMethod<ListScopesInput, ListScopesOutput, ListScopesError, Credentials | HttpClient.HttpClient, ScopeSummary>;
export type ListTagsForResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns all the tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartQueryMonitorTopContributorsError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a query that you can use with the Network Flow Monitor query interface to return the top contributors for a monitor. Specify the monitor that you want to create the query for.
 *
 * The call returns a query ID that you can use with GetQueryResultsMonitorTopContributors to run the query and return the top contributors for a specific monitor.
 *
 * Top contributors in Network Flow Monitor are network flows with the highest values for a specific metric type. Top contributors can be across all workload insights, for a given scope, or for a specific monitor. Use the applicable APIs for the top contributors that you want to be returned.
 */
export declare const startQueryMonitorTopContributors: API.OperationMethod<StartQueryMonitorTopContributorsInput, StartQueryMonitorTopContributorsOutput, StartQueryMonitorTopContributorsError, Credentials | HttpClient.HttpClient>;
export type StartQueryWorkloadInsightsTopContributorsError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a query with the Network Flow Monitor query interface that you can run to return workload insights top contributors. Specify the scope that you want to create a query for.
 *
 * The call returns a query ID that you can use with GetQueryResultsWorkloadInsightsTopContributors to run the query and return the top contributors for the workload insights for a scope.
 *
 * Top contributors in Network Flow Monitor are network flows with the highest values for a specific metric type. Top contributors can be across all workload insights, for a given scope, or for a specific monitor. Use the applicable APIs for the top contributors that you want to be returned.
 */
export declare const startQueryWorkloadInsightsTopContributors: API.OperationMethod<StartQueryWorkloadInsightsTopContributorsInput, StartQueryWorkloadInsightsTopContributorsOutput, StartQueryWorkloadInsightsTopContributorsError, Credentials | HttpClient.HttpClient>;
export type StartQueryWorkloadInsightsTopContributorsDataError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a query with the Network Flow Monitor query interface that you can run to return data for workload insights top contributors. Specify the scope that you want to create a query for.
 *
 * The call returns a query ID that you can use with GetQueryResultsWorkloadInsightsTopContributorsData to run the query and return the data for the top contributors for the workload insights for a scope.
 *
 * Top contributors in Network Flow Monitor are network flows with the highest values for a specific metric type. Top contributors can be across all workload insights, for a given scope, or for a specific monitor. Use the applicable call for the top contributors that you want to be returned.
 */
export declare const startQueryWorkloadInsightsTopContributorsData: API.OperationMethod<StartQueryWorkloadInsightsTopContributorsDataInput, StartQueryWorkloadInsightsTopContributorsDataOutput, StartQueryWorkloadInsightsTopContributorsDataError, Credentials | HttpClient.HttpClient>;
export type StopQueryMonitorTopContributorsError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stop a top contributors query for a monitor. Specify the query that you want to stop by providing a query ID and a monitor name.
 *
 * Top contributors in Network Flow Monitor are network flows with the highest values for a specific metric type. Top contributors can be across all workload insights, for a given scope, or for a specific monitor. Use the applicable call for the top contributors that you want to be returned.
 */
export declare const stopQueryMonitorTopContributors: API.OperationMethod<StopQueryMonitorTopContributorsInput, StopQueryMonitorTopContributorsOutput, StopQueryMonitorTopContributorsError, Credentials | HttpClient.HttpClient>;
export type StopQueryWorkloadInsightsTopContributorsError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stop a top contributors query for workload insights. Specify the query that you want to stop by providing a query ID and a scope ID.
 *
 * Top contributors in Network Flow Monitor are network flows with the highest values for a specific metric type. Top contributors can be across all workload insights, for a given scope, or for a specific monitor. Use the applicable call for the top contributors that you want to be returned.
 */
export declare const stopQueryWorkloadInsightsTopContributors: API.OperationMethod<StopQueryWorkloadInsightsTopContributorsInput, StopQueryWorkloadInsightsTopContributorsOutput, StopQueryWorkloadInsightsTopContributorsError, Credentials | HttpClient.HttpClient>;
export type StopQueryWorkloadInsightsTopContributorsDataError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stop a top contributors data query for workload insights. Specify the query that you want to stop by providing a query ID and a scope ID.
 *
 * Top contributors in Network Flow Monitor are network flows with the highest values for a specific metric type. Top contributors can be across all workload insights, for a given scope, or for a specific monitor. Use the applicable call for the top contributors that you want to be returned.
 */
export declare const stopQueryWorkloadInsightsTopContributorsData: API.OperationMethod<StopQueryWorkloadInsightsTopContributorsDataInput, StopQueryWorkloadInsightsTopContributorsDataOutput, StopQueryWorkloadInsightsTopContributorsDataError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a tag to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a tag from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateMonitorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a monitor to add or remove local or remote resources.
 */
export declare const updateMonitor: API.OperationMethod<UpdateMonitorInput, UpdateMonitorOutput, UpdateMonitorError, Credentials | HttpClient.HttpClient>;
export type UpdateScopeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a scope to add or remove resources that you want to be available for Network Flow Monitor to generate metrics for, when you have active agents on those resources sending metrics reports to the Network Flow Monitor backend.
 */
export declare const updateScope: API.OperationMethod<UpdateScopeInput, UpdateScopeOutput, UpdateScopeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=networkflowmonitor.d.ts.map