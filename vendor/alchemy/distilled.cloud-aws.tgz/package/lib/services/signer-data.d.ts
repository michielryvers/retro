import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServiceErrorException_base: S.TaggedErrorClass<"InternalServiceErrorException", {
    readonly message: any;
    readonly code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServiceErrorException extends /*@__PURE__*/ InternalServiceErrorException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
    readonly code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type PlatformId = string;
export type Arn = string;
export type CertificateHash = string;
export type CertificateHashes = string[];
export interface GetRevocationStatusRequest {
    signatureTimestamp: Date;
    platformId: string;
    profileVersionArn: string;
    jobArn: string;
    certificateHashes: string[];
}
export type RevokedEntity = string;
export type RevokedEntities = string[];
export interface GetRevocationStatusResponse {
    revokedEntities?: string[];
}
export type GetRevocationStatusError = AccessDeniedException | InternalServiceErrorException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Retrieves the revocation status for a signed artifact by checking if the signing profile, job, or certificate has been revoked.
 */
export declare const getRevocationStatus: API.OperationMethod<GetRevocationStatusRequest, GetRevocationStatusResponse, GetRevocationStatusError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=signer-data.d.ts.map