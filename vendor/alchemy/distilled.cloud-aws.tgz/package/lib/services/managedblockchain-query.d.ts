import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type QueryNetwork = string;
export type ChainAddress = string;
export type QueryTokenId = string;
export interface TokenIdentifier {
    network: string;
    contractAddress?: string;
    tokenId?: string;
}
export interface OwnerIdentifier {
    address: string;
}
export interface BlockchainInstant {
    time?: Date;
}
export interface BatchGetTokenBalanceInputItem {
    tokenIdentifier: TokenIdentifier;
    ownerIdentifier: OwnerIdentifier;
    atBlockchainInstant?: BlockchainInstant;
}
export type GetTokenBalanceInputList = BatchGetTokenBalanceInputItem[];
export interface BatchGetTokenBalanceInput {
    getTokenBalanceInputs?: BatchGetTokenBalanceInputItem[];
}
export interface BatchGetTokenBalanceOutputItem {
    ownerIdentifier?: OwnerIdentifier;
    tokenIdentifier?: TokenIdentifier;
    balance: string;
    atBlockchainInstant: BlockchainInstant;
    lastUpdatedTime?: BlockchainInstant;
}
export type BatchGetTokenBalanceOutputList = BatchGetTokenBalanceOutputItem[];
export type ErrorType = string;
export interface BatchGetTokenBalanceErrorItem {
    tokenIdentifier?: TokenIdentifier;
    ownerIdentifier?: OwnerIdentifier;
    atBlockchainInstant?: BlockchainInstant;
    errorCode: string;
    errorMessage: string;
    errorType: string;
}
export type BatchGetTokenBalanceErrors = BatchGetTokenBalanceErrorItem[];
export interface BatchGetTokenBalanceOutput {
    tokenBalances: BatchGetTokenBalanceOutputItem[];
    errors: BatchGetTokenBalanceErrorItem[];
}
export interface ContractIdentifier {
    network: string;
    contractAddress: string;
}
export interface GetAssetContractInput {
    contractIdentifier: ContractIdentifier;
}
export type QueryTokenStandard = string;
export interface ContractMetadata {
    name?: string;
    symbol?: string;
    decimals?: number;
}
export interface GetAssetContractOutput {
    contractIdentifier: ContractIdentifier;
    tokenStandard: string;
    deployerAddress: string;
    metadata?: ContractMetadata;
}
export interface GetTokenBalanceInput {
    tokenIdentifier: TokenIdentifier;
    ownerIdentifier: OwnerIdentifier;
    atBlockchainInstant?: BlockchainInstant;
}
export interface GetTokenBalanceOutput {
    ownerIdentifier?: OwnerIdentifier;
    tokenIdentifier?: TokenIdentifier;
    balance: string;
    atBlockchainInstant: BlockchainInstant;
    lastUpdatedTime?: BlockchainInstant;
}
export type QueryTransactionHash = string;
export type QueryTransactionId = string;
export interface GetTransactionInput {
    transactionHash?: string;
    transactionId?: string;
    network: string;
}
export type BlockHash = string;
export type ConfirmationStatus = string;
export type ExecutionStatus = string;
export interface Transaction {
    network: string;
    blockHash?: string;
    transactionHash: string;
    blockNumber?: string;
    transactionTimestamp: Date;
    transactionIndex: number;
    numberOfTransactions: number;
    to: string;
    from?: string;
    contractAddress?: string;
    gasUsed?: string;
    cumulativeGasUsed?: string;
    effectiveGasPrice?: string;
    signatureV?: number;
    signatureR?: string;
    signatureS?: string;
    transactionFee?: string;
    transactionId?: string;
    confirmationStatus?: string;
    executionStatus?: string;
}
export interface GetTransactionOutput {
    transaction: Transaction;
}
export interface ContractFilter {
    network: string;
    tokenStandard: string;
    deployerAddress: string;
}
export type NextToken = string;
export interface ListAssetContractsInput {
    contractFilter: ContractFilter;
    nextToken?: string;
    maxResults?: number;
}
export interface AssetContract {
    contractIdentifier: ContractIdentifier;
    tokenStandard: string;
    deployerAddress: string;
}
export type AssetContractList = AssetContract[];
export interface ListAssetContractsOutput {
    contracts: AssetContract[];
    nextToken?: string;
}
export type ChainAddresses = string[];
export interface AddressIdentifierFilter {
    transactionEventToAddress: string[];
}
export interface TimeFilter {
    from?: BlockchainInstant;
    to?: BlockchainInstant;
}
export interface VoutFilter {
    voutSpent: boolean;
}
export type ConfirmationStatusIncludeList = string[];
export interface ConfirmationStatusFilter {
    include: string[];
}
export type ListFilteredTransactionEventsSortBy = string;
export type SortOrder = string;
export interface ListFilteredTransactionEventsSort {
    sortBy?: string;
    sortOrder?: string;
}
export interface ListFilteredTransactionEventsInput {
    network: string;
    addressIdentifierFilter: AddressIdentifierFilter;
    timeFilter?: TimeFilter;
    voutFilter?: VoutFilter;
    confirmationStatusFilter?: ConfirmationStatusFilter;
    sort?: ListFilteredTransactionEventsSort;
    nextToken?: string;
    maxResults?: number;
}
export type QueryTransactionEventType = string;
export interface TransactionEvent {
    network: string;
    transactionHash: string;
    eventType: string;
    from?: string;
    to?: string;
    value?: string;
    contractAddress?: string;
    tokenId?: string;
    transactionId?: string;
    voutIndex?: number;
    voutSpent?: boolean;
    spentVoutTransactionId?: string;
    spentVoutTransactionHash?: string;
    spentVoutIndex?: number;
    blockchainInstant?: BlockchainInstant;
    confirmationStatus?: string;
}
export type TransactionEventList = TransactionEvent[];
export interface ListFilteredTransactionEventsOutput {
    events: TransactionEvent[];
    nextToken?: string;
}
export interface OwnerFilter {
    address: string;
}
export interface TokenFilter {
    network: string;
    contractAddress?: string;
    tokenId?: string;
}
export interface ListTokenBalancesInput {
    ownerFilter?: OwnerFilter;
    tokenFilter: TokenFilter;
    nextToken?: string;
    maxResults?: number;
}
export interface TokenBalance {
    ownerIdentifier?: OwnerIdentifier;
    tokenIdentifier?: TokenIdentifier;
    balance: string;
    atBlockchainInstant: BlockchainInstant;
    lastUpdatedTime?: BlockchainInstant;
}
export type TokenBalanceList = TokenBalance[];
export interface ListTokenBalancesOutput {
    tokenBalances: TokenBalance[];
    nextToken?: string;
}
export interface ListTransactionEventsInput {
    transactionHash?: string;
    transactionId?: string;
    network: string;
    nextToken?: string;
    maxResults?: number;
}
export interface ListTransactionEventsOutput {
    events: TransactionEvent[];
    nextToken?: string;
}
export type ListTransactionsSortBy = string;
export interface ListTransactionsSort {
    sortBy?: string;
    sortOrder?: string;
}
export interface ListTransactionsInput {
    address: string;
    network: string;
    fromBlockchainInstant?: BlockchainInstant;
    toBlockchainInstant?: BlockchainInstant;
    sort?: ListTransactionsSort;
    nextToken?: string;
    maxResults?: number;
    confirmationStatusFilter?: ConfirmationStatusFilter;
}
export interface TransactionOutputItem {
    transactionHash: string;
    transactionId?: string;
    network: string;
    transactionTimestamp: Date;
    confirmationStatus?: string;
}
export type TransactionOutputList = TransactionOutputItem[];
export interface ListTransactionsOutput {
    transactions: TransactionOutputItem[];
    nextToken?: string;
}
export type ExceptionMessage = string;
export type ResourceId = string;
export type ResourceType = string;
export type ServiceCode = string;
export type QuotaCode = string;
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type BatchGetTokenBalanceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the token balance for a batch of tokens by using the `BatchGetTokenBalance`
 * action for every token in the request.
 *
 * Only the native tokens BTC and ETH, and the ERC-20,
 * ERC-721, and ERC 1155 token standards are supported.
 */
export declare const batchGetTokenBalance: API.OperationMethod<BatchGetTokenBalanceInput, BatchGetTokenBalanceOutput, BatchGetTokenBalanceError, Credentials | HttpClient.HttpClient>;
export type GetAssetContractError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the information about a specific contract deployed on the blockchain.
 *
 * - The Bitcoin blockchain networks do not support this
 * operation.
 *
 * - Metadata is currently only available for some `ERC-20` contracts.
 * Metadata will be available for additional contracts in the future.
 */
export declare const getAssetContract: API.OperationMethod<GetAssetContractInput, GetAssetContractOutput, GetAssetContractError, Credentials | HttpClient.HttpClient>;
export type GetTokenBalanceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the balance of a specific token, including native tokens, for a given address (wallet or contract) on the blockchain.
 *
 * Only the native tokens BTC and ETH, and the ERC-20,
 * ERC-721, and ERC 1155 token standards are supported.
 */
export declare const getTokenBalance: API.OperationMethod<GetTokenBalanceInput, GetTokenBalanceOutput, GetTokenBalanceError, Credentials | HttpClient.HttpClient>;
export type GetTransactionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of a transaction.
 *
 * This action will return transaction details for all transactions
 * that are *confirmed* on the blockchain, even if they have not reached
 * finality.
 */
export declare const getTransaction: API.OperationMethod<GetTransactionInput, GetTransactionOutput, GetTransactionError, Credentials | HttpClient.HttpClient>;
export type ListAssetContractsError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the contracts for a given contract type deployed by an address
 * (either a contract address or a wallet address).
 *
 * The Bitcoin blockchain networks do not support this
 * operation.
 */
export declare const listAssetContracts: API.PaginatedOperationMethod<ListAssetContractsInput, ListAssetContractsOutput, ListAssetContractsError, Credentials | HttpClient.HttpClient, AssetContract>;
export type ListFilteredTransactionEventsError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the transaction events for an address on the blockchain.
 *
 * This operation is only supported on the Bitcoin networks.
 */
export declare const listFilteredTransactionEvents: API.PaginatedOperationMethod<ListFilteredTransactionEventsInput, ListFilteredTransactionEventsOutput, ListFilteredTransactionEventsError, Credentials | HttpClient.HttpClient, TransactionEvent>;
export type ListTokenBalancesError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This action returns the following for a given blockchain network:
 *
 * - Lists all token balances owned by an address (either a contract
 * address or a wallet address).
 *
 * - Lists all token balances for all tokens created by a contract.
 *
 * - Lists all token balances for a given token.
 *
 * You must always specify the network property of
 * the `tokenFilter` when using this operation.
 */
export declare const listTokenBalances: API.PaginatedOperationMethod<ListTokenBalancesInput, ListTokenBalancesOutput, ListTokenBalancesError, Credentials | HttpClient.HttpClient, TokenBalance>;
export type ListTransactionEventsError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the transaction events for a transaction
 *
 * This action will return transaction details for all transactions
 * that are *confirmed* on the blockchain, even if they have not reached
 * finality.
 */
export declare const listTransactionEvents: API.PaginatedOperationMethod<ListTransactionEventsInput, ListTransactionEventsOutput, ListTransactionEventsError, Credentials | HttpClient.HttpClient, TransactionEvent>;
export type ListTransactionsError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the transaction events for a transaction.
 */
export declare const listTransactions: API.PaginatedOperationMethod<ListTransactionsInput, ListTransactionsOutput, ListTransactionsError, Credentials | HttpClient.HttpClient, TransactionOutputItem>;
export {};
//# sourceMappingURL=managedblockchain-query.d.ts.map