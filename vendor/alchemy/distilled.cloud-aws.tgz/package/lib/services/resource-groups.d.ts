import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const GroupAlreadyExists_base: S.TaggedErrorClass<"GroupAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class GroupAlreadyExists extends /*@__PURE__*/ GroupAlreadyExists_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const MethodNotAllowedException_base: S.TaggedErrorClass<"MethodNotAllowedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MethodNotAllowedException extends /*@__PURE__*/ MethodNotAllowedException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
export type TagSyncTaskArn = string;
export interface CancelTagSyncTaskInput {
    TaskArn: string;
}
export interface CancelTagSyncTaskResponse {
}
export type CreateGroupName = string;
export type Description = string;
export type QueryType = "TAG_FILTERS_1_0" | "CLOUDFORMATION_STACK_1_0" | (string & {});
export type Query = string;
export interface ResourceQuery {
    Type: QueryType;
    Query: string;
}
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export type GroupConfigurationType = string;
export type GroupConfigurationParameterName = string;
export type GroupConfigurationParameterValue = string;
export type GroupConfigurationParameterValueList = string[];
export interface GroupConfigurationParameter {
    Name: string;
    Values?: string[];
}
export type GroupParameterList = GroupConfigurationParameter[];
export interface GroupConfigurationItem {
    Type: string;
    Parameters?: GroupConfigurationParameter[];
}
export type GroupConfigurationList = GroupConfigurationItem[];
export type Criticality = number;
export type Owner = string;
export type DisplayName = string;
export interface CreateGroupInput {
    Name: string;
    Description?: string;
    ResourceQuery?: ResourceQuery;
    Tags?: {
        [key: string]: string | undefined;
    };
    Configuration?: GroupConfigurationItem[];
    Criticality?: number;
    Owner?: string;
    DisplayName?: string;
}
export type GroupArnV2 = string;
export type GroupName = string;
export type ApplicationTagKey = string;
export type ApplicationArn = string;
export type ApplicationTag = {
    [key: string]: string | undefined;
};
export interface Group {
    GroupArn: string;
    Name: string;
    Description?: string;
    Criticality?: number;
    Owner?: string;
    DisplayName?: string;
    ApplicationTag?: {
        [key: string]: string | undefined;
    };
}
export type GroupConfigurationStatus = "UPDATING" | "UPDATE_COMPLETE" | "UPDATE_FAILED" | (string & {});
export type GroupConfigurationFailureReason = string;
export interface GroupConfiguration {
    Configuration?: GroupConfigurationItem[];
    ProposedConfiguration?: GroupConfigurationItem[];
    Status?: GroupConfigurationStatus;
    FailureReason?: string;
}
export interface CreateGroupOutput {
    Group: Group;
    ResourceQuery?: ResourceQuery;
    Tags?: {
        [key: string]: string | undefined;
    };
    GroupConfiguration?: GroupConfiguration;
}
export type GroupStringV2 = string;
export interface DeleteGroupInput {
    GroupName?: string;
    Group?: string;
}
export interface DeleteGroupOutput {
    Group?: Group;
}
export interface GetAccountSettingsRequest {
}
export type GroupLifecycleEventsDesiredStatus = "ACTIVE" | "INACTIVE" | (string & {});
export type GroupLifecycleEventsStatus = "ACTIVE" | "INACTIVE" | "IN_PROGRESS" | "ERROR" | (string & {});
export type GroupLifecycleEventsStatusMessage = string;
export interface AccountSettings {
    GroupLifecycleEventsDesiredStatus?: GroupLifecycleEventsDesiredStatus;
    GroupLifecycleEventsStatus?: GroupLifecycleEventsStatus;
    GroupLifecycleEventsStatusMessage?: string;
}
export interface GetAccountSettingsOutput {
    AccountSettings?: AccountSettings;
}
export interface GetGroupInput {
    GroupName?: string;
    Group?: string;
}
export interface GetGroupOutput {
    Group: Group;
}
export type GroupString = string;
export interface GetGroupConfigurationInput {
    Group?: string;
}
export interface GetGroupConfigurationOutput {
    GroupConfiguration?: GroupConfiguration;
}
export interface GetGroupQueryInput {
    GroupName?: string;
    Group?: string;
}
export interface GroupQuery {
    GroupName: string;
    ResourceQuery: ResourceQuery;
}
export interface GetGroupQueryOutput {
    GroupQuery?: GroupQuery;
}
export interface GetTagsInput {
    Arn: string;
}
export interface GetTagsOutput {
    Arn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetTagSyncTaskInput {
    TaskArn: string;
}
export type RoleArn = string;
export type TagSyncTaskStatus = "ACTIVE" | "ERROR" | (string & {});
export type ErrorMessage = string;
export interface GetTagSyncTaskOutput {
    GroupArn?: string;
    GroupName?: string;
    TaskArn?: string;
    TagKey?: string;
    TagValue?: string;
    ResourceQuery?: ResourceQuery;
    RoleArn?: string;
    Status?: TagSyncTaskStatus;
    ErrorMessage?: string;
    CreatedAt?: Date;
}
export type ResourceArn = string;
export type ResourceArnList = string[];
export interface GroupResourcesInput {
    Group: string;
    ResourceArns: string[];
}
export type ErrorCode = string;
export interface FailedResource {
    ResourceArn?: string;
    ErrorMessage?: string;
    ErrorCode?: string;
}
export type FailedResourceList = FailedResource[];
export interface PendingResource {
    ResourceArn?: string;
}
export type PendingResourceList = PendingResource[];
export interface GroupResourcesOutput {
    Succeeded?: string[];
    Failed?: FailedResource[];
    Pending?: PendingResource[];
}
export type MaxResults = number;
export type ListGroupingStatusesFilterName = "status" | "resource-arn" | (string & {});
export type ListGroupingStatusesFilterValue = string;
export type ListGroupingStatusesFilterValues = string[];
export interface ListGroupingStatusesFilter {
    Name: ListGroupingStatusesFilterName;
    Values: string[];
}
export type ListGroupingStatusesFilterList = ListGroupingStatusesFilter[];
export type NextToken = string;
export interface ListGroupingStatusesInput {
    Group: string;
    MaxResults?: number;
    Filters?: ListGroupingStatusesFilter[];
    NextToken?: string;
}
export type GroupingType = "GROUP" | "UNGROUP" | (string & {});
export type GroupingStatus = "SUCCESS" | "FAILED" | "IN_PROGRESS" | "SKIPPED" | (string & {});
export interface GroupingStatusesItem {
    ResourceArn?: string;
    Action?: GroupingType;
    Status?: GroupingStatus;
    ErrorMessage?: string;
    ErrorCode?: string;
    UpdatedAt?: Date;
}
export type GroupingStatusesList = GroupingStatusesItem[];
export interface ListGroupingStatusesOutput {
    Group?: string;
    GroupingStatuses?: GroupingStatusesItem[];
    NextToken?: string;
}
export type ResourceFilterName = "resource-type" | (string & {});
export type ResourceFilterValue = string;
export type ResourceFilterValues = string[];
export interface ResourceFilter {
    Name: ResourceFilterName;
    Values: string[];
}
export type ResourceFilterList = ResourceFilter[];
export interface ListGroupResourcesInput {
    GroupName?: string;
    Group?: string;
    Filters?: ResourceFilter[];
    MaxResults?: number;
    NextToken?: string;
}
export type ResourceType = string;
export interface ResourceIdentifier {
    ResourceArn?: string;
    ResourceType?: string;
}
export type ResourceStatusValue = "PENDING" | (string & {});
export interface ResourceStatus {
    Name?: ResourceStatusValue;
}
export interface ListGroupResourcesItem {
    Identifier?: ResourceIdentifier;
    Status?: ResourceStatus;
}
export type ListGroupResourcesItemList = ListGroupResourcesItem[];
export type ResourceIdentifierList = ResourceIdentifier[];
export type QueryErrorCode = "CLOUDFORMATION_STACK_INACTIVE" | "CLOUDFORMATION_STACK_NOT_EXISTING" | "CLOUDFORMATION_STACK_UNASSUMABLE_ROLE" | "RESOURCE_TYPE_NOT_SUPPORTED" | (string & {});
export type QueryErrorMessage = string;
export interface QueryError {
    ErrorCode?: QueryErrorCode;
    Message?: string;
}
export type QueryErrorList = QueryError[];
export interface ListGroupResourcesOutput {
    Resources?: ListGroupResourcesItem[];
    ResourceIdentifiers?: ResourceIdentifier[];
    NextToken?: string;
    QueryErrors?: QueryError[];
}
export type GroupFilterName = "resource-type" | "configuration-type" | "owner" | "display-name" | "criticality" | (string & {});
export type GroupFilterValue = string;
export type GroupFilterValues = string[];
export interface GroupFilter {
    Name: GroupFilterName;
    Values: string[];
}
export type GroupFilterList = GroupFilter[];
export interface ListGroupsInput {
    Filters?: GroupFilter[];
    MaxResults?: number;
    NextToken?: string;
}
export type GroupArn = string;
export interface GroupIdentifier {
    GroupName?: string;
    GroupArn?: string;
    Description?: string;
    Criticality?: number;
    Owner?: string;
    DisplayName?: string;
}
export type GroupIdentifierList = GroupIdentifier[];
export type GroupList = Group[];
export interface ListGroupsOutput {
    GroupIdentifiers?: GroupIdentifier[];
    Groups?: Group[];
    NextToken?: string;
}
export interface ListTagSyncTasksFilter {
    GroupArn?: string;
    GroupName?: string;
}
export type ListTagSyncTasksFilterList = ListTagSyncTasksFilter[];
export interface ListTagSyncTasksInput {
    Filters?: ListTagSyncTasksFilter[];
    MaxResults?: number;
    NextToken?: string;
}
export interface TagSyncTaskItem {
    GroupArn?: string;
    GroupName?: string;
    TaskArn?: string;
    TagKey?: string;
    TagValue?: string;
    ResourceQuery?: ResourceQuery;
    RoleArn?: string;
    Status?: TagSyncTaskStatus;
    ErrorMessage?: string;
    CreatedAt?: Date;
}
export type TagSyncTaskList = TagSyncTaskItem[];
export interface ListTagSyncTasksOutput {
    TagSyncTasks?: TagSyncTaskItem[];
    NextToken?: string;
}
export interface PutGroupConfigurationInput {
    Group?: string;
    Configuration?: GroupConfigurationItem[];
}
export interface PutGroupConfigurationOutput {
}
export interface SearchResourcesInput {
    ResourceQuery: ResourceQuery;
    MaxResults?: number;
    NextToken?: string;
}
export interface SearchResourcesOutput {
    ResourceIdentifiers?: ResourceIdentifier[];
    NextToken?: string;
    QueryErrors?: QueryError[];
}
export interface StartTagSyncTaskInput {
    Group: string;
    TagKey?: string;
    TagValue?: string;
    ResourceQuery?: ResourceQuery;
    RoleArn: string;
}
export interface StartTagSyncTaskOutput {
    GroupArn?: string;
    GroupName?: string;
    TaskArn?: string;
    TagKey?: string;
    TagValue?: string;
    ResourceQuery?: ResourceQuery;
    RoleArn?: string;
}
export interface TagInput {
    Arn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagOutput {
    Arn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface UngroupResourcesInput {
    Group: string;
    ResourceArns: string[];
}
export interface UngroupResourcesOutput {
    Succeeded?: string[];
    Failed?: FailedResource[];
    Pending?: PendingResource[];
}
export type TagKeyList = string[];
export interface UntagInput {
    Arn: string;
    Keys: string[];
}
export interface UntagOutput {
    Arn?: string;
    Keys?: string[];
}
export interface UpdateAccountSettingsInput {
    GroupLifecycleEventsDesiredStatus?: GroupLifecycleEventsDesiredStatus;
}
export interface UpdateAccountSettingsOutput {
    AccountSettings?: AccountSettings;
}
export interface UpdateGroupInput {
    GroupName?: string;
    Group?: string;
    Description?: string;
    Criticality?: number;
    Owner?: string;
    DisplayName?: string;
}
export interface UpdateGroupOutput {
    Group?: Group;
}
export interface UpdateGroupQueryInput {
    GroupName?: string;
    Group?: string;
    ResourceQuery: ResourceQuery;
}
export interface UpdateGroupQueryOutput {
    GroupQuery?: GroupQuery;
}
export type CancelTagSyncTaskError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Cancels the specified tag-sync task.
 *
 * **Minimum permissions**
 *
 * To run this command, you must have the following permissions:
 *
 * - `resource-groups:CancelTagSyncTask` on the application group
 *
 * - `resource-groups:DeleteGroup`
 */
export declare const cancelTagSyncTask: API.OperationMethod<CancelTagSyncTaskInput, CancelTagSyncTaskResponse, CancelTagSyncTaskError, Credentials | HttpClient.HttpClient>;
export type CreateGroupError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | TooManyRequestsException | GroupAlreadyExists | CommonErrors;
/**
 * Creates a resource group with the specified name and description. You can optionally
 * include either a resource query or a service configuration. For more information about
 * constructing a resource query, see Build queries and groups in
 * Resource Groups in the *Resource Groups User Guide*. For more information
 * about service-linked groups and service configurations, see Service configurations for Resource Groups.
 *
 * **Minimum permissions**
 *
 * To run this command, you must have the following permissions:
 *
 * - `resource-groups:CreateGroup`
 */
export declare const createGroup: API.OperationMethod<CreateGroupInput, CreateGroupOutput, CreateGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the specified resource group. Deleting a resource group does not delete any
 * resources that are members of the group; it only deletes the group structure.
 *
 * **Minimum permissions**
 *
 * To run this command, you must have the following permissions:
 *
 * - `resource-groups:DeleteGroup`
 */
export declare const deleteGroup: API.OperationMethod<DeleteGroupInput, DeleteGroupOutput, DeleteGroupError, Credentials | HttpClient.HttpClient>;
export type GetAccountSettingsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the current status of optional features in Resource Groups.
 */
export declare const getAccountSettings: API.OperationMethod<GetAccountSettingsRequest, GetAccountSettingsOutput, GetAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type GetGroupError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns information about a specified resource group.
 *
 * **Minimum permissions**
 *
 * To run this command, you must have the following permissions:
 *
 * - `resource-groups:GetGroup`
 */
export declare const getGroup: API.OperationMethod<GetGroupInput, GetGroupOutput, GetGroupError, Credentials | HttpClient.HttpClient>;
export type GetGroupConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the service configuration associated with the specified resource group. For
 * details about the service configuration syntax, see Service configurations for Resource Groups.
 *
 * **Minimum permissions**
 *
 * To run this command, you must have the following permissions:
 *
 * - `resource-groups:GetGroupConfiguration`
 */
export declare const getGroupConfiguration: API.OperationMethod<GetGroupConfigurationInput, GetGroupConfigurationOutput, GetGroupConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetGroupQueryError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the resource query associated with the specified resource group. For more
 * information about resource queries, see Create
 * a tag-based group in Resource Groups.
 *
 * **Minimum permissions**
 *
 * To run this command, you must have the following permissions:
 *
 * - `resource-groups:GetGroupQuery`
 */
export declare const getGroupQuery: API.OperationMethod<GetGroupQueryInput, GetGroupQueryOutput, GetGroupQueryError, Credentials | HttpClient.HttpClient>;
export type GetTagsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns a list of tags that are associated with a resource group, specified by an
 * Amazon resource name (ARN).
 *
 * **Minimum permissions**
 *
 * To run this command, you must have the following permissions:
 *
 * - `resource-groups:GetTags`
 */
export declare const getTags: API.OperationMethod<GetTagsInput, GetTagsOutput, GetTagsError, Credentials | HttpClient.HttpClient>;
export type GetTagSyncTaskError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns information about a specified tag-sync task.
 *
 * **Minimum permissions**
 *
 * To run this command, you must have the following permissions:
 *
 * - `resource-groups:GetTagSyncTask` on the application group
 */
export declare const getTagSyncTask: API.OperationMethod<GetTagSyncTaskInput, GetTagSyncTaskOutput, GetTagSyncTaskError, Credentials | HttpClient.HttpClient>;
export type GroupResourcesError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Adds the specified resources to the specified group.
 *
 * You can only use this operation with the following groups:
 *
 * - `AWS::EC2::HostManagement`
 *
 * - `AWS::EC2::CapacityReservationPool`
 *
 * - `AWS::ResourceGroups::ApplicationGroup`
 *
 * Other resource group types and resource types are not currently supported by this
 * operation.
 *
 * **Minimum permissions**
 *
 * To run this command, you must have the following permissions:
 *
 * - `resource-groups:GroupResources`
 */
export declare const groupResources: API.OperationMethod<GroupResourcesInput, GroupResourcesOutput, GroupResourcesError, Credentials | HttpClient.HttpClient>;
export type ListGroupingStatusesError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | TooManyRequestsException | NotFoundException | CommonErrors;
/**
 * Returns the status of the last grouping or ungrouping action for
 * each resource in the specified application group.
 */
export declare const listGroupingStatuses: API.PaginatedOperationMethod<ListGroupingStatusesInput, ListGroupingStatusesOutput, ListGroupingStatusesError, Credentials | HttpClient.HttpClient, GroupingStatusesItem>;
export type ListGroupResourcesError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of Amazon resource names (ARNs) of the resources that are members of a specified resource
 * group.
 *
 * **Minimum permissions**
 *
 * To run this command, you must have the following permissions:
 *
 * - `resource-groups:ListGroupResources`
 *
 * - `cloudformation:DescribeStacks`
 *
 * - `cloudformation:ListStackResources`
 *
 * - `tag:GetResources`
 */
export declare const listGroupResources: API.PaginatedOperationMethod<ListGroupResourcesInput, ListGroupResourcesOutput, ListGroupResourcesError, Credentials | HttpClient.HttpClient, ResourceIdentifier>;
export type ListGroupsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | TooManyRequestsException | CommonErrors;
/**
 * Returns a list of existing Resource Groups in your account.
 *
 * **Minimum permissions**
 *
 * To run this command, you must have the following permissions:
 *
 * - `resource-groups:ListGroups`
 */
export declare const listGroups: API.PaginatedOperationMethod<ListGroupsInput, ListGroupsOutput, ListGroupsError, Credentials | HttpClient.HttpClient, GroupIdentifier>;
export type ListTagSyncTasksError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of tag-sync tasks.
 *
 * **Minimum permissions**
 *
 * To run this command, you must have the following permissions:
 *
 * - `resource-groups:ListTagSyncTasks` with the group passed in the filters as the resource
 * or * if using no filters
 */
export declare const listTagSyncTasks: API.PaginatedOperationMethod<ListTagSyncTasksInput, ListTagSyncTasksOutput, ListTagSyncTasksError, Credentials | HttpClient.HttpClient, TagSyncTaskItem>;
export type PutGroupConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Attaches a service configuration to the specified group. This occurs asynchronously,
 * and can take time to complete. You can use GetGroupConfiguration to
 * check the status of the update.
 *
 * **Minimum permissions**
 *
 * To run this command, you must have the following permissions:
 *
 * - `resource-groups:PutGroupConfiguration`
 */
export declare const putGroupConfiguration: API.OperationMethod<PutGroupConfigurationInput, PutGroupConfigurationOutput, PutGroupConfigurationError, Credentials | HttpClient.HttpClient>;
export type SearchResourcesError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of Amazon Web Services resource identifiers that matches the specified query. The
 * query uses the same format as a resource query in a CreateGroup or
 * UpdateGroupQuery operation.
 *
 * **Minimum permissions**
 *
 * To run this command, you must have the following permissions:
 *
 * - `resource-groups:SearchResources`
 *
 * - `cloudformation:DescribeStacks`
 *
 * - `cloudformation:ListStackResources`
 *
 * - `tag:GetResources`
 */
export declare const searchResources: API.PaginatedOperationMethod<SearchResourcesInput, SearchResourcesOutput, SearchResourcesError, Credentials | HttpClient.HttpClient, ResourceIdentifier>;
export type StartTagSyncTaskError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new tag-sync task to onboard and sync resources tagged with a specific tag key-value pair to an
 * application. To start a tag-sync task, you need a resource tagging role.
 * The resource tagging role grants permissions to tag and untag applications resources and must include a
 * trust policy that allows Resource Groups to assume the role and perform resource tagging tasks on your behalf.
 *
 * For instructions on creating a tag-sync task, see Create a tag-sync
 * using the Resource Groups API in the *Amazon Web Services Service Catalog AppRegistry Administrator Guide*.
 *
 * **Minimum permissions**
 *
 * To run this command, you must have the following permissions:
 *
 * - `resource-groups:StartTagSyncTask` on the application group
 *
 * - `resource-groups:CreateGroup`
 *
 * - `iam:PassRole` on the role provided in the request
 */
export declare const startTagSyncTask: API.OperationMethod<StartTagSyncTaskInput, StartTagSyncTaskOutput, StartTagSyncTaskError, Credentials | HttpClient.HttpClient>;
export type TagError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Adds tags to a resource group with the specified Amazon resource name (ARN). Existing tags on a resource
 * group are not changed if they are not specified in the request parameters.
 *
 * Do not store personally identifiable information (PII) or other confidential or
 * sensitive information in tags. We use tags to provide you with billing and
 * administration services. Tags are not intended to be used for private or sensitive
 * data.
 *
 * **Minimum permissions**
 *
 * To run this command, you must have the following permissions:
 *
 * - `resource-groups:Tag`
 */
export declare const tag: API.OperationMethod<TagInput, TagOutput, TagError, Credentials | HttpClient.HttpClient>;
export type UngroupResourcesError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes the specified resources from the specified group. This operation works only
 * with static groups that you populated using the GroupResources
 * operation. It doesn't work with any resource groups that are automatically populated by
 * tag-based or CloudFormation stack-based queries.
 *
 * **Minimum permissions**
 *
 * To run this command, you must have the following permissions:
 *
 * - `resource-groups:UngroupResources`
 */
export declare const ungroupResources: API.OperationMethod<UngroupResourcesInput, UngroupResourcesOutput, UngroupResourcesError, Credentials | HttpClient.HttpClient>;
export type UntagError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes tags from a specified resource group.
 *
 * **Minimum permissions**
 *
 * To run this command, you must have the following permissions:
 *
 * - `resource-groups:Untag`
 */
export declare const untag: API.OperationMethod<UntagInput, UntagOutput, UntagError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountSettingsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | TooManyRequestsException | CommonErrors;
/**
 * Turns on or turns off optional features in Resource Groups.
 *
 * The preceding example shows that the request to turn on group lifecycle events is
 * `IN_PROGRESS`. You can call the GetAccountSettings
 * operation to check for completion by looking for `GroupLifecycleEventsStatus`
 * to change to `ACTIVE`.
 */
export declare const updateAccountSettings: API.OperationMethod<UpdateAccountSettingsInput, UpdateAccountSettingsOutput, UpdateAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateGroupError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the description for an existing group. You cannot update the name of a
 * resource group.
 *
 * **Minimum permissions**
 *
 * To run this command, you must have the following permissions:
 *
 * - `resource-groups:UpdateGroup`
 */
export declare const updateGroup: API.OperationMethod<UpdateGroupInput, UpdateGroupOutput, UpdateGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateGroupQueryError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the resource query of a group. For more information about resource queries,
 * see Create a tag-based group in Resource Groups.
 *
 * **Minimum permissions**
 *
 * To run this command, you must have the following permissions:
 *
 * - `resource-groups:UpdateGroupQuery`
 */
export declare const updateGroupQuery: API.OperationMethod<UpdateGroupQueryInput, UpdateGroupQueryOutput, UpdateGroupQueryError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=resource-groups.d.ts.map