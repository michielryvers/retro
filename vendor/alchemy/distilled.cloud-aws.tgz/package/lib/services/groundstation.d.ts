import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const DependencyException_base: S.TaggedErrorClass<"DependencyException", {
    readonly message: any;
    readonly parameterName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class DependencyException extends /*@__PURE__*/ DependencyException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
    readonly parameterName: any;
}>;
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceLimitExceededException_base: S.TaggedErrorClass<"ResourceLimitExceededException", {
    readonly message: any;
    readonly parameterName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ResourceLimitExceededException extends /*@__PURE__*/ ResourceLimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly parameterName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
export type Uuid = string;
export interface CancelContactRequest {
    contactId: string;
}
export type VersionId = number;
export interface ContactIdResponse {
    contactId?: string;
    versionId?: number;
}
export type SafeName = string;
export type FrequencyUnits = "GHz" | "MHz" | "kHz" | (string & {});
export interface Frequency {
    value: number;
    units: FrequencyUnits;
}
export type BandwidthUnits = "GHz" | "MHz" | "kHz" | (string & {});
export interface FrequencyBandwidth {
    value: number;
    units: BandwidthUnits;
}
export type Polarization = "RIGHT_HAND" | "LEFT_HAND" | "NONE" | (string & {});
export interface SpectrumConfig {
    centerFrequency: Frequency;
    bandwidth: FrequencyBandwidth;
    polarization?: Polarization;
}
export interface AntennaDownlinkConfig {
    spectrumConfig: SpectrumConfig;
}
export type Criticality = "REQUIRED" | "PREFERRED" | "REMOVED" | (string & {});
export interface TrackingConfig {
    autotrack: Criticality;
}
export interface DataflowEndpointConfig {
    dataflowEndpointName: string;
    dataflowEndpointRegion?: string;
}
export type JsonString = string;
export interface DemodulationConfig {
    unvalidatedJSON: string;
}
export interface DecodeConfig {
    unvalidatedJSON: string;
}
export interface AntennaDownlinkDemodDecodeConfig {
    spectrumConfig: SpectrumConfig;
    demodulationConfig: DemodulationConfig;
    decodeConfig: DecodeConfig;
}
export interface UplinkSpectrumConfig {
    centerFrequency: Frequency;
    polarization?: Polarization;
}
export type EirpUnits = "dBW" | (string & {});
export interface Eirp {
    value: number;
    units: EirpUnits;
}
export interface AntennaUplinkConfig {
    transmitDisabled?: boolean;
    spectrumConfig: UplinkSpectrumConfig;
    targetEirp: Eirp;
}
export type ConfigArn = string;
export interface UplinkEchoConfig {
    enabled: boolean;
    antennaUplinkConfigArn: string;
}
export type BucketArn = string;
export type RoleArn = string;
export type S3KeyPrefix = string;
export interface S3RecordingConfig {
    bucketArn: string;
    roleArn: string;
    prefix?: string;
}
export type TelemetrySinkType = "KINESIS_DATA_STREAM" | (string & {});
export type KinesisDataStreamArn = string;
export interface KinesisDataStreamData {
    kinesisRoleArn: string;
    kinesisDataStreamArn: string;
}
export type TelemetrySinkData = {
    kinesisDataStreamData: KinesisDataStreamData;
};
export interface TelemetrySinkConfig {
    telemetrySinkType: TelemetrySinkType;
    telemetrySinkData: TelemetrySinkData;
}
export type ConfigTypeData = {
    antennaDownlinkConfig: AntennaDownlinkConfig;
    trackingConfig?: never;
    dataflowEndpointConfig?: never;
    antennaDownlinkDemodDecodeConfig?: never;
    antennaUplinkConfig?: never;
    uplinkEchoConfig?: never;
    s3RecordingConfig?: never;
    telemetrySinkConfig?: never;
} | {
    antennaDownlinkConfig?: never;
    trackingConfig: TrackingConfig;
    dataflowEndpointConfig?: never;
    antennaDownlinkDemodDecodeConfig?: never;
    antennaUplinkConfig?: never;
    uplinkEchoConfig?: never;
    s3RecordingConfig?: never;
    telemetrySinkConfig?: never;
} | {
    antennaDownlinkConfig?: never;
    trackingConfig?: never;
    dataflowEndpointConfig: DataflowEndpointConfig;
    antennaDownlinkDemodDecodeConfig?: never;
    antennaUplinkConfig?: never;
    uplinkEchoConfig?: never;
    s3RecordingConfig?: never;
    telemetrySinkConfig?: never;
} | {
    antennaDownlinkConfig?: never;
    trackingConfig?: never;
    dataflowEndpointConfig?: never;
    antennaDownlinkDemodDecodeConfig: AntennaDownlinkDemodDecodeConfig;
    antennaUplinkConfig?: never;
    uplinkEchoConfig?: never;
    s3RecordingConfig?: never;
    telemetrySinkConfig?: never;
} | {
    antennaDownlinkConfig?: never;
    trackingConfig?: never;
    dataflowEndpointConfig?: never;
    antennaDownlinkDemodDecodeConfig?: never;
    antennaUplinkConfig: AntennaUplinkConfig;
    uplinkEchoConfig?: never;
    s3RecordingConfig?: never;
    telemetrySinkConfig?: never;
} | {
    antennaDownlinkConfig?: never;
    trackingConfig?: never;
    dataflowEndpointConfig?: never;
    antennaDownlinkDemodDecodeConfig?: never;
    antennaUplinkConfig?: never;
    uplinkEchoConfig: UplinkEchoConfig;
    s3RecordingConfig?: never;
    telemetrySinkConfig?: never;
} | {
    antennaDownlinkConfig?: never;
    trackingConfig?: never;
    dataflowEndpointConfig?: never;
    antennaDownlinkDemodDecodeConfig?: never;
    antennaUplinkConfig?: never;
    uplinkEchoConfig?: never;
    s3RecordingConfig: S3RecordingConfig;
    telemetrySinkConfig?: never;
} | {
    antennaDownlinkConfig?: never;
    trackingConfig?: never;
    dataflowEndpointConfig?: never;
    antennaDownlinkDemodDecodeConfig?: never;
    antennaUplinkConfig?: never;
    uplinkEchoConfig?: never;
    s3RecordingConfig?: never;
    telemetrySinkConfig: TelemetrySinkConfig;
};
export type TagsMap = {
    [key: string]: string | undefined;
};
export interface CreateConfigRequest {
    name: string;
    configData: ConfigTypeData;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type ConfigCapabilityType = "antenna-downlink" | "antenna-downlink-demod-decode" | "tracking" | "dataflow-endpoint" | "antenna-uplink" | "uplink-echo" | "s3-recording" | "telemetry-sink" | (string & {});
export interface ConfigIdResponse {
    configId?: string;
    configType?: ConfigCapabilityType;
    configArn?: string;
}
export type SubnetList = string[];
export type SecurityGroupIdList = string[];
export interface SecurityDetails {
    subnetIds: string[];
    securityGroupIds: string[];
    roleArn: string;
}
export interface SocketAddress {
    name: string;
    port: number;
}
export type EndpointStatus = "created" | "creating" | "deleted" | "deleting" | "failed" | (string & {});
export interface DataflowEndpoint {
    name?: string;
    address?: SocketAddress;
    status?: EndpointStatus;
    mtu?: number;
}
export interface ConnectionDetails {
    socketAddress: SocketAddress;
    mtu?: number;
}
export type IpV4Address = string;
export interface IntegerRange {
    minimum: number;
    maximum: number;
}
export interface RangedSocketAddress {
    name: string;
    portRange: IntegerRange;
}
export interface RangedConnectionDetails {
    socketAddress: RangedSocketAddress;
    mtu?: number;
}
export type AgentStatus = "SUCCESS" | "FAILED" | "ACTIVE" | "INACTIVE" | (string & {});
export type AuditResults = "HEALTHY" | "UNHEALTHY" | (string & {});
export interface AwsGroundStationAgentEndpoint {
    name: string;
    egressAddress: ConnectionDetails;
    ingressAddress: RangedConnectionDetails;
    agentStatus?: AgentStatus;
    auditResults?: AuditResults;
}
export interface UplinkConnectionDetails {
    ingressAddressAndPort: ConnectionDetails;
    agentIpAndPortAddress: RangedConnectionDetails;
}
export type UplinkDataflowDetails = {
    agentConnectionDetails: UplinkConnectionDetails;
};
export interface UplinkAwsGroundStationAgentEndpointDetails {
    name: string;
    dataflowDetails: UplinkDataflowDetails;
    agentStatus?: AgentStatus;
    auditResults?: AuditResults;
}
export interface DownlinkConnectionDetails {
    agentIpAndPortAddress: RangedConnectionDetails;
    egressAddressAndPort: ConnectionDetails;
}
export type DownlinkDataflowDetails = {
    agentConnectionDetails: DownlinkConnectionDetails;
};
export interface DownlinkAwsGroundStationAgentEndpointDetails {
    name: string;
    dataflowDetails: DownlinkDataflowDetails;
    agentStatus?: AgentStatus;
    auditResults?: AuditResults;
}
export type CapabilityHealth = "HEALTHY" | "UNHEALTHY" | (string & {});
export type CapabilityHealthReason = "NO_REGISTERED_AGENT" | "INVALID_IP_OWNERSHIP" | "NOT_AUTHORIZED_TO_CREATE_SLR" | "UNVERIFIED_IP_OWNERSHIP" | "INITIALIZING_DATAPLANE" | "DATAPLANE_FAILURE" | "HEALTHY" | (string & {});
export type CapabilityHealthReasonList = CapabilityHealthReason[];
export interface EndpointDetails {
    securityDetails?: SecurityDetails;
    endpoint?: DataflowEndpoint;
    awsGroundStationAgentEndpoint?: AwsGroundStationAgentEndpoint;
    uplinkAwsGroundStationAgentEndpoint?: UplinkAwsGroundStationAgentEndpointDetails;
    downlinkAwsGroundStationAgentEndpoint?: DownlinkAwsGroundStationAgentEndpointDetails;
    healthStatus?: CapabilityHealth;
    healthReasons?: CapabilityHealthReason[];
}
export type EndpointDetailsList = EndpointDetails[];
export type DataflowEndpointGroupDurationInSeconds = number;
export interface CreateDataflowEndpointGroupRequest {
    endpointDetails: EndpointDetails[];
    tags?: {
        [key: string]: string | undefined;
    };
    contactPrePassDurationSeconds?: number;
    contactPostPassDurationSeconds?: number;
}
export interface DataflowEndpointGroupIdResponse {
    dataflowEndpointGroupId?: string;
}
export interface UplinkAwsGroundStationAgentEndpoint {
    name: string;
    dataflowDetails: UplinkDataflowDetails;
}
export interface DownlinkAwsGroundStationAgentEndpoint {
    name: string;
    dataflowDetails: DownlinkDataflowDetails;
}
export type CreateEndpointDetails = {
    uplinkAwsGroundStationAgentEndpoint: UplinkAwsGroundStationAgentEndpoint;
    downlinkAwsGroundStationAgentEndpoint?: never;
} | {
    uplinkAwsGroundStationAgentEndpoint?: never;
    downlinkAwsGroundStationAgentEndpoint: DownlinkAwsGroundStationAgentEndpoint;
};
export type CreateEndpointDetailsList = CreateEndpointDetails[];
export interface CreateDataflowEndpointGroupV2Request {
    endpoints: CreateEndpointDetails[];
    contactPrePassDurationSeconds?: number;
    contactPostPassDurationSeconds?: number;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateDataflowEndpointGroupV2Response {
    dataflowEndpointGroupId?: string;
}
export type CustomerEphemerisPriority = number;
export type KeyArn = string;
export type S3BucketName = string;
export type S3ObjectKey = string;
export type S3VersionId = string;
export interface S3Object {
    bucket?: string;
    key?: string;
    version?: string;
}
export type TleLineOne = string;
export type TleLineTwo = string;
export interface TimeRange {
    startTime: Date;
    endTime: Date;
}
export interface TLEData {
    tleLine1: string;
    tleLine2: string;
    validTimeRange: TimeRange;
}
export type TLEDataList = TLEData[];
export interface TLEEphemeris {
    s3Object?: S3Object;
    tleData?: TLEData[];
}
export type UnboundedString = string;
export interface OEMEphemeris {
    s3Object?: S3Object;
    oemData?: string;
}
export type GroundStationName = string;
export type AngleUnits = "DEGREE_ANGLE" | "RADIAN" | (string & {});
export interface ISO8601TimeRange {
    startTime: Date;
    endTime: Date;
}
export interface TimeAzEl {
    dt: number;
    az: number;
    el: number;
}
export type TimeAzElList = TimeAzEl[];
export interface AzElSegment {
    referenceEpoch: Date;
    validTimeRange: ISO8601TimeRange;
    azElList: TimeAzEl[];
}
export type AzElSegmentList = AzElSegment[];
export interface AzElSegments {
    angleUnit: AngleUnits;
    azElSegmentList: AzElSegment[];
}
export type AzElSegmentsData = {
    s3Object: S3Object;
    azElData?: never;
} | {
    s3Object?: never;
    azElData: AzElSegments;
};
export interface AzElEphemeris {
    groundStation: string;
    data: AzElSegmentsData;
}
export type EphemerisData = {
    tle: TLEEphemeris;
    oem?: never;
    azEl?: never;
} | {
    tle?: never;
    oem: OEMEphemeris;
    azEl?: never;
} | {
    tle?: never;
    oem?: never;
    azEl: AzElEphemeris;
};
export interface CreateEphemerisRequest {
    satelliteId?: string;
    enabled?: boolean;
    priority?: number;
    expirationTime?: Date;
    name: string;
    kmsKeyArn?: string;
    ephemeris?: EphemerisData;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface EphemerisIdResponse {
    ephemerisId?: string;
}
export type DurationInSeconds = number;
export type PositiveDurationInSeconds = number;
export type DataflowEdge = string[];
export type DataflowEdgeList = string[][];
export type KeyAliasArn = string;
export type KeyAliasName = string;
export type KmsKey = {
    kmsKeyArn: string;
    kmsAliasArn?: never;
    kmsAliasName?: never;
} | {
    kmsKeyArn?: never;
    kmsAliasArn: string;
    kmsAliasName?: never;
} | {
    kmsKeyArn?: never;
    kmsAliasArn?: never;
    kmsAliasName: string;
};
export interface CreateMissionProfileRequest {
    name: string;
    contactPrePassDurationSeconds?: number;
    contactPostPassDurationSeconds?: number;
    minimumViableContactDurationSeconds: number;
    dataflowEdges: string[][];
    trackingConfigArn: string;
    telemetrySinkConfigArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    streamsKmsKey?: KmsKey;
    streamsKmsRole?: string;
}
export interface MissionProfileIdResponse {
    missionProfileId?: string;
}
export interface DeleteConfigRequest {
    configId: string;
    configType: ConfigCapabilityType;
}
export interface DeleteDataflowEndpointGroupRequest {
    dataflowEndpointGroupId: string;
}
export interface DeleteEphemerisRequest {
    ephemerisId: string;
}
export interface DeleteMissionProfileRequest {
    missionProfileId: string;
}
export interface DescribeContactRequest {
    contactId: string;
}
export type MissionProfileArn = string;
export type SatelliteArn = string;
export type ContactStatus = "SCHEDULING" | "FAILED_TO_SCHEDULE" | "SCHEDULED" | "CANCELLED" | "AWS_CANCELLED" | "PREPASS" | "PASS" | "POSTPASS" | "COMPLETED" | "FAILED" | "AVAILABLE" | "CANCELLING" | "AWS_FAILED" | (string & {});
export interface Elevation {
    value: number;
    unit: AngleUnits;
}
export interface AntennaDemodDecodeDetails {
    outputNode?: string;
}
export interface S3RecordingDetails {
    bucketArn?: string;
    keyTemplate?: string;
}
export type ConfigDetails = {
    endpointDetails: EndpointDetails;
    antennaDemodDecodeDetails?: never;
    s3RecordingDetails?: never;
} | {
    endpointDetails?: never;
    antennaDemodDecodeDetails: AntennaDemodDecodeDetails;
    s3RecordingDetails?: never;
} | {
    endpointDetails?: never;
    antennaDemodDecodeDetails?: never;
    s3RecordingDetails: S3RecordingDetails;
};
export interface Source {
    configType?: ConfigCapabilityType;
    configId?: string;
    configDetails?: ConfigDetails;
    dataflowSourceRegion?: string;
}
export interface Destination {
    configType?: ConfigCapabilityType;
    configId?: string;
    configDetails?: ConfigDetails;
    dataflowDestinationRegion?: string;
}
export interface DataflowDetail {
    source?: Source;
    destination?: Destination;
    errorMessage?: string;
}
export type DataflowList = DataflowDetail[];
export interface AzElProgramTrackSettings {
    ephemerisId: string;
}
export interface OemProgramTrackSettings {
    ephemerisId: string;
}
export interface TleProgramTrackSettings {
    ephemerisId: string;
}
export type ProgramTrackSettings = {
    azEl: AzElProgramTrackSettings;
    oem?: never;
    tle?: never;
} | {
    azEl?: never;
    oem: OemProgramTrackSettings;
    tle?: never;
} | {
    azEl?: never;
    oem?: never;
    tle: TleProgramTrackSettings;
};
export interface TrackingOverrides {
    programTrackSettings?: ProgramTrackSettings;
}
export type EphemerisType = "TLE" | "OEM" | "AZ_EL" | "SERVICE_MANAGED" | (string & {});
export interface EphemerisResponseData {
    ephemerisId?: string;
    ephemerisType: EphemerisType;
}
export type VersionStatus = "UPDATING" | "ACTIVE" | "SUPERSEDED" | "FAILED_TO_UPDATE" | (string & {});
export type VersionFailureReasonCode = "INTERNAL_ERROR" | "INVALID_SATELLITE_ARN" | "INVALID_UPDATE_CONTACT_REQUEST" | "EPHEMERIS_NOT_FOUND" | "EPHEMERIS_TIME_RANGE_INVALID" | "EPHEMERIS_NOT_ENABLED" | "SATELLITE_DOES_NOT_MATCH_EPHEMERIS" | "NOT_ONBOARDED_TO_AZEL_EPHEMERIS" | "AZEL_EPHEMERIS_NOT_FOUND" | "AZEL_EPHEMERIS_WRONG_GROUND_STATION" | "AZEL_EPHEMERIS_INVALID_STATUS" | "AZEL_EPHEMERIS_TIME_RANGE_INVALID" | (string & {});
export type VersionFailureReasonCodes = VersionFailureReasonCode[];
export interface ContactVersion {
    versionId?: number;
    created?: Date;
    activated?: Date;
    superseded?: Date;
    lastUpdated?: Date;
    status?: VersionStatus;
    failureCodes?: VersionFailureReasonCode[];
    failureMessage?: string;
}
export interface DescribeContactResponse {
    contactId?: string;
    missionProfileArn?: string;
    satelliteArn?: string;
    startTime?: Date;
    endTime?: Date;
    prePassStartTime?: Date;
    postPassEndTime?: Date;
    groundStation?: string;
    contactStatus?: ContactStatus;
    errorMessage?: string;
    maximumElevation?: Elevation;
    tags?: {
        [key: string]: string | undefined;
    };
    region?: string;
    dataflowList?: DataflowDetail[];
    visibilityStartTime?: Date;
    visibilityEndTime?: Date;
    trackingOverrides?: TrackingOverrides;
    ephemeris?: EphemerisResponseData;
    version?: ContactVersion;
}
export interface DescribeContactVersionRequest {
    contactId: string;
    versionId: number;
}
export interface DescribeContactVersionResponse {
    contactId?: string;
    missionProfileArn?: string;
    satelliteArn?: string;
    startTime?: Date;
    endTime?: Date;
    prePassStartTime?: Date;
    postPassEndTime?: Date;
    groundStation?: string;
    contactStatus?: ContactStatus;
    errorMessage?: string;
    maximumElevation?: Elevation;
    tags?: {
        [key: string]: string | undefined;
    };
    region?: string;
    dataflowList?: DataflowDetail[];
    visibilityStartTime?: Date;
    visibilityEndTime?: Date;
    trackingOverrides?: TrackingOverrides;
    ephemeris?: EphemerisResponseData;
    version?: ContactVersion;
}
export interface DescribeEphemerisRequest {
    ephemerisId: string;
}
export type EphemerisStatus = "VALIDATING" | "INVALID" | "ERROR" | "ENABLED" | "DISABLED" | "EXPIRED" | (string & {});
export type EphemerisPriority = number;
export interface EphemerisDescription {
    sourceS3Object?: S3Object;
    ephemerisData?: string;
}
export type EphemerisTypeDescription = {
    tle: EphemerisDescription;
    oem?: never;
    azEl?: never;
} | {
    tle?: never;
    oem: EphemerisDescription;
    azEl?: never;
} | {
    tle?: never;
    oem?: never;
    azEl: EphemerisDescription;
};
export type EphemerisInvalidReason = "METADATA_INVALID" | "TIME_RANGE_INVALID" | "TRAJECTORY_INVALID" | "KMS_KEY_INVALID" | "VALIDATION_ERROR" | (string & {});
export type EphemerisErrorCode = "INTERNAL_ERROR" | "MISMATCHED_SATCAT_ID" | "OEM_VERSION_UNSUPPORTED" | "ORIGINATOR_MISSING" | "CREATION_DATE_MISSING" | "OBJECT_NAME_MISSING" | "OBJECT_ID_MISSING" | "REF_FRAME_UNSUPPORTED" | "REF_FRAME_EPOCH_UNSUPPORTED" | "TIME_SYSTEM_UNSUPPORTED" | "CENTER_BODY_UNSUPPORTED" | "INTERPOLATION_MISSING" | "INTERPOLATION_DEGREE_INVALID" | "AZ_EL_SEGMENT_LIST_MISSING" | "INSUFFICIENT_TIME_AZ_EL" | "START_TIME_IN_FUTURE" | "END_TIME_IN_PAST" | "EXPIRATION_TIME_TOO_EARLY" | "START_TIME_METADATA_TOO_EARLY" | "STOP_TIME_METADATA_TOO_LATE" | "AZ_EL_SEGMENT_END_TIME_BEFORE_START_TIME" | "AZ_EL_SEGMENT_TIMES_OVERLAP" | "AZ_EL_SEGMENTS_OUT_OF_ORDER" | "TIME_AZ_EL_ITEMS_OUT_OF_ORDER" | "MEAN_MOTION_INVALID" | "TIME_AZ_EL_AZ_RADIAN_RANGE_INVALID" | "TIME_AZ_EL_EL_RADIAN_RANGE_INVALID" | "TIME_AZ_EL_AZ_DEGREE_RANGE_INVALID" | "TIME_AZ_EL_EL_DEGREE_RANGE_INVALID" | "TIME_AZ_EL_ANGLE_UNITS_INVALID" | "INSUFFICIENT_KMS_PERMISSIONS" | "FILE_FORMAT_INVALID" | "AZ_EL_SEGMENT_REFERENCE_EPOCH_INVALID" | "AZ_EL_SEGMENT_START_TIME_INVALID" | "AZ_EL_SEGMENT_END_TIME_INVALID" | "AZ_EL_SEGMENT_VALID_TIME_RANGE_INVALID" | "AZ_EL_SEGMENT_END_TIME_TOO_LATE" | "AZ_EL_TOTAL_DURATION_EXCEEDED" | (string & {});
export type ErrorString = string;
export interface EphemerisErrorReason {
    errorCode: EphemerisErrorCode;
    errorMessage: string;
}
export type EphemerisErrorReasonList = EphemerisErrorReason[];
export interface DescribeEphemerisResponse {
    ephemerisId?: string;
    satelliteId?: string;
    status?: EphemerisStatus;
    priority?: number;
    creationTime?: Date;
    enabled?: boolean;
    name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    suppliedData?: EphemerisTypeDescription;
    invalidReason?: EphemerisInvalidReason;
    errorReasons?: EphemerisErrorReason[];
}
export interface GetAgentConfigurationRequest {
    agentId: string;
}
export interface GetAgentConfigurationResponse {
    agentId?: string;
    taskingDocument?: string;
}
export interface GetAgentTaskResponseUrlRequest {
    agentId: string;
    taskId: string;
}
export interface GetAgentTaskResponseUrlResponse {
    agentId: string;
    taskId: string;
    presignedLogUrl: string;
}
export interface GetConfigRequest {
    configId: string;
    configType: ConfigCapabilityType;
}
export interface GetConfigResponse {
    configId: string;
    configArn: string;
    name: string;
    configType?: ConfigCapabilityType;
    configData: ConfigTypeData;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetDataflowEndpointGroupRequest {
    dataflowEndpointGroupId: string;
}
export type DataflowEndpointGroupArn = string;
export interface GetDataflowEndpointGroupResponse {
    dataflowEndpointGroupId?: string;
    dataflowEndpointGroupArn?: string;
    endpointsDetails?: EndpointDetails[];
    tags?: {
        [key: string]: string | undefined;
    };
    contactPrePassDurationSeconds?: number;
    contactPostPassDurationSeconds?: number;
}
export type Month = number;
export type Year = number;
export interface GetMinuteUsageRequest {
    month: number;
    year: number;
}
export interface GetMinuteUsageResponse {
    isReservedMinutesCustomer?: boolean;
    totalReservedMinuteAllocation?: number;
    upcomingMinutesScheduled?: number;
    totalScheduledMinutes?: number;
    estimatedMinutesRemaining?: number;
}
export interface GetMissionProfileRequest {
    missionProfileId: string;
}
export type AWSRegion = string;
export interface GetMissionProfileResponse {
    missionProfileId?: string;
    missionProfileArn?: string;
    name?: string;
    region?: string;
    contactPrePassDurationSeconds?: number;
    contactPostPassDurationSeconds?: number;
    minimumViableContactDurationSeconds?: number;
    dataflowEdges?: string[][];
    trackingConfigArn?: string;
    telemetrySinkConfigArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    streamsKmsKey?: KmsKey;
    streamsKmsRole?: string;
}
export interface GetSatelliteRequest {
    satelliteId: string;
}
export type NoradSatelliteID = number;
export type GroundStationIdList = string[];
export type EphemerisSource = "CUSTOMER_PROVIDED" | "SPACE_TRACK" | (string & {});
export interface EphemerisMetaData {
    source: EphemerisSource;
    ephemerisId?: string;
    epoch?: Date;
    name?: string;
}
export interface GetSatelliteResponse {
    satelliteId?: string;
    satelliteArn?: string;
    noradSatelliteID?: number;
    groundStations?: string[];
    currentEphemeris?: EphemerisMetaData;
}
export type PaginationMaxResults = number;
export type PaginationToken = string;
export interface ListAntennasRequest {
    groundStationId: string;
    maxResults?: number;
    nextToken?: string;
}
export type AntennaName = string;
export interface AntennaListItem {
    groundStationName: string;
    antennaName: string;
    region: string;
}
export type AntennaList = AntennaListItem[];
export interface ListAntennasResponse {
    antennaList: AntennaListItem[];
    nextToken?: string;
}
export interface ListConfigsRequest {
    maxResults?: number;
    nextToken?: string;
}
export interface ConfigListItem {
    configId?: string;
    configType?: ConfigCapabilityType;
    configArn?: string;
    name?: string;
}
export type ConfigList = ConfigListItem[];
export interface ListConfigsResponse {
    nextToken?: string;
    configList?: ConfigListItem[];
}
export type StatusList = ContactStatus[];
export interface AzElEphemerisFilter {
    id: string;
}
export type EphemerisFilter = {
    azEl: AzElEphemerisFilter;
};
export interface ListContactsRequest {
    maxResults?: number;
    nextToken?: string;
    statusList: ContactStatus[];
    startTime: Date;
    endTime: Date;
    groundStation?: string;
    satelliteArn?: string;
    missionProfileArn?: string;
    ephemeris?: EphemerisFilter;
}
export interface ContactData {
    contactId?: string;
    missionProfileArn?: string;
    satelliteArn?: string;
    startTime?: Date;
    endTime?: Date;
    prePassStartTime?: Date;
    postPassEndTime?: Date;
    groundStation?: string;
    contactStatus?: ContactStatus;
    errorMessage?: string;
    maximumElevation?: Elevation;
    region?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    visibilityStartTime?: Date;
    visibilityEndTime?: Date;
    ephemeris?: EphemerisResponseData;
    version?: ContactVersion;
}
export type ContactList = ContactData[];
export interface ListContactsResponse {
    nextToken?: string;
    contactList?: ContactData[];
}
export interface ListContactVersionsRequest {
    contactId: string;
    maxResults?: number;
    nextToken?: string;
}
export type ContactVersionsList = ContactVersion[];
export interface ListContactVersionsResponse {
    nextToken?: string;
    contactVersionsList?: ContactVersion[];
}
export interface ListDataflowEndpointGroupsRequest {
    maxResults?: number;
    nextToken?: string;
}
export interface DataflowEndpointListItem {
    dataflowEndpointGroupId?: string;
    dataflowEndpointGroupArn?: string;
}
export type DataflowEndpointGroupList = DataflowEndpointListItem[];
export interface ListDataflowEndpointGroupsResponse {
    nextToken?: string;
    dataflowEndpointGroupList?: DataflowEndpointListItem[];
}
export type EphemerisStatusList = EphemerisStatus[];
export interface ListEphemeridesRequest {
    satelliteId?: string;
    ephemerisType?: EphemerisType;
    startTime: Date;
    endTime: Date;
    statusList?: EphemerisStatus[];
    maxResults?: number;
    nextToken?: string;
}
export interface EphemerisItem {
    ephemerisId?: string;
    ephemerisType?: EphemerisType;
    status?: EphemerisStatus;
    priority?: number;
    enabled?: boolean;
    creationTime?: Date;
    name?: string;
    sourceS3Object?: S3Object;
}
export type EphemeridesList = EphemerisItem[];
export interface ListEphemeridesResponse {
    nextToken?: string;
    ephemerides?: EphemerisItem[];
}
export type ReservationType = "MAINTENANCE" | "CONTACT" | (string & {});
export type ReservationTypeFilterList = ReservationType[];
export interface ListGroundStationReservationsRequest {
    groundStationId: string;
    startTime: Date;
    endTime: Date;
    reservationTypes?: ReservationType[];
    maxResults?: number;
    nextToken?: string;
}
export type MaintenanceType = "PLANNED" | "UNPLANNED" | (string & {});
export interface MaintenanceReservationDetails {
    maintenanceType: MaintenanceType;
}
export interface ContactReservationDetails {
    contactId?: string;
}
export type ReservationDetails = {
    maintenance: MaintenanceReservationDetails;
    contact?: never;
} | {
    maintenance?: never;
    contact: ContactReservationDetails;
};
export interface GroundStationReservationListItem {
    reservationType: ReservationType;
    groundStationId: string;
    antennaName: string;
    startTime: Date;
    endTime: Date;
    reservationDetails: ReservationDetails;
}
export type GroundStationReservationList = GroundStationReservationListItem[];
export interface ListGroundStationReservationsResponse {
    reservationList: GroundStationReservationListItem[];
    nextToken?: string;
}
export interface ListGroundStationsRequest {
    satelliteId?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface GroundStationData {
    groundStationId?: string;
    groundStationName?: string;
    region?: string;
}
export type GroundStationList = GroundStationData[];
export interface ListGroundStationsResponse {
    nextToken?: string;
    groundStationList?: GroundStationData[];
}
export interface ListMissionProfilesRequest {
    maxResults?: number;
    nextToken?: string;
}
export interface MissionProfileListItem {
    missionProfileId?: string;
    missionProfileArn?: string;
    region?: string;
    name?: string;
}
export type MissionProfileList = MissionProfileListItem[];
export interface ListMissionProfilesResponse {
    nextToken?: string;
    missionProfileList?: MissionProfileListItem[];
}
export interface ListSatellitesRequest {
    maxResults?: number;
    nextToken?: string;
}
export interface SatelliteListItem {
    satelliteId?: string;
    satelliteArn?: string;
    noradSatelliteID?: number;
    groundStations?: string[];
    currentEphemeris?: EphemerisMetaData;
}
export type SatelliteList = SatelliteListItem[];
export interface ListSatellitesResponse {
    nextToken?: string;
    satellites?: SatelliteListItem[];
}
export type AnyArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export type IpAddressList = string[];
export type CapabilityArn = string;
export type CapabilityArnList = string[];
export interface DiscoveryData {
    publicIpAddresses: string[];
    privateIpAddresses: string[];
    capabilityArns: string[];
}
export type VersionString = string;
export type InstanceId = string;
export type InstanceType = string;
export type AgentCpuCoresList = number[];
export type ComponentTypeString = string;
export type VersionStringList = string[];
export interface ComponentVersion {
    componentType: string;
    versions: string[];
}
export type ComponentVersionList = ComponentVersion[];
export interface AgentDetails {
    agentVersion: string;
    instanceId: string;
    instanceType: string;
    reservedCpuCores?: number[];
    agentCpuCores?: number[];
    componentVersions: ComponentVersion[];
}
export interface RegisterAgentRequest {
    discoveryData: DiscoveryData;
    agentDetails: AgentDetails;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface RegisterAgentResponse {
    agentId?: string;
}
export interface ReserveContactRequest {
    missionProfileArn: string;
    satelliteArn?: string;
    startTime: Date;
    endTime: Date;
    groundStation: string;
    tags?: {
        [key: string]: string | undefined;
    };
    trackingOverrides?: TrackingOverrides;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export type SignatureMap = {
    [key: string]: boolean | undefined;
};
export interface AggregateStatus {
    status: AgentStatus;
    signatureMap?: {
        [key: string]: boolean | undefined;
    };
}
export interface ComponentStatusData {
    componentType: string;
    capabilityArn: string;
    status: AgentStatus;
    bytesSent?: number;
    bytesReceived?: number;
    packetsDropped?: number;
    dataflowId: string;
}
export type ComponentStatusList = ComponentStatusData[];
export interface UpdateAgentStatusRequest {
    agentId: string;
    taskId: string;
    aggregateStatus: AggregateStatus;
    componentStatuses: ComponentStatusData[];
}
export interface UpdateAgentStatusResponse {
    agentId: string;
}
export interface UpdateConfigRequest {
    configId: string;
    name: string;
    configType: ConfigCapabilityType;
    configData: ConfigTypeData;
}
export type ClientToken = string;
export interface UpdateContactRequest {
    contactId: string;
    clientToken?: string;
    trackingOverrides?: TrackingOverrides;
    satelliteArn?: string;
}
export interface UpdateContactResponse {
    contactId?: string;
    versionId?: number;
}
export interface UpdateEphemerisRequest {
    ephemerisId: string;
    enabled: boolean;
    name?: string;
    priority?: number;
}
export interface UpdateMissionProfileRequest {
    missionProfileId: string;
    name?: string;
    contactPrePassDurationSeconds?: number;
    contactPostPassDurationSeconds?: number;
    minimumViableContactDurationSeconds?: number;
    dataflowEdges?: string[][];
    trackingConfigArn?: string;
    telemetrySinkConfigArn?: string;
    streamsKmsKey?: KmsKey;
    streamsKmsRole?: string;
}
export type CancelContactError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Cancels or stops a contact with a specified contact ID based on its position in the contact lifecycle.
 *
 * For contacts that:
 *
 * - Have yet to start, the contact will be cancelled.
 *
 * - Have started but have yet to finish, the contact will be stopped.
 */
export declare const cancelContact: API.OperationMethod<CancelContactRequest, ContactIdResponse, CancelContactError, Credentials | HttpClient.HttpClient>;
export type CreateConfigError = DependencyException | InvalidParameterException | ResourceLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a `Config` with the specified `configData` parameters.
 *
 * Only one type of `configData` can be specified.
 */
export declare const createConfig: API.OperationMethod<CreateConfigRequest, ConfigIdResponse, CreateConfigError, Credentials | HttpClient.HttpClient>;
export type CreateDataflowEndpointGroupError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a `DataflowEndpoint` group containing the specified list of ` DataflowEndpoint` objects.
 *
 * The `name` field in each endpoint is used in your mission profile ` DataflowEndpointConfig` to specify which endpoints to use during a contact.
 *
 * When a contact uses multiple `DataflowEndpointConfig` objects, each ` Config` must match a `DataflowEndpoint` in the same group.
 */
export declare const createDataflowEndpointGroup: API.OperationMethod<CreateDataflowEndpointGroupRequest, DataflowEndpointGroupIdResponse, CreateDataflowEndpointGroupError, Credentials | HttpClient.HttpClient>;
export type CreateDataflowEndpointGroupV2Error = DependencyException | InvalidParameterException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a `DataflowEndpoint` group containing the specified list of Ground Station Agent based endpoints.
 *
 * The `name` field in each endpoint is used in your mission profile ` DataflowEndpointConfig` to specify which endpoints to use during a contact.
 *
 * When a contact uses multiple `DataflowEndpointConfig` objects, each ` Config` must match a `DataflowEndpoint` in the same group.
 */
export declare const createDataflowEndpointGroupV2: API.OperationMethod<CreateDataflowEndpointGroupV2Request, CreateDataflowEndpointGroupV2Response, CreateDataflowEndpointGroupV2Error, Credentials | HttpClient.HttpClient>;
export type CreateEphemerisError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Create an ephemeris with your specified EphemerisData.
 */
export declare const createEphemeris: API.OperationMethod<CreateEphemerisRequest, EphemerisIdResponse, CreateEphemerisError, Credentials | HttpClient.HttpClient>;
export type CreateMissionProfileError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a mission profile.
 *
 * `dataflowEdges` is a list of lists of strings. Each lower level list of strings has two elements: a *from* ARN and a *to* ARN.
 */
export declare const createMissionProfile: API.OperationMethod<CreateMissionProfileRequest, MissionProfileIdResponse, CreateMissionProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a `Config`.
 */
export declare const deleteConfig: API.OperationMethod<DeleteConfigRequest, ConfigIdResponse, DeleteConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteDataflowEndpointGroupError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a dataflow endpoint group.
 */
export declare const deleteDataflowEndpointGroup: API.OperationMethod<DeleteDataflowEndpointGroupRequest, DataflowEndpointGroupIdResponse, DeleteDataflowEndpointGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteEphemerisError = DependencyException | InvalidParameterException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Delete an ephemeris.
 */
export declare const deleteEphemeris: API.OperationMethod<DeleteEphemerisRequest, EphemerisIdResponse, DeleteEphemerisError, Credentials | HttpClient.HttpClient>;
export type DeleteMissionProfileError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a mission profile.
 */
export declare const deleteMissionProfile: API.OperationMethod<DeleteMissionProfileRequest, MissionProfileIdResponse, DeleteMissionProfileError, Credentials | HttpClient.HttpClient>;
export type DescribeContactError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Describes an existing contact.
 */
export declare const describeContact: API.OperationMethod<DescribeContactRequest, DescribeContactResponse, DescribeContactError, Credentials | HttpClient.HttpClient>;
export type DescribeContactVersionError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a specific version of a contact.
 */
export declare const describeContactVersion: API.OperationMethod<DescribeContactVersionRequest, DescribeContactVersionResponse, DescribeContactVersionError, Credentials | HttpClient.HttpClient>;
export type DescribeEphemerisError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieve information about an existing ephemeris.
 */
export declare const describeEphemeris: API.OperationMethod<DescribeEphemerisRequest, DescribeEphemerisResponse, DescribeEphemerisError, Credentials | HttpClient.HttpClient>;
export type GetAgentConfigurationError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * For use by AWS Ground Station Agent and shouldn't be called directly.
 *
 * Gets the latest configuration information for a registered agent.
 */
export declare const getAgentConfiguration: API.OperationMethod<GetAgentConfigurationRequest, GetAgentConfigurationResponse, GetAgentConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetAgentTaskResponseUrlError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * For use by AWS Ground Station Agent and shouldn't be called directly.
 *
 * Gets a presigned URL for uploading agent task response logs.
 */
export declare const getAgentTaskResponseUrl: API.OperationMethod<GetAgentTaskResponseUrlRequest, GetAgentTaskResponseUrlResponse, GetAgentTaskResponseUrlError, Credentials | HttpClient.HttpClient>;
export type GetConfigError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns `Config` information.
 *
 * Only one `Config` response can be returned.
 */
export declare const getConfig: API.OperationMethod<GetConfigRequest, GetConfigResponse, GetConfigError, Credentials | HttpClient.HttpClient>;
export type GetDataflowEndpointGroupError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns the dataflow endpoint group.
 */
export declare const getDataflowEndpointGroup: API.OperationMethod<GetDataflowEndpointGroupRequest, GetDataflowEndpointGroupResponse, GetDataflowEndpointGroupError, Credentials | HttpClient.HttpClient>;
export type GetMinuteUsageError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns the number of reserved minutes used by account.
 */
export declare const getMinuteUsage: API.OperationMethod<GetMinuteUsageRequest, GetMinuteUsageResponse, GetMinuteUsageError, Credentials | HttpClient.HttpClient>;
export type GetMissionProfileError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a mission profile.
 */
export declare const getMissionProfile: API.OperationMethod<GetMissionProfileRequest, GetMissionProfileResponse, GetMissionProfileError, Credentials | HttpClient.HttpClient>;
export type GetSatelliteError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a satellite.
 */
export declare const getSatellite: API.OperationMethod<GetSatelliteRequest, GetSatelliteResponse, GetSatelliteError, Credentials | HttpClient.HttpClient>;
export type ListAntennasError = DependencyException | InvalidParameterException | CommonErrors;
/**
 * Returns a list of antennas at a specified ground station.
 */
export declare const listAntennas: API.PaginatedOperationMethod<ListAntennasRequest, ListAntennasResponse, ListAntennasError, Credentials | HttpClient.HttpClient, AntennaListItem>;
export type ListConfigsError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of `Config` objects.
 */
export declare const listConfigs: API.PaginatedOperationMethod<ListConfigsRequest, ListConfigsResponse, ListConfigsError, Credentials | HttpClient.HttpClient, ConfigListItem>;
export type ListContactsError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of contacts.
 *
 * If `statusList` contains AVAILABLE, the request must include ` groundStation`, `missionprofileArn`, and `satelliteArn`.
 */
export declare const listContacts: API.PaginatedOperationMethod<ListContactsRequest, ListContactsResponse, ListContactsError, Credentials | HttpClient.HttpClient, ContactData>;
export type ListContactVersionsError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of versions for a specified contact.
 */
export declare const listContactVersions: API.PaginatedOperationMethod<ListContactVersionsRequest, ListContactVersionsResponse, ListContactVersionsError, Credentials | HttpClient.HttpClient, ContactVersion>;
export type ListDataflowEndpointGroupsError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of `DataflowEndpoint` groups.
 */
export declare const listDataflowEndpointGroups: API.PaginatedOperationMethod<ListDataflowEndpointGroupsRequest, ListDataflowEndpointGroupsResponse, ListDataflowEndpointGroupsError, Credentials | HttpClient.HttpClient, DataflowEndpointListItem>;
export type ListEphemeridesError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * List your existing ephemerides.
 */
export declare const listEphemerides: API.PaginatedOperationMethod<ListEphemeridesRequest, ListEphemeridesResponse, ListEphemeridesError, Credentials | HttpClient.HttpClient, EphemerisItem>;
export type ListGroundStationReservationsError = DependencyException | InvalidParameterException | CommonErrors;
/**
 * Returns a list of reservations for a specified ground station.
 */
export declare const listGroundStationReservations: API.PaginatedOperationMethod<ListGroundStationReservationsRequest, ListGroundStationReservationsResponse, ListGroundStationReservationsError, Credentials | HttpClient.HttpClient, GroundStationReservationListItem>;
export type ListGroundStationsError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of ground stations.
 */
export declare const listGroundStations: API.PaginatedOperationMethod<ListGroundStationsRequest, ListGroundStationsResponse, ListGroundStationsError, Credentials | HttpClient.HttpClient, GroundStationData>;
export type ListMissionProfilesError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of mission profiles.
 */
export declare const listMissionProfiles: API.PaginatedOperationMethod<ListMissionProfilesRequest, ListMissionProfilesResponse, ListMissionProfilesError, Credentials | HttpClient.HttpClient, MissionProfileListItem>;
export type ListSatellitesError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of satellites.
 */
export declare const listSatellites: API.PaginatedOperationMethod<ListSatellitesRequest, ListSatellitesResponse, ListSatellitesError, Credentials | HttpClient.HttpClient, SatelliteListItem>;
export type ListTagsForResourceError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of tags for a specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RegisterAgentError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * For use by AWS Ground Station Agent and shouldn't be called directly.
 *
 * Registers a new agent with AWS Ground Station.
 */
export declare const registerAgent: API.OperationMethod<RegisterAgentRequest, RegisterAgentResponse, RegisterAgentError, Credentials | HttpClient.HttpClient>;
export type ReserveContactError = DependencyException | InvalidParameterException | ResourceLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Reserves a contact using specified parameters.
 */
export declare const reserveContact: API.OperationMethod<ReserveContactRequest, ContactIdResponse, ReserveContactError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Assigns a tag to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Deassigns a resource tag.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentStatusError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * For use by AWS Ground Station Agent and shouldn't be called directly.
 *
 * Update the status of the agent.
 */
export declare const updateAgentStatus: API.OperationMethod<UpdateAgentStatusRequest, UpdateAgentStatusResponse, UpdateAgentStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the `Config` used when scheduling contacts.
 *
 * Updating a `Config` will not update the execution parameters for existing future contacts scheduled with this `Config`.
 */
export declare const updateConfig: API.OperationMethod<UpdateConfigRequest, ConfigIdResponse, UpdateConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateContactError = DependencyException | InvalidParameterException | ResourceLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a specific contact.
 */
export declare const updateContact: API.OperationMethod<UpdateContactRequest, UpdateContactResponse, UpdateContactError, Credentials | HttpClient.HttpClient>;
export type UpdateEphemerisError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Update an existing ephemeris.
 */
export declare const updateEphemeris: API.OperationMethod<UpdateEphemerisRequest, EphemerisIdResponse, UpdateEphemerisError, Credentials | HttpClient.HttpClient>;
export type UpdateMissionProfileError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a mission profile.
 *
 * Updating a mission profile will not update the execution parameters for existing future contacts.
 */
export declare const updateMissionProfile: API.OperationMethod<UpdateMissionProfileRequest, MissionProfileIdResponse, UpdateMissionProfileError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=groundstation.d.ts.map