import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly ResourceType: any;
    readonly ServiceCode: any;
    readonly QuotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ConnectorArn = string;
export type ClientToken = string;
export type Tags = {
    [key: string]: string | undefined;
};
export interface CreateChallengeRequest {
    ConnectorArn: string;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type ChallengeArn = string;
export type SensitiveString = string | redacted.Redacted<string>;
export interface Challenge {
    Arn?: string;
    ConnectorArn?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    Password?: string | redacted.Redacted<string>;
}
export interface CreateChallengeResponse {
    Challenge?: Challenge;
}
export type CertificateAuthorityArn = string;
export type AzureApplicationId = string;
export type AzureDomain = string;
export interface IntuneConfiguration {
    AzureApplicationId: string;
    Domain: string;
}
export type MobileDeviceManagement = {
    Intune: IntuneConfiguration;
};
export type VpcEndpointId = string;
export interface CreateConnectorRequest {
    CertificateAuthorityArn: string;
    MobileDeviceManagement?: MobileDeviceManagement;
    VpcEndpointId?: string;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateConnectorResponse {
    ConnectorArn?: string;
}
export interface DeleteChallengeRequest {
    ChallengeArn: string;
}
export interface DeleteChallengeResponse {
}
export interface DeleteConnectorRequest {
    ConnectorArn: string;
}
export interface DeleteConnectorResponse {
}
export interface GetChallengeMetadataRequest {
    ChallengeArn: string;
}
export interface ChallengeMetadata {
    Arn?: string;
    ConnectorArn?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export interface GetChallengeMetadataResponse {
    ChallengeMetadata?: ChallengeMetadata;
}
export interface GetChallengePasswordRequest {
    ChallengeArn: string;
}
export interface GetChallengePasswordResponse {
    Password?: string | redacted.Redacted<string>;
}
export interface GetConnectorRequest {
    ConnectorArn: string;
}
export type ConnectorType = "GENERAL_PURPOSE" | "INTUNE" | (string & {});
export interface OpenIdConfiguration {
    Issuer?: string;
    Subject?: string;
    Audience?: string;
}
export type ConnectorStatus = "CREATING" | "ACTIVE" | "DELETING" | "FAILED" | (string & {});
export type ConnectorStatusReason = "INTERNAL_FAILURE" | "PRIVATECA_ACCESS_DENIED" | "PRIVATECA_INVALID_STATE" | "PRIVATECA_RESOURCE_NOT_FOUND" | "VPC_ENDPOINT_RESOURCE_NOT_FOUND" | "VPC_ENDPOINT_DNS_ENTRIES_NOT_FOUND" | (string & {});
export interface Connector {
    Arn?: string;
    CertificateAuthorityArn?: string;
    Type?: ConnectorType;
    MobileDeviceManagement?: MobileDeviceManagement;
    OpenIdConfiguration?: OpenIdConfiguration;
    Status?: ConnectorStatus;
    StatusReason?: ConnectorStatusReason;
    Endpoint?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export interface GetConnectorResponse {
    Connector?: Connector;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListChallengeMetadataRequest {
    MaxResults?: number;
    NextToken?: string;
    ConnectorArn: string;
}
export interface ChallengeMetadataSummary {
    Arn?: string;
    ConnectorArn?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export type ChallengeMetadataList = ChallengeMetadataSummary[];
export interface ListChallengeMetadataResponse {
    Challenges?: ChallengeMetadataSummary[];
    NextToken?: string;
}
export interface ListConnectorsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface ConnectorSummary {
    Arn?: string;
    CertificateAuthorityArn?: string;
    Type?: ConnectorType;
    MobileDeviceManagement?: MobileDeviceManagement;
    OpenIdConfiguration?: OpenIdConfiguration;
    Status?: ConnectorStatus;
    StatusReason?: ConnectorStatusReason;
    Endpoint?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export type ConnectorList = ConnectorSummary[];
export interface ListConnectorsResponse {
    Connectors?: ConnectorSummary[];
    NextToken?: string;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export type ValidationExceptionReason = "CA_CERT_VALIDITY_TOO_SHORT" | "INVALID_CA_USAGE_MODE" | "INVALID_CONNECTOR_TYPE" | "INVALID_STATE" | "NO_CLIENT_TOKEN" | "UNKNOWN_OPERATION" | "OTHER" | (string & {});
export type CreateChallengeError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * For general-purpose connectors. Creates a *challenge password* for the specified connector. The SCEP protocol uses a challenge password to authenticate a request before issuing a certificate from a certificate authority (CA). Your SCEP clients include the challenge password as part of their certificate request to Connector for SCEP. To retrieve the connector Amazon Resource Names (ARNs) for the connectors in your account, call ListConnectors.
 *
 * To create additional challenge passwords for the connector, call `CreateChallenge` again. We recommend frequently rotating your challenge passwords.
 */
export declare const createChallenge: API.OperationMethod<CreateChallengeRequest, CreateChallengeResponse, CreateChallengeError, Credentials | HttpClient.HttpClient>;
export type CreateConnectorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a SCEP connector. A SCEP connector links Amazon Web Services Private Certificate Authority to your SCEP-compatible devices and mobile device management (MDM) systems. Before you create a connector, you must complete a set of prerequisites, including creation of a private certificate authority (CA) to use with this connector. For more information, see Connector for SCEP prerequisites.
 */
export declare const createConnector: API.OperationMethod<CreateConnectorRequest, CreateConnectorResponse, CreateConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteChallengeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified Challenge.
 */
export declare const deleteChallenge: API.OperationMethod<DeleteChallengeRequest, DeleteChallengeResponse, DeleteChallengeError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified Connector. This operation also deletes any challenges associated with the connector.
 */
export declare const deleteConnector: API.OperationMethod<DeleteConnectorRequest, DeleteConnectorResponse, DeleteConnectorError, Credentials | HttpClient.HttpClient>;
export type GetChallengeMetadataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the metadata for the specified Challenge.
 */
export declare const getChallengeMetadata: API.OperationMethod<GetChallengeMetadataRequest, GetChallengeMetadataResponse, GetChallengeMetadataError, Credentials | HttpClient.HttpClient>;
export type GetChallengePasswordError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the challenge password for the specified Challenge.
 */
export declare const getChallengePassword: API.OperationMethod<GetChallengePasswordRequest, GetChallengePasswordResponse, GetChallengePasswordError, Credentials | HttpClient.HttpClient>;
export type GetConnectorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about the specified Connector. Calling this action returns important details about the connector, such as the public SCEP URL where your clients can request certificates.
 */
export declare const getConnector: API.OperationMethod<GetConnectorRequest, GetConnectorResponse, GetConnectorError, Credentials | HttpClient.HttpClient>;
export type ListChallengeMetadataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the challenge metadata for the specified ARN.
 */
export declare const listChallengeMetadata: API.PaginatedOperationMethod<ListChallengeMetadataRequest, ListChallengeMetadataResponse, ListChallengeMetadataError, Credentials | HttpClient.HttpClient, ChallengeMetadataSummary>;
export type ListConnectorsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the connectors belonging to your Amazon Web Services account.
 */
export declare const listConnectors: API.PaginatedOperationMethod<ListConnectorsRequest, ListConnectorsResponse, ListConnectorsError, Credentials | HttpClient.HttpClient, ConnectorSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the tags associated with the specified resource. Tags are key-value pairs that you can use to categorize and manage your resources, for purposes like billing. For example, you might set the tag key to "customer" and the value to the customer name or ID. You can specify one or more tags to add to each Amazon Web Services resource, up to 50 tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds one or more tags to your resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from your resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=pca-connector-scep.d.ts.map