import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import * as T from "../traits.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const GoneException_base: S.TaggedErrorClass<"GoneException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GoneException extends /*@__PURE__*/ GoneException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const PreconditionFailedException_base: S.TaggedErrorClass<"PreconditionFailedException", {
    readonly Code: any;
    readonly message: any;
}>;
export declare class PreconditionFailedException extends /*@__PURE__*/ PreconditionFailedException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
export type __stringMin0Max256 = string;
export type __stringMin20Max1600 = string;
export type Tags = {
    [key: string]: string | undefined;
};
export interface CreateDiscovererRequest {
    Description?: string;
    SourceArn?: string;
    CrossAccount?: boolean;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type DiscovererState = "STARTED" | "STOPPED" | (string & {});
export interface CreateDiscovererResponse {
    Description?: string;
    DiscovererArn?: string;
    DiscovererId?: string;
    SourceArn?: string;
    State?: DiscovererState;
    CrossAccount?: boolean;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateRegistryRequest {
    Description?: string;
    RegistryName: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateRegistryResponse {
    Description?: string;
    RegistryArn?: string;
    RegistryName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __stringMin1Max100000 = string;
export type Type = "OpenApi3" | "JSONSchemaDraft4" | (string & {});
export interface CreateSchemaRequest {
    Content?: string;
    Description?: string;
    RegistryName: string;
    SchemaName: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Type?: Type;
}
export type __timestampIso8601 = Date;
export interface CreateSchemaResponse {
    Description?: string;
    LastModified?: Date;
    SchemaArn?: string;
    SchemaName?: string;
    SchemaVersion?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Type?: string;
    VersionCreatedDate?: Date;
}
export interface DeleteDiscovererRequest {
    DiscovererId: string;
}
export interface DeleteDiscovererResponse {
}
export interface DeleteRegistryRequest {
    RegistryName: string;
}
export interface DeleteRegistryResponse {
}
export interface DeleteResourcePolicyRequest {
    RegistryName?: string;
}
export interface DeleteResourcePolicyResponse {
}
export interface DeleteSchemaRequest {
    RegistryName: string;
    SchemaName: string;
}
export interface DeleteSchemaResponse {
}
export interface DeleteSchemaVersionRequest {
    RegistryName: string;
    SchemaName: string;
    SchemaVersion: string;
}
export interface DeleteSchemaVersionResponse {
}
export interface DescribeCodeBindingRequest {
    Language: string;
    RegistryName: string;
    SchemaName: string;
    SchemaVersion?: string;
}
export type CodeGenerationStatus = "CREATE_IN_PROGRESS" | "CREATE_COMPLETE" | "CREATE_FAILED" | (string & {});
export interface DescribeCodeBindingResponse {
    CreationDate?: Date;
    LastModified?: Date;
    SchemaVersion?: string;
    Status?: CodeGenerationStatus;
}
export interface DescribeDiscovererRequest {
    DiscovererId: string;
}
export interface DescribeDiscovererResponse {
    Description?: string;
    DiscovererArn?: string;
    DiscovererId?: string;
    SourceArn?: string;
    State?: DiscovererState;
    CrossAccount?: boolean;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeRegistryRequest {
    RegistryName: string;
}
export interface DescribeRegistryResponse {
    Description?: string;
    RegistryArn?: string;
    RegistryName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeSchemaRequest {
    RegistryName: string;
    SchemaName: string;
    SchemaVersion?: string;
}
export interface DescribeSchemaResponse {
    Content?: string;
    Description?: string;
    LastModified?: Date;
    SchemaArn?: string;
    SchemaName?: string;
    SchemaVersion?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Type?: string;
    VersionCreatedDate?: Date;
}
export interface ExportSchemaRequest {
    RegistryName: string;
    SchemaName: string;
    SchemaVersion?: string;
    Type?: string;
}
export interface ExportSchemaResponse {
    Content?: string;
    SchemaArn?: string;
    SchemaName?: string;
    SchemaVersion?: string;
    Type?: string;
}
export interface GetCodeBindingSourceRequest {
    Language: string;
    RegistryName: string;
    SchemaName: string;
    SchemaVersion?: string;
}
export interface GetCodeBindingSourceResponse {
    Body?: T.StreamingOutputBody;
}
export type GetDiscoveredSchemaVersionItemInput = string;
export type __listOfGetDiscoveredSchemaVersionItemInput = string[];
export interface GetDiscoveredSchemaRequest {
    Events?: string[];
    Type?: Type;
}
export interface GetDiscoveredSchemaResponse {
    Content?: string;
}
export interface GetResourcePolicyRequest {
    RegistryName?: string;
}
export type SynthesizedJson__string = string;
export interface GetResourcePolicyResponse {
    Policy?: string;
    RevisionId?: string;
}
export interface ListDiscoverersRequest {
    DiscovererIdPrefix?: string;
    Limit?: number;
    NextToken?: string;
    SourceArnPrefix?: string;
}
export interface DiscovererSummary {
    DiscovererArn?: string;
    DiscovererId?: string;
    SourceArn?: string;
    State?: DiscovererState;
    CrossAccount?: boolean;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfDiscovererSummary = DiscovererSummary[];
export interface ListDiscoverersResponse {
    Discoverers?: DiscovererSummary[];
    NextToken?: string;
}
export interface ListRegistriesRequest {
    Limit?: number;
    NextToken?: string;
    RegistryNamePrefix?: string;
    Scope?: string;
}
export interface RegistrySummary {
    RegistryArn?: string;
    RegistryName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfRegistrySummary = RegistrySummary[];
export interface ListRegistriesResponse {
    NextToken?: string;
    Registries?: RegistrySummary[];
}
export interface ListSchemasRequest {
    Limit?: number;
    NextToken?: string;
    RegistryName: string;
    SchemaNamePrefix?: string;
}
export interface SchemaSummary {
    LastModified?: Date;
    SchemaArn?: string;
    SchemaName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    VersionCount?: number;
}
export type __listOfSchemaSummary = SchemaSummary[];
export interface ListSchemasResponse {
    NextToken?: string;
    Schemas?: SchemaSummary[];
}
export interface ListSchemaVersionsRequest {
    Limit?: number;
    NextToken?: string;
    RegistryName: string;
    SchemaName: string;
}
export interface SchemaVersionSummary {
    SchemaArn?: string;
    SchemaName?: string;
    SchemaVersion?: string;
    Type?: Type;
}
export type __listOfSchemaVersionSummary = SchemaVersionSummary[];
export interface ListSchemaVersionsResponse {
    NextToken?: string;
    SchemaVersions?: SchemaVersionSummary[];
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface PutCodeBindingRequest {
    Language: string;
    RegistryName: string;
    SchemaName: string;
    SchemaVersion?: string;
}
export interface PutCodeBindingResponse {
    CreationDate?: Date;
    LastModified?: Date;
    SchemaVersion?: string;
    Status?: CodeGenerationStatus;
}
export interface PutResourcePolicyRequest {
    Policy?: string;
    RegistryName?: string;
    RevisionId?: string;
}
export interface PutResourcePolicyResponse {
    Policy?: string;
    RevisionId?: string;
}
export interface SearchSchemasRequest {
    Keywords?: string;
    Limit?: number;
    NextToken?: string;
    RegistryName: string;
}
export interface SearchSchemaVersionSummary {
    CreatedDate?: Date;
    SchemaVersion?: string;
    Type?: Type;
}
export type __listOfSearchSchemaVersionSummary = SearchSchemaVersionSummary[];
export interface SearchSchemaSummary {
    RegistryName?: string;
    SchemaArn?: string;
    SchemaName?: string;
    SchemaVersions?: SearchSchemaVersionSummary[];
}
export type __listOfSearchSchemaSummary = SearchSchemaSummary[];
export interface SearchSchemasResponse {
    NextToken?: string;
    Schemas?: SearchSchemaSummary[];
}
export interface StartDiscovererRequest {
    DiscovererId: string;
}
export interface StartDiscovererResponse {
    DiscovererId?: string;
    State?: DiscovererState;
}
export interface StopDiscovererRequest {
    DiscovererId: string;
}
export interface StopDiscovererResponse {
    DiscovererId?: string;
    State?: DiscovererState;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type __listOf__string = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateDiscovererRequest {
    Description?: string;
    DiscovererId: string;
    CrossAccount?: boolean;
}
export interface UpdateDiscovererResponse {
    Description?: string;
    DiscovererArn?: string;
    DiscovererId?: string;
    SourceArn?: string;
    State?: DiscovererState;
    CrossAccount?: boolean;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface UpdateRegistryRequest {
    Description?: string;
    RegistryName: string;
}
export interface UpdateRegistryResponse {
    Description?: string;
    RegistryArn?: string;
    RegistryName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __stringMin0Max36 = string;
export interface UpdateSchemaRequest {
    ClientTokenId?: string;
    Content?: string;
    Description?: string;
    RegistryName: string;
    SchemaName: string;
    Type?: Type;
}
export interface UpdateSchemaResponse {
    Description?: string;
    LastModified?: Date;
    SchemaArn?: string;
    SchemaName?: string;
    SchemaVersion?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Type?: string;
    VersionCreatedDate?: Date;
}
export type CreateDiscovererError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Creates a discoverer.
 */
export declare const createDiscoverer: API.OperationMethod<CreateDiscovererRequest, CreateDiscovererResponse, CreateDiscovererError, Credentials | HttpClient.HttpClient>;
export type CreateRegistryError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Creates a registry.
 */
export declare const createRegistry: API.OperationMethod<CreateRegistryRequest, CreateRegistryResponse, CreateRegistryError, Credentials | HttpClient.HttpClient>;
export type CreateSchemaError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a schema definition.
 *
 * Inactive schemas will be deleted after two years.
 */
export declare const createSchema: API.OperationMethod<CreateSchemaRequest, CreateSchemaResponse, CreateSchemaError, Credentials | HttpClient.HttpClient>;
export type DeleteDiscovererError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Deletes a discoverer.
 */
export declare const deleteDiscoverer: API.OperationMethod<DeleteDiscovererRequest, DeleteDiscovererResponse, DeleteDiscovererError, Credentials | HttpClient.HttpClient>;
export type DeleteRegistryError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Deletes a Registry.
 */
export declare const deleteRegistry: API.OperationMethod<DeleteRegistryRequest, DeleteRegistryResponse, DeleteRegistryError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Delete the resource-based policy attached to the specified registry.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteSchemaError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Delete a schema definition.
 */
export declare const deleteSchema: API.OperationMethod<DeleteSchemaRequest, DeleteSchemaResponse, DeleteSchemaError, Credentials | HttpClient.HttpClient>;
export type DeleteSchemaVersionError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Delete the schema version definition
 */
export declare const deleteSchemaVersion: API.OperationMethod<DeleteSchemaVersionRequest, DeleteSchemaVersionResponse, DeleteSchemaVersionError, Credentials | HttpClient.HttpClient>;
export type DescribeCodeBindingError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Describe the code binding URI.
 */
export declare const describeCodeBinding: API.OperationMethod<DescribeCodeBindingRequest, DescribeCodeBindingResponse, DescribeCodeBindingError, Credentials | HttpClient.HttpClient>;
export type DescribeDiscovererError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Describes the discoverer.
 */
export declare const describeDiscoverer: API.OperationMethod<DescribeDiscovererRequest, DescribeDiscovererResponse, DescribeDiscovererError, Credentials | HttpClient.HttpClient>;
export type DescribeRegistryError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Describes the registry.
 */
export declare const describeRegistry: API.OperationMethod<DescribeRegistryRequest, DescribeRegistryResponse, DescribeRegistryError, Credentials | HttpClient.HttpClient>;
export type DescribeSchemaError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Retrieve the schema definition.
 */
export declare const describeSchema: API.OperationMethod<DescribeSchemaRequest, DescribeSchemaResponse, DescribeSchemaError, Credentials | HttpClient.HttpClient>;
export type ExportSchemaError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 *
 */
export declare const exportSchema: API.OperationMethod<ExportSchemaRequest, ExportSchemaResponse, ExportSchemaError, Credentials | HttpClient.HttpClient>;
export type GetCodeBindingSourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Get the code binding source URI.
 */
export declare const getCodeBindingSource: API.OperationMethod<GetCodeBindingSourceRequest, GetCodeBindingSourceResponse, GetCodeBindingSourceError, Credentials | HttpClient.HttpClient>;
export type GetDiscoveredSchemaError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Get the discovered schema that was generated based on sampled events.
 */
export declare const getDiscoveredSchema: API.OperationMethod<GetDiscoveredSchemaRequest, GetDiscoveredSchemaResponse, GetDiscoveredSchemaError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Retrieves the resource-based policy attached to a given registry.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type ListDiscoverersError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * List the discoverers.
 */
export declare const listDiscoverers: API.PaginatedOperationMethod<ListDiscoverersRequest, ListDiscoverersResponse, ListDiscoverersError, Credentials | HttpClient.HttpClient, DiscovererSummary>;
export type ListRegistriesError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * List the registries.
 */
export declare const listRegistries: API.PaginatedOperationMethod<ListRegistriesRequest, ListRegistriesResponse, ListRegistriesError, Credentials | HttpClient.HttpClient, RegistrySummary>;
export type ListSchemasError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * List the schemas.
 */
export declare const listSchemas: API.PaginatedOperationMethod<ListSchemasRequest, ListSchemasResponse, ListSchemasError, Credentials | HttpClient.HttpClient, SchemaSummary>;
export type ListSchemaVersionsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Provides a list of the schema versions and related information.
 */
export declare const listSchemaVersions: API.PaginatedOperationMethod<ListSchemaVersionsRequest, ListSchemaVersionsResponse, ListSchemaVersionsError, Credentials | HttpClient.HttpClient, SchemaVersionSummary>;
export type ListTagsForResourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Get tags for resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutCodeBindingError = BadRequestException | ForbiddenException | GoneException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnauthorizedException | ConflictException | CommonErrors;
/**
 * Put code binding URI
 */
export declare const putCodeBinding: API.OperationMethod<PutCodeBindingRequest, PutCodeBindingResponse, PutCodeBindingError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | PreconditionFailedException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * The name of the policy.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type SearchSchemasError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Search the schemas
 */
export declare const searchSchemas: API.PaginatedOperationMethod<SearchSchemasRequest, SearchSchemasResponse, SearchSchemasError, Credentials | HttpClient.HttpClient, SearchSchemaSummary>;
export type StartDiscovererError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Starts the discoverer
 */
export declare const startDiscoverer: API.OperationMethod<StartDiscovererRequest, StartDiscovererResponse, StartDiscovererError, Credentials | HttpClient.HttpClient>;
export type StopDiscovererError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Stops the discoverer
 */
export declare const stopDiscoverer: API.OperationMethod<StopDiscovererRequest, StopDiscovererResponse, StopDiscovererError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Add tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDiscovererError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates the discoverer
 */
export declare const updateDiscoverer: API.OperationMethod<UpdateDiscovererRequest, UpdateDiscovererResponse, UpdateDiscovererError, Credentials | HttpClient.HttpClient>;
export type UpdateRegistryError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates a registry.
 */
export declare const updateRegistry: API.OperationMethod<UpdateRegistryRequest, UpdateRegistryResponse, UpdateRegistryError, Credentials | HttpClient.HttpClient>;
export type UpdateSchemaError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Updates the schema definition
 *
 * Inactive schemas will be deleted after two years.
 */
export declare const updateSchema: API.OperationMethod<UpdateSchemaRequest, UpdateSchemaResponse, UpdateSchemaError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=schemas.d.ts.map