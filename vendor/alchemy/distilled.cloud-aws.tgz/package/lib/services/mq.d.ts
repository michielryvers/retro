import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly ErrorAttribute: any;
    readonly message: any;
    readonly ResourceShareErrors: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly ErrorAttribute: any;
    readonly message: any;
    readonly ResourceShareErrors: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly ErrorAttribute: any;
    readonly message: any;
    readonly ResourceShareErrors: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly ErrorAttribute: any;
    readonly message: any;
    readonly ResourceShareErrors: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly ErrorAttribute: any;
    readonly message: any;
    readonly ResourceShareErrors: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly ErrorAttribute: any;
    readonly message: any;
    readonly ResourceShareErrors: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
export type AuthenticationStrategy = "SIMPLE" | "LDAP" | "CONFIG_MANAGED" | (string & {});
export interface ConfigurationId {
    Id?: string;
    Revision?: number;
}
export type DeploymentMode = "SINGLE_INSTANCE" | "ACTIVE_STANDBY_MULTI_AZ" | "CLUSTER_MULTI_AZ" | (string & {});
export interface EncryptionOptions {
    KmsKeyId?: string;
    UseAwsOwnedKey?: boolean;
}
export type EngineType = "ACTIVEMQ" | "RABBITMQ" | (string & {});
export type __listOf__string = string[];
export interface LdapServerMetadataInput {
    Hosts?: string[];
    RoleBase?: string;
    RoleName?: string;
    RoleSearchMatching?: string;
    RoleSearchSubtree?: boolean;
    ServiceAccountPassword?: string | redacted.Redacted<string>;
    ServiceAccountUsername?: string;
    UserBase?: string;
    UserRoleName?: string;
    UserSearchMatching?: string;
    UserSearchSubtree?: boolean;
}
export interface Logs {
    Audit?: boolean;
    General?: boolean;
}
export type DayOfWeek = "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | "SUNDAY" | (string & {});
export interface WeeklyStartTime {
    DayOfWeek?: DayOfWeek;
    TimeOfDay?: string;
    TimeZone?: string;
}
export type BrokerStorageType = "EBS" | "EFS" | (string & {});
export type __mapOf__string = {
    [key: string]: string | undefined;
};
export interface User {
    ConsoleAccess?: boolean;
    Groups?: string[];
    Password?: string | redacted.Redacted<string>;
    Username?: string;
    ReplicationUser?: boolean;
}
export type __listOfUser = User[];
export type DataReplicationMode = "NONE" | "CRDR" | (string & {});
export interface CreateBrokerRequest {
    AuthenticationStrategy?: AuthenticationStrategy;
    AutoMinorVersionUpgrade?: boolean;
    BrokerName?: string;
    Configuration?: ConfigurationId;
    CreatorRequestId?: string;
    DeploymentMode?: DeploymentMode;
    EncryptionOptions?: EncryptionOptions;
    EngineType?: EngineType;
    EngineVersion?: string;
    HostInstanceType?: string;
    LdapServerMetadata?: LdapServerMetadataInput;
    Logs?: Logs;
    MaintenanceWindowStartTime?: WeeklyStartTime;
    PubliclyAccessible?: boolean;
    SecurityGroups?: string[];
    StorageSize?: number;
    StorageType?: BrokerStorageType;
    SubnetIds?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
    Users?: User[];
    DataReplicationMode?: DataReplicationMode;
    DataReplicationPrimaryBrokerArn?: string;
}
export interface CreateBrokerResponse {
    BrokerArn?: string;
    BrokerId?: string;
}
export interface CreateConfigurationRequest {
    AuthenticationStrategy?: AuthenticationStrategy;
    EngineType?: EngineType;
    EngineVersion?: string;
    Name?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __timestampIso8601 = Date;
export interface ConfigurationRevision {
    Created?: Date;
    Description?: string;
    Revision?: number;
}
export interface CreateConfigurationResponse {
    Arn?: string;
    AuthenticationStrategy?: AuthenticationStrategy;
    Created?: Date;
    Id?: string;
    LatestRevision?: ConfigurationRevision & {
        Created: __timestampIso8601;
        Revision: number;
    };
    Name?: string;
}
export interface CreateTagsRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface CreateTagsResponse {
}
export interface CreateUserRequest {
    BrokerId: string;
    ConsoleAccess?: boolean;
    Groups?: string[];
    Password?: string | redacted.Redacted<string>;
    Username: string;
    ReplicationUser?: boolean;
}
export interface CreateUserResponse {
}
export interface DeleteBrokerRequest {
    BrokerId: string;
}
export interface DeleteBrokerResponse {
    BrokerId?: string;
}
export interface DeleteConfigurationRequest {
    ConfigurationId: string;
}
export interface DeleteConfigurationResponse {
    ConfigurationId?: string;
}
export interface DeleteTagsRequest {
    ResourceArn: string;
    TagKeys?: string[];
}
export interface DeleteTagsResponse {
}
export interface DeleteUserRequest {
    BrokerId: string;
    Username: string;
}
export interface DeleteUserResponse {
}
export interface DescribeBrokerRequest {
    BrokerId: string;
}
export interface ActionRequired {
    ActionRequiredCode?: string;
    ActionRequiredInfo?: string;
}
export type __listOfActionRequired = ActionRequired[];
export interface BrokerInstance {
    ConsoleURL?: string;
    Endpoints?: string[];
    IpAddress?: string;
}
export type __listOfBrokerInstance = BrokerInstance[];
export type BrokerState = "CREATION_IN_PROGRESS" | "CREATION_FAILED" | "DELETION_IN_PROGRESS" | "RUNNING" | "REBOOT_IN_PROGRESS" | "CRITICAL_ACTION_REQUIRED" | "REPLICA" | (string & {});
export type __listOfConfigurationId = ConfigurationId[];
export interface Configurations {
    Current?: ConfigurationId;
    History?: ConfigurationId[];
    Pending?: ConfigurationId;
}
export interface LdapServerMetadataOutput {
    Hosts?: string[];
    RoleBase?: string;
    RoleName?: string;
    RoleSearchMatching?: string;
    RoleSearchSubtree?: boolean;
    ServiceAccountUsername?: string;
    UserBase?: string;
    UserRoleName?: string;
    UserSearchMatching?: string;
    UserSearchSubtree?: boolean;
}
export interface PendingLogs {
    Audit?: boolean;
    General?: boolean;
}
export interface LogsSummary {
    Audit?: boolean;
    AuditLogGroup?: string;
    General?: boolean;
    GeneralLogGroup?: string;
    Pending?: PendingLogs;
}
export type ChangeType = "CREATE" | "UPDATE" | "DELETE" | (string & {});
export interface UserSummary {
    PendingChange?: ChangeType;
    Username?: string;
}
export type __listOfUserSummary = UserSummary[];
export interface DataReplicationCounterpart {
    BrokerId?: string;
    Region?: string;
}
export interface DataReplicationMetadataOutput {
    DataReplicationCounterpart?: DataReplicationCounterpart;
    DataReplicationRole?: string;
}
export interface DescribeBrokerResponse {
    ActionsRequired?: ActionRequired[];
    AuthenticationStrategy?: AuthenticationStrategy;
    AutoMinorVersionUpgrade?: boolean;
    BrokerArn?: string;
    BrokerId?: string;
    BrokerInstances?: BrokerInstance[];
    BrokerName?: string;
    BrokerState?: BrokerState;
    Configurations?: Configurations & {
        Current: ConfigurationId & {
            Id: string;
        };
        History: (ConfigurationId & {
            Id: string;
        })[];
        Pending: ConfigurationId & {
            Id: string;
        };
    };
    Created?: Date;
    DeploymentMode?: DeploymentMode;
    EncryptionOptions?: EncryptionOptions & {
        UseAwsOwnedKey: boolean;
    };
    EngineType?: EngineType;
    EngineVersion?: string;
    HostInstanceType?: string;
    LdapServerMetadata?: LdapServerMetadataOutput & {
        Hosts: __listOf__string;
        RoleBase: string;
        RoleSearchMatching: string;
        ServiceAccountUsername: string;
        UserBase: string;
        UserSearchMatching: string;
    };
    Logs?: LogsSummary & {
        General: boolean;
        GeneralLogGroup: string;
    };
    MaintenanceWindowStartTime?: WeeklyStartTime & {
        DayOfWeek: DayOfWeek;
        TimeOfDay: string;
    };
    PendingAuthenticationStrategy?: AuthenticationStrategy;
    PendingEngineVersion?: string;
    PendingHostInstanceType?: string;
    PendingLdapServerMetadata?: LdapServerMetadataOutput & {
        Hosts: __listOf__string;
        RoleBase: string;
        RoleSearchMatching: string;
        ServiceAccountUsername: string;
        UserBase: string;
        UserSearchMatching: string;
    };
    PendingSecurityGroups?: string[];
    PendingStorageSize?: number;
    PubliclyAccessible?: boolean;
    SecurityGroups?: string[];
    StorageSize?: number;
    StorageType?: BrokerStorageType;
    SubnetIds?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
    Users?: (UserSummary & {
        Username: string;
    })[];
    DataReplicationMetadata?: DataReplicationMetadataOutput & {
        DataReplicationRole: string;
        DataReplicationCounterpart: DataReplicationCounterpart & {
            BrokerId: string;
            Region: string;
        };
    };
    DataReplicationMode?: DataReplicationMode;
    PendingDataReplicationMetadata?: DataReplicationMetadataOutput & {
        DataReplicationRole: string;
        DataReplicationCounterpart: DataReplicationCounterpart & {
            BrokerId: string;
            Region: string;
        };
    };
    PendingDataReplicationMode?: DataReplicationMode;
}
export type MaxResults = number;
export interface DescribeBrokerEngineTypesRequest {
    EngineType?: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface EngineVersion {
    Name?: string;
}
export type __listOfEngineVersion = EngineVersion[];
export interface BrokerEngineType {
    EngineType?: EngineType;
    EngineVersions?: EngineVersion[];
}
export type __listOfBrokerEngineType = BrokerEngineType[];
export type __integerMin5Max100 = number;
export interface DescribeBrokerEngineTypesResponse {
    BrokerEngineTypes?: BrokerEngineType[];
    MaxResults?: number;
    NextToken?: string;
}
export interface DescribeBrokerInstanceOptionsRequest {
    EngineType?: string;
    HostInstanceType?: string;
    MaxResults?: number;
    NextToken?: string;
    StorageType?: string;
}
export interface AvailabilityZone {
    Name?: string;
}
export type __listOfAvailabilityZone = AvailabilityZone[];
export type __listOfDeploymentMode = DeploymentMode[];
export interface BrokerInstanceOption {
    AvailabilityZones?: AvailabilityZone[];
    EngineType?: EngineType;
    HostInstanceType?: string;
    StorageType?: BrokerStorageType;
    SupportedDeploymentModes?: DeploymentMode[];
    SupportedEngineVersions?: string[];
}
export type __listOfBrokerInstanceOption = BrokerInstanceOption[];
export interface DescribeBrokerInstanceOptionsResponse {
    BrokerInstanceOptions?: BrokerInstanceOption[];
    MaxResults?: number;
    NextToken?: string;
}
export interface DescribeConfigurationRequest {
    ConfigurationId: string;
}
export interface DescribeConfigurationResponse {
    Arn?: string;
    AuthenticationStrategy?: AuthenticationStrategy;
    Created?: Date;
    Description?: string;
    EngineType?: EngineType;
    EngineVersion?: string;
    Id?: string;
    LatestRevision?: ConfigurationRevision & {
        Created: __timestampIso8601;
        Revision: number;
    };
    Name?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface DescribeConfigurationRevisionRequest {
    ConfigurationId: string;
    ConfigurationRevision: string;
}
export interface DescribeConfigurationRevisionResponse {
    ConfigurationId?: string;
    Created?: Date;
    Data?: string;
    Description?: string;
}
export interface DescribeSharedResourcesRequest {
    BrokerId: string;
    MaxResults?: number;
    NextToken?: string;
}
export type SharedResourceErrorCode = "QUOTA_EXCEEDED" | "SHARE_NOT_FOUND" | "INVITE_FAILED" | "SETUP_INCOMPLETE" | "INTERNAL_ERROR" | "AZ_MISMATCH" | "RESOURCE_CONFIGURATION_NOT_FOUND" | (string & {});
export interface SharedResourceError {
    Code?: SharedResourceErrorCode;
    Message?: string;
}
export type SharedResourceStatus = "AVAILABLE" | "SETUP_IN_PROGRESS" | "DELETION_IN_PROGRESS" | "PENDING_CREATE" | "PENDING_DELETE" | "ERROR" | (string & {});
export type SharedResourceType = "RESOURCE_SHARE" | "RESOURCE" | (string & {});
export interface SharedResource {
    DnsNames?: string[];
    Error?: SharedResourceError;
    ResourceArn?: string;
    ResourceShareArns?: string[];
    Status?: SharedResourceStatus;
    Type?: SharedResourceType;
}
export type __listOfSharedResource = SharedResource[];
export interface DescribeSharedResourcesResponse {
    NextToken?: string;
    SharedResources?: (SharedResource & {
        ResourceArn: string;
        Status: SharedResourceStatus;
        Type: SharedResourceType;
        Error: SharedResourceError & {
            Code: SharedResourceErrorCode;
            Message: string;
        };
    })[];
}
export interface DescribeUserRequest {
    BrokerId: string;
    Username: string;
}
export interface UserPendingChanges {
    ConsoleAccess?: boolean;
    Groups?: string[];
    PendingChange?: ChangeType;
}
export interface DescribeUserResponse {
    BrokerId?: string;
    ConsoleAccess?: boolean;
    Groups?: string[];
    Pending?: UserPendingChanges & {
        PendingChange: ChangeType;
    };
    Username?: string;
    ReplicationUser?: boolean;
}
export interface ListBrokersRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface BrokerSummary {
    BrokerArn?: string;
    BrokerId?: string;
    BrokerName?: string;
    BrokerState?: BrokerState;
    Created?: Date;
    DeploymentMode?: DeploymentMode;
    EngineType?: EngineType;
    HostInstanceType?: string;
}
export type __listOfBrokerSummary = BrokerSummary[];
export interface ListBrokersResponse {
    BrokerSummaries?: (BrokerSummary & {
        DeploymentMode: DeploymentMode;
        EngineType: EngineType;
    })[];
    NextToken?: string;
}
export interface ListConfigurationRevisionsRequest {
    ConfigurationId: string;
    MaxResults?: number;
    NextToken?: string;
}
export type __listOfConfigurationRevision = ConfigurationRevision[];
export interface ListConfigurationRevisionsResponse {
    ConfigurationId?: string;
    MaxResults?: number;
    NextToken?: string;
    Revisions?: (ConfigurationRevision & {
        Created: __timestampIso8601;
        Revision: number;
    })[];
}
export interface ListConfigurationsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface Configuration {
    Arn?: string;
    AuthenticationStrategy?: AuthenticationStrategy;
    Created?: Date;
    Description?: string;
    EngineType?: EngineType;
    EngineVersion?: string;
    Id?: string;
    LatestRevision?: ConfigurationRevision;
    Name?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export type __listOfConfiguration = Configuration[];
export interface ListConfigurationsResponse {
    Configurations?: (Configuration & {
        Arn: string;
        AuthenticationStrategy: AuthenticationStrategy;
        Created: __timestampIso8601;
        Description: string;
        EngineType: EngineType;
        EngineVersion: string;
        Id: string;
        LatestRevision: ConfigurationRevision & {
            Created: __timestampIso8601;
            Revision: number;
        };
        Name: string;
    })[];
    MaxResults?: number;
    NextToken?: string;
}
export interface ListTagsRequest {
    ResourceArn: string;
}
export interface ListTagsResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListUsersRequest {
    BrokerId: string;
    MaxResults?: number;
    NextToken?: string;
}
export interface ListUsersResponse {
    BrokerId?: string;
    MaxResults?: number;
    NextToken?: string;
    Users?: (UserSummary & {
        Username: string;
    })[];
}
export type PromoteMode = "SWITCHOVER" | "FAILOVER" | (string & {});
export interface PromoteRequest {
    BrokerId: string;
    Mode?: PromoteMode;
}
export interface PromoteResponse {
    BrokerId?: string;
}
export interface RebootBrokerRequest {
    BrokerId: string;
}
export interface RebootBrokerResponse {
}
export interface UpdateBrokerRequest {
    AuthenticationStrategy?: AuthenticationStrategy;
    AutoMinorVersionUpgrade?: boolean;
    BrokerId: string;
    Configuration?: ConfigurationId;
    EngineVersion?: string;
    HostInstanceType?: string;
    LdapServerMetadata?: LdapServerMetadataInput;
    Logs?: Logs;
    MaintenanceWindowStartTime?: WeeklyStartTime;
    ResourceShareArns?: string[];
    SecurityGroups?: string[];
    StorageSize?: number;
    DataReplicationMode?: DataReplicationMode;
}
export interface UpdateBrokerResponse {
    AuthenticationStrategy?: AuthenticationStrategy;
    AutoMinorVersionUpgrade?: boolean;
    BrokerId?: string;
    Configuration?: ConfigurationId & {
        Id: string;
    };
    EngineVersion?: string;
    HostInstanceType?: string;
    LdapServerMetadata?: LdapServerMetadataOutput & {
        Hosts: __listOf__string;
        RoleBase: string;
        RoleSearchMatching: string;
        ServiceAccountUsername: string;
        UserBase: string;
        UserSearchMatching: string;
    };
    Logs?: Logs;
    MaintenanceWindowStartTime?: WeeklyStartTime & {
        DayOfWeek: DayOfWeek;
        TimeOfDay: string;
    };
    ResourceShareArns?: string[];
    SecurityGroups?: string[];
    DataReplicationMetadata?: DataReplicationMetadataOutput & {
        DataReplicationRole: string;
        DataReplicationCounterpart: DataReplicationCounterpart & {
            BrokerId: string;
            Region: string;
        };
    };
    DataReplicationMode?: DataReplicationMode;
    PendingDataReplicationMetadata?: DataReplicationMetadataOutput & {
        DataReplicationRole: string;
        DataReplicationCounterpart: DataReplicationCounterpart & {
            BrokerId: string;
            Region: string;
        };
    };
    PendingDataReplicationMode?: DataReplicationMode;
    StorageSize?: number;
}
export interface UpdateConfigurationRequest {
    ConfigurationId: string;
    Data?: string;
    Description?: string;
}
export type SanitizationWarningReason = "DISALLOWED_ELEMENT_REMOVED" | "DISALLOWED_ATTRIBUTE_REMOVED" | "INVALID_ATTRIBUTE_VALUE_REMOVED" | (string & {});
export interface SanitizationWarning {
    AttributeName?: string;
    ElementName?: string;
    Reason?: SanitizationWarningReason;
}
export type __listOfSanitizationWarning = SanitizationWarning[];
export interface UpdateConfigurationResponse {
    Arn?: string;
    Created?: Date;
    Id?: string;
    LatestRevision?: ConfigurationRevision & {
        Created: __timestampIso8601;
        Revision: number;
    };
    Name?: string;
    Warnings?: (SanitizationWarning & {
        Reason: SanitizationWarningReason;
    })[];
}
export interface UpdateUserRequest {
    BrokerId: string;
    ConsoleAccess?: boolean;
    Groups?: string[];
    Password?: string | redacted.Redacted<string>;
    Username: string;
    ReplicationUser?: boolean;
}
export interface UpdateUserResponse {
}
export interface ResourceShareError {
    ErrorCode?: string;
    ResourceShareArn?: string;
    Status?: string;
}
export type __listOfResourceShareError = ResourceShareError[];
export type CreateBrokerError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | UnauthorizedException | CommonErrors;
/**
 * Creates a broker. Note: This API is asynchronous.
 *
 * To create a broker, you must either use the AmazonMQFullAccess IAM policy or include the following EC2 permissions in your IAM policy.
 *
 * - ec2:CreateNetworkInterface
 *
 * This permission is required to allow Amazon MQ to create an elastic network interface (ENI) on behalf of your account.
 *
 * - ec2:CreateNetworkInterfacePermission
 *
 * This permission is required to attach the ENI to the broker instance.
 *
 * - ec2:DeleteNetworkInterface
 *
 * - ec2:DeleteNetworkInterfacePermission
 *
 * - ec2:DetachNetworkInterface
 *
 * - ec2:DescribeInternetGateways
 *
 * - ec2:DescribeNetworkInterfaces
 *
 * - ec2:DescribeNetworkInterfacePermissions
 *
 * - ec2:DescribeRouteTables
 *
 * - ec2:DescribeSecurityGroups
 *
 * - ec2:DescribeSubnets
 *
 * - ec2:DescribeVpcs
 *
 * For more information, see Create an IAM User and Get Your Amazon Web Services Credentials and Never Modify or Delete the Amazon MQ Elastic Network Interface in the *Amazon MQ Developer Guide*.
 */
export declare const createBroker: API.OperationMethod<CreateBrokerRequest, CreateBrokerResponse, CreateBrokerError, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | CommonErrors;
/**
 * Creates a new configuration for the specified configuration name. Amazon MQ uses the default configuration (the engine type and version).
 */
export declare const createConfiguration: API.OperationMethod<CreateConfigurationRequest, CreateConfigurationResponse, CreateConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateTagsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Add a tag to a resource.
 */
export declare const createTags: API.OperationMethod<CreateTagsRequest, CreateTagsResponse, CreateTagsError, Credentials | HttpClient.HttpClient>;
export type CreateUserError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Creates an ActiveMQ user.
 *
 * Do not add personally identifiable information (PII) or other confidential or sensitive information in broker usernames. Broker usernames are accessible to other Amazon Web Services services, including CloudWatch Logs. Broker usernames are not intended to be used for private or sensitive data.
 */
export declare const createUser: API.OperationMethod<CreateUserRequest, CreateUserResponse, CreateUserError, Credentials | HttpClient.HttpClient>;
export type DeleteBrokerError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Deletes a broker. Note: This API is asynchronous.
 */
export declare const deleteBroker: API.OperationMethod<DeleteBrokerRequest, DeleteBrokerResponse, DeleteBrokerError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Deletes the specified configuration.
 */
export declare const deleteConfiguration: API.OperationMethod<DeleteConfigurationRequest, DeleteConfigurationResponse, DeleteConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteTagsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Removes a tag from a resource.
 */
export declare const deleteTags: API.OperationMethod<DeleteTagsRequest, DeleteTagsResponse, DeleteTagsError, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Deletes an ActiveMQ user.
 */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest, DeleteUserResponse, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DescribeBrokerError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Returns information about the specified broker.
 */
export declare const describeBroker: API.OperationMethod<DescribeBrokerRequest, DescribeBrokerResponse, DescribeBrokerError, Credentials | HttpClient.HttpClient>;
export type DescribeBrokerEngineTypesError = BadRequestException | ForbiddenException | InternalServerErrorException | CommonErrors;
/**
 * Describe available engine types and versions.
 */
export declare const describeBrokerEngineTypes: API.OperationMethod<DescribeBrokerEngineTypesRequest, DescribeBrokerEngineTypesResponse, DescribeBrokerEngineTypesError, Credentials | HttpClient.HttpClient>;
export type DescribeBrokerInstanceOptionsError = BadRequestException | ForbiddenException | InternalServerErrorException | CommonErrors;
/**
 * Describe available broker instance options.
 */
export declare const describeBrokerInstanceOptions: API.OperationMethod<DescribeBrokerInstanceOptionsRequest, DescribeBrokerInstanceOptionsResponse, DescribeBrokerInstanceOptionsError, Credentials | HttpClient.HttpClient>;
export type DescribeConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Returns information about the specified configuration.
 */
export declare const describeConfiguration: API.OperationMethod<DescribeConfigurationRequest, DescribeConfigurationResponse, DescribeConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeConfigurationRevisionError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Returns the specified configuration revision for the specified configuration.
 */
export declare const describeConfigurationRevision: API.OperationMethod<DescribeConfigurationRevisionRequest, DescribeConfigurationRevisionResponse, DescribeConfigurationRevisionError, Credentials | HttpClient.HttpClient>;
export type DescribeSharedResourcesError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Returns the resources shared to a broker.
 */
export declare const describeSharedResources: API.PaginatedOperationMethod<DescribeSharedResourcesRequest, DescribeSharedResourcesResponse, DescribeSharedResourcesError, Credentials | HttpClient.HttpClient, SharedResource>;
export type DescribeUserError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Returns information about an ActiveMQ user.
 */
export declare const describeUser: API.OperationMethod<DescribeUserRequest, DescribeUserResponse, DescribeUserError, Credentials | HttpClient.HttpClient>;
export type ListBrokersError = BadRequestException | ForbiddenException | InternalServerErrorException | CommonErrors;
/**
 * Returns a list of all brokers.
 */
export declare const listBrokers: API.PaginatedOperationMethod<ListBrokersRequest, ListBrokersResponse, ListBrokersError, Credentials | HttpClient.HttpClient, BrokerSummary>;
export type ListConfigurationRevisionsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Returns a list of all revisions for the specified configuration.
 */
export declare const listConfigurationRevisions: API.OperationMethod<ListConfigurationRevisionsRequest, ListConfigurationRevisionsResponse, ListConfigurationRevisionsError, Credentials | HttpClient.HttpClient>;
export type ListConfigurationsError = BadRequestException | ForbiddenException | InternalServerErrorException | CommonErrors;
/**
 * Returns a list of all configurations.
 */
export declare const listConfigurations: API.OperationMethod<ListConfigurationsRequest, ListConfigurationsResponse, ListConfigurationsError, Credentials | HttpClient.HttpClient>;
export type ListTagsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Lists tags for a resource.
 */
export declare const listTags: API.OperationMethod<ListTagsRequest, ListTagsResponse, ListTagsError, Credentials | HttpClient.HttpClient>;
export type ListUsersError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Returns a list of all ActiveMQ users.
 */
export declare const listUsers: API.OperationMethod<ListUsersRequest, ListUsersResponse, ListUsersError, Credentials | HttpClient.HttpClient>;
export type PromoteError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Promotes a data replication replica broker to the primary broker role.
 */
export declare const promote: API.OperationMethod<PromoteRequest, PromoteResponse, PromoteError, Credentials | HttpClient.HttpClient>;
export type RebootBrokerError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Reboots a broker. Note: This API is asynchronous.
 */
export declare const rebootBroker: API.OperationMethod<RebootBrokerRequest, RebootBrokerResponse, RebootBrokerError, Credentials | HttpClient.HttpClient>;
export type UpdateBrokerError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Adds a pending configuration change to a broker.
 */
export declare const updateBroker: API.OperationMethod<UpdateBrokerRequest, UpdateBrokerResponse, UpdateBrokerError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Updates the specified configuration.
 */
export declare const updateConfiguration: API.OperationMethod<UpdateConfigurationRequest, UpdateConfigurationResponse, UpdateConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateUserError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Updates the information for an ActiveMQ user.
 */
export declare const updateUser: API.OperationMethod<UpdateUserRequest, UpdateUserResponse, UpdateUserError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=mq.d.ts.map