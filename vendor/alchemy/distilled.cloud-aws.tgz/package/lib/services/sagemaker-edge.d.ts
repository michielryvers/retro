import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InternalServiceException_base: S.TaggedErrorClass<"InternalServiceException", {
    readonly message: any;
}>;
export declare class InternalServiceException extends /*@__PURE__*/ InternalServiceException_base {
}
export type DeviceName = string;
export type DeviceFleetName = string;
export interface GetDeploymentsRequest {
    DeviceName?: string;
    DeviceFleetName?: string;
}
export type EntityName = string;
export type DeploymentType = "Model" | (string & {});
export type FailureHandlingPolicy = "ROLLBACK_ON_FAILURE" | "DO_NOTHING" | (string & {});
export type S3Uri = string;
export type ChecksumType = "SHA1" | (string & {});
export type ChecksumString = string;
export interface Checksum {
    Type?: ChecksumType;
    Sum?: string;
}
export type ModelState = "DEPLOY" | "UNDEPLOY" | (string & {});
export interface Definition {
    ModelHandle?: string;
    S3Url?: string;
    Checksum?: Checksum;
    State?: ModelState;
}
export type Definitions = Definition[];
export interface EdgeDeployment {
    DeploymentName?: string;
    Type?: DeploymentType;
    FailureHandlingPolicy?: FailureHandlingPolicy;
    Definitions?: Definition[];
}
export type EdgeDeployments = EdgeDeployment[];
export interface GetDeploymentsResult {
    Deployments?: EdgeDeployment[];
}
export interface GetDeviceRegistrationRequest {
    DeviceName?: string;
    DeviceFleetName?: string;
}
export type DeviceRegistration = string;
export type CacheTTLSeconds = string;
export interface GetDeviceRegistrationResult {
    DeviceRegistration?: string;
    CacheTTL?: string;
}
export type Dimension = string;
export type Metric = string;
export type Value = number;
export interface EdgeMetric {
    Dimension?: string;
    MetricName?: string;
    Value?: number;
    Timestamp?: Date;
}
export type EdgeMetrics = EdgeMetric[];
export type ModelName = string;
export type Version = string;
export interface Model {
    ModelName?: string;
    ModelVersion?: string;
    LatestSampleTime?: Date;
    LatestInference?: Date;
    ModelMetrics?: EdgeMetric[];
}
export type Models = Model[];
export type DeploymentStatus = "SUCCESS" | "FAIL" | (string & {});
export interface DeploymentModel {
    ModelHandle?: string;
    ModelName?: string;
    ModelVersion?: string;
    DesiredState?: ModelState;
    State?: ModelState;
    Status?: DeploymentStatus;
    StatusReason?: string;
    RollbackFailureReason?: string;
}
export type DeploymentModels = DeploymentModel[];
export interface DeploymentResult {
    DeploymentName?: string;
    DeploymentStatus?: string;
    DeploymentStatusMessage?: string;
    DeploymentStartTime?: Date;
    DeploymentEndTime?: Date;
    DeploymentModels?: DeploymentModel[];
}
export interface SendHeartbeatRequest {
    AgentMetrics?: EdgeMetric[];
    Models?: Model[];
    AgentVersion?: string;
    DeviceName?: string;
    DeviceFleetName?: string;
    DeploymentResult?: DeploymentResult;
}
export interface SendHeartbeatResponse {
}
export type ErrorMessage = string;
export type GetDeploymentsError = InternalServiceException | CommonErrors;
/**
 * Use to get the active deployments from a device.
 */
export declare const getDeployments: API.OperationMethod<GetDeploymentsRequest, GetDeploymentsResult, GetDeploymentsError, Credentials | HttpClient.HttpClient>;
export type GetDeviceRegistrationError = InternalServiceException | CommonErrors;
/**
 * Use to check if a device is registered with SageMaker Edge Manager.
 */
export declare const getDeviceRegistration: API.OperationMethod<GetDeviceRegistrationRequest, GetDeviceRegistrationResult, GetDeviceRegistrationError, Credentials | HttpClient.HttpClient>;
export type SendHeartbeatError = InternalServiceException | CommonErrors;
/**
 * Use to get the current status of devices registered on SageMaker Edge Manager.
 */
export declare const sendHeartbeat: API.OperationMethod<SendHeartbeatRequest, SendHeartbeatResponse, SendHeartbeatError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=sagemaker-edge.d.ts.map