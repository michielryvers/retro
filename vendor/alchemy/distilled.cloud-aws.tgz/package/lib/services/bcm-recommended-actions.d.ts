import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type FilterName = "FEATURE" | "SEVERITY" | "TYPE" | (string & {});
export type MatchOption = "EQUALS" | "NOT_EQUALS" | (string & {});
export type FilterValue = string;
export type FilterValues = string[];
export interface ActionFilter {
    key: FilterName;
    matchOption: MatchOption;
    values: string[];
}
export type ActionFilterList = ActionFilter[];
export interface RequestFilter {
    actions?: ActionFilter[];
}
export type MaxResults = number;
export type NextToken = string;
export interface ListRecommendedActionsRequest {
    filter?: RequestFilter;
    maxResults?: number;
    nextToken?: string;
}
export type ActionType = "ADD_ALTERNATE_BILLING_CONTACT" | "CREATE_ANOMALY_MONITOR" | "CREATE_BUDGET" | "ENABLE_COST_OPTIMIZATION_HUB" | "MIGRATE_TO_GRANULAR_PERMISSIONS" | "PAYMENTS_DUE" | "PAYMENTS_PAST_DUE" | "REVIEW_ANOMALIES" | "REVIEW_BUDGET_ALERTS" | "REVIEW_BUDGETS_EXCEEDED" | "REVIEW_EXPIRING_RI" | "REVIEW_EXPIRING_SP" | "REVIEW_FREETIER_USAGE_ALERTS" | "REVIEW_FREETIER_CREDITS_REMAINING" | "REVIEW_FREETIER_DAYS_REMAINING" | "REVIEW_SAVINGS_OPPORTUNITY_RECOMMENDATIONS" | "UPDATE_EXPIRED_PAYMENT_METHOD" | "UPDATE_INVALID_PAYMENT_METHOD" | "UPDATE_TAX_EXEMPTION_CERTIFICATE" | "UPDATE_TAX_REGISTRATION_NUMBER" | (string & {});
export type AccountId = string;
export type Severity = "INFO" | "WARNING" | "CRITICAL" | (string & {});
export type Feature = "ACCOUNT" | "BUDGETS" | "COST_ANOMALY_DETECTION" | "COST_OPTIMIZATION_HUB" | "FREE_TIER" | "IAM" | "PAYMENTS" | "RESERVATIONS" | "SAVINGS_PLANS" | "TAX_SETTINGS" | (string & {});
export type Context = {
    [key: string]: string | undefined;
};
export type NextStep = string;
export type NextSteps = string[];
export interface RecommendedAction {
    id?: string;
    type?: ActionType;
    accountId?: string;
    severity?: Severity;
    feature?: Feature;
    context?: {
        [key: string]: string | undefined;
    };
    nextSteps?: string[];
    lastUpdatedTimeStamp?: string;
}
export type RecommendedActions = RecommendedAction[];
export interface ListRecommendedActionsResponse {
    recommendedActions: RecommendedAction[];
    nextToken?: string;
}
export type ValidationExceptionReason = "unknownOperation" | "cannotParse" | "fieldValidationFailed" | "other" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type ListRecommendedActionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of recommended actions that match the filter criteria.
 */
export declare const listRecommendedActions: API.PaginatedOperationMethod<ListRecommendedActionsRequest, ListRecommendedActionsResponse, ListRecommendedActionsError, Credentials | HttpClient.HttpClient, RecommendedAction>;
export {};
//# sourceMappingURL=bcm-recommended-actions.d.ts.map