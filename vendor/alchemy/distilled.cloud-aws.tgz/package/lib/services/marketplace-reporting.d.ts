import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
export type DashboardIdentifier = string;
export type EmbeddingDomain = string;
export type EmbeddingDomains = string[];
export interface GetBuyerDashboardInput {
    dashboardIdentifier: string;
    embeddingDomains: string[];
}
export interface GetBuyerDashboardOutput {
    embedUrl: string;
    dashboardIdentifier: string;
    embeddingDomains: string[];
}
export type GetBuyerDashboardError = AccessDeniedException | BadRequestException | InternalServerException | UnauthorizedException | CommonErrors;
/**
 * Generates an embedding URL for an Amazon QuickSight dashboard for an anonymous user.
 *
 * This API is available only to Amazon Web Services Organization management accounts or
 * delegated administrators registered for the procurement insights
 * (`procurement-insights.marketplace.amazonaws.com`) feature.
 *
 * The following rules apply to a generated URL:
 *
 * - It contains a temporary bearer token, valid for 5 minutes after it is generated. Once redeemed within that period, it cannot be re-used again.
 *
 * - It has a session lifetime of one hour. The 5-minute validity period runs separately from the session lifetime.
 */
export declare const getBuyerDashboard: API.OperationMethod<GetBuyerDashboardInput, GetBuyerDashboardOutput, GetBuyerDashboardError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=marketplace-reporting.d.ts.map