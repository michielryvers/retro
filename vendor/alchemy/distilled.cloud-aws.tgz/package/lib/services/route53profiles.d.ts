import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}>;
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServiceErrorException_base: S.TaggedErrorClass<"InternalServiceErrorException", {
    readonly message: any;
}>;
export declare class InternalServiceErrorException extends /*@__PURE__*/ InternalServiceErrorException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}>;
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
    readonly FieldName: any;
}>;
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
    readonly ResourceType: any;
}>;
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceExistsException_base: S.TaggedErrorClass<"ResourceExistsException", {
    readonly message: any;
    readonly ResourceType: any;
}>;
export declare class ResourceExistsException extends /*@__PURE__*/ ResourceExistsException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceType: any;
}>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}>;
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ResourceId = string;
export type Name = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface AssociateProfileRequest {
    ProfileId: string;
    ResourceId: string;
    Name: string;
    Tags?: Tag[];
}
export type AccountId = string;
export type ProfileStatus = "COMPLETE" | "DELETING" | "UPDATING" | "CREATING" | "DELETED" | "FAILED" | (string & {});
export type Rfc3339Timestamp = Date;
export interface ProfileAssociation {
    Id?: string;
    Name?: string;
    OwnerId?: string;
    ProfileId?: string;
    ResourceId?: string;
    Status?: ProfileStatus;
    StatusMessage?: string;
    CreationTime?: Date;
    ModificationTime?: Date;
}
export interface AssociateProfileResponse {
    ProfileAssociation?: ProfileAssociation;
}
export type Arn = string;
export type ResourceProperties = string;
export interface AssociateResourceToProfileRequest {
    ProfileId: string;
    ResourceArn: string;
    Name: string;
    ResourceProperties?: string;
}
export interface ProfileResourceAssociation {
    Id?: string;
    Name?: string;
    OwnerId?: string;
    ProfileId?: string;
    ResourceArn?: string;
    ResourceType?: string;
    ResourceProperties?: string;
    Status?: ProfileStatus;
    StatusMessage?: string;
    CreationTime?: Date;
    ModificationTime?: Date;
}
export interface AssociateResourceToProfileResponse {
    ProfileResourceAssociation?: ProfileResourceAssociation;
}
export type CreatorRequestId = string;
export interface CreateProfileRequest {
    Name: string;
    ClientToken: string;
    Tags?: Tag[];
}
export type ShareStatus = "NOT_SHARED" | "SHARED_WITH_ME" | "SHARED_BY_ME" | (string & {});
export interface Profile {
    Id?: string;
    Arn?: string;
    Name?: string;
    OwnerId?: string;
    Status?: ProfileStatus;
    StatusMessage?: string;
    ShareStatus?: ShareStatus;
    CreationTime?: Date;
    ModificationTime?: Date;
    ClientToken?: string;
}
export interface CreateProfileResponse {
    Profile?: Profile;
}
export interface DeleteProfileRequest {
    ProfileId: string;
}
export interface DeleteProfileResponse {
    Profile?: Profile;
}
export interface DisassociateProfileRequest {
    ProfileId: string;
    ResourceId: string;
}
export interface DisassociateProfileResponse {
    ProfileAssociation?: ProfileAssociation;
}
export interface DisassociateResourceFromProfileRequest {
    ProfileId: string;
    ResourceArn: string;
}
export interface DisassociateResourceFromProfileResponse {
    ProfileResourceAssociation?: ProfileResourceAssociation;
}
export interface GetProfileRequest {
    ProfileId: string;
}
export interface GetProfileResponse {
    Profile?: Profile;
}
export interface GetProfileAssociationRequest {
    ProfileAssociationId: string;
}
export interface GetProfileAssociationResponse {
    ProfileAssociation?: ProfileAssociation;
}
export interface GetProfileResourceAssociationRequest {
    ProfileResourceAssociationId: string;
}
export interface GetProfileResourceAssociationResponse {
    ProfileResourceAssociation?: ProfileResourceAssociation;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListProfileAssociationsRequest {
    ResourceId?: string;
    ProfileId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type ProfileAssociations = ProfileAssociation[];
export interface ListProfileAssociationsResponse {
    ProfileAssociations?: ProfileAssociation[];
    NextToken?: string;
}
export interface ListProfileResourceAssociationsRequest {
    ProfileId: string;
    ResourceType?: string;
    MaxResults?: number;
    NextToken?: string;
}
export type ProfileResourceAssociations = ProfileResourceAssociation[];
export interface ListProfileResourceAssociationsResponse {
    ProfileResourceAssociations?: ProfileResourceAssociation[];
    NextToken?: string;
}
export interface ListProfilesRequest {
    MaxResults?: number;
    NextToken?: string;
}
export interface ProfileSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    ShareStatus?: ShareStatus;
}
export type ProfileSummaryList = ProfileSummary[];
export interface ListProfilesResponse {
    ProfileSummaries?: ProfileSummary[];
    NextToken?: string;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export type TagMap = {
    [key: string]: string | undefined;
};
export interface ListTagsForResourceResponse {
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateProfileResourceAssociationRequest {
    ProfileResourceAssociationId: string;
    Name?: string;
    ResourceProperties?: string;
}
export interface UpdateProfileResourceAssociationResponse {
    ProfileResourceAssociation?: ProfileResourceAssociation;
}
export type ExceptionMessage = string;
export type AssociateProfileError = AccessDeniedException | ConflictException | InvalidParameterException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a Route 53 Profiles profile with a VPC. A VPC can have only one Profile associated with it, but a Profile can be associated with 1000 of VPCs (and you can request a higher quota).
 * For more information, see https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/DNSLimitations.html#limits-api-entities.
 */
export declare const associateProfile: API.OperationMethod<AssociateProfileRequest, AssociateProfileResponse, AssociateProfileError, Credentials | HttpClient.HttpClient>;
export type AssociateResourceToProfileError = AccessDeniedException | ConflictException | InternalServiceErrorException | InvalidParameterException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a DNS reource configuration to a Route 53 Profile.
 */
export declare const associateResourceToProfile: API.OperationMethod<AssociateResourceToProfileRequest, AssociateResourceToProfileResponse, AssociateResourceToProfileError, Credentials | HttpClient.HttpClient>;
export type CreateProfileError = AccessDeniedException | InvalidParameterException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an empty Route 53 Profile.
 */
export declare const createProfile: API.OperationMethod<CreateProfileRequest, CreateProfileResponse, CreateProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteProfileError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified Route 53 Profile. Before you can delete a profile, you must first disassociate it from all VPCs.
 */
export declare const deleteProfile: API.OperationMethod<DeleteProfileRequest, DeleteProfileResponse, DeleteProfileError, Credentials | HttpClient.HttpClient>;
export type DisassociateProfileError = AccessDeniedException | InvalidParameterException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Dissociates a specified Route 53 Profile from the specified VPC.
 */
export declare const disassociateProfile: API.OperationMethod<DisassociateProfileRequest, DisassociateProfileResponse, DisassociateProfileError, Credentials | HttpClient.HttpClient>;
export type DisassociateResourceFromProfileError = AccessDeniedException | ConflictException | InternalServiceErrorException | InvalidParameterException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Dissoaciated a specified resource, from the Route 53 Profile.
 */
export declare const disassociateResourceFromProfile: API.OperationMethod<DisassociateResourceFromProfileRequest, DisassociateResourceFromProfileResponse, DisassociateResourceFromProfileError, Credentials | HttpClient.HttpClient>;
export type GetProfileError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specified Route 53 Profile, such as whether whether the Profile is shared, and the current status of the Profile.
 */
export declare const getProfile: API.OperationMethod<GetProfileRequest, GetProfileResponse, GetProfileError, Credentials | HttpClient.HttpClient>;
export type GetProfileAssociationError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a Route 53 Profile association for a VPC. A VPC can have only one Profile association, but a Profile can be associated with up to 5000 VPCs.
 */
export declare const getProfileAssociation: API.OperationMethod<GetProfileAssociationRequest, GetProfileAssociationResponse, GetProfileAssociationError, Credentials | HttpClient.HttpClient>;
export type GetProfileResourceAssociationError = AccessDeniedException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specified Route 53 Profile resource association.
 */
export declare const getProfileResourceAssociation: API.OperationMethod<GetProfileResourceAssociationRequest, GetProfileResourceAssociationResponse, GetProfileResourceAssociationError, Credentials | HttpClient.HttpClient>;
export type ListProfileAssociationsError = AccessDeniedException | InvalidNextTokenException | InvalidParameterException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the VPCs that the specified Route 53 Profile is associated with.
 */
export declare const listProfileAssociations: API.PaginatedOperationMethod<ListProfileAssociationsRequest, ListProfileAssociationsResponse, ListProfileAssociationsError, Credentials | HttpClient.HttpClient, ProfileAssociation>;
export type ListProfileResourceAssociationsError = AccessDeniedException | InternalServiceErrorException | InvalidNextTokenException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the resource associations for the specified Route 53 Profile.
 */
export declare const listProfileResourceAssociations: API.PaginatedOperationMethod<ListProfileResourceAssociationsRequest, ListProfileResourceAssociationsResponse, ListProfileResourceAssociationsError, Credentials | HttpClient.HttpClient, ProfileResourceAssociation>;
export type ListProfilesError = AccessDeniedException | InvalidNextTokenException | InvalidParameterException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the Route 53 Profiles associated with your Amazon Web Services account.
 */
export declare const listProfiles: API.PaginatedOperationMethod<ListProfilesRequest, ListProfilesResponse, ListProfilesError, Credentials | HttpClient.HttpClient, ProfileSummary>;
export type ListTagsForResourceError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags that you associated with the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds one or more tags to a specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from a specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateProfileResourceAssociationError = AccessDeniedException | ConflictException | InternalServiceErrorException | InvalidParameterException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified Route 53 Profile resourse association.
 */
export declare const updateProfileResourceAssociation: API.OperationMethod<UpdateProfileResourceAssociationRequest, UpdateProfileResourceAssociationResponse, UpdateProfileResourceAssociationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=route53profiles.d.ts.map