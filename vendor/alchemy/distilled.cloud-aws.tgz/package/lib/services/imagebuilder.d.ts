import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const CallRateLimitExceededException_base: S.TaggedErrorClass<"CallRateLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class CallRateLimitExceededException extends /*@__PURE__*/ CallRateLimitExceededException_base {
}
declare const ClientException_base: S.TaggedErrorClass<"ClientException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClientException extends /*@__PURE__*/ ClientException_base {
}
declare const DryRunOperationException_base: S.TaggedErrorClass<"DryRunOperationException", {
    readonly message: any;
}>;
export declare class DryRunOperationException extends /*@__PURE__*/ DryRunOperationException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const IdempotentParameterMismatchException_base: S.TaggedErrorClass<"IdempotentParameterMismatchException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IdempotentParameterMismatchException extends /*@__PURE__*/ IdempotentParameterMismatchException_base {
}
declare const InvalidPaginationTokenException_base: S.TaggedErrorClass<"InvalidPaginationTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidPaginationTokenException extends /*@__PURE__*/ InvalidPaginationTokenException_base {
}
declare const InvalidParameterCombinationException_base: S.TaggedErrorClass<"InvalidParameterCombinationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterCombinationException extends /*@__PURE__*/ InvalidParameterCombinationException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidParameterValueException_base: S.TaggedErrorClass<"InvalidParameterValueException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const InvalidVersionNumberException_base: S.TaggedErrorClass<"InvalidVersionNumberException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidVersionNumberException extends /*@__PURE__*/ InvalidVersionNumberException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceDependencyException_base: S.TaggedErrorClass<"ResourceDependencyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceDependencyException extends /*@__PURE__*/ ResourceDependencyException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceException_base: S.TaggedErrorClass<"ServiceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceException extends /*@__PURE__*/ ServiceException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type ImageBuildVersionArn = string;
export type ClientToken = string;
export interface CancelImageCreationRequest {
    imageBuildVersionArn: string;
    clientToken: string;
}
export type NonEmptyString = string;
export interface CancelImageCreationResponse {
    requestId?: string;
    clientToken?: string;
    imageBuildVersionArn?: string;
}
export type LifecycleExecutionId = string;
export interface CancelLifecycleExecutionRequest {
    lifecycleExecutionId: string;
    clientToken: string;
}
export interface CancelLifecycleExecutionResponse {
    lifecycleExecutionId?: string;
}
export type ResourceName = string;
export type VersionNumber = string;
export type Platform = "Windows" | "Linux" | "macOS" | (string & {});
export type OsVersion = string;
export type OsVersionList = string[];
export type InlineComponentData = string;
export type Uri = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateComponentRequest {
    name: string;
    semanticVersion: string;
    description?: string;
    changeDescription?: string;
    platform: Platform;
    supportedOsVersions?: string[];
    data?: string;
    uri?: string;
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
    dryRun?: boolean;
}
export type ComponentBuildVersionArn = string;
export type ImageBuilderArn = string;
export interface LatestVersionReferences {
    latestVersionArn?: string;
    latestMajorVersionArn?: string;
    latestMinorVersionArn?: string;
    latestPatchVersionArn?: string;
}
export interface CreateComponentResponse {
    requestId?: string;
    clientToken?: string;
    componentBuildVersionArn?: string;
    latestVersionReferences?: LatestVersionReferences;
}
export type ContainerType = "DOCKER" | (string & {});
export type WildcardVersionNumber = string;
export type ComponentVersionArnOrBuildVersionArn = string;
export type ComponentParameterName = string;
export type ComponentParameterValue = string;
export type ComponentParameterValueList = string[];
export interface ComponentParameter {
    name: string;
    value: string[];
}
export type ComponentParameterList = ComponentParameter[];
export interface ComponentConfiguration {
    componentArn: string;
    parameters?: ComponentParameter[];
}
export type ComponentConfigurationList = ComponentConfiguration[];
export type EbsIopsInteger = number;
export type EbsVolumeSizeInteger = number;
export type EbsVolumeType = "standard" | "io1" | "io2" | "gp2" | "gp3" | "sc1" | "st1" | (string & {});
export type EbsVolumeThroughput = number;
export interface EbsInstanceBlockDeviceSpecification {
    encrypted?: boolean;
    deleteOnTermination?: boolean;
    iops?: number;
    kmsKeyId?: string;
    snapshotId?: string;
    volumeSize?: number;
    volumeType?: EbsVolumeType;
    throughput?: number;
}
export type EmptyString = string;
export interface InstanceBlockDeviceMapping {
    deviceName?: string;
    ebs?: EbsInstanceBlockDeviceSpecification;
    virtualName?: string;
    noDevice?: string;
}
export type InstanceBlockDeviceMappings = InstanceBlockDeviceMapping[];
export interface InstanceConfiguration {
    image?: string;
    blockDeviceMappings?: InstanceBlockDeviceMapping[];
}
export type InlineDockerFileTemplate = string;
export type ContainerRepositoryService = "ECR" | (string & {});
export interface TargetContainerRepository {
    service: ContainerRepositoryService;
    repositoryName: string;
}
export interface CreateContainerRecipeRequest {
    containerType: ContainerType;
    name: string;
    description?: string;
    semanticVersion: string;
    components?: ComponentConfiguration[];
    instanceConfiguration?: InstanceConfiguration;
    dockerfileTemplateData?: string;
    dockerfileTemplateUri?: string;
    platformOverride?: Platform;
    imageOsVersionOverride?: string;
    parentImage: string;
    tags?: {
        [key: string]: string | undefined;
    };
    workingDirectory?: string;
    targetRepository: TargetContainerRepository;
    kmsKeyId?: string;
    clientToken: string;
    dryRun?: boolean;
}
export type ContainerRecipeArn = string;
export interface CreateContainerRecipeResponse {
    requestId?: string;
    clientToken?: string;
    containerRecipeArn?: string;
    latestVersionReferences?: LatestVersionReferences;
}
export type AmiNameString = string;
export type AccountId = string;
export type AccountList = string[];
export type StringList = string[];
export type OrganizationArn = string;
export type OrganizationArnList = string[];
export type OrganizationalUnitArn = string;
export type OrganizationalUnitArnList = string[];
export interface LaunchPermissionConfiguration {
    userIds?: string[];
    userGroups?: string[];
    organizationArns?: string[];
    organizationalUnitArns?: string[];
}
export interface AmiDistributionConfiguration {
    name?: string;
    description?: string;
    targetAccountIds?: string[];
    amiTags?: {
        [key: string]: string | undefined;
    };
    kmsKeyId?: string;
    launchPermission?: LaunchPermissionConfiguration;
}
export interface ContainerDistributionConfiguration {
    description?: string;
    containerTags?: string[];
    targetRepository: TargetContainerRepository;
}
export type LicenseConfigurationArn = string;
export type LicenseConfigurationArnList = string[];
export type LaunchTemplateId = string;
export interface LaunchTemplateConfiguration {
    launchTemplateId: string;
    accountId?: string;
    setDefaultVersion?: boolean;
}
export type LaunchTemplateConfigurationList = LaunchTemplateConfiguration[];
export type DiskImageFormat = "VMDK" | "RAW" | "VHD" | (string & {});
export interface S3ExportConfiguration {
    roleName: string;
    diskImageFormat: DiskImageFormat;
    s3Bucket: string;
    s3Prefix?: string;
}
export type TargetResourceCount = number;
export interface FastLaunchSnapshotConfiguration {
    targetResourceCount?: number;
}
export type MaxParallelLaunches = number;
export interface FastLaunchLaunchTemplateSpecification {
    launchTemplateId?: string;
    launchTemplateName?: string;
    launchTemplateVersion?: string;
}
export interface FastLaunchConfiguration {
    enabled: boolean;
    snapshotConfiguration?: FastLaunchSnapshotConfiguration;
    maxParallelLaunches?: number;
    launchTemplate?: FastLaunchLaunchTemplateSpecification;
    accountId?: string;
}
export type FastLaunchConfigurationList = FastLaunchConfiguration[];
export type SsmParameterName = string;
export type SsmParameterDataType = "text" | "aws:ec2:image" | (string & {});
export interface SsmParameterConfiguration {
    amiAccountId?: string;
    parameterName: string;
    dataType?: SsmParameterDataType;
}
export type SsmParameterConfigurationList = SsmParameterConfiguration[];
export interface Distribution {
    region: string;
    amiDistributionConfiguration?: AmiDistributionConfiguration;
    containerDistributionConfiguration?: ContainerDistributionConfiguration;
    licenseConfigurationArns?: string[];
    launchTemplateConfigurations?: LaunchTemplateConfiguration[];
    s3ExportConfiguration?: S3ExportConfiguration;
    fastLaunchConfigurations?: FastLaunchConfiguration[];
    ssmParameterConfigurations?: SsmParameterConfiguration[];
}
export type DistributionList = Distribution[];
export interface CreateDistributionConfigurationRequest {
    name: string;
    description?: string;
    distributions: Distribution[];
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
    dryRun?: boolean;
}
export type DistributionConfigurationArn = string;
export interface CreateDistributionConfigurationResponse {
    requestId?: string;
    clientToken?: string;
    distributionConfigurationArn?: string;
}
export type ImageRecipeArn = string;
export type InfrastructureConfigurationArn = string;
export type ImageTestsTimeoutMinutes = number;
export interface ImageTestsConfiguration {
    imageTestsEnabled?: boolean;
    timeoutMinutes?: number;
}
export interface EcrConfiguration {
    repositoryName?: string;
    containerTags?: string[];
}
export interface ImageScanningConfiguration {
    imageScanningEnabled?: boolean;
    ecrConfiguration?: EcrConfiguration;
}
export type WorkflowVersionArnOrBuildVersionArn = string;
export type WorkflowParameterName = string;
export type WorkflowParameterValue = string;
export type WorkflowParameterValueList = string[];
export interface WorkflowParameter {
    name: string;
    value: string[];
}
export type WorkflowParameterList = WorkflowParameter[];
export type ParallelGroup = string;
export type OnWorkflowFailure = "CONTINUE" | "ABORT" | (string & {});
export interface WorkflowConfiguration {
    workflowArn: string;
    parameters?: WorkflowParameter[];
    parallelGroup?: string;
    onFailure?: OnWorkflowFailure;
}
export type WorkflowConfigurationList = WorkflowConfiguration[];
export type RoleNameOrArn = string;
export type LogGroupName = string;
export interface ImageLoggingConfiguration {
    logGroupName?: string;
}
export interface CreateImageRequest {
    imageRecipeArn?: string;
    containerRecipeArn?: string;
    distributionConfigurationArn?: string;
    infrastructureConfigurationArn: string;
    imageTestsConfiguration?: ImageTestsConfiguration;
    enhancedImageMetadataEnabled?: boolean;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
    imageScanningConfiguration?: ImageScanningConfiguration;
    workflows?: WorkflowConfiguration[];
    executionRole?: string;
    loggingConfiguration?: ImageLoggingConfiguration;
}
export interface CreateImageResponse {
    requestId?: string;
    clientToken?: string;
    imageBuildVersionArn?: string;
    latestVersionReferences?: LatestVersionReferences;
}
export type Timezone = string;
export type PipelineExecutionStartCondition = "EXPRESSION_MATCH_ONLY" | "EXPRESSION_MATCH_AND_DEPENDENCY_UPDATES_AVAILABLE" | (string & {});
export type AutoDisableFailureCount = number;
export interface AutoDisablePolicy {
    failureCount: number;
}
export interface Schedule {
    scheduleExpression?: string;
    timezone?: string;
    pipelineExecutionStartCondition?: PipelineExecutionStartCondition;
    autoDisablePolicy?: AutoDisablePolicy;
}
export type PipelineStatus = "DISABLED" | "ENABLED" | (string & {});
export interface PipelineLoggingConfiguration {
    imageLogGroupName?: string;
    pipelineLogGroupName?: string;
}
export interface CreateImagePipelineRequest {
    name: string;
    description?: string;
    imageRecipeArn?: string;
    containerRecipeArn?: string;
    infrastructureConfigurationArn: string;
    distributionConfigurationArn?: string;
    imageTestsConfiguration?: ImageTestsConfiguration;
    enhancedImageMetadataEnabled?: boolean;
    schedule?: Schedule;
    status?: PipelineStatus;
    tags?: {
        [key: string]: string | undefined;
    };
    imageTags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
    imageScanningConfiguration?: ImageScanningConfiguration;
    workflows?: WorkflowConfiguration[];
    executionRole?: string;
    loggingConfiguration?: PipelineLoggingConfiguration;
    dryRun?: boolean;
}
export type ImagePipelineArn = string;
export interface CreateImagePipelineResponse {
    requestId?: string;
    clientToken?: string;
    imagePipelineArn?: string;
}
export interface SystemsManagerAgent {
    uninstallAfterBuild?: boolean;
}
export type UserDataOverride = string;
export interface AdditionalInstanceConfiguration {
    systemsManagerAgent?: SystemsManagerAgent;
    userDataOverride?: string;
}
export type AmiWatermarkName = string;
export type AmiWatermarksList = string[];
export interface CreateImageRecipeRequest {
    name: string;
    description?: string;
    semanticVersion: string;
    components?: ComponentConfiguration[];
    parentImage: string;
    blockDeviceMappings?: InstanceBlockDeviceMapping[];
    tags?: {
        [key: string]: string | undefined;
    };
    workingDirectory?: string;
    additionalInstanceConfiguration?: AdditionalInstanceConfiguration;
    amiTags?: {
        [key: string]: string | undefined;
    };
    amiWatermarks?: string[];
    clientToken: string;
    dryRun?: boolean;
}
export interface CreateImageRecipeResponse {
    requestId?: string;
    clientToken?: string;
    imageRecipeArn?: string;
    latestVersionReferences?: LatestVersionReferences;
}
export type InstanceType = string;
export type InstanceTypeList = string[];
export type InstanceProfileNameType = string;
export type SecurityGroupIds = string[];
export interface S3Logs {
    s3BucketName?: string;
    s3KeyPrefix?: string;
}
export interface Logging {
    s3Logs?: S3Logs;
}
export type SnsTopicArn = string;
export type ResourceTagMap = {
    [key: string]: string | undefined;
};
export type HttpTokens = string;
export type HttpPutResponseHopLimit = number;
export interface InstanceMetadataOptions {
    httpTokens?: string;
    httpPutResponseHopLimit?: number;
}
export type TenancyType = "default" | "dedicated" | "host" | (string & {});
export interface Placement {
    availabilityZone?: string;
    tenancy?: TenancyType;
    hostId?: string;
    hostResourceGroupArn?: string;
}
export interface CreateInfrastructureConfigurationRequest {
    name: string;
    description?: string;
    instanceTypes?: string[];
    instanceProfileName: string;
    securityGroupIds?: string[];
    subnetId?: string;
    logging?: Logging;
    keyPair?: string;
    terminateInstanceOnFailure?: boolean;
    snsTopicArn?: string;
    resourceTags?: {
        [key: string]: string | undefined;
    };
    instanceMetadataOptions?: InstanceMetadataOptions;
    tags?: {
        [key: string]: string | undefined;
    };
    placement?: Placement;
    clientToken: string;
    dryRun?: boolean;
}
export interface CreateInfrastructureConfigurationResponse {
    requestId?: string;
    clientToken?: string;
    infrastructureConfigurationArn?: string;
}
export type LifecyclePolicyStatus = "DISABLED" | "ENABLED" | (string & {});
export type LifecyclePolicyResourceType = "AMI_IMAGE" | "CONTAINER_IMAGE" | (string & {});
export type LifecyclePolicyDetailActionType = "DELETE" | "DEPRECATE" | "DISABLE" | (string & {});
export interface LifecyclePolicyDetailActionIncludeResources {
    amis?: boolean;
    snapshots?: boolean;
    containers?: boolean;
}
export interface LifecyclePolicyDetailAction {
    type: LifecyclePolicyDetailActionType;
    includeResources?: LifecyclePolicyDetailActionIncludeResources;
}
export type LifecyclePolicyDetailFilterType = "AGE" | "COUNT" | (string & {});
export type LifecyclePolicyDetailFilterValue = number;
export type LifecyclePolicyTimeUnit = "DAYS" | "WEEKS" | "MONTHS" | "YEARS" | (string & {});
export type LifecyclePolicyDetailFilterRetainAtLeast = number;
export interface LifecyclePolicyDetailFilter {
    type: LifecyclePolicyDetailFilterType;
    value: number;
    unit?: LifecyclePolicyTimeUnit;
    retainAtLeast?: number;
}
export type LifecyclePolicyDetailExclusionRulesAmisLastLaunchedValue = number;
export interface LifecyclePolicyDetailExclusionRulesAmisLastLaunched {
    value: number;
    unit: LifecyclePolicyTimeUnit;
}
export interface LifecyclePolicyDetailExclusionRulesAmis {
    isPublic?: boolean;
    regions?: string[];
    sharedAccounts?: string[];
    lastLaunched?: LifecyclePolicyDetailExclusionRulesAmisLastLaunched;
    tagMap?: {
        [key: string]: string | undefined;
    };
}
export interface LifecyclePolicyDetailExclusionRules {
    tagMap?: {
        [key: string]: string | undefined;
    };
    amis?: LifecyclePolicyDetailExclusionRulesAmis;
}
export interface LifecyclePolicyDetail {
    action: LifecyclePolicyDetailAction;
    filter: LifecyclePolicyDetailFilter;
    exclusionRules?: LifecyclePolicyDetailExclusionRules;
}
export type LifecyclePolicyDetails = LifecyclePolicyDetail[];
export interface LifecyclePolicyResourceSelectionRecipe {
    name: string;
    semanticVersion: string;
}
export type LifecyclePolicyResourceSelectionRecipes = LifecyclePolicyResourceSelectionRecipe[];
export interface LifecyclePolicyResourceSelection {
    recipes?: LifecyclePolicyResourceSelectionRecipe[];
    tagMap?: {
        [key: string]: string | undefined;
    };
}
export interface CreateLifecyclePolicyRequest {
    name: string;
    description?: string;
    status?: LifecyclePolicyStatus;
    executionRole: string;
    resourceType: LifecyclePolicyResourceType;
    policyDetails: LifecyclePolicyDetail[];
    resourceSelection: LifecyclePolicyResourceSelection;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
    dryRun?: boolean;
}
export type LifecyclePolicyArn = string;
export interface CreateLifecyclePolicyResponse {
    clientToken?: string;
    lifecyclePolicyArn?: string;
}
export type InlineWorkflowData = string;
export type WorkflowType = "BUILD" | "TEST" | "DISTRIBUTION" | (string & {});
export interface CreateWorkflowRequest {
    name: string;
    semanticVersion: string;
    description?: string;
    changeDescription?: string;
    data?: string;
    uri?: string;
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
    type: WorkflowType;
    dryRun?: boolean;
}
export type WorkflowBuildVersionArn = string;
export interface CreateWorkflowResponse {
    clientToken?: string;
    workflowBuildVersionArn?: string;
    latestVersionReferences?: LatestVersionReferences;
}
export interface DeleteComponentRequest {
    componentBuildVersionArn: string;
}
export interface DeleteComponentResponse {
    requestId?: string;
    componentBuildVersionArn?: string;
}
export interface DeleteContainerRecipeRequest {
    containerRecipeArn: string;
}
export interface DeleteContainerRecipeResponse {
    requestId?: string;
    containerRecipeArn?: string;
}
export interface DeleteDistributionConfigurationRequest {
    distributionConfigurationArn: string;
}
export interface DeleteDistributionConfigurationResponse {
    requestId?: string;
    distributionConfigurationArn?: string;
}
export interface DeleteImageRequest {
    imageBuildVersionArn: string;
}
export interface DeleteImageResponse {
    requestId?: string;
    imageBuildVersionArn?: string;
}
export interface DeleteImagePipelineRequest {
    imagePipelineArn: string;
}
export interface DeleteImagePipelineResponse {
    requestId?: string;
    imagePipelineArn?: string;
}
export interface DeleteImageRecipeRequest {
    imageRecipeArn: string;
}
export interface DeleteImageRecipeResponse {
    requestId?: string;
    imageRecipeArn?: string;
}
export interface DeleteInfrastructureConfigurationRequest {
    infrastructureConfigurationArn: string;
}
export interface DeleteInfrastructureConfigurationResponse {
    requestId?: string;
    infrastructureConfigurationArn?: string;
}
export interface DeleteLifecyclePolicyRequest {
    lifecyclePolicyArn: string;
}
export interface DeleteLifecyclePolicyResponse {
    lifecyclePolicyArn?: string;
}
export interface DeleteWorkflowRequest {
    workflowBuildVersionArn: string;
}
export interface DeleteWorkflowResponse {
    workflowBuildVersionArn?: string;
}
export interface DistributeImageRequest {
    sourceImage: string;
    distributionConfigurationArn: string;
    executionRole: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
    loggingConfiguration?: ImageLoggingConfiguration;
}
export interface DistributeImageResponse {
    clientToken?: string;
    imageBuildVersionArn?: string;
}
export interface GetComponentRequest {
    componentBuildVersionArn: string;
}
export type ComponentType = "BUILD" | "TEST" | (string & {});
export type ComponentStatus = "DEPRECATED" | "DISABLED" | "ACTIVE" | (string & {});
export interface ComponentState {
    status?: ComponentStatus;
    reason?: string;
}
export type ComponentParameterType = string;
export type ComponentParameterDescription = string;
export interface ComponentParameterDetail {
    name: string;
    type: string;
    defaultValue?: string[];
    description?: string;
}
export type ComponentParameterDetailList = ComponentParameterDetail[];
export type ComponentData = string;
export type ProductCodeId = string;
export type ProductCodeType = "marketplace" | (string & {});
export interface ProductCodeListItem {
    productCodeId: string;
    productCodeType: ProductCodeType;
}
export type ProductCodeList = ProductCodeListItem[];
export interface Component {
    arn?: string;
    name?: string;
    version?: string;
    description?: string;
    changeDescription?: string;
    type?: ComponentType;
    platform?: Platform;
    supportedOsVersions?: string[];
    state?: ComponentState;
    parameters?: ComponentParameterDetail[];
    owner?: string;
    data?: string;
    kmsKeyId?: string;
    encrypted?: boolean;
    dateCreated?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    publisher?: string;
    obfuscate?: boolean;
    productCodes?: ProductCodeListItem[];
}
export interface GetComponentResponse {
    requestId?: string;
    component?: Component;
    latestVersionReferences?: LatestVersionReferences;
}
export interface GetComponentPolicyRequest {
    componentArn: string;
}
export type ResourcePolicyDocument = string;
export interface GetComponentPolicyResponse {
    requestId?: string;
    policy?: string;
}
export interface GetContainerRecipeRequest {
    containerRecipeArn: string;
}
export type DockerFileTemplate = string;
export interface ContainerRecipe {
    arn?: string;
    containerType?: ContainerType;
    name?: string;
    description?: string;
    platform?: Platform;
    owner?: string;
    version?: string;
    components?: ComponentConfiguration[];
    instanceConfiguration?: InstanceConfiguration;
    dockerfileTemplateData?: string;
    kmsKeyId?: string;
    encrypted?: boolean;
    parentImage?: string;
    dateCreated?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    workingDirectory?: string;
    targetRepository?: TargetContainerRepository;
}
export interface GetContainerRecipeResponse {
    requestId?: string;
    containerRecipe?: ContainerRecipe;
    latestVersionReferences?: LatestVersionReferences;
}
export interface GetContainerRecipePolicyRequest {
    containerRecipeArn: string;
}
export interface GetContainerRecipePolicyResponse {
    requestId?: string;
    policy?: string;
}
export interface GetDistributionConfigurationRequest {
    distributionConfigurationArn: string;
}
export type DistributionTimeoutMinutes = number;
export interface DistributionConfiguration {
    arn?: string;
    name?: string;
    description?: string;
    distributions?: Distribution[];
    timeoutMinutes?: number;
    dateCreated?: string;
    dateUpdated?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetDistributionConfigurationResponse {
    requestId?: string;
    distributionConfiguration?: DistributionConfiguration;
}
export type ImageVersionArnOrBuildVersionArn = string;
export interface GetImageRequest {
    imageBuildVersionArn: string;
}
export type ImageType = "AMI" | "DOCKER" | (string & {});
export type VersionNumberWithBuild = string;
export type ImageStatus = "PENDING" | "CREATING" | "BUILDING" | "TESTING" | "DISTRIBUTING" | "INTEGRATING" | "AVAILABLE" | "CANCELLED" | "FAILED" | "DEPRECATED" | "DELETED" | "DISABLED" | (string & {});
export type WorkflowExecutionId = string;
export type WorkflowStepExecutionId = string;
export type WorkflowStepName = string;
export type NonEmptyMaxLengthString = string;
export interface ComponentFailureContext {
    componentArn?: string;
    phaseName?: string;
    stepName?: string;
    action?: string;
    errorMessage?: string;
}
export type RegionFailureStatus = "FAILED" | "CANCELLED" | "TIMED_OUT" | (string & {});
export type ImageConfigurationStep = "ASSOCIATE_LICENSES" | "UPDATE_LAUNCH_TEMPLATES" | "PUT_SSM_PARAMETERS" | "UPDATE_FAST_LAUNCH_CONFIGURATIONS" | "EXPORT_AMI" | (string & {});
export interface RegionFailure {
    region?: string;
    status?: RegionFailureStatus;
    imageConfigurationStep?: ImageConfigurationStep;
    errorMessage?: string;
    targetAccountId?: string;
}
export type RegionFailureList = RegionFailure[];
export interface DistributionFailureContext {
    errorMessage?: string;
    regionFailures?: RegionFailure[];
}
export interface ImageFailureContext {
    imageStatus?: ImageStatus;
    workflowExecutionId?: string;
    workflowArn?: string;
    stepExecutionId?: string;
    failedStep?: string;
    componentFailure?: ComponentFailureContext;
    distributionFailure?: DistributionFailureContext;
}
export interface ImageState {
    status?: ImageStatus;
    reason?: string;
    failureContext?: ImageFailureContext;
}
export interface ImageRecipe {
    arn?: string;
    type?: ImageType;
    name?: string;
    description?: string;
    platform?: Platform;
    owner?: string;
    version?: string;
    components?: ComponentConfiguration[];
    parentImage?: string;
    blockDeviceMappings?: InstanceBlockDeviceMapping[];
    dateCreated?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    workingDirectory?: string;
    additionalInstanceConfiguration?: AdditionalInstanceConfiguration;
    amiTags?: {
        [key: string]: string | undefined;
    };
    amiWatermarks?: string[];
}
export type Arn = string;
export interface InfrastructureConfiguration {
    arn?: string;
    name?: string;
    description?: string;
    instanceTypes?: string[];
    instanceProfileName?: string;
    securityGroupIds?: string[];
    subnetId?: string;
    logging?: Logging;
    keyPair?: string;
    terminateInstanceOnFailure?: boolean;
    snsTopicArn?: string;
    dateCreated?: string;
    dateUpdated?: string;
    resourceTags?: {
        [key: string]: string | undefined;
    };
    instanceMetadataOptions?: InstanceMetadataOptions;
    tags?: {
        [key: string]: string | undefined;
    };
    placement?: Placement;
}
export interface Ami {
    region?: string;
    image?: string;
    name?: string;
    description?: string;
    state?: ImageState;
    accountId?: string;
}
export type AmiList = Ami[];
export interface Container {
    region?: string;
    imageUris?: string[];
}
export type ContainerList = Container[];
export interface OutputResources {
    amis?: Ami[];
    containers?: Container[];
}
export type BuildType = "USER_INITIATED" | "SCHEDULED" | "IMPORT" | "IMPORT_ISO" | (string & {});
export type ImageSource = "AMAZON_MANAGED" | "AWS_MARKETPLACE" | "IMPORTED" | "CUSTOM" | (string & {});
export type ImageScanStatus = "PENDING" | "SCANNING" | "COLLECTING" | "COMPLETED" | "ABANDONED" | "FAILED" | "TIMED_OUT" | (string & {});
export interface ImageScanState {
    status?: ImageScanStatus;
    reason?: string;
}
export type DateTimeTimestamp = Date;
export interface Image {
    arn?: string;
    type?: ImageType;
    name?: string;
    version?: string;
    platform?: Platform;
    enhancedImageMetadataEnabled?: boolean;
    osVersion?: string;
    state?: ImageState;
    imageRecipe?: ImageRecipe;
    containerRecipe?: ContainerRecipe;
    sourcePipelineName?: string;
    sourcePipelineArn?: string;
    infrastructureConfiguration?: InfrastructureConfiguration;
    distributionConfiguration?: DistributionConfiguration;
    imageTestsConfiguration?: ImageTestsConfiguration;
    dateCreated?: string;
    outputResources?: OutputResources;
    tags?: {
        [key: string]: string | undefined;
    };
    buildType?: BuildType;
    imageSource?: ImageSource;
    scanState?: ImageScanState;
    imageScanningConfiguration?: ImageScanningConfiguration;
    deprecationTime?: Date;
    lifecycleExecutionId?: string;
    executionRole?: string;
    workflows?: WorkflowConfiguration[];
    loggingConfiguration?: ImageLoggingConfiguration;
}
export interface GetImageResponse {
    requestId?: string;
    image?: Image;
    latestVersionReferences?: LatestVersionReferences;
}
export interface GetImagePipelineRequest {
    imagePipelineArn: string;
}
export type ConsecutiveFailures = number;
export interface ImagePipeline {
    arn?: string;
    name?: string;
    description?: string;
    platform?: Platform;
    enhancedImageMetadataEnabled?: boolean;
    imageRecipeArn?: string;
    containerRecipeArn?: string;
    infrastructureConfigurationArn?: string;
    distributionConfigurationArn?: string;
    imageTestsConfiguration?: ImageTestsConfiguration;
    schedule?: Schedule;
    status?: PipelineStatus;
    dateCreated?: string;
    dateUpdated?: string;
    dateLastRun?: string;
    lastRunStatus?: ImageStatus;
    dateNextRun?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    imageScanningConfiguration?: ImageScanningConfiguration;
    imageTags?: {
        [key: string]: string | undefined;
    };
    executionRole?: string;
    workflows?: WorkflowConfiguration[];
    loggingConfiguration?: PipelineLoggingConfiguration;
    consecutiveFailures?: number;
}
export interface GetImagePipelineResponse {
    requestId?: string;
    imagePipeline?: ImagePipeline;
}
export interface GetImagePolicyRequest {
    imageArn: string;
}
export interface GetImagePolicyResponse {
    requestId?: string;
    policy?: string;
}
export interface GetImageRecipeRequest {
    imageRecipeArn: string;
}
export interface GetImageRecipeResponse {
    requestId?: string;
    imageRecipe?: ImageRecipe;
    latestVersionReferences?: LatestVersionReferences;
}
export interface GetImageRecipePolicyRequest {
    imageRecipeArn: string;
}
export interface GetImageRecipePolicyResponse {
    requestId?: string;
    policy?: string;
}
export interface GetInfrastructureConfigurationRequest {
    infrastructureConfigurationArn: string;
}
export interface GetInfrastructureConfigurationResponse {
    requestId?: string;
    infrastructureConfiguration?: InfrastructureConfiguration;
}
export interface GetLifecycleExecutionRequest {
    lifecycleExecutionId: string;
}
export interface LifecycleExecutionResourcesImpactedSummary {
    hasImpactedResources?: boolean;
}
export type LifecycleExecutionStatus = "IN_PROGRESS" | "CANCELLED" | "CANCELLING" | "FAILED" | "SUCCESS" | "PENDING" | (string & {});
export interface LifecycleExecutionState {
    status?: LifecycleExecutionStatus;
    reason?: string;
}
export interface LifecycleExecution {
    lifecycleExecutionId?: string;
    lifecyclePolicyArn?: string;
    resourcesImpactedSummary?: LifecycleExecutionResourcesImpactedSummary;
    state?: LifecycleExecutionState;
    startTime?: Date;
    endTime?: Date;
}
export interface GetLifecycleExecutionResponse {
    lifecycleExecution?: LifecycleExecution;
}
export interface GetLifecyclePolicyRequest {
    lifecyclePolicyArn: string;
}
export interface LifecyclePolicy {
    arn?: string;
    name?: string;
    description?: string;
    status?: LifecyclePolicyStatus;
    executionRole?: string;
    resourceType?: LifecyclePolicyResourceType;
    policyDetails?: LifecyclePolicyDetail[];
    resourceSelection?: LifecyclePolicyResourceSelection;
    dateCreated?: Date;
    dateUpdated?: Date;
    dateLastRun?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface GetLifecyclePolicyResponse {
    lifecyclePolicy?: LifecyclePolicy;
}
export type MarketplaceResourceType = "COMPONENT_DATA" | "COMPONENT_ARTIFACT" | (string & {});
export type MarketplaceResourceLocation = string;
export interface GetMarketplaceResourceRequest {
    resourceType: MarketplaceResourceType;
    resourceArn: string;
    resourceLocation?: string;
}
export interface GetMarketplaceResourceResponse {
    resourceArn?: string;
    url?: string;
    data?: string;
}
export interface GetWorkflowRequest {
    workflowBuildVersionArn: string;
}
export type WorkflowStatus = "DEPRECATED" | (string & {});
export interface WorkflowState {
    status?: WorkflowStatus;
    reason?: string;
}
export type WorkflowData = string;
export type WorkflowParameterType = string;
export type WorkflowParameterDescription = string;
export interface WorkflowParameterDetail {
    name: string;
    type: string;
    defaultValue?: string[];
    description?: string;
}
export type WorkflowParameterDetailList = WorkflowParameterDetail[];
export interface Workflow {
    arn?: string;
    name?: string;
    version?: string;
    description?: string;
    changeDescription?: string;
    type?: WorkflowType;
    state?: WorkflowState;
    owner?: string;
    data?: string;
    kmsKeyId?: string;
    dateCreated?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    parameters?: WorkflowParameterDetail[];
}
export interface GetWorkflowResponse {
    workflow?: Workflow;
    latestVersionReferences?: LatestVersionReferences;
}
export interface GetWorkflowExecutionRequest {
    workflowExecutionId: string;
}
export type WorkflowExecutionStatus = "PENDING" | "SKIPPED" | "RUNNING" | "COMPLETED" | "FAILED" | "ROLLBACK_IN_PROGRESS" | "ROLLBACK_COMPLETED" | "CANCELLED" | (string & {});
export type WorkflowExecutionMessage = string;
export type WorkflowStepCount = number;
export interface GetWorkflowExecutionResponse {
    requestId?: string;
    workflowBuildVersionArn?: string;
    workflowExecutionId?: string;
    imageBuildVersionArn?: string;
    type?: WorkflowType;
    status?: WorkflowExecutionStatus;
    message?: string;
    totalStepCount?: number;
    totalStepsSucceeded?: number;
    totalStepsFailed?: number;
    totalStepsSkipped?: number;
    startTime?: string;
    endTime?: string;
    parallelGroup?: string;
}
export interface GetWorkflowStepExecutionRequest {
    stepExecutionId: string;
}
export type WorkflowStepDescription = string;
export type WorkflowStepAction = string;
export type WorkflowStepExecutionStatus = "PENDING" | "SKIPPED" | "RUNNING" | "COMPLETED" | "FAILED" | "CANCELLED" | (string & {});
export type WorkflowStepExecutionRollbackStatus = "RUNNING" | "COMPLETED" | "SKIPPED" | "FAILED" | (string & {});
export type WorkflowStepMessage = string;
export type WorkflowStepInputs = string;
export type WorkflowStepOutputs = string;
export type WorkflowStepTimeoutSecondsInteger = number;
export type WorkflowStepAttemptCount = number;
export interface GetWorkflowStepExecutionResponse {
    requestId?: string;
    stepExecutionId?: string;
    workflowBuildVersionArn?: string;
    workflowExecutionId?: string;
    imageBuildVersionArn?: string;
    name?: string;
    description?: string;
    action?: string;
    status?: WorkflowStepExecutionStatus;
    rollbackStatus?: WorkflowStepExecutionRollbackStatus;
    message?: string;
    inputs?: string;
    outputs?: string;
    startTime?: string;
    endTime?: string;
    onFailure?: string;
    timeoutSeconds?: number;
    attemptNumber?: number;
    maxAttempts?: number;
}
export type ComponentFormat = "SHELL" | (string & {});
export interface ImportComponentRequest {
    name: string;
    semanticVersion: string;
    description?: string;
    changeDescription?: string;
    type: ComponentType;
    format: ComponentFormat;
    platform: Platform;
    data?: string;
    uri?: string;
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
}
export interface ImportComponentResponse {
    requestId?: string;
    clientToken?: string;
    componentBuildVersionArn?: string;
}
export type UefiData = string;
export interface RegisterImageOptions {
    secureBootEnabled?: boolean;
    uefiData?: string;
}
export type WindowsConfigurationImageIndex = number;
export interface WindowsConfiguration {
    imageIndex: number;
}
export interface ImportDiskImageRequest {
    name: string;
    semanticVersion: string;
    description?: string;
    platform: string;
    osVersion: string;
    executionRole?: string;
    infrastructureConfigurationArn: string;
    uri: string;
    loggingConfiguration?: ImageLoggingConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
    registerImageOptions?: RegisterImageOptions;
    windowsConfiguration?: WindowsConfiguration;
    clientToken: string;
}
export interface ImportDiskImageResponse {
    clientToken?: string;
    imageBuildVersionArn?: string;
}
export interface ImportVmImageRequest {
    name: string;
    semanticVersion: string;
    description?: string;
    platform: Platform;
    osVersion?: string;
    vmImportTaskId: string;
    loggingConfiguration?: ImageLoggingConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
}
export interface ImportVmImageResponse {
    requestId?: string;
    imageArn?: string;
    clientToken?: string;
}
export type ComponentVersionArn = string;
export type RestrictedInteger = number;
export type PaginationToken = string;
export interface ListComponentBuildVersionsRequest {
    componentVersionArn?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface ComponentSummary {
    arn?: string;
    name?: string;
    version?: string;
    platform?: Platform;
    supportedOsVersions?: string[];
    state?: ComponentState;
    type?: ComponentType;
    owner?: string;
    description?: string;
    changeDescription?: string;
    dateCreated?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    publisher?: string;
    obfuscate?: boolean;
}
export type ComponentSummaryList = ComponentSummary[];
export interface ListComponentBuildVersionsResponse {
    requestId?: string;
    componentSummaryList?: ComponentSummary[];
    nextToken?: string;
}
export type Ownership = "Self" | "Shared" | "Amazon" | "ThirdParty" | "AWSMarketplace" | (string & {});
export type FilterName = string;
export type FilterValue = string;
export type FilterValues = string[];
export interface Filter {
    name?: string;
    values?: string[];
}
export type FilterList = Filter[];
export interface ListComponentsRequest {
    owner?: Ownership;
    filters?: Filter[];
    byName?: boolean;
    maxResults?: number;
    nextToken?: string;
}
export interface ComponentVersion {
    arn?: string;
    name?: string;
    version?: string;
    description?: string;
    platform?: Platform;
    supportedOsVersions?: string[];
    type?: ComponentType;
    owner?: string;
    dateCreated?: string;
    status?: ComponentStatus;
    productCodes?: ProductCodeListItem[];
}
export type ComponentVersionList = ComponentVersion[];
export interface ListComponentsResponse {
    requestId?: string;
    componentVersionList?: ComponentVersion[];
    nextToken?: string;
}
export interface ListContainerRecipesRequest {
    owner?: Ownership;
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export interface ContainerRecipeSummary {
    arn?: string;
    containerType?: ContainerType;
    name?: string;
    platform?: Platform;
    owner?: string;
    parentImage?: string;
    dateCreated?: string;
    instanceImage?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type ContainerRecipeSummaryList = ContainerRecipeSummary[];
export interface ListContainerRecipesResponse {
    requestId?: string;
    containerRecipeSummaryList?: ContainerRecipeSummary[];
    nextToken?: string;
}
export interface ListDistributionConfigurationsRequest {
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export type RegionList = string[];
export interface DistributionConfigurationSummary {
    arn?: string;
    name?: string;
    description?: string;
    dateCreated?: string;
    dateUpdated?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    regions?: string[];
}
export type DistributionConfigurationSummaryList = DistributionConfigurationSummary[];
export interface ListDistributionConfigurationsResponse {
    requestId?: string;
    distributionConfigurationSummaryList?: DistributionConfigurationSummary[];
    nextToken?: string;
}
export type ImageVersionArn = string;
export interface ListImageBuildVersionsRequest {
    imageVersionArn?: string;
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export interface ImageSummary {
    arn?: string;
    name?: string;
    type?: ImageType;
    version?: string;
    platform?: Platform;
    osVersion?: string;
    state?: ImageState;
    owner?: string;
    dateCreated?: string;
    outputResources?: OutputResources;
    tags?: {
        [key: string]: string | undefined;
    };
    buildType?: BuildType;
    imageSource?: ImageSource;
    deprecationTime?: Date;
    lifecycleExecutionId?: string;
    loggingConfiguration?: ImageLoggingConfiguration;
}
export type ImageSummaryList = ImageSummary[];
export interface ListImageBuildVersionsResponse {
    requestId?: string;
    imageSummaryList?: ImageSummary[];
    nextToken?: string;
}
export interface ListImagePackagesRequest {
    imageBuildVersionArn: string;
    maxResults?: number;
    nextToken?: string;
}
export interface ImagePackage {
    packageName?: string;
    packageVersion?: string;
}
export type ImagePackageList = ImagePackage[];
export interface ListImagePackagesResponse {
    requestId?: string;
    imagePackageList?: ImagePackage[];
    nextToken?: string;
}
export interface ListImagePipelineImagesRequest {
    imagePipelineArn: string;
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export interface ListImagePipelineImagesResponse {
    requestId?: string;
    imageSummaryList?: ImageSummary[];
    nextToken?: string;
}
export interface ListImagePipelinesRequest {
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export type ImagePipelineList = ImagePipeline[];
export interface ListImagePipelinesResponse {
    requestId?: string;
    imagePipelineList?: ImagePipeline[];
    nextToken?: string;
}
export interface ListImageRecipesRequest {
    owner?: Ownership;
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export interface ImageRecipeSummary {
    arn?: string;
    name?: string;
    platform?: Platform;
    owner?: string;
    parentImage?: string;
    dateCreated?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type ImageRecipeSummaryList = ImageRecipeSummary[];
export interface ListImageRecipesResponse {
    requestId?: string;
    imageRecipeSummaryList?: ImageRecipeSummary[];
    nextToken?: string;
}
export interface ListImagesRequest {
    owner?: Ownership;
    filters?: Filter[];
    byName?: boolean;
    maxResults?: number;
    nextToken?: string;
    includeDeprecated?: boolean;
}
export interface ImageVersion {
    arn?: string;
    name?: string;
    type?: ImageType;
    version?: string;
    platform?: Platform;
    osVersion?: string;
    owner?: string;
    dateCreated?: string;
    buildType?: BuildType;
    imageSource?: ImageSource;
}
export type ImageVersionList = ImageVersion[];
export interface ListImagesResponse {
    requestId?: string;
    imageVersionList?: ImageVersion[];
    nextToken?: string;
}
export interface ListImageScanFindingAggregationsRequest {
    filter?: Filter;
    nextToken?: string;
}
export type SeverityCountNumber = number;
export interface SeverityCounts {
    all?: number;
    critical?: number;
    high?: number;
    medium?: number;
}
export interface AccountAggregation {
    accountId?: string;
    severityCounts?: SeverityCounts;
}
export interface ImageAggregation {
    imageBuildVersionArn?: string;
    severityCounts?: SeverityCounts;
}
export interface ImagePipelineAggregation {
    imagePipelineArn?: string;
    severityCounts?: SeverityCounts;
}
export interface VulnerabilityIdAggregation {
    vulnerabilityId?: string;
    severityCounts?: SeverityCounts;
}
export interface ImageScanFindingAggregation {
    accountAggregation?: AccountAggregation;
    imageAggregation?: ImageAggregation;
    imagePipelineAggregation?: ImagePipelineAggregation;
    vulnerabilityIdAggregation?: VulnerabilityIdAggregation;
}
export type ImageScanFindingAggregationsList = ImageScanFindingAggregation[];
export interface ListImageScanFindingAggregationsResponse {
    requestId?: string;
    aggregationType?: string;
    responses?: ImageScanFindingAggregation[];
    nextToken?: string;
}
export type ImageScanFindingsFilterValues = string[];
export interface ImageScanFindingsFilter {
    name?: string;
    values?: string[];
}
export type ImageScanFindingsFilterList = ImageScanFindingsFilter[];
export interface ListImageScanFindingsRequest {
    filters?: ImageScanFindingsFilter[];
    maxResults?: number;
    nextToken?: string;
}
export interface RemediationRecommendation {
    text?: string;
    url?: string;
}
export interface Remediation {
    recommendation?: RemediationRecommendation;
}
export type NonNegativeDouble = number;
export interface CvssScoreAdjustment {
    metric?: string;
    reason?: string;
}
export type CvssScoreAdjustmentList = CvssScoreAdjustment[];
export interface CvssScoreDetails {
    scoreSource?: string;
    cvssSource?: string;
    version?: string;
    score?: number;
    scoringVector?: string;
    adjustments?: CvssScoreAdjustment[];
}
export interface InspectorScoreDetails {
    adjustedCvss?: CvssScoreDetails;
}
export type VulnerabilityId = string;
export type SourceLayerHash = string;
export type PackageEpoch = number;
export type PackageArchitecture = string;
export interface VulnerablePackage {
    name?: string;
    version?: string;
    sourceLayerHash?: string;
    epoch?: number;
    release?: string;
    arch?: string;
    packageManager?: string;
    filePath?: string;
    fixedInVersion?: string;
    remediation?: string;
}
export type VulnerablePackageList = VulnerablePackage[];
export interface CvssScore {
    baseScore?: number;
    scoringVector?: string;
    version?: string;
    source?: string;
}
export type CvssScoreList = CvssScore[];
export type VulnerabilityIdList = string[];
export type NonEmptyStringList = string[];
export interface PackageVulnerabilityDetails {
    vulnerabilityId: string;
    vulnerablePackages?: VulnerablePackage[];
    source?: string;
    cvss?: CvssScore[];
    relatedVulnerabilities?: string[];
    sourceUrl?: string;
    vendorSeverity?: string;
    vendorCreatedAt?: Date;
    vendorUpdatedAt?: Date;
    referenceUrls?: string[];
}
export interface ImageScanFinding {
    awsAccountId?: string;
    imageBuildVersionArn?: string;
    imagePipelineArn?: string;
    type?: string;
    description?: string;
    title?: string;
    remediation?: Remediation;
    severity?: string;
    firstObservedAt?: Date;
    updatedAt?: Date;
    inspectorScore?: number;
    inspectorScoreDetails?: InspectorScoreDetails;
    packageVulnerabilityDetails?: PackageVulnerabilityDetails;
    fixAvailable?: string;
}
export type ImageScanFindingsList = ImageScanFinding[];
export interface ListImageScanFindingsResponse {
    requestId?: string;
    findings?: ImageScanFinding[];
    nextToken?: string;
}
export interface ListInfrastructureConfigurationsRequest {
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export interface InfrastructureConfigurationSummary {
    arn?: string;
    name?: string;
    description?: string;
    dateCreated?: string;
    dateUpdated?: string;
    resourceTags?: {
        [key: string]: string | undefined;
    };
    tags?: {
        [key: string]: string | undefined;
    };
    instanceTypes?: string[];
    instanceProfileName?: string;
    placement?: Placement;
}
export type InfrastructureConfigurationSummaryList = InfrastructureConfigurationSummary[];
export interface ListInfrastructureConfigurationsResponse {
    requestId?: string;
    infrastructureConfigurationSummaryList?: InfrastructureConfigurationSummary[];
    nextToken?: string;
}
export interface ListLifecycleExecutionResourcesRequest {
    lifecycleExecutionId: string;
    parentResourceId?: string;
    maxResults?: number;
    nextToken?: string;
}
export type LifecycleExecutionResourceStatus = "FAILED" | "IN_PROGRESS" | "SKIPPED" | "SUCCESS" | (string & {});
export interface LifecycleExecutionResourceState {
    status?: LifecycleExecutionResourceStatus;
    reason?: string;
}
export type LifecycleExecutionResourceActionName = "AVAILABLE" | "DELETE" | "DEPRECATE" | "DISABLE" | (string & {});
export interface LifecycleExecutionResourceAction {
    name?: LifecycleExecutionResourceActionName;
    reason?: string;
}
export interface LifecycleExecutionSnapshotResource {
    snapshotId?: string;
    state?: LifecycleExecutionResourceState;
}
export type LifecycleExecutionSnapshotResourceList = LifecycleExecutionSnapshotResource[];
export interface LifecycleExecutionResource {
    accountId?: string;
    resourceId?: string;
    state?: LifecycleExecutionResourceState;
    action?: LifecycleExecutionResourceAction;
    region?: string;
    snapshots?: LifecycleExecutionSnapshotResource[];
    imageUris?: string[];
    startTime?: Date;
    endTime?: Date;
}
export type LifecycleExecutionResourceList = LifecycleExecutionResource[];
export interface ListLifecycleExecutionResourcesResponse {
    lifecycleExecutionId?: string;
    lifecycleExecutionState?: LifecycleExecutionState;
    resources?: LifecycleExecutionResource[];
    nextToken?: string;
}
export interface ListLifecycleExecutionsRequest {
    maxResults?: number;
    nextToken?: string;
    resourceArn: string;
}
export type LifecycleExecutionsList = LifecycleExecution[];
export interface ListLifecycleExecutionsResponse {
    lifecycleExecutions?: LifecycleExecution[];
    nextToken?: string;
}
export interface ListLifecyclePoliciesRequest {
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export interface LifecyclePolicySummary {
    arn?: string;
    name?: string;
    description?: string;
    status?: LifecyclePolicyStatus;
    executionRole?: string;
    resourceType?: LifecyclePolicyResourceType;
    dateCreated?: Date;
    dateUpdated?: Date;
    dateLastRun?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type LifecyclePolicySummaryList = LifecyclePolicySummary[];
export interface ListLifecyclePoliciesResponse {
    lifecyclePolicySummaryList?: LifecyclePolicySummary[];
    nextToken?: string;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface ListWaitingWorkflowStepsRequest {
    maxResults?: number;
    nextToken?: string;
}
export interface WorkflowStepExecution {
    stepExecutionId?: string;
    imageBuildVersionArn?: string;
    workflowExecutionId?: string;
    workflowBuildVersionArn?: string;
    name?: string;
    action?: string;
    startTime?: string;
}
export type WorkflowStepExecutionList = WorkflowStepExecution[];
export interface ListWaitingWorkflowStepsResponse {
    steps?: WorkflowStepExecution[];
    nextToken?: string;
}
export type WorkflowWildcardVersionArn = string;
export interface ListWorkflowBuildVersionsRequest {
    workflowVersionArn?: string;
    maxResults?: number;
    nextToken?: string;
}
export interface WorkflowSummary {
    arn?: string;
    name?: string;
    version?: string;
    description?: string;
    changeDescription?: string;
    type?: WorkflowType;
    owner?: string;
    state?: WorkflowState;
    dateCreated?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export type WorkflowSummaryList = WorkflowSummary[];
export interface ListWorkflowBuildVersionsResponse {
    workflowSummaryList?: WorkflowSummary[];
    nextToken?: string;
}
export interface ListWorkflowExecutionsRequest {
    maxResults?: number;
    nextToken?: string;
    imageBuildVersionArn: string;
}
export interface WorkflowExecutionMetadata {
    workflowBuildVersionArn?: string;
    workflowExecutionId?: string;
    type?: WorkflowType;
    status?: WorkflowExecutionStatus;
    message?: string;
    totalStepCount?: number;
    totalStepsSucceeded?: number;
    totalStepsFailed?: number;
    totalStepsSkipped?: number;
    startTime?: string;
    endTime?: string;
    parallelGroup?: string;
    retried?: boolean;
}
export type WorkflowExecutionsList = WorkflowExecutionMetadata[];
export type ImageBuildMessage = string;
export interface ListWorkflowExecutionsResponse {
    requestId?: string;
    workflowExecutions?: WorkflowExecutionMetadata[];
    imageBuildVersionArn?: string;
    message?: string;
    nextToken?: string;
}
export interface ListWorkflowsRequest {
    owner?: Ownership;
    filters?: Filter[];
    byName?: boolean;
    maxResults?: number;
    nextToken?: string;
}
export interface WorkflowVersion {
    arn?: string;
    name?: string;
    version?: string;
    description?: string;
    type?: WorkflowType;
    owner?: string;
    dateCreated?: string;
}
export type WorkflowVersionList = WorkflowVersion[];
export interface ListWorkflowsResponse {
    workflowVersionList?: WorkflowVersion[];
    nextToken?: string;
}
export interface ListWorkflowStepExecutionsRequest {
    maxResults?: number;
    nextToken?: string;
    workflowExecutionId: string;
}
export interface WorkflowStepMetadata {
    stepExecutionId?: string;
    name?: string;
    description?: string;
    action?: string;
    status?: WorkflowStepExecutionStatus;
    rollbackStatus?: WorkflowStepExecutionRollbackStatus;
    message?: string;
    inputs?: string;
    outputs?: string;
    startTime?: string;
    endTime?: string;
    attemptNumber?: number;
    maxAttempts?: number;
}
export type WorkflowStepExecutionsList = WorkflowStepMetadata[];
export interface ListWorkflowStepExecutionsResponse {
    requestId?: string;
    steps?: WorkflowStepMetadata[];
    workflowBuildVersionArn?: string;
    workflowExecutionId?: string;
    imageBuildVersionArn?: string;
    message?: string;
    nextToken?: string;
}
export interface PutComponentPolicyRequest {
    componentArn: string;
    policy: string;
}
export interface PutComponentPolicyResponse {
    requestId?: string;
    componentArn?: string;
}
export interface PutContainerRecipePolicyRequest {
    containerRecipeArn: string;
    policy: string;
}
export interface PutContainerRecipePolicyResponse {
    requestId?: string;
    containerRecipeArn?: string;
}
export interface PutImagePolicyRequest {
    imageArn: string;
    policy: string;
}
export interface PutImagePolicyResponse {
    requestId?: string;
    imageArn?: string;
}
export interface PutImageRecipePolicyRequest {
    imageRecipeArn: string;
    policy: string;
}
export interface PutImageRecipePolicyResponse {
    requestId?: string;
    imageRecipeArn?: string;
}
export interface RetryImageRequest {
    imageBuildVersionArn: string;
    clientToken: string;
}
export interface RetryImageResponse {
    clientToken?: string;
    imageBuildVersionArn?: string;
}
export type WorkflowStepActionType = "RESUME" | "STOP" | (string & {});
export interface SendWorkflowStepActionRequest {
    stepExecutionId: string;
    imageBuildVersionArn: string;
    action: WorkflowStepActionType;
    reason?: string;
    clientToken: string;
}
export interface SendWorkflowStepActionResponse {
    stepExecutionId?: string;
    imageBuildVersionArn?: string;
    clientToken?: string;
}
export interface StartImagePipelineExecutionRequest {
    imagePipelineArn: string;
    clientToken: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export interface StartImagePipelineExecutionResponse {
    requestId?: string;
    clientToken?: string;
    imageBuildVersionArn?: string;
}
export type ResourceStatus = "AVAILABLE" | "DELETED" | "DEPRECATED" | "DISABLED" | (string & {});
export interface ResourceState {
    status?: ResourceStatus;
}
export interface ResourceStateUpdateIncludeResources {
    amis?: boolean;
    snapshots?: boolean;
    containers?: boolean;
}
export interface ResourceStateUpdateExclusionRules {
    amis?: LifecyclePolicyDetailExclusionRulesAmis;
}
export interface StartResourceStateUpdateRequest {
    resourceArn: string;
    state: ResourceState;
    executionRole?: string;
    includeResources?: ResourceStateUpdateIncludeResources;
    exclusionRules?: ResourceStateUpdateExclusionRules;
    updateAt?: Date;
    clientToken: string;
}
export interface StartResourceStateUpdateResponse {
    lifecycleExecutionId?: string;
    resourceArn?: string;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateDistributionConfigurationRequest {
    distributionConfigurationArn: string;
    description?: string;
    distributions: Distribution[];
    clientToken: string;
}
export interface UpdateDistributionConfigurationResponse {
    requestId?: string;
    clientToken?: string;
    distributionConfigurationArn?: string;
}
export interface UpdateImagePipelineRequest {
    imagePipelineArn: string;
    description?: string;
    imageRecipeArn?: string;
    containerRecipeArn?: string;
    infrastructureConfigurationArn: string;
    distributionConfigurationArn?: string;
    imageTestsConfiguration?: ImageTestsConfiguration;
    enhancedImageMetadataEnabled?: boolean;
    schedule?: Schedule;
    status?: PipelineStatus;
    clientToken: string;
    imageScanningConfiguration?: ImageScanningConfiguration;
    workflows?: WorkflowConfiguration[];
    loggingConfiguration?: PipelineLoggingConfiguration;
    executionRole?: string;
    imageTags?: {
        [key: string]: string | undefined;
    };
}
export interface UpdateImagePipelineResponse {
    requestId?: string;
    clientToken?: string;
    imagePipelineArn?: string;
}
export interface UpdateInfrastructureConfigurationRequest {
    infrastructureConfigurationArn: string;
    description?: string;
    instanceTypes?: string[];
    instanceProfileName: string;
    securityGroupIds?: string[];
    subnetId?: string;
    logging?: Logging;
    keyPair?: string;
    terminateInstanceOnFailure?: boolean;
    snsTopicArn?: string;
    resourceTags?: {
        [key: string]: string | undefined;
    };
    instanceMetadataOptions?: InstanceMetadataOptions;
    placement?: Placement;
    clientToken: string;
}
export interface UpdateInfrastructureConfigurationResponse {
    requestId?: string;
    clientToken?: string;
    infrastructureConfigurationArn?: string;
}
export interface UpdateLifecyclePolicyRequest {
    lifecyclePolicyArn: string;
    description?: string;
    status?: LifecyclePolicyStatus;
    executionRole: string;
    resourceType: LifecyclePolicyResourceType;
    policyDetails: LifecyclePolicyDetail[];
    resourceSelection: LifecyclePolicyResourceSelection;
    clientToken: string;
}
export interface UpdateLifecyclePolicyResponse {
    lifecyclePolicyArn?: string;
}
export type ErrorMessage = string;
export type CancelImageCreationError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Cancels the creation of an image. This operation can only be used on
 * images in a non-terminal state. Cancellation is asynchronous: the request
 * returns immediately, then Image Builder stops the running build and moves the image
 * to the `CANCELLED` state. Output resources that the build already
 * created, such as AMIs and snapshots, aren't removed.
 */
export declare const cancelImageCreation: API.OperationMethod<CancelImageCreationRequest, CancelImageCreationResponse, CancelImageCreationError, Credentials | HttpClient.HttpClient>;
export type CancelLifecycleExecutionError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Cancels a lifecycle execution - a single run of lifecycle actions that a
 * lifecycle policy or a StartResourceStateUpdate request
 * started. You can only cancel an execution that hasn't reached a
 * terminal state. Cancellation is asynchronous and doesn't undo
 * completed lifecycle actions.
 */
export declare const cancelLifecycleExecution: API.OperationMethod<CancelLifecycleExecutionRequest, CancelLifecycleExecutionResponse, CancelLifecycleExecutionError, Credentials | HttpClient.HttpClient>;
export type CreateComponentError = CallRateLimitExceededException | ClientException | DryRunOperationException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterCombinationException | InvalidRequestException | InvalidVersionNumberException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a new component that can be used to build, validate, test, and assess your
 * image. The component is based on a YAML document that you specify using exactly one of
 * the following methods:
 *
 * - Inline, using the `data` property in the request body.
 *
 * - A URL that points to a YAML document file stored in Amazon S3, using the
 * `uri` property in the request body.
 *
 * Image Builder determines the component type from the document. If the document
 * contains a single phase named `test`, the component type is
 * `TEST`. Otherwise, the component type is `BUILD`.
 */
export declare const createComponent: API.OperationMethod<CreateComponentRequest, CreateComponentResponse, CreateComponentError, Credentials | HttpClient.HttpClient>;
export type CreateContainerRecipeError = CallRateLimitExceededException | ClientException | DryRunOperationException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | InvalidVersionNumberException | ResourceAlreadyExistsException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a new container recipe. Container recipes define how images are configured,
 * tested, and assessed.
 */
export declare const createContainerRecipe: API.OperationMethod<CreateContainerRecipeRequest, CreateContainerRecipeResponse, CreateContainerRecipeError, Credentials | HttpClient.HttpClient>;
export type CreateDistributionConfigurationError = CallRateLimitExceededException | ClientException | DryRunOperationException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterCombinationException | InvalidRequestException | ResourceAlreadyExistsException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a new distribution configuration. Distribution configurations define
 * and configure the outputs for your images, including the target Regions,
 * accounts, and settings for each Region.
 */
export declare const createDistributionConfiguration: API.OperationMethod<CreateDistributionConfigurationRequest, CreateDistributionConfigurationResponse, CreateDistributionConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateImageError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a new image along with all configured output resources defined in the
 * distribution configuration. You must specify exactly one recipe for your image, using
 * either a `containerRecipeArn` or an `imageRecipeArn`.
 *
 * The response returns as soon as Image Builder creates the new image resource.
 * The image build process runs asynchronously. To check its progress, call
 * GetImage and check the image status.
 */
export declare const createImage: API.OperationMethod<CreateImageRequest, CreateImageResponse, CreateImageError, Credentials | HttpClient.HttpClient>;
export type CreateImagePipelineError = CallRateLimitExceededException | ClientException | DryRunOperationException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceAlreadyExistsException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a new image pipeline. Use image pipelines to automate the creation and
 * distribution of images. You must specify exactly one recipe for the pipeline,
 * using either a `containerRecipeArn` or an
 * `imageRecipeArn`.
 */
export declare const createImagePipeline: API.OperationMethod<CreateImagePipelineRequest, CreateImagePipelineResponse, CreateImagePipelineError, Credentials | HttpClient.HttpClient>;
export type CreateImageRecipeError = CallRateLimitExceededException | ClientException | DryRunOperationException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | InvalidVersionNumberException | ResourceAlreadyExistsException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a new image recipe. Image recipes define how images are configured, tested,
 * and assessed.
 */
export declare const createImageRecipe: API.OperationMethod<CreateImageRecipeRequest, CreateImageRecipeResponse, CreateImageRecipeError, Credentials | HttpClient.HttpClient>;
export type CreateInfrastructureConfigurationError = CallRateLimitExceededException | ClientException | DryRunOperationException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceAlreadyExistsException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | InvalidParameterValueException | CommonErrors;
/**
 * Creates a new infrastructure configuration. An infrastructure configuration defines
 * the environment in which your image will be built and tested.
 */
export declare const createInfrastructureConfiguration: API.OperationMethod<CreateInfrastructureConfigurationRequest, CreateInfrastructureConfigurationResponse, CreateInfrastructureConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateLifecyclePolicyError = CallRateLimitExceededException | ClientException | DryRunOperationException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceAlreadyExistsException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a lifecycle policy resource.
 */
export declare const createLifecyclePolicy: API.OperationMethod<CreateLifecyclePolicyRequest, CreateLifecyclePolicyResponse, CreateLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type CreateWorkflowError = CallRateLimitExceededException | ClientException | DryRunOperationException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterCombinationException | InvalidRequestException | InvalidVersionNumberException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a new workflow or a new version of an existing workflow. If a workflow
 * with the same name and semantic version already exists, and your request changes
 * its configuration, Image Builder creates a new build version.
 * If the configuration is identical to the latest build version, the request
 * fails because that workflow configuration already exists.
 */
export declare const createWorkflow: API.OperationMethod<CreateWorkflowRequest, CreateWorkflowResponse, CreateWorkflowError, Credentials | HttpClient.HttpClient>;
export type DeleteComponentError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a component build version. The request fails with
 * `ResourceDependencyException` if an image recipe or container
 * recipe references this component version. It also fails if the component
 * build version is shared with other accounts.
 */
export declare const deleteComponent: API.OperationMethod<DeleteComponentRequest, DeleteComponentResponse, DeleteComponentError, Credentials | HttpClient.HttpClient>;
export type DeleteContainerRecipeError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes a container recipe. The request fails with
 * `ResourceDependencyException` if the recipe is shared with other
 * accounts, or if an image pipeline references it.
 */
export declare const deleteContainerRecipe: API.OperationMethod<DeleteContainerRecipeRequest, DeleteContainerRecipeResponse, DeleteContainerRecipeError, Credentials | HttpClient.HttpClient>;
export type DeleteDistributionConfigurationError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a distribution configuration. You can't delete a configuration
 * that an image pipeline still references. The request fails with
 * `ResourceDependencyException`. Update or delete the referencing
 * pipelines first.
 */
export declare const deleteDistributionConfiguration: API.OperationMethod<DeleteDistributionConfigurationRequest, DeleteDistributionConfigurationResponse, DeleteDistributionConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteImageError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an Image Builder image resource. This does not delete any EC2 AMIs or ECR container
 * images that are created during the image build process. You must clean those up
 * separately, using the appropriate Amazon EC2 or Amazon ECR console actions, or API or CLI
 * commands.
 *
 * The request fails with `ResourceDependencyException` if the image
 * is shared with other accounts, or if other resources depend on it. It also
 * fails while the image build is still running. Cancel an in-progress build
 * with CancelImageCreation before you delete the image.
 *
 * - To deregister an EC2 Linux AMI, see Deregister your
 * Linux AMI in the
 * *Amazon EC2 User Guide*
 * .
 *
 * - To deregister an EC2 Windows AMI, see Deregister your
 * Windows AMI in the
 * *Amazon EC2 Windows Guide*
 * .
 *
 * - To delete a container image from Amazon ECR, see Deleting
 * an image in the *Amazon ECR User Guide*.
 */
export declare const deleteImage: API.OperationMethod<DeleteImageRequest, DeleteImageResponse, DeleteImageError, Credentials | HttpClient.HttpClient>;
export type DeleteImagePipelineError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an image pipeline. Images that the pipeline created aren't
 * deleted - remove those separately with DeleteImage. You
 * can delete a pipeline while a build that it started is still running. The
 * build continues independently.
 */
export declare const deleteImagePipeline: API.OperationMethod<DeleteImagePipelineRequest, DeleteImagePipelineResponse, DeleteImagePipelineError, Credentials | HttpClient.HttpClient>;
export type DeleteImageRecipeError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an image recipe.
 */
export declare const deleteImageRecipe: API.OperationMethod<DeleteImageRecipeRequest, DeleteImageRecipeResponse, DeleteImageRecipeError, Credentials | HttpClient.HttpClient>;
export type DeleteInfrastructureConfigurationError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an infrastructure configuration. You can't delete a configuration
 * that an image pipeline still references. The request fails with
 * `ResourceDependencyException`. Update or delete the referencing
 * pipelines first.
 */
export declare const deleteInfrastructureConfiguration: API.OperationMethod<DeleteInfrastructureConfigurationRequest, DeleteInfrastructureConfigurationResponse, DeleteInfrastructureConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteLifecyclePolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the specified lifecycle policy resource. Deleting the policy removes
 * its schedule, so no further lifecycle runs occur for that policy. If a
 * lifecycle execution is in progress for the policy, Image Builder cancels it. Deletion
 * doesn't revert actions that the policy already applied to your
 * resources.
 */
export declare const deleteLifecyclePolicy: API.OperationMethod<DeleteLifecyclePolicyRequest, DeleteLifecyclePolicyResponse, DeleteLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkflowError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes a specific workflow resource. You can't delete a workflow build
 * version while an image pipeline references it. The request fails with
 * `ResourceDependencyException`.
 */
export declare const deleteWorkflow: API.OperationMethod<DeleteWorkflowRequest, DeleteWorkflowResponse, DeleteWorkflowError, Credentials | HttpClient.HttpClient>;
export type DistributeImageError = AccessDeniedException | CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Distributes an existing AMI to target Regions and accounts without running
 * the full image build process. This operation only runs the distribution
 * phase on an image that has already been built.
 */
export declare const distributeImage: API.OperationMethod<DistributeImageRequest, DistributeImageResponse, DistributeImageError, Credentials | HttpClient.HttpClient>;
export type GetComponentError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a component object.
 */
export declare const getComponent: API.OperationMethod<GetComponentRequest, GetComponentResponse, GetComponentError, Credentials | HttpClient.HttpClient>;
export type GetComponentPolicyError = CallRateLimitExceededException | ForbiddenException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves a component policy.
 */
export declare const getComponentPolicy: API.OperationMethod<GetComponentPolicyRequest, GetComponentPolicyResponse, GetComponentPolicyError, Credentials | HttpClient.HttpClient>;
export type GetContainerRecipeError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves a container recipe.
 */
export declare const getContainerRecipe: API.OperationMethod<GetContainerRecipeRequest, GetContainerRecipeResponse, GetContainerRecipeError, Credentials | HttpClient.HttpClient>;
export type GetContainerRecipePolicyError = CallRateLimitExceededException | ForbiddenException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves the policy for a container recipe.
 */
export declare const getContainerRecipePolicy: API.OperationMethod<GetContainerRecipePolicyRequest, GetContainerRecipePolicyResponse, GetContainerRecipePolicyError, Credentials | HttpClient.HttpClient>;
export type GetDistributionConfigurationError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a distribution configuration.
 */
export declare const getDistributionConfiguration: API.OperationMethod<GetDistributionConfigurationRequest, GetDistributionConfigurationResponse, GetDistributionConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetImageError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves an image.
 */
export declare const getImage: API.OperationMethod<GetImageRequest, GetImageResponse, GetImageError, Credentials | HttpClient.HttpClient>;
export type GetImagePipelineError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves an image pipeline.
 */
export declare const getImagePipeline: API.OperationMethod<GetImagePipelineRequest, GetImagePipelineResponse, GetImagePipelineError, Credentials | HttpClient.HttpClient>;
export type GetImagePolicyError = CallRateLimitExceededException | ForbiddenException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves an image policy.
 */
export declare const getImagePolicy: API.OperationMethod<GetImagePolicyRequest, GetImagePolicyResponse, GetImagePolicyError, Credentials | HttpClient.HttpClient>;
export type GetImageRecipeError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves an image recipe.
 */
export declare const getImageRecipe: API.OperationMethod<GetImageRecipeRequest, GetImageRecipeResponse, GetImageRecipeError, Credentials | HttpClient.HttpClient>;
export type GetImageRecipePolicyError = CallRateLimitExceededException | ForbiddenException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves an image recipe policy.
 */
export declare const getImageRecipePolicy: API.OperationMethod<GetImageRecipePolicyRequest, GetImageRecipePolicyResponse, GetImageRecipePolicyError, Credentials | HttpClient.HttpClient>;
export type GetInfrastructureConfigurationError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves an infrastructure configuration.
 */
export declare const getInfrastructureConfiguration: API.OperationMethod<GetInfrastructureConfigurationRequest, GetInfrastructureConfigurationResponse, GetInfrastructureConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetLifecycleExecutionError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves runtime information for a lifecycle execution - a single run of
 * lifecycle actions that a lifecycle policy or a
 * StartResourceStateUpdate request started.
 */
export declare const getLifecycleExecution: API.OperationMethod<GetLifecycleExecutionRequest, GetLifecycleExecutionResponse, GetLifecycleExecutionError, Credentials | HttpClient.HttpClient>;
export type GetLifecyclePolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves details for the specified image lifecycle policy.
 */
export declare const getLifecyclePolicy: API.OperationMethod<GetLifecyclePolicyRequest, GetLifecyclePolicyResponse, GetLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type GetMarketplaceResourceError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Verifies the subscription and performs resource dependency checks on the
 * requested Amazon Web Services Marketplace resource. The caller must be entitled to the resource. For
 * Amazon Web Services Marketplace components, the response contains fields to download the components
 * and their artifacts.
 */
export declare const getMarketplaceResource: API.OperationMethod<GetMarketplaceResourceRequest, GetMarketplaceResourceResponse, GetMarketplaceResourceError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves a workflow resource object.
 */
export declare const getWorkflow: API.OperationMethod<GetWorkflowRequest, GetWorkflowResponse, GetWorkflowError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowExecutionError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves runtime information for a specific runtime instance
 * of the workflow.
 */
export declare const getWorkflowExecution: API.OperationMethod<GetWorkflowExecutionRequest, GetWorkflowExecutionResponse, GetWorkflowExecutionError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowStepExecutionError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves runtime information for a specific runtime instance of
 * the workflow step.
 */
export declare const getWorkflowStepExecution: API.OperationMethod<GetWorkflowStepExecutionRequest, GetWorkflowStepExecutionResponse, GetWorkflowStepExecutionError, Credentials | HttpClient.HttpClient>;
export type ImportComponentError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterCombinationException | InvalidRequestException | InvalidVersionNumberException | ResourceInUseException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Imports a component and transforms its data into a component document. For
 * the `SHELL` format, Image Builder wraps your script in a component
 * document with a single step that runs the script.
 */
export declare const importComponent: API.OperationMethod<ImportComponentRequest, ImportComponentResponse, ImportComponentError, Credentials | HttpClient.HttpClient>;
export type ImportDiskImageError = AccessDeniedException | ClientException | ServiceException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Imports a Windows operating system image from a verified Microsoft ISO disk
 * file. The following disk images are supported:
 *
 * - Windows 11 Enterprise
 *
 * The response returns as soon as Image Builder creates the new image resource in the
 * `PENDING` state. The conversion from ISO file to AMI then runs
 * asynchronously on an EC2 instance that Image Builder launches with the specified
 * infrastructure configuration.
 */
export declare const importDiskImage: API.OperationMethod<ImportDiskImageRequest, ImportDiskImageResponse, ImportDiskImageError, Credentials | HttpClient.HttpClient>;
export type ImportVmImageError = ClientException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Creates an Image Builder image resource from an Amazon EC2 VM import task. The response
 * returns as soon as Image Builder creates the image resource in the
 * `PENDING` state. Image Builder then monitors the import task
 * asynchronously. When the task completes, Image Builder records the AMI that it
 * produced as the new image's output resource and marks the image
 * `AVAILABLE`. You can then use the imported image as the base
 * image for your recipes.
 *
 * To create the VM import task, use the Amazon EC2 API ImportImage
 * operation, or the import-image
 * CLI command.
 */
export declare const importVmImage: API.OperationMethod<ImportVmImageRequest, ImportVmImageResponse, ImportVmImageError, Credentials | HttpClient.HttpClient>;
export type ListComponentBuildVersionsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of component build versions for the specified component
 * version ARN. You can only list build versions for components that your
 * account owns. Deprecated build versions aren't included in the
 * results.
 */
export declare const listComponentBuildVersions: API.PaginatedOperationMethod<ListComponentBuildVersionsRequest, ListComponentBuildVersionsResponse, ListComponentBuildVersionsError, Credentials | HttpClient.HttpClient, ComponentSummary>;
export type ListComponentsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the list of components that you have access to. By default, the
 * response doesn't include components in the
 * `DEPRECATED` state. To list deprecated components, use the
 * `status` filter with the value `DEPRECATED`.
 *
 * The semantic version has four nodes: ../.
 * You can assign values for the first three, and can filter on all of them.
 *
 * **Filtering:** You can use wildcards (x) to specify the most recent versions or nodes when
 * selecting the base image or components for your recipe. When you use a wildcard in any node, all nodes
 * to the right of the first wildcard must also be wildcards.
 */
export declare const listComponents: API.PaginatedOperationMethod<ListComponentsRequest, ListComponentsResponse, ListComponentsError, Credentials | HttpClient.HttpClient, ComponentVersion>;
export type ListContainerRecipesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of container recipes.
 */
export declare const listContainerRecipes: API.PaginatedOperationMethod<ListContainerRecipesRequest, ListContainerRecipesResponse, ListContainerRecipesError, Credentials | HttpClient.HttpClient, ContainerRecipeSummary>;
export type ListDistributionConfigurationsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of distribution configurations.
 */
export declare const listDistributionConfigurations: API.PaginatedOperationMethod<ListDistributionConfigurationsRequest, ListDistributionConfigurationsResponse, ListDistributionConfigurationsError, Credentials | HttpClient.HttpClient, DistributionConfigurationSummary>;
export type ListImageBuildVersionsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of image build versions.
 */
export declare const listImageBuildVersions: API.PaginatedOperationMethod<ListImageBuildVersionsRequest, ListImageBuildVersionsResponse, ListImageBuildVersionsError, Credentials | HttpClient.HttpClient, ImageSummary>;
export type ListImagePackagesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the packages that are associated with an image build version, as determined by
 * Amazon Web Services Systems Manager Inventory at build time.
 */
export declare const listImagePackages: API.PaginatedOperationMethod<ListImagePackagesRequest, ListImagePackagesResponse, ListImagePackagesError, Credentials | HttpClient.HttpClient, ImagePackage>;
export type ListImagePipelineImagesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of images created by the specified pipeline.
 */
export declare const listImagePipelineImages: API.PaginatedOperationMethod<ListImagePipelineImagesRequest, ListImagePipelineImagesResponse, ListImagePipelineImagesError, Credentials | HttpClient.HttpClient, ImageSummary>;
export type ListImagePipelinesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of image pipelines.
 */
export declare const listImagePipelines: API.PaginatedOperationMethod<ListImagePipelinesRequest, ListImagePipelinesResponse, ListImagePipelinesError, Credentials | HttpClient.HttpClient, ImagePipeline>;
export type ListImageRecipesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of image recipes.
 */
export declare const listImageRecipes: API.PaginatedOperationMethod<ListImageRecipesRequest, ListImageRecipesResponse, ListImageRecipesError, Credentials | HttpClient.HttpClient, ImageRecipeSummary>;
export type ListImagesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the list of images that you have access to.
 */
export declare const listImages: API.PaginatedOperationMethod<ListImagesRequest, ListImagesResponse, ListImagesError, Credentials | HttpClient.HttpClient, ImageVersion>;
export type ListImageScanFindingAggregationsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of image scan aggregations for your account. You can filter by the type
 * of key that Image Builder uses to group results. For example, if you want to get a list of
 * findings by severity level for one of your pipelines, you might specify your pipeline
 * with the `imagePipelineArn` filter. If you don't specify a filter, Image Builder
 * returns an aggregation for your account.
 *
 * To streamline results, you can use the following filters in your request:
 *
 * - `imageBuildVersionArn`
 *
 * - `imagePipelineArn`
 *
 * - `vulnerabilityId`
 */
export declare const listImageScanFindingAggregations: API.PaginatedOperationMethod<ListImageScanFindingAggregationsRequest, ListImageScanFindingAggregationsResponse, ListImageScanFindingAggregationsError, Credentials | HttpClient.HttpClient, ImageScanFindingAggregation>;
export type ListImageScanFindingsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of image scan findings for your account. Amazon Inspector generates the
 * findings when it scans images that have scanning enabled.
 */
export declare const listImageScanFindings: API.PaginatedOperationMethod<ListImageScanFindingsRequest, ListImageScanFindingsResponse, ListImageScanFindingsError, Credentials | HttpClient.HttpClient, ImageScanFinding>;
export type ListInfrastructureConfigurationsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of infrastructure configurations.
 */
export declare const listInfrastructureConfigurations: API.PaginatedOperationMethod<ListInfrastructureConfigurationsRequest, ListInfrastructureConfigurationsResponse, ListInfrastructureConfigurationsError, Credentials | HttpClient.HttpClient, InfrastructureConfigurationSummary>;
export type ListLifecycleExecutionResourcesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Lists resources that the runtime instance of the image lifecycle identified for lifecycle actions.
 */
export declare const listLifecycleExecutionResources: API.PaginatedOperationMethod<ListLifecycleExecutionResourcesRequest, ListLifecycleExecutionResourcesResponse, ListLifecycleExecutionResourcesError, Credentials | HttpClient.HttpClient, LifecycleExecutionResource>;
export type ListLifecycleExecutionsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves the lifecycle runtime history for the specified resource.
 */
export declare const listLifecycleExecutions: API.PaginatedOperationMethod<ListLifecycleExecutionsRequest, ListLifecycleExecutionsResponse, ListLifecycleExecutionsError, Credentials | HttpClient.HttpClient, LifecycleExecution>;
export type ListLifecyclePoliciesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves a list of lifecycle policies in your Amazon Web Services account.
 */
export declare const listLifecyclePolicies: API.PaginatedOperationMethod<ListLifecyclePoliciesRequest, ListLifecyclePoliciesResponse, ListLifecyclePoliciesError, Credentials | HttpClient.HttpClient, LifecyclePolicySummary>;
export type ListTagsForResourceError = InvalidParameterException | ResourceNotFoundException | ServiceException | CommonErrors;
/**
 * Returns the list of tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWaitingWorkflowStepsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the workflow steps in your Amazon Web Services account that have paused at a
 * `WaitForAction` step, and are waiting for you to respond. To send
 * a response, call SendWorkflowStepAction.
 */
export declare const listWaitingWorkflowSteps: API.PaginatedOperationMethod<ListWaitingWorkflowStepsRequest, ListWaitingWorkflowStepsResponse, ListWaitingWorkflowStepsError, Credentials | HttpClient.HttpClient, WorkflowStepExecution>;
export type ListWorkflowBuildVersionsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of build versions for a specific workflow resource.
 */
export declare const listWorkflowBuildVersions: API.PaginatedOperationMethod<ListWorkflowBuildVersionsRequest, ListWorkflowBuildVersionsResponse, ListWorkflowBuildVersionsError, Credentials | HttpClient.HttpClient, WorkflowSummary>;
export type ListWorkflowExecutionsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of workflow runtime instance metadata objects for a specific image build
 * version.
 */
export declare const listWorkflowExecutions: API.PaginatedOperationMethod<ListWorkflowExecutionsRequest, ListWorkflowExecutionsResponse, ListWorkflowExecutionsError, Credentials | HttpClient.HttpClient, WorkflowExecutionMetadata>;
export type ListWorkflowsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Lists workflow versions based on filtering parameters. To list the build
 * versions of a specific workflow version, call
 * ListWorkflowBuildVersions.
 */
export declare const listWorkflows: API.PaginatedOperationMethod<ListWorkflowsRequest, ListWorkflowsResponse, ListWorkflowsError, Credentials | HttpClient.HttpClient, WorkflowVersion>;
export type ListWorkflowStepExecutionsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns runtime data for each step in a runtime instance of the workflow
 * that you specify in the request.
 */
export declare const listWorkflowStepExecutions: API.PaginatedOperationMethod<ListWorkflowStepExecutionsRequest, ListWorkflowStepExecutionsResponse, ListWorkflowStepExecutionsError, Credentials | HttpClient.HttpClient, WorkflowStepMetadata>;
export type PutComponentPolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidParameterValueException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Applies a policy to a component. The preferred way to share resources is with
 * the RAM API CreateResourceShare. If you use the PutComponentPolicy operation instead, you
 * must also call the RAM API PromoteResourceShareCreatedFromPolicy. Otherwise, the resource
 * isn't visible to the principals that it's shared with.
 */
export declare const putComponentPolicy: API.OperationMethod<PutComponentPolicyRequest, PutComponentPolicyResponse, PutComponentPolicyError, Credentials | HttpClient.HttpClient>;
export type PutContainerRecipePolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidParameterValueException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Applies a policy to a container recipe. The preferred way to share resources is with
 * the RAM API CreateResourceShare. If you use the PutContainerRecipePolicy operation instead, you
 * must also call the RAM API PromoteResourceShareCreatedFromPolicy. Otherwise, the resource
 * isn't visible to the principals that it's shared with.
 */
export declare const putContainerRecipePolicy: API.OperationMethod<PutContainerRecipePolicyRequest, PutContainerRecipePolicyResponse, PutContainerRecipePolicyError, Credentials | HttpClient.HttpClient>;
export type PutImagePolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidParameterValueException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Applies a policy to an image. The preferred way to share resources is with
 * the RAM API CreateResourceShare. If you use the PutImagePolicy operation instead, you
 * must also call the RAM API PromoteResourceShareCreatedFromPolicy. Otherwise, the resource
 * isn't visible to the principals that it's shared with.
 */
export declare const putImagePolicy: API.OperationMethod<PutImagePolicyRequest, PutImagePolicyResponse, PutImagePolicyError, Credentials | HttpClient.HttpClient>;
export type PutImageRecipePolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidParameterValueException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Applies a policy to an image recipe. The preferred way to share resources is with
 * the RAM API CreateResourceShare. If you use the PutImageRecipePolicy operation instead, you
 * must also call the RAM API PromoteResourceShareCreatedFromPolicy. Otherwise, the resource
 * isn't visible to the principals that it's shared with.
 */
export declare const putImageRecipePolicy: API.OperationMethod<PutImageRecipePolicyRequest, PutImageRecipePolicyResponse, PutImageRecipePolicyError, Credentials | HttpClient.HttpClient>;
export type RetryImageError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retries a failed or canceled image build without rebuilding the phases
 * that already completed. The image re-runs asynchronously in place: the same
 * build version returns to the test or distribution phase where it failed and
 * continues from there. No new image build version is created. Retry is only
 * supported for AMI-based images.
 */
export declare const retryImage: API.OperationMethod<RetryImageRequest, RetryImageResponse, RetryImageError, Credentials | HttpClient.HttpClient>;
export type SendWorkflowStepActionError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterValueException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Sends an action to a workflow step that has paused at a
 * `WaitForAction` step, so that image creation can continue.
 * To find the steps that are waiting for an action, call
 * ListWaitingWorkflowSteps.
 */
export declare const sendWorkflowStepAction: API.OperationMethod<SendWorkflowStepActionRequest, SendWorkflowStepActionResponse, SendWorkflowStepActionError, Credentials | HttpClient.HttpClient>;
export type StartImagePipelineExecutionError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Manually triggers a pipeline to create an image. You can start a build
 * this way whether the pipeline is enabled or disabled. The response returns
 * as soon as Image Builder creates the new image resource and queues the build. Use
 * the returned `imageBuildVersionArn` with
 * GetImage to track build progress.
 */
export declare const startImagePipelineExecution: API.OperationMethod<StartImagePipelineExecutionRequest, StartImagePipelineExecutionResponse, StartImagePipelineExecutionError, Credentials | HttpClient.HttpClient>;
export type StartResourceStateUpdateError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Begins an ad-hoc state change for the specified image build version.
 * This is a one-time operation - if you schedule the update, it runs only
 * once. If the
 * request includes underlying resources, or schedules the update far enough in
 * the future, Image Builder runs the update as an asynchronous lifecycle execution and
 * returns its identifier. Otherwise, for target states other than
 * `DELETED`, the state change applies immediately. If a request
 * that starts a lifecycle execution arrives while the image already has one in
 * progress, Image Builder rejects it.
 */
export declare const startResourceStateUpdate: API.OperationMethod<StartResourceStateUpdateRequest, StartResourceStateUpdateResponse, StartResourceStateUpdateError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidParameterException | ResourceNotFoundException | ServiceException | CommonErrors;
/**
 * Adds a tag to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InvalidParameterException | ResourceNotFoundException | ServiceException | CommonErrors;
/**
 * Removes a tag from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDistributionConfigurationError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterCombinationException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a distribution configuration. Distribution configurations define and
 * configure the outputs for your images, including the target Regions,
 * accounts, and settings for each Region.
 *
 * This operation doesn't support selective updates. The request
 * replaces the stored configuration, so include every setting that you
 * want to keep.
 */
export declare const updateDistributionConfiguration: API.OperationMethod<UpdateDistributionConfigurationRequest, UpdateDistributionConfigurationResponse, UpdateDistributionConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateImagePipelineError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an image pipeline. Use image pipelines to automate the creation and
 * distribution of images. You must specify exactly one recipe for your image, using either
 * a `containerRecipeArn` or an `imageRecipeArn`. The
 * recipe must be the same type, image or container, as the pipeline's current
 * recipe.
 *
 * UpdateImagePipeline does not support selective updates. The request
 * replaces the pipeline's entire configuration, so include every setting
 * that you want to keep. Any optional property that you omit is removed
 * or reset to its default.
 */
export declare const updateImagePipeline: API.OperationMethod<UpdateImagePipelineRequest, UpdateImagePipelineResponse, UpdateImagePipelineError, Credentials | HttpClient.HttpClient>;
export type UpdateInfrastructureConfigurationError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | InvalidParameterValueException | CommonErrors;
/**
 * Updates an infrastructure configuration. An infrastructure configuration defines
 * the environment in which Image Builder builds and tests your image.
 *
 * This operation doesn't support selective updates.
 * The request replaces the configuration, so include every setting that
 * you want to keep. Omitted optional properties are cleared.
 */
export declare const updateInfrastructureConfiguration: API.OperationMethod<UpdateInfrastructureConfigurationRequest, UpdateInfrastructureConfigurationResponse, UpdateInfrastructureConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateLifecyclePolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterCombinationException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Updates the specified lifecycle policy. The request replaces the existing
 * policy configuration rather than merging changes, so re-specify every setting
 * that you want to keep. The `resourceType` must match the existing
 * policy's value.
 */
export declare const updateLifecyclePolicy: API.OperationMethod<UpdateLifecyclePolicyRequest, UpdateLifecyclePolicyResponse, UpdateLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=imagebuilder.d.ts.map