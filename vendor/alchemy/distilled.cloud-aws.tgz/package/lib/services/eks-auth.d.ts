import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials as Creds } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ExpiredTokenException_base: S.TaggedErrorClass<"ExpiredTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ExpiredTokenException extends /*@__PURE__*/ ExpiredTokenException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const InvalidTokenException_base: S.TaggedErrorClass<"InvalidTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTokenException extends /*@__PURE__*/ InvalidTokenException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type ClusterName = string;
export type JwtToken = string | redacted.Redacted<string>;
export interface AssumeRoleForPodIdentityRequest {
    clusterName: string;
    token: string | redacted.Redacted<string>;
    eksNodeName?: string;
    instanceId?: string;
    zone?: string;
}
export interface Subject {
    namespace: string;
    serviceAccount: string;
}
export interface PodIdentityAssociation {
    associationArn: string;
    associationId: string;
}
export interface AssumedRoleUser {
    arn: string;
    assumeRoleId: string;
}
export interface Credentials {
    sessionToken: string | redacted.Redacted<string>;
    secretAccessKey: string | redacted.Redacted<string>;
    accessKeyId: string;
    expiration: Date;
}
export interface AssumeRoleForPodIdentityResponse {
    subject: Subject;
    audience: string;
    podIdentityAssociation: PodIdentityAssociation;
    assumedRoleUser: AssumedRoleUser;
    credentials: Credentials;
}
export type AssumeRoleForPodIdentityError = AccessDeniedException | ExpiredTokenException | InternalServerException | InvalidParameterException | InvalidRequestException | InvalidTokenException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * The Amazon EKS Auth API and the `AssumeRoleForPodIdentity` action are only used by the EKS Pod Identity Agent.
 *
 * We recommend that applications use the Amazon Web Services SDKs to connect to Amazon Web Services services; if credentials from an EKS Pod Identity association are available in the pod, the latest versions of the SDKs use them automatically.
 */
export declare const assumeRoleForPodIdentity: API.OperationMethod<AssumeRoleForPodIdentityRequest, AssumeRoleForPodIdentityResponse, AssumeRoleForPodIdentityError, Creds | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=eks-auth.d.ts.map