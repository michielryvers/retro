import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
    readonly QuotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
    readonly FieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type CatalogName = string;
export type BenefitApplicationIdentifier = string;
export interface Amendment {
    FieldPath: string;
    NewValue: string;
}
export type AmendmentList = Amendment[];
export interface AmendBenefitApplicationInput {
    Catalog: string;
    ClientToken: string;
    Revision: string;
    Identifier: string;
    AmendmentReason: string;
    Amendments: Amendment[];
}
export interface AmendBenefitApplicationOutput {
}
export type Arn = string;
export interface AssociateBenefitApplicationResourceInput {
    Catalog: string;
    BenefitApplicationIdentifier: string;
    ResourceArn: string;
}
export type BenefitApplicationId = string;
export interface AssociateBenefitApplicationResourceOutput {
    Id?: string;
    Arn?: string;
    Revision?: string;
}
export interface CancelBenefitApplicationInput {
    Catalog: string;
    ClientToken: string;
    Identifier: string;
    Reason?: string;
}
export interface CancelBenefitApplicationOutput {
}
export type BenefitApplicationName = string;
export type BenefitApplicationDescription = string;
export type FulfillmentType = "CREDITS" | "CASH" | "ACCESS" | (string & {});
export type FulfillmentTypes = FulfillmentType[];
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type Tags = Tag[];
export type Arns = string[];
export type ContactEmail = string | redacted.Redacted<string>;
export type ContactFirstName = string | redacted.Redacted<string>;
export type ContactLastName = string | redacted.Redacted<string>;
export type ContactPhone = string | redacted.Redacted<string>;
export interface Contact {
    Email?: string | redacted.Redacted<string>;
    FirstName?: string | redacted.Redacted<string>;
    LastName?: string | redacted.Redacted<string>;
    BusinessTitle?: string;
    Phone?: string | redacted.Redacted<string>;
}
export type Contacts = Contact[];
export type FileURI = string;
export interface FileInput {
    FileURI: string;
    BusinessUseCase?: string;
}
export type FileInputDetails = FileInput[];
export interface CreateBenefitApplicationInput {
    Catalog: string;
    ClientToken: string;
    Name?: string;
    Description?: string;
    BenefitIdentifier: string;
    FulfillmentTypes?: FulfillmentType[];
    BenefitApplicationDetails?: any;
    Tags?: Tag[];
    AssociatedResources?: string[];
    PartnerContacts?: Contact[];
    FileDetails?: FileInput[];
}
export interface CreateBenefitApplicationOutput {
    Id?: string;
    Arn?: string;
    Revision?: string;
}
export interface DisassociateBenefitApplicationResourceInput {
    Catalog: string;
    BenefitApplicationIdentifier: string;
    ResourceArn: string;
}
export interface DisassociateBenefitApplicationResourceOutput {
    Id?: string;
    Arn?: string;
    Revision?: string;
}
export interface GetBenefitInput {
    Catalog: string;
    Identifier: string;
}
export type Program = string;
export type Programs = string[];
export type BenefitStatus = "ACTIVE" | "INACTIVE" | (string & {});
export interface GetBenefitOutput {
    Id?: string;
    Catalog?: string;
    Arn?: string;
    Name?: string;
    Description?: string;
    Programs?: string[];
    FulfillmentTypes?: FulfillmentType[];
    BenefitRequestSchema?: any;
    Status?: BenefitStatus;
}
export type BenefitAllocationIdentifier = string;
export interface GetBenefitAllocationInput {
    Catalog: string;
    Identifier: string;
}
export type BenefitAllocationId = string;
export type BenefitAllocationArn = string;
export type BenefitAllocationStatus = "ACTIVE" | "INACTIVE" | "FULFILLED" | (string & {});
export type BenefitId = string;
export type BenefitIdentifiers = string[];
export type CurrencyCode = "AED" | "AMD" | "ARS" | "AUD" | "AWG" | "AZN" | "BBD" | "BDT" | "BGN" | "BMD" | "BND" | "BOB" | "BRL" | "BSD" | "BYR" | "BZD" | "CAD" | "CHF" | "CLP" | "CNY" | "COP" | "CRC" | "CZK" | "DKK" | "DOP" | "EEK" | "EGP" | "EUR" | "GBP" | "GEL" | "GHS" | "GTQ" | "GYD" | "HKD" | "HNL" | "HRK" | "HTG" | "HUF" | "IDR" | "ILS" | "INR" | "ISK" | "JMD" | "JPY" | "KES" | "KHR" | "KRW" | "KYD" | "KZT" | "LBP" | "LKR" | "LTL" | "LVL" | "MAD" | "MNT" | "MOP" | "MUR" | "MVR" | "MXN" | "MYR" | "NAD" | "NGN" | "NIO" | "NOK" | "NZD" | "PAB" | "PEN" | "PHP" | "PKR" | "PLN" | "PYG" | "QAR" | "RON" | "RUB" | "SAR" | "SEK" | "SGD" | "SIT" | "SKK" | "THB" | "TND" | "TRY" | "TTD" | "TWD" | "TZS" | "UAH" | "USD" | "UYU" | "UZS" | "VND" | "XAF" | "XCD" | "XOF" | "XPF" | "ZAR" | (string & {});
export interface MonetaryValue {
    Amount: string;
    CurrencyCode: CurrencyCode;
}
export interface IssuanceDetail {
    IssuanceId?: string;
    IssuanceAmount?: MonetaryValue;
    IssuedAt?: Date;
}
export interface DisbursementDetails {
    DisbursedAmount?: MonetaryValue;
    IssuanceDetails?: IssuanceDetail;
}
export interface ConsumableDetails {
    AllocatedAmount?: MonetaryValue;
    RemainingAmount?: MonetaryValue;
    UtilizedAmount?: MonetaryValue;
    IssuanceDetails?: IssuanceDetail;
}
export interface CreditCode {
    AwsAccountId: string;
    Value: MonetaryValue;
    AwsCreditCode: string;
    Status: BenefitAllocationStatus;
    IssuedAt: Date;
    ExpiresAt: Date;
}
export type CreditCodes = CreditCode[];
export interface CreditDetails {
    AllocatedAmount: MonetaryValue;
    IssuedAmount: MonetaryValue;
    Codes: CreditCode[];
}
export interface AccessDetails {
    Description?: string;
}
export type FulfillmentDetails = {
    DisbursementDetails: DisbursementDetails;
    ConsumableDetails?: never;
    CreditDetails?: never;
    AccessDetails?: never;
} | {
    DisbursementDetails?: never;
    ConsumableDetails: ConsumableDetails;
    CreditDetails?: never;
    AccessDetails?: never;
} | {
    DisbursementDetails?: never;
    ConsumableDetails?: never;
    CreditDetails: CreditDetails;
    AccessDetails?: never;
} | {
    DisbursementDetails?: never;
    ConsumableDetails?: never;
    CreditDetails?: never;
    AccessDetails: AccessDetails;
};
export interface GetBenefitAllocationOutput {
    Id?: string;
    Catalog?: string;
    Arn?: string;
    Name?: string;
    Description?: string;
    Status?: BenefitAllocationStatus;
    StatusReason?: string;
    BenefitApplicationId?: string;
    BenefitId?: string;
    FulfillmentType?: FulfillmentType;
    ApplicableBenefitIds?: string[];
    FulfillmentDetail?: FulfillmentDetails;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    StartsAt?: Date;
    ExpiresAt?: Date;
}
export interface GetBenefitApplicationInput {
    Catalog: string;
    Identifier: string;
}
export type BenefitApplicationStatus = "PENDING_SUBMISSION" | "IN_REVIEW" | "ACTION_REQUIRED" | "APPROVED" | "REJECTED" | "CANCELED" | (string & {});
export type BenefitApplicationStage = string;
export type StatusReasonCode = string;
export type StatusReasonCodes = string[];
export type FileType = "application/msword" | "application/vnd.openxmlformats-officedocument.wordprocessingml.document" | "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" | "application/vnd.openxmlformats-officedocument.presentationml.presentation" | "application/pdf" | "image/png" | "image/jpeg" | "image/svg+xml" | "text/csv" | (string & {});
export interface FileDetail {
    FileURI: string;
    BusinessUseCase?: string;
    FileName?: string;
    FileStatus?: string;
    FileStatusReason?: string;
    FileType?: FileType;
    CreatedBy?: string;
    CreatedAt?: Date;
}
export type FileDetails = FileDetail[];
export interface GetBenefitApplicationOutput {
    Id?: string;
    Arn?: string;
    Catalog?: string;
    BenefitId?: string;
    Name?: string;
    Description?: string;
    FulfillmentTypes?: FulfillmentType[];
    BenefitApplicationDetails?: any;
    Programs?: string[];
    Status?: BenefitApplicationStatus;
    Stage?: string;
    StatusReason?: string;
    StatusReasonCode?: string;
    StatusReasonCodes?: string[];
    CreatedAt?: Date;
    UpdatedAt?: Date;
    Revision?: string;
    AssociatedResources?: string[];
    PartnerContacts?: Contact[];
    FileDetails?: FileDetail[];
}
export type BenefitApplicationIdentifierList = string[];
export type BenefitAllocationStatusList = BenefitAllocationStatus[];
export interface ListBenefitAllocationsInput {
    Catalog: string;
    FulfillmentTypes?: FulfillmentType[];
    BenefitIdentifiers?: string[];
    BenefitApplicationIdentifiers?: string[];
    Status?: BenefitAllocationStatus[];
    MaxResults?: number;
    NextToken?: string;
}
export type BenefitAllocationName = string;
export type BenefitIds = string[];
export interface BenefitAllocationSummary {
    Id?: string;
    Catalog?: string;
    Arn?: string;
    Status?: BenefitAllocationStatus;
    StatusReason?: string;
    Name?: string;
    BenefitId?: string;
    BenefitApplicationId?: string;
    FulfillmentTypes?: FulfillmentType[];
    CreatedAt?: Date;
    ExpiresAt?: Date;
    ApplicableBenefitIds?: string[];
}
export type BenefitAllocationSummaries = BenefitAllocationSummary[];
export interface ListBenefitAllocationsOutput {
    BenefitAllocationSummaries?: BenefitAllocationSummary[];
    NextToken?: string;
}
export type Statuses = BenefitApplicationStatus[];
export type Stages = string[];
export type ResourceType = "OPPORTUNITY" | "BENEFIT_ALLOCATION" | (string & {});
export interface AssociatedResource {
    ResourceType?: ResourceType;
    ResourceIdentifier?: string;
    ResourceArn?: string;
}
export type AssociatedResources = AssociatedResource[];
export interface ListBenefitApplicationsInput {
    Catalog: string;
    Programs?: string[];
    FulfillmentTypes?: FulfillmentType[];
    BenefitIdentifiers?: string[];
    Status?: BenefitApplicationStatus[];
    Stages?: string[];
    AssociatedResources?: AssociatedResource[];
    AssociatedResourceArns?: string[];
    MaxResults?: number;
    NextToken?: string;
}
export type Attributes = {
    [key: string]: string | undefined;
};
export interface BenefitApplicationSummary {
    Catalog?: string;
    Name?: string;
    Id?: string;
    Arn?: string;
    BenefitId?: string;
    Programs?: string[];
    FulfillmentTypes?: FulfillmentType[];
    Status?: BenefitApplicationStatus;
    Stage?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    BenefitApplicationDetails?: {
        [key: string]: string | undefined;
    };
    AssociatedResources?: string[];
}
export type BenefitApplicationSummaries = BenefitApplicationSummary[];
export interface ListBenefitApplicationsOutput {
    BenefitApplicationSummaries?: BenefitApplicationSummary[];
    NextToken?: string;
}
export type BenefitStatuses = BenefitStatus[];
export interface ListBenefitsInput {
    Catalog: string;
    Programs?: string[];
    FulfillmentTypes?: FulfillmentType[];
    Status?: BenefitStatus[];
    MaxResults?: number;
    NextToken?: string;
}
export interface BenefitSummary {
    Id?: string;
    Catalog?: string;
    Arn?: string;
    Name?: string;
    Description?: string;
    Programs?: string[];
    FulfillmentTypes?: FulfillmentType[];
    Status?: BenefitStatus;
}
export type BenefitSummaries = BenefitSummary[];
export interface ListBenefitsOutput {
    BenefitSummaries?: BenefitSummary[];
    NextToken?: string;
}
export type TaggableResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[];
}
export interface RecallBenefitApplicationInput {
    Catalog: string;
    ClientToken?: string;
    Identifier: string;
    Reason: string;
}
export interface RecallBenefitApplicationOutput {
}
export interface SubmitBenefitApplicationInput {
    Catalog: string;
    Identifier: string;
}
export interface SubmitBenefitApplicationOutput {
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateBenefitApplicationInput {
    Catalog: string;
    ClientToken: string;
    Name?: string;
    Description?: string;
    Identifier: string;
    Revision: string;
    BenefitApplicationDetails?: any;
    PartnerContacts?: Contact[];
    FileDetails?: FileInput[];
}
export interface UpdateBenefitApplicationOutput {
    Id?: string;
    Arn?: string;
    Revision?: string;
}
export type ValidationExceptionReason = "unknownOperation" | "cannotParse" | "fieldValidationFailed" | "other" | "BUSINESS_VALIDATION_FAILED" | (string & {});
export type ValidationExceptionErrorCode = "REQUIRED_FIELD_MISSING" | "INVALID_ENUM_VALUE" | "INVALID_STRING_FORMAT" | "INVALID_VALUE" | "NOT_ENOUGH_VALUES" | "TOO_MANY_VALUES" | "INVALID_RESOURCE_STATE" | "DUPLICATE_KEY_VALUE" | "VALUE_OUT_OF_RANGE" | "ACTION_NOT_PERMITTED" | (string & {});
export interface ValidationExceptionField {
    Name: string;
    Message: string;
    Code?: ValidationExceptionErrorCode;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AmendBenefitApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies an existing benefit application by applying amendments to specific fields while maintaining revision control.
 */
export declare const amendBenefitApplication: API.OperationMethod<AmendBenefitApplicationInput, AmendBenefitApplicationOutput, AmendBenefitApplicationError, Credentials | HttpClient.HttpClient>;
export type AssociateBenefitApplicationResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Links an AWS resource to an existing benefit application for tracking and management purposes.
 */
export declare const associateBenefitApplicationResource: API.OperationMethod<AssociateBenefitApplicationResourceInput, AssociateBenefitApplicationResourceOutput, AssociateBenefitApplicationResourceError, Credentials | HttpClient.HttpClient>;
export type CancelBenefitApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels a benefit application that is currently in progress, preventing further processing.
 */
export declare const cancelBenefitApplication: API.OperationMethod<CancelBenefitApplicationInput, CancelBenefitApplicationOutput, CancelBenefitApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateBenefitApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new benefit application for a partner to request access to AWS benefits and programs.
 */
export declare const createBenefitApplication: API.OperationMethod<CreateBenefitApplicationInput, CreateBenefitApplicationOutput, CreateBenefitApplicationError, Credentials | HttpClient.HttpClient>;
export type DisassociateBenefitApplicationResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the association between an AWS resource and a benefit application.
 */
export declare const disassociateBenefitApplicationResource: API.OperationMethod<DisassociateBenefitApplicationResourceInput, DisassociateBenefitApplicationResourceOutput, DisassociateBenefitApplicationResourceError, Credentials | HttpClient.HttpClient>;
export type GetBenefitError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific benefit available in the partner catalog.
 */
export declare const getBenefit: API.OperationMethod<GetBenefitInput, GetBenefitOutput, GetBenefitError, Credentials | HttpClient.HttpClient>;
export type GetBenefitAllocationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific benefit allocation that has been granted to a partner.
 */
export declare const getBenefitAllocation: API.OperationMethod<GetBenefitAllocationInput, GetBenefitAllocationOutput, GetBenefitAllocationError, Credentials | HttpClient.HttpClient>;
export type GetBenefitApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific benefit application.
 */
export declare const getBenefitApplication: API.OperationMethod<GetBenefitApplicationInput, GetBenefitApplicationOutput, GetBenefitApplicationError, Credentials | HttpClient.HttpClient>;
export type ListBenefitAllocationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of benefit allocations based on specified filter criteria.
 */
export declare const listBenefitAllocations: API.PaginatedOperationMethod<ListBenefitAllocationsInput, ListBenefitAllocationsOutput, ListBenefitAllocationsError, Credentials | HttpClient.HttpClient, BenefitAllocationSummary>;
export type ListBenefitApplicationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of benefit applications based on specified filter criteria.
 */
export declare const listBenefitApplications: API.PaginatedOperationMethod<ListBenefitApplicationsInput, ListBenefitApplicationsOutput, ListBenefitApplicationsError, Credentials | HttpClient.HttpClient, BenefitApplicationSummary>;
export type ListBenefitsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of available benefits based on specified filter criteria.
 */
export declare const listBenefits: API.PaginatedOperationMethod<ListBenefitsInput, ListBenefitsOutput, ListBenefitsError, Credentials | HttpClient.HttpClient, BenefitSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves all tags associated with a specific resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RecallBenefitApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Recalls a submitted benefit application, returning it to draft status for further modifications.
 */
export declare const recallBenefitApplication: API.OperationMethod<RecallBenefitApplicationInput, RecallBenefitApplicationOutput, RecallBenefitApplicationError, Credentials | HttpClient.HttpClient>;
export type SubmitBenefitApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Submits a benefit application for review and processing by AWS.
 */
export declare const submitBenefitApplication: API.OperationMethod<SubmitBenefitApplicationInput, SubmitBenefitApplicationOutput, SubmitBenefitApplicationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds or updates tags for a specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes specified tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBenefitApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing benefit application with new information while maintaining revision control.
 */
export declare const updateBenefitApplication: API.OperationMethod<UpdateBenefitApplicationInput, UpdateBenefitApplicationOutput, UpdateBenefitApplicationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=partnercentral-benefits.d.ts.map