/**
 * AWS restXml Protocol Implementation
 *
 * https://smithy.io/2.0/aws/protocols/aws-restxml-protocol.html
 */
import { type ProtocolImpl } from "../client/protocol.ts";
export declare const restXmlProtocol: ProtocolImpl;
//# sourceMappingURL=rest-xml.d.ts.map