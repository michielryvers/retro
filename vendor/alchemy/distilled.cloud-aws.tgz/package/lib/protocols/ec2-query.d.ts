/**
 * AWS EC2 Query Protocol Implementation
 *
 * https://smithy.io/2.0/aws/protocols/aws-ec2-query-protocol.html
 *
 * Key differences from awsQuery:
 * - All lists are flattened (no wrapper elements)
 * - Uses aws.protocols#ec2QueryName trait for custom query key names
 * - Response root is {OperationName}Response (no result wrapper)
 * - Errors wrapped in <Response><Errors><Error>...</Error></Errors><RequestID>...</RequestID></Response>
 * - HTTP binding traits are ignored
 */
import { type ProtocolImpl } from "../client/protocol.ts";
export declare const ec2QueryProtocol: ProtocolImpl;
//# sourceMappingURL=ec2-query.d.ts.map