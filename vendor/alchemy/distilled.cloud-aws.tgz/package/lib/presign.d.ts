import * as Effect from "effect/Effect";
import * as Credentials from "./credentials-service.ts";
import * as Region from "./region.ts";
import * as SigV4 from "./sigv4.ts";
/** Errors returned when resolving credentials or signing a URL. */
export type PresignError = Credentials.CredentialsError | SigV4.SigningError;
/** Services required by the presigning helpers. */
export type PresignContext = Credentials.Credentials | Region.Region;
/**
 * Options for {@link presignUrl}.
 */
export interface PresignUrlOptions {
    /**
     * HTTP method the presigned URL authorizes.
     * @default "GET"
     */
    readonly method?: string;
    /**
     * Full URL to presign (scheme + host + path + any query parameters that
     * should be part of the signature).
     */
    readonly url: string;
    /**
     * SigV4 signing service name (e.g. `s3`, `execute-api`, `lambda`).
     */
    readonly service: string;
    /**
     * SigV4 signing region. Defaults to the {@link Region.Region} service.
     */
    readonly region?: string;
    /**
     * Number of seconds the URL remains valid.
     * @default 900
     */
    readonly expiresIn?: number;
    /**
     * Headers to sign into the URL (`X-Amz-SignedHeaders`). The consumer of
     * the presigned URL must send these headers verbatim or the signature
     * fails to validate.
     */
    readonly headers?: Record<string, string>;
    /**
     * Fixed signing datetime in `YYYYMMDDTHHMMSSZ` format. Defaults to now.
     * Signing is deterministic for a fixed datetime + credentials, which
     * makes this useful for tests.
     */
    readonly datetime?: string;
}
/**
 * SigV4 query-string presigning for an arbitrary AWS URL.
 *
 * Pure client-side computation -- no AWS API call is made. Credentials are
 * resolved from the {@link Credentials.Credentials} service (the presigned
 * URL inherits that identity's IAM permissions) and the signing region
 * defaults to the {@link Region.Region} service.
 */
export declare const presignUrl: (options: PresignUrlOptions) => Effect.Effect<string, PresignError, PresignContext>;
/**
 * Options for {@link presignS3Url}.
 */
export interface PresignS3UrlOptions {
    /**
     * HTTP method the presigned URL authorizes.
     * @default "GET"
     */
    readonly method?: "GET" | "PUT" | "HEAD" | "DELETE";
    /**
     * Name of the bucket the object lives in.
     */
    readonly bucket: string;
    /**
     * Key of the object.
     */
    readonly key: string;
    /**
     * Specific object version to access, signed as the `versionId` query
     * parameter. If omitted, S3 uses the current version.
     */
    readonly versionId?: string;
    /**
     * Region the bucket lives in (used for both the endpoint and the SigV4
     * credential scope). Defaults to the {@link Region.Region} service.
     */
    readonly region?: string;
    /**
     * Number of seconds the URL remains valid.
     * @default 900
     */
    readonly expiresIn?: number;
    /**
     * `Content-Type` header to sign into the URL. The consumer (e.g. a PUT
     * uploader) must send exactly this `Content-Type` or S3 rejects the
     * request with a signature mismatch.
     */
    readonly contentType?: string;
    /**
     * `response-content-type` override for GET URLs -- S3 responds with this
     * `Content-Type` regardless of the stored object's metadata.
     */
    readonly responseContentType?: string;
    /**
     * Fixed signing datetime in `YYYYMMDDTHHMMSSZ` format. Defaults to now.
     */
    readonly datetime?: string;
}
/**
 * SigV4 query-string presigning for S3 objects.
 *
 * Produces a virtual-hosted-style URL
 * (`https://{bucket}.s3.{region}.amazonaws.com/{key}`), or a path-style URL
 * under the custom {@link Endpoint.Endpoint} when one is provided (e.g.
 * LocalStack or S3-compatible stores).
 *
 * Pure client-side computation -- no AWS API call is made. The URL inherits
 * the IAM permissions of the identity resolved from the
 * {@link Credentials.Credentials} service.
 */
export declare const presignS3Url: (options: PresignS3UrlOptions) => Effect.Effect<string, PresignError, PresignContext>;
//# sourceMappingURL=presign.d.ts.map