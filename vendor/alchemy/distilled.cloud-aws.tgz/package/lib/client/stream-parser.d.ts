/**
 * Stream Parser - converts raw event stream bytes into typed events.
 *
 * This module handles:
 * 1. Detecting event stream members in output schemas
 * 2. Parsing wire format into StreamEvent objects
 * 3. Decoding event payloads into typed schema instances
 * 4. Filtering out internal events (initial-response)
 */
import type * as AST from "effect/SchemaAST";
/**
 * Stream parser function - transforms deserialized response if it contains an event stream.
 * Returns the modified response, or null if no event stream handling was needed.
 */
export type StreamParser = (deserialized: Record<string, unknown> | undefined) => Record<string, unknown> | null;
/**
 * Create a stream parser for the given output schema.
 *
 * @param outputAst - The AST of the output schema
 * @returns A stream parser function, or null if no event stream member
 */
export declare function makeStreamParser(outputAst: AST.AST): StreamParser | null;
//# sourceMappingURL=stream-parser.d.ts.map