import * as Effect from "effect/Effect";
import { ParseError } from "../errors.ts";
import type { Operation } from "./operation.ts";
import type { Request } from "./request.ts";
import type { Response } from "./response.ts";
/**
 * A ProtocolHandler is created by a Protocol factory function
 * with the operation pre-bound, allowing one-time preprocessing
 * of schema metadata (like getEncodedPropertySignatures, etc.).
 */
/**
 * Result of deserializing an error response.
 * Contains the sanitized error code and any additional data fields.
 */
export interface DeserializedError {
    /** The sanitized error code (e.g., "ValidationException") */
    errorCode: string;
    /** Additional data fields from the error response */
    data: Record<string, unknown>;
}
export interface ProtocolHandler {
    /**
     * Serialize an input object into a request, without effects. Throws the
     * `ParseError` an input that does not match the schema fails with.
     */
    readonly serialize: (input: unknown) => Request;
    /**
     * Deserialize a 2xx response whose body has been read as text, without
     * effects. A body the protocol cannot read comes back as {@link Unreadable}.
     */
    readonly deserializeText: (response: TextResponse) => unknown;
    /**
     * Deserialize a 2xx response of an output with a streaming, event-stream
     * or blob member; `undefined` for outputs that are read as text (see
     * {@link deserialize}).
     */
    readonly deserializeStream?: (response: Response) => Effect.Effect<unknown, ParseError> | undefined;
    /**
     * Deserialize an error response and extract the error code and data.
     * @param response - The HTTP error response to deserialize
     * @returns Effect yielding the error code and additional data
     */
    deserializeError(response: Response): Effect.Effect<DeserializedError, ParseError>;
}
/** A handler whose implementation loads on first use. */
export interface LazyHandler {
    readonly ready: Effect.Effect<ProtocolHandler>;
}
/** A response whose body has been read as text. */
export interface TextResponse extends Response {
    body: string;
}
/**
 * A 2xx body a protocol could not read into its output shape (e.g. invalid
 * JSON). Strict mode fails with `error`; lenient mode returns `asRead`.
 */
export declare class Unreadable {
    readonly error: ParseError;
    readonly asRead: unknown;
    constructor(error: ParseError, asRead: unknown);
}
/**
 * A Protocol is a factory function that takes an operation
 * and returns a ProtocolHandler with pre-computed metadata.
 *
 * This allows expensive operations like getEncodedPropertySignatures
 * to be done once at initialization time rather than on every request.
 */
export type Protocol = (operation: Operation) => ProtocolHandler | LazyHandler;
/** A protocol implementation: builds the handler directly. */
export type ProtocolImpl = (operation: Operation) => ProtocolHandler;
/** The loaded handler. */
export declare const loadHandler: (handler: ProtocolHandler | LazyHandler) => Effect.Effect<ProtocolHandler>;
/** `serialize` as an effect: a thrown `ParseError` fails, anything else dies. */
export declare const serializeEffect: (serialize: (input: unknown) => Request) => (input: unknown) => Effect.Effect<Request, ParseError>;
/**
 * A 2xx response through the handler: `deserializeStream` for outputs
 * that stream, else the body (read as text) through `deserializeText`. An {@link Unreadable} body fails in strict mode and is returned as
 * read in lenient mode.
 */
export declare const deserialize: (protocol: ProtocolHandler, response: Response) => Effect.Effect<unknown, ParseError>;
/** The handler with effect-returning `serializeRequest` / `deserializeResponse`, for tests. */
export declare const withEffects: (handler: ProtocolHandler) => {
    serialize: (input: unknown) => Request;
    deserializeText: (response: TextResponse) => unknown;
    deserializeStream?: (response: Response) => Effect.Effect<unknown, ParseError> | undefined;
    /**
     * Deserialize an error response and extract the error code and data.
     * @param response - The HTTP error response to deserialize
     * @returns Effect yielding the error code and additional data
     */
    deserializeError(response: Response): Effect.Effect<DeserializedError, ParseError>;
    serializeRequest: (input: unknown) => Effect.Effect<Request, ParseError>;
    deserializeResponse: (response: Response) => Effect.Effect<unknown, ParseError, never>;
};
//# sourceMappingURL=protocol.d.ts.map