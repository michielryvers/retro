/**
 * Request Builder - wraps Protocol and Middleware to build complete requests.
 *
 * This layer:
 * 1. Fills in idempotency tokens with generated UUIDs if not provided
 * 2. Uses the Protocol to serialize the input into a Request
 * 3. Applies middleware (e.g., checksum computation, streaming body handling)
 * 4. Adds common headers
 *
 * This is independently testable without making HTTP requests.
 */
import * as Effect from "effect/Effect";
import type { ParseError } from "../errors.ts";
import type { Operation } from "./operation.ts";
import { type ProtocolHandler } from "./protocol.ts";
import type { Request } from "./request.ts";
/**
 * Create a request builder for a given operation and its (loaded) protocol
 * handler: fills idempotency tokens, serializes, applies middleware
 * (checksums, streaming bodies) and adds the common headers.
 *
 * Operations without middleware or a streaming payload build the request
 * synchronously: the builder returns it directly and throws the
 * `ParseError` of an input that does not match the schema. Other
 * operations return an effect.
 */
export declare const makeRequestBuilder: (operation: Operation, protocol: ProtocolHandler) => ((input: unknown) => Request | Effect.Effect<Request, ParseError>);
//# sourceMappingURL=request-builder.d.ts.map