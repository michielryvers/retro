/**
 * Response Parser - wraps Protocol to parse responses.
 *
 * This layer:
 * 1. Uses the Protocol to deserialize the response
 * 2. Applies schema decoding/validation
 * 3. Handles error responses
 * 4. Delegates event stream parsing to stream-parser.ts
 *
 * This is independently testable without making HTTP requests.
 */
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import type * as SchemaIssue from "effect/SchemaIssue";
import type { Operation } from "./operation.ts";
import { type Protocol } from "./protocol.ts";
import type { Response } from "./response.ts";
export interface ResponseParserOptions {
    /** Override the protocol (otherwise discovered from schema annotations) */
    protocol?: Protocol;
    /** Skip schema validation - returns raw deserialized response */
    skipValidation?: boolean;
    /** AWS service SDK ID for error context (e.g., "S3", "DynamoDB") */
    service?: string;
    /** Operation name for error context (e.g., "createBucket", "putObject") */
    operation?: string;
}
export type ResponseParser<A, R> = (response: Response) => Effect.Effect<A, SchemaIssue.Issue, R>;
/** The outcome of decoding a 2xx response: the value, or the error the call fails with. */
export type Decoded = {
    readonly ok: true;
    readonly value: unknown;
} | {
    readonly ok: false;
    readonly error: unknown;
};
/**
 * The success path of {@link makeResponseParser} without effects, for an
 * operation whose output never streams: converts what the protocol's
 * `deserializeText` read and, unless lenient, validates it. `context` is
 * the calling fiber's (it carries the validation mode).
 */
export declare const makeSuccessDecoder: (operation: Operation<any, any, any>, options?: ResponseParserOptions) => (context: Context.Context<any>, read: unknown) => Decoded;
/**
 * Create a response parser for a given operation.
 *
 * Expensive work (protocol discovery, preprocessing) is done once at creation time.
 *
 * @param operation - The operation (with input/output schemas and protocol annotations)
 * @param options - Optional overrides
 * @returns A function that parses responses
 */
export declare const makeResponseParser: <A>(operation: Operation<any, any, any>, options?: ResponseParserOptions) => ((response: Response) => Effect.Effect<any, never, never>);
//# sourceMappingURL=response-parser.d.ts.map