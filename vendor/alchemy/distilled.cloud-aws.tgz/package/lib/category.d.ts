export * from "@distilled.cloud/core/category";
//# sourceMappingURL=category.d.ts.map