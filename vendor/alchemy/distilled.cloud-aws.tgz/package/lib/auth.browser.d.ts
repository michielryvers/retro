import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import type { CredentialsError, ResolvedCredentials } from "./credentials-service.ts";
declare const Auth_base: Context.ServiceClass<Auth, "distilled-aws/AWS/Auth", {
    loadProfile: (profileName: string) => Effect.Effect<AwsProfileConfig, CredentialsError>;
    loadProfileCredentials: (profileName: string) => Effect.Effect<ResolvedCredentials, CredentialsError>;
}>;
export declare class Auth extends /*@__PURE__*/ Auth_base {
}
export declare const Default: Effect.Effect<{
    loadProfile: (profileName: string) => Effect.Effect<AwsProfileConfig, CredentialsError>;
    loadProfileCredentials: (profileName: string) => Effect.Effect<ResolvedCredentials, CredentialsError>;
}, never, never>;
export interface AwsProfileConfig {
    /** Set by `aws login`; names the cached console session. */
    login_session?: string;
    sso_session?: string;
    sso_account_id?: string;
    sso_role_name?: string;
    region?: string;
    output?: string;
    sso_start_url?: string;
    sso_region?: string;
}
export interface SsoProfileConfig extends AwsProfileConfig {
    sso_start_url: string;
    sso_region: string;
    sso_account_id: string;
    sso_role_name: string;
}
/**
 * Cached SSO token retrieved from SSO login flow.
 * @public
 */
export interface SSOToken {
    /**
     * A base64 encoded string returned by the sso-oidc service.
     */
    accessToken: string;
    /**
     * The expiration time of the accessToken as an RFC 3339 formatted timestamp.
     */
    expiresAt: string;
    /**
     * The token used to obtain an access token in the event that the accessToken is invalid or expired.
     */
    refreshToken?: string;
    /**
     * The unique identifier string for each client. The client ID generated when performing the registration
     * portion of the OIDC authorization flow. This is used to refresh the accessToken.
     */
    clientId?: string;
    /**
     * A secret string generated when performing the registration portion of the OIDC authorization flow.
     * This is used to refresh the accessToken.
     */
    clientSecret?: string;
    /**
     * The expiration time of the client registration (clientId and clientSecret) as an RFC 3339 formatted timestamp.
     */
    registrationExpiresAt?: string;
    /**
     * The configured sso_region for the profile that credentials are being resolved for.
     */
    region?: string;
    /**
     * The configured sso_start_url for the profile that credentials are being resolved for.
     */
    startUrl?: string;
}
export {};
//# sourceMappingURL=auth.browser.d.ts.map