/**
 * Endpoint Resolver - resolves endpoints using compiled Smithy rules.
 *
 * This layer:
 * 1. Extracts the endpoint resolver function from schema annotations
 * 2. Builds endpoint parameters from input and region
 * 3. Calls the resolver to get endpoint URL, headers, and auth schemes
 * 4. Adjusts request path when context params are moved to hostname
 *
 * The resolver function is compiled at code generation time from the Smithy
 * rule set, eliminating the need for runtime interpretation.
 *
 * This is independently testable without making HTTP requests.
 */
import type { Operation } from "../client/operation.ts";
import type { Request } from "../client/request.ts";
import type { ResolvedEndpoint } from "./expression.ts";
export interface EndpointResolverInput {
    /** The operation input payload */
    input: unknown;
    /** The AWS region */
    region: string;
    /** The serialized request (path may be adjusted based on endpoint resolution) */
    request: Request;
}
export interface EndpointResolverOutput {
    /** The resolved endpoint */
    endpoint: ResolvedEndpoint;
    /** The request with path adjusted if needed */
    request: Request;
}
/**
 * Create an endpoint resolver for a given operation.
 *
 * Expensive work (resolver discovery, context param extraction) is done once at creation time.
 *
 * @param operation - The operation (with input schema containing endpoint resolver annotation)
 * @returns A function that resolves endpoints from input values and region
 */
export declare const makeEndpointResolver: (operation: Operation) => ((resolverInput: EndpointResolverInput) => EndpointResolverOutput | Error) | undefined;
//# sourceMappingURL=endpoint-resolver.d.ts.map