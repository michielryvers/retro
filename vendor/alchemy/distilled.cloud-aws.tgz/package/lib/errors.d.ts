import * as S from "@distilled.cloud/core/schema-lite-typed";
import type * as HttpClientError from "effect/http/HttpClientError";
import type * as Credentials from "./credentials-service.ts";
import type * as SigV4 from "./sigv4.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ExpiredTokenException_base: S.TaggedErrorClass<"ExpiredTokenException", {
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ExpiredTokenException extends /*@__PURE__*/ ExpiredTokenException_base {
}
declare const IncompleteSignature_base: S.TaggedErrorClass<"IncompleteSignature", {
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class IncompleteSignature extends /*@__PURE__*/ IncompleteSignature_base {
}
declare const InternalFailure_base: S.TaggedErrorClass<"InternalFailure", {
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalFailure extends /*@__PURE__*/ InternalFailure_base {
}
declare const MalformedHttpRequestException_base: S.TaggedErrorClass<"MalformedHttpRequestException", {
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MalformedHttpRequestException extends /*@__PURE__*/ MalformedHttpRequestException_base {
}
declare const NotAuthorized_base: S.TaggedErrorClass<"NotAuthorized", {
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class NotAuthorized extends /*@__PURE__*/ NotAuthorized_base {
}
declare const OptInRequired_base: S.TaggedErrorClass<"OptInRequired", {
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class OptInRequired extends /*@__PURE__*/ OptInRequired_base {
}
declare const RequestAbortedException_base: S.TaggedErrorClass<"RequestAbortedException", {
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AbortedError: true;
    };
});
export declare class RequestAbortedException extends /*@__PURE__*/ RequestAbortedException_base {
}
declare const RequestEntityTooLargeException_base: S.TaggedErrorClass<"RequestEntityTooLargeException", {
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RequestEntityTooLargeException extends /*@__PURE__*/ RequestEntityTooLargeException_base {
}
declare const RequestExpired_base: S.TaggedErrorClass<"RequestExpired", {
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class RequestExpired extends /*@__PURE__*/ RequestExpired_base {
}
declare const RequestTimeoutException_base: S.TaggedErrorClass<"RequestTimeoutException", {
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class RequestTimeoutException extends /*@__PURE__*/ RequestTimeoutException_base {
}
declare const ServiceUnavailable_base: S.TaggedErrorClass<"ServiceUnavailable", {
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailable extends /*@__PURE__*/ ServiceUnavailable_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnrecognizedClientException_base: S.TaggedErrorClass<"UnrecognizedClientException", {
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnrecognizedClientException extends /*@__PURE__*/ UnrecognizedClientException_base {
}
declare const UnknownOperationException_base: S.TaggedErrorClass<"UnknownOperationException", {
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnknownOperationException extends /*@__PURE__*/ UnknownOperationException_base {
}
declare const ValidationError_base: S.TaggedErrorClass<"ValidationError", {
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationError extends /*@__PURE__*/ ValidationError_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    /** The human-readable validation failure reason from the service. */
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
    /** Machine-readable reason code (e.g. "FIELD_VALIDATION_FAILED"). */
    readonly reason: import("effect/Schema").optional<import("effect/Schema").String>;
    /** Per-field validation failures, when the service reports them. */
    readonly fieldList: import("effect/Schema").optional<import("effect/Schema").Any>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
declare const OperationAborted_base: S.TaggedErrorClass<"OperationAborted", {
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AbortedError: true;
    };
});
export declare class OperationAborted extends /*@__PURE__*/ OperationAborted_base {
}
declare const UnknownAwsError_base: S.TaggedErrorClass<"UnknownAwsError", {
    readonly errorTag: import("effect/Schema").String;
    readonly errorData: import("effect/Schema").Any;
    /** The AWS service SDK ID (e.g., "S3", "DynamoDB") */
    readonly service: import("effect/Schema").optional<import("effect/Schema").String>;
    /** The operation name (e.g., "createBucket", "putObject") */
    readonly operation: import("effect/Schema").optional<import("effect/Schema").String>;
    readonly message: import("effect/Schema").String;
}>;
export declare class UnknownAwsError extends /*@__PURE__*/ UnknownAwsError_base {
}
/**
 * Check if an error is a transient network error that should be retried.
 * These are low-level fetch/socket errors that indicate temporary connectivity issues.
 */
export declare const isTransientNetworkError: (err: unknown) => boolean;
declare const TransientFetchError_base: S.TaggedErrorClass<"TransientFetchError", {
    readonly message: import("effect/Schema").String;
    readonly cause: import("effect/Schema").Any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NetworkError: true;
    };
});
/**
 * Error thrown when a fetch request fails due to a transient network issue.
 * Marked as retryable so the default retry policy will automatically retry these.
 */
export declare class TransientFetchError extends /*@__PURE__*/ TransientFetchError_base {
}
declare const InternalError_base: S.TaggedErrorClass<"InternalError", {
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalError extends /*@__PURE__*/ InternalError_base {
}
declare const EndpointError_base: S.TaggedErrorClass<"EndpointError", {
    readonly message: import("effect/Schema").String;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
/** Error when endpoint resolution fails due to a rule error */
export declare class EndpointError extends /*@__PURE__*/ EndpointError_base {
}
declare const NoMatchingRuleError_base: S.TaggedErrorClass<"NoMatchingRuleError", {
    readonly message: import("effect/Schema").optional<import("effect/Schema").String>;
}>;
/** Error when no rule matches in the ruleset */
export declare class NoMatchingRuleError extends /*@__PURE__*/ NoMatchingRuleError_base {
}
declare const ParseError_base: S.TaggedErrorClass<"ParseError", {
    readonly message: import("effect/Schema").String;
}>;
export declare class ParseError extends /*@__PURE__*/ ParseError_base {
}
export declare const COMMON_ERRORS: readonly [typeof AccessDeniedException, typeof ExpiredTokenException, typeof IncompleteSignature, typeof InternalError, typeof InternalFailure, typeof MalformedHttpRequestException, typeof NotAuthorized, typeof OperationAborted, typeof OptInRequired, typeof RequestAbortedException, typeof RequestEntityTooLargeException, typeof RequestExpired, typeof RequestTimeoutException, typeof ServiceUnavailable, typeof ThrottlingException, typeof UnknownOperationException, typeof UnrecognizedClientException, typeof ValidationError, typeof ValidationException];
export type CommonAwsError = AccessDeniedException | ExpiredTokenException | IncompleteSignature | InternalFailure | MalformedHttpRequestException | NotAuthorized | OptInRequired | RequestAbortedException | RequestEntityTooLargeException | RequestExpired | RequestTimeoutException | ServiceUnavailable | ThrottlingException | UnrecognizedClientException | UnknownOperationException | ValidationError | ValidationException | OperationAborted;
/**
 * All error types that can be returned by AWS operations.
 *
 * `HttpClientError` belongs here because `API.make` puts it in every
 * operation's error channel (the request can fail before any AWS response
 * exists -- DNS, TLS, connection reset). Leaving it out made each generated
 * operation's declared type narrower than what it can actually fail with.
 */
export type CommonErrors = UnknownAwsError | ParseError | CommonAwsError | EndpointError | NoMatchingRuleError | SigV4.SigningError | Credentials.CredentialsError | HttpClientError.HttpClientError;
export {};
//# sourceMappingURL=errors.d.ts.map