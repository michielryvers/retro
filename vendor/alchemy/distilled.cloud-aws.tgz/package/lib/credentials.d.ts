/**
 * `@distilled.cloud/aws/Credentials` for Node, Bun and workers: everything
 * the browser entry exports, with the Node variants of `fromHttp`,
 * `fromInstanceMetadata` and `fromTemporaryCredentials` in place of the
 * browser ones, plus the providers that read `~/.aws` or run a process.
 * Each layer is defined in its provider's own file.
 */
export * from "./credentials.browser.ts";
import type * as __from_http_node from "./credential-providers/from-http.node.ts";
import type * as __from_ini from "./credential-providers/from-ini.ts";
import type * as __from_instance_metadata_node from "./credential-providers/from-instance-metadata.node.ts";
import type * as __from_login_credentials from "./credential-providers/from-login-credentials.ts";
import type * as __from_node_provider_chain from "./credential-providers/from-node-provider-chain.ts";
import type * as __from_process from "./credential-providers/from-process.ts";
import type * as __from_sso from "./credential-providers/from-sso.ts";
import type * as __from_temporary_credentials_node from "./credential-providers/from-temporary-credentials.node.ts";
import type * as __from_token_file from "./credential-providers/from-token-file.ts";
export declare const fromHttp: typeof __from_http_node.fromHttp;
export declare const fromIni: typeof __from_ini.fromIni;
export declare const fromInstanceMetadata: typeof __from_instance_metadata_node.fromInstanceMetadata;
export declare const fromLoginCredentials: typeof __from_login_credentials.fromLoginCredentials;
export declare const fromChain: typeof __from_node_provider_chain.fromChain;
export declare const fromNodeProviderChain: typeof __from_node_provider_chain.fromNodeProviderChain;
export declare const fromProcess: typeof __from_process.fromProcess;
export declare const fromSSO: typeof __from_sso.fromSSO;
export declare const fromTemporaryCredentials: typeof __from_temporary_credentials_node.fromTemporaryCredentials;
export declare const fromTokenFile: typeof __from_token_file.fromTokenFile;
//# sourceMappingURL=credentials.d.ts.map